#!/bin/bash
# plugin-lint.sh — verify every backticked `*.md` reference resolves
# Run from the plugin repo root.
set -euo pipefail

PLUGIN_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PLUGIN_ROOT"

# Files that are runtime-generated in the user's project folder (not plugin refs)
RUNTIME_FILES="pipeline-checkpoint.md entity-canon.md running-banlist.md \
    market-pulse.md model-health.md project-config.md research-bible.md \
    outline.md sources.md run.log story-bible.md progress-dashboard.md \
    word-counts.md concept-seeds.md thesis-seeds.md protagonist.md \
    antagonist.md supporting-cast.md hook-positioning.md chapter-outline.md \
    ending.md tension-tracker.md key-figures.md genre-architecture.md \
    beat-structure.md entities.md project-mode.md trope-plan.md \
    style-guide.md screenplay-source.md import-errors.md \
    chapter-01.md chapter-02.md entry.md novel.md world-setting.md \
    ch01.md ch02.md ch01-draft.md"

# Collect all backticked .md references from every SKILL.md and reference file
grep -roE '`[a-z][a-z0-9_-]*\.md`' skills/ 2>/dev/null \
    | sed 's/.*`\([^`]*\)`/\1/' \
    | sort -u > /tmp/plugin-lint-refs.txt

FAIL=0
while read -r ref; do
    # Skip runtime-generated files
    for rt in $RUNTIME_FILES; do
        [ "$ref" = "$rt" ] && continue 2
    done
    # Check whether ref exists anywhere under skills/
    if ! find skills/ -name "$ref" -type f | grep -q .; then
        echo "DEAD REFERENCE: $ref"
        FAIL=1
    fi
done < /tmp/plugin-lint-refs.txt

rm -f /tmp/plugin-lint-refs.txt

if [ "$FAIL" -eq 1 ]; then
    echo ""
    echo "Plugin lint: FAIL — dead references found"
    exit 1
else
    echo "Plugin lint: PASS — all references resolve"
    exit 0
fi
