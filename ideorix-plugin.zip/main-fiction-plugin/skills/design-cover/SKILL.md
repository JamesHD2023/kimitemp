---
name: design-cover
description: "Ideorix Fiction: design a book cover. Trigger: 'Design a cover', 'Cover art for my novel', 'Book cover prompts', 'Cover concept', 'Make a cover for [project]'. Genre-accurate concepts with AI image prompts for the supported platforms (Ideogram, Leonardo, Grok Aurora, Midjourney, Claude Design) plus print specifications. Fiction only."
---

This is a trigger entry point for the Ideorix Fiction engine. To handle
this request:

1. Read and follow `skills/ideorix/SKILL.md` from the same plugin
   (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Writers Studio flow at item 6, "Marketing & Cover".
3. Follow `skills/ideorix/references/cover-designer.md` for the
   complete cover-design protocol (genre-accurate concepts, AI image
   prompts for the supported platforms, print specifications).

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
