---
name: write-a-book
description: "Ideorix Fiction: write a novel from scratch. Trigger: 'Write a book', 'Write a [genre] novel', 'New manuscript', 'Start a story', 'Help me write fiction', 'Phase 1 setup'. Launches the 14-question setup → Story Bible → chapter-by-chapter writing pipeline. Fiction only (use research-a-project for non-fiction)."
---

This is a trigger entry point for the Ideorix Fiction engine. To handle
this request:

1. Read and follow `skills/ideorix/SKILL.md` from the same plugin
   (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Writers Studio flow at item 1, "Write a New Book".
3. Follow `skills/ideorix/references/write-a-book.md` for the
   complete Phase 1 → Phase 6 pipeline.

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
