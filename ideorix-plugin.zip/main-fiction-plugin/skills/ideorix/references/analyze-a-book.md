---
name: analyze-a-book
description: "Reverse-engineer any novel into a structural blueprint — extract genre, tropes, beats, arcs, and reusable plot templates"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Analyze a Book

Reverse-engineer an existing novel into a structural blueprint you can study or use as a template.

## File Location Discipline (MANDATORY — HARD GATE — runs FIRST)

**Before any analysis / extraction work begins, this flow MUST
confirm or establish a canonical project folder at
`~/Documents/Ideorix-Projects/[Title]/`** (where `[Title]` is
the analysed book's title or a user-chosen project name). The
extracted blueprint, structural breakdown, beat map, comp
analysis, and any companion outputs MUST be written into that
folder structure (see `core-pipeline.md` § File Location
Discipline for the canonical layout and Bash-Direct Write +
Verify protocol).

**If no project folder exists for this analysis**, run the
project-folder bootstrap BEFORE proceeding: ask for the project
title, confirm the save location, create the canonical folder
structure, and only then begin extraction.

**HARD GATE — BLOCKING.** Outputs MUST NOT be written to the
agent's working directory, a sandbox path, or any temporary
location. The user MUST be able to open every blueprint
deliverable in their own file explorer the moment the analysis
completes.

## What it extracts

| Element | What you get |
|---------|-------------|
| **Genre & subgenre** | Classification with confidence scores |
| **Beat structure** | Which template the book follows (Save the Cat, Hero's Journey, etc.) |
| **Tropes** | Identified story patterns and how they're deployed |
| **Character arcs** | Arc type per character (redemption, fall, growth, flat, etc.) |
| **Plot structure** | Act breaks, midpoint, climax, turning points |
| **Pacing map** | Chapter-by-chapter tension curve |
| **Genericized template** | A reusable plot skeleton with the specifics stripped out |

## How to start

Say any of:
- "Analyze this book"
- "Reverse-engineer [book title]"
- "Break down the structure of [book title]"
- "Extract the plot template from [book title]"

## Input options

- **Paste text** — Paste the full text or a substantial excerpt
- **Describe it** — Give the title and author, and describe the plot from memory
- **Upload file** — Provide a text file of the manuscript

**Read-Verification HARD GATE applies (see `read-verification.md`)
when the user uploads a file.** Verify the Read returned content
above the per-format threshold (PDF ≥ 100 chars, DOCX ≥ 100,
MD/TXT ≥ 20). A failed Read on an uploaded book file produces an
"analysis" of zero source content with fabricated structural
observations. Failed Reads BLOCK and surface the failure to the
user with resolution options before any structural extraction runs.

**Source Persistence HARD GATE applies (see `source-persistence.md`,
v2.7.9) when the user uploads a file (Option C).** After successful
Read, the source book is persisted to
`source-canon/{filename}` (since this is supplementary canon used to
study structural patterns, not the user's own manuscript) BEFORE the
structural extraction runs. The canon-absorbed.md marker file gives
the user an audit trail of which book was analyzed and when. Option A
(paste text) is exempt from persistence — pasted content lives in the
chat message and the analysis is the artifact.

## What you can do with the output

- Use the genericized template as an outline for your own book
- Study how a bestseller deploys tropes and beats
- Compare multiple books to find common genre patterns
- Feed the template directly into "Write a New Book" as your outline source

> **Tip:** The more text you provide, the more accurate the analysis. A full manuscript gives the best results.
