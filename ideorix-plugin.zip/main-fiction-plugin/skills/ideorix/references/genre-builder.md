---
name: genre-builder
description: Guided interview that produces a custom genre file — user invents their own genre, optionally inheriting from 1–3 existing genres as a scaffold
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Custom Genre Builder

## Purpose

Let the user design their own genre from scratch (or by stacking existing ones
as parents) and produce a fully-formed genre file that every downstream agent
— Architect, Writer, Quality Guardian, Humaniser — treats identically to a
built-in genre.

A custom genre can be used as the Primary of a standalone project, or as any
slot in a Genre Mash-Up (see `_index.md` Genre Mash-Up Mode).

## When to Use

Triggered either:
- **From inside Phase 1, Question 1** — the category list includes
  "9. Build a custom genre" as an option
- **Direct trigger phrases:**
  - "Build a custom genre"
  - "Create my own genre"
  - "Design a genre"
  - "I want a genre that isn't in the list"
  - "Custom genre builder"
  - "Add a new genre"

When triggered outside a project, the builder runs in "library-only" mode and
saves to the persistent genre library (`~/Documents/Ideorix-Projects/.genre-library/`)
for later use. When triggered inside a project, the builder additionally
offers to register the custom genre as the project's Primary.

## Output Format

The builder produces a markdown file matching the standard genre file format
documented in `_index.md`. Minimum viable sections:

```
---
name: {slug}-genre
description: "Custom genre — {display name}"
version: "1.0"
user-invocable: false
custom: true
parents: [{parent_slug_1}, {parent_slug_2}, ...]
---

# {Display Name} — Custom Genre Plugin

## Metadata
- **Genre ID:** {slug}
- **Display Name:** {display name}
- **Category:** {closest built-in category}
- **Custom:** true
- **Parents:** {parent list or "none"}
- **Created:** {ISO date}
- **Target Word Count:** {per-chapter range}

## Architect Instructions
{merged parent blocks if parents provided, PLUS user overlays}

## Writer Craft Rules
{merged parent blocks PLUS user overlays}

## Quality Check Criteria
{merged parent blocks PLUS user overlays}

## Continuity Rules
{merged parent blocks, user overlay optional}

## Genre-Specific Craft Techniques
{merged parent blocks PLUS user overlays}

## Genre-Specific Revision Rules
{merged parent blocks PLUS user overlays}

## Names & Patterns to Avoid
{merged parent blocks PLUS user overlays}

## AI Crutch Phrases (ELIMINATE ALL)
{merged parent tables PLUS user additions}
```

Sections with parent content inherit; sections without parents require
direct user input (with sensible defaults offered).

---

## Storage Locations

Custom genre files live in one of two places:

### 1. Project-local (default for in-project builds)

```
~/Documents/Ideorix-Projects/{Title}/engine-data/custom-genres/{slug}.md
```

Use this when the custom genre only makes sense for one project. The genre
is automatically loaded for that project and ignored for all others.

### 2. Persistent library (cross-project)

```
~/Documents/Ideorix-Projects/.genre-library/{slug}.md
```

Use this when the user wants to reuse the custom genre across multiple
projects. The builder creates `.genre-library/` the first time it's needed.

### 3. Both (recommended for most cases)

The builder writes to both locations — the project gets its own copy so
it's self-contained, AND the library gets a copy for future projects.

The user picks which storage approach during Phase 1 of the interview
(question A5).

---

## Interview Flow

Run each phase sequentially. Use AskUserQuestion for every question. Present
one question at a time. Do NOT batch. Let the user abandon the build at any
step by typing "cancel" — if so, delete any partial files and return to
the previous menu.

### Phase A: Scoping (5 questions)

**A1 — Genre display name:**
"What do you want to call this genre? (e.g. 'Neon Western', 'Suburban Horror',
'Cozy Noir')"

**A2 — One-paragraph genre definition:**
"In one paragraph, what is this genre? What's the reader promise — what do
readers pick it up to feel? Aim for 3-5 sentences."

**A3 — Parent inheritance count:**
"Does this genre inherit from existing ones?
  - No — build from scratch (slower but maximum freedom)
  - Yes, 1 parent (recommended — fastest path to a working genre)
  - Yes, 2 parents (good for hybrids — e.g. 'cozy + noir')
  - Yes, 3 parents (for complex hybrids)"

**A4 — Which parents:** (only if A3 > 0)
Show the same category list as Q1 (Phase 1). For each parent slot, let the
user drill down into a category and pick a built-in genre. Validate:
- Each parent must be different
- Each parent must be a built-in genre (no custom genres as parents to
  avoid cycles in v1; this may relax in a later version)

**A5 — Save location:**
"Where should this genre live?
  - Project only (lives inside this project; won't appear in future projects)
  - Library only (saves to cross-project library, not tied to this project)
  - Both — recommended (project gets its own copy AND the library stores one)"

If the builder is running outside a project (library-only mode), skip this
question and always save to the library.

### Phase B: Identity (6 questions)

**B1 — Closest category:**
"Which existing category is this closest to? (Mystery-Crime, Romance,
Fantasy-Scifi, Literary-Contemporary, Horror-Gothic, Historical-Adventure,
YA-Childrens, or Other) This determines where it shows up in menus."

**B2 — Icon emoji:**
"Pick a single emoji for the menu icon (e.g. 🌵 for western, 🕯️ for gothic).
'skip' is fine — we'll default to 📖."

**B3 — Target word count tier:**
"Typical chapter length for this genre?
  - 1,400 (novelette chapters — light/fast genres)
  - 2,500 (novella/novel standard — default)
  - 3,000 (longer chapters — epic/literary)
  - 3,500+ (very long chapters — sprawling epics only)"

**B4 — Reader expectations:**
"Three to six things readers expect from this genre. Short phrases.
Example for 'Neon Western':
  - Frontier outlaw archetypes in near-future settings
  - Codes of honour vs corporate power
  - Wide-open visual landscapes
  - Stakes that feel personal, not civilisational
  - Understated violence with real consequences"

**B5 — Comparable titles:**
"Any comp titles that capture the feel? (Optional — 2-4 examples, or 'skip'.)"

**B6 — Tonal range:**
"Tonal descriptors (3-5 words). Examples: 'dusty, laconic, quietly
violent' or 'warm, wry, domestically unsettling'."

### Phase C: Craft (parent-aware)

**If parents were selected (A3 > 0):**

Load each parent genre file. Merge their `## Architect Instructions`,
`## Writer Craft Rules`, `## Quality Check Criteria`, and
`## Genre-Specific Craft Techniques` sections using the mash-up merge
rules from `core-pipeline.md`.

Present the merged block to the user:

```
Your custom genre will inherit these rules from {parent 1}[, {parent 2}, {parent 3}]:

[show merged Architect Instructions]
[show merged Writer Craft Rules]
[show merged Quality Check Criteria]
[show merged Craft Techniques]

For each section, do you want to:
  1. Keep as inherited (the default — builds nothing extra)
  2. Add rules (your rules are appended after the inherited ones)
  3. Replace one rule (you edit a specific inherited rule)
```

Run this review section-by-section. For "Add rules", accept a free-text
list and append to the section. For "Replace", ask which rule to replace
and what with.

**If no parents (A3 == 0):**

Ask the core craft questions directly:

**C1 — Prose style:**
"How does the prose feel? (e.g. 'terse and muscular', 'lyrical and
immersive', 'plain and reportorial', 'sardonic and wry')"

**C2 — POV preference:**
"Preferred POV? (First-person, Third-person close, Third-person omniscient,
Mixed, or No preference)"

**C3 — Dialogue density:**
"How much dialogue? (Heavy, balanced, sparse, or action-first)"

**C4 — Description density:**
"How much description? (Heavy — world-building matters, balanced — scene-serving,
sparse — dialogue-first)"

**C5 — Sentence rhythm:**
"Sentence rhythm? (Staccato, varied, long-form, mixed)"

**C6 — Three must-include chapter beats:**
"Name 3-5 beats that should appear in every chapter of this genre.
Example for 'Cozy Noir': (1) sensory domestic grounding, (2) wry
observation of a minor injustice, (3) understated emotional shift."

**C7 — Three forbidden patterns:**
"Name 3-5 things this genre should NEVER do. Example for 'Cozy Noir':
never open with violence, never resolve emotionally in one chapter,
never sanitise the moral ambiguity."

**C8 — Signature craft techniques:**
"Name 3-5 signature prose techniques that distinguish good work in
this genre. Example for 'Cozy Noir': rain-as-metaphor, observational
dialogue that reveals character, restrained sensory escalation."

**C9 — Automatic-fail criteria:**
"What would a quality check fail a manuscript in this genre for?
(3-5 criteria — be specific)"

### Phase D: Names & Patterns to Avoid (3 questions, optional)

**D1 — Tropes to avoid:**
"Any tropes this genre avoids? (Free text — 'skip' is fine if none come to mind.)"

**D2 — Name patterns to avoid:**
"Any naming conventions to avoid? (e.g. 'no punning character names',
'avoid Celtic-revival fantasy names')"

**D3 — Setting clichés to avoid:**
"Any setting clichés this genre should steer clear of? (e.g. 'no generic
dusty diner', 'no Victorian London fog unless earned')"

### Phase E: AI Crutch Phrases (single question with three paths)

This is the hardest section to get right — crutch phrases need corpus
analysis to identify properly. Offer three paths:

**E1 — Crutch phrase strategy:**
"AI Crutch Phrases are 10-15 overused patterns that signal AI-generated
prose for a given genre. They need real examples to catch. How would
you like to fill this section?

  1. Inherit from parents only (if parents were selected — uses their
     crutch phrase tables verbatim; best choice if parents exist)
  2. Seed from a similar built-in genre (pick one — the builder copies
     that genre's crutch phrase table as a starting point; you can
     edit entries later by hand in the generated file)
  3. Skip for now (builder writes a minimal placeholder table; the
     universal AI-ism detection in the Humaniser still runs — you're
     just missing genre-specific patterns until you fill them in)"

### Phase F: Review and Save

**F1 — Preview:**
Assemble the full genre file using the standard template (see "Output
Format" above). Display it to the user in full.

**F2 — Edit or approve:**
"Here's your custom genre file. Options:
  1. Approve — save as-is
  2. Edit a section — specify which, I'll ask what to change
  3. Regenerate from scratch (you'll keep your answers but I'll
     rebuild the file)"

Loop on option 2 until the user approves.

**F3 — Save:**
Write to the chosen location(s). Create parent directories as needed.
If the file already exists (slug collision), ask:
"A custom genre named {slug} already exists at {path}. Options:
  - Overwrite
  - Save with a new slug (I'll append a number)
  - Cancel"

**F4 — Post-save action:**
If the builder ran inside a project setup flow:
"Custom genre saved. Use it as this project's Primary genre?
  1. Yes — use {Display Name} as Primary (continues to Q2: English Dialect)
  2. No — just save, let me pick a different genre"

If the builder ran outside a project (direct trigger):
"Custom genre saved to {path}. It's now available next time you start a
project — you'll see it in the Question 1 category list under 'Custom
genres'. Return to the Front Gate?"

---

## Slug Generation

Derive the slug from the display name:
1. Lowercase
2. Replace spaces with hyphens
3. Remove all non-alphanumeric-hyphen characters
4. Strip leading/trailing hyphens

Examples:
- "Neon Western" → `neon-western`
- "Cozy Noir" → `cozy-noir`
- "Witch's Apothecary" → `witchs-apothecary`

If the user rejects the auto-generated slug, accept a manual override
(must match `^[a-z0-9][a-z0-9-]*[a-z0-9]$`).

## Parent Loading Rules

When the user selects parents in Phase A4:

1. Read each parent's full genre file from the built-in bank
2. Extract sections as documented in `core-pipeline.md` Genre Bank
   Loading Protocol
3. Merge using the same rules as mash-up mode (concatenate with
   attribution headers for most sections; union for Quality Check
   Criteria, Names & Patterns, and AI Crutch Phrases)
4. Present the merged rulebook to the user in Phase C

The merged inherited block becomes the scaffold the user builds on.
Their overlays are appended (or replace specific rules, per the
Phase C options).

## Registering the Custom Genre

After saving, the custom genre file is immediately available to the
Genre Bank Loading Protocol (see `core-pipeline.md`). The loader
checks custom locations BEFORE the built-in bank, so a custom genre
can shadow a built-in genre with the same slug if the user names it
the same (strongly discouraged — the builder warns and asks for a
different slug if a built-in exists).

Agents downstream don't need to know a genre is custom — they see the
same section structure and placeholder substitution as with built-in
genres. The only visible marker is the `custom: true` frontmatter
field, which the Architect can mention in the chapter brief:
"Custom genre active: {Display Name}. Rules loaded from user's
custom genre file."

## Error Handling

| Error | Response |
|-------|----------|
| Display name empty | Re-prompt A1 |
| Slug matches built-in | Warn and ask for different name |
| Parent genre file missing | Warn user, offer to pick different parent |
| Invalid emoji (B2) | Warn, default to 📖 |
| Save path not writable | Show error, ask to try different location |
| File already exists (same slug) | See F3 — overwrite / rename / cancel |
| User cancels mid-interview | Discard all partial data, return to caller |

## Anti-Patterns (Things the Builder Must Not Do)

1. **Do not generate content the user hasn't approved.** Every
   section must trace to either a parent file or a direct user answer.
2. **Do not invent AI crutch phrases.** Offer the three options in
   Phase E — do not fabricate phrases the user hasn't confirmed.
3. **Do not skip the User Review Gate (Phase F).** The user must see
   and approve the full file before it's saved.
4. **Do not write to the built-in genre bank.** Custom genres only go
   to the project-local or library paths described above.
5. **Do not allow a custom genre to be a parent of another custom
   genre** in v1 — avoid inheritance cycles.

## Future Expansion

v2 will add:
- Custom genres as parents (with cycle detection)
- Community library sharing (import a `.genre-library/{slug}.md` from
  another user)
- Crutch phrase auto-extraction from user-provided sample prose
- Genre testing: write a one-chapter stress test to check whether the
  custom rules produce coherent output before committing the genre
