---
name: manuscript-clinic
description: "Personal genre-expert consultation on uploaded manuscripts — structural analysis, character assessment, market viability, and actionable recommendations"
version: "1.1"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Manuscript Clinic

> **File role:** USER-FACING trigger entry. This file is loaded when
> the user invokes the Manuscript Clinic via natural-language phrases.
> All execution logic — Pre-flight HARD GATEs (File Location
> Discipline, Read-Verification, Source Persistence), six-axis
> analysis, scoring formulas, consultation flow, and output files —
> lives in `manuscript-clinic-protocol.md` (single source of truth).

## Trigger Phrases

- "Can you look at my manuscript?" — Author uploads existing work for feedback
- "What's wrong with this?" — Author seeking diagnostic analysis
- "Is this ready to publish?" — Pre-submission assessment
- "What genre does this fit?" — Genre classification with market context
- "How can I improve this?" — Targeted improvement recommendations
- "Analyse my manuscript" / "Manuscript clinic" — Direct trigger phrases

## Routing

On any of the trigger phrases above, the engine MUST:

1. Load `manuscript-clinic-protocol.md`.
2. Run the Pre-flight HARD GATEs section in order (File Location
   Discipline → Read-Verification → Source Persistence). If any
   gate blocks, surface the block to the user and STOP until
   resolved — do NOT begin axis analysis.
3. Proceed through the protocol's Consultation Flow (Step 1 Intake
   → Step 2 Run Analysis → Step 3 Overall Assessment → Step 4
   Interactive Expert Session).
4. Write every deliverable (diagnostic reports, scorecards,
   transcripts, recommendations) into
   `~/Documents/Ideorix-Projects/[Title]/` via the Bash-Direct
   Write + Verify protocol per `core-pipeline.md`.

## Single Source of Truth

`manuscript-clinic-protocol.md` is the canonical specification. Any
content question, scoring formula, axis definition, or HARD GATE
binding is resolved by reading that file. This wrapper exists only
to give the user-invocable trigger phrases a discoverable entry
point in the menu / natural-language activation surface.
