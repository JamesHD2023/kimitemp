---
name: producer-state-protocol
description: "Engine-neutral binding/protocol. The state-reconciliation HARD GATE that verifies pipeline-checkpoint.md project-level fields agree with chapter-table reality and filesystem reality. Invoked before every Director Agent recommendation, after every audit-gate pass, and on demand. Repairs derived state (Audits Passed list) from filesystem evidence; flags DIVERGENCE when claimed state contradicts reality."
version: "2.7.25"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Producer State Reconciliation Protocol

A binding/protocol spec invoked by every flow that consumes
project-level pipeline-checkpoint.md state — most importantly the
Director Agent (`director-protocol.md`), but also Stage 13 Pre-Pub
READY check, the Catalog Overview project-status scan, and the
on-demand "where am I in this project?" trigger phrases.

## Why this exists

`engine-data/pipeline-checkpoint.md` is the source of truth for
"what's the state of this project?". Its chapter-level columns are
written under File-Write Hygiene with bash-direct write + Bash `ls`
verification. That covers the chapter-table fields.

The project-level header (`## Pipeline Status`, `## Audits Passed`,
`## Next Action`) is **derived** state — not authoritatively written
by a single step, but assembled from filesystem evidence that
accumulates across the pipeline. The `## Audits Passed` list, in
particular, only matters if it actually agrees with the on-disk
audit-report files. A list claiming `bible-coverage-audit | passed
| engine-data/reports/bible-coverage.md` when no such file exists
is the silent-failure shape the engine has fixed eight times since
v2.6.7 — a success-claim that diverges from actual effect.

This protocol is the verification HARD GATE for project-level
state. Every consumer that reads pipeline-checkpoint.md project-
level fields invokes this protocol first. If reconciliation passes,
the consumer trusts the state. If reconciliation fails, the consumer
**stops** and surfaces the divergence to the user before proceeding.

## Invocation contract

This protocol is invoked by the calling flow as a **HARD GATE**
between reading the project-level state and acting on it.

**Block until reconciliation completes.** Do not silently pass through.
Do not allow recommendation flows to start with unreconciled
divergence in the project-level state.

Flows that MUST invoke this protocol:

- Director Agent (`director-protocol.md`) — at the start of every
  Director invocation, before reading `## Pipeline Status` or
  `## Audits Passed` to ground a recommendation
- Stage 13 Pre-Pub READY gate — before granting publication-ready
  status, verify every audit row in `## Audits Passed` corresponds
  to an on-disk report file
- Catalog Overview (`catalog-overview-protocol.md`) — when surfacing
  per-project status across the full Ideorix-Projects/ tree
- Any future flow that reads project-level pipeline-checkpoint.md
  fields to make a routing decision

Flows that DO NOT need to invoke this protocol:

- Per-chapter Content Writer / Verifier / Humaniser flows (these
  read chapter-level columns, which are authoritatively written by
  step 18 under existing File-Write Hygiene; they do not consume
  the project-level header)
- Phase 2E creating pipeline-checkpoint.md for the first time (no
  prior state to reconcile against)

## The reconciliation protocol

### Step 1: Read pipeline-checkpoint.md project-level header

Read `engine-data/pipeline-checkpoint.md` once. Extract the
following sections:

- `## Pipeline Status` — `Phase:`, `Current chapter:`, `Mode:` fields
- `## Audits Passed` — every row in the audit-ledger table
- `## Next Action` — current stale "what should happen next" text

Apply `read-verification.md` HARD GATE to the read. If the file is
missing or returns zero extracted text, this is **not** a
reconciliation failure — it indicates Phase 2E has not yet run; tell
the calling flow "no project state yet; cannot reconcile" and stop.

### Step 2: Bash-list filesystem evidence

Use bash (not the Read tool) to enumerate the on-disk audit-report
files the project has accumulated. Apply `bash-output-verification.md`
HARD GATE — verify the find / ls invocation returned a non-error,
expected-shape result.

```bash
find {project_root}/engine-data/reports -maxdepth 2 -type f \
  \( -name '*audit*.md' -o -name '*verification*.md' \
     -o -name 'external-source-verification.md' \
     -o -name 'bible-coverage*.md' \) -print
```

Build the **filesystem-side audit-report set**: every audit report
the project has on disk, with its mtime as a timestamp ground truth.

### Step 3: Compute the state delta

Three sets are compared:

```
list_audits      = rows in pipeline-checkpoint.md ## Audits Passed
filesystem_audits = audit-report files on disk
list_audits  ∩  filesystem_audits  =  CONSISTENT
filesystem_audits  −  list_audits  =  LIST-MISSING (auto-repair)
list_audits  −  filesystem_audits  =  CLAIM-FABRICATED (DIVERGENCE)
```

The chapter table is also reconciled (lighter touch — File-Write
Hygiene already covers per-step writes, but the protocol adds a
sanity check):

```
For every chapter row with column X = "Yes":
    verify the artifact for column X exists on disk
For every chapter file engine-data/chapters/ch{NN}.md:
    verify the chapter row exists in the table
```

### Step 4: Auto-repair the LIST-MISSING set

For every audit-report file on disk that has no corresponding row
in `## Audits Passed`, append a row using bash-direct write
(per `core-pipeline.md` § File-Write Hygiene):

```bash
ROW="| $audit_name | $iso_mtime | $report_path |"
# Read pipeline-checkpoint.md once, locate the ## Audits Passed
# table closing boundary, splice the row in, write back via bash.
```

Apply Bash `ls` post-write verification + run.log entry:

```
{iso8601} | producer-state | reconcile-repair | producer | OK | engine-data/pipeline-checkpoint.md
```

Auto-repair is conservative: it only ADDS rows the filesystem
proves are valid. It NEVER deletes or modifies existing rows.

### Step 5: Halt on the CLAIM-FABRICATED set

If `## Audits Passed` claims an audit passed but no corresponding
report file exists on disk, this is a **DIVERGENCE** — the same
silent-failure shape the discipline catalog tracks. Stop. Do not
auto-resolve. Display:

```
═════════════════════════════════════════════════════════════════
PIPELINE STATE DIVERGENCE — {Project Title}
═════════════════════════════════════════════════════════════════

The pipeline-checkpoint.md ## Audits Passed list claims the
following audit(s) passed, but no corresponding report file
exists on disk:

  1. bible-coverage-audit  (claimed 2026-04-30T11:14:22Z;
     report path: engine-data/reports/bible-coverage.md
     — file not found)

This means EITHER (a) the audit report was deleted after the
list row was written (recoverable — re-run the audit), OR
(b) the list row was written without the audit actually running
(the silent-failure shape this protocol catches).

Choose:
  (a) Re-run the listed audit(s) — restores the report file
  (b) Remove the unsubstantiated row(s) — pipeline-checkpoint.md
      is corrected; the audit must be re-run before it can be
      cited again
  (c) Investigate manually — pause; I will not proceed until
      you reconcile

Until reconciled, downstream flows that depend on the audit (e.g.
Stage 13 READY check, Director recommendations that require this
audit as a prereq) are BLOCKED.
═════════════════════════════════════════════════════════════════
```

The HARD GATE remains down until the user resolves the divergence.

### Step 6: Reconcile chapter-table sanity check

Apply the same shape to chapter-table claims:

- `Written: Yes` but `engine-data/chapters/ch{NN}.md` missing →
  CLAIM-FABRICATED, surface to user
- `engine-data/chapters/ch{NN}.md` present but no row in chapter
  table → LIST-MISSING, auto-add the row with all step columns
  blank (the user / next pipeline run fills them in)

The chapter-table reconciliation is a sanity check — not a
replacement for File-Write Hygiene's per-step Bash `ls` verification.
It catches the case where pipeline-checkpoint.md was edited
externally or the reports/chapters directory was cleaned without
updating the table.

### Step 7: Acknowledgement and unblock

If reconciliation completed with no DIVERGENCE (or the user
resolved every flagged case), display:

```
✓ Pipeline state reconciled.
  Audits in ledger:        {N_list}
  Audit reports on disk:   {N_disk}
  Auto-repaired (list <- disk):  {N_repaired}
  Divergences resolved:    {N_resolved}

State trusted. Downstream consumers (Director Agent, Stage 13
READY check, etc.) unblocked.
```

The HARD GATE is now lifted; the calling flow consumes the
reconciled state.

## Run.log entries

Every reconciliation run appends one or more lines to
`engine-data/run.log` (per `core-pipeline.md` § Run log):

```
{iso8601} | producer-state | reconcile-start | producer | OK | engine-data/pipeline-checkpoint.md
{iso8601} | producer-state | reconcile-repair | producer | OK | engine-data/pipeline-checkpoint.md
{iso8601} | producer-state | reconcile-divergence | producer | FAIL | engine-data/pipeline-checkpoint.md
{iso8601} | producer-state | reconcile-complete | producer | OK | engine-data/pipeline-checkpoint.md
```

The run.log is the observability layer — when the user reports "the
Director gave me a wrong recommendation", the log shows whether the
state-reconciliation HARD GATE passed cleanly or auto-repaired or
flagged divergence.

## Failure modes prevented

The Silent-Failure Audit catalog (`silent-failure-audit.md`) tracks
the engine's drift-failure shapes. Producer State Reconciliation
prevents:

- **Audit-list fabrication** — `## Audits Passed` claims an audit
  passed, no report file on disk, downstream flow trusts the claim
  and grants READY / recommends a phase-skip. The same success-
  claim/effect divergence shape; this protocol is its HARD GATE.
- **Audit-list lossiness** — audit report exists on disk but the
  list never recorded the row (the audit-gate spec was modified
  without updating the list-append step, or the append step
  silently failed). Without reconciliation, downstream flows
  re-prompt the audit needlessly. Auto-repair fixes the omission.
- **Chapter-table fabrication** — `Written: Yes` for a chapter
  file that doesn't exist; the per-step Bash `ls` verification at
  step 18 covers the write-time path, but external editing of
  pipeline-checkpoint.md or filesystem cleanup can introduce drift.
  Sanity check catches it before a Director recommendation cites
  the false claim.
- **Director hallucination cascade** — Director Agent reads
  pipeline-checkpoint.md, the list says audit X passed, Director
  recommends "proceed to next phase that depends on X", the audit
  was never actually run. Reconciliation HARD GATE catches the
  fabrication before Director's recommendation is issued.

## See also

- `silent-failure-audit.md` — full catalog of drift-failure shapes;
  this protocol adds the `state-reconciliation` binding
- `core-pipeline.md` § Pipeline Checkpoint — the schema this
  protocol reconciles against
- `core-pipeline.md` § File-Write Hygiene — the bash-direct write
  protocol used for auto-repair
- `read-verification.md` — read-side HARD GATE applied to the
  pipeline-checkpoint.md read
- `bash-output-verification.md` — bash-side HARD GATE applied to
  filesystem enumeration
- `director-protocol.md` — the primary consumer of reconciled state
- `director-orchestration-protocol.md` — the recommendation HARD
  GATE that runs after this reconciliation completes
