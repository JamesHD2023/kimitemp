---
name: ask-user-disambiguation
description: "AskUserQuestion Disambiguation HARD GATE. When the engine asks the user a question, ambiguous inputs (compound 'yes' to multi-part questions, single-letter answers when multiple options share a letter, free-form answers that overlap multiple branches) can be silently interpreted by the engine in a way the user didn't intend. The user catches the mismatch only after seeing downstream output that doesn't match what they thought they agreed to. This spec defines question-construction rules (single-decision per ask), answer-confirmation rules (echo interpretation back before acting), and the HARD GATE on ambiguous responses. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.8"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# AskUserQuestion Disambiguation Protocol (MANDATORY for any question whose answer routes a decision)

## Purpose

Ensure that the engine's interpretation of a user's response
matches the user's intent before acting on it. Three failure
modes:

**Compound-question failure mode:**
The engine asks two or three things in one question; the user
answers "yes" to one of them; the engine assumes "yes" to all,
or picks one interpretation silently. Example:

```
Engine: "Do you want me to check the genre, build the bible,
         and start writing chapter one?"
User:   "Yes."
Engine: [proceeds to all three]
User:   "Wait — I just meant yes to checking the genre. I
         haven't decided about the bible yet."
```

The damage is downstream: the bible was built and chapter one
written before the user could correct the misinterpretation.

**Letter-collision failure mode:**
Multi-option menus share initial letters; user types "C"; the
engine picks one option silently. Example:

```
Engine: "Choose:
         A. Continue with genre 1
         B. Continue with genre 2
         C. Customize"
User:   "C"
Engine: [picks "Continue with genre 2" because it sees C as a
         loose synonym]
User:   "I meant Customize."
```

**Free-form-overlap failure mode:**
User answers in their own words; the engine maps the response
to one branch when it could legitimately map to another.
Example:

```
Engine: "Should I keep this scene or cut it?"
User:   "I'd cut down some parts but keep the ending."
Engine: [interprets as "cut" — removes the entire scene]
```

If the engine acts without confirming the interpretation, the
mismatch surfaces only after wasted work.

## Failure mode shape

The pattern is identical to the broader silent-failure shape:
the engine treats the user's response (success metadata: "I
got an answer") as correct interpretation (actual effect: "the
user meant what I think they meant"). Disambiguation makes the
engine require explicit confirmation when interpretation is
ambiguous.

## When the protocol applies

Every spec that asks the user a question whose answer routes
a downstream decision MUST apply this protocol. Specifically:

| Operation | Where used |
|-----------|------------|
| Project setup Q1-Q14 | core-pipeline.md Phase 1 (fiction & NF) |
| Story Bible Approval Gate | core-pipeline.md Phase 2G |
| Chapter Brief Approval | core-pipeline.md Phase 3 step 6 |
| Prose Approval | core-pipeline.md Phase 3 step 7a |
| BYO-canon constraint confirmation | byo-canon.md Step 0 |
| Read-Verification resolution | read-verification.md (paste / skip / re-upload) |
| Web-Content Verification resolution | web-content-verification.md (re-fetch / paste / mark-SPECULATIVE) |
| Tracked-Changes mode selection | tracked-changes.md Stage 8 routing |
| Editorial scope selection | edit-and-revise.md (which stages to run) |
| Continue Writing prompts | continue-writing.md / continue-researching.md |
| Manuscript Clinic axis selection | manuscript-clinic.md |
| Importer triage | novelcrafter-importer.md, plottr-importer.md, scrivener-importer.md, screenplay-importer.md |

## The protocol — three rules

### Rule 1: Single-decision questions (REQUIRED for routing decisions)

Every question whose answer routes a decision MUST resolve a
**single decision**. Compound questions are FORBIDDEN.

**Forbidden:**
```
"Do you want to proceed, change the outline, or skip this stage?"
"Should I check chapters 1-12 and run the audit and ship the report?"
"Confirm or correct anything before I begin."
```

**Required pattern:** decompose into per-decision questions.

**Acceptable (one decision per ask):**
```
"Do you want me to proceed with the current outline?
  A. Proceed
  B. Change something first
  C. Skip this stage"
[user answers; engine proceeds OR asks the next single-decision question]
```

If the spec inherently needs to gate on multiple decisions,
EACH decision is a separate AskUserQuestion call. The engine
MUST NOT batch decisions into a single ask.

### Rule 2: Disambiguating-confirm before acting on ambiguous responses

After receiving a user response, the engine MUST classify the
response as one of:

- **UNAMBIGUOUS** — single option clearly indicated (e.g. user
  typed "A" to a labelled menu, or typed the exact option text)
- **AMBIGUOUS** — multiple options could match, free-form
  response could route multiple ways, single-letter answer
  collides with multiple option initials
- **OUT-OF-SCOPE** — response doesn't map to any offered option

For UNAMBIGUOUS: proceed.

For AMBIGUOUS: the engine MUST echo the interpretation back
to the user and wait for explicit confirmation before acting.
Format:

```
"You said: '{user_response}'.
 I'm reading that as: {interpretation}.
 Before I proceed, is that correct?
   A. Yes — proceed with {interpretation}
   B. No — I meant {alternative_1}
   C. No — I meant something else (please tell me)"
```

For OUT-OF-SCOPE: surface the option set again with a request
to choose one of the listed options.

### Rule 3: HARD GATE — never act on ambiguous-without-confirmation

The engine MUST NOT proceed past an AMBIGUOUS response without
a UNAMBIGUOUS follow-up confirmation. Acting on the engine's
own interpretation of an ambiguous answer is forbidden.

If the user repeatedly gives ambiguous responses (e.g. answering
"I don't know" or providing context without selecting), the
engine surfaces the question again with explicit guidance:

```
"To continue, I need a single choice from this list:
   A. {option_1}
   B. {option_2}
   C. {option_3}
 Reply with A, B, or C — or paste 'pause' to stop here and
 come back later."
```

## Ambiguity-detection heuristics

The engine classifies a response as AMBIGUOUS when ANY of:

- **Single letter response** to a menu where multiple options
  share that letter as their initial.
- **Compound answer** — response contains "and", "but", "also",
  "or" linking different option references.
- **Conditional answer** — "yes if X" / "depends on Y" / "maybe"
  / "I'd consider" — answer carries a contingency the engine
  cannot resolve.
- **Hedged answer** — "I think so", "probably", "I guess",
  "sort of" — answer signals uncertainty.
- **Out-of-list free-form** — response doesn't quote any option
  text or letter, but instead describes the user's preference
  in their own words that could map to multiple offered
  options.
- **Negation without alternative** — "not A" without specifying
  what to do instead.

## What this protocol does NOT do

- It does **not** apply to free-form questions where the user
  is expected to give open input (e.g. "Tell me about your
  story idea"). Those answers are absorbed into the engine's
  context but don't route a discrete decision — they shape
  downstream questions, not a single fork.
- It does **not** apply to confirmations of structured engine
  output (e.g. "Here's the chapter outline I built — confirm or
  correct"). Those are content-review gates with their own
  protocols.
- It does **not** apply to questions where ambiguity has zero
  blast radius (e.g. "Want a cup of coffee while I write?"
  — engine ignores irrelevant chitchat). Use judgment: if the
  ambiguous answer cannot route a damaging decision, no
  disambiguation is required.

## Anti-patterns this protocol prevents

- **Compound-yes silent over-commitment** — engine batches
  three decisions in one question; user says yes to one;
  engine commits all three.
- **Letter-collision unilateral pick** — user types "C";
  engine silently picks one of two C-options.
- **Free-form-overlap unilateral interpretation** — engine
  maps "cut down some parts" to "cut the scene".
- **Implicit-and chain** — engine asks "should I do A and
  B?"; user says yes to A; engine does B too.
- **Hedged-answer absorption** — user says "maybe"; engine
  proceeds as if "yes".

## Logging

The engine writes a per-session disambiguation log when an
ambiguous response triggers Rule 2 confirmation:

```
~/Documents/Ideorix-Projects/[Title]/engine-data/run.log
```

Per-disambiguation entry:

```
[YYYY-MM-DDTHH-MM] DISAMBIGUATION
  Question: {question_text}
  Raw response: {user_response}
  Classification: AMBIGUOUS (reason: {heuristic})
  Engine interpretation: {interpretation}
  Confirmation: CONFIRMED | CORRECTED ({corrected_interpretation})
```

## Cross-cutting binding

This protocol is the **ninth cross-cutting binding**. The
canonical catalog of all bindings and audited primitives is
`silent-failure-audit.md`. This binding addresses primitive
#14 (AskUserQuestion ambiguity) in that catalog.

Parallel bindings —

1. Architect Mode binding
2. Verification Discipline binding
3. File-Write Hygiene binding
4. Edit-Tool Typographic Fidelity binding
5. Read-Verification binding
6. Web-Content Verification binding
7. Subagent Output Verification binding
8. Bash-Output Verification binding
9. **AskUserQuestion Disambiguation binding (this spec)**

## Silent-Failure Audit

This binding spec is exempt from the Silent-Failure Audit
section requirement (Check 10) because it IS audit
infrastructure rather than a feature spec. The exemption is
granted in the engine's spec-lint repo CI discipline `check_silent_failure_audit`
exempt pattern.
