---
name: canon-validation-taxonomy
description: "Engine-neutral taxonomy. The 10 quality domains every Ideorix manuscript must satisfy — LOGIC, CONSISTENCY, COHERENCE, PHYSICS, CHARACTER, GENRE, ECONOMY, INTENT PRESERVATION, AI-ISM DETECTION, and SHOW NOT TELL. Indexes every existing audit, gate, and verification protocol against the 10 axes; surfaces the novel gaps as a roadmap. Adopted from a user-supplied framework and translated to Ideorix terms. Foundation for the /validate command + Wave 4 audit additions in v2.7.27-v2.8.0."
version: "2.7.39"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Canon Validation Taxonomy

A reference index spec. Defines the 10 quality domains a manuscript
must satisfy under the engine's discipline, maps every existing
audit / gate / verification protocol to its primary and secondary
domains, and lists the explicit gaps where novel checks are still
needed. The taxonomy is the published organisational lens for
v2.7.27's `/validate` dispatcher and Wave 4 audit additions
(v2.7.29-v2.7.33).

## Why this exists

Ideorix has accumulated audit infrastructure organically across
many releases — entity canon, accuracy gate, prose humaniser,
quality gate, verification discipline, Stage 9a/9b, Bible
Coverage Audit, the seven cross-read-primitive HARD GATEs of
the Silent-Failure catalog. Every individual audit is well-
motivated, but the catalog has no single organising lens. A
new feature spec asking "is this surface adequately audited?"
must consult ten different specs to answer.

User feedback in v2.7.25 surfaced a clean 10-axis taxonomy
that names every quality domain the engine cares about. The
taxonomy is not a replacement for the existing audit
infrastructure — it is the **index** by which the existing
audits are organised, and by which gaps in coverage are
surfaced. Adopting it as a published reference makes:

- Coverage assessment legible (every audit lives at one or
  more axis intersections)
- Gaps explicit (axis cells with no covering audit are visible
  as a roadmap)
- The `/validate` dispatcher (v2.7.27) possible (it routes
  per-domain rather than per-spec)
- Phase-gate semantics cleaner (each gate names which subset
  of domains it asserts)

The taxonomy is engine-neutral. Both fiction and non-fiction
manuscripts must satisfy all ten domains; the specific audits
that cover each domain may differ by engine, but the axes
themselves are universal.

## The ten domains

Each domain is defined in engine-neutral terms with NF and
fiction examples.

### 1. LOGIC — Does the work make sense mechanically?

The story / argument coheres at the structural level. Premise,
emotional core, and structural method describe the same work.
Information sequencing satisfies prerequisites before payoffs.
Procedural and timeline plausibility hold.

- **Fiction examples**: foundation agreement (premise +
  emotional core + structural method describe one story), plot
  coherence, reveal sequencing (logic gates satisfied before
  beats they unlock), procedural plausibility (events could
  physically happen), ticking-clock timeline integrity.
- **Non-fiction examples**: thesis-evidence-conclusion alignment,
  argument sequencing (premises before inferences), source
  ordering preserves citation logic, claim-prerequisite resolution
  (defined terms before deployed terms).

### 2. CONSISTENCY — Do details stay stable across documents and chapters?

Details established once persist correctly. Cross-document
continuity (bible → outline → brief → prose), cross-brief
continuity, cross-chapter continuity. Props introduced are
tracked. POV and voice register stay locked.

- **Fiction examples**: character appearance stays stable,
  prop and object tracking, POV lock (narration never leaves
  POV character), voice register holds.
- **Non-fiction examples**: figure-name spelling stays stable
  across chapters, source-credential tier preserved on every
  citation, terminology held (a term defined Ch 1 means the
  same thing Ch 12), authority register (academic ↔
  conversational) holds.

### 3. COHERENCE — Does the work hold together as a living system?

Beyond structural logic and detail consistency: the work breathes.
Tension holds without zero-tension gaps. Antagonist pressure is
felt where the plan requires it. Pacing varies (no two
consecutive units serve the same dramatic / argumentative
function). Motifs land and evolve, not repeat.

- **Fiction examples**: arc continuity (no character resets),
  tension-field integrity, antagonist presence, escalation,
  leitmotif coherence (motifs land where planned, evolve, not
  explained), scene-type variation.
- **Non-fiction examples**: argument-tension across chapters
  (counter-arguments engaged where promised), thematic motifs
  (recurring concept reframings), no two consecutive chapters
  serve the same expository function (e.g., back-to-back
  case-study chapters without contrast).

### 4. PHYSICS — Does the physical world behave realistically?

Bodies and objects obey continuity rules. Injuries accumulate
and constrain behavior in subsequent chapters. Exertion depletes.
Recovery time is proportional. Causal weight: decisions close
doors, costs persist, moral costs don't resolve in the same
chapter that introduced them. Adrenaline masks pain temporarily,
then crash. Hunger, cold, exhaustion, the body as object.

- **Fiction examples**: injury-accumulation (injured Ch 3, still
  injured Ch 5, wounds constrain), exertion-depletion (ran two
  miles + fought = not at peak), recovery-time proportionality,
  adrenaline-and-crash, body-as-physical-object (hunger, cold,
  bodily needs).
- **Non-fiction examples**: where the work makes physical
  claims (memoir, biography, history with embodied subjects,
  field-research narrative), the same physics rules apply.
  For abstract NF, the corresponding axis is mathematical /
  logical "physics" (numerical claims preserve units; chronology
  obeys dating conventions; spatial claims hold under map
  geometry).

### 5. CHARACTER — Are these people, not functions?

The cast comprises persons with private interiority, not
roles that exist only to drive plot. The 7-criterion humanity
gate tests for it: contradiction between self-belief and
behavior; independent existence (lives a life when not
on-page); five emotional registers with unique physical tells;
private self; competing desires; surprise behavior; gap
between stated values and actual behavior. Voice
differentiation (dialogue distinguishable without attribution).
The "remove the plot" test: would this person exist without
the story's events?

- **Fiction examples**: full humanity gate applies to all
  POV-bearing characters; secondary characters need at least
  3 of the 7 criteria; antagonists need contradictions and
  competing desires.
- **Non-fiction examples**: in narrative NF (memoir, biography,
  literary journalism), the humanity gate applies to every
  named figure presented as a person. In analytical NF,
  the parallel test is **source persons not flattened to
  evidence-instruments** — does the cited expert exist with
  context and motivations beyond their utility to the
  argument? Sources should not be cast as flat citations.

### 6. GENRE — Does the work honor the reader's contract?

Every genre carries a contract. Non-negotiables met. Logic
gates satisfied before beats they unlock. Rage triggers (the
moves that make a category-savvy reader put the book down)
not tripped. Beats fire in correct structural position. The
felt contract delivered, not just structural compliance.

- **Fiction examples**: mystery (clue placement, fairness
  rules), romance (HEA / HFN, beat positioning), fantasy
  (magic-system consistency, world-rule integrity), thriller
  (pacing, antagonist presence at threshold moments).
- **Non-fiction examples**: memoir (vulnerability, scene-
  weight), biography (source diversity, balance), business
  (actionable framework, evidence-led), self-help (the promise
  the cover makes is delivered). Each NF category has its
  own non-negotiables (catalogued in the engine's category
  files).

### 7. ECONOMY — Is the prose lean?

Each paragraph earns its presence. No echo paragraphs
(demonstrate, then explain what was demonstrated). No triple
approach (same emotional truth from three angles because one
wasn't trusted). No confirmation loops (scenes that exist
only to remind the reader of established info). No explained
subtext. No redundant reaction (physical, then emotional,
then reflects on both, in same scene). No restatements of
earlier-scene establishment. Could the paragraph be removed
without the reader missing anything?

- **Fiction examples**: same as the canonical patterns above,
  detected per-chapter.
- **Non-fiction examples**: argument-restatement (same point
  three ways in adjacent paragraphs), evidence-redundancy
  (the same study cited three chapters running with no new
  framing), confirmation-loop (chapter that re-summarises
  prior chapters before its own content begins).

### 8. INTENT PRESERVATION — Is meaning felt but not announced?

The work's meaning surfaces through implication, not
declaration. Unresolved images (objects/gestures that
accumulate meaning without explanation). Unanswered questions
(deliberate silences — not plot holes, designed openness).
Unnamed feelings (states experienced but not articulated).
Incomplete arcs (secondary threads that don't resolve, world
extending beyond the story). Theme leaks as a failure mode:
the draft naming its own theme, a character stating the
meaning, narration resolving an open image. The resolution
test: at three moments per chapter where meaning surfaces,
does prose **land on it** (fail) or **pass through** (target)?

- **Fiction examples**: full discipline applies. The
  resolution test runs on every prose chapter.
- **Non-fiction examples**: argumentative subtext (the case
  the evidence accumulates toward) should not be over-stated
  in conclusion; the reader should arrive at the inference
  with the author, not be told the inference. Memoir-specific:
  the theme of the memoir should be felt across scenes, not
  named in chapter titles.

### 9. AI-ISM DETECTION — Does the prose sound written by a person?

The structural and prose-level patterns that mark LLM-
generated text. Tricolon / Rule-of-Three overuse. Elegant
variation (synonym cycling). Negative parallelisms
("not only X but also Y"). False ranges ("everything from X
to Y"). Copula avoidance ("serves as" instead of "is").
Metaphors that close too cleanly. Sanitized prose
(emotional impact pre-translated). Filler phrases. Excessive
hedging. Generic positive conclusions. Undue emphasis on
significance ("a testament to", "pivotal moment"). Superficial
-ing chains. Vague attributions. Overused AI vocabulary
(vibrant, tapestry, intricate, showcase, pivotal, delve).
Voice patterns: same-length sentences, no uncertainty, no
humor, reads like non-fiction (in fiction), character voices
too consistently calibrated.

- **Fiction examples**: prose-humaniser primary domain;
  forbidden-words and pattern-counter scripts active.
- **Non-fiction examples**: same patterns; additionally,
  authority-voice should still allow human uncertainty and
  edge — calibrated objectivity is itself an AI-ism.

### 10. SHOW NOT TELL — Is emotion and meaning carried in behavior, not labels?

Emotion rendered through body and behavior, not labeled.
Character traits demonstrated, not asserted. Subtext shown,
not explained. No exposition disguised as remembering ("I
thought back to when..."). No melodramatic internal
monologue during action. In first person: not every paragraph
opens with "I + verb". Strong verbs over weak constructions
+ adverb. "Said" preferred over decorative attributions. One
strong image per paragraph (enough). The body has full
vocabulary — **no physical tell used twice for the same
emotion in the same chapter**.

- **Fiction examples**: full discipline applies per-chapter.
- **Non-fiction examples**: in narrative NF, full discipline
  applies. In analytical NF, the parallel principle is
  **don't tell the reader what to conclude — show the
  evidence and let the conclusion form**. Conclusion-stating
  paragraphs that paraphrase what the evidence already showed
  are the analytical-NF echo of "labeled emotion".

## Mapping — every existing audit indexed by domain

The table below indexes every audit / gate / verification
protocol the engine ships, against its primary and secondary
domains. Audits with multi-domain coverage are listed in
their primary domain row; the secondary domains are noted in
the Coverage column.

### Primary domain: LOGIC

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Phase 2D Entity Canon Lockfile | both | LOGIC + CONSISTENCY | core-pipeline.md § Phase 2D |
| Phase 2F Bible / Research-Bible Conformance | both | LOGIC + GENRE | core-pipeline.md § Phase 2F |
| Phase 2G Verification Discipline | NF only | LOGIC + CONSISTENCY | verification-discipline.md |
| Story / Research Bible Approval Gate | both | LOGIC | core-pipeline.md § Phase 2 Approval |
| Step 5a Outline Conformance Gate | both | LOGIC + COHERENCE | outline-conformance-gate.sh |
| Pre-Flight Check (per chapter) | both | LOGIC | pre-flight-gate.sh |

### Primary domain: CONSISTENCY

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Bible Coverage Audit | both | CONSISTENCY + LOGIC | bible-coverage-audit.md (v2.7.24) |
| Entity Canon Verify | both | CONSISTENCY | entity-canon-verify.sh |
| Tense Contract Scan (Class A, WARN) | fiction | CONSISTENCY (narrative tense: retrospective/foreshadowing markers in an immediate-contract project) | narrative-tense.md + tense-contract-scan.sh (v2.7.125) |
| Accuracy Gate (Source Guardian) | NF | CONSISTENCY + LOGIC | accuracy-gate.md |
| Quality Gate canon-fidelity checks | fiction | CONSISTENCY + CHARACTER | quality-gate.md (Architect Mode) |
| Read Verification | both | CONSISTENCY (input integrity) | read-verification.md |
| Web-Content Verification | both | CONSISTENCY (input integrity) | web-content-verification.md |
| Subagent Output Verification | both | CONSISTENCY (delegated work) | subagent-output-verification.md |
| Bash Output Verification | both | CONSISTENCY (tool output) | bash-output-verification.md |
| Source Persistence | both | CONSISTENCY (uploads → disk) | source-persistence.md |
| Producer State Reconciliation | both | CONSISTENCY (state ledger) | producer-state-protocol.md (v2.7.25) |
| Director Orchestration Protocol | both | CONSISTENCY (recommendations) | director-orchestration-protocol.md (v2.7.25) |
| Tracked-Changes Phase A→C | both | CONSISTENCY (DOCX integrity) | tracked-changes.md |
| File-Write Hygiene | both | CONSISTENCY (write integrity) | core-pipeline.md § File-Write Hygiene |
| Edit-Tool Typographic Fidelity | both | CONSISTENCY + AI-ISM | core-pipeline.md § Edit Typographic Fidelity |
| Step 18 Pipeline Checkpoint Update | both | CONSISTENCY | core-pipeline.md § Step 18 |
| File-Freshness Post-Write | both | CONSISTENCY | core-pipeline.md § File-Freshness |
| Per-Stage File Freshness Check | both | CONSISTENCY | core-pipeline.md § Editorial Pipeline |
| Stage 11 Multi-Source Consistency Pass | NF | CONSISTENCY | editorial-suite.md Stage 11 |
| Stage 10 Multi-POV Consistency Pass | fiction | CONSISTENCY + CHARACTER | editorial-suite.md Stage 10 |

### Primary domain: COHERENCE

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Same-Function-Consecutive Audit | both | COHERENCE (adjacent-function uniqueness) | coherence-function-consecutive.md + .sh (v2.7.31) |
| Leitmotif Tracker — manuscript-scope (Class B subagent) | both | COHERENCE (motif delivery + evolution against bible plan; full-arc verification) | leitmotif-tracker.md (v2.7.33); runs at Stage 9.5 Canon Validation Sweep |
| Leitmotif Tracker — per-chapter delta (Class B subagent) | both | COHERENCE (per-chapter incremental against running ledger; catches drift at write-time) | leitmotif-tracker-delta.md (v2.7.61); runs at Rule 1b Class B Delta Pass after each chapter |
| Injury Accumulation Tracker — per-chapter delta (Class B subagent) | both | PHYSICS (per-chapter incremental against running injury ledger; catches capability violations at write-time) | injury-accumulation-delta.md (v2.7.61); runs at Rule 1b Class B Delta Pass after each chapter |
| Stage 4 Developmental Editor | both | COHERENCE | editorial-suite.md Stage 4 |
| Stage 9 Full-Manuscript Continuity Audit | fiction | COHERENCE + CHARACTER | editorial-suite.md Stage 9 |
| Stage 4.5 Repetition Sweep | both (≥40k) | COHERENCE + ECONOMY | editorial-suite.md Stage 4.5 |
| Chekhov's Guns | fiction | COHERENCE | chekhovs-guns.md (fiction-engine only) |
| Stage 1 Genre / Category Audit | both | COHERENCE + GENRE | editorial-suite.md Stage 1 |

### Primary domain: PHYSICS

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Injury-Accumulation Tracker (Class B subagent) | both | PHYSICS (cross-chapter character physical-state coherence) | injury-accumulation.md (v2.7.32) |
| Temporal Verify | both | PHYSICS (timeline) | temporal-verify.sh |
| Number-7 Bias | both | PHYSICS (numerical) | number-7-bias.sh |

(Coverage is thin — see Gap Analysis below.)

### Primary domain: CHARACTER

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Humanity Gate (Class B subagent, 7-criterion scorecard) | both | CHARACTER (per-character depth: contradiction, independent existence, five emotional registers, private self, competing desires, surprise behavior, stated-values/behavior gap) | humanity-gate.md (v2.7.34) |
| Character Tell-Register Distinctness (Class A) | fiction | CHARACTER (canon-level: each main-cast character's five-register Physical Tell Register is populated and mutually distinct across the cast) | character-depth.md + character-tell-distinctness.sh (v2.7.124) |
| Character Depth Layer completeness | fiction | CHARACTER (main-cast depth fields present, specific, non-stubbed) | character-depth.md §enforcement (v2.7.124) |
| Stage 0 Voice / Authority Profile | both | CHARACTER | editorial-suite.md Stage 0 |
| Quality Gate character-drift checks | fiction | CHARACTER | quality-gate.md |
| Stage 6 Beta Reader (persona loop) | NF | CHARACTER (sources-as-people) + GENRE | beta-reader-personas.md |
| Authenticity Guard (AI-name avoidance) | both | CHARACTER + AI-ISM | authenticity-guard.md |

In the fiction engine the humanity-gate's *criteria* are now also
**authored as canon** by the Character Depth Layer (character-depth.md) and
the tell-register half is structurally audited (character-tell-distinctness.sh);
the gate remains the Class B scorecard that judges the qualities in the work.

### Primary domain: GENRE

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Stage 1 Genre / Category Audit | both | GENRE | editorial-suite.md Stage 1 |
| Genre files (`genre-*.md`) | fiction | GENRE | references/genre-*.md |
| Category files | NF | GENRE | references/business.md, biography.md, etc. |
| Market Scout Gate | both | GENRE (positioning) | market-scout-gate.sh |
| Stage 11 Intimate Scene Review | fiction | GENRE | editorial-suite.md Stage 11 |
| Stage 10 Bias & Balance Review | NF | GENRE (contested topics) | bias-balance-review.md |

### Primary domain: ECONOMY

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Stage 3 Copy Editor (frequency analysis) | both | ECONOMY | editorial-suite.md Stage 3 |
| Pattern Counter | both | ECONOMY + AI-ISM | pattern-counter.sh |
| Forbidden Words Scan | both | ECONOMY + AI-ISM | forbidden-words-scan.sh |
| Stage 4.5 Repetition Sweep | both (≥40k) | ECONOMY + COHERENCE | editorial-suite.md Stage 4.5 |
| Word Count Check | both | ECONOMY (target adherence) | word-count-check.sh |

### Primary domain: INTENT PRESERVATION

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Intent Preservation Audit (Class B subagent, theme-leak + resolution test) | both | INTENT PRESERVATION (theme-leak detection + resolution test; bible-grounded; WARN-only on first ship) | intent-preservation.md (v2.7.35) |

### Primary domain: AI-ISM DETECTION

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Prose Humaniser | NF (and fiction via Stage 3) | AI-ISM | prose-humaniser.md |
| Forbidden Words Scan | both | AI-ISM + ECONOMY | forbidden-words-scan.sh |
| Pattern Counter | both | AI-ISM + ECONOMY | pattern-counter.sh |
| Authenticity Guard | both | AI-ISM + CHARACTER | authenticity-guard.md |
| Typography Sweep | both | AI-ISM (typographic fingerprints) | typography-sweep.md + .sh |
| Formatting Check | both | AI-ISM | formatting-check.sh |
| Edit-Tool Typographic Fidelity | both | AI-ISM + CONSISTENCY | core-pipeline.md |
| Placeholder Scan | both | AI-ISM (artifact leak) | placeholder-scan.sh |
| Pending-Marker Scan | NF | AI-ISM (placeholder leak) | pending-marker-scan.sh |

### Primary domain: SHOW NOT TELL

| Audit / Gate | Engine | Coverage | Spec / Script |
|---|---|---|---|
| Physical-Tell Repetition Audit | both | SHOW-NOT-TELL (no-double-use physical tell, body-part-collocated phrasings only — see coverage trade-off below) | show-not-tell-tells.md + .sh (v2.7.30, dictionary tightened v2.7.36) |
| Stage 2 Proofreader (active-voice review) | both | SHOW-NOT-TELL (partial) | editorial-suite.md Stage 2 |
| Stage 3 Copy Editor (filter-word density) | both | SHOW-NOT-TELL (partial) | editorial-suite.md Stage 3 |
| Quality Gate prose-quality | fiction | SHOW-NOT-TELL (partial) | quality-gate.md |

**Coverage trade-off (v2.7.36 dictionary tightening).** The v2.7.30
Physical-Tell Repetition Audit originally flagged five additional
patterns: bare verbs `flinched`, `recoiled`, `stiffened`, `shivered`,
plus `lips parted`. Independent code review found these fired on
non-character usage ("the wind stiffened against the sails", "the
spring recoiled") and on neutral romance/literary prose ("her lips
parted slightly to ask"). Catching person-subject usage requires
named-entity / pronoun context which a regex dictionary cannot
reliably express. v2.7.36 dropped those patterns to keep the
dictionary's false-positive profile clean. The trade-off is missing
some real bare-verb tells (e.g. "she flinched" used twice without
body-part collocation). A future Class B refinement (semantic
context check using subagent reasoning) can recover the lost
coverage when the framework gains semantic-tell detection.

## Gap analysis — domains needing dedicated audits

Six gap-closes (the original five expanded after splitting the
COHERENCE bundle into two distinct checks). Each is a Wave 4
candidate. Target releases sequenced by complexity.

| # | Domain | Gap | Target | Class | Status |
|---|---|---|---|---|---|
| 1 | SHOW NOT TELL | No-double-use physical tell (same physical tell for same emotion twice in one chapter) | v2.7.30 (shipped) | Class A bash | **COVERED** (`show-not-tell-tells.md` + `.sh`) |
| 2 | COHERENCE | Same-function-consecutive-chapter check (tag each chapter's dramatic / argumentative function at step 5; flag adjacent duplicates) | v2.7.31 (shipped) | Class C engine-protocol + Class A bash audit | **COVERED** (`coherence-function-consecutive.md` + `.sh`) |
| 3 | PHYSICS | Injury-accumulation tracker (Ch N injury constrains Ch N+M behavior) | v2.7.32 (shipped) | Class B subagent | **COVERED** (`injury-accumulation.md`) — first Class B audit; introduces the dispatcher's CLASS_B_AUDIT line + engine-layer subagent dispatch protocol |
| 4 | COHERENCE | Leitmotif tracker (extract motif plan from bible at outline time; verify prose lands as planned, evolves not repeats) | v2.7.33 (shipped) | Class B subagent | **COVERED** (`leitmotif-tracker.md`) — second Class B audit; COHERENCE domain now fully COVERED (both sub-gaps closed) |
| 5 | CHARACTER | 7-criterion humanity gate (contradiction self-belief/behavior, independent existence, five emotional registers, private self, competing desires, surprise behavior, gap stated values vs actual behavior) | v2.7.34 (shipped) | Class B subagent | **COVERED** (`humanity-gate.md`) — third Class B audit; per-character scorecard with graduated severity (6-7=PASS, 4-5=WARN, 0-3=FAIL); CHARACTER domain now has its first primary-domain audit |
| 6 | INTENT PRESERVATION | Theme-leak detection + resolution test (does prose land on meaning or pass through?) | v2.7.35 (shipped) | Class B subagent (WARN-only on first ship) | **COVERED** (`intent-preservation.md`) — fourth Class B audit; engine layer downgrades any FAIL subagent verdict to WARN to surface findings without blocking craft choices on the most subjective audit; bible-grounded (every finding cites both bible intent statement AND prose moment that diverges); INTENT PRESERVATION domain gains its first primary-domain audit |

Each gap, when authored, follows the canonical structure of
existing binding/protocol specs (`bible-coverage-audit.md` is
the v2.7.24 reference shape) and adds an entry to the
`silent-failure-audit.md` catalog. The taxonomy then re-indexes
the new audit into its primary-domain row.

## Validation levels — phase-gate mapping

The user-facing validation levels (architecture / brief / prose
/ full) map to existing engine phase gates. The `/validate`
command (v2.7.27) routes via these levels.

### architecture (pre-brief, post-bible)

Run after Phase 2 (Story Bible / Research Bible complete),
before Phase 3 step 5a.

Domains checked:

- LOGIC (full)
- CONSISTENCY (cross-document — bible vs setup answers)
- COHERENCE (structural — outline tension, antagonist plan)
- PHYSICS (structural — timeline, ticking-clock setup)
- CHARACTER (humanity gate + bible character profiles)
- GENRE (full)

Inputs: story-bible.md / research-bible.md, chapters.md (the
chapter-list overview), genre / category files, entity-canon.md.

Maps to existing gates: Phase 2D + Phase 2F + Phase 2G + Story
Bible Approval.

### brief (post-brief, pre-write)

Run after Phase 3 step 5 (per-chapter brief written), before
step 7 (Content Writer runs).

Domains checked:

- CONSISTENCY (cross-brief — Ch N brief vs Ch N-1 brief)
- PHYSICS (timeline, injury continuation)
- COHERENCE (tension, antagonist pressure, pacing per the
  brief)
- GENRE (beats fire as planned, non-negotiables met)

Inputs: per-chapter brief file, chapters.md, genre / category
files.

Maps to existing gates: Step 5a Outline Conformance Gate +
Banlist Loaded.

### prose (per-chapter, post-write)

Run after Phase 3 step 7-10 (chapter written + humanised),
before step 12 (verification agents fire) — or after step 12
as a redundant check.

Domains checked:

- CONSISTENCY (cross-chapter)
- PHYSICS (physical state continuity)
- ECONOMY (full)
- INTENT PRESERVATION (full, WARN-only initially)
- AI-ISM DETECTION (full)
- SHOW NOT TELL (full)
- CHARACTER (voice consistency, humanity-gate per-chapter
  re-check)

Inputs: chapter prose file, chapter brief, voice-builder /
authority-builder profile, prior-chapter summary.

Maps to existing gates: Quality Gate (fiction) / Accuracy Gate
(NF) + Step 12 Verification Agents + ideorix-audit.sh
mechanical modules.

### full (pre-submission)

Run before submission / publication. Cross-validates every
domain against the full manuscript.

Domains checked: all 10.

Inputs: complete manuscript, all bibles, all briefs, run.log,
pipeline-checkpoint.md.

Maps to existing gates: Stage 9a + Stage 9b (NF) / Stage 9
Continuity Audit (fiction) + Stage 13 Pre-Pub READY check +
sampled-VERIFIED re-check.

## Roadmap — v2.7.27 through v2.7.35

The taxonomy is Phase 1 of the framework adoption. The original
plan (5 novel-check releases + v2.8.0-rc1 pipeline restructure)
was reassessed after v2.7.28 smoke-testing surfaced three real
issues — see `validate-dispatcher.md` § Roadmap context for the
detail. Revised 7-release sequence:

| Release | Scope |
|---|---|
| v2.7.26 | Taxonomy spec + gap analysis published |
| v2.7.27 | `/validate` slash-command dispatcher — full validation only |
| v2.7.28 | Validation-level scoping (`/validate <book> architecture\|brief\|prose\|full [chapter]`); OUT_OF_SCOPE emissions; level→domain canonical mapping |
| v2.7.29 | Dispatcher signature normalisation: per-script `script_class()` registry + iterate-all-chapters fallback; framework feature-complete |
| v2.7.30 | Gap close: SHOW NOT TELL no-double-use physical tell (Class A bash) — first novel-check shipped; SHOW NOT TELL domain status: COVERED |
| v2.7.31 | Gap close: COHERENCE same-function-consecutive (Class C engine-protocol + Class A bash audit) — declares chapter argumentative/dramatic function via `<!-- Function: <value> -->` convention; bash audit flags adjacent duplicates |
| v2.7.32 | Gap close: PHYSICS injury-accumulation (first Class B audit) — introduces the Class B dispatch protocol: bash dispatcher emits `CLASS_B_AUDIT` lines, engine layer dispatches subagent per linked spec, applies subagent-output-verification HARD GATE on return, merges verdict into briefing |
| v2.7.33 | Gap close: COHERENCE leitmotif tracker (second Class B audit; uses v2.7.32 framework) — extracts motif plan from bible, verifies prose lands as planned and evolves rather than repeats unchanged; COHERENCE domain now fully COVERED |
| v2.7.34 | Gap close: CHARACTER 7-criterion humanity gate (third Class B audit) — per-character scorecard against contradiction / independent existence / five emotional registers / private self / competing desires / surprise behavior / stated-values-vs-behavior gap; graduated severity (6-7=PASS, 4-5=WARN, 0-3=FAIL); material-character scope (bible-listed, fall back to 3+ chapter heuristic); CHARACTER domain now has its first primary-domain audit |
| v2.7.35 — final Wave 4 gap close | INTENT PRESERVATION theme-leak / resolution test (fourth Class B audit, WARN-only); bible-grounded; theme-leak + resolution-test sub-checks; engine layer downgrades any FAIL subagent verdict to WARN to surface findings without blocking craft choices on the most subjective audit. **All ten canon-validation domains now COVERED; framework feature-complete.** |
| v2.7.36 — fix release | Three production bugs + one cosmetic + adversarial test coverage (post-pass-1 review): cross-domain log-path collision; exit-2 misclassified as FAIL "configuration error"; show-not-tell pattern dictionary FPs (bare verbs, "lips parted"); injury-accumulation HARD GATE off-by-one. New `tests/runners/runner-validate-dispatcher.sh`. |
| v2.7.37 — design polish | Brittleness items (post-pass-1 review): dead `gap_target_for_domain()` removed; `severity_cap_for_audit()` registry + CLASS_B_AUDIT severity_cap field + spec frontmatter make the WARN-only cap machine-readable end-to-end; HARD GATE template canonicalised to a 5-check structure across all Class B specs; `resolve_forbidden_words_file()` simplified to project-local candidates only (NOTE: this last change was a regression and was reverted in v2.7.38). |
| v2.7.38 — second-pass fixes | Post-pass-2 review: forbidden-words.md engine-internal fallback restored (v2.7.37 had wrongly removed it); typography-sweep.sh real-error exit-2 sites moved to exit-3 so dispatcher maps to WARN not silent SKIP; intent-preservation HARD GATE reordered so the WARN-only cap applies LAST after all evidence-validation checks (was at #3, before hallucination strip); 4 documentation drift sites fixed; new t01c content-based runner assertion. |
| **v2.7.39 (current) — third-pass fixes** | Post-pass-3 review: typography-sweep.sh header doc-comment + `typography-sweep.md` exit-code table updated to reflect the v2.7.38 exit-3 contract (drifted in v2.7.38); this taxonomy file's frontmatter version was frozen at 2.7.26 across 13 content updates and is now bumped + roadmap rows added; 3 byte-identical scripts (pre-flight-gate, outline-conformance-gate, market-scout-gate) added to spec-lint MIRRORED_FILES (false-negative gap that pass 1 missed); dead `FILE_OR_PROJECT` class doc removed from dispatcher header (CHAPTERS_DIR doc added); `run_audit()` `fail_count` over-counted SKIPs as fails in per-chapter summary line (leftover from before v2.7.36 SKIP semantics) — fixed; new validate-dispatcher.md "Implementation venue" section explicitly documents that the engine-layer consumer is Claude reading the spec, not a code path under `commands/` (architectural concern surfaced by passes 2+3, made explicit). |
| v2.7.32 | Gap close: PHYSICS injury-accumulation tracker (Class B subagent) |
| v2.7.33 | Gap close: COHERENCE leitmotif tracker (Class B subagent) |
| v2.7.34 | Gap close: CHARACTER 7-criterion humanity gate (Class B subagent) |
| v2.7.35 | Gap close: INTENT PRESERVATION theme-leak / resolution test (Class B subagent, WARN-only on first ship) |
| v2.8.0 (deferred) | Reserved for genuine architectural change. Not the previously-planned pipeline restructure — that was reassessed as speculative; existing phase HARD GATEs work and the dispatcher is orthogonal, not a replacement. |

Each gap-close release follows the canonical pattern: new
binding/protocol spec (mirrored), new audit script (if
applicable), Silent-Failure Audit catalog entry, taxonomy
mapping table updated to move the gap from UNAUDITED to
COVERED.

## Anti-patterns this taxonomy prevents

- **Coverage drift** — a new feature ships without explicit
  domain assignment; reviewers cannot tell which axes the
  feature touches; gaps multiply silently.
- **Audit overlap blindness** — three audits cover the same
  axis well, two axes have nothing; without an index, the
  imbalance stays invisible.
- **Spec-by-spec consultation** — the question "is this surface
  adequately audited?" requires reading ten specs; the index
  collapses it to a table lookup.
- **Validation-level vocabulary collision** — without a
  documented mapping, "architecture" / "brief" / "prose" /
  "full" risks colliding with phase / stage names. The mapping
  table fixes it explicitly.

## See also

- `silent-failure-audit.md` — the catalog of drift-failure
  shapes; this taxonomy is the orthogonal organising lens
  (silent-failure catalogs primitives → fix-bindings; the
  taxonomy catalogs quality-domains → audits)
- `core-pipeline.md` — the per-phase HARD GATE specifications
  the validation-level mapping references
- `editorial-suite.md` — the numbered editorial stages the
  prose-level domain checks dispatch through
- `producer-state-protocol.md` + `director-orchestration-protocol.md`
  (v2.7.25) — the orientation layer; the taxonomy is the
  quality layer; together they answer "where am I?" + "is
  this work passing its bars?"
- The user-supplied 10-domain framework that motivated this
  spec is preserved in the v2.7.26 commit message for
  provenance
