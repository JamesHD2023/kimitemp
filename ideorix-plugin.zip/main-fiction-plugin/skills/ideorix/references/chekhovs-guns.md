---
name: chekhovs-guns
description: "Chekhov's Gun lifecycle tracking protocol"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Chekhov's Gun Protocol

## Purpose

Chekhov's Guns are story elements planted early that must pay off later. A locked
drawer mentioned in Chapter 2 must be opened by the climax. A character's unusual
skill introduced casually must become critical. This protocol ensures every planted
element is tracked and resolved.

> "If in the first act you have hung a pistol on the wall, then in the following
> one it should be fired." — Anton Chekhov

## When It Runs

- **Selection:** Phase 1 (Interactive Setup) — user chooses how many guns
- **Generation:** Phase 2B (Story Bible — Plot & Story Elements)
- **Tracking:** Phase 3 (Chapter Generation) — every chapter
- **Verification:** Phase 4 (Verification) — Continuity Guardian checks payoff status

## Phase 1: Gun Count Selection

During Interactive Setup, ask the user. Present ALL FOUR options as individually
selectable choices — do not omit, merge, or group any of them:

```
How many Chekhov's Guns would you like woven into the story?

1. None — No planted-and-paid-off elements (simpler narrative)
2. One (1) — A single significant planted element
3. A Few (3) — Three planted elements across the narrative
4. Several (5) — Five planted elements for a richly layered story

Chekhov's Guns are objects, skills, details, or story elements introduced
early that become significant later. They reward attentive readers and
create satisfying "aha!" moments on re-reading.
```

Map the selection:
```
none    → 0 guns
one     → 1 gun
few     → 3 guns
several → 5 guns
```

Store the selection as `chekhovsGunOption` in the project metadata.

## Phase 2B: Gun Generation

During Story Bible Phase 2B (Plot & Story Elements), generate the Chekhov's Guns
as part of the story outline.

### Generation Prompt Addition

Add to the Story Bible Phase 2B prompt:

```
CHEKHOV'S GUNS — Generate exactly {N} Chekhov's Gun elements.

For each gun, provide:
1. NAME: A short, memorable name for the element
2. DESCRIPTION: What it is and why it matters (1-2 sentences)
3. SETUP (Introduction): How and when it's planted in the story
   - Which chapter it appears in
   - How it's introduced naturally (not telegraphed)
   - Why the reader won't immediately recognize its importance
4. PAYOFF: How and when it becomes significant
   - Which chapter the payoff occurs in
   - How the earlier mention connects to the later significance
   - The "aha!" moment for the reader

RULES FOR GOOD CHEKHOV'S GUNS:
- The SETUP must feel natural and incidental at the time — no neon arrows
- The PAYOFF must feel inevitable in retrospect — "of course that mattered!"
- Guns should be VARIED: objects, skills, locations, relationships, details
- Setup chapters should be in the first 40% of the manuscript
- Payoff chapters should be in the last 40% of the manuscript
- At least ONE gun should pay off in the climax or penultimate chapter
- Guns should NOT all pay off in the same chapter (distribute across Act 3)
```

### Gun Data Shape

Each generated gun follows this structure:
```
{
  name: "The Hidden Key",
  description: "A tarnished key found in the victim's pocket, dismissed as
               unimportant until it unlocks the final piece of evidence.",
  introducedChapter: 3,
  payoffChapter: 27,
  status: "pending"
}
```

### Output

Save guns to: `Ideorix-Projects/[Title]/engine-data/chekhovs-guns.md`

Format:
```markdown
# Chekhov's Guns — {Book Title}

Gun Count: {N}
Status: {X} pending | {Y} paid off

## Gun 1: {Name}

**Description:** {description}
**Planted:** Chapter {N} — {how it's introduced}
**Payoff:** Chapter {N} — {how it pays off}
**Status:** pending / paid-off

## Gun 2: {Name}
...
```

## Phase 3: Chapter Generation Integration

### Architect Agent

The Architect receives the full gun list with every chapter brief.

For chapters where a gun is PLANTED:
```
CHEKHOV'S GUN — PLANT IN THIS CHAPTER:
Gun: "{gun_name}" — {description}
How to plant: Introduce this element naturally within the scene.
It should feel incidental — part of the world, not a spotlight moment.
The reader should NOT suspect its importance yet.
DO NOT draw attention to it with unusual description or emphasis.
```

For chapters where a gun PAYS OFF:
```
CHEKHOV'S GUN — PAYOFF IN THIS CHAPTER:
Gun: "{gun_name}" — {description}
Originally planted: Chapter {N}
How to pay off: This element must become significant in this chapter.
The connection to the earlier mention should be clear but not belabored.
The reader should have the "aha!" moment naturally.
If the reader has forgotten the setup, include a brief, natural reminder
(a character noticing it, a sensory callback) before the payoff.
```

For all other chapters:
```
CHEKHOV'S GUNS — AWARENESS:
Active guns (planted but not yet paid off):
- "{gun_name}" — planted Ch.{N}, payoff Ch.{N}
Do NOT reference these guns unless the brief specifically calls for it.
Avoid accidentally paying off a gun early or drawing attention to it
before the planned payoff chapter.
```

### Writer Agent

The Writer receives a simplified version:
```
CHEKHOV'S GUN INSTRUCTION:
[PLANT] Include "{gun_name}" naturally in this chapter: {brief description
of how to introduce it without emphasis}
— OR —
[PAYOFF] "{gun_name}" (first seen Ch.{N}) becomes significant here:
{brief description of the payoff moment}
— OR —
[AWARENESS] These elements are active — do not accidentally reference or
resolve them: {list of active gun names}
```

## Phase 4: Verification — Continuity Guardian

The Continuity Guardian tracks gun status after each chapter.

### Gun Status Check

Add to the Continuity Guardian's per-chapter analysis:

```
CHEKHOV'S GUN STATUS:
For each gun, report:
- Name: {gun_name}
- Planted: Yes (Ch.{N}) / Not yet
- Paid off: Yes (Ch.{N}) / Not yet
- Status: pending / paid-off / overdue

OVERDUE CHECK:
A gun is OVERDUE if:
- It was supposed to be planted by Chapter {N} and hasn't been
- It was supposed to pay off by Chapter {N} and hasn't been
- The story is past 90% completion and a gun is still pending

If a gun is overdue, flag as severity: HIGH
Suggestion: "Chekhov's Gun '{name}' was planted in Ch.{N} but has not
paid off. Expected payoff: Ch.{N}. Current chapter: {N}. This gun
must pay off within the next {remaining} chapters or it becomes a
planted element without resolution."
```

### Continuity Guardian Output Schema Addition

Add to the Continuity Guardian's output:
```
chekhovsGuns: {
  guns: [
    {
      name: string,
      plantedChapter: number | null,
      payoffChapter: number | null,
      expectedPayoff: number,
      status: "pending" | "paid-off" | "overdue" | "not-yet-planted"
    }
  ],
  overdueCount: number,
  summary: string
}
```

## Rules

### Planting Rules
1. **Natural introduction** — The gun must feel like part of the world, not a
   spotlight moment. A character picks up an object, mentions a skill, or
   notices a detail as part of normal action.
2. **No emphasis** — Do NOT use unusual description, extended focus, or
   character reaction to signal importance. The gun should be one detail
   among many.
3. **Early placement** — All guns should be planted in the first 40% of
   the manuscript. Late planting feels like a cheat.
4. **Multiple senses** — Where possible, ground the gun in a specific
   sensory detail (the feel of the key, the smell of the chemical, the
   sound of the floorboard). This makes the callback more visceral.

### Payoff Rules
1. **Earned significance** — The gun must become important through story
   logic, not coincidence. The key fits the lock because someone put it
   there, not because the universe was helpful.
2. **Natural callback** — If the reader may have forgotten the setup,
   include a brief, natural reminder before the payoff (a character
   notices the object again, a sensory echo).
3. **Distributed resolution** — Don't pay off all guns in the same
   chapter. Distribute across Act 3 for sustained satisfaction.
4. **At least one climax gun** — One gun should pay off in the climax
   or penultimate chapter for maximum impact.

### What Makes a Good Chekhov's Gun

| Good Guns | Bad Guns |
|-----------|----------|
| A specific object with a later use | A vague "feeling" that pays off |
| A skill mentioned casually that becomes critical | A character who appears once and solves everything |
| A location detail that becomes the setting of the climax | An information dump that's later "remembered" |
| A relationship dynamic that reverses | A prophetic dream that comes true literally |
| A physical detail of the setting that enables the resolution | A coincidence dressed as foreshadowing |

### What Chekhov's Guns Are NOT

- **Foreshadowing** — Foreshadowing hints at what's coming. Guns are specific
  elements that recur with new significance.
- **Red herrings** — Red herrings deliberately mislead. Guns deliver on their
  implicit promise.
- **Themes** — Themes recur throughout. Guns have a specific plant-and-payoff
  structure with identifiable chapters.
- **Setup/payoff in the same scene** — A gun must span multiple chapters.
  Setup and payoff in adjacent scenes is just good writing, not a gun.

---

## Series-Level Guns (Multi-Volume Projects)

When the project is part of a planned series (Phase 0 completed), Chekhov's Guns
can span across volumes. These are called **Long-Range Guns** — elements planted in
an early volume that pay off in a later volume.

### How Long-Range Guns Differ

| Aspect | Standard Gun | Long-Range Gun |
|--------|-------------|----------------|
| Scope | Within one volume | Across 2+ volumes |
| Plant timing | First 40% of manuscript | Any point in early volumes |
| Payoff timing | Last 40% of manuscript | Later volumes (specified in Series Bible) |
| Tracking | Per-volume gun file | Series-level gun file + per-volume awareness |
| Reader impact | "Aha!" within one book | "Aha!" that rewards series commitment |

### Generation

Long-Range Guns are defined during Phase 0 (Series Architecture) as part of the
Arc Weave Matrix. They appear in the Series Bible under a dedicated section:

```markdown
# Series-Level Guns — {Series Title}

Long-Range Gun Count: {N}

## Long Gun 1: {Name}

**Description:** {what it is and why it matters across the series}
**Planted:** Volume {N}, Chapter {N} — {how it's introduced}
**Developed:** Volume {N} — {how it's referenced or deepened}
**Payoff:** Volume {N}, Chapter {N} — {how it pays off}
**Status:** not-yet-planted / planted / developing / paid-off
```

### Per-Volume Integration

When writing a specific volume, the Architect and Writer receive awareness of
Long-Range Guns relevant to that volume:

**If this volume PLANTS a long-range gun:**
```
SERIES GUN — PLANT IN THIS VOLUME:
Gun: "{name}" — {description}
Target chapter: {N}
How to plant: Introduce naturally. This element won't pay off until Volume {N}.
It should feel like background texture now — its significance comes later.
```

**If this volume DEVELOPS a long-range gun (keeps it alive without payoff):**
```
SERIES GUN — DEVELOP IN THIS VOLUME:
Gun: "{name}" — planted in Volume {N}
How to develop: Reference or deepen this element naturally. Don't resolve it —
just keep it alive in the reader's mind. A brief callback is enough.
```

**If this volume PAYS OFF a long-range gun:**
```
SERIES GUN — PAYOFF IN THIS VOLUME:
Gun: "{name}" — planted in Volume {N}
How to pay off: This element becomes significant. Include a natural reminder of
when it was first seen (readers may have forgotten across volumes), then deliver
the payoff. The connection should feel earned and inevitable.
```

### Tracking File

Save series-level guns to: `Ideorix-Projects/[Series Title]/series-data/series-guns.md`
This file persists across all volumes and is updated after each volume is completed.
