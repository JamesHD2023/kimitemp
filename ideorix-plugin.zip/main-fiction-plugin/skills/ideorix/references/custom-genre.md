---
name: custom-genre
description: "Build your own genre — guided interview that produces a fully-formed genre plugin, optionally inheriting from existing genres"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Custom Genre Builder

Don't see your genre in the 68 built-ins? Build your own. The Custom Genre
Builder walks you through a guided interview and produces a fully-formed
genre file that every downstream agent — Architect, Writer, Quality
Guardian, Prose Humaniser — treats identically to a built-in genre.

You can use your custom genre as a standalone project's primary genre, as
one slot in a 2-3 genre Mash-Up, or save it to a cross-project library
for future use.

## What it does

| Task | What happens |
|------|-------------|
| **Scoping interview** | Asks your genre's name, reader promise, and whether it inherits from existing genres |
| **Parent inheritance** | Optional — pick 1–3 existing genres as scaffolds. The builder pre-fills 80% of the file using merged parent rules, then asks what you want to change. Strongly recommended. |
| **Identity section** | Category placement, icon, target word count, reader expectations, comparable titles, tonal range |
| **Craft rules** | Prose style, POV, dialogue density, must-include beats, forbidden patterns, signature craft techniques — either from scratch or as overlays on inherited parent rules |
| **AI crutch phrases** | Three paths: inherit from parents, seed from a similar built-in genre, or skip (universal AI-ism detection still runs) |
| **Review gate** | You see the complete generated file before it's saved. Edit any section, regenerate, or approve. |
| **Save + register** | Writes to your project's custom-genre folder and/or the cross-project library. Immediately usable by the Genre Bank Loading Protocol. |

## How to start

Say any of:
- "Build a custom genre"
- "Create my own genre"
- "Design a genre"
- "I want a genre that isn't in the list"
- "Custom genre builder"
- "Add a new genre"

Or, during Phase 1 genre selection, pick **option 9: "Build a custom genre"**
from the category list. The builder runs inline and hands back to the
setup flow with your custom genre as the Primary.

## Inheritance — the fast path

The builder runs fastest and produces the strongest custom genres when
you inherit from 1–3 existing parents. Here's why:

- The engine already has 68 hand-tuned genre files, each with 400-600
  lines of craft rules, quality criteria, revision priorities, and
  AI crutch phrase tables.
- Starting from scratch means rebuilding all that depth yourself in a
  single interview session.
- Inheriting lets you keep the parent's depth and just describe what's
  **different** about your genre. For a "Neon Western", inherit from
  `western` + `cyberpunk` and the builder asks you only about the
  things those two don't already cover together.

You can still build from scratch if your genre genuinely doesn't overlap
with any existing one — the interview is longer but the result is
entirely yours.

## Storage

Custom genre files live in one of two places:

- **Project-local** (default): `~/Documents/Ideorix-Projects/{Title}/engine-data/custom-genres/{slug}.md`
  Used only for this project. Isolated from other projects.

- **Persistent library** (cross-project): `~/Documents/Ideorix-Projects/.genre-library/{slug}.md`
  Available to every project. Shown in the Question 1 category list
  under "Your custom genres".

- **Both** (recommended): project gets its own copy AND the library
  stores one for future projects.

You pick the storage approach during the interview.

## What a custom genre can do

Once saved, a custom genre behaves identically to a built-in one:

- **Primary of a project** — it drives the Architect, Writer, Quality
  Guardian, and Humaniser the same way any built-in genre does.
- **Slot in a mash-up** — combine it with built-in genres in a 2- or
  3-genre Mash-Up (e.g. `custom-neon-western` + `cyberpunk` + `noir`).
- **Reused across projects** — if saved to the library, it appears in
  the Phase 1 category list forever.
- **Editable** — the file is plain markdown. Edit it directly in any
  text editor to tune rules between projects.

## What the builder is NOT

- **Not a genre expert substitute.** A custom genre is only as good as
  the rules you (or the inherited parents) provide. For production
  quality, inherit from built-in genres rather than building from
  scratch.
- **Not a corpus analyser.** The builder can't auto-detect AI crutch
  phrases — you either inherit them from parents, seed from a similar
  genre, or skip that section.
- **Not permanent.** Custom genres can be deleted by removing the file
  from the custom-genres folder or the library.

## What you get back

A markdown genre file at your chosen location(s), matching the
standard Ideorix genre file format:

```
# {Your Genre Name} — Custom Genre Plugin

## Metadata
## Architect Instructions
## Writer Craft Rules
## Quality Check Criteria
## Continuity Rules
## Genre-Specific Craft Techniques
## Genre-Specific Revision Rules
## Names & Patterns to Avoid
## AI Crutch Phrases (ELIMINATE ALL)
```

Plus, if you ran the builder inside a project setup flow, an offer to
immediately register the custom genre as that project's Primary and
continue to Question 2.

> Protocol: `genre-builder.md`
