---
name: tension-graph
description: "Tension Arc / Plot Energy Map — renders the manuscript's pacing trajectory as a visual graph from the data the engine already tracks (the six Narrative Pacing Sliders in engine-data/tension-tracker.md). User-invocable on demand ('show my tension graph', 'plot my story's tension', 'pacing arc') and offered automatically at delivery. Graceful-fallback rendering: a rich library chart when the runtime environment supports it, falling back to a guaranteed zero-dependency stdlib SVG (scripts/tension-arc-render.py) so every user gets a real graph without an install step. Fiction only — non-fiction has no six-slider system. The plotted values are the engine's ASSESSED tension (Architect-planned, Arc-Analyst-verified 1-10 craft judgments), not a mechanical measurement of the prose; the chart is labelled as such."
version: "2.7.120"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript Engine
> *© James Harvey Media. All rights reserved.*

# Tension Graph — Visualise the Pacing Arc

## Purpose

The engine already tracks a rich, per-chapter pacing dataset in
`engine-data/tension-tracker.md` — the six Narrative Pacing Sliders
(Tension, Dread, Emotional Intimacy, Relationship Tension, Pacing
Energy, Humor), each with a planned value (set by the Architect when
the chapter brief is designed) and an actual value (set by the Arc
Analyst after the chapter is verified). See `blueprint-protocol.md`
§3a (the sliders), the Tension & Pacing Tracker section (the file),
and `quality-gate.md` (the verification update).

That data is the perfect shape for a graph, and writers want one.
A real user, on their own, asked Claude (Ideorix in Cowork) for "an
action plot graph for a 30-chapter thriller I just finished" and got
a polished three-act tension chart with the climax and key beats
annotated. The capability already exists in practice; what was
missing was making it a **discoverable, repeatable, named feature**
rather than something the rare creative user thinks to ask for.

This spec is that feature: the Tension Graph (a.k.a. Plot Energy
Map / Pacing Arc).

## What it plots

By default, **all six sliders** as separate lines over the chapter
axis — the full pacing fingerprint of the manuscript. The data
already exists for all six, so plotting them is free and more
informative (a writer can see, e.g., that Dread leads Tension by a
couple of chapters, or that Humor collapses in Act 3).

A **single-arc** mode plots only the Tension line, for the cleaner
one-line "dramatic energy" view most writers first picture (matching
the user's example). Offered when the user asks for "just the
tension line" / "a simple arc" / "one line".

For each chapter the **actual** (verified) value is plotted where it
exists; chapters not yet verified fall back to their **planned**
value, so the graph works mid-draft as well as on a finished book.

## Honest labelling (MANDATORY)

The plotted values are the engine's **assessed** tension — the
Architect's planned 1-10 judgments and the Arc Analyst's verified
1-10 judgments. They are a craft assessment, NOT a mechanical
measurement of the prose (there is no deterministic "tension meter"
reading the words). Every rendered chart MUST carry a caption to
that effect (the stdlib renderer prints it automatically; a
library-rendered chart MUST include the equivalent). Do not present
the curve as objective measurement — present it as "here is how the
engine assessed your manuscript's pacing", which is genuinely useful
and honest.

## Rendering — graceful fallback (MANDATORY contract)

The feature MUST always produce a graph for the user, regardless of
environment, while taking advantage of richer rendering when it is
available. Two tiers:

1. **Rich chart (preferred when available).** If the runtime
   environment provides a charting capability (e.g. the Cowork
   sandbox where a plotting library can run), the orchestrator MAY
   render a polished chart — act-band shading, climax marker, beat
   annotations, the lot (the user's own example is the quality bar).
   This is the nicer output and should be used when it can be.

2. **Zero-dependency SVG (guaranteed floor).** Otherwise — and as
   the always-available fallback — run the stdlib renderer:

   ```bash
   python3 scripts/tension-arc-render.py {project-root} [--single]
   ```

   It reads `engine-data/tension-tracker.md`, writes
   `engine-data/reports/tension-arc.svg` (a plain-text SVG, no
   external deps), and opens in any browser on macOS / Windows /
   Linux with no install step. This mirrors the
   `manuscript-render.py` philosophy exactly: the engine guarantees
   working output everywhere via stdlib, and uses something prettier
   only when the environment offers it.

**The contract:** the user must NEVER be told "I can't draw a graph
here." If the rich path is unavailable, the SVG floor runs. The only
legitimate failure is a missing or empty tracker (handled below).

## Procedure

1. **Locate the tracker.** Resolve the project root (per
   `core-pipeline.md` path resolution) and check
   `engine-data/tension-tracker.md` exists and is non-empty.
   - If absent: the manuscript has not been through enough of the
     pipeline to populate it. Tell the user plainly: "The pacing
     data isn't available yet — it's built up as chapters are
     planned and verified. Run the generation or editorial pipeline
     first, then ask again." Do NOT fabricate slider values to draw
     a graph; an invented arc is worse than no arc.
2. **Choose the mode.** Multi-slider by default; single-arc if the
   user asked for the simple/one-line view.
3. **Render.** Rich chart if the environment supports it (with the
   honest caption); otherwise run `tension-arc-render.py`.
4. **Present.** Show/describe the graph inline and tell the user
   where the file is (`engine-data/reports/tension-arc.svg` for the
   SVG path). Offer a one-paragraph plain-English read of the arc
   (where it builds, where it breathes, where the climax peaks) —
   the graph plus the reading is more useful than the graph alone.
5. **Optional annotations.** When a rich chart is produced, the
   orchestrator may annotate act boundaries (from the beat
   structure) and the climax chapter (the manuscript Tension peak),
   matching the user-example quality. The stdlib SVG keeps it clean
   (lines + legend + caption) by design — annotation richness is the
   reward for a capable environment, not a requirement.

## When it runs

- **User-invocable on demand** via trigger phrases: "show my tension
  graph", "plot my story's tension", "pacing arc", "tension graph",
  "plot energy map", "show my pacing", "graph my plot". Routed from
  SKILL.md.
- **Offered at delivery.** After the editorial pipeline / Handoff
  Protocol completes, offer the Tension Graph alongside the other
  delivery artifacts ("Would you like a Tension Arc graph of your
  manuscript's pacing?"). Opt-in — not forced.

## What this does NOT do

- Does **not** compute or change any slider value — it only
  VISUALISES the existing tracker data. (Slider assessment lives in
  blueprint-protocol.md / quality-gate.md and is unchanged.)
- Does **not** apply to non-fiction — NF has no six-slider tension
  system (its momentum is argumentative, not dramatic). Fiction only.
- Does **not** require any external library, ever, as a hard
  dependency — the stdlib SVG floor guarantees that.
- Does **not** fabricate data when the tracker is missing — it tells
  the user the data isn't ready yet.

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification binding are
documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (tension-tracker.md) | "Tracker read, data extracted" | Tracker absent / empty / malformed table → an invented or blank graph is drawn | `tension-arc-render.py` returns exit 1 with an explicit "tracker not found / unparseable" message and draws NOTHING; the spec forbids fabricating slider values to fill a graph. The orchestrator surfaces the "data not ready" message instead of a fake arc. |
| Rendering (graceful fallback) | "Graph produced" | Rich path unavailable in the environment → user told "can't draw a graph" (a capability gap presented as a failure) | The MANDATORY fallback contract: when the rich path is unavailable, run the stdlib SVG renderer, which has no environmental dependency. The user always gets a real graph; "I can't draw one here" is a forbidden response. |
| Write (SVG output) | "SVG written" | Subdir flush / partial write leaves a corrupt SVG | `tension-arc-render.py` writes via stdlib file write to `engine-data/reports/` (the directory the PostToolUse Engine-Data Integrity Hook covers); the SVG is well-formed XML by construction (escaped text, closed tags). A truncated write fails the browser's XML parse loudly rather than silently. |
| Honest labelling | "Graph shown" | Curve presented as an objective measurement of prose tension | MANDATORY caption on every chart (auto-printed by the stdlib renderer; required of any rich chart) stating the values are the engine's assessed craft judgment, not a mechanical measurement. |

## Routing

- `blueprint-protocol.md` §3a + Tension & Pacing Tracker — the
  source of the slider data this feature visualises
- `quality-gate.md` Tension Tracker Update — where actual values are
  written
- `scripts/tension-arc-render.py` — the zero-dependency SVG floor
- `scripts/manuscript-render.py` — the precedent for the stdlib-
  floor / prettier-when-available rendering philosophy
- `core-pipeline.md` path resolution — for locating the project root
- `editorial-suite.md` / Handoff Protocol — where the graph is
  offered at delivery
- `SKILL.md` Direct Triggers — the user-invocable trigger phrases
