---
name: historical-romance-genre
description: Genre-specific instructions for historical romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Historical Romance. Genre Plugin

## Metadata
- id: historical-romance
- name: Historical Romance
- icon: 🏛️
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Romancing the Beat", "Three-Act Structure", "Save the Cat", "Freytag's Pyramid"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| **Regency Romance** | Set during the British Regency era (1811–1820), centred on the London Season, the ton, and the marriage mart. Witty banter, rigid social hierarchy, and ballroom courtship define the subgenre. | Lighter, more comedic tone. Strict rules of address and precedence. The Season as pacing device. Influence of Austen and Heyer on reader expectations. Empire-waist fashion, Almack's, and the patronesses as cultural gatekeepers. |
| **Victorian Romance** | Set during Queen Victoria's reign (1837–1901), spanning early industrial upheaval through the height of Empire. Greater emphasis on moral propriety, domestic life, and the tension between public respectability and private desire. | Darker, more emotionally intense tone. Stricter sexual morality and heavier consequences for transgression. Industrialisation creates new class tensions (self-made men vs. aristocracy). Longer mourning customs. Corsetry, gaslight, and fog as atmospheric staples. |
| **Medieval Romance** | Set between roughly 1066 and 1485, encompassing the Norman Conquest, the Crusades, and the Wars of the Roses. Raw physicality, feudal obligation, and the Church's authority shape every romantic encounter. | Higher physical stakes. violence, warfare, and survival are closer to the surface. Arranged marriage as default, love matches as rebellion. Feudal loyalty and land ownership drive conflict. Less literate society means oral communication, fewer letters. Cruder living conditions create different sensory landscape. |
| **American Frontier Romance** | Set during westward expansion (1800s–1890s), on the raw edges of settlement where social rules are thinner and survival is paramount. Frontier hardship, self-reliance, and the collision of cultures define the romantic landscape. | Looser social constraints but harsher physical environment. Class distinctions less rigid but racial and cultural tensions more prominent. Isolation creates enforced proximity. Pioneer self-sufficiency as attractive trait. Mail-order brides, ranch life, and frontier justice as common frameworks. |
| **WWII Romance** | Set during the Second World War (1939–1945), against the backdrop of global conflict, rationing, and the upheaval of traditional gender roles. Urgency, separation, and the ever-present threat of death intensify every romantic moment. | Compressed timeline. wartime urgency accelerates courtship. Letters as primary romantic medium during deployment. Women in new roles (factories, military auxiliaries, resistance). Death as constant shadow raising emotional stakes. Espionage, Blitz spirit, and home-front resilience as settings. |
| **Ancient World Romance** | Set in classical civilisations. Rome, Greece, Egypt, Persia, or other ancient cultures. Slavery, empire, religious plurality, and radically different gender norms create a romantic landscape far removed from Anglophone defaults. | Requires deepest research commitment. readers have fewer preconceptions but less tolerance for errors. Slavery and conquest as unavoidable context. Polytheistic religious frameworks shape morality differently. Physical settings (baths, forums, temples) offer unique romantic spaces. Power dynamics more extreme and less familiar to modern readers. |

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-5,000 words
- Pacing: Courtship rhythm: slow-building tension within period constraints, stolen moments escalating
- Must open with: Period atmosphere establishing era and social world, romantic tension or charged first encounter
- Must close with: Chemistry deepened against social odds, scandal threatened, or period obstacle tightened

BEATS PER CHAPTER
1. Period Atmosphere: Sensory grounding in era. clothing, setting, social ritual, historical backdrop
2. Romance Moment: Attraction, banter, stolen glance, forbidden touch. chemistry within period boundaries
3. Social Constraint: Class, propriety, family duty, gender roles, or law creating romantic obstacle
4. Intimacy Against Odds: Vulnerability shared despite era's rules. emotional closeness defying convention
5. Historical Stakes: Period event, social consequence, or political pressure raising personal cost of love

GENRE-SPECIFIC REQUIREMENTS
- Romance IS the plot: historical setting creates the obstacles, not backdrop decoration
- HEA/HFN required: couple together at end despite period barriers
- Historical accuracy in major details: technology, social customs, political context, daily life
- Social constraints drive conflict: class difference, scandal, reputation, family duty, law
- Dual POV expected: both romantic leads' perspectives and period experiences
- Chemistry palpable: desire shown through what the era forbids (touch, proximity, direct speech)
- Period-appropriate agency: characters find power within era's limitations, not magically outside them
- Courtship customs observed or deliberately transgressed (with consequences)
- Scandal as real stakes: reputation destruction, social exile, financial ruin, imprisonment
- Supporting cast reflects era: servants, chaperones, family, society matrons, historical figures
- Research invisible: period detail woven through action, never lectured
- Letters, calls, and correspondence as romantic devices when era demands separation

FORBIDDEN
- History as wallpaper: setting must actively shape conflict, not just provide pretty dresses
- Modern attitudes without consequence: 21st century feminism spoken aloud in Regency ballroom
- Anachronistic language: "okay," "cool," therapy-speak, modern slang
- Perfect gender equality: era's constraints must be felt even as characters push against them
- Instalove without courtship: attraction instant, love develops through period-paced interaction
- Abuse romanticized: rakish behavior requires genuine consent and growth
- Sanitized history: era's prejudices, hardships, and inequities shown honestly
- Info-dumping research: no history lessons in dialogue or narration
- Ignoring consequences: transgressing social rules without realistic repercussions
- Stereotypical characters: no generic rake/wallflower without individual complexity; every character needs specific, ground-up backstory
- Single-obstacle stories: period barriers alone aren't enough; layer internal emotional wounds alongside social constraints
- Relentless heaviness: even stories set in war or hardship need humor, warmth, moments of unexpected lightness

OBSTACLE LAYERING (critical for historical romantic tension)

Historical romance has a built-in advantage: the era itself provides external obstacles (class, propriety, law, family authority). But external barriers alone aren't enough. Layer INTERNAL obstacles that the period context illuminates: fear of vulnerability masked by social propriety, past wounds that era expectations make impossible to discuss, desire for autonomy in a world that forbids it. The more obstacles. social AND personal. the more the reader yearns for every stolen moment.

Example historical obstacle layering:
- Obstacle 1: She is married/promised to someone her family chose
- Obstacle 2: He lives in a different social world with different codes
- Obstacle 3: She has never spoken her true feelings to anyone: the era prohibits it
- Obstacle 4: A small-town setting where nothing goes unwitnessed

LIGHT AND SHADE

Even in a historical romance set against bleak circumstances, you need emotional contrast. After a scene of devastating societal pressure or heartbreaking separation, provide relief. a moment of unexpected humor, a small kindness from an unlikely quarter, an absurd mishap. After a scene of romantic warmth and stolen intimacy, introduce a complication that crashes hopes. Two heavy scenes back to back either overwhelm or cancel each other out. The contrast between joy and sorrow is what makes each emotion register fully.

RESEARCH ENRICHING TONE AND AUTHENTICITY

Quality research doesn't just fill in historical details. it feeds into the TONE of the entire story. The way people spoke in a specific era and region, the rhythms of their daily life, the textures they touched. these discoveries should transform the emotional atmosphere of the writing, not just decorate the plot. Wear your research lightly. Never lecture the reader with historical facts. Instead, let period detail emerge through one sensory experience at a time, filtered through the character's awareness. If research reveals something that threatens the plot, you can adjust the story. but never ignore what the period actually was.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (relationship arc), Captivation (period), Anticipation (social-stakes obstacle).

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-protocol.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE
- POV: Dual 3rd limited (both romantic leads) or alternating 1st person
- Tense: Past (fits historical narrative naturally)
- Voice: Period-influenced but never impenetrable: formal enough for era, emotional enough for romance
- Reading level: Adult: historical sophistication, mature romantic content, period complexity

PROSE IMPERATIVES
- Period vocabulary natural: era-appropriate words for clothing, address, objects, feelings
- Sensory detail grounds every scene in the past: candlelight, horse leather, coal smoke, silk against skin
- Social hierarchy visible in every interaction: who speaks first, who sits, forms of address
- Internal longing intensified by prohibition: wanting what propriety forbids
- Chemistry shown through what the era restricts: the charged brush of gloved fingers, an improper gaze held too long
- Formality as tension: rigid social rules making every breach electric
- Research integrated invisibly: period details through action and experience, never exposition
- Emotional interiority modern in depth: characters feel as deeply as contemporary people, think within period framework
- Letters and correspondence as intimate revelation: written word carrying what spoken word cannot
- Landscape and architecture as mood: great houses, ballrooms, gardens, battlefields reflecting emotional state

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- Period-specific sensory immersion AND immediate chemistry or intrigue from the first page
- Tension floor: 5 (the reader must feel both the era's atmosphere and the romantic pull)
- Open with a character IN their world. arriving at an assembly, managing a household crisis, receiving a letter. not with historical exposition
- Dialogue density: 30%+. balance period-accurate speech with readability; formality is tension, not barrier

Courtship scenes (prose rhythm):
- Sentence structure slightly more formal, reflecting the era: but never stiff or impenetrable
- Medium-to-long sentences during social ritual; shorter when propriety is breached
- Interiority budget: 40%: what characters CANNOT say aloud lives in their thoughts
- Sensory detail era-specific: candlelight, fabric weight, glove leather, the temperature of a room
- Dialogue must balance period-accuracy with readability: use era vocabulary the modern reader still feels

Stolen-moment scenes (prose rhythm):
- Sentences shorten when transgression occurs: a touch, a look held too long, a name used improperly
- Silence on the page carries weight: paragraph breaks for the charged pause
- Era-appropriate vocabulary without making it feel like a textbook: one period detail per beat, lived in

Climax/resolution prose rhythm:
- The declaration: formality cracks: shorter, more direct sentences break through the era's restraint
- Grand gesture earned within period means: the prose respects the world while the characters defy it
- Final beat: the HEA carries the weight of everything the era demanded they sacrifice

GENRE-SPECIFIC STYLE
- Courtship customs as plot engine: calls, chaperones, dances, introductions creating structured proximity
- The Season or social calendar as pacing device: balls, assemblies, house parties compressing encounters
- Scandal as genuine threat: not melodrama but real social, financial, and legal consequences
- Stolen moments heightened: a private conversation, an unchaperoned walk, a closed carriage
- Class difference in dialogue: aristocrat and servant speak differently, merchant and duke think differently
- Letters as romance: correspondence revealing true feelings impossible in person
- Gossip and reputation as antagonist: society itself as obstacle, the ton as judge
- Domestic detail as world-building: managing households, dressing, dining, calling cards
- Historical events as pressure: war, political upheaval, social reform creating urgency
- Secondary romances reflecting era: servants' courtship, widows' limited options, arranged matches as contrast

FORBIDDEN WORDS/PHRASES
- "Okay" or "OK": use "very well," "certainly," "agreed"
- "Boyfriend/girlfriend": use "suitor," "beau," "intended," "betrothed," "sweetheart"
- Modern therapy language: "boundaries," "toxic," "triggered," "self-care," "gaslighting"
- Modern slang: "cool," "guys," "awesome," "basically"
- Anachronistic idioms: research when phrases entered language; many "old sayings" are modern
- "Chemistry" stated outright: show the attraction through period-specific physical awareness
- Purple prose cliches: "heaving bosom," "throbbing manhood," "orbs" for eyes
- Modern profanity if period-inaccurate: research era-specific oaths and curses

HISTORICAL DETAIL IN ROMANCE
- Clothing as sensory experience. Pick the ONE detail that matters to THIS character in THIS moment: the stays cutting under her ribs, or the drag of wet skirts, or the cold air on skin as laces loosen
- Dance as permitted intimacy: the only sanctioned public touching, choreography as flirtation
- Dining and social ritual: seating arrangements, precedence, conversation rules as obstacles or opportunities
- Travel as enforced proximity: long carriage rides, house party isolation, sea voyages
- Servants as witnesses: privacy nearly impossible, stolen moments precious
- Money and property as marriage stakes: dowries, entails, settlements, financial dependence
- Religion shaping morality: church attendance, sin and redemption, marriage as sacrament

INTIMACY IN HISTORICAL CONTEXT
- Emotional depth modern, physical context period-appropriate: characters feel everything, express within era's boundaries
- Virginity and sexual knowledge realistic to era and class: not modern sexual confidence without justification
- Consequences real: pregnancy without contraception, reputation destroyed, marriage forced or forbidden
- Consent shown clearly despite period power dynamics: willingness explicit even in era of male authority
- Undressing as revelation: layers of period clothing removed with significance
- Wedding night expectations: period anxieties, limited knowledge, tenderness or awkwardness authentic
- Widows and experienced characters: different sexual knowledge and freedom than unmarried characters
- Physical intimacy escalation within period logic: hand kiss to unchaperoned meeting to compromising position

INTIMATE SCENES. CHARACTER AND PERIOD TRUTH

- Sex scenes in historical romance must illuminate something about the characters AND the era: not exist merely for heat
- Ask: what does this intimate moment reveal about the power dynamics, the social risks, the emotional landscape of these specific people in this specific time?
- Awkwardness, nervousness, and limited knowledge are MORE authentic and compelling than modern sexual confidence transplanted into a period setting
- Build physical intimacy into the emotional landscape of the story: it should feel like the inevitable culmination of chapters of restrained longing
- The period context makes every physical transgression electric: a brush of ungloved fingers, an improper gaze, a moment alone carries enormous weight precisely because the era forbids it

DIALOGUE. THE POWER OF THE UNSAID IN PERIOD SETTINGS

- Historical dialogue demands mastery of what is NOT said: the era's social rules create a built-in gap between feeling and expression that IS the romantic tension
- Characters should communicate desire through everything EXCEPT direct declaration: the way they address each other, the formality they maintain or breach, what they write in letters that they would never say aloud
- Restraint gives enormous resonance to the moment feelings are finally spoken: after chapters of propriety, a single use of a first name can be more devastating than any modern love declaration
- Each character must speak distinctly according to their class, education, region, and personality: a servant and an aristocrat use different words, different rhythms, different forms of address
- Research the actual speech patterns of the era: there is often a musicality, formality, or directness that feeds into the tone of the entire book
- The most powerful exchanges in historical romance happen when both characters are fighting the constraints of their world to communicate something they cannot say directly

METHOD WRITING. EMOTIONAL IMMERSION

- Identify the specific emotion you want the reader to FEEL before writing any key scene: the ache of forbidden longing? The thrill of transgression? The terror of scandal?
- Write through the senses to ground the reader in the period. One sensory detail per beat, not a list. The stays cut under her ribs. The room is cold enough to see her breath. One detail, lived in
- If you aren't feeling the emotion as you write it, the reader won't feel it: that is the signal to go back and find what's missing
- Research trips (real or imaginative) are invaluable: hearing how people speak in a place, seeing what they see, touching what they touch, lends writing an extra dimension it wouldn't otherwise have

THEME BENEATH THE PERIOD SETTING

Every strong historical romance has a THEME. what the book is really about beneath the corsets and courtship. Is it about the cost of duty versus the claims of the heart? About how society constrains women (and men) from being fully themselves? About the gap between what we communicate and what we mean? Theme gives the story a universality that connects modern readers to historical characters. The period creates the conflict, but the theme creates the resonance.
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)
1. HEA/HFN delivered: Couple together at end. romance genre promise kept despite historical obstacles
2. Period authenticity: Historical setting accurate and immersive. not modern story in costume
3. History drives romance: Era's constraints create the obstacles. class, propriety, law, duty shape conflict
4. Dual protagonists: Both romantic leads fully developed with period-specific agency, goals, and growth
5. Research invisible: Period detail woven naturally. no info-dumps, no anachronisms, no history lectures

GENRE-SPECIFIC CHECKS
- HEA/HFN present: Couple together and committed despite period barriers overcome
- Period accuracy: Major historical details correct: technology, customs, politics, social structure
- Social constraints as conflict: Class, reputation, family duty, or law creating genuine romantic obstacles
- Both POVs present: Reader experiences both protagonists' perspectives within period context
- Chemistry shown through period lens: Attraction demonstrated within era's boundaries: charged restraint
- Courtship customs observed or deliberately transgressed with consequences
- Language period-appropriate: No anachronistic slang, modern therapy-speak, or jarring contemporary phrasing
- Characters think in period: Worldview authentic to era: religious framework, class consciousness, gender expectations
- Scandal stakes real: Social consequences of romance treated as genuinely threatening
- Research integrated: Period details through action and sensory experience, not exposition

AUTOMATIC FAILS
- Tragic ending: Couple not together: violates romance genre promise regardless of historical accuracy
- History as wallpaper: Period setting decorative only, not driving conflict or shaping characters
- Anachronistic attitudes presented as normal: Modern feminism, racial enlightenment, sexual liberation without period consequence
- Anachronistic language: "Okay," modern slang, therapy-speak breaking immersion
- Info-dumping: History lectures in dialogue or narration: characters explaining shared knowledge
- One POV only: Only one romantic lead developed, other a cardboard love interest
- Abuse romanticized: Rake's predatory behavior presented as attractive without genuine consent or growth
- Modern characters in costume: Protagonists think, speak, and act like 21st century people wearing period clothes
- Historical events wrong: Major dates, figures, or facts inaccurate
- No chemistry: Attraction stated but never shown through period-specific tension and longing

ACCEPTABLE IMPERFECTIONS
- Slightly elevated female agency if character's unusual status is established and consequences shown
- Minor period detail approximations if major framework accurate and immersive
- Heat level varies: from closed-door to explicit, if emotionally connected and period-contextualized
- Some romance tropes (rake reformed, wallflower transformed) if executed with historical grounding
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Historical timeline: Real events occur on correct dates. wars, coronations, social seasons, political shifts
2. Social status consistency: Characters' class position, titles, forms of address, and privileges maintained
3. Period technology and knowledge: What exists, what doesn't. no telegraph before invention, no antibiotics
4. Romance progression: Courtship milestones tracked within period constraints. introduction, calls, dances, proposal
5. Reputation and scandal: What society knows, what's been witnessed, consequences that accumulate

GENRE-SPECIFIC TRACKING
- Courtship milestones: Formal introduction, first dance, first call, first unchaperoned meeting, proposal, compromising incident
- Social status of each character: Title, family connections, fortune, reputation: changes tracked
- Forms of address: How characters address each other evolving (surname to Christian name is significant)
- What society knows vs. what's private: Gossip spread, witnesses to impropriety, public vs. private behavior
- Letters exchanged: Content, promises made, secrets revealed in correspondence
- Financial situation: Dowries, debts, inheritance, settlements discussed or promised
- Family alliances and objections: Which families approve or oppose match, and why
- Chaperonage: Who is present for which scenes: privacy is rare and significant
- Historical events: Wars, elections, social reforms happening in background on correct timeline
- Servants' knowledge: What household staff have witnessed: they are always present
- Season and social calendar: Which balls, which house parties, Parliament sitting, country vs. town

ACCEPTABLE INCONSISTENCIES
- Minor background character attendance at social events
- Slight variation in daily routine descriptions
- Exact servant names if not plot-significant

CRITICAL CONSISTENCY
- Titles and forms of address: "my lord" vs. Christian name marks relationship stage; cannot regress without reason
- Virginity and sexual experience: once established, consistent until scene changes this
- Reputation status: once compromised, stays compromised unless specific rehabilitation shown
- Class position: cannot shift without major plot event (inheritance, scandal, marriage)
- Historical events on correct dates: Battle of Waterloo is June 1815, always
- "I love you" or declaration is special: track when first spoken
- Financial agreements: dowry, settlement, debt amounts stay consistent
- Family relationships: who approves, who objects, alliances don't shift without cause
- What has been witnessed: if a servant saw the kiss, that knowledge exists permanently
- Letter contents: promises and revelations in correspondence remembered and referenced
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Social class authentic: Characters' education, speech, manners, expectations, and opportunities consistent with their station
2. Period worldview: Characters think within era's framework. religious, class-conscious, gender-aware. not modern minds in corsets
3. Both protagonists developed: Dual romantic leads with period-specific agency, goals, wounds, and growth arcs
4. Gender roles navigated: Era's expectations for men and women shown honestly, resistance has consequences
5. Historical figures (if any): Real people portrayed accurately to historical record, with appropriate deference to documented facts

CHARACTER BUILDING. GROUND UP FOR HISTORICAL ROMANCE

Build each protagonist from the ground up, asking foundational questions within the period context:
- What do they want from life: within what the era allows them to want? What frustrations do they carry about their world's limitations?
- What is their family history? Class position? Education? Religious framework?
- Character tests adapted for period: What would they carry in their reticule/pocket? How would they react to witnessing injustice within their era's norms? How do they behave with servants?
- The vast majority of this backstory won't appear on the page, but it informs every reaction, every social interaction, every moment of romantic tension
- Messy, flawed characters within period constraints are far more compelling than idealized historical archetypes: a heroine who is impulsive, opinionated, or socially awkward within her era is more interesting than a generic "spirited" beauty

ANTI-STEREOTYPE IMPERATIVE

Avoid default historical romance archetypes without individual depth: no generic rake reformed by love, no wallflower who is secretly beautiful, no duke who is dark and brooding "just because." Every character needs specific, ground-up backstory that makes them feel like a real person of their era, not a costume on a hanger. The compelling ordinary people of history—the merchant's daughter, the younger son with no prospects, the widow managing her own affairs—are often far more interesting than aristocratic archetypes.

GENRE-SPECIFIC CHARACTER ELEMENTS
- Both POVs developed: Hero and heroine are full protagonists with period-specific goals beyond romance
- Social class markers: Speech patterns, education, manners, clothing, daily life reflecting station
- Period-appropriate education: What each character would know based on class, gender, era, and geography
- Gender constraints felt: Women's legal status (coverture, property rights), men's duty expectations real
- Family as force: Parents, siblings, guardians exert period-appropriate authority over romantic choices
- Reputation as character trait: How society sees each character: rake, wallflower, bluestocking, fortune hunter
- Financial reality: Characters' wealth or poverty shapes options: marriage as economic transaction alongside love
- Religious framework: Faith shaping moral reasoning, guilt, duty, and worldview
- Period skills: What characters can do. riding, needlework, estate management, languages, music. class-appropriate
- Historical awareness: Characters know what their era knows: no future knowledge, limited geography, class-filtered news
- Servants as characters: Not invisible: valets, lady's maids, housekeepers with personalities and knowledge

CHARACTER ARCS MUST
- Show romance arc within period constraints: attraction through courtship to commitment
- Navigate era's limitations: finding agency within what the period allows
- Overcome period-specific obstacles: class barrier, family opposition, scandal, financial ruin, duty
- Grow beyond era's narrowness: characters can be ahead of their time, but face consequences for it
- Earn the HEA: both romance obstacles and historical constraints resolved or defied with cost
- Demonstrate vulnerability despite period stoicism: walls lowered within era's emotional framework
- Choose love despite period's penalties: social exile, disinheritance, scandal embraced for partner
- Maintain period authenticity in growth: characters don't become modern, they become braver within their world

TRACK
- Social status and any changes: title, fortune, reputation shifts through story
- Forms of address evolution: how they address each other marks intimacy progression
- Period skills and knowledge: what each character can realistically do and know
- Family relationships and authority: who controls marriage decision, inheritance, social access
- Reputation in society: what is publicly known about each character
- Emotional wounds: period-specific traumas (war, childbirth loss, forced marriage, poverty)
- Financial situation: debts, income, dowry, inheritance expectations
- Physical appearance details: described features, clothing preferences, distinguishing marks
- Religious beliefs and moral framework: how faith shapes decisions about love and duty
```

## Arc Rules

```
ACT I (Chapters 1-10): Meeting Within Period Constraints
- Ch 1: Historical world established: era, social setting, protagonist's position; charged first encounter
- Ch 2-3: Formal courtship begins: introductions, calls, dances; chemistry sparks within propriety's rules
- Ch 4-5: Period obstacle introduced: class difference, family opposition, prior engagement, scandal history
- Ch 6-8: Stolen intimacy: unchaperoned conversation, private correspondence, touch beyond propriety
- Ch 9-10: First major transgression: compromising moment, kiss, or declaration defying social rules
- Purpose: Establish period world, introduce both leads, show attraction constrained by era
- Ends with: Chemistry undeniable, social obstacle clear, first breach of propriety committed

MIDPOINT (Chapter 15): Compromised or Committed
- Compromising incident forces hand, OR couple commits to pursuing love despite social cost
- Historical event or social crisis intensifies pressure: war, scandal exposed, family demands
- Tonal shift: From courtship games to genuine stakes: reputation, fortune, freedom at risk

ACT II (Chapters 11-23): Love Against the Era
- Ch 11-14: Deepening intimacy: secret meetings, letters, emotional vulnerability shared within period context
- Ch 15: MIDPOINT: compromising event or major declaration; historical pressure peaks
- Ch 16-18: Society pushes back: gossip, family intervention, rival suitor, financial threat
- Ch 19-21: Period constraints tighten: forced separation, arranged alternative, social exile threatened
- Ch 22-23: Black moment: scandal breaks, duty demands separation, historical event tears apart
- Purpose: Romance deepens while period obstacles escalate; both historical and romantic stakes peak
- Ends with: Black moment: society, family, duty, or history separating couple; seems impossible

ACT III (Chapters 24-30): Defying Convention for Love
- Ch 24-25: Choosing love over safety: willing to face scandal, poverty, exile for partner
- Ch 26-28: Fighting for love within period's means: elopement, public declaration, legal maneuvering, societal defiance
- Ch 29: Resolution: period obstacle overcome or accepted; couple committed despite cost
- Ch 30: Epilogue: showing couple's life together, social position after choice, HEA within historical reality
- Purpose: Earn the HEA against period's constraints; love triumphs but cost is real and acknowledged
- Ends with: HEA: together, committed, period-appropriate happiness (not modern fantasy of total freedom)

GENRE PROMISE
- HEA/HFN: couple together at end despite era's barriers
- Historical accuracy: period creates the conflict, not just the costumes
- Social constraints as real obstacles: class, reputation, duty, law, family authority
- Dual POV: both protagonists' period experiences and inner lives
- Chemistry intensified by prohibition: wanting what propriety forbids
- Courtship customs: formal social dance of attraction
- Scandal as genuine threat: consequences real, stakes high
- Period detail immersive: sensory, authentic, never lectured
- Research invisible: world felt, not explained
- Emotionally modern depth: characters feel as deeply as contemporary readers, within period framework
- Agency within constraints: heroines find power in era's limitations, not magically outside them

REQUIRED CHECKPOINTS
- Ch 3: Chemistry undeniable AND period social world established: readers feel both attraction and era
- Ch 8: Period obstacle clear: class, family, reputation, or duty blocking romance specifically because of era
- Ch 10: First major breach of propriety: kiss, unchaperoned meeting, or declaration violating social rules
- Ch 15: Compromising incident or commitment to love despite social cost; historical pressure peaks
- Ch 20: Society, family, or historical events actively threatening to separate couple
- Ch 23: Black moment: period forces at maximum, separation seems permanent
- Ch 28: Grand gesture within period's means: elopement, public stand, defiance of family/society
- Ch 30: HEA confirmed: together within historical reality, cost acknowledged, love triumphant

EMOTIONAL CONTRAST IN ARC STRUCTURE

Chart emotional highs and lows throughout the arc. After scenes of romantic warmth and stolen intimacy, introduce complications that crash hopes. After scenes of societal pressure and heartbreak, allow moments of unexpected humor, small kindnesses, or quiet beauty. This alternation amplifies every emotion. the reader relaxes into a scene of courtship joy only to have scandal threaten, then finds unexpected grace in the aftermath of disaster. Never allow more than two consecutive chapters at the same emotional register.

EARNED ENDINGS

The HEA must be TRUE to the characters and the era. Don't contrive a modern solution to a period problem. characters must find resolution within the tools their world provides (elopement, legal maneuvering, social defiance with real cost). Seed the resolution early: if the couple will overcome class barriers through a specific legal mechanism, establish that mechanism in earlier chapters. The ending should feel like the inevitable conclusion for these specific people in this specific time, not a fantasy of total freedom imposed on a constrained world. Bittersweet is acceptable. together but at cost. as long as the couple's choice is clearly worth the price.
```

## Timeline Rules

```
TIME SCALE
- Total story duration: Weeks to months, often shaped by social Season (London Season: April-July) or historical event
- Chapter time span: Days to weeks: courtship moves at period pace, not modern dating speed
- Time progression: Linear, possibly with epistolary interludes (letters bridging time gaps)

PERIOD-SPECIFIC TEMPORAL RULES
- Social Season structures pacing: balls, assemblies, house parties compress romantic encounters into defined period
- Travel times realistic: Horse/carriage 20-35 miles/day, sailing weeks-months, early rail faster but limited routes
- Communication delays: Letters take days (local) to weeks (international): no instant messaging
- Courtship pace period-appropriate: Weeks to months of formal interaction before proposal is normal
- Mourning periods enforced: Widow in black for a year minimum (Victorian), remarriage has social timeline
- Pregnancy timeline if relevant: 9 months, no reliable contraception, discovery has severe social consequences
- News travels slowly: Battle results, deaths, political events reach characters with realistic delay
- Seasons affect everything: Winter roads impassable, summer in country, spring in London, harvest obligations
- Church calendar matters: Sundays, holy days, Lent, banns read three consecutive Sundays before marriage
- War and military service: Deployment, leave, communication from front: all have period-realistic timelines

TRACK CAREFULLY
- Days since formal introduction: courtship timeline from first meeting
- Social Season progress: which week of the Season, which events attended
- Time between courtship milestones: first dance to first call to proposal
- Travel durations between locations: country estate to London, port to port
- Letter transit times: when sent, when received, response delay
- Historical event dates: real events occurring on correct dates in background
- Mourning period if relevant: how long since death, when remarriage acceptable
- Pregnancy timing if relevant: conception to discovery to birth realistic
- Military campaign timeline if relevant: deployments, battles, returns

FLEXIBLE
- Exact hours unless social obligation depends on it (morning calls are 1-4 PM, not morning)
- Minor travel between familiar nearby locations
- Background characters' daily schedules if not affecting main romance
```

## Genre-Specific Craft Techniques

Historical romance is the integration of two demands the prose
must hold simultaneously: period authenticity (the rules,
language, material culture, and psychological frame of a
specific era) and romantic satisfaction (the modern reader's
contract for an emotionally fulfilling love story they can
follow without scholarly footnoting). The form ranges from the
deeply researched social-history register (Mary Balogh, Cecilia
Grant, Loretta Chase, Eloisa James, Sarah MacLean's Bareknuckle
Bastards, Joanna Shupe, Tessa Dare's Castles Ever After) through
the lighter Regency-confection tradition (Heyer's heirs, the
Bridgerton model) into the cross-period and global-historical
expansions (Beverly Jenkins's Reconstruction-era; Vanessa Riley
on the Black diaspora across periods; Alyssa Cole; Talia Hibbert
where the historical mode is contemporary-cousin). The
techniques below are how the form sustains its dual contract
without slipping into the failure modes (wallpaper historical
where modern people wear costumes; airless museum-piece where
period accuracy crowds out the romance; or hybrid drift where
neither register is committed to fully).

### The Period-Accurate Constraint

Using historical restrictions to create romantic tension. The
period's constraints — chaperones who must be evaded; letters
that might be intercepted; servants who see and report;
unmarried women who cannot be alone with men without
chaperonage; social seasons that impose marriage-market
deadlines; mourning periods that prohibit intimacy; class
hierarchies that determine which marriages can occur; specific
laws (the marriage acts of 1753 and 1836 in Britain;
miscegenation laws in the antebellum US; coverture and married-
women's-property regimes everywhere) — are not obstacles the
writer must work around. They are the engine of the romance.
Every stolen moment gains power from what it costs in the
specific terms of the era. The technique requires that the
constraints be rendered as fully operative, not waved at: the
chaperone is a particular person with a particular relationship
to the protagonist, with her own concerns and her own
fallibility; the letter-interception risk is a specific risk
the protagonists calculate when they choose to write; the
season's deadline is a particular date with particular
consequences if missed. Test: would removing one of the period
constraints from the manuscript actually change the plot? If
the chaperone's removal would not affect the trajectory, the
chaperone is wallpaper; the constraint is decoration rather
than engine.

### The Language Register

Dialogue and prose that feel historical without being
impenetrable. Avoid both extremes: modern slang in period
mouths (the Regency duke who says "honestly" or "I'm fine"; the
Victorian heroine who "feels gaslit") breaks the spell
immediately, and dense archaisms ("forsooth"; "an it please
thee") slow the reader and signal pastiche. The trick is
rhythm and vocabulary selection — words the period used that
modern readers still understand, sentence structures that feel
formal without being stiff, and the deliberate avoidance of
both contemporary therapeutic vocabulary and faux-old quaintness.
Read substantial primary sources from the period (letters,
diaries, novels written in the era) to internalise the rhythm
the period actually used; do not rely on adjacent
historical-romance novels alone, which can amplify each
other's anachronisms without anyone noticing. The Dialogue
Register System later in this section provides per-era
calibration. Test: pick three dialogue exchanges spaced across
the manuscript and ask, in each, whether a fluent reader of
period letters would recognise the rhythm as belonging to the
chosen era — without having to consult the chapter heading.

### The Social Rules as Plot Engine

Propriety, reputation, class, and family obligation as
obstacles to love. These are not arbitrary barriers; they
represent genuine stakes within the world the book has
constructed. A ruined reputation in Regency England meant
social death — the closing of doors that could not be reopened,
the marriage offer rescinded, the season's invitations
withdrawn, the family's collective standing damaged. A cross-
class marriage in Victorian England meant family severance —
the daughter cut off from inheritance and from kin, the son
cast out of his profession's networks. A free woman of colour
choosing a white partner in 1850s New Orleans faced legal
prohibitions, social erasure, and economic consequences whose
specifics shaped what their love could and could not be. The
social consequences must feel real and devastating; the
romance's resolution must reckon with them rather than wave
them away. The technique requires that the writer plot the
social cost of each romantic decision, not as background
threat but as ongoing operating constraint. Test: at the
moment the protagonists choose each other, can the writer
specify what each of them has just given up, and is that loss
acknowledged in the prose rather than waved off as
inconsequential because the love is real?

### The Stolen Moment

Intimacy under surveillance — what is possible when eyes are
watching. The gloved hand that lingers a half-beat too long
when handing the dance card back. The waltz that permits
public closeness with a partner the rest of the season would
not tolerate. The greenhouse encounter behind the orchid table
where the hostess has not yet positioned the chaperone. The
turn around the perimeter of the ballroom that takes them past
the open window where they will not be overheard for thirty
seconds. The carriage ride home with the curtain drawn at the
moment the lamps along the road run out. Each stolen moment
must balance risk and desire — the reader should feel both the
thrill of the closeness and the precise mathematical terror of
discovery. The technique requires choreographic specificity:
where exactly is each character standing, who is watching from
where, what is the sightline through the doorway, what would
be heard if someone listened, what is the precise window of
unobservation the protagonists have noticed. Generic stolen
moments ("they found themselves alone") are the failure mode;
the moment in which the writer has tracked the household's
movements and the reader can see the timing the protagonists
calculated is the technique.

### The Historical Detail as Sensuality

Period-specific textures, scents, and sounds as romantic
atmosphere. Candlelight on silk; the creak of a carriage on
gravel; the particular weight of a corset loosened by a hand
that should not be loosening it; the smell of beeswax polish
and the cold-iron tang of old keys; the sound of horsehair
sofa cushions; the specific darkness of a country house at
night before electric light. Historical detail becomes
sensual when it engages the body rather than the intellect —
when the reader feels the material world the protagonists
inhabit rather than learning about it. The period setting
should make the romance feel more tactile, not less; the
modern reader's body is unfamiliar with these specifics and
the unfamiliarity sharpens attention. The technique fails when
historical detail is offered as period-appropriate decoration
("she wore a gown of pale blue silk; the room was lit by
candles") without engaging the body's experience of the
material; it succeeds when the silk's specific weight, the
candles' specific guttering as the door opens, and the
specific cold of a stone-floored corridor become the medium
through which the romance is felt. Test: pick three intimate
or charged scenes and identify the period-specific sensory
detail in each. If the detail could be lifted into a
contemporary romance unchanged, it has not done period work;
if it could only have occurred in this era, the technique is
operating.

### The Reader's Bargain

Historical romance has an evolving compact with its modern
readers that other historical sub-genres do not have to
negotiate so explicitly. The reader has come for romance, which
requires the protagonists to be lovable to a contemporary
sensibility — but the reader has also come for the historical
register, which requires the world to operate by its own
period rules even when those rules are now repugnant. The
genre's strongest practitioners hold this balance through
deliberate calibration: the heroine pushes against her era's
constraints without violating its plausibility (Heyer's Sophy
Stanton-Lacy navigates Regency strictures with mischief, not
with anachronistic feminist consciousness); the hero is
recognisably a man of his time on most axes but specifically
modern in his treatment of the heroine (Loretta Chase's
heroes); the world contains the period's injustices visibly and
the protagonists move through them with awareness even when
their position prevents them from undoing them (Beverly Jenkins,
Vanessa Riley, Alyssa Cole on race; multiple authors on class
and gender). The technique is not "make the period nicer than
it was" — sanitised historicals fail their period-fidelity
contract — and it is not "punish the reader with full historical
brutality" — that fails the romance contract. It is the
calibrated negotiation: which constraints are operative in the
world, which are violated by the protagonists at specific
cost, and which are surfaced in the prose as ongoing
acknowledgement that this world is not ours. Test: pick three
moments where contemporary sensibility and period
authenticity pull in opposite directions. In each, has the
manuscript chosen one register and held it, or has it
collapsed into a hybrid that satisfies neither?

### Period Psychology Check (MANDATORY. Before Every Chapter)

AI writes "wallpaper historicals". modern people in period costumes. Before writing
ANY character's internal monologue, emotional reaction, or decision, ask:

1. **What would this character's ERA teach them about this situation?**
   - A Regency woman: her value is her reputation and marriage prospects
   - A Medieval lord: honour means keeping oaths even at personal cost
   - A WWII woman: sacrifice for the greater good is expected
   - A Viking woman: strength and pragmatism are virtues

2. **What language would they use to think about their feelings?**
   - They would NOT think: "I need to set boundaries" / "this is gaslighting" /
     "I deserve better" / "that's a red flag"
   - They MIGHT think: "I must guard my heart" / "he makes me doubt my own senses" /
     "surely I am worth more than this match"

3. **What options do they believe they have?**
   - A Regency heroine knows: marry well, become a governess, depend on family charity
   - She may want MORE. but she's aware of the limits and works within or against them

### The Social Consequence Framework

For EVERY social rule in the story, maintain a consequence chain:
**Rule → Violation → Who Notices → Immediate Consequence → Escalation if Unresolved**

Example (Regency): Unmarried woman alone with a man → Found in library by Lady Harrington →
Whispers at next ball, mother's interrogation → If repeated: formal compromise, forced
engagement, or social ruin.

**The "Everyone Just Forgot" Prevention:** After EVERY social violation:
1. At least one character must reference it in the NEXT chapter
2. The reputation tracker must update
3. The consequence must persist until actively resolved
4. Resolution requires specific action (ally provides cover, rival silenced, public propriety)

### The Touch Economy

Map what's permitted and what's scandalous in the chosen era. Every touch must register.

In an era where a bare hand is intimate, touching someone's wrist should land like a
modern kiss scene. Write the physical sensation AND the social awareness:
"His fingers brushed her wrist where the glove ended, and she felt it like a brand —
and knew that Lady Marchmont had seen."

### Dialogue Register System

Each era has a baseline formality with class and education variation:

**Regency (1811-1820):** Formal, witty, indirect. "I find I am not indifferent to your
company" = "I like you." No contractions in formal speech. Contractions acceptable in
intimate/heated moments.

**Victorian (1837-1901):** More rigid than Regency. Class divide MORE audible.
Religious language more present.

**Medieval (1100-1500):** Do NOT write "ye olde" English. More direct, less ironic than
Regency. Religious oaths common. Hierarchy audible.

**Dialogue Red Flags. NEVER allow:**
- "Okay" (not used until mid-20th century)
- "Got it" / "Absolutely" / "I'm fine" / "Honestly" (modern)
- "I feel like..." (modern therapy construction)
- "That's not fair" (modern. period characters think in duty, honour, propriety)

### Historical Romance AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "She was not like other women of her time" | SHOW through action, not declaration |
| "He was a rake, but there was something in his eyes" | What does she actually see? |
| "The ballroom glittered" | Specific: candlelight on WHICH surfaces, smell of beeswax and perfume |
| "She felt a frisson of awareness" | What specifically caused it? A touch, a word, a look? |
| "The brooding duke" | He's not brooding. he's doing something specific |
| "Propriety demanded she look away" | What does SHE want? What does she actually do? |
| "In an era when women had few choices" | Don't tell the reader about the era. SHOW it. |
| "His touch burned through the fabric" | What fabric? How many layers? What does it feel like? |
| "An unconventional woman for her time" | Never use this. Show, don't label. |
| "A silence stretched between them" | Specific: what are they hearing, looking at, feeling? |
| "Their eyes met across the room" | WHOSE eyes, what expression, what does POV feel? |

### Romance Masterclass — Historical-Romance Calibration

The romance master file (romance.md) holds the canonical
romance frameworks: Heat Level Calibration, the 7-Element
Chemistry Scene Construction, the 6 Romance Character
Archetypes with character-build tests, Obstacle Layering
Quantitative, Light and Shade Heart-Monitor Rule, the
Differentiation Imperative, Hope-as-Resolution Calibration,
and Series Architecture. All apply directly to historical-
romance, calibrated below to the genre's specific period-
constrained register.

**7-Element Chemistry Scene — Historical-Romance calibration:**

- **Element 1 (Setup):** the period-specific social
  setting establishes the constraint architecture. Each
  Chemistry Scene must operate within the period's
  specific rules of class, gender, religion, marriage,
  and inheritance. The Setup must register the period
  as material constraint, not as decorative costume.
- **Element 2 (Approach):** period-appropriate proximity
  — the chaperoned drawing room, the shared carriage,
  the formal introduction, the public ball, the country-
  house weekend. The proximity-pretext is constrained by
  what the period permitted; modern unaccompanied
  proximity is often impossible and the genre's craft
  is in finding the period-permitted moments.
- **Element 3 (Banter Beat):** period-register dialogue;
  social-coded subtext. The dialogue must use period-
  appropriate vocabulary, syntax, and address forms.
  The wit operates within the period's rhetorical
  conventions (the controlled drawing-room exchange,
  the letter as carrier of subtext, the public
  conversation with private second meaning).
- **Element 4 (Awareness Spike):** rendered through
  period-appropriate restraint vocabulary — the held
  glance, the gloved hand briefly touched, the dance
  step held one beat too long, the line of poetry
  quoted. The body's response must be filtered through
  what the period permitted to be felt openly.
- **Element 5 (Pull-Back):** the load-bearing pull-back
  is carried by period-specific consequence —
  reputation jeopardy, scandal threat, family pressure,
  legal frame (marriage law, property law, divorce
  inaccessibility), Church or religious authority,
  inheritance architecture. The leads cannot act
  because the period itself holds them.
- **Element 6 (Aftermath):** period-specific
  consequence-management — the gossip risk to manage,
  the chaperone to satisfy, the letter to write, the
  next social occasion to navigate. The Aftermath
  registers the period's constant social surveillance.
- **Element 7 (Hook):** the next social occasion
  (ball, dinner, calling-day visit, country-house
  weekend) or period-specific milestone (Season's
  start, court presentation, marriage announcement,
  inheritance ceremony).

**6 Character Archetypes — Historical-Romance calibration:**

- **The Wounded Lead** is trapped by period social
  position — what was permitted to her (or him) within
  the period's gender, class, religious, racial, or
  legal constraints. The wound is often inflicted by
  the period itself (the forced first marriage, the
  withheld inheritance, the reputation lost to malice,
  the family obligation that constrains love).
- **The Opposite Lead** is either an outsider to the
  constraint (a foreign visitor, a class-crosser, a
  rake-with-genuine-conscience) OR trapped by a
  different aspect of the same constraint
  (constrained by his title, by his estate's debts,
  by his obligation to marry well, by his family
  honour).
- **The External Antagonist Force** is the period's
  social institution itself — the marriage market,
  the Church, the family, the inheritance system,
  the legal apparatus, the gossip network, the
  political faction. Where a personal antagonist
  appears, they are typically an enforcer of the
  period's institutional pressure rather than a
  free agent.
- **The Found Family** in historical-romance is often
  cousins, sisters, devoted servants, or the literary
  / political circle. Period social structures shape
  what found-family configurations were permitted.

**Obstacle Architecture — Historical-Romance dominant obstacles:**

The Obstacle Layering Quantitative rules apply. For
historical-romance, the dominant obstacle types are:

1. **Class barrier** (specific to period — nobility /
   gentry / merchant / professional / working class —
   each with specific permeability rules)
2. **Marriage law and property rights** (what changes
   on marriage; what is alienable; whose consent is
   legally required)
3. **Divorce (in)accessibility** (the period-specific
   legal mechanism, who could initiate, what was
   socially permissible)
4. **Period-specific gender constraint** (what each
   lead can / cannot do, own, study, work at, travel
   to, refuse)
5. **Reputation jeopardy** (how reputation operated in
   THIS period, what cost a woman / man their
   standing, what could and could not be recovered)

**Differentiation Imperative — Historical-Romance specific axes:**

- Specific historical period (Regency vs Victorian vs
  Edwardian vs interbellum vs post-WW2; pre-Civil-War
  vs Reconstruction vs Gilded Age; early-Tudor vs late-
  Tudor vs Stuart — each period with specific
  constraint-architecture)
- Specific geography (London vs country estate vs
  Scotland vs colonial setting vs Continental vs
  America — each with specific period configuration)
- Specific class configuration (the cross-class pairing
  must be specific within the period's permeability
  rules — not generic "they came from different
  worlds")

**Ending Calibration — Historical-Romance patterns:**

Historical-romance typically delivers HEA — period
romance demands resolution within the period's
permissions, with the marriage or commitment achieved
within the genre's expectations. HFN is possible with
explicit period-constraint acknowledgment (the
betrothal achieved, the formal marriage to follow next
season). The Hopeful ending is rare in historical-
romance proper — the genre's contract is conventional
resolution within period limits — though it appears in
literary historical-fiction-with-romance-element
projects where the genre's typical resolution may not
apply.

## Genre-Specific Revision Rules

Eight revision passes specific to historical romance, each with
a single question, run cover-to-cover before the next begins.
Historical romance has more revision passes than other romance
sub-genres because the form's failure modes are unusually
numerous: factual anachronism, voice anachronism, psychological
anachronism, social-consequence amnesia, sensory abstraction,
and the wallpaper-historical drift in which all of the above
slip below the writer's notice simultaneously. The eight
passes below are ordered to surface factual and voice failures
first (the most-detected by genre readers), psychological and
social failures next (the deeper anachronism risks), and
sensory and integration failures last (the polish work that
cannot operate until the bones are sound).

### Pass 1: Historical Accuracy Audit

Verify every historical detail in the manuscript: dates,
events, social customs, material culture, technology, fashion,
food, transportation, medicine, currency, weights and measures,
forms of address, legal frameworks, religious observance,
political context, geographic detail. Build a fact ledger
during revision: every checkable claim, with the source the
writer is relying on and a reliability assessment. Verify
characters do not know things they could not know in their
period (the heroine who recognises depression as a clinical
category; the hero who anticipates antiseptic surgery; the
viscount who plans his investments around rates the actual
markets had not yet developed). Check that meals,
transportation, medicine, and communication match the era's
specific possibilities — the morning coffee that arrived in
England decades before the heroine's date of birth and not
months; the locomotive that does not yet exist in the year of
the scene; the postal service whose actual delivery times were
faster or slower than the plot requires. Flag any detail that
feels like wallpaper rather than lived experience: lived
experience is specific (this room, this person's specific
clothing, this season's particular weather, this household's
particular routine), wallpaper is generic (a Regency ballroom,
a Victorian parlour, a country estate). Where genuine period
research is impossible to verify, flag the choice as
calculated risk — period-romance readers occasionally include
specialists who will catch what the writer missed, and the
honest acknowledgement of uncertain claims is preferable to
confident assertion.

### Pass 2: Period Voice Consistency

Read all dialogue aloud, ideally with a second reader, listening
for tonal coherence across the manuscript. Does the voice of
each character sound consistent across all their scenes? Check
that characters from different classes speak differently — the
duke and the housemaid should not sound alike, but the
distinction should be in vocabulary, sentence rhythm, and
topical concern, not in dropped consonants for the
working-class ("Oi, guv'nor") that read as caricature. Verify
that no modern idioms or phrasings have crept in (the most
common silent-anachronism categories: business / finance
metaphors that did not exist; sports vocabulary that postdates
the era; therapeutic language; "no problem", "got it", "I'm
fine", "okay" all of which are 20th-century constructions).
Ensure that formality levels shift appropriately: the duke and
the heroine speak more formally when others are present and
less formally when alone, and the gradation of their
loosening register is itself a romantic indicator. Test:
attribute-stripped dialogue test — pick three exchanges and
read them with the dialogue tags removed; can the reader
identify each speaker by voice alone? If not, the voices are
not yet differentiated.

### Pass 3: Social Rules Integrity

Map every social interaction in the manuscript against
period-appropriate behaviour. Build a social-rules ledger for
the era and the social position of the protagonists: who can
visit whom, who can be alone with whom, who can address whom
without prior introduction, who must be chaperoned and by
whom, who can write letters to whom and through what channels,
who can dance with whom and how often, what marriage
configurations are legally and socially possible. Verify that
breaches of propriety are intentional (the protagonists know
they are breaching), specific (a particular rule, with a
particular consequence chain), and consequential (the breach
ripples forward in the prose). Check that characters
understand the social rules of their world even when they
choose to break them — the heroine who genuinely does not
know that being alone with a man would compromise her marks
the writer's ignorance of the period, not the heroine's
spirited independence. Where the protagonists violate rules,
verify they pay specific costs (the failure mode the Social
Consequence Framework above is designed to prevent: the
violation that everyone forgets by chapter twenty).

### Pass 4: Anachronism Check

Scan for attitudes, objects, foods, phrases, and technologies
that did not exist in the period. The standard categories to
audit:

- **Material anachronisms** — objects, foods, drinks, fabrics,
  tools, weapons, transportation, medicines that did not yet
  exist or had not yet reached the location.
- **Linguistic anachronisms** — words, phrases, idioms,
  expressions whose first attested use postdates the scene's
  year. Check the OED first-attestation date for any phrase
  that gives the slightest pause.
- **Conceptual anachronisms** — categories of thought that did
  not exist in the period: "teenager" (1944), "homosexuality
  as identity" (late 19th century), "the unconscious" as a
  popular concept (post-Freud), "the economy" as a discrete
  domain (19th century), "race" as biology (18th-19th century
  formalisation).
- **Emotional anachronisms** — characters with modern
  therapeutic language, feminist consciousness beyond what was
  historically possible, casual attitudes toward class that
  would have been radical in their era. The most-flagged
  category in contemporary critical reviews of historical
  romance.
- **Institutional anachronisms** — schools, hospitals, banks,
  newspapers, professions in forms or positions they did not
  occupy in the era; legal frameworks (divorce, custody,
  inheritance, women's property, voting rights) that did not
  yet exist as written.

The Period Psychology Check earlier in this file is the
single most powerful tool against the deepest anachronisms;
ensure it has been run on every chapter before this pass.

### Pass 5: Romance-to-History Balance

Verify that historical detail serves the romance rather than
overwhelming it. If the reader could skip the historical
passages and still follow the love story, the history is not
integrated enough — it is sitting on top of the romance
rather than shaping it. Conversely, if the romance could take
place in any era with no change to the love-story beats, the
historical setting is mere costume — the protagonists are
modern people in period dress and the genre's contract has not
been honoured. Both failure modes are visible in revision:
historical-as-overlay shows up as paragraphs of period
exposition the writer is reluctant to cut; historical-as-
costume shows up as romantic beats that turn on contemporary
psychological assumptions. The fix in both directions is
integration: every romantic beat should be shaped by the
period (this confession occurs because the season is ending and
he must speak now or lose her to another suitor; this kiss
occurs in this specific space because no other private space
exists in their world); every period detail should be doing
romantic or character work (this household ritual reveals the
heroine's precarity; this fashion choice signals the hero's
class anxiety).

### Pass 6: Psychology Audit

Read EVERY internal monologue passage in the manuscript and
flag:

- Therapeutic language (boundaries, toxic, gaslighting, red flags, empowerment, self-care, anxiety as named diagnostic, depression as named diagnostic)
- Modern self-awareness ("I know I have trust issues because of my childhood"; "his behaviour is making me anxious"; "this is unhealthy")
- Characters understanding their emotions with modern precision (period characters experience grief, jealousy, doubt, longing, resentment in their own period vocabulary; they do not categorise their feelings the way contemporary therapy does)
- Any reference to modern psychological concepts (even unnamed: the unconscious; childhood trauma as causal explanation; attachment styles; love languages; emotional labour as a category)
- Modern feminist consciousness in characters whose era did not have access to it (the Regency heroine does not think in terms of patriarchy; she may chafe against specific constraints, identify specific injustices, and find her own way to refuse what she can refuse, but the framework she uses to think about it must be hers, not ours)
- Modern anti-class consciousness in characters whose era was thoroughly hierarchical (the duke who genuinely sees the housemaid as his social equal is not in the period; the duke who is challenged by his attraction to her, who reckons with what crossing the boundary would cost, who arrives at his decision through period-specific reasoning, is)

Where the manuscript needs to render emotion the period had no
vocabulary for, render it through the period's available
language and metaphor. The period-protagonist's grief sounds
like period grief, not contemporary grief therapy. The Period
Psychology Check above provides per-era guidance.

### Pass 7: Social Consequence Tracking

For EVERY social violation in the manuscript, run the
consequence-chain check:

- Is the violation noticed by at least one character (named, on the page, with a specific reaction)?
- Do consequences persist into subsequent chapters (rumour, social cost, family pressure, marriage-market damage, professional risk)?
- Is the violation resolved through specific action (ally provides cover; reputation laundered through countervailing event; engagement announced to forestall ruin) — not just forgotten because the writer needed the plot to move on?
- Does the consequence chain match the era's actual severity (Regency reputation damage was permanent; Victorian class-crossing was severance; antebellum miscegenation laws carried legal as well as social consequences)?

Build a violation ledger: every breach, who saw, what
followed, when resolved. The "everyone just forgot" failure
mode is the genre's most-flagged structural lapse and is the
clearest signal that the writer has used the period's social
constraints as plot scaffolding without committing to their
weight.

### Pass 8: Sensory Period Detail Check

For EACH chapter, verify:

- At least one specific, sensory, era-accurate detail that could ONLY exist in this era? (The candle's specific guttering when the door opens; the corset's specific weight loosened; the carriage's specific rocking on a particular stretch of road; the kitchen's specific morning smells; the dressing-room's specific mirror that distorts the heroine's face)
- The detail affects the scene — creates obstacle, opportunity, comedy, intimacy, or atmospheric pressure — rather than sitting decoratively on the page?
- The detail engages a non-visual sense (smell, sound, touch, taste, ambient temperature, the specific quality of period darkness)?
- The detail's specificity is verifiable: a reader who knows the period would recognise the detail as authentic, not as the writer's plausible-sounding invention?

The strongest historical romances run sensory period detail at
roughly one to two per chapter at scene level, with a more
elaborate set-piece sensory rendering at major scenes (the
ball, the country-house weekend, the carriage journey, the
estate's first arrival, the wedding). A book with full
historical voice but generic sensory atmosphere fails the
genre's tactile contract: the reader is told the period is
present but never feels it. Test: read three chapters
sampled across the book and identify each chapter's
distinctive sensory signature. If two chapters share the same
sensory grammar (candlelight, silk, beeswax, gravel — the
genre's stock atmosphere), the writer has reached for the
shelf rather than for the chapter.

## Names & Patterns to Avoid

### Forbidden Patterns
- **Modern attitudes in historical mouths**. Characters should not espouse 21st-century values without narrative awareness that these views are progressive for their time
- **Wallpaper history**. Period detail that decorates rather than shapes the story; if you could transplant the plot to a modern setting without changing anything fundamental, the history is cosmetic
- **The anachronistic feminist**. Female protagonists can be strong and unconventional, but their rebellion must be legible within their historical context
- **Clean history**. Sanitising the past of its prejudices, diseases, smells, and cruelties creates a theme park, not a historical world

### Cliché Setups to Avoid
- The rake who is reformed by the virgin's purity (without genuine character work)
- The bluestocking who is secretly beautiful when she removes her spectacles
- The Scottish Highlander who is noble savage plus abs
- The duke who attends to his own estates (historically improbable without explanation)

### Naming Considerations
- Names must be period-appropriate. check historical records for the era and region
- Avoid modern names in historical settings (no Regency Madisons or Medieval Tiffanys. though Tiffany is actually medieval, most readers will not believe it)
- Titles and forms of address must be accurate (a duke's daughter is Lady Firstname, not Lady Surname)
- Avoid the overused Regency hero names (Sebastian, Benedict, Marcus) unless deliberately playing with reader expectations

## Comp Titles

Historical-romance's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Pride and Prejudice* — Jane Austen (1813): the marriage-plot foundation; modern Regency romance's structural ancestor.
- *Persuasion* — Jane Austen (1817): second-chance historical romance template.
- *The Flame and the Flower* — Kathleen E. Woodiwiss (1972): the modern historical-romance launch; arranged-marriage / forced-proximity template.
- *Whitney, My Love* — Judith McNaught (1985): the 1980s Regency-romance benchmark.

### Contemporary (current best-in-class)

- *The Duke and I* — Julia Quinn (2000): the Bridgerton series; modern Regency-romance category benchmark; Netflix-adapted.
- *Devil in Winter* — Lisa Kleypas (2006): the Wallflowers series; emotionally complex Regency-romance.
- *Romancing Mister Bridgerton* — Julia Quinn (2002): demonstrates Regency-series architecture.
- *Bringing Down the Duke* — Evie Dunmore (2019): suffragist-era Regency romance with progressive politics.
- *A Lady's Guide to Fortune-Hunting* — Sophie Irwin (2022): contemporary-voiced Regency romance.
- *The Bridgerton Series* — Julia Quinn (2000-2013, ongoing adaptations): the genre's current commercial anchor.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. The dominant and most commercially successful style for historical romance. Painterly digital illustrations of period-costumed figures, estates, or romantic scenes. Allows for idealized period beauty without the uncanny valley of photorealistic attempts at historical settings.
- **Vintage**. Aged, antique-inspired design with period typography, distressed textures, and warm sepia or gilt tones. Signals literary quality and historical authenticity. Works beautifully for Regency, Victorian, and Georgian settings.
- **Graphic**. Stylised period silhouettes, cameo-style portraits, or decorative period motifs (fans, gloves, dance cards) with bold typography. Effective for series branding and stands out in a crowded illustrated market.
- **Typographic**. Title-dominant with period-appropriate decorative fonts, ornamental borders, and minimal imagery. Works for established authors or literary historical crossover where the design signals sophistication.

### Genre Cover Aesthetics
- **Styles:** Painterly quality with rich texture, period-authentic compositions, romantic warmth with historical grandeur, soft candlelit or golden-hour lighting, elegant poses in period costume, estate or ballroom backgrounds, landscape vistas suggesting the historical world
- **Colours:** Sepia and amber warmth, aged gold and gilt, rich burgundy and claret, parchment cream, dusty rose, sage green, midnight blue. The palette should feel warm, rich, and aged. like the pages of an old book or the light through leaded glass windows. Avoid anything that reads as modern or synthetic.
- **Elements:** Period costumes (ball gowns, riding habits, military uniforms, cravats), grand estates and manor houses, carriages, ballrooms, candlelight, gloved hands, fans, dance cards, sealed letters, horses, period gardens, hedgerow mazes, wax seals, cameos and lockets
- **Typography:** Elegant serif fonts with period character. Didot, Bodoni, Baskerville, or similar high-contrast serifs. Decorative flourishes, ornamental borders, and period-appropriate lettering. Gold foil or embossed effects are genre-standard. The typography should evoke the elegance of the era without being illegible.

### Subgenre Variations
- **Regency Romance:** Pastel palettes (soft blue, blush, sage), empire-waist gowns, Austen-era aesthetics, ballroom scenes, lighter and more playful than other periods
- **Victorian Romance:** Deeper, richer palettes (burgundy, navy, forest green), more ornate design elements, corseted silhouettes, gaslit atmospheres, industrialised settings
- **Medieval/Tudor Romance:** Bolder, more dramatic compositions, castle settings, heraldic elements, richer jewel tones, more illustrated than other periods
- **Scottish Highland Romance:** Tartan and plaid elements, rugged landscape, highland castles, warmer earth tones with purple heather accents, muscular kilted figures
- **Western Historical Romance:** Frontier landscapes, warm earth tones, sunset palettes, rustic textures, cowboy and pioneer imagery
- **War-era Romance:** Military uniforms, period-specific settings (WWII London, Civil War South), more muted and serious palettes, letters and correspondence as visual elements

### Market Positioning
Historical romance readers are visual connoisseurs who can identify the era from the cover alone. the cover must accurately signal the period. Illustrated covers dominate the market and are expected; photorealistic covers rarely work for historical because modern photography struggles to convincingly depict period settings. The cover must communicate era, tone, and heat level at thumbnail size. Series branding through consistent period palette and layout is essential. Historical romance readers are loyal to specific eras. a cover that signals Regency when the book is Victorian will frustrate readers. The cover should feel like an invitation into the past: beautiful, romantic, and atmospherically rich.

### Cover Design DON'Ts
- Modern or contemporary visual elements. nothing on the cover should break the period immersion
- Neon, electric, or synthetic colour palettes. historical romance demands warm, aged, natural tones
- Minimalist design with clean lines and white space. historical romance covers should feel rich and layered
- Photorealistic photography (almost never works). period costumes and settings look unconvincing in modern photography; illustrated is strongly preferred
- Sans-serif or modern typography. fonts must feel period-appropriate and elegant
- Anachronistic clothing or styling. readers will immediately notice wrong-era costumes, hairstyles, or accessories
- Generic castle or estate imagery without period specificity. the setting should feel like a SPECIFIC historical place, not a fantasy castle
- Overly dark or gothic aesthetics (unless gothic historical crossover). standard historical romance covers should feel warm and inviting, not brooding
