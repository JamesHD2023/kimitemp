---
name: format-docx
description: "DOCX manuscript generation template"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# DOCX Generation Template

> **As of v2.7.93 the canonical DOCX export entry point is
> `scripts/manuscript-render.sh`** — a chooser that auto-detects
> which renderer is available on the user's machine and dispatches:
>
> 1. `scripts/markdown-to-docx-render.sh` (pandoc-based; best
>    quality) when `command -v pandoc` succeeds, OR
> 2. `scripts/manuscript-render.py` (Python 3 stdlib only; zero
>    external dependencies) when pandoc is absent.
>
> The Python-stdlib renderer closes the "Claude writes an ad-hoc
> Python script each session" gap surfaced in pilots: instead of
> every export reinventing DOCX generation (and each
> implementation having its own bugs), the engine ships one
> tested Python implementation. It uses only `zipfile`, `re`,
> `html`, `os`, `sys`, `argparse`, `datetime` — no `pip install`
> required, works wherever python3 runs.
>
> Both renderers default the output path to
> `manuscript/{Title}.docx` (per v2.7.92), feed into the existing
> `docx-integrity-check.sh` post-write gate, and apply the
> canonical style spec below (Heading1 / FirstParagraph /
> BodyText / SceneBreak).
>
> **Direct invocation of `markdown-to-docx-render.sh` remains
> supported** for projects that want to force the pandoc path
> regardless of detection. **This spec is also retained** for
> projects that need to write or maintain a per-project Node.js
> DOCX generator. The patterns below remain canonical for that
> path.
>
> ⛔ **DO NOT default to the Node.js pattern below.** For any normal
> export, run `scripts/manuscript-render.sh` (above) — it needs no
> external package and self-heals NULL-byte-padded chapters. The
> Node.js generator here is a **LAST RESORT**, only for the rare
> machine with **neither pandoc nor python3**, and it must be written
> **bash-direct** (heredoc/`printf` + verify), **never with the Write
> tool** (which can NULL-pad or truncate it — the exact failure this
> path is meant to avoid). See `core-pipeline.md` § File Operation
> Policy.

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.docx`

This DOCX export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Pre-Write Typography Gate (MANDATORY — runs before every DOCX write)

Before generating any DOCX, invoke the pre-export typography gate
on the source markdown:

```bash
bash scripts/pre-export-typography-gate.sh "{project-root}" "{source-md-path}"
```

When the source path is omitted, the gate scans every
`engine-data/chapters/ch*.md` and FAILs closed if any contain
typographic artifacts (ASCII straight quotes, double-hyphen em-dash
imposters, three-dot ellipses). Fix the source markdown BEFORE
attempting the DOCX write — typographic artifacts baked into the
export are far more expensive to find after publication than to
fix at the source.

The gate honors `typography_status: skip / legacy` and
`typography_target: ascii` in `engine-data/project-config.md`.

This pre-write gate (v2.7.68) complements the post-write integrity
gate below: the pre-write catches artifacts in the SOURCE before
they're written; the post-write catches malformed DOCX after.
Together they bracket the export.

## Post-Write Integrity Check (MANDATORY — runs after every DOCX write)

After generating any DOCX file (chapter, full manuscript, screenplay,
or any other DOCX output), invoke the integrity check **before
reporting success to the user**:

```bash
bash scripts/docx-integrity-check.sh "{docx-path}" "{source-md-path}"
```

The source MD path is optional; supplying it adds a word-count
parity check against the source. For chapter DOCX exports, ALWAYS
supply the source MD — that's how the gate catches the "DOCX is a
stale snapshot from before the MD was edited" drift.

The gate verifies:
- DOCX file exists, non-zero bytes
- DOCX is a valid zip archive containing `word/document.xml`
- `word/document.xml` is parseable as XML
- `word/document.xml` contains zero `\x00` (null) bytes
- (with MD) word counts agree within ±5% or ±100 words, whichever
  is greater

If the gate exits non-zero, STOP. Do not report DOCX write success
to the user. The DOCX is malformed and Word + LibreOffice will
either refuse to open it or display truncated/wrong content. Fix
the generation pipeline (typical causes: null bytes injected by
Python string operations, stale DOCX-vs-MD drift after the MD was
re-edited), regenerate, and re-run the gate.

This gate exists to prevent the failure class documented in
`silent-failure-audit.md` row 60: a user reported chapters that
Word refused to open (null bytes in document.xml) and chapters
that opened but showed stale word counts (DOCX captured an
earlier MD state). The DOCX export pipeline reported success in
both cases — write completed, file exists on disk, no error
returned. The integrity gate makes the success claim verify
against reality.

## Routing — Novel vs. Screenplay (READ FIRST)

This file ships **two** DOCX layouts. Pick the right one before generating.

| Source content | Use this layout | Why |
|---|---|---|
| Novel manuscript (prose chapters, scene breaks `* * *`, no Fountain syntax) | **Novel DOCX** (the main body of this file) | Industry manuscript format: Times New Roman 12pt, double/1.5 spacing, first-line indent, page break per chapter |
| Screenplay (Fountain source, scene headings `INT./EXT.`, character cues, action paragraphs) | **Screenplay DOCX** (see "Screenplay DOCX Layout" section below) | Industry-standard spec script format: Courier 12pt, US Letter, screenplay margins, character-cue indentation. Output should match what Final Draft / Highland export as DOCX. |

**Detection:** if the source text contains scene headings matching
`^(INT\.|EXT\.|INT\./EXT\.|I/E\.)` followed by a slugline pattern, OR
the source filename ends in `.fountain`, route to the Screenplay DOCX
layout. Otherwise use the Novel DOCX layout below.

If a project contains both, generate two separate DOCX files — one
per format.

---

## Novel DOCX — how to produce it (READ THIS FIRST)

**Produce the DOCX by running the shipped renderer. Do NOT write a Node.js or
Python generator, do NOT use the Write tool to create one, and do NOT
`npm`/`pip install` anything:**

```bash
bash scripts/manuscript-render.sh "{project-root}"
```

It auto-selects pandoc or the bundled Python-stdlib renderer (zero external
deps), **handles project paths with spaces**, **self-heals NULL-byte-padded
chapters**, writes to `manuscript/{Title}.docx`, and runs the integrity check.
**Everything below is a STYLE REFERENCE describing the output the renderer
already produces — it is NOT a build recipe.** There is no per-project script
to write.

## Manuscript Specifications

- **Page size:** US Letter (8.5" x 11")
- **Margins:** 1 inch all sides
- **Body font:** Times New Roman, 12pt
- **Chapter headings:** Times New Roman, 16pt, bold, centered
- **Line spacing:** 1.5
- **Paragraph spacing:** 6pt after each paragraph
- **First line indent:** 0.5 inch (except first paragraph after heading)
- **Page breaks:** Between every chapter
- **Header:** Book title (even pages) / Chapter title (odd pages) — from chapter 2 onward
- **Footer:** Page number, centered

## File Size Expectations

- **Short Story (~8,000 words):** 15-25 KB
- **Novelette (~12,500 words):** 22-35 KB
- **Novella (~40,000 words):** 65-100 KB
- **Standard Novel (~75,000 words):** 110-170 KB
- **Epic Novel (~120,000 words):** 170-250 KB

## Title Page Structure

```
[3 blank lines]

[Book Title — 24pt, bold, centered]

[1 blank line]

[Subtitle — 14pt, italic, centered] (if applicable)

[2 blank lines]

[Author Name — 16pt, centered]

[Page break]
```

## Chapter Structure

```
[Page break before each chapter]

[Chapter heading — 16pt, bold, centered]
[e.g., "Chapter 1: The Discovery"]

[1 blank line]

[Chapter body — 12pt, 1.5 spacing]
[First paragraph: no indent]
[Subsequent paragraphs: 0.5" first line indent]
```

## Scene Break Formatting

Within a chapter, scene breaks are indicated by:
```
[blank line]
* * *
[blank line]
```

Centered, with three asterisks separated by spaces.

## Node.js generator — REMOVED from the normal path (last resort only)

The per-project Node.js `docx`-package generation template that used to live
here has been **removed from the standard path**. It repeatedly caused the very
failures the shipped renderer exists to prevent: `npm install` friction,
Write-tool truncation of the generated script, path-with-spaces `ENOENT`, and
smart-quote parser breakage. **Use `scripts/manuscript-render.sh`** (above) —
it is dependency-free and self-healing.

Only if a machine genuinely has **neither `pandoc` nor `python3`** — essentially
never, since the orchestrator already runs Python scripts — should a generator
be hand-written, and then it MUST be written **bash-direct** (heredoc/`printf` +
verify), **never with the Write tool** (`core-pipeline.md` § File Operation
Policy). This is a true last resort, not a normal export path.

## Content parsing

The shipped renderer parses chapter markdown itself — paragraphs, scene breaks,
dialogue, and `**bold**` / `*italic*` — so **you never parse or assemble
anything by hand**. (The parsing rules are an implementation detail of
`markdown-to-docx-render.sh` / `manuscript-render.py`.)
5. Preserve em-dashes (—), curly quotes, and special characters

## CRITICAL: Paragraph Formatting Requirements

**Regardless of how the .docx is generated** (Node.js docx package, Pandoc,
Python python-docx, or direct XML), every body paragraph MUST have these
properties applied explicitly — do NOT rely on named styles resolving correctly:

**Body paragraphs (all paragraphs after the first in each chapter/scene):**
- First line indent: 0.5 inch (720 twips / 360 EMUs / `ind firstLine="720"`)
- Spacing after: 6pt (120 twentieth-points / `spacing after="120"`)
- Line spacing: 1.5 (360 twentieth-points / `spacing line="360"`)
- Font: Times New Roman, 12pt

**First paragraph after heading or scene break:**
- NO first line indent
- Spacing after: 6pt (same as body)
- Line spacing: 1.5 (same as body)

**Chapter headings:**
- Centered, bold, 16pt
- Spacing after: 20pt (400 twentieth-points)
- Page break before (except chapter 1 which follows the title page)

**If using Pandoc:** You MUST either:
1. Provide a reference.docx with BodyText and FirstParagraph styles properly
   defined (indent + spacing), OR
2. Apply spacing and indent as direct formatting on every paragraph rather
   than relying on style names

**If using Python python-docx:** Apply `paragraph_format.first_line_indent`
and `paragraph_format.space_after` directly on each paragraph object.

**Test:** Open the generated .docx in Word or LibreOffice. If all paragraphs
are flush-left with no indent and no spacing, the formatting was not applied.
This is the most common DOCX generation failure — fix it before delivery.

---

## Screenplay DOCX Layout

Generate industry-standard screenplay DOCX from Fountain source. The
output must be indistinguishable from a Final Draft / Highland / Fade In
export — that's the bar; anything less reads as amateur.

### Page geometry (MANDATORY)

- **Page size:** US Letter (8.5" × 11") — 12240 × 15840 twips
- **Top margin:** 1.0" (1440 twips)
- **Bottom margin:** 0.5"–1.0" (720–1440 twips)
- **Left margin:** 1.5" (2160 twips)
- **Right margin:** 1.0" (1440 twips)

### Font (MANDATORY)

- **Font:** Courier or Courier Prime, 12pt (24 half-points). Monospace.
- **Single weight:** Plain. No bold sluglines (industry has moved
  away from underlined or bold sluglines).
- **Color:** Black only.

### Element layout (MANDATORY)

| Element | Indent (left) | Right indent | Alignment | Notes |
|---|---|---|---|---|
| Scene Heading | 0 (relative to page margin) | 0 | Left | UPPERCASE |
| Action | 0 | 0 | Left | Single-spaced within paragraph; blank line between paragraphs |
| Character Cue | 2.2" (3168 twips) | 0 | Left | UPPERCASE; on its own line; blank line above |
| Parenthetical | 1.6" (2304 twips) | 1.4" (2016 twips) | Left | Lowercase; in parens; immediately above the dialogue |
| Dialogue | 1.0" (1440 twips) | 1.5" (2160 twips) | Left | Single-spaced |
| Transition | 0 | 0 | Right | UPPERCASE; ends with `:` |
| Page Number | top right | — | Right | `N.` (with period); first page omitted |

The indent values above are **relative to the page text area** (which
already has the 1.5" left page margin), so a Character Cue at 2.2"
indent appears 1.5" + 2.2" = 3.7" from the page edge — matching the
PDF layout in `format-pdf.md`.

### Title Page

First section, separate from the body. No page number. Layout:

- ~3.5" of vertical space at the top
- Centered TITLE (12pt Courier, uppercase)
- Blank line
- Centered credit line (`Written by` etc.)
- Blank line
- Centered author name
- (Optional) blank line + centered Source line (italic if Source present)
- Push down with vertical space
- Bottom-left contact block (author, email, phone)
- (Optional) bottom-right `Draft date`

Title page is one section with its own properties (no page number);
body starts on the second section with page numbers from page 2.

### Special elements

- **MORE / CONT'D at page break:** when a dialogue block must split
  across a page break, append `(MORE)` at the bottom of the page and
  `CHARACTER (CONT'D)` at the top of the next page.
- **Scene numbers:** **omit** in spec scripts.
- **Dual dialogue:** render as a 2-column table at the dual dialogue
  widths above. Both columns left-aligned within their column.
- **MONTAGE / INTERCUT / INSERT / SUPER:** rendered as scene headings.

### How to produce it — run the shipped renderer (do NOT hand-write a generator)

**Produce the screenplay DOCX by running the bundled renderer:**

```bash
bash scripts/screenplay-render.sh "{project-root}"
```

It reads the project's Fountain source (from `deliverables/` or `screenplay/`),
emits the layout specified above via the dependency-free Python-stdlib renderer
`scripts/screenplay-render.py` (no `npm`/`pip` install, handles spaced paths,
strips NULL-byte padding), writes to `deliverables/{Title}.docx`, and runs
`docx-integrity-check.sh`. **Do NOT write a Node.js or per-project generator,
and do NOT use the Write tool to create one.**

The Node.js `docx`-package template that used to live here has been **removed**
for the same reasons as the novel path (npm friction, Write-tool truncation of
the generated script, path-with-spaces ENOENT, smart-quote breakage).
Hand-writing a generator is a true last resort — only if `python3` is genuinely
absent — and then it MUST be written **bash-direct** (heredoc/`printf` +
verify), never via the Write tool (`core-pipeline.md` § File Operation Policy).
Scope of the shipped renderer: **page numbers ARE produced** (top-right, `N.`
format; title page unnumbered). Not yet handled: **MORE/CONT'D** at page breaks
(a DOCX limitation — Word controls pagination, so a pre-built file cannot know
where breaks fall; use the PDF path if needed) and **dual-dialogue tables**
(only relevant to scripts with simultaneous speech).


### Critical: paragraph properties on every element

DO NOT rely on Word style names. Apply font, size, indent, and
spacing as direct formatting on every paragraph. The most common DOCX
screenplay generation failure is a file that opens in Word with
proportional font and novel formatting because the engine relied on
named styles.

### Verification (do before delivery)

- Open in Word or LibreOffice and confirm:
  - All paragraphs in monospace Courier (or Courier Prime), 12pt
  - Sluglines flush at the page text area's left edge (1.5" from page edge total)
  - Character cues at +2.2" indent (3.7" from page edge)
  - Dialogue at +1.0" indent (2.5" from page edge), with right indent so total dialogue width is 3.5"
  - Page numbers top-right with format `N.`
  - First body page is `2.`; title page has no number

### When the source is not Fountain

Route through `screenplay-importer.md` to convert DOCX/FDX/PDF to
normalised scene list, then regenerate using the layout above. Do NOT
attempt to "fix up" a malformed screenplay DOCX in place — re-derive
from the canonical scene structure.
