---
name: web-content-verification
description: "Web-Content Verification HARD GATE. WebFetch can return success metadata (200 OK + byte-count) for paywall stubs, redirect pages, login walls, empty error pages, and cached-stale content. WebSearch can return zero results on transient network failure indistinguishable from genuine 'no information found'. Without verification the engine treats placeholder/empty content as canonical source and either fabricates downstream or silently commits to SPECULATIVE classifications when retry would have succeeded. This spec defines the per-fetch content-presence + content-quality check, the per-search retry+distinguish protocol, and the HARD GATE on failure. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.7"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Web-Content Verification Protocol (MANDATORY for any flow that consumes WebFetch / WebSearch output)

## Purpose

Ensure that web-tool responses returning success metadata
correspond to actual usable content before the engine treats
them as canonical source. Two distinct failure modes:

**WebFetch failure modes:**
- **Paywall stub** — server returns HTTP 200 with content like
  "Subscribe to read this article" instead of the article body
- **Login wall** — server redirects to a login page returning
  HTTP 200 with a sign-in form
- **Redirect to home** — server redirects an outdated URL to
  homepage (HTTP 200 but no requested content)
- **Empty body** — transient network error returns 200 with
  zero or near-zero body bytes
- **Cached-stale** — CDN returns last-known cached content for
  a now-removed URL; 200 with outdated content
- **Truncated content** — request timed out mid-stream; partial
  HTML returned with HTTP 200
- **Cloudflare / bot wall** — server returns "Just a moment..."
  challenge page with HTTP 200 expecting JavaScript execution

**WebSearch failure modes:**
- **Transient zero-results** — search backend hiccups, returns
  empty result set; engine cannot distinguish from "this query
  has no real-world matches"
- **Rate-limit silent zero** — quota exceeded; backend returns
  empty rather than error
- **Region-blocked silent zero** — geographic restrictions
  return empty for some queries

If the engine treats success metadata as "content absorbed",
the cascade is identical to the Read-Verification failure mode:
fabricated downstream content, wasted user work, lost trust.

## Failure mode addressed

In production, the Verification Discipline (`verification-
discipline.md`, v2.6.8) classifies cited specifics as
VERIFIED / SPECULATIVE / REJECTED. The discipline assumes
WebSearch + WebFetch return reliable signal: a hit means
real-world support; zero hits means genuine absence. This
assumption breaks down when:

- WebFetch returns a paywall stub and the engine quotes from
  the stub as if it were the article (silent fabrication
  laundered through "I quoted what the page said")
- WebSearch transient-empty drives a SPECULATIVE
  classification when retry would have produced a VERIFIED
  one (silent over-marking of speculation)
- Cached-stale content drives a VERIFIED classification on
  outdated information (silent over-marking of verification)

The fix is the same shape as Read-Verification: verify actual
effect, not metadata. After every WebFetch / WebSearch the
engine MUST sanity-check the response before treating it as
authoritative.

## When the protocol applies

Every flow that consumes WebFetch or WebSearch output MUST
apply this protocol. Specifically:

| Flow | Spec | Web-tool use |
|------|------|--------------|
| Verification Discipline Phase A | verification-discipline.md | WebSearch for real-world anchor verification at Bible build time |
| Verification Discipline Phase B | verification-discipline.md | WebSearch for prose-time fact verification |
| Market Scout | market-scout.md (fiction) / market-scout.md (NF) | WebSearch + WebFetch for market intelligence |
| Heritage Text | heritage-text.md | WebFetch for Project Gutenberg sources |
| Analyze a Book (Option C) | analyze-a-book.md | WebSearch for publicly-available book information |
| Industry Scout | market-scout.md (run in screen mode — fiction Screen Studio) | WebSearch + WebFetch for industry buying signals |
| Reader Magnet Studio | reader-magnet-studio.md | WebFetch for comp-title research |

## The protocol — three checks

### Check 1: WebFetch content-presence + content-quality

After every WebFetch, verify the response BEFORE treating it
as canonical source:

**a. Byte-count threshold.** Response body MUST be ≥ 500
non-whitespace characters. Below this, the response is
suspect-empty regardless of HTTP status. Most legitimate
article bodies are 2,000+ chars; stubs and error pages are
usually < 200.

**b. Paywall / wall pattern detection.** Scan the response
body for known wall patterns. If matched, treat as FAILED_FETCH
regardless of byte count:

- "Subscribe to read", "Subscribe now", "Unlock this article"
- "Sign in to continue", "Log in to read", "Create a free account"
- "Just a moment...", "Checking your browser", "Please enable JavaScript"
- "Page not found", "404", "This content is not available"
- "Redirecting...", "You will be redirected"
- "Access denied", "Forbidden", "Geographic restriction"

**c. Title-only response detection.** If response is < 1,000
chars AND consists predominantly of `<title>`, `<meta>`, or
navigation chrome (links, headers) without article body
paragraphs, treat as FAILED_FETCH (likely a redirect or
truncated response).

**d. Cached-stale check.** If response includes `Last-Modified`
header or visible date markers older than the user's research
window (e.g., article dated 2018 when querying for current
market data), surface to user before treating as VERIFIED.
Cached-stale content is not necessarily wrong — but it MUST
be flagged for user awareness, not silently absorbed.

### Check 2: WebSearch zero-results distinction

A WebSearch returning zero results has two possible
interpretations the engine MUST distinguish:

**a. Genuine absence** — the query has no real-world matches
(e.g., a fabricated specifictic the engine speculatively
proposed). The Verification Discipline's SPECULATIVE
classification applies.

**b. Tool failure** — backend hiccup, rate limit, region
block, or transient outage. Retry once after a short delay;
if second attempt also returns zero, then treat as genuine
absence.

The distinction is practical: a single zero-result hit is
suspect; two zero-result hits in succession are evidence of
genuine absence.

### Check 3: HARD GATE — halt on FAILED_FETCH

After all WebFetch / WebSearch calls in scope, check
`FAILED_FETCHES`:

- **If empty (all responses passed checks 1 + 2):** proceed.
- **If non-empty (one or more failed):** the protocol BLOCKS
  the flow. The engine MUST NOT use the failed response as
  source for any classification (VERIFIED / SPECULATIVE /
  REJECTED), citation, market data, or canonical fact until
  every failed fetch has a resolution.

The user MUST be told **exactly which fetches came back
suspect** in a single clear message. Format:

```
HALT — Some web fetches returned suspect content when I tried to use them as source material.

Fetches I could NOT confirm returned real article content:
  - {URL1}  (reason: paywall stub detected — "Subscribe to read")
  - {URL2}  (reason: byte-count below threshold — 87 chars)
  - {URL3}  (reason: redirected to homepage; no article body)

Fetches I confirmed returned real content:
  - {URL4}  (1,847 chars; article body absorbed)
  - ...

I will NOT cite from the suspect fetches — using a paywall
stub or redirect page as if it were the article would silently
fabricate quotes. Three options:

  A. Confirm the URL is correct and re-fetch (some failures
     are transient).
  B. Provide alternative sources for these specifics, or paste
     the article content directly into chat.
  C. Mark the affected specifics as SPECULATIVE in the
     verification ledger and proceed without citation.

Which option for each suspect fetch?
```

## Resolution

For each failed fetch the user selects A (re-fetch), B (paste
content / alternative source), or C (mark SPECULATIVE).

- **Option A:** the engine re-runs WebFetch. If the second
  attempt also fails the same checks, return to the gate and
  ask the user to choose B or C.
- **Option B:** the user pastes article content into chat or
  provides an alternative URL. The engine absorbs from the
  pasted/alternative content (Read-Verification thresholds
  apply if pasted content is checked).
- **Option C:** the engine records the affected specifics as
  SPECULATIVE in `verification-ledger.md` with explicit
  marker language in prose, per the existing Verification
  Discipline three-class protocol.

Only when **every** entry in `FAILED_FETCHES` has a resolution
does the engine proceed past the HARD GATE.

## Logging

The engine writes a per-session web-fetch log:

```
~/Documents/Ideorix-Projects/[Title]/engine-data/web-fetch-log.md
```

Format:

```markdown
# Web-Fetch Log — {Title}

## Session {YYYY-MM-DDTHH-MM} — {Flow Name}

WebFetch calls:
- {URL1} — PASS — 2,847 chars; article body absorbed
- {URL2} — FAIL → reason: paywall stub — resolved by Option C (SPECULATIVE)
- {URL3} — FAIL → reason: byte-count below threshold — resolved by Option B (alternative URL)
- {URL4} — PASS — 4,212 chars; article body absorbed

WebSearch calls:
- "{query1}" — 12 results — VERIFIED hit selected
- "{query2}" — 0 results, retry — 0 results, treated as genuine absence — SPECULATIVE
- "{query3}" — 0 results, retry — 8 results — VERIFIED hit selected
```

The log persists across sessions so a returning user can audit
which specifics were verified vs. speculated and why.

## Integration with Verification Discipline

The Verification Discipline (`verification-discipline.md`,
v2.6.8) and this protocol form a paired safety net:

1. **Verification Discipline (preventive)** — three-class
   classification system; engine MUST classify every
   real-world cited specific into VERIFIED / SPECULATIVE /
   REJECTED. Defines what to do based on web-tool output.
2. **Web-Content Verification (this spec, detective)** —
   verifies that web-tool output is real signal vs. silent
   failure mode before the Verification Discipline classifies.

Without this spec, the Verification Discipline can over-mark
SPECULATIVE (transient-empty mistaken for genuine absence) or
under-mark by treating paywall stubs as VERIFIED sources.

## What the protocol does NOT do

- It does **not** auto-bypass paywalls. Paywalled content is
  not accessible to the engine; the protocol catches the
  attempt and surfaces it to the user.
- It does **not** validate factual correctness of fetched
  content. Once content passes presence/quality checks, the
  Verification Discipline takes over for factual
  classification.
- It does **not** apply to the engine's own URLs or training-
  data recall. Training-data recall is covered by the
  Verification Discipline's two-phase WebSearch protocol.
- It does **not** retry indefinitely. One automatic retry on
  WebSearch zero-results; one manual retry on Option A. Beyond
  that, the user must choose Option B (alternative source) or
  Option C (mark SPECULATIVE).

## Anti-patterns this protocol prevents

- **Paywall-stub citation laundering** — engine quotes from a
  paywall page as if it were the article body, fabricating a
  citation that looks legitimate.
- **Transient-empty silent over-speculation** — single
  zero-result WebSearch drives SPECULATIVE classification
  when retry would have produced VERIFIED.
- **Cached-stale silent over-verification** — outdated cached
  content drives VERIFIED classification on superseded facts
  (e.g., a now-defunct company, a now-corrected statistic).
- **Redirect blindness** — engine treats homepage HTML as if
  it were the article body the URL originally pointed to.
- **Bot-wall absorption** — engine reads "Just a moment..."
  challenge page text as article content.

## Cross-cutting binding

This protocol is the **sixth cross-cutting binding**. The
canonical catalog of all bindings and audited primitives is
`silent-failure-audit.md`. This binding addresses primitives
#8 (WebFetch) and #9 (WebSearch transient empty) in that
catalog.

Parallel bindings —
parallel to:

1. Architect Mode binding (byo-canon.md in fiction; Q13 = Research Bible Only in NF; plus Quality Guardian)
2. Verification Discipline binding (`verification-discipline.md`)
3. File-Write Hygiene binding (`core-pipeline.md` § File-Write Hygiene)
4. Edit-Tool Typographic Fidelity binding (`core-pipeline.md` § Edit-Tool Typographic Fidelity)
5. Read-Verification binding (`read-verification.md`)
6. **Web-Content Verification binding (this spec)**

Every spec listed in the "When the protocol applies" table
above invokes this binding at its WebFetch / WebSearch step.

## Enforcement model (honest)

This is an orchestrator-invoked discipline binding, not a
tool-intercepting hook. There is no PreToolUse / PostToolUse
hook on the WebFetch or WebSearch tools that fires the
paywall-stub / byte-threshold / retry checks automatically;
the flows that consume web content (fact-audit Stage 9b, deep
fact-check Stage 9c, market scout, source research) are
responsible for applying this binding at their fetch step per
this spec. The "MANDATORY" framing means *the discipline is
non-negotiable for those flows* — not that a hook enforces it
structurally. The downstream HARD GATE (a fetch that fails
this binding cannot be promoted to VERIFIED) is what catches a
paywall stub or empty result when this binding fires.
