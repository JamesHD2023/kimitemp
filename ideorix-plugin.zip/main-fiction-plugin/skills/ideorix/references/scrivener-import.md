---
name: scrivener-import
description: "Import a Scrivener project — preserves manuscript prose, binder structure, characters, places, and notes"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the user-facing skill. The technical implementation protocol lives in `scrivener-importer.md` (same folder) — loaded by reference once the user triggers an import.


> **Powered by Ideorix** — The Manuscript & Screen Engine


# Scrivener Import

Bring your Scrivener project into Ideorix. The importer parses the
binder, extracts every chapter's prose, maps your Characters and Places
folders into the Story Bible, and lands you in a working Ideorix project
ready for the full editorial pipeline (Continue Writing, Edit & Revise,
Manuscript Clinic, etc.).

Handles two cases automatically:
- **Full-prose Scrivener projects** — your written chapters become
  Ideorix chapter files; you can run them straight through Edit & Revise
- **Outline-only Scrivener projects** — synopses become brief content
  ready for chapter generation; you proceed to Story Bible review

## What it does

| Task | What happens |
|------|-------------|
| **Binder parsing** | Reads `.scrivx` XML to map your full project structure |
| **Manuscript extraction** | Each chapter Text item's body RTF → Ideorix chapter file (RTF converted to clean markdown) |
| **Synopsis preservation** | Your one-line synopses become Section 12 chapter outline entries |
| **Character import** | Each item in your Characters folder → Section 2 character bio |
| **Place import** | Each item in your Places folder → Section 5 location entry |
| **Notes import** | Items in Notes/Research folders → "Author notes" appended to relevant Story Bible sections |
| **Folder hierarchy preservation** | Top-level folders (Parts, Days, Acts) preserved as chapter groupings or Section 11 (Timeline) |
| **Reduced setup** | Skips outline source (already provided); asks only for what Scrivener doesn't record (genre, dialect, voice, pen name) |
| **Smart hand-off** | Full-prose projects → Continue Writing or Edit & Revise. Outline-only projects → Story Bible review then chapter generation. |

## How to start

Say any of:
- "Import from Scrivener"
- "Import my Scrivener project"
- "Bring my Scrivener work across"
- "Scrivener import"
- "I have a Scrivener project"

Or pick **Import Project** from the Writers Studio or Full Creative Suite
menu, then choose **Scrivener** as the source.

## How to prepare your Scrivener project

The simplest path:

1. **Close your project in Scrivener** (so the bundle is in a clean state)
2. Find your `.scriv` folder in Finder/Explorer
3. Right-click → **Compress** (Mac) or **Send to → Compressed folder** (Windows)
4. Save the resulting `.zip` to `~/Documents/Ideorix-Projects/imports/`

That's it. The importer accepts:
- A `.zip` of the `.scriv` directory (recommended for cloud transfer)
- The `.scriv` directory itself (if you're already working locally)

You don't need to "Compile" or "Export" anything from Scrivener — the
importer reads the project bundle directly.

## What gets imported

From a Scrivener project, the importer brings across:

- **Manuscript prose** — every chapter from the Manuscript/Draft folder, with paragraphs, italics, em dashes, and inline formatting preserved
- **Synopses** — your one-line chapter/scene summaries
- **Characters** — bios, descriptions, and any custom fields
- **Places** — location entries
- **Notes / Research folder content** — preserved as Story Bible author notes
- **Binder hierarchy** — Parts, Days, Acts, or whatever grouping you used
- **Project title** — from the `.scrivx` ProjectProperties

## What is NOT imported

- **Trash folder content** — silently ignored, never imported
- **Snapshots** — Scrivener's revision history isn't carried across (Ideorix has its own snapshot system)
- **Comments and footnotes inside RTF** — stripped during conversion (v2 will preserve as inline notes)
- **Project settings** (label colours, status flags, custom metadata fields beyond name/description) — v1 ignores these
- **Compile presets** — Ideorix has its own export pipeline (Phase 6)
- **Scrivener research files** (PDFs, web archives, images) — these stay in your local Scrivener project; only text-based notes are imported

## What Ideorix will ask you after import

Scrivener doesn't record the things Ideorix needs for its agent pipeline.
After the import completes, you'll be asked for:

1. **Genre** — controls which genre plugin loads
2. **Dialect** — US or GB English
3. **POV** — inferred from the first chapter, confirmed by you
4. **Length tier** — inferred from word count, confirmed by you
5. **Voice** — attach an existing voice profile, build one now, or skip
6. **Pen name** — attach existing, create new, or skip
7. **Romance subplot? Heat level? Tropes?** — standard Phase 1 questions

Skipped (Scrivener already provides the answer):
- Outline source — your binder is the outline
- Project mode — inferred from whether the import is full-prose or outline-only

## What you get back

A fully populated Ideorix project workspace:

```
~/Documents/Ideorix-Projects/{Your Title}/
├── project-config.md              Project metadata + setup answers
├── manuscript/
│   └── chapters/
│       ├── chapter-01.docx        (full-prose mode only)
│       ├── chapter-02.docx
│       └── ...
├── engine-data/
│   ├── story-bible.md             Built from binder hierarchy
│   ├── entities/
│   │   ├── characters.md          Character bios from Characters folder
│   │   └── places.md              Locations from Places folder
│   ├── chapters/                  Raw markdown copies
│   ├── summaries/                 Auto-generated for full-prose mode
│   └── imports/
│       └── scrivener-bundle/      Original .scriv (kept for reference)
└── marketing/
```

From there:
- **Full-prose mode** → choose Continue Writing, Edit & Revise, Manuscript Clinic, or Export & Publish
- **Outline-only mode** → review the Story Bible, then proceed to chapter generation with the Outline Conformance Agent enforcing your binder structure

## Why this matters

Scrivener has been the industry standard for ~20 years. Many novelists
have decades of work locked inside `.scriv` bundles. This importer is
the bridge — bring your existing manuscripts into Ideorix's editorial
pipeline without reformatting, retyping, or losing your binder structure.

> Protocol: `scrivener-importer.md`
