---
name: novelcrafter-importer
description: Import a Novelcrafter project (manuscript + codex) into Ideorix — preserves characters, locations, objects, subplots, and chapter structure
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Novelcrafter Importer

## Purpose

Convert a Novelcrafter export (full project zip) into a working Ideorix project.
Preserves the manuscript, characters, locations, objects, subplots, and world
building, maps them into Ideorix's Story Bible format, then hands off to the
user's chosen next step (Continue Writing, Writers Studio, or Edit & Revise).

This is a **one-way import**. It does not keep the Novelcrafter export in sync
— once imported, the Ideorix copy becomes the authoritative working project.

## When to Use

Trigger phrases:
- "Import from Novelcrafter"
- "Import my Novelcrafter project"
- "Bring my Novelcrafter work across"
- "Novelcrafter import"
- "I have a Novelcrafter project" / "I'm moving from Novelcrafter"

## Prerequisites

The user must provide a **full Novelcrafter export zip**, produced by:
1. In Novelcrafter, open the project to import
2. Use Export → choose **Markdown** format
3. Tick **"Include codex"** (critical — this is what we need for the Story Bible)
4. Tick all other defaults (chapters, scenes, summaries)
5. Export → save the resulting zip

If the user exported a partial set (manuscript only, no codex), the importer
can still run but the Story Bible will be empty — warn the user and offer to
proceed or wait for a full export.

---

## Input Format Reference

A Novelcrafter full export zip contains the following structure. This spec is
based on confirmed export analysis (Novelcrafter v1 export format, 2026).

```
{project-slug}.zip
├── novel.md                           ← full manuscript (markdown)
├── codex.html                         ← human-readable HTML view (IGNORE)
├── characters/                        ← one directory per character
│   └── {slug}-{uuid}/
│       ├── entry.md                   ← YAML frontmatter + description body
│       └── metadata.json              ← redundant — ignore
├── locations/                         ← one directory per location (same layout)
├── objects/                           ← one directory per object (same layout)
├── other/                             ← mixed: world-building + workflow clutter
├── subplots/                          ← one directory per subplot (same layout)
├── snippets/                          ← flat .md files — scratch notes (IGNORE)
└── chats/                             ← flat .md files — AI chat logs (IGNORE)
```

### Codex Entry Format (all types)

Every codex entry (characters, locations, objects, other, subplots) uses an
identical file format:

```markdown
---
type: character                # character | location | object | other | subplot
name: Lucas Carsten Roth
color: null
aliases:
  - Lucas
  - Luke
  - Cars
tags:
  - Ensemble
  - Taipei Rain
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
fields: {}                     # structured key/values — usually empty
---
{free-form markdown description body — the authoritative content}
```

**Parsing rules:**
- Read the YAML frontmatter for: `type`, `name`, `aliases`, `tags`, `fields`
- The description body (everything after the closing `---`) is the canonical content
- If `fields` is non-empty, prepend each key/value pair to the description as
  `**{Key}:** {value}\n`
- `color`, `alwaysIncludeInContext`, `doNotTrack`, `noAutoInclude` — ignore
- `metadata.json` in the same directory is redundant — do NOT read it

### Manuscript Format (novel.md)

```markdown
# {Book Title}
by {Author Name}

## {Act Name}

### {Chapter Name}

{one-paragraph scene summary}

---

{chapter prose — may contain * * * as in-chapter scene breaks}

### {Next Chapter Name}
...
```

**Parsing rules:**
- `#` (H1) → book title. The line immediately after is usually `by {Author}` — extract the author name
- `##` (H2) → Act name. Ideorix does not use acts as structure; preserve act names as chapter metadata only
- `###` (H3) → Chapter name
- The first non-empty paragraph after a `### Chapter` heading is the **chapter summary**
- A standalone `---` line after the summary separates the summary from the prose — strip it
- `* * *` within the prose is an in-chapter scene break — preserve it in the chapter file
- Any other `---` inside prose should be preserved (it may be the author's intentional separator)

---

## Processing Pipeline

### Step 1: Locate the Export

Ask the user where the Novelcrafter zip is located. Three options:

```
Where is your Novelcrafter export?

1. I've put it in ~/Documents/Ideorix-Projects/imports/ (recommended)
2. I'll give you a full file path
3. I've already unpacked it — point me to the folder
```

If option 1: look for the most recent `.zip` file in `~/Documents/Ideorix-Projects/imports/`.
If option 2: ask for the absolute path and verify the file exists.
If option 3: ask for the folder path and verify `novel.md` exists at the root.

### Step 2: Unpack and Validate

If given a zip, unpack it to a temporary working directory under
`~/Documents/Ideorix-Projects/imports/unpacked-{timestamp}/`.

Validate the export by checking for:
- `novel.md` at the root (required — this is the manuscript)
- At least ONE of: `characters/`, `locations/`, `objects/`, `subplots/`, `other/` (if none exist, this isn't a Novelcrafter export)

**If validation fails:**
- `novel.md` missing → tell the user the export looks incomplete and ask them to re-export with all defaults enabled
- No codex folders → warn that the Story Bible will be empty but offer to proceed with manuscript-only import

### Step 3: Preview and Confirm

Walk the unpacked folder and produce a summary for the user:

```
Novelcrafter Export Found — {project-name}

Manuscript:
  • {N} chapters ({M} total words)
  • {K} acts: {Act I, Act II, ...}
  • Author: {author-name-from-novel.md}

Codex:
  • {N} characters
  • {N} locations
  • {N} objects
  • {N} subplots
  • {N} "other" entries (will be triaged — see below)

Workflow artifacts (will be dropped):
  • {N} snippets
  • {N} chat logs
  • codex.html (render artifact)

Proceed with import? [y/n]
```

Word count for the manuscript = count words in the full `novel.md` minus the
heading lines. Chapter count = number of `###` headings.

If the user declines, stop. If yes, continue.

### Step 4: Parse the Manuscript

**Read-Verification HARD GATE applies (see `read-verification.md`).**
Before parsing, verify the Read of `novel.md` returned content above
the `.md` threshold (≥ 20 chars). If the read returned empty or
near-empty content, the importer BLOCKS and surfaces the failed read
to the user with the three resolution options (paste / skip / re-upload)
before any parse logic runs. Treating an empty Read as "manuscript
absorbed" would silently produce zero chapters and a project the user
would have to debug from scratch.

Read `novel.md` and split it into chapters using the `###` heading delimiter.

For each chapter:
1. Extract the chapter heading (the text after `### `)
2. Determine which act it belongs to (last `##` heading seen before this `###`)
3. Extract the first non-empty paragraph after the heading as `chapter_summary`
4. If the next non-empty line after the summary is `---`, strip that `---`
5. Everything remaining until the next `###` is the chapter prose
6. Preserve `* * *` scene breaks exactly as written

Output: one markdown file per chapter, written to the project workspace
(see Step 7 for location).

**Naming convention:** `chapter-{NN}.md` where NN is the zero-padded index
(chapter-01.md, chapter-02.md, etc.). If the original heading was "Chapter
Fifteen" or "15: The Reckoning", preserve that as the file's top-level `#`
heading inside the file, but use numeric indexing for the filename.

Chapter file format:
```markdown
# {Chapter Name}

<!-- chapter-meta
act: {Act Name}
imported_from: novelcrafter
chapter_index: {N}
-->

## Summary

{chapter summary paragraph}

## Prose

{chapter prose with * * * scene breaks preserved}
```

### Step 5: Parse the Codex (Characters, Locations, Objects, Subplots)

For each of the folders `characters/`, `locations/`, `objects/`, `subplots/`:

1. List all subdirectories (each represents one entry)
2. For each subdirectory, read `entry.md`
3. Parse the YAML frontmatter to extract: `name`, `aliases`, `tags`, `fields`
4. Read the description body (everything after the closing `---`)
5. If `fields` contains any key/value pairs, prepend them to the description as
   a structured block:
   ```
   **{Key}:** {value}
   **{Key}:** {value}

   {original description body}
   ```
6. Build a normalised entity object:
   ```yaml
   type: character | location | object | subplot
   name: {name}
   aliases: [{alias1}, {alias2}, ...]
   tags: [{tag1}, {tag2}, ...]
   description: {processed description body}
   source: novelcrafter
   source_id: {uuid-from-folder-name}
   ```

**IGNORE** the `metadata.json` file in each entry directory — it is redundant.

### Step 6: Triage the "other" Folder

Novelcrafter's `other/` folder is a catch-all that mixes legitimate
world-building with workflow artifacts (chapter drafts, AI style guides,
scene outlines, etc.). Run each entry through the following triage.

**Auto-DROP** (filename contains any of these patterns, case-insensitive):
- `outline` / `chapter-outline` / `scene-outline` / `scene-level`
- `draft` / `drafts` / `redraft`
- `c-NN` pattern (chapter number markers like `c-15-draft`, `c-22-c-24`)
- `reimagined` / `rebuild` / `new-scene`
- `style-guide` / `style-` / `gemini` / `sonnet` / `gpt-` / `-ai-`
- `exploring` / `testing` / `learning`
- `marketing-materials`
- `prev-think` / `prompt`

**Auto-KEEP** (include in Story Bible automatically):
- `synopsis` / `synopses` / `logline` / `pitch`
- `personnel` / `cast` / `characters-i` / `characters-list`
- `world` / `worldbuilding` / `lore`
- `timeline` / `chronology`
- `religion` / `magic-system` / `technology`
- `geography` / `maps`

**Ask the user** about everything else. Present unmatched entries as a
checklist:

```
Found {N} "other" entries that need your input. For each:
keep (add to Story Bible), skip (drop), or view (see the content first):

1. {entry-name} — {first 80 chars of description}
   [k] keep  [s] skip  [v] view

2. ...
```

Keep entries go into the Story Bible as **World Building** entries (Section 3:
Worldbuilding Categories in `world-canon.md`). Skip entries are silently
dropped.

### Step 7: Build the Project Workspace and Story Bible

Create the Ideorix project workspace at:
```
~/Documents/Ideorix-Projects/{project-title-slug}/
```

Where `{project-title-slug}` is derived from the H1 title in `novel.md`
(lowercased, spaces → hyphens, non-alphanumeric stripped).

**Workspace structure:**
```
~/Documents/Ideorix-Projects/{title-slug}/
├── project-config.md              ← metadata (title, author, source, date)
├── manuscript/
│   └── imported/
│       ├── chapter-01.md
│       ├── chapter-02.md
│       └── ...
├── engine-data/
│   ├── story-bible.md             ← populated from codex
│   ├── entities/
│   │   ├── characters.md
│   │   ├── locations.md
│   │   ├── objects.md
│   │   ├── subplots.md
│   │   └── world-building.md
│   ├── reports/                   ← empty — filled by future editorial passes
│   ├── summaries/
│   │   └── chapter-summaries.md   ← all chapter summaries in one file
│   └── revisions/                 ← empty
├── marketing/                     ← empty
└── imports/
    └── novelcrafter-export/       ← copy of the original unpacked export (for reference)
```

**Story Bible population rules:**

Build `engine-data/story-bible.md` by mapping:
- **Novelcrafter characters** → Section 2: Characters (in `world-canon.md` format)
  - Each character: Name (with aliases), one-line role inference from tags, full description
- **Novelcrafter locations** → Section 1: Settings & Locations
- **Novelcrafter objects** → Section 3: Objects & Artifacts
- **Novelcrafter subplots** → Section 7: Subplot Threads (new section if not present)
- **Triaged "other" entries (kept)** → Section 2: High-Level World / Section 10: History & Lore
  (based on best match with the entry content — use the entry name as a hint)

**Critical: preserve aliases.** In the characters file, every character MUST
have its alias list preserved as an explicit field:

```markdown
### {Character Name}
**Aliases:** {alias1}, {alias2}, {alias3}
**Tags:** {tag1}, {tag2}
**Source:** Novelcrafter import ({original-folder-name})

{description}
```

The Continuity Guardian and Prose Humaniser rely on the alias list for mention
tracking and name consistency. Losing aliases breaks both.

**`project-config.md` contents:**
```markdown
# Project: {Title}

- **Author:** {author from novel.md}
- **Created:** {today's date}
- **Source:** Novelcrafter import
- **Original export:** imports/novelcrafter-export/
- **Status:** Imported — awaiting setup

## Architect Mode

- **architect_mode:** true
- **architect_mode_set_at:** {ISO 8601 timestamp}
- **architect_mode_source:** novelcrafter-import
- **import_source:** novelcrafter

## Imported Content

- {N} chapters ({M} words)
- {N} characters, {N} locations, {N} objects, {N} subplots
- {N} world-building entries (from triaged "other")

## Next Steps

Complete setup (genre, length tier, voice) before running any agent pipeline.
See next-action prompt after import completes.
```

### Step 8: Reduced Phase 1 Setup

Novelcrafter does not track genre, length tier, pen name, voice profile,
tropes, or beat structure. Ideorix needs those to run its agents. Prompt the
user for the minimum required setup, skipping questions that only apply to
fresh projects.

**Ask (in order):**

1. **Q1 Genre** (required) — full genre list from `_index.md`. Explain: "Novelcrafter doesn't record genre, so I need to ask. This controls which craft rules and genre plugin loads."
2. **Q2 Dialect** (required) — US or GB English
3. **Q3 POV** (infer from text if possible — scan chapter 1's first 500 words for first-person vs third-person markers; confirm with user)
4. **Q5 Heat level** (if genre is romance-adjacent)
5. **Q6 Length tier** — infer from word count and confirm:
   - < 10K words → Short Story
   - 10K-17K → Novelette
   - 17K-50K → Novella
   - 50K-90K → Standard Novel
   - 90K+ → Epic Novel
   Note: this is a published-tier inference; confirm with the user, especially
   if the manuscript is still in progress (they may be targeting a longer tier).
6. **Q8 Style Guide / Voice** — ask if they have a saved voice profile to attach; if not, offer to build one now via Voice Builder (optional — can be done later)
7. **Q12 Pen Name** — ask if they want to attach an existing pen name or create one

**Skip:**
- Q4 (tropes) — can be inferred later from genre + content
- Q7 (series position) — ask only if explicitly mentioned in the import
- Q9 (outline source) — already have the outline (the imported chapters ARE the outline)
- Q10 (Chekhov's guns), Q11 (transportive setting), Q13, Q14 — can all be derived from existing content or asked later

Write answers into `project-config.md`.

### Step 8b: Post-Import Lockfile Generation (MANDATORY)

After the Story Bible is assembled and setup is complete, generate the
MODERN MODE infrastructure files. Without these, the project will hit
the Graceful Degradation decision tree and look like a legacy project.

1. **Entity Canon Lockfile (Phase 2D)** — Generate `entity-canon.md`
   from the imported Story Bible's character, location, and object
   entries. Use the same protocol as `world-canon.md` Phase 2D. Write
   to `engine-data/entity-canon.md`. Verify with Bash ls.

2. **Pipeline Checkpoint (Phase 2E)** — Generate
   `pipeline-checkpoint.md` with the v2 schema. Populate the Chapter
   Progress table with rows for already-imported chapters (mark as
   `Written: Yes` since prose exists on disk). Write to
   `engine-data/pipeline-checkpoint.md`. Verify with Bash ls.

3. **Running Banlist (Phase 2E)** — Generate the empty
   `running-banlist.md` starter file. Write to
   `engine-data/running-banlist.md`. Verify with Bash ls.

4. **Forbidden root-file scan** — Bash ls `engine-data/` and confirm
   no forbidden files are present (see `core-pipeline.md` File
   Location Discipline).

5. **Architect Mode flag (MANDATORY — v2.7.1+).** Imported
   material is user-supplied canon by definition; the import
   flow MUST set Architect mode so downstream agents
   (Architect, Writer, Quality Guardian) treat the imported
   content as authoritative rather than as raw material to
   reinterpret. Write the following to
   `engine-data/project-config.md` (under the Architect Mode
   section established in Step 7):

   ```markdown
   architect_mode: true
   architect_mode_set_at: {ISO 8601 timestamp}
   architect_mode_source: novelcrafter-import
   import_source: novelcrafter
   ```

   Verify the write with Bash ls, then read back to confirm
   the flag is set. Every downstream agent reads
   `architect_mode` from this file:

   - Outline Builder Step 0 trigger detection (recognises
     imported projects as user-canon-present)
   - Architect agent (`blueprint-protocol.md`) — locked
     content immutable; no character flattening; no
     psychology projection; conflicts surface to user
   - Writer agent (`prose-protocol.md`) — voice authoritative;
     character voice immutable; samples calibrate not
     anchor
   - Quality Guardian (`quality-gate.md`) — flags canon
     drift (character flattening, voice drift, world-rule
     violation, psychology projection)

6. **Source-canon mirror (MANDATORY — v2.7.1+).** Copy the
   imported user material into `source-canon/` so the Step 0
   filesystem trigger fires uniformly across BYO-canon and
   import paths. The mirror is read-only canon — the engine
   reads from it but never writes back.

   ```
   source-canon/
   ├── novelcrafter-import/      ← original parsed export
   │   ├── characters/           ← Novelcrafter character codex
   │   ├── locations/
   │   ├── objects/
   │   ├── subplots/
   │   └── manuscript/           ← original chapter prose
   └── README.md                 ← "imported from Novelcrafter on {date}"
   ```

   The engine-data/ files (story-bible.md, entity-canon.md,
   etc.) are the WORKING copy; source-canon/ preserves the
   original imported state for reference.

**The imported Story Bible is the user's canon.** Downstream agents
(Architect, Writer, Humaniser, Verification) execute it — they do not
rewrite, simplify, or "improve" the user's characters, world, or
voice. The Architect mode flag set in Step 5 above MAKES THIS
STRUCTURALLY ENFORCED rather than convention-only. See
`outline-builder.md` Anti-Rewriting Rule and
`blueprint-protocol.md` Architect Mode Binding.

### Step 9: Hand Off

Present the next-action menu:

```
Novelcrafter import complete. Your project is set up at:
  ~/Documents/Ideorix-Projects/{title-slug}/

What would you like to do next?

1. Continue Writing — Resume from chapter {N+1} using Ideorix's AI pipeline
   (Architect → Writer → Verification)
2. Writers Studio — Run the full editorial pipeline on your imported manuscript
   (Proofreader → Copy Editor → Dev Editor → Alpha/Beta Reader → Humaniser)
3. Edit & Revise — Targeted fixes on specific chapters
4. Manuscript Clinic — Get a scored analysis + expert consultation
5. Return to main menu — I'll pick up later
```

Route based on user's choice to the appropriate existing agent.

---

## Anti-Patterns

- Do NOT attempt to parse the `codex.html` file — it is a render artifact, not a source
- Do NOT read `metadata.json` files — they duplicate what's already in `entry.md`
- Do NOT treat `---` inside chapter prose as a chapter break — only `###` headings mark chapters
- Do NOT discard the alias list on any character — it is critical for continuity tracking
- Do NOT auto-keep everything in `other/` — many entries are workflow clutter (drafts, AI style guides)
- Do NOT assume every Novelcrafter entry maps 1:1 to a Story Bible entry — the triage is essential
- Do NOT overwrite an existing Ideorix project if the slug collides — append a timestamp to the new folder name instead
- Do NOT prompt the user for fresh-project setup questions that don't apply (Q9 Outline Source, Q10 Chekhov's Guns, etc.) — only ask what's required to run the pipeline
- Do NOT run any agent pipeline automatically after import — always hand off to the user's explicit choice

---

## Error Handling

| Situation | Action |
|-----------|--------|
| Zip not found | Ask the user for the correct path |
| Zip not a Novelcrafter export (no `novel.md`, no codex folders) | Tell the user this doesn't look like a Novelcrafter export and list what was found |
| `novel.md` present but empty | Warn; offer codex-only import (Story Bible but no manuscript) |
| Codex folders empty | Warn; offer manuscript-only import (user will need to build Story Bible separately) |
| Malformed YAML frontmatter in an entry | Skip that entry, log to a `import-errors.md` file in the workspace, continue processing |
| Duplicate character names (different UUIDs) | Ask the user to merge or keep both — don't silently overwrite |
| Project slug collision with existing Ideorix project | Append `-imported-{date}` to the new project folder |
| Disk write failure | Abort the import cleanly; leave the user's disk in the same state as before |

---

## Future Expansion

This importer is designed as the first of several external-source importers.
Future imports (Scrivener, Plottr, Campfire, World Anvil, etc.) should follow
the same pattern:

1. A source-specific parser (like this file) that normalises entities into the
   standard Ideorix shape
2. A shared "build workspace from entity list" step
3. A shared "reduced Phase 1 setup" step
4. A shared hand-off menu

When adding a new source, create a new `{source}-importer.md` file and update
`import-project.md` to add a new entry in the "Choose your source" selection.
