---
name: director-protocol
description: "Engine-neutral orchestrator agent. Reads pipeline-checkpoint.md (prose mode) or project-config.md + on-disk Quality-Gate / Pre-Delivery Sweep artifacts (screen mode), reconciles via producer-state-protocol HARD GATE, scans recent run.log activity, and produces an evidence-bearing Director Briefing recommending the next step. Surfaces alternative paths, prerequisite checks. Read-only on project state — never writes manuscript files. v2.7.98 adds the screen-mode branch so Screen Studio projects route to a real recommendation rather than hard-halting on the absent prose pipeline-checkpoint."
version: "2.7.98"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Director Agent

The Director answers two questions a user repeatedly asks across long
projects:

1. **"Where am I in this project?"** — what phase has the engine
   reached, what audits have passed, what's the last thing the
   pipeline did.
2. **"What should I do next?"** — given current state, what is the
   next logical pipeline step, with explicit grounding in
   filesystem evidence and explicit prerequisite checks.

Director is **read-only** on project state. It never writes
manuscript files, audit reports, or pipeline-checkpoint.md fields.
It produces a Director Briefing — a structured recommendation the
user accepts (and triggers the recommended flow) or overrides.

## Why this exists

Long manuscript projects accumulate state across many sessions. A
user returning to a project after two weeks has lost the in-head
model of "we just finished Phase 2D, the bible coverage audit
passed, we were about to start Stage 9b". Without an orchestrator,
the user must:

- Read the pipeline-checkpoint.md by hand
- Cross-check audit-report files against the audits-passed list
- Remember which phases are gated on which audits
- Decide what comes next

The first three are exactly what `producer-state-protocol.md`
reconciles structurally. The fourth is what the Director adds —
applying the engine's phase-graph knowledge to current state and
producing a grounded recommendation.

The Director is also the right place to surface DIVERGENCE caught
by the state-reconciliation HARD GATE — when the audits-list
disagrees with filesystem reality, the user sees the divergence as
part of the briefing, not as a separate alarm.

## Invocation contract

The Director Agent is invoked by user trigger phrases (registered in
SKILL.md):

- "Where am I in this project?"
- "What should I do next?"
- "Director — orient me"
- "Recommend next step"

Or programmatically by Catalog Overview when the user asks for a
per-project status report.

The Director runs **once per invocation**. It does not loop, does
not re-prompt, does not chain into the recommended flow. It produces
a briefing; the user reads it and acts (or asks a follow-up).

## The orchestration protocol

### Step 1: Identify the project

Determine the project root from the calling context. If multiple
projects are open or the project is ambiguous, invoke
`ask-user-disambiguation.md` discipline — single-decision-per-ask
with confirmation echo on ambiguous responses.

Detect the engine mode by reading `project-config.md`'s `Mode:`
field (under `read-verification.md` HARD GATE — empty extraction
on Read failure is treated as project-not-initialised and the
Director stops with the project-init recommendation rather than
fabricating a mode).

**Prose mode** (`Mode: Writers Studio` / `Mode: Full Creative
Suite` / NF):

- Verify `engine-data/pipeline-checkpoint.md` exists. If not,
  the project has not yet completed Phase 2E — recommend the
  user run the project-init flow and stop.

**Screen mode** (`Mode: Screen Studio` — the screenplay project
tree creates `screenplay/`, `coverage/`, `deliverables/`, and
`engine-data/{reports,scenes,beats,revisions}/` but does NOT
create `pipeline-checkpoint.md`):

- Verify `project-config.md` exists and has a populated `Status:`
  field. If not, recommend running Screen Studio Start New
  Project and stop.
- Treat the screenplay Quality-Gate state (see Step 4 Screen-
  mode phase-graph) as the analogue of pipeline-checkpoint:
  the Director reads `engine-data/reports/quality-gate-*.md`
  (if present) and the most recent revision under
  `engine-data/revisions/` to determine current state. Missing
  reports mean "no audits yet" — that is valid state for a
  brand-new screenplay project and the Director's
  recommendation is to begin Step 1 of the screenplay generation
  protocol (fiction-engine spec, references/screenplay-protocol).

### Step 2: Reconcile project-level state

Invoke `producer-state-protocol.md` HARD GATE. Apply the protocol
in full:

- Read pipeline-checkpoint.md (under `read-verification.md` HARD
  GATE)
- Bash-list filesystem audit-report evidence (under
  `bash-output-verification.md` HARD GATE)
- Compute the LIST-MISSING / CLAIM-FABRICATED / CONSISTENT delta
- Auto-repair LIST-MISSING rows
- Halt on CLAIM-FABRICATED — surface DIVERGENCE to the user as
  the briefing's first section; do not produce a recommendation
  until the user resolves

If reconciliation halts on DIVERGENCE, the Director's output is
exactly the divergence message from the protocol. No
recommendation is produced. The user resolves and re-invokes.

### Step 3: Read recent activity

Read the last 50 lines of `engine-data/run.log` via bash. This
gives the Director the recent-activity context (last write, last
audit, last verification step). Apply
`bash-output-verification.md` HARD GATE.

### Step 4: Compute the recommendation

Apply the engine's phase-graph knowledge to current state.
**Prose mode** (Writers Studio / Full Creative Suite / NF):

- **Current phase** (from `## Pipeline Status` / `Phase:` field)
  determines the set of valid next steps
- **Audits passed** (from reconciled `## Audits Passed` ledger)
  determines which audit-gated next steps are unblocked
- **Chapter-table state** (last column populated, last chapter row)
  determines per-chapter loop position
- **Recent run.log entries** disambiguate "we just finished X" from
  "X happened a week ago and the user has paused"

**Screen mode** (Screen Studio): the phase-graph is the
screenplay pipeline rather than the prose stage table.

- **Current status** (from `project-config.md` `Status:` field
  — `Awaiting screenplay` / `Setup complete` / `Drafting` /
  `Quality Gate` / `Pre-Delivery Sweep` / `Delivered`)
  determines the next valid step.
- **Quality-Gate reports present** under `engine-data/reports/`
  (per-track artifacts named `quality-gate-format-<date>.md`,
  `quality-gate-craft-<date>.md`, etc., produced by the Quality
  Gate run — runtime artifacts, not shipped specs) determine
  which of the four Quality-Gate tracks have run.
- **Pre-Delivery Sweep state** — presence and pass-count of
  the 10-pass sweep report (`engine-data/reports/pre-delivery-
  sweep-*.md`) determines whether the screenplay is delivery-
  ready.
- **Coverage / Industry Scout artifacts** under `coverage/` and
  `engine-data/reports/market-scout-*.md` inform the "is this
  ready for industry submission?" recommendation tier.
- **Recent run.log entries** disambiguate active vs paused work
  the same way as prose mode.

Screen-mode recommendations route to Screen Studio menu items
(e.g. "Run the Quality Gate (Edit & Revise)", "Run the 10-pass
Pre-Delivery Sweep", "Request Script Coverage", "Format &
Export") — not to prose-pipeline stages.

Generate the recommendation. Apply
`director-orchestration-protocol.md` HARD GATE — every claim in
the briefing must cite four pieces of evidence. In **prose mode**
these are (a) a specific pipeline-checkpoint field, (b) filesystem
evidence from the bash-list, (c) a prerequisite-phase check, (d)
a prerequisite-audit check. In **screen mode** the equivalents
are (a) a specific `project-config.md` field, (b) filesystem
evidence from the bash-list, (c) a prerequisite-step check, (d)
a prerequisite-artifact check (see Step 5 screen-mode grounding-
gate). Recommendations that cannot be grounded against all four
in the active mode are REJECTED — the briefing displays "no
grounded recommendation possible — here is the raw state for
your review" and lists the obstacles.

### Step 5: Produce the Director Briefing

Output format (**prose mode** — Writers Studio / Full Creative
Suite / NF):

```
═════════════════════════════════════════════════════════════════
DIRECTOR BRIEFING — {Project Title}
═════════════════════════════════════════════════════════════════

WHERE YOU ARE
  Engine:                  {fiction|nonfiction}
  Phase:                   {current_phase}
  Current chapter:         {N} of {total}
  Last activity:           {recent run.log summary}
  Audits passed:           {audit names, comma-separated}
  Audits pending:          {expected-next-audit names}

RECOMMENDED NEXT STEP
  → {recommended action, e.g. "Run Stage 9b External Source Verification"}

  Why:
    Phase field is {phase}; the next phase per the engine's pipeline
    graph is {next_phase}, which requires the prerequisite audit
    {prereq_audit_name}. The Audits Passed ledger shows
    {prereq_audit_name} | {iso} | {report_path}, and the report
    file is verified on disk. {next_phase} is unblocked.

  How to start:
    Say "{trigger phrase}" or run the {flow_name} pipeline.

ALTERNATIVE PATHS
  ◦ {alternative 1, with one-line rationale}
  ◦ {alternative 2, with one-line rationale}

OBSTACLES (if any)
  ◦ {prerequisite that's missing, and how to satisfy it}

This briefing reads pipeline-checkpoint.md and on-disk audit
reports. It does not write to your project. To act on the
recommendation, give the trigger phrase or invoke the flow
directly.
═════════════════════════════════════════════════════════════════
```

Output format (**screen mode** — Screen Studio):

```
═════════════════════════════════════════════════════════════════
DIRECTOR BRIEFING — {Project Title}  (Screen Studio)
═════════════════════════════════════════════════════════════════

WHERE YOU ARE
  Mode:                    Screen Studio
  Format:                  {Feature 90 | Feature 120 | TV Pilot | …}
  Status:                  {Awaiting screenplay | Setup complete | Drafting | Quality Gate | Pre-Delivery Sweep | Delivered}
  Last activity:           {recent run.log summary}
  Quality Gate tracks run: {Format / Craft / Multi-Track / Story Logic — comma-separated}
  Pre-Delivery Sweep:      {Not run | Run, N/10 passes flagged | Clean}
  Coverage state:          {None | Development coverage on disk | Industry coverage on disk}

RECOMMENDED NEXT STEP
  → {recommended action, e.g. "Run the 10-pass Pre-Delivery Sweep"}

  Why:
    Status field is {status}; the next valid Screen Studio step
    per the screenplay pipeline is {next_step}, which requires
    {prereq}. The on-disk evidence shows {prereq} is {satisfied|
    missing}.

  How to start:
    Say "{trigger phrase}" or pick item {N} from the Screen
    Studio menu.

ALTERNATIVE PATHS
  ◦ {alternative 1, with one-line rationale}
  ◦ {alternative 2, with one-line rationale}

OBSTACLES (if any)
  ◦ {prerequisite that's missing, and how to satisfy it}

This briefing reads project-config.md, engine-data/reports/, and
recent run.log entries. It does not write to your project. To act
on the recommendation, give the trigger phrase or pick the menu
item directly.
═════════════════════════════════════════════════════════════════
```

If `producer-state-protocol.md` halted on DIVERGENCE, the briefing
is replaced by the divergence message and no recommendation is
produced.

**Grounding-gate (screen mode):** the 4-claim citation gate the
prose mode applies (pipeline-checkpoint field / filesystem
evidence / prerequisite-phase / prerequisite-audit) is honored
with screen-equivalent evidence: (a) a specific `project-
config.md` field (Mode / Status / Format), (b) filesystem
evidence from the bash-list (presence/absence of quality-gate-
*.md / pre-delivery-sweep-*.md / coverage/*.md), (c) a
prerequisite-step check (e.g. "Pre-Delivery Sweep requires
Quality Gate / Craft track to have passed"), (d) a prerequisite-
artifact check (e.g. "Format & Export requires the deliverables
packet from Step 25 of the screenplay-deliverables spec —
fiction-engine only").
Recommendations that cannot be grounded against all four are
REJECTED in screen mode the same way they are in prose mode.

## Read-only discipline

The Director **never writes**:

- Not to manuscript files (chapters, briefs, summaries)
- Not to audit-report files
- Not to pipeline-checkpoint.md fields
- Not to run.log (the producer-state-protocol writes the
  reconciliation lines; the Director itself does not append a
  separate "I ran" line, since the briefing is informational and
  the calling flow is the next observable event)

The producer-state-protocol auto-repair step (LIST-MISSING rows
appended to `## Audits Passed`) is the only write that happens
during a Director invocation — and it is performed BY the
producer-state-protocol, not by the Director itself. The Director
consumes the reconciled state.

## What the Director does NOT do

- Does not chain into the recommended flow. The user accepts and
  triggers the flow explicitly. This preserves user agency and
  prevents runaway pipeline cascades.
- Does not summarise the manuscript content. (Use Manuscript Clinic
  / read the manuscript directly for content review.)
- Does not assess writing quality. (Use Quality Gate / Editor
  agents.)
- Does not predict timeline / cost. The recommendation is "next
  pipeline step", not "you'll be done in N days".
- Does not recommend skipping a prerequisite audit, even when the
  user's stated goal would be served by the skip. If the user
  wants to skip, they invoke the flow directly; Director will not
  ground a skip-recommendation.

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification binding
are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (pipeline-checkpoint.md) | "Read succeeded with N bytes" | Empty / partial extraction; stale cached view | `read-verification.md` HARD GATE invoked at Step 2 (via producer-state-protocol Step 1) |
| Bash (find / ls audit reports) | "Exit 0; results listed" | Empty result misread as "no audits"; path typo | `bash-output-verification.md` HARD GATE invoked at Step 2 (via producer-state-protocol Step 2) and Step 3 (run.log read) |
| Pipeline-checkpoint state-claim | "Audits Passed list says X passed" | Claim diverges from filesystem reality (audit file absent) | `producer-state-protocol.md` HARD GATE invoked at Step 2 — halts on DIVERGENCE before recommendation is produced |
| Phase-graph reasoning | "Next phase is Y" | Recommendation skips a prerequisite phase / audit | `director-orchestration-protocol.md` HARD GATE invoked at Step 4 — every recommendation must cite checkpoint field + filesystem evidence + prereq-phase check + prereq-audit check |
| Subagent dispatch | n/a — Director is single-agent | n/a | Director does not dispatch subagents (read-only briefing); no `subagent-output-verification.md` invocation needed |
| Write tool | n/a — Director is read-only on project state | n/a | No writes performed; auto-repair writes are performed BY producer-state-protocol under File-Write Hygiene, not by the Director |

The Director's correctness rests entirely on the two HARD GATEs
it invokes (producer-state-protocol for state reconciliation,
director-orchestration-protocol for recommendation grounding) plus
the underlying primitive verifications they delegate to. There is
no Director-specific verification logic — by design, the Director
is a thin orchestration layer over already-verified primitives.

## Failure modes prevented

The Silent-Failure Audit catalog (`silent-failure-audit.md`)
tracks the engine's drift-failure shapes. Director Agent prevents:

- **Hallucinated next-step** — Director cannot recommend a phase
  the engine's graph does not reach from current state; the
  recommendation HARD GATE rejects ungrounded recommendations.
- **Prerequisite-skip recommendation** — Director cannot recommend
  a step that depends on an unrun audit; the prereq-audit check
  is mandatory and references the reconciled `## Audits Passed`
  ledger.
- **Lost session context cascade** — user returning after a long
  pause loses the head-model of project state; without the
  Director, they read pipeline-checkpoint.md by hand and can miss
  the audits-list / filesystem disagreement that the producer-
  state-protocol catches structurally.
- **Stale-state recommendation** — Director cannot ground a
  recommendation against fabricated audit-list rows; if the list
  claims an audit passed and the report file is absent, the
  HARD GATE halts before the recommendation is produced.

## See also

- `silent-failure-audit.md` — full catalog; this spec adds the
  `director-orchestration` binding
- `producer-state-protocol.md` — state-reconciliation HARD GATE
  invoked at Step 2
- `director-orchestration-protocol.md` — recommendation HARD GATE
  invoked at Step 4
- `core-pipeline.md` § Pipeline Checkpoint — the schema Director
  reads project-level fields from
- `read-verification.md` — read-side HARD GATE applied transitively
- `bash-output-verification.md` — bash-side HARD GATE applied
  transitively
- `ask-user-disambiguation.md` — applied at Step 1 when project
  identification is ambiguous
