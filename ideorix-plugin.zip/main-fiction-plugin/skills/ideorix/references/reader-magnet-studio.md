---
name: reader-magnet-studio
description: "Subscriber growth toolkit — create reader magnets, opt-in funnels, and automated welcome sequences tied to your catalog"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Reader Magnet Studio

## Purpose

Build subscriber magnets and automated welcome funnels that convert readers
into buyers. The studio analyses your manuscript or Story Bible, identifies
the strongest magnet angle, writes the complete magnet, and produces all
supporting assets: opt-in page copy, delivery email, and a 3-email
onboarding sequence designed to bridge naturally to your paid catalog.

Every asset is voice-matched to your manuscript using the Ideorix Voice
Profile system and genre-tuned using the genre bank.

---

## Integration Points

This studio draws on existing Ideorix infrastructure:

- **Genre Bank** — genre-specific magnet recommendations, trope awareness,
  reader expectation mapping
- **Voice Profile** — matches all output (magnet prose, emails, landing copy)
  to your established author voice
- **Story Bible / Research Bible** — identifies characters, world elements,
  unresolved threads, and reader-desire hooks for magnet content
- **Prose Humaniser** — runs on all magnet prose to strip AI patterns
- **Entity Database** — ensures character names, locations, and details are
  consistent with the published manuscript

---

## Setup (5 Questions)

Ask one question at a time. Wait for each answer before proceeding.

### S1: Source Material

```
What should I work from?

  A. This project's manuscript — analyse the current Ideorix project
  B. Upload a different manuscript — I'll paste or upload text
  C. Multiple books / describe my catalog — I'll analyse the full catalog
  D. Outline only — build a magnet before the book is written
  E. Genre and premise only — I'll describe what I'm writing
```

If A: Load the Story Bible, entity database, chapter summaries, and Voice
Profile from the current project. This is the fastest path — all analysis
is already done.

If B/C: Run voice extraction on the uploaded text (same protocol as Voice
Builder Path B).

### S2: Strategic Objective

```
What's the magnet for?

  A. Build a list from zero — attract readers who haven't heard of me
  B. Sharpen conversion — I have visibility but signups are low
  C. Pre-launch — build anticipation before a book releases
  D. Wake up a cold list — re-engage subscribers who've stopped opening
  E. Bridge between pen names — attract readers from one name to another
```

### S3: Distribution Channel

```
How will you deliver the magnet?

  A. BookFunnel
  B. StoryOrigin
  C. Direct download from my website
  D. Not decided yet — recommend the best option
```

### S4: Email Platform

```
Where do your emails live?

  A. MailerLite
  B. Kit (formerly ConvertKit)
  C. Mailchimp
  D. Beehiiv
  E. Other — I'll specify
  F. Don't have one yet — recommend one
```

### S5: Magnet Scale

```
How substantial should the magnet be?

  A. Compact (2,000–5,000 words) — bonus scene, epilogue, character dossier
  B. Mid-length (5,000–15,000 words) — short story, origin piece, prequel
  C. Novella (15,000–25,000 words) — standalone story that hooks into the catalog
  D. Reference piece — not a story: world guide, recipe collection, reading companion
  E. Recommend based on my genre and objective
```

---

## Phase 1: Catalog Intelligence

### If Working from an Ideorix Project (S1 = A)

Load from the existing project:
- Story Bible (characters, world, themes, arcs)
- Entity Database (names, locations, objects, relationships)
- Voice Profile (sentence architecture, vocabulary, dialogue style)
- Chapter summaries (plot events, emotional peaks, unresolved threads)

Analyse for magnet opportunities:
- **Characters readers will want more of** — who has the strongest emotional pull?
- **Unresolved curiosity** — what questions does the book raise that it deliberately doesn't answer?
- **Unexplored world** — what locations, time periods, or subcultures appear but aren't fully developed?
- **Reader desire patterns** — based on genre conventions, what do fans of this genre typically want after finishing a book?
- **Pre-story potential** — is there a compelling "before" for the protagonist or a key secondary character?
- **Post-story potential** — is there a satisfying "after" that extends rather than undermines the ending?

### If Working from Uploaded Text (S1 = B/C)

Run the same analysis on the uploaded text. Extract voice using the Voice
Builder extraction protocol. Build a lightweight entity database from the
text for consistency checking.

### If Working from Outline or Description (S1 = D/E)

Work from the provided material. Flag that magnet recommendations will be
less precise without a completed manuscript to analyse.

---

## Phase 2: Magnet Strategy

Present **3 magnet concepts** ranked by strategic fit.

For each concept:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  CONCEPT {N}: {Title}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Type:       {e.g., Prequel Story, Bonus Epilogue, World Companion}
  Scale:      {word count range}
  Premise:    {3-4 sentences — what is this, what happens, why it hooks}

  WHY THIS WORKS:
  {How it connects to the paid catalog. What reader desire it fulfils.
  Why this type outperforms alternatives for this genre + objective.}

  CATALOG BRIDGE:
  {Exactly how this magnet leads to a purchase. Which book it feeds
  into. What the reader will want after finishing it.}

  GENRE FIT: {score}/10
  {Why this type matches genre reader expectations.}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Magnet Types by Category

**Story Magnets (fiction prose):**
- Prequel Story — protagonist before Book 1, must have its own arc
- Bonus Epilogue — after the ending, needs a small conflict or revelation
- Alternate Perspective — a key scene from a different character's POV
- Origin Piece — how a character became who they are
- Same-World Story — different characters, same universe
- Recovered Scene — a cut scene that fans would value
- Seasonal Piece — holiday or seasonal content featuring established characters
- Series Bridge — connects two series or pen names through a crossover

**Companion Magnets (non-prose):**
- Character Dossier — profiles of the cast with scene references and insider detail
- World Companion — locations, maps, lore, rules, with references to the books
- Recipe / Craft Collection — tied to specific scenes and characters (cozy genres)
- Reading Roadmap — guided catalog tour with first-chapter samplers

### Genre-Specific Defaults

Load the genre file from the Ideorix genre bank. Use its trope library
and reader expectation data to inform recommendations.

| Genre | Strongest Type | Strong Alternative | Poor Fit |
|-------|---------------|-------------------|----------|
| Romance (any sub) | Bonus Epilogue | Alternate Perspective (love interest POV) | World Companion |
| Cozy Mystery | Prequel Mystery | Recipe / Craft Collection | Bonus Epilogue |
| Thriller / Suspense | Prequel Case | Same-World Story (same investigator) | Recipe Collection |
| Urban Fantasy | Prequel / Origin | World Companion (city guide) | Bonus Epilogue |
| Epic / Dark Fantasy | Origin Piece | World Companion | Reading Roadmap |
| Horror | Same-World Story (same threat) | Origin of the threat | Character Dossier |
| Cozy Fantasy | World Companion (tavern/crafting) | Same-World Story | Alternate Perspective |
| Historical Romance | Alternate Perspective | Bonus Epilogue | World Companion |
| Romantasy | Prequel / Origin | World Companion with map | Recipe Collection |
| Literary / Contemporary | Recovered Scene | Alternate Perspective | Character Dossier |
| Sci-Fi | World Companion | Prequel Story | Bonus Epilogue |

User selects one concept (or combines elements from multiple).

---

## Phase 3: Write the Magnet

### Pre-Writing Checklist

Before writing:
1. Load the Voice Profile — all prose must match the author's voice exactly
2. Load relevant entities from the Entity Database — character names, locations,
   details must be consistent with the published work
3. Identify the **catalog bridge moment** — the specific point in the magnet
   where the reader thinks "I want to read the full book/series"
4. Confirm the **tone calibration** — heat level, darkness level, humour level
   must match the paid catalog

### Writing Standards

All magnet prose follows the same quality standards as the main Ideorix
fiction pipeline:

- **Craft Standards** from `craft-standards.md` apply in full
- **Forbidden Words** from `forbidden-words.md` enforced
- **Prose Humaniser** runs on all magnet content
- **Voice Profile** governs sentence architecture, vocabulary, dialogue
- Genre-specific guardrails from the loaded genre file apply

### Story Magnet Requirements

1. **Self-contained satisfaction** — a reader who never buys another book
   should feel they received something complete and worthwhile
2. **Desire without deprivation** — the magnet creates wanting through love
   of characters/world, not through withholding or cliffhanger bait
3. **Quality parity** — this is often the reader's first encounter with the
   author. The prose must be indistinguishable from the paid catalog.
4. **Tone match** — a dark magnet for a dark series, a warm magnet for a
   warm series. Mismatched tone loses subscribers immediately.
5. **Natural bridge** — a character mention, a plot thread, a world element
   that the reader will recognise in the paid book. Not a hard sell —
   an organic connection.

### Companion Magnet Requirements

1. **Personality over database** — a Character Dossier should sound like the
   author talking about their characters, not a wiki entry
2. **Scene anchors** — every entry references specific moments from the books
3. **Gift presentation** — this should feel like a curated present, not a
   marketing brochure
4. **Catalog integration** — natural mentions of the books woven into content

### Output

Save as: `{Title}-reader-magnet.docx`

---

## Phase 4: Opt-In Page Copy

Write landing page copy that converts visitors to subscribers.

### Structure

**Above the fold:**
1. **Headline** — what the reader gets, not what they give up.
   Clear over clever. Genre signal in the first 5 words.
2. **Subheadline** — one sentence: emotional promise + specificity
3. **Cover image brief** — describe what the magnet cover should look like
   (for the author to create or commission)
4. **CTA button** — genre-tuned action text, not "Subscribe"

**Below the fold:**
5. **Description** — 3-5 sentences in the author's voice. What the magnet
   is about. What emotional experience it delivers.
6. **What you'll receive** — the magnet + what being on the list means
   (new releases, exclusive content — not "weekly newsletters")
7. **Author line** — 2 sentences, personality-forward
8. **Privacy line** — one sentence: "No spam. Unsubscribe anytime."

### CTA Button Text by Genre

| Genre | Options |
|-------|---------|
| Romance | "Send Me the Story" / "Get Your Free Romance" |
| Cozy Mystery | "Join the Mystery" / "Get Your Free Cozy" |
| Thriller | "Get the Free Thriller" / "Send It Now" |
| Fantasy / UF | "Enter the World" / "Get the Free Adventure" |
| Horror | "Get the Free Horror" / "Send Me the Darkness" |
| General | "Get Your Free Copy" / "Claim Your Copy" |

### Platform Variants

Generate copy optimised for the platform selected in S3:
- **BookFunnel** — shorter, book-focused, cover-prominent
- **StoryOrigin** — similar to BookFunnel, slightly more author personality
- **Author website** — longer, more personality, embed-ready

### Output

Save as: `{Pen-Name}-opt-in-page.html`

---

## Phase 5: Email Onboarding Sequence

### Email 0: Delivery

The email that delivers the magnet. First impression — not just a download link.

- **Subject:** Excited, personal, genre-voiced. Not "Here's your download."
- **Body (150-250 words):** Warm opener → prominent download link → 1-2
  sentences building excitement to read → brief preview of what being on
  the list means → sign-off with first name
- **Tone:** Like the author texting a friend who just asked for a book
  recommendation

### Email 1: The Backstory (sent 2-3 days later)

Build a personal bond. Make the reader feel they know the author.

- **Subject:** Conversational, curious. "The story behind {magnet title}"
- **Body (300-500 words):** Check in on the magnet → share something
  personal about writing the book/series → naturally mention the paid book
  (not a pitch, a reference) → soft CTA ("check it out if you're curious")
- **Purpose:** Move from "stranger who gave me a free book" to "writer I
  feel connected to"

### Email 2: The Insider (sent 3-4 days later)

Prove the list is worth staying on. Deliver something only subscribers get.

- **Subject:** Benefit-driven. Behind-the-scenes, recommendations, bonus content.
- **Body (250-400 words):** Something genuinely useful or entertaining →
  the paid book appears naturally within the insider content (not as a
  separate pitch) → reply invitation for engagement
- **Purpose:** Demonstrate that being on this list delivers exclusive value
  beyond release announcements

### Email 3: The Reading Guide (sent 3-4 days later)

Make the purchase path clear. Guided tour, not a list of links.

- **Subject:** "Where to start" / "Your personal reading guide"
- **Body (300-500 words):** Walk through the catalog with personality →
  "Start here if you like {trope}, start here if you want {emotion}" →
  series reading order if applicable → social proof (reviews, reader
  messages) → direct CTA
- **Purpose:** Convert interest into purchase with a warm, guided hand

### Email Craft Rules

- **Voice match is absolute** — every email must sound like the person who
  wrote the book, not a marketing department
- **Short paragraphs** (1-3 sentences) — this is a personal email, not a blog
- **One CTA per email** — don't split attention
- **Escalation** — each email asks for slightly more investment: read →
  relate → reward → buy. The ask grows. The reader should feel ready for
  the reading guide by the time it arrives.
- **Sign off with first name** — not "The {Pen Name} Team"
- **PS lines** — high read-rate, use for the secondary message

### Output

Save as: `{Pen-Name}-welcome-sequence.docx`

---

## Phase 6: Funnel Review & Delivery

### Coherence Audit

Before delivering, verify the complete funnel as a chain:

1. **Voice consistency** — read the magnet's opening paragraph, the opt-in
   page headline, and the delivery email subject line in sequence. Do they
   sound like the same person? If not, rewrite the outliers.

2. **Catalog connection** — after reading the magnet, would a reader
   naturally think "I want more of this"? Is the path to the first paid
   book visible without being forced?

3. **Genre calibration** — does every asset meet the specific expectations
   of readers in this genre? Not just "a free story" but "the right kind
   of free story for these readers."

4. **Escalation arc** — read the 4 emails in sequence. Does each feel like
   the natural next step? Does the ask grow? Is the reader ready for the
   catalog email when it arrives?

5. **Opt-in page test** — if someone glanced at the page for 3 seconds,
   would they know: (a) what they get, (b) that it's free, (c) that it's
   for them?

6. **Quality standard** — is the magnet good enough that readers would pay
   for it? Free does not mean low effort. This is the author's first
   impression.

### Deployment Guide

Compile a setup guide tailored to the user's selected platforms (S3 + S4):

- Step-by-step upload instructions for the distribution platform
- Automation setup for the email sequence in their email platform
- Where to promote the magnet (back matter, website, social, swap groups)
- What to measure (signup rate, open rates, click rates, conversion to purchase)
- When to refresh (after new releases, seasonal updates, if conversion drops)

### File Delivery

Save all files to the project folder:

```
{Project}/marketing/reader-magnet/
├── {Title}-reader-magnet.docx           — the magnet content
├── {Pen-Name}-opt-in-page.html          — landing page copy
├── {Pen-Name}-welcome-sequence.docx     — delivery + 3 onboarding emails
└── {Pen-Name}-funnel-deployment.docx    — setup guide + promotion plan
```
