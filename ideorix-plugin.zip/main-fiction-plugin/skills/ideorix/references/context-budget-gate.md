---
name: context-budget-gate
description: "Context-Budget Gate (fail-closed HARD GATE). Decides whether a context-heavy 'global' pass (one that loads the whole manuscript + bible + trackers into a single context) may run, based on a one-time capability tier the user declares once and the engine persists in project-config.md. Models cannot reliably introspect their own identity or context-window ceiling, so the gate never silently auto-detects: it reads a declared tier and FAILS CLOSED to windowed/cost-saver behaviour when the declaration is absent, unparseable, over-budget, or ambiguous. Prevents the silent-truncation-as-success failure on smaller-context models (the engine reading a truncated manuscript and reporting on a half-read book) and prevents unauthorised premium-above-200K token spend. Engine-agnostic; mirrored byte-identically across fiction and nonfiction."
version: "2.7.99"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Context-Budget Gate (MANDATORY for any context-heavy / whole-manuscript pass)

## Purpose

Ideorix's per-chapter discipline (delta trackers, windowed audits)
keeps the working set small so the engine runs on smaller-context,
lower-cost models. Some validation is strictly better when the
**whole** manuscript + bible + every tracker sit in one context at
once (a global coherence capstone catches non-adjacent drift that a
sliding window structurally cannot). Those passes are
**context-heavy** and only make sense on a large-context, higher-
capability configuration.

This gate decides, per pass, whether a context-heavy variant may
run — without ever silently guessing the user's model or context
ceiling. It reads a **declared** capability tier and fails closed to
windowed behaviour whenever that signal is missing or insufficient.

## Why not auto-detect

A running model cannot reliably introspect (a) which model it is —
self-reported identity hallucinates — or (b) its configured context-
window ceiling. The engine already encodes this distrust: the Model
Health Monitor sources the model ID `{from the host app}` as written-
down telemetry, and the model-switch gate can only *instruct the user*
to change models in the host app — it cannot detect or change the
model itself. A wrong auto-detect is itself a silent-failure vector:
guess "large context", run the global pass on a standard-context
configuration, truncate the manuscript, and report success on a half-
read book — the exact failure class the engine's whole discipline
exists to prevent. So the gate uses a **declared** tier, not a
detected one.

## The Capability Declaration (persisted in project-config.md)

A single block, appended to `project-config.md` once and read on
every subsequent run:

```markdown
## Capability Declaration
<!-- schema: ideorix-capability v1 -->
Context-Tier: cost-saver | max-quality
Context-Budget-Tokens: 200000 | 1000000
Cost-Consent: ask-each-time | auto-approve
Declared: {ISO-8601 timestamp}
Declared-Model: {model ID as shown in the host app, e.g. claude-sonnet-4-6}
```

- **`cost-saver`** — windowed behaviour only. Context-heavy passes
  never fire; the engine behaves exactly as it does today. Budget
  recorded as 200000 (the standard-window assumption).
- **`max-quality`** — context-heavy passes are permitted up to the
  declared `Context-Budget-Tokens`. The premium configuration.

`Declared-Model` is recorded for telemetry and to pre-fill the
suggestion on re-declaration; it is **not** used as an authority on
the tier (see Why not auto-detect). The tier is whatever the user
declared, full stop.

## Capture protocol (lazy, one-time, low-friction)

The declaration is captured **lazily** — never as a mandatory setup-
interview question, so cost-saver users who never request a global
pass are never asked at all:

1. A context-heavy pass is requested **and** no valid Capability
   Declaration exists in `project-config.md`.
2. Ask **once**, via `AskUserQuestion` (consistent with the Model
   Health gate's one-ask-then-persist pattern):
   *"Quality tier for whole-manuscript passes — cost-saver
   (standard context, no premium spend) or max-quality (large
   context, enables global coherence passes)?"*
   Pre-fill the recommended option from `Declared-Model` when the
   host model ID is available (`opus` → suggest max-quality;
   `sonnet`/`haiku` → suggest cost-saver) — but the user always
   chooses.
3. Append the Capability Declaration block to `project-config.md`
   using the **Class-2 File-Write Hygiene** rules from
   `core-pipeline.md` (Edit/Write tool, never bash cat-and-mv).
4. Never re-ask. Subsequent runs read the persisted block. The user
   changes tier only by explicitly invoking re-declaration (below).

## The gate procedure (FAIL-CLOSED)

Invoked by any pass registered as context-heavy, before it loads the
working set:

1. **Read** `project-config.md` under the `read-verification.md`
   HARD GATE. Empty / failed extraction → treat as **undeclared** →
   `DECISION = WINDOWED`. Stop.
2. **Parse** the Capability Declaration block. Absent, `Context-Tier`
   unparseable, or not one of the two known values →
   `DECISION = WINDOWED` (fail closed). Stop. (If the calling context
   is interactive and capture has not yet been offered, route to the
   Capture protocol instead of silently proceeding.)
3. `Context-Tier = cost-saver` → `DECISION = WINDOWED`. Stop.
4. `Context-Tier = max-quality`:
   a. **Estimate** the working-set token cost (see below).
   b. estimate + safety-margin ≤ `Context-Budget-Tokens` →
      `DECISION = GLOBAL-ELIGIBLE`.
   c. Otherwise → `DECISION = WINDOWED`, and surface an over-budget
      notice: *"this manuscript's working set (~N tokens) exceeds
      your declared budget (M) — running the windowed pass instead."*
      Never silently run an over-budget global pass.
5. `GLOBAL-ELIGIBLE` → apply **Cost-Consent** before the expensive
   call.

### Every failure direction is the safe one

Undeclared, unparseable, ambiguous, over-budget, corrupt-write,
mis-counted size — **every** degenerate path resolves to `WINDOWED`,
which is cheaper and fits a smaller context. The gate can only ever
fail *toward* cost-saver, never toward an unauthorised premium spend
or a context overflow. This is the gate's core safety property and
the reason it can default on for all projects without risk to
cost-conscious users.

## Working-set estimation (cheap pre-check, no full load)

Eligibility is decided **before** loading anything into context, so
an over-budget case is caught up front rather than after the
expensive read:

1. Bash-sum the bytes/words of the working-set files (manuscript
   chapters + bible + active trackers) with `wc`, under the
   `bash-output-verification.md` HARD GATE.
2. Convert to tokens with the `words × 1.33` (≈ `bytes / 4`)
   heuristic.
3. Add fixed spec/prompt overhead plus a **15% safety margin** to
   absorb heuristic error.
4. Compare against `Context-Budget-Tokens`. Within budget →
   eligible; otherwise fail closed to windowed.

## Cost-Consent

A `max-quality` global pass crosses the 200K premium-pricing
threshold — a spending decision that is the user's to authorise, not
the engine's to assume. The first time per session a global pass
would fire, confirm via `AskUserQuestion` unless
`Cost-Consent = auto-approve` is persisted. Honour a persisted
auto-approve so the consent is not re-asked every chapter.

## What is and isn't gated

- **Gated** (must consult this gate): any pass that loads the whole
  manuscript + bible + trackers simultaneously — i.e., global
  coherence capstones. These register against the gate as they are
  built; the gate is the foundation they call.
- **Not gated** (runs for everyone, unchanged): every per-chapter
  delta audit, the existing windowed Phase 5 / Stage 9.5 sweep, and
  all other windowed passes. **The per-chapter discipline stays
  mandatory and ungated for all tiers — it is what makes the engine
  viable on cost-saver in the first place.** Context-heavy variants
  are strictly *additive*, never a replacement.

## Backward compatibility

Existing projects carry no Capability Declaration → the gate fails
closed to cost-saver/windowed → behaviour identical to today. No
migration, no retro-edit of existing `project-config.md` files.
(Parallels the `coherence-function-consecutive.md` stance: a missing
declaration degrades gracefully, it does not fail the run.)

## Re-declaration

The user changes tier (upgraded their model, or wants to stop paying
premium) by explicitly invoking re-declaration — re-run the Capture
protocol, overwrite the block with a fresh `Declared` timestamp.
There is no automatic tier change; the engine never silently promotes
a project to max-quality.

## Silent-Failure Audit

This gate uses the following primitives. For each, the success-claim,
divergence failure mode, and verification binding are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (`project-config.md`) | "Read succeeded" | Empty extraction of an existing `max-quality` declaration would downgrade the project to windowed | `read-verification.md` HARD GATE. The fail direction is intentionally safe: a missed declaration downgrades to cheaper/windowed, never up to premium/overflow |
| Bash (working-set `wc` sizing) | "wc returned N" | Miscount / partial directory listing → under-estimate → a global pass that overflows the real budget | `bash-output-verification.md` HARD GATE on the sizing command; the 15% safety margin absorbs heuristic error; over-budget fails closed to windowed |
| Write/Edit (append declaration) | "Write succeeded" | Subdir flush / partial write leaves a half-written declaration | Class-2 File-Write Hygiene (Edit/Write tool, never bash cat-and-mv) per `core-pipeline.md`; a corrupt block fails to parse on next read and the gate fails closed |
| AskUserQuestion (tier + cost consent) | "User answered" | The risk here is the inverse — *not* asking, i.e. silently assuming max-quality or auto-approving premium spend | The gate requires an explicit answer before any global-eligible or premium-spend path; there is no silent assumption of the expensive tier |

## Routing

- Own Read of `project-config.md` → governed by `read-verification.md`
- Own working-set sizing → governed by `bash-output-verification.md`
- Declaration persistence → Class-2 File-Write Hygiene in `core-pipeline.md`
- Consulted by: any context-heavy / whole-manuscript pass (registers
  against this gate before loading its working set)
