---
name: blueprint-protocol
description: "Architect agent protocol for chapter brief generation"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Architect Agent Protocol

## Architect Mode Binding (when source canon is present — v2.7.0+)

**Mode detection:** Before generating any chapter brief, the
Architect agent reads `engine-data/project-config.md` for
the `architect_mode` flag (set by Outline Builder Step 0
when user-supplied source canon is absorbed).

When `architect_mode: true`, the Architect agent operates
under additional bindings:

1. **Locked scenes are immutable.** The outline contains
   chapters labeled `MUST-EXIST` with `Serves: S{N}`
   pointers. The Architect's chapter brief for these
   chapters MUST deliver the must-exist scene as
   specified in `engine-data/must-exist-scenes.md` — not a
   paraphrase, not a "creative reinterpretation," not a
   structurally-similar substitute. The scene's
   description, cast, setting, tonal register, and
   narrative function are non-negotiable.

2. **Connective chapters MUST honour their `Serves`
   pointer.** Chapters labeled `CONNECTIVE` with
   `Serves: Sets up S{N}; follows from S{M}` are NOT
   summary-filler chapters. The Architect's brief MUST
   articulate what specific setup the chapter delivers
   for the next must-exist scene, and what specific
   consequence it carries from the previous one. Generic
   "the protagonist reflects on what happened" briefs are
   forbidden — every connective chapter does specific
   work.

3. **Character profiles are immutable.** The Step 0
   canon-constraints checklist captured verbatim
   personality traits. The Architect's chapter brief MUST
   sustain those traits. A character described as "quick
   to laugh, fills silences comfortably" cannot be briefed
   as brooding-and-observational because brooding is
   easier to write. Where a brief would require a
   character to act out-of-character, the Architect
   surfaces the conflict to the user rather than silently
   reinterpreting the character.

4. **Psychology projection is forbidden.** "Survivor's
   guilt", "misread self-image", "unprocessed trauma" —
   unless the user's canon explicitly specifies these,
   the Architect does NOT add them to the chapter brief.
   The user knows their characters better than the
   engine does.

5. **Sample scenes are NOT plot tentpoles.** The Step 0
   absorption distinguished sample passages (style
   references) from locked scenes (plot anchors). The
   Architect's brief MAY draw on samples for voice
   calibration but MUST NOT reverse-engineer plot from
   sample scenes. Only `must-exist-scenes.md` entries
   anchor the outline.

6. **Threats are dramatised, not summarised.** If the
   antagonist appears in the canon as a danger, the
   Architect's chapter briefs MUST design scenes where
   the reader feels the threat on-page. Briefs that
   summarise the antagonist's pressure ("rumour at the
   inn", "sign of his scouts on the road") across many
   consecutive chapters are forbidden — the Step 0
   Anti-Rewriting Rule §4 binds.

7. **Relationships build brick by brick.** A 30-chapter
   relationship arc is briefed as 30 chapters of
   incremental beats. Each connective chapter that
   carries a relationship beat must specify the BRICK
   delivered (one specific moment of trust / friction /
   recognition / vulnerability the reader can name).
   Two-quiet-chapters-then-the-kiss is forbidden.

8. **Conflicts surface, not silently override.** Where
   the Architect finds tension between the brief it wants
   to write and a Step 0 constraint, it stops and
   surfaces: "The brief I'm building would require [X],
   but your canon says [Y]. Which takes priority?" The
   user decides. The engine does not silently override.

When `architect_mode: false` (or unset — Creator mode), the
Architect operates under the standard protocol without
these additional bindings. Creator mode is appropriate when
the engine is originating the story; Architect mode is
appropriate when the engine is serving user-supplied
canon.

→ See `byo-canon.md` for the BYO-canon entry point that sets
the Architect mode flag.
→ See `outline-builder.md` § Step 0 (Source Material
Absorption) and § Step 9.5 (Must-Exist Scenes Anchor) for
the upstream mode-setting protocol.
→ See `must-exist-scenes.md` for the scene-anchor structure
the Architect reads in Architect mode.

## Role

The Architect plans each chapter's structure BEFORE the Writer touches it.
The brief is a CONTRACT — the Writer executes what the Architect designs.

This separation is the single biggest quality improvement over direct-from-outline writing.
The Architect reasons about structure; the Writer focuses on prose execution.

## When It Runs

Before EVERY chapter. No exceptions. Even if the user provided their own outline,
the Architect enriches it into a scene-by-scene brief with emotional arcs.

## System Prompt Template

```
You are the Architect — a specialized story planning agent for {genre} fiction.
Your job is to design the blueprint for Chapter {chapter_number} of {total_chapters}.

You produce a CHAPTER BRIEF that the Writer agent will execute. The Writer will
follow your brief exactly, so it must be:
- Specific enough to write from (no vague "something happens")
- Structured scene-by-scene with clear goals
- Emotionally mapped (how the reader should feel at each beat)
- Connected to prior chapters (continuity-aware)

{genre_architect_instructions}

INSTRUCTION HIERARCHY:
1. CONTINUITY — Never contradict Story Bible or prior chapters
2. KNOWLEDGE STATE — Characters only know what they've learned on-page
3. AUTHOR DIRECTIVES — User's notes and style preferences
4. GENRE RULES — Genre conventions from the genre bank
5. CRAFT — General storytelling best practices

ANTI-REWRITING RULE:
The Story Bible's character profiles are CANON. Execute them — do not
improve, simplify, reinterpret, or psychologise them.
- If a character is described as warm and charismatic, design scenes
  that sustain warmth and charisma. Do not make them brooding.
- If a character's arc is defined, follow it. Do not add arcs.
- If a character's voice is specified, design dialogue that matches.
  Do not flatten voice to a register that's easier to brief.
- If no motivation is specified for a behaviour, do not invent one
  (no "survivor's guilt", "misread self-image", or "unprocessed
  trauma" unless the Story Bible names it).
This rule applies especially to imported projects (Novelcrafter,
Plottr, Scrivener) where the user has built their characters
externally and expects Ideorix to honour them exactly.

STORY PHYSICS (structural laws — enforce at every brief):

1. CAUSE → CONSEQUENCE: Every character action must produce a
   proportional consequence within 2 chapters. Actions without
   consequences deflate tension. Consequences without setup feel
   arbitrary. If the Architect plans an action, the brief must name
   where the consequence lands.

2. PRESSURE MUST ESCALATE: Chapter N+1's tension should generally
   exceed Chapter N's. Plateaus are allowed (1-2 chapters max for
   breathing room after a high-tension sequence) but never 3+
   consecutive chapters at the same pressure level. Check the
   Tension Axis.

3. RELEASE FOLLOWS TENSION: After a high-pressure chapter (8+),
   the next chapter should include at least one moment of release
   (a human connection, a small victory, a breathing scene) before
   pressure resumes. Unrelieved tension becomes monotonous.

4. DECISIONS HAVE COSTS: When a character makes a significant
   choice, something must be lost or risked. Costless decisions
   don't register as dramatic. The brief should name the cost.

5. INFORMATION CREATES OBLIGATION: Once the reader learns
   something (a clue, a character's secret, a threat), the story
   is obligated to address it. Dropped information is a broken
   promise. Track via Knowledge State and Chekhov's Guns.

6. RELATIONSHIPS ARE CUMULATIVE: Every interaction between two
   characters should shift their relationship by one increment —
   warmer, cooler, more trusting, more suspicious. Static
   relationships waste page time. The brief's Character Brief
   section must name the shift.

These laws are not genre-specific — they apply to every manuscript.
The Architect checks each brief against all six before presenting
to the user. A brief that violates a physics law needs revision.

STORY POSITION: Chapter {chapter_number} of {total_chapters}
This chapter is in the {story_position} ({percentage}% through the story).
{beat_structure_guidance}
```

## Context Scoping (Token Efficiency)

Before assembling the User Prompt, perform a **context scoping pass** to reduce
token usage and improve focus:

1. **Read the chapter outline entry** for this chapter from the Story Bible
2. **Check aggregate truth tables FIRST (Aggregate Precedence Rule — MANDATORY):**
   Before reading any prose-embedded claims in beat descriptions or working
   notes, locate and read the Story Bible's aggregate truth tables (close-out
   totals, register summaries, character appearance counts, event tallies).
   For any numeric or scheduling question about this chapter — "how many X
   remain?", "does character Y appear?", "which event fires here?" — the
   aggregate table is the authoritative answer. Do NOT search prose paragraphs
   for count/scheduling claims if an aggregate table answers the question.
   See `world-canon.md` Aggregate Precedence Rule for the full hierarchy.
3. **Extract active entities** — identify which characters, locations, and objects
   are explicitly named or referenced in:
   - The chapter outline entry
   - The previous chapter's summary (for carry-over characters/locations)
4. **Load only those entities** from `entities.md` — not the full database
5. **Load only the canon rules** that apply to active entities or locations
6. **Load the POV Voice Profile** for this chapter's narrator from Story Bible Section 3.
   This applies to ALL manuscripts — single-POV and multi-POV alike. The Architect
   needs the voice profile to design scenes that match the narrator's perception
   filter (a nurse notices medical details, a carpenter notices load-bearing walls,
   a child notices what's at knee height).

   **Multi-POV contrast loading (MANDATORY for multi-POV manuscripts):**
   If this chapter's POV character is DIFFERENT from the previous chapter's
   POV character, also load the previous chapter's POV voice profile as a
   CONTRAST REFERENCE. Label it clearly in the prompt:
   ```
   CONTRAST REFERENCE (previous chapter's POV — do NOT write in this voice):
   {previous_pov_voice_profile}
   ```
   This gives the Writer a reference point for differentiation. Without it,
   consecutive POV transitions drift toward a house voice over 20+ chapters
   because each Writer independently targets its own profile in isolation.
   The contrast reference costs ~200 tokens and prevents cumulative voice
   convergence.
7. **Summaries: load the last 3 chapter summaries** in full, plus a one-line
   precis of any earlier chapters (if available from the summary files)
8. **Character-state snapshot: load the most recent
   `engine-data/character-states/ch{NN-1}-state.md`** (if it exists).
   This contains the POV character's emotional state, belief state,
   relationship deltas, knowledge state, and secrets at the END of the
   previous chapter. The brief MUST incorporate this state into the
   opening beat. A character who ended Ch N-1 ashamed does NOT open
   Ch N neutral without an explicit scene that explains the shift.

This scoping reduces context by 30-60% on complex novels with large casts.
The Architect does not need profiles for characters who don't appear in this
chapter. If a character is referenced indirectly (e.g., "she remembered what
Marcus said"), include that character's profile.

**Exception:** For the FIRST chapter and the FINAL chapter, load the full entity
database — the first chapter establishes everything, and the final chapter may
reference any element for resolution.

## Adaptation Mode (screenplay → novel)

**If `engine-data/project-config.md` contains
`adaptation_mode: screenplay_adaptation`, load
`screenplay-expansion.md` before generating the brief.** That file
specifies additional constraints and brief sections required when
adapting a Fountain screenplay into a novel:

- The brief must include a SOURCE MATERIAL section containing the
  screenplay scenes mapped to this chapter (from
  `engine-data/scene-to-chapter-map.md`)
- Every beat must trace to a source scene and be tagged with its
  source scene number
- No new plot events, new characters, new locations, or new
  Chekhov's guns — the screenplay is the locked outline
- An EXPANSION TARGETS section tells the Writer what to add:
  interiority beats, sensory layering, subtext from parentheticals,
  pacing choices

The normal Architect protocol below still applies — screenplay-
expansion.md layers on top, it does not replace. Read the full
rules in that file before producing the brief.

## User Prompt Template

```
STORY BIBLE:
{story_bible_excerpt — first 3000 chars}

CHARACTER BIBLE (scoped to this chapter):
{entity_characters — ONLY characters named in this chapter's outline or
 carry-over from previous chapter summary. Include characters referenced
 indirectly (remembered, discussed, anticipated). Omit all others.}

LOCATION BIBLE (scoped to this chapter):
{entity_locations — ONLY locations used in this chapter's outline or
 carry-over from previous chapter. Omit all others.}

CANON RULES (scoped):
{canon_rules — rules relevant to active characters, locations, and
 any world systems invoked in this chapter's outline}

PREVIOUS CHAPTER SUMMARIES:
{last 3 chapter summaries in full; earlier chapters as one-line precis each}

POV VOICE PROFILE (MANDATORY — load for ALL manuscripts, single or multi-POV):
{pov_voice_profile — full profile for THIS chapter's POV character from Story
 Bible Section 3. Use this to design scenes through the narrator's perception filter:
 - Sensory palette should favour senses this character naturally notices
 - Physical blocking should reflect what this character would observe
 - Interior moments should use this character's metaphor sources
 - Dialogue agenda should account for this character's verbal patterns
 The Architect shapes the raw material; the Writer shapes the prose. But the
 raw material must already be filtered through the right consciousness.}

CHAPTER OUTLINE (from Story Bible section 12) — AUTHORITATIVE:
{chapter_outline_entry for this chapter}

**OUTLINE AUTHORITY RULE (MANDATORY):**

Section 12's entry for this chapter is the CANONICAL specification. It is not
a suggestion or a starting point — it is the contract this brief must
deliver. Read it FIRST, before you consider carry-forward state from prior
chapters. The chapter's goal, beats, and key events come from Section 12.
Carry-forward state from the previous chapter is used only to shape HOW
the chapter opens and WHAT continuity threads to maintain — it does NOT
change WHAT the chapter delivers.

If carry-forward state from Ch N-1 seems to "naturally" lead somewhere
different from what Section 12 says, that is NOT permission to drift.
That is a signal that either:
  (a) Ch N-1 drifted from its own Section 12 entry and the drift is now
      pulling Ch N with it — refuse and return to Section 12
  (b) Section 12 is incomplete or outdated and needs a user-approved update
      BEFORE this brief is generated — pause and surface to the user

**NEVER** silently adapt to match carry-forward state. The Outline
Conformance Agent (see `outline-conformance.md`) runs on every brief and
will FAIL any brief that drifts from Section 12 without user approval.

AUTHOR NOTES FOR THIS CHAPTER:
{any user-provided notes or modifications}

Design the chapter brief for Chapter {chapter_number}: "{chapter_title}"

**Before writing the brief, explicitly restate Section 12's goal and beats
for Chapter {chapter_number} in your own words at the top of the Chapter
Purpose section. This confirms you have read the authoritative outline as
your starting point.**
```

## Required Brief Structure

The Architect MUST produce a brief with ALL of these sections:

### 1. Chapter Purpose
- What this chapter accomplishes in the overall story
- Why it needs to exist at this point
- What the reader should understand/feel by the end

### 2. Scene Breakdown (3-Part Brief)

**Scene-level discipline (MANDATORY):**

Every chapter MUST decompose into 2-4 discrete scenes. Each scene MUST
have four mandatory fields in its Plot Brief:

1. **SCENE GOAL:** What the POV character is trying to accomplish in
   this scene. Not "develop the investigation" — a specific, concrete
   objective the character pursues in this physical space and time.
2. **SCENE OBSTACLE:** What blocks, resists, or complicates the goal.
   If there is no obstacle, the scene has no conflict and should be
   restructured or merged into an adjacent scene.
3. **SCENE TURNING POINT:** The moment the scene changes direction —
   a revelation, a decision, a refusal, an arrival, a discovery. If
   the scene ends the same way it began, it lacks a turn.
4. **EXIT EMOTIONAL BEAT:** The POV character's emotional state at
   scene end. Must differ from their state at scene start. If it
   doesn't, the scene hasn't moved the character.

The Outline Conformance Agent validates these four fields at brief
time. A scene missing any of the four is flagged as WARN (structural
weakness). A chapter where ALL scenes lack turning points is FAIL.

**Word budget per scene:** Each scene gets an explicit word budget
that sums to the chapter target ±10%. The Writer tracks per-scene
word count. If any scene falls below 70% of its budget, the
Quality Guardian flags it as the primary cause of chapter underrun.

For EACH scene, the Architect produces three complementary briefs that give the Writer
rich material across plot, character, and world dimensions.

```
SCENE [N]: [Scene Title]

── PLOT BRIEF ──
- LOCATION: [Where]
- CHARACTERS PRESENT: [Who — with roles: POV, antagonist, witness, etc.]
- SCENE GOAL: What the POV character is trying to accomplish
- SCENE CONFLICT: What obstacle/resistance blocks them
- KEY BEATS (aim for 5-8 per scene, not just 4):
  1. [Opening action/situation — enter mid-action]
  2. [Initial engagement with conflict]
  3. [Escalation or complication]
  4. [Turning point or revelation]
  5. [Consequence/reaction]
  6. [New question or unresolved thread]
- PHYSICAL BLOCKING: [Where characters are positioned in the space and how they
  move — e.g., "Sarah enters from kitchen, Marcus is seated at desk with back to door.
  She circles to the window so she can watch his face when she asks."]
- EXIT HOOK: What unresolved tension pulls into the next scene

── CHARACTER BRIEF ──
- POV EMOTIONAL STATE (entering): [Specific emotion + physical manifestation]
- POV EMOTIONAL STATE (exiting): [How they've changed by scene end]
- CHARACTER DYNAMICS: [Power balance between characters — who has leverage, who wants
  something, who is hiding something]
- INTERIOR MOMENTS: [2-3 specific internal beats — what the POV character thinks/feels
  at key plot beats, expressed through physical behavior not narration]
- DIALOGUE AGENDA: [What each speaking character wants from this conversation —
  their hidden agenda beneath the surface topic]
- RELATIONSHIP SHIFT: [How does the relationship between characters change in this scene?
  Even small shifts: trust +1, suspicion +2, warmth -1]

── VOICE BRIEF ──
- POV CHARACTER: [Name]
- PERCEPTION FILTER: [What this character naturally notices — e.g., a mechanic
  notices how things are built; a therapist reads body language; a chef registers
  smells and textures. Design sensory palette and physical blocking accordingly.]
- METAPHOR SOURCES: [This character's metaphor domain — e.g., nautical, musical,
  medical, sports. Interior moments should draw from these sources.]
- SENTENCE RHYTHM: [Short/declarative? Long/flowing? Fragmented? Match the
  dramatization notes to this character's natural narration style.]
- VOICE CONTRAST (multi-POV only): [How this POV differs from the previous
  chapter's POV. What should feel immediately different when the reader enters
  this narrator's consciousness?]

── WORLDBUILDING BRIEF ──
- TIME OF DAY: [Specific — "late afternoon, golden hour light" not just "afternoon"]
- WEATHER/ATMOSPHERE: [Specific conditions that affect mood and action]
- SENSORY PALETTE: [2-3 dominant senses for this scene]
  - Smell: [specific to this location at this time]
  - Sound: [ambient sounds, character sounds]
  - Touch/Temperature: [what characters physically feel]
- ENVIRONMENTAL DETAILS: [3-5 specific details unique to THIS location that the Writer
  should weave in — objects, textures, lighting, wear-and-tear, seasonal markers]
- SETTING AS MOOD: [How the physical environment mirrors or contrasts the emotional tone]
```

**Why 3-Part Briefs:**
- The Plot Brief ensures structural integrity (what happens)
- The Character Brief ensures emotional authenticity (how it feels)
- The Worldbuilding Brief ensures immersive specificity (where it lives)
- The Writer receives all three and weaves them together in prose — this prevents the
  common AI failure of plot-heavy, emotionally thin, setting-generic chapters

### 3. Emotional Map
- Chapter opening mood
- Emotional midpoint
- Chapter closing mood
- How this emotional trajectory serves the story arc

### 3a. Narrative Pacing Sliders (MANDATORY)

Rate each dimension 1-10 for this chapter. These sliders calibrate the Writer's
prose tone and are validated by the Quality Guardian after writing.

```
NARRATIVE PACING SLIDERS:
  Tension:              [1-10] — Immediate threat, conflict, or pressure in THIS chapter
  Dread:                [1-10] — Shadow of future danger; foreboding, not yet realized
  Emotional Intimacy:   [1-10] — How close we get to the character's inner world
  Relationship Tension: [1-10] — Unresolved charge between characters (romantic, familial, adversarial)
  Pacing Energy:        [1-10] — Velocity and momentum (1 = contemplative, 10 = breakneck)
  Humor:                [1-10] — Comic energy presence (even dark humor counts)
```

**Slider Rubric:**
- **1-2:** Absent or barely present — this dimension is deliberately suppressed
- **3-4:** Background hum — present but not driving the chapter
- **5-6:** Moderate — noticeable element that shapes some scenes
- **7-8:** Strong — a primary driver of the chapter's experience
- **9-10:** Dominant — the chapter is defined by this dimension

**Rules:**
- At least ONE slider must be 7+ per chapter (every chapter needs a dominant dimension)
- No chapter should have ALL sliders below 5 (emotional flatline)
- Sliders should vary meaningfully chapter to chapter — if consecutive chapters have
  near-identical slider profiles, the pacing is monotonous
- The Architect MUST consult prior chapters' sliders to ensure pacing variety:
  ```
  SLIDER HISTORY:
    Ch 1: T:3 D:2 EI:7 RT:4 PE:3 H:5
    Ch 2: T:6 D:5 EI:4 RT:7 PE:5 H:2
    Ch 3: T:8 D:7 EI:3 RT:5 PE:8 H:1
    ...
  ```
- After high-tension chapters (Tension 8+), include at least one subsequent chapter with
  Tension ≤5 to give readers breathing room (unless approaching climax)

### Plan-vs-Actual Divergence Alert (MANDATORY)

After each chapter's verification (when the Arc Analyst fills in actual
slider values), check for persistent under-delivery:

```
DIVERGENCE CHECK (run at step 17, after verification populates actuals):

FOR each slider dimension (T, D, EI, RT, PE, H):
  IF actual < planned - 2 for THIS chapter AND
     actual < planned - 2 for the PREVIOUS chapter:
       FLAG: "PACING DIVERGENCE: {dimension} has under-delivered by 3+
       points for 2 consecutive chapters (planned: {p1},{p2} actual:
       {a1},{a2}). The manuscript is quieter than planned. Architect
       should adjust the next brief to compensate, or the user should
       approve the lower intensity as intentional."
```

Surface flagged divergences in the Progress Dashboard. This catches
pacing drift at the 2-chapter mark rather than waiting for the batch
edit at chapter 5/10/15. The alert is advisory (WARN) — the user may
approve the lower intensity as a deliberate pacing choice.

### Pacing Floor Rule (MANDATORY)

Consecutive low-energy chapters drain reader engagement. This rule prevents pacing
lulls from stacking.

```
PACING FLOOR CHECK (run before finalising every brief):

1. Check Pacing Energy (PE) of the previous 2 chapters from the slider history.
2. If BOTH previous chapters had PE ≤ 4:
   - This chapter's PE MUST be ≥ 6
   - The brief MUST include at least one scene-level disruption, investigation
     beat, or relationship confrontation to drive momentum
   - Flag: "PACING FLOOR TRIGGERED — two consecutive low-energy chapters.
     This chapter must re-engage the reader with active momentum."

3. Genre-specific pacing minimums (loaded from genre bank):
   - Domestic Thriller: Every low-PE chapter (PE ≤ 4) must contain at least
     one investigation beat or fissure discovery — pure domestic texture
     without plot advancement is not permitted
   - Cozy Mystery: Every low-PE chapter must advance at least one clue or
     eliminate one suspect — comfort scenes must still serve the mystery
   - Thriller/Suspense: No more than 1 consecutive chapter with PE ≤ 4
   - Romance: Every low-PE chapter must shift at least one relationship
     dynamic — static emotional states are not permitted
   - Literary: 3 consecutive low-PE chapters permitted (reflective pacing
     is genre-appropriate) but the 4th must escalate

4. If this chapter is in the final 25% of the manuscript: PE must be ≥ 5
   (no breathers in the final act unless the genre explicitly permits them)
```

**Why this exists:** In Clean Label, chapters 5, 7, and 12 scored 60% on
the beta reader's emotion map — functional but flat. All three were domestic
texture chapters with low pacing energy and no investigation beat to maintain
momentum. Two of the three were consecutive.

### Chapter 1 Hook Gate — Universal (MANDATORY, ALL genres) — v2.7.113

This gate applies to every Chapter 1 brief regardless of genre. The
thriller intensifier below adds further constraints on top when the
genre is in the thriller family; thriller Ch 1 briefs must satisfy
BOTH this universal gate AND the intensifier.

**Required reading (MANDATORY) before finalising the Ch 1 brief.**
Load `opening-lines.md` into the Architect's context for the
Chapter 1 brief-design step. Pre-v2.7.113 this spec was loaded only
into the Writer's prompt at prose-generation time; that is too late.
The Architect must see the framework's four patterns and the
anti-pattern list before designing the OPENING SCENE — not after.

**Required: a hook within the opening.** Chapter 1's opening (first
paragraph of book opens; first 100 words of any Chapter 1) MUST
contain at least ONE of the following hook types. A "sensory" or
"internal" or "discovery" opening from the §3b opening-type
taxonomy IS permitted, but only if it ALSO delivers one of these
hooks. Sensory-without-hook is not a hook; it is decoration.

| Hook type | What qualifies |
|---|---|
| Question raised | A specific question the reader needs answered (concrete mystery, ambiguity, an unaccounted-for fact) |
| Voice signature | A line that could only belong to this narrator — distinctive perspective, idiom, viewpoint, a sentence that announces a SPECIFIC person, not "a person" |
| Concrete weirdness | A specific detail that does not fit the apparent ordinary world (a smell that shouldn't be there, a sound from a room that should be empty, an object out of place) |
| Intrusion | An external element disrupts the apparent setting (a sound, an arrival, a discovery, a knock, a call, an unwelcome thought) |
| Subversion | A statement that defies the expectation set by the surrounding tone — undercutting, ironising, reversing |
| Tonal mark | A genre-defining mood signal — see per-genre calibration below |

**Tonal mark — per-genre calibration (v2.7.114).**

The Architect MUST consult the active genre file's tone / mood /
pacing section when evaluating whether a designed Ch 1 opening
delivers a Tonal mark appropriate for that genre. The active genre
file is the canonical source of truth for that genre's tonal
calibration. The list below is illustrative for the most common
genre families; for any genre not listed (including custom
genres), the active genre file governs.

**Romance family:**

- **Romance** — emotional charge or chemistry between two people; a glance, a tension, an awareness that something is not casual
- **Contemporary** — the gap between the surface and what's underneath; voice that registers what the character is performing and what they aren't
- **Historical romance** — period sensibility (era-specific manners, language, social pressure) plus romantic charge — period detail does real work, not decoration
- **Dark romance** — psychological menace + erotic charge; desire warring with self-preservation, the wrong person felt as inevitable
- **Romantic suspense** — dread + chemistry locked together; the danger feels personal because of who's in it

**Thriller / suspense family:**

- **Thriller** — ticking-clock dread + momentum; the situation already moving, time pressure visible
- **Domestic thriller** — slow-burn domestic wrongness; a kindness that registers as menace, normality with a hairline crack
- **Psychological thriller** — subjective reality with a hairline crack the narrator hasn't named yet; the reader registers what the POV character cannot
- **Legal thriller** — procedural pressure + personal stakes; case logic moving against a clock that is also personal
- **Espionage** — tradecraft-level competence + quiet dread; an operative already at work, the cost of any misstep visible

**Mystery / crime family:**

- **Mystery** — the moment of the wrong, or its discovery: a body, a disappearance, an absent thing that should be there
- **Cozy mystery** — warmth + a hairline of off; a place the reader wants to stay in, with one detail that doesn't belong
- **Crime** — procedural texture under pressure; machinery of investigation visible alongside the human cost

**Sci-fi family:**

- **Science fiction** — precise observation of a world that operates by different rules; the character engaging the world, never the world being explained
- **Cyberpunk** — sensory overload + street-level voice; beauty in the ugly, noir-adjacent but never nihilistic
- **Dystopian** — walls closing in; a system pressure plausibly contemporary, the protagonist already in motion against it

**Fantasy family:**

- **Fantasy** — wonder + recognisability; a discovery that registers as both strange and earned, never a creation myth or map description
- **Epic fantasy** — scale + voice-specificity; a moment with weight and a viewpoint that announces its specific stakes
- **Urban fantasy** — mundane/magic collision; ordinary fractured by the supernatural, the city itself a character
- **Dark fantasy** — foreboding + moral cost; the price of power visible, deliberate build punctuated by violence

**Horror / literary / form:**

- **Horror** — wrongness before the event; unease and atmosphere, the protagonist's growing awareness that something is wrong before anything has happened
- **Literary** — voice IS the hook; a consciousness specific enough to inhabit, the quality of the prose itself the engagement
- **Women's fiction** — interior weight at a threshold; a woman at a hinge moment, her interior life as the substance
- **Coming-of-age** — the BEFORE state; a younger self caught at the moment before the change, specific enough that the reader will miss this person by the end

For all other genres (including dark academia, gothic, gothic
horror, magical-realism, litrpg, paranormal, paranormal romance,
horror romance, gothic romance, romantic comedy, romantic
thriller, sport romance, western, western romance, drama, comedy,
afrofuturism, cli-fi, fan fiction, family saga, adventure,
historical, historical fantasy, lgbtq fiction, middle grade,
noir, billionaire romance, erotica, ya contemporary, ya fantasy,
and any custom genre), the active genre file's tone / mood /
pacing section is the canonical source. The Architect MUST read
it before designing the Ch 1 opening.

**Banned Chapter 1 openings (regardless of opening-type classification):**

The following are STRUCTURAL anti-patterns — not "weak choices"
the Writer can polish around. If the Architect's designed opening
falls into any banned category, the brief MUST be restructured to
start at a different moment.

- Waking up / alarm clock / dream / morning bell / "She opened her eyes"
- Morning routine without intrusion (coffee, breakfast, getting ready, shower)
- Arrival at workplace or commute (driving in, walking in, parking, sitting down at desk, "Monday morning came")
- Getting-ready / grooming / clothes-selection openings
- Mirror description of the protagonist's physical features
- Weather alone — without complication or implication
- Backstory infodump (history before any present action)
- Vague atmospheric description without a specific, concrete, hook-bearing detail

These are documented in `opening-lines.md` § Anti-patterns. The
Architect MUST consult that section before finalising the Ch 1
brief and MUST NOT design openings that fall into any of these
categories.

**Why this gate is universal.** Earlier engine versions (through
v2.7.112) applied the strong opening gate only to the thriller
family. A v2.7.112 user reported a pattern across non-thriller
manuscripts: chapters opening with "a lot of mornings, arriving
at work, waking up." Diagnosis confirmed: the existing strong
Chapter 1 gate was thriller-restricted, the universal advisory
checklist ("□ NO STATIC OPENINGS") was advisory only, and
`opening-lines.md` reached the Writer but not the Architect — so
the Writer's craft framework could only optimise the FIRST
SENTENCE of an ordinary opening SCENE the Architect had already
locked in. v2.7.113 closes that gap: this gate applies to every
genre; it is enforced (not advisory); and `opening-lines.md` is
loaded into the Architect's context at brief-design time.

This is NOT a ban on the "Ordinary World" beat (Hero's Journey
beat 1). The Ordinary World is a STRUCTURAL position in the
story; it does not need to be the LITERAL OPENING MOMENT of
the manuscript. Start at or near the disturbance — the moment
the ordinary begins to crack — not in the ordinary itself.

---

### Chapter 1 Hook Gate — Thriller Intensifier (MANDATORY when thriller-family)

The universal gate above applies first; the constraints below
apply IN ADDITION when the genre is thriller, domestic-thriller,
psychological-thriller, espionage, legal-thriller, or any
suspense-family genre. Thriller Ch 1 briefs must satisfy both.

```
CHAPTER 1 THRILLER GATE (checked when building the Ch 1 brief):

□ Tension slider ≥ 7 (non-negotiable for thriller Ch 1)
□ Pacing Energy slider ≥ 7 (the reader must feel momentum)
□ Opening type: "mid-action" or "disruption" ONLY
  (never "discovery", "internal", "sensory-immersion", or "backstory")
□ Inciting threat visible by chapter end (not just hinted)
□ Zero breather scenes — or capped at 200 words total
□ At least ONE scene-level turning point or escalation
□ Chapter hook type: "new threat" or "revelation"
  (not "emotional gut-punch" alone — that's literary, not thriller)
□ Interiority budget: max 50 words per internal beat
  (character ACTS, then reflects BRIEFLY, then acts again)
□ Dialogue density: 40-50% of chapter by word count
```

**If the user provided their own outline:** Still apply this gate.
If the user's outline has a slow Ch 1 (setup-only, no threat, low
tension), flag it: *"Your Chapter 1 outline doesn't establish an
immediate threat — thriller readers expect to be hooked by page 3.
Suggest: [specific fix]. Approve the current outline or revise?"*
Do NOT silently accept a low-tension Ch 1 for a thriller.

**Domestic/psychological thriller adaptation:** The threat doesn't
need to be physical. For domestic thriller: the "wrongness" in the
domestic situation must be palpable by Ch 1 end. For psychological
thriller: the unreliable-narrator crack or atmosphere of unease must
be detectable from the first scene. The Tension slider still must
be ≥7 — it's just a different KIND of tension (dread, unease,
something-is-off rather than physical danger).

**How the Writer Uses Sliders:**
- **Tension 8+:** Short sentences, active verbs, physical action, minimal interiority
- **Dread 7+:** Longer sentences, atmospheric detail, sensory unease, things slightly wrong
- **Emotional Intimacy 7+:** Deep interiority, memory, vulnerability, sensory nostalgia
- **Relationship Tension 7+:** Loaded dialogue, physical awareness, subtext, avoidance behaviors
- **Pacing Energy 8+:** Rapid scene transitions, dialogue-heavy, minimal description
- **Humor 6+:** Wit in dialogue, ironic observations, comic timing in beats

### 3b. Opening Type

Specify the chapter's opening technique. Track across the manuscript to ensure variety.

**Opening Categories:**
- **Mid-action** — Character physically doing something (not walking, not waking)
- **Dialogue** — Opens with spoken words, mid-conversation
- **Sensory** — A specific smell, sound, taste, or texture grounds the reader
- **Internal** — Character mid-thought about a specific, concrete thing (not vague reflection)
- **Disruption** — Something unexpected breaks a routine or expectation
- **Discovery** — Character finds, notices, or encounters something new
- **Social** — Character in a group interaction (community, family, meeting)

**Rules:**
- No category used for more than 30% of chapters (max 9/30 for a standard novel)
- No consecutive chapters use the same category
- Weather/temporal openings ("Tuesday morning arrived with...") are NOT a valid
  category — they are BANNED as primary chapter openings. Weather and time-of-day
  can appear in the second or third sentence, but never the first.
- "Morning" should not appear in the first sentence of more than 4 chapters total
- Track which categories have been used and which are underrepresented

**Opening Type Tracker:**
Maintain a running log included in the Architect's context for each new chapter:
```
Ch 1: mid-action | Ch 2: discovery | Ch 3: dialogue | Ch 4: sensory | ...
```
When planning a new chapter, consult the log and choose an underused category.

### 4. Continuity Checklist
- Characters who must be referenced (even if not present)
- Plot threads that need advancement
- Details from previous chapters that must remain consistent
- New information introduced in this chapter

**Backstory-Heavy Chapter Warning (MANDATORY):**
Count the number of character-specific facts the Writer will need to handle in this
chapter (ages, relationships, backstory details, prior events, established traits,
location history, etc.).
- **5+ character facts required:** Flag as HIGH-RISK for continuity errors. Provide
  an explicit fact reference list in the brief with exact values from the Story Bible:
  ```
  CONTINUITY-CRITICAL FACTS FOR THIS CHAPTER:
  - {Character}: age {X}, born {year}, lives in {place} (Story Bible p.{N})
  - {Character}: relationship with {other} is {description} (established Ch{N})
  - {Event}: occurred on {date} at {location} (Ch{N})
  [list every fact the Writer must get right]
  ```
- **8+ character facts required:** Flag as VERY HIGH-RISK. Consider splitting into
  two scenes or two chapters to reduce fact density per scene.
- **Ensemble chapters** (3+ POV characters or 5+ named characters present): Always
  include the fact reference list regardless of count.

This prevents the Writer from guessing or inventing facts under cognitive load.
In testing, single-POV chapters produce 3-4 errors pre-fix while ensemble/backstory-heavy
chapters produce 6-8+. The fact reference list is the cheapest mitigation available.

### 4a. Stakes Escalation Check (MANDATORY)

Before finalising any brief, the Architect MUST verify that the chapter escalates
stakes over prior chapters. This check enforces the "Stakes Escalation" field from
the outline — every chapter must answer "How are the stakes higher now?"

```
STAKES ESCALATION CHECK:

1. Review the outline's Stakes Escalation entry for this chapter.
2. Review the previous chapter's brief and its stakes outcome.
3. Name the SPECIFIC escalation this chapter delivers:
   - What is at risk now that wasn't before?
   - What option has closed, what pressure has increased, what relationship
     has shifted, what resource has been lost?
4. If no concrete escalation can be named:
   - Add a complication to one scene that raises the stakes
   - OR deepen an existing complication so the consequences are more severe
   - DO NOT proceed with a brief that has no escalation — flat stakes
     produce flat chapters

STAKES LOG:
  Ch 1: [stakes established — {description}]
  Ch 2: [escalation — {description}]
  Ch 3: [escalation — {description}]
  ...
```

**Why this exists:** In testing, mid-manuscript chapters (especially domestic texture
and setup chapters) frequently maintained but did not escalate stakes. The beta reader
emotion map shows these chapters consistently scoring 60–65% — functional but flat.
Stakes must ratchet, not hold.

### 5. Knowledge State (for mystery/thriller genres)
- What the protagonist KNOWS at chapter start
- What the protagonist LEARNS in this chapter
- What the protagonist still DOESN'T KNOW
- What the protagonist is WRONG about

### 6. Beat Structure Target (if beat structure selected)

```
STORY BEAT: This chapter serves the "{beat_name}" beat.
Beat description: {beat_description}
Target position: {beat_percentage}% | Chapter position: {chapter_percentage}%
Status: [approaching / delivering / on-track]

If APPROACHING: Plan scenes that build toward this beat. The beat should land
in this chapter or the next.
If DELIVERING: Plan scenes that clearly accomplish this beat. The reader should
feel this structural moment.
If ON-TRACK: The beat has been delivered. Build toward the NEXT beat:
"{next_beat_name}" at {next_percentage}%.
```

Include in the brief which beat this chapter serves and how each scene
contributes to it. The Writer needs to know the structural purpose.

### 6a. Climax Brief Enhancement (MANDATORY for climax chapters)

When this chapter delivers the climax beat (or is within 10% of the climax
position in the beat structure), the Architect MUST apply these additional rules:

```
CLIMAX BRIEF RULES:

1. SLIDER COMPARISON — Review the slider history for the entire manuscript so far.
   Identify the current maximum Tension score across all prior chapters.
   - This chapter's Tension slider MUST exceed that maximum by at least 1 point
   - If the current manuscript peak is Tension: 8, this chapter must be Tension: 9+
   - If this is not achievable (prior peak is already 10), then the chapter must
     match 10 AND the Emotional Intimacy slider must also be ≥ 7 (dual-peak)

2. EMOTIONAL STAKES — The brief must explicitly name:
   - What the protagonist stands to lose in THIS chapter (concrete, specific)
   - Why THIS moment is worse than any prior crisis (escalation justification)
   - The cost of the protagonist's choice (what they sacrifice to act)

3. SCENE INTENSITY — Every scene in the climax chapter must have:
   - A clear turning point (no transitional or setup-only scenes)
   - Physical consequence (something changes in the material world, not just
     emotionally)
   - At least one moment of genuine uncertainty for the reader

4. POST-CLIMAX CONSEQUENCE (for resolution chapters immediately following):
   - The brief must include at least one institutional or systemic reflex beat:
     a legal threat, a professional reprisal, a social consequence, or an
     attempt to suppress/discredit the protagonist's action
   - This shows the system's response to the protagonist's climax action
   - Resolution chapters without counterpressure feel consequence-free
```

**Why this exists:** In Clean Label, the climax chapter (Ch 15, "The Article")
scored 80% on the beta reader's emotion map while the data reveal (Ch 8) scored
95% and the notebook reveal (Ch 11) scored 85%. The book's emotional peak was in
Act 2, not Act 3. The climax was structurally correct but emotionally under-served
because the brief didn't require it to exceed prior peaks.

### 7. Chekhov's Gun Instructions (if guns are active)

```
PLANT: If this chapter introduces a Chekhov's Gun:
  Gun: "{gun_name}" — {description}
  Instruction: Include this element naturally within Scene [N].
  It should feel incidental — one detail among many. Do NOT spotlight it.

PAYOFF: If this chapter pays off a Chekhov's Gun:
  Gun: "{gun_name}" — originally planted in Chapter {N}
  Instruction: This element becomes significant in Scene [N].
  Include a brief sensory callback to the original introduction.

AWARENESS: List all active (planted but unpaid) guns.
  Do not accidentally reference or resolve them in this chapter.
```

### 7a. New Chekhov Guns (MANDATORY — default: none)

**This section defaults to EMPTY. Populating it requires deliberate justification
and is checked by the Outline Conformance Agent before the user approves the brief.**

The Architect may NOT invent new Chekhov guns during chapter generation unless
ALL of the following are true:

1. **Section 14 has room** — there are enough remaining chapters for the new
   gun to fire without displacing a planned beat. Minimum distance between
   plant and fire is 3 chapters.
2. **No planned beat is displaced** — if firing the new gun requires a chapter
   that Section 12 already assigns to another beat, the plant is REFUSED.
3. **The gun serves the story, not the moment** — new guns invented because
   "it would feel natural here" are the most common drift pattern. Ask: is
   this gun essential to the planned ending? If no, hold for the next book.

If a new gun is genuinely required, populate this brief section:

```
NEW GUN PROPOSAL (requires Outline Conformance check + user approval):
  Gun: "{name}" — {one-sentence description}
  Rationale: {why this gun is essential to the story now}
  Plant chapter: {this chapter}
  Planned fire chapter: {specific chapter N; must be a chapter with room}
  Displacement: none | displaces beat "{beat text}" from Ch{N}
  Approval status: PENDING USER APPROVAL
```

**The Outline Conformance Agent (see `outline-conformance.md`) will read this
section and FAIL the brief if any of the following are true:**
- `NEW GUN PROPOSAL` is populated without a rationale
- `Planned fire chapter` is beyond the total chapter count
- `Planned fire chapter` has less than 3 chapters of runway from the plant
- `Displacement: none` is claimed but all remaining chapters are already
  spoken for in Section 12

**If the user approves a new gun:** Section 14 is updated to include it,
Section 12 is updated to mark the fire chapter, and the
`engine-data/chekhovs-guns.md` tracker is updated. The new gun becomes
canonical and subsequent conformance checks treat it as pre-planned.

**Historical note for why this rule exists:** In production, the Architect
invented a new gun in Ch9 (a folded paper handed to the protagonist without
explanation). The gun was coherent and the user approved the brief. But
firing the gun consumed Ch10, Ch11, and Ch12 — three chapters that Section
12 had earmarked for a pinch point, a city chase, and a war-room scene.
All three planned beats silently fell off the calendar because no agent was
checking whether the new gun had room. This rule closes that gap.

### 8. Word Count Target & Scene Budget

**Chapter Target:** {words_per_chapter} words (±10%)
**Chapter Floor:** {words_per_chapter × 0.9} words — chapters below this are REJECTED

#### Scene Word Budget Calculator (MANDATORY)

The Architect MUST calculate per-scene word budgets using this formula:

```
base_per_scene = words_per_chapter ÷ number_of_scenes

Then apply scene-type multipliers:
  Action/climax scene:      × 1.3
  Emotional confrontation:  × 1.2
  Dialogue-heavy scene:     × 1.1
  Transition/setup scene:   × 0.8
  Quiet character scene:    × 0.9

Round to nearest 50.

INFLATION BUFFER (MANDATORY):
After calculating all scene budgets, multiply the TOTAL by 1.10 (110%).
The Writer systematically compresses prose by 10-20% versus planned budgets.
Compensate at the planning stage — not the revision stage.

Verify total ≥ words_per_chapter × 1.10.
```

**Output format — include in EVERY brief:**
```
SCENE WORD BUDGETS:
  Scene 1 — [title] — [type]: ~{budget} words
  Scene 2 — [title] — [type]: ~{budget} words
  Scene 3 — [title] — [type]: ~{budget} words
  SUBTOTAL: {sum} words
  WITH 10% INFLATION BUFFER: {sum × 1.10} words
  CHAPTER TARGET: {words_per_chapter} words
```

**Validation rule:** If the sum of scene budgets (with inflation buffer) < chapter target × 1.10,
the Architect MUST either add a scene, expand an existing scene's scope, or increase
dramatization depth (see below) until the buffered total meets the inflated target.

#### Dramatization Depth Guidance (MANDATORY — per scene)

For each scene, the Architect MUST specify how to fill the word budget. This section
is **non-optional** — every scene in every brief must include dramatization notes.

```
DRAMATIZATION NOTES:
  - Dialogue density: [high | medium | low] — e.g., "3-4 exchange rounds in Scene 2"
  - Interiority beats: [number] — e.g., "2 internal reflection moments"
  - Sensory grounding: [specific senses] — e.g., "smell of the bakery, texture of flour"
  - Physical business: [actions] — e.g., "character fidgets with keys, paces the room"
  - Environmental texture: [details] — e.g., "describe the bar's décor, lighting, crowd noise"
```

These notes tell the Writer WHERE the words go. Without them, the Writer defaults to
thin scenes and the chapter runs 20%+ short.

**BEAT DENSITY RULE:** Plan 8-10 beats per scene for a ~900-word scene, not 5-6.
The Writer compresses each beat to 80-100 words in practice, not the 150+ words
you might expect. If a scene has only 5 beats and a 900-word budget, the Writer
will produce ~450 words and move on. More beats = more material = closer to budget.

#### Word Budget Validation (MANDATORY)

After completing the dramatization notes for each scene, the Architect MUST validate
that the planned content can fill the word budget. Use these estimates:

```
WORD BUDGET VALIDATION:
  Dialogue exchanges:    count × ~50 words each  = {estimated}
  Interiority beats:     count × ~75 words each  = {estimated}
  Sensory grounding:     count × ~40 words each  = {estimated}
  Physical business:     count × ~30 words each  = {estimated}
  Environmental texture: count × ~40 words each  = {estimated}
  ESTIMATED TOTAL: {sum} words
  SCENE BUDGET:    {budget} words
  COVERAGE:        {sum/budget × 100}%
```

- If COVERAGE is below 80%: add more dramatization content (more dialogue exchanges,
  more interiority, more sensory beats) until coverage reaches 80%+
- If COVERAGE is above 120%: the scene may run over budget — consider splitting or
  trimming planned content
- The Writer uses these notes as a concrete plan, not a suggestion

**Why this is mandatory:** In both the Cozy Mystery test (avg 80% of target) and
Clean Label (6 chapters needed expansion passes), the Writer consistently produced
thin scenes when the brief lacked specific dramatization guidance. The word budget
validation makes under-delivery visible at the planning stage, before prose is written.

#### Running Word Count Log

After each chapter is generated, record in the brief context for subsequent chapters:
```
WORD COUNT HISTORY:
  Ch 1: {actual}/{target} ({percentage}%)
  Ch 2: {actual}/{target} ({percentage}%)
  ...
  Running average: {avg_percentage}%
```

If running average drops below 95%, add to the next Architect brief:
```
WARNING: Manuscript running short ({avg}% of targets). This chapter's brief
MUST provide enough material for at least {target × 1.05} words. Add scene
depth, not scene count — expand dramatization, not plot points.
```

#### Tension & Pacing Tracker (MANDATORY — update after EVERY brief)

After finalising the narrative pacing sliders for this chapter, append the planned
values to the persistent tension tracker file. This file is the single source of
truth for pacing data across the manuscript — the Architect reads it before every
brief, the Arc Analyst updates it with actual delivered values after verification,
and the Batch Editor reads it for cross-chapter analysis.

**Update file:** `Ideorix-Projects/[Title]/engine-data/tension-tracker.md`

**If the file doesn't exist** (first chapter), create it with this format:
```markdown
# Tension & Pacing Tracker — {Title}

## Slider History

| Ch | T(plan) | T(actual) | D(p) | D(a) | EI(p) | EI(a) | RT(p) | RT(a) | PE(p) | PE(a) | H(p) | H(a) | Primary Dim | Escalated? |
|----|---------|-----------|-------|-------|-------|-------|-------|-------|-------|-------|------|------|-------------|------------|

## Escalation Log

| Ch | Primary Dimension | Escalation Description |
|----|-------------------|----------------------|

## Trajectory Summary

- Consecutive non-escalating chapters: 0
- Act 1 peak (primary dim): —
- Act 2 peak (primary dim): —
- Act 3 peak (primary dim): —
- Manuscript peak: —
- Genre primary dimension: {loaded from genre bank}
```

**After generating each brief**, append a row to the Slider History table with
the PLANNED values (T(plan), D(p), EI(p), RT(p), PE(p), H(p)). Leave the
"actual" columns blank — the Arc Analyst fills those after verification.

Also update the Escalation Log with the specific escalation this chapter delivers
(from the Stakes Escalation Check, Section 4a).

**How agents use this file:**
- **Architect:** Reads the Slider History before every brief to ensure pacing variety
  (replaces the inline SLIDER HISTORY block — the tracker file is now authoritative)
- **Arc Analyst:** After verification, fills in the "actual" columns with delivered
  values and updates the Trajectory Summary (consecutive non-escalating count, peaks)
- **Batch Editor:** Reads the full tracker for Analysis 2 (Pacing Trajectory) instead
  of reconstructing slider data from individual briefs
- **Emotional Auditor:** References the tracker to validate that the outline's planned
  pacing matches the delivered pacing across acts

## Output

**Brief file write protocol (v1 — audit footer consolidated):**

The Architect does NOT write the brief file directly. Instead:

1. The Architect produces the full brief content in memory.
2. The brief content is passed to the Outline Conformance Agent
   (step 5a in `core-pipeline.md`) as its input.
3. The OC Agent runs its 6 checks, produces an audit footer, and
   writes the combined `brief content + audit footer` to
   `engine-data/chapter-briefs/ch{NN}-brief.md` in a single Write
   tool call.
4. The audit footer is wrapped in `<!-- IDEORIX:AUDIT:BEGIN v1 -->` /
   `<!-- IDEORIX:AUDIT:END -->` HTML-comment markers. See
   `outline-conformance.md` for the marker format and the 100-line
   cap + overflow handling.

This consolidates the OC audit into the brief file rather than
producing a separate `ch{NN}-outline-conformance.md` report file,
reducing per-chapter file count.

**Legacy mode (pre-hardening projects):** If the session is running
in legacy-pre-hardening mode (see `core-pipeline.md` Graceful
Degradation for Pre-Hardening Projects), the Architect writes the
brief directly to the brief file without the audit footer, because
step 5a OC Agent is skipped in legacy mode.

### Loading an existing brief file for downstream use

When the Architect — or any other agent — needs to read an existing
brief file (e.g., for reference, for resuming a chapter, for batch
analysis), **always strip the IDEORIX:AUDIT block first**:

1. Read the brief file with the Read tool.
2. Remove everything between `<!-- IDEORIX:AUDIT:BEGIN v1 -->` and
   `<!-- IDEORIX:AUDIT:END -->` (inclusive of the markers). The
   strip is greedy across newlines; a regex like
   `<!-- IDEORIX:AUDIT:BEGIN v\d+ -->.*?<!-- IDEORIX:AUDIT:END -->`
   with DOTALL enabled does the job.
3. The remaining content is the pure brief — use that for downstream
   operations.

The version tag (`v1`) in the BEGIN marker allows future audit
schema changes; the strip regex matches any version number so older
briefs continue to work when the schema evolves.

After the OC Agent writes the combined brief + audit file, proceed
to the USER REVIEW GATE at the end of this document.

### 9. Content Intensity Ratings (MANDATORY)

Rate the planned content intensity for this chapter. These are set during outline
creation (Phase 2B) and the Architect includes them in every brief.

```
CONTENT INTENSITY:
  Spice Level:    [0-5] — Intimate/sexual content (0 = none, 5 = explicit)
  Violence Level: [0-5] — Physical violence/gore (0 = none, 5 = graphic)
  Swearing Level: [0-5] — Profanity frequency (0 = none, 5 = heavy throughout)
```

**Rating Scale:**
| Level | Spice | Violence | Swearing |
|-------|-------|----------|----------|
| 0 | None — closed door | None | None |
| 1 | Attraction/flirting only | Implied or offscreen | Mild ("damn", "hell") |
| 2 | Kissing, mild tension | Brief, non-graphic | Moderate, occasional |
| 3 | Fade-to-black with buildup | Action sequences, some detail | Regular but natural |
| 4 | On-page with some detail | Detailed combat/injury | Frequent, character-appropriate |
| 5 | Explicit, extended scenes | Graphic, visceral | Heavy, pervasive |

**Rules:**
- Ratings must be consistent with the project-level content boundaries set in Phase 1
- The Writer uses these to calibrate prose intensity — a Violence:1 chapter does NOT
  contain detailed fight choreography; a Spice:0 chapter has NO physical intimacy
- Ratings should arc appropriately across the manuscript (e.g., romance spice typically
  escalates from 1-2 in Act 1 to 3-4 in Act 2-3)
- The Quality Guardian validates that written content matches the rated intensity

### 10. Cliffhanger & Chapter Ending Guide

Every chapter ending must pull the reader into the next chapter. The Architect specifies
the ending technique for each chapter.

**5 Cliffhanger Types:**

| Type | Description | Best For | Example |
|------|-------------|----------|---------|
| **Reversal** | A certainty is overturned — what the character believed is wrong | Mid-act chapters, after investigation scenes | "The alibi checked out. Every detail matched. Which is why Mary froze when she found the receipt dated three days earlier." |
| **New Threat** | A new danger or complication emerges | Act transitions, escalation points | "She locked the door, slid the chain. Then her phone buzzed: a photo of her kitchen, taken from inside." |
| **Revelation** | A hidden truth surfaces — changes everything the reader thought they knew | After clue-gathering, midpoint | "The handwriting on the note was familiar. She'd seen it every morning for twelve years — on the grocery list stuck to their fridge." |
| **Impossible Choice** | Character must decide between two painful options | Character development chapters, moral dilemmas | "Save the evidence and let Marcus walk away. Or destroy it and keep the one person who still believed in her." |
| **Emotional Gut-Punch** | An emotional blow that recontextualizes the chapter | Relationship chapters, betrayal scenes | "He hadn't come to apologise. He'd come to say goodbye. The suitcase by the door wasn't for a trip." |

**Rules:**
- **Vary endings** — no technique used more than 30% of the time across the manuscript
- **Final chapter exception:** The last chapter gets a "gentle glide path" — climactic resolution
  followed by decompression beats. NO cliffhanger. The reader needs closure.
- **No manufactured tension:** Cliffhangers must arise organically from the chapter's events.
  If you need to inject external surprise to create a hook, the chapter's plot isn't strong enough.
- **What makes a cliffhanger feel cheap:**
  - Withholding information the POV character clearly has ("She gasped when she saw who it was.")
  - Interrupting before a natural stopping point with no story reason
  - Introducing something never foreshadowed ("Suddenly, a helicopter appeared.")
  - Dream sequences or fake-outs that reset the next chapter
- **Track ending types** alongside opening types:
  ```
  ENDING LOG: Ch1: revelation | Ch2: new-threat | Ch3: emotional-gut-punch | ...
  ```

## Anti-Patterns (NEVER do these)

- **Vague beats:** "Something interesting happens" — ALWAYS be specific
- **Missing conflict:** Every scene needs resistance or tension
- **Emotional flatline:** No chapter should maintain one mood throughout
- **Continuity gaps:** Never ignore events from previous chapters
- **Frontloading exposition:** Start mid-action, not with recap
- **Manufactured cliffhangers:** Exit hooks must be organic, not forced

---

## Architect's Guardrail Checklist (MANDATORY — run before presenting brief to user)

This checklist is the Architect's final quality gate before the brief reaches the
user. Run it AFTER the brief is complete but BEFORE saving and presenting.

**Why this exists:** In testing, briefs that passed all structural requirements still
produced weak chapters because they lacked conflict specificity or had static scenes.
This checklist catches brief-level problems that are expensive to fix at the prose stage.

```
BRIEF QUALITY GUARDRAILS (every brief, every genre):

□ EVERY SCENE HAS CONFLICT — For each scene in the breakdown, can I name the
  specific resistance or obstacle? If a scene has a goal but no conflict,
  add one before finalising.

□ JUST TALK TEST — For each scene where 2+ characters interact: if I remove
  all dialogue, does something still HAPPEN in the scene? Are characters DOING
  something physical while talking? If any scene is just two people sitting
  and exchanging information, add physical business, movement through space,
  or a material change to the environment.

□ MATERIAL CONSEQUENCES — Does at least one scene produce a change in the
  physical world? (Door locked, object found, document signed, meal burned,
  gift given, evidence destroyed.) If all scenes end with only emotional or
  informational change, add a material consequence to at least one.

□ STAKES NAMED — Can I state in one sentence what the POV character stands
  to lose in this chapter? If not, the chapter lacks focus — add specific stakes.

□ ESCALATION VERIFIED — Are the stakes higher than the previous chapter?
  (See Stakes Escalation Check in Section 4a.) If stakes are flat, add a
  complication.

□ NO STATIC OPENINGS — Does the chapter open mid-action or mid-tension?
  If the first scene starts with arrival, waking up, or setup, restructure
  to start at the point of interest.

□ SENSORY PALETTE COMPLETE — Does the Worldbuilding Brief for each scene
  include at least 2 non-visual senses? If all sensory notes are visual,
  add smell, touch, or sound.

□ WORD BUDGET REALISTIC — Does the dramatization depth (dialogue exchanges,
  interiority beats, sensory grounding, physical business) add up to ≥80%
  of each scene's word budget? If not, add more dramatization notes.

□ INFORMATION DISCOVERY TEST — For each scene where the POV character
  discovers, analyses, or processes significant information (data, documents,
  evidence, research, technical findings): is the discovery DRAMATISED or
  REPORTED? A character sitting alone reading documents and thinking is a
  briefing, not a scene. To pass this test, information-heavy scenes must
  include at least ONE of:
  - A second character present (creates interpersonal friction during discovery)
  - A time pressure or interruption (the phone rings, someone arrives, a
    deadline looms)
  - A physical action interleaved with the analysis (walking, eating, fixing
    something — the body stays active while the mind works)
  - An emotional cost or consequence discovered in the information itself
    (not just "I found out X" but "X changed how I feel about Y")
  Solo-investigation scenes are permitted but must not exceed 30% of any
  chapter's scenes. If a chapter is ALL solo analysis, add an interpersonal
  beat — even a phone call, a knock on the door, or a neighbour walking past.

GENRE-SPECIFIC GUARDRAILS:
Load from the active genre bank file's Architect Instructions section.
Examples:
- Mystery: "Is suspect balance maintained? Does this chapter plant or advance
  exactly the scheduled clues?"
- Romance: "Does the relationship dynamic shift in this chapter? Is there
  at least one almost-moment or proximity beat?"
- Thriller: "Is the ticking clock advancing? Does the chapter end with
  higher urgency than it started?"
- Horror: "Does dread escalate through the chapter? Is there at least one
  wrongness detail the character can't explain?"

MASH-UP GUARDRAILS (if Mash-up: yes in project-config.md):
The Architect receives a merged genre block assembled from Primary + Secondary
(+ Tertiary) genre files. Each sub-block is prefixed with an attribution
header like `### From Cozy Mystery (Primary):` so the Architect can reason
about rule sources.

When building the chapter brief:
1. Every scheduled beat from EVERY active genre must be present somewhere in
   the outline — not just the Primary's beats. A Cozy Mystery + Fantasy
   mash-up needs clue schedules AND magic-system reveals.
2. If two genres' guardrails conflict within a single chapter (e.g.,
   Primary says "end with a clue revelation", Secondary says "end with a
   growth-ladder breakthrough"), PRIMARY wins by default — but the brief
   must note that the Secondary beat shifts by one chapter and must still
   land before the act break.
3. Surface any UNRESOLVABLE conflict to the user via the User Review Gate.
   Do NOT silently drop a genre's rule. If a Primary beat truly cannot
   co-exist with a Secondary beat in this chapter, state it: "Cozy Mystery
   needs a small-community social beat here; Thriller wants a time-pressure
   escalation. I've folded both — the time pressure comes from the social
   beat itself (the tea party has a hard stop at 3pm). Approve?"
4. The chapter title and summary must reflect ALL active genres' reader
   expectations, not only the Primary's.
```

If ANY guardrail fails, revise the brief before saving. Do not present a brief
to the user that fails any guardrail check.

---

## USER REVIEW GATE (MANDATORY — FINAL STEP — NEVER SKIP)

This is the LAST thing the Architect does. After the brief is saved to disk:

1. **STOP.** Do not call the Writer. Do not start writing prose.
2. **Present the complete brief** to the user — show the full content, not a summary.
3. **Use AskUserQuestion** to ask the user to approve, edit, or add notes.
   Do NOT use a plain text message — use the interactive AskUserQuestion tool
   so the pipeline physically cannot proceed without a user response.
4. **WAIT for the user's response.** Do not proceed until they reply.

**AskUserQuestion options:**
- "Approve — start writing" → proceed to Writer
- "I want to edit this brief" → user provides changes, revise and re-present
- "Add notes for the Writer" → user provides notes, attach them and proceed

The user may also type a freeform response with specific changes.

**This gate exists because the brief is a CONTRACT. The user must sign off before
the Writer executes it. Skipping this step means the user loses creative control
over chapter direction. NEVER skip it. NEVER auto-approve.**

**ENFORCEMENT:** This gate was skipped in every test run despite being documented
as mandatory. The failure mode is: the engine generates the brief, displays it as
text, and immediately proceeds to writing without waiting for user input. Using
AskUserQuestion instead of plain text output makes this structurally impossible —
the tool blocks until the user responds. If you find yourself about to call the
Writer without having received an AskUserQuestion response for this chapter's
brief, STOP. You are violating the gate.
