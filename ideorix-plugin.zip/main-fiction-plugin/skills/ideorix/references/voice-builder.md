---
name: voice-builder
description: "Build a reusable author voice profile — from scratch or from a writing sample — and attach it to a pen name"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine

# Voice Builder

## File Location Discipline (MANDATORY)

**All voice profile outputs MUST be written into the canonical
project folder at `~/Documents/Ideorix-Projects/[Title]/`** (or
the cross-project pen-name voice library where applicable). If
no project folder exists when this tool is invoked directly,
run the project-folder bootstrap (ask for project title /
confirm save location / create the canonical folder structure)
BEFORE generating the voice profile. See `core-pipeline.md`
§ File Location Discipline for the canonical layout and the
Bash-Direct Write + Verify protocol. **HARD GATE — BLOCKING.**
Outputs MUST resolve to local files the user can open in their
own file explorer.

Build a unique, reusable author voice profile that travels with your pen name and holds
across every project you write. Your voice is the fingerprint on the page — it's what
makes *your* thriller sound different from every other thriller on the shelf.

## What You Can Do

1. **Build a new voice** — Create a voice profile from scratch using guided conversation + test-drive samples
2. **Build from a sample** — Paste or upload existing writing and the engine extracts your voice
3. **View my voices** — Browse saved voice profiles with summaries and sample passages
4. **Edit a voice** — Refine any dimension of an existing voice profile
5. **Test-drive a voice** — Generate a sample passage in any saved voice to hear how it sounds
6. **Attach to pen name** — Link a voice profile to a pen name (or detach/reassign)
7. **Back to main menu**

## How It Works

The Voice Builder creates a complete **Voice Profile** — the same format used by the
editorial pipeline (Stage 0) — so your voice is understood by every agent in the engine:
the Writer, the Humaniser, the editors, and the quality gate.

Three ways to build a voice:

### Path A: Guided Build (recommended for new voices)
A short conversation about how you want to sound, followed by test-drive passages you
react to until the voice clicks. Takes 5-10 minutes.

### Path B: Extract from Writing
Paste 500+ words of your existing prose. The engine analyses it and generates a Voice
Profile automatically. Best when you already have a voice you want to replicate.

### Path C: Hybrid
Start with the guided conversation, then calibrate against a writing sample. The engine
reconciles both inputs into a single profile. Most accurate result.

## What Gets Saved

Each voice profile includes:
- **Writer Profile** — age bracket, experience level, genre background, literary influences
- **7-dimension Voice Profile** — sentence architecture, vocabulary, narrative stance, dialogue, pacing, metaphor, imagery
- **Voice Summary** — 3-5 sentence fingerprint
- **Sample Passage** — 300-word reference passage demonstrating the voice in action
- **Pen Name Link** — which pen name uses this voice (if any)

Voice profiles are saved to your local Ideorix Projects folder and persist across all projects.
When you select a pen name that has a linked voice, the voice loads automatically as your Style Guide.

> Protocol: `voice-builder-protocol.md`
