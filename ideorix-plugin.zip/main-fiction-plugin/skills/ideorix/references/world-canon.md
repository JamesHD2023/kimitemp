---
name: world-canon
description: "3-phase Story Bible generation protocol"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->
# Story Bible Generation Protocol

## Overview

The Story Bible is the single source of truth for all story elements. Every agent references
it. Without a Bible, characters drift, timelines break, and locations change between chapters.

This protocol mirrors Ideorix's 3-phase Story Bible generation.

## Story Bible Integrity Rule — Always Full Content (MANDATORY)

**Every time the Story Bible is written, every section must contain its
complete current content. NEVER use elision placeholders or references
to a "previous version".**

Forbidden patterns in ANY Story Bible section:

- `*(Unchanged from previous version)*`
- `*(See original entries for...)*`
- `*(See previous draft...)*`
- `[content omitted — same as last draft]`
- `[see earlier version]`
- Any language that refers to a "previous version", "original",
  "prior draft", "earlier version", or "last draft" as a separate
  source the reader can consult

**Why:** There is no "previous version" on disk. The Story Bible is
a single file. The moment you write a reference to a previous version,
you have destroyed the content the reference points at. Every
downstream agent that reads the Bible programmatically — the
Architect, the Writer, the Continuity Guardian, the Outline
Conformance Agent, the Canon Compliance Check — sees the placeholder,
not the rules. The protection falls silent. A Bible section that
reads "Unchanged from previous version" gives the Writer no magic
rules to obey, the Continuity Guardian no canon to check against, the
Architect no specification for planning.

**The rule:**

1. When editing the Bible, READ the existing file in full first.
2. Hold every section's content in memory.
3. Modify only the sections that need to change.
4. When writing the updated Bible, output every section's complete
   content — modified or not.
5. If a section is unchanged from the last read, COPY ITS VERBATIM
   CONTENT from the in-memory read into the new write. Do not compress
   to a shorthand marker. Do not write a reference back to a version
   that will no longer exist after your Write tool call returns.

**Elision is destruction, not preservation.** Writing
*"Unchanged from previous version"* deletes the content that was
previously there — because the previous version was the file you are
about to overwrite. The next time an agent reads the Bible, it sees
the placeholder and has no recourse.

This rule applies to every Phase 2 generation (Foundation, Plot,
Entity Extraction, Entity Canon, Series Continuity) AND to every
later update the user requests ("revise Section 5 with the new theme",
"update the character list with Marcus's new tic", etc.). Partial
updates must rewrite the full file with every section's complete
content. The Write tool is not diff-aware — it replaces the file
whole.

**Self-check before every Story Bible Write tool call:** Does any
section I'm about to write contain the string "previous version",
"original", "prior draft", "earlier version", or "see previous" as
a reference? If yes, STOP, retrieve the actual content from my
in-memory read of the existing Bible, and replace the placeholder
with the verbatim content. Only then write.

## When to Generate

- **New project with AI outline:** Generate after outline approval (Phase 2)
- **New project with user outline:** Generate from user's outline
- **Imported manuscript:** Reverse-engineer from existing chapters

## Phase 2 Content Discipline (MANDATORY — applies to 2A, 2B, and 2C)

### Expansion vs Invention vs Contradiction

Every element the Story Bible generator adds falls into one of three
categories. The generator MUST classify each addition correctly,
because they carry different costs:

**EXPANSION (low risk, permitted):**
Detail that fills a gap the outline or architecture deliberately left
open. The architecture says "Helen: tired, half-sentences, grey
temples" — the Story Bible expands this into a full character profile
with wardrobe, speech rhythms, and physical mannerisms. Expansion is
IN-BOOK ONLY: it adds reader-facing detail that doesn't contradict
the architecture and doesn't create persistent cross-book obligations.

- Example: Marlo's hoodie colour (architecture didn't specify)
- Example: Nell's freckles (architecture didn't specify)
- Example: The pub's name (architecture left it unnamed)
- Cost: low. Changes are contained to this book.

**INVENTION (medium risk, requires PLACEHOLDER or user approval):**
Adding a persistent NAMED element with downstream continuity cost —
a character name, a place name, a named object, an animal, a
relationship, a backstory detail that will need to be consistent
across future books. Inventions are CROSS-BOOK: they carry forward.

- Example: Naming a pet "Pip" (now every book must include Pip)
- Example: Adding a named boat "Dewi" (carries to Book 2+ if it
  appears in prose)
- Example: Placing a specific historical reference (now canon)
- Cost: medium. Creates continuity obligations the Series Bible
  must track.

**CONTRADICTION (high risk, FORBIDDEN):**
Breaking an architecture lock — deploying a character, plot element,
clue, reveal, or timeline event that the series architecture assigns
to a different book or chapter. Contradictions are STRUCTURAL ERRORS
that undermine the series plan.

- Example: Surfacing "Penvose" in Book 1 when the architecture says
  Penvose doesn't appear until Book 2 Chapter 12
- Example: Overriding a clue-timing mechanism ("Thursday reveal")
  that the architecture locks to a specific chapter
- Example: Revealing a character's backstory in Book 1 that the
  architecture holds back until Book 3
- Cost: high. Breaks the series plan and requires either a retcon
  or an architecture revision.

### Classification rule

Before writing ANY named element into the Story Bible that doesn't
have a direct citation in the outline or series architecture:

1. **Ask:** Is this element in the outline or architecture? If yes,
   it's a CITATION — use it verbatim. No classification needed.
2. **Ask:** Does this element create a cross-book obligation? If no,
   it's an EXPANSION — permitted, but note it in the traceability
   pass (see below).
3. **Ask:** Does this element create a cross-book obligation? If yes,
   it's an INVENTION — use a [PLACEHOLDER] tag instead of silently
   naming it. The user approves inventions at the Story Bible
   Approval Gate.
4. **Ask:** Does this element contradict anything in the architecture?
   If yes, it's a CONTRADICTION — STOP. Do not write it. Flag it
   to the user immediately.

### Placeholder Convention (for Inventions)

Anything not sourced from the outline or architecture that carries a
cross-book continuity cost gets a placeholder tag instead of a
silently invented name:

```
[PLACEHOLDER: pet name — suggestion: Pip / Nipper / Other]
[PLACEHOLDER: boat name — suggestion: Dewi / Morwenna / Other]
[PLACEHOLDER: house name — suggestion: Gull Cottage / Cliff House / Other]
```

The user sees all placeholders at the Story Bible Approval Gate and
approves (or replaces) each one. Nothing ships named-by-the-engine
without the user's explicit nod.

**Placeholders are NOT needed for expansions** (in-book-only detail
like wardrobe colour, speech rhythms, room layouts). Only for
inventions with cross-book cost.

### Traceability Pass (MANDATORY — before presenting Story Bible)

Before the Story Bible is presented to the user at the Approval Gate,
the generator runs a traceability pass. Every element in the Bible
must either:

**(a) Trace to architecture with citation:**
```
Helen Pascoe — "tired, half-sentences, grey temples"
  Source: Series Architecture Section 9, Character Matrix
  Classification: CITATION
```

**(b) Be flagged as expansion with one-line justification:**
```
Helen's cardigan (navy, pilled at the elbows)
  Source: not in architecture (expansion)
  Classification: EXPANSION — in-book wardrobe detail, no cross-book cost
```

**(c) Be flagged as invention with [PLACEHOLDER]:**
```
Helen's cat [PLACEHOLDER: cat name — suggestion: Smudge / Other]
  Source: not in architecture (invention)
  Classification: INVENTION — named pet carries to Books 2-3
  Downstream cost: must appear in every book at Helen's cottage
```

The traceability pass is reported at the TOP of the Story Bible
when presented to the user:

```
TRACEABILITY SUMMARY:
  Citations (from architecture): {N} elements
  Expansions (in-book only): {N} elements
  Inventions (cross-book, [PLACEHOLDER]): {N} elements — REQUIRE YOUR APPROVAL
  Contradictions found: {N} — {listed if any}
```

If any contradictions are found, STOP and resolve them before
presenting the Story Bible.

### Series projects — additional checks

For series projects (where `series-data/series-bible.md` exists),
the traceability pass ALSO checks every Story Bible element against:

- **Series Bible character trajectories** — does this book's character
  state match where the trajectory says they should be at this volume?
- **Arc Weave Matrix** — does this book's plot deploy the correct
  threads for this volume position?
- **Cross-book seed inventory** — does this book plant the seeds the
  architecture assigns to it, without pre-firing seeds assigned to
  later books?
- **Long-range Chekhov's Guns** — are series-level guns tracked
  correctly (setup in the right book, payoff in the right book)?

A Story Bible for Book 1 that references Book 2 content is a
CONTRADICTION, not an expansion.

---

## Phase 2A: Foundation

Generate sections 1-6 of the Story Bible.

### System Prompt

```
You are a Story Architect building the canonical reference document for a
{genre} {length_tier}. This document will be the SINGLE SOURCE OF TRUTH
that all writing and verification agents reference.

{genre_architect_instructions}

CRITICAL: Every detail you establish here is CANON. Agents will flag
contradictions against this document. Be precise and specific.
Do not use vague descriptions — give exact details that can be verified.
```

### Required Sections

**1. Core Concept**
- Premise (1-2 sentences)
- Central conflict
- Tone and atmosphere
- Thematic throughline

**2. Themes**
- Primary theme (with how it manifests in plot)
- Secondary themes (2-3)
- Thematic question the story asks

**3. POV & Narrative Style**
- POV type (first person, third close, etc.)
- Narrative tense: {present | past-immediate | past-literary | past-retrospective | future}
- Tense contract: {immediate | retrospective}  (immediate = no foreshadowing /
  hindsight / "if she'd only known"; retrospective = both permitted, sparingly;
  future = brief passages only). See `narrative-tense.md`. The `tense-contract-scan.sh`
  audit reads this contract; it must be recorded, not left to the binary past/present flag.
- Narrative voice characteristics
- What the narrator can/cannot know

#### POV CHARACTER VOICE PROFILES (MANDATORY for Dual/Multiple POV)

When the POV structure is Dual POV, Multiple POV, or Mixed, generate a **Voice
Profile** for EACH POV character. These profiles are the Writer's primary tool
for ensuring each narrator sounds like a distinct person — not the same narrator
wearing different name tags.

**Why this is mandatory:** Without per-character voice profiles, multi-POV
manuscripts converge toward a single narrative voice by mid-manuscript. The
Writer has no reference for HOW Character A's narration differs from Character
B's. Personality sliders drive behaviour; voice profiles drive prose texture.

For EACH POV character, generate:

```
POV VOICE PROFILE — {Character Name}

VOCABULARY & REGISTER:
  - Education/class markers: [e.g., "uses technical jargon from nursing background"
    vs "thinks in concrete, physical terms — hands and tools, not abstractions"]
  - Vocabulary ceiling: [simple/moderate/rich — with examples]
  - Profanity/slang: [specific patterns — "swears when alone, never in front of
    children" vs "drops f-bombs mid-sentence without noticing"]
  - Verbal tics in internal monologue: [e.g., "asks herself rhetorical questions"
    vs "narrates in clipped, declarative fragments"]

SENTENCE ARCHITECTURE:
  - Dominant rhythm: [short/punchy | long/flowing | varied/irregular]
  - Fragment usage: [frequent/occasional/rare]
  - Complexity: [simple sentences | compound | nested subordinate clauses]
  - Example sentence (representative of this character's narration):
    "[Write one example sentence in this character's voice]"

PERCEPTION FILTER:
  - What they notice FIRST in a room: [e.g., "exits and sight lines" vs
    "what people are wearing" vs "smells — always smells first"]
  - Sensory bias: [which senses dominate their narration]
  - What they MISS or ignore: [e.g., "never notices décor" vs "oblivious
    to social dynamics" vs "doesn't register background noise"]
  - Professional/life lens: [how their background colours what they observe —
    a nurse notices skin pallor; a carpenter notices load-bearing walls]

EMOTIONAL PROCESSING:
  - How they handle fear: [e.g., "goes still and analytical" vs "floods
    with adrenaline, acts first, thinks later"]
  - How they handle attraction: [e.g., "hyper-aware of physical proximity,
    narrates micro-details" vs "intellectualises feelings, avoids naming them"]
  - How they handle anger: [e.g., "cold, clipped internal monologue" vs
    "chaotic, run-on sentences, profanity spikes"]
  - Default emotional register: [the baseline emotional temperature of their
    narration when nothing dramatic is happening]

METAPHOR & IMAGERY SOURCE:
  - Where their metaphors come from: [their job, childhood, hobbies,
    obsessions — e.g., "military metaphors" vs "cooking metaphors" vs
    "weather and landscape"]
  - Imagery density: [sparse/moderate/frequent]
  - Example metaphor (representative): "[Write one example]"

INTERNAL MONOLOGUE STYLE:
  - Structure: [full sentences | fragments | questions to self | lists]
  - Self-awareness: [highly introspective | avoidant | selectively blind]
  - Humour: [self-deprecating | dark | absent | dry observations]
  - Relationship to truth: [brutally honest with self | in denial |
    rationalises constantly]

VOICE CONTRAST SUMMARY:
  [One sentence capturing what makes this character's narration UNMISTAKABLY
  different from every other POV character. This is the "if you read one
  paragraph, you know who's narrating" marker.]
```

**Voice Differentiation Audit (run after all POV profiles are generated):**
Compare all POV character voice profiles and verify:
- No two characters share the same sentence architecture
- No two characters share the same perception filter bias
- No two characters use metaphors from the same source domain
- No two characters have the same internal monologue structure
- Each character's Voice Contrast Summary is genuinely distinct

If any overlap is found, revise the overlapping profiles to create sharper
contrast. Exaggerate differences — in practice, the Writer will flatten
distinctions, so profiles should be MORE different than you think necessary.

**How Agents Use POV Voice Profiles:**
- **Architect:** References the active POV character's voice profile when
  building the chapter brief. Designs scenes that play to the POV character's
  perception filter (a scene narrated by the nurse should include medical
  details; the same scene from the carpenter's POV notices different things).
- **Writer:** Uses the voice profile as the primary voice reference for the
  chapter. Every paragraph should pass the test: "Could this narration ONLY
  come from this character?"
- **Character Tracker:** Compares narration against the voice profile, scoring
  VOICE DIFFERENTIATION higher when the prose matches the profile's markers.
- **Batch Editor:** Uses voice profiles as the benchmark for Analysis 8
  (POV Voice Differentiation Audit) — detecting convergence across chapters.
- **Editorial Suite:** Uses voice profiles during the Multi-POV Consistency
  Pass to compare narrative voice across the full manuscript.

**4. Characters**

#### CHARACTER NAME GENERATOR — MANDATORY INTEGRATION

**Do NOT assign names directly.** For EVERY named character (protagonist,
antagonist, love interest, mentor, supporting cast — anyone who speaks or
is referenced by name), follow this protocol:

1. **Define the character first** using a placeholder label (e.g., "PROTAGONIST",
   "LOVE INTEREST", "MENTOR", "BEST FRIEND"). Complete all fields below
   (age, background, occupation, personality, etc.) using the placeholder.

2. **Load `character-name-generator.md`** and run the full Character Name
   Generator protocol for each character. The generator uses the character's
   birth year (derived from age + story timeline), region, culture, social
   class, and role to produce 5 historically and culturally accurate name
   candidates — each validated against `authenticity-guard.md` (including
   the High-Frequency AI Names list) and the genre file's Names to Avoid
   section.

3. **Present ALL character name candidates together** to the user for
   approval before finalising the Story Bible. Group them by character:
   ```
   PROTAGONIST — 5 candidates:
     1. [name] — [one-line rationale]
     2. [name] — [one-line rationale]
     ...
   ANTAGONIST — 5 candidates:
     1. [name] — [one-line rationale]
     ...
   ```
   Use AskUserQuestion so the user can select, mix-and-match, request
   more candidates, or provide their own name (which the engine then
   validates for era/cultural accuracy).

4. **Run the Differentiation Check** across the full approved cast —
   no shared first initials (unless cast >10), no matching syllable
   count + stress patterns, no rhyming surnames, protagonist/antagonist
   names phonetically contrast.

5. **Lock approved names** into the Story Bible and entity database.
   Only after names are confirmed should the Story Bible be finalised.

**Why this is mandatory:** Without the Character Name Generator, the
engine defaults to its own name biases — producing names like Marcus Chen,
Elena Okafor, and other high-frequency AI patterns that experienced readers
identify instantly. The generator forces era-appropriate, culturally
researched, cast-differentiated names that pass the Phone Book Test.

For EACH named character:
- Full name (assigned by Character Name Generator — see protocol above)
- Age (avoid numbers ending in 7 — anti-AI-bias). IMMUTABLE: if a birthday
  occurs during the story, document it here with the chapter number where it
  happens. All verification agents must check age references against this value.
  A character's age may only change in prose if a birthday scene is explicitly
  planned and recorded in this field. Any age discrepancy without a documented
  birthday is a CRITICAL continuity error.
- Physical appearance (specific, verifiable details)
- Occupation/role
- Personality (3-5 concrete traits with behavioral examples)
- Speech patterns (how they talk differently from others)
- Internal conflict
- Goals and motivations
- Relationships to other characters
- Character arc (beginning state → end state)
- Secrets (what they know that others don't)

**Personality Sliders** (for MAJOR characters only — protagonist + up to 5 key characters):

Rate each dimension on a -10 to +10 scale. These sliders give agents a quantified
personality profile that ensures consistent voice differentiation and behavior.

```
BEHAVIORAL SLIDERS:
  Stress / Calm:          [-10 to +10]
  Fear / Courage:         [-10 to +10]
  Suspicion / Trust:      [-10 to +10]
  Callous / Empathic:     [-10 to +10]
  Impulse / Control:      [-10 to +10]
  Dominant / Submissive:  [-10 to +10]
  Gut / Logic:            [-10 to +10]
  Deception / Honesty:    [-10 to +10]

PERSONALITY SLIDERS:
  Pessimism / Optimism:   [-10 to +10]
  Introverted / Extroverted: [-10 to +10]
  Detail-Focused / Big-Picture: [-10 to +10]
  Cautious / Risk-Taker:  [-10 to +10]
  Serious / Humorous:     [-10 to +10]
  Stable / Sensitive:     [-10 to +10]
  Shame / Self-Worth:     [-10 to +10]
```

**How Agents Use Sliders:**
- **Architect:** Designs scenes that test slider extremes — a character with Impulse:+8
  makes snap decisions that create plot complications
- **Writer:** Uses sliders to differentiate behavior — a character with Cautious:+7
  pauses before entering a room; one with Risk-Taker:+7 walks straight in
- **Character Tracker:** Validates behavior is consistent with established sliders.
  A sudden shift (e.g., an Introverted:+8 character hosting a party) must be
  justified by plot events or flagged as inconsistent
- **Arc progression:** Sliders can shift across the story (noted in Character Arc).
  A Shame:-7 character who reaches Self-Worth:+3 by the end IS the arc.

**For MINOR characters** (appearing in <3 chapters):
- Background (2-3 sentences)
- Core desire and how it relates to the plot
- One distinguishing speech or behavioral trait
- No sliders needed — keep minor characters lean

**4b. Character Depth Layer (main cast — see `character-depth.md`)**

For the protagonist(s)/co-leads, every POV character, and the primary
antagonist (FULL depth), plus major supporting characters (MEDIUM depth),
author the **Character Depth Layer** alongside the profile above. It adds
the observable, groundable canon the prose stage honours and the audits
check — and is **deduped** against the §3 POV Voice Profiles and the
Personality Sliders (do not repeat voice/perception or temperament here).
Role scoping and the full schema live in `character-depth.md`; the canon
written here is:

- **Hidden Life** — the Unprocessed Event (a *specific* pre-page-one
  moment, no generic trauma), Core Contradiction ("believes X; under
  pressure does Y"), Off-Plot Want, Unspoken Fear, Primal Loss.
- **Physical Tell Register** — five registers (Fear / Anger / Grief /
  Desire / Resolve), one specific observable tell each, **mutually distinct
  across the main cast**, authored in the fixed `#### Physical Tell
  Register — {Name}` format `character-depth.md` §B specifies so
  `scripts/character-tell-distinctness.sh` can verify it.
- **Page-One Visual** — build / face / hair / hands / clothing /
  scars-with-causes, earned by history and tied to the world.
- **Relationship Dynamic** (co-leads / duals / central romance) — mutual
  misreading, mutual offering, internal incompatibility, arc intersection,
  subtext pattern, relational physical anchor.

The quality gates (Independent Existence, depth-priority, no-cliché,
world / emotional-core integration) apply at generation;
`bible-coverage-audit.md` checks the layer is populated and specific.

**5. Locations & World**

For EACH key location:
- Name (check against names-avoidance list)
- Physical description (specific, sensory details)
- Atmosphere/mood
- Associated characters
- Story significance

#### COMPANY NAME GENERATOR — MANDATORY INTEGRATION

**Do NOT assign business names directly.** For EVERY named business, company,
shop, pub, restaurant, organisation, institution, or brand that appears in the
story world, follow this protocol:

1. **Define the business first** using a placeholder label (e.g., "PROTAGONIST'S
   WORKPLACE", "THE LOCAL PUB", "THE ANTAGONIST'S CORPORATION"). Complete all
   world-building details using the placeholder.

2. **Load `company-name-generator.md`** and run the full Company Name Generator
   protocol for each business. The generator uses the business type, founding era,
   region, industry, scale, and owner background to produce 5 era-accurate,
   regionally authentic name candidates — each validated against
   `authenticity-guard.md` AND checked for real-world company collisions.

3. **Present ALL business name candidates together** to the user for approval
   (alongside character name candidates if running concurrently). Group by business:
   ```
   PROTAGONIST'S WORKPLACE — 5 candidates:
     1. [name] — [one-line rationale]
     2. [name] — [one-line rationale]
     ...
   THE LOCAL PUB — 5 candidates:
     1. [name] — [one-line rationale]
     ...
   ```

4. **Run the Differentiation Check** — no business name starts with the same
   letter as a main character's surname, no two businesses share a first word,
   business names contrast in length and feel.

5. **Lock approved names** into the Story Bible and entity database.

**Why this is mandatory:** AI defaults to patterns like "Nexus Technologies",
"The Gilded Fox", and "Whiskers & Wands" — instantly recognisable AI tells.
Worse, randomly generated names frequently collide with real companies. The
generator forces era-appropriate, regionally researched names verified against
real-world entities.

**Worldbuilding Categories** (generate sections relevant to the genre):

Not all categories apply to every genre. Generate ONLY the categories marked as
relevant for the selected genre. Contemporary fiction may need only 3-4 categories;
epic fantasy may need all 12.

| # | Category | When to Include | Format |
|---|----------|----------------|--------|
| 1 | **Settings & Locations** | ALL genres | Physical details, atmosphere, sensory palette, associated characters |
| 2 | **High-Level World** | ALL genres | Era, geography, social norms, daily life texture |
| 3 | **Objects & Artifacts** | Fantasy, Sci-Fi, Mystery, Historical | Name, appearance, origin, abilities/significance, current location, who knows about it |
| 4 | **Magic Systems / Technology** | Fantasy, Sci-Fi, Paranormal, Steampunk | Hard rules (what it CAN'T do), soft rules, cost/limitation, who can use it, how it affects daily life |
| 5 | **Groups, Factions & Races** | Fantasy, Sci-Fi, Political, Historical | Name, beliefs, structure, territory, allies/enemies, how they affect the protagonist |
| 6 | **Gods, Deities & Powers** | Fantasy, Paranormal, Historical, Horror | Name, domain, relationship to mortals, worship practices, story relevance |
| 7 | **Geography & Nature** | Fantasy, Adventure, Survival, Historical | Terrain, climate, distances, travel time, natural hazards, seasonal patterns |
| 8 | **Population & Politics** | Political, Thriller, Historical, Dystopian, Sci-Fi | Power structures, class/caste, governance, current conflicts, protagonist's position |
| 9 | **Culture & Daily Life** | ALL genres (depth varies) | Food, customs, greetings, dress, entertainment, work rhythms — details to USE IN PROSE as sensory texture |
| 10 | **History & Lore** | Fantasy, Historical, Sci-Fi, Gothic | Key past events that affect present, oral traditions, secrets, what characters believe vs. what's true |
| 11 | **Religion & Belief Systems** | Fantasy, Historical, Horror, Paranormal | Organized religion, folk beliefs, superstitions, how beliefs affect character decisions |
| 12 | **Languages & Communication** | Fantasy, Sci-Fi, Historical | Dialects, formal vs. informal speech, jargon, how language marks social class or group membership |

**Category-Specific Formatting:**

For **Magic Systems / Technology** (Category 4):
```
SYSTEM NAME: [name]
TYPE: hard magic | soft magic | technology | hybrid
HARD RULES (what it CANNOT do — define limits first):
  - [limitation 1]
  - [limitation 2]
SOFT RULES (what it CAN do — within the hard limits):
  - [capability 1]
  - [capability 2]
COST: [what using this system costs the user — energy, materials, health, time]
WHO CAN USE IT: [requirements, training, birthright, access]
DAILY LIFE IMPACT: [how it affects ordinary people, not just the protagonist]
STORY INTEGRATION: [how it creates pressure/stakes, not just spectacle]
```

For **Culture & Daily Life** (Category 9):
```
DETAILS TO USE IN PROSE (sensory grounding):
  - What people EAT (specific dishes, ingredients, preparation)
  - What people WEAR (fabrics, styles, condition, what clothing signals)
  - How people GREET each other (formal/informal, physical gestures)
  - What people DO for work/leisure (rhythms, routines, seasonal variation)
  - What the environment SMELLS/SOUNDS like (market sounds, cooking smells, etc.)
```

**Cross-Category Consistency:**
When generating multiple worldbuilding categories, each new category must be checked
against all previously generated categories for consistency. The world must feel
coherent — the geography should affect the culture, the politics should reflect the
history, the religion should influence daily life.

**6. Timeline Overview**

**STORY CALENDAR (MANDATORY — all fields required, all are CANONICAL):**

```
SEASON: [spring | summer | autumn | winter]
START DATE: [Month Day — e.g., "October 14"]
END DATE: [Month Day — e.g., "November 2"]
TOTAL TIMESPAN: [e.g., "19 days"]
MONTHS PERMITTED IN PROSE: [list every month name that may appear in the
  narrative — any month NOT on this list appearing in prose is a CRITICAL
  continuity error. Include months referenced in backstory/flashback if any.]
```

These fields are the SINGLE SOURCE OF TRUTH for all temporal references in the
manuscript. Verification agents (Timeline Keeper, Continuity Guardian) and
editorial agents (Stage 9 Audit) compare every month, season, and weather
reference against these values. There is zero tolerance for deviation.

**Additional timeline elements:**
- Key dates/events with calendar positions relative to START DATE
- Weather context tied to the established SEASON
- Any time-sensitive plot elements (countdowns, deadlines, scheduled events)
- Backstory dates that may be referenced in dialogue or narration

### Output

Write to: `Ideorix-Projects/[Title]/engine-data/story-bible.md` (sections 1-6)

## Phase 2B: Plot

Generate sections 7-14, building on the Foundation.

### System Prompt

```
You are continuing the Story Bible for "{title}".
The Foundation (sections 1-6) is established below. Build the plot structure
that serves this story's characters and themes.

{genre_architect_instructions}

CRITICAL: The chapter outline must have EXACTLY {chapter_count} chapters.
Each chapter must have clear purpose and advance at least one of:
plot, character development, or thematic exploration.

[Foundation sections 1-6 inserted here]
```

### Required Sections

**7. Plot Structure**
- Act breakdown with chapter ranges
- Key turning points
- Subplot integration points

**8. Key Plot Points**
- Inciting incident (chapter number + description)
- First plot point / point of no return
- Midpoint reversal
- All Is Lost / Dark moment
- Climax
- Resolution

**9. Subplots**
For each subplot:
- Description
- Characters involved
- Chapters where it appears
- How it connects to main plot
- Resolution

**9b. Conflicts Register**
A strategic overview of ALL active conflicts in the story — not
per-chapter (that's the Architect's brief), but the full map.

For each conflict:

| Field | Content |
|---|---|
| Conflict | One-line description |
| Type | External (protagonist vs antagonist) / Internal (character vs self) / Relationship (character vs character) / Societal (character vs system/world) |
| Parties | Who is in conflict with whom |
| Stakes | What's at risk if this conflict isn't resolved |
| Root cause | Why this conflict exists |
| Introduced | Chapter where the conflict first appears |
| Escalation points | Chapters where the conflict intensifies (list) |
| Resolves | Chapter where the conflict resolves (or "Unresolved" / "Carries to Book 2") |
| Resolution type | Victory / Compromise / Acceptance / Transformation / Unresolved |
| Status | Active / Resolved / Dormant |

**Update discipline:** The Conflicts Register is GENERATED during
Phase 2B alongside the Chapter Outline. It is UPDATED by the Architect
after each chapter brief (the Architect checks: did this brief advance
any conflict? did it introduce a new one?). The pipeline-checkpoint
does NOT track individual conflicts — the Register is the persistent
document. The user can review the Register at any time to see their
strategic conflict landscape.

**Why this exists:** Conflicts tracked one chapter at a time are
tactical — useful for the Writer but invisible at the strategic level.
The Register gives the user (and the Architect) a zoomed-out view of
which conflicts are active, which are escalating, and which need
attention. It prevents the common failure where a subplot conflict is
introduced in Ch 3 and forgotten until Ch 12.

**10. Trope Integration** (if tropes selected)
- How each trope manifests
- Chapter appearances
- Subversions or straight plays

**11. Character Arcs** (detailed)
For protagonist + major characters:
- Starting state (specific behavior/belief)
- Catalyst for change
- Midpoint shift
- Climax moment
- Resolution state
- Observable Final-Page State — what they look like and do on the final
  page, in behavioural terms only (no abstract theme statements); see
  `character-depth.md` §C
- Key scenes driving the arc

**11b. Tension Axis**
A single consolidated view mapping the planned pressure curve alongside
character arc milestones. This gives the user (and the Architect) a
visual of how tension, character growth, and plot pressure interact
across the full manuscript.

```
TENSION AXIS — {Title}

| Ch | Plot Pressure (1-10) | Internal Pressure (1-10) | Character Arc Beat | Key Relationship State | Conflict(s) Active |
|---|---|---|---|---|---|
| 1 | 2 | 1 | Baseline established | Warm / stable | External only |
| 2 | 4 | 3 | First challenge | First tension | External + internal |
| ... | ... | ... | ... | ... | ... |
| N | 9 | 8 | Climax — character breaks or transforms | Crisis | All converge |
```

**Rules:**
- Plot Pressure and Internal Pressure must not be identical across more
  than 2 consecutive chapters (variation creates rhythm)
- At least one pressure axis must be ≥8 by the 75% mark
- The axis should show a general upward trend with deliberate valleys
  (release chapters after high-tension chapters)
- Character Arc Beats should map to pressure shifts — when pressure
  rises, the character should be facing a choice or revelation

**Source:** Generated during Phase 2B from the Chapter Outline and
Character Arcs. Updated by the Architect (planned values) and Arc
Analyst (actual delivered values) during Phase 3. The tension-tracker
file contains the per-chapter actual values; the Tension Axis is the
strategic plan.

**12. Chapter Outline**
For EACH chapter:
- Chapter number and working title
- 3-5 sentence summary
- Primary beat (what this chapter accomplishes structurally)
- Characters present
- Key events
- Emotional tone (opening → closing)
- Clue/revelation (if mystery/thriller)
- Subplot beats (if any)
- **Narrative Pacing Sliders:** T:[1-10] D:[1-10] EI:[1-10] RT:[1-10] PE:[1-10] H:[1-10]
  (Tension, Dread, Emotional Intimacy, Relationship Tension, Pacing Energy, Humor —
  see blueprint-protocol.md for rubric)
- **Content Intensity:** Spice:[0-5] Violence:[0-5] Swearing:[0-5]
  (see blueprint-protocol.md for rating scale)

**13. Timeline** (detailed)
- Day-by-day or scene-by-scene chronology
- Character locations at key times
- Overlapping events

**14. Chekhov's Guns** (see `chekhovs-guns.md` for full protocol)

If the user selected Chekhov's Guns in Phase 1 (Question 10):
- Generate EXACTLY {gun_count} gun elements (0, 1, 3, or 5)
- For each gun, include:
  - NAME: A short, memorable name for the element
  - DESCRIPTION: What it is and why it matters (1-2 sentences)
  - SETUP: How and when it's planted (which chapter, how it's introduced naturally)
  - PAYOFF: How and when it becomes significant (which chapter, the "aha!" moment)
- Rules:
  - Setups in the first 40% of chapters; payoffs in the last 40%
  - At least ONE gun pays off in the climax or penultimate chapter
  - Guns should be VARIED (objects, skills, locations, relationships, details)
  - Setups must feel natural and incidental — no neon arrows

If the user selected "None", skip this section entirely.

After generation, extract guns to: `Ideorix-Projects/[Title]/engine-data/chekhovs-guns.md`
(see chekhovs-guns.md for the tracking file format)

### Genre-Specific Story Bible Extensions (CONDITIONAL — Phase 2B addition)

After generating the standard 14 sections, check the selected genre and generate
the appropriate genre-specific extension. These extensions provide structured
reference documents that address genre-critical planning needs the standard Bible
doesn't cover.

**Why this exists:** The standard Story Bible is genre-agnostic — it captures
universal story elements (characters, plot, timeline). But each genre has planning
needs the standard sections miss. A mystery needs a suspect dossier and clue
schedule. A romance needs a relationship arc map. A thriller needs a ticking-clock
timeline. Without these, the Architect must reconstruct genre-critical data from
the general outline every chapter — expensive and error-prone.

**Section 15: Genre Extension** — Generate the relevant extension based on genre:

#### Mystery / Crime / Noir / Legal Thriller / Espionage

```
SUSPECT DOSSIER:
For each suspect:
  - NAME: [full name]
  - MOTIVE: [specific reason they could have done it]
  - ALIBI: [what they claim + weakness in the alibi]
  - MEANS: [access to weapon/method]
  - RELATIONSHIP TO VICTIM: [specific connection]
  - KEY SCENES: [chapters where they appear/are investigated]
  - ELIMINATION: [when and how they're ruled out — or not]

CLUE SCHEDULE:
| Ch | Clue | Type (real/red herring) | Delivery Method | Visibility |
|----|------|------------------------|-----------------|------------|
| 3  | Muddy shoes | Real | Sleuth notices during interview | Subtle |
| 5  | False alibi | Red herring | Gossip at market | Obvious |

EVIDENCE CHAIN:
  The solution path a careful reader can follow:
  Clue A (Ch{N}) + Clue B (Ch{N}) → Inference → Clue C (Ch{N}) → Solution
  Every link must be on-page and findable.

INFORMATION ASYMMETRY MAP:
| Character | Knows | Doesn't Know | Lies About |
|-----------|-------|--------------|------------|

CLUES & RED HERRINGS REGISTER (persistent tracking document):
  Generated during Phase 2B from the Clue Schedule above. Saved to
  engine-data/clue-register.md. Updated by the Architect after each
  chapter brief and by the Continuity Guardian after each verification
  pass. Gives the user a strategic view of all clues across the full
  manuscript — not just per-chapter.

| Clue | Type | Planted | Developed | Resolved | Reader has it? | Fair-play status | Status |
|------|------|---------|-----------|----------|----------------|------------------|--------|
| Muddy shoes | Real | Ch 3 | Ch 5, 7 | Ch 12 | Yes (Ch 3) | Solvable from Ch 7 | Active |
| False alibi | Red herring | Ch 5 | Ch 6-8 | Ch 9 (debunked) | Yes | Debunked on-page | Resolved |

  Update discipline:
  - Architect: after each brief, check — does this chapter plant a new
    clue? develop an existing one? resolve a red herring? Update the
    register before presenting the brief.
  - Continuity Guardian: after verification, confirm — was the planned
    clue/development actually delivered in the prose? If not, flag it.
  - User: can review the register at any time ("show me the clue
    register") to see the strategic mystery landscape.

  Fair-play status column values:
  - "Not yet solvable" — reader has clue but not enough to connect it
  - "Solvable from Ch {N}" — reader has enough clues to reach this
    inference (even if they haven't been given the solution explicitly)
  - "Debunked on-page" — red herring has been eliminated for the reader
  - "Debunked for sleuth only" — sleuth knows it's false, reader may not

  Why this exists: Seeing clues one chapter at a time is tactical.
  The Register is the strategic view — which clues are live, which
  are resolved, whether the evidence chain is complete, and whether
  the reader could solve it right now if they were paying attention.
```

#### Romance / Romantic Comedy / Romantic Suspense / Romantic Thriller

```
RELATIONSHIP ARC MAP:
  Stage 1 — First Meeting: Ch{N} — [how they meet, first impression]
  Stage 2 — Attraction: Ch{N}-{N} — [what draws them together]
  Stage 3 — First Barrier: Ch{N} — [what pushes them apart]
  Stage 4 — Deepening: Ch{N}-{N} — [what brings them closer]
  Stage 5 — Dark Moment: Ch{N} — [the crisis that threatens everything]
  Stage 6 — Grand Gesture: Ch{N} — [what proves their love]
  Stage 7 — Resolution: Ch{N} — [HEA/HFN]

HEAT LEVEL PROGRESSION:
| Ch | Spice Level (0-5) | Key Moment |
|----|-------------------|------------|
| 3  | 1 — Awareness | First physical awareness during accidental touch |
| 8  | 2 — Tension | Almost-kiss interrupted |

EMOTIONAL BEAT SCHEDULE:
  Per chapter: the specific emotional shift in the relationship
  Ch 1: Strangers → Curiosity
  Ch 2: Curiosity → Reluctant attraction
  ...

ALMOST-MOMENTS LOG:
  Track near-misses and proximity beats — the bread and butter of romance pacing:
  | Ch | Almost-Moment | What Interrupts | Residue (how it changes them) |
```

#### Fantasy / Epic Fantasy / Dark Fantasy / Urban Fantasy / Historical Fantasy

```
MAGIC SYSTEM REFERENCE CARD:
  HARD RULES (what it CANNOT do):
  - [limitation 1]
  - [limitation 2]
  SOFT RULES (what it CAN do):
  - [capability 1]
  - [capability 2]
  COST: [what using magic costs]
  EXCEPTIONS: [any rule-breaking moments planned, with justification]

WORLD RULES QUICK-REFERENCE:
  10 rules the Writer must NEVER violate, distilled from Section 5:
  1. [rule]
  2. [rule]
  ...

FACTION RELATIONSHIP MATRIX:
| Faction | Allies | Enemies | Neutral | Key Conflict |
|---------|--------|---------|---------|-------------|

POWER HIERARCHY:
  Who is more powerful than whom, and why it matters for each scene.
```

#### Thriller / Psychological Thriller / Domestic Thriller

```
THREAT ESCALATION TIMELINE:
| Ch | Threat Level (1-10) | Specific Threat | What's New |
|----|--------------------|-----------------|-----------|
| 1  | 2 | Unease | Something slightly wrong in routine |
| 5  | 5 | Direct threat | Antagonist makes first move |

INFORMATION ASYMMETRY MAP:
| Character | Knows | Doesn't Know | Suspects | Wrong About |
|-----------|-------|--------------|----------|-------------|

TICKING CLOCK SCHEDULE:
  Deadline: [specific date/time]
  Chapters remaining at each milestone:
  Ch{N}: 7 days remain — [what happens]
  Ch{N}: 3 days remain — [escalation]
  Ch{N}: Hours remain — [climax]

CAGE INVENTORY (domestic thriller):
  What traps the protagonist:
  - Financial: [specific dependency]
  - Social: [specific reputation risk]
  - Emotional: [specific attachment]
  - Physical: [specific constraint]
  How each bar weakens or strengthens across the story.
```

#### Horror / Gothic Horror / Gothic / Vampire / Zombie / Supernatural

```
DREAD ESCALATION MAP:
| Ch | Dread Level (1-10) | Source | Sensory Signature |
|----|-------------------|--------|-------------------|
| 1  | 2 | Atmospheric unease | Smell of something wrong |
| 4  | 5 | First encounter | Sound that shouldn't exist |

RULES OF THE THREAT:
  What the threat CAN do: [specific capabilities]
  What the threat CANNOT do: [specific limitations — these create tension]
  What the threat WANTS: [specific goal]
  How characters can survive: [specific defences or weaknesses]

SAFE SPACE DEGRADATION SCHEDULE:
  Track how safe spaces erode across the story:
  | Ch | Safe Space | Status | What Changed |
  | 1  | Home | Safe | — |
  | 6  | Home | Compromised | Strange noise from attic |
  | 12 | Home | Invaded | [specific breach] |

WRONGNESS INVENTORY:
  Specific "wrong" details planted across chapters that accumulate
  into dread. Each should be small enough to dismiss individually
  but terrifying when the reader connects them.
```

#### Historical / Historical Romance / Historical Fantasy

```
PERIOD ACCURACY REFERENCE:
  ERA: [specific years]
  VOCABULARY WATCHLIST:
  | Modern Word | Period Alternative | Notes |
  |------------|-------------------|-------|
  | "okay" | "very well" / "right" | Not used before 1839 |

  TECHNOLOGY BOUNDARIES:
  - Available: [list what exists]
  - NOT available: [list anachronisms to avoid]
  - In development: [things that exist but aren't widespread]

  SOCIAL NORMS:
  - Forms of address between [classes/genders/roles]
  - What characters can/cannot do in public
  - Taboo topics and how characters navigate them

ANACHRONISM WATCHLIST:
  Specific modern concepts, objects, or phrases that must NOT appear.
  The Continuity Guardian checks against this list every chapter.

HISTORICAL EVENTS TIMELINE:
  Real events that overlap with or affect the story:
  | Date | Event | Impact on Characters |
```

#### Science Fiction / Cyberpunk / Space Opera / Dystopian

```
TECHNOLOGY REFERENCE CARD:
  For each technology in the story:
  - NAME: [technology name]
  - FUNCTION: [what it does]
  - LIMITATIONS: [what it can't do — creates tension]
  - SOCIAL IMPACT: [how it affects daily life]
  - COST/ACCESS: [who can use it and what it costs]

WORLD RULES QUICK-REFERENCE:
  10 rules the Writer must NEVER violate:
  1. [rule — e.g., "FTL requires 48-hour cooldown"]
  2. [rule — e.g., "AI cannot lie but can withhold"]
  ...

FACTION/POWER STRUCTURE:
| Entity | Controls | Wants | Opposes | Character Connection |
|--------|----------|-------|---------|---------------------|

SPECULATIVE ELEMENT CONSISTENCY:
  Track every speculative element introduced and ensure consistent
  treatment. A technology that works one way in Ch 3 must work
  the same way in Ch 15.
```

**Output:** Append as Section 15 to `Ideorix-Projects/[Title]/engine-data/story-bible.md`

**How agents use genre extensions:**
- **Architect:** References the extension when building chapter briefs. The suspect
  dossier tells them which suspect to focus on; the relationship arc map tells them
  which emotional stage to deliver; the threat escalation tells them the target
  dread level.
- **Writer:** References quick-reference cards (magic system, period accuracy,
  technology) to avoid contradictions during prose generation.
- **Continuity Guardian:** Checks facts against genre extension data (alibis,
  magic rules, period vocabulary, tech limitations) in addition to the standard
  entity database.
- **Character Tracker:** Uses faction matrices and information asymmetry maps
  to verify characters only reference knowledge they should have.

### Output

Append to: `Ideorix-Projects/[Title]/engine-data/story-bible.md` (sections 7-15)
Extract guns to: `Ideorix-Projects/[Title]/engine-data/chekhovs-guns.md` (if guns selected)

## Phase 2C: Entity Extraction

After the full Bible is written, extract structured entities.

### Protocol

For each character mentioned in the Bible, extract:
```
NAME: [Full name]
ALSO KNOWN AS: [Nicknames, titles]
AGE: [Specific number]
PHYSICAL: [Key appearance details]
OCCUPATION: [Role]
PERSONALITY: [3-5 traits]
SPEECH PATTERNS: [How they talk]
INTERNAL CONFLICT: [Core struggle]
GOALS: [What they want]
RELATIONSHIPS: [To other characters]
ARC: [Beginning → End state]
FIRST APPEARS: [Chapter number]
```

For each location:
```
NAME: [Location name]
TYPE: [Home, business, outdoor, etc.]
DESCRIPTION: [Physical details]
ATMOSPHERE: [Mood/feeling]
ASSOCIATED CHARACTERS: [Who frequents this place]
SIGNIFICANCE: [Why it matters to the story]
FIRST APPEARS: [Chapter number]
```

For canon rules (world constraints):
```
RULE: [Statement]
CATEGORY: [Magic, technology, social, physical]
IMPLICATIONS: [What this means for the story]
EXCEPTIONS: [If any]
```

### Deduplication

After extraction, check for:
- Name variants ("Detective Ray" and "Ray Martinez" = same person)
- Title variations ("The Bakery" and "Brennan's Bakery" = same place)
- Merge duplicates, keeping the most complete entry

### Output

Write to: `Ideorix-Projects/[Title]/engine-data/entities.md`

## Phase 2D: Entity Canon Lockfile (MANDATORY — Writer & Verifier input)

After entity extraction, the World Canon MUST also produce a **flat,
mechanical name lookup** used by the Writer's pre-load and by the
Continuity Guardian's canon-compliance check. This is a separate file
from `entities.md`, formatted for one purpose: trivially-scannable name
lookups that catch drift at a glance.

**Why this exists (production failure):** A manuscript had the father's
canonical name set to "Matthew" in the Story Bible's character
description, but Ch10 prose established "Mark" in dialogue. The Continuity
Guardian's proper-noun check missed it because the Bible description was
in paragraph form ("Dad (Matthew) is a retired civil engineer who...")
rather than a structured lookup, and the Guardian cached "Dad" as the
prominent reference. The drift carried through 3 chapters before the user
caught it manually. The entity canon lockfile makes that class of drift
impossible to miss — every capitalised name-shaped token in prose can be
checked against the flat table in O(1).

### File location

`Ideorix-Projects/[Title]/engine-data/entity-canon.md`

### File format

```markdown
# Entity Canon — {Title}
Last updated: Phase {N}, Chapter {N}
Lock level: HARD — every name in prose must match a row below.

## Characters

| ID | Canonical Name | Aliases / Also Called | Role | First appears |
|----|----------------|----------------------|------|---------------|
| ch.ellie_hale | Ellie Hale | — | Protagonist | Ch 1 |
| ch.matthew_hale | Matthew Hale | Dad, Father, Mr Hale, Matt | Ellie's father | Ch 1 |
| ch.catherine_hale | Catherine Hale | Mum, Mother, Mrs Hale, Cath | Ellie's mother | Ch 1 |

## Locations

| ID | Canonical Name | Aliases | Type | First appears |
|----|----------------|---------|------|---------------|
| loc.hale_cottage | Hale Cottage | the cottage, home | dwelling | Ch 1 |
| loc.swindon | Swindon | — | town | Ch 5 |

## Objects / Artefacts

| ID | Canonical Name | Aliases | Type | First appears |
|----|----------------|---------|------|---------------|
| obj.grandfather_clock | the grandfather clock | the clock | heirloom | Ch 2 |

## NEW ENTITIES PENDING APPROVAL

(This section is populated by the Architect when a new brief introduces
an entity that isn't in the canon. The user must approve each row before
it is promoted to the main tables above. The Writer MAY NOT produce prose
for a chapter whose brief introduces a PENDING entity until the row is
approved.)

| Proposed by | Type | Canonical Name | Aliases | Context | Status |
|-------------|------|----------------|---------|---------|--------|
| Ch {N} brief | Character | {name} | {aliases} | {context} | pending |
```

### Population rules

**At Phase 2 (Story Bible generation):** World Canon creates
entity-canon.md with one row per character, location, and significant
object from the Story Bible. Every named character gets a canonical
full name (NOT a nickname — the canonical name is what the authority
considers "real"), a list of aliases/also-called forms, and a role
description. Locations and objects same pattern.

**Canonical name rules:**
1. The canonical name is the **authoritative full name** — the one the
   author/Story Bible considers "real". For characters, this is usually
   the full legal/formal name. "Matthew Hale", not "Dad".
2. Every other form the character is referred to goes in Aliases.
   "Dad", "Father", "Mr Hale", "Matt" all become aliases of Matthew Hale.
3. When the prose uses an alias (e.g., "Dad"), the alias must point to
   the canonical name via the ID. The Continuity Guardian uses this to
   resolve "Dad said 'I'll check with Mark'" → is Mark an alias of Dad
   (Matthew)? If no, Canon Drift.
4. Nicknames that only one character uses are valid aliases (e.g., only
   the mother calls the protagonist "Elliekin"). Note in the Context
   column: "used only by Catherine Hale".

**When entities are introduced mid-manuscript:**
1. The Architect notices the brief introduces a name not in the canon
   (a new character, a new place)
2. The Architect adds a NEW ENTITIES PENDING APPROVAL row with its
   proposal for canonical name + aliases
3. At the User Review Gate (step 6), the user sees the pending entity
   and must approve before the brief is accepted
4. On approval, the row moves from PENDING to the main table and is
   written to the file BEFORE step 6a (Writer Pre-Load)
5. The Writer now sees the new canonical name in its pre-load

**When an existing entity gets a new alias:**
The Humaniser or Continuity Guardian detects an unrecognised name-shaped
token that could plausibly refer to an existing character. Flagged at
the Progress Dashboard's Canon Drift line. The user resolves: either
add the new form as an alias of an existing entity, or declare it a
new entity, or confirm it's a genuine prose error and request a rewrite.

### Integration points

- **Writer pre-load** (`prose-protocol.md` + core-pipeline step 6a) — reads
  entity-canon.md and injects a flat quick-reference into the Writer
  prompt's ENTITY CANON (HARD LOCK) block, adjacent to the OPENING HARD
  CONSTRAINTS block. The Writer is physically prevented from inventing
  new names because the ones in the canon are right at the top of the
  prompt.
- **Continuity Guardian** (`quality-gate.md` — see Canon Compliance
  Check) reads the same file and runs a mechanical extract-and-match
  pass on every proper noun in the chapter.
- **Architect** (`blueprint-protocol.md`) reads the canon to confirm all
  entity names in its brief are on the approved list; new entities go
  to PENDING.
- **Pipeline checkpoint** tracks `Canon Check: {clean | {N} drift}` per
  chapter.

### Update discipline

The entity-canon.md file is **write-rarely, read-every-chapter**. It is
the source of truth for names. Every update is user-approved. Do NOT
silently update the file in response to a Writer producing a different
name — that normalises drift instead of flagging it. The Guardian
reports drift, the user decides what the truth is, the user approves
any canonical change, only then the file updates.

## Series Continuity Extension (Multi-Volume Projects)

When the project is part of a planned series (Phase 0 completed), extend the Story
Bible with a **Series Continuity** section. This connects the individual volume's
Story Bible to the overarching Series Bible.

### When to Add

Add this section during Phase 2A (Foundation) if `engine-data/series-bible.md` exists.

### Required Section: Series Continuity

Append after the standard Phase 2A sections (Section 15 = Genre Extension;
this is Section 16):

**16. Series Continuity**

```
SERIES CONTEXT:
  Series Title: [from series-bible.md]
  This Volume: [number] of [planned total]
  Spine Question: [the central question spanning all volumes]
  Thematic Throughline: [the deeper theme running through every volume]

MOMENTUM LADDER — THIS VOLUME:
  Previous Volume Stakes: [what was at stake in the prior volume]
  This Volume Stakes: [how stakes have escalated]
  Next Volume Setup: [what this volume plants for the next]

CHARACTER TRAJECTORIES — THIS VOLUME:
  For each major recurring character:
  - NAME: [character name]
  - SERIES ARC POSITION: [where they should be at this point per trajectory map]
  - THIS VOLUME STATE: [emotional/relational starting point for this volume]
  - THIS VOLUME ENDPOINT: [where they should be by the end of this volume]
  - KEY SHIFT: [the most significant change this volume delivers for them]

ARC WEAVE — ACTIVE THREADS:
  Threads carrying forward from previous volumes:
  - [thread name] — planted Vol [N], develops this volume, resolves Vol [N]
  - [thread name] — planted Vol [N], resolves THIS volume
  New threads to plant this volume:
  - [thread name] — plant here, develops Vol [N], resolves Vol [N]

GROWTH SEEDS — THIS VOLUME:
  Elements introduced that could support future expansion:
  - [seed description] — could become [potential storyline]

SERIES CANON CONSTRAINTS:
  Facts established in prior volumes that MUST be honoured:
  - [fact 1 — from Vol N]
  - [fact 2 — from Vol N]
  - [fact 3 — from Vol N]
  Any contradiction with these facts is a CRITICAL continuity error.
```

### How Agents Use Series Continuity

- **Architect:** Designs chapter briefs that advance the correct arc weave threads
  and deliver the character trajectory milestones for this volume
- **Writer:** References series canon constraints to avoid contradicting prior volumes
- **Continuity Guardian:** Checks against both the Story Bible AND the Series Canon
  Constraints for cross-volume consistency
- **Arc Analyst:** Validates that the momentum ladder is being served — this volume
  should feel like an escalation from the previous one
- **Character Tracker:** Validates character behaviour against their series trajectory
  position, not just their within-volume arc

### Output

Append to: `Ideorix-Projects/[Title]/engine-data/story-bible.md` (Section 16)

---

## Aggregate Precedence Rule (MANDATORY)

Whenever the Story Bible contains an aggregate truth table — a close-out
totals table, register summary, character appearance count, event tally,
or any table with quantitative claims about the manuscript — that table
is the **tie-breaker** for every conflicting claim elsewhere in the Bible.

**Precedence order (highest to lowest):**

1. **Aggregate truth tables** — close-out totals, register summaries,
   count tables. These are compiled from the full story and represent the
   canonical totals. If a table says "HHS count: 1 (Ch 8)" then there is
   exactly one HHS, regardless of what any prose paragraph elsewhere says.
2. **Corrections/supersessions** — any statement marked with
   `> CORRECTION — SUPERSEDES ABOVE:` overrides the text it corrects.
3. **Section 12 chapter entries** — the per-chapter canonical spec.
4. **Section 14 Chekhov gun schedule** — the locked gun plan.
5. **All other Bible prose** — character descriptions, thematic notes,
   beat descriptions. These are authoritative for their own domain but
   yield to aggregate tables on any numeric or scheduling question.

**How agents apply this rule:**
- The **Architect** checks aggregate tables FIRST for any count or
  scheduling question before reading prose-embedded claims in beat
  descriptions. If the aggregate table answers the question, the
  Architect uses that answer and does not search further.
- The **Canon Validator** (see `canon-validator.md`) uses aggregate tables
  as the authoritative source when validating checkpoint content claims.
- The **Continuity Guardian** defers to aggregate tables when a chapter's
  prose contains a count that could be checked against a table.

**Why this rule exists:** The Story Bible is a living document. As beats
are drafted and revised, prose paragraphs accumulate forward-looking
notes, authorial asides, and planning remarks. These are working material.
Aggregate tables are compiled summaries. When the two disagree, the table
is correct because it was written with full knowledge of the final state.
A prose note written during Ch 8 planning that says "one more HHS later"
may have been superseded by a decision made during Ch 12 planning — the
aggregate table reflects that decision; the prose note does not.

## Bible Structure Convention — Authority Class Markers

To prevent agents from treating working notes as canonical specifications,
the Story Bible uses explicit authority-class markers. These markers are
REQUIRED in all new Bible content and should be applied incrementally to
existing content as sections are touched.

### Marker Definitions

**Aggregate truth tables (highest authority):**
```
> AUTHORITATIVE AGGREGATE — overrides any conflicting prose above or below.

| Metric | Value | Chapter(s) |
|--------|-------|------------|
| HHS count | 1 | Ch 8 |
| ... | ... | ... |
```

**Corrections that supersede prior text:**
```
> CORRECTION — SUPERSEDES ABOVE: Helen does NOT have a second HHS.
> The forward-looking note in the Ch 8 beat was a planning remark,
> not a commitment. Final count: 1 HHS (Ch 8 only).
```

**Authorial working notes (lowest authority — NOT valid sources for
checkpoint claims or Architect decisions):**
```
> NOTE: Consider giving Helen a second HHS in a later chapter.
> This is a planning thought, not a decision. Do not commit to
> checkpoint or brief without an aggregate table entry.
```

### Rules for Agents

1. **Never source a checkpoint claim from a `> NOTE:` block.** Working
   notes are thinking-in-the-margins. They may be superseded, abandoned,
   or contradicted by later decisions. Only aggregate tables, corrections,
   and canonical Section 12/14 entries are valid sources.

2. **When encountering a `> CORRECTION` block,** treat the corrected text
   as dead — do not read it, cite it, or act on it. The correction is
   the canonical replacement.

3. **When building or updating aggregate tables,** scan the full Bible for
   any prose-embedded claims on the same metric and verify they are
   consistent. If they conflict, the table value wins and the prose should
   be updated with a `> CORRECTION` block at the next touch.

4. **During Bible generation (Phase 2),** mark all forward-looking
   planning remarks with `> NOTE:` as they are written. This is not
   retroactive cleanup — it is a generation-time convention.

---

## Reverse-Engineering (for imported manuscripts)

When the user provides existing chapters instead of starting fresh:

### Protocol

1. **Sample all chapters** (up to 80,000 chars total, ~7,000 per chapter)
2. **Generate Bible** with strict rules:
   - NO inventing details not in the text
   - NO renaming characters or locations
   - 100% text fidelity — if it's not on the page, it's not in the Bible
   - Use quotes from the manuscript as evidence
3. **Extract entities** from FULL chapter content (not truncated)
4. **Validate** — check for contradictions within the Bible itself
5. **Present to user** for review and correction before proceeding

### System Prompt for Reverse-Engineering

```
You are an elite manuscript analyst. Extract a comprehensive Story Bible
from this existing manuscript. You are a DETECTIVE, not a CREATOR.

ABSOLUTE RULES:
- If the text says a character has brown hair, write "brown hair"
- If the text never mentions hair color, write "Not described"
- NEVER invent, infer, or assume details not explicitly in the text
- Quote the manuscript when establishing facts
- Flag contradictions you find (they may be errors or intentional)
```
