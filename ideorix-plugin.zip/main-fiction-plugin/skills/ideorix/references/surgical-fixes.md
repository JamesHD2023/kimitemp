---
name: surgical-fixes
description: "Two-step surgical revision protocol"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Revision Protocol

## File-Write Hygiene (MANDATORY)

This protocol's core discipline (precisely targeted Edits, no
wholesale chapter rewrites) is structurally aligned with the
chained-Edit truncation safeguard documented in
`core-pipeline.md` § Chained-Edit Truncation Safeguard, but
the safeguard's specific bindings still apply:

- **Cap individual Edit replacements at ~2 KB.** Surgical fixes
  should rarely exceed this; if a single fix needs more, split
  it into multiple smaller Edits.
- **Run `scripts/word-count-check.sh` after every chapter file
  this protocol edits**, not just at the end of the revision
  set. Word-count drift after a "single-line fix" is the
  signature of silent truncation.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) before reporting fix success. The Edit
  tool's success return does not confirm on-disk integrity.

**HARD GATE — BLOCKING.** A truncated chapter file caught at
this stage MUST be repaired (clean Write of the full intended
content, post-write integrity verification) before subsequent
fixes are applied to the same file.

## Core Principle

ALL revisions are SURGICAL. Never rewrite a chapter wholesale.
The two-step process (analyse → fix) preserves the author's voice
and prevents the "fix introduces new bugs" problem.

## When Revision Triggers

1. **Per-chapter verification score below 80** → fix before next chapter
2. **Any agent returns "fail" status** → fix critical issues
3. **3+ agents flag the same issue** → elevated to critical
4. **Editorial pipeline flags structural issues** → targeted fixes
5. **User requests specific changes** → targeted fixes

## The Two-Step Process

### Step 1: Analyse

Collect all issues that need fixing from verification/editorial reports.
Rank by severity × impact:

```
CRITICAL (must fix):
- Continuity contradictions (high likelihood)
- Timeline impossibilities
- Character knowledge violations
- Genre automatic fails

MODERATE (should fix):
- Pacing drag points
- Weak show-vs-tell passages
- Voice inconsistencies
- Missing emotional beats

MINOR (fix if time allows):
- Word choice improvements
- Rhythm polish
- Adverb reduction
- Crutch phrase cleanup
```

For each issue to fix, record:
- **EXACT QUOTE** from the chapter (the text to change)
- **PROBLEM** (what's wrong with it)
- **FIX** (what it should become)
- **REASON** (which agent flagged it and why)

### Step 2: Apply

For each fix in the plan:

1. **Locate** the exact text in the chapter
2. **Apply** the minimum edit that resolves the issue
3. **Verify** the fix doesn't:
   - Change the plot
   - Alter character voice
   - Break continuity with adjacent paragraphs
   - Introduce new AI-isms
   - Change word count by more than 5%
4. **Log** what was changed

### Apply Prompt Template

```
Apply the following fixes to the chapter. Make SURGICAL edits only — do not rewrite.

CRITICAL RULES:
1. Apply ONLY the fixes listed below. Do NOT make additional changes.
2. Preserve ALL: plot events, scene order, chapter structure, character decisions.
3. Preserve the author's VOICE — the chapter should read like the same writer.
4. Word count must stay within 5% of original.
5. Do NOT add new content, scenes, or descriptions.
6. Keep all proper nouns and terminology exactly as written.

FIXES TO APPLY:
{numbered list of exact fixes from analysis}

CHAPTER TO EDIT:
{full chapter text}

Return the COMPLETE chapter with fixes applied. No commentary.
```

### Step 3: Verify (MANDATORY — every fix batch)

After applying fixes, verify each one landed correctly and didn't introduce
regressions. This step catches the "fix introduces new bugs" problem.

**Per-fix verification:**
For each fix in the batch, confirm:
1. The fix was applied correctly (the old text is gone, the new text is present)
2. The surrounding paragraph still reads naturally
3. No new AI-isms were introduced in the rewrite
4. Voice consistency held (compare to the Voice Profile from editorial-suite.md)

**Regression check:**
5. Read the full chapter (not just the fixed passages) for:
   - New continuity breaks caused by the fix
   - Changed character voice or behaviour
   - Plot or timeline contradictions
   - Tone shifts that don't match the surrounding material

**Quantitative checks:**
6. **Word count** — within 5% of original
7. **Content preservation** — key events, dialogue, and plot beats intact
8. **No text corruption** — no garbled sentences, no duplicate paragraphs

**If verification fails:**
- If a single fix regressed: apply a targeted second fix for that fix only
- If 2+ fixes regressed: REVERT to pre-revision version and try a different approach
- If voice consistency failed: the edit went too far — simplify the fix
- Present to user for manual decision if the regression is complex

## Drift Corrector

After revision, run a quick validation:

```
Compare the revised chapter against:
1. The Architect's brief — does it still follow the brief?
2. The Story Bible — does it still comply?
3. Internal consistency — does it contradict itself?

Report any new issues introduced by the revision.
```

If the Drift Corrector finds issues, the revision created new problems.
Options:
- Apply a second targeted fix (for the new issues only)
- Revert to pre-revision and try a different approach
- Present to user for manual decision

## Em-dash and capped-punctuation cleanup (MANDATORY at Stage 8)

All prose em-dashes (single AND paired) are IN SCOPE for Stage 8.
Fiction caps (per `scripts/formatting-check.sh`): zero em-dashes
in narration; up to 3 in dialogue per chapter. Stage 8 MUST
convert every narration em-dash and any dialogue em-dash beyond
the cap — do NOT defer "single em-dashes" to a human copyeditor.
Same applies to over-cap ellipses (>3) and exclamation marks
(>1) in narration.

Per-instance conversion guidance for narration em-dashes:

| Em-dash use | Replace with |
|-------------|--------------|
| Mid-sentence aside, brief and parenthetical | Pair of commas |
| Two independent clauses joined for emphasis | Semicolon, or split into two sentences |
| End-of-sentence interruption / abrupt stop | Period (full stop) |
| Attribution before a quote or speaker tag | Comma |
| Trailing thought or unfinished reflection | Period or short ellipsis (within ellipsis cap) |

Dialogue em-dashes beyond the cap of 3: keep the dramatically
strongest 3, convert the rest using the same guidance.

Stage 8 ends with `bash scripts/formatting-check.sh <chapter>` on
each touched chapter, exit 0. The Handoff Protocol's
`handoff-gate.sh` (Check 6) re-runs `formatting-check.sh` on
every chapter as a final gate — a Stage 8 deferral cannot
survive to handoff.

**v2.7.89 deterministic backstop.** When Stage 8's LLM-driven
conversion misses narration em-dashes, the Handoff Protocol's
new Step 7.3.5 runs `scripts/em-dash-auto-convert.sh` on every
chapter as a deterministic substitution pass — em-dash → comma
in narration, dialogue spans preserved. Stage 8 should still do
the per-instance grammatical conversion (where comma is wrong,
choose period / semicolon / ellipsis); the auto-converter is
the safety net that ensures nothing survives. Honors
`formatting_mode: human` for human-authored manuscripts.

## What NOT to Do During Revision

- **Never rewrite from scratch** — always edit the existing text
- **Never "improve" text that wasn't flagged** — resist scope creep
- **Never change character names or locations** — even if you think of "better" ones
- **Never add philosophical observations** — the #1 AI revision sin
- **Never merge or split chapters** — structural changes require user approval
- **Never change POV or tense** — even momentarily
- **Never apply contradictory fixes** — if agents disagree, surface to user first
