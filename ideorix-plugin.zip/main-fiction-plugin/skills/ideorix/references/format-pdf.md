---
name: format-pdf
description: "Print-ready PDF generation template"
user-invocable: false
---
<!-- (c) 2025 Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->
# Print-Ready PDF Generation Template

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.pdf`

This print-ready PDF export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Routing — Novel vs. Screenplay (READ FIRST)

This file ships **two** PDF layouts. Pick the right one before generating.

| Source content | Use this layout | Why |
|---|---|---|
| Novel manuscript (prose chapters, scene breaks `* * *`, no Fountain syntax) | **Novel PDF** (the main body of this file) | Trade paperback layout: Garamond 11pt, recto-chapter-start, running headers, justified body |
| Screenplay (Fountain source, scene headings `INT./EXT.`, character cues, action paragraphs) | **Screenplay PDF** (see "Screenplay PDF Layout" section below) | Industry-standard spec script layout: Courier 12pt, US Letter, screenplay margins, character-cue indentation |

**Detection:** if the source text contains scene headings matching
`^(INT\.|EXT\.|INT\./EXT\.|I/E\.)` followed by a slugline pattern, OR
the source filename ends in `.fountain`, route to the Screenplay PDF
layout. Otherwise use the Novel PDF layout below.

If a project contains both (e.g., a manuscript in development AND a
companion screenplay adaptation), generate two separate PDFs — one
per format.

---

## Novel PDF — Overview

Generate print-ready PDFs with configurable trim sizes for paperback and hardcover.
Proper margins for binding, chapter headings positioned correctly, page numbers,
and formatting ready for print-on-demand services like KDP Print, IngramSpark,
and Barnes & Noble Press.

## Trim Size Options

| Trim Size | Use Case | Interior Margins |
|-----------|----------|-----------------|
| 5" x 8" | Mass market / compact paperback | Inside: 0.75", Outside: 0.5", Top: 0.7", Bottom: 0.7" |
| 5.5" x 8.5" | Standard trade paperback (most common) | Inside: 0.8", Outside: 0.6", Top: 0.75", Bottom: 0.75" |
| 6" x 9" | Large trade / hardcover | Inside: 0.875", Outside: 0.625", Top: 0.8", Bottom: 0.8" |

**Inside margin (gutter)** is always larger to account for the binding.

## Manuscript Specifications

- **Body font:** Garamond, 11pt (industry standard for print books)
- **Chapter headings:** Garamond, 18pt, bold, centered
- **Line spacing:** 1.3 (tighter than manuscript format — this is a typeset book)
- **Paragraph spacing:** 0pt (use first-line indent instead)
- **First line indent:** 0.3" (except first paragraph after heading or scene break)
- **Page numbers:** Centered in footer, starting from Chapter 1 (not title page)
- **Running headers:** Book title (verso/left pages), Chapter title (recto/right pages)
- **Chapter starts:** Always on recto (right/odd) page — insert blank verso if needed

## Title Page Structure

```
[Recto page — right side]

[generous top margin — ~35% down the page]

[Book Title — 24pt, bold, centered]

[1 blank line]

[Subtitle — 14pt, italic, centered] (if applicable)

[generous space]

[Author Name — 16pt, centered]

[Page break — verso blank, then chapter 1 on next recto]
```

## Chapter Structure

```
[Always starts on recto (odd) page]

[Drop — ~25% from top of page]

[Chapter heading — 18pt, bold, centered]
[e.g., "Chapter 1: The Discovery"]

[2 blank lines]

[Chapter body — 11pt, 1.3 spacing]
[First paragraph: no indent]
[Subsequent paragraphs: 0.3" first line indent]
```

## Scene Break Formatting

```
[blank line — ~1em space]
* * *
[blank line — ~1em space]
```

Centered, with three asterisks separated by spaces. No extra paragraph spacing.

## Node.js Generation Template

```javascript
const PDFDocument = require('pdfkit');

// Trim sizes in points (1 inch = 72 points)
const TRIM_SIZES = {
  '5x8':     { width: 360, height: 576, inside: 54, outside: 36, top: 50.4, bottom: 50.4 },
  '5.5x8.5': { width: 396, height: 612, inside: 57.6, outside: 43.2, top: 54, bottom: 54 },
  '6x9':     { width: 432, height: 648, inside: 63, outside: 45, top: 57.6, bottom: 57.6 }
};

function createPrintPdf(title, author, chapters, options = {}) {
  const trimSize = options.trimSize || '5.5x8.5';
  const dims = TRIM_SIZES[trimSize];
  const font = 'Times-Roman';       // PDFKit built-in (close to Garamond)
  const boldFont = 'Times-Bold';
  const italicFont = 'Times-Italic';

  const doc = new PDFDocument({
    size: [dims.width, dims.height],
    margins: { top: dims.top, bottom: dims.bottom, left: dims.inside, right: dims.outside },
    bufferPages: true,
    info: {
      Title: title,
      Author: author,
      Creator: 'Ideorix Manuscript & Screen Engine'
    }
  });

  const buffers = [];
  doc.on('data', chunk => buffers.push(chunk));

  let pageNum = 0;

  // --- Title Page ---
  const titleY = dims.height * 0.35;
  doc.font(boldFont).fontSize(24).text(title, dims.inside, titleY, {
    width: dims.width - dims.inside - dims.outside, align: 'center'
  });
  doc.moveDown(2);
  doc.font(font).fontSize(16).text(author, {
    width: dims.width - dims.inside - dims.outside, align: 'center'
  });

  // Blank verso after title page
  doc.addPage();

  // --- Chapters ---
  chapters.forEach((chapter, index) => {
    const heading = `Chapter ${index + 1}: ${chapter.title}`;

    // Start on recto (odd page) — add blank verso if needed
    ensureRectoPage(doc, dims);

    pageNum++;

    // Chapter drop — start ~25% down
    const dropY = dims.height * 0.25;
    doc.font(boldFont).fontSize(18).text(heading, dims.inside, dropY, {
      width: dims.width - dims.inside - dims.outside, align: 'center'
    });
    doc.moveDown(2);

    // Chapter body
    const paragraphs = chapter.content.split('\n\n');
    let isFirstAfterBreak = true;

    paragraphs.forEach(para => {
      const trimmed = para.trim();
      if (!trimmed) return;

      // Scene break
      if (trimmed === '* * *' || trimmed === '---') {
        doc.moveDown(1);
        doc.font(font).fontSize(11).text('* * *', {
          width: dims.width - dims.inside - dims.outside, align: 'center'
        });
        doc.moveDown(1);
        isFirstAfterBreak = true;
        return;
      }

      // Check if we need a new page
      if (doc.y > dims.height - dims.bottom - 50) {
        doc.addPage();
        swapMarginsForPage(doc, dims);
      }

      // Paragraph with conditional indent
      const indent = isFirstAfterBreak ? 0 : 21.6; // 0.3 inches = 21.6pt
      doc.font(font).fontSize(11).text(stripMarkdown(trimmed), {
        width: dims.width - dims.inside - dims.outside - indent,
        align: 'justify',
        indent: indent,
        lineGap: 2.3  // ~1.3 line spacing
      });

      isFirstAfterBreak = false;
    });
  });

  // --- Add running headers and page numbers ---
  const pages = doc.bufferedPageRange();
  for (let i = 2; i < pages.count; i++) {  // Skip title page and blank verso
    doc.switchToPage(i);
    const isRecto = (i % 2 === 0);  // 0-indexed: even = recto after title

    // Page number — centered footer
    doc.font(font).fontSize(9).text(
      String(i - 1),  // Page numbering starts at 1 from first chapter
      0, dims.height - dims.bottom + 20,
      { width: dims.width, align: 'center' }
    );

    // Running header
    if (i > 2) {  // No header on first chapter page
      const headerText = isRecto ? getCurrentChapterTitle(i, chapters) : title;
      doc.font(italicFont).fontSize(8).text(
        headerText,
        dims.inside, dims.top - 25,
        { width: dims.width - dims.inside - dims.outside,
          align: isRecto ? 'right' : 'left' }
      );
    }
  }

  doc.end();
  return new Promise(resolve => {
    doc.on('end', () => resolve(Buffer.concat(buffers)));
  });
}

function ensureRectoPage(doc, dims) {
  // Recto = right page = odd page number in book terms
  // In PDFKit buffered pages, we track via page count
  doc.addPage();
  const currentPage = doc.bufferedPageRange().count;
  if (currentPage % 2 === 1) {
    // We're on a verso — add one more blank page
    doc.addPage();
  }
  swapMarginsForPage(doc, dims);
}

function swapMarginsForPage(doc, dims) {
  // Alternate inside/outside margins for recto/verso
  const currentPage = doc.bufferedPageRange().count;
  const isRecto = (currentPage % 2 === 0);
  if (!isRecto) {
    doc.page.margins.left = dims.outside;
    doc.page.margins.right = dims.inside;
  } else {
    doc.page.margins.left = dims.inside;
    doc.page.margins.right = dims.outside;
  }
}

function getCurrentChapterTitle(pageIndex, chapters) {
  // Simplified — returns chapter title based on page index
  // In production, track chapter start pages during generation
  return chapters.length > 0 ? chapters[0].title : '';
}

function stripMarkdown(text) {
  return text.replace(/\*\*(.+?)\*\*/g, '$1').replace(/\*(.+?)\*/g, '$1');
}
```

## Print-on-Demand Service Notes

### KDP Print (Amazon)
- Upload interior PDF + cover PDF separately
- Bleed setting: "No bleed" for text-only interiors
- Paper: Cream or white (cream preferred for fiction)
- Trim sizes supported: all three options above

### IngramSpark
- Same PDF requirements as KDP Print
- Additional trim sizes available (see IngramSpark docs)
- Requires ICC color profile for cover (sRGB for interior)

### Barnes & Noble Press
- Accepts PDF interior files
- Similar trim size options to KDP Print

## Delivery Notes

When delivering a print PDF, include:
- Trim size used
- Page count (for spine width calculation)
- Paper color recommendation (cream for fiction, white for non-fiction)
- Note that a cover PDF is needed separately (see `cover-designer.md`)

---

## Screenplay PDF Layout

Generate industry-standard screenplay PDFs from Fountain source. The
output must be indistinguishable from a Final Draft / Highland / Fade In
export — that's the bar; anything less reads as amateur to readers.

**Honesty on enforcement.** This layout spec defines the geometry,
margins, and typography that the renderer MUST honor. No script in
the current engine emits screenplay PDFs directly; the practical
generation path is either (a) the user's local conversion of the
delivered Fountain file via afterwriting / Highland / Final Draft
(which all match this geometry by default), or (b) an LLM-orchestrated
PDFKit-style render following the spec below. A future
`screenplay-render.sh` could mechanically enforce the geometry the
same way `manuscript-render.sh` does for prose; until then, the
spec is the contract the renderer is held to, not a script-enforced
gate. The FDX delivery (`format-fdx.md`) is the more reliable round-
trip path to a typeset PDF — every screenplay app reads FDX and
emits its own industry-grade PDF.

### Page geometry (MANDATORY — these are not configurable)

- **Page size:** US Letter (8.5" × 11") — 612 × 792 points
- **Top margin:** 1.0" (72pt)
- **Bottom margin:** 0.5"–1.0" (36–72pt)
- **Left margin:** 1.5" (108pt)
- **Right margin:** 1.0" (72pt)
- **Body width:** 6.0" (432pt)

### Element layout (MANDATORY)

Per `format-fountain.md` Industry Page Layout table — reproduced and
extended here for PDF generation:

| Element | Left (from page edge) | Right (from page edge) | Width | Notes |
|---|---|---|---|---|
| Scene Heading | 1.5" | 1.0" | 6.0" | UPPERCASE, no underline, no bold (some pros bold; default is plain) |
| Action | 1.5" | 1.0" | 6.0" | Plain text, paragraph-aligned left, single-spaced within, blank line between paragraphs |
| Character Cue | 3.7" | — | — | UPPERCASE, on its own line, blank line above |
| Parenthetical | 3.1" | 2.9" | 2.5" | Lowercase, in parens, immediately above the dialogue line |
| Dialogue | 2.5" | 2.5" | 3.5" | Plain text, single-spaced |
| Dual Dialogue (left half) | 1.5" | (mid) | ~3.0" | Both halves split the page roughly equally |
| Dual Dialogue (right half) | (mid) | 1.0" | ~3.0" | |
| Transition | right-aligned | 1.0" | — | UPPERCASE, ends with `:` (e.g., `CUT TO:`, `FADE TO:`) |
| Page Number | top right | 0.5" from top | — | Followed by a period (e.g., `23.`); first page has no number |
| Title Page | centered block | — | — | See Title Page section below |

### Font (MANDATORY — these are non-negotiable in spec scripts)

- **Font family:** Courier (or Courier Prime; Courier New if those
  are unavailable). Monospace 12pt at 10 characters per inch.
- **Single weight:** Plain. Bold and italic are permitted only in
  rare emphasis (`*italic*` and `**bold**` from Fountain). Most spec
  scripts have neither.
- **No underline.** Industry has moved away from underlined sluglines.

### Title Page

Full page, no page number, generous spacing. Layout (top-to-bottom,
all centered horizontally):

- Top margin ~3.5" from page top
- **TITLE** (uppercase, 12pt Courier): the screenplay title
- Blank line
- Credit line (e.g., `Written by` or `Screenplay by`)
- Blank line
- Author name
- Blank line (only if Source line present)
- `Based on the {novel/story/play} by {Original Author}` (italic if rendering supports; plain otherwise)
- ~3" of vertical space (push the contact block down)
- Bottom-left contact block:
  - Author name
  - Email
  - Phone
- Bottom-right (optional): `Draft date: MM/DD/YYYY`

The Fountain title-page key/value block is rendered into this layout.
See `format-fountain.md` Title Page section for the source syntax.

### Special elements

- **MORE / CONT'D at page break:** when a dialogue block spans a page
  break, append `(MORE)` at the bottom of the page (centered under the
  dialogue) and `CHARACTER (CONT'D)` at the top of the next page above
  the continuation.
- **(CONTINUED) at page-break for action:** legacy device; **omit** in
  spec scripts.
- **Scene numbers:** **omit** in spec scripts. Only production drafts
  number scenes.
- **Dual dialogue:** Fountain `^` syntax renders side-by-side at the
  Dual Dialogue widths above.
- **MONTAGE / INTERCUT / INSERT:** rendered as scene headings
  (left-aligned at 1.5") followed by their content. `END MONTAGE` and
  `BACK TO SCENE` likewise.

### Node.js generation (using PDFKit + Courier Prime)

```javascript
const PDFDocument = require('pdfkit');
const fs = require('fs');

// Screenplay constants (US Letter, points; 1 inch = 72pt)
const SCRPLAY = {
  width: 612, height: 792,
  marginTop: 72, marginBottom: 72,
  marginLeft: 108, marginRight: 72,
  bodyWidth: 432,
  font: 'Courier',     // PDFKit built-in; substitute Courier-Prime if registered
  fontBold: 'Courier-Bold',
  fontOblique: 'Courier-Oblique',
  fontSize: 12,
  // Element x-positions (from page left edge), in points
  x: {
    sceneHeading: 108,    // 1.5"
    action: 108,          // 1.5"
    character: 266.4,     // 3.7"
    parenthetical: 223.2, // 3.1"
    dialogue: 180,        // 2.5"
    transitionRight: 540, // page width - 1" right margin
  },
  width: {
    sceneHeading: 432,
    action: 432,
    parenthetical: 180,   // 2.5"
    dialogue: 252,        // 3.5"
  }
};

function createScreenplayPdf(title, fountainScenes) {
  const doc = new PDFDocument({
    size: [SCRPLAY.width, SCRPLAY.height],
    margins: {
      top: SCRPLAY.marginTop,
      bottom: SCRPLAY.marginBottom,
      left: SCRPLAY.marginLeft,
      right: SCRPLAY.marginRight,
    },
    bufferPages: true,
    info: { Title: title, Creator: 'Ideorix Manuscript & Screen Engine' }
  });

  doc.font(SCRPLAY.font).fontSize(SCRPLAY.fontSize);

  // Title page
  renderTitlePage(doc, fountainScenes.titlePage);
  doc.addPage();

  // Body
  fountainScenes.scenes.forEach(scene => renderScene(doc, scene));

  // Page numbers (top right, except first page)
  paginate(doc);

  doc.end();
  return doc;
}

function renderScene(doc, scene) {
  // Scene heading (uppercase, plain, blank line above and below)
  doc.moveDown(1);
  doc.text(scene.heading.toUpperCase(), SCRPLAY.x.sceneHeading, doc.y, {
    width: SCRPLAY.width.sceneHeading
  });
  doc.moveDown(1);

  scene.elements.forEach(el => {
    switch (el.type) {
      case 'action':
        doc.text(el.text, SCRPLAY.x.action, doc.y, { width: SCRPLAY.width.action });
        doc.moveDown(1);
        break;
      case 'character':
        doc.text(el.name.toUpperCase() + (el.extension || ''), SCRPLAY.x.character, doc.y);
        break;
      case 'parenthetical':
        doc.text('(' + el.text + ')', SCRPLAY.x.parenthetical, doc.y, {
          width: SCRPLAY.width.parenthetical
        });
        break;
      case 'dialogue':
        doc.text(el.text, SCRPLAY.x.dialogue, doc.y, { width: SCRPLAY.width.dialogue });
        doc.moveDown(1);
        break;
      case 'transition':
        doc.text(el.text.toUpperCase() + ':', SCRPLAY.x.transitionRight, doc.y, {
          align: 'right',
          width: SCRPLAY.width.action
        });
        doc.moveDown(1);
        break;
    }
  });
}

function paginate(doc) {
  const range = doc.bufferedPageRange();
  for (let i = 1; i < range.count; i++) {  // skip title page
    doc.switchToPage(i);
    doc.font(SCRPLAY.font).fontSize(SCRPLAY.fontSize);
    doc.text(`${i}.`, SCRPLAY.width - 90, 36, { align: 'right', width: 50 });
  }
}
```

### Verification (do before delivery)

- Open the generated PDF and confirm:
  - Page geometry (US Letter, 1.5" left margin)
  - Font is monospace Courier (or Courier Prime), 12pt — one inch = 10
    characters
  - Sluglines left-aligned at 1.5", uppercase, plain weight
  - Character cues at 3.7" from left
  - Dialogue at 2.5" from left, 3.5" wide
  - Page numbers top-right, format `N.` (with period)
  - Title page has no page number
  - First body page has no page number (page 2 is `2.`)

### When the source is not Fountain

If the source is a screenplay in DOCX or PDF format and being
re-rendered, run it through the importer (`screenplay-importer.md`)
to convert to a normalised scene list, then generate the screenplay
PDF from the normalised structure using the layout above.
