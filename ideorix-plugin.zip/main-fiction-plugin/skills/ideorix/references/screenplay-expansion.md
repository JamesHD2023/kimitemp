---
name: screenplay-expansion
description: "Expansion-aware Architect + Writer mode for screenplay-to-novel adaptation — locks plot to the source and gives the Writer licence to expand interiority, sensory detail, and subtext"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Screenplay Expansion Mode (Architect + Writer)

## File-Write Hygiene (MANDATORY)

Expansion writes produce large screenplay files. The chained-
Edit truncation safeguard documented in `core-pipeline.md`
§ Chained-Edit Truncation Safeguard applies in full to every
expansion write: Prefer Write over chained Edit, cap Edit
replacements at ~2 KB, run `scripts/word-count-check.sh` after
every screenplay file this expansion writes or edits, and
verify on-disk integrity via Bash before declaring expansion
complete. **HARD GATE — BLOCKING** — truncation MUST be
repaired before downstream stages read the expanded file.

## File Location Discipline (MANDATORY)

**All expansion outputs — expanded scene briefs, scene cards,
expanded screenplay pages, beat refinements — MUST be written
into the canonical project folder at
`~/Documents/Ideorix-Projects/[Title]/`.** If this expansion
mode is invoked outside an established project context, the
upstream agent (Screenplay Agent / Adapt flow) is responsible
for ensuring the project-folder bootstrap has run; if it has
not, this file's Architect / Writer pair MUST not produce
output to a working directory or sandbox path. See
`core-pipeline.md` § File Location Discipline for the
canonical layout and the Bash-Direct Write + Verify protocol.

This file specifies how the Architect and Writer behave differently
when the project mode is `screenplay_adaptation`. It layers on top of
the normal Architect (`blueprint-protocol.md`) and Writer (`prose-protocol.md`)
protocols — it does NOT replace them. Everything the normal pipeline
does still applies. This file defines the additions, the locks, and
the licence boundaries.

**Supported tiers:** All 5 length tiers (Short Story, Novelette,
Novella, Standard Novel, Epic Novel) with per-tier expansion ratio
calibration.

**Supported POV modes:** Single-POV, Dual-POV, Multi-POV (3+).

**Supported input formats** (handled by the importer — this file is
format-agnostic): Fountain, FDX, DOCX, text-layer PDF.

**Activation.** This mode activates automatically when
`engine-data/project-config.md` contains `source: screenplay` and
`adaptation_mode: screenplay_adaptation`. See
`screenplay-importer.md` for how that flag is set.

## The core principle

> **Faithful plot. New prose.**

Every plot event, every character action, every scripted beat must
trace back to the source screenplay. What the novel adds is what
novels are for — interiority, sensory layering, pacing through prose
rhythm, and the subtext a performance would have carried.

The adaptation writer does NOT:
- Invent new plot events
- Introduce characters not in the screenplay
- Add new locations beyond what the screenplay contains
- Create relationships, backstories, or motivations contradicted
  by the screenplay
- Drop scripted scenes or scripted beats
- Rearrange scene order (the screenplay's sequence is the novel's
  sequence)
- Change a character's decisions or outcomes

The adaptation writer DOES:
- Give every scene the interior life of the POV character — thoughts,
  feelings, memories triggered by the scene, sensory impressions
- Expand "INT. KITCHEN — DAY" into a fully-rendered sensory environment
  (smell of coffee, clock on the wall, sunlight through the blinds,
  the particular cold of the tile underfoot)
- Add the POV character's subtext to every dialogue exchange — what
  they're thinking between lines, what they notice about the other
  character's tone/face/posture, what they're afraid to say
- Vary pacing through prose rhythm — short sentences in action, long
  winding sentences in reflection, staccato fragments at the emotional
  peak
- Turn parentheticals (`(whispered)`, `(with disgust)`) into prose
  around the dialogue — action beats, internal reactions, descriptive
  tags — so the parenthetical's intent lands without being stated
- Add breathing-space scenes the screenplay elided — travel between
  locations, the seconds after a door closes, the morning that
  follows a confrontation — but only if the screenplay implies them
  and the user has approved the beat

## Architect modifications (brief-time)

When `adaptation_mode: screenplay_adaptation`, the Architect
(see `blueprint-protocol.md`) modifies its brief generation as follows:

### Load the scene-to-chapter mapping

Before generating the Chapter N brief, read
`engine-data/scene-to-chapter-map.md` and
`engine-data/screenplay-source.md`. Identify which source scenes are
mapped to Chapter N. These are the chapter's locked content. Load
them into the brief as the SOURCE MATERIAL section.

### Source material section (new brief section)

Every adapted chapter brief includes a new SOURCE MATERIAL section at
the top, before the Chapter Purpose and Beats sections:

```
═══ SOURCE MATERIAL (LOCKED — screenplay scenes ↓) ═══

Scene {N}: {slugline}
Characters present: {list}
Action (from screenplay):
{exact action lines, preserved verbatim}
Dialogue (from screenplay):
{SPEAKER (parenthetical): "line"}
{SPEAKER: "line"}
Transition: {CUT TO: etc, if any}

Scene {N+1}: {slugline}
...

═══ END SOURCE MATERIAL ═══
```

The SOURCE MATERIAL is the Architect's contract. Every beat in the
brief must trace to a line or action block in this section. The
Architect may NOT introduce beats from outside the scenes mapped to
this chapter.

### Expansion targets section (new brief section)

Every adapted chapter brief includes an EXPANSION TARGETS section
that specifies what the Writer must add beyond the source:

```
═══ EXPANSION TARGETS (WHAT THE WRITER ADDS) ═══

Source word count (this chapter's scenes): {N}
Target chapter word count: {target}
Expansion ratio: {target/source}x

Interiority beats required ({N} minimum):
- What is {POV character} thinking as Scene 1 opens?
- What does {POV character} notice about {other character} during
  the Scene 1 exchange that the camera couldn't show?
- What memory or association is triggered by {specific detail}?
- What is {POV character} NOT saying, and why?
- How does the scene change {POV character}'s internal state?

Sensory layering required (across this chapter):
- {Location 1}: at least 3 sensory details beyond visual
- {Location 2}: at least 3 sensory details beyond visual
- Time-of-day grounding: {morning/night/etc.} must shape the prose

Subtext opportunities (from parentheticals + performance cues):
- Scene {N} dialogue exchange "{line}": the screenplay's
  parenthetical "{whispered}" / "{with disgust}" — translate into
  prose around the dialogue, not dialogue tags
- {other subtext notes from the action lines}

Pacing choices:
- {which scene carries the chapter's tension peak}
- {where the prose should slow down for reflection}
- {where rhythm should shift to fragments or long carry-throughs}

═══ END EXPANSION TARGETS ═══
```

### Brief constraints

Under `screenplay_adaptation` mode, the Architect's brief must:

1. **Lock every plot beat to a source scene.** The Beats section lists
   each scripted beat with its source scene number: "Beat 3 (from
   Scene 17): Ben finds the letter in the drawer."
2. **NOT introduce a Chekhov's gun that isn't in the screenplay.** The
   screenplay already resolves its own setups. Section 14 (Guns) is
   locked at import time from action-line object scanning and stays
   locked.
3. **NOT introduce new characters.** If the brief mentions a character,
   that character must be in `engine-data/entity-canon.md`. Any new
   entity must route through the NEW ENTITIES PENDING APPROVAL
   workflow (see `world-canon.md` Phase 2D) — the user reviews and
   either approves (screenplay had an unlisted walk-on) or rejects
   (prevents Architect drift).
4. **Preserve dialogue attribution.** If Scene 17 has Ben saying "I
   already told you" and Sarah responding "(softly) You didn't,"
   the brief's Dialogue section quotes both lines verbatim and notes
   the parenthetical. The Writer will decide how much to preserve
   verbatim in prose (per the dialogue handling policy in
   project-config.md).
5. **Respect the dialogue handling policy.** `dialogue_handling:
   verbatim | natural | paraphrase` from project-config.md governs
   how strictly the Writer preserves scripted lines. The Architect
   passes this policy through to the Writer prompt.

### What the Architect does NOT add in screenplay mode

- New scenes not in the source
- New beats beyond what the scenes contain
- New characters (even walk-ons — those must go through PENDING
  APPROVAL)
- New objects that become Chekhov's guns
- Subplots the screenplay didn't establish
- Backstory not implied by the screenplay
- Relationships between characters not evident in the source

## Writer modifications (prose-time)

When `adaptation_mode: screenplay_adaptation`, the Writer
(see `prose-protocol.md`) writes prose with the following modifications:

### The expansion licence

The Writer IS permitted to:

1. **Write the POV character's interiority freely.** Thoughts,
   feelings, memories, sensory impressions, anticipations, regrets,
   body sensations, emotional reactions. The camera couldn't show
   these; the novel must. Interiority is where the novel lives.

2. **Render setting into full sensory environment.** A slugline
   "INT. KITCHEN — DAY" becomes prose that establishes the kitchen
   as a place the POV character inhabits: smells, textures,
   temperature, light quality, sound, the specific objects that
   matter to this character in this moment.

3. **Expand action lines into full dramatic scenes.** A single action
   line "Ben crosses to the sink" becomes a paragraph that includes
   what Ben's body does, what his eyes catch on the way, what he's
   thinking, what the kitchen's atmosphere does to him.

4. **Turn parentheticals into prose.** `(softly)` becomes "she said,
   her voice barely above the hum of the fridge" or "the word came
   out small, like she was already bracing for him to pull away" —
   whichever carries the parenthetical's intent better in prose.

5. **Add breathing-space between scenes.** A screenplay cuts between
   scenes with a transition; a novel often needs a paragraph of
   transit. Between Scene 17 (kitchen confrontation) and Scene 18
   (Ben driving), the novel can include the seconds of Ben gathering
   his coat, the walk to the car, the way the rain feels, the radio
   he doesn't turn on. This is expansion, not invention.

6. **Choose dialogue tag variation.** Screenplays use character cues
   (BEN:). Novels vary: "he said", "she asked", action beats ("Ben
   set down the mug"), and occasional unattributed lines when the
   context is clear. The Writer applies standard novel dialogue-tag
   craft while preserving the lines themselves.

### Prose-quality safeguards (CRITICAL — read before generating interiority)

The expansion licence above grants the Writer the largest single block
of new prose in the manuscript pipeline: ~45% interiority + ~25%
sensory environment per chapter at the Novella tier (and higher at
Standard / Epic tiers). This is the prime real estate for AI-tell prose
patterns — specifically the **character-inference** family that reads
as confidently literary while saying nothing the reader can verify.

Before generating any interiority or sensory paragraph, the Writer must
apply the **Character-Inference Patterns** section of `prose-humaniser.md`
as a pre-write filter, not just a post-write fix. The forbidden
constructions:

- "the timing / economy / care / precision of [a person] who has…"
- "there is something [adjective] about the way [she/he] [verbs]…"
- "as if [she/he] had / has been / were…" (used to imply backstory)
- "in a way that suggests / implies / hints at…"
- "[she/he] is the kind of [person] who…"
- "it [is / was] the kind of [thing / silence / look] that…"
- "[she/he] has the [look / way / quality] of [someone] who…"

Replace every instance with the literal observable detail that would
have produced that inference. Show the action; let the reader earn the
conclusion.

Industry readers and trained beta readers spot these patterns on
**page one**. The expansion-aware Writer's value proposition is the
quality of the interiority and sensory layering — if those paragraphs
read as AI-pattern prose, the entire adaptation reads as AI even though
the plot is locked to the screenplay. The humaniser will catch
violations post-hoc, but pre-write filtering produces better prose with
fewer rewrites.

### The expansion hard locks

The Writer MAY NOT:

1. **Invent plot events.** Every action, every decision, every
   character choice must trace to the source. If the prose has
   Ben making a phone call, that phone call has to be in the
   screenplay. If it isn't, the Writer has drifted and the Outline
   Conformance Agent will flag the chapter as FAIL at brief-time.
2. **Invent characters.** Every proper noun must be in the Entity
   Canon. The Canon Compliance Check (see `quality-gate.md`) runs
   mechanically — any name not on the canon is CRITICAL drift.
3. **Change a character's outcome or decision.** If the screenplay
   has Sarah leaving at the end of Scene 23, the novel must have
   Sarah leaving at the end of the prose that renders Scene 23.
4. **Drop scripted dialogue.** Under `dialogue_handling: verbatim`,
   every scripted line must appear in the prose. Under
   `dialogue_handling: natural`, up to 20% may be paraphrased for
   novel rhythm. Under `paraphrase`, the Writer may treat scripted
   dialogue as a guide.
5. **Add scripted dialogue that isn't in the source.** The POV
   character may THINK things the screenplay doesn't contain, but
   any character may not SAY things the screenplay doesn't contain.
6. **Skip parentheticals.** Every parenthetical must land in the
   prose — either as an action beat, an interior reaction, or a
   descriptive tag. The parenthetical is the playwright's
   performance note; the novel has to perform it.

### Dialogue handling policies

The policy is set at import time in `project-config.md`. The Writer's
prompt includes the policy verbatim.

**verbatim (default for your own screenplays):**
- Every scripted line appears in the prose exactly as written.
- Parentheticals become action beats or descriptive tags around
  the dialogue.
- Dialogue attribution varies (said, asked, action beats) but the
  words are unchanged.
- If a line reads as stilted in prose, the Writer may add an action
  beat before or after to soften it, but may not change the words.

**natural (recommended for external adaptations):**
- Up to 20% of scripted lines may be paraphrased for novel flow.
- Paraphrasing is allowed only when:
  - The scripted line repeats information the prose already
    conveyed (redundant in novel form)
  - The scripted line reads as stilted in prose (e.g., exposition
    that needs softer delivery)
  - The scripted line's meaning is clear without the exact words
- The meaning must be preserved exactly. The emotional beat must
  land the same way.
- Every paraphrased line is logged in the chapter's verification
  report so the user can review.

**paraphrase (looser adaptation):**
- Scripted dialogue is a guide, not a script.
- The Writer may rewrite lines for novel rhythm as long as the
  meaning, emotional beat, and plot function are preserved.
- Exact lines are preserved only when they're the emotional peak
  of a scene or clearly meant to be iconic ("I already told you,"
  if it's the line the whole scene hinges on).

### Expansion ratio calibration

The Writer's word-count target for each chapter comes from the
scene-to-chapter chunker (~2,500 words per chapter for Novella tier,
Phase 1). The source scenes mapped to this chapter have a certain
word count (typically 800–1,200 words of action + dialogue per
chapter's worth of scenes). The expansion ratio for this specific
chapter is `target / source`, typically 2.2x–3x for Novella tier.

The Writer allocates that new wordage as:
- **~45% interiority** — POV character's thoughts, feelings,
  memories, body sensations, emotional beats
- **~25% sensory environment** — rendering the setting into full
  sensory detail beyond the slugline
- **~15% dialogue craft** — tag variation, action beats around
  dialogue, pacing the exchanges
- **~10% transitional prose** — arriving at scenes, leaving scenes,
  movement between beats
- **~5% preserved source** — the action and dialogue lines rendered
  in novel form

These percentages are guidance, not rules. The Writer adjusts per
scene — a dialogue-heavy confrontation scene may shift toward 60%
dialogue craft; a slow reflective scene may shift toward 70%
interiority.

## Outline Conformance Agent modifications

In screenplay-adaptation mode, the Outline Conformance Agent (see
`outline-conformance.md`) treats the scenes mapped to the current
chapter as the canonical outline. Its 6 checks apply as follows:

| OC Check | Screenplay mode adaptation |
|----------|----------------------------|
| A. Chapter Goal Match | The brief's Chapter Purpose must match the dramatic function of the source scenes (from their synopses if present, else from the action arc) |
| B. Required Beat Delivery | Every source scene's action and dialogue must appear in the brief's Beats section, mapped explicitly to a source scene number |
| C. No Silent Drops | Any source scene beat not in the brief is a DROP and a FAIL |
| D. No Unauthorised Additions | Any beat in the brief not traceable to a source scene is an ADDITION and a FAIL |
| E. Zoom-Out Sustainability | Remaining scenes ≤ remaining chapters × average scenes-per-chapter (from the chunker) |
| F. Chekhov Gun Room | In adaptation mode: any new gun in the brief that isn't from the screenplay is an UNAUTHORISED ADDITION (Check D failure) |

The OC Agent's PASS/WARN/FAIL verdict is surfaced on the Progress
Dashboard (as normal) and feeds the Canon Drift + Outline
Conformance lines.

## Running Banlist + Humaniser interaction

The Running Banlist (see `prose-humaniser.md` Running Banlist
section) operates identically in adaptation mode. Recurring patterns
still promote to opening hard constraints.

The adaptation-specific consideration is **dialogue preservation**.
A scripted line like "I just couldn't believe it" contains the "just"
AI-crutch filler, but under `dialogue_handling: verbatim` the Writer
is contractually obliged to keep it as written. The Humaniser must
NOT rewrite preserved dialogue or it will silently break the verbatim
contract.

**Detection and exemption mechanism** is specified in
`prose-humaniser.md` "Adaptation Mode — Dialogue Preservation
Exemption" section. Summary:

1. The Humaniser loads `engine-data/screenplay-source.md` and builds
   a preserved-dialogue set (every scripted dialogue line keyed by
   scene + speaker).
2. For each quote in the chapter prose, the Humaniser looks up the
   speaker (from the attached dialogue tag or adjacent action beat)
   and searches the preserved-dialogue set scoped to the scenes
   mapped to the current chapter.
3. Under `verbatim`, a matching quote is PRESERVED (exempt from all
   Humaniser bans). A non-matching quote is flagged as DIALOGUE
   DRIFT — the Humaniser does NOT rewrite; it alerts the user.
4. Under `natural`, matching quotes are preserved, paraphrased
   quotes are allowed (up to 20% of total dialogue), and the
   Humaniser logs paraphrase density in the verification report.
5. Under `paraphrase`, every quote is treated as novel dialogue and
   is fully subject to Humaniser rules.

**What the exemption covers:** the text inside quote marks.
**What it does NOT cover:** narration, description, interiority,
sensory environment, transitional prose — those are novel prose and
subject to normal Humaniser rules with no exemption.

Patterns found ONLY inside preserved-dialogue blocks are NOT promoted
to the Running Banlist's HARD CONSTRAINTS section — they're contract
obligations, not drift. Patterns found in narration are promoted
normally.

## Checkpoint additions

The pipeline checkpoint (see `core-pipeline.md`) gains one flag for
adaptation projects:
```
adaptation_mode: screenplay_adaptation
scenes_mapped: {chapter N's source scene list}
expansion_ratio: {target/source for this chapter}
dialogue_preserved: {N} verbatim lines / {N} paraphrased / {N} added
```

The last line is populated by the Writer at chapter completion and
feeds the verification report.

## What to tell the user

When Chapter 1 is about to begin, display this notice:

```
Screenplay Adaptation Mode — expansion brief
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Source:           {title} ({author})
Length tier:      Novella (~40,000 words / 16 chapters)
POV character:    {name}
Dialogue policy:  {verbatim | natural | paraphrase}
Expansion ratio:  {ratio}x

Every plot beat is locked to the screenplay. The Writer expands:
  — Interiority (~45% of new wordage)
  — Sensory environment (~25%)
  — Dialogue craft (~15%)
  — Transitional prose (~10%)
  — Preserved source (~5%)

The Outline Conformance Agent treats the screenplay as the canonical
outline. Any drift is caught at brief-time.

Proceeding to Chapter 1 (source scenes: {N..M}).
```

Then the normal pipeline runs: Architect brief → OC check → User
Review Gate → Writer pre-load (banlist + canon) → Writer → prose
review gate → Humaniser → verification → Progress Dashboard →
user approval → next chapter.

## Per-tier calibration

Each length tier has its own expansion character. The Writer's
allocation percentages (interiority / sensory / dialogue craft /
transitional / preserved source) shift based on how much expansion
room the tier gives.

### Short Story tier (~8,000 words / 5 chapters / ~1,600 words/ch)

**Typical expansion from a feature screenplay:** 0.5x (COMPRESSION).

This is a compression mode, not an expansion mode. The source is
SHORTER than the target novel will be. See "Compression Mode" below
for the protocol. The Writer's job is to condense, pick the most
dramatic scenes, and preserve plot shape while dropping lower-value
source material.

**Use case:** a feature screenplay adapted as a short story for a
magazine, an anthology, or a promotional piece.

### Novelette tier (~12,500 words / 9 chapters / ~1,400 words/ch)

**Typical expansion from a feature screenplay:** 0.8x (TIGHT /
mild compression).

Still compression-leaning for standard-length features. The Writer
preserves all major plot beats but may compress dialogue exchanges
and merge minor scenes. Interiority is added sparingly — the novel
stays close to the source's dialogue-driven pacing.

**Allocation (when tier is TIGHT, ratio 0.9-1.5):**
- ~15% interiority (minimal)
- ~15% sensory environment
- ~30% dialogue craft + source-preservation rendering
- ~10% transitional prose
- ~30% preserved source

### Novella tier (~40,000 words / 16 chapters / ~2,500 words/ch)

**Typical expansion from a feature screenplay:** 2.5x–3x (IDEAL).

The sweet spot. The source plot is dominant, the Writer has enough
wordage to expand interiority and sensory environment meaningfully,
and dialogue preservation is comfortable.

**Allocation (the default IDEAL baseline):**
- ~45% interiority
- ~25% sensory environment
- ~15% dialogue craft
- ~10% transitional prose
- ~5% preserved source rendered in novel form

### Standard Novel tier (~75,000 words / 30 chapters / ~2,500 words/ch)

**Typical expansion from a feature screenplay:** 4.5x–5x (STRETCH).

Significant expansion. Most chapters cover 1–2 source scenes at most.
Interiority and sensory layering dominate. The Writer may add
transitional material between scenes (travel, reflection, the
aftermath of a scene before the next begins) — but only where the
screenplay implies the time passing.

**Allocation (STRETCH mode):**
- ~55% interiority
- ~20% sensory environment
- ~10% dialogue craft
- ~12% transitional prose (more than other tiers — you're filling
  time between scripted moments)
- ~3% preserved source

**Warning at setup:** "You're building a Standard Novel from a
~15,000-word feature — a 5x expansion. Most of the novel's word
count will be new interiority and sensory layering. Plot remains
locked to the screenplay via the Outline Conformance Agent, but
the novel's voice will dominate the experience. Confirmed?"

### Epic Novel tier (~120,000 words / 40 chapters / ~3,000 words/ch)

**Typical expansion from a feature screenplay:** 7x–8x (EXTREME).

The chapter-to-scene mapping is typically 1:1 at this tier (40
source scenes → 40 chapters). Each chapter is a 3,000-word
meditation on a single scene's content. The Writer invents a
great deal of novelistic material — backstory flashes, layered
memories, extended reflection on every beat, and often
transitional chapters for travel/aftermath.

**Allocation (EXTREME mode):**
- ~60% interiority (the dominant mode)
- ~15% sensory environment
- ~8% dialogue craft
- ~15% transitional prose
- ~2% preserved source

**Strong warning at setup:** "You're building a 120,000-word Epic
Novel from a ~15,000-word feature — an 8x expansion. The source
screenplay accounts for ~2% of the final novel's wordage. Most of
the novel will be interiority, sensory layering, memory, reflection,
and transitional material I invent (within the screenplay's plot
frame). Plot is locked via the OC Agent, but this is really a
novelisation project in the fullest sense — readers of the novel
will experience a story that the screenplay only sketched.
Confirmed?"

## Compression Mode (COMPRESSION ratios only)

When `expansion_mode: compression` (ratio < 1.0), the Writer's job
inverts. Instead of expanding, the Writer condenses. The expansion
hard locks still apply (no new plot, no new characters, no new
locations), but the expansion licence becomes a compression licence:

**The Writer MAY drop:**
- Minor scenes with no plot consequence (walk-ons, transitional
  beats, atmospheric inserts)
- Redundant dialogue exchanges that repeat information
- Extended action sequences that can be condensed to their dramatic
  essence
- Parentheticals where the performance cue is obvious from context
- Scenes flagged by the user as "drop if needed"

**The Writer MUST NOT drop:**
- Scenes that establish a character for the first time
- Scenes that resolve a plot thread
- Scenes whose dialogue is the emotional peak of an arc
- The opening and closing scenes
- Scenes the Outline Conformance Agent has flagged as
  plot-critical

**Interiority in compression mode:** minimal. A short-story-length
adaptation of a feature is dialogue-driven and action-driven, with
interiority limited to brief POV moments at scene transitions.

**Dialogue in compression mode:** preserved verbatim for the
emotional peaks, paraphrased or compressed for functional exchanges.

The user is warned at setup that compression mode is unusual — most
screenplay adaptations are expansion projects. Compression is offered
for cases where the user genuinely wants a short-form adaptation
(magazine short story, anthology piece, promo).

## Multi-POV mode

When `pov_type: dual | multi`, the Architect and Writer apply these
additional rules:

### POV per chapter is locked at import time

The importer's POV assignment step (see `screenplay-importer.md`
POV selection gate) assigns a POV character to every chapter based
on the chosen mode (alternating, scene-driven, or user-assigned).
This assignment is written to `engine-data/scene-to-chapter-map.md`
and is LOCKED for the project.

The Architect reads the POV assignment for the current chapter at
brief-generation time and passes it to the Writer in the brief's
header:

```
CHAPTER N — POV: {character name}
```

The Writer loads the voice profile for that specific POV character
(from Story Bible Section 3 — each POV character has their own
voice entry) and narrates the chapter locked to that character's
perspective.

### Voice contrast is mandatory (not optional)

Every POV character in a Dual or Multi-POV project MUST have a
distinct voice profile stored in the Story Bible. The voice profiles
govern:
- Sentence rhythm and length distribution
- Vocabulary range (formal vs colloquial, regional markers,
  profession-specific language)
- Perception filter (what this character notices first — physical
  detail, people, abstractions, money, danger)
- Metaphor sources (what their internal associations draw from)
- Emotional processing style (externalised, suppressed, intellectualised)
- Dialogue tag preferences (if any)

If a POV character is missing a voice profile, the Writer STOPS
and alerts the user. Running multi-POV without voice profiles
produces chapters that are indistinguishable from each other — the
single biggest failure mode for multi-POV novels.

### POV hand-off rules at chapter boundaries

When the POV character changes between Chapter N and Chapter N+1:
- Chapter N closes with a beat that naturally sets up a POV shift
  (the old POV character exits the scene, or the scene ends, or
  a major transition is signalled)
- Chapter N+1 opens grounded in the new POV character — the first
  paragraph establishes that the reader is now in a different head
- The new POV character's voice profile is fully engaged from the
  first sentence; no "neutral narration" bridging allowed
- The Writer may NOT narrate Chapter N+1's opening from Chapter N's
  POV character's perspective, even briefly. Voice drift across
  POV boundaries is flagged CRITICAL by the verification suite.

### Scene-driven POV adjustment during writing

If the Writer, during chapter generation, finds that the assigned
POV character is not actually present in most of the chapter's
source scenes (an edge case the chunker may have missed), the
Writer STOPS and flags the mismatch:

```
⚠ POV MISMATCH — Chapter N is assigned to {character X} but only
{N} of {M} source scenes have that character present. Suggesting
reassignment to {character Y} who is present in {N} source scenes.
```

The user can approve the reassignment, keep the original assignment
(accepting that some scenes will be filtered through an absent
POV character's perspective — e.g., the POV character learning
about the scene second-hand), or split the chapter into multiple
chapters with different POV characters.

### Multi-POV verification additions

The 6-agent verification suite gains one additional check in
multi-POV mode: **POV voice distinctiveness**. The Arc Analyst
compares the chapter's prose against the POV character's voice
profile (from Story Bible Section 3) and scores voice match. A
score below 80 is a CRITICAL drift indicating the Writer has
produced generic narration instead of locked POV.

This check is per-chapter. Cross-chapter voice distinctiveness
(can a reader tell who's narrating from a random paragraph?) is
evaluated by the Batch Editor every 5 chapters.

## Format-agnostic operation

This file is input-format-agnostic. The importer
(`screenplay-importer.md`) has separate parsers for Fountain, FDX,
DOCX, and PDF, but all four produce the same in-memory structure
and the same `engine-data/screenplay-source.md` output. The
Architect and Writer never see raw Fountain or FDX or DOCX or PDF —
they read the normalised scene list from `screenplay-source.md`.

Adding a new input format in the future only requires adding a new
parser to the importer. This file does not change.
