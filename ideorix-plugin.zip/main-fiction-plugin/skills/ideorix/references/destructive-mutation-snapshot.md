---
name: destructive-mutation-snapshot
description: "Engine-neutral binding/protocol. Mandatory snapshot discipline for any tool that overwrites user-approved content (humaniser, proofreader, copy editor, batch editor, edit-and-revise, repetition sweep, surgical fixes, restructure tools). Before any in-place overwrite of a user-owned file, the tool MUST copy the current version to engine-data/snapshots/ with an audit-trail-compatible filename. Snapshot path is reported in the tool's output so the user can revert. Closes the Destructive-Success silent-failure shape: the operation succeeds too well and the user has no path back. Authored v2.7.41 in response to a real production incident where the humaniser overwrote an approved chapter with 19 unauthorised changes and no recoverable original existed."
version: "2.7.41"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Destructive-Mutation Snapshot Discipline

A binding/protocol spec applied as a HARD GATE before any tool
overwrites user-approved content. Authored v2.7.41 in direct
response to a production incident: a user's chapter 1 was
overwritten by the humaniser with 19 documented changes; the
user reviewed the result, found it unrecognisable from the
version they had originally approved, and discovered no
snapshot existed for reversion. The path Claude pointed them
to (where it claimed the original would be saved) did not
exist on disk.

## The recurring failure shape

The `silent-failure-audit.md` catalog tracks operations that
return success metadata diverging from their actual effect.
Most rows describe **failed** operations claiming success
(write claimed success but wrote nothing; subagent returned
"complete" with stub content; etc.).

This binding addresses the inverse failure shape — operations
that **succeed too well**:

> A tool overwrites a file the user has approved. The
> operation reports success and the new content is correct
> by the tool's own standards. But the user, on review, finds
> the new content materially different from what they
> approved — and no snapshot exists for them to revert to.
> The user has lost work and has no path back.

This is destructive-success. The user did not consent to the
specific changes (only to "running the tool"); the
implementation has no preservation step; the tool's report
does not point at a recoverable original because no
recoverable original was created.

## What this binding requires

Before any tool overwrites a user-owned file with substantive
changes, the tool MUST:

1. **Snapshot the current file** to a designated audit-trail
   location BEFORE the overwrite Write tool is invoked.
2. **Verify the snapshot succeeded** via `bash ls -la` on the
   snapshot path immediately after the cp/Write that created
   it. The snapshot is the user's reversion path; if it
   doesn't exist on disk, the binding has failed.
3. **Report the snapshot path in the tool's output** so the
   user can find it without searching.
4. **Only then proceed** to overwrite the user file.

Failure of step 1 or 2 → STOP. Do not overwrite. Surface the
snapshot failure to the user and abort the tool run.

## Snapshot path convention

```
engine-data/snapshots/{stem}.pre-{tool}.{ISO-timestamp}.{ext}
```

Where:
- `{stem}` — original filename without extension (e.g.
  `ch01`, `research-bible`, `entity-canon`)
- `{tool}` — the tool name taking the snapshot in
  hyphen-lowercase form (e.g. `humaniser`, `proofreader`,
  `copy-editor`, `batch-editor`, `repetition-sweep`,
  `surgical-fixes`)
- `{ISO-timestamp}` — UTC ISO 8601 with `:` replaced by `-`
  for filesystem safety (e.g. `2026-05-10T12-34-56Z`)
- `{ext}` — original file extension (`md`, `docx`, etc.)

Examples:

```
engine-data/snapshots/ch01.pre-humaniser.2026-05-10T12-34-56Z.md
engine-data/snapshots/ch01.pre-proofreader.2026-05-10T13-22-15Z.md
engine-data/snapshots/research-bible.pre-batch-editor.2026-05-10T14-08-00Z.md
engine-data/snapshots/manuscript.pre-typography-sweep.2026-05-10T15-44-30Z.docx
```

Multiple snapshots of the same file accumulate naturally
(timestamps differ). Reverting is a `cp` operation the user
runs themselves; the tool does not auto-revert.

The `engine-data/snapshots/` directory must be created on
first snapshot via `mkdir -p` (idempotent). A `.gitkeep` is
not required.

## Tools that MUST invoke this binding

Every tool in the engine that overwrites a user-owned file
with substantive changes is bound by this discipline.
Currently:

| Tool | Spec | What it overwrites |
|---|---|---|
| Humaniser | `prose-humaniser.md` | `engine-data/chapters/ch{NN}.md` |
| Stage 2 Proofreader | `editorial-suite.md` Stage 2 | Chapter prose, in-place |
| Stage 3 Copy Editor | `editorial-suite.md` Stage 3 | Chapter prose, in-place |
| Stage 4 Developmental Editor | `editorial-suite.md` Stage 4 | Manuscript / chapter, in-place |
| Stage 4.5 Repetition Sweep | `repetition-sweep.md` (≥40k) | Chapter prose, in-place |
| Batch Editor | `batch-editor.md` | Multiple chapters, in-place |
| Edit-and-Revise | `edit-and-revise.md` | User-targeted file |
| Surgical Fixes | `surgical-fixes.md` | User-targeted file |
| Heritage Text Refiner | `heritage-text-refiner.md` | Source text, in-place |
| Typography Sweep (curly→ascii or reverse) | `typography-sweep.md` | Manuscript, in-place |
| Format-* tools (when overwriting an existing export) | `format-*.md` | Output file |

When a NEW destructive tool is added to the engine, its spec
MUST cite this binding in its "File Output Discipline" or
equivalent section, and its execution procedure MUST include
the snapshot step before the overwrite.

## What this binding does NOT cover

- **Tool report files** (e.g. `engine-data/reports/ch01-humaniser-notes.md`)
  — these are tool-generated, not user-approved content; no
  snapshot needed.
- **Audit log files** (e.g. `engine-data/pipeline-checkpoint.md`)
  — these have their own integrity discipline (File-Write Hygiene
  + the v2.7.42 long-lived-state-file rule).
- **New file creation** — when a tool writes a file that did
  not previously exist, there's nothing to snapshot.
- **System / tooling files** (gitignored, build outputs, etc.)
  — out of scope.
- **User-rejected content** — if the user explicitly rejects
  a draft and asks for it to be discarded, the snapshot step
  is still taken (audit trail), but the user can manually
  delete the snapshot if they truly want it gone.

The discipline applies to user-approved content the user
might want to revert to. Everything else is covered by other
bindings.

## Snapshot retention

Snapshots accumulate without auto-deletion. A 30-chapter
manuscript with 3-4 destructive operations per chapter
produces ~100-120 snapshot files at ~5-10KB each → <2MB
total. Acceptable.

Users who want to clean up can `rm engine-data/snapshots/*`
at any point. The engine never deletes snapshots
automatically; the audit trail's value depends on its
permanence.

## Integration with File-Write Hygiene

The snapshot copy is itself a file-write operation and is
governed by the existing File-Write Hygiene binding
(`core-pipeline.md` § File-Write Hygiene). Specifically:

- The snapshot is written via `cp` (bash), NOT through the
  Write tool. `cp` is appropriate for verbatim file copy.
- Bash `ls -la` post-write verification applies (verify the
  snapshot file exists with non-zero size).
- The directory `engine-data/snapshots/` is created via
  `mkdir -p` on first use.

Cross-reference: `silent-failure-audit.md` rows 1, 2, 11
(Edit, Write, File-Write Hygiene bindings).

## Engine-neutral applicability

Both fiction and non-fiction engines own user-approved prose
content (chapters, bibles, canon files, project-config). Both
engines have tools that overwrite that content. The binding
applies identically; only the per-engine list of tools
varies.

## Concrete protocol (the standard execution)

This is the protocol every destructive tool must follow.
Adapt only the `{tool}` token and the target filename.

```bash
# Step 1: ensure snapshot dir exists
mkdir -p {project-path}/engine-data/snapshots

# Step 2: compute timestamp (UTC, filesystem-safe)
TS=$(date -u +"%Y-%m-%dT%H-%M-%SZ")

# Step 3: copy original to snapshot path
SRC={project-path}/engine-data/chapters/ch{NN}.md
SNAP={project-path}/engine-data/snapshots/ch{NN}.pre-{tool}.${TS}.md
cp "$SRC" "$SNAP"

# Step 4: verify snapshot succeeded (HARD GATE)
if [ ! -s "$SNAP" ]; then
    echo "FATAL: snapshot creation failed at $SNAP — destructive-mutation"
    echo "       binding requires a recoverable snapshot before overwrite."
    echo "       Aborting tool run. User content unmodified."
    exit 1
fi

ls -la "$SNAP"  # surface the snapshot to the user

# Step 5: only NOW invoke the overwrite Write tool
# (the tool's existing logic continues from here)
```

The protocol is intentionally a bash sequence, not a Class A
audit script — it runs INSIDE each tool's flow rather than
being dispatched separately. Inlining keeps the snapshot
co-located with the overwrite it precedes; the user always
sees the snapshot path in the same conversation turn as the
overwrite report.

## Snapshot path in tool reports

Every destructive tool's user-facing report MUST include a
"Snapshot" line in the report header:

```markdown
# Humaniser Report — Chapter 1

**Source:** engine-data/chapters/ch01.md
**Snapshot:** engine-data/snapshots/ch01.pre-humaniser.2026-05-10T12-34-56Z.md
**Reverting:** `cp engine-data/snapshots/ch01.pre-humaniser.2026-05-10T12-34-56Z.md engine-data/chapters/ch01.md`

## Detection Pass
[...]
```

The "Reverting" line gives the user a copy-paste command to
restore. No assumptions about user filesystem expertise.

## Failure modes prevented

Per `silent-failure-audit.md` row 37 (added v2.7.41):

- **Destructive-success cascade** — a tool the user authorised
  to "run on" a chapter makes substantive changes that the
  user, on review, would not have approved at the granular
  level; the tool's report shows what changed but offers no
  path back; the user has lost approved work and must rewrite
  from memory or from a partial commit history. The discipline
  closes this shape by guaranteeing a snapshot exists before
  every overwrite.
- **Hallucinated-snapshot-path cascade** — Claude points the
  user at a snapshot path that doesn't exist on disk because
  no snapshot was ever taken; the user trusts the path
  because it sounds plausible; the user discovers the gap
  hours later. The discipline closes this by requiring the
  snapshot to be created and verified BEFORE the overwrite.
  If the snapshot fails, the overwrite never happens; the
  user's content is preserved.
- **Multi-tool-cascade** — chapter is humanised, then
  proofread, then copy-edited; each step overwrites without
  snapshotting; by the time the user reviews the final
  output and wants to compare to the original, the original
  is unrecoverable across three lossy steps. The discipline
  preserves intermediate states by snapshotting before each
  step; the user can compare any pair of versions.

## Adoption path for existing projects

For projects authored before v2.7.41 ships, no retroactive
snapshots can be created — those original states are lost.
Going forward, every destructive tool run from v2.7.41
onward creates snapshots. Existing projects can immediately
benefit; they just don't have history before the binding
shipped.

The first time a tool runs on a chapter under v2.7.41, the
snapshot it creates is the "post-Content-Writer-pre-tool"
state — the user's approved version BEFORE the destructive
tool runs. This is the version the user would want to revert
to if the tool's output is unsatisfactory.

## See also

- `silent-failure-audit.md` row 37 — catalog entry
- `prose-humaniser.md` — first tool retrofitted (v2.7.41)
- `editorial-suite.md` — Stages 2-4.5 retrofitted (v2.7.41)
- `batch-editor.md` — retrofitted (v2.7.41)
- `core-pipeline.md` § File-Write Hygiene — the broader file-write binding this extends
- `bash-output-verification.md` — the bash-mode verification for `cp` + `ls -la`
- `read-verification.md` — applies to any read-back of the snapshot
