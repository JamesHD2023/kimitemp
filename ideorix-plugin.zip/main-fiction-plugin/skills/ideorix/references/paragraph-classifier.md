---
name: paragraph-classifier
description: "Per-paragraph semantic classification (Class B audit, engine-neutral). Produces a structured classification table assigning every paragraph in a chapter to one of five categories (ANCHOR-NARRATIVE / ANALYTICAL-AUTHOR / EXPOSITORY-THIRDPARTY / DIALOGUE / META-STRUCTURAL). Consumed by voice-metrics-audit.sh to compute semantic FP ratio (analytical-paragraphs-only denominator) — a higher-fidelity drift signal than the v2.7.65 raw FP ratio. Output is also read by voice-restoration-brief.md as a starting point for the brief's own classification pass."
version: "2.7.67"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Paragraph Classifier

A per-chapter Class B audit that assigns every paragraph in a
chapter to one of five semantic categories. The classification
artifact lets the voice audits compute a HIGHER-FIDELITY drift
signal — the "semantic FP ratio" measures first-person presence
only within paragraphs where author-voice belongs, instead of the
v2.7.65 raw FP ratio which counts every paragraph including
expository / dialogue / structural ones.

## Why this audit exists

The v2.7.65 voice-metrics-audit's FP ratio is a syntactic proxy:
"paragraphs containing first-person pronouns / total paragraphs."
It catches catastrophic drift (Vol 2 of the user's series at 13
chapters of zero first-person was unmissable by any metric) but
produces false-INFO/WARN signals for chapters that legitimately
recess the author-voice:

- A memoir chapter with extended quoted dialogue (low FP because
  dialogue uses character voice, not author voice)
- A biography chapter detailing the subject's history from
  third-party sources (low FP because the subject IS the third
  party)
- A self-help chapter heavy on case studies (low FP because the
  cases ARE third-party narrative)

In each case the AUTHOR-VOICE register may be completely intact —
the chapter just has structural reasons for less first-person.
The semantic FP ratio disentangles the two: it asks "in
paragraphs where author-voice should be present, IS it?" instead
of "is first-person present in this chapter overall?"

## When this audit runs

User-invoked, like voice-restoration-brief. The classifier is not
part of the per-chapter automatic cycle — that would double the
subagent cost. The user invokes the classifier:

- once per chapter when they want a high-fidelity reading
- as a batch (one invocation per chapter) when establishing a
  baseline across the manuscript
- before invoking voice-restoration-brief, so the brief can use
  the classifier output as a starting point instead of doing the
  classification work itself

Trigger paths:

- `bash scripts/validate-dispatcher.sh "{project}" classify {N}`
  — emits a CLASS_B_AUDIT line for chapter N; engine dispatches
  the subagent
- `bash scripts/paragraph-classifier-dispatch.sh "{project}" {N}`
  — same effect, useful when scripting batches
- The voice-metrics-audit picks up the artifact automatically on
  next run; no re-invocation needed

## Class B dispatch

```
CLASS_B_AUDIT|paragraph-classifier|VOICE|references/paragraph-classifier.md|-
```

## Subagent task brief

> **Task: Paragraph Classifier**
>
> **Background.** A manuscript's per-chapter voice metrics need a
> higher-fidelity signal than "count paragraphs with first-person
> pronouns." You are producing the per-paragraph classification
> that lets the audit pipeline compute "first-person presence in
> paragraphs where author-voice belongs" instead. You are NOT
> rewriting prose. You are producing a structured classification
> table.
>
> **Inputs.**
> - `engine-data/voice-profile.md` — the project's voice register
>   declaration (read voice_prose_description to understand what
>   "author voice" means for this project)
> - `engine-data/chapters/ch{NN}.md` — the chapter to classify
>
> **Classification taxonomy.** Every paragraph maps to exactly one:
>
> | Class | Meaning | When author-FP is expected |
> |---|---|---|
> | ANCHOR-NARRATIVE | Author/narrator in the scene; sensory anchor; "I" or close-POV register | YES |
> | ANALYTICAL-AUTHOR | Author's analysis, reasoning, argument, generalisation; the voice the reader follows | YES (memoir-NF + guide-NF) or NO (biography-NF + reference-NF) per voice-profile |
> | EXPOSITORY-THIRDPARTY | Information about external subject (historical event, other person, citation, research summary) | NO |
> | DIALOGUE | Quoted dialogue dominant (>50% of paragraph is quoted speech) | NEUTRAL — dialogue carries character voice, not author voice |
> | META-STRUCTURAL | Chapter transitions, section headings rendered as paragraphs, scene-break devices | NEUTRAL |
>
> **Procedure.**
> 1. Read voice-profile.md voice_prose_description. This tells you
>    what register counts as ANCHOR-NARRATIVE / ANALYTICAL-AUTHOR
>    for this project. (A memoir's analytical paragraphs sound
>    different from a business book's analytical paragraphs;
>    the prose description disambiguates.)
> 2. Strip YAML frontmatter and headings from the chapter file.
> 3. Split on blank lines into paragraphs. Number them 1..N from
>    top.
> 4. For each paragraph, assign exactly one class. When a paragraph
>    is genuinely mixed (analytical author commenting on a quoted
>    passage), pick the DOMINANT mode by sentence count.
> 5. For each row, write a one-clause rationale citing what made
>    the call (a verb form, a discourse marker, the subject of the
>    sentences, the presence of dialogue quotes).
> 6. Compute the summary counts.
> 7. Produce the structured return.
>
> **Return contract (mandatory).**
>
> ```
> ## Chapter under review
> - Path: engine-data/chapters/ch{NN}.md
> - Total paragraphs: {N}
>
> ## Paragraph classifications
> | Para # | Lines | Class | Rationale (one clause) |
> |---|---|---|---|
> [one row per paragraph; N rows total]
>
> ## Summary
> | Class | Count |
> |---|---|
> | ANCHOR-NARRATIVE | {N} |
> | ANALYTICAL-AUTHOR | {N} |
> | EXPOSITORY-THIRDPARTY | {N} |
> | DIALOGUE | {N} |
> | META-STRUCTURAL | {N} |
> | TOTAL | {N} |
>
> ## Verdict
> One of: PASS | WARN
> - PASS: classification complete; all paragraphs accounted for
> - WARN: one or more ambiguous-class paragraphs flagged in
>   rationale (still a complete return; the WARN signals "human
>   judgement needed on these calls" for downstream tooling)
>
> ## One-Line Summary
> "PASS: ch{NN} — {N} paragraphs classified ({A} anchor + {B}
>  analytical = {A+B} author-voice paragraphs; {C} expository,
>  {D} dialogue, {E} structural)"
> ```
>
> **Discipline.**
> - Every paragraph gets exactly one class. No skipping. No
>   "multiple classes" rows.
> - Line numbers cite the chapter file as written, not paragraph-
>   index offsets.
> - Rationale is ONE CLAUSE, not a sentence. Tight. The artifact
>   is read by other tools; brevity matters.
> - Do NOT rewrite or paraphrase paragraphs in the rationale. If
>   a rationale is longer than ~15 words, it's too long — say
>   what cued the classification and stop.
> - If the chapter has zero paragraphs after frontmatter strip,
>   FAIL the return with a clear "empty chapter" message; do not
>   fabricate paragraphs.

## Engine HARD GATE on return

Per `subagent-output-verification.md`. Specific checks:

1. **Shape check.** All five sections present (`## Chapter under
   review`, `## Paragraph classifications`, `## Summary`, `##
   Verdict`, `## One-Line Summary`).
2. **Classification completeness.** Per-paragraph table row count
   matches the chapter's actual paragraph count (calculated from
   the chapter file post-frontmatter, with tolerance ±1 for parse
   edge cases). A missing row means a paragraph was silently
   dropped — that's the silent-failure shape this catalog has
   been fighting since row 1.
3. **Summary consistency.** Summary table TOTAL matches the
   per-paragraph row count.
4. **Class validity.** Every Class field is exactly one of the
   five taxonomy values (case-sensitive). No invented classes.
5. **Verdict / one-line consistency.** Verdict is PASS or WARN;
   One-Line Summary verdict-prefix matches.

After verification, the engine emits:

```
AUDIT|paragraph-classifier|VOICE|<verdict>|<one_line_summary>|<subagent_return_path>
```

## Artifact landing path

`engine-data/reports/validate/paragraph-classifier-ch{NN}-subagent.md`

Mirror the existing Class B return file convention. Once landed,
the artifact persists across sessions; voice-metrics-audit.sh
reads it on subsequent runs and emits the semantic FP ratio as a
ledger column. The artifact may be regenerated by re-invoking the
audit; the new artifact overwrites the old.

## How voice-metrics-audit consumes the artifact

When `paragraph-classifier-ch{NN}-subagent.md` exists for the
chapter being audited, voice-metrics-audit reads the Summary
section + the per-paragraph table and computes:

- `semantic_fp_ratio` = (FP-containing paragraphs ∩
  {ANCHOR-NARRATIVE ∪ ANALYTICAL-AUTHOR}) / |{ANCHOR-NARRATIVE ∪
  ANALYTICAL-AUTHOR}|

If the author-voice paragraph set is empty (all paragraphs are
expository / dialogue / structural), the semantic_fp_ratio is
recorded as `N/A` rather than dividing by zero. Trend audit
skips N/A rows.

The original `fp_ratio` column is preserved unchanged so
historical ledger rows remain valid.

## How voice-trend-audit consumes the new column

When semantic_fp_ratio is present for ≥3 chapters in the trend
window, the trend audit prefers it over fp_ratio. The drift
thresholds are the same (window-mean below 50% / 75% target,
3+ consecutive zero-FP chapters, slope < -0.030). The result is
a higher-fidelity drift signal that doesn't false-alarm on
chapters with legitimate expository-heavy structure.

When semantic_fp_ratio is unavailable for the window (no
classifier has been run, or classifications are stale), the
trend audit falls back to the v2.7.65 fp_ratio behaviour with no
loss of coverage.

## Silent-Failure Audit

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (voice-profile.md) | "Read succeeded" | Skeleton file (no real prose_description) | voice-profile-preload-gate (v2.7.65) as precondition; paragraph-classifier-dispatch.sh preflight check |
| Read (chapter file) | "Read succeeded with N bytes" | Empty extraction post-frontmatter strip | paragraph-classifier-dispatch.sh preflight word-count check (FAIL on <100 words after strip) |
| Subagent (classification production) | "Returned complete" | Silently dropped paragraphs (table has fewer rows than chapter has paragraphs) — would produce an undercount in the semantic ratio | Engine HARD GATE classification-completeness check (row count vs chapter paragraph count ±1) |
| Subagent (classification production) | "Returned complete" | Fabricated class (taxonomy invented to cover ambiguous paragraph) | Engine HARD GATE class-validity check (every Class field is exactly one of 5 taxonomy values; case-sensitive) |
| Write (classifier artifact) | "Write succeeded" | Subdir flush failure | mkdir -p before write; bash-direct write protocol per File Operation Policy Class 1 (NEW files) |
| Read (classifier artifact by voice-metrics-audit) | "Read succeeded" | Stale artifact (older than chapter file) — classifications reflect a previous chapter state | voice-metrics-audit mtime check: when classifier artifact is older than chapter file, fall back to syntactic fp_ratio for that chapter (don't trust stale semantics) |
