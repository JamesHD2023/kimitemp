---
name: injury-accumulation-delta
description: "Per-chapter incremental delta of the injury-accumulation tracker (engine-neutral Class B). Runs after each chapter as part of the per-chapter cycle: reads the running injury ledger as-of the previous chapter, scans only the current chapter for new injuries / recoveries / actions, and flags actions that violate the running ledger's recovery-window constraints. Catches injury continuity drift at write-time. The full-manuscript injury-accumulation.md still runs at Phase 5 Stage 9.5 (Canon Validation Sweep) as the final cross-check."
version: "2.7.61"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Injury Accumulation Tracker — Per-Chapter Delta

A per-chapter incremental variant of `injury-accumulation.md`. Both
share the same audit semantics (build per-character injury ledger,
project recovery windows, flag actions inconsistent with severity);
they differ in scope: the parent spec scans the entire manuscript at
end-of-pipeline, this spec scans only the just-written chapter
against a running ledger from prior chapters.

## Why per-chapter

Injury continuity violations are cheap to fix at write-time and
expensive after subsequent chapters are written around the
inconsistency. If chapter 8 ignores a broken leg from chapter 6,
chapters 7-15 may already depend on the broken-leg trajectory; a
Phase 5 Stage 9.5 catch requires retro-revising every dependent
chapter. Per-chapter delta flags chapter 8 the moment it lands.

Trade-off: per-chapter cannot verify the full recovery arc lands
correctly across the manuscript (some injuries recover gradually
over many chapters by design). The parent spec still runs at
Stage 9.5 to verify the complete arc.

## When this audit runs

After each chapter completes its full per-chapter cycle (Architect →
Writer → Humaniser → Verification 6-agent suite), the Class B Delta
Pass dispatches this audit as part of the per-chapter discipline.
See `mandatory-pipeline-rules.md` Rule 1's "Class B Delta Pass" step.

## Class B dispatch

Same dispatch pattern as the parent spec. The bash dispatcher emits:

```
CLASS_B_AUDIT|injury-accumulation-delta|PHYSICS|references/injury-accumulation-delta.md|-
```

The engine layer reads the line, dispatches a subagent per the brief
below, applies the engine HARD GATE on return, merges the verdict
into the per-chapter Progress Dashboard.

## Subagent task brief

> **Task: Injury Accumulation — Per-Chapter Delta**
>
> **Background.** Injuries constrain subsequent character behaviour.
> A character with a broken leg in chapter 6 cannot sprint cleanly
> in chapter 8 unless explicitly healed. You are scanning only the
> just-written chapter against a running injury ledger from prior
> chapters.
>
> **Inputs.**
> - `engine-data/chapters/ch{NN}.md` — current chapter (the only one
>   you scan for new injuries / recoveries / actions)
> - `engine-data/reports/injury-ledger.md` — running ledger of all
>   open injuries with chapter-of-onset, severity, projected
>   recovery window (created if missing, updated on every per-
>   chapter delta run)
> - `engine-data/story-bible.md` (fiction) or
>   `engine-data/research-bible.md` (NF) — for character-physical-
>   capability context if declared
>
> **Procedure.**
> 1. Read the running ledger to load open injuries with their
>    severity + projected recovery windows.
> 2. Scan the current chapter for three signal classes:
>    - **New injuries:** physical injuries sustained this chapter
>      (broken bones, lacerations, burns, concussions, etc.)
>    - **Recovery events:** explicit healing actions, medical
>      treatment, time-skip recoveries (the chapter says "six
>      weeks later" and the prior open injury is within projected
>      recovery window)
>    - **Constraint-relevant actions:** character actions in this
>      chapter that would be implausible given an open injury
>      (running, fighting, climbing, lifting, fine motor tasks,
>      etc., for a character whose ledger shows a relevant open
>      injury still within recovery window)
> 3. For each open injury in the ledger, evaluate the current
>    chapter's actions:
>    - If a constraint-relevant action exceeds the projected
>      capability — and the chapter does NOT explicitly narrate
>      the character struggling, compensating, or otherwise
>      acknowledging the injury — → CAPABILITY-VIOLATION finding
>      (FAIL severity).
>    - If a constraint-relevant action is performed and the
>      chapter narrates struggle / compensation / pain → no
>      finding (the writer is using the injury, not ignoring it).
> 4. Update the ledger:
>    - Add new injuries with projected recovery windows (use
>      conventional medical timelines: broken arm ~6 weeks, deep
>      laceration ~2 weeks, concussion ~1-3 weeks symptomatic,
>      etc.)
>    - Close out injuries reached by explicit healing or time-skip
>    - Note the current chapter number against each open injury
>      (for stale-injury detection later)
> 5. Write the updated ledger to disk using the Class 2 long-
>    lived-state Edit protocol (see `mandatory-pipeline-rules.md`
>    File Operation Policy — the ledger is long-lived state, not
>    a Class 1 NEW file).
> 6. Produce the structured return.
>
> **Return contract (mandatory).**
>
> ```
> ## Ledger State After This Chapter
> | Character | Injury | Onset (ch) | Severity | Projected recovery | Status |
> |---|---|---|---|---|---|
> [populated rows for all open + newly-closed injuries; "Status" ∈
>  {open, closed-this-chapter, was-open-pre-chapter}]
>
> ## New Injuries This Chapter
> | Character | Injury | Severity | Recovery window |
> |---|---|---|---|
> [rows; or "(none)"]
>
> ## Recovery Events This Chapter
> | Character | Prior injury | Mechanism | Reasonable per timeline? |
> |---|---|---|---|
> [rows; or "(none)"]
>
> ## Findings
> | Severity | Character | Injury | Type | Detail |
> |---|---|---|---|---|
> [type ∈ {CAPABILITY-VIOLATION, RECOVERY-IMPLAUSIBLE}; or
>  "(no findings)"]
>
> ## Verdict
> One of: PASS | WARN | FAIL
> - PASS: no findings
> - WARN: RECOVERY-IMPLAUSIBLE only (timeline tight but not impossible)
> - FAIL: any CAPABILITY-VIOLATION
>
> ## One-Line Summary
> Format: "<verdict>: ch{NN} — <count> finding(s) — <top finding>"
> or "PASS: ch{NN} — N open injur(ies) tracked, no violations"
> or "PASS: ch{NN} — no injury activity this chapter"
> ```
>
> **Discipline.**
> - Cite every finding with character name + chapter:line.
> - Conventional medical recovery windows are first-pass estimates;
>   if the bible declares a different convention (e.g., "characters
>   in this world have accelerated healing"), follow the bible.
> - Do NOT flag every physical exertion as a CAPABILITY-VIOLATION;
>   if the chapter narrates the struggle, the writer is using the
>   injury, not ignoring it.
> - When uncertain about timeline plausibility, downgrade FAIL to
>   WARN.

## Engine HARD GATE on return

Per `subagent-output-verification.md`. Same shape as the parent
spec: shape check, citation check, verdict consistency, hallucination
markers.

After verification, the engine emits:

```
AUDIT|injury-accumulation-delta|PHYSICS|<verdict>|<one_line_summary>|<subagent_return_path>
```

The verdict surfaces on the per-chapter Progress Dashboard. A FAIL
does NOT block chapter approval — the writer chooses whether to
revise now or carry the finding forward.

## Running ledger format

`engine-data/reports/injury-ledger.md` accumulates across the
manuscript. Format:

```markdown
# Injury Accumulation Ledger

## Open injuries

| Character | Injury | Onset (ch) | Severity | Projected recovery |
|---|---|---|---|---|
| Sarah | broken left ankle | ch04 | moderate (~6wk) | ch07 if normal healing |

## Closed injuries (historical)

| Character | Injury | Onset (ch) | Closed (ch) | Mechanism |
|---|---|---|---|---|
| Marcus | concussion | ch02 | ch03 | time-skip + medical attention |
```

The ledger is updated on every delta run using Class 2 Edit-tool
protocol (long-lived state file). The full-manuscript
injury-accumulation at Stage 9.5 uses the final ledger as one input
but re-scans the manuscript end-to-end for the verdict.

## Category-aware default (v2.7.63)

The per-chapter delta is **on by default for narrative work** (all
fiction; narrative non-fiction with physical-event continuity —
memoir, biography, true crime, literary journalism, narrative
history, microhistory, travel writing, sports narrative) and
**auto-skipped for argumentative non-fiction** (self-help, business,
economics-finance, personal-finance, psychology-popular,
philosophy-popular, popular-science, health-wellness, fitness,
how-to-guide, cooking, education, parenting, technology,
religion-spirituality).

Rationale: injury-accumulation tracking matters when the manuscript
contains characters whose physical state can be injured and constrains
their subsequent behaviour. Argumentative non-fiction generally
doesn't have characters in that sense; even when it cites case studies
involving injured people, the prose isn't tracking those injuries
across a narrative timeline. Running the audit on a self-help book
typically returns "no injuries in chapter — audit not applicable" —
useful as catalog data but not a productive per-chapter check.

`class-b-delta-gate.sh` reads `engine-data/project-config.md` to
apply the default:

- `nf_shape: argumentative` → explicit auto-skip
- `nf_category: <argumentative slug>` → auto-skip via category lookup
- Otherwise (fiction, narrative NF, or no category) → audit runs

Both defaults are overridable:

- `class_b_delta_status: enable` — force the audit on
- `class_b_delta_status: skip` — force off regardless of category

## Failure modes prevented

- **Late-stage continuity retrofit cost** — capability violations
  caught at Phase 5 Stage 9.5 may require revising 10+ chapters;
  per-chapter delta flags at write-time, fix is one chapter.
- **Compounding continuity drift** — once chapter 8 ignores chapter
  6's injury, chapters 9 through 15 may all assume the character is
  uninjured; without per-chapter catch, the drift compounds into
  manuscript-shaped damage.

## Relationship to parent spec

| Spec | When | Scope | Catches |
|---|---|---|---|
| `injury-accumulation-delta.md` (this spec) | Per chapter, Rule 1 Class B Delta Pass | Just-written chapter against running ledger | Drift at write-time |
| `injury-accumulation.md` (parent) | End of manuscript, Phase 5 Stage 9.5 Canon Validation Sweep | Full manuscript end-to-end | Final cross-check + recovery-arc completeness across full timeline |

## See also

- `injury-accumulation.md` — manuscript-scope parent spec; runs at
  Stage 9.5
- `mandatory-pipeline-rules.md` Rule 1 — defines the per-chapter
  Class B Delta Pass that dispatches this audit
- `validate-dispatcher.md` — registers `injury-accumulation-delta`
  alongside the parent spec in the audit registry
- `leitmotif-tracker-delta.md` — companion per-chapter delta for the
  COHERENCE domain (same pattern)
- `subagent-output-verification.md` — HARD GATE applied to subagent
  returns
