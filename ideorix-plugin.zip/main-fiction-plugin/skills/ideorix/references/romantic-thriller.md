---
name: romantic-thriller-genre
description: Genre-specific instructions for romantic thriller fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Romantic Thriller. Genre Plugin

## Metadata
- id: romantic-thriller
- name: Romantic Thriller
- icon: 💣
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Thriller 12-Beat Structure", "Save the Cat", "Three-Act Structure", "Seven-Point Structure"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Conspiracy Romance Thriller | Love entangled with government or corporate conspiracies | The paranoia extends to the relationship. can you trust someone when trust itself is weaponised? |
| Espionage Romance | Spies on opposite sides or within the same agency | Double identities create double meanings in every romantic exchange; loyalty is the central question |
| Heist Romance | Partners in crime whose professional partnership becomes personal | The heist structure (plan, execution, twist) mirrors the romance arc; betrayal has dual stakes |
| Revenge Romance Thriller | Love complicated by one partner's vengeance mission | The revenge plot and the romance are in direct conflict. the character must choose |
| Political Romance Thriller | Romance within political power struggles. campaigns, coups, diplomatic crises | Public and private lives collide; every personal decision has political consequences |
| Tech Thriller Romance | Love amidst technological threats. cyber warfare, AI, surveillance | Digital intimacy and digital danger; the technology that threatens them also connects them |

## Architect Instructions

```
STRUCTURE

Chapter length: 3,000-5,000 words
Pacing: Relentless forward momentum. thriller drives, romance breathes
Must open with: Threat in motion, action underway, or danger arriving
Must close with: Escalated stakes, cliffhanger, or revelation that reframes the danger

GENRE PROMISE

This is a THRILLER where love happens. not a romance where danger happens. The conspiracy, the assassin, the countdown, the cover-up. that is the engine. The romance makes the reader terrified someone they love might die. Remove the romance and the thriller plot MUST still work. Remove the thriller and there is no book.

CRITICAL DISTINCTION FROM ROMANTIC SUSPENSE:
- Romantic Suspense: Reading a romance where danger happens. HEA guaranteed. Safety assured.
- Romantic Thriller: Reading a thriller where love happens. HEA hoped for, NOT guaranteed. Characters in genuine mortal danger. Survival is NOT assured.

WHAT READERS CRAVE
- Professional competence under fire: protagonists who are GOOD at dangerous work
- External threat that would matter even without the romance
- Romance forged in crisis: attraction born from shared danger, not safe courtship
- Real stakes: characters CAN die, CAN lose, CAN be separated permanently
- Fast pacing with romance woven into action, not pausing it
- Cliffhanger chapters that make the book impossible to put down

BEATS PER CHAPTER (Choose 3-4)
1. Threat Escalation: Danger increases. new enemy, countdown ticks, escape route closes
2. Clue/Revelation: Intelligence gathered, conspiracy uncovered, ally's loyalty questioned
3. Romantic Connection: Stolen moment, protective instinct, vulnerability exposed under pressure
4. Action Sequence: Chase, firefight, escape, infiltration. physical danger on the page
5. Trust Tested: Professional trust and romantic trust intertwined. can they rely on each other?

SCENE CONSTRUCTION
- Open mid-action or mid-tension: no preamble, no location essays
- One grounding detail, then character and forward motion
- Romance happens INSIDE the thriller: during stakeouts, between firefights, while running
- Close on danger, revelation, or relationship shift: never summary or reflection

STRUCTURAL BACKBONE FOR 30 CHAPTERS:
- Ch 1-3: Threat introduced, protagonist's competence shown, love interest enters through the plot (not separately)
- Ch 4-6: Danger confirmed, forced proximity or reluctant alliance, initial attraction acknowledged but subordinate to mission
- Ch 7-9: Stakes escalate, first collaborative action sequence, trust building through competence
- Ch 10-12: First real romantic moment: earned through shared danger. Betrayal or complication raises personal stakes
- Ch 13-15: Midpoint: scope of threat revealed. Romance deepens because survival now means protecting someone you love
- Ch 16-18: Villain closes in, protagonists isolated together, romance under siege
- Ch 19-21: Dark night: separation, capture, or near-death. The cost of love in a dangerous world made visceral
- Ch 22-24: Regrouping, critical intelligence obtained, romantic commitment tested against mission priorities
- Ch 25-27: Final assault preparation, all-or-nothing stakes, romance provides the WHY behind the fight
- Ch 28-29: Climactic action sequence: romance heightens every bullet, every second
- Ch 30: Resolution: threat neutralized (or transformed), reunion or sacrifice, future uncertain but earned

REVELATION ARCHITECTURE (THREE major turning points)
- Act I Break (~Ch 10): The threat is personal: it targets someone the protagonist now cares about
- Midpoint (~Ch 15): The conspiracy is bigger than imagined AND the romantic relationship creates new vulnerability
- Act II Break (~Ch 23): Ultimate revelation: betrayal from within, impossible choice between love and mission

KNOW THE ENDING FIRST
Before planning chapter beats, establish the ending: What is the conspiracy? Who is behind it? What sacrifice or victory resolves it? Then work backwards. plant clues, seed the betrayal, and build the romantic connection that will make the climax devastating. The ending should feel inevitable in retrospect. Both the thriller resolution and the romantic resolution must be earned.

PREMISE FUSION
The strongest romantic thriller premises combine two or more seemingly unrelated elements. A conspiracy is a story; a conspiracy that collides with an old personal connection and a third party's hidden agenda is a thriller. The romance should complicate the premise, not just coexist with it. falling for someone who might be part of the conspiracy, or whose past connects to the threat in ways neither expected.

QUESTION-ANSWER ENGINE
Every chapter must raise at least one new question and answer at least one old question. Don't withhold answers to create suspense—deliver them faster than the reader expects, but ensure each answer spawns a deeper, more dangerous question. The question-answer chain should operate in BOTH the thriller plot and the romantic subplot simultaneously: "Can I trust them professionally?" answered alongside "Can I trust them personally?"

HOPE AS SUSPENSE
The reader needs to desperately want two things: survival AND the relationship. Where possible, create situations where both are at risk simultaneously. a near-death that threatens reunion, a separation that might be permanent, a sacrifice that could save the mission but end the relationship. Hope is the most powerful suspense tool in romantic thriller because there are TWO things to hope for.

GROUNDING TWISTS IN REALITY
The more shocking the betrayal or revelation, the more it must be anchored in emotional truth. After a major twist, show both protagonist's tactical AND emotional reaction—the operational assessment shattering into something personal. The reader should think: "That explains the moment in chapter 7 when their hand hesitated."

PACING CONTRAST
Relentless action without breathing room becomes numbing. The romance provides natural pacing contrast. stolen moments of tenderness between danger create the rhythm that makes both the action and the emotion hit harder. Use romance scenes as the calm before escalation, not as interruptions. When the reader catches their breath during a safe house night, they're actually being set up for the next blow.

ROMANCE INTEGRATION RULES
- Romance must NEVER pause the thriller. No scenes where danger stops so characters can process feelings
- Instead: feelings emerge DURING danger, BETWEEN crises, in stolen moments
- Physical attraction heightened by adrenaline: this is biology, use it
- Emotional vulnerability happens when guards drop: exhaustion, near-death aftermath, safe house nights
- The romance raises stakes: now there's someone to lose

FORBIDDEN FOR ARCHITECT
- Romance scenes that stop the plot dead (the "thriller pauses for love" problem)
- Thriller scenes that forget the romantic relationship exists
- Incompetent protagonists who need rescuing (both leads must be capable)
- Villain monologues explaining the conspiracy
- Convenient coincidences resolving danger
- Love interest as damsel/trophy: both leads must be professionally competent
- Guaranteed safety: HEA is hoped for, not promised. Real danger means real risk
- Stereotypical romantic thriller leads: no generic tough-guy/tough-girl without emotional specificity

OBSTACLE LAYERING (critical for romantic thriller tension):
A romantic thriller needs MULTIPLE obstacles layered simultaneously. The external threat (conspiracy, assassin, countdown) is the framework, but INTERNAL obstacles give the romance its devastating power. Fear of vulnerability in someone trained to suppress emotion. Past operational betrayals that make personal trust feel impossible. The professional conviction that caring about someone creates tactical weakness. Self-sabotage dressed as operational discipline. keeping distance not because it's smart, but because closeness is terrifying. Each obstacle should make the reader YEARN for connection while understanding why these specific people can't reach for it.

LIGHT AND SHADE:
Even relentless thrillers need emotional contrast. After scenes of maximum danger and operational intensity, allow a moment that catches the reader off guard. unexpected tenderness, a flash of humor under pressure, a quiet gesture of care that contradicts the tactical exterior. After moments of romantic vulnerability or connection, shatter the calm with an escalation that reminds both characters (and the reader) that survival is not guaranteed. This contrast is the difference between compelling thriller-romance and monotonous action. Two relentless action sequences back to back numb the reader; danger followed by a stolen moment of warmth makes both register at full force.

ANTI-STEREOTYPE IMPERATIVE:
The best romantic thrillers feature specific, surprising, REAL people. not action-movie archetypes with romantic tension bolted on. Your operative can be uncertain, your love interest can be the more emotionally courageous one. Both leads should be professionally competent AND emotionally specific. Avoid the generic tough guy/girl and the standard love interest. these are starting points, not characters. The romance should emerge from who these particular people ARE when the operational mask slips.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (thriller stakes) + Affection (bond) — twin engines, with Revelation at intersection points.

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-protocol.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE

POV: Deep 3rd limited. tight on protagonist's tactical awareness AND emotional state
Tense: Past (traditional weight) or present (heightened immediacy)
Voice: Taut, urgent, controlled. the prose of someone operating under threat who is also falling in love
Reading level: Sophisticated adult. technical accuracy without jargon dumps, emotional truth without sentimentality

THE ROMANTIC THRILLER VOICE: Two Frequencies

Your protagonist broadcasts on two channels simultaneously:
1. OPERATIONAL: Threat assessment, tactical planning, professional competence
2. EMOTIONAL: Awareness of the other person, protective instincts, desire complicated by danger

"Three exits. Two covered. The service corridor—maybe. Her hand found his in the dark and his tactical assessment shattered into something simpler: keep her alive."

This dual frequency is the genre's signature. The reader gets thriller tension AND romantic tension in the same paragraph.

GOOD DUAL-FREQUENCY WRITING (Use freely):
- "He cleared the room in three seconds. Checked corners, checked closets, checked the window line of sight. Then he looked at her—really looked—and the tremor in his hands had nothing to do with the rifle."
- "She disarmed the charge with steady fingers. Twenty seconds to spare. Then she turned and his mouth was on hers, desperate and alive, because twenty seconds was almost not enough."
- "The bullet had missed her by inches. He could see the nick in the doorframe. His report would read 'near miss, no casualties.' His body was telling a different story."

BAD WRITING (Avoid):
- "She felt attracted to him despite the danger." → TELL, not SHOW. Put the attraction IN the danger.
- "They paused their escape to discuss their feelings." → The escape IS where feelings happen.
- "He was both a skilled operative and a tender lover." → Author summary, not scene.

PROSE IMPERATIVES

1. Sentence Length Matches Intensity
   Action: Short. Punchy. Fragments. Staccato. "Down. Move. Now."
   Romance: Longer sentences. Breath returns. Observation deepens. Detail noticed.
   Transition between these rhythms is the CRAFT of romantic thriller writing.

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- Thriller-grade threat AND chemistry setup from the first page: both engines firing
- Tension floor: 7 (inherits all thriller Ch 1 prose rhythm rules: the hook must be visceral)
- Open mid-action or mid-tension: the chapter should feel like walking into a room where something is already happening
- Dialogue density: 40-50%: crisp, dual-layered exchanges (operational surface, emotional subtext)

Action scenes (prose rhythm):
- Sentences: 8-15 words maximum during threat: fragments, staccato, white space
- Single-line paragraphs for maximum impact; let the reader's heart fill the silence
- Romance beats earn their space BETWEEN action: never pause the thriller for feelings
- Interiority during danger: one flash of the other person per action sequence, no more: but devastating

Romance scenes (prose rhythm):
- Sentences lengthen as breath returns: observation deepens, detail sharpens, the operative's mask slips
- Stolen moments: short scenes, high density: every word counts because time is borrowed
- Physical intimacy charged by danger: urgent, desperate, alive: prose matches that energy
- Interiority budget: 40%: dual frequency (tactical assessment + emotional truth) in same paragraph

Climax/resolution prose rhythm:
- Final convergence: action and romance peaks collide: prose alternates rhythms within paragraphs
- The sacrifice/declaration: short, declarative, stripped of operational language: the mask fully off
- Resolution: prose exhales: longer sentences, warmth, the specific quiet of safety earned through fire

2. Technical Accuracy Matters
   Weapons: Correct caliber, realistic capacity, proper handling
   Procedures: Law enforcement protocols, military terminology, intelligence tradecraft
   Locations: Real geography, accurate distances, plausible logistics
   Medical: Realistic injuries, actual recovery times, correct treatment
   Get it wrong and you lose thriller readers. They WILL notice.

3. Romance in Stolen Moments
   Not: Extended love scenes in the middle of danger
   Instead: His hand on the small of her back guiding her through the door. The look that lasted one second too long. Her voice saying his name differently than she said anyone else's.
   Physical intimacy, when it happens, is charged by danger: urgent, desperate, alive.

4. Sexual Tension During Danger
   Adrenaline heightens every sense. including attraction
   Forced proximity in safe houses, stakeouts, escape vehicles
   Professional touch becoming personal: adjusting a vest, checking a wound, steadying aim
   The near-death kiss is a cliche. The almost-kiss interrupted by gunfire is the genre.

5. Dialogue: Crisp and Double-Layered
   Surface: Mission briefing, tactical communication, professional exchange
   Beneath: Trust building, attraction acknowledged, vulnerability masked in competence
   "Watch my six" means "I trust you with my life" means "I love you"

6. White Space in Crisis
   Short paragraphs when danger peaks
   Fragments when shocked
   Single-line paragraphs for maximum impact
   Let the reader's heart fill the silence

7. Professional Jargon: Authentic, Not Academic
   Use real terminology. SITREP, breach, overwatch, exfil, asset, blown cover
   But never dump jargon. context makes meaning clear
   Characters use shorthand with each other. readers follow through context
   Over-explaining jargon breaks the illusion of competence

8. Setting Reveals Character
   A safe house, a hotel room under cover, a vehicle during pursuit. each setting should reveal who these people really are through one unexpected detail. The worn photo tucked in a gear bag. The way one protagonist organizes ammo and the other keeps a tattered paperback. Find the one small, specific detail that makes the reader's imagination build the entire world. and the relationship. around it.

9. Dialogue Must Multi-Task
   Every significant exchange must serve at least two purposes simultaneously: advance the mission AND deepen the relationship, deliver intelligence AND build trust, acknowledge danger AND reveal vulnerability. The genre's signature is dual-frequency. operational surface with emotional subtext. If a line only does one thing, it's not doing enough.

DIALOGUE PATTERNS

- Operational dialogue carrying emotional subtext
- Banter under pressure: humor as coping mechanism and flirtation
- Half-sentences finished by the other person (earned intimacy)
- Silence that says more than words: the loaded pause mid-mission
- Arguments about tactics that are really about trust and fear of loss
- "Stay alive" as "I love you"
- Every exchange should serve both the thriller and the romance: never just one

FORBIDDEN WORDS/PHRASES

"Suddenly" (action flows, doesn't ambush)
"Managed to" (undermines competence)
"Somehow" (vague, robs clarity)
"As if in slow motion" (cliche)
"He/she couldn't help but notice" (weak filter)
"Despite everything" (hand-wave)
"Their eyes met across the room" (romance cliche that stops thriller momentum)
"His/her heart skipped a beat" (dead metaphor)

CHAPTER RHYTHM

Open: Mid-action or mid-tension. the chapter should feel like you walked into a room where something was already happening
Build: Thriller tension + romantic awareness woven together, never alternating
Close: Cliffhanger, revelation, or emotional gut-punch. never summary, never resolution

METHOD WRITING. EMOTIONAL IMMERSION:
- Identify what you want the reader to FEEL before writing any key scene: the specific cocktail of fear and desire, the ache of wanting someone you might lose, the exhilaration of operational competence sharpened by someone watching who matters
- If the writer isn't feeling the dual-frequency emotion. both the tactical tension and the romantic pull. the reader won't feel it either
- Write through the senses with operational specificity: the exact quality of a safe house at 3am, how hypervigilance makes you aware of another person's breathing, the way adrenaline makes every accidental touch feel electric
- Never manufacture danger purely for spectacle or a romantic moment purely for heat. Both must serve the characters' truth: genuine feeling, even in extreme contexts, is what separates compelling romantic thriller from empty action-romance

INTIMATE SCENES. CHARACTER REVELATION UNDER PRESSURE:
- Intimate scenes in romantic thriller must illuminate something about these specific characters: what does physical closeness reveal when both have been trained to keep distance? What does vulnerability look like in people whose survival depends on control?
- Urgency and imperfection make these scenes authentic: not choreographed passion but desperate, alive, charged by mortality and adrenaline
- Post-intimacy vulnerability is critical: the operative whose walls come down, the moment of genuine tenderness that terrifies more than any bullet. Don't skip the aftermath: the scramble to rebuild professional distance, the realization that it's too late for that

DIALOGUE. THE POWER OF THE UNSAID (romance frequency):
- Beyond tactical subtext, track the ROMANTIC unsaid: the feelings these operationally competent people cannot bring themselves to name. "Stay alive" means "I love you." "Watch my six" means "I trust you with everything."
- The gap between what is felt and what is spoken IS the romantic tension. Characters trained to suppress emotion don't suddenly become eloquent about feelings: they express love through action, through operational choices, through the specific way they position themselves between their partner and danger
- When someone finally breaks through the operational language to say something raw and personal, it should land like a detonation: because everything before it was holding back

THEME BENEATH THE THRILLER:
Every strong romantic thriller has a THEME. what the story is really about beneath the conspiracy and the falling-in-love. Is it about the cost of a dangerous life? About whether people who live in shadows can find genuine light? About what you're willing to sacrifice and what you refuse to lose? Theme gives romantic thriller emotional weight beyond the adrenaline. When the bullets stop and the reunion happens, it is the theme that makes the reader's eyes sting.
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Thriller dominance. external threat drives the chapter, plot would work without the romance (but romance makes it matter)
2. Professional competence. protagonists skilled and capable under pressure, competence shown through action not description
3. Romance integration. love woven INTO danger, not pausing it, romantic moments earned through shared peril
4. Dual-frequency prose. tactical awareness and emotional awareness in the same passages, both channels enhancing each other
5. Pacing and momentum. relentless forward drive with earned breathing room, every scene advancing threat AND relationship

GENRE-SPECIFIC CHECKS

External threat drives every chapter forward. danger escalating, not static
Stakes genuinely real. characters in mortal peril, survival not guaranteed
Both leads solve problems through expertise and quick thinking. neither reduced to damsel or trophy
Stolen romantic moments more powerful for being brief. urgency earned
Sexual tension woven into danger, not separated from it
Weapons, procedures, locations technically accurate. military or law enforcement readers would accept this
Injuries and physical consequences realistic. no miraculous recovery
Professional jargon used correctly and sparingly. context makes meaning clear
Chapter ends on cliffhanger, revelation, or emotional gut-punch. never summary
Reads as a THRILLER with romance, not a romance with danger. thriller fan satisfied AND emotionally moved

AUTOMATIC FAILS

Romance pausing the thriller plot. extended love scenes stopping forward momentum
Thriller ignoring the romance entirely. action chapters where the relationship has no presence
Incompetent protagonist needing rescue. both leads must demonstrate professional-grade capability
Villain monologue explaining the conspiracy. menace through action and reach, never through speechifying
"Feeling processing" paragraphs during active danger—emotional interiority that halts action momentum
Technical inaccuracies in weapons or procedures that break verisimilitude for informed readers
Survival guaranteed. if the reader never believes characters could die, the thriller engine fails
Romantic conflict trivially solvable. obstacles that a single conversation would resolve
Love interest as passive cargo. one lead doing all the dangerous work while the other waits

ACCEPTABLE IMPERFECTIONS

Slightly more thriller than romance in a given chapter if relationship still present
Some familiar tropes (reluctant alliance, forced proximity, competent partners) if characters feel specific
Simplified technical details if internal consistency maintained
Romance progressing quickly if danger compression justifies the accelerated timeline

RED FLAGS TO INVESTIGATE

Romance and thriller running on separate tracks. romantic scenes between action scenes rather than woven into them
Dual-frequency writing absent. operational passages with no emotional undercurrent, or emotional passages with no tactical context
Stolen moments feeling leisurely rather than urgent. safe house scenes that lose awareness of surrounding danger
One lead significantly more competent than the other. professional imbalance undermining the partnership dynamic
Emotional vulnerability appearing only in designated "romance scenes"—the operational mask never cracking during action
Technical language used as decoration rather than function. jargon that doesn't advance plot or reveal character
Post-action emotional processing skipped. moving to next crisis without characters registering what they survived
Chemistry stated rather than demonstrated—"she felt the pull" replacing shown physical awareness and loaded tactical dialogue
Countdown or ticking clock forgotten during romantic development. urgency dropping when it should be ever-present
Villain feeling like backdrop rather than active threat. antagonist not present enough to create genuine fear
Breathing moments that become rest stops. pacing contrast turning into pacing stalls
Operational competence without emotional cost. characters performing dangerous work without it affecting their inner life or their relationship
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES

1. Threat timeline: Conspiracy/danger progression tracked precisely. what the antagonist knows, what they've done, what's coming next
2. Clue chain: What intelligence the protagonists have gathered, from whom, when. can't use information before obtaining it
3. Geographic accuracy: Real or plausible locations, travel times, distances between action set pieces
4. Romance milestones: First touch, first kiss, first trust-fall, first vulnerability. track escalation and never repeat without advancement
5. Technical consistency: Weapons (ammo counts, realistic capacity), vehicles, communication equipment, injuries

GENRE-SPECIFIC TRACKING

Threat Progression:
- Antagonist's plan timeline: what they're doing while protagonists react
- Resources antagonist has deployed (operatives, surveillance, weapons)
- What the antagonist knows about the protagonists and when they learned it
- Escalation pattern: each chapter should raise the danger ceiling

Intelligence Chain:
- What protagonists know and when they learned it
- Source reliability: who provided what information, can they be trusted?
- Red herrings planted and their resolution
- Critical evidence. documents, recordings, witnesses. location and status

Physical State:
- Injuries accumulate: gunshot wounds don't heal overnight, bruises persist
- Exhaustion tracked: hours since sleep, since food, since safety
- Equipment status: ammunition remaining, phones charged, vehicles functional
- Medical treatment received or needed

Romance Continuity:
- Relationship milestones: first significant look, first physical contact, first admission
- Trust level between leads: tracked chapter by chapter, never jumping levels
- What each knows about the other's past, wounds, fears
- Physical intimacy progression: consistent with compressed timeline and danger context
- Professional respect established before romantic vulnerability

Ally/Enemy Status:
- Who's confirmed ally, confirmed enemy, uncertain
- When loyalties were tested or revealed
- What each supporting character knows about the threat AND the romance
- Communication status: can protagonists reach their support network?

ACCEPTABLE INCONSISTENCIES
- Minor setting details if action geography maintained
- Exact timing of background events if not plot-critical
- Supporting character appearance details if not relevant to identification

ROMANCE-CRAFT CONTINUITY:
- Track what characters have SAID vs. NOT SAID about their feelings across chapters: in romantic thriller, feelings are expressed through tactical choices more than words. When someone finally breaks operational language to say something raw, the reader must feel the weight of everything that was previously held back
- Track obstacle progression: internal emotional wounds alongside external threats. A fear of vulnerability established early doesn't vanish without earned development through shared danger. Each close call should chip away at defenses: or reinforce them, with narrative reason
- Track emotional register alternation: flag sequences where multiple chapters carry the same operational intensity without romantic breathing room, or romantic connection without thriller momentum. The dual-frequency rhythm requires both channels active
- Track character consistency beneath the operational roles: a character who showed vulnerability in chapter 10 doesn't revert to complete emotional shutdown in chapter 15 without narrative justification. Professional control can be rebuilt, but the reader knows what's underneath now
```

## Character Rules

```
PROTAGONIST REQUIREMENTS: PROFESSIONALLY COMPETENT LEADS

The romantic thriller demands protagonists who are GOOD at dangerous work. This is not a genre for amateurs stumbling into peril. Both leads must demonstrate professional-grade skill.

LEAD ARCHETYPES (Mix and match):
- Law enforcement: FBI agent, detective, U.S. Marshal, Interpol
- Military: Special forces, intelligence officer, combat veteran
- Intelligence: CIA operative, MI6 agent, NSA analyst turned field
- Security: Private military contractor, bodyguard, security consultant
- Specialist: Forensic expert, trauma surgeon, investigative journalist, prosecutor
- Criminal: Reformed thief, hacker, undercover operative who's been under too long

WHAT MAKES THEM COMPELLING:
- Competence is SHOWN through action: clearing rooms, reading people, making tactical decisions
- Professional reputation established early: other characters respect or fear them
- Specific skill set that matters to the plot: not generically "tough," specifically skilled
- Complementary abilities between leads: what one lacks, the other provides

THE COMPETENCE-VULNERABILITY PARADOX:
This is the genre's emotional engine. The protagonist who can disarm a bomb in thirty seconds but cannot say "I'm terrified of losing you." The operative who reads microexpressions for a living but can't read their own heart.

Professional competence + romantic vulnerability = romantic thriller gold.

HOW COMPETENCE SHOWS:
- Quick tactical decisions under fire
- Reading environments for threat (exits, sight lines, cover)
- Professional jargon used naturally, not explained
- Physical capability: not superhuman, but trained
- Problem-solving under pressure: improvisation with available resources

HOW VULNERABILITY SHOWS:
- The hand that shakes AFTER the danger passes
- Admitting fear for the other person (not for self: self-fear is weakness, other-fear is love)
- The moment professional control slips and the person underneath shows
- Past wounds that explain why trust is hard: ex-partner betrayal, partner killed, burned by the agency
- Letting someone in despite knowing it creates tactical vulnerability

ROMANTIC LEAD DYNAMICS

The best romantic thriller pairs create:
- Professional respect BEFORE attraction: competence is the first aphrodisiac
- Complementary skills: she's the tactician, he's the infiltrator; she reads people, he reads systems
- Productive conflict: disagreements about approach that are really about how much risk they'll accept for each other
- Earned trust: built through life-or-death reliability, not conversation
- Physical awareness heightened by operational proximity: adjusting body armor, checking wounds, covering each other

TRACK FOR EACH LEAD:
- Professional skill set and how it's demonstrated
- Physical state (injuries, exhaustion, combat readiness)
- Emotional walls and what breaches them
- Trust level with the other lead (professional and personal, tracked separately)
- Fear hierarchy: what they fear for themselves vs. what they fear for the other
- Past relationship trauma that complicates current vulnerability

ANTAGONIST REQUIREMENTS:

The villain must be a credible threat to PROFESSIONALLY COMPETENT people:
- Equally skilled or resourced: not a pushover for trained protagonists
- Motivated beyond generic evil: ideology, profit, revenge, survival
- Active throughout: not waiting for climax, pursuing relentlessly
- Menace through action and reach, never through monologue
- May exploit the romantic relationship as vulnerability: targeting the person the protagonist loves

SUPPORTING CAST:
- Handler/commander creating professional pressure
- Team members with their own loyalties and agendas
- Informants and assets whose reliability is uncertain
- Civilian connections creating vulnerability (family, friends outside the world)
- Each supporting character's knowledge of both the threat AND the romance tracked

DEFY THE ARCHETYPE
Give at least one major character a trait that subverts their expected role:
- The lethal operative who has an unexpectedly tender hobby or passion
- The love interest whose professional competence manifests in a surprising specialty
- The villain who is terrifyingly reasonable and even charming
- The supporting character whose loyalty shows in unexpected ways
Avoid: the generic tough guy/girl, the love interest who exists only to be protected, the villain motivated solely by greed or revenge. The most memorable romantic thriller characters are the ones with contradictions. lethal competence alongside genuine warmth, professional distance alongside specific vulnerability.

CHARACTER BUILDING. GROUND UP:
Build each romantic lead from the ground up BEFORE they enter the story:
- Background questions: What do they want from life beyond the mission? What shaped them into who they are: which specific operational experience, which personal loss, which moment of trust betrayed? What were their formative relationships?
- Character tests: What's in their go-bag besides operational gear? How do they react to unexpected kindness? When someone they've started to trust lets them down? What do they do in the first quiet moment after an operation?
- The vast majority of this backstory never appears on the page, but it informs every tactical decision, every moment where the operational mask slips, every choice to let someone in despite the professional cost
- The most compelling romantic thriller characters are contradictions: lethal AND gentle, controlled AND desperate for connection, brilliant at reading threats AND blind to their own hearts

ANTI-STEREOTYPE IMPERATIVE:
Romantic thriller has its own dangerous defaults—the stone-cold operative and the beautiful asset. Subvert these. Your operative can be uncertain about the one thing that matters. Your love interest can be the more emotionally courageous one. Both leads should be professionally specific AND emotionally particular—not just "tough" and "attractive" but messy, real people with contradictions that make them compelling. The romance should emerge from who these SPECIFIC people are when the job is done and the adrenaline fades, not from generic chemistry between generic operatives.
```

## Arc Rules

```
THREE-ACT STRUCTURE: THRILLER DOMINATES, ROMANCE PROVIDES THE HEARTBEAT

The romantic thriller arc is a THRILLER arc with an emotional throughline. The external threat creates the structure. The romance creates the stakes.

GENRE PROMISE

A relentlessly paced thriller where professional competence meets personal vulnerability. External danger that would matter on its own, made devastating by the fact that the protagonist now has someone to lose. Survival not guaranteed. Love not guaranteed. Both fought for with everything.

ACT I (Chapters 1-10): FORCED ALLIANCE
Purpose: Establish the threat, demonstrate competence, create the spark

Ch 1-3: The World on Fire
- External threat introduced with immediate stakes
- Protagonist's competence demonstrated under pressure
- Love interest enters THROUGH THE PLOT: not a meet-cute, a meet-crisis
- Professional dynamic established before personal chemistry

Ch 4-7: Reluctant Partnership
- Forced to work together by circumstances: neither chose this
- Professional friction masking attraction
- First collaborative action sequence: competence recognized
- Danger validates the partnership

Ch 8-10: First Cracks
- FIRST TURNING POINT: The threat becomes personal: targeting someone the protagonist now cares about
- First genuine romantic moment earned through shared danger
- Professional boundaries acknowledged and beginning to blur
- Stakes raised: now it's not just the mission, it's THEM

EMOTIONAL TARGET: Respect → Awareness → "Oh no"

ACT II (Chapters 11-23): HUNTED TOGETHER
Purpose: Escalate danger AND intimacy simultaneously. they cannot be separated

Ch 11-14: Running Together
- Investigation deepens, danger escalates, trust grows
- Romance in stolen moments: safe house nights, stakeout confessions, post-action adrenaline
- Each action sequence bonds them further
- Supporting character loyalties tested

Ch 15: MIDPOINT. The Scope
- Conspiracy bigger than imagined AND relationship creates new vulnerability
- The villain knows they care about each other: and will exploit it
- Everything reframed: personal and professional stakes are now the same
- Can't walk away from either the mission or each other

Ch 16-19: Under Siege
- Hunted, isolated, running out of allies and options
- Relationship deepens under maximum pressure: this is where real intimacy happens
- Professional disagreements about risk that are really about fear of losing each other
- Physical intimacy (if it occurs) charged with desperation and aliveness

Ch 20-22: Dark Night
- Separation, capture, or near-death: one or both in extreme danger
- The cost of loving someone in a dangerous world made visceral
- Fear of loss more powerful than any villain
- Darkest moment: professional failure AND romantic despair

Ch 23: ULTIMATE TURNING POINT
- Betrayal from within OR impossible choice: mission vs. the person they love
- The moment the protagonist realizes what they'll sacrifice: everything
- Sets up the climactic action where both thriller and romantic stakes resolve

EMOTIONAL TARGET: Trust → Intimacy → "I can't lose you" → Near-loss

ACT III (Chapters 24-30): ALL OR NOTHING
Purpose: Thriller climax where romance provides the emotional fuel

Ch 24-26: Final Preparation
- All intelligence gathered, plan formed, no more running
- Romantic commitment fuels professional resolve: fighting FOR someone
- Brief calm before the storm: the conversation that isn't about the mission
- Alliances finalized, resources deployed

Ch 27-29: Climactic Sequence
- Maximum action, maximum danger, maximum emotional stakes
- Every bullet, every second weighted by what they'll lose
- Romance expressed through ACTION: protecting, sacrificing, choosing
- No pausing for feelings: feelings ARE the action
- Genuine uncertainty about survival

Ch 30: Aftermath
- Threat neutralized (or transformed: sequel potential)
- Reunion or sacrifice: earned by everything that came before
- Cost acknowledged: scars, losses, changed worldview
- Future together implied but not guaranteed: they've earned hope, not certainty
- The world is different. They are different. What they have was forged in fire.

EMOTIONAL TARGET: Commitment → Sacrifice → Survival (earned, not guaranteed)

REQUIRED CHECKPOINTS

- Ch 3: Threat established, both leads' competence demonstrated, professional dynamic set
- Ch 8: First genuine romantic connection earned through shared danger
- Ch 10: Threat becomes personal: now about protecting someone, not just completing the mission
- Ch 15: Midpoint: conspiracy and vulnerability both revealed, stakes permanently raised
- Ch 20: Dark night: separation or near-death, cost of love in danger made real
- Ch 23: Ultimate choice: mission vs. love, or betrayal that forces impossible decision
- Ch 28: Climactic action where romantic stakes fuel every moment
- Ch 30: Resolution earned: survival and love neither guaranteed nor denied without cause

PACING MANDATES

- No more than 2 chapters without forward threat movement
- No more than 3 chapters without romantic development
- Action sequences and romantic moments must OVERLAP, not alternate
- Final 8 chapters should feel like a fuse burning down
- Romance never stops the thriller. The thriller never forgets the romance.

ENDGAME LAYERING
The final 3-5 chapters should contain 2-3 cascading revelations, not a single climactic shootout:
- First: The operational truth (who the enemy really is and what they wanted)
- Second: The personal cost or sacrifice (what the protagonist is willing to lose)
- Third: The romantic resolution (earned reunion, sacrifice acknowledged, future forged in fire)
Order matters. the most emotionally devastating reveal comes last. In romantic thriller, the final beat should be emotional, not tactical. The reader should feel the conspiracy resolve, THEN feel their heart break or soar with the romantic payoff. One ending satisfies the mind; layered endings satisfy the heart.

EMOTIONAL CONTRAST IN ARC STRUCTURE:
Chart emotional highs and lows throughout both arcs. After scenes of maximum operational intensity, allow moments that catch the reader off guard. unexpected tenderness in a safe house, humor under pressure, a quiet gesture of care that contradicts everything tactical. After moments of romantic vulnerability, shatter the calm with an escalation that forces both characters back behind their operational masks. This oscillation between danger and tenderness, competence and vulnerability, is what gives romantic thriller its emotional rhythm and keeps readers turning pages.

EARNED ENDINGS:
The romantic resolution must be TRUE to the characters built throughout the story. Seed it early: the moment of trust that will be remembered in the climax, the specific vulnerability that had to be overcome, the operational choice that becomes a declaration of love. The reader should think "of course—it HAD to end this way, with THIS sacrifice and THIS reunion." Hope is earned, not guaranteed—and earned hope hits harder than certain safety.

THEME AS THROUGH-LINE:
Every strong romantic thriller weaves its theme through both the conspiracy and the love story. If the theme is about the cost of a dangerous life, the thriller plot shows the operational cost while the romance shows the personal cost. If it's about trust, professional trust and romantic trust should echo and test each other. Theme unifies the dual-frequency structure and gives the story weight that outlasts the adrenaline.
```

## Timeline Rules

```
TIME SCALE

Total story duration: Hours to days, rarely extending beyond two weeks
Chapter time span: Minutes to hours during action, hours to a day during regrouping
Time progression: Linear with relentless forward momentum. flashbacks rare and brief

GENRE-SPECIFIC TEMPORAL RULES

Compression Creates Tension:
- Romantic thrillers happen FAST: the ticking clock is the genre's heartbeat
- Days feel like weeks under threat: relationship intensity compressed by danger
- Romance accelerated by crisis is REALISTIC, not contrived: life-or-death situations bond people
- The "we've known each other three days" problem: acknowledge it. Characters KNOW this is fast. That's part of the emotional truth.

Countdown Elements (Use at least one):
- Bomb timer, auction deadline, extraction window, witness testimony date
- Antagonist's plan reaching completion: clock running whether protagonists act or not
- Political/public event creating hard deadline
- Personal countdown: someone captured, injured, or targeted with diminishing survival window

PACING TIMELINE

Act I (Ch 1-10): 24-72 hours
- Ch 1-3: Day 1: threat emerges, protagonists meet or are thrown together (HOURS)
- Ch 4-6: Day 1-2: forced alliance, first action sequence, first sparks (HOURS)
- Ch 7-10: Day 2-3: escalation, first real romantic moment, trust built through fire (HOURS TO A DAY)

Act II (Ch 11-23): 3-10 days
- Ch 11-14: Day 3-5: investigation and danger intertwined, relationship deepening (DAYS)
- Ch 15: Day 5-6: midpoint revelation, stakes reframed (HOURS)
- Ch 16-19: Day 6-8: hunted together, isolation intensifies bond and danger (DAYS)
- Ch 20-23: Day 8-10: dark night, separation or near-death, regrouping (HOURS TO DAYS)

Act III (Ch 24-30): 24-48 hours
- Ch 24-26: Final preparation: every second counts (HOURS)
- Ch 27-29: Climactic sequence: real-time tension, minutes matter (MINUTES TO HOURS)
- Ch 30: Aftermath: immediate resolution, future uncertain (HOURS)

ROMANCE IN COMPRESSED TIME

Track the relationship against the clock:
- How long since they met? (Acknowledge the speed: characters should be aware)
- When did trust shift from professional to personal?
- Physical intimacy paced against danger: urgency makes it believable, not rushed
- Post-crisis bonding: the quiet after the storm is where emotional depth happens

RED FLAGS TO INVESTIGATE

- Story extends beyond 2 weeks without justification
- Characters functional after 72+ hours without sleep
- Romance progresses with no shared danger catalyst (attraction must be forged in fire)
- Action sequence timing physically impossible (travel distances, reload times)
- Countdown abandoned or ignored for romantic interlude
- Injuries healed too quickly
- Characters have lengthy emotional conversations while being actively pursued

FLEXIBLE
- Exact times of non-critical events
- Minor travel duration variations
- Background character schedules if not affecting main threat
```

## Genre-Specific Craft Techniques

Romantic thriller at the level of Patricia Highsmith,
Daphne du Maurier, Gillian Flynn, Liv Constantine, Greer
Hendricks, Sarah Pekkanen, Alex Michaelides, A.J. Finn,
Colleen Hoover, and Jean Hanff Korelitz earns its genre-
defining intensity through dual-frequency writing,
professional competence rendered alongside romantic
vulnerability, and the genuine mortality stakes that
distinguish the form from romantic suspense. The form is
uniquely vulnerable to a cluster of failure modes that
AI-generated drafts hit with predictable frequency:
**Romance-Pauses-the-Thriller** (extended love scenes that
stop the forward momentum, voiding the form's relentless-
pacing contract); **Thriller-Forgets-the-Romance** (action
chapters where the relationship has no presence, breaking
the dual-frequency contract); **Incompetent-Protagonist**
(one or both leads needing rescue, voiding the form's
professional-competence contract); **Bond-Villain-
Monologue** (the antagonist explaining the conspiracy in
speech rather than threatening through action and reach);
**Coincidence-Resolves-Danger** (convenient coincidences
saving the protagonist when peril should have cost them);
**Damsel-Trophy Lead** (the love interest as passive cargo
or motivation, with one lead doing all the dangerous work
while the other waits); **Guaranteed-Survival Failure**
(the reader never believes the characters could die,
voiding the genre's mortality-stakes contract — HEA is
hoped for, not promised); **Trivially-Solvable Romantic
Conflict** (obstacles that a single conversation would
resolve, betraying the form's earned-obstacle contract);
**Single-Frequency Drift** (operational passages with no
emotional undercurrent, or emotional passages with no
tactical context — the dual-frequency rhythm requires both
channels active); **Stated-Chemistry Failure** ("she felt
the pull" replacing shown physical awareness and loaded
tactical dialogue); **Countdown-Forgotten-During-Romance**
(urgency dropping when it should be ever-present, the
ticking clock quietly abandoned for a romantic interlude
— this is an automatic fail); **Generic-Tough-Operative
Drift** (action-movie archetypes with romantic tension
bolted on, rather than specific surprising real people
whose romance emerges from who they actually are); and
**Action-Without-Aftermath** (characters performing
dangerous work without it affecting their inner life or
their relationship — the cost of operations skipped). The
three canonical technique clusters below — Dual-Frequency
Writing (with five rules), the Hope-and-Dread Engine
(with the Competence-Vulnerability Paradox), and the
Pacing Contrast Technique — are how the form defends
against these failure modes through dual-channel
specificity, mortal stakes, and earned intimacy.

### Dual-Frequency Writing (CRITICAL FOR ROMANTIC THRILLERS)

The romantic thriller's defining craft is maintaining two narrative channels simultaneously.
Every significant scene should operate on BOTH frequencies. operational and emotional.

**The 5 Rules of Dual-Frequency Prose:**

**Rule 1: Operational Surface, Emotional Undercurrent**
Every action scene carries romantic subtext. Every romantic moment carries threat awareness.
- During a firefight: tactical decisions that also protect the love interest
- During a safe house night: tenderness shadowed by the knowledge that safety is temporary
- Never write a scene that only serves one frequency

**Rule 2: Competence as Attraction**
Show attraction through professional admiration FIRST, physical awareness SECOND.
- "She cleared the room in three seconds. He'd never seen anyone move like that."
- The moment competence registers as attractive should be specific, not generic
- Professional respect is the foundation: build romantic tension on top of it

**Rule 3: Stolen Moments Architecture**
Plan romantic development points around operational pressure:
- Pre-mission: tension, unspoken fear for each other
- Mid-mission: adrenaline heightening physical awareness
- Post-mission: guards dropping, vulnerability emerging, the tremor after the danger passes
- Safe house: compressed intimacy, awareness of borrowed time

**Rule 4: The Unsaid Carries More Weight Than the Said**
In a genre where characters are trained to suppress emotion:
- Track what has NOT been said across the manuscript
- When someone finally breaks through operational language to say something raw, it should detonate
- "Stay alive" means "I love you." "Watch my six" means "I trust you with everything."
- The gap between what is felt and what is spoken IS the romantic tension

**Rule 5: Physical Contact Progression**
Track every physical touch and its context:
- Professional touch (adjusting body armour, checking wounds, steadying aim)
- Accidental touch (hands brushing, proximity in confined spaces)
- Intentional touch (hand on shoulder, held gaze)
- Intimate touch (earned through shared danger, not mere attraction)
- Each escalation should feel inevitable in context: danger compresses normal relationship timelines

### The Hope-and-Dread Engine

The romantic thriller's unique suspense tool: the reader desperately wants TWO outcomes (survival AND the relationship) and fears losing BOTH.

**How to operate the engine:**
- Create situations where both are at risk simultaneously
- A near-death that threatens reunion
- A separation that might be permanent
- A sacrifice that could save the mission but end the relationship
- The reader's investment in survival is DOUBLED because there are two things to hope for

**The Competence-Vulnerability Paradox:**
This is the genre's emotional engine. The protagonist who can disarm a bomb in thirty seconds but cannot say "I'm terrified of losing you." The operative who reads microexpressions for a living but can't read their own heart. Professional competence alongside romantic vulnerability is what makes these characters compelling. Exploit this contrast in every chapter.

### Pacing Contrast Technique

Relentless action without breathing room becomes numbing. The romance provides natural pacing contrast.

**The Rhythm:**
- Danger scene → stolen moment of tenderness → escalated danger
- The calm SETS UP the next blow: safe house intimacy makes the reader fear what's coming
- Romance scenes are NOT interruptions: they are the reload between shots
- When the reader catches their breath during a quiet moment, they're actually being primed for the next escalation

**What to avoid:**
- Two consecutive action sequences without emotional breathing room
- Two consecutive romantic scenes without threat awareness
- Extended romantic interludes that forget the countdown is still ticking
- Action sequences that forget the relationship exists

### Romantic Thriller AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "love in the crosshairs" | Show the specific moment where romance creates vulnerability |
| "she didn't know who to trust" | Show the specific contradictory evidence |
| "the threat was closer than she thought" | Show the specific discovery of proximity |
| "their love could get them killed" | Show the specific leverage point |
| "passion and peril intertwined" | Show ONE moment where both are present |
| "he had a dark past" | Show the specific past event through its current consequence |
| "the conspiracy ran deeper than they imagined" | Show the specific new thread |
| "their safe haven wasn't safe" | Show the specific breach |
| "love was the only thing that felt real" | Show the specific grounding moment |
| "the stakes were personal now" | Show the specific personal risk |
| "she felt the pull between them" | Show the specific physical or operational moment — the hand on the small of her back, the held look across the briefing table, the second she didn't take to step away |
| "he would do anything to protect her" | Show the specific tactical choice — the position taken between her and the doorway, the round saved for the worst case, the truth withheld because the consequence is unbearable |
| "their chemistry was undeniable" | Show one specific charged exchange the reader can hear, or one specific unintended touch with its specific aftermath in both bodies |
| "the mission and her heart were now intertwined" | Show the specific operational decision that was made differently because of the relationship |
| "a love forged in fire" | Show the specific moment of fire — the firefight in the parking garage, the bleeding-out in the car, the specific instant the trust was earned |
| "danger had brought them closer" | Show the specific shared danger and its specific effect on the next scene's intimacy |
| "she trusted him with her life now" | Show the specific moment of trust — the back turned, the door unwatched, the weapon she let him hold |
| "he was a man of secrets" | Show one specific secret-keeping behaviour — the call he didn't take in front of her, the room she's not allowed in, the photo he turned face-down when she walked in |

## Genre-Specific Revision Rules

### Six-Pass Romantic Thriller Audit (Run FIRST in editorial pipeline)

The Romantic Thriller Audit runs every chapter through six
named passes. Run them in order — each builds on the last.

#### Pass 1: Dual-Frequency Balance

The Dual-Frequency Balance pass enforces the form's
defining contract against Single-Frequency Drift. Verify
each chapter operates on BOTH frequencies — operational
AND emotional — with neither channel ever fully silent.
For action-heavy chapters, verify there is at least one
moment of romantic awareness or vulnerability woven into
the operational sequence (the hand that finds the other's
in the dark, the tactical choice made differently because
of the relationship, the half-second flash of the other
person during the firefight). For romance-heavy chapters,
verify there is at least one reminder of active danger or
operational context (the countdown still ticking, the
weapon still present, the awareness that safety is
borrowed). Flag any chapter that runs entirely on one
frequency. Verify the dual-frequency dialogue contract:
operational dialogue carrying emotional subtext, every
significant exchange serving both the thriller and the
romance simultaneously. Confirm the genre's signature
tactic — "Stay alive" means "I love you," "Watch my six"
means "I trust you with everything" — is operating
across the manuscript, not just at designated moments.
The pass also verifies the Competence-Vulnerability
Paradox is active throughout: professional control never
completely masking the person underneath, the operative's
mask slipping at specific moments the manuscript renders.

#### Pass 2: Thriller Dominance + Pacing

The Thriller Dominance and Pacing pass enforces the
form's distinction from romantic suspense. Verify the
external threat drives every chapter forward — the
chapter's plot must work without the romance (the
thriller engine must be self-sufficient, with the romance
making it MATTER, not making it work). Verify the
romance ENHANCES the stakes rather than pausing them.
Verify the pacing is relentless with earned breathing
room, not stalling: no extended romantic interludes
without threat awareness, no romance scenes that stop the
plot dead, no "thriller pauses for love" failures.
Verify the form's no-more-than rules: no more than 2
chapters without forward threat movement; no more than 3
chapters without romantic development; action sequences
and romantic moments OVERLAP rather than alternate. The
final 8 chapters should feel like a fuse burning down.
Verify the genre promise: a thriller where love happens,
not a romance where danger happens. If the romance were
removed, the thriller plot must still work; if the
thriller were removed, there is no book. The pass closes
by confirming pacing contrast: danger scene → stolen
moment of tenderness → escalated danger. Two consecutive
action sequences without emotional breathing room numb
the reader; danger followed by warmth makes both register
at full force.

#### Pass 3: Competence + Technical Accuracy

The Competence and Technical Accuracy pass enforces the
form's professional-reader contract. For Competence,
verify both leads demonstrate professional-grade skill
through ACTION (not narrator description) — clearing
rooms, reading people, making tactical decisions,
solving problems under pressure. Verify competence is
shown, not told — flag "she was one of the best" without
on-page demonstration. Verify neither lead needs rescuing
by the other more than once across the manuscript
(partnership, not protection). Verify the antagonist is a
credible threat to professionally competent people: equally
skilled or resourced, not a pushover for trained
protagonists, active throughout rather than waiting for
the climax. For Technical Accuracy, verify weapons (correct
caliber, realistic magazine capacity, proper handling,
reload times); procedures (law enforcement protocols,
military terminology, intelligence tradecraft verified
against actual practice); locations (real geography,
accurate distances, plausible logistics, travel times);
medical (realistic injuries, actual recovery times, correct
treatment); communication (operational comms, encrypted
channels, surveillance capability all plausible). Verify
consequence persistence: an injury in Chapter 5 still
affects the protagonist in Chapter 15; equipment lost
stays lost; depletion accumulates across the arc. The
informed reader (military, law enforcement, intelligence
practitioner, medical professional) must not be jarred
out of the manuscript by basic technical errors.

#### Pass 4: Stolen Moments + Trust and Vulnerability

The Stolen Moments and Trust and Vulnerability pass
enforces the form's earned-intimacy contract. For Stolen
Moments, verify romantic moments are woven INTO the
thriller, not pausing it: stolen moments feel urgent and
time-limited rather than leisurely; physical intimacy
(when present) is charged by danger rather than
separated from it; every romantic beat advances the
relationship AND heightens the stakes. Verify the
form's stolen-moments architecture: pre-mission tension
and unspoken fear; mid-mission adrenaline heightening
physical awareness; post-mission guards-dropping
vulnerability; safe-house compressed intimacy with
awareness of borrowed time. For Trust and Vulnerability,
map trust milestones chapter by chapter — professional
trust and romantic trust tracked separately, since they
escalate at different rates and through different
catalysts. Verify trust never jumps levels without
earned catalyst (shared danger, operational reliability,
vulnerability shown specifically). Check that emotional
walls established early don't vanish without narrative
justification — if a fear of vulnerability was set up in
Chapter 3, it must be worked through across multiple
chapters, never simply forgotten. Verify physical
contact progression: professional touch (adjusting body
armour, checking wounds, steadying aim) → accidental
touch (hands brushing, proximity) → intentional touch
(hand on shoulder, held gaze) → intimate touch (earned
through shared danger). Each escalation should feel
inevitable in context.

#### Pass 5: Countdown Integrity

The Countdown Integrity pass enforces the form's ticking-
clock contract against Countdown-Forgotten-During-Romance.
Verify the ticking clock is first established by the end
of Act 1 (no later); that no more than 3 chapters pass
without a clock reference (romantic thriller's threshold
is tighter than general thriller's because the form
operates at higher pacing intensity); that the countdown
compresses in Act 3 (chapters cover shorter time spans);
and that the deadline is never quietly abandoned for a
romantic interlude (this is an automatic fail). Verify
the romance accelerates WITH the countdown rather than
despite it — the compression of relationship development
must feel justified by the operational pressure, with
characters aware they are operating on borrowed time.
Track the countdown's specific landmarks: when is the
deadline; what happens if it expires; what tactical or
emotional milestones must be reached before then. Verify
the countdown applies pressure to the romantic arc as
well as the operational arc — characters cannot have
extended emotional conversations while being actively
pursued or while a bomb is counting down. The form's
strongest practitioners use the countdown to force
relationship clarity that would never happen in safe
conditions; the manuscript must use the clock as both
operational and emotional pressure, never as decoration.

#### Pass 6: Cliffhanger + Resolution Honesty

The Cliffhanger and Resolution Honesty pass enforces the
form's chapter-end and arc-end contracts. For Cliffhanger,
verify every chapter ends on a cliffhanger, revelation, or
emotional gut-punch — never on summary, reflection, calm,
or resolution. Flag chapters ending on resolution. Verify
Act 3 hooks escalate beyond Act 1 hooks. Verify hook types
are varied (not all the same): mid-action cuts, threat
escalations, ally compromises, romantic-revelation
turns, decision points, location shifts — the rotation
matters. For Resolution Honesty, verify the form's
Guaranteed-Survival contract is held — the reader must
believe the characters could die, with mortal stakes
genuine through Act 3. Verify the climactic action
sequence has romance providing the emotional fuel rather
than pausing for declarations. Verify the endgame layering
across the final 3-5 chapters: first the operational
truth, then the personal cost or sacrifice, then the
romantic resolution — the most emotionally devastating
reveal landing last. Verify the form's earned-hope
contract: hope is earned, not guaranteed; the resolution
should feel TRUE to the characters built throughout the
story; "of course it had to end this way, with THIS
sacrifice and THIS reunion." Verify cost is acknowledged:
scars, losses, changed worldview — what they have was
forged in fire. The pass closes by confirming the genre's
signature: thriller fan satisfied AND emotionally moved,
with the conspiracy resolved and the heart either broken
or soaring.

## Names & Patterns to Avoid

### Romantic Thriller Character Names. NEVER USE
- Protagonist names: Jack Stone, Max Steel, Blaze, Hunter, Gunner, Hawk, Wolf (action-movie names)
- Love interest names: Any name chosen purely because it "sounds sexy" (Scarlett, Raven, Blaze)
- Antagonist names: Viktor (any spelling), Dimitri, Hans, or any name selected to "sound villainous" by ethnicity
- Handler names: Control, The Director, The Old Man (unless deliberately homaging le Carré)
- Generic operative names: Agent [Surname], Codename [Animal/Color]

### Romantic Thriller Organisation Names. NEVER USE
- "The Shadow [Noun]" (The Shadow Council, The Shadow Protocol)
- "Project [Greek Letter]" (Project Omega, Project Alpha)
- "Operation [Dramatic Adjective]" (Operation Darkfall, Operation Endgame)
- "[Color] [Noun]" for covert ops (Black Horizon, Red Cipher, Dark Aegis)

### Romantic Thriller Plot Patterns. AVOID
- Love interest is kidnapped purely as motivation for the protagonist (fridging)
- The "she's not like other girls" operative who's exceptional because she's female
- The stone-cold operative who is instantly softened by the love interest's beauty
- Sexual tension replaced by actual sex at every opportunity (earned intimacy, not constant)
- The betrayal is always the mentor/handler (find a more surprising traitor)
- The female lead exists only to humanise the male lead
- Both leads are generically "tough" without emotional specificity
- The villain targets the love interest because "that's what villains do" (needs specific tactical reason)
- The countdown stops at 0:01 (find a more inventive resolution)
- Opening with the protagonist on a solo mission that goes wrong (overused)

### Use Instead
- Real names from census data appropriate to character background (Michael, Sarah, James, Daniel, David, Priya, Catherine, Laura)
- Organisations with bureaucratic real-world names (National Infrastructure Security Division, Joint Threat Assessment Group)
- Operations named after mundane things (Operation GARDEN FENCE, Operation BLUE LAMP. real ops have boring names)
- Diverse cast with names matching actual demographic backgrounds of their professions
- Both leads with specific, surprising traits that subvert their archetype
- Plot twists that feel inevitable in hindsight, not "gotcha" surprises
- Betrayals that reframe earlier scenes: "of course, that explains the hesitation in chapter 7"
- Romantic development that emerges from who these SPECIFIC people are, not from generic chemistry

## Comp Titles

Romantic-thriller's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Talented Mr. Ripley* — Patricia Highsmith (1955): obsession-thriller with romance-coded undertow.
- *Rebecca* — Daphne du Maurier (1938): the marriage-thriller template.
- *Gone Girl* — Gillian Flynn (2012): the modern marriage-thriller benchmark; reframed the category.

### Contemporary (current best-in-class)

- *The Last Mrs. Parrish* — Liv Constantine (2017): contemporary marriage-thriller with class-friction architecture.
- *The Wife Between Us* — Greer Hendricks & Sarah Pekkanen (2018): twist-led romantic-thriller; modern category benchmark.
- *The Silent Patient* — Alex Michaelides (2019): psychological-thriller-romance hybrid.
- *The Woman in the Window* — A.J. Finn (2018): unreliable-narrator romantic-thriller.
- *Verity* — Colleen Hoover (2018): romantic-thriller with manuscript-as-evidence; massive commercial success.
- *The Plot* — Jean Hanff Korelitz (2021): writer-protagonist romantic-thriller; literary-commercial crossover.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. The dominant style for romantic thriller; film-poster compositions with high contrast, dramatic lighting, and widescreen energy convey the operational intensity this genre demands
- **Photorealistic**. Real figures in high-stakes environments; suits romantic thrillers grounded in recognizable settings (cities, military installations, covert operations); must feel urgent, not posed
- **Typographic**. Bold, aggressive typography dominating the cover with atmospheric imagery beneath; works for established authors and series where the brand is the draw; the lettering itself should feel dangerous
- **Graphic**. High-contrast, stylized design with bold silhouettes and negative space; suits modern, high-concept romantic thrillers; crosshair motifs, shattered glass, fractured compositions

### Genre Cover Aesthetics
- **Styles:** High-contrast cinematic compositions, dual-figure silhouettes suggesting partnership under fire, urban nightscapes with cold operational lighting, split or fractured imagery implying dual lives, figures in motion (running, fighting, reaching for each other), dramatic angles and depth
- **Colours:** Deep black and charcoal (operational darkness, covert ops), blood red and dark crimson (danger, passion, cost), cold steel blue and gunmetal (tactical, clinical, professional), amber and warm gold sparingly (the human warmth beneath the operational surface), stark white as accent (light cutting through darkness). high contrast is essential
- **Elements:** Urban skylines at night, shadowed figures in tactical clothing, dual silhouettes (together or separated), crosshairs or scope imagery, shattered or fractured glass, city lights reflected on wet streets, helicopter searchlights, encrypted text or redacted documents, weapons as props not focal points, buildings and bridges in dramatic perspective
- **Typography:** Bold, angular sans-serif fonts with weight and urgency; title often large and dominating; stencil or military-style lettering for certain subgenres; metallic or embossed effects (gunmetal, chrome); author name strong and prominent; taglines short and punchy

### Subgenre Variations
- **Military Romantic Thriller**. Tactical imagery, desert or combat-zone landscapes, dog tags, military silhouettes; more muted earth tones alongside the standard dark palette; cinematic dominates
- **Spy/Espionage Romantic Thriller**. Sleeker, more sophisticated design; European city settings, passport stamps, redacted text overlays; cooler colour palette; more typographic options
- **Political Romantic Thriller**. Institutional imagery (government buildings, courtrooms, media); more restrained design; power-suit silhouettes; darker, more serious tone in typography
- **Action-Adventure Romantic Thriller**. More dynamic compositions, exotic locations, brighter accent colours; closer to film-poster aesthetic; movement and energy in the design

### Market Positioning
Romantic thriller covers must read as THRILLER FIRST on Amazon thumbnails. The operational intensity, dark palette, and high-contrast design should immediately signal danger and urgency. The romantic element is conveyed through dual-figure compositions, warm accent colours beneath the cold surface, and body language suggesting emotional connection within a hostile environment. not through soft romantic posing. At thumbnail size, the cover should be indistinguishable in energy from a top-tier thriller; the romantic element reveals itself on closer inspection. This is critical: readers who want a thriller with romantic depth will click; readers who see a romance cover will scroll past. Bold typography at large scale ensures title and author name punch through even at small sizes.

### Cover Design DON'Ts
- No soft romance aesthetics. dreamy lighting, pastel colours, flowing dresses, tender couple poses; this is a thriller cover with romantic energy underneath, not a romance cover with thriller elements
- No pure action-movie design without emotional charge. there must be something human and vulnerable beneath the operational surface, even if subtle
- No illustrated or cartoon styles. photorealistic and cinematic are the only credible options for this market
- No cluttered compositions with too many elements. the design should be bold, clean, and high-impact; one or two strong visual elements, not a collage
- No weapons as the sole focal point. guns, knives, and explosives should support the composition, not dominate it; this is about the people, not the hardware
- No cheap stock-photo aesthetics. the imagery must feel cinematic and intentional, not assembled from a photo library
- No bright, saturated colours (tropical blues, sunny yellows, vibrant greens). the palette is dark, cold, and controlled with warm accents earned, not given
- No generic "man in suit" or "woman looking over shoulder" without environmental context. the setting and situation must be visible and specific
