---
name: beta-synthesis-capstone
description: "Gated Beta Reader Panel synthesis-on-top capstone. Runs only when context-budget-gate.md returns GLOBAL-ELIGIBLE; reads the five per-persona Beta Reader reports + the full manuscript + the Story Bible into a single PARENT 1M context, then reasons across the lenses to produce the four classes of finding the existing consolidated dedup report structurally cannot: productive conflicts (where personas disagree in craft-meaningful ways), whole-book arc patterns (findings that emerge across reports but no single persona stated), justified prioritization (why this ranking, not just the ranking), and fix-compatibility analysis (do the recommended fixes work together). It then emits a machine-consumable Revision Routing plan (§5) that classifies every finding into one of three autonomy tiers — SURGICAL (auto-applied by revision-loop.md / surgical-fixes.md), DEVELOPMENTAL-BOUNDED (drafted and applied by the revision loop's Tier-2 gated executor behind a human-confirm checkpoint), or CREATIVE-OPEN (escalated to the author with the productive-conflict framing) — so the synthesis feeds the autonomous revision loop rather than terminating as advisory prose. Fail-closes to 'use the existing consolidated dedup report' so cost-saver projects are unaffected. Opt-in trigger: this is the deeper, higher-cost second pass; the consolidated dedup report remains the default Stage 6 output. Fiction-engine only initially — NF's per-project domain-expert panel has fundamentally different inputs and would need its own synthesis design."
version: "2.7.107"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript Engine
> *© James Harvey Media. All rights reserved.*

# Beta Synthesis Capstone — Cross-Lens Reasoning Over the Five-Persona Panel

## Purpose

The v2.7.103 fiction Beta Reader Panel produces five per-persona
reaction reports (Genre Devotee, Casual, Critical, Target-Audience,
Emotional) plus a consolidated summary that lists each report and
flags **DEDUPLICATION-CANDIDATE** findings raised by 2+ personas
independently. That consolidation is fast and mechanical — its job
is to surface convergent findings without collapsing the per-persona
reports, which remain authoritative.

What the consolidated report **structurally cannot do** — by design,
because it's a list/dedup operation — is reason ACROSS the lenses:

1. **Productive conflicts.** Where personas DISAGREE in craft-
   meaningful ways. From the canonical Synthiate panel run: the
   Genre Devotee scored Chapter 26 (Sean's apartment erased) at
   9/10 ("three gestures of institutional conscience, each
   insufficient, each the most the person could do"); the
   Emotional Reader noted the same chapter "asks for grief the
   book hasn't fully primed the reader to feel for Sean as a
   person rather than as an investigative collaborator." Both
   readings are defensible. Both are honest. The disagreement is
   itself a craft signal — the author faces a real decision (does
   Sean need additional pre-Ch-26 interiority, or is institutional
   horror the correct register?) that the dedup report doesn't
   surface because the two findings don't share enough wording to
   trigger DEDUP-CANDIDATE.

2. **Whole-book arc patterns.** Findings that emerge ACROSS
   reports but no single persona stated. From the Synthiate run:
   the Critical Reader flagged Laura Beckett's underdeveloped
   interiority ("defined primarily by method and prior loss");
   the Emotional Reader flagged Sean's similar gap ("primarily a
   technical partner — known through pen-clicking and sardonic
   deflection, not vulnerability"). Both observations are
   present in the consolidated report as separate single-persona
   findings. Neither persona connected them. The cross-report
   pattern — *the book renders Jim/Rachel/Doug with interior life;
   renders Sean/Laura primarily through method and function across
   the second half* — is the actionable craft observation. Surfacing
   it requires reading both reports against the manuscript at once.

3. **Justified prioritization.** The Synthiate consolidated report
   says "Primary revision priority: DEDUP-01 (Ch 14-17 velocity
   dip)." It does not argue WHY DEDUP-01 over DEDUP-02 or DEDUP-04.
   A capstone argues: DEDUP-01 affects every reader's experience
   for ~50 pages (highest reader-experience scope); DEDUP-02 affects
   only the final-chapter landing (narrower scope); DEDUP-04 is an
   additive scene (lower cost, but doesn't fix an existing problem).
   Same ranking — but now defensible to the author rather than
   asserted.

4. **Fix-compatibility analysis.** The Synthiate panel recommends
   three fixes: move the patent filing earlier (DEDUP-01 fix); reorder
   Ch 30 internal sequence (DEDUP-02 fix); add an Owen scene
   (DEDUP-04 fix). Are these mutually compatible? Do they touch
   the same chapters? Does the patent-filing reposition affect
   Ch 30's restructure? Should Owen's scene land before or after
   Ch 23 to maximize emotional setup-payoff? The dedup report
   surfaces fixes in isolation. The capstone analyzes them as a
   revision plan.

This spec authorizes a separate, explicit capstone pass that
performs these four classes of reasoning. It is **opt-in**, runs
only when the Context Budget Gate grants the 1M slot, fail-closes
to the existing consolidated report when not authorized, and does
not replace or modify any output from the Beta Reader Panel itself.

## Relationship to the Beta Reader Panel (NOT a replacement)

The Beta Reader Panel (v2.7.103) remains exactly as shipped:

- Five per-persona reaction reports written to `engine-data/reports/`
- A consolidated dedup report (`engine-data/reports/beta-reaction-report.md`) listing
  each report + DEDUPLICATION-CANDIDATE findings

The Synthesis Capstone is a **second, optional pass**. It reads
the panel's outputs as inputs and produces ONE additional file:

```
engine-data/reports/beta-synthesis.md
```

The per-persona reports are not modified, re-summarised, or
overridden. The consolidated dedup report is not replaced. The
synthesis is ADDITIVE: a reader who wants only the panel can
ignore the synthesis; a reader who wants the deeper read has
both.

This separation matters because:

- The dedup report is fast, cheap, and structurally honest about
  what it does (list + flag convergence). Removing it would break
  cost-saver projects.
- The synthesis is slow, expensive (1M context), and requires
  Opus-class reasoning. Making it mandatory would impose that
  cost on every panel run.
- The two artifacts serve different consumption modes: dedup for
  "what does the panel agree on?" — synthesis for "what should
  I revise next, in what order, and why?".

## Why it needs 1M context (the honest case)

The synthesis must read, **in one parent context**:

- All five per-persona reports (≈5,000-15,000 words combined)
- The full manuscript (typically 60,000-120,000 words)
- The Story Bible's character section + audience profile
  (the context the personas implicitly assumed)
- project-config.md + the Alpha Reader report (cross-reference, for
  the metadata-consistency scan — see procedure step 5b)

A normal-context (~200K tokens) summary-based pass would
materially degrade two of the four reasoning classes:

- **Whole-book arc patterns** require checking persona findings
  against actual manuscript text at multiple chapter positions.
  Pre-summarising the manuscript loses the texture the persona
  findings cite (specific beats, exact phrases). Once summarised,
  the synthesis can no longer verify a finding like "Owen goes
  quieter" by locating the specific descriptions across the
  manuscript.
- **Fix-compatibility analysis** requires reasoning about which
  chapters each proposed fix touches and whether they interact.
  This requires the manuscript present in full, not a summary.

Productive-conflict surfacing and justified prioritization could
in principle work with a manuscript summary — but the same
capstone pass is performing all four, and the manuscript-present
overhead is shared across them. There is no efficient way to
load only-what-the-second-and-third-class-need without losing
the first and fourth classes.

This is the second consumer of `context-budget-gate.md` after
`arc-completion-capstone.md` (v2.7.100). The pattern is the
same: real cross-cutting reasoning that subagent windowing cannot
deliver, gated against accidental cost.

## Why parent-context, not a subagent dispatch

Subagent dispatch (the pattern used by Class B audits and by the
five Beta Reader personas themselves) provides isolation and the
subagent-output-verification HARD GATE on return. That is the
correct pattern when the dispatched work has a narrow scope and
the parent needs the result verified before acting on it.

The Synthesis Capstone needs the OPPOSITE: a single agent
holding all six artifacts (5 reports + manuscript) in one mind
and reasoning across them. Subagent dispatch would fragment the
synthesis (one subagent per output section?) and lose the
cross-section coherence the capstone exists to produce.

This matches the v2.7.100 Arc-Completion Capstone architecture:
parent-context reasoning, gated by Context Budget Gate, with the
gate (not subagent-output-verification) as the structural
authorization.

The trade-off: the capstone's output is not protected by the
subagent-output-verification HARD GATE. The verification net is
different — every finding in the synthesis report MUST cite at
least two source-persona claims by file + section, AND every
manuscript-evidence assertion MUST cite chapter + the exact
extracted text. The main agent spot-checks at least one finding
per output section before delivery (see Silent-Failure Audit
below).

## Gate-binding (FAIL-CLOSED)

The capstone registers against `context-budget-gate.md` BEFORE
loading any inputs. Request shape:

```
CAPSTONE_REQUEST: beta-synthesis
INPUTS (mandatory):
  - 5 × engine-data/reports/beta-reaction-{persona}.md
  - engine-data/chapters/* (full manuscript)
  - engine-data/story-bible.md (character + audience sections)
INPUTS (cross-reference — for the metadata-consistency scan):
  - engine-data/project-config.md (series/volume, title, declared
    comp titles, character-name register — cross-checked against the
    Story Bible and the manuscript)
  - the Stage 5 Alpha Reader report, if persisted (its general-reader
    flags often pre-figure a metadata or whole-book finding)
ESTIMATED_TOKENS: {sum of measured input sizes}
JUSTIFICATION: cross-lens synthesis (4 classes + metadata-
  consistency scan) cannot be performed under windowed dispatch —
  see capstone spec § "Why it needs 1M context"
```

Gate responses and capstone behavior:

| Gate response | Capstone action |
|---|---|
| GLOBAL-ELIGIBLE | Proceed: load inputs, run synthesis, write report |
| INELIGIBLE | Halt with explicit message: "Synthesis capstone requires {ESTIMATED_TOKENS} but Context Budget Gate denied. Existing consolidated dedup report (`engine-data/reports/beta-reaction-report.md`) remains authoritative. Adjust budget or re-run without capstone." |
| GATE_UNAVAILABLE | Halt with explicit message: same as INELIGIBLE — fail-closed, never proceed without explicit gate authorization |

The capstone NEVER silently proceeds with a degraded input set
(e.g., manuscript summarised because full text exceeded budget).
If the inputs cannot fit, the capstone halts. The dedup report
covers cost-saver projects.

## When this runs (opt-in trigger)

Two trigger paths, both opt-in:

1. **After Stage 6 panel completes**, the engine offers in chat:

   > "The Beta Reader Panel has completed. The five per-persona
   > reports and consolidated dedup report are in
   > `engine-data/reports/`. Would you like to run the Beta
   > Synthesis Capstone? This is an additional deep-reasoning
   > pass (~1M context, Opus-class) that synthesises across the
   > five lenses to identify productive conflicts, whole-book
   > arc patterns, justified prioritization, and fix-compatibility
   > analysis. Higher quality, higher latency, higher token cost
   > than the dedup report you already have."

   User answers YES → proceed (gate check + run). User answers NO
   or declines → panel output stands; capstone does not run.

2. **User-invocable independently** via trigger phrase (after a
   prior panel run, without re-running the panel):

   > "Run beta synthesis" / "Synthesise the panel" / "Cross-lens
   > beta read"

   The capstone reads the existing `engine-data/reports/beta-
   reaction-*.md` files (Read-Verification HARD GATE per file —
   if any persona report is missing or empty, capstone halts with
   "Panel incomplete: cannot synthesise from 4/5 reports"), checks
   the gate, runs the synthesis.

The capstone is NOT automatic after the panel. The dedup report
is the default Stage 6 output; the capstone is the deeper opt-in
second pass.

## Capstone procedure

1. **Trigger received.** Either post-panel offer accepted, or
   user invoked independently.

2. **Read-Verification HARD GATE on the five persona reports.**
   Each `engine-data/reports/beta-reaction-{persona}.md` Read,
   verified non-empty per `read-verification.md`. If any persona
   report fails verification, halt with explicit "Panel
   incomplete" message. Do NOT proceed with 4/5 reports —
   synthesis depends on cross-lens reasoning, which a missing
   lens would silently degrade.

3. **Read-Verification HARD GATE on the manuscript.** Every
   chapter in `engine-data/chapters/` Read, verified non-empty.
   Per the file-freshness post-write discipline, the chapter
   set used for synthesis MUST match the chapter set the panel
   read (file modification timestamps compared — if any chapter
   has changed since the panel ran, halt with "Manuscript
   modified since panel run: re-run panel before synthesis or
   acknowledge stale-panel synthesis").

4. **Read the Story Bible's character + audience profile**
   sections. Verified non-empty.

5. **Context Budget Gate request.** Submit ESTIMATED_TOKENS
   (measured sum of input sizes). On GLOBAL-ELIGIBLE, proceed.
   On INELIGIBLE or GATE_UNAVAILABLE, halt with the explicit
   message above.

5b. **Metadata-consistency scan (MANDATORY).** Cross-check the
   series/volume count, title, declared comp titles, and principal
   character names across `engine-data/project-config.md`, the Story
   Bible, and the manuscript. Any divergence (e.g. a character named
   one way in the Bible and another in a late chapter, a comp title
   in config the prose doesn't deliver, a volume/series number that
   disagrees between config and Bible) is a §2 Metadata-Consistency
   pattern, and the fix routes to §5c CREATIVE-OPEN (factual
   metadata) or §5a (a name-spelling fix is surgical) as
   appropriate. The synthesis NEVER picks which conflicting value is
   correct when the answer is an authorial fact (volume count, the
   "true" character name) — that routes to the author. (This mirrors
   the NF engine's volume-count catch on its validation run.)

6. **Synthesis pass.** Reason across all inputs in the single
   parent context. Produce the five output sections (schema
   below): §1-§4 reasoned prose, §5 the machine-consumable
   revision-routing plan. Every finding cites at least two
   source-persona claims by file + section heading. Every
   manuscript-evidence assertion cites chapter + the exact
   extracted text of the passage. In §5, every finding is routed
   to exactly one tier (SURGICAL / DEVELOPMENTAL-BOUNDED /
   CREATIVE-OPEN); a DEVELOPMENTAL-BOUNDED finding with no
   existing SETUP ANCHOR in the manuscript MUST be re-routed to
   CREATIVE-OPEN (no setup = it is not a bounded payoff, it is a
   creative addition).

7. **Self-verification spot-check (MANDATORY).** Before writing
   the report, spot-check at least one finding per output section
   by re-reading the cited persona-report passages and confirming
   the cited text exists verbatim. If any cited passage cannot
   be located, drop that finding from the report and surface the
   verification failure in a "Drop log" subsection at the end.

8. **Write `engine-data/reports/beta-synthesis.md`** via
   File-Write Hygiene (Edit/Write tool, never bash cat-and-mv).
   Per `core-pipeline.md`, the post-write verification hook
   re-verifies the artifact on disk.

9. **Present the synthesis report inline + as a `.docx` render**
   following the same delivery convention as the Beta Reader
   Panel output: `Beta-Synthesis-Capstone-{Title}.docx`.

## Output schema

The synthesis report has five output sections, in this order.
Sections 1-4 are reasoned prose for the author; section 5 is the
machine-consumable revision plan the autonomous loop ingests. The
schema is structural; the prose within each reasoned section is
not templated.

```markdown
# Beta Synthesis Capstone — {Title}

> Synthesis of the v{X} Beta Reader Panel for {Title} by {Author}
> Source reports: 5 × beta-reaction-*.md | Manuscript: {N} chapters, {word count}
> Generated: {date} | Capstone version: v2.7.107
> Context Budget Gate: GLOBAL-ELIGIBLE ({estimated tokens})

(The manuscript word count and chapter count in this header MUST
match the figures used in the body of the report — a capstone that
contradicts itself on the manuscript's size has not actually read
what it claims to have read.)

## 1. Productive Conflicts

Disagreements between personas where the difference is craft-
meaningful (not trivial wording overlap, not subjective taste
within the same finding). Each entry:

- **Conflict statement** (one sentence)
- **Personas involved** (which reports + which sections)
- **Substance of the disagreement** (what each side observes,
  cited verbatim from the reports)
- **Craft decision the author faces** (what's actually being
  asked)
- **Synthesis read** (which way the balance leans, or explicit
  acknowledgement that it's a coin-toss the author owns)

## 2. Whole-Book Arc Patterns

Findings that emerge ACROSS reports but no single persona
stated. Each entry:

- **Pattern statement** (one sentence)
- **Contributing persona findings** (cited verbatim from the
  reports, ≥2 personas)
- **Manuscript evidence** (chapter + exact extracted passages
  supporting the pattern)
- **Revision implication** (what this implies for the author —
  specific, actionable)

One pattern type is a MANDATORY output of the step-5b scan and
appears here whenever it fires:

- **Metadata-Consistency pattern** — any divergence in series/
  volume count, title, declared comp titles, or principal character
  names across project-config.md, the Story Bible, and the
  manuscript. State each source's value verbatim with its file +
  location. Authorial-fact divergences (volume count, canonical
  character name) route to §5c CREATIVE-OPEN for author confirmation
  — the synthesis never selects the correct value.

## 3. Justified Prioritization

Ranked list of all findings the panel raised (DEDUP +
single-persona). For each:

- **Rank position** (1, 2, 3, ...)
- **Finding** (one-sentence statement + source — DEDUP-N or
  persona name)
- **Reader-experience scope** (does it affect every reader, or
  only a subset?)
- **Revision cost class** (additive scene, reordering, rewrite,
  line-edit, structural change)
- **Revision tier** (SURGICAL | DEVELOPMENTAL-BOUNDED |
  CREATIVE-OPEN — see §5 for the routing definitions; this field
  is what §5 keys off)
- **Confidence** (single-persona, dedup-2, dedup-3+, capstone-
  derived from whole-book pattern)
- **Why this rank** (one paragraph arguing the position — must
  reference at least one of scope, cost, or confidence)

## 4. Fix-Compatibility Analysis

Treats the recommended fixes as a revision plan. Each entry:

- **Fix description** (what the author would do)
- **Chapters touched** (specific list)
- **Interaction with other fixes** (does Fix A enable Fix B?
  Does Fix C make Fix D redundant? Are A and B compatible?)
- **Suggested order** (which fix first, which depends on which)
- **Combined effect estimate** (one paragraph — what the
  manuscript looks like after the full revision plan)

## 5. Revision Routing (machine-consumable revision plan)

The bridge into the autonomous revision loop. Every finding from
§1-§4 is routed into exactly one of three autonomy tiers. This
section is what `revision-loop.md` ingests; the prose sections
above are for the author, this section is for the machine.

### 5a. SURGICAL fixes → revision-loop.md / surgical-fixes.md

Line-level fixes that change ≤ a few sentences, add no new scene,
move no beat, and stay within the surgical word-count discipline
(±5%). Emitted in the EXACT shape `surgical-fixes.md` Step 1
consumes, one block per fix:

```
TIER: SURGICAL
CHAPTER: {chapter file}
EXACT QUOTE: "{verbatim text from the chapter to change}"
PROBLEM: {what's wrong — traced to the persona finding}
FIX: {the replacement text}
REASON: {which persona(s) flagged it + the craft rationale}
```

Worked example (from the Synthiate run, Casual Reader finding):

```
TIER: SURGICAL
CHAPTER: engine-data/chapters/ch22.md
EXACT QUOTE: "Meridian Consulting Group operated out of Tysons Corner."
PROBLEM: Two Meridian entities appear in this chapter; the reader
  has to re-read to tell Meridian Applied Sciences (Reston
  researcher shell) from Meridian Consulting Group (Tysons
  operational entity). [P2 Casual, Comprehension §]
FIX: "Meridian Consulting Group — a separate entity from the
  Reston research shell, this one the operational arm — operated
  out of Tysons Corner."
REASON: P2 Casual Reader flagged first-mention ambiguity; a single
  differentiating clause resolves it without restructuring.
```

### 5b. DEVELOPMENTAL-BOUNDED fixes → revision-loop.md Tier-2 gated executor

Changes that are larger than surgical but still BOUNDED and
VERIFIABLE — they do not require open creative judgment. Exactly
two operations qualify:

- **additive-insertion** — inserting a new self-contained scene
  or beat at a clean chapter/section boundary, where the
  surrounding text is not rewritten (e.g. the Synthiate Owen
  scene). Setup anchors already exist in the manuscript; the
  insertion pays them off.
- **beat-relocation** — moving a self-contained beat from one
  chapter to another (e.g. the Synthiate patent-filing move from
  Ch 19 to Ch 16-17), where the beat is liftable without
  rewriting the prose around either the source or target.

Anything that requires rewriting existing prose, changing what a
character decides, altering the ending, or restructuring scene
logic is NOT developmental-bounded — it is CREATIVE-OPEN (§5c).
Emitted one block per fix:

```
TIER: DEVELOPMENTAL-BOUNDED
OPERATION: additive-insertion | beat-relocation
TARGET POINT: {for insertion: the chapter + boundary where the
  new content lands. for relocation: SOURCE chapter:beat →
  TARGET chapter:position}
SCOPE: {word budget — additive insertions capped at ~1,500 words}
INTENT: {what the new/moved content must accomplish}
SETUP ANCHORS: {chapter:line citations of the existing setup this
  content pays off — MUST already exist in the manuscript; if
  there is no existing setup, the finding is CREATIVE-OPEN, not
  bounded}
PAYOFF/CONTINUITY CONSTRAINTS: {facts the content must not
  contradict — character knowledge, timeline, Story Bible canon}
RE-VERIFY DOMAINS: {which canon-validation domains the loop must
  re-run after applying — e.g. CHARACTER, PHYSICS, COHERENCE}
SOURCE FINDINGS: {persona finding(s) + §2 pattern this addresses}
```

The synthesis capstone SPECIFIES the bounded operation; it does
NOT draft the prose. The revision loop's Tier-2 executor drafts
the content, presents it behind the human-confirm gate, applies
on confirmation, and re-verifies (see `revision-loop.md` § Tier-2
Developmental Executor).

### 5c. CREATIVE-OPEN decisions → escalated to the author

Findings that require author judgment and MUST NOT be auto-applied
at any autonomy level: ending alternatives, character-arc
direction, POV changes, subplot add/remove, thematic emphasis,
world-building rule changes, and every §1 Productive Conflict
(which is by definition a decision the author owns). Emitted one
block per decision:

```
TIER: CREATIVE-OPEN
DECISION: {the choice the author faces, one sentence}
FRAMING: {the productive-conflict or pattern framing from §1/§2}
OPTIONS: {the distinct directions, each with its trade-off}
SYNTHESIS RECOMMENDATION: {which way the balance leans, or
  explicit coin-toss}
WHY HUMAN: {why this cannot be auto-applied}
SOURCE FINDINGS: {persona finding(s) this came from}
```

## Drop log (if any)

Findings the self-verification spot-check dropped because cited
passages could not be located verbatim. Listed for transparency;
not part of the synthesis itself.
```

## What this does NOT do

- Does **not** replace or modify any per-persona report. The
  five reaction reports remain authoritative.
- Does **not** replace the consolidated dedup report. Both
  coexist; the synthesis is additive.
- Does **not** run automatically. Opt-in only — post-panel
  offer or user-invoked.
- Does **not** dispatch its own subagents. It reasons across
  the existing panel's outputs in a single parent context.
- Does **not** itself rewrite or apply anything. It produces the
  reasoned analysis (§1-§4) AND the machine-consumable routing
  plan (§5) that classifies each finding by autonomy tier. The
  APPLICATION is done downstream: SURGICAL fixes by
  `revision-loop.md` / `surgical-fixes.md`; DEVELOPMENTAL-BOUNDED
  fixes by the revision loop's Tier-2 gated executor (which
  drafts the content behind a human-confirm checkpoint);
  CREATIVE-OPEN decisions by the author. The capstone is the
  diagnosis-and-routing layer, not the application layer. (This
  corrects the earlier framing that implied Stage 8 Apply-Top-
  Fixes alone could action these findings — Stage 8 is surgical-
  only and structurally cannot perform the developmental tier.)
- Does **not** re-read the manuscript looking for NEW findings
  the panel missed. It synthesises ACROSS the panel's findings
  against the manuscript. If the panel missed something
  entirely, the capstone won't catch it — that's a panel design
  question, not a synthesis question.
- Does **not** apply to NF projects. The NF Beta Reader uses
  per-project domain-expert personas (different inputs,
  different reasoning); a NF synthesis capstone would require
  its own spec. Out of scope for v2.7.104; may follow in a
  future release.
- Does **not** apply to screenplays. Stage 6 Screenplay Redirect
  routes screenplays to Script Coverage Pass 2 instead of the
  Beta Reader Panel, so there is no five-persona output for
  the capstone to synthesise.

## Non-fiction analogue

Not in scope for v2.7.104. The NF Beta Reader Panel is per-
project variable-N domain-expert personas (office-furniture
historian for a book on the office, etc.) — different inputs,
different consensus shapes, different cross-lens reasoning
needs. A NF synthesis capstone is plausible but requires its
own design, grounded in NF panel runs the way this spec is
grounded in the Synthiate fiction panel run.

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification
binding are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (5 persona reports) | "Read succeeded with N bytes" | One report missing or empty → synthesis fabricates the missing persona's perspective | `read-verification.md` HARD GATE per file at step 2; if any persona report fails verification, capstone halts with "Panel incomplete: cannot synthesise from 4/5 reports". Does NOT proceed with degraded input. |
| Read (chapter files) | "Read succeeded with N bytes" | Truncated / empty chapter → manuscript-evidence assertions cite nonexistent passages | `read-verification.md` HARD GATE per chapter at step 3; chapter modification timestamps compared to panel-run timestamps; stale-panel synthesis surfaced explicitly to user |
| Read (Story Bible) | "Read succeeded" | Empty or missing character/audience sections → synthesis loses the context personas implicitly assumed | Read-Verification at step 4; if Story Bible sections missing, capstone halts and prompts user to confirm proceeding without bible context |
| Context Budget Gate | "GLOBAL-ELIGIBLE" | Slot silently downsized; manuscript loaded as summary rather than full text | `context-budget-gate.md` fail-closed contract; gate returns explicit verdict (GLOBAL-ELIGIBLE / INELIGIBLE / GATE_UNAVAILABLE); capstone proceeds only on GLOBAL-ELIGIBLE; never proceeds with summarised manuscript |
| Cross-lens synthesis reasoning | "Synthesis identifies real patterns" | Hallucinated patterns / false consensus / confabulated whole-book observations / cited persona passages that don't exist verbatim | (a) Every finding cites ≥2 source-persona claims by file + section. (b) Every manuscript-evidence assertion cites chapter + exact extracted text. (c) Mandatory self-verification spot-check at step 7: re-read at least one cited passage per output section; drop unverifiable findings to the Drop Log. (d) Subagent-output-verification.md does NOT apply (capstone is parent-context, not subagent dispatch) — the citation discipline + spot-check is the equivalent verification net. |
| Revision routing classification (§5) | "Finding routed to tier X" | A CREATIVE-OPEN finding mis-routed as DEVELOPMENTAL-BOUNDED → the gated executor drafts content for a change that actually needs author judgment (e.g. an arc change dressed up as an additive scene) | Two structural guards: (a) every DEVELOPMENTAL-BOUNDED block MUST cite a SETUP ANCHOR (chapter:line) that already exists in the manuscript — no anchor forces re-route to CREATIVE-OPEN; (b) the OPERATION field is constrained to exactly two values (additive-insertion, beat-relocation) — anything requiring rewrite of existing prose is CREATIVE-OPEN by definition. The Tier-2 executor's human-confirm gate (`revision-loop.md`) is the final backstop before any developmental change lands. |
| Metadata-consistency resolution (step 5b) | "Metadata divergence found, value X is correct" | The synthesis picks which of two conflicting authorial-fact values (volume count, canonical character name) is right and silently "corrects" it — propagating a guess | The scan REPORTS the divergence with each source's verbatim value + location and routes authorial-fact divergences to §5c CREATIVE-OPEN; the synthesis NEVER selects the correct value — author confirmation is mandatory. Only a mechanical name-spelling typo routes to §5a. |
| Write (synthesis report) | "Write succeeded" | Subdir flush failure leaves partial report | File-Write Hygiene per `core-pipeline.md` — Edit/Write tool only, never bash cat-and-mv; PostToolUse Engine-Data Integrity Hook re-verifies the artifact on disk |
| docx render | "Render succeeded" | Empty docx / truncated content / formatting drift | Standard `.docx` delivery convention used by Beta Reader Panel (v2.7.103); render verified by python-docx round-trip discipline per `tracked-changes.md` Phase A→C; same verification applied. |

## Routing

- `editorial-suite.md` Stage 6 — Synthesis Capstone (optional)
  block at end of stage pointing at this spec
- `context-budget-gate.md` — the fail-closed gate this capstone
  registers against (second consumer after
  `arc-completion-capstone.md`)
- `read-verification.md` — HARD GATE applied to every Read
  (persona reports, chapter files, Story Bible)
- `beta-reader-personas.md` — the v2.7.103 panel spec whose
  output this capstone synthesises
- `arc-completion-capstone.md` — sibling capstone spec; same
  architectural pattern (parent-context, gate-bound, fail-closed)
- `revision-loop.md` — consumes §5 Revision Routing: SURGICAL
  fixes drive its surgical loop; DEVELOPMENTAL-BOUNDED fixes
  drive its Tier-2 gated executor; CREATIVE-OPEN decisions are
  surfaced in its deferred-to-human list
- `surgical-fixes.md` — the protocol the §5a SURGICAL blocks are
  shaped for (EXACT QUOTE / PROBLEM / FIX / REASON)
- `core-pipeline.md` File-Write Hygiene + File-Freshness Post-
  Write Discipline — applied to the synthesis report write
- `tracked-changes.md` Phase A→C — applied to the docx render
