---
name: market-scout-protocol
description: "Live market intelligence implementation — genre trends, bestseller analysis, trope momentum, comp titles, and strategic positioning via web search. Implementation behind market-scout.md / Industry Scout. All WebSearch + WebFetch operations bound to web-content-verification.md HARD GATE."
version: "2.7.98"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Market Scout — Engine Skill

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/engine-data/market-pulse.md`

The Market Scout protocol's report MUST be written to the
canonical project's `engine-data/` subfolder, NOT to the
parent `~/Documents/Ideorix-Projects/` folder, the agent's
working directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline.
**HARD GATE — BLOCKING.**

## Purpose

Market Scout provides live market intelligence for any genre by searching the web
for current bestseller data, reader community discussions, trending tropes, and
competitive landscape analysis. It produces a structured Market Scout Report that
informs decisions across the pipeline.

## When to Use

Market Scout is loaded on demand by other skills. It runs in these contexts:

| Context | Triggered By | Purpose |
|---------|-------------|---------|
| `setup` | Outline Builder (Q9, Step 2) OR Pre-Phase 2 (if Outline Builder was skipped) | Inform outline/Story Bible with trending tropes, reader expectations, market gaps |
| `clinic` | Manuscript Clinic (Market Viability axis) | Position an existing manuscript within its competitive landscape |
| `cover` | Cover Designer (Phase 1) | Identify current bestseller cover trends, visual language, what's dated |
| `marketing` | Marketing Expert (Phase 1) | Marketing copy trends, hooks that convert, keywords, audience targeting |
| `trailer` | Video Trailer Designer (Phase 1) | Video marketing trends, BookTok strategies, trailer styles driving engagement |

## Trigger Phrases

Activate when:
- Another skill loads this file for market research
- The user explicitly asks for market research, market analysis, or genre trends
- The user says "what's selling", "market scout", "genre demand", or "comp titles"

---

## Inputs

**Required:**
- `genre` — The genre ID (e.g., "cozy-mystery", "romantasy", "thriller")

**Optional:**
- `context` — One of: "setup", "clinic", "cover", "marketing", "trailer" (defaults to "setup")
- `manuscript_title` — If positioning a specific manuscript (clinic context)
- `subgenre` — Narrow the search to a specific subgenre if known

---

## Market Research Protocol

### Phase 1: Live Web Search

**MANDATORY web-fetch verification.** Every WebSearch result and every
WebFetch of an article body MUST be gated by `web-content-verification.md`
Check 1 (paywall-stub regex) and Check 2 (≥2 KB byte threshold + retry-and-
distinguish). A 200 OK that returns a paywall stub ("Subscribe to read",
soft-404, redirect to a login page) is the dominant failure mode for the
trade-press surface (Variety / Deadline / The Hollywood Reporter / The
Black List) and the wider book-trade press. Treating a stub as the article
body produces fabricated "what studios are buying" / "what's selling"
findings — the silent-failure class this binding exists to prevent.

On verification failure for any source, record the source as
`NEEDS_HUMAN_REVIEW` in the report and do NOT carry its content into the
Phase 2 analysis. Never auto-synthesize a market claim from a content-
verification failure.

**Screen mode** (Industry Scout, invoked from the Screen Studio menu) uses
an industry-focused source set: The Black List, Variety, Deadline, The
Hollywood Reporter, IMDb Pro, Studio System, Coverfly. The same binding
applies.

Run 3–5 targeted web searches for the genre's current market. Searches should cover:

1. **Current bestsellers** — "[genre] bestselling books [current year]" and "[genre] bestselling books [last year]"
2. **Reader community discussions** — "[genre] readers want 2025 2026 reddit goodreads" or "[genre] BookTok trending"
3. **Trending tropes and themes** — "[genre] popular tropes trending [current year]"
4. **Recent notable releases** — "best new [genre] books [current year]"
5. **Market dynamics** — "[genre] book market demand competition [current year]"

Adapt search queries to the context:
- `cover` context: Add "cover design trends", "bestseller covers [genre]"
- `marketing` context: Add "book marketing [genre]", "Amazon description trends"
- `trailer` context: Add "book trailer trends", "BookTok book promotion"
- `clinic` context: Add "reader complaints [genre]", "what readers want [genre]"

### Phase 2: Structured Analysis

Analyse the search results (combined with genre bank data from the relevant genre file in `genres/`)
into a structured Market Scout Report:

**1. Demand vs. Saturation** (3–5 sub-niches):

For each sub-niche within the genre, assess:
- Demand level: High / Medium / Low
- Saturation: High / Medium / Low
- Opportunity: Strong / Moderate / Weak

Focus on gaps where demand outstrips supply — these are the positioning goldmines.

**2. Trending Tropes** (4–6 tropes with momentum):

For each trope:
- Direction: Rising / Peaking / Declining
- Evidence: Brief example of recent book(s) using it
- Relevance: How it connects to the user's genre/subgenre

This section directly informs trope selection (Q5) when used in setup context.

**3. Emerging Themes** (3–4 themes):

Fresh angles gaining traction. For each:
- What the theme is
- Why it resonates now (cultural moment, reader fatigue with alternatives, etc.)
- How to incorporate it without being derivative

**4. Reader Expectations**:
- *Must-have elements* — Non-negotiable for the genre (readers will DNF without these)
- *Fresh opportunities* — Ways to differentiate within the genre
- *Overdone elements* — What to avoid (tropes, openers, character types that readers
  are tired of seeing)

**5. Comp Titles** (3–5 current bestsellers):

For each comp title:
- Title, author, approximate release date
- Why it's relevant (similar tropes, audience, positioning)
- What it does well that the user can learn from
- What gap it leaves that the user could fill

**6. Price Point Guidance**:
- Optimal price range for the genre and format (ebook, paperback, hardcover)
- Series pricing strategy (if applicable — first-in-series pricing, box sets)
- KU (Kindle Unlimited) vs wide distribution recommendation for the genre

**7. Strategic Positioning** (1 paragraph):

Concise, actionable advice for an author entering this genre right now. What
specific angle, trope combination, or approach would give them the best shot at
standing out?

---

## Context-Specific Output Adapters

After generating the full report, emphasise different sections based on context:

### Setup Context
**Emphasise:** Trending Tropes, Reader Expectations, Demand vs. Saturation
**De-emphasise:** Price Point, Comp Titles (keep but shorten)
**Additional output:** Present trending tropes as selectable options that can feed
into Q5 (Trope Selection). Ask: "Which of these market insights should we build
into your outline? Pick any that resonate."
Use AskUserQuestion with multiSelect: true.

### Clinic Context
**Emphasise:** Comp Titles, Strategic Positioning, Reader Expectations (overdone elements)
**Additional output:** Position the user's manuscript within the competitive landscape.
What makes it stand out? What's its closest comp? Where does it need differentiation?

### Cover Context
**Emphasise:** Comp Titles (focus on their cover designs), Demand vs. Saturation
**Additional output:** Current bestseller cover trends — dominant colours, typography
styles, imagery types, what's dated. Feed findings into Cover Designer Phase 2.

### Marketing Context
**Emphasise:** Reader Expectations (must-haves for copy), Comp Titles (for positioning),
Price Point
**Additional output:** Keywords and phrases that resonate with readers in this genre.
Hooks and emotional triggers that convert browsers to buyers.

### Trailer Context
**Emphasise:** Comp Titles (look for video trailers), Emerging Themes
**Additional output:** Current book trailer trends on BookTok and YouTube. What visual
styles, music choices, and pacing patterns are driving engagement?

---

## Output

### Report File

Save the full Market Scout Report to:
`Ideorix-Projects/[Title]/engine-data/market-pulse.md`

### Report Format

```markdown
# Market Scout Report — {Genre}
Generated: {date}
Context: {context}

## Demand vs. Saturation
| Sub-niche | Demand | Saturation | Opportunity |
|-----------|--------|------------|-------------|
| {name}    | {H/M/L}| {H/M/L}   | {S/M/W}     |

## Trending Tropes
1. **{Trope Name}** — {Rising/Peaking/Declining}
   Evidence: {example}

## Emerging Themes
1. **{Theme}** — {why it resonates}

## Reader Expectations
**Must-haves:** {list}
**Fresh opportunities:** {list}
**Overdone:** {list}

## Comp Titles
1. **{Title}** by {Author} ({year})
   - Relevance: {why}
   - Strength: {what it does well}
   - Gap: {what it leaves open}

## Price Point Guidance
- Ebook: {range}
- Paperback: {range}
- KU recommendation: {yes/no + reasoning}

## Strategic Positioning
{paragraph}
```

---

## Fallback Protocol

If web search is unavailable or fails:

1. Note the failure explicitly: "Market Scout: Live web search unavailable. Falling
   back to static genre data."
2. Use the genre bank file's reader expectations, quality check criteria, and
   genre-specific craft techniques as a substitute data source
3. Still produce the report structure, but mark sections as "Based on static genre
   data — not live market research"
4. Do NOT fabricate market data, bestseller lists, or trending tropes. If you don't
   have live data, say so.

---

## Relationship to Other Engine Files

| Engine File | Relationship |
|-------------|-------------|
| `outline-builder.md` | Market Scout runs at Step 2 (Market Pulse Research) — feeds trending tropes and reader expectations into outline choices |
| `manuscript-clinic.md` | Market Scout runs when Market Viability is selected — provides competitive landscape for manuscript positioning |
| `cover-designer.md` | Market Scout runs at Phase 1 — provides current bestseller cover trends |
| `marketing-expert.md` | Market Scout runs at Phase 1 — provides marketing copy trends and reader psychology |
| `video-trailer-designer.md` | Market Scout runs at Phase 1 — provides video marketing trends |
| `trope-library.md` | Trending tropes from Market Scout supplement the static trope library during setup |
| `core-pipeline.md` | Market Scout is a Tier 2 skill loaded on demand |

---

## Quality Criteria

### Accuracy
- All market claims must be sourced from web search results
- Do not hallucinate bestseller lists, sales figures, or trend data
- If a claim cannot be verified, mark it as "anecdotal" or "estimated"

### Actionability
- Every section must contain information the user can act on
- Avoid vague advice ("write a good book") — be specific ("readers in this genre
  are currently responding to dual-timeline narratives with unreliable narrators")

### Recency
- Prioritise data from the current year and last year
- Flag any data older than 2 years as potentially outdated
- BookTok and reader community trends move fast — emphasise the most recent signals

### Honesty
- If the market is saturated, say so
- If the genre is niche with limited data, acknowledge the limitation
- Do not oversell opportunities — an honest assessment serves the author better

---

## Screen Mode (Industry Scout)

When invoked from Screen Studio (item 11: Industry Scout)
or via screen-coded triggers ("industry scout", "what's
selling in TV / film", "what are studios buying",
"Black List", "Variety", "Deadline"), the agent runs in
Screen Mode. The protocol logic stays the same; the
SOURCE SET, COMP TITLES, and OUTPUT ADAPTER change to
the screen-industry domain.

### Detection

```
if invoked from Screen Studio menu OR
   trigger phrase contains screen-industry keywords OR
   project-config.md → Mode == "Screen Studio":
    activate Screen Mode (this section)
else:
    activate Book Mode (default protocol above)
```

### Screen-Mode Source Set

Replace book-market sources (Amazon, Goodreads, KDP,
BookBub, NetGalley) with screen-industry sources:

#### Tier 1: Industry Trade Publications
- **Variety** (variety.com): production deals, talent
  packages, studio strategy, box office, streaming
  performance, executive moves
- **Deadline** (deadline.com): breaking deal news, spec
  sales, pilot orders, casting announcements, picked-up
  / cancelled / renewed series
- **The Hollywood Reporter** (hollywoodreporter.com):
  coverage, executive interviews, awards-season
  intelligence
- **IndieWire** (indiewire.com): independent film
  signals, festival circuits, awards-darling tracking
- **Screen Daily** (screendaily.com): UK / international
  industry signal
- **The Wrap** (thewrap.com): consolidated entertainment
  industry coverage

#### Tier 2: Spec Tracking + Development Intelligence
- **The Black List** (blcklst.com): annual best
  unproduced screenplays list; the genre's positioning
  benchmark; reads for spec-script trends
- **Tracking Board** (tracking-board.com): spec sales
  tracking, agency packaging, in-development projects
- **Production Weekly** (productionweekly.com):
  current production landscape, upcoming projects
- **It's On The Grid** (itsonthegrid.com): agency
  representation tracking
- **Spec Scout** / similar spec-focused sites: trending
  scripts, query patterns

#### Tier 3: Streaming Platform Signals
- **Netflix Top 10** (top10.netflix.com): weekly
  performance data; reads for what's resonating with
  global subscribers
- **Nielsen streaming reports**: cross-platform
  performance benchmarks
- **Parrot Analytics** / similar demand-tracking:
  audience-demand intelligence
- **JustWatch** trends: cross-platform availability and
  popularity tracking
- **Tudum / Netflix newsroom**: Netflix commissioning
  signals
- **Apple TV+ press / Amazon Studios press / Max press
  / Disney+ press / Hulu press / Peacock press**:
  platform-specific commissioning patterns

#### Tier 4: Festival + Awards Circuit Signal
- **Sundance / Cannes / TIFF / SXSW / Tribeca /
  Venice / Berlin / Telluride**: festival selections,
  audience-award winners, distribution acquisitions
- **Academy / WGA / DGA / PGA / SAG-AFTRA awards
  trackers**: what the industry is rewarding
- **Cannes / TIFF market reports**: distribution deals
  and territory pickups

#### Tier 5: WGA Production + Strike Intelligence
- **WGA West / East**: production tier reports, MBA
  framework intelligence (post-2023 strike landscape
  matters: minimum guarantees, AI clauses, residual
  structures)
- **WGA-signatory tracking**: which studios / mini-
  majors / streamers are signatory (affects spec
  submission strategy)

#### Tier 6: Audience + Demand Intelligence
- **Letterboxd** trends and ratings (film audience
  signal — strong indicator for indie / arthouse /
  genre-passionate demographics)
- **Reddit r/movies / r/television / r/Screenwriting
  / r/TrueFilm / r/PopCultureChat**: organic audience
  conversation
- **TikTok #FilmTok / #ScreenwritingTok / #MovieTok**:
  viral movie / TV moments and audience signal
- **YouTube long-form film / TV criticism channels**
  (Lessons from the Screenplay, NerdWriter1, Every
  Frame a Painting, etc.): treatment of craft
  benchmarks

### Screen-Mode Comp-Title Logic

Replace book comp titles with screen comp titles. The
Comp Titles section of the report should produce:

```
## Comp Titles (Screen)

### Recent Comparable Projects (last 3-5 years)
- *{Title}* ({Year}) — {Format: feature/series/limited}
  — {Distributor/Network/Streamer}
  Why comparable: {logline parallel, tone parallel,
  audience parallel, scale parallel}
  Performance signal: {box office / streaming
  performance / awards / critical reception}

### Historical Anchors (foundational comps from any era)
- *{Title}* ({Year}) — {Format} — {Studio}
  Genre-defining for: {what this comp set the
  template for}

### "X meets Y" Pitch Template (industry-standard)
- "{Title} meets {Title} with {distinctive twist}"
  Example: "Knives Out meets Succession with a
  near-future AI heir-apparent twist."

### Cross-format reference points (where applicable)
- Adapted from / spawned: novel, play, podcast,
  short film, video game, real event, IP universe
- Audience overlap with: comparable shows / films
  the same audience would queue alongside
```

The "X meets Y" pitch is industry-standard for
screen development and MUST appear in every Screen
Mode report — it is how decks, packages, and pitch
meetings communicate.

### Screen-Mode Audience + Performance Adapters

Replace book-audience adapters with screen-audience:

```
## Audience (Screen)

### Demographic primary
- Age band (18-34 / 25-54 / 35-64 / 50+)
- Gender skew (if signal exists)
- Education / income (if signal exists for arthouse vs
  mass-market positioning)

### Streaming-platform fit
Which streamer's audience matches the project? Match
specific platform commissioning patterns to the
project's logline/tone:
- Netflix global / Netflix US / Netflix non-English
- Apple TV+ (prestige + originals + tech-adjacent)
- Max (HBO prestige / WB-Discovery library)
- Hulu (FX synergy / prestige drama)
- Amazon (genre-friendly + prestige + IP-leveraged)
- Peacock (NBCU library + sports + comedy-leaning)
- Disney+ (Disney/Marvel/Star Wars/Pixar IP)
- Paramount+ (CBS franchise + prestige)
- A24 (theatrical + indie auteurs)
- Neon / IFC / Magnolia / Searchlight (theatrical +
  indie distribution)

### Theatrical fit (if feature)
- Wide-release commercial (multiplex)
- Specialty (arthouse / awards-pivot)
- Festival-launch + acquisition strategy
- Direct-to-streaming (no theatrical window)

### Festival circuit fit (if applicable)
Which festival(s) match the project? Sundance /
Cannes (Compétition / Un Certain Regard / Quinzaine /
ACID / Critics' Week) / TIFF / SXSW / Tribeca / Venice
/ Telluride / Toronto / Berlinale / Sitges (genre) /
Fantastic Fest (genre) / SCAD Savannah Film / etc.
```

### Screen-Mode Strategic Positioning

Replace book-market positioning with screen-industry:

```
## Strategic Positioning (Screen)

### Spec script vs commission landscape
- Is this format / budget tier currently buying spec
  scripts? (specs sell more in feature than in TV;
  TV requires open writer's room or showrunner-
  attached package)
- Is the project's logline a "package play"
  (attach director / star first, sell as
  package) or a "spec play" (sell on script
  alone)?

### Studio / streamer commissioning fit
Match the project's tone, genre, scale, and audience
to current commissioning patterns:
- Genre + scale combinations currently being bought
- Genre + scale combinations that are oversaturated
  / on cooldown
- Specific buyer ladder (which studio/streamer
  development executives would be the natural reads)

### Budget tier signal
- Micro (<$1M): festival / indie / streaming-direct
- Low ($1-5M): indie + first-look / specialty
- Mid ($5-30M): theatrical specialty + streaming
- Studio ($30-100M): mid-budget studio
- Tentpole ($100M+): franchise / IP-driven

### Strike landscape (post-2023 reality)
- AI clauses and protections (current MBA framework)
- Minimum guarantees by tier
- Residual structures (especially streaming residuals)
- Open Writers' Room intelligence (which studios /
  streamers are staffing rooms now)
- Foreign-shooting tax incentive landscape
  (Atlanta / New Mexico / UK / Ireland / Hungary
  / Australia)
```

### Screen-Mode Output Template

Replace the book-mode output template with:

```
# Industry Scout Report — {Logline / Title}

## Format & Genre
{Feature / TV pilot half-hour / TV pilot hour / Limited
series / Short — Genre / sub-genre}

## Logline
{1-2 sentence pitch for this project}

## Industry Demand Signal
{Is this format / genre being bought right now? Specific
recent deals, package activity, commissioning patterns.}

## Comp Titles (Screen)
{Per Screen-Mode Comp-Title Logic above — recent +
historical + "X meets Y" + cross-format reference}

## Audience (Screen)
{Per Screen-Mode Audience adapter above — demographic +
streaming-platform fit + theatrical fit + festival fit}

## Strategic Positioning (Screen)
{Per Screen-Mode Strategic Positioning above — spec vs
commission + buyer ladder + budget tier + strike
landscape}

## Comparable Recent Deals (last 12 months)
{Specific named deals with format, buyer, package
attachment, and reported price tier where public}

## Source Citations
{All sources from the Screen-Mode tier set, with
publication date — flag anything older than 18 months}
```

### Screen-Mode Anti-Patterns

- Do NOT apply book-market positioning logic to a
  screenplay project (genres don't map directly —
  "cozy mystery" book audience differs significantly
  from "cozy mystery" TV audience)
- Do NOT cite KDP / Amazon / BookBub as sources for a
  screenplay positioning report
- Do NOT skip the "X meets Y" pitch template — this is
  industry-standard for screen development
- Do NOT cite outdated pre-2023-strike intelligence
  without flagging the strike landscape (residuals,
  AI clauses, MBA changed materially)
- Do NOT conflate "the show is on Netflix" with
  "Netflix produced it" — distribution and production
  are different signals
- Do NOT ignore festival circuit for indie / arthouse
  features (festival launch is often the entire
  strategic positioning for that tier)
- Do NOT recommend WGA-signatory submission strategy
  for projects targeting non-signatory buyers without
  flagging the residual / minimum-guarantee implications

## Silent-Failure Audit

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| WebSearch (Phase 1) | "Search returned N results" | Stale/cached / SEO-spam / empty results reported as a successful search | Results treated as a candidate list, never a verified-fact source; followed up by WebFetch + Check 1/2 below before content is used |
| WebFetch (Phase 1 article body) | "200 OK with N bytes" | Paywall stub / soft-404 / redirect-to-login returning a 200 with a "Subscribe to read" body — dominant failure mode for the trade-press surface | `web-content-verification.md` Check 1 (paywall-stub regex) + Check 2 (≥2KB byte threshold + retry-and-distinguish) applied at the Phase 1 fetch step. On verification failure: record source as `NEEDS_HUMAN_REVIEW`, exclude from Phase 2 analysis |
| Write (Market Scout report) | "Write succeeded" | Subdir flush failure / partial write | File-Write Hygiene bash-direct write protocol per `core-pipeline.md`; report written to `engine-data/reports/` so the PostToolUse Engine-Data Integrity Hook re-verifies the artifact |
