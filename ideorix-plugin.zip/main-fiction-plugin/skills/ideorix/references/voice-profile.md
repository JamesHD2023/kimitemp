---
name: voice-profile
description: "Canonical template + protocol for engine-data/voice-profile.md — the calibration artifact that anchors POV-narrator voice consistency across a fiction manuscript. Read by voice-metrics-audit.sh, voice-trend-audit.sh, and the voice-profile-preload-gate. Without this file populated, the writer has no reference voice to reproduce and drift becomes invisible until a reader catches it."
version: "2.7.65"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Voice Profile — Fiction

The voice-profile.md is the **calibration corpus** for narrator
voice across the manuscript. The writer reproduces a voice; the
audit pipeline measures whether the reproduction held; the trend
audit fires when the measurements drift away from this profile.
Without the profile, all three pieces are guessing.

## Why this artifact exists

Voice drift is a well-documented failure mode in long-form fiction:
a first-person narrator gradually slides into third-person
omniscient summary; a tight close-third POV widens into head-
hopping; a distinctive register (working-class, regional, period)
flattens into generic literary prose. Across many chapters the
drift may never trigger any single-chapter alarm — but the
cumulative effect breaks the reader's contract with the narrator.

The voice-profile.md gives the writer a concrete reference voice to
reproduce AND gives the audits a target to measure against. The
voice-profile-preload-gate.sh runs as part of pre-flight and blocks
chapter generation when the profile is missing or skeleton-only.

## Required file structure

The profile lives at `engine-data/voice-profile.md`. Minimum viable
content (all five keys required):

```markdown
# Voice Profile

fp_target: <float, 0.0-1.0>
sentence_band_min: <int, minimum acceptable median sentence length>
sentence_band_max: <int, maximum acceptable median sentence length>

voice_calibration_exemplar: <relative path to exemplar chapter 1>
voice_calibration_exemplar: <relative path to exemplar chapter 2>
voice_calibration_exemplar: <relative path to exemplar chapter 3>

voice_prose_description: <2-4 sentences describing the narrator's
register — POV, distance, distinctive markers, what the writer
must not collapse into>
```

Recommended additional sections:

```markdown
## Voice-Avoid List

Chapters that exhibit drift and should NOT be used as exemplars.

voice_calibration_avoid: <relative path to drifted chapter 1>

## Anchor Voice Markers

Specific phrases / cadences / verbal tics that define the narrator.
Read before generating each chapter so the register stays consistent
at the sentence level.

- <phrase or cadence 1>
- <phrase or cadence 2>
```

## Field guide

### `fp_target`

The target first-person paragraph ratio. A paragraph is "first-
person" if it contains any of `I, me, my, mine, myself, we, us,
our, ours, ourselves` as a standalone word.

Calibration ranges by POV:

| POV                              | Typical fp_target |
|----------------------------------|-------------------|
| First-person (single narrator)   | 0.50–0.80         |
| First-person (multiple narrators)| 0.40–0.70         |
| Close third (deep POV)           | 0.05–0.15         |
| Third limited                    | 0.02–0.10         |
| Third omniscient                 | 0.00–0.05         |
| Epistolary / mixed-form          | 0.30–0.70         |

If you don't know yet, run voice-metrics-audit.sh on three
non-drifted exemplar chapters and average the FP ratios. That
empirical baseline is your `fp_target`.

For multi-POV novels: set `fp_target` to the average across POVs,
and document the per-POV expectation in `voice_prose_description`.
A future enhancement may add per-POV targets; for now, the global
target plus prose-level discipline carries the load.

### `sentence_band_min` / `sentence_band_max`

The acceptable median sentence-length band. Default 13–19 for
literary prose; tightens to 10–15 for short-sentence styles
(noir, hard-boiled, action); widens to 16–22 for longer-cadence
literary fiction. Set whatever matches the exemplar chapters'
actual measurements.

### `voice_calibration_exemplar`

The most important field. At least one path is required; three is
the recommended floor. Each path points to a chapter (or excerpt
file) where the narrator voice was demonstrably correct — not
drifted, not over-corrected.

Picking exemplars:

- **Span the manuscript**: one early chapter, one mid, one late.
- **Avoid first chapters**: those tend to be exposition-heavy and
  not voice-representative.
- **Prefer chapters where the audit metrics matched target**: pull
  voice-metrics-ledger.md and pick rows where fp_ratio + sentence
  median both landed in-band.
- **For multi-POV novels**: pick at least one exemplar per POV
  character so the writer can re-anchor on the correct voice when
  switching POVs.
- **If no chapter is exemplar-quality, write a 500-1500 word
  excerpt that IS, and use that as the exemplar**. The exemplar
  format is identical to a chapter file.

### `voice_prose_description`

A short prose description naming what the voice IS and what it is
NOT. Two to four sentences. Examples:

> "Close-third POV anchored on Maya. The reader is inside Maya's
> head — what she notices, what she chooses not to name, the
> rhythm of her observation. Sentences run mid-length with short
> beats when emotion lands. The writer must NOT slip into
> omniscient summary or other-character interiority. When the
> chapter needs a different character's view, switch chapters."

> "First-person Catalina narrator, 1957 New Orleans setting.
> Conversational, with an unreliable-narrator slant — Catalina
> tells the reader what she wants the reader to think. Period
> register (no anachronistic vocabulary), sentences medium-length,
> occasional one-word sentence beats for emphasis. The writer
> must NOT modernise the register or collapse into objective
> third-person."

### `voice_calibration_avoid` (optional)

When a manuscript has known-drifted chapters, list them explicitly
so the calibration corpus never accidentally pulls from them.

## How the audits use this file

- **voice-metrics-audit.sh** reads `fp_target`, `sentence_band_min`,
  `sentence_band_max` to set per-chapter classification thresholds.
- **voice-trend-audit.sh** reads `fp_target` to compute window-mean
  FAIL/WARN thresholds.
- **voice-profile-preload-gate.sh** (Pre-Flight Check 6) verifies
  the profile exists + is populated before chapter N+1 generation.

## When to revise the profile

Bump the `version:` in frontmatter and re-export when:

- The exemplar chapters change.
- The `fp_target` is revised (measure, don't guess).
- The prose description tightens.

Do NOT lower `fp_target` because chapters keep failing the audit.
That is the audit telling you the voice has drifted, not the
profile being too strict.

## Silent-Failure Audit

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (voice-profile.md) | "Read succeeded" | Skeleton file (empty headers, no fp_target) | voice-profile-preload-gate.sh structural check (FAIL on no fp_target / no exemplar / no prose-description) |
| Read (voice-metrics-ledger.md) | "Read succeeded" | Stale ledger (no recent chapters appended) | voice-trend-audit short-circuits to INFO until window-size rows exist |
| Write (voice-metrics-ledger.md append) | "Append succeeded" | Subdir flush failure on a new project | mkdir -p before append; lazy header on first write |
| LLM-Writer (chapter generation) | "Voice profile referenced" | Profile cited but voice not reproduced | voice-metrics-audit measures the produced chapter; voice-trend-audit catches sustained divergence; profile preload makes the reference verifiable not just claimed |
