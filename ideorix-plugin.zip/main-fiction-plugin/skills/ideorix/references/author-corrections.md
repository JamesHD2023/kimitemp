---
name: author-corrections
description: Append-only register of corrections the user has issued during sessions. The orchestrator logs each detected correction in a structured format; a deterministic script scans for repeated corrections (3+ occurrences of the same fix) and surfaces them as canon-promotion candidates for user review. Solves the cross-session memory gap where in-chat corrections vanish when the session ends. Engine-agnostic — mirrored across fiction and nonfiction engines.
version: 2.7.74
---

<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Author Corrections Register

> **Powered by Ideorix** — The Manuscript Engine
> *© James Harvey Media. All rights reserved.*

## Purpose

In normal session work users issue corrections inline: "no, his name is
Mira", "actually she has green eyes not blue", "we agreed she's 23, not
24." These corrections vanish when the chat ends. The next session
starts fresh and may reintroduce the same error.

The author corrections register makes these durable. Each detected
correction is appended to a per-project log; a deterministic promotion
script surfaces corrections seen 3+ times as candidates for permanent
canon updates. The repetition threshold is the safety net: a single
correction might be a one-off; three is a pattern the engine has been
getting wrong and the user is tired of fixing.

## Architecture (three layers)

1. **Detection (orchestrator, LLM-side):**
   When the user issues a correction in chat, the orchestrator appends
   an entry to `engine-data/author-corrections.md` using the structured
   format below. Detection criteria are listed in the next section.

2. **The register (append-only file):**
   `engine-data/author-corrections.md` is the project's running log.
   New entries are appended; existing entries are never rewritten
   except to change `canon-status` from `not-yet-promoted` to
   `promoted` after a successful canon update. The file is the source
   of truth for what corrections have been observed.

3. **Promotion (script-enforced, deterministic):**
   `scripts/corrections-promotion-scan.sh` reads the register, groups
   entries by `(category, field, from, to)`, and reports any group with
   3+ occurrences where `canon-status: not-yet-promoted`. The user (or
   the orchestrator under user direction) updates the relevant canon
   file (`entity-canon.md`, `project-config.md`, `forbidden-words.md`,
   `story-bible.md`, or `research-bible.md` depending on category) and
   marks the corrections in the group as `canon-status: promoted`.

## What counts as a correction

A correction is a user statement that meets all three tests:

1. It **identifies an existing fact** the engine has produced or that
   currently lives in canon.
2. It **states the corrected version explicitly** ("X is actually Y").
3. It is **not a hypothetical, query, or new-content preference**.

Examples that QUALIFY:

| User statement | Logged entry |
|---|---|
| "No, her name is Mira not Mara." | `category: entity, field: name, from: "Mara", to: "Mira"` |
| "Actually she has green eyes, not blue." | `category: entity, field: appearance, from: "blue eyes", to: "green eyes"` |
| "We agreed she's 23, not 24." | `category: entity, field: age, from: "24", to: "23"` |
| "British spelling, not American." | `category: preference, field: spelling, from: "American", to: "British"` |
| "Don't use 'tapestry' as a metaphor." | `category: preference, field: avoid-word, from: "tapestry", to: "(avoid)"` |
| "She doesn't lie to Tabitha — that's a rule." | `category: constraint, field: behavior, from: "(none)", to: "Mira does not lie to Tabitha"` |
| "The disaster was 1948, not 1944." | `category: chronology, field: year, from: "1944", to: "1948"` |

Examples that DO NOT QUALIFY (don't log):

- "Let's change his name to Mira." → change of a deliberate decision,
  not a correction of an error
- "I'm not sure about her age — what did we say?" → query
- "I think I'd prefer auburn here." → preference for new content
- "Wait, didn't we decide she had green eyes?" → query

When in doubt, log it. The 3+ promotion threshold is the safety gate —
a false-positive entry sits in the log without harm and never gets
promoted unless it repeats.

## Categories (controlled vocabulary)

- `entity` — facts about a named character, place, or item (name, age,
  appearance, relationships, etc.)
- `preference` — author's stylistic preferences (spelling, word
  avoidances, formatting, register)
- `architectural` — POV, tense, narrative voice, structural
  commitments
- `constraint` — rules discovered in drafting ("Mira doesn't lie to
  Tabitha")
- `chronology` — timeline facts (year of event, sequence of events,
  age at moment in story)

The promotion script uses category to determine the target canon file:

| Category | Target canon |
|---|---|
| entity | `engine-data/entity-canon.md` |
| preference | `engine-data/project-config.md` or `engine-data/forbidden-words.md` |
| architectural | story bible §1–3 (fiction) / research bible §1–3 (NF) |
| constraint | story bible §3 (fiction) / research bible §3 (NF) |
| chronology | story bible §4 timeline (fiction) / research bible §4 (NF) |

## Register format

`engine-data/author-corrections.md` (append-only):

```markdown
# Author Corrections — {Project Title}

*Append-only log of user corrections issued during sessions. Format:
dated entries with category + field + from + to + context +
canon-status. The promotion script `corrections-promotion-scan.sh`
scans for repeated corrections (3+ occurrences in the same group)
and surfaces them as canon update candidates. This file is the
source of truth; the orchestrator appends entries when corrections
are detected and updates canon-status when promotions complete.*

## {ISO date} — Session {N}
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: chapter 7 dialogue review
- canon-status: not-yet-promoted

## {ISO date} — Session {N}
- category: preference
- field: avoid-word
- from: "tapestry"
- to: "(avoid)"
- context: ch9 metaphor flagged
- canon-status: not-yet-promoted
```

Every entry MUST have all six fields. `context` may be brief or empty
(use `""`); the other five are required for the promotion script to
group correctly.

Date format: ISO 8601 (`YYYY-MM-DD`). Session number is the project's
running session count (incremented per Claude work session); if
unknown, use `unknown`.

## Detection protocol (for the orchestrator)

When the user issues a correction during a session, the orchestrator
must:

1. Identify whether the statement meets all three correction tests
   (existing fact, explicit corrected version, not query/preference)
2. Determine category from the controlled vocabulary above
3. Determine field (name, age, appearance, spelling, etc.)
4. Extract `from` (the erroneous version) and `to` (the corrected
   version) as user-stated strings
5. Append an entry to `engine-data/author-corrections.md` using the
   format above, with `canon-status: not-yet-promoted`
6. Acknowledge the correction in chat and apply it to the current
   piece of work (current chapter, current paragraph, etc.) — the log
   is durable memory, NOT a replacement for in-the-moment correction

The append step uses the same same-FS-temp + post-write integrity
pattern as any other engine-data write (see core-pipeline.md File
Operation Policy).

## Promotion protocol (user-initiated or session-end)

The user (or the orchestrator at end-of-session) runs:

```bash
bash scripts/corrections-promotion-scan.sh {path}/engine-data/author-corrections.md
```

The script reports zero or more PROMOTION CANDIDATEs. Each candidate
lists:
- The grouped key (category, field, from, to)
- Number of occurrences in the group
- Sessions/contexts where the correction appeared
- The target canon file based on category

The user reviews each candidate and decides:
- **Promote** — update the target canon file with the correction, then
  edit `engine-data/author-corrections.md` to mark every entry in the
  group as `canon-status: promoted`
- **Defer** — leave the corrections as `not-yet-promoted`; the
  candidate will resurface on the next scan
- **Reject** — the correction was a one-off or misread; mark entries
  as `canon-status: rejected` so future scans skip them

Canon updates that result from promotion follow normal canon-update
discipline (e.g., entity-canon updates pass through canon-validation
sweep at next manuscript-scope verification).

## Limits and honest caveats

- **Detection is LLM-side.** The orchestrator may miss a correction
  (especially terse or ambiguous ones). The 3+ promotion threshold is
  the safety net — a missed first instance becomes a logged second
  instance, and the third triggers promotion review.
- **Promotion is gated by user review.** The script does not mutate
  canon files. It reports candidates; the user decides.
- **The register grows unboundedly.** For a typical book this is
  small (10–100 entries over a full manuscript). For very long
  projects, archive entries with `canon-status: promoted` to
  `engine-data/archives/author-corrections-archive-{date}.md`.
- **The append-only convention is by discipline.** If the orchestrator
  rewrites the file destructively the post-engine-data-write-hook
  (v2.7.73+) catches NULL/UTF-8 corruption but not unintended
  rewrites. Treat the file as append-only by spec.

## Related specs

- `entity-canon.md` — the canon file most `entity`-category
  corrections target
- `project-config.md` / `forbidden-words.md` — preference targets
- `session-log.md` — companion register for session-level events
  (distinct scope: session-log records what was decided/done; this
  spec records errors corrected)
- `core-pipeline.md` File Operation Policy — append protocol for
  engine-data writes
- `silent-failure-audit.md` row 65 (v2.7.73 reassessment) — the
  same-FS-temp + post-write integrity discipline that applies here

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification binding are
documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Bash append (`>>`) to engine-data file | "Append succeeded" | Bridge intermittency → NULL fill at target size | Post-engine-data-write-hook (v2.7.73+) runs chapter-integrity-check.sh on the file; FAIL surfaces immediately |
| LLM correction detection | "I detected a correction and logged it" | Missed correction (terse / ambiguous user phrasing) | 3+ promotion threshold — a missed first instance is captured on the second/third occurrence |
| Promotion script (`corrections-promotion-scan.sh`) | "Reported all groups with 3+ occurrences" | Group key mismatch (whitespace / quote variants) | Test fixture in `test/run-tests.sh` covers normalisation; script normalises via python3 dict grouping |
| Canon file update (user-driven post-promotion) | "Canon was updated with the corrected fact" | User forgets to mark `canon-status: promoted` → same candidate resurfaces | Re-surfacing on next scan is the intended behaviour, not a failure; the user re-reviews |
