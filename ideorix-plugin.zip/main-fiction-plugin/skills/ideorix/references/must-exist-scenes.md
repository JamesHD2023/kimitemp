---
name: must-exist-scenes
description: "Must-Exist Scenes Anchor protocol — Step 9.5 of the Outline Builder. Operationalises the user's specific scenes / images / character moments as the SEED for outline construction in Architect mode, replacing the prior structure-first-then-content pattern with scene-first-then-structure ordering. The architectural primitive that produces real books rather than 'greatest hits albums of canon moments with summary connecting them.'"
version: "2.7.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Must-Exist Scenes Anchor — Step 9.5 of the Outline Builder

## Purpose

Replace structure-first outline construction with scene-first
outline construction in Architect mode. This is the
v2.7.0 architectural rewire that addresses the deepest
diagnosis from a user-reported failure:

> "I keep starting from STRUCTURE (30 chapters, alternating
> POV, act math, canon samples placed at correct positions)
> and retrofitting story into it. Books don't work that way.
> Books start from specific images and specific character
> moments that must exist, and the structure is whatever
> accommodates them."

The user is correct. Books-as-actually-written work like:

1. Start with specific images / scenes / moments that MUST
   exist
2. Find the character truth those scenes reveal
3. Find the structure that delivers them with maximum
   impact
4. Plot is the pattern that connects the must-exist scenes

Engine-as-previously-built worked like:

1. Apply structural template (chapter count, act %s, beat
   structure)
2. Slot canon samples into structural positions
3. Fill connecting tissue with summary
4. Result: structure-with-canon-decoration, not story

Step 9.5 inverts this. In Architect mode, the outline is
constructed FROM the must-exist scenes outward. Genre
structure templates apply as accommodations to the
must-exist scenes, not as templates the scenes are slotted
into.

## When this step runs

Step 9.5 runs in **Architect mode only** (when Step 0 has
absorbed user-supplied canon and locked the constraints).
In Creator mode (no source material, engine originates
plot), Step 9.5 is skipped — the existing Step 10 structural-
template approach applies, which is appropriate when the
engine is inventing the story.

The trigger is the Architect mode flag set in
`engine-data/project-config.md` by Step 0:

```
architect_mode: true
```

When this flag is set, Step 9.5 runs between Step 9 (Genre-
Specific Architecture) and Step 10 (Detailed Chapter
Outline). When unset, Step 9.5 is skipped.

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/engine-data/must-exist-scenes.md`

The must-exist scenes anchor list is written to the
canonical project's `engine-data/` subfolder, NOT to the
parent Ideorix-Projects folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline.
**HARD GATE — BLOCKING.**

## Inputs to Step 9.5

The step reads:

1. **`source-canon/locked-scenes.md`** (or the equivalent
   user-supplied locked-scenes file in `source-canon/`) —
   scenes the user has explicitly committed to as
   must-exist
2. **`source-canon/samples/*`** — sample passages MAY
   include pre-written scenes the user wants in the
   manuscript; the agent identifies these vs. pure style
   samples
3. **`engine-data/research-bible.md` § 11 (or equivalent)**
   — any motif / theme / image the user has committed to
4. **The conversation history** — any scene description
   the user mentioned as "this has to happen" / "I want
   to see X" / "the book ends with Y"
5. **The user, interactively** — Step 9.5 explicitly asks:
   "What scenes / images / character moments MUST appear
   in this manuscript? List them in any order — we'll find
   the structure that delivers them."

## Step 9.5 Workflow

### Phase A: Collect must-exist scenes

Identify every scene the user has committed to. Three
sources:

1. **Explicit (from the user's `locked-scenes` file):** scenes the user
   has formally listed
2. **Implicit (from samples / conversation):** scenes the
   user has described or sketched but not formally locked
3. **Solicited (from the user, interactively):** scenes
   the agent asks about: "Is there a scene you've imagined
   that has to be in this book? An ending? An opening
   image? A character moment that defines who they are?"

For each scene, capture:

- **Scene ID:** S1, S2, S3...
- **Description:** what happens (3-5 sentences)
- **Setting:** where it happens
- **Cast:** who is present
- **Why it must exist:** the story-truth this scene
  carries (character revelation, plot turn, thematic
  payoff, emotional climax, world demonstration)
- **Chronological constraint:** "must be early" / "must
  be middle" / "must be late" / "flexible — earliest X,
  latest Y" / "must come after S4 and before S7"
- **Tonal register:** how the scene should feel (the
  reader's emotional state)
- **Required precursors:** what setup must come before
  this scene for it to land (information the reader
  needs, character development, world rules established)
- **Required consequences:** what must change after this
  scene (character arc beats, plot progression, tonal
  shift)
- **Source:** explicit / implicit / solicited

Present the collected list to the user for confirmation:
"Here are the must-exist scenes I've identified. Is
anything missing? Is anything in this list a 'nice to
have' rather than a 'must' — let me know so I can
distinguish them."

### Phase B: Identify must-exist character moments

Beyond named scenes, capture must-exist character moments
that are smaller-scale than full scenes:

- "This character must, at some point, do X" (e.g., "Gwaine
  must make a joke that lands during a serious moment —
  that's who he is")
- "The relationship must reach this beat by chapter Y"
- "The reader must feel X about Y character by chapter Z"

These are not full scenes but they constrain the outline's
chapter-by-chapter design. They produce REQUIRED BEATS
that connective chapters must include.

### Phase C: Identify must-exist images / motifs

Beyond scenes and moments, capture the visual / thematic
images the user wants the book to carry:

- "The book starts with X image"
- "The recurring motif is Y"
- "The closing image is Z"
- "The book's opening sentence is one of these three..."

These constrain the prose register and create anchor
points for the Writer agent in v2.7.0+.

### Phase D: Validate completeness

Before proceeding to Step 10, validate that the must-exist
scenes are sufficient to seed an outline:

- **Minimum threshold:** at least 3 must-exist scenes for
  a Novelette, 5 for a Novella, 8 for a Standard Novel,
  12 for an Epic. Below threshold, the outline cannot be
  scene-anchored — surface to user: "You've given me {N}
  must-exist scenes. For a {length tier} book, scene-first
  outlining typically needs at least {threshold}. Want
  to identify more, or proceed with structural-template
  outlining (Creator-mode default)?"

- **Coverage check:** verify the must-exist scenes span
  the manuscript's emotional / structural arc, not just
  one phase. If all scenes are climactic, the outline
  will lack setup. Surface: "Most of your must-exist
  scenes are climactic. Are there opening / mid-book
  moments that should also be locked, or is the build-up
  flexible?"

- **Conflict check:** identify any chronological /
  precursor / consequence conflicts between scenes. If
  S3's required precursors conflict with S5's chronology,
  surface to user.

### Output: `engine-data/must-exist-scenes.md`

Structured anchor file Step 10 reads in scene-first mode:

```
# Must-Exist Scenes Anchor — {Title}

## Scenes

### S1: {Scene Description}
- Setting: ...
- Cast: ...
- Why it must exist: ...
- Chronological constraint: ...
- Tonal register: ...
- Required precursors: ...
- Required consequences: ...
- Source: ...

### S2: ...

[... etc.]

## Character Moments (smaller-scale required beats)

### M1: ...
### M2: ...

## Images / Motifs

### I1: ...
### I2: ...

## Validation

- Scene count: {N} (threshold for {length tier}: {threshold} — {pass/fail})
- Arc coverage: {opening / mid / climax distribution}
- Chronological conflicts: {none / list}
```

## Step 10 (REWIRED) — Scene-First Chapter Outline

In Architect mode, Step 10 reads `must-exist-scenes.md`
and constructs the outline FROM the scenes outward, not
into a pre-filled structural template.

### Phase 10A: Place must-exist scenes

For each scene in `must-exist-scenes.md`:

1. **Identify the scene's narratively optimal chapter
   position.** Informed by:
   - Scene's own chronological constraint
   - Scene's required precursors (setup must come before)
   - Scene's required consequences (effects must come
     after)
   - Genre structure rhythms (Act 1 climax, midpoint,
     dark night, climax) — applied as ACCOMMODATIONS to
     scene placement, not as templates scenes are slotted
     into

2. **Map scene → chapter.** A must-exist scene IS a
   chapter (or, for set-piece sequences, a multi-chapter
   block). Each must-exist chapter is labeled `MUST-EXIST`
   with the scene ID it serves.

### Phase 10B: Identify connective tissue

Between consecutive must-exist scenes, identify the
connective work needed:

- **Setup needed for the next scene:** what does the
  reader need to know / feel / understand for the next
  must-exist scene to land?
- **Consequence required from the previous scene:** what
  must change after the previous must-exist scene that
  the next scene depends on?
- **Character development the scenes themselves don't
  show:** must-exist scenes are pivots; quiet character
  development happens between them
- **World-building scaffolding:** if the next scene
  requires the reader to understand world rule X, that
  rule must be demonstrated in connective tissue
- **Tension escalation between scenes:** the connective
  span carries the rising-pressure work that makes the
  next scene's stakes legible

### Phase 10C: Construct connective chapters

Each connective span becomes one or more chapters. Each
connective chapter has:

- **Complication** (something specific goes wrong)
- **Decision** (specific choice made by a specific
  character)
- **Escalation** (stakes specifically raised)
- **Serves:** explicit pointer — what must-exist scene
  this chapter sets up or follows from
- **POV:** chosen to deliver the connective work most
  effectively
- **Character moments delivered:** if the
  must-exist-scenes anchor includes M-codes (character
  moments), this is where they land

The connective chapter is NOT a "summary fillers between
locked scenes" chapter. It is a PURPOSEFUL chapter that
serves a specific narrative function the must-exist
scenes need but don't provide themselves.

### Phase 10D: Validate genre structure

Verify the resulting outline meets genre rhythm
requirements:

- Act 1/2/3 boundaries fall at reasonable manuscript
  positions
- Pressure curve climbs across acts
- Beat targets are met (or deliberately subverted)
- Must-exist scenes serve as the genre's structural beats
  where possible

If genre structure can't be served because must-exist
scenes don't align with it, **surface the conflict to
the user**:

```
Your locked scenes place the romantic kiss at chapter 19.
Genre romance convention places it around chapter 15
(the midpoint).

Three options:
  (a) Accept the late kiss as a deliberate genre subversion.
      The book becomes a slower-burn romance; we'll need to
      compensate with stronger emotional anchoring earlier.
  (b) Move the kiss to chapter 15 and adjust your
      locked-scenes anchor.
  (c) Restructure the connective tissue to give the
      chapter-19 placement an earlier beat that satisfies
      the genre's midpoint expectation (e.g., a near-kiss
      at chapter 15, the actual kiss at chapter 19).

Your call.
```

The user decides. The engine does NOT silently override.

### Phase 10E: Generate the chapter outline

Produce the standard chapter outline (per the legacy Step
10 fields: Chapter Number / Title / POV / Summary / Tone /
Goal / Complication / Decision / Stakes Escalation / Genre
Adaptive Fields), with two additions in Architect mode:

- **Chapter Type:** `MUST-EXIST` or `CONNECTIVE`
- **Serves:** for MUST-EXIST chapters, the scene ID
  served (e.g., "S3"); for CONNECTIVE chapters, the
  scene IDs being set up or followed from (e.g., "Sets
  up S4; follows from S3")

The outline is written to `engine-data/outline.md` as
usual.

## Output Comparison: Scene-First vs Structure-First

**Structure-first output (Creator mode, or Architect mode
without Step 9.5):**
```
Ch 1: Setup. Establish protagonist's world. Plant inciting
  question.
Ch 2: Continuing setup. Introduce love interest.
Ch 3: First plot complication.
Ch 4: ...
Ch 19: Romantic kiss (slot for canon Sample 7).
...
Ch 30: Climax. Final confrontation.
```

The locked scenes are slotted into structural positions.
The connective chapters are summary fillers.

**Scene-first output (Architect mode with Step 9.5):**
```
S1 (Ch 1): Opening image — Meg at the cathedral threshold
  hearing the bells. [MUST-EXIST]
Ch 2: Connective. Meg meets the captain of the watch; sets
  up S2's confrontation. [Serves: S2]
Ch 3: Connective. Gwaine's first scene — quick to laugh,
  fills silences with the porter at the inn. Trust signal
  for the reader. [Serves: M1, S2]
S2 (Ch 4): The first marker carved into the door — Meg
  realises she's been followed since the cathedral.
  [MUST-EXIST]
...
```

The must-exist scenes are the spine. The connective
chapters serve specific functions the scenes need.
Character moments (M1) anchor in the connective work, not
just the locked scenes.

## What this prevents

This step exists because the previous Step 10 produced
exactly the failure mode the user's session diagnosed:

- "The outline reads like a greatest-hits album of canon
  moments with summary connecting them, not a novel."
- "I summarised threat instead of dramatising it. Dorian
  exists for 24 chapters as rumour on notices and lines
  from farriers."
- "I leaned on your pre-written sample scenes as
  load-bearing tentpoles. Every one of the eight sample
  passages in the voice guide ended up anchoring a chapter."
- "Trust building brick by brick never happened. I wrote
  two quiet road chapters and then jumped to the kiss.
  Two bricks is not brick-by-brick."

Scene-first construction makes these failures structurally
impossible:

- The must-exist scenes are GOALS the connective work
  builds toward — they cannot become "summary tentpoles"
  because each MUST-EXIST chapter is identified as such
  and each CONNECTIVE chapter has a specific Serves
  pointer
- Threats cannot be summarised across 24 chapters because
  the connective work explicitly delivers escalating
  on-page pressure between must-exist scenes
- Sample scenes are not used as plot tentpoles because
  they're consumed by Step 0 as VOICE references, not by
  Step 9.5 as scene anchors (unless the user has
  explicitly added them to the user's `locked-scenes` file)
- Trust-building cannot be skipped because connective
  chapters carry M-code character-moment requirements
  that include incremental relationship beats

## Limits and caveats

This step has costs that the user should know about:

- **It requires more upfront work from the user** — the
  must-exist scenes need to be identified and articulated
  before outline construction. The agent helps, but the
  user has to commit to specifics.
- **It can produce non-genre-conventional outlines** — if
  the user's must-exist scenes don't align with genre
  rhythm, the outline reflects that. The user has to
  decide whether to subvert convention deliberately or
  re-anchor scenes to align.
- **It assumes the user knows what scenes matter** — for
  writers still discovering their book, Creator mode
  (skip Step 9.5, use structural template, let the
  engine help find the scenes) may be more appropriate.

For users who DO know what scenes matter — the BYO-canon
case — this step delivers the architectural promise of
"engine SERVES user's creative work" rather than the
structure-first failure of "engine slots canon into
template."

## See also

- `byo-canon.md` — the BYO-canon entry point
- `byo-canon-checklist.md` — `source-canon/` layout
  including `locked-scenes` file
- `outline-builder.md` § Step 0 — Source Material
  Absorption (pre-condition for Step 9.5)
- `outline-builder.md` § Step 10 — Detailed Chapter
  Outline (consumer of must-exist-scenes.md output in
  Architect mode)
- `blueprint-protocol.md` — Architect agent behaviour in
  Architect mode
- `prose-protocol.md` — Writer agent behaviour with
  must-exist-scenes anchored chapters
