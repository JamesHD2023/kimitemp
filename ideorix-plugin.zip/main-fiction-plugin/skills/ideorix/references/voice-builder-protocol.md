---
name: voice-builder-protocol
description: "Full protocol for building, testing, and saving reusable author voice profiles"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Voice Builder Protocol

## Overview

Creates reusable Voice Profiles compatible with the editorial pipeline (Stage 0 format).
Voice profiles can be built from scratch through guided conversation, extracted from
existing writing, or both. Each profile optionally links to a pen name.

## Storage

All voice profiles are stored locally:

```
~/Documents/Ideorix-Projects/
└── .pen-names/
    ├── index.md                    # Master list (updated with voice column)
    └── profiles/
        ├── elena-blackwood.md      # Pen name profile (now includes voice section)
        └── voices/
            ├── elena-blackwood-voice.md    # Full voice profile
            ├── jack-reeve-voice.md
            └── standalone-voice-01.md      # Voice without pen name
```

---

## Path A: Guided Build (Build from Scratch)

### Step 1: Writer Profile

Use AskUserQuestion to collect the writer profile. This shapes every subsequent
dimension — a 25-year-old debut writer sounds fundamentally different from a
55-year-old career novelist.

```
WRITER PROFILE:

1. Age bracket:
   a) Under 25 — Fresh, contemporary, digital-native voice
   b) 25-35 — Emerging, confident, culturally current
   c) 35-50 — Established, layered, experienced perspective
   d) 50-65 — Mature, assured, deep reference pool
   e) 65+ — Seasoned, reflective, timeless quality

2. Writing experience:
   a) New writer — finding my voice (engine helps shape it)
   b) Some experience — I know what I like but can't always pin it down
   c) Experienced — I have a clear sense of my voice, I need to codify it
   d) Professional — I write for a living and need a specific voice for this pen name

3. Genre background (select all that apply):
   a) Literary / book club fiction
   b) Commercial / genre fiction (thriller, romance, fantasy, etc.)
   c) Poetry or short fiction
   d) Journalism / non-fiction
   e) Screenwriting / playwriting
   f) Academic / technical writing
   g) No background — starting fresh

4. Reader profile — what do you read most?
   (Free text — e.g., "Sally Rooney, Tana French, literary thrillers")

5. Voice aspiration — in plain language, how do you want to sound?
   (Free text — e.g., "warm but sharp, like a smart friend telling you a story
   over wine" or "cold, precise, clinical — like a scalpel")
```

### How Age Bracket Influences Voice Defaults

Age doesn't dictate voice, but it shifts the starting point. These are defaults
the user can override — they set the baseline for Step 2.

| Dimension | Under 25 | 25-35 | 35-50 | 50-65 | 65+ |
|-----------|----------|-------|-------|-------|-----|
| Sentence length | Short-medium, punchy | Mixed, rhythmic | Varied, controlled | Longer, layered | Mixed — short for punch, long for reflection |
| Vocabulary | Contemporary, accessible | Moderate range, current idiom | Rich, precise | Expansive, occasionally formal | Precise, classical undertones |
| Fragment usage | Frequent | Occasional-frequent | Occasional | Rare-occasional | Rare — used for emphasis only |
| Register | Casual-conversational | Conversational-moderate | Moderate-literary | Moderate-formal | Literary — never stiff, but measured |
| Pop culture refs | Heavy, current | Moderate, selective | Light, canonical | Rare, classical | Very rare — period-specific if any |
| Dialogue style | Naturalistic, overlapping | Sharp, subtext-aware | Layered, controlled | Weighted, meaningful | Economical — every line earns its place |
| Introspection | Stream of consciousness | Internal monologue | Measured reflection | Deep, philosophical | Contemplative, distilled |
| Metaphor source | Digital, urban, media | Mixed modern | Nature, domestic, professional | Literary, historical, natural | Elemental — land, sea, time, memory |
| Humour type | Sarcastic, self-aware | Dry, observational | Ironic, understated | Wry, character-driven | Gentle, earned, situational |
| Pacing | Fast, clipped scenes | Balanced | Deliberate, breathing room | Patient, earned climaxes | Unhurried — trusts the reader |

**CRITICAL:** These are starting points, not stereotypes. Always present them as
adjustable defaults. A 22-year-old writing literary fiction may want the vocabulary
range of a 50-year-old. A 60-year-old writing YA may want the pacing of a 25-year-old.
The user overrides anything that doesn't fit.

### Step 2: Voice Dimensions

Based on the Writer Profile, present the 7 voice dimensions with **pre-selected
defaults** (informed by age bracket, genre background, and voice aspiration).
The user confirms or adjusts each one.

Use AskUserQuestion — present all 7 dimensions at once with the defaults highlighted.
The user can approve all, or change individual settings.

```
VOICE DIMENSIONS — based on your profile, here are your defaults:

SENTENCE ARCHITECTURE:
  - Average sentence length: [default based on age/genre] ← change?
  - Sentence variety: [default] ← change?
  - Fragment usage: [default] ← change?
  - Complexity preference: [default] ← change?

VOCABULARY:
  - Register: [default] ← change?
  - Range: [default] ← change?
  - Profanity level: [none/mild/moderate/heavy] ← your choice
  - Dialect markers: [none — or specify]

NARRATIVE STANCE:
  - Psychic distance: [default] ← change?
  - Introspection ratio: [default] ← change?
  - Description density: [default] ← change?
  - Sensory preferences: [default — e.g., "visual and tactile"] ← change?

DIALOGUE CHARACTERISTICS:
  - Tag style: [default] ← change?
  - Subtext level: [default] ← change?
  - Humour style: [default] ← change?

PACING SIGNATURE:
  - Chapter length: [regular/varied] ← change?
  - Scene transitions: [default] ← change?
  - Action-to-reflection ratio: [default] ← change?

METAPHOR & IMAGERY:
  - Density: [default] ← change?
  - Source domains: [default] ← change?
  - Recurring images: [none yet — these develop over time]
```

**Presentation rules:**
- Show the defaults clearly — make it easy to approve all at once
- Use plain language, not jargon: "How close are we to the character's thoughts?"
  not "psychic distance calibration"
- If the user says "approve all" or "looks good," accept and move on
- If the user changes specific items, update only those and confirm

### Step 3: Voice Summary

Generate a 3-5 sentence Voice Summary that captures the feel of this voice.
This is the most important output — it's what agents read first.

Present to the user for approval. Example:

> "This voice is warm, direct, and slightly irreverent — like a smart friend who
> reads too much and can't help making observations. Sentences are short when they
> need to land, longer when they're building atmosphere. Vocabulary is accessible
> but never dumbed down — the exact word, not the fancy one. Dialogue is clipped
> and subtextual; characters talk around the thing, not about it. Humour is dry and
> self-deprecating, delivered through internal monologue rather than set pieces."

### Step 4: Test Drive

Generate a **300-word sample passage** using the Voice Profile. The passage should:
- Use the selected genre (or a neutral contemporary scene if no genre specified)
- Include narrative prose, at least one description, and a short dialogue exchange
- Demonstrate the voice dimensions in action
- NOT be from any specific book — original content only

Present the sample and ask:

```
TEST DRIVE — Here's how this voice sounds on the page:

[300-word sample passage]

How does this feel?
1. That's my voice — save it
2. Close, but adjust: [tell me what to change]
3. Too [formal/casual/dense/sparse/slow/fast] — shift it
4. Start over — this isn't right
```

**Iteration rules:**
- If the user says "adjust," regenerate with their feedback applied
- Maximum 3 iterations — if it's not clicking after 3, suggest Path C (add a writing sample)
- After each iteration, show ONLY the changed passage — don't re-present the full dimensions
- When the user approves, move to Step 5

### Step 5: Save

See **Saving a Voice Profile** below.

---

## Path B: Extract from Writing

### Step 1: Collect Sample

Use AskUserQuestion:

```
Paste or upload a writing sample — at least 500 words, ideally 1,000+.

Best results come from:
- A passage you're proud of (it should represent how you WANT to sound)
- A mix of narrative and dialogue
- Something recent (your voice may have evolved)

Paste it below, or upload a file.
```

### Step 2: Writer Profile (abbreviated)

After receiving the sample, ask the abbreviated Writer Profile — only the items
that can't be inferred from the text:

```
A few quick questions to complete your profile:

1. Age bracket: [a-e as above]
2. Voice aspiration — is this sample how you WANT to sound going forward,
   or are you aiming for something different?
   a) This IS my voice — capture it exactly
   b) This is close, but I want to evolve it (tell me how)
   c) This is my old voice — I want something different (tell me what)
```

### Step 3: Analyse and Generate Profile

Run the Stage 0 Voice Profile analysis (from `editorial-suite.md`) on the sample.
Document all 7 dimensions + Voice Summary.

If the user selected (b) or (c) in Step 2, apply their requested shifts before
finalising.

### Step 4: Present and Confirm

Present the full Voice Profile and Voice Summary. Then run a Test Drive (same as
Path A Step 4) to validate.

### Step 5: Save

See **Saving a Voice Profile** below.

---

## Path C: Hybrid (Guided + Sample Calibration)

1. Run **Path A Steps 1-4** (Guided Build through Test Drive)
2. After the test drive, offer:

```
Want to calibrate against your own writing?

Paste a sample (500+ words) and the engine will compare your guided profile
against your actual prose. Where they differ, you choose which version to keep.
```

3. If the user provides a sample:
   - Run Stage 0 analysis on the sample
   - Compare each dimension: guided profile vs. extracted profile
   - Present differences in a clear table:

```
CALIBRATION — Guided vs. Your Actual Prose:

| Dimension              | Guided Profile      | Your Prose          | Keep? |
|------------------------|---------------------|---------------------|-------|
| Sentence length        | short-medium        | medium-long         | ?     |
| Fragment usage         | frequent            | rare                | ?     |
| Register               | conversational      | conversational      | ✓     |
| Description density    | sparse              | moderate            | ?     |
| Humour style           | dry                 | dry                 | ✓     |
```

   - Matching dimensions: auto-keep (mark ✓)
   - Differing dimensions: user picks guided or extracted
   - Update the profile with the user's choices
   - Regenerate Voice Summary and run one final Test Drive

4. Save.

---

## Saving a Voice Profile

### Link to Pen Name

Before saving, ask:

```
VOICE PROFILE READY — Link to a pen name?

1. Link to [pen name] (if currently in pen name context)
2. Link to an existing pen name (show list from .pen-names/index.md)
3. Save as standalone voice (can link to a pen name later)
4. Create a new pen name for this voice (launches Pen Name Studio)
```

### Voice Profile File Format

Save to: `~/Documents/Ideorix-Projects/.pen-names/profiles/voices/{slug}-voice.md`

```markdown
# Voice Profile — {Voice Name or Pen Name}

## Created
- **Date:** {date}
- **Method:** {Guided Build / Extracted from Sample / Hybrid}
- **Linked Pen Name:** {pen name or "Standalone"}

## Writer Profile
- **Age Bracket:** {selected bracket + label}
- **Experience:** {level}
- **Genre Background:** {selected backgrounds}
- **Reader Profile:** {what they read}
- **Voice Aspiration:** {their own words}

## Voice Dimensions

SENTENCE ARCHITECTURE:
  - Average sentence length: {value}
  - Sentence variety: {value}
  - Fragment usage: {value}
  - Complexity preference: {value}

VOCABULARY:
  - Register: {value}
  - Range: {value}
  - Profanity level: {value}
  - Dialect markers: {value}

NARRATIVE STANCE:
  - Psychic distance: {value}
  - Introspection ratio: {value}
  - Description density: {value}
  - Sensory preferences: {value}

DIALOGUE CHARACTERISTICS:
  - Tag style: {value}
  - Subtext level: {value}
  - Humour style: {value}

PACING SIGNATURE:
  - Chapter length: {value}
  - Scene transitions: {value}
  - Action-to-reflection ratio: {value}

METAPHOR & IMAGERY:
  - Density: {value}
  - Source domains: {value}
  - Recurring images: {value}

## Voice Summary

{3-5 sentence voice fingerprint}

## Sample Passage

{300-word approved test-drive passage demonstrating this voice}

## Usage History
| Project | Date | Genre |
|---------|------|-------|
```

### Update Pen Name Profile

If linked to a pen name, add a Voice section to the pen name profile
(`~/Documents/Ideorix-Projects/.pen-names/profiles/{pen-name-slug}.md`):

```markdown
## Voice Profile
- **Voice file:** voices/{slug}-voice.md
- **Voice summary:** {3-5 sentence summary}
- **Built:** {date}
- **Method:** {Guided Build / Extracted / Hybrid}
```

### Update Index

Update `~/Documents/Ideorix-Projects/.pen-names/index.md` to show voice status:

```markdown
| Pen Name | Genre | Created | Projects | Voice |
|----------|-------|---------|----------|-------|
| Elena Blackwood | Romance | 2026-01-15 | 2 | Yes |
| Jack Reeve | Thriller | 2026-02-03 | 1 | No |
```

---

## Integration Points

### Project Setup (Q8: Style Guide)

When Q8 asks about style, the engine should check for voice profiles:

```
Question 8: Style Guide

You have saved voice profiles:
  → Elena Blackwood: "Warm, direct, slightly irreverent — like a smart friend..."
  → Jack Reeve: "Cold, precise, clinical — short sentences that hit like facts..."

Choose your style guide:
1. Use a saved voice profile (select from list above)
2. Upload previous manuscripts for voice matching
3. Describe your preferred style
4. Use genre defaults
```

If a pen name was already selected in Q12 and it has a linked voice, pre-select it:

```
Question 8: Style Guide

Your pen name Elena Blackwood has a linked voice profile:
  "Warm, direct, slightly irreverent — like a smart friend..."

1. Use Elena Blackwood's voice (recommended)
2. Choose a different voice
3. Upload manuscripts instead
4. Describe a new style
5. Use genre defaults
```

### Prose Agent Integration

When a voice profile is loaded as the Style Guide, the prose agent receives:
- The full Voice Dimensions block (injected via `{style_guide_if_exists}`)
- The Voice Summary (placed at the top of the style guide)
- The Writer Profile age bracket and experience level (for register calibration)

### Editorial Pipeline Integration

When a voice profile exists, Stage 0 of the editorial pipeline SKIPS building a
new profile and uses the saved one instead. This ensures the same voice standard
is applied to both writing and editing.

### Pen Name Selection (Q12)

When a pen name is selected in Q12, check if it has a linked voice. If it does,
auto-suggest it for Q8. If the user hasn't reached Q8 yet, note the voice for
when they do. The flow becomes:

```
Q12: Select pen name → Elena Blackwood
Q8:  "Elena Blackwood has a linked voice. Use it?" → Yes
     → Voice Profile loaded as Style Guide. Done.
```

Note: Q12 comes after Q8 in the question order. If a pen name with a voice is
selected at Q12, offer to retroactively apply the voice as the Style Guide
(replacing whatever was chosen at Q8):

```
You selected Elena Blackwood, who has a saved voice profile.
Your current Style Guide is set to "genre defaults."

Would you like to switch to Elena Blackwood's voice instead?
1. Yes — use Elena's voice (recommended)
2. No — keep genre defaults
```

---

## Standalone Studio Mode

When accessed from the main menu (not during project setup):

Present these options:
1. **Build a new voice** — Full guided build (Path A)
2. **Build from my writing** — Extract from a sample (Path B)
3. **Hybrid build** — Guided + calibration (Path C)
4. **View my voices** — List all saved voice profiles with summaries
5. **Edit a voice** — Modify dimensions, summary, or writer profile
6. **Test-drive a voice** — Generate a new sample passage in any saved voice
7. **Link voice to pen name** — Attach, detach, or reassign pen name links
8. **Back to main menu**

---

## Anti-Patterns

- Do NOT use real author names in the Voice Summary (say "warm and direct" not "writes like Sally Rooney")
- Do NOT generate voice profiles that are carbon copies of famous authors' styles
- Do NOT skip the Test Drive — the user must hear the voice before it's saved
- Do NOT present voice dimensions using academic jargon — always use plain language alongside technical terms
- Do NOT assume age equals ability — a young writer can have a mature voice, and vice versa
- Do NOT store voice profiles inside the project directory — they live in `.pen-names/` and persist across projects
- Do NOT overwrite an existing voice profile without explicit confirmation

---

## Screen Mode (Screenplay Voice Profiles)

When the active project is a screenplay (Screen Studio, or
`project-config.md` Mode = "Screen Studio"), the voice
question is structurally different from prose voice and
requires three distinct voice-profile types. Detection:

```
if project-config.md → Mode == "Screen Studio":
    activate Screen Mode (this section)
elif project-config.md → Mode == "Writers Studio" or "Full Creative Suite":
    activate Prose Mode (Path A / B / C above)
else:
    ask the user: "Is this for a manuscript or a screenplay?"
```

In Screen Mode, prose voice dimensions (sentence length,
paragraph rhythm, narrator voice) do not apply directly.
The screenwriter's voice question splits into three
profile types, each independently buildable and
attachable to a project.

### Screen Voice Profile Types

#### Type 1: Per-Character Dialogue Voice (MANDATORY for any screenplay)

The single highest-leverage voice work in screenwriting.
Each named character in the screenplay must be
distinguishable in dialogue alone — a reader covering
the names should still know who is speaking. This is
the cover-name test from the screenplay-agent's Quality
Gate (Pass 4: Dialogue anti-pattern scan).

Build a Per-Character Dialogue Voice profile per major
character (typically 4-8 characters per feature, 6-12
per TV series). Each profile captures:

```
CHARACTER: {Name}
ROLE: protagonist | antagonist | ally | rival | mentor |
      love interest | comic relief | ensemble member
APPEARANCE BUDGET: lead (~30-40% of dialogue) | major
                   supporting (~15-20%) | supporting
                   (~5-10%) | recurring (<5%)

VERBAL TICS (the 3-5 character-rooted patterns):
  - Catchphrase or recurring word ("Right?" / "Look —" /
    Italian sayings / military jargon / specific oath)
  - Sentence length default (terse < 8 words / medium
    8-15 / verbose 15+)
  - Interruption habit (interrupts others / gets
    interrupted / never interrupts / always finishes
    sentences)
  - Question-vs-statement default (asks more than
    states / states more than asks / equal)
  - Profanity register (clean / mild / moderate /
    heavy — and what they swear by)

VOCABULARY REGISTER:
  - Education level (street / blue-collar / college /
    professional / academic / specialist)
  - Period vocabulary (modern / 1990s / mid-century /
    Victorian / Elizabethan / etc.)
  - Domain vocabulary (legal / medical / military /
    sports / academic / criminal / religious / etc.)
  - Profession-specific patterns (doctor uses
    differential-diagnosis register; lawyer uses
    conditional clauses; soldier uses rank-and-task
    structure)

EMOTIONAL DEFAULT:
  - Reactive (responds to others) / Proactive (drives
    conversation)
  - Tonal default (sardonic / earnest / wry / hostile
    / warm / closed / opaque)
  - Conflict mode (deflects / confronts / escalates
    / withdraws / placates)
  - Affect range (narrow — controlled / wide —
    expressive)

WHAT THIS CHARACTER WILL NOT SAY:
  - Specific words / topics they avoid
  - The taboo register (what they would never address
    directly — names of dead, certain emotions,
    specific facts)
  - The tell-of-the-deflection (how they verbally
    change subject when pressed)
```

**Cover-name test (MANDATORY before saving):** generate
3 lines of dialogue from the profile, remove the
character name, and ask the user to identify which
character is speaking. If they can't — the profile is
not specific enough; rebuild for differentiation.

#### Type 2: Action-Line Writer Voice (the screenwriter's narrative voice)

Action lines (scene description) carry the writer's
voice in a screenplay. This is NOT prose narration —
it is its own register: present-tense, visual-first,
lean, character-rooted-but-impersonal. The Coen
brothers, Aaron Sorkin, Diablo Cody, Phoebe Waller-
Bridge, Jordan Peele, Greta Gerwig, Damon Lindelof,
Charlie Kaufman, Vince Gilligan — each has a
recognizable action-line voice. The writer's voice
on the page (not the characters' voices in dialogue).

Build an Action-Line Writer Voice profile:

```
TENSE DISCIPLINE:
  Present-tense throughout (industry standard) /
  Light past-tense (rare, signal-specific) /
  Mixed (NOT recommended — flag as anti-pattern)

VISUAL DENSITY:
  Lean (8-12 word action lines / single image per
    line) / Medium (12-18 words / 1-2 images) /
    Dense (18-30 words / multiple images per beat)

VOICE PERSONALITY:
  Invisible (industry-default — Trottier-perfect
    impersonal) / Lightly present (occasional editorial
    aside, dry observation) / Strongly present
    (writerly voice as character — Coen / Sorkin
    register) / Distinctive idiosyncratic (Diablo Cody
    / Charlie Kaufman / PWB register)

RHYTHM PATTERN:
  Staccato (short bursts, frequent paragraph breaks) /
  Flowing (medium runs, breathing rhythm) / Layered
  (longer beats, embedded camera direction)

CAMERA / DIRECTION HABIT:
  Spec-clean (no shot direction, action-line-only) /
  Light direction (occasional ANGLE / CLOSE ON for
  emphasis) / Moderate (consistent shot framing in
  action lines) / Heavy (full shot direction —
  shooting-script register, NOT spec-appropriate)

CAPS DISCIPLINE:
  Strict (only first character introduction + key
  sound effects, ≤ 3 per page per Quality Gate Pass 8)
  / Medium (specific objects / actions also CAPS) /
  Loose (frequent CAPS — flag as anti-pattern)

EDITORIAL VOICE:
  Pure-witness (action-line as objective observation) /
  Dry-witty (occasional editorial flicker) /
  Distinctive (writer's voice clearly present in
  description register)

PUNCTUATION TICS:
  Em-dash use / Comma rhythm / Sentence fragments /
  Single-word lines / All-caps for emphasis

GENRE CALIBRATION:
  Horror — sparse, present-tense imperative ("She turns.
    The room is wrong.") / Thriller — kinetic, action-
    verb-first / Comedy — rhythmic, occasional editorial
    aside / Drama — measured, character-state-first /
    Action — staccato, body-mechanic / Literary —
    sensory-layered, observation-rich
```

#### Type 3: Voice-Over Voice (when applicable)

Used only for screenplays with significant V.O. (voice-
over) — Sunset Boulevard, Goodfellas, The Big Lebowski,
Fleabag (TV), Mad Men's narration episodes, the Royal
Tenenbaums narrator, Forrest Gump's voiceover.

Voice-Over voice is closer to prose narration voice
than action-line voice. Build a V.O. profile using a
truncated version of Path A (prose Voice Builder): pick
the relevant prose voice dimensions (sentence rhythm,
narrator personality, register, period) — but ALWAYS
mark the profile clearly as `Type: Voice-Over` so the
Writer agent invokes it only for V.O. scenes, not for
action-line work or character dialogue.

### Screen-Mode Build Flow

When user invokes Voice Builder from Screen Studio:

```
What would you like to build?

  1. Per-Character Dialogue Voice (build for one or
     more named characters)
  2. Action-Line Writer Voice (the script's narrative
     voice in scene description)
  3. Voice-Over Voice (only if your screenplay uses
     voice-over)
  4. Build all three for a new project
  5. Edit / view existing screen voice profiles
  6. Back to Screen Studio

Type a number to continue.
```

For Path 1 (Per-Character Dialogue Voice), accept a
character name and run the per-character profile flow.
For multi-character builds (option 4), iterate the
flow per-character with the character roster from the
Story Bible.

### Storage

Screen voice profiles save to the same `.pen-names/`
infrastructure as prose voice profiles, with
disambiguation by Type:

```
.pen-names/{pen-name}/voices/
├── {voice-name}-prose.md            ← Prose Mode (Path A/B/C)
├── {voice-name}-character-{NAME}.md ← Screen Mode Type 1 (per character)
├── {voice-name}-action-line.md      ← Screen Mode Type 2
└── {voice-name}-voice-over.md       ← Screen Mode Type 3
```

A single project may use multiple character-voice
profiles + one action-line profile + (optionally) one
voice-over profile, all attached to the same project
and the same pen name.

### Anti-Patterns (Screen-Specific)

- Do NOT apply prose voice dimensions to dialogue
  voice (sentence-length distributions don't translate
  the same way; per-line rhythm matters more than
  paragraph rhythm)
- Do NOT skip the cover-name test for Per-Character
  Dialogue Voice (this is the genre's primary
  differentiation discipline)
- Do NOT confuse Action-Line Writer Voice with Voice-
  Over Voice (different registers, different prose
  rhythm, different agent invocation paths)
- Do NOT force all characters to have the same
  vocabulary register (the soldier should sound
  different from the lawyer should sound different
  from the teenager — voice differentiation is the
  craft)
- Do NOT build a "screenwriter voice" profile that
  contradicts the screenplay-agent's Quality Gate
  (e.g. heavy CAPS, heavy shot direction, mixed-tense
  action lines — these flag as anti-patterns at
  delivery)
- Do NOT auto-link a voice to a pen name without asking — always offer the choice
