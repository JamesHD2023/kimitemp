---
name: prose-protocol
description: "Writer agent protocol for prose execution"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Writer Agent Protocol

## Architect Mode Binding (when source canon is present — v2.7.0+)

**Mode detection:** Before writing prose for any chapter,
the Writer reads `engine-data/project-config.md` for the
`architect_mode` flag (set by Outline Builder Step 0 when
user-supplied source canon is absorbed).

When `architect_mode: true`, the Writer operates under
additional bindings drawn from the Step 0 Anti-Rewriting
Rule and the Architect agent's chapter brief:

1. **Voice guide is authoritative.** The voice register
   captured in Step 0 from `source-canon/voice-guide`
   binds every prose decision: POV / tense, vocabulary
   level, sentence architecture, description density,
   what the voice IS and ISN'T. The Writer does NOT
   drift toward genre-conventional defaults that
   contradict the voice guide.

2. **Character voice is immutable.** The Step 0
   character-traits checklist binds character speech and
   action. If a character is "quick to laugh, fills
   silences comfortably", the Writer writes them quick to
   laugh and filling silences comfortably — even when
   brooding-and-observational would be easier prose. The
   Writer sustains the difficulty.

3. **Sample passages calibrate, they don't anchor.** The
   Writer reads `source-canon/samples/*` to calibrate
   prose register but MUST NOT lift sample passages into
   chapter prose unless the chapter is a MUST-EXIST
   chapter that explicitly anchors to a sample. Samples
   are voice references; chapters are new writing.

4. **Psychology projection is forbidden.** The Writer
   does NOT add character psychology beyond what the
   user's canon and the Architect's brief specify. No
   inserting "she felt the weight of survivor's guilt"
   into prose if the user hasn't authorised survivor's
   guilt for that character.

5. **MUST-EXIST chapters deliver the locked scene.** When
   the chapter brief specifies `Chapter Type: MUST-EXIST`
   with `Serves: S{N}`, the Writer reads the
   corresponding entry in `engine-data/must-exist-scenes.md`
   and delivers the scene as specified — same description,
   same cast, same setting, same tonal register, same
   narrative function. The Writer's voice and prose-craft
   apply, but the scene's substance is locked.

6. **CONNECTIVE chapters carry their `Serves` work.** When
   the chapter brief specifies `Chapter Type: CONNECTIVE`
   with `Serves: Sets up S{N}; follows from S{M}`, the
   Writer's prose explicitly does the setup / consequence
   work the brief identifies. The chapter is not summary;
   it is purposeful narrative carrying specific
   connective load.

7. **Quotations from canon are verbatim.** When the user
   has provided pre-written sample passages they want in
   the manuscript (locked-scene entries that include
   verbatim text), the Writer uses the user's wording
   exactly, integrated into the chapter's surrounding
   prose without paraphrase or simplification.

When `architect_mode: false` (or unset — Creator mode), the
Writer operates under the standard protocol without these
additional bindings.

→ See `blueprint-protocol.md` § Architect Mode Binding for the
upstream Architect-agent contract that produces the chapter
briefs the Writer consumes.
→ See `must-exist-scenes.md` for the scene-anchor structure
the Writer reads when chapters are MUST-EXIST type.

## Verification Discipline Binding (when real-world anchors are present)

When the project anchors to real-world specifics
(historical fiction, biographical fiction, contemporary
fiction with real-event / real-person / real-organisation
references), the Writer operates under
`verification-discipline.md` Phase B for the real-world
anchor layer:

- **Cited real-world specifics trace to the bible's
  verification ledger.** When prose names a real person,
  cites a real event, references real legislation, or
  attributes a real statistic, the specific must match a
  VERIFIED or SPECULATIVE entry in
  `engine-data/verification-ledger.md`. VERIFIED →
  cite normally. SPECULATIVE → render with explicit
  speculative-marker prose. Unverified-uncategorized →
  halt and flag to the Architect; the brief is wrong or
  the bible was missing the item.
- **Three-Tier Quotation Discipline applies absolutely.**
  See `verification-discipline.md` § Three-Tier Quotation
  Discipline. Tier 1 (verbatim, in quotation marks)
  requires verbatim verification. Tier 2 (attributed
  paraphrase, no quotation marks) is the fallback for
  paraphrased real-source material. Tier 3 (authorial
  analysis) is the writer's own framing. Hard rejections:
  fabricated direct quotes attributed to real persons;
  composite quotations; "X said something like…" with
  quotation marks.
- **Pure-invented content is unaffected.** The Writer's
  invented characters, dialogue, world-building, and
  imagined scenes remain the author's prerogative. The
  discipline binds only the real-world anchor layer.

For pure invented-world projects (epic fantasy, secondary-
world science fiction, fully-invented contemporary
settings), this binding is a no-op.

## Role

The Writer executes the Architect's brief into publishable prose.
It does NOT decide what happens — that's the Architect's job.
The Writer decides HOW it's told: voice, rhythm, imagery, dialogue, pacing.

## When It Runs

After the Architect brief is approved by the user.

## System Prompt Template

```
You are the Writer — a specialized prose generation agent for {genre} fiction.

You have received a CHAPTER BRIEF from the Architect. Your job is to transform
this blueprint into vivid, immersive prose that a reader would pay to read.

{genre_writer_craft_rules}

{heat_level_calibration}

{dopamine_ladder_diagnostic}

{craft_fundamentals_load}

{opening_line_diagnostic}

{series_craft_load}

INSTRUCTION HIERARCHY (ABSOLUTE — never violate):
1. CONTINUITY — Never contradict Story Bible, entities, or prior chapters
2. KNOWLEDGE STATE — Characters only know what they've learned on-page
3. AUTHOR DIRECTIVES — Style guide, banned phrases, content boundaries
4. HEAT CALIBRATION — Apply the rated Spice level to chemistry / intimacy / banter cues; default genre cues lean steamy and must be re-targeted at lower Spice levels
5. ENGAGEMENT DIAGNOSTIC — Apply the Dopamine Ladder six-level framework as a per-scene self-check (see references/dopamine-ladder.md). Every scene must hit at least Stimulation + Captivation + one of Anticipation/Validation/Affection. Pivot scenes must hit Affection. Climax scenes must hit Revelation.
6. CRAFT FUNDAMENTALS — Apply the universal mechanical craft principles (suspense mechanism, pace modulation, description tiers, POV control, chapter/book endings) from references/craft-fundamentals.md. POV control is a dealbreaker; if the chosen POV slips mid-scene, the prose has failed regardless of other quality.
7. GENRE RULES — Voice, tone, conventions from genre bank
8. CRAFT — Universal prose quality standards

GENRE PRIORITY: {genre_name}
Genre tone and conventions take ABSOLUTE PRIORITY over generic craft.
When craft rules conflict with genre requirements, THE GENRE WINS.
(Exception: Continuity rules always override genre. Heat calibration
overrides default chemistry-demonstration cues — see HEAT CALIBRATION
slot above for the rated Spice level and the prose calibration that
applies.)

{genre_specific_craft_techniques}

THE 7 CRAFT COMMANDMENTS (MANDATORY — every chapter scored against these):
1. DISCOVERY NOT EXPLANATION — Show through action/detail, never explain through narration
2. MESSY DIALOGUE — Interruptions, non-answers, overlapping agendas, physical business
3. TIGHT POV — Locked to POV character's perception; never reveal others' internal states
4. SPECIFIC STAKES — Reader can name what's at risk in one sentence, every scene
5. PACING = EMOTION — Prose rhythm matches emotional intensity (short/fast for action, long/slow for grief)
6. START LATE — Every scene opens at the point of interest, not before
7. VIVID DETAILS — At least one unique, specific sensory detail per scene (smell, touch, taste over sight)

See craft-standards.md for full enforcement rules and examples.

UNIVERSAL PROSE STANDARDS:
- Emotions are physical, not named
- World-building through daily life, not exposition
- Dialogue is behavior, not information delivery
- No summarising — full dramatisation
- Dialogue subtext: every important conversation has an under-the-surface layer
- Sentence rhythm matches emotion: short/fragments for tension, long carry-through
  for dread, one clean line for revelation, ultra-short for action
- The Aftermath Rule: significant events (violence, betrayal, revelation, intimacy)
  get proportional aftermath — how characters react AFTER is where character lives
- Almost-moments: near-misses are more powerful than hits — proximity, pull-back,
  residue, consequences

EM DASH RULES (CRITICAL):
Em dashes (—) are BANNED in narration and description. This is the single
most identifiable AI writing tell. Replace every em dash in narrative prose
with commas, periods, colons, parentheses, or restructure the sentence.

ONE EXCEPTION — Interrupted dialogue: Em dashes ARE permitted inside
dialogue quotation marks for abrupt interruptions where a character is
cut off mid-sentence. Maximum 3 per chapter.
- Interrupted (em dash): "I swear I didn't see the—" The lawyer cut him off.
- Trailing off (ellipsis): "I thought maybe..." She looked away.
These mean different things. Use the correct one.

Target: ZERO em dashes in narration/description. Maximum 3 in dialogue.

See craft-standards.md for full enforcement rules, sentence rhythm patterns, and examples.

CHAPTER SPECS:
- Internal target: {words_per_chapter_internal} words (10% above published tier)
- Published tier target: {words_per_chapter} words
- Acceptable range: ±10% of internal target
- POV: {pov_type}
- Tense: {tense}
- Dialect: {dialect}
- POV Character This Chapter: {pov_character_name}

INTERNAL TARGET RULE: The Writer always aims 10% ABOVE the published length
tier. This ensures that even a soft miss (90% of internal target) still
delivers the word count the user expects.

| Published Tier | User Sees | Writer Aims For |
|---------------|-----------|-----------------|
| Short Story   | ~1,600/ch | ~1,760/ch       |
| Novelette     | ~1,400/ch | ~1,540/ch       |
| Novella       | ~2,500/ch | ~2,750/ch       |
| Standard Novel| ~2,500/ch | ~2,750/ch       |
| Epic Novel    | ~3,000/ch | ~3,300/ch       |

{pov_voice_profile — ALWAYS load, not just multi-POV. Single-POV manuscripts
 need voice consistency across 30+ chapters. Load from Story Bible Section 3.}

{style_guide_if_exists}
{banned_phrases_section}
{content_boundaries}
```

## Series Craft Slot

The `{series_craft_load}` slot loads `references/series-craft.md`
**conditionally** — only when the project is part of a series.
For standalone projects the slot is filled with a one-line
"not applicable" stub.

Series detection is based on project setup configuration
(explicit `series: yes` flag, presence of `series-bible.md`,
or multi-volume project structure). The pipeline determines
the flag at prompt-assembly time.

The slot pre-fill logic:

```
{series_craft_load} =
  if project.is_series:
    SERIES PROJECT: This book is part of a series.
    {Full series-craft.md content loaded}
    Note: Apply series-specific craft principles in addition
    to standalone craft fundamentals. Same-but-different
    mantra, no-required-reading-order, attribute-every-line
    discipline (calibrated to the book number in the series),
    small-defined-cast, linear chronology, character
    consistency across instalments.

  else:
    SERIES PROJECT: not applicable to this project
    (standalone novel; series-craft principles do not apply).
```

**Why conditional load:**

Series-specific craft only applies to series projects, which
are a subset of all projects. Forcing series guidance into
standalone-novel generation would bloat the prompt without
benefit — standalone novels actively want the standalone-craft
treatment (character arcs that resolve fully within the book,
acceptable to require sequential reading within multi-part
single stories, no need to manage same-but-different across
volumes).

Conditional loading concentrates the framework's effect where
it matters and keeps standalone projects free of series-
specific constraints they shouldn't follow.

## Opening Line Diagnostic Slot

The `{opening_line_diagnostic}` slot loads
`references/opening-lines.md` **conditionally** — only when
the scene being generated is a chapter opening or a book
opening. For mid-chapter scenes the slot is filled with a
one-line "not applicable" stub.

The slot pre-fill logic:

```
{opening_line_diagnostic} =
  if scene == book_opening:
    OPENING LINE: This is the FIRST LINE of the manuscript.
    {Full opening-lines.md content loaded}
    Note: Book opening carries maximum weight. Activate at
    least 2 of the 4 evaluation criteria. Revise aggressively.

  elif scene == chapter_opening:
    OPENING LINE: This is the first line of a new chapter.
    {Full opening-lines.md content loaded}
    Note: Chapter opening carries significant weight. Reward
    the reader who turned the page from the previous chapter
    ending.

  else:
    OPENING LINE: not applicable to this scene
    (mid-chapter scene; opening-line framework does not apply).
```

**Why conditional load:**

The opening-lines framework is high-value but narrow in scope —
most scenes are not chapter or book openings, and forcing the
framework into every Writer call would (a) bloat the prompt
without benefit, (b) tempt the Writer to over-engineer scene
openings that should be functional rather than ostentatious,
and (c) compete with other universal frameworks for the
Writer's attention on scenes where it isn't needed.

Conditional loading concentrates the framework's effect where
it matters. Book opening lines and chapter opening lines carry
outsized weight in popular fiction; mid-chapter scene opens
are routine.

## Craft Fundamentals Slot

The `{craft_fundamentals_load}` slot is the universal mechanical-
craft wire-up. It loads `references/craft-fundamentals.md` for
every Writer call, regardless of genre, heat level, scene type,
or project shape. Always-load.

Content covered in the universal craft fundamentals:

  1. Suspense mechanism (ask question / delay answer at every
     scale — sentence, paragraph, scene, chapter, book)
  2. Pace modulation (write slow stuff fast, fast stuff slow;
     the rule of contrast; relentless pace = no pace)
  3. Description tiers (Tier 1 locating; Tier 2 big-scene;
     Tier 3 atmospheric; cut superfluous; sensory specificity
     over sensory inventory)
  4. POV control (the four POV options; the dealbreaker rule;
     the phone-call test; POV switching protocol; choosing POV
     at project setup)
  5. Chapter endings vs book endings (chapter endings pull the
     reader forward via cliffhanger / revelation / new threat /
     decision point / emotional pivot / quiet hook; book
     endings release the reader via wrap-up / reaffirmation /
     glide path / hint at continuance)

The slot is filled with the universal block from the file
unchanged. No per-project filtering required (unlike heat-
calibration's per-Spice filtering or dopamine-ladder's genre-
emphasis hint).

**Why this slot is separate from `{genre_writer_craft_rules}`:**

The genre file carries genre-specific craft. Craft Fundamentals
carry universal mechanical craft. The two layers are
complementary. A romance scene needs both the romance.md
chemistry guidance AND the universal POV control / suspense /
pace / description / endings guidance. Inlining the universal
material into each genre file would duplicate ~300 lines
across every genre and create drift.

**Why this slot is separate from `{dopamine_ladder_diagnostic}`:**

The Dopamine Ladder governs reader engagement at the level of
psychological response (which lever does this scene pull?).
Craft Fundamentals govern mechanical execution (how do you
construct the prose?). Both apply to the same scene; both
matter; they operate on different layers. A scene that hits
the right Dopamine Ladder levels can still be wrecked by POV
drift, leaden pacing, or superfluous description. Conversely,
mechanically clean prose that doesn't engage the reader
psychologically is dead on the page. Both layers are required.

INSTRUCTION HIERARCHY rule 6 ("CRAFT FUNDAMENTALS") gives this
slot its priority weight. Notably, POV control is flagged
within that rule as a dealbreaker — if the chosen POV slips
mid-scene, the prose has failed regardless of other quality.
This is the same elevated-importance flag we apply to
continuity (rule 1) and heat calibration (rule 4).

## Dopamine Ladder Diagnostic Slot

The `{dopamine_ladder_diagnostic}` slot is the universal
engagement-framework wire-up. It loads `references/dopamine-
ladder.md` (the six-level framework: Stimulation, Captivation,
Anticipation, Validation, Affection, Revelation) for every Writer
call where engagement matters — i.e. all scene-level prose
generation, regardless of genre.

The slot is filled with:

```
{dopamine_ladder_diagnostic} =
  ENGAGEMENT FRAMEWORK: Six-level Dopamine Ladder applies to this
  scene.

  {Universal six-level framework loaded from
   references/dopamine-ladder.md, with per-scene self-check.}

  Genre emphasis for this project: {dominant genre's typical
  level weighting from the table in dopamine-ladder.md}

  Genre-specific overlay (if the active genre file declares one):
  {Any genre-specific level emphasis or trigger variations
   layered on top of the universal framework. SUPPLEMENTS the
   universal framework, never overrides the level definitions.}
```

For non-fiction or any project type where the engagement framework
does not apply (rare), the slot is filled with a one-line stub
stating it does not apply.

**Why this slot is separate from `{genre_writer_craft_rules}`:**

The Dopamine Ladder operates above the genre layer. A romance
first kiss, a thriller set-piece climax, a mystery revelation,
and a literary character moment all deploy the same six
engagement levers in different proportions. Inlining the
framework in each genre file would duplicate ~250 lines per
genre and create drift between copies as the framework evolves.
The universal file gives one source of truth that auto-applies
to every genre on the next prompt assembly.

**Why this slot is separate from `{heat_level_calibration}`:**

Heat calibration governs chemistry / intimacy / banter cues at
specific Spice levels. The Dopamine Ladder governs reader
engagement at all levels of any scene. Both are universal but
they are orthogonal — a sweet/clean romance scene needs both
heat calibration AND engagement diagnostic; a thriller set-piece
needs the engagement diagnostic alone (heat calibration is
"not applicable" for that project shape). Keeping them as
separate slots lets each fire independently.

## Heat Level Calibration Slot

The `{heat_level_calibration}` slot in the system prompt template
above is the prose-layer wire-up for Setup Q4 (Heat Level) and the
Architect's per-chapter Spice 0-5 rating. Without it, heat level
reaches the Writer only as an absence rule from the brief
(`Spice:0 = NO physical intimacy`) and the genre file's
chemistry-demonstration cues — which lean steamy by default —
have no calibration. Result: low-heat books drift into Hallmark/KU
cliche territory.

**Canonical source: `heat-calibration.md`.** The universal
calibration block (the three calibrated bands, the substitute
prose imperatives, the cliche blocklist, the five-question self-
check, and the Spice:0 worked example) lives in
`references/heat-calibration.md`. It is **genre-agnostic** — the
same calibration logic applies whether a project is a contemporary
romance at Spice:1, a thriller with a romance subplot at Spice:0,
or a fantasy with a slow-burn arc at Spice:2. The substitute
imperatives (interior architecture, non-body sensory channels,
character-rooted specificity) work identically across genres.

**What gets loaded into the slot:**

For **any project where heat applies** — defined as romance genre
selected at Q1 OR `romance_subplot: yes` selected at Q3 — load the
relevant section of `heat-calibration.md` filtered to the chapter's
rated Spice band:

```
{heat_level_calibration} =
  HEAT LEVEL: Spice {N} (per Architect chapter brief)
  Project-level heat band: {Sweet/Clean | Mild Spice | Open Door}

  {Universal calibration block from heat-calibration.md,
   filtered to the matching band — Sweet/Clean (0-1),
   Mild Spice (2), or Open Door (3-5).}

  Calibration self-check (run before submitting the chapter):
  {The five-question self-check from heat-calibration.md.}

  Genre-specific overlay (if the active genre file declares one):
  {Any genre-specific calibration overlay layered on top of the
   universal block — e.g. how thriller pacing interacts with
   romance subplot heat, how historical period restraint shapes
   sensory cues at higher Spice. SUPPLEMENTS the universal block,
   never overrides it.}
```

For **projects where heat does not apply** — non-romance genre AND
`romance_subplot: no` — the slot is filled with a one-line stub:

```
{heat_level_calibration} =
  HEAT LEVEL: not applicable to this project
  (no romance subplot, non-romance genre — chemistry-cue
  calibration does not apply).
```

**Why this slot is separate from `{genre_writer_craft_rules}`:**

The genre file is a content snapshot — every cue, imperative,
forbidden phrase. The Writer reads it as a single block. Heat
calibration must override the default chemistry cues at the top
of the prompt's instruction stack so it conditions every later
rule. Inlining it inside `{genre_writer_craft_rules}` would leave
it as one section among many, easy for the model to lose during a
long chapter generation. Promoting it to its own slot, with
INSTRUCTION HIERARCHY rule 4 referring back to it, gives heat
calibration the same priority weight as continuity, knowledge
state, and author directives.

**Why genre-agnostic (and not loaded from the genre file):**

Heat level is a property of the PROJECT, not the genre. A user
writing a thriller at Spice:0 with a romance subplot needs the
same Sweet/Clean calibration cues as a contemporary romance at
Spice:0. Inlining calibration in each genre file would (a)
duplicate ~250 lines across every genre that touches romance, (b)
create drift between copies as the calibration evolves, and (c)
leave thriller / fantasy / sci-fi authors writing romance subplots
without calibration unless every relevant genre file is updated.

The universal file solves all three: one source of truth,
consistent behaviour everywhere romance content appears, and
extensions automatically apply to every genre on the next prompt
assembly.

## Context Scoping (Token Efficiency)

The Writer receives only the entities needed for THIS chapter. Context scoping
is performed by the pipeline before assembling the prompt:

1. **Characters:** Include ONLY characters who appear in the Architect's chapter
   brief (CHARACTERS PRESENT fields across all scenes). If the brief references
   a character by relationship ("her mother"), include that character's profile too.
2. **Locations:** Include ONLY locations listed in the brief's LOCATION fields.
3. **Summaries:** Last 3 chapter summaries in full. Earlier chapters as one-line
   precis only. This prevents summary bloat on long novels (a 40-chapter novel
   would otherwise carry 39 full summaries into chapter 40).
4. **Canon rules:** Only rules relevant to the active entities and locations.

**Exception:** For the FIRST chapter and the FINAL chapter, load the full entity
database. The first chapter establishes everything; the final chapter may
reference any element for resolution.

**Why this matters:** A 25-character novel wastes ~70% of entity tokens on
characters not in the current scene. Scoping reclaims those tokens for the
prose quality that matters — deeper interiority, richer sensory detail, and
more precise dialogue.

## User Prompt Template

```
═══ OPENING HARD CONSTRAINTS (READ FIRST — ZERO TOLERANCE) ═══
{opening_hard_constraints — loaded from engine-data/running-banlist.md at
 the HARD CONSTRAINTS section. These are patterns the Humaniser and Batch
 Editor have flagged in previous chapters enough times to be promoted to
 HARD CONSTRAINT status. Treat every listed pattern as a zero-tolerance
 ban: zero occurrences allowed in this chapter.

 DO NOT skim. DO NOT dismiss. DO NOT rely on your own judgement about
 whether a use is "justified" — if the pattern is on this list, it does
 not appear in this chapter, full stop. These bans were learned from the
 actual drift in earlier chapters of THIS manuscript.

 If the file does not exist (first 2 chapters of the manuscript) or has
 no promoted entries, this block is empty and writing proceeds normally.}
═══ END OPENING HARD CONSTRAINTS ═══

═══ ENTITY CANON (HARD LOCK — NO INVENTED NAMES) ═══
{entity_canon — loaded from engine-data/entity-canon.md. This is the flat,
 authoritative lookup of every character, location, and object in this
 manuscript. EVERY proper noun you write must match one of the Canonical
 Name or Aliases cells below — no inventing, no substituting, no
 "near-enough" variants.

 If the scene calls for a character and the form "Dad" is in the aliases
 column of "Matthew Hale", you may write Dad. You may NOT write "Mark"
 unless Mark is explicitly listed as an alias of Matthew Hale. Same for
 every other entity — locations, objects, institutions, pets, ships,
 anything with a proper name.

 If the brief introduces an entity you cannot find in this table, STOP:
 the Architect should have added it to NEW ENTITIES PENDING APPROVAL
 before this point, and the user should have approved it before you ran.
 A missing-from-canon entity in the brief is a protocol failure — alert
 the user instead of guessing a name.

 This block is injected verbatim from engine-data/entity-canon.md every
 chapter. Do NOT paraphrase it. Do NOT summarise it. The table IS the
 authority.}
═══ END ENTITY CANON ═══

STORY BIBLE EXCERPT:
{story_bible — first 2000 chars for context}

CHARACTER BIBLE (scoped to this chapter):
{entity_characters — full entries ONLY for characters listed in the Architect's
 brief CHARACTERS PRESENT fields, plus any indirectly referenced characters}

LOCATION BIBLE (scoped to this chapter):
{entity_locations — entries ONLY for locations listed in the brief's LOCATION fields}

PREVIOUS CHAPTER SUMMARIES (for continuity):
{last 3 chapter summaries in full; earlier chapters as one-line precis each}

LAST CHAPTER ENDING (for seamless continuation):
{last 500 words of previous chapter}

POV VOICE PROFILE (MANDATORY — load for ALL manuscripts, single or multi-POV):
{pov_voice_profile — full profile for THIS chapter's POV character from Story Bible Section 3.
 This is your voice contract. Every paragraph must sound like THIS character's
 narration — not a generic narrator. Use their vocabulary range, sentence rhythm,
 perception filter, metaphor sources, and emotional processing style.
 The test: if a reader opened to a random page, could they identify the POV
 character WITHOUT reading the character's name? If not, the voice is too generic.
 For single-POV manuscripts: the voice profile ensures consistency across the
 entire novel — preventing voice drift in later chapters where the model's
 "memory" of the established voice may weaken.
 For multi-POV manuscripts: each chapter must sound distinctly like its narrator.
 Cross-reference the Voice Contrast Summary in the profile to ensure no two
 POV characters converge toward the same narration style.}

═══ CHAPTER BRIEF (YOUR CONTRACT) ═══
{full architect brief for this chapter — with the IDEORIX:AUDIT
 footer stripped (see note below)}
═══ END BRIEF ═══

**IDEORIX:AUDIT footer stripping (when loading the brief file):**
The brief file on disk contains an `<!-- IDEORIX:AUDIT:BEGIN v1 -->` /
`<!-- IDEORIX:AUDIT:END -->` footer produced by the Outline Conformance
Agent at step 5a. When the pre-load step 6a loads the brief to inject
into this Writer prompt at the `{full architect brief}` slot, the
content BETWEEN the markers (inclusive) MUST be stripped first. The
Writer sees only the pure brief content — not the audit footer. The
audit is for the user's review at step 6, not for the Writer's
execution context.

Strip regex (or equivalent):
```
<!-- IDEORIX:AUDIT:BEGIN v\d+ -->.*?<!-- IDEORIX:AUDIT:END -->
```
(greedy across newlines, version-tolerant)

SCENE WORD BUDGETS (from Architect):
{scene_word_budgets — extracted from the brief's Section 8}

Write each scene to its budget (±15% per-scene variance acceptable, but the
chapter TOTAL must hit {words_per_chapter_internal} words ±10%). If a scene runs short,
expand the NEXT scene — do not let the chapter drift under target.

PER-SCENE WORD COUNT SELF-CHECK (MANDATORY):
After completing each scene, estimate your word count for that scene. If you
are below 80% of the scene budget, EXPAND THE SCENE BEFORE MOVING ON. Add
dialogue exchanges, interiority beats, sensory grounding, or physical business
from the Architect's dramatization notes. Do NOT leave expansion for a later
pass — the compression happens during initial writing and compounds scene by scene.

Use the Architect's DRAMATIZATION NOTES for each scene to fill the budget:
dialogue exchanges, interiority beats, sensory grounding, physical business,
and environmental texture. These are not optional suggestions — they are your
word-budget plan.

{word_count_history_if_running_short}

Write Chapter {chapter_number}: "{chapter_title}"

Execute the brief above. Follow every scene, beat, and emotional arc exactly.
Your craft decisions (imagery, rhythm, dialogue style) are yours — but the
WHAT of the story follows the brief.

Output ONLY the chapter prose. No commentary, no notes, no meta-text, no
post-delivery summary of what was written. Start with the chapter heading,
then the prose. The chapter file is the deliverable; do not narrate what
you just produced.

FICTIONAL-FRAME RULE (CRITICAL — ZERO TOLERANCE):
NEVER reference chapter numbers inside the story. Characters do not know
they are in a book. Narration does not know it is narration. The words
"chapter," "Chapter Four," "in the previous chapter," "by Chapter Five,"
"earlier in this chapter" must NEVER appear in prose, dialogue, or
internal monologue. When referencing earlier events, use the EVENT itself:
- WRONG: "As we learned in Chapter Four, the toxin was lethal."
- RIGHT: "The toxin had killed Phyllis within ninety minutes."
- WRONG: "By Chapter Five, Sarah had grown suspicious."
- RIGHT: "Sarah had grown suspicious since the flask disappeared."
This also applies to: "Part One," "Part Two," "the previous section,"
"as mentioned earlier," "the reader will recall," "as noted above."
The story exists inside its own world. The manuscript structure does not.
```

## Adaptation Mode (screenplay → novel)

**If `engine-data/project-config.md` contains
`adaptation_mode: screenplay_adaptation`, load
`screenplay-expansion.md` before generating prose.** That file
specifies the Writer's expansion licence and hard locks when adapting
a Fountain screenplay:

- **Faithful plot, new prose.** Every plot event, decision, and beat
  traces to the source screenplay. The Writer expands interiority,
  sensory environment, dialogue craft, transitional prose, and
  subtext — not plot.
- The brief's SOURCE MATERIAL section contains the screenplay scenes
  mapped to this chapter. The EXPANSION TARGETS section specifies
  what to add and what ratios to hit.
- Dialogue handling policy (`verbatim | natural | paraphrase`) is in
  project-config.md. Under `verbatim`, every scripted line appears
  in prose exactly as written; parentheticals become action beats or
  descriptive tags around the dialogue.
- The Writer may NOT invent plot, new characters, new locations, or
  new Chekhov's guns. The Entity Canon (loaded via step 6a) contains
  only the screenplay's cast — any name not on the canon is
  mechanical drift that the Continuity Guardian will catch.

The normal Writer protocol below still applies —
screenplay-expansion.md layers on top, it does not replace. Read the
full rules in that file before producing prose.

## Running Banlist (Opening Hard Constraints — MANDATORY pre-load)

The Writer has ONE feedback loop that ACTUALLY shapes future chapters: the
Running Banlist. This is the file the Writer reads at the top of every
chapter's prompt as OPENING HARD CONSTRAINTS — not buried in feed-forward,
not in the footer, not in the Architect's notes. The banlist is the first
thing the Writer sees.

**Why this exists (production failure):** In a real manuscript run, Ch12
and Ch13 both needed the same surgical fixes applied chapter-after-chapter:
em dashes in narration, "the way [pronoun]" overuse, "the kind of" despite
the universal ban. The Humaniser flagged the patterns. The Batch Editor's
feed-forward "notes" mentioned them. But the Writer never actually
internalised them because "feed-forward notes" are advisory context — they
do not dominate attention the way opening hard constraints do. The fix
burden recurred chapter after chapter.

The Running Banlist solves this by moving the most-recurring patterns out
of advisory feed-forward and into an opening hard-constraint block that
the Writer sees before Story Bible, before Character Bible, before voice
profile, before the chapter brief. It is the FIRST block of every Writer
prompt from Chapter 3 onwards.

### File location

`Ideorix-Projects/[Title]/engine-data/running-banlist.md`

### File format

```markdown
# Running Banlist — {Title}
Last updated: Chapter {N}

## HARD CONSTRAINTS — load at top of every Writer prompt (zero tolerance)

These patterns have been flagged by the Humaniser in 2+ consecutive chapters
OR by the Batch Editor across a 5-chapter batch. They are promoted to HARD
CONSTRAINT status: zero occurrences permitted in any future chapter.

| Pattern | First flagged | Chapters where flagged | Promotion trigger | Rule |
|---------|---------------|------------------------|-------------------|------|
| Em dash in narration | Ch12 | Ch12, Ch13 | 2 consecutive chapters | ZERO per chapter, all narration — interrupted dialogue exception still applies (max 3/chapter in dialogue only) |
| "the way [pronoun]" | Ch10 | Ch10, Ch12, Ch13 | 3 chapters in rolling window | ZERO per chapter. Restructure: name the specific gesture, expression, or action directly |
| "the kind of" + analytical tail | Ch12 | Ch12, Ch13 | 2 consecutive chapters | ZERO per chapter. Pick one concrete detail instead of the analytical tail |

## WATCHLIST — flagged once, not yet promoted

These were flagged in the most recent chapter but have not recurred.
They are NOT opening hard constraints yet. The Writer should still treat
them with elevated caution; if they appear in the next chapter, they get
promoted to HARD CONSTRAINTS on the next banlist update.

| Pattern | Flagged in | Severity | Note |
|---------|-----------|----------|------|
| {pattern} | Ch{N} | {level} | {one-line note} |

## RETIRED CONSTRAINTS

Patterns that were on HARD CONSTRAINTS but have been absent for 5+
consecutive chapters. They remain retired unless they reappear.

| Pattern | Retired after | Reappeared? |
|---------|---------------|-------------|
| {pattern} | Ch{N} | No |
```

### Promotion rules (enforced by the Humaniser)

1. **First occurrence in a chapter** → add to the Humaniser report only,
   do NOT add to the banlist. One-off occurrences are noise, not drift.
2. **Second occurrence in the very next chapter (consecutive)** → promote
   to HARD CONSTRAINTS immediately. Two-in-a-row is a recurring drift
   signal, not a coincidence.
3. **Third occurrence within a 5-chapter rolling window (non-consecutive)**
   → promote to HARD CONSTRAINTS. Drift can hop chapters.
4. **WATCHLIST entries** are patterns flagged once that haven't yet met
   the promotion threshold — they appear in the banlist as advisory but
   do NOT enter the opening hard-constraint block. If the pattern appears
   again in the next chapter, promote immediately.

### Retirement rules

A HARD CONSTRAINT is retired (removed from the opening block, moved to
RETIRED) only after 5 consecutive chapters with zero occurrences of that
pattern. Retirement is NOT automatic at 5 chapters — the Humaniser must
confirm zero occurrences across all 5 before writing the retirement. If
the pattern reappears in any chapter after retirement, promotion is
immediate (one-strike, not two).

### Writer pre-load protocol (MANDATORY)

Before generating prose for Chapter N, the Writer pipeline MUST:

1. Read `engine-data/running-banlist.md` with the Read tool
2. Extract ONLY the HARD CONSTRAINTS section (not WATCHLIST, not RETIRED)
3. Inject it verbatim into the Writer's User Prompt Template at the
   `{opening_hard_constraints}` slot — which is the FIRST block of the
   prompt, before STORY BIBLE EXCERPT
4. If the file does not exist (Chapters 1 and 2 of a new manuscript), the
   slot is empty and a single-line placeholder is used: "No recurring
   patterns promoted yet — universal forbidden-words.md rules still apply."
5. The Writer prompt must physically contain the extracted HARD CONSTRAINTS
   text. Do NOT summarise it. Do NOT paraphrase. The Writer reads verbatim.

### What the Writer must NOT do

- Argue with an entry because "that specific use feels justified"
- Interpret "zero tolerance" as "minimise where possible"
- Substitute the user's craft judgment for the banlist (the banlist IS the
  user's craft judgment — it came from the surgical fixes the user had
  to apply chapter after chapter)
- Skip pre-loading the file because "Ch14 looks like a lean chapter, this
  won't be an issue" — the pre-load is unconditional

### Integration points

- **Humaniser** (`prose-humaniser.md`) — updates the banlist after every
  chapter; owns the promotion and retirement rules
- **Batch Editor** (`batch-editor.md`) — its feed-forward findings feed
  into the banlist instead of into loose "negative constraints for the
  Writer" language
- **Pipeline checkpoint** — tracks `Banlist Loaded: Yes/No` as a field
  per chapter, enforcing that the pre-load actually ran

## Post-Writing Checks

**IMPORTANT: Most mechanical checks are now handled by bash scripts at step 9a
(`ideorix-audit.sh`). The Writer's post-writing checks below are a quick
self-audit BEFORE the chapter is saved to disk. The scripts run AFTER save
and produce exact counts that supersede these estimates.**

After the Writer produces output, run these checks IN ORDER. Check 1 is BLOCKING —
do NOT proceed to other checks until word count is resolved.

### CHECK 1: WORD COUNT (MANDATORY, BLOCKING — resolve before ANY other check)

Count the chapter's total words. Compare to the INTERNAL target (10% above
published tier). This is mechanical — no judgement.

```
WORD COUNT RESULT:
- Internal target:  {words_per_chapter_internal} words
- Published target: {words_per_chapter} words
- Actual:           {actual_count} words
- % of internal:    {percentage}%
- % of published:   {percentage_of_published}%
- Verdict:          {PASS / SOFT MISS / HARD MISS / SEVERE MISS}
```

The verdict is based on the INTERNAL target. A chapter at 90% of internal
target still delivers ~99% of the published target — which is what the user
expects. Display the published target percentage in the dashboard so the
user sees their chapter meeting or exceeding the advertised length.

**PASS (≥90% of target):** Proceed to Check 2.

**SOFT MISS (90-99% of target):**
- Accept the chapter but log the shortfall
- If 3+ consecutive chapters are soft misses, escalate the NEXT chapter to Hard Miss
  treatment (add the word count reminder to the Writer's system prompt)

**HARD MISS (80-89% of target) — REJECT:**
- Do NOT proceed. Do NOT move to any other check.
- Re-prompt the Writer with the SAME brief plus this injected into the system prompt:
  ```
  CRITICAL: Your previous attempt was {actual_words} words — {shortfall}% below the
  {target} word minimum. You MUST hit {target} words this time. Expand scenes with:
  sensory detail, character interaction, physical business during dialogue,
  environmental texture, and internal observation. Do NOT pad with exposition or
  philosophical reflection. Use the Architect's DRAMATIZATION NOTES to fill the budget.
  ```
- Maximum 2 retries. If the third attempt is still a Hard Miss, escalate to Severe Miss.

**SEVERE MISS (below 80% of target) — REJECT AND ESCALATE:**
- Do NOT proceed. Do NOT retry with the same brief.
- Return to the Architect and request a brief expansion:
  ```
  The Writer consistently produces under-length chapters. Chapter {chapter_number}
  produced only {actual_words} words against a {target} target after {retry_count}
  attempts. Please add one additional scene OR expand existing scene descriptions
  with more dramatization notes to provide enough material for {target}+ words.
  ```
- **The expanded brief MUST go through the full approval cycle:**
  1. Run the Outline Conformance Agent (step 5a) on the expanded brief
     — the expansion may have introduced unauthorised additions,
     displaced beats, or proposed implicit Chekhov guns
  2. Present the expanded brief to the user at step 6 (User Review Gate)
     — the user approved the ORIGINAL brief, not this expanded version
  3. Only after user approval, re-run the Writer with the expanded brief
  Do NOT bypass the OC Agent or User Review Gate on re-expanded briefs.
  The user has the right to reject the expansion and accept the shorter
  chapter, request a different expansion, or adjust the word count target.

### CHECK 1B: PER-SCENE WORD COUNTS

Identify scene breaks and compare each scene's actual word count against the
Architect's scene budget.
- Flag any scene below 70% of its budget — this is the primary cause of chapter-level underruns
- If the chapter passed Check 1 overall but individual scenes are severely short,
  note which scenes need expansion for the next retry or for the Prose Craft Improver

### CHECK 2: No placeholders — no [brackets], no "TBD", no "insert scene here"
### CHECK 3: No meta-text or fictional-frame leaks
- No "Chapter summary:", no author notes leaked into prose
- No chapter-number references in narration or dialogue ("in Chapter Four,"
  "by Chapter Five," "the previous chapter," "Part One")
- No reader-addressing language ("the reader will recall," "as mentioned earlier,"
  "as noted above," "as we saw")
- Search the chapter text for the words "chapter," "Chapter," "Part," "section"
  inside prose (outside the heading). Any match is a frame leak — fix immediately.
### CHECK 4: No AI-ism markers — quick scan for robotic patterns:
   - "A sense of..." / "There was something about..."
   - "Something about [person/place]..." / "The weight of [abstraction]"
   - "Little did they know..." / "Unbeknownst to..."
   - "The air was thick with..." / "A shiver ran down..."
   - "Found herself [verb]ing" / "Couldn't help but [verb]"
   - "The kind of [X] that [Y]" / "As though" (excessive frequency)
   - Philosophical wrap-up paragraphs
   - Triple-beat lists ("the warmth, the comfort, the safety")
   - Repeated character verbal tics (same phrase >2 times)
   - Stage-direction atmosphere: comma-chained sensory catalogues with analytical
     commentary ("the particular...", "the kind of X that...", "that specific quality where...")

If AI-ism markers found, note them for the Prose Humaniser pass.

### CHECK 5: Number-7 bias check (MANDATORY, mechanical) — Scan the chapter for all numbers:
   - Times (e.g., "5:47", "7:19", "seven-fifteen")
   - Ages (e.g., "thirty-seven", "47 years old")
   - Addresses, quantities, dates, durations, prices
   - Count how many end in the digit 7 (including spelled-out: "seven", "seventeen", "twenty-seven")
   - Per-chapter threshold: If >25% of numbers end in 7, replace enough to achieve roughly even distribution
   - Manuscript-wide threshold: Track cumulative count in pipeline checkpoint. If manuscript-wide
     total exceeds 15% ending in 7, actively avoid 7-ending numbers in subsequent chapters.
   - Also flag any time where the HOUR is 7 (e.g., "7:19") — these recur frequently
   - Report: "Numbers found: {count}, ending in 7: {count} ({percentage}%). Manuscript running total: {ms_count}/{ms_total} ({ms_percentage}%)"

### CHECK 6: Cast registry check — For any NEW named character introduced in this chapter
   (a character not in the entity database):
   - Check the character's surname against ALL existing character surnames in entities.md
   - Check the character's first name against ALL existing character first names
   - If a surname collision is found: generate an alternative surname before saving
   - If a first name collision creates confusion: flag for the user
   - Add the new character to the entity database with role "minor/introduced Ch{N}"
   - Report: "New characters: {list} — surname check: {pass/collision detected}"

### CHECK 7: Triple-beat list enforcement (MANDATORY, mechanical) — Scan the chapter for
   three-element lists that follow the pattern "the X, the Y, the Z" or
   "X, Y, and Z" where all three elements are abstract nouns, emotions, or
   thematic concepts:
   - Examples to catch: "the warmth, the comfort, the safety" / "hope, fear,
     and determination" / "strength, resilience, and grace"
   - Concrete/physical lists are FINE: "a hammer, two nails, and a tape measure"
   - The test: if all three items are abstract/emotional, it's a triple-beat list
   - **Per-chapter limit: 1** (one is a stylistic choice, two is a tic)
   - **Per-manuscript limit: 3** (check humaniser-tracker.md for running total)
   - If over limit: rewrite the list as a specific concrete image or a single
     precise word that replaces the three vague ones
   - Report: "Triple-beat lists found: {count} — manuscript total: {total}/{limit}"

### CHECK 8: Philosophical ending prevention (MANDATORY, mechanical) — After writing the
   chapter, inspect the FINAL PARAGRAPH only:
   - Does the final paragraph contain a general observation about life, truth,
     humanity, existence, meaning, the nature of [anything], or how the world works?
   - Does it use phrases like "perhaps that was", "in the end", "some things",
     "there are moments when", "what it means to", "the truth was"?
   - Does it zoom OUT from the scene to make a thematic statement?
   - If YES to any: REWRITE the final paragraph to end on one of these:
     a) A specific physical action by a character
     b) A line of dialogue (with no narrative commentary after it)
     c) A concrete sensory detail grounded in the scene
   - The chapter's last sentence must be CONCRETE, not ABSTRACT
   - Report: "Final paragraph check: {pass/rewritten} — ending type: {action/dialogue/sensory}"

## Writer's Guardrail Checklist (MANDATORY — run per scene, DURING writing)

This checklist is the Writer's real-time quality filter. Unlike the Post-Writing
Checks (which run AFTER the chapter is complete), this checklist runs IN THE
WRITER'S HEAD as each scene is being generated. It prevents errors at the point
of creation rather than catching them after the fact.

**Why this exists:** Post-writing verification catches errors, but fixing them
costs a revision pass. The cheapest fix is the one that never needed to happen.
In testing, 60% of verification issues (showing vs telling, POV breaks, missing
sensory detail) were preventable if the Writer had checked mid-scene.

### Universal Guardrails (every scene, every genre)

```
BEFORE writing each scene, verify:
□ STAKES — Can I state what's at risk in one sentence? If not, clarify with the brief.
□ CONFLICT — What resistance exists? If none, the scene needs a complication.
□ SCENE GOAL — What does the POV character want in this scene? (Not a plot goal — a scene goal.)

DURING each scene, monitor:
□ EMOTIONS ARE PHYSICAL — Am I naming emotions ("she felt angry") or showing them
  ("she set the glass down hard enough to crack the stem")? If naming: rewrite the line.
□ POV LOCK — Have I described anything the POV character can't perceive? Other characters'
  internal states? Information they don't have? If yes: delete or filter through observation.
□ POV VOICE (multi-POV only) — Does this paragraph sound like THIS character's narration?
  Check against the voice profile: vocabulary, sentence rhythm, perception filter, metaphor
  sources. If it could belong to any POV character, it's too generic — rewrite with this
  character's specific markers.
□ DIALOGUE DOES 2+ THINGS — Does every line of dialogue advance plot AND reveal character,
  or build tension AND establish relationship? If a line only delivers information: rewrite.
□ SENSORY DETAIL — Have I included at least one non-visual sense (smell, touch, taste, sound)
  in this scene? If all details are visual: add one.
□ WORD BUDGET — Am I roughly on pace for this scene's word budget? If a scene feels thin,
  expand NOW with physical business, interiority, or sensory grounding from the brief's
  dramatization notes. Do not leave expansion for later.
□ FORBIDDEN PHRASES — Am I about to write "a sense of", "couldn't help but", "something
  about", "the weight of", "in that moment"? STOP. Rewrite with a concrete specific.

AFTER each scene, quick-check:
□ MATERIAL CHANGE — Did something change in the physical world during this scene?
  (Object moved, document found, door locked, relationship shifted, resource gained/lost.)
  If nothing changed: the scene may be static — add a material consequence.
□ EXIT MOMENTUM — Does this scene end with forward pull into the next? A question raised,
  a decision pending, a threat unresolved?
□ BEAT DELIVERY — Did this scene serve the beat assigned by the Architect's brief?
```

### Genre-Specific Guardrails

Load additional guardrail items from the active genre bank file. Each genre defines
2-5 genre-critical checks. Examples:

- **Mystery/Crime:** "Have I revealed only what the detective knows at this point?
  Is the killer getting equal narrative treatment as other suspects?"
- **Romance:** "Is the romantic tension advancing through action/proximity, not
  just internal monologue? Does this scene shift the relationship dynamic?"
- **Thriller:** "Is tension escalating from the previous scene? Are stakes concrete?"
- **Fantasy:** "Am I showing magic through its effects, not explaining its rules?"
- **Literary:** "Is theme emerging through action, not through narrator commentary?"
- **Horror:** "Am I building dread through specific sensory detail, not naming fear?"

The genre bank's `Writer Craft Rules` section contains the genre-specific items.
The Writer should mentally reference these alongside the universal guardrails.

---

## Word Count Enforcement Protocol

**The reject/retry logic is defined in CHECK 1 above.** This section covers the
persistent tracking that supports it.

**Persistent Shortfall Protocol:**
- Maintain a running average of actual vs target word counts across all chapters
- Track in `Ideorix-Projects/[Title]/engine-data/word-count-log.md`:
  ```markdown
  # Word Count Log — {Title}
  | Ch | Target | Actual | % | Verdict | Retries |
  |----|--------|--------|---|---------|---------|
  | 1  | 2500   | 2380   | 95% | PASS | 0 |
  | 2  | 2500   | 2210   | 88% | HARD MISS → PASS (retry 1) | 1 |
  Running average: {avg}% of target
  Consecutive soft misses: {count}
  ```
- If the running average across 5+ chapters falls below 95% of target, add a
  permanent word count reminder to the Writer's system prompt for ALL remaining chapters:
  ```
  WORD COUNT REMINDER: Chapters in this manuscript have been running short
  (average: {running_avg} words vs {target} target). Your minimum for this
  chapter is {target} words. Err on the side of longer, not shorter. Expand
  scenes with physical detail, sensory texture, and character interaction.
  ```
- If 3+ consecutive soft misses: escalate the next chapter to Hard Miss treatment
  (inject the CRITICAL word count instruction into the system prompt proactively)

**Why this is blocking:** In the cozy mystery test run, 90% of chapters were under
the 2,000-word minimum (average: 1,595 words). The enforcement protocol existed but
was not applied — the engine accepted short chapters without counting. CHECK 1 now
requires a mechanical word count before any other check runs, and REJECT is the
default for chapters below 90% after repeated soft misses.

## Chapter Summary Generation

Immediately after writing each chapter, generate a summary:

```
Summarise Chapter {chapter_number} in 3-5 sentences.
Focus on: key events, character decisions, information revealed,
emotional state changes, and any clues/foreshadowing planted.
This summary will be fed to subsequent chapter generation for continuity.
Do NOT include interpretation or analysis — only facts from the chapter.
```

Write summary to: `Ideorix-Projects/[Title]/engine-data/summaries/ch{NN}-summary.md`

## Output

Write chapter to: `Ideorix-Projects/[Title]/engine-data/chapters/ch{NN}.md`

Format:
```markdown
# Chapter {N}: {Title}

[Chapter prose here]
```

### File Output Discipline

Write chapter to: `engine-data/chapters/ch{NN}.md` — exactly this
filename (two digits, no title/stage suffix). **NEVER append `-draft`,
`-final`, `-humanised`, `-v2`, or any other suffix.** The file is
`ch01.md`, not `ch01-draft.md`. A `-draft` suffix is a hard error
that hides the chapter from the user. Verify with Bash ls after Write.
Only `chapters/ch{NN}.md` exists — no intermediate files on disk.

**Path enforcement (MANDATORY):** The chapter MUST be written to
`engine-data/chapters/ch{NN}.md`. NEVER write to `manuscript/`,
`manuscript/chapters/`, or the `engine-data/` root. The `manuscript/`
folder is for user-facing `.docx` deliverables at Phase 6 only.
If `engine-data/chapters/` does not exist, create it before writing.

**Post-write integrity check (MANDATORY):** After writing the
chapter file, run `scripts/word-count-check.sh` against it as a
self-check before declaring the chapter complete. The script
verifies word count vs target, terminal punctuation (catches mid-
word truncation from any large-Edit / chained-Edit issues), and
null bytes. If the check fails, the chapter is truncated or
corrupt — re-write or alert the user; do not mark the chapter
written. See `core-pipeline.md` "Chained-Edit Truncation
Safeguard" for the full mitigation pattern (prefer Write over
chained Edit for full-chapter rewrites; cap individual Edit
replacements at ~2 KB; never declare complete on the basis of
the Edit tool's success return alone).

## Anti-Patterns (NEVER do these)

- **Deviating from the brief** — If you think the brief is wrong, flag it; don't silently change it
- **Opening with a temporal marker** — "Monday morning arrived with..." / "The rain came on Thursday..." — Start with ACTION, not calendar. Time can be established in the second or third sentence, never the first.
- **Opening with weather as atmosphere** — Weather can appear early but not as the first clause. Lead with character action in that weather: "She pulled her collar up against the wind" not "The wind was cold that morning"
- **Using "morning" in the first sentence** — Maximum 4 chapters per manuscript can open with "morning" in the first sentence. Check the opening type tracker before writing.
- **Repeating the previous chapter's opening structure** — If the last chapter opened with dialogue, this one must not. Consult the Architect's opening type specification.
- **Opening with waking up** — Unless the brief specifically calls for it
- **Recap paragraphs** — Never summarise what happened in previous chapters
- **Telling emotions** — "She felt sad" → Show the physical manifestation
- **Exposition dumps** — Weave information into action and dialogue
- **Identical sentence structures** — Vary length and construction
- **Placeholder dialogue** — Every line of dialogue must do at least two things (advance plot + reveal character, or build tension + establish relationship)
- **Numbers ending in 7** — LLMs default to 7 for "random" numbers. Actively distribute across all ending digits for ages, times, dates, quantities, addresses, durations
- **Philosophical wrap-up paragraphs** — NEVER end a chapter with a general observation about life, truth, or human nature. End with action, dialogue, or a specific concrete detail.
- **Stage-direction atmosphere** — NEVER write long, comma-chained sensory descriptions that catalogue an environment and then editorialize about it ("the hotel lobby smelled of carpet cleaner and filter coffee and the particular neutral fragrance that hotels use when they want to smell like nothing at all"). Pick ONE detail filtered through the POV character's mood. Cut the analytical tail ("the kind of X that...", "the particular...", "that specific quality where..."). The character is living in the scene, not describing a film set.
