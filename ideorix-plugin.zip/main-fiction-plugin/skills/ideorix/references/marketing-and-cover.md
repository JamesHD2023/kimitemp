---
name: marketing-and-cover
description: "Generate cover concepts, blurbs, Amazon descriptions, social media packs, and book trailers"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Marketing & Cover Design

Create everything you need to market and sell your book.

## File Location Discipline (MANDATORY)

**All marketing and cover deliverables — cover concepts and
image prompts, blurbs, Amazon descriptions, social media
packs, query letters, audience analysis, keyword sets, video
trailer assets — MUST be written into the canonical project
folder at `~/Documents/Ideorix-Projects/[Title]/marketing/`.**
If no project folder exists when this flow is invoked directly,
run the project-folder bootstrap (ask for project title /
confirm save location / create the canonical folder structure)
BEFORE generating any deliverable. See `core-pipeline.md`
§ File Location Discipline for the canonical layout and the
Bash-Direct Write + Verify protocol. **HARD GATE — BLOCKING.**
Marketing deliverables MUST resolve to local files the user
can open in their own file explorer.

## Available services

### Cover Designer
Genre-researched cover concepts with AI image prompts for **five user-selectable platforms** — pick one or more during Phase 0a (Cover Inputs Selection) and the engine emits prompt-blocks ONLY for the platforms you picked:

- **Ideogram** — Best text rendering; covers with title/subtitle text baked in
- **Grok Aurora** — Free, fast iteration via X; atmospheric and mood-driven concepts
- **Claude Design** — Design-native iteration at `claude.ai/design`; layered text + image with full typographic control (research preview — Pro / Max / Team / Enterprise subscribers)
- **Leonardo.ai** — Style consistency across iterations; illustrated/painterly aesthetic (fantasy, romance, YA, MG)
- **Midjourney** — Highest visual quality for final-production imagery (image-only — text added afterwards in Canva)

Phase 0a also collects subtitle (Yes / No / Create-for-me) and tagline (Yes / No / Create-for-me) — selections persist to `project-config.md` so Book 2+ in a series inherits the choices automatically. For full specs see `cover-designer.md`.

### Marketing Expert

Ten material types across four categories. For full specs see `marketing-expert.md`.

| Category | Material |
|----------|----------|
| Retail Copy | Amazon Description, Back-Cover Blurb, Keywords & Categories |
| Pitching | Elevator Pitch, Query Letter, Comparison Titles |
| Digital Marketing | Social Media Pack, Email Newsletter, Press Release |
| Strategy & Analysis | Target Audience Analysis |

Tone options: hooky / commercial, character-driven / literary, atmospheric, urgent, witty, emotional.

**Canonical for content generation.** Amazon Description, Keywords & Categories, and Comparison Titles are generated here and then bundled into the KDP companion document at export — see `export-and-publish.md` for the KDP Package structure.

### Video Trailer Designer
Scene-by-scene storyboards with AI video prompts for:
- Sora, Runway, Pika, Luma, Kling

## How to start

Say any of:
- "Design a cover for my book"
- "Write a blurb"
- "Create an Amazon description"
- "Generate social media posts"
- "Write a query letter"
- "Create a book trailer storyboard"
- "Run the full marketing suite"

> **Tip:** These tools work best after your manuscript is complete, but you can generate preliminary marketing materials from your Story Bible alone.
