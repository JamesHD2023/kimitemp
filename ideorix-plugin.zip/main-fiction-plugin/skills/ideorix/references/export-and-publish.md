---
name: export-and-publish
description: "Format your manuscript for publishing — DOCX export, KDP metadata, and submission-ready files"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Export & Publish

Prepare your finished manuscript for publication or submission.

## File Location Discipline (MANDATORY — HARD GATE — applies to every output this flow produces)

**All Phase 6 deliverables MUST be written into the
canonical project folder structure.** Specifically:

- **Manuscript exports** (DOCX, Atticus DOCX, EPUB, PDF,
  RTF, Markdown, SMF, Fountain, FDX) →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.{ext}`
- **KDP metadata** →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-kdp-metadata.{ext}`
- **Marketing assets** (cover concepts, blurbs, social
  pack, query letters, trailer assets) →
  `~/Documents/Ideorix-Projects/[Title]/marketing/...`
- **Editorial / verification reports** generated during
  Phase 6 →
  `~/Documents/Ideorix-Projects/[Title]/engine-data/reports/...`

See `core-pipeline.md` § File Location Discipline for the
full canonical project layout.

**HARD GATE — BLOCKING.** Outputs MUST NOT be written to:

- The agent's working directory
- The parent `~/Documents/Ideorix-Projects/` folder (the
  most common bug — files end up alongside other projects
  instead of inside this project's subfolder, making them
  effectively invisible to the user when looking in the
  project folder)
- A sandbox or temporary path
- Any non-canonical location

The user MUST be able to open every Phase 6 deliverable
in their own file explorer at the canonical project
subfolder the moment processing completes. The Phase 6
Delivery flow has historically been vulnerable to dropping
manuscript exports in the parent `Ideorix-Projects/`
folder rather than the project's `[Title]/manuscript/`
subfolder; this section is the explicit counter-protocol.

When invoking any of the per-format specs below
(`format-docx.md`, `format-epub.md`, etc.), this
File Location Discipline binds them — each format spec
also reiterates its specific destination, but THIS gate
is the authoritative one and supersedes any ambiguity.

## Typography Sweep Gate (MANDATORY — HARD GATE — runs before every prose export)

Before assembling the final manuscript file (DOCX, EPUB, PDF,
SMF, RTF, Markdown, Atticus DOCX), run the pre-export typography
gate against the project. The gate wraps `typography-sweep.sh`
with fail-closed semantics + opt-out handling (v2.7.68+):

```sh
bash scripts/pre-export-typography-gate.sh "{project-root}"
```

When invoked without a specific file, the gate scans every
`engine-data/chapters/ch*.md` automatically. To gate a single
file (per-chapter export), pass the file path as a second arg.

**HARD GATE — BLOCKING.** If the gate fails:

1. Halt the export flow.
2. Report the per-chapter artifact list to the user.
3. Wait for resolution (user normalizes, or explicitly opts-in
   to ASCII target via `--target ascii` re-run).
4. Re-run the gate before proceeding.

**Rationale:** the engine's Edit-tool typographic-fidelity
discipline (`core-pipeline.md` § Edit-Tool Typographic Fidelity)
is preventive — it stops curly-vs-ASCII mismatches from being
inserted during normal Edits. The sweep is the detective layer:
even if an artifact slips through (paste-in, importer, partial
Edit, manual user touch-up), the sweep catches it before any
publishable file is assembled. See `typography-sweep.md` for
the full spec, exit codes, and category list.

**Skipped only when:**

- The user has explicitly declared ASCII typography for the
  manuscript (rare — typically technical / programming books
  with heavy code blocks). In that case the gate runs with
  `--target ascii` and inverts.
- The output format is intentionally raw text without typography
  enforcement (e.g. Fountain screenplay, where Courier-style
  ASCII is the format convention — Fountain exports skip this
  gate and route to their own format spec).

## Available formats

| Format | Use case |
|--------|----------|
| **DOCX** | Industry-standard manuscript format (Shunn-style) with proper margins, headers, page breaks |
| **EPUB 3.3/3.2** | Universal vendor-independent e-book format for all major retailers |
| **PDF** | Print-ready with proper pagination and trim sizes |
| **Fountain** | Screenplay format — plain-text markup compatible with Final Draft, Highland, Fade In |
| **Markdown** | Clean plain text for version control and editing |
| **SMF** | Standard Manuscript Format for agent/publisher submission |
| **RTF** | Rich Text Format for maximum compatibility |
| **KDP Metadata** | Amazon Kindle Direct Publishing — title, subtitle, description, keywords, BISAC categories |
| **Query Package** | Query letter + synopsis + sample chapters for agent submissions |

For full format specifications, see `publishing-formats.md`.

## How to start

Say any of:
- "Export my manuscript as DOCX"
- "Generate KDP metadata"
- "Prepare my book for Amazon"
- "Create a query package"
- "Format for submission"

## What gets generated

### DOCX Export

**How — MANDATORY (v2.7.127):** run the canonical renderer. Do **NOT** hand-write
a DOCX generation script, do **NOT** create one with the Write tool, and do
**NOT** `pip`/`npm install` any docx package:

```bash
bash scripts/manuscript-render.sh "{project-root}"
```

It auto-selects **pandoc** or the bundled **Python-stdlib renderer** (zero
external dependencies), **self-heals NULL-byte-padded chapters** (stripping +
reporting them), defaults output to `manuscript/{Title}.docx`, and runs
`docx-integrity-check.sh` on the result. Only if it reports BOTH pandoc *and*
python3 absent — essentially never — fall back to the patterns in
`format-docx.md` (written bash-direct, never via the Write tool).

**What it produces:**
- Title page with author name and word count
- Properly formatted chapter headings
- Standard manuscript margins (1 inch)
- Double-spaced, 12pt Times New Roman / Courier
- Page headers with author name and title

### KDP Package
- Book title and subtitle suggestions
- HTML-formatted book description
- 7 keyword phrases (optimized for Amazon search)
- BISAC category recommendations
- Pricing tier suggestion based on word count

> **Tip:** Always run the editorial pipeline before exporting. Clean prose makes a better first impression.

## Launch Readiness Gate (MANDATORY — v2.7.68+)

Before declaring the project ready to ship — KDP upload, cover
generation, marketing campaign — run the launch readiness gate.
It chains all five constituent Phase 6 gates and reports a single
composite verdict:

```bash
bash scripts/launch-readiness-gate.sh "{project-root}"
```

Constituents (each fails closed independently):
- **Market Scout** — market-pulse.md present + fresh
- **Cover Brief** — structured cover brief per cover-designer.md
- **Marketing Pack** — marketing-brief.docx + 5 core sections + cover dependency
- **KDP Metadata** — KDP file present + required fields + 7 keywords
- **Manuscript Export** — at least one rendered manuscript file in `manuscript/`

If the composite FAILs, re-run each failing constituent gate
directly for its specific diagnostic + ACTION instructions. The
launch readiness gate is the composite check; the constituent
scripts have the prescriptive fixes.

This is the v2.7.68 fix for the Phase 6 LLM-contract gap: cover
+ marketing + KDP + launch were rules Claude was supposed to
follow but nothing verified at the artifact level. The five new
gates make every step a verifiable precondition rather than a
disciplined-Claude assumption.

Opt-outs: `launch_readiness_status: legacy / skip` in
`engine-data/project-config.md`.
