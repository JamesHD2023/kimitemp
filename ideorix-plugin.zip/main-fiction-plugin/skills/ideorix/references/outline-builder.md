---
name: outline-builder
description: "Genre-adaptive interactive outline builder — generates concept seeds, character bios, world design, and fully labeled chapter outlines for any genre"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Outline Builder Protocol

## Purpose

Guide the user through an interactive, step-by-step process to develop a story
concept into a fully detailed chapter outline. This protocol adapts to ANY genre
by loading genre-specific conventions from the genre bank and applying genre-aware
question sets, structure templates, and tracking tables.

## When It Runs

- During Phase 1 (Interactive Setup), Question 9: "Outline Source"
- When the user selects **"Generate one for me"** or **"Help me develop a concept"**
- Can also be triggered directly: "outline a book", "help me outline", "build an outline"

## Core Principles

- **One step at a time**: Complete each step fully, present the output, and WAIT
  for user feedback before moving on.
- **Source material first**: If the user has provided worldbuilding files,
  character profiles, voice guides, sample scenes, or any reference documents,
  READ THEM ALL IN FULL before generating anything. See Step 0 below.
- **Genre-adaptive**: Load the genre bank file for the selected genre and adapt
  every step to genre conventions. A thriller outline needs revelation maps and
  pressure tracking. A cozy fantasy needs comfort indexing and growth ladders. A
  romance needs relationship arc mapping. The protocol detects what's needed.
- **Mash-up aware**: If the active project uses a 2- or 3-genre mash-up (see
  `project-config.md` for `Mash-up: yes`), the Outline Builder loads every
  active genre's bank file and runs the matching question sets, architecture
  modules, tracking tables, and chapter field templates for ALL of them — not
  just the Primary. See "Multi-Genre (Mash-Up) Handling" below for the exact rules.
- **Detail-oriented outlines**: Every chapter entry includes genre-appropriate tags,
  beat tracking, character dynamics, and tone markers.
- **Execute, don't rewrite**: When the user has provided character profiles,
  world rules, or voice guides, you are EXECUTING their vision, not improving
  it. Do not add arcs, motivations, traits, or backstory the user hasn't
  specified. Do not flatten complex characters into simpler ones (warm →
  brooding, charismatic → observational). Do not project psychological
  frameworks onto established personalities ("survivor's guilt" when the user
  never wrote survivor's guilt). The user's source material is canon — treat
  it with the same authority as a Story Bible.
- **Fresh and original**: All names, places, and titles must follow
  `authenticity-guard.md` and `forbidden-words.md`. No AI-default patterns.

## Multi-Genre (Mash-Up) Handling

Check `engine-data/project-config.md` at the start of every Outline Builder run.
If it contains `Mash-up: yes`, read the Primary, Secondary, and Tertiary genre
IDs from the config and load every genre bank file. Then apply these rules to
every step below:

### Step 1 — Genre-Specific Preference Gathering (mash-up)

Run the universal questions (U1 Story Length, U2 Trope Selection) once.

For the genre-adaptive questions, run the question set from EACH active
genre's family — Primary first, then Secondary, then Tertiary. De-dupe
identical questions across families (e.g., if Thriller and Mystery both
ask about POV structure, ask it once).

Example — a Cozy Mystery (Primary) + Fantasy (Secondary) mash-up runs:
- Q-T1..T6 from the Thriller/Suspense/Mystery set (adjusted for cozy)
- Q-F1..F5 from the Fantasy/Sci-Fi set
- Annotated as: "These questions shape the Cozy Mystery spine. The next
  ones shape the Fantasy layer."

### Step 3 — Concept Seeds (mash-up)

Generate 5 concepts that genuinely fuse all active genres. Each seed must:
- Satisfy the Primary's core reader promise
- Fold in at least ONE distinctive element from each Secondary/Tertiary
- Not read as "Primary with Secondary bolted on" — the fusion must be
  integral to the premise

### Step 9 — Genre-Specific Architecture (mash-up)

Run the architecture module for EACH active genre's family (not just
Primary). For a Cozy Mystery + Fantasy mash-up, build:
- **Revelation Map** (from the Thriller/Mystery module)
- **Growth Ladder** (from the Fantasy module, if progression applies)
- **Bond Progression Arc** (from the Fantasy module, if ensemble)

The Primary's architecture takes precedence on structural conflicts
(act boundaries, climax shape). Secondary/Tertiary architectures become
overlay arcs that thread through the Primary's acts.

### Step 10 — Chapter Outline (mash-up)

The chapter outline uses the Primary's act structure. Every chapter entry
includes the universal fields PLUS the genre-adaptive fields from EVERY
active genre family. For Cozy Mystery + Fantasy:

- Universal fields (Chapter Number, Title, POV, Summary, Tone, Goal,
  Complication, Decision, Stakes Escalation)
- Mystery fields (Clue planted, Red herring active, Suspect spotlight,
  Investigation progress, Information Withheld)
- Fantasy fields (Scene Type Tags, Growth Beat, Party Dynamic Beat)

Don't omit fields. A reader expecting both genres notices when one is
shortchanged.

### Step 10 — Tracking Tables (mash-up)

Generate all tracking tables from every active genre family. For Cozy
Mystery + Fantasy, generate both the Revelation Schedule AND the Growth
Ladder AND the Comfort Index (if cozy-fantasy level comfort is intended).

### Step 11 — Ending Options (mash-up)

Present 3 endings that satisfy ALL active genres simultaneously. Do NOT
mix options from different genres' ending menus — instead, construct
hybrid endings. For example, a Thriller + Romance mash-up generates:
1. Clean resolution + HEA
2. Ambiguous justice + HFN
3. Final reversal + Bittersweet HEA

### Mash-up output delivery

The final outline document's front matter should state the active genre
stack explicitly, so downstream agents and the user can see what rules
shaped the outline:

```
# {Title} — Outline
Genre Stack:
  Primary: {Primary}
  Secondary: {Secondary} (optional)
  Tertiary: {Tertiary} (optional)
```

## Names & Places Rules

ALL generated content must follow `authenticity-guard.md`. Additionally:

- Load the genre bank file's `## Names & Patterns to Avoid` section for
  genre-specific avoidance rules
- Use real-world naming conventions appropriate to the setting and characters
- Avoid formulaic naming patterns (no "[Dark Word]+[Suffix]", no
  "[Nature]+[Landscape]", no apostrophe fantasy names)
- Specificity makes stories feel real — real neighbourhoods, actual job titles,
  names that match the character's background

## Number & Time Diversity (Anti-7 Bias)

Actively avoid defaulting to 7 for ages, quantities, chapter counts, levels,
prices, dates, addresses, or any other number. Distribute across all ending digits.

---

## Workflow

### Step 0: Source Material Absorption (MANDATORY — HARD GATE — when user provides material)

**Trigger Detection (MECHANICAL, not discretionary):**

Run the following checks at the start of every Outline Builder
invocation, BEFORE any other step:

```bash
ls -la ~/Documents/Ideorix-Projects/{Title}/source-canon/ 2>/dev/null
grep -E "^architect_mode:|^import_source:" ~/Documents/Ideorix-Projects/{Title}/engine-data/project-config.md 2>/dev/null
```

If `source-canon/` exists with files, **OR** if
`project-config.md` contains `architect_mode: true` or
`import_source: <novelcrafter|plottr|scrivener|screenplay>`,
Step 0 is structurally required. Additionally, Step 0 is
required when ANY of the following is true:

- The user has uploaded or pasted worldbuilding documents in
  this conversation
- The user has uploaded or pasted character profiles or
  character sheets
- The user has provided a voice guide or sample scenes
- The user has an existing outline, synopsis, or plot summary
- The user has mentioned "I have notes", "I've already built
  the world", "use my worldbuilding", "I have my characters",
  "bring my own canon", "Architect mode", or any equivalent
  phrasing
- The user invoked the BYO-canon entry point (see
  `byo-canon.md`)
- The project was imported from another writing tool
  (Novelcrafter / Plottr / Scrivener / Screenplay — see
  `import-project.md`); the importer sets
  `architect_mode: true` and `import_source:` in
  `project-config.md` precisely so this trigger fires
- Any reference files are present in the project's
  `source-canon/`, `manuscript/`, or `engine-data/` folders
  that pre-date the Outline Builder run

**If the user has provided NO source material** (no
`source-canon/` folder, no uploaded / pasted material, no
mention of pre-existing canon — starting from a genuinely
blank concept), skip Step 0 and proceed directly to Step 1.
But verify the absence mechanically — do not assume "no
canon" without checking.

**This gate is BLOCKING.** Step 1 (and every subsequent step)
MUST NOT execute until Step 0 has either (a) completed in
full with confirmed canon-constraints checklist, or (b) been
verified-skippable because no source material exists.

**This step exists because of a documented production
failure mode** — and this trigger detection is mechanical
because the failure mode previously slipped through when
the trigger was discretionary. The engine's own post-mortem
from a real production session, quoted as evidence:
*"I drafted before I actually absorbed the canon. I read
the worldbuilding files only after you told me to."* This
step exists to make that failure impossible.

**Execution:**

1. **Identify all source files.** Scan the project folder and the
   conversation for uploaded documents, pasted content, or referenced
   files. List them: "I see the following source material: [list].
   Is there anything else I should read before we begin?"

2. **Read every file in full.** Not skimming. Not summarising from
   filenames. Full content read using the Read tool. If a file is
   large, read it in sections — but read ALL of it. The engine's own
   post-mortem from a production failure: *"I drafted before I
   actually absorbed the canon. I read the worldbuilding files only
   after you told me to."* This step exists to make that impossible.

3. **Extract canon constraints** as a structured checklist. For each
   category, pull VERBATIM descriptions from the user's material:

   **Characters (for each named character):**
   - Name (canonical form + any aliases)
   - Personality: verbatim traits from the user's profile — do NOT
     paraphrase, simplify, or reinterpret. If the user wrote "quick
     to laugh, fills silences comfortably," the constraint is THOSE
     WORDS, not "warm and sociable."
   - Voice/speech patterns (if specified)
   - Physical description (if specified)
   - Relationships to other characters
   - Arc notes (if the user has specified an arc)
   - What this character is NOT: any explicit negatives the user has
     stated ("not brooding", "never cruel", "doesn't do X")

   **World rules:**
   - Setting (geography, era, social structure)
   - Magic/technology/power systems (rules, limits, costs)
   - Factions, institutions, political structures
   - Hard world constraints ("no teleportation", "magic has a cost",
     "the wall cannot be crossed")
   - Cultural details (food, dress, language, customs)

   **Locked scenes/beats:**
   - Any scenes the user has pre-written or described as must-include
   - For each: what happens, who is present, what the scene
     accomplishes narratively
   - NOTE: Locked scenes are GOALS the outline must build toward,
     not ANCHORS the outline slots in. The outline must construct a
     narrative that makes each locked scene feel earned and inevitable
     — not a greatest-hits album connected by summary.

   **Voice guide (if provided):**
   - POV type and tense
   - Prose register (vocabulary level, sentence architecture)
   - What the voice IS and ISN'T
   - Sample passages: what each one demonstrates (don't use them as
     plot tentpoles — they're STYLE references, not structural ones)

   **Tone constraints:**
   - What the book IS (e.g., "warm", "tense", "literary", "cosy")
   - What the book ISN'T (e.g., "not grimdark", "not YA", "no camp")

4. **Present the extracted constraints to the user.** Display the
   full checklist: "Before I start building the outline, here's what
   I understand about your world, characters, and voice. Please
   confirm or correct anything."

5. **Wait for user confirmation.** Use AskUserQuestion with options:
   "Confirmed — proceed to outline", "Corrections needed" (user
   specifies), "Add more material" (user has additional files).

6. **Lock the confirmed constraints.** They become HARD RAILS for
   every subsequent step. The Outline Builder CANNOT:
   - Change a character's personality from the confirmed profile
   - Violate a world rule the user has established
   - Skip or underserve a locked scene/beat
   - Adopt a prose register inconsistent with the voice guide
   - Add arcs, motivations, or psychological frameworks the user
     hasn't specified

   If at any point during Steps 1-11 the Outline Builder finds a
   conflict between its outline design and a confirmed constraint,
   it STOPS and surfaces the conflict to the user: "The outline I'm
   building would require [X], but your world rules say [Y]. Which
   takes priority?" The user decides. The engine does not silently
   override.

7. **Set the Architect mode flag (v2.7.0+).** Write the
   following entry to `engine-data/project-config.md`:

   ```markdown
   architect_mode: true
   architect_mode_set_at: {ISO 8601 timestamp}
   architect_mode_source: step-0-canon-absorption
   ```

   Every downstream stage reads this flag and applies its
   Architect-mode binding:
   - Outline Builder Step 9.5 (Must-Exist Scenes Anchor) and
     Step 10 (scene-first construction) — see
     `must-exist-scenes.md`
   - Architect agent (`blueprint-protocol.md`) — locked scenes
     immutable, character profiles immutable, no psychology
     projection, conflicts surface to user
   - Writer agent (`prose-protocol.md`) — voice guide
     authoritative, character voice immutable, samples
     calibrate not anchor, MUST-EXIST chapters deliver
     locked scenes verbatim
   - Quality Guardian (`quality-gate.md`) — flags canon drift
     (character flattening, voice drift, world-rule
     violation, psychology projection, locked-scene
     substitution, connective-chapter collapse,
     sample-as-plot-tentpole)

   When `architect_mode: false` (or unset — Creator mode),
   downstream agents operate without these bindings.

### Anti-Rewriting Rule (applies from Step 0 through Step 11)

When the user has provided source material, the Outline Builder's
role changes from CREATOR to ARCHITECT. The distinction:

- **Creator mode** (no source material): invent characters, build
  world, design plot from genre conventions. Full creative latitude.
- **Architect mode** (source material provided): design a plot that
  SERVES the user's characters, world, and voice. The user has
  already done the creative work on who these people are and what
  this world is. The engine's job is structural: how to arrange
  their story for maximum dramatic effect within the constraints
  they've established.

**Specific anti-rewriting rules:**

1. **Do not flatten characters.** If the user wrote a warm,
   charismatic character, the outline must sustain that warmth
   across 30 chapters. "Brooding and observational" is easier to
   outline — but it's not the user's character. Sustain the
   difficulty.

2. **Do not add psychology.** "Survivor's guilt", "misread
   self-image", "unprocessed trauma" — unless the user specified
   these, do not project them. The user knows their character
   better than the engine does.

3. **Do not use sample scenes as structural tentpoles.** If the
   user provided 8 sample passages in a voice guide, those are
   PROSE EXAMPLES, not plot points. Build a story that might
   produce scenes with that quality — don't reverse-engineer a
   plot from the sample scenes.

4. **Dramatise, don't summarise.** If the antagonist is a threat,
   the outline must design scenes where the reader FEELS the
   threat — on-page pressure, not reported rumour. "Dorian is
   mentioned in notices for 24 chapters" is summary. "Dorian's
   scouts are visible from the ridgeline in Ch 3, and in Ch 8 his
   mark is carved into the door of a village they passed through
   yesterday" is dramatisation.

5. **Build relationships brick by brick.** If a relationship arc
   needs 30 chapters, design 30 chapters' worth of incremental
   moments — not 2 quiet scenes and a kiss. Each chapter should
   advance the relationship by ONE SPECIFIC BEAT that the reader
   can name.

---

### Step 1: Genre-Specific Preference Gathering

The outline builder asks genre-specific questions using AskUserQuestion, ONE AT A TIME.

**Universal Questions (all genres):**

#### Question U1: Story Length

**"How long should this book be?"**

Options:
- "Short Story (~8,000 words, 5 chapters, ~1,600 words/chapter)"
- "Novelette (~12,500 words, 9 chapters, ~1,400 words/chapter)"
- "Novella (~40,000 words, 16 chapters, ~2,500 words/chapter)"
- "Standard Novel (~75,000 words, 30 chapters, ~2,500 words/chapter)"
- "Epic Novel (~120,000 words, 40 chapters, ~3,000 words/chapter)"

**Novelette suitability note:** If the user selects Novelette, check the genre. Novelette length
works well for cozy mystery, romance, literary, horror, noir, and contemporary genres. It is
NOT well-suited to epic fantasy, space opera, historical epic, family saga, or any genre that
needs extensive worldbuilding or a large cast. If the genre is a poor fit, warn the user and
suggest Novella or longer before proceeding.

#### Question U2: Trope Selection

**"Which tropes do you want to build around? (Pick 2–5)"**

Present genre-relevant tropes from `trope-library.md`, filtered by the selected
genre. If trope selection already happened in Phase 1, skip this question and
carry the selections forward.

#### Question U3: Narrative Tense

**"What tense should the story be told in?"** Ask once, like POV — it sets a
contract the whole book must honour. Pre-select the genre norm.

Options:
- "Past tense, immediate (recommended for most genres) — deep POV, the
  character lives it now, no narrator looking back"
- "Present tense — maximum immediacy (common in YA / dark romance; can tire
  past ~40k words)"
- "Past tense, literary — immediate, craft-forward prose (literary / upmarket)"
- "Past tense, retrospective — a narrator looking back, with hindsight and
  foreshadowing permitted (epic fantasy, memoir-style, coming-of-age)"

Record the choice in the Story Bible as `Narrative tense` + `Tense contract`
(`world-canon.md` §3). The contract is **immediate** for present /
past-immediate / past-literary (no foreshadowing, no "if she'd only known"),
and **retrospective** for the look-back mode. Future tense is offered only for
brief passages, never a whole book. See `narrative-tense.md` for genre fit and
the full contract; `scripts/tense-contract-scan.sh` checks it (WARN-level).

#### Step 1b: Trope Twister (after trope selection)

After the user selects their tropes, offer twist options for each one.
Twisting tropes adds freshness without abandoning reader expectations —
the reader still gets what they came for, but delivered in an unexpected
way.

**Prompt to user:**

```
You've selected these tropes:
1. {Trope A}
2. {Trope B}
3. {Trope C}

For each trope, I can suggest three unexpected twists that still satisfy
reader expectations. Twisting even one trope can make your story stand
out in a crowded genre. Want to see the twist options?

  A. Show me twist options for all selected tropes
  B. Show me twist options for just the top trope
  C. Play all tropes straight — no twists
```

**If the user selects A or B, generate 3 twists per trope:**

For each trope, produce three subversion options. Each twist must:
- Still satisfy the core reader promise of that trope (an Enemies to
  Lovers twist must still deliver a love story; a Closed Community
  twist must still deliver isolation-driven tension)
- Be genuinely surprising — not just a timing shift ("they fall in
  love earlier") but a structural or perspective reframe
- Be implementable within the selected genre and length tier

**Format per trope:**

```
TROPE: {Trope Name}
Reader promise: {one sentence — what readers expect from this trope}

  Twist 1: {name}
  {2-3 sentences explaining the twist and how it changes the story}

  Twist 2: {name}
  {2-3 sentences}

  Twist 3: {name}
  {2-3 sentences}

Which twist (1/2/3), or play this trope straight?
```

**After the user chooses** (twist or straight for each trope), record
the decisions. They feed into:
- Step 3 (Concept Seeds) — concepts must incorporate selected twists
- The trope-plan.md output — delivery schedule reflects twist timing
- The Story Bible Section 10 (Trope Integration) — twist noted
- The Architect's brief-time trope targets — each chapter's trope
  delivery instructions reflect the twist

**If the user selects C (all straight):** Skip this step entirely.
Playing tropes straight is a valid choice, especially in genres where
readers want comfort and familiarity (cozy mystery, cozy fantasy,
category romance).

---

**Genre-Adaptive Questions:**

After the universal questions, ask genre-specific questions based on the loaded
genre bank file. Below are the question templates for major genre families.
For genres not listed, derive questions from the genre bank file's conventions.

#### Thriller / Suspense / Mystery Family

**Q-T1: Subgenre Flavour**
"What kind of [genre] are we building?"
— Options derived from genre bank (e.g., psychological, domestic, legal, techno, espionage)

**Q-T2: Protagonist Type**
"Who is your protagonist?"
— Options: Ordinary person in extraordinary situation / Professional under pressure /
  The outsider-investigator / The flawed expert / The victim who fights back /
  Dual protagonists / The antihero / Custom

**Q-T3: POV Structure**
"How should we handle point of view?"
— Single first-person / Single third-person close / Dual POV / Multiple POV / Mixed

**Q-T4: Reversal Complexity**
"How many major reversals should the story have?"
— One major reversal / Two-layer (mid-book + final) / Puzzle-box (multiple) / None

**Q-T5: Pacing Style**
"What's the pacing feel?"
— Slow burn / Relentless / Ratcheting (pressure–release cycles) / Dual timeline

**Q-T6: Time Pressure**
"Is there a deadline driving the story?"
— Literal deadline / Escalating pattern / Soft pressure / No time element

#### Romance Family

**Q-R1: Romance Model**
"What's the romance structure?"
— Single couple, full arc / Love triangle / Second chance / Dual POV romance

**Q-R2: Heat Level**
(Skip if already answered in Phase 1)
— Sweet/Clean / Mild Spice / Open Door

**Q-R3: Central Obstacle**
"What keeps them apart?"
— External circumstances / Internal fears / Misunderstanding / Social/cultural barriers / Past hurt / Rivalry

#### Fantasy / Sci-Fi Family

**Q-F1: World Complexity**
"How deep should the world-building go?"
— Light touch (world serves the story) / Moderate (world is a character) / Deep (world-building is a draw)

**Q-F2: Power/Progression**
"Does the protagonist grow in power or ability?"
— Yes, structured progression / Yes, organic growth / No significant power growth

**Q-F3: Party/Ensemble**
"Is this a solo journey or a party/ensemble?"
— Solo protagonist / Small party (2–4) / Full ensemble (5+) / Shifting alliances

**Q-F4: Core Activity** (for cozy/slice-of-life subgenres)
"What does your protagonist mainly do?"
— Adventuring / Crafting-alchemy / Shopkeeping / Farming / Cooking / Monster bonding / Exploring / Mix

**Q-F5: Companion Creature** (for applicable subgenres)
"Should the protagonist have a companion creature?"
— Yes, as a main character with personality / No

#### Horror / Gothic Family

**Q-H1: Horror Style**
"What kind of fear?"
— Psychological / Supernatural / Body horror / Cosmic / Gothic atmosphere / Survival

**Q-H2: Protagonist Fate**
"How dark can the ending go?"
— Triumphant survival / Pyrrhic victory / Ambiguous / Bleak

#### Literary / Contemporary Family

**Q-L1: Structural Approach**
"How should the story be structured?"
— Linear chronological / Non-linear / Fragmented-mosaic / Frame narrative / Epistolary

**Q-L2: Emotional Core**
"What's the emotional centre of this story?"
— User describes (free text via AskUserQuestion "Other" option)

---

### Step 2: Market Pulse Research

Load `market-scout.md` and run Market Scout with context: **"setup"**.

Market Scout handles all web search, analysis, and report generation. It produces
a structured Market Scout Report with demand vs. saturation, trending tropes,
emerging themes, reader expectations, comp titles, and strategic positioning.

The setup context adapter emphasises trending tropes and reader expectations,
and presents trending tropes as selectable options via AskUserQuestion (multiSelect).

Selected insights are carried forward and injected into the concept seed
generation (Step 3) and the genre architecture (Step 9).

See `market-scout.md` for the full protocol, report format, and fallback behaviour.

---

### Step 3: Generate 5 Concept Seeds

Generate 5 unique story concepts based on all selections. Each seed must include:

- **Title** (avoiding all forbidden patterns)
- **Premise** (2–3 sentences)
- **Protagonist sketch** (name, role, core tension)
- **Central conflict** (what drives the story)
- **Setting** (grounded and specific)
- **Trope integration** (how selected tropes work together, not just listed)
- **Genre-specific hook** (what makes this compelling for THIS genre's readers)

Make the 5 seeds genuinely diverse — vary settings, character types, tonal range,
and structural approach. Don't generate 5 variations of the same idea.

**Present all 5, use AskUserQuestion to pick one.**

---

### Step 4: Hook and Positioning

Generate:
- **Hook**: One sentence that captures the genre feeling and the story promise.
  A thriller hook should make the reader feel unsafe. A romance hook should create
  longing. A fantasy hook should spark wonder. A horror hook should unsettle.
- **Positioning Statement**: 150–250 words establishing the protagonist, the world,
  the central conflict, and the emotional promise. This is the back-cover pitch.

**Present and wait for feedback.**

---

### Step 5: Protagonist Design

Generate using a genre-adapted character bio. For each field, follow the
instruction in parentheses — these guide what makes each field useful.

```
Name:
  (Use real-world naming conventions for the character's background. Avoid
   AI-default names — see authenticity-guard.md.)
Age:
  (Specific age, not a range. Avoid defaulting to 7-ending numbers.)
Background:
  (Where they came from, what shaped them. Be specific — a job title, a place,
   a defining event. "Teacher" is weak; "burned-out Year 6 teacher who left
   mid-term after a classroom incident" is strong.)
Physical Description:
  (2–3 distinctive details, not a police report. What would a stranger notice
   first? What do they do with their hands? Avoid "piercing eyes" and "chiseled jaw.")
Personality — Surface (how others see them):
  (The mask they wear in public. What would a colleague say about them at a party?)
Personality — Underneath (who they really are):
  (What comes out under pressure, in private, or with people they trust.)
Internal Conflict:
  (The tension between two competing needs or beliefs. This drives character
   decisions throughout the story. Frame as "X vs Y" — e.g., "safety vs honesty"
   or "loyalty to family vs need for independence.")
What They Want:
  (The conscious, stated goal. What they'd tell you if you asked.)
What They Need (that they don't realise):
  (The deeper need the story will force them to confront. Often the opposite
   of what they want — or a prerequisite they've been avoiding.)
Core Flaw (creates complications):
  (Not a weakness — a flaw that actively causes problems in the story.
   "Stubborn" is a trait; "refuses to ask for help even when drowning" is a flaw
   that creates scenes.)
Voice/Speech Patterns:
  (How they talk — sentence length, vocabulary, tics, humour style. A reader
   should be able to identify them from dialogue alone.)
```

**Character Depth Layer (main cast):** the protagonist, co-leads, POV
characters, and primary antagonist also carry the **Character Depth Layer**
(`character-depth.md`) — a specific pre-page-one wound, a "believes X /
under pressure does Y" contradiction, a five-register Physical Tell Register
(mutually distinct across the cast), a Page-One Visual, an observable
final-page state, and (for co-leads) a Relationship Dynamic. Seed it here at
outline time where you can; it is fully authored at Story-Bible time
(`world-canon.md` §4b) and checked by `scripts/character-tell-distinctness.sh`.

**Genre-specific additions:**

| Genre Family | Additional Fields |
|---|---|
| Thriller/Suspense | Blind Spot, Skill Set, Limitation, Under Pressure behaviour |
| Romance | Emotional armour, What they've sworn off, Vulnerability trigger |
| Fantasy/Sci-Fi | Starting ability level, Specialisation, Comfort habits |
| Mystery | Investigative method, Key weakness exploited, What they miss |
| Horror | Coping mechanism, Breaking point, What they refuse to believe |
| Literary | Defining relationship, Central memory, Narrative voice quality |

**Present and ask for feedback.**

---

### Step 6: Antagonist / Opposition Design

**For genres with a clear antagonist** (thriller, mystery, horror, fantasy):

Generate using antagonist bio format with field-level guidance:
```
Name (if known — may be hidden):
  (If the antagonist's identity is a reveal, note "hidden" and give a
   placeholder reference. Avoid AI-default villain names.)
Role/Position:
  (Their place in the story's world — job, social standing, relationship
   to other characters. Specificity makes them real.)
Surface Presentation:
  (How the world sees them. For hidden antagonists, this is the mask they
   wear. Make it convincing — readers should believe it too.)
True Nature:
  (Who they really are when the mask slips. The gap between surface and
   truth is where the tension lives.)
Goal:
  (What they want — stated plainly. Must be specific and achievable, not
   vague menace. "Control the family trust" not "power.")
Method (their specific playbook):
  (HOW they pursue their goal. This should be genre-appropriate and
   detailed enough to generate scenes. "Manipulates through financial
   dependency" creates different scenes than "uses physical intimidation.")
Why They're Formidable:
  (What makes them a genuine threat to THIS protagonist specifically.
   Smarter? Better-resourced? More ruthless? More information? Must
   outmatch the protagonist in at least one critical dimension.)
Connection to Protagonist:
  (Why these two people are in conflict. The stronger the personal
   connection, the higher the emotional stakes.)
Motive (the real why):
  (The human reason behind their actions. Even horrifying motives should
   make psychological sense. "They were never given what they believe they
   deserved" is more useful than "evil.")
Their Flaw (what enables their defeat):
  (The specific weakness, blind spot, or overconfidence that the
   protagonist can exploit. Must be established BEFORE the climax so the
   ending feels earned.)
```

**For thriller/mystery:** Add Information Advantage and Information Vulnerability fields.

**For romance:** Replace with the Obstacle Design — what keeps the couple apart,
why it's genuinely difficult to overcome, and what has to change.

**For literary/contemporary:** Replace with the Central Tension — the situation,
relationship, or internal conflict that drives the narrative.

**Present and ask for feedback.**

---

### Step 7: Supporting Cast

Generate 3–6 supporting character bios appropriate to the genre:

**Universal format with field guidance:**
```
Name:
  (Real-world naming conventions. Each supporting character should have a
   name that's easily distinguishable from every other character — avoid
   names starting with the same letter or sounding similar.)
Role in Story:
  (Their function — ally, mentor, rival, confidant, obstacle, comic relief,
   love interest, red herring. A character can serve multiple roles.)
Relationship to Protagonist:
  (How they know each other and what the dynamic is. "College roommate who
   never forgave the protagonist for moving away" is more useful than "friend.")
Key Personality Traits:
  (2–3 traits that create friction or chemistry with the protagonist. At
   least one trait should generate scenes on its own.)
Brief Backstory:
  (Only what's relevant to the story. What in their past explains their
   behaviour in the present? 2–3 sentences maximum.)
Purpose in Plot:
  (What would break if you removed this character? If the answer is "nothing,"
   they don't belong in the outline. Every character earns their page-time.)
```

**Genre-specific additions:**

| Genre | Additional Cast Elements |
|---|---|
| Thriller/Mystery | Trustworthiness rating, Information they hold, Red herring suspect |
| Romance | Role in couple's dynamic, Whose side they're on, Comedy potential |
| Fantasy | Party role/class, Specialisation, Bond contribution, Friction points |
| Cozy subgenres | Comfort contribution, Community role, Recurring quirk |
| Horror | Survival likelihood, What they know, How they complicate escape |

**For fantasy with party dynamics:** Use the expanded party member format including
trust level at start, friction points, comfort contribution (what they add to cozy
scenes — do they cook? tell stories? hum? whittle? argue about directions? A party
member who only exists in action scenes is half a character), and what they contribute
to downtime scenes.

**For fantasy with companion creatures:** Generate a dedicated companion bio:
```
Species:
  (Not just "cat" — what kind? Magical variant? What makes it distinct?)
Name:
  (How did the protagonist name it? Does it respond to the name?)
Personality:
  (3–4 traits. At least one should be endearing and one should cause problems.)
Communication Style:
  (Full speech? Emotive chirps? Telepathic images? Physical gestures only?)
Wants (that differ from the protagonist):
  (The creature has its own agenda. It wants naps, or shinies, or to hunt, or to
   go somewhere the protagonist doesn't want to go. This creates organic friction
   and comedy — a companion that only wants what the protagonist wants is a prop.)
Opinions About Other Characters:
  (The companion likes, dislikes, or is suspicious of specific cast members. These
   opinions may be hilariously wrong or eerily accurate. They create subplots and
   reveal character indirectly.)
Helpful Abilities:
  (What useful things can it do? Detect magic? Navigate? Calm people?)
Unhelpful Abilities:
  (Things it does that cause problems — attracts predators by glowing, eats
   important ingredients, "helps" by knocking things over, hoards items the
   protagonist needs. These are as important as helpful abilities for generating
   scenes and comedy.)
Annoying Habits:
  (Distinct behavioral tics that the protagonist tolerates because they love it.)
Relationship Arc with Protagonist:
  (How does the bond deepen? What's the trust-building progression? Is there a
   moment where the bond is tested?)
```

**Present and ask for feedback.**

---

### Step 8: World and Setting Design

**Scale adapts to genre:**

- **Thriller/Mystery/Romance/Contemporary:** 4–6 key locations with atmosphere and
  function. Focus on how settings create genre-specific feelings (tension,
  intimacy, unease, warmth).
- **Fantasy/Sci-Fi:** Full world-building section — home base, magic/tech system,
  larger world geography, economic basics, 4–6 key locations.
- **Cozy subgenres:** Heavy emphasis on home base (the shop, farm, tavern) and
  community locations. These are genre requirements, not decoration.
- **Horror/Gothic:** Emphasis on how settings amplify dread. Escape routes (or
  lack of them). Isolation. Atmosphere as character.

**Present and ask for feedback.**

---

### Step 9: Genre-Specific Architecture

This step varies significantly by genre. Run the appropriate module:

#### Thriller/Mystery Module: Revelation Map

Build the information control architecture:

**The Truth:** State the complete truth in 3–5 sentences (who did what, why,
what's really going on). This is the answer the reader works toward.

**Revelation Schedule:**
| Timing | What's Revealed | What It Seems to Mean | What It Actually Means |
|---|---|---|---|
| Act 1 | [initial situation] | [surface reading] | [real significance in hindsight] |
| Midpoint | [mid-book revelation] | [reader recalculates] | [still missing a piece] |
| Act 3 | [final truth] | [everything clicks] | [the real story] |

**Misdirection Strategy:** For each reversal, map what the reader is meant to
believe, what evidence supports the false belief, what contradicts it (hidden in
plain sight), and when the truth emerges.

**Red Herrings:** List each one — what it is, what false conclusion it supports,
when and how it's debunked, the real explanation.

#### Thriller/Mystery Module: Reversal Blueprint

For each planned reversal:
- The reversal (stated clearly)
- 3–5 setup moments that seed it (each must appear in the outline)
- Logic test: "If a reader goes back after this reversal, can they find the
  clues? Does it hold up under scrutiny?" If the answer is no, the reversal
  needs more setup seeded into earlier chapters.
- Emotional impact: What the reader FEELS (betrayal, horror, dread,
  satisfaction, recontextualisation)
- What changes after: How the reversal alters stakes, relationships, or the
  reader's understanding going forward. A reversal that changes nothing is a
  gimmick, not a story beat.

#### Romance Module: Relationship Arc Map

Map the romantic progression:
- First meeting / initial dynamic
- What draws them together (specific, not generic attraction)
- Key relationship milestones (4–6 across the story)
- Central obstacle and how it manifests in specific scenes
- The crisis that tests the relationship
- Resolution path (HEA/HFN)

#### Fantasy Module: Growth Ladder (if progression applies)

Map skill/power growth:
| Stage | Chapter Range | What They Can't Do | Key Failure | Breakthrough | What They Can Do After |
|---|---|---|---|---|---|
| Novice | Ch 1–5 | [specific limitation] | [specific failure scene] | [specific learning] | [specific new ability] |
| ... | ... | ... | ... | ... | ... |

#### Fantasy Module: Bond Progression Arc (if party/ensemble)

Map the group's trust development:
| Phase | Chapters | Trust Level | Key Moment |
|---|---|---|---|
| Strangers | 1–3 | Surface politeness | First meeting |
| Testing | 4–8 | Learning habits | First disagreement |
| Developing | 9–14 | Real conversations | First real argument, asking for help |
| Solid | 15–20+ | Comfortable silence | Showing up without being asked |

Identify: the friction pair, the first shared joke, the moment they become a
team, the moment the protagonist realises these are their people.

#### Horror Module: Dread Architecture

Map the fear progression:
- What's unsettling in Act 1 (subtle wrongness)
- What's frightening in Act 2 (direct threat)
- What's terrifying in Act 3 (full confrontation)
- The source of horror (and when it's revealed vs. left ambiguous)
- Protagonist's psychological deterioration arc (if applicable)

#### Literary Module: Emotional Topography

Map the emotional journey:
- The emotional state at opening
- Key emotional shifts (4–6 across the narrative)
- The central revelation or transformation
- What's different at the end (internally, not just externally)

**Present the genre architecture and ask for feedback.**

---

### Step 9.5: Must-Exist Scenes Anchor (MANDATORY in Architect mode — v2.7.0+)

**Trigger:** Run this step BEFORE Step 10 when Architect mode
is active (i.e., Step 0 has absorbed user-supplied canon and
set the `architect_mode: true` flag in
`engine-data/project-config.md`). In Creator mode (no source
material, engine originates plot), Step 9.5 is skipped — the
existing structural-template Step 10 applies.

**Purpose:** Replace structure-first outline construction with
scene-first outline construction. The user's must-exist
scenes become the SEED for outline construction. Genre
structure templates apply as ACCOMMODATIONS to scene
placement, not as templates the scenes are slotted into.

**Why this step exists:** the user's documented self-diagnosis
captures the failure mode this step prevents — *"I keep
starting from STRUCTURE (30 chapters, alternating POV, act
math, canon samples placed at correct positions) and
retrofitting story into it. Books don't work that way. Books
start from specific images and specific character moments
that must exist, and the structure is whatever accommodates
them."* Step 9.5 inverts the construction order to match
how books actually work.

**Workflow:**

1. **Collect must-exist scenes** from three sources: explicit
   (user's `locked-scenes` file in `source-canon/`), implicit
   (sample scenes flagged as locked, conversation
   references), and solicited (the agent asks: "What scenes /
   images / character moments MUST appear in this manuscript?
   List them in any order — we'll find the structure that
   delivers them.").
2. **For each scene**, capture: description, setting, cast,
   why-it-must-exist, chronological constraint, tonal
   register, required precursors, required consequences.
3. **Collect must-exist character moments** (smaller-scale
   beats: "this character must do X at some point", "the
   relationship must reach this beat by chapter Y").
4. **Collect must-exist images / motifs** (visual /
   thematic anchors).
5. **Validate completeness**: scene count meets threshold
   for length tier (3 for Novelette, 5 for Novella, 8 for
   Standard Novel, 12 for Epic); arc coverage spans
   opening / middle / climax phases (not just one phase);
   chronological / precursor / consequence conflicts
   identified.
6. **Write `engine-data/must-exist-scenes.md`** with the
   structured anchor list.
7. **Present to user for confirmation**: "Here are the
   must-exist scenes I've identified. Is anything missing?
   Is anything in this list a 'nice to have' rather than a
   'must' — let me know so I can distinguish them."
8. **Lock the confirmed list.** Step 10 (Architect mode)
   reads this file and constructs the outline FROM the
   scenes outward.

→ See `must-exist-scenes.md` for the full Step 9.5 protocol,
including the validation thresholds, the structured output
format, and the genre-conflict surfacing pattern.

### Step 10: Detailed Chapter Outline

**Architect mode (v2.7.0+):** when Step 9.5 has produced
`engine-data/must-exist-scenes.md`, Step 10 operates in
**scene-first mode**. The outline is constructed FROM the
must-exist scenes outward, not into a pre-filled structural
template:

- **Phase 10A — Place must-exist scenes** at narratively
  optimal chapter positions (informed by chronological
  constraints, required precursors, required consequences,
  and genre rhythm as accommodation)
- **Phase 10B — Identify connective tissue** between
  consecutive must-exist scenes (setup, consequence,
  character development, world-building scaffolding,
  tension escalation)
- **Phase 10C — Construct connective chapters** as
  PURPOSEFUL chapters with their own complications,
  decisions, escalations, and explicit `Serves: S{N}`
  pointers — NOT summary fillers
- **Phase 10D — Validate genre structure** and surface
  conflicts to user when must-exist scenes don't align
  with genre rhythm (do not silently override)
- **Phase 10E — Generate chapter outline** with two
  Architect-mode additions per chapter:
  - **Chapter Type:** `MUST-EXIST` or `CONNECTIVE`
  - **Serves:** for MUST-EXIST chapters, the scene ID
    served (e.g., "S3"); for CONNECTIVE chapters, the
    scene IDs being set up or followed from (e.g., "Sets
    up S4; follows from S3")

→ See `must-exist-scenes.md` § "Step 10 (REWIRED) — Scene-
First Chapter Outline" for the full scene-first
construction protocol.

**Creator mode (no source material):** the legacy
structure-first Step 10 below applies. The structural
template anchors the outline; chapter-level fields fill in
the details.

Use AskUserQuestion to confirm chapter count (based on chosen length).

Generate the full chapter outline. **Every chapter entry includes:**

**Universal fields (all genres):**
- **Chapter Number & Title**
- **POV Character**
- **Chapter Summary** (3–5 sentences)
- **Chapter Tone**
- **Chapter Goal** (what this chapter must accomplish)
- **Complication** (what goes wrong or creates tension)
- **Character Decision/Choice** (the meaningful choice made)

**Universal additional field (all genres):**
- **Stakes Escalation** — "How are the stakes higher now than before this chapter?"
  This forces escalation accountability per chapter. The answer must be specific
  and concrete — not "things get worse" but "Meg now knows the GP is compromised
  but has no alternative doctor for Poppy." If the stakes haven't escalated, the
  chapter needs a complication that raises them.

**Genre-adaptive fields (added per genre):**

| Genre Family | Additional Chapter Fields |
|---|---|
| Thriller/Suspense | Pressure Level (1–10), Revelation (what reader learns), Information Withheld (what is deliberately kept hidden THIS chapter), Reversal Seed, Time Pressure status |
| Mystery | Clue planted, Red herring active, Suspect spotlight, Investigation progress, Information Withheld |
| Romance | Relationship beat, Intimacy level, Obstacle status, Heat moment |
| Fantasy | Scene Type Tags [Adventure] [Cozy] [Crafting] etc., Growth Beat, Party Dynamic Beat |
| Cozy subgenres | Comfort Element, Comfort Index (% cozy content), Community moment |
| Horror | Fear Level (1–10), Dread source, Safety illusion status, Protagonist mental state, Information Withheld |
| Literary | Emotional register, Thematic resonance, Structural purpose |

### Genre Structure Templates

The outline follows genre-appropriate act structures. Below are the templates:

**Thriller/Suspense/Mystery Structure:**

- **Act 1 (1–20%):** Establish protagonist's world, the disruption, initial
  engagement, first misdirection. Pressure: 3–5, climbing.
- **Act 2A (20–40%):** Situation worse than it seemed, answers spawn bigger
  questions, resources failing. Pressure: 5–7.
- **Midpoint (~50%):** A revelation or escalation that fundamentally alters the
  story. Pressure spikes to 8–9.
- **Act 2B (50–75%):** Protagonist increasingly isolated, walls closing in, the
  key piece found but not yet understood. Pressure: 7–9, relentless.
- **Act 3 (75–100%):** Truth assembled, confrontation, final reversal, maximum
  stakes, resolution. Pressure: 9–10, then release.

**Romance Structure:**

- **Act 1 (1–25%):** Meet-cute or initial encounter, establish attraction and
  obstacle, first meaningful interaction.
- **Act 2A (25–50%):** Growing closer, vulnerability moments, external pressure
  pushing them together or apart.
- **Midpoint (~50%):** Major relationship milestone or reversal.
- **Act 2B (50–75%):** Deepening bond, the obstacle threatens to win, dark moment
  of doubt.
- **Act 3 (75–100%):** Crisis, grand gesture or honest conversation, resolution, HEA/HFN.

**Fantasy Structure:**

- **Act 1 (1–25%):** World establishment through daily life, protagonist's starting
  state, inciting quest. Heavy [Cozy][Home Base] for cozy subgenres.
- **Act 2A (25–50%):** Growth, learning, party forming, first adventure arc.
- **Act 2B (50–75%):** Higher stakes (still proportional), major setback, bonds
  deepen through shared challenge.
- **Act 3 (75–100%):** Big challenge, protagonist demonstrates growth, team
  functions together, warm resolution.

**Horror Structure:**

- **Act 1 (1–25%):** Normality with subtle wrongness. Fear: 2–4.
- **Act 2A (25–50%):** Direct encounters, escalating threat, rational explanations
  failing. Fear: 4–6.
- **Act 2B (50–75%):** Full confrontation with the threat, isolation, allies lost
  or compromised. Fear: 6–8.
- **Act 3 (75–100%):** Climactic confrontation, maximum horror, resolution or
  devastating conclusion. Fear: 8–10.

**Literary/Contemporary Structure:**

- Adapt to the chosen structural approach (linear, non-linear, fragmented, etc.)
- Focus on emotional beats rather than plot escalation
- Each chapter serves a thematic purpose

### Tracking Tables

Generate genre-appropriate tracking tables alongside the outline:

**Thriller/Mystery — Pressure Gauge:**
| Chapter | Pressure (1–10) | Direction | What Drives It |
|---|---|---|---|

**Thriller/Mystery — Revelation Schedule:**
| Chapter | Reader Learns | Reader Doesn't Know | Misdirection Active? |
|---|---|---|---|

**Romance — Relationship Barometer:**
| Chapter | Closeness (1–10) | Key Beat | Obstacle Status |
|---|---|---|---|

**Fantasy — Comfort Index** (cozy subgenres):
| Chapter | Scene Types | Comfort Content? | Growth Beat? |
|---|---|---|---|
Target: 30%+ chapters tagged primarily [Cozy].

**Fantasy — Growth Ladder:**
| Chapter | Skill Level | What Happens | Failure or Success? |
|---|---|---|---|

**Horror — Fear Curve:**
| Chapter | Fear (1–10) | Source | Protagonist State |
|---|---|---|---|

**Present the full outline with tracking tables and ask for feedback.**

---

### Step 11: Ending Options

Generate 3 ending options tailored to genre:

**Thriller/Mystery:**
1. Clean resolution (justice, truth, safety)
2. Ambiguous ending (threat handled but something lingers)
3. Final reversal (last-page revelation that recontextualises the story)

**Romance:**
1. Classic HEA (full commitment, joy, certainty)
2. HFN (together and hopeful, but life continues)
3. Bittersweet HEA (together, but with sacrifice or compromise)

**Fantasy:**
1. Triumphant return (quest complete, home enriched, future bright)
2. Quiet contentment (protagonist at peace with what they've built)
3. Open horizon (satisfied but a new adventure beckons)

**Horror:**
1. Triumphant survival (threat defeated, protagonist changed but alive)
2. Pyrrhic victory (survived, but at great cost)
3. Ambiguous/bleak (the horror is not truly over)

**Literary:**
1. Transformation complete (character fundamentally changed)
2. Ambiguous (the reader decides what it means)
3. Circular (returns to the beginning with new understanding)

**Use AskUserQuestion to pick one.**

---

### Step 12: Series Hooks (if applicable)

If the user indicated this is Book 1 or part of a series:

"Your outline is complete. If you want to plan the full series arc — volume
blueprints, character trajectories across books, and the series spine — the
Series Architect can build that from this outline. Say 'plan the series' to start."

If standalone: Skip this step.

---

### Step 13: Final Delivery

Compile everything into a single outline document:

1. Selected concept with hook and positioning
2. Protagonist bio
3. Antagonist/opposition design
4. Supporting cast bios (including companion creature if applicable)
5. World and setting design
6. Genre-specific architecture (revelation map, relationship arc, growth ladder, etc.)
7. Full chapter outline with tracking tables
8. Selected ending

Save as: `Ideorix-Projects/[Title]/engine-data/outline.md`
Also save: `Ideorix-Projects/[Title]/engine-data/market-pulse.md` (the Market Pulse Report from Step 2)
Also save user-facing version: `Ideorix-Projects/[Title]/manuscript/outline.docx`

### File Output Discipline

The Outline Builder produces exactly THREE files:
1. `engine-data/outline.md` — ALL sections in one file
2. `engine-data/market-pulse.md` — Market Scout report
3. `manuscript/outline.docx` — user-facing version

Do NOT write separate files for concept-seeds, protagonist, antagonist,
supporting-cast, world-setting, genre-architecture, chapter-outline,
ending, hook-positioning, or tension-tracker. All of that content
belongs as SECTIONS inside `outline.md`.

The outline then feeds directly into Phase 2 (Story Bible Generation) — the Story
Bible protocol uses it as the structural foundation.

---

## Integration with Core Pipeline

The Outline Builder is triggered from Phase 1, Question 9 when the user selects
"Generate one for me" or "Help me develop a concept."

After the Outline Builder completes:
1. The outline is saved to `engine-data/outline.md`
2. Phase 1 continues with remaining setup questions (beat structure, Chekhov's Guns)
3. Phase 2 (Story Bible) uses the outline as its structural foundation
4. The Architect agent receives the chapter outline as its starting template

If the user selected "Help me develop a concept," the Outline Builder runs in
collaborative mode — generating options at each step and iterating based on
feedback. If they selected "Generate one for me," it runs in guided mode —
presenting complete outputs at each step with the option to modify.
