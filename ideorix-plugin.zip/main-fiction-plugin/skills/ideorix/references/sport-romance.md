---
name: sport-romance-genre
description: Genre-specific instructions for Sport Romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Sport Romance. Genre Plugin

## Metadata
- id: sport-romance
- name: Sport Romance
- icon: 🏆
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Romancing the Beat", "Save the Cat", "Three-Act Structure", "Seven-Point Structure"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Football/Soccer Romance | Love within professional football. players, coaches, sports journalists | Team dynamics create the ensemble; the season structure provides natural pacing |
| Hockey Romance | Ice hockey setting with its culture of toughness and loyalty | The enforcer-with-a-heart trope dominates; physicality of the sport mirrors physical attraction |
| Baseball Romance | America's pastime as backdrop. minor leagues to majors | The long season creates slow-burn opportunity; small-town minor league settings add charm |
| Boxing/MMA Romance | Combat sports with their intensity, discipline, and physical vulnerability | The fighter's body is both weapon and romantic object; training montages parallel relationship building |
| Racing Romance | Motorsport, horse racing, or cycling. speed and risk as aphrodisiac | The danger of the sport raises stakes; the adrenaline culture attracts sensation-seeking characters |
| Olympic/Elite Sport Romance | Elite athletes whose pursuit of excellence conflicts with love | The sacrifice demanded by elite sport creates the central romantic tension |

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-5,000 words
- Pacing: Athletic intensity alternating with romantic slow-burn\u2014competition builds external tension, emotional vulnerability provides relief and deepening, training montages and game-day urgency drive momentum
- Must open with: Athletic action, training intensity, competitive stakes, or the sport world disrupted by the arrival or return of the love interest
- Must close with: Romantic tension heightened, athletic stakes raised, performance and relationship intersecting, or a revelation that changes both the competitive and emotional landscape

BEATS PER CHAPTER
1. Athletic Action: Training, competition, physical performance, sport-specific detail\u2014the sport is always present
2. Romantic Connection: Chemistry built through proximity, physical awareness, competition, shared passion, or vulnerability exposed by the pressure to perform
3. Competitive Stakes: Season progression, championship approach, career-defining moments, injury threats, team dynamics\u2014the external engine driving urgency
4. Physical Awareness: Athletic bodies in motion, the line between training partner and lover, the intimacy of shared physical exertion, post-workout vulnerability
5. Performance vs. Heart: The internal tension between competitive focus and emotional distraction, between the discipline required to win and the vulnerability required to love

GENRE-SPECIFIC REQUIREMENTS
- The sport MUST be authentic\u2014accurate rules, training methods, competitive structures, physical demands, and culture; fans of the sport will notice errors
- Romance MUST be central\u2014not a sports novel with a love interest tacked on, the emotional engine alongside the competitive engine
- HEA/HFN required\u2014couple together at end, both having grown as people and athletes
- The sport shapes identity\u2014characters are athletes first, and the romance challenges that singular focus
- Physical awareness heightened\u2014athletic bodies are hyper-aware of physicality; attraction built through watching competence, physical proximity during training, the intimacy of athletic partnership
- Competition creates natural structure\u2014season schedules, tournaments, championships, playoffs provide built-in stakes, deadlines, and escalation
- Team dynamics as community\u2014teammates as found family, locker room culture, coaching relationships, team rules about fraternization create both support and obstacles
- Performance pressure mirrors relationship pressure\u2014fear of failure in sport echoes fear of vulnerability in love; choking under pressure in one arena reflects avoidance in the other
- Injury as vulnerability\u2014physical injury strips the athlete's armor, creating space for emotional intimacy; recovery romance is a powerful sub-arc
- Both the romantic arc AND the athletic arc must resolve satisfyingly\u2014love won AND the competition concluded (win or meaningful loss)
- Body as temple and weapon\u2014athletes have complex relationships with their bodies; this must be explored with nuance
- Sacrifice and discipline\u2014the demands of elite sport (diet, training, travel, focus) create real obstacles to romance
- Media and public scrutiny\u2014professional athletes face spotlight pressure that complicates private relationships
- Coach/mentor dynamics\u2014authority figures who affect both athletic and romantic trajectories

FORBIDDEN
- Sport as wallpaper\u2014cowboy hats don't make a western, and a jersey doesn't make a sport romance; the athletic world must be real, detailed, and consequential
- Romance without athletic substance\u2014cannot be a contemporary romance where someone happens to play a sport
- Inaccurate sport detail\u2014wrong rules, impossible plays, unrealistic training, implausible timelines for skill development
- Insta-love without earned respect\u2014attraction may be immediate, but love requires demonstrated character through competition and crisis
- Athlete stereotypes\u2014no dumb jock, no ice queen female athlete, no one-dimensional characters whose only trait is being good at their sport
- Ignoring physical consequences\u2014injuries heal at realistic rates, fatigue accumulates, the body has limits; no miraculous game-day recoveries
- Trivializing the sport\u2014treating competition as merely a setting for romance rather than something the characters genuinely care about with their whole being
- Abusive coaching portrayed as tough love\u2014problematic authority dynamics must be recognized as problems
- Sex scenes that ignore athletic bodies\u2014characters who train for hours daily have specific physicality; intimacy should reflect this
- Single-obstacle stories\u2014layer internal emotional barriers alongside competitive pressure; the championship is the external obstacle, the characters' fear of vulnerability is the internal one
- Relentless intensity without breathing room\u2014even elite athletes have rest days; moments of normalcy, humor, and tenderness between training and competition amplify both the athletic and romantic stakes
- Performance-enhancing drug storylines treated casually\u2014if addressed, handle with genuine complexity
- Love interest who doesn't respect the athlete's dedication\u2014partners must understand and honor what the sport means
- Tragic endings where the injury or loss destroys everything\u2014genre promise is hope; setbacks are temporary, love endures

LIGHT AND SHADE IN SPORT ROMANCE

Emotional contrast is your most powerful tool. After a scene of grueling training or crushing competition\u2014a devastating loss, a career-threatening injury, a public humiliation\u2014allow a moment of surprising warmth: laughter during recovery, tenderness in the training room, the absurdity of ice baths shared with someone you want to impress. After a scene of genuine connection or intimacy, introduce a complication that tests the bond: a rival's return, a coach's ultimatum, an injury scare, the temptation of a career opportunity that means separation. This alternation mirrors the athletic cycle itself\u2014brutal exertion followed by recovery, defeat followed by the determination to try again. Two intense competition scenes back to back exhaust; a loss followed by unexpected comfort creates the emotional whiplash that hooks readers permanently.

OBSTACLE LAYERING

Sport romance has powerful built-in external obstacles (competition pressure, team rules, coach disapproval, injury risk, career demands, media scrutiny, travel schedules), but these alone are not enough for the romance. Layer INTERNAL obstacles that the sport illuminates: the fear that loving someone will compromise competitive edge, the identity crisis of "who am I if I'm not the best?", the vulnerability of letting someone see you fail, the trauma of a career-ending injury threatening to define you. The sport should test the relationship itself\u2014can you love someone who beats you? Can you be vulnerable with someone who sees you at your physical peak? Can you risk your heart when you've been trained to protect your body? The more obstacles between the couple\u2014athletic AND emotional\u2014the more the reader yearns for their connection.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (relationship arc), Stimulation (competition / training intensity), Captivation (sport world).

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-protocol.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE
- POV: Close 3rd limited (both leads in alternating chapters) or 1st person (intimate, visceral athletic experience)
- Tense: Past (traditional romance weight) or present (heightened immediacy of competition and attraction)
- Voice: Physical, visceral, kinetic\u2014the prose of someone who lives in their body, who measures the world in heartbeats and split seconds and the burn of muscles pushed to failure. Precise athletic detail layered with emotional vulnerability.
- Reading level: Adult\u2014authentic sport detail, mature romantic content, emotional complexity beneath competitive exterior

PROSE IMPERATIVES
- Athletic action rendered with visceral specificity. Pick the ONE physical sensation that defines each moment rather than cataloguing every sense. "They played hard" reads false, but so does listing every sound, smell, and ache in one sentence
- Physical awareness between leads built through sport-specific moments\u2014the brush of hands during practice, spotting someone's weight, the charged space between competitors, the way one body reads another's movement
- Competition written with genuine tension\u2014the reader must feel the stakes of the game, the match, the race; stakes must be real even to readers unfamiliar with the sport
- Body described with athlete's intimacy\u2014characters who train constantly have a relationship with their own bodies; they notice muscle, fatigue, capability, limitation; this extends to how they perceive the other person's body
- Training montages as character development\u2014repetition, discipline, incremental improvement, frustration, breakthrough; these scenes reveal character as powerfully as dialogue
- Injury rendered with unflinching specificity\u2014the pop of a ligament, the breathless moment of "is this the end?", the slow grind of rehabilitation; injury is the sport romance's equivalent of the horror genre's monster
- Locker room and training room as intimate spaces\u2014where guards drop, where bodies are most vulnerable, where the boundary between teammate and something more blurs
- Crowd energy as emotional amplifier\u2014the roar that carries you, the silence after a miss, the specific atmosphere of a stadium or arena at a crucial moment
- Post-competition vulnerability\u2014the emotional rawness after a big win or devastating loss; this is where walls crumble and connection happens
- The sport's rhythm in the prose\u2014short punchy sentences during action, longer flowing sentences during recovery and intimacy; let the physical pace shape the writing

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1 \u2014 Hook delivery:
- Competition or physical stakes AND chemistry from page one\u2014the sport is alive, the attraction is electric
- Tension floor: 5 (the reader must feel both the athletic stakes and the charged awareness)
- Open with the body in motion: training, competing, or recovering\u2014never with backstory about the sport
- Dialogue density: 30-40%\u2014banter and competitive trash talk establish chemistry fast

Sport/competition scenes (prose rhythm):
- Short, kinetic sentences during action\u2014the same choreographic clarity as thriller combat
- Fragments permitted at peak intensity: the sprint, the final set, the last seconds
- Sensory detail physical and specific: the burn of lactic acid, the sound of impact, the crowd\u2019s roar as pressure
- Interiority budget: 20% during competition\u2014the body leads, the mind follows

Romance/vulnerability scenes (prose rhythm):
- Sentences lengthen during recovery and intimacy\u2014breath returns, the competitive mask slips
- Post-competition emotional flooding: longer paragraphs, deeper interiority, walls dissolving
- Physical awareness carries over: the way an athlete notices another body is specific\u2014strength, movement, capability
- Interiority budget: 45%\u2014the gap between physical confidence and emotional uncertainty

Climax/resolution prose rhythm:
- Championship/final match: prose mirrors the sport\u2019s pace\u2014building, building, then the decisive moment in a single short line
- Romantic climax alongside or after athletic peak: the emotional declaration carries the same intensity as the winning point
- Resolution: both arcs satisfied\u2014prose settles into the rhythm of two bodies at rest, together

GENRE-SPECIFIC STYLE
- Pre-game rituals as character revelation\u2014superstitions, routines, the specific way someone prepares reveals who they are
- Training partners and the intimacy of physical instruction\u2014adjusting form, demonstrating technique, the teacher-student dynamic crackling with awareness
- Ice baths, massage tables, and recovery rooms\u2014the sports-specific intimate spaces where bodies are tended and pretenses dissolve
- Team dynamics as found family\u2014the camaraderie, the ribbing, the fierce loyalty, the unspoken codes; teammates who see the romance developing
- Sports metaphors for emotion\u2014but used sparingly and precisely, never forced; "she had been training for this her whole life, but nothing had prepared her for the way he looked at her after the final whistle"
- Press conferences and media as public performance\u2014the mask athletes wear in public, the contrast with who they are in private
- Watching film/reviewing performance as parallel to relationship reflection\u2014analyzing what went wrong, what went right, what to do differently
- Road trips and away games\u2014travel as forced proximity, hotel rooms, team buses, airports; the transient intimacy of athletes on the road
- Championship countdown\u2014the ticking clock of a season moving toward its climax providing urgency to both the athletic and romantic arcs
- Off-season vulnerability\u2014when the sport's structure disappears, who are you? This is prime romance territory
- Gym playlists, game-day music, workout routines\u2014the sensory details that make the athletic world feel lived-in
- Nutrition and diet scenes\u2014shared meals with athletic constraints, the discipline of fuel vs. the pleasure of food; cooking for someone as intimacy
- Equipment and gear as character\u2014the well-worn gloves, the lucky shoes, the carefully maintained equipment; athletes have relationships with their tools
- Victory and defeat as emotional catalysts\u2014winning makes you feel invincible and reckless; losing strips everything away and leaves you raw

FORBIDDEN WORDS/PHRASES
- "Gave 110%"\u2014dead sports cliche; show the effort through specific physical detail
- "Orbs" for eyes\u2014say eyes, gaze, or specific color
- "Suddenly" without athletic buildup\u2014earn every competitive moment through pacing
- "They had chemistry"\u2014demonstrate attraction through physical awareness and competitive tension
- "His/her heart skipped a beat"\u2014show the specific physical response to the other person with athletic body-awareness
- Generic sport action\u2014"they played well" instead of specific plays, specific movements, specific athletic moments
- "The crowd went wild"\u2014show the specific sensory experience of crowd energy
- Telling competence\u2014"she was the best player"\u2014show it through action, through the way others defer or compete
- "Game changer"\u2014find fresh language for pivotal moments

SPORT-ROMANCE TENSION
- Competition as foreplay: Competing against or alongside someone creates charged physical awareness\u2014reading each other's bodies, anticipating movement, the rush of matched capability
- Training as intimacy: The physical closeness of coaching, spotting, demonstrating technique; bodies in proximity with no social excuse to maintain distance
- Performance vulnerability: Failing in front of someone you want to impress; the exposure of not being the best, of being human, of being breakable
- Athletic bodies as both armor and exposure: The body that can dominate on the field is also the body that trembles at a touch; strength and softness coexisting
- Discipline as obstacle: The focus required to compete at elite level leaves little room for emotional risk; loving someone is the ultimate distraction
- Shared language: Athletes who understand each other's world\u2014the sacrifices, the obsession, the physical toll\u2014connect on a level civilians cannot reach
- Rivalry as attraction: The person who pushes you hardest may be the person who sees you most clearly
- The body after competition: Exhausted, adrenaline-spent, stripped of pretense\u2014this is when athletes are most human and most available for genuine connection

INTIMACY IN SPORT CONTEXT
- Romantic scenes carry the charge of athletic physicality\u2014these are people who live in their bodies, who are comfortable with sweat and exertion and physical intensity
- Tenderness amplified by surrounding toughness\u2014gentleness means more from someone who hits for a living, who runs until they collapse, who disciplines their body mercilessly
- The first touch matters enormously\u2014after weeks of formalized athletic contact (handshakes, high-fives, training adjustments), an unscripted touch electrifies
- Post-competition emotional flooding\u2014after a huge win or devastating loss, emotional barriers dissolve; this is when confessions happen, when restraint breaks
- Athletic recovery as intimacy\u2014icing joints, stretching muscles, taping injuries; the tenderness of caring for a body that has been punished by the sport they love
- Shared physical experience\u2014running together, working out together, the parallel breathing and synchronized effort creating a bond deeper than conversation

INTIMATE SCENES \u2014 CHARACTER REVELATION THROUGH PHYSICALITY

- Intimate scenes in sport romance must serve the relationship and character development\u2014not merely provide heat
- Ask: what does this moment reveal about characters who spend their lives controlling their bodies? What does surrender look like for someone trained in discipline? What does vulnerability look like for someone whose body is their primary instrument?
- The best intimate scenes in sport romance contain emotional rawness\u2014the elite athlete who cannot control their response to this person, the physical confidence that evaporates into emotional uncertainty, the body that performs perfectly in competition but trembles at tenderness
- Build physical intimacy into the athletic landscape\u2014it should feel like the natural culmination of weeks of heightened physical awareness, competitive tension, and growing trust
- Sensory writing is essential: the specific textures of athletic bodies\u2014callused hands, tape-wrapped wrists, the contrast between competitive intensity and intimate gentleness
- The sport should remain present even in intimate moments\u2014an early morning alarm for training, the awareness that tomorrow is game day, the knowledge that this body must perform under scrutiny

METHOD WRITING \u2014 EMOTIONAL TRUTH

- Identify what you want the reader to FEEL before writing any key scene\u2014the electric awareness of watching someone perform at their peak? The devastating vulnerability of injury? The ache of wanting someone who is focused on everything except you? The fierce joy of winning alongside someone you love?
- If the writer is not feeling the emotion while writing, the reader will not feel it while reading\u2014that is the signal to go back and find what is blocking the feeling
- Write through all five senses with athletic specificity: what does a training facility smell like at 5 AM? What is the exact sensation of a body pushed past its limit? How does adrenaline alter your perception of someone standing across the court, the field, the ring?
- Never be cynical about emotion\u2014do not manufacture an injury or a loss purely for dramatic convenience. Genuine emotion, earned through character investment and authentic athletic detail, is what makes readers feel both the thrill of competition and the ache of falling in love

DIALOGUE \u2014 TWO LANGUAGES

- Athletes speak differently on and off the field\u2014sport-specific jargon, shorthand, the coded communication of teammates vs. the stumbling vulnerability of personal confession
- The gap between competitive trash talk and emotional honesty IS the tension\u2014characters who can challenge an opponent's weakness but cannot name their own feelings
- Each character should speak distinctly\u2014the confident captain vs. the quiet rookie, the media-trained professional vs. the raw newcomer; voices shaped by their position in the sport
- Post-game interviews as public performance contrasted with private conversation\u2014what they say to the cameras vs. what they say in the car afterward
- Conversations during training carry different weight than conversations over dinner\u2014physical exertion strips social armor; things said while running hills or sparring have a rawness that formal settings cannot produce
- "Good game" as "I see you." "Stay healthy" as "I need you to be okay." Athletic understatement carrying emotional freight
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Athletic authenticity. sport-specific detail rendered with genuine knowledge, rules, training, competition, culture, and physicality accurate and specific
2. Romance central. love story drives every chapter, not a sports novel with romantic subplot but the emotional engine alongside the competitive engine
3. HEA/HFN delivered. couple together at end, both grown as people and athletes, relationship and athletic arc both resolved
4. Sport shapes the love story. competition, training, team dynamics, physical awareness integral to romantic development, not backdrop decoration
5. Both arcs resolved. athletic season or competition AND romance both satisfyingly concluded, neither abandoned for the other

GENRE-SPECIFIC CHECKS

Sport authentically rendered. rules, training, competitive structures, physical demands accurate and specific
Romance every chapter. relationship advances, no chapters without romantic development or charged awareness
Athletic bodies present. physical awareness of self and other rendered with athlete's intimacy and knowledge
Competition genuinely tense. game, match, or race scenes create real stakes and suspense for the reader
Team dynamics authentic. teammate relationships, coaching dynamics, locker room culture ring true
Training as character development. practice scenes reveal discipline, growth, frustration, partnership
Injury handled with gravity. physical setbacks treated seriously, healing takes time, fear is real, vulnerability shown
Performance pressure shown. the mental game of competition, pre-game nerves, choking, flow states, clutch moments
Career stakes real. what winning or losing means for these specific characters' futures, identities, self-worth
Physical labor of sport. the unglamorous side rendered honestly, exhaustion, diet restriction, repetitive training, body maintenance

AUTOMATIC FAILS

No genuine sport. characters happen to be athletes but the sport has no authentic detail, no real stakes, no impact on the story
No real romance. sports novel with attraction subplot, couple not central emotional engine
Tragic ending. couple not together or career destroyed without hope, violates genre promise
Athlete stereotypes. dumb jock, ice queen, one-dimensional competitor without inner life or vulnerability
Sport inaccuracy. wrong rules, impossible physical feats, unrealistic timelines for skill development or injury recovery
Injury trivialized. major injury resolved in one chapter, no psychological impact, no realistic rehabilitation timeline
Romance pausing the sport. extended love scenes during championship week with no acknowledgment of competitive demands
Sport pausing the romance. multiple competition chapters with no romantic development whatsoever
Abusive coaching normalized. harmful authority dynamics presented as necessary toughness without critique
One arc abandoned. athletic season resolved but romance dropped, or romance concluded but competition forgotten

ACCEPTABLE IMPERFECTIONS

More sport than romance chapters (or vice versa) if both genres substantial and satisfying
Heat level varies. some sport romance explicit, some closed door, some fade-to-black
Minor technical sport details simplified if core athletic authenticity maintained
Supporting cast (teammates) not all fully developed if main characters and key team dynamics vivid

RED FLAGS TO INVESTIGATE

Sport feeling like wallpaper. athletic detail decorative rather than integral to the romance and character development
Competition scenes generic. game or match action that could be any sport rather than specific to this one
Athletic bodies described only during intimate scenes. physical awareness absent during training and competition where it should be constant
One protagonist significantly more developed than the other. star athlete fully realized but love interest feeling like accessory
Injury mentioned then forgotten. a significant physical setback that doesn't affect subsequent training, competition, or emotional state
Team dynamics absent. characters existing in a competitive vacuum without teammates, coaches, or team culture
Training montaged rather than shown. practice scenes summarized instead of rendered with the same specificity as game scenes
Competence told rather than demonstrated—"she was the best player on the team" without showing her skill in action
Romantic milestones disconnected from athletic context. relationship moments that could happen in any contemporary romance without the sport
Performance pressure absent. no pre-game anxiety, no competitive psychology, no mental game alongside the physical
Career stakes vague—generic "championship" without specific consequences for these characters' professional futures
Physical awareness one-directional. only one character noticing the other's athletic body rather than mutual charged awareness
Emotional register stuck on one note. multiple consecutive chapters of competition intensity without romantic tenderness, or sustained romance without competitive intrusion
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Athletic timeline: Season schedule, game dates, training cycles, playoff progression tracked precisely\u2014no games appearing out of schedule or seasons compressing impossibly
2. Relationship progression: Emotional intimacy deepens logically through shared athletic experience\u2014trust earned through competition and vulnerability, not assumed or artificially accelerated
3. Physical condition: Injuries, fatigue, fitness levels tracked\u2014a torn ACL in chapter 8 means months of rehabilitation, not miraculous recovery for the championship; soreness accumulates after intense training
4. Competition results: Win-loss records, standings, statistics\u2014once established, maintained consistently; a loss in chapter 5 affects standings in chapter 10
5. Team dynamics: Teammate relationships, coaching decisions, roster changes, locker room politics\u2014established dynamics maintained and evolved logically

GENRE-SPECIFIC TRACKING
- Romance milestones: First meeting, first charged physical awareness, first non-athletic touch, first kiss, first vulnerability shared, declaration, commitment\u2014each tied to athletic context
- Season progression: Where in the competitive season the story sits\u2014preseason, regular season, playoffs, championship, off-season; game results and standings
- Training schedule: What the daily/weekly routine looks like, when it changes, what the training cycles demand
- Injury status: Every injury tracked through diagnosis, treatment, rehabilitation, return-to-play; no injuries vanishing between chapters
- Athletic performance arc: Each character's competitive trajectory\u2014improving, declining, peaking, slumping\u2014tracked consistently
- Team roster: Who plays what position, who is starting, who is injured, who has been traded or cut
- Coaching relationship: Trust level between athlete and coach, coaching decisions about playing time, team strategy
- Media presence: What has been reported publicly about the athletes, the team, the relationship
- Contract/career status: Where each athlete stands professionally\u2014contract year, free agency, scholarship, sponsorship
- Rival status: Opponents' records, upcoming matchups, competitive history between rivals
- Training environment: Gym, facility, field, rink, pool\u2014described consistently in layout and atmosphere

ACCEPTABLE INCONSISTENCIES
- Minor crowd numbers or attendance details if game atmosphere maintained
- Slight variation in daily routine timing if training rhythm consistent
- Background teammate details if core team dynamics well-established

CRITICAL CONSISTENCY
- Injury recovery timelines\u2014a broken bone takes weeks, a ligament tear takes months; no shortcuts without established reason
- Game/match results\u2014every result affects standings, morale, and trajectory; track the record
- Athletic skill level\u2014a player who struggles with a specific skill in chapter 3 does not master it by chapter 5 without shown development
- Season calendar\u2014games happen on established schedules; playoffs follow real formats for the sport
- Body condition\u2014exhaustion from a brutal training week carries into game performance; weight cutting has real effects
- Relationship intimacy level\u2014first kiss happens once, trust once broken must be rebuilt through demonstrated commitment
- Team rules\u2014if fraternization is prohibited, consequences for breaking rules must be consistent
- Equipment and facilities\u2014established gym layout, training equipment, game facilities maintained throughout
- Dietary restrictions\u2014if an athlete follows a specific nutrition plan, it remains consistent
- Travel schedule\u2014road games mean absence; distance creates specific relationship challenges
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Athletic identity: Characters' sport-specific skills, training discipline, competitive fire, and physical capability are established and maintained\u2014competence shown through action, not claimed through dialogue
2. Body relationship: Each character's relationship with their body\u2014its capabilities, limitations, injuries, and physical self-awareness\u2014is specific and consistent; athletes know their bodies intimately
3. Competitive drive balanced with vulnerability: The fierce determination required to compete at high levels coexists with the emotional vulnerability required for genuine romance\u2014neither dominates permanently
4. Team role and status: Each character's position within the team hierarchy\u2014leader, newcomer, veteran, underdog\u2014is established and shapes how they navigate both competition and relationship
5. Athletic and romantic arcs interconnected: Growth in one area should reflect or challenge growth in the other\u2014becoming a better athlete and becoming a better partner are parallel journeys

CHARACTER BUILDING \u2014 GROUND UP FOR SPORT ROMANCE

Build each protagonist from the ground up BEFORE the romance begins. The character must exist fully as an athlete:
- Background questions: Why this sport? When did they start? What have they sacrificed for it? What do they love about competition\u2014and what do they hate? What is their relationship with their body? What are they afraid of\u2014career-ending injury, irrelevance, peaking too early, aging out? What happens to them when the sport ends?
- Character tests: How do they handle losing? What is their pre-game ritual? How do they treat the equipment manager? What do they do on rest days\u2014and can they actually rest? What music is on their workout playlist? How do they respond to a teammate's failure vs. their own?
- These details inform everything: how they express attraction (competitively? protectively? tentatively?), how they handle vulnerability (as weakness to be overcome? as injury to be rehabbed? as something completely outside their training?), what specific fears the romance triggers
- Messy, flawed characters create richer sport romance\u2014an athlete whose competitive drive masks crippling insecurity, a player whose body confidence vanishes in intimate contexts, a champion who has never learned to lose gracefully\u2014in love or sport

ANTI-STEREOTYPE IMPERATIVE

Avoid default sport romance archetypes: no dumb jock whose only quality is physical prowess; no ice queen female athlete who just needs the right man to soften her; no walking six-pack whose personality begins and ends with being attractive and good at sports. Both protagonists need specific, individual complexity beyond their athletic identity. The star quarterback can be anxious, bookish, or emotionally intelligent. The figure skater can be brash, competitive, and terrible at relationships. The most compelling sport romance characters are athletes who are fully human\u2014whose sport has shaped them but does not define the limits of who they are. Stereotypes flatten both the athletic and romantic dimensions.

GENRE-SPECIFIC CHARACTER ELEMENTS
- Sport-specific physicality: How each character moves, carries themselves, occupies space\u2014a swimmer moves differently than a boxer, a runner differently than a hockey player; this shapes how they are perceived and how they perceive the world
- Competitive response: Each character has a distinct reaction to winning, losing, and the pressure between\u2014grace, fury, withdrawal, renewed determination; consistent but capable of growth
- Injury history: Past injuries that shape current physicality, create fear, or provide the vulnerability that the romance requires
- Training philosophy: Each character approaches their craft differently\u2014methodical vs. instinctive, conservative vs. risk-taking, solo vs. collaborative; this extends to how they approach relationships
- Role on the team: Captain, star, role player, rookie, veteran\u2014their status affects their confidence, their public persona, and what they risk by falling in love
- Off-field identity: Who they are when they are not competing\u2014hobbies, family, education, friendships outside the sport; the person beneath the uniform
- Relationship with coaching/authority: Trust, rebellion, dependence, mentorship; this dynamic often parallels or complicates the romantic relationship
- Body confidence: The paradox of athletic body\u2014supremely confident in physical performance, potentially uncertain in intimate vulnerability; the body as instrument vs. the body as self
- Career timeline: Where they are in their athletic career\u2014rising, peaking, declining, transitioning\u2014shapes their willingness to risk emotional distraction
- Relationship with fame/public identity: For professional athletes, the public persona vs. private self creates specific romance obstacles

CHARACTER ARCS MUST
- Show vulnerability beneath competitive armor\u2014initial focus/stoicism through crisis-forced honesty to chosen emotional openness
- Demonstrate the competence-vulnerability paradox\u2014the athlete who can perform under immense pressure but cannot say "I need you"
- Navigate sport's demands on the relationship\u2014training schedules, travel, competitive focus, team obligations creating real friction with romantic needs
- Confront identity beyond sport\u2014who am I if I am injured? If I lose? If I retire? The romance should help answer these questions
- Earn love through character shown in competition\u2014sportsmanship, determination, grace under pressure, how they treat opponents and teammates reveals who they are
- Choose love despite the risk to competitive focus\u2014knowing that emotional vulnerability might cost them their edge, choosing to be human anyway
- Transform through dual journey\u2014characters at end fundamentally changed by both the athletic experience and the romantic one
- Maintain agency\u2014both characters make choices that affect competition AND relationship; no passive recipients of either victory or love

TRACK
- Athletic performance\u2014current form, recent results, confidence level, fitness; tracked chapter by chapter
- Physical condition\u2014injuries active, soreness levels, fatigue accumulation, rehabilitation progress
- Competitive standing\u2014team record, individual stats, ranking, playoff position
- Emotional walls\u2014what triggers vulnerability, what rebuilds competitive armor, which walls have been permanently lowered
- Romantic milestone reached\u2014where in the attraction-to-love progression each character sits relative to the season
- Team relationships\u2014allies, rivals, the teammates who know about the romance, the ones who don't
- Coaching dynamic\u2014trust level with coach, playing time decisions, whether coach knows about the relationship
- Public vs. private self\u2014what the media/fans see vs. who the character really is; when the mask slips
- Career trajectory\u2014contract status, performance trend, future plans; how these affect romantic decisions
- Competitive psychology\u2014mental game, confidence, superstitions, pre-game state; evolving through the season
```

## Arc Rules

```
ACT I (Chapters 1-10): The Starting Lineup
- Ch 1: Athletic world established through visceral action\u2014training, competition, or the physical reality of the sport; protagonist's competitive drive and current stakes shown; the disruption arrives (new teammate, rival, return from injury, new season beginning)
- Ch 2-3: Second lead introduced through athletic context\u2014as competitor, teammate, trainer, journalist, or someone whose world intersects with the sport; initial friction or charged awareness; the athletic stakes established (championship pursuit, comeback, proving themselves, saving a career)
- Ch 4-5: Forced proximity through the sport\u2014training together, traveling together, competing alongside or against each other; competence observed and admired; physical awareness building through sport-specific contact and proximity
- Ch 6-8: Athletic pressure mounting alongside growing attraction\u2014early season competition, training intensity increasing, team dynamics complicating; first moments of genuine vulnerability exposed by competitive pressure (a loss, a mistake, a fear shared in the training room); the attraction acknowledged internally if not spoken
- Ch 9-10: First genuine romantic moment earned through shared athletic experience\u2014a victory celebrated, a loss comforted, an injury weathered together, a barrier broken through physical challenge; the competitive stakes and the romantic stakes begin to intertwine
- Purpose: Establish BOTH athletic authenticity and romantic chemistry as co-equal forces\u2014the sport shapes the love story
- Ends with: Mutual respect and physical awareness undeniable, attraction acknowledged internally, competitive season in motion, both athletic and romantic trajectories launched

MIDPOINT (Chapter 15): The Big Game and the Bigger Risk
- A major competitive moment (mid-season showdown, crucial match, qualifying round) AND a significant romantic turning point collide\u2014the pressure of performance strips emotional armor, and what is revealed cannot be un-seen
- Physical or deep emotional intimacy earned through the crucible of competition\u2014post-game vulnerability, shared triumph or shared defeat creating a window that both characters step through
- Tonal shift: From "this person is a distraction I cannot afford" to "this person might be worth more than the championship"\u2014the question changes from avoidance to choice

ACT II (Chapters 11-23): The Heart of the Season
- Ch 11-14: Romance deepening through the rhythms of the athletic life\u2014training side by side, travel together, the small acts of care (icing someone's knee, sharing a meal within dietary constraints, the quiet of a hotel room on the road); the team begins to notice; the public/private tension increases
- Ch 15: MIDPOINT\u2014major competition AND romantic breakthrough; the sport and the relationship demand the same courage: the willingness to be fully present, fully committed, fully at risk
- Ch 16-18: External complications from the sport world\u2014a rival's challenge, a coach's ultimatum about focus, media speculation about the relationship, a teammate's jealousy, a career opportunity that means relocation or separation; the romance tested by the real demands of athletic life
- Ch 19-21: Internal obstacles surface\u2014fear that love compromises competitive edge, identity crisis ("am I still the same athlete?"), past relationship failure connected to sport demands, the terrifying vulnerability of needing someone when you have been trained to be self-sufficient; injury threatens one or both characters
- Ch 22-23: Black moment\u2014the athletic season reaches a crisis point AND the relationship fractures; a devastating loss, a career-threatening injury, a public exposure, or a choice between the sport and the person; the couple separates because the very qualities that make them great athletes (discipline, independence, competitive focus) prevent them from choosing vulnerability
- Purpose: Romance intensifies BECAUSE athletic pressure escalates\u2014each competition, each training session, each crisis reveals more of who the characters are and what they mean to each other
- Ends with: Darkest hour\u2014the championship may be lost, the relationship may be over, and the character must face who they are without the armor of competition or the comfort of the relationship

ACT III (Chapters 24-30): The Championship Round
- Ch 24-25: Choosing each other despite the cost\u2014one or both must overcome their deepest fear (vulnerability, losing control, needing someone, being "soft") and reach for the other; this choice should require the same courage as their greatest athletic moment
- Ch 26-28: The championship/final competition\u2014the athletic climax where the romantic stakes make every moment more intense; the couple either competing together, supporting each other, or finding that their personal growth makes them better athletes; the sport and the love story feeding each other's resolution
- Ch 29: Aftermath\u2014the competition concluded (win, lose, or meaningful resolution), the relationship committed, the athletic identity expanded to include love; scars and growth acknowledged
- Ch 30: Earned HEA/HFN\u2014the couple together, the season behind them, a final scene that shows both the love and the athletic world; the future includes both competition and partnership; the person who began the book defined solely by their sport now carries a fuller identity
- Purpose: Resolve the athletic season AND cement romantic commitment\u2014both earned through courage, vulnerability, and the willingness to risk everything
- Ends with: HEA/HFN\u2014couple together, competition concluded, both characters transformed; the athlete and the lover integrated into one whole person

GENRE PROMISE
Sport Romance readers expect:
- Authentic sport: the training, competition, physicality, and culture rendered with genuine knowledge and respect, not costume
- Central romance: not subplot, the emotional spine of the story
- HEA/HFN: couple together, both having grown
- Physical awareness: athletic bodies described with intimacy and nuance, attraction built through competence and proximity
- Competition as emotional catalyst: wins, losses, pressure, and performance stripping characters to their emotional core
- Team as community: found family, support system, and complication
- Injury as vulnerability: physical setbacks creating space for emotional honesty
- Both arcs resolved: the season concludes AND the love story reaches its destination
- The sport matters: these characters care deeply about competition, and the reader must feel that passion alongside the romantic one

REQUIRED CHECKPOINTS
- Ch 3: Athletic world established AND romantic chemistry or charged awareness undeniable
- Ch 5: First shared athletic experience\u2014competition, training, or physical challenge weathered together
- Ch 8: Competence-based attraction solidified; first genuine vulnerability exposed by competitive pressure
- Ch 10: First romantic moment earned through shared athletic experience
- Ch 13: Team dynamics affecting the romance\u2014teammates noticing, coach reacting, or rules complicating
- Ch 15: Major competition AND romantic breakthrough\u2014sport and love demanding the same courage
- Ch 18: Athletic career demands threatening the relationship\u2014travel, opportunity, injury, or focus
- Ch 23: Black moment\u2014competition AND relationship at breaking point; athletic and emotional crises colliding
- Ch 25: Choosing love\u2014the competitor who has been trained to prioritize winning learns that some things matter more
- Ch 28: Championship/climax where romantic stakes intensify every athletic moment
- Ch 30: HEA/HFN\u2014together, the season concluded, both characters transformed by sport and love

EMOTIONAL CONTRAST IN ARC STRUCTURE

Chart the emotional arc as alternating peaks and valleys of competitive intensity and romantic tenderness. After every major athletic moment (a crushing defeat, a career-best performance, a terrifying injury), provide a breathing space where the couple connects\u2014even briefly: humor in the ice bath, quiet comfort after a loss, the shared joy of a win that means more because someone is there to share it. After every moment of genuine romantic connection, introduce a complication that tests the bond: the demands of training, the temptation of a career opportunity, the exposure of media attention, the fear that being in love makes you weak on the field. This rhythm mirrors the athletic cycle itself\u2014peak performance followed by recovery, the brutal honesty of competition followed by the comfort of someone who sees you beyond the scoreboard. Two consecutive game chapters exhaust; competition followed by tenderness creates the emotional whiplash that makes sport romance irresistible.

EARNED ENDINGS

The HEA/HFN must be earned through everything the characters have endured\u2014in competition and in each other. The resolution should feel like the inevitable destination of THESE specific athletes who were built from the ground up. If the couple overcomes their obstacles through courage, it must be the same courage they have demonstrated on the field\u2014applied to the harder arena of emotional vulnerability. Seed the resolution early: the mental toughness that wins the championship should be the same quality that allows them to risk their heart; the teamwork that saves the game should mirror the partnership that saves the relationship. A sport romance ending should feel like the best kind of victory\u2014not the one on the scoreboard, but the one that means you never have to compete alone again.

THEME BENEATH THE SPORT

Every sport romance benefits from a THEME running beneath the surface\u2014what the story is really about beyond the championship and the love story. Is it about what defines you beyond your talent? About the courage to want something you cannot train for? About what winning really means when the scoreboard goes dark? About whether the person who pushes you hardest might also be the person who holds you most gently? Theme adds a dimension that makes sport romance resonate beyond the genre\u2014the reader should close the book feeling something true about competition, vulnerability, and the human need to be seen for who you are when the uniform comes off.
```

## Timeline Rules

```
TIME SCALE
- Total story duration: One competitive season (weeks to months), with possible epilogue showing next season or off-season
- Chapter time span: Days to weeks\u2014paced by the competitive calendar, training cycles, and game schedules
- Time progression: Linear following the season, with possible flashbacks to previous seasons, past injuries, or relationship history

GENRE-SPECIFIC TEMPORAL RULES
- The competitive calendar dictates pacing\u2014games and matches provide natural story beats; playoff progression creates escalating urgency
- Training cycles create rhythm\u2014heavy training periods followed by taper before competition, recovery days between games, preseason conditioning different from in-season maintenance
- Injury timelines are non-negotiable\u2014a concussion requires specific protocol, a muscle strain takes days to weeks, a ligament tear takes months; these cannot be compressed for plot convenience
- Travel creates separation and reunion\u2014road games mean days apart; homestand means daily proximity; this rhythm naturally creates romantic tension
- Game day as emotional heightening\u2014competition strips emotional armor; pre-game nerves make everything feel more intense; post-game vulnerability creates windows for connection
- Off-season as transformation\u2014the period when competitive structure disappears and characters must face each other (and themselves) without the sport as shield
- Recovery and rest days\u2014athletes need actual rest; these quieter moments are where romance deepens without competitive distraction
- Media cycles\u2014press coverage follows game schedules; big wins and losses generate attention that affects the relationship
- Contract and trade deadlines\u2014career decision points that create external urgency

TRACK CAREFULLY
- Game/match schedule\u2014when competitions happen, how many per week/month, travel between venues
- Days since significant athletic events\u2014last game, last injury, last practice
- Training cycle phase\u2014building, peaking, tapering, recovering
- Injury recovery timeline\u2014days/weeks/months since injury, current rehabilitation stage, projected return date
- Competitive season position\u2014early season, mid-season, playoff push, championship round
- Relationship timeline against athletic calendar\u2014when milestones happen relative to competition schedule
- Rest and recovery\u2014how long since characters had genuine downtime
- Travel schedule\u2014home and away stretches, travel days, time zone changes
- Academic calendar (if college athletics)\u2014classes, exams, breaks affecting availability

FLEXIBLE
- Exact practice start/end times if general routine established
- Minor scheduling details between games
- Precise statistics if general performance level tracked
```

## Genre-Specific Craft Techniques

Sport romance is the integration of two demanding registers:
the body in athletic motion (specific, technical, embodied) and
the body in emotional contact (vulnerable, exposed, unguarded).
Done well, the two share the same language — heart rate,
breath, pressure, recovery, second wind. Done badly, the sport
becomes wallpaper for a generic romance, or the romance becomes
distraction from a sports novel. The techniques below are how
the integration is sustained at scene level, season level, and
career level.

### The Game as Metaphor

Sporting events must mirror the romantic arc, not run in
parallel beside it. The comeback victory carries the
relationship's second chance; the training montage paces the
slow work of building trust; the injury makes emotional
vulnerability literal; the rivalry game externalises the
internal romantic conflict. Every game on the page should
advance both the sports plot and the love story
simultaneously — and the writer should be able to say in one
sentence what each game means for the relationship. If a game
does only sport-plot work, it belongs in a sports novel; if it
does only romance work, the sport has been wasted. The craft
test: strip the dialogue and interior monologue from a key
match scene; can the reader still feel where the relationship
stands? If yes, the metaphor is operating at the level of
action, which is where sport romance should live.

### The Body as Character

Athletes relate to the world through their bodies — pain,
performance, discipline, recovery, pleasure, fear of decline.
Sport romance must treat the body as more than decoration or
trophy. How does this athlete experience a first kiss
differently because they are attuned to micro-shifts in
physical sensation? How does an injury threaten identity, not
merely career? How does training-discipline carry into intimate
discipline (the controlled breath, the studied attention to a
partner's response)? The technique requires sport-specific
embodiment: a sprinter's awareness is not a long-distance
runner's; a boxer's hands are not a pianist's are not a
keeper's; a gymnast's relationship to gravity is not a
swimmer's. Catalogue prose ("rippling muscles", "chiselled
jaw") is the failure mode this technique exists to prevent —
the body should be felt from the inside as the athlete
experiences it, and from the outside as the partner
specifically perceives it.

### The Locker Room Intimacy

The team is a found family the love interest must navigate, and
the team's rituals — pre-game silences, post-game showers, the
way kit is folded, the captain's speech, the rookie hazing, the
shared injury — are the social world of the novel. The love
interest's gradual acceptance by the team is a significant
romantic milestone, often as important as the central romantic
beat. Conversely, the team's rejection of the relationship (or
of the partner) is a genuine threat the romance must navigate.
Treat the team as ensemble: each meaningful teammate has a
distinguishable voice, a particular role on the field and in
the social structure, and a specific stake in the central
relationship's success or failure. The technique fails when
teammates become a faceless crowd; it succeeds when the reader
can name three teammates and their distinct relationship to the
protagonist by the midpoint.

### The Season Arc Structure

Sport romance has a natural structural spine: preseason hope,
early wins (or losses) that establish stakes, mid-season slump
or crisis, playoff pressure, championship climax. This is not a
straitjacket — books can begin mid-season, span multiple
seasons, or compress to a single tournament — but the season's
pulse should provide pacing and escalation that prose alone
cannot. The championship game (or season-defining match, fight,
race, meet, run, final) and the romantic climax should
coincide or closely align: the moment of greatest sporting
stakes is also the moment of greatest emotional stakes. Off-
season scenes do specific structural work — recovery,
reflection, romance allowed to deepen without external
pressure — and should not be treated as filler. The craft test:
chart the season's natural beats against the romance's natural
beats; misalignments visible in a chart will be felt by the
reader as the book's pacing problem.

### The Sacrifice Play

The moment where the athlete must choose between sporting glory
and romantic commitment, and where the choice is genuinely
costly either way. The sacrifice must be specific and material:
not "she chose love" but "she chose to attend the funeral
instead of the qualifying meet that would have set her ranking
for the season"; not "he prioritised the relationship" but "he
declined the trade to a contending team because the move would
end the relationship and he had reckoned with what that meant".
If the answer is obvious — if the sport is positioned as
shallow or the romance is positioned as the only true call —
the tension collapses. The best sport romances make the reader
unsure what they want the character to choose, and respect both
sides of the cost. The technique extends to the partner: their
sacrifices for the athlete (relocations, schedule subordination,
the missed Christmas because of the bowl game) must also be
named and weighed.

### The Recovery Arc

Injury, slump, retirement, and the post-career interregnum are
where sport romance does its deepest emotional work. The
athlete's body is also their identity, their income, and their
social standing; what does it mean to be loved during the
period when the public role disappears? Recovery scenes should
be physically specific (the prescribed exercises, the slow
return to training load, the visible weight loss or gain, the
fear of the next attempt at the move that caused the original
injury) and emotionally exposed (the dependence the athlete is
not used to feeling, the partner's testing as nurse rather
than fan, the question of whether attraction survives the body
that produced it). Even in non-injury sport romances, the off-
season or post-career interlude does similar work. The
technique closes a gap that game-only sport romances leave
unaddressed: who is this person when they cannot perform, and
is the relationship strong enough to know the answer?

### Sport Romance AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the game was his whole life. until her" | Show the specific sacrifice or schedule clash, named in the language of the sport |
| "she was a distraction he couldn't afford" | Show the specific missed play, late arrival, or focus failure and its concrete cost |
| "the crowd roared but he only heard her voice" | Show the specific moment of focus — what he was about to do, what her presence interrupts or steadies |
| "muscles rippled beneath his jersey" | Show through her specific physical reaction (her own pulse, her hand on the rail) — not body-part catalogue |
| "the rivalry on the field became something more" | Show the specific charged competitive moment — the play, the call, the look across the line |
| "his dedication to the sport was both attractive and infuriating" | Show the specific scheduling conflict and her precise reaction to it |
| "the injury changed everything" | Name the specific injury (ACL, rotator cuff, concussion protocol, hairline fracture in the navicular) and its specific career consequence |
| "she saw past the fame" | Show the specific unglamorous moment she witnesses — the post-game ice bath, the press-conference exhaustion, the early-morning recovery routine |
| "victory tasted sweeter with her watching" | Show his specific post-game behaviour, the look up to the stands, the gesture only she would catch |
| "the training montage of their relationship" | Show ONE specific shared activity in physical detail — the run she paces him on, the catch they fall into, the lift they spot for each other |
| "the pressure of the season" | Show the specific game / match / meet and what is riding on it for ranking, contract, or career |
| "a body built for the sport" | Show the specific adaptations — the calluses, the asymmetric muscle development, the breath capacity, the gait |
| "the locker room fell silent" | Show the specific moment that hushed it — the captain's entrance, the news, the rookie's question that should not have been asked |
| "he was a champion in every sense" | Pick the specific arena where his competence is being demonstrated and show only that |
| "the sound of leather on willow" / "the crack of the bat" | Sport-specific concrete sound replacing the cliché phrase for that sport |
| "she had never been into sports" | Show the specific moment she chooses to learn, what she misunderstands first, what she figures out for herself |
| "the post-game adrenaline" | Show the specific physical sensations and behaviours — shaky hands, hyper-clarity, sleeplessness, the appetite that follows |
| "the coach was tough but fair" | Show the specific decision that demonstrates both qualities — the bench in the third quarter, the late-night call, the cut that someone needed |

### Romance Masterclass — Sport-Romance Calibration

The romance master file (romance.md) holds the canonical
romance frameworks: Heat Level Calibration, the 7-Element
Chemistry Scene Construction, the 6 Romance Character
Archetypes with character-build tests, Obstacle Layering
Quantitative, Light and Shade Heart-Monitor Rule, the
Differentiation Imperative, Hope-as-Resolution Calibration,
and Series Architecture. All apply directly to sport-
romance, calibrated below to the genre's specific physical-
stakes register.

**7-Element Chemistry Scene — Sport-Romance calibration:**

- **Element 1 (Setup):** physical training discipline,
  competition window, body as instrument. Establish the
  athletic stake of the moment — what training cycle, what
  performance pressure, what physical state each lead
  arrives in. The body is the genre's primary signal-
  carrier and must be present in the Setup.
- **Element 2 (Approach):** often through professional
  proximity — the coach-athlete dynamic, the teammate
  encounter, the journalist-athlete interview, the physio-
  athlete session, the rival-sport encounter. Proximity is
  often institutionally enforced (the gym, the locker
  room, the bus, the press conference).
- **Element 3 (Banter Beat):** physical-stakes humour;
  competitive register; locker-room or training-floor
  vocabulary. The dialogue often carries embedded sport
  reference (technique, tactic, training jargon) that
  reveals character through what each lead notices about
  the sport itself.
- **Element 4 (Awareness Spike):** typically arrives
  during physical performance, recovery, training session,
  pre-competition focus, or post-competition come-down.
  The body's intensity carries the emotional pivot — the
  way one lead watches the other train, the recovery touch
  that lingers, the high-five that holds for one second
  longer.
- **Element 5 (Pull-Back):** the load-bearing pull-back is
  carried by career-vs-relationship friction — contract
  obligations, championship window, performance peak,
  public visibility, fraternisation rules, professional
  ethics. The leads cannot act because the season, the
  contract, or the sport itself holds them.
- **Element 6 (Aftermath):** the body's response carried
  forward into the next training session, performance, or
  recovery. Render the Aftermath through how the physical
  discipline now shifts (better focus, distraction, hidden
  smile during stretches, missed timing during drill).
- **Element 7 (Hook):** the next physical or career
  milestone — the next match, the next training cycle,
  the contract negotiation, the medical check, the press
  appearance.

**6 Character Archetypes — Sport-Romance calibration:**

- **The Wounded Lead** carries one of: athletic ambition
  unfulfilled, past injury that may recur, performance
  anxiety, post-career identity transition, the cost of
  what the sport has demanded of their body or
  relationships. The wound must be sport-specific in its
  texture (not generic "self-doubt" but the named
  injury, the named missed selection, the named family
  cost).
- **The Opposite Lead** is the contrast — civilian (no
  sport background), journalist (institutional outsider),
  physio (clinical insider), rival athlete (different
  sport or different team), agent or coach (structural
  power dynamic). Their departure from the typical pairing
  must be specific.
- **The Found Family** is the team, training group,
  fan community, or post-career support network. Sport-
  romance benefits from a strong Found Family because
  the sport itself produces it.
- **The External Antagonist Force** is often the
  institution itself — the league, the team management,
  the contract, the doping authority, the press cycle,
  the sponsorship architecture.

**Obstacle Architecture — Sport-Romance dominant obstacles:**

The Obstacle Layering Quantitative rules apply. For
sport-romance, the dominant obstacle types are:

1. **Career timing** (contract window, season,
   championship cycle, peak-performance window)
2. **Physical injury risk** (acute, chronic, recurring)
3. **Public visibility / media scrutiny** (the
   fraternisation reveal, the speculation, the press
   intrusion)
4. **Post-athletic identity transition** (retirement,
   forced exit, transition to coaching or commentary
   or civilian life)
5. **Fraternisation rules / professional ethics**
   (coach-athlete, doctor-patient, journalist-source,
   rival-team)

**Differentiation Imperative — Sport-Romance specific axes:**

- Specific sport (running, MMA, hockey, equestrian,
  climbing, swimming, motorsport, gymnastics, tennis —
  each with its own culture, season, body-architecture)
- Specific career-stage (pre-debut, mid-career,
  championship-window, post-career)
- Specific role configuration (coach-athlete, two
  athletes, athlete-civilian, athlete-rival, athlete-
  press, athlete-physio)

**Ending Calibration — Sport-Romance patterns:**

Sport-romance typically delivers HEA in contemporary
register. HFN is possible mid-career (the relationship
navigates the career rather than concluding it; book 1 of
a series may resolve to HFN with the championship still
ahead). The Hopeful ending is rare except for retirement-
loss or career-ending-injury narratives where the genre
permits the relationship to end with hope for the
surviving lead's post-sport life.

## Genre-Specific Revision Rules

Six revision passes specific to sport romance, each with a
single question, each run cover-to-cover before the next
begins. Sport romance has a particular reader: frequently a
sports fan in their own right, frequently a competitive athlete
or former athlete, almost always able to detect the writer who
researched the sport from a Wikipedia page versus the writer
who knows the rhythms of the locker room. These passes catch
the failures that lose those readers.

### Pass 1: Sport Accuracy Audit

Verify every sporting detail in the manuscript: rules,
terminology, season structure, team dynamics, training regimens,
equipment, league calendars, contract conventions, scoring
mechanics, in-game decision points, recovery protocols. Build a
glossary of every sport-specific term that appears and verify
each one against current usage (terminology drifts: "concussion
protocol" only became routine vocabulary post-2010; "the
transfer portal" did not exist as a term before 2018; "the
bubble" carries a specific 2020 meaning in NBA / WNBA). If
writing about a real sport, the details must be impeccable —
sport romance readers are frequently competitive participants
or serious fans, and a single mistake (a position that does not
exist, a tournament that runs in the wrong month, a record that
the wrong athlete holds) will fracture trust for the rest of
the book. For invented or fictionalised leagues, internal
consistency is the standard: the rules must hold across every
appearance.

### Pass 2: Athletic Voice Consistency

Read the athlete character's POV scenes in isolation and ask:
do they move, observe, and react as someone who has spent ten
thousand hours doing this sport? An elite athlete's perception
is sport-shaped — the swimmer reads water, the climber reads
holds, the boxer reads the millisecond shift in an opponent's
shoulder, the goalkeeper reads angles before the striker has
chosen the shot. The athlete's relationship with their body
should be consistent and sport-specific, not a generic athletic
register. Check temporal scale: athletes track time in seconds,
splits, intervals, sets, reps, rotations — not in vague "a
while". Check spatial vocabulary: their language for distance,
angle, contact, pace will be specific to their sport. Flag
scenes where the athlete sounds like a non-athlete narrator
who happens to be at a sports event.

### Pass 3: Sport-Romance Integration

Build a chronological table mapping every significant sporting
event against every significant romantic beat. Mark each event
with a one-line answer: what does this game do for the
relationship? Mark each romantic beat: what does this scene do
for the season? Connections should run in both directions —
the game affects the relationship and the relationship affects
performance — with at least three high-cost intersections per
book (the away match where the partner does not come; the
victory celebrated alone; the injury watched from the stands;
the offer accepted or declined). If either storyline could be
removed without impacting the other, they are not integrated;
the book is two stories sharing a setting, not one story in two
registers. Flag chapters that read as pure-sport (the partner
is not present in mind or body) or pure-romance (the sport is
not present in mind or body) for more than two consecutive
chapters.

### Pass 4: Team Dynamics Check

Read every scene in which teammates, coaches, support staff,
agents, family-of-the-team, or rivals appear. Do they feel like
a genuine sporting environment, or do they feel like a romance
novel's chorus? Each significant team / staff figure should
have: a distinguishable voice, a specific role on the field
(or in the franchise), a particular history with the
protagonist, and a specific stake — supportive, sceptical, or
adversarial — in the central relationship. The team's response
to the relationship should evolve across the book and should
create both comedy (the rookie's fascinated questions, the
veteran's ribbing, the captain's pretence of disinterest) and
conflict (the trade rumour the partner did not know was being
floated, the teammate whose own injury the lovers' happiness
inadvertently echoes). Flag teammates who appear, exchange
generic encouragement, and disappear; that is chorus, not
ensemble.

### Pass 5: Physical Description Balance

Audit every description of an athlete's body in the manuscript.
The test: are descriptions specific (sport-shaped, scarred,
calloused, asymmetric, weathered, particular) and
character-revealing, or are they catalogue (broad shoulders,
narrow hips, abs, jawline)? Catalogue descriptions are the
genre's most-named AI crutch and the surest signal that the
writer is reaching for stock images rather than seeing the
specific person. Check directionality: physical admiration must
be mutual — both leads should be physically aware of each
other, not the partner positioned as the reader's surrogate
ogling the athlete. Check sensory range: the athlete's body
should also be felt from the inside (what training has done to
joints, tendons, sleep, appetite, mood) and not only seen from
without. Flag any description that could be applied unchanged
to any athlete in any sport; that description has not earned
its place.

### Pass 6: The Win-or-Career-Cost Test

Sport romance has a particular structural risk: the easy
ending, in which the athlete wins the championship AND keeps
the relationship AND retires healthy AND makes the All-Star
team. That ending is the genre's equivalent of every-couple-
has-a-baby-at-the-end — emotionally weightless because nothing
was risked. Run a final pass asking: what did the athlete
actually pay? Specific costs that count: the season missed for
recovery; the trade declined that ended a career trajectory;
the contract signed for less than market value to stay in the
city; the late-career retirement chosen because the body has
told them; the dream version of the championship that did not
arrive even when the relationship did. The pass also runs in
the partner's direction: what did they pay (relocations,
career subordination, public scrutiny, the time the sport took
that was not given back)? If both columns are empty, the
romance has not been earned by the book's own measure.

## Names & Patterns to Avoid

### Forbidden Patterns
- **The athlete as body only**. Sport romance protagonists must have intellectual and emotional depth beyond their physical attributes
- **The disapproving love interest**. "I don't even like sports" as a character trait creates an adversarial dynamic that undermines the athlete's identity
- **Injury as convenient plot device**. Injuries should have realistic recovery timelines and genuine emotional consequences
- **The generic "big game"**. Sporting events must be described with specific, accurate detail, not vague action

### Cliché Setups to Avoid
- The playboy athlete who has never been in love before meeting the protagonist
- The sports journalist who hates athletes but is assigned to cover the team
- The career-ending injury that conveniently frees the athlete for romance
- The rival who is purely villainous with no redeeming sporting talent

### Naming Considerations
- Athlete names should feel strong and physical without being cartoonishly masculine
- Consider how names sound in sports commentary. they will be shouted, chanted, and abbreviated
- Avoid names that are identical to real current professional athletes in the same sport
- Team names and sports terminology should be researched for the specific sport and league level

## Comp Titles

Sport-romance's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Hook Up* — Kristen Callihan (2015): early sport-romance template; college-football setting.
- *The Deal* — Elle Kennedy (2015): the Off-Campus series; college hockey romance; broad commercial appeal.
- *The Score* — Elle Kennedy (2016): same series; demonstrates sport-romance series architecture.

### Contemporary (current best-in-class)

- *Heated Rivalry* — Rachel Reid (2019): LGBTQ+ professional-hockey rivals-to-lovers; modern register.
- *Things We Never Got Over* — Lucy Score (2022): small-town sport-adjacent contemporary.
- *Icebreaker* — Hannah Grace (2022): figure-skating / hockey crossover romance; viral BookTok success.
- *Pucking Around* — Emily Rath (2023): polyamorous hockey-romance; expanded sport-romance configurations.
- *Off the Ice* — various series: ice-hockey romance category benchmark.
- *Catching Caden* — Vivian Wood et al: NFL-romance category template.
- *The Cheat Sheet* — Sarah Adams (2021): football-adjacent friends-to-lovers; cross-cultural success.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. The dominant style for sport romance, especially in the BookTok era. Digital illustrations of athletic couples or single figures in sporty settings. Bold, energetic compositions with strong character presence. This is the style readers expect and search for.
- **Graphic**. Bold graphic design with sport-specific iconography, high-contrast colour blocking, and dynamic typography. Works for series branding and stands out at thumbnail size with strong visual identity.
- **Photorealistic**. Real-model photography featuring athletic bodies, sports settings, or intimate athletic moments. Works for steamier sport romance where physicality is a selling point. Less dominant than illustrated but still viable.
- **Typographic**. Title-forward design with sporty, bold fonts and minimal imagery (jersey numbers, equipment silhouettes). Effective for established series or authors where name recognition drives sales.

### Genre Cover Aesthetics
- **Styles:** High-energy compositions with athletic movement or tension, strong character presence (illustrated athletes), stadium or training facility backgrounds, locker room intimacy, competitive intensity conveyed through pose and composition, sweat and physicality as visual elements
- **Colours:** Bold team colours. navy, crimson, emerald, royal blue. paired with high contrast (white, gold, black). Sport romance covers tend to be bolder and more saturated than other romance subgenres. Metallics (gold, silver) for championship or trophy elements. The palette should feel athletic, competitive, and energetic.
- **Elements:** Jerseys and team uniforms, sports equipment (footballs, hockey sticks, boxing gloves, ballet shoes), stadium lights, locker rooms, athletic tape and bandages, scoreboards, championship trophies, jersey numbers, athletic bodies in motion or at rest, gym and training settings
- **Typography:** Bold, impactful sans-serif fonts. often with a sporty or athletic feel. Jersey-style numbering as design elements. Block letters, condensed typefaces, and high-weight fonts that convey strength and energy. Author names can be styled like team branding.

### Subgenre Variations
- **Hockey Romance:** Ice rink blues and whites, hockey sticks crossed, illustrated players in gear, bruised knuckles, cold-weather palettes with warm romantic contrast
- **Football Romance:** Stadium lights, pigskin textures, team colours (particularly navy, crimson, gold), illustrated quarterback poses, Friday night lights aesthetic
- **Boxing/MMA Romance:** Dark, gritty palettes with red accents, wrapped hands and gloves, ring ropes, muscular silhouettes, more intensity and edge than other sport romance
- **Baseball Romance:** Classic Americana palettes, warm summer tones, diamond and dugout imagery, vintage sport aesthetic, wholesome-with-heat energy
- **Ballet/Dance Romance:** Graceful silhouettes, pointe shoes, studio mirrors, softer colour palettes (blush, dusty rose, gold) blended with athletic discipline
- **College Athletics:** Campus settings, school colours, younger illustrated characters, varsity elements, academic calendar integration

### Market Positioning
Sport romance is one of the fastest-growing romance subgenres, driven heavily by BookTok and social media. Illustrated covers dominate the bestseller lists and are virtually required for discoverability. The cover must immediately communicate WHICH SPORT at thumbnail size. readers shop by sport first, then by author or series. Bold typography and high-contrast colours ensure visibility in crowded digital storefronts. Series branding is critical: consistent team colours, character illustration style, and layout across a series builds readership. The cover should convey both athletic energy and romantic chemistry. sport romance readers want to see the sport AND the romance signalled visually.

### Cover Design DON'Ts
- Delicate, ornate, or period-style design. sport romance covers must feel modern, bold, and athletic
- Muted, pastel, or soft colour palettes (unless ballet/dance romance). the colours should feel competitive and energetic
- Dark, gritty, noir aesthetics (unless explicitly dark sport romance like boxing/MMA). most sport romance is fun and high-energy
- Period or historical visual elements. sport romance is contemporary by default
- Small, thin, or decorative typography. fonts must be bold, impactful, and readable at thumbnail
- Generic romance couple photography without sport context. the sport must be visually present
- Overly complex compositions. sport romance covers work best with clear, bold, simple compositions that read instantly
- Realistic injury or medical imagery. keep injuries romanticised (athletic tape, ice packs) rather than clinical
