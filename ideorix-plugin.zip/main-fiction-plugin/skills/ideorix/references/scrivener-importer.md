---
name: scrivener-importer
description: Import a Scrivener project (.scriv bundle) into Ideorix — preserves manuscript prose, binder structure, characters, places, and notes
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the technical protocol document. The user-facing skill lives in `scrivener-import.md` (same folder) — that's where the trigger phrases and branding rule live. This file is loaded by reference during import execution.


> **Powered by Ideorix** — The Manuscript & Screen Engine

# Scrivener Importer

## Purpose

Convert a Scrivener project (`.scriv` bundle) into a working Ideorix
project. Handles two cases: (a) **fully drafted manuscripts** — chapter
prose extracted into Ideorix chapter files; and (b) **outline-only
projects** — synopses become brief content, no prose yet. Both cases
build a complete Story Bible from the binder structure.

This is a **one-way import.**

## When to Use

Trigger phrases:
- "Import from Scrivener"
- "Import my Scrivener project"
- "Bring my Scrivener work across"
- "Scrivener import"
- "I have a Scrivener project"

## Prerequisites

The user provides a `.scriv` bundle. Two acceptable forms:
1. A `.zip` of the `.scriv` directory (recommended for cloud transfer)
2. The `.scriv` directory itself (if working locally)

Place at `~/Documents/Ideorix-Projects/imports/` or have the path ready.

## Input Format Reference

A Scrivener 3 project is a directory bundle:

```
{Project Name}.scriv/
├── {Project Name}.scrivx     ← binder XML (project structure)
├── Files/
│   └── Docs/                  ← per-item content files
│       ├── {id}.rtf            ← body content (RTF — chapters, character bios)
│       ├── {id}_synopsis.txt   ← plain-text synopsis (one-line summary)
│       └── {id}_notes.rtf      ← RTF notes
├── Settings/
└── Snapshots/
```

**Binder XML structure** (`{Project Name}.scrivx`):

```xml
<ScrivenerProject Version="1.5">
  <Binder>
    <BinderItem ID="0" Type="DraftFolder">
      <Title>Manuscript</Title>
      <Children>
        <BinderItem ID="3" Type="Folder">
          <Title>Saturday</Title>
          <Children>
            <BinderItem ID="4" Type="Text">
              <Title>Chapter One</Title>
            </BinderItem>
            ...
          </Children>
        </BinderItem>
        ...
        <BinderItem ID="200" Type="Folder">
          <Title>Characters</Title>
          ...
        </BinderItem>
        <BinderItem ID="211" Type="Folder">
          <Title>Places</Title>
        </BinderItem>
        <BinderItem ID="212" Type="Folder">
          <Title>Notes</Title>
        </BinderItem>
      </Children>
    </BinderItem>
    <BinderItem ID="2" Type="TrashFolder">...</BinderItem>
  </Binder>
</ScrivenerProject>
```

**Item types:**
- `DraftFolder` — the manuscript root (always ID 0)
- `Folder` — a grouping (e.g. "Saturday", "Characters", "Places")
- `Text` — a leaf document (a chapter, scene, or character bio)
- `TrashFolder` — ignore entirely

**Content lookup by binder ID:**
- Body prose: `Files/Docs/{id}.rtf` (may not exist if outline-only)
- Synopsis: `Files/Docs/{id}_synopsis.txt`
- Notes: `Files/Docs/{id}_notes.rtf`

## Processing Pipeline

### Step 1: Locate and unpack

If user provides a `.zip`, extract to a temp directory. Walk the result
to find the `.scriv` bundle inside (the zip may contain it at the root or
nested).

### Step 2: Parse the binder XML

**Read-Verification HARD GATE applies (see `read-verification.md`).**
Verify the `.scrivx` Read returned content above threshold (≥ 100
chars). The Read tool can return success metadata with empty content
on certain Scrivener bundle structures (older project format
versions, locked permissions, oversized binders). Empty `.scrivx`
content would parse to an empty BinderItem tree and a project with
zero chapters. The same gate applies in Step 4 — every Text-item
nested document MUST be verified to return content above the
per-format threshold; any document whose Read returns empty is
flagged in `FAILED_READS` and surfaced to the user with resolution
options before the binder tree is finalised.

Read `{Project Name}.scrivx`. Walk the BinderItem tree, building an
in-memory tree:

```python
{
  id: "0", type: "DraftFolder", title: "Manuscript",
  children: [
    {id: "3", type: "Folder", title: "Saturday", children: [
      {id: "4", type: "Text", title: "Chapter One", children: []},
      {id: "5", type: "Text", title: "Rick Opens", children: []},
      ...
    ]},
    ...
  ]
}
```

### Step 3: Identify top-level sections

Inside the DraftFolder (Manuscript), look for these well-known folders:
- **Chapter/scene folders** — typically grouped by Part, Day, or Act
  (everything that ISN'T Characters/Places/Notes/Research)
- **Characters** folder — character bios
- **Places** folder — location entries
- **Notes** folder — research notes
- **Research** folder (alternative name for Notes)

If a folder name doesn't match a known pattern, treat it as a chapter
group (since Scrivener users freely customise folder names).

### Step 4: Extract each Text item's content

For each Text item in the binder, attempt to load:
1. Body RTF: `Files/Docs/{id}.rtf` — if present, this is the prose
2. Synopsis: `Files/Docs/{id}_synopsis.txt` — always check
3. Notes: `Files/Docs/{id}_notes.rtf` — optional

Convert RTF to markdown using the embedded RTF parser. Strip RTF control
codes, preserve paragraph breaks, and normalise inline formatting (italic,
bold, em dashes).

**Detect outline-only vs full-prose mode:**
- If MOST chapter items have body `.rtf` files → full-prose mode
- If MOST chapter items only have `_synopsis.txt` → outline-only mode
- Mixed → treat as outline-only with partial drafts (warn the user)

### Step 5: Strip Plottr template content

Some `.scriv` files come from Plottr's "Export to Scrivener" feature. In
these, synopses contain Plottr template instructions. Detect by the
`--- Add Your Details Above this Line ---` marker. Strip everything
below the marker (template content) before using the synopsis.

This is the same template-stripping rule as the Plottr Importer — see
`plottr-importer.md`.

### Step 6: Preview and confirm

Display a summary:

```
Scrivener import preview:
  Title:        {ProjectTitle from .scrivx or filename}
  Mode:         {Full prose | Outline-only | Mixed}
  Chapters:     {count of Text items in chapter folders}
  Characters:   {count of Text items in Characters folder}
  Places:       {count}
  Total words:  {sum of body RTF word counts, if any}

Proceed? (yes / cancel)
```

### Step 7: Build the Story Bible

Map binder content to Story Bible sections:

| Story Bible Section | Source |
|---|---|
| Section 1 (Title, etc.) | ProjectTitle from `.scrivx` |
| Section 2 (Characters) | Each Text item in the Characters folder. Body RTF → bio block; synopsis → short description. |
| Section 5 (Locations) | Each Text item in the Places folder |
| Section 11 (Timeline) | Top-level chapter folders if they look like dates/days |
| Section 12 (Chapter Outline) | Chapter Text items in binder order, with synopsis as the Section 12 entry text |
| Section 13 (Beat Structure) | Empty unless beat templates are detected |
| Section 14 (Chekhov's Guns) | Empty — Scrivener doesn't track guns |

### Step 8: Build manuscript files (full-prose mode only)

For each chapter Text item with a body `.rtf`:
1. Convert RTF → markdown
2. Save to `engine-data/chapters/ch{NN}.md`
3. Save to `manuscript/chapters/chapter-{NN}.docx` (the user-facing copy)
4. Generate a chapter summary from the prose for `engine-data/summaries/`

For outline-only items: skip — chapters will be generated by the Architect/Writer using the Section 12 outline.

### Step 9: Reduced Phase 1 setup

Scrivener doesn't record:
- Genre, dialect, length tier, POV preference, voice profile, pen name
- Romance subplot, heat level, tropes, beat structure, Chekhov's guns

Ask for these during the post-import setup. Skip questions that the binder structure already answers (chapter outline source, etc.).

### Step 9b: Post-Import Lockfile Generation (MANDATORY)

After the Story Bible is assembled and setup is complete, generate
MODERN MODE infrastructure:

1. **Entity Canon Lockfile** — Generate `entity-canon.md` from
   imported characters, locations, and objects. Verify with Bash ls.
2. **Pipeline Checkpoint** — Generate `pipeline-checkpoint.md` (v2
   schema). For full-prose imports, populate Chapter Progress rows
   with `Written: Yes` for existing chapters. For outline-only, header
   rows only. Verify with Bash ls.
3. **Running Banlist** — Generate empty `running-banlist.md` starter.
   Verify with Bash ls.
4. **Forbidden root-file scan** — Bash ls `engine-data/` and confirm
   no forbidden files present.

5. **Architect Mode flag (MANDATORY — v2.7.1+).** Imported
   material is user-supplied canon by definition; the import
   flow MUST set Architect mode so downstream agents
   (Architect, Writer, Quality Guardian) treat the imported
   content as authoritative rather than as raw material to
   reinterpret. Write the following to
   `engine-data/project-config.md`:

   ```markdown
   architect_mode: true
   architect_mode_set_at: {ISO 8601 timestamp}
   architect_mode_source: scrivener-import
   import_source: scrivener
   ```

   Verify the write with Bash ls; read back to confirm.
   Every downstream agent reads `architect_mode` and applies
   its Architect Mode Binding (see `blueprint-protocol.md` §
   Architect Mode Binding, `prose-protocol.md` § Architect Mode
   Binding, `quality-gate.md` § Architect Mode Binding).

6. **Source-canon mirror (MANDATORY — v2.7.1+).** Copy the
   imported user material into
   `source-canon/scrivener-import/` so the Step 0 filesystem
   trigger fires uniformly across BYO-canon and import paths.
   The mirror is read-only canon — the engine reads from it
   but never writes back. The engine-data/ files are the
   WORKING copy; source-canon/ preserves the original imported
   state for reference.

**The imported Story Bible is the user's canon.** Downstream
agents execute the user's characters, not improve them. The
Architect mode flag set in Step 5 above MAKES THIS
STRUCTURALLY ENFORCED rather than convention-only. See
`blueprint-protocol.md` § Architect Mode Binding,
`outline-builder.md` § Anti-Rewriting Rule.

### Step 10: Build the workspace and hand off

Create the standard Ideorix project structure. For full-prose mode, hand
off to **Continue Writing** (chapters exist, ready for editorial pipeline).
For outline-only mode, hand off to **Story Bible review → chapter
generation**.

## Anti-Patterns

1. **Do NOT include Scrivener Trash folder content.** Trash items should
   be ignored entirely.
2. **Do NOT lose binder hierarchy.** Folder structure conveys grouping
   intent (Parts, Days, Acts) — preserve it as Section 11 (Timeline) or
   chapter grouping metadata.
3. **Do NOT include Plottr template content** in synopses — strip below
   the `--- Add Your Details Above this Line ---` marker.
4. **Do NOT silently merge same-named items.** If two characters have
   the same name in different binder positions, preserve both with a
   disambiguator and warn the user.
5. **Do NOT discard `_notes.rtf` content.** Notes often contain valuable
   author intent — append to the relevant Story Bible section as
   "Author notes" rather than dropping.

## Error Handling

| Error | Response |
|---|---|
| `.scrivx` file missing | Surface error, ask user to verify the bundle |
| Binder XML malformed | Fall back to filename-based parsing |
| RTF parse failure | Skip that item, warn user, continue |
| Body RTF missing for chapter | Treat as outline-only for that chapter |
| Trash folder contains items | Ignore — never import |
| Custom folder name (e.g. "Plot Threads") | Treat as chapter group; preserve name as section metadata |
