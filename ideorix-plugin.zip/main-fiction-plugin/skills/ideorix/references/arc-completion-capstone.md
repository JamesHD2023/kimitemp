---
name: arc-completion-capstone
description: "Gated whole-manuscript cross-track arc-coherence capstone (the first real consumer of context-budget-gate.md). Runs only when the gate returns GLOBAL-ELIGIBLE; reads the entire manuscript + bible + the three existing arc ledgers (motif, injury, Chekhov's gun) into a single PARENT context, then verifies the three arc tracks cohere AS A SYSTEM — not the per-track verification the existing Class B subagent audits already do, but the cross-track interactions those audits structurally cannot see. Fail-closes to 'covered by per-track windowed audits' so cost-saver projects are unaffected. Engine-neutral; mirrored byte-identically across fiction and nonfiction (NF runs the same cross-track pass over its arc analogues — recurring-imagery, claim-evolution, evidence-callback)."
version: "2.7.100"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Arc-Completion Capstone — Cross-Track Whole-Manuscript Coherence

## Purpose

Verify that the manuscript's three arc tracks — **leitmotif**,
**injury accumulation**, and **Chekhov's gun setup/payoff** (the
third track names differently per engine — see "Non-fiction
analogue" below) — cohere **as a system** at full-book scale, not
just independently. The existing Class B subagent audits
(`leitmotif-tracker.md`, `injury-accumulation.md`, plus the
setup/payoff tracker — chekhovs-guns.md in fiction; the
evidence-callback analogue in NF) each verify their own track
end-to-end. None of them can see the *interactions* between
tracks, because each is dispatched as a separate subagent with its
own context window and its own focused brief.

Examples of cross-track coherence this capstone catches and the
per-track audits structurally cannot:

- The "fear of fire" leitmotif planted in chapter 3 + the burn injury
  sustained in chapter 11 + the Chekhov's-gun fire-extinguisher
  planted in chapter 4 + the climactic rescue scene — do all four
  arcs land on the same beat, or do they pay off in scattered
  chapters that dilute the dramatic peak?
- A character whose recovery arc (injury) outpaces their internal-
  state arc (motif: "weakness becoming strength") so the prose
  shows them physically healed but still emotionally fragile in a
  scene that demands the opposite.
- A Chekhov payoff that fires correctly but is undermined by a
  motif callback in the same chapter that contradicts its dramatic
  weight.

## Relationship to the existing trackers (NOT a replacement)

This is a **fourth, cross-cutting** verification, additive to the
three per-track audits — never a substitute. The per-track audits
remain mandatory for all tiers and unchanged. Per-chapter delta
trackers (`leitmotif-tracker-delta.md`, `injury-accumulation-delta.md`)
remain mandatory and ungated. This capstone runs after the per-track
Class B audits complete, consumes their ledgers, and reasons about
the spaces between tracks that the per-track scope by design cannot
reach.

## Why it needs 1M context (the honest case)

The per-track audits work because each subagent's working set is
narrow: one motif plan + one bible + the prose. Cross-track
reasoning requires the parent to hold simultaneously:

- The full manuscript prose (every chapter)
- `engine-data/story-bible.md` (fiction) or `research-bible.md` (NF)
  — the canonical motif / character / arc plans
- `engine-data/reports/leitmotif-ledger.md` — all motif instances
  across all chapters (from the delta tracker's running accumulation)
- `engine-data/reports/injury-ledger.md` — all open + closed
  injuries with onset/recovery
- `engine-data/reports/chekhovs-guns-ledger.md` — every planted gun
  with planted-chapter / payoff-chapter / status
- The architectural overview / outline showing planned dramatic
  peaks

A typical 90k-word novel + bible + three ledgers + overview is
~150–220K tokens. Holding all of it simultaneously is the load that
makes cross-track reasoning possible, and is exactly what
`context-budget-gate.md` was built to authorize.

## Why parent-context, not a fourth subagent

A subagent dispatched to do this work would face two compounding
risks the parent does not:

1. **Subagent-output fabrication.** The exact silent-failure class
   `subagent-output-verification.md` exists to police: a subagent
   returns "verified all arcs land coherently" without actually
   having read everything. The parent's own Read tool calls are
   directly inspectable; subagent returns are not.
2. **Context redundancy.** A subagent would need the whole working
   set loaded into its window too — doubling the token cost while
   adding the verification overhead. The parent already has the
   bandwidth budget by virtue of the gate's `GLOBAL-ELIGIBLE`
   verdict; using it directly is cheaper and safer.

## Gate-binding (FAIL-CLOSED)

This capstone is a **registered consumer** of `context-budget-gate.md`.
Before any work:

1. Call the gate. `DECISION = WINDOWED` → log "arc-completion
   capstone skipped (context budget windowed); cross-track
   coherence covered per-track by Stage 9.5 Class B audits" in the
   Validation Briefing's domain-by-domain summary (the
   validate-dispatcher already supports out-of-scope skip
   reporting) and exit. No further work. **This is the entire
   cost-saver experience — exactly today's pipeline.**
2. `DECISION = GLOBAL-ELIGIBLE` → proceed to the capstone procedure.
3. The gate's `Cost-Consent` step fires before the first large-
   context Read of the manuscript, not before this spec is reached
   — the consent decision is the gate's, not the consumer's.

## When this runs

After Stage 9.5 (Canon Validation Sweep) completes — i.e., after
`leitmotif-tracker.md`, `injury-accumulation.md`, and the
Continuity Guardian's Chekhov's-gun verification have all returned
their per-track verdicts and merged into the Validation Briefing.
The capstone reads the briefing's per-track verdicts as input
context, then performs the cross-track pass.

Dispatched at the `full` level of `validate-dispatcher.md` — when
the dispatcher would otherwise close the briefing, it instead
appends the arc-completion section if the gate authorizes.

## Capstone procedure

**Step 1 — Working-set assembly (in the parent context).** Read in
this order, each under `read-verification.md` HARD GATE:

1. `engine-data/story-bible.md` (fiction) or `research-bible.md` (NF)
2. The architectural overview / outline
3. `engine-data/reports/leitmotif-ledger.md`
4. `engine-data/reports/injury-ledger.md`
5. `engine-data/reports/chekhovs-guns-ledger.md`
6. Every `engine-data/chapters/ch{NN}.md`, in chapter order

Any HARD GATE failure aborts the capstone with the partial-read
divergence message (`read-verification.md` controls the message);
do not proceed against a truncated working set. The Validation
Briefing records the abort with the file(s) that failed.

**Step 2 — Beat-anchored arc grid.** Construct an internal grid
(reasoning artifact, not a written file at this step):

| Chapter | Plot Beat | Motif Instances | Open Injuries | Active Guns | Coherence Notes |

The grid binds the three arc tracks to the structural beats so
cross-track interactions become legible: a motif callback in a
recovery chapter, a Chekhov payoff that overlaps a motif's planned
evolution point, a planned dramatic peak where two arcs are
expected to converge.

**Step 3 — Cross-track coherence checks.** For each of the seven
checks below, scan the grid and the prose. Each finding cites the
specific chapter + the specific arcs involved + the prose
evidence:

1. **Peak convergence.** At each planned dramatic peak (climax,
   penultimate beat, mid-point reversal), do the arcs the bible
   committed to converge in the same chapter? Misalignment is a
   FINDING.
2. **Recovery/motif sync.** For each character with a tracked
   injury, does the motif evolution attached to that character
   stay coherent with their physical recovery (e.g., the motif
   does not declare them "made whole" in a chapter where the
   injury ledger has them still convalescent)?
3. **Payoff/motif weight.** Does each Chekhov payoff land in a
   chapter where its associated motif (if any) supports rather
   than contradicts the dramatic register?
4. **Same-chapter saturation.** Does any single chapter carry
   three+ arc landings that would dilute each other? (Conversely,
   are arc landings *too* clustered around one beat at the
   expense of others?)
5. **Orphan landings.** Does any arc track land in a chapter the
   bible did not plan a beat for, suggesting an accidental
   landing rather than a structural one?
6. **Forgotten arc.** Does any track go silent for more than the
   bible-declared callback window, then reappear, in a way that
   suggests the writer forgot the track and revived it mechanically?
7. **Cross-arc contradiction.** Does any single chapter contain
   two arc events that contradict each other (a motif callback
   suggesting hope + a Chekhov payoff suggesting despair in the
   same paragraph, without a deliberate ironic register)?

**Step 4 — Verdict and findings.** Per check: PASS / FINDING /
INFO. The capstone returns three artifacts:

1. The Validation Briefing's new **Arc-Completion** section,
   listing each check's verdict and per-finding details
   (chapters, arcs, prose evidence).
2. `engine-data/reports/arc-completion-capstone-{ISO}.md` — the
   full grid + check-by-check log, written under Class-2 File-
   Write Hygiene (`core-pipeline.md`).
3. A pointer in `run.log` recording the gate decision, the
   working-set token estimate, and the capstone's exit verdict.

**Step 5 — Disposition.** FINDINGs are advisory (capstone never
auto-blocks publication — that is the Handoff Gate's role); the
user resolves each finding before pre-publication sign-off. The
existing per-track audits remain the gates that block on hard
errors; the capstone's role is to surface the structural
interactions only.

## What this does NOT do

- **Does NOT replace** the per-track Class B audits. They run
  first; the capstone consumes their output.
- **Does NOT replace** the per-chapter delta trackers. They run
  every chapter, untouched, for every tier.
- **Does NOT block on findings.** All cross-track findings are
  advisory; they appear in the briefing, the writer addresses them
  before publication. The Handoff Gate's per-track blocking
  remains the publication HARD GATE.
- **Does NOT auto-detect model or context.** It registers against
  `context-budget-gate.md`, which uses the declared tier per its
  fail-closed contract.
- **Does NOT run on cost-saver projects.** The gate skips it,
  cleanly, with a documented "out-of-scope" marker in the briefing.

## Non-fiction analogue

Engine-neutral by design. NF tracks the same three arc classes
under different names: **recurring imagery** (leitmotif analogue),
**claim/argument evolution** (injury-recovery analogue: a claim
introduced as tentative must be developed, qualified, and either
confirmed or retracted across the book), and **evidence callback**
(Chekhov's-gun analogue: a piece of evidence introduced early must
either pay off in a later argument or be acknowledged as a thread
the book chose not to pursue). The seven cross-track checks apply
identically; only the source-of-truth files change names per the
engine.

## Silent-Failure Audit

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (manuscript chapters / bible / three ledgers) | "Read succeeded with N bytes" | Empty / truncated extraction of any working-set file → capstone reasons on a partial book and reports cross-track verdicts as if the missing chapter never existed | `read-verification.md` HARD GATE applied per-file; ANY failure aborts the capstone with the partial-read divergence message rather than proceeding against a truncated working set |
| Gate consultation (`context-budget-gate.md`) | "Gate returned GLOBAL-ELIGIBLE" | A spoofed / mis-parsed gate return runs the capstone on a cost-saver configuration | The gate is the single source of truth for tier; the capstone does not second-guess the gate's verdict. The gate itself is fail-closed (every degenerate path → WINDOWED), so a spoof would only ever downgrade the run, not upgrade it |
| Cross-track reasoning (the capstone's own LLM judgment) | "Verified arcs cohere across tracks" | Hallucinated PASS — the model claims it checked all seven cross-track checks but actually only addressed a subset | Each of the seven checks emits its own verdict line with cited chapters + prose evidence; checks without evidence emit INFO not PASS; the full grid is written to `engine-data/reports/arc-completion-capstone-{ISO}.md` as inspectable artifact. The capstone is NOT a HARD GATE on publication — it is advisory — so the cost of a missed cross-track finding is feedback the writer doesn't see, not a corrupted manuscript |
| Write (Validation Briefing section + capstone report) | "Write succeeded" | Subdir flush / partial write leaves a half-written briefing | Class-2 File-Write Hygiene (Edit/Write tool, never bash cat-and-mv) per `core-pipeline.md`; the report lands under `engine-data/reports/` so the PostToolUse Engine-Data Integrity Hook re-verifies the artifact |

## Routing

- **Consults:** `context-budget-gate.md` (FAIL-CLOSED to skip if not authorized)
- **Reads under HARD GATE:** `read-verification.md`
- **Reads the per-track verdicts produced by:** `leitmotif-tracker.md`,
  `injury-accumulation.md`, plus the engine-specific setup/payoff
  tracker (chekhovs-guns.md in fiction; the evidence-callback
  analogue in NF)
- **Writes under:** Class-2 File-Write Hygiene (`core-pipeline.md`)
- **Dispatched at `full` level of:** `validate-dispatcher.md`
- **Runs after:** Stage 9.5 (Canon Validation Sweep) completes
- **Does not block:** the Handoff Gate (advisory only)
