---
name: heritage-text-refiner
description: Modernizes public domain source texts — updates archaic spelling, fixes OCR artifacts, applies Chicago Manual of Style formatting while preserving original voice and meaning
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Heritage Text Refiner (Source Material Processor)

## File Location Discipline (MANDATORY)

The modernized text output MUST be written to the
canonical project folder per the parent flow's
destination decision (typically
`~/Documents/Ideorix-Projects/[Title]/manuscript/`). The
parent `heritage-text.md` flow's File Location Discipline
controls destination; this refiner inherits that
destination and MUST NOT write to the agent's working
directory, a sandbox path, or the parent
`~/Documents/Ideorix-Projects/` folder. See
`core-pipeline.md` § File Location Discipline and
`heritage-text.md` § File Location Discipline.
**HARD GATE — BLOCKING.**

## Snapshot before overwrite (v2.7.41 HARD GATE — `destructive-mutation-snapshot.md`)

This protocol modifies user-supplied heritage source text in
place. Before any overwrite, the refiner MUST snapshot the
current source to `engine-data/snapshots/{stem}.pre-heritage-text-refiner.{ISO-timestamp}.{ext}`
per the canonical destructive-mutation snapshot protocol. See
`destructive-mutation-snapshot.md` for the full HARD GATE
sequence (mkdir, cp, verify with `ls -la`, abort on failure).

Heritage text is especially valuable to snapshot: original
public-domain transcriptions may not be re-fetchable, so a
recoverable original is the only reliable reversion path.

## File-Write Hygiene (MANDATORY)

This protocol performs heavy text modification (modernization,
OCR repair, formatting) which often involves chapter-scale
rewrites of large source files. The chained-Edit truncation
safeguard documented in `core-pipeline.md` § Chained-Edit
Truncation Safeguard applies in full:

- **Prefer Write over chained Edit for chapter / book-scale
  rewrites.** Heritage modernization typically rewrites large
  spans; a single bash-heredoc + mv Write per chapter is safer
  than accumulating Edit patches.
- **Cap individual Edit replacements at ~2 KB** when Edit is
  used for targeted fixes (e.g., a specific OCR artifact
  cluster).
- **Run `scripts/word-count-check.sh` after every chapter file
  this protocol writes or edits.** Heritage source files are
  often >15 KB and modernization spans push close to the
  truncation-vulnerability threshold.
- **Verify on-disk integrity via Bash** before declaring a
  chapter modernization complete.

**HARD GATE — BLOCKING.** Truncation in a heritage source file
is especially serious — the original public-domain text may not
be re-fetchable without restarting the modernization, so
silent loss is doubly costly.

## Purpose

Process public domain texts into clean, modern-readable source material — modernize
archaic spelling, repair OCR transcription errors, and apply Chicago Manual of Style
formatting while **strictly preserving** the original words, voice, sentence structure,
and meaning.

This is a **fidelity-first** tool. It does NOT rewrite, paraphrase, or substitute
modern synonyms. It updates only the *spelling* of existing words to current
conventions and corrects obvious transcription defects from digitization.

## When to Use

- **"Refine this heritage text"** — Full processing of a public domain source
- **"Clean up this classic text"** — Same as above
- **"Modernize the spelling in this text"** — Spelling-only pass
- **"Fix OCR errors in this text"** — Transcription repair focus
- **"Prepare source material"** — Process a text for use as reference/inspiration
- **"Process this public domain text"** — General heritage text processing
- **"Format this classic text"** — Formatting and style normalization

## Use Cases Within Ideorix

1. **Research Material** — Clean up public domain reference texts before using them
   as inspiration for Story Analysis or world-building
2. **Adaptation Prep** — Prepare classic texts that inform a new adaptation or retelling
3. **Style Study** — Produce readable versions of archaic texts for craft analysis
4. **Anthology Assembly** — Process multiple heritage texts into consistent, readable format

## Processing Pipeline

### Step 1: Intake Assessment

Before processing, assess the source material:

```
INTAKE CHECKLIST:
- [ ] Estimated word count of full text
- [ ] Source era (pre-1900, 1900-1950, 1950+)
- [ ] Text type (prose, poetry, drama, essay, mixed)
- [ ] OCR quality estimate (clean / moderate artifacts / heavy artifacts)
- [ ] Chapter/section structure present? (Y/N)
- [ ] Language variant (British English, American English, other)
```

Report findings to the user before proceeding.

### Step 2: Segmentation

Split the full text into processing segments of approximately **1,000 words each**,
breaking only at sentence boundaries.

**Segmentation Rules:**
- Target: 1,000 words per segment
- Hard ceiling: 1,600 words (force-split at word boundaries if a single sentence exceeds this)
- Never break mid-sentence unless the hard ceiling is hit
- Preserve all original line breaks, paragraph breaks, and stanza divisions
- Track segment index for sequential reassembly

### Step 3: Refinement Pass (Per Segment)

Process each segment with the following mandate:

#### System Directive

```
You are a heritage text specialist performing fidelity-first modernization of
public domain source material. Your mandate is preservation with clarity — make
the text accessible to modern readers without altering the author's voice.
```

#### Refinement Rules

1. **Spelling Modernization**
   - Update archaic spellings to current conventions (e.g., "colour" stays as-is
     if British source; "honour" → "honor" only if target is American English)
   - Change obsolete letter forms (e.g., "ſ" long-s → "s")
   - Normalize archaic contractions where they cause confusion
   - **NEVER substitute a different word** — only modernize the spelling of the
     existing word

2. **OCR Artifact Repair**
   - Fix character misreads (e.g., "rn" misread as "m", "l" as "1", "O" as "0")
   - Repair broken words from line-wrap artifacts
   - Restore punctuation damaged by scanning (e.g., periods read as commas)
   - Rejoin hyphenated words split across page boundaries

3. **Style Normalization (Chicago Manual of Style)**
   - Apply modern punctuation conventions (serial comma, em-dash usage, quotation marks)
   - Normalize inconsistent spacing and indentation
   - Standardize ellipsis formatting
   - **Do NOT alter sentence structure or meaning** — if original grammar conflicts
     with Chicago style, preserve the original

4. **Structural Formatting**
   - Format chapter/section titles as Markdown H1 headers: `# Chapter I`, `# Prologue`, etc.
   - Preserve original paragraph breaks exactly
   - For poetry: maintain original line breaks and stanza divisions exactly
   - For drama: preserve speaker labels and stage directions
   - Remove footnote markers and footnote text (these are editorial additions, not
     original text)

5. **Capitalization Preservation**
   - Maintain the original capitalization choices (e.g., if "Nature" is capitalized
     in the source, keep it capitalized)

6. **Output Format**
   - All output in Markdown
   - One segment at a time, maintaining segment index

### Step 4: Sequential Assembly

After all segments are processed:

1. Concatenate segments in order by segment index
2. Verify no content was dropped between segment boundaries
3. Check that chapter/section headers flow correctly
4. Perform a final consistency pass on formatting

### Step 5: Delivery

Present the refined text to the user with a summary report:

```
REFINEMENT SUMMARY
──────────────────
Source title:        [title]
Source era:          [era]
Text type:           [prose/poetry/drama/mixed]
Total word count:    [count]
Segments processed:  [N]

Changes applied:
- Spelling updates:  [count]
- OCR repairs:       [count]
- Footnotes removed: [count]
- Headers formatted: [count]
- Style normalizations: [count]

Fidelity note: No words were substituted, added, or removed.
Only spelling, formatting, and transcription errors were addressed.
```

## Quality Standards

### Fidelity Checks

After each segment, verify:

| Check | Pass Criteria |
|-------|--------------|
| **Word Preservation** | No words added, removed, or substituted — only spelling changed |
| **Sentence Integrity** | All original sentences present; structure unmodified |
| **Line Break Fidelity** | Poetry stanzas and paragraph divisions match source |
| **Capitalization Match** | Original capitalization choices preserved |
| **Meaning Preservation** | No semantic drift from spelling or formatting changes |

### Automatic Failures

The following trigger an automatic redo of the segment:

- Any word substituted with a synonym or modern equivalent
- Sentence structure altered (reordering, combining, splitting)
- Poetry line breaks changed
- Original capitalization overridden without OCR-repair justification
- Content added that was not in the source (explanatory notes, glosses, etc.)

## Integration with Ideorix Pipeline

This skill operates **independently** of the manuscript generation pipeline.
It is a utility skill that can be invoked:

- **Before Phase 1** — To prepare reference material for a new project
- **Alongside Story Analysis** — To clean up a source text before structural analysis
- **Standalone** — As a dedicated text processing task unrelated to manuscript generation

The refined output can be saved to the project's `reference-materials/` directory
for use during world-building and writing phases.

## Supported Source Formats

- Plain text (pasted directly)
- Markdown files
- Text extracted from Google Docs (via manual paste)
- Text extracted from PDFs (via manual paste)
- Project Gutenberg format (with header/footer removal)

## Limitations

- Does not translate between languages (English sources only)
- Does not add annotations, glossary entries, or explanatory notes
- Does not modify sentence structure, even if archaic grammar is confusing
- Does not handle image-based PDFs (text must be extracted first)
- Maximum recommended source length: 150,000 words per session
