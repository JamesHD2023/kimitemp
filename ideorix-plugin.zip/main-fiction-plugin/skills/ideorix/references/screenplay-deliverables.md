---
name: screenplay-deliverables
description: "Industry submission packet — logline, query letter, one-sheet, short treatment, and 25-Checkpoint Revision Checklist generated alongside the screenplay"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Screenplay Deliverables — Industry Submission Packet

## Purpose

A finished screenplay is one of several materials a writer needs to
*sell* the work. Per Trottier's *Screenwriter's Bible*, the
professional submission packet includes the screenplay plus four
written deliverables (logline, query letter, one-sheet, short
treatment) and one diagnostic worksheet (the 25-Checkpoint Revision
Checklist).

This agent generates all five alongside the screenplay so the user
walks away with a **complete submission packet**, not just the script.

## When this runs

- **Automatically** after the screenplay completes the full Pre-Delivery
  Sweep and is ready for delivery. The user is offered the packet:

  ```
  Your screenplay is complete and has passed the 10-pass craft sweep.
  Generate the Industry Submission Packet alongside it?

    A. Yes, generate the full packet
       (logline, query letter, one-sheet, short treatment,
        25-Checkpoint Revision Checklist, Production Notes)

    B. Just the logline and query letter
    C. Just the 25-Checkpoint Revision Checklist
    D. Just the Production Notes
    E. Skip — I'll do these myself
  ```

- **On demand** from a finished screenplay (Ideorix-generated or
  imported). Trigger phrases: "Build my submission packet," "I need a
  query letter for my script," "Write a treatment for this," "Run the
  25-checkpoint revision."

## Deliverable 1 — Logline

A logline is a one-sentence pitch (≤25 words) that captures the
script's central character, goal, opposition, and stakes. It is
required for almost every submission, contest, and pitch.

### The Trottier formula

```
A [character] must [goal] before [opposition / deadline / stake]
or risk [consequence].
```

### Worked examples (all from produced films)

- *Air Force One*: A US president must save his family from
  hijackers on his own plane.
- *Juno*: A pregnant teenager must navigate adoption while
  discovering what family means.
- *The Kid*: A cynical lawyer must reconnect with his childhood
  self — literally — before he loses what's left of his life.
- *Get Out*: A young Black man visits his white girlfriend's
  family for the weekend and discovers something far more sinister
  than awkwardness.

### Generation protocol

Pull from the Story Bible / Character Architecture:

1. **Character** — protagonist's name and one-word role (the "lawyer,"
   "the pregnant teenager," "the marine"). Specific, never generic.
2. **Goal** — the protagonist's Want, expressed actively.
3. **Opposition / deadline / stake** — what stops them, when, or what
   they lose if they fail.
4. **Consequence** — what the audience cares about if they fail.

Generate **3 logline candidates** of varying angle (action-led,
character-led, theme-led) and present to the user. The user picks one
or asks for revision.

### Output format

```
Logline (Option 1 — action-led):
{generated logline}

Logline (Option 2 — character-led):
{generated logline}

Logline (Option 3 — theme-led):
{generated logline}

Recommended: Option {N}
{one-line reason — typically the one that lands the genre and stakes hardest}
```

## Deliverable 2 — Query Letter

A one-page business letter that precedes the script submission. It is
the first thing 90% of agents and managers see; if it doesn't sell
the read, the script never opens.

### Structure

| Section | Length | Purpose |
|---|---|---|
| **Hook / opening** | 1–2 sentences | Grab attention with the logline or a unique premise framing |
| **Story core** | 1–2 paragraphs (~100–150 words) | Elevator pitch of plot — character + Want + opposition + stakes. Tease the ending without spoiling it. |
| **Author bio** | 2–3 sentences (optional) | Relevant writing credits, life experience pertinent to the script, or contests / fellowships. If none, omit cleanly — never apologise. |
| **Closing** | 2–3 lines | Professional sign-off + contact details |

### Tone rules

- Professional, enthusiastic, confident — never desperate, never
  oversold.
- No "this will be a hit" / "this has never been done before" / "I
  guarantee."
- No synopsis (save for the one-sheet).
- No starting with plot summary — start with the hook.

### Generation protocol

1. Use the chosen logline as the hook (or open with a sharper one-line
   premise framing).
2. Draft the story core from the script's Catalyst → Big Event →
   Midpoint reframing → Crisis stake. 100–150 words. Do not summarise
   the climax.
3. Insert the user's bio if provided at intake; otherwise omit the
   bio paragraph entirely (do not invent credentials).
4. Close with: contact name, email, phone (only if user provided),
   WGA registration number (only if user provided).

### Output template

```
[YOUR NAME]
[YOUR ADDRESS — optional]
[YOUR EMAIL]
[YOUR PHONE — optional]

[DATE]

[RECIPIENT NAME]
[RECIPIENT TITLE]
[COMPANY]

Dear [RECIPIENT NAME],

[HOOK — the logline or a one-line premise framing]

[STORY CORE — 100–150 words. Plot from Catalyst through Midpoint
reframing, with stakes named. Tease the ending without spoiling it.]

[AUTHOR BIO — 2–3 sentences if relevant. Otherwise omit.]

May I send the full screenplay?

Best regards,
[YOUR NAME]
```

### Length constraint

The whole letter must fit on one page (single-spaced, 12pt Times or
Courier, 1" margins). Flag if the generated draft exceeds one page.

## Deliverable 3 — One-Sheet

A one-page document — typically given to a producer at a meeting or
left behind after a pitch. More visual than a query, less detailed
than a treatment.

### Structure

```
─────────────────────────────────────────────
  [TITLE]
  ([genre], [length])
─────────────────────────────────────────────

LOGLINE: {one sentence, ≤25 words}

[100–150 word synopsis — slightly longer than the query's story core,
reaching into the climax. Written in present tense.]

GENRE: {primary genre}
TONE: {tone reference — "Sicario meets Three Billboards," etc.}
TARGET AUDIENCE: {demographic + mood}
LENGTH: {page count} pages / {minutes} min

COMP TITLES:
- {Comp 1} — {one-line why this is comparable}
- {Comp 2} — {one-line why this is comparable}
- {Comp 3} — {one-line why this is comparable}

WRITER: [Your name]
CONTACT: [email, phone optional]
WGA #: [if registered]
```

### Generation protocol

- Logline: from Deliverable 1.
- Synopsis: 100–150 words. Open with the inciting situation; trace
  through Big Event, Midpoint shift, Crisis. Reveal the climax (this
  is for a producer, not marketing).
- Comp titles: pull from the Market Scout pass if present; otherwise
  ask the user for 3 comp films/shows.
- Tone: pull from the Tone-and-Style preset (S5).

## Deliverable 4 — Short Treatment

A 3–5 page narrative-prose summary of the full story. Often requested
after a successful query or pitch. Written in **present tense**,
**third person**, **no dialogue** (or very sparing — only when a line
is the emotional centre of a scene).

### Structure

| Section | Length | Content |
|---|---|---|
| **Title block** | header | Title, "A Treatment," writer name |
| **Logline** | 1 sentence | from Deliverable 1 |
| **Character introductions** | 1–2 sentences each | Brief, vivid; protagonist + primary antagonist + 2–4 key supporting characters |
| **Act 1** | 1–1.5 pages | Setup → Catalyst → Big Event |
| **Act 2** | 1.5–2 pages | Complications → Midpoint shift → escalation → Crisis |
| **Act 3** | 0.5–1 page | Showdown → Realization → Resolution |
| **Theme / tone** | 0.5 page (optional) | What the script is *really* about; tone references |

### Generation protocol

1. Pull the Beat Sheet (already generated alongside the screenplay)
   and convert each beat to narrative prose.
2. Convert character cues + dialogue + action into present-tense
   third-person narration.
3. Compress 90–120 pages of script into 3–5 pages of prose. Most
   detail compresses; only key dialogue lines preserve.
4. Render as a `.docx` or `.md` file the user can email or print.

### Tone

Treatment prose is **active**, **specific**, and **propulsive** — like
back-of-book copy that doesn't stop. It is not a list of scenes; it
is a story told in summary form. Read like the best half-page film
review you've ever seen, sustained for 4 pages.

### Length variants

- **Short treatment** (default): 3–5 pages. Industry standard.
- **Long treatment** (10–12 pages): on user request — useful for the
  writer's own clarity but not normally submitted.

## Deliverable 5 — 25-Checkpoint Revision Checklist

A diagnostic worksheet adapted from Trottier's *Screenwriter's Bible*
revision framework. The user works through the checklist on their
revision pass — this is **not** automated; it is a structured
self-review document.

### Format

A `.docx` (or `.md`) the user prints or fills in digitally. Each
checkpoint has a question and space for notes.

### The 25 checkpoints (delivered as fillable form)

```
─────────────────────────────────────────────
  25-CHECKPOINT REVISION CHECKLIST
  for: {SCREENPLAY TITLE}
  Generated: {date}
─────────────────────────────────────────────

CONCEPT
─────────────────────────────────────────────
1. Is the story idea solid, fresh, commercial, with legs?
   [ ] Yes  [ ] Needs work  Notes: ____________________

2. Is the title inspiring? Does it grab?
   [ ] Yes  [ ] Needs work  Notes: ____________________

3. Can the logline be summarised in ≤25 words?
   [ ] Yes  [ ] Needs work  Notes: ____________________

4. Is the genre / tone / scope defined and consistent?
   [ ] Yes  [ ] Needs work  Notes: ____________________

5. Do all 7 plot points (Backstory / Catalyst / Big Event /
   Midpoint / Crisis / Showdown / Realization) land on time
   and do their work?
   [ ] Yes  [ ] Needs work  Notes: ____________________

CHARACTER
─────────────────────────────────────────────
6. Does the protagonist have all four elements (Want / Need /
   Flaw / Backstory)?
   [ ] Yes  [ ] Needs work  Notes: ____________________

6b. Does the main cast carry the Character Depth Layer
   (`character-depth.md`)? On screen there is no narration, so the
   OBSERVABLE fields do all the work: a five-register Physical Tell
   Register (mutually distinct across the cast), a Page-One Visual, the
   "believes X / under pressure does Y" contradiction externalised in
   action, an observable final-page state, and — for co-leads — the
   subtext pattern + relational physical anchor. (The Hidden Life drives
   choices but stays off the page.)
   [ ] Yes  [ ] Needs work  Notes: ____________________

7. Does the protagonist have rooting interest within the first
   10 pages?
   [ ] Yes  [ ] Needs work  Notes: ____________________

8. Is the Flaw tested at three structural points (early Act 2,
   Crisis, Showdown)?
   [ ] Yes  [ ] Needs work  Notes: ____________________

9. Does the antagonist have their own logic and motivation?
   Are they as compelling as the protagonist?
   [ ] Yes  [ ] Needs work  Notes: ____________________

10. Are supporting characters distinct? Could any two be
    combined? Is anyone "furniture"?
    [ ] Yes  [ ] Needs work  Notes: ____________________

11. Does the protagonist's arc travel from Want to Need by
    the Realization?
    [ ] Yes  [ ] Needs work  Notes: ____________________

STRUCTURE
─────────────────────────────────────────────
12. Is the Act 1 break (Big Event) a genuine commit point, not
    just a beat?
    [ ] Yes  [ ] Needs work  Notes: ____________________

13. Is the Midpoint a real turn — does something *shift*?
    [ ] Yes  [ ] Needs work  Notes: ____________________

14. Is the Crisis a decision moment, separated from the
    Showdown by 10–15% of pages?
    [ ] Yes  [ ] Needs work  Notes: ____________________

15. Does the Showdown land its emotional and physical climax?
    [ ] Yes  [ ] Needs work  Notes: ____________________

16. Does the Realization deliver the inside-story payoff?
    [ ] Yes  [ ] Needs work  Notes: ____________________

DIALOGUE
─────────────────────────────────────────────
17. Does dialogue carry subtext rather than on-the-nose
    statements?
    [ ] Yes  [ ] Needs work  Notes: ____________________

18. Are character voices distinct (blind identification test:
    cover the cues, can you tell who's speaking)?
    [ ] Yes  [ ] Needs work  Notes: ____________________

19. Have the 7 Deadly Dialogue Sins been audited (exposition,
    speechifying, on-the-nose, derivative, profanity excess,
    pleasantries, repetition)?
    [ ] Yes  [ ] Needs work  Notes: ____________________

SCENES & PROSE
─────────────────────────────────────────────
20. Does every scene have an emotional centre, a motivated
    conflict, escalating turns, and a punch at the end?
    [ ] Yes  [ ] Needs work  Notes: ____________________

21. Have all "talking heads" scenes been blocked with
    meaningful action?
    [ ] Yes  [ ] Needs work  Notes: ____________________

22. Have AI-tell patterns been swept from action lines
    (the timing of / there is something / the kind of)?
    [ ] Yes  [ ] Needs work  Notes: ____________________

23. Are scene headings clean (DAY/NIGHT only, no camera
    directions, no re-establishing master locations)?
    [ ] Yes  [ ] Needs work  Notes: ____________________

24. Is exposition embedded in conflict / action, not
    isolated monologue?
    [ ] Yes  [ ] Needs work  Notes: ____________________

DELIVERY
─────────────────────────────────────────────
25. Has the page-by-page polish pass been completed
    (typos, formatting, page count within target, title
    page complete, contact details correct)?
    [ ] Yes  [ ] Needs work  Notes: ____________________

─────────────────────────────────────────────
  OVERALL READINESS
─────────────────────────────────────────────
  Total Yes: __ / 25
  ≥22 → Ready to submit
  17–21 → Targeted revision needed
  ≤16 → Structural revision needed

  Top 3 priorities for next pass:
  1. ____________________
  2. ____________________
  3. ____________________
```

## Deliverable 6 — Production Notes

A short document flagging the script's production-cost implications.
Useful for producers screening for budget fit, and for writers
targeting indie / mid-budget vs. studio.

### What it captures

| Category | What's tracked |
|---|---|
| **Location count** | Total distinct locations in the script. Threshold: ≤15 = indie-friendly; 16–30 = mid-budget; >30 = high-budget signal. |
| **Named cast count** | Total named speaking characters. Threshold: ≤8 = chamber piece; 9–20 = standard; >20 = ensemble or expensive. |
| **Period setting** | Flag if the script is set in any period requiring specific costume / set / vehicle / language work. Period drama = roughly 2–3x the equivalent contemporary budget. |
| **Major set pieces** | Count of explicit explosions, vehicle stunts, large practical effects, large crowd scenes. Each is a budget-defining item. |
| **VFX-heavy moments** | Count of scenes requiring significant visual effects (creatures, spaceships, weather effects, full CG environments). |
| **Animal performers** | Flag if domestic or wild animals are required for performance. Adds budget and shoot-day complications. |
| **Child performers** | Flag if children are required for substantial roles. Legal / shoot-day restrictions apply. |
| **Stunt-heavy sequences** | Count and type of fight choreography, falls, vehicle work. |
| **International / foreign-location requirements** | If the script requires location-specific shooting (Tokyo, Iceland, the Sahara), flag for budget and scheduling impact. |

### Generation protocol

After the screenplay completes, scan the script for:

- All distinct sluglines → de-duplicate to count unique locations
- All character cues → de-duplicate for named-cast count
- Action lines containing trigger keywords (`explodes`, `crashes`,
  `gunfight`, `chase`, `crowd`, `shatters`, `helicopter`, etc.) →
  set-piece tally
- Genre + setting metadata → period flag
- Action lines mentioning animals as performers → animal flag
- Character ages from intros → child-performer flag
- Trigger words for stunts (`leaps`, `falls`, `wrestles`, `crashes
  through`, `is thrown`) → stunt tally
- Sluglines with foreign / specialised locations → international flag

### Output template

```
─────────────────────────────────────────────
  PRODUCTION NOTES
  for: {SCREENPLAY TITLE}
  Page count: {N} pages
  Estimated runtime: {N} min
─────────────────────────────────────────────

LOCATIONS:           {N} distinct ({indie/mid/high} budget signal)
NAMED CAST:          {N} speaking characters ({chamber/standard/ensemble})
PERIOD SETTING:      {yes/no — period: {era}}
SET PIECES:          {N} (list with page numbers)
VFX-HEAVY MOMENTS:   {N} (list with page numbers)
ANIMAL PERFORMERS:   {yes/no — list animals + scenes}
CHILD PERFORMERS:    {yes/no — count and scope}
STUNT SEQUENCES:     {N} (list with page numbers)
INTERNATIONAL:       {yes/no — locations required}

─────────────────────────────────────────────
BUDGET-TIER ASSESSMENT
─────────────────────────────────────────────

Based on the production indicators above, this script reads as:

  → {INDIE / MID-BUDGET / STUDIO / TENTPOLE}-tier production

Indicative comparable budget range: ${min}M–${max}M
(based on similar produced scripts in this category)

─────────────────────────────────────────────
PRODUCTION-FRIENDLY ADJUSTMENTS (optional)
─────────────────────────────────────────────

If you want to lower the budget tier, the highest-impact adjustments
typically are:

  1. {specific suggestion based on the script's indicators —
     "Combine 6 of the 32 locations" / "Reduce explosions from 7 to 3" /
     "Move the Tokyo sequence to a domestic city"}
  2. {second suggestion}
  3. {third suggestion}

If the budget tier is correct for your target market, ignore these.
```

### When to use Production Notes

- **Always generate** for projects flagged at intake as targeting
  indie / festival / streaming-original markets. These markets care
  about budget feasibility.
- **Optional for studio / tentpole projects** — the budget is
  expected to be high; less informative.
- **Especially useful** for adapted material (where the source
  novel's scope might exceed practical screenplay-budget ranges).

## Output bundling

When the user requests the full packet, generate:

| File | Format | Naming convention |
|---|---|---|
| Logline | `.txt` (plain) | `{Title}-Logline.txt` |
| Query Letter | `.docx` | `{Title}-Query-Letter.docx` |
| One-Sheet | `.docx` | `{Title}-One-Sheet.docx` |
| Short Treatment | `.docx` | `{Title}-Treatment.docx` |
| 25-Checkpoint Revision Checklist | `.docx` | `{Title}-Revision-Checklist.docx` |
| Production Notes | `.docx` | `{Title}-Production-Notes.docx` |

Also display each inline in the conversation so the user can review
without opening the files.

## Closing message

After delivering the packet, show:

```
─────────────────────────────────────────────────────────
Your Industry Submission Packet is ready.

The screenplay has been through:
  • 10-pass Pre-Delivery Sweep
  • Quality Gate (Format / Craft / Multi-Track / Story Logic)
  • Beat-anchoring against the 7 plot points
  • Character Architecture verification

The submission packet is built per Trottier's Screenwriter's Bible
framework. To submit:

  1. Use the LOGLINE in pitch contexts and the first line of every
     query.
  2. Send the QUERY LETTER first; only send the screenplay when an
     agent or producer requests it.
  3. Attach the ONE-SHEET if a producer asks for "more material" but
     not the full read.
  4. Send the SHORT TREATMENT if requested explicitly (often after
     a positive query response).
  5. Use the 25-CHECKPOINT REVISION CHECKLIST as your final pass
     before any submission. Aim for ≥22 of 25 before sending.

Save the packet. Industry submissions are won and lost on these
materials, not on the screenplay alone.
─────────────────────────────────────────────────────────
```

## Relationship to other engine files

| Engine File | Relationship |
|-------------|-------------|
| `screenplay-protocol.md` | Generates the screenplay this packet ships alongside |
| `format-fountain.md` | The screenplay-format spec (`.fountain`/PDF/DOCX/FDX delivery) sibling to this packet — this packet is the *submission* materials, format-fountain is the *script file* itself |
| `format-fdx.md` | FDX (Final Draft XML) emitter — the industry-interchange deliverable Final Draft / WriterDuet / Highland read |
| `script-coverage.md` | Independent post-delivery editorial assessment; complements the 25-Checkpoint Revision Checklist |
| `cover-designer.md` | If the project later becomes a novel adaptation, the marketing materials cross over |
| `market-scout.md` | Provides comp-title research used in the One-Sheet |

This agent is the **business-side companion** to the screenplay-agent.
The screenplay-agent makes the script professional; this agent makes
the *submission* professional.
