---
name: revision-loop
description: "Automated iterative revision loop — reader diagnostics drive fixes until convergence. Three autonomy tiers: SURGICAL fixes auto-apply; DEVELOPMENTAL-BOUNDED fixes (additive-insertion, beat-relocation) run through the Tier-2 gated executor behind a human-confirm checkpoint; CREATIVE-OPEN decisions are escalated to the author. Consumes the Beta Synthesis Capstone's §5 Revision Routing plan as rich initial diagnosis when present, falling back to fresh Alpha+Beta diagnosis otherwise."
version: "2.7.108"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Revision Loop Orchestrator

## File-Write Hygiene (MANDATORY — applies across every loop iteration)

The revision loop iteratively applies surgical fixes across
multiple chapter files until convergence. Each iteration is an
opportunity for silent truncation to enter and propagate. The
chained-Edit truncation safeguard documented in
`core-pipeline.md` § Chained-Edit Truncation Safeguard applies
in full per iteration:

- **Prefer Write over chained Edit for chapter-scale rewrites.**
- **Cap individual Edit replacements at ~2 KB.**
- **Run `scripts/word-count-check.sh` after every Edit each
  iteration applies**, not just at convergence. The loop's
  iterative nature makes per-iteration verification mandatory —
  a corrupted file in iteration 2 will be re-edited (and
  potentially worsened) in iteration 3.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) at the end of every iteration before the
  next iteration's diagnostic pass reads the file.

**HARD GATE — BLOCKING.** Any chapter file with truncation
detected at any iteration MUST be repaired and re-validated
before the loop advances. The loop MUST NOT advance with a
corrupted file in scope.

## Purpose

Automates the cycle of **analyse → diagnose → fix → validate → repeat** until
the manuscript converges on reader-ready quality. Replaces manual "run readers,
read report, decide what to fix, apply fixes, run readers again" with a single
orchestrated loop that stops when both Alpha and Beta readers agree the
manuscript has crossed the convergence threshold — or when safety limits halt
the process for human review.

## When to Run

- After the editorial pipeline (Stages 0–9 of `editorial-suite.md`) has completed
  at least once
- After a human author has applied their own revisions and wants automated polish
- When returning to a manuscript after structural edits to bring prose quality
  back up to standard

**Do NOT run:**
- On a first draft that hasn't been through the editorial pipeline at all
- When the user wants manual control over every fix decision
- When structural issues (chapter reordering, subplot removal, POV changes) are
  the primary concern — those require human judgement first

## Prerequisites

Before the loop can start, these must exist:

1. **Voice Profile** — Built in editorial-suite.md Stage 0
2. **Story Bible** — Canonical facts, characters, timeline
3. **Entity Database** — Characters, locations, objects
4. **Genre file loaded** — Active genre bank with scoring rubrics
5. **At least one prior editorial pass** — So the loop refines rather than discovers

If any prerequisite is missing, halt and direct the user to run the editorial
pipeline first.

---

## Seeding from a Synthesis Capstone Revision Plan

The loop has two diagnosis sources. In order of preference:

1. **Beta Synthesis Capstone (preferred when present).** If
   `engine-data/reports/beta-synthesis.md` exists and contains a
   `## 5. Revision Routing` section (see `beta-synthesis-capstone.md`),
   the loop ingests it as the **initial diagnosis** for iteration 1:
   - **§5a SURGICAL blocks** populate the Consensus Issue List
     directly — each block is already in EXACT QUOTE / PROBLEM /
     FIX / REASON shape, so DIAGNOSE (Step 3) is pre-computed.
     These flow into Tier 1 and are auto-applied.
   - **§5b DEVELOPMENTAL-BOUNDED blocks** route to the Tier-2
     Developmental Executor (below).
   - **§5c CREATIVE-OPEN blocks** route straight to the deferred-
     to-human list — the loop never touches them.

   Seeding from the capstone is strictly better than fresh
   diagnosis for iteration 1 because the synthesis was produced
   with the whole manuscript + all five persona lenses in a single
   1M context — a richer diagnosis than the loop's per-iteration
   Alpha+Beta pass can produce. After iteration 1, the loop reverts
   to fresh Alpha+Beta diagnosis (Step 2) for convergence tracking,
   because re-running the full panel+synthesis every iteration is
   cost-prohibitive and the surgical convergence signal does not
   need it.

2. **Fresh Alpha+Beta diagnosis (fallback).** If no synthesis
   capstone exists, the loop diagnoses from a fresh Alpha+Beta
   pass exactly as it always has (Steps 2-3). No behavior change
   for projects that never ran the panel.

**Verification on ingest (HARD GATE).** Before trusting a seeded
plan, Read-verify `engine-data/reports/beta-synthesis.md` (non-empty, contains the
`## 5. Revision Routing` heading and at least one tier block). A
malformed or empty synthesis file falls back to fresh diagnosis
rather than proceeding with a partial plan — never run the loop on
half a routing plan.

---

## Convergence Thresholds

The loop stops when the manuscript meets ALL of these criteria:

```
ALPHA READER:
  Stars:             ≥ 4.75 / 5
  Engagement Map:    No chapter block rated below "engaged"
  Confusion Points:  0 unresolved

BETA READER:
  Stars:             ≥ 4.5 / 5
  Genre Authenticity: ≥ 90%
  Market Readiness:   ≥ 88%
  Improvements list:  No item rated "high impact"

COMBINED:
  Consensus issues (flagged by both readers): 0 critical, 0 moderate
```

These thresholds are calibrated from real iteration data — the Clean Label
manuscript reached Alpha 95%/Fit 98% and Beta 85%/Fit 95% after 6 rounds,
with fresh reader validation confirming durability. The thresholds represent
the zone where additional automated revision yields diminishing returns and
human taste should take over.

### Threshold Override

The user may adjust thresholds before starting the loop:

```
"Run revision loop with beta target 4.0 stars"
"Run revision loop with max 3 iterations"
"Run revision loop — stop after pacing fixes only"
```

---

## Safety Limits

```
MAXIMUM ITERATIONS:          5  (hard cap — no override)
MAXIMUM FIXES PER ITERATION: 7  (prevents over-editing)
WORD COUNT DRIFT TOLERANCE:  ±5% per iteration, ±10% cumulative
VOICE DRIFT THRESHOLD:       If any fix fails voice verification → revert that fix
SCORE REGRESSION TOLERANCE:  If any metric drops > 5 points → halt and flag
REVERT TRIGGER:              If 2+ metrics regress in same iteration → full revert
```

**Why 5 iterations max:** The Clean Label data shows recurring reader fatigue
sets in around round 5 — scores plateau or drift regardless of actual quality
improvements. Beyond 5 iterations, use fresh reader validation instead.

---

## The Loop

### Iteration Flow

```
┌──────────────────────────────────────────────────────────────┐
│                                                              │
│  ┌─── SNAPSHOT ◄── Create revision snapshot before edits     │
│  │                                                           │
│  ├─── ANALYSE ◄── Run Alpha + Beta Readers on current ms     │
│  │                                                           │
│  ├─── DIAGNOSE ◄── Extract consensus issues, rank by impact  │
│  │                                                           │
│  ├─── TRIAGE ◄── Sort: Tier 1 surgical / Tier 2 bounded /    │
│  │              Tier 3 creative-open                         │
│  │                                                           │
│  ├─── FIX ◄── Apply Tier-1 surgical fixes (max 7/iteration)  │
│  │            + Tier-2 gated executor (≤1 per loop run)      │
│  │                                                           │
│  ├─── VERIFY ◄── Regression check + voice consistency        │
│  │                                                           │
│  ├─── VALIDATE ◄── Re-run Alpha + Beta on fixed manuscript   │
│  │                                                           │
│  ├─── COMPARE ◄── Score deltas vs. previous iteration        │
│  │       │                                                   │
│  │       ├── Converged? ──────────► EXIT (deliver report)     │
│  │       ├── Improved? ──────────► LOOP (next iteration)      │
│  │       └── Regressed? ─────────► REVERT + EXIT (flag)       │
│  │                                                           │
│  └─── LOG ◄── Record iteration results in changelog          │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

### Step 1: SNAPSHOT

Before any edits, create an immutable revision snapshot:

```
engine-data/revisions/{YYYY-MM-DDTHH-MM}_revision-loop-R{N}/
```

Where `{N}` is the iteration number (1, 2, 3...). Copy all chapter files
into this directory using the bash-direct snapshot protocol:

```bash
cp {path}/engine-data/chapters/ch*.md \
   {path}/engine-data/revisions/{YYYY-MM-DDTHH-MM}_revision-loop-R{N}/
sync
ls -la {path}/engine-data/revisions/{YYYY-MM-DDTHH-MM}_revision-loop-R{N}/
```

Do NOT use the Write tool for the snapshot copy. The snapshot is the
ONLY rollback path for this iteration. After `ls -la`, verify each
copied file has non-zero byte count. If any file is missing or zero-
byte, STOP and re-run the `cp`.

This enables rollback to any iteration point.

### Step 2: ANALYSE

Run the Alpha Reader and Beta Reader (editorial-suite.md Stages 5 and 6) on
the current manuscript state. Collect their full output schemas:

**From Alpha Reader:**
- Star rating
- Engagement map (per chapter-block)
- The Good / The Bad (with chapter references)
- Confusion points
- Reader questions

**From Beta Reader:**
- Star rating
- Genre Authenticity score
- Market Readiness score
- The Good / The Bad (with chapter references)
- Ranked improvements list
- Comp titles & market notes

### Step 3: DIAGNOSE

Cross-reference Alpha and Beta outputs to build the **Consensus Issue List**.

**Consensus rules:**
- Issue flagged by BOTH Alpha and Beta → **consensus critical** (auto-fix)
- Issue flagged by one reader as "high impact" → **consensus moderate** (auto-fix)
- Issue flagged by one reader as "low impact" → **consensus minor** (auto-fix if within fix budget)
- Contradictory feedback (Alpha says X, Beta says opposite) → **conflict** (surface to user, do not auto-fix)

For each consensus issue, record:

```
ISSUE #{N}:
  SOURCE:      Alpha | Beta | Both
  SEVERITY:    critical | moderate | minor
  CATEGORY:    pacing | voice | character | continuity | atmosphere |
               dialogue | exposition | genre-fit | phrase-frequency |
               show-vs-tell | emotional-beat | hook | resolution
  CHAPTERS:    [list of affected chapters]
  DESCRIPTION: [what the reader(s) flagged]
  EVIDENCE:    [exact quotes from reader reports]
  AUTO-FIXABLE: yes | no (human decision required)
  FIX APPROACH: [specific surgical fix strategy]
```

### Step 4: TRIAGE

Separate issues into three autonomy tiers. (When seeded from a
Beta Synthesis Capstone — see § Seeding — the tier is already
assigned in the capstone's §5 Revision Routing and TRIAGE just
validates it; when diagnosing from fresh Alpha+Beta, assign the
tier here.)

**TIER 1 — SURGICAL** (the loop auto-applies these every iteration):

| Category | Fix Approach |
|----------|-------------|
| Phrase frequency / crutch words | Find-and-replace with voice-consistent alternatives |
| POV zoom-out drift | Tighten psychic distance in flagged passages |
| Stage-direction atmosphere | Add sensory grounding to "talking heads" scenes |
| Pacing drag | Compress exposition, add micro-tension, trim redundancy |
| Show-vs-tell violations | Convert named emotions to physical/behavioral indicators |
| Weak chapter hooks | Strengthen final 2-3 sentences of flagged chapters |
| Missing emotional beats | Insert character-voice reactions at flagged moments |
| Dialogue exposition dumps | Break info-delivery into conflict-driven exchanges |
| Triple-beat list normalization | Vary list rhythms in flagged passages |
| Adverb/filter word density | Surgical removal with stronger verb substitution |
| Comprehension / clarity gaps | Add an orientation clause or differentiating phrase at a flagged first-mention |
| Genre convention gaps | Add missing genre beats per genre bank requirements |

All Tier 1 fixes obey the surgical discipline: ≤5% word-count
change per passage, no new scene, no beat moved, voice-verified.

**TIER 2 — DEVELOPMENTAL-BOUNDED** (the loop drafts and applies
these behind a human-confirm checkpoint — see § Tier-2
Developmental Executor):

| Category | Operation | Why it is bounded (not open) |
|----------|-----------|------------------------------|
| Setup-without-payoff scene gap | additive-insertion | Existing setup anchors already in the manuscript; the new scene pays them off without rewriting surrounding prose (e.g. the deferred Owen scene) |
| Beat in the wrong chapter | beat-relocation | A self-contained beat is liftable to a better position without rewriting the prose around either end (e.g. moving a patent-filing reveal earlier to fill a velocity dip) |

Tier 2 is the ONLY tier where the loop generates new prose or
moves content. It is strictly limited to the two operations above,
each requires an existing setup/relocation anchor, and NOTHING
lands without the human-confirm gate.

**TIER 3 — CREATIVE-OPEN** (the loop flags these and NEVER applies
them at any autonomy level):

| Category | Why It Needs a Human |
|----------|---------------------|
| Structural reordering | Chapter/scene sequence changes alter story logic |
| Subplot addition/removal | Creative direction — affects theme and pacing globally |
| Character arc changes | Fundamental story decisions about who characters become |
| POV character changes | Alters whose story this is |
| Ending alternatives | The most consequential creative choice |
| Thematic emphasis shifts | Author's intent territory |
| Contradictory reader feedback | Judgement call between valid perspectives (every Synthesis §1 Productive Conflict lands here) |
| World-building rule changes | Cascading continuity implications |

**The Tier-2 / Tier-3 boundary is load-bearing.** A change is
Tier 2 ONLY if it is one of the two bounded operations AND cites
an existing anchor AND rewrites no existing prose. If it requires
deciding what a character does, rewriting existing scenes, or
altering story logic, it is Tier 3 — no exceptions, regardless of
how small it looks.

### Step 5: FIX

Apply surgical fixes using `surgical-fixes.md` protocol, with these loop-specific rules:

1. **Fix budget:** Maximum 7 fixes per iteration (prevents cumulative drift)
2. **Priority order:** Critical consensus → moderate consensus → minor consensus
3. **Voice Profile attached:** Every fix instruction includes the Voice Profile
4. **Scope discipline:** Fix ONLY the flagged passages — do not "improve" adjacent text
5. **Independence:** Each fix must be independent — no fix should depend on another
   fix landing correctly (prevents cascading failures)

**Fix application template:**

```
REVISION LOOP — ITERATION {N}, FIX {M}/{TOTAL}

VOICE PROFILE: {attached}

ISSUE: {description from diagnosis}
SEVERITY: {critical|moderate|minor}
CATEGORY: {category}

EXACT TEXT TO CHANGE:
"{quoted passage from manuscript}"

PROBLEM: {what's wrong — from reader diagnosis}

FIX: {the replacement text}

RULES:
1. Apply ONLY this fix. Do not touch surrounding text.
2. The fixed text must pass the voice test: "Could the same writer
   who wrote the surrounding paragraphs have written this?"
3. Word count change must be < 5% of the passage length.
4. Do not introduce any forbidden words (see forbidden-words.md).
5. Preserve all: plot events, character knowledge, continuity facts.
```

### Step 5b: TIER-2 DEVELOPMENTAL EXECUTOR (gated)

This is the path for DEVELOPMENTAL-BOUNDED items (§5b of a synthesis
plan, or a Tier-2 item assigned during fresh TRIAGE). It is the only
place the loop generates new prose or relocates content, and it is
gated end-to-end. It runs at MOST once per loop run (not per
iteration) and only after the Tier-1 surgical convergence has been
attempted, so the manuscript is otherwise stable before any
developmental change lands.

**Autonomy level (configurable, safe default).**

```
DEVELOPMENTAL AUTONOMY:  confirm   (default)
  confirm → executor drafts the change, presents before/after,
            applies ONLY after explicit user confirmation
  auto    → executor drafts and applies without per-change confirm
            (user opts in: "run developmental fixes automatically");
            still snapshotted, re-verified, and auto-reverted on
            any verification failure
  off     → executor does not run; all Tier-2 items are escalated
            to the deferred-to-human list like Tier-3
```

The default is `confirm`. `auto` is available for users who want
maximum hands-off operation and accept that a developmental change
may need to be reverted after the fact. `off` makes the loop behave
exactly as pre-Tier-2 (everything beyond surgical goes to a human).

**Per-item executor protocol:**

1. **SNAPSHOT** (mandatory, same bash-direct protocol as Step 1).
   The developmental change has a larger blast radius than any
   surgical fix; the snapshot is the only rollback path.

2. **VALIDATE THE ANCHOR.** Re-read the SETUP ANCHOR(S) cited in
   the §5b block (or the TRIAGE assignment) and confirm they exist
   verbatim in the manuscript. No anchor → abort this item, escalate
   to human (it was misclassified; a payoff with no setup is a
   creative addition, not a bounded one).

3. **DRAFT.** Generate the content:
   - **additive-insertion:** draft a new scene/beat (≤ the SCOPE
     word budget, default cap ~1,500 words) that pays off the
     anchor, in the author's voice (Voice Profile attached), that
     contradicts no PAYOFF/CONTINUITY CONSTRAINT. The surrounding
     chapters are NOT rewritten — the draft slots in at the named
     boundary.
   - **beat-relocation:** lift the named beat verbatim from the
     SOURCE position and prepare it for the TARGET position with
     only the minimal stitch (a transition sentence at each seam)
     needed for it to read naturally — no rewriting of the beat's
     content.

4. **CONFIRM GATE** (skipped only when autonomy = `auto`). Present
   to the user: the operation, the target point, the drafted
   content (full text for insertion; the moved beat + the two
   stitch sentences for relocation), and the before/after of the
   seams. The user confirms, edits, or rejects. Rejection escalates
   the item to the deferred-to-human list.

5. **APPLY** via File-Write Hygiene (Write for the modified
   chapter file(s); never bash cat-and-mv). For relocation, both
   the source chapter (beat removed) and target chapter (beat
   inserted) are written and verified.

6. **RE-VERIFY (HARD GATE — blocking).** A developmental change can
   break things a surgical fix cannot, so re-verification is
   broader than Step 6 VERIFY:
   - **Continuity:** run the canon-validation audits for the
     RE-VERIFY DOMAINS named in the §5b block (at minimum CHARACTER
     + COHERENCE; PHYSICS/timeline if the content touches injury or
     chronology) against the modified chapters. See
     `canon-validator.md`.
   - **Word-count + integrity:** on-disk `wc -w` + tail-byte check
     on every modified file (per § File-Write Hygiene).
   - **Voice:** the inserted/stitched prose passes the Voice Profile
     test.
   - **Story Bible Section 12 reconciliation:** if the change moved
     or added a beat, update Section 12 to the post-change reality
     (per `editorial-suite.md` Stage 8 reconciliation rule) — a
     relocated beat that leaves Section 12 stale is a verification
     failure, not a pass.

7. **REVERT ON FAILURE.** Any re-verify failure → restore from the
   Step-1b snapshot and escalate the item to the deferred-to-human
   list with the specific failure named. The loop NEVER keeps a
   developmental change that failed re-verification.

8. **LOG.** Record the operation, the confirm decision, and the
   re-verify result in `engine-data/revision-loop-log.md`.

After the Tier-2 executor completes (or escalates), the loop
continues to Step 6 VERIFY for the iteration's surgical fixes as
normal.

### Step 6: VERIFY

After all fixes in this iteration are applied, run verification:

**Per-fix verification:**
- Each fix landed correctly (old text gone, new text present)
- Surrounding paragraph reads naturally
- No new AI-isms introduced (check against `forbidden-words.md`)
- Voice consistency held (compare to Voice Profile)

**Regression check:**
- Full-chapter read for each modified chapter
- Continuity spot-check against Story Bible for modified passages
- Word count within tolerance (±5% per chapter, ±10% cumulative)

**If verification fails:**
- Single fix regressed → revert that fix only, continue iteration
- 2+ fixes regressed → revert ALL fixes in this iteration, try alternative approach
- Voice consistency failed → simplify the fix (less ambitious edit)

### Step 7: VALIDATE

Re-run Alpha and Beta Readers on the post-fix manuscript. This produces new
scores to compare against the pre-fix baseline.

**Important:** This is a FRESH read — the readers assess the fixed manuscript
without reference to the previous iteration's report. This prevents confirmation
bias (looking for whether a fix "worked" rather than reading naturally).

### Step 8: COMPARE

Calculate score deltas for every metric:

```
ITERATION {N} SCORE COMPARISON:

                        Before      After       Delta
ALPHA:
  Stars:                {x.xx}      {x.xx}      {+/-x.xx}
  Engagement Floor:     {label}     {label}     {improved/same/degraded}
  Confusion Points:     {count}     {count}     {+/-count}

BETA:
  Stars:                {x.xx}      {x.xx}      {+/-x.xx}
  Genre Authenticity:   {xx%}       {xx%}       {+/-xx%}
  Market Readiness:     {xx%}       {xx%}       {+/-xx%}
  High-Impact Issues:   {count}     {count}     {+/-count}

COMBINED:
  Consensus Issues:     {count}     {count}     {+/-count}
  Word Count Drift:     {xx%} cumulative

VERDICT: CONVERGED | IMPROVED | PLATEAUED | REGRESSED
```

**Decision logic:**

```
IF all convergence thresholds met:
    → VERDICT: CONVERGED → Exit loop, deliver final report

ELSE IF any metric improved AND no metric regressed > 5 points:
    → VERDICT: IMPROVED → Continue to next iteration

ELSE IF no metric changed by more than ±2 points:
    → VERDICT: PLATEAUED → Exit loop (diminishing returns)
    → Note: plateau after 2+ iterations suggests remaining issues
      are structural, not prose-level — flag for human review

ELSE IF any metric regressed > 5 points:
    → VERDICT: REGRESSED → Revert this iteration's fixes
    → Analyse WHY regression occurred (common cause: tightening
      surrounding prose makes unchanged sections stand out more)
    → If regression cause is identifiable: attempt alternative fixes
    → If regression cause is unclear: exit loop, flag for human review
```

### Step 9: LOG

Record iteration results in the revision changelog:

```
engine-data/revision-loop-log.md
```

**Log format per iteration:**

```markdown
## Iteration {N} — {YYYY-MM-DD HH:MM}

### Scores
| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Alpha Stars | {x.xx} | {x.xx} | {+/-} |
| Beta Stars | {x.xx} | {x.xx} | {+/-} |
| Genre Authenticity | {xx%} | {xx%} | {+/-} |
| Market Readiness | {xx%} | {xx%} | {+/-} |

### Verdict: {CONVERGED|IMPROVED|PLATEAUED|REGRESSED}

### Fixes Applied
1. **{category}** — Ch{N}: {brief description} → {outcome}
2. **{category}** — Ch{N}: {brief description} → {outcome}
...

### Issues Deferred to Human Review
- {description} — Reason: {why it can't be auto-fixed}

### Snapshot: `engine-data/revisions/{snapshot-path}/`
```

---

## Exit Conditions

The loop exits when ANY of these conditions is met:

| Condition | Action |
|-----------|--------|
| **Converged** — All thresholds met | Deliver final report + clean manuscript |
| **Plateaued** — No meaningful improvement for 2 consecutive iterations | Exit with "structural issues remain" advisory |
| **Regressed** — Score drop > 5 points after revert attempt | Exit with regression analysis |
| **Max iterations reached** (5) | Exit with current best + recommendations |
| **All remaining issues are human-decision** | Exit with deferred issues list |
| **Word count drift exceeded** (±10% cumulative) | Exit with drift warning |

---

## Final Report

When the loop exits (any exit condition), produce the **Revision
Loop Summary** below, then produce the **Author Action Report**
(`author-action-report.md`) as the closing artifact — unless the
loop ran as Stage 12 within the Handoff Protocol, in which case
the handoff's own closing step produces it (do not produce it
twice). The Revision Loop Summary's "Human Decision Required" +
deferred lists feed the Author Action Report (source S5); the
report is the consolidated, exact-location punch-list the author
acts from.

When the loop exits, produce the **Revision Loop Summary**:

```markdown
# Revision Loop Summary

## Result: {CONVERGED | EXITED — reason}

## Iterations: {N} of {max}

## Score Trajectory
| Metric | Start | End | Total Delta |
|--------|-------|-----|-------------|
| Alpha Stars | {x.xx} | {x.xx} | {+/-} |
| Beta Stars | {x.xx} | {x.xx} | {+/-} |
| Genre Authenticity | {xx%} | {xx%} | {+/-} |
| Market Readiness | {xx%} | {xx%} | {+/-} |
| Consensus Issues | {count} | {count} | {+/-} |

## Fixes Applied (All Iterations)
{Numbered list of every fix that survived verification}

## Issues Remaining
### Auto-fixable (would require more iterations)
{List — if loop hit max iterations or plateaued}

### Human Decision Required
{List — with both reader perspectives and recommended approach}

## Voice Integrity
- Voice Profile violations detected: {count}
- Fixes reverted for voice reasons: {count}
- Cumulative word count drift: {xx%}

## Recommendation
{One paragraph: what the author should focus on next —
specific chapters, specific issues, whether a fresh human read
would be valuable before further automated revision}

## Publication Readiness Assessment

{Include this section ONLY when Result is CONVERGED or when all
remaining issues are human-decision items with no critical/moderate
consensus issues outstanding.}

### What This Means

Your manuscript has passed through a rigorous, multi-layered editorial
process. Here is what has been confirmed:

- **Story logic is sound.** No unresolved plot holes, continuity errors,
  or broken cause-and-effect chains were detected by either reader.
- **Readers can follow and enjoy your story.** The Alpha Reader — a
  stand-in for a first-time reader with no genre expertise — reported
  sustained engagement with zero confusion points.
- **Your genre contract is fulfilled.** The Beta Reader — a genre-savvy
  assessor — confirmed your manuscript meets the conventions and quality
  bar readers in your genre expect.
- **Your voice is intact.** Every edit applied during this process was
  verified against your Voice Profile. The words on the page still
  sound like you.
- **Revision has reached the point of diminishing returns.** Additional
  automated passes will not meaningfully improve the reader experience.
  The gains left are in the territory of personal taste, not craft
  deficiency.

### The Honest Truth About "Ready"

No book is perfect. In a year you will see things you would write
differently — not because this book was published too early, but
because you will have grown. That is exactly how it should work.

Your manuscript has met every objective standard this pipeline can
measure. The checklist is complete:

- [x] Structural integrity verified (pacing, arcs, plot resolution)
- [x] Prose quality confirmed (voice, clarity, rhythm)
- [x] Proofreading and copy-editing passes complete
- [x] Reader experience validated (engagement, comprehension, genre fit)
- [x] Revision rounds capped and convergence achieved
- [x] Remaining items are taste-level, not error-level

**You are not looking for permission to stop editing. You already have
the evidence that it is ready. Trust the process you built, trust the
results it produced, and go share your story.**
```

---

## Integration with Editorial Pipeline

The revision loop slots into the editorial pipeline as an optional stage
after Stage 9 (Full-Manuscript Continuity Audit):

```
Existing Pipeline:
  0. Voice Profile
  1. Genre-Specific Audit
  2. Proofreader
  3. Copy Editor
  4. Developmental Editor
  5. Alpha Reader
  6. Beta Reader
  7. Conflict Resolution
  8. Apply Top Fixes
  9. Full-Manuscript Continuity Audit
  10. Multi-POV Consistency Pass (conditional)
  11. Intimate Scene Review (conditional)

NEW:
  12. Revision Loop (conditional — activated by user or when Alpha/Beta
      scores are below convergence thresholds after Stage 8)
```

**Auto-activation rule:** If Stage 8 fixes are applied and the post-fix
Alpha/Beta scores (from Stage 9 re-validation) remain below convergence
thresholds, offer the revision loop:

```
"Alpha and Beta readers still flag [N] consensus issues after initial fixes.
Would you like to run the revision loop for automated iterative refinement?
Estimated iterations: [1-3 based on gap to threshold]. Say 'yes' to start,
or 'show issues' to review them first."
```

---

## Interaction with Surgical Fixes Protocol

The revision loop USES `surgical-fixes.md` — it does not replace it. Every fix
applied within the loop follows the same two-step analyse → apply process, the
same voice preservation rules, and the same verification checks. The loop adds:

1. **Automated issue extraction** from reader reports (replaces manual reading)
2. **Consensus detection** across Alpha and Beta (replaces human judgement for clear cases)
3. **Iteration management** (snapshot → fix → validate → compare → decide)
4. **Convergence tracking** (when to stop)
5. **Regression protection** (when to revert)

---

## Interaction with Fresh Reader Validation

After the loop exits (whether converged or not), the user may request a
**fresh reader validation** — running Alpha and Beta readers configured as
first-time readers with no memory of prior iterations. This is the gold
standard test: if fresh readers score at or above the convergence thresholds,
the manuscript is ready.

Fresh reader validation is NOT part of the automated loop (it's a separate,
user-triggered action) because:
- It tests durability of changes, not incremental improvement
- It should be done after a cooling-off period (the author reviews the loop's
  deferred issues and makes any human-decision edits first)
- It provides the final go/no-go signal before publication-readiness declaration

---

## What This Does NOT Do

- **Rewrite existing chapters from scratch** — Tier 1 fixes are surgical,
  minimum edits. Tier 2 ADDS a bounded new scene or RELOCATES a self-
  contained beat, but never rewrites the existing prose around it.
- **Make open creative decisions** — Chapter reordering, subplot
  presence, arc direction, POV, endings, thematic emphasis (Tier 3)
  remain human territory and are never auto-applied at any autonomy
  level. The Tier-2 carve-out is strictly the two bounded operations
  (additive-insertion, beat-relocation) with an existing anchor.
- **Land a developmental change without a gate** — Tier 2 runs behind
  a human-confirm checkpoint by default (autonomy = `confirm`), is
  always snapshotted, and is auto-reverted on any re-verification
  failure. Even at autonomy = `auto`, the snapshot + re-verify + revert
  protections hold.
- **Override the Voice Profile** — Voice preservation is non-negotiable; any
  fix (surgical or developmental) that fails the voice test is reverted
- **Run indefinitely** — Hard cap of 5 iterations prevents over-processing;
  the Tier-2 executor runs at most once per loop run
- **Replace human editorial judgement** — The loop handles craft-level polish
  and bounded developmental gaps; open creative direction remains with the author
- **Touch passages not flagged by readers or the synthesis plan** — Scope
  discipline prevents drift

---

## Silent-Failure Audit

The Tier-2 Developmental Executor (v2.7.105) introduced the
loop's first new-prose-generation and content-relocation
primitives. For each, the success-claim, divergence failure mode,
and verification binding are documented. (The pre-existing
surgical loop's primitives — chained Edit, Write, word-count
verification — are covered by `core-pipeline.md` § File-Write
Hygiene + Chained-Edit Truncation Safeguard, cited in the
File-Write Hygiene section at the top of this spec.)

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (synthesis plan ingest) | "Read beta-synthesis.md, plan loaded" | Empty / malformed / partial routing plan → loop runs on half a plan | § Seeding HARD GATE: verify non-empty + `## 5. Revision Routing` heading + ≥1 tier block present; malformed → fall back to fresh Alpha+Beta diagnosis, never proceed on a partial plan |
| Read (setup anchor validation) | "Anchor exists" | Anchor cited but not actually in the manuscript → executor drafts a payoff for a setup that was never planted | Tier-2 executor step 2: re-read the cited anchor, confirm verbatim presence; no anchor → abort the item, escalate to human (misclassified developmental → creative) |
| Write (new scene / relocated beat) | "Write succeeded" | Subdir flush / truncation leaves a half-written or corrupted chapter; relocation drops the beat from source without landing it in target | File-Write Hygiene (Write tool, never bash cat-and-mv) + on-disk `wc -w` + tail-byte check on EVERY modified file at executor step 6; relocation writes AND verifies both source and target chapters; any integrity failure → revert from snapshot |
| Subagent (canon-validation re-verify) | "Re-verify passed" | Hallucinated clean verdict — the developmental change broke continuity but the audit claims it didn't | Tier-2 executor step 6 dispatches the canon-validation audits for the named RE-VERIFY DOMAINS under `subagent-output-verification.md` HARD GATE (evidence-bearing return, citation discipline); a developmental change is kept ONLY on an evidence-backed clean verdict |
| Tier classification (developmental vs creative) | "Item is DEVELOPMENTAL-BOUNDED" | A creative-open change (arc/ending/rewrite) mis-routed as bounded → executor generates content for a decision the author owns | Two structural guards (mirrored from `beta-synthesis-capstone.md` §5): OPERATION constrained to exactly two values; mandatory existing SETUP ANCHOR. Plus the human-confirm gate (default autonomy) as the final backstop before any developmental change lands. |
| Confirm gate (human checkpoint) | "User approved the change" | Compound / ambiguous approval applied to the wrong item; silent auto-apply when the user expected confirm; OR content materially changed after approval so the applied artifact differs from the approved one ("approved A, applied B") | Default autonomy is `confirm` (explicit per-item approval, presenting full before/after); `auto` is opt-in only and still snapshotted + re-verified + auto-reverted; AskUserQuestion disambiguation discipline (`ask-user-disambiguation.md`) applies to the confirm prompt; the RE-CONFIRM ON MATERIAL CHANGE rule (executor step 4) forces fresh confirmation whenever post-approval text, location, length, or source basis materially changes |
| Snapshot (rollback path) | "Snapshot created" | Zero-byte / missing snapshot → no rollback path for a high-blast-radius change | Bash-direct snapshot protocol (same as Step 1 SNAPSHOT) with `ls -la` + non-zero byte verification before the executor proceeds; no verified snapshot → executor does not run |
