---
name: continue-writing
description: "Resume an in-progress manuscript — pick up where you left off"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Continue Writing

Resume work on a manuscript you've already started.

## What happens

The engine reads your existing project folder, locates your Story Bible and last completed chapter, and picks up from the next unwritten chapter.

**Read-Verification HARD GATE applies (see `read-verification.md`)
when re-loading any user-supplied or previously-saved file from
the project folder.** Verify each Read of `story-bible.md`,
`outline.md`, prior chapter files, and any user-supplied source-
canon files returns content above threshold (MD/TXT ≥ 20 chars,
DOCX ≥ 100, PDF ≥ 100). Empty Reads on the Story Bible or outline
would produce a Continue-Writing run that fabricates content
inconsistent with the user's prior chapters. Failed Reads BLOCK
the resume flow and surface the failure to the user with
resolution options before the next chapter is generated. Engine-
written runtime files (`pipeline-checkpoint.md`, `entity-canon.md`,
chapter summaries, briefs) are exempt from this gate — the
File-Write Hygiene binding verified them at write time.

**Source Persistence HARD GATE applies (see `source-persistence.md`,
v2.7.9).** If the user uploads NEW supplementary canon when
resuming (additional worldbuilding, updated character sheets,
revised codex), the engine MUST persist each new file to
`source-canon/` via `scripts/source-persistence.sh` BEFORE the next
chapter is generated. The canon-absorbed.md marker file accumulates
across sessions, giving the user a complete history of what's been
absorbed when. Conflict-on-existing-content surfaces to the user
via AskUserQuestion (replace / rename / skip).

## How to start

Say any of:
- "Continue writing"
- "Resume my manuscript"
- "Pick up where I left off"
- "Write the next chapter"

## What you'll need

Your project folder should be at `Ideorix-Projects/[Book Title]/` and contain:
- `engine-data/pipeline-checkpoint.md` — the authoritative record of which chapters are complete and where each is in the pipeline. **If this file is missing, the engine treats the project as new** (legacy mode) and you risk re-processing completed chapters. Always copy this file when moving projects between machines.
- `story-bible.md` — Your Story Bible from Phase 2
- `outline.md` — Your chapter outline
- Completed chapter files (e.g., `chapter-01.md`, `chapter-02.md`, ...)

The engine will:
1. Read the Story Bible and outline to restore context
2. Identify the next unwritten chapter
3. Run the Architect → Writer → Verification loop for that chapter
4. Continue chapter-by-chapter until the manuscript is complete

> **Tip:** If you want to rewrite a specific chapter, say "Rewrite chapter 5" instead.
