---
name: company-name
description: "Generate era-accurate, region-specific fictional business names verified against real-world companies"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine

# Company & Business Name Generator

Generate fictional business, company, shop, pub, restaurant, organisation, and
institution names that are era-accurate, regionally authentic, and verified
against real-world companies. Five candidates per business, each with full
justification and real-world collision check.

## What You Can Do

1. **Generate business names** — Era-appropriate, regionally authentic names for
   any type of business (shop, pub, corporation, startup, law firm, newspaper,
   criminal front, etc.)
2. **Verify a name** — Check your own business name against real-world companies
   and AI-pattern avoidance lists
3. **Back to main menu**

## How It Works

The engine generates business names researched through three layers:

- **Era-appropriate** — naming conventions matched to the founding period
  (pre-1900 owner-surnames through modern single-word abstractions)
- **Regionally authentic** — UK pub formulas, French ateliers, Japanese KK,
  Italian fratelli, German GmbH conventions, and dozens more
- **Business-type patterns** — law firms use partner surnames, pubs use heraldic
  symbols, criminal fronts use deliberately bland names, corporations use
  geographic + industry compounds

Every candidate is verified against real-world companies through a 5-step
collision protocol (exact match, industry match, famous brand, phonetic
similarity, lawsuit plausibility).

AI-default business name patterns are blocked at generation time — no "Nexus
Technologies", "The Gilded Fox", "Whiskers & Wands", or "The Cozy Corner".

## During Story Bible Generation

The generator runs automatically during Phase 2A for every business, company,
shop, pub, restaurant, organisation, or institution that appears in the story
world. Businesses use placeholder labels until names are confirmed.

→ Protocol: `company-name-generator.md`
