---
name: byo-canon
description: "Bring your own worldbuilding, characters, story idea — Ideorix writes the prose using your canon as authoritative input. Direct entry point that routes to Outline Builder Step 0 (Source Material Absorption) before any outline construction begins. For users who have already done the world-building / character-work / story-conception work themselves and want the engine in a service role, not an originator role."
version: "2.6.11"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with `> **Powered by Ideorix** — The Manuscript & Screen Engine` before any other output.

# Use My Worldbuilding (Bring Your Own Canon)

Bring your existing worldbuilding, characters, voice, and story
idea into Ideorix. The engine treats your material as
**authoritative canon** — not as samples or starting points —
and writes the manuscript in service of the creative work
you've already done.

This entry point exists for a specific kind of writer: one who
has already done substantial world-building / character-work /
story-conception themselves, and wants the engine to **execute
their vision** rather than originate one. The prior creative
work is yours; the engine's job is structural — how to arrange
your story for maximum dramatic effect within the constraints
you've established.

## When to use this flow (vs. other Writers Studio entries)

| You have... | Use this flow |
|---|---|
| Worldbuilding files, character profiles, voice guide, story idea | **Use My Worldbuilding (this flow)** |
| A finished manuscript ready for editing | Edit & Revise |
| A Plottr / Scrivener / Novelcrafter export | Import Project |
| Just an idea, no built canon | Start New Project / Write a New Book |
| An Ideorix-built Story Bible from a previous session | Continue Writing |

If you're not sure whether your material is substantive enough
for this flow, the heuristic is: **do you have characters
whose personality / voice / specific traits you've already
defined and committed to?** If yes, this flow. If you're still
deciding who they are, use Write a New Book.

## What this flow guarantees (Architect mode contract)

When the engine runs this flow, it operates in **Architect
mode** rather than Creator mode (see
`outline-builder.md` § Anti-Rewriting Rule). Architect mode
binds the engine to:

1. **Read your canon in full BEFORE generating any outline.**
   Not skimming. Not summarising from filenames. Full content
   read using the Read tool. (Step 0 of Outline Builder makes
   this mandatory.)
2. **Treat your characters' personalities as locked.** If your
   profile says a character is "quick to laugh, fills silences
   comfortably", the outline must sustain that warmth across
   every chapter. The engine does NOT flatten characters to
   the easier-to-write versions.
3. **Treat your world rules as immutable.** If your magic
   system has costs, the costs must apply. If a wall cannot
   be crossed, it cannot be crossed.
4. **Treat your sample scenes as PROSE EXAMPLES, not plot
   tentpoles.** Voice guide samples demonstrate style, not
   structure. The outline does not reverse-engineer a plot
   from sample scenes.
5. **Refuse to project psychology.** "Survivor's guilt",
   "misread self-image", "unprocessed trauma" — unless you
   specified these, the engine does not add them. You know
   your characters better than the engine does.
6. **Dramatise threats, not summarise them.** If your antagonist
   is dangerous, scenes show the danger on-page — not "the
   threat is mentioned in notices for 24 chapters."
7. **Build relationships brick by brick.** A 30-chapter
   relationship arc gets 30 chapters of incremental beats —
   not 2 quiet scenes and a kiss.

If at any point the engine finds a conflict between its
outline design and your locked canon, it STOPS and surfaces the
conflict to you: "The outline I'm building would require [X],
but your world rules say [Y]. Which takes priority?" You
decide. The engine does not silently override.

## File Location Discipline (MANDATORY — HARD GATE — runs FIRST)

**Before any work begins, this flow MUST confirm or establish
a canonical project folder at
`~/Documents/Ideorix-Projects/[Title]/` with a `source-canon/`
subfolder containing your prior creative work.** The expected
layout (see `byo-canon-checklist.md` for full detail):

```
~/Documents/Ideorix-Projects/[Title]/
├── source-canon/          ← YOUR prior creative work (read-only canon)
│   ├── worldbuilding/     ← world files (geography, magic, factions, culture)
│   ├── characters/        ← character profiles (one per file, or one combined)
│   ├── voice-guide.md     ← voice / tone / register guide
│   ├── samples/           ← sample passages or pre-written scenes
│   └── locked-scenes.md   ← must-exist scenes (optional but recommended)
├── manuscript/            ← engine output (chapters, exports)
├── marketing/             ← engine output (cover, blurbs)
├── engine-data/           ← engine state (story bible, ledger, reports)
└── project-config.md      ← project metadata
```

**If no `source-canon/` exists**, this flow halts and asks the
user where their material is. The engine cannot operate in
Architect mode without canon to anchor to.

**HARD GATE — BLOCKING.** Outputs MUST be written to
`~/Documents/Ideorix-Projects/[Title]/manuscript/` and
`engine-data/`. The agent's working directory and any sandbox
path are forbidden destinations. See `core-pipeline.md`
§ File Location Discipline.

## How to start

Say any of:
- "Use my worldbuilding"
- "Bring your own canon"
- "I have my world and characters built — write the story"
- "Adopt my canon and write the prose"
- "Architect mode"

Or select **Use My Worldbuilding** from the Writers Studio menu.

## The flow

### Step 0: Source Material Absorption (MANDATORY — HARD GATE)

This step is the foundation. It MUST complete before any
outline-building begins. See `outline-builder.md` § Step 0 for
the full protocol. Brief summary of what happens:

1. **Identify all source files.** Engine scans
   `source-canon/` and lists every file: "I see the following
   source material: [list]. Is there anything else I should
   read before we begin?"
2. **Read every file in full.** Not skimming. Not from
   filenames. Full content via the Read tool. If files are
   large, read in sections — but read ALL of it.

   **Read-Verification HARD GATE (MANDATORY — see
   `read-verification.md`).** Each Read MUST be verified to
   return actual content above the per-format threshold (PDF
   ≥ 100 chars; DOCX ≥ 100; MD/TXT ≥ 20; Fountain ≥ 50). The
   Read tool can return a successful response with empty or
   near-empty extracted content — particularly for PDFs.
   Treating success metadata as "content absorbed" is the
   documented Beta-user failure mode where the engine built
   an entire Act 1 outline on missing PDF foundations and
   silently contradicted the user's canon. If ANY file's Read
   returns content below threshold, this step BLOCKS until
   the user resolves each failed read (paste content into
   chat / confirm-skip / re-upload). The block is not
   negotiable — proceeding past it with empty reads is
   forbidden.

3. **Extract canon constraints** as a structured checklist.
   Verbatim character traits, world rules, locked scenes,
   voice register, tone constraints, explicit negatives ("not
   brooding", "never cruel", "no teleportation").
4. **Present the extracted constraints to you for
   confirmation.** "Before I start building the outline,
   here's what I understand about your world, characters,
   and voice. Please confirm or correct anything."
5. **Wait for your confirmation.** Three options: "Confirmed
   — proceed", "Corrections needed", "Add more material".
6. **Lock the confirmed constraints as HARD RAILS.** The
   Outline Builder cannot violate them, change them, or
   silently override them.

This step exists because of a documented production failure
mode: agents drafting before absorbing the canon, leaning on
sample scenes as plot tentpoles, flattening characters,
projecting psychology, summarising threats, and producing
outlines that read as "greatest hits albums of canon moments
with summary connecting them, not novels." Step 0 makes
those failures structurally impossible — by ensuring canon
absorption happens BEFORE outline construction begins.

### Steps 1-9: Phase 1 setup (skipped where canon answers)

Standard Phase 1 setup runs (see `core-pipeline.md` § Phase
1: Interactive Setup), with one critical adaptation: any
question already answered by the source canon is auto-filled
and presented for user confirmation rather than asked
fresh. Example:

- Q1 (Genre / Subgenre) — if `worldbuilding/` indicates
  fantasy with elemental magic and dynastic politics, the
  engine auto-detects "epic fantasy" and asks: "Your
  worldbuilding suggests epic fantasy. Confirm or override?"
- Q3 (POV / Tense) — if the user's voice-guide file specifies third-
  limited past tense, auto-detected and confirmed.
- Q4 (Length / Chapter count) — asked fresh unless source
  canon includes a target.

The setup completes faster and with fewer redundant questions,
because the canon already answers many of them.

### Step 9.5 (v2.7.0+): Must-Exist Scenes Anchor

When v2.7.0 ships, this step collects the user's must-exist
scenes (specific images, character moments, set-pieces that
MUST appear in the manuscript) and uses them as the SEED for
outline construction. See the must-exist-scenes anchor protocol (v2.7.0+).

In v2.6.11, locked scenes are still collected but as part
of Step 0 canon absorption rather than as a dedicated step.
The full scene-first ordering ships in v2.7.0.

### Step 10: Detailed Chapter Outline (Architect mode)

Outline Builder Step 10 runs in Architect mode (see
`outline-builder.md` § Step 10). The locked constraints from
Step 0 bind every chapter: characters cannot be flattened,
world rules cannot be violated, voice cannot drift, locked
scenes must be served as goals (not slotted as tentpoles).

In v2.7.0+, Step 10 is rewired to construct the outline FROM
the must-exist scenes outward (place scenes in optimal
positions, build connective tissue between them as
purposeful chapters). In v2.6.11, Step 10 follows the
existing structural-template approach but with the Step 0
constraints firmly enforced.

### Phase 2: Story Bible Generation

The Story Bible is generated FROM your canon, not in addition
to it. Where your canon has filled a Bible section
(characters, world, voice), the engine consolidates rather
than re-creates. Where your canon hasn't filled a section
(e.g., chapter outline detail, plot beat structure), the
engine fills it through the standard Phase 2 flow with
Architect-mode constraints applied.

The output `engine-data/research-bible.md` (or
`engine-data/story-bible.md`) reflects YOUR canon, with the
engine's structural additions clearly labeled.

### Phases 3-6: Standard pipeline with Architect mode active

Chapter generation, verification, editorial pipeline, and
Phase 6 Delivery all run as standard — but with the
Architect mode flag set in `engine-data/project-config.md`,
which propagates to every downstream agent:

- **Architect agent (`blueprint-agent.md`):** treats locked
  scenes as immutable; refuses to invent character traits;
  builds chapter briefs that serve canon, not invent canon.
- **Writer agent (`prose-agent.md`):** treats voice guide
  as authoritative prose register; treats character voice
  as immutable; refuses to project psychology onto
  characters.
- **Quality Guardian (`quality-gate.md`):** flags any
  chapter prose that drifts from canon (character flattening,
  world-rule violation, voice drift, projection of unstated
  psychology).
- **Continuity Guardian / Canon Validator
  (`canon-validator.md`):** enforces YOUR canon as the
  source of truth, not an Ideorix-generated bible.

## What changes for the user

Compared to standard Write a New Book:

- **Setup is faster** — questions already answered by canon
  are auto-filled and confirmed rather than asked fresh.
- **The Bible is YOURS** — the engine consolidates your
  material rather than inventing a parallel one.
- **Character voice doesn't drift** — Architect mode is
  binding through every prose stage.
- **Locked scenes are served, not slotted** — your must-exist
  moments anchor the outline rather than decorating it.
- **You stay in control of the creative direction** — the
  engine surfaces conflicts when they arise, and you decide.

## Limits of this flow (be honest about scope)

This flow does NOT:

- Re-invent your characters in interesting new ways. If you
  want creative reinterpretation, use Write a New Book.
- Override your voice guide for genre-convention reasons. If
  your voice guide says first-person past tense, the
  manuscript is first-person past tense even if the genre
  template typically uses third-person.
- Add psychological depth your profiles haven't authorised.
  The engine refuses to project survivor's guilt, misread
  self-image, etc., onto your characters.
- Substitute its judgment for yours when canon is ambiguous.
  Where canon is silent, the engine asks rather than guesses.

If your canon is incomplete (e.g., you have characters and
world but no story idea), the engine surfaces the gap and
runs a focused mini-flow to fill it WITH your involvement —
rather than inventing fill content silently.

## Documented failure modes this flow counter-protocols

The Outline Builder's Anti-Rewriting Rule (see
`outline-builder.md` § "Anti-Rewriting Rule") names the
specific failure modes Architect mode is designed to prevent:

1. **Drafting before absorbing canon** — Step 0 makes
   absorption mandatory before outline generation.
2. **Leaning on sample scenes as load-bearing tentpoles** —
   sample scenes are PROSE EXAMPLES, not plot points.
3. **Summarising threat instead of dramatising** — outline
   designs scenes where the reader feels the threat
   on-page.
4. **Stripping character warmth** — character profiles bind
   every chapter; flattening to easier-to-write versions
   is forbidden.
5. **Trust building skipped** — relationships build chapter
   by chapter with specific incremental beats.
6. **Projecting inner arcs onto user's characters** — the
   engine refuses to add arcs the user didn't specify.
7. **Oscillating between over-asking and over-producing** —
   the Step 0 confirmation gate establishes the canon once,
   then the engine executes against it without circling back
   for re-confirmation.

These failure modes were documented from a real production
session in which the engine produced an unusable outline
despite the user providing comprehensive canon. The fix is
this flow: a dedicated entry point that routes through Step
0 as a HARD GATE before any outline-building begins, with
Architect mode binding through every downstream stage.

## See also

- `outline-builder.md` § Step 0 (Source Material Absorption)
- `outline-builder.md` § Anti-Rewriting Rule
- `byo-canon-checklist.md` — canonical `source-canon/` layout
- `core-pipeline.md` § File Location Discipline
- `core-pipeline.md` § Q9 (Outline Source) — Architect mode trigger
