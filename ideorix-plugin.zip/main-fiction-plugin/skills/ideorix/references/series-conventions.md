---
name: series-conventions
description: "Genre-specific multi-volume series conventions — escalation patterns, arc pacing, and reader expectations per genre"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Genre-Specific Series Conventions

When planning a multi-volume series, adapt the architecture and pacing to match
genre reader expectations. Each genre has distinct rules for how volumes connect,
how characters evolve across books, and what readers demand from a series commitment.

---

## Cozy Mystery Series

**Architecture**: Each volume has a standalone case that is fully resolved, PLUS a
series-spanning tension that builds across volumes.

**Series-Level Elements**:
- A town or community that evolves and grows richer with each volume
- The investigator's growing reputation, capabilities, and community standing
- A long-running series mystery OR gradually escalating threats to the community
- Recurring suspects who were cleared in one volume may return in new roles
- Seasonal variety (one volume per season is a popular pattern)
- Community events that anchor each volume (festivals, holidays, openings)

**Romance Progression in Cozy Mystery Series**:
- SLOW BURN is the standard. Do not rush the romance.
- Volume 1: Meeting, attraction, perhaps a moment of connection
- Volume 2: Growing tension, first significant one-on-one time, an obstacle
- Volume 3: Significant emotional moment, perhaps a first kiss or near-miss
- Volume 4: Deepening, a crisis that tests the relationship
- Volume 5: Resolution, commitment, readers get the payoff
- For shorter series (3 volumes), compress but never skip stages

**Paranormal Elements in Cozy Mystery Series**:
- Magical world-building deepens each volume (new abilities, new creatures, new
  rules discovered)
- The investigator's powers grow but never make the case too easy to crack
- New familiars or magical characters can be introduced per volume
- The magical community should have its own politics and tensions that generate
  subplots

**What Readers Expect**:
- Comfort and consistency — the "visiting old friends" feeling
- Fair-play mysteries (clues planted, solution logical)
- Character growth that's gradual and believable
- Humour maintained throughout the series
- The world should feel like a place they want to inhabit
- Justice always prevails — even in the series-level arc

---

## Romance Series

**Two Primary Models**:

### Interconnected Standalones (most common)
- Each volume features a different couple and a complete HEA
- Set in the same world (town, friend group, workplace, family)
- Supporting characters from earlier volumes appear in later ones
- The couple from Volume 1 might have cameos in Volumes 3–5
- Readers can technically start at any volume but get more from reading in order

### Continuing Couple
- Same couple across all volumes, relationship deepening each time
- Each volume has its own central conflict
- Often used for slow-burn or dark romance
- Higher risk — readers need to trust the HEA is coming

**Series-Level Elements**:
- A shared community or setting that grows
- Running traditions, inside jokes, or events
- Escalating emotional stakes
- For interconnected standalones: plant the next couple's chemistry as a subplot
  1–2 volumes early

**What Readers Expect**:
- HEA or HFN in every volume (even if the series has a bigger arc)
- Growing emotional depth
- The feeling that the series world is expanding
- Favourite characters from earlier volumes showing up happy

---

## Paranormal Romance Series

Similar to romance series but with:
- A magical world that expands each volume
- Power scaling — characters or the world grow stronger/more complex
- Often features a "fated" or "destined" element
- World-building reveals that change understanding of the magical system
- A series-spanning supernatural threat that builds

---

## Fantasy Series

**Architecture**: Usually a continuing storyline rather than standalone entries.

- Epic quest or conflict that spans the series
- World-building that deepens significantly each volume
- Power progression for the protagonist
- Expanding cast of characters
- Political/social systems that become more complex
- The stakes escalate dramatically from volume to volume

---

## Thriller / Suspense Series

**Two Primary Models**:

### Same Protagonist (most common)
- Each volume has a standalone case/threat
- The protagonist's personal life evolves across volumes
- Skills and reputation grow
- A recurring antagonist or organisation may connect volumes
- Personal stakes escalate

### Connected Standalone
- Different protagonists in the same world
- Events from one volume have ripple effects in others
- Often tied to the same organisation, location, or event

---

## Urban Fantasy Series

- Same protagonist across all volumes
- World-building reveals layer by layer (the "hidden world" expands)
- Power progression is expected
- Often has a "major threat" that builds across the series
- Personal relationships deepen alongside escalating threats
- Humour and voice consistency are crucial — readers return for the protagonist's
  personality as much as the plot

---

## Horror Series

**Architecture**: Escalating dread — each volume raises the supernatural or
psychological stakes while deepening the mythology.

**Two Primary Models**:

### Same Protagonist / Location
- A single protagonist (or group) faces increasingly dangerous threats
- Each volume peels back another layer of the central horror
- The protagonist accumulates trauma and hard-won knowledge
- Rules of the threat are revealed gradually — what worked before stops working
- Personal cost escalates: allies are lost, relationships strained, sanity tested

### Anthology-Connected
- Different protagonists encounter manifestations of the same underlying evil
- Shared mythology links volumes (a cursed object, a location, a bloodline)
- Earlier volumes' events become legend or warning in later ones
- The final volume often reveals the origin or confronts the source

**Series-Level Elements**:
- A mythology or cosmology that deepens with each volume
- Escalating personal cost — the horror gets closer to home each time
- Rules that shift: what the characters (and readers) thought they knew gets subverted
- Dread that compounds — earlier traumas resurface and amplify new threats
- An atmosphere that darkens progressively across volumes

**What Readers Expect**:
- Genuine escalation of fear — each volume scarier or more disturbing than the last
- Internal consistency of the horror rules (even when rules shift, the shift is logical)
- Characters who earn their survival through resourcefulness, not luck
- Payoff on the mythology — the deepening world-building must lead somewhere
- An ending that honours the horror rather than neutralising it

---

## Gothic / Gothic Horror Series

**Architecture**: Generational or locational — the series centres on a place, a
family, or both, with each volume excavating deeper layers of history and secrets.

**Series-Level Elements**:
- A central location (estate, town, institution) that holds secrets across volumes
- Generational trauma that passes down and compounds
- The past literally haunting the present — historical events echoing in each volume
- Architectural or environmental decay that mirrors narrative deterioration
- Family secrets revealed in stages, each more devastating than the last
- Atmosphere as a character — the setting's mood deepens and shifts across volumes

**What Readers Expect**:
- Rich, immersive atmosphere maintained across volumes
- Secrets that recontextualise earlier events when revealed
- The sense that the location/family has deeper darkness yet to uncover
- Beauty and horror intertwined — the aesthetic is part of the promise
- Resolution that acknowledges the weight of history rather than erasing it

---

## Science Fiction Series

**Architecture**: Expanding scope — from personal to planetary to cosmic.

**Two Primary Models**:

### Continuing Saga
- Same protagonist(s) across volumes, stakes expanding outward
- Technology and world-building grow more complex
- Political/social systems evolve in response to events
- The implications of the core speculative element unfold across volumes

### Universe-Connected
- Different protagonists in the same universe, different time periods or locations
- Shared technology, history, or speculative premise links volumes
- Events in one volume have ripple effects felt in others
- The universe itself is the protagonist

**Series-Level Elements**:
- A speculative premise whose implications deepen with each volume
- Technology or science that evolves, with consequences
- Political and social structures that respond realistically to change
- Scale escalation — personal → institutional → societal → existential
- Thematic questions about humanity, consciousness, progress, or ethics
  that grow more complex

**What Readers Expect**:
- Internal consistency of the speculative rules
- Ideas that go somewhere — each volume should push the "what if" further
- Characters who are shaped by the world they inhabit
- Payoff on the big questions, not just the plot threads
- A sense of discovery — each volume should reveal something new about the universe

---

## Space Opera Series

**Architecture**: Epic scale with intimate character moments — galactic stakes
anchored by personal relationships.

**Series-Level Elements**:
- A galaxy-spanning conflict that escalates across volumes
- Factions, empires, or civilisations with shifting alliances
- A crew or ensemble cast whose internal dynamics drive the emotional core
- Technology, alien species, or cosmic phenomena introduced progressively
- Political intrigue interwoven with action set pieces
- The protagonist's role in the larger conflict grows from peripheral to central

**What Readers Expect**:
- Grand scale that never loses the human element
- Space battles and action sequences that escalate
- Complex political landscapes with shifting allegiances
- Found-family dynamics within the core cast
- Revelations about the universe's history or nature that reframe the conflict

---

## Dystopian Series

**Architecture**: Escalating rebellion — from discovery of the system's true nature,
through resistance, to confrontation and resolution.

**Common Arc Pattern**:
- Volume 1: Discovery — protagonist sees the system's true nature
- Volume 2: Resistance — protagonist joins or leads opposition, discovers the cost
- Volume 3: Confrontation — the system is challenged; victory is costly and imperfect

**Series-Level Elements**:
- A social/political system whose layers of control are revealed progressively
- The protagonist's radicalisation arc — from compliant to rebel
- Personal sacrifice that escalates with each volume
- Allies who are lost, betrayed, or compromised
- The question of what replaces the old system (often more complex than expected)

**What Readers Expect**:
- A system that feels plausibly constructed and internally consistent
- The protagonist earning their role through choices, not destiny
- Real consequences — victories should cost something
- Moral complexity — the "good side" should have flaws too
- An ending that acknowledges the difficulty of systemic change

---

## Epic Fantasy Series

**Architecture**: Quest or war arc spanning volumes, with deep world-building and
large ensemble casts.

**Series-Level Elements**:
- A prophecy, quest, or existential threat that spans the full series
- Multiple POV characters whose storylines converge over volumes
- A magic system with rules that deepen and expand
- Political landscapes with multiple factions, betrayals, and alliances
- World history that becomes relevant to current events
- Power progression for key characters, with corresponding moral challenges

**What Readers Expect**:
- World-building that rewards investment — the more you read, the richer it gets
- Character arcs that span the full series with meaningful payoff
- Political and military strategy that feels earned, not convenient
- The magic system's rules honoured consistently
- An ending that resolves the major threads while honouring the journey

---

## Dark Fantasy Series

Similar to epic fantasy but with:
- Moral ambiguity as a core feature — protagonists make terrible choices
- A world where the "good" option is often merely the least bad
- Power that corrupts — character progression includes moral deterioration
- Grim consequences that carry across volumes (deaths stick, injuries scar)
- Hope is scarce but meaningful when it appears

---

## Cozy Fantasy Series

**Architecture**: Comfort-driven — each volume deepens the community, the found
family, and the protagonist's sense of belonging.

**Series-Level Elements**:
- A warm, inviting setting that expands organically (new shops, neighbours, traditions)
- Found-family bonds that deepen across volumes
- Low-stakes conflicts that feel meaningful to the characters
- The protagonist settling in and finding purpose
- Seasonal or cyclical rhythms that give each volume a distinct flavour
- Gentle world-building — magic is wondrous, not threatening

**What Readers Expect**:
- Warmth and comfort maintained across volumes — never betrayed
- Character growth through connection, not combat
- A world they want to visit — the reading experience should feel like a retreat
- Conflicts that resolve through communication, compassion, and community
- No character deaths that break the found family

---

## Dark Romance Series

**Architecture**: Intensifying emotional and physical intimacy alongside escalating
external threats.

**Series-Level Elements**:
- A central relationship whose power dynamics shift across volumes
- External threats that force the couple together or drive them apart
- Moral grey areas that deepen — the love interest's darkness is explored, not excused
- Escalating intimacy that mirrors emotional vulnerability
- A redemption arc or acceptance arc for the morally complex love interest
- Secondary couples seeded for future volumes

**What Readers Expect**:
- Emotional intensity that never plateaus
- The central relationship earning its resolution through genuine growth
- Dark elements handled with authorial awareness, not glorification
- Consent as a clear line even in power-imbalanced dynamics
- HEA that feels earned by the journey, not granted despite it

---

## Historical Fiction Series

**Architecture**: Generational or era-spanning — the series tracks a family, community,
or institution across historical periods.

**Two Primary Models**:

### Generational Saga
- Each volume follows a different generation of the same family
- Historical events shape each generation's challenges
- Family traits, secrets, and legacies echo across volumes
- Objects, places, or traditions link the generations

### Same-Era Continuing
- Same protagonist across volumes in a consistent historical period
- Each volume covers a different historical event or phase
- The protagonist's relationship to their era deepens and evolves

**Series-Level Elements**:
- Historical accuracy that deepens with each volume
- The way larger historical forces shape individual lives
- Recurring themes that manifest differently in each era/volume
- A sense of the passage of time — things change, are lost, are preserved

**What Readers Expect**:
- Rigorous period detail that enhances rather than overwhelms the story
- Characters who feel of their time, not modern people in costume
- Historical events woven into personal narratives, not lectured about
- The feeling of witnessing history through intimate human experience

---

## Domestic Thriller Series

**Architecture**: Same protagonist (often an ordinary person) who keeps encountering
or uncovering threatening situations in domestic settings.

**Series-Level Elements**:
- A protagonist whose investigative instincts sharpen across volumes
- Domestic settings that become threatening (neighbourhoods, schools, workplaces)
- Each volume's threat feels plausible and grounded
- Trust as a recurring theme — who can be trusted, and how trust is rebuilt
- The protagonist's personal relationships tested by each volume's events
- Escalating personal stakes — the threats get closer to home

**What Readers Expect**:
- Twists that feel fair in retrospect
- A protagonist they root for, who uses wits rather than weapons
- Domestic settings made genuinely unsettling
- Standalone satisfaction per volume while the protagonist's life develops
- The feeling that danger can hide in ordinary places

---

## Psychological Thriller Series

Similar to thriller/suspense but with:
- Unreliable narration that deepens across volumes — reader trust is continuously tested
- Psychological complexity as the primary escalation (not physical danger)
- Internal landscapes as vivid as external ones
- Each volume may reframe understanding of previous volumes
- The protagonist's mental state as a key series thread

---

## Crime / Noir Series

**Architecture**: Procedural with character erosion — the protagonist solves cases
but the work takes a cumulative toll.

**Series-Level Elements**:
- A protagonist whose personal life deteriorates as professional competence grows
- A city or jurisdiction that is itself a character, revealed across volumes
- Institutional corruption or systemic failure as a series-level theme
- Cases that are standalone but occasionally connect to a larger pattern
- Moral compromise that compounds — each volume's choices narrow future options

**What Readers Expect**:
- Procedural authenticity — the investigative work feels real
- A protagonist with a distinctive voice and worldview
- Atmosphere and setting as thick as the plot
- Moral complexity — no clean wins
- The cumulative weight of the work reflected in the character

---

## Literary Fiction Series

**Architecture**: Thematic rather than plot-driven — volumes are connected by theme,
place, characters, or worldview rather than a continuing storyline.

**Series-Level Elements**:
- Thematic resonance across volumes — the same questions examined from different angles
- Characters whose interior lives deepen with each volume
- A setting or community explored with increasing intimacy
- Prose style as a unifying element — the voice is the connective tissue
- Events from earlier volumes recontextualised by later ones

**What Readers Expect**:
- Depth over pace — each volume should reward careful reading
- Characters who feel like real people encountered across years
- Thematic ambition — the series should be about something larger
- Language and craft that sustain across volumes
- No tidy resolutions — life's complexity honoured

---

## Coming-of-Age Series

**Architecture**: Developmental — each volume covers a distinct life phase or
formative experience.

**Series-Level Elements**:
- A protagonist aging and maturing across volumes
- Each volume centred on a specific developmental challenge (identity, belonging,
  independence, first love, loss, purpose)
- Relationships that evolve as the protagonist matures
- The world expanding as the protagonist's awareness grows
- Nostalgia and growth in tension — looking back while moving forward

**What Readers Expect**:
- Authentic voice that matures across volumes without losing its essence
- Developmental milestones that feel true to the age being portrayed
- Relationships that change realistically as people grow
- The bittersweet quality of growing up — gains and losses both honoured
- A sense of the protagonist becoming who they were always going to be

---

## Middle Grade Series

**Architecture**: Adventure-driven with friendship at the centre — each volume is
a complete adventure with series-level mysteries or relationships developing.

**Series-Level Elements**:
- A friend group or team whose dynamics evolve across volumes
- A world with secrets revealed progressively (hidden rooms, new abilities, deeper lore)
- Each volume introduces a new challenge, skill, or location
- Adult characters who are present but don't solve the problems
- The protagonist's growing confidence and competence
- Humour and heart maintained consistently

**What Readers Expect**:
- Age-appropriate content with genuine stakes (not sanitised, but safe)
- Protagonists who solve problems through cleverness, teamwork, and bravery
- Friendship dynamics that feel real — disagreements, reconciliations, loyalty tested
- A world that rewards curiosity and exploration
- Each volume accessible enough for new readers while rewarding series loyalty

---

## YA Fantasy Series

**Architecture**: Identity-driven epic — a coming-of-age arc woven into a fantasy
quest or conflict.

**Series-Level Elements**:
- A protagonist discovering their identity and power simultaneously
- A corrupt or failing system the protagonist must challenge
- Romance subplot that deepens across volumes
- Friend group / found family that forms and is tested
- Power progression tied to emotional growth
- Moral complexity increasing — the "right choice" becomes harder each volume

**What Readers Expect**:
- A protagonist with agency who earns their role
- Romance that builds with genuine chemistry (not instalove)
- Stakes that feel real — characters can be lost
- Themes of identity, belonging, and challenging authority
- An ending that honours the characters' sacrifices

---

## YA Contemporary Series

Similar to coming-of-age but with:
- Modern settings and issues (social media, mental health, identity, activism)
- Each volume may focus on a different character in the same friend group
- Diverse representation as natural, not performative
- Realistic consequences for choices — no magical fixes
- Voice-driven — the narrative voice is the primary draw

---

## Family Saga Series

**Architecture**: Generational — the series tracks a family across decades or
centuries, with each volume centred on a different generation or branch.

**Series-Level Elements**:
- A family legacy (business, estate, secret, curse, talent) that connects volumes
- Generational patterns that repeat and evolve
- Historical events as backdrop to family drama
- Secrets passed down (or buried) across generations
- The tension between family loyalty and individual identity
- Objects, places, or traditions that recur as touchstones

**What Readers Expect**:
- Rich family dynamics with characters who feel distinct across generations
- The sense that the past shapes the present
- Satisfying reveals about family history
- Characters who both embody and resist their family legacy
- A sense of the passage of time felt in the storytelling

---

## Romantic Comedy Series

**Architecture**: Interconnected standalones in a warm, witty world — each volume
features a new couple from the same social orbit.

**Series-Level Elements**:
- A shared setting (workplace, friend group, small town, family) that provides
  consistent comedic opportunities
- Past couples appearing as happily settled secondary characters
- Running gags, traditions, and inside jokes that reward series readers
- Supporting characters whose romantic potential is teased before their volume
- A tone of warmth and optimism maintained across all volumes

**What Readers Expect**:
- Laugh-out-loud moments in every volume
- Banter and chemistry that feel fresh for each new couple
- HEA guaranteed — the fun is in the journey, not the uncertainty
- Cameos from past couples that are delightful, not intrusive
- A world that feels like a place where love (and humour) always wins

---

## Western Series

**Architecture**: Frontier chronicle — same protagonist across volumes, moving
through different frontier challenges and settlements.

**Series-Level Elements**:
- A protagonist shaped by the landscape and the era
- Each volume tied to a different frontier challenge (land disputes, railroad,
  mining, cattle, law enforcement, settlement)
- The tension between civilisation and wilderness as a series-level theme
- A code of honour tested and refined across volumes
- The frontier itself changing — what was wild becomes settled
- Relationships forged in hardship that deepen across volumes

**What Readers Expect**:
- Authentic period detail and landscape
- Action sequences rooted in the era (not modern action in costume)
- Moral clarity tested by frontier realities
- A protagonist whose skills and reputation grow
- The frontier as a character — weather, terrain, distance as real forces

---

## Espionage Series

**Architecture**: Mission-based with accumulating personal cost — each volume is a
standalone operation while the protagonist's loyalties and identity erode.

**Series-Level Elements**:
- A protagonist whose cover identities and real self blur across volumes
- Each volume centred on a different operation, location, or geopolitical crisis
- Institutional politics (agency rivalries, moles, shifting allegiances)
- A personal life that becomes increasingly difficult to maintain
- Tradecraft skills that deepen and evolve
- A series-level conspiracy or adversary revealed in stages

**What Readers Expect**:
- Authentic tradecraft and geopolitical context
- Moral ambiguity — the "good side" does terrible things too
- Twists rooted in character and institutional logic, not coincidence
- The personal cost of espionage depicted honestly
- A protagonist whose competence is matched by their vulnerability

---

## Supernatural / Paranormal Series

**Architecture**: Expanding mythology — each volume reveals more about the
supernatural world and the protagonist's place in it.

**Series-Level Elements**:
- A supernatural hierarchy or ecosystem revealed across volumes
- The protagonist's abilities or knowledge growing
- Rules of the supernatural that deepen and occasionally subvert expectations
- A balance between the supernatural and the mundane — both worlds matter
- A series-level threat emerging from the mythology
- Alliances with supernatural beings that grow more complex

**What Readers Expect**:
- Internal consistency of the supernatural rules
- Genuine wonder alongside genuine danger
- A protagonist who is tested by powers beyond their understanding
- The mythology rewarding investment — deeper reading yields deeper meaning
- Resolution that honours both the human and supernatural dimensions

---

## Satire Series

**Architecture**: Thematic — each volume satirises a different institution, trend,
or social phenomenon, connected by a shared world or recurring characters.

**Series-Level Elements**:
- A consistent satirical voice and worldview across volumes
- Recurring characters who move through different satirical targets
- The satirical world becoming more absurd as volumes progress
- Real-world parallels that shift with each volume's focus
- Dark humour that deepens as the series reveals more of its world

**What Readers Expect**:
- Sharp, consistent wit that doesn't soften across volumes
- Recognition of the real-world targets without heavy-handedness
- Characters who are both satirical types and genuine people
- Escalating absurdity that remains internally logical
- A point of view — the satire should stand for something, not just mock

---

## Magical Realism Series

**Architecture**: Layered reality — each volume deepens the blurring between the
mundane and the magical, often tied to a family, community, or place.

**Series-Level Elements**:
- Magic woven into everyday life — never fully explained, never fully dismissed
- A place or family where the magical is inherited or endemic
- Each volume reveals a new facet of how magic operates in this world
- Generational stories where magical elements echo across time
- The emotional truth of the magic matters more than its mechanics

**What Readers Expect**:
- Poetic prose that sustains across volumes
- Magic that feels inevitable rather than arbitrary
- Emotional depth — the magic serves the human story, not the reverse
- Cultural specificity honoured and deepened
- Ambiguity maintained — the reader is never certain what is "real"

---

## LitRPG Series

**Architecture**: Progression-driven — the protagonist levels up, gains new abilities,
and faces increasingly powerful challenges across volumes.

**Series-Level Elements**:
- A game or system whose mechanics are revealed and expanded across volumes
- Clear power progression with measurable advancement (levels, skills, stats)
- Escalating dungeon/quest/challenge difficulty
- A guild, party, or team whose composition evolves
- Meta-knowledge about the system that reframes earlier events
- Economic and political systems within the game world that grow more complex

**What Readers Expect**:
- Consistent system mechanics (no deus ex machina power-ups)
- Satisfying progression — each volume should show meaningful advancement
- Strategic problem-solving using the system's rules
- The game world taken seriously as a real environment
- Power fantasy balanced with genuine challenge

---

## Steampunk Series

**Architecture**: Invention-driven — each volume introduces new technology or
discoveries that reshape the world and its conflicts.

**Series-Level Elements**:
- A technological trajectory — inventions from earlier volumes have consequences
  in later ones
- Political structures that evolve in response to technological change
- Class dynamics explored through the lens of industrial revolution
- An aesthetic (brass, gears, steam, airships) maintained and expanded
- The tension between progress and its human cost as a series-level theme

**What Readers Expect**:
- Inventive world-building that builds on itself across volumes
- The aesthetic honoured consistently — it's part of the promise
- Characters shaped by their relationship to technology
- Adventure and ingenuity as primary drivers
- The social implications of the technology explored, not just the spectacle

---

## Cyberpunk Series

Similar to science fiction but with:
- Corporate power structures whose corruption deepens across volumes
- Technology that becomes increasingly invasive or threatening
- The boundary between human and machine as a series-level question
- Street-level perspective maintained even as stakes escalate
- Noir-influenced atmosphere and moral ambiguity throughout
- The digital and physical worlds increasingly blurred

---

## Survival Series

**Architecture**: Escalating threat — each volume presents a more extreme survival
scenario or reveals deeper layers of the threat.

**Series-Level Elements**:
- A protagonist whose survival skills and psychological resilience grow
- Each volume escalates the environmental or human threat
- Resources, allies, and safe havens gained and lost across volumes
- The psychological toll of sustained survival as a series thread
- A larger cause or mystery behind the survival scenario (revealed across volumes)

**What Readers Expect**:
- Authentic survival detail — readers want to learn alongside the protagonist
- Genuine danger — plot armour undermines the genre
- Resourcefulness rewarded — the protagonist survives through skill, not luck
- The psychological dimension honoured — survival changes people
- Escalation that feels earned, not arbitrary

---

## Adventure Series

**Architecture**: Quest or journey-based — each volume is a distinct expedition,
mission, or adventure, with the protagonist's skills and reputation growing.

**Series-Level Elements**:
- A protagonist whose resourcefulness and daring grow across volumes
- Each volume set in a different location or environment
- Escalating danger and higher-stakes missions
- A supporting cast that rotates but with recurring allies
- A series-level mystery, organisation, or adversary that connects volumes
- Treasures, discoveries, or knowledge accumulated across the series

**What Readers Expect**:
- Exotic settings vividly rendered
- Action sequences that escalate in creativity and stakes
- A protagonist who is clever and capable but not invincible
- Each volume self-contained enough to satisfy while building the larger arc
- The thrill of discovery — each volume should reveal something new about the world

---

## Afrofuturism Series

**Architecture**: Cultural-technological — each volume explores a different facet
of African diasporic futures, connected by shared world-building or lineage.

**Series-Level Elements**:
- Technology or magic systems rooted in African cultural traditions
- A society or civilisation whose history and future unfold across volumes
- Themes of identity, heritage, liberation, and reimagined power structures
- Ancestral knowledge as a living force that deepens across the series
- Colonialism, resistance, and sovereignty as series-level tensions
- Art, music, and oral tradition woven into the narrative fabric

**What Readers Expect**:
- Cultural specificity celebrated, not tokenised
- Speculative elements grounded in real traditions and philosophies
- Power structures that challenge Western defaults
- Characters whose identities are shaped by culture and community
- World-building that feels both visionary and rooted

---

## Cli-Fi (Climate Fiction) Series

**Architecture**: Escalating crisis — each volume tracks a different phase of
environmental catastrophe and human response.

**Series-Level Elements**:
- An environmental crisis that worsens or transforms across volumes
- Different communities or regions affected in each volume
- The tension between survival, adaptation, and restoration
- Political and social systems breaking down or reforming
- Technology as both cause and potential solution
- Generational impact — the choices of one volume shape the world of the next

**What Readers Expect**:
- Scientific plausibility grounded in real climate science
- Human stories at the centre — the crisis is the backdrop, not the protagonist
- Hope and agency balanced against the scale of the threat
- Diverse responses to crisis (not just one "right" answer)
- The emotional weight of loss alongside the drive to rebuild

---

## Comedy Series

**Architecture**: Situational — a recurring cast in an escalating series of absurd
situations, with each volume funnier and more outrageous than the last.

**Series-Level Elements**:
- A core cast whose quirks and dynamics deepen across volumes
- A setting or situation that generates renewable comic material
- Running gags that evolve and pay off across volumes
- Escalating absurdity while maintaining internal logic
- Character growth expressed through comedy — characters change but stay funny
- Secondary characters who become fan favourites and get expanded roles

**What Readers Expect**:
- Consistent comedic voice and timing across volumes
- Each volume funnier than the last (or at least as funny)
- Characters who are lovable despite (because of) their flaws
- Callbacks and in-jokes that reward series loyalty
- Heart underneath the humour — moments of genuine emotion

---

## Contemporary Fiction Series

Similar to literary fiction but with:
- More accessible prose and pace
- Relationship dynamics as the primary driver
- A community or social circle that evolves across volumes
- Each volume may focus on a different character's perspective
- Contemporary issues (technology, social change, workplace dynamics) as backdrop
- Emotional accessibility — readers should connect easily

---

## Dark Academia Series

**Architecture**: Institutional mystery — each volume peels back another layer of
the academic institution's dark history and the protagonist's entanglement.

**Series-Level Elements**:
- An institution (university, secret society, elite school) with hidden depths
- Intellectual pursuits that become dangerous — knowledge as power and threat
- A group of students or scholars whose alliances shift across volumes
- Historical secrets embedded in the institution that surface progressively
- The seductive atmosphere of learning, beauty, and privilege masking decay
- Moral compromises that accumulate — how far will characters go for knowledge?

**What Readers Expect**:
- Rich, atmospheric academic settings
- Intellectual content that enhances the plot (not lectures)
- Morally complex characters who are brilliant but flawed
- The tension between beauty and darkness maintained across volumes
- Secrets that feel earned — revelations that reframe earlier events

---

## Drama Series

**Architecture**: Character-driven — each volume examines a different crisis or
turning point in the protagonist's life or a community's evolution.

**Series-Level Elements**:
- Characters whose inner lives deepen across volumes
- Relationship dynamics that evolve realistically
- Each volume centred on a different life event or interpersonal crisis
- A community or family whose collective story unfolds
- Thematic threads (forgiveness, ambition, loyalty) explored from new angles
- Time passing — characters age, circumstances change, priorities shift

**What Readers Expect**:
- Emotional authenticity above all
- Characters who feel like real people
- Relationships portrayed with nuance and complexity
- Each volume illuminating something new about the human experience
- Resolution that honours the messiness of real life

---

## Erotica Series

**Architecture**: Exploration-driven — each volume explores new dimensions of
intimacy, desire, and relationship dynamics.

**Two Primary Models**:

### Same Couple
- The same couple across volumes, exploring deeper levels of trust and intimacy
- Each volume introduces a new challenge, boundary, or dynamic
- Emotional intimacy deepening alongside physical intimacy
- Power dynamics evolving as the relationship matures

### Interconnected
- Different protagonists in the same world (club, community, social circle)
- Each volume features a new central relationship
- Past couples appear as secondary characters
- A shared setting that provides context and community

**Series-Level Elements**:
- Escalating emotional and physical intimacy across volumes
- Clear, evolving consent dynamics
- Character growth through vulnerability and trust
- A world or community that normalises open exploration
- Emotional arcs as important as physical scenes

**What Readers Expect**:
- Heat level maintained or escalated across volumes
- Emotional depth alongside physical content
- Consent as foundational — always clear, never ambiguous
- Characters who grow through intimacy, not just experience it
- Fresh scenarios that don't repeat earlier volumes

---

## Fan Fiction Series

**Architecture**: Source-material-driven — each volume explores a different
"what if" or untold story from the source material.

**Series-Level Elements**:
- Fidelity to source material's characters and world (unless AU is stated)
- Each volume expanding on underexplored aspects of the source
- Character voices consistent with canon
- Original elements that enhance rather than contradict the source
- A central OC (original character) or ship whose arc spans volumes

**What Readers Expect**:
- Love and respect for the source material
- Character voices that feel authentic
- Fresh perspectives on familiar characters and worlds
- The gap between canon moments filled with plausible detail
- Emotional payoffs that the source material didn't provide

---

## General Fiction Series

Similar to contemporary fiction — adaptable to any setting or style. Follow the
conventions of whichever genre elements are most prominent. When truly genre-
agnostic, default to the universal principles below.

---

## Gothic Romance Series

**Architecture**: Escalating revelation — each volume deepens the mystery of the
romantic interest and the dark setting, with passion and danger intertwined.

**Series-Level Elements**:
- A brooding, complex love interest whose secrets unfold across volumes
- A central location (manor, estate, castle) with hidden histories
- Atmospheric tension between desire and danger maintained throughout
- Family or ancestral secrets that surface progressively
- The heroine's agency growing even as the setting threatens to consume her
- Past romances or tragedies echoing into the present

**What Readers Expect**:
- Thick, moody atmosphere sustained across volumes
- A love interest whose darkness is explored, not excused
- The heroine as an active participant, not a passive victim
- Secrets that genuinely recontextualise earlier events
- Romance that feels dangerous but ultimately safe (HEA guaranteed)

---

## Historical Fantasy Series

**Architecture**: Era-spanning — each volume may cover a different historical
period with fantasy elements that connect across time.

**Series-Level Elements**:
- A magical system rooted in specific historical cultures and periods
- Historical events reimagined through a fantasy lens
- Power, artefacts, or bloodlines that persist across historical eras
- The tension between historical accuracy and fantasy invention
- Real historical figures interacting with fantasy elements
- A series-level mythology that explains the presence of magic in history

**What Readers Expect**:
- Period detail that feels authentic even with fantasy elements
- Magic that enhances history rather than replacing it
- Characters grounded in their historical context
- The fun of "what if magic were real during [era]" fully explored
- Internal consistency — the fantasy rules don't change arbitrarily

---

## Historical Romance Series

**Architecture**: Period-set interconnected standalones — each volume features a
different couple within the same social circle, family, or era.

**Series-Level Elements**:
- A shared social world (ton, court, regiment, estate) linking volumes
- Period-accurate social constraints driving romantic tension
- Past couples appearing as settled, happy secondary characters
- Family dynamics (siblings, cousins, friends) providing natural volume pairings
- Historical events as backdrop that affects different couples differently
- Reputation, scandal, and social standing as recurring obstacles

**What Readers Expect**:
- Period authenticity in language, manners, and social rules
- HEA in every volume — non-negotiable
- Chemistry that overcomes period-appropriate obstacles
- The next couple's tension seeded 1–2 volumes ahead
- Cameos from past couples that feel warm, not intrusive

---

## Horror Romance Series

**Architecture**: Danger and desire intertwined — each volume deepens both the
romantic bond and the horror elements simultaneously.

**Series-Level Elements**:
- A supernatural or horrific world whose rules deepen across volumes
- A central romance where one or both partners are entangled with the horror
- The horror element testing the relationship in each volume
- Escalating supernatural stakes alongside deepening intimacy
- The question of whether love can survive (or transform) the horror
- World-building that grows darker as the romance grows deeper

**What Readers Expect**:
- Genuine scares alongside genuine romance
- The horror and romance enhancing each other, not competing
- A love interest whose supernatural nature is explored honestly
- Consent and agency maintained even in dark scenarios
- HEA or HFN that acknowledges the horror — not a fairy-tale ending

---

## Legal Thriller Series

**Architecture**: Case-based — each volume is a standalone legal case while the
protagonist's career, reputation, and personal life evolve across the series.

**Series-Level Elements**:
- A protagonist (lawyer, judge, investigator) whose courtroom skills sharpen
- Each volume centred on a different case with its own moral complexity
- Legal procedure depicted with authenticity and tension
- Institutional corruption or systemic injustice as a series-level theme
- Personal life complications that grow alongside professional stakes
- A recurring adversary or institutional antagonist across volumes

**What Readers Expect**:
- Courtroom scenes that are dramatic and procedurally credible
- Cases with genuine moral complexity — not clear-cut good vs. evil
- The protagonist's legal strategy feeling clever and earned
- Personal stakes that humanise the protagonist beyond the courtroom
- Justice (or its failure) handled with nuance

---

## LGBTQ+ Fiction Series

**Architecture**: Identity and community — each volume explores different facets
of queer experience, often through interconnected characters.

**Series-Level Elements**:
- A community or found family of queer characters whose lives intertwine
- Each volume may centre a different character's journey
- Identity, coming out, acceptance, and self-discovery as recurring themes
- Intersectionality explored — characters at the intersection of multiple identities
- Joy and celebration alongside struggle — not purely trauma narratives
- Relationship dynamics that challenge heteronormative templates

**What Readers Expect**:
- Authentic, nuanced queer representation
- Joy and love given as much space as struggle
- Characters defined by more than their identity — they are full people
- Community bonds that feel real and sustaining
- Diverse queer experiences — no single "queer story" template

---

## Mystery Series

**Architecture**: Case-per-volume — each volume is a standalone mystery with a
detective or amateur sleuth whose skills and personal life develop across books.

**Series-Level Elements**:
- A detective/sleuth whose methods and reputation evolve
- Each volume features a completely resolvable standalone case
- A recurring setting (precinct, town, agency) that deepens
- Supporting cast (partner, contacts, informants) who recur and develop
- The protagonist's personal life as a series-level thread
- Clue-planting and fair-play conventions honoured in every volume

**What Readers Expect**:
- Fair-play mysteries — clues planted, solution logical
- A detective whose process and personality are the draw
- Standalone satisfaction — each case resolved completely
- The world and characters growing richer with each volume
- Puzzles that challenge without cheating

---

## Occult / Magic Series

**Architecture**: Initiation — each volume takes the protagonist deeper into
hidden magical knowledge, with escalating consequences.

**Series-Level Elements**:
- A magical system whose deeper layers are revealed across volumes
- Secret societies, occult hierarchies, or magical traditions explored
- The cost of magical knowledge escalating — power demands sacrifice
- Forbidden knowledge as a temptation that grows across volumes
- The boundary between the mundane and magical becoming thinner
- Historical or mythological sources of magic explored progressively

**What Readers Expect**:
- Magical systems that feel deep and internally consistent
- The sense of peeling back layers of hidden reality
- Power with genuine costs — no free magic
- Atmosphere of mystery and wonder maintained
- Resolution that honours the complexity of the magical world

---

## Religious Fiction Series

**Architecture**: Faith journey — each volume explores a different aspect of faith,
doubt, community, and spiritual growth.

**Series-Level Elements**:
- A protagonist (or community) whose faith is tested and deepened across volumes
- Each volume centred on a different spiritual challenge or question
- Religious community dynamics that evolve — alliances, schisms, renewal
- The tension between faith and doubt as a productive force
- Historical or scriptural elements woven into contemporary narratives
- Moral questions explored through the lens of faith traditions

**What Readers Expect**:
- Respectful treatment of faith traditions
- Genuine spiritual questions, not propaganda
- Characters whose faith feels real, including their doubts
- Community depicted with warmth and complexity
- Stories that illuminate faith without requiring it of the reader

---

## Romantasy Series

**Architecture**: Romance and fantasy arc intertwined — the romantic relationship
and the fantasy quest advance in lockstep across volumes.

**Series-Level Elements**:
- A central romance whose progression mirrors the fantasy stakes
- A fantasy world whose magic system deepens alongside the relationship
- Power dynamics between the couple shaped by the fantasy elements
- Each volume advancing both the romantic arc and the epic conflict
- Found family or court dynamics that provide secondary relationships
- Fated elements (mates, prophecies, bonds) that complicate choice and agency

**What Readers Expect**:
- Equal investment in romance and fantasy — neither is subplot
- Chemistry that burns hotter with each volume
- Fantasy world-building that is genuinely inventive
- HEA or HFN — the romance must resolve positively
- Power couple dynamics — the leads are stronger together

---

## Romantic Suspense Series

**Architecture**: Case-and-couple — each volume pairs a suspense plot with a romance,
often featuring different couples from the same professional world.

**Series-Level Elements**:
- A professional setting (security firm, FBI unit, military team) linking volumes
- Each volume pairs a different couple with a standalone suspense plot
- The danger forcing intimacy and trust between the couple
- A series-level threat or conspiracy connecting individual cases
- Past couples appearing in professional and personal capacities
- The next couple's chemistry planted 1–2 volumes ahead

**What Readers Expect**:
- Genuine suspense alongside genuine romance
- Both the case and the relationship resolved satisfyingly per volume
- Competent protagonists — both leads should be capable
- HEA in every volume
- The suspense creating organic reasons for intimacy, not contrivance

---

## Romantic Thriller Series

Similar to romantic suspense but with:
- Higher stakes and faster pace — lives at immediate risk
- The thriller plot driving the pacing, romance woven into the tension
- More morally grey scenarios and harder choices
- Action sequences alongside romantic scenes
- The relationship tested by extreme circumstances

---

## Speculative Mystery Series

**Architecture**: Case-per-volume in a speculative setting — each mystery is shaped
by the speculative element (alternate history, near-future tech, soft sci-fi).

**Series-Level Elements**:
- A speculative premise whose implications for crime and detection deepen
- Each volume's mystery shaped by the speculative rules
- A detective/investigator adapting to non-standard investigative tools
- The speculative world's social implications explored through cases
- A series-level conspiracy or systemic issue connected to the speculative element

**What Readers Expect**:
- The speculative element genuinely affecting how mysteries work
- Fair-play principles adapted to the speculative rules
- World-building that rewards series investment
- Cases that couldn't exist without the speculative premise
- The detective's relationship with the speculative element evolving

---

## Sport Romance Series

**Architecture**: Team or league-based — each volume features a different athlete
and their romantic partner from the same sporting world.

**Series-Level Elements**:
- A shared sporting world (team, league, training facility) linking volumes
- Each volume features a different athlete's romance
- Seasonal rhythms (pre-season, championship, off-season) shaping each volume
- Team dynamics and locker-room camaraderie as connective tissue
- Sports psychology, competition pressure, and injury as recurring themes
- The next couple's chemistry seeded through team interactions

**What Readers Expect**:
- Authentic sports detail without overwhelming the romance
- Athletes portrayed as complex people, not just bodies
- HEA in every volume
- Team banter and camaraderie that feels real
- The sport creating organic romantic tension and obstacles

---

## Vampire Series

**Architecture**: Immortal perspective — the series leverages the vampire's
lifespan to span eras, accumulate enemies, and deepen mythology.

**Series-Level Elements**:
- A vampire mythology whose rules and politics deepen across volumes
- Power hierarchies (covens, courts, ancient elders) revealed progressively
- The vampire protagonist's centuries of history surfacing as plot threads
- The tension between the vampire and human worlds escalating
- Morality of immortality explored — what happens when you outlive everyone?
- New supernatural species or factions introduced across volumes

**What Readers Expect**:
- Consistent vampire mythology — the rules don't change without reason
- The weight of immortality felt in characterisation
- Vampire politics and power dynamics taken seriously
- Action and atmosphere balanced with character depth
- The seductive and terrifying aspects of vampirism both honoured

---

## War Fiction Series

**Architecture**: Campaign or conflict arc — each volume covers a different phase,
theatre, or perspective of a war.

**Series-Level Elements**:
- A conflict whose phases structure the series (mobilisation, campaign, aftermath)
- Different perspectives on the same war across volumes (soldier, civilian, leader)
- The psychological toll of combat accumulating across volumes
- Relationships forged under fire that deepen or fracture
- Historical accuracy in military operations and period detail
- The moral complexity of war — no clean heroes, no pure villains

**What Readers Expect**:
- Authentic military detail without glorifying violence
- Characters who feel like real people, not archetypes
- The psychological impact of combat portrayed honestly
- Brotherhood and camaraderie that feel earned
- An honest reckoning with war's costs

---

## Western Romance Series

**Architecture**: Frontier community — each volume features a different couple in
the same frontier town or ranch, set against the backdrop of the settling West.

**Series-Level Elements**:
- A frontier community growing across volumes (new settlers, new businesses)
- Each volume features a different couple finding love in challenging conditions
- Period-accurate frontier life (ranching, homesteading, mining, cattle drives)
- The community's collective story as a series thread
- Past couples appearing as established members of the community
- The landscape as a character — weather, distance, and wildness as forces

**What Readers Expect**:
- Authentic frontier detail and atmosphere
- HEA in every volume
- Strong, capable protagonists (both leads)
- The frontier creating organic obstacles and intimacy
- A community readers want to return to

---

## Women's Fiction Series

**Architecture**: Life-stage or friendship — each volume explores a different life
challenge or a different member of a friend group.

**Series-Level Elements**:
- A group of women whose lives intertwine across volumes
- Each volume centred on a different protagonist's crisis or transformation
- Themes of identity, motherhood, career, friendship, ageing, reinvention
- The support network evolving — how women show up for each other
- Generational dynamics (mothers, daughters, mentors) as recurring threads
- Each volume self-contained while the collective story deepens

**What Readers Expect**:
- Emotionally authentic female experiences
- Characters who feel like women the reader might know
- Friendship depicted with complexity — not idealised
- Life stages treated with respect and nuance
- Empowerment through connection, not isolation

---

## Zombie Series

**Architecture**: Survival phases — each volume covers a different stage of the
outbreak and the survivors' adaptation.

**Common Arc Pattern**:
- Volume 1: Outbreak — the world falls, a group forms
- Volume 2: Survival — establishing safety, learning the new rules
- Volume 3: Community — building something new, human threats emerge
- Volume 4: Conflict — human factions clash, the real enemy is us
- Volume 5: Resolution — a new equilibrium (not necessarily the old world restored)

**Series-Level Elements**:
- A survivor group whose composition changes (losses, newcomers) across volumes
- The zombie threat evolving — new types, new behaviours, new dangers
- Human antagonists becoming as dangerous as the undead
- The psychological toll of survival as a series-level arc
- Questions of what civilisation means when the old one is gone
- Resources, territory, and power as escalating conflicts

**What Readers Expect**:
- Genuine tension — characters can and should die
- The zombie rules consistent (unless evolution is part of the premise)
- Human drama more compelling than zombie action
- Survival resourcefulness that feels plausible
- An ending that acknowledges the new reality rather than magically restoring the old

---

## Upmarket Fiction Series

Similar to literary fiction with broader commercial appeal:
- More accessible prose and plotting than pure literary fiction
- Book-club-friendly themes and discussion points
- Each volume standing alone while rewarding series readers
- Character depth combined with narrative momentum
- Contemporary issues explored with nuance and craft

---

## Universal Series Architecture Principles (All Genres)

1. **Each volume must stand on its own** while contributing to the larger arc.
   Readers should feel satisfied after each volume, not shortchanged.

2. **The momentum ladder is essential.** Volume 3 should feel bigger, deeper, or
   more intense than Volume 1. This doesn't always mean "more action" — it can mean
   deeper emotional stakes, more complex relationships, or harder choices.

3. **Plant seeds early.** The best series moments are ones that were seeded 2–3
   volumes earlier. A throwaway detail in Volume 1 becoming crucial in Volume 4 is
   peak series craft.

4. **Don't hoard all payoffs for the finale.** Every volume should have satisfying
   resolutions AND new questions. The series-level payoff is the final resolution,
   but readers need victories along the way.

5. **Characters must evolve.** A character who's the same person in Volume 5 as
   in Volume 1 is a failed series character. Growth can be subtle, but it must be
   genuine.

6. **Build in growth seeds.** The best series can extend organically. Include
   supporting characters, unresolved minor threads, and world-building elements
   that could support additional volumes if the series takes off.

7. **Consistency of tone and voice.** Readers return to a series for the FEELING
   it gives them. Don't dramatically shift tone between volumes unless it's a
   deliberate narrative choice acknowledged in the architecture.
