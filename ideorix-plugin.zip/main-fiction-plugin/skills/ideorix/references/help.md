---
name: help
description: "Quick reference for all Ideorix commands, features, and workflow phases"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Help — Ideorix

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

## Quick Commands

| Command | What It Does |
|---------|-------------|
| "Write a book" | Start a new fiction or short-story project from scratch |
| "Write a screenplay" | Start a new screenplay (feature / TV / short) |
| "Continue writing" | Resume an in-progress manuscript |
| "Writers Studio" | Open the Writers Studio menu (editorial + publishing tools) |
| "Screen Studio" | Open the Screen Studio menu (screenplay-format tools) |
| "Full Creative Suite" | Open the full Front Gate with all three paths |
| "Edit my manuscript" | Run the editorial pipeline on your writing |
| "Export & Publish" | Format as DOCX, EPUB, PDF, Fountain, or prepare for KDP |
| "Marketing" | Generate blurbs, descriptions, social media packs |
| "Market Scout" | Live market intelligence for any genre |
| "Manuscript Clinic" | Scored analysis with expert consultation |
| "Analyze a Book" | Reverse-engineer any novel into a structural blueprint |
| "Voice Builder" | Build a reusable author voice profile |
| "Heritage Text" | Modernize public domain texts |
| "Pen Name" | Create and manage pen names |
| "Menu" | Return to the Front Gate |
| "Help" | Show this reference |

## Front Gate

The engine opens with three paths:

| Path | What's inside |
|------|--------------|
| **A. Writers Studio** | Editorial, publishing, and marketing for novels and short stories. Bring your manuscript or write one from scratch. |
| **B. Screen Studio** | Industry-format engine for screenplays — features, TV, and short film. Bidirectional novel ↔ screenplay adaptation. |
| **C. Full Creative Suite** | Complete creative solution — write, edit, publish, and market novels end to end. |

Type **A**, **B**, **C**, or any trigger phrase. Type **"Menu"** or **"Back"** at any point to return here.

## Writers Studio Menu

| # | Item | Purpose |
|---|------|---------|
| 1 | Start New Project | Set up your project workspace — do this first |
| 2 | Import Project | Bring your work from Novelcrafter, Scrivener, Plottr |
| 3 | Edit & Revise | Run the full editorial pipeline on your manuscript |
| 4 | Export & Publish | Format as DOCX, EPUB, PDF, Fountain, or prepare for KDP |
| 5 | Marketing & Cover | Cover concepts, blurbs, social media, trailers |
| 6 | Manuscript Clinic | Scored analysis across 6 axes with expert consultation |
| 7 | Market Scout | Live market intelligence for any genre |
| 8 | Reader Magnet Studio | Subscriber magnets, opt-in funnels, welcome sequences |
| 9 | Voice Builder | Build a reusable author voice profile |
| 10 | Analyze a Book | Reverse-engineer any novel into a structural blueprint |
| 11 | Heritage Text | Modernize public domain texts |
| 12 | Pen Name | Create and manage pen names |

## Screen Studio Menu

Industry-format screenplay engine — features, TV scripts, short film, plus bidirectional novel ↔ screenplay adaptation. Menu items cover writing from scratch, adapting an existing novel, script coverage, format conversion (Fountain ↔ FDX), and screenplay-specific editorial passes. Activate by typing **B** or any screenwriting trigger phrase.

## Full Creative Suite Menu

The complete novel-writing flow end to end. Same satellite tools as Writers Studio plus the new-project research-and-write integrated pipeline. Activate by typing **C** or "Full Creative Suite".

## Workflow Phases (Full Creative Suite)

A new-novel project moves through these phases. The engine handles the sequencing — you respond to each step's prompts.

1. **Research & Setup** — Genre selection, premise, audience targeting, market positioning
2. **Story Bible** — Characters, world, themes, structural plan, chapter outline
3. **Per-Chapter Writing Loop** — Brief → User Review → Writer → Humaniser → Verification → Summary
4. **5-Agent Verification Suite (per chapter)** — Story Guardian, Character Tracker, Continuity Auditor, Voice Tracker, Forbidden-Word Sentinel
5. **Editorial Pipeline (post-draft)** — Stage 0 Voice Profile pre-edit pass + numbered stages (Proofreader, Copy Editor, Developmental Editor, Alpha Reader, Beta Reader, Conflict Resolution, Surgical Fixes, Revision Loop, Publication Readiness)
6. **Delivery** — Formatted manuscript, KDP metadata, cover concepts, full editorial report

## License & Watermarking

Every manuscript Ideorix produces is licensed under James Harvey Media's terms (see `LICENSE.txt` at the project root). The engine watermarks every chapter file with a per-session licence header that asserts the manuscript was generated through Ideorix. The watermark is not user-visible in the final output formats (DOCX, EPUB, PDF).

## See Also

- `SKILL.md` — the orchestrator (loads at session start)
- `core-pipeline.md` — the canonical writing protocol
- `craft-standards.md` — the 7 Craft Commandments and prose quality bar
- `_index.md` — index of all reference files

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---------|--------------|-----|
| Engine doesn't recognise my command | Trigger phrase not registered | Type "Menu" to return to Front Gate, then pick a path |
| Chapter prose contains AI-isms | Humaniser was skipped | Ask Claude to "run the humaniser on chapter N" |
| New session lost continuity | Prior-chapter context not loaded | Engine should auto-load (v2.7.43+). If it doesn't, ask "re-read chapters 1 through N-1" |
| Lost an approved chapter to a tool overwrite | Pre-tool snapshot exists at `engine-data/snapshots/` (v2.7.41+) | `cp engine-data/snapshots/ch01.pre-{tool}.{timestamp}.md engine-data/chapters/ch01.md` |
| Pipeline-checkpoint file is corrupted | bash cat-and-mv race on long-lived state file | See File Operation Policy (v2.7.42+) — use Edit/Write tool only for long-lived state files |
