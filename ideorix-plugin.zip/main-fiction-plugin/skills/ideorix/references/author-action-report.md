---
name: author-action-report
description: "Final author-facing consolidation layer for fiction. After the fix cycle completes (revision loop and/or synthesis-driven fixes) — and as the author-facing closing step of the Handoff Protocol — this produces ONE report with two halves: what the engine fixed automatically (no action needed), and what still requires the author (CREATIVE-OPEN craft decisions, productive-conflict resolutions, deferred items, inline placeholders) — each remaining item with exact location, why it cannot be auto-done, a specific recommended action, and its source finding. A pure AGGREGATION layer: it collects from defined upstream sources (revision-loop Final Report, beta-synthesis §5, the pending-marker scan, the handoff checklist + gate output) and never re-analyses or re-derives. Its one safety obligation is coverage: every author-action item from every defined source must appear, and any absent source is named explicitly rather than silently skipped. Trigger: the Handoff Protocol's closing step, OR auto at the end of any standalone fix cycle, OR user-invocable ('what's left', 'author action report', 'what do I still need to fix')."
version: "2.7.109"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript Engine
> *© James Harvey Media. All rights reserved.*

# Author Action Report — The "What's Left For You" Consolidation

## Purpose

The engine now produces excellent diagnosis (the five-lens Beta
Reader Panel + the Beta Synthesis Capstone) and applies a
graduated set of fixes automatically (the revision loop's surgical
tier + the gated Tier-2 developmental executor). But the items
that genuinely require the author — the decisions the engine
correctly refuses to make alone — end up **scattered across
several artifacts**:

- The Synthesis Capstone's §5c CREATIVE-OPEN decisions (ending,
  arc, POV, subplot, thematic emphasis) and §1 Productive
  Conflicts (where two reader lenses disagree in a craft-
  meaningful way the author must resolve)
- The Synthesis Capstone's §5b DEVELOPMENTAL-BOUNDED items that
  were deferred or rejected at the confirm gate
- The revision loop's Final Report "Human Decision Required" and
  deferred-to-human lists (only produced if the loop ran)
- Inline `[TK]` / placeholder markers in the manuscript, surfaced
  only by running `pending-marker-scan.sh`

The Synthiate panel run demonstrated the shape: the engine
correctly surfaced the Owen-scene developmental item, the Sean-
interiority productive conflict, and the Ch 30 ordering decision —
but across the synthesis report and the chat narration. There was
no single "we did X/Y/Z; you still need to decide A/B/C, here is
exactly where and how."

This spec closes that gap with ONE final report. It is the last
artifact the pipeline produces and the document the author
actually acts from.

## Relationship to the Handoff Protocol (adjacent, not duplicate)

The Handoff Protocol (`core-pipeline.md` § Handoff Protocol +
`handoff-gate.sh`) already owns the moment a manuscript is
declared done. It is a **quality-completeness gate**: its job is
to guarantee the engine actually did its work — that the full
editorial pipeline ran every stage (not collapsed to mechanical
cleanup), that no chapter slips past formatting rules, that the
gate verdict is real and not narrated. It produces
`handoff-checklist.md` (stage-by-stage verdicts) and
`handoff-gate-output.md` (the gate's source-of-truth PASS/FAIL).
It answers: **"did the engine do its job?"** It is engine-facing
enforcement, not an author to-do list.

The Author Action Report answers the **other half** of that same
moment: **"what is left for the human, and exactly where?"** The
handoff checklist says "Stage 6: PASS" — it does not extract and
consolidate the specific author-action items (the CREATIVE-OPEN
decisions, the productive conflicts, the placeholders to resolve)
into one actionable punch-list. That is the gap.

So the two are bound, not separate: **the Author Action Report is
the author-facing output of the Handoff Protocol's final step.**
A completed handoff produces BOTH faces of "done" — the internal
gate verdict (`handoff-gate-output.md`) AND the human punch-list
(this report) — as one coherent finish. The report additionally
pulls the handoff checklist + gate output into its own source set
(S7, S8 below), so "did every stage run / did the gate pass"
becomes something the author sees in their action report rather
than a separate artifact they would never open.

It still runs **standalone** (loop-end auto-trigger and
user-invocable — see Trigger) for projects that do not run the
full Handoff Protocol but still want the consolidated punch-list.

## What this is NOT (scope discipline)

This is a **pure aggregation / presentation layer**. It:

- does **not** re-analyse the manuscript, re-run the panel, or
  re-derive findings — it collects what upstream sources already
  produced;
- does **not** make craft decisions or rewrite prose (the author
  decides CREATIVE-OPEN items; this report only *frames* them);
- does **not** apply any fix (the revision loop applies; this
  report only *lists* what was applied and what remains);
- does **not** make or recommend a final publish/hold decision
  beyond surfacing the outstanding items — the author decides.

Re-deriving anything here would create a NEW silent-failure
surface (a second, divergent analysis that could contradict the
synthesis). The report's correctness obligation is **coverage**,
not insight: every author-action item from every defined source
must appear, verbatim-traceable to its origin.

## Trigger

Three paths:

1. **As the final step of the Handoff Protocol (primary).** When
   the Handoff Protocol runs (`core-pipeline.md`), its closing
   step produces the Author Action Report after the gate verdict
   is written. This is the integrated path: a completed handoff
   delivers both the gate verdict and the author punch-list.

2. **Auto-generated at the end of any fix cycle.** Whenever the
   revision loop exits (any exit condition) OR a synthesis-driven
   manual fix pass completes outside a full handoff, the engine
   produces the Author Action Report as the closing artifact and
   presents it inline. This is the standalone path for projects
   that do not run the full Handoff Protocol.

3. **User-invocable any time** via trigger phrase: "what's left",
   "author action report", "what do I still need to fix", "show
   me the remaining items". Re-runs the aggregation against the
   current state of the defined sources (so re-running after the
   author resolves an item shows a shorter list).

## Source set (the coverage contract)

The report aggregates from exactly these sources. This list is
the coverage contract: the report MUST read each, and MUST state
for each whether it was present or absent (an absent source is
named, never silently skipped — see Silent-Failure Audit).

| # | Source | What it contributes | Goes to which half |
|---|--------|---------------------|--------------------|
| S1 | `engine-data/reports/beta-synthesis.md` §5a SURGICAL (applied) | fixes already applied | Done |
| S2 | `engine-data/reports/beta-synthesis.md` §5b DEVELOPMENTAL-BOUNDED | applied (confirmed) → Done; deferred/rejected → Action | both |
| S3 | `engine-data/reports/beta-synthesis.md` §5c CREATIVE-OPEN | author craft decisions (ending/arc/POV/subplot/theme) | Action |
| S4 | `engine-data/reports/beta-synthesis.md` §1 Productive Conflicts | lens-vs-lens disagreements the author resolves | Action |
| S5 | revision-loop Final Report (`engine-data/revision-loop-log.md` + the summary) | Fixes Applied → Done; "Human Decision Required" + deferred → Action | both |
| S6 | `scripts/pending-marker-scan.sh` over `engine-data/chapters/` | inline `[TK]` / unresolved placeholders | Action |
| S7 | `engine-data/reports/handoff-checklist.md` (when handoff ran) | any stage with a WARN/FAIL/SKIPPED verdict the author should know about | Action |
| S8 | `engine-data/reports/handoff-gate-output.md` (when handoff ran) | the gate VERDICT (PASS/FAIL); a FAIL is the highest-priority Action item | Action |

If a project never ran the synthesis (S1-S4 absent), never ran
the loop (S5 absent), or never ran the Handoff Protocol (S7-S8
absent), the report runs on whatever sources exist and names the
absent ones. S6 (the marker scan) is always run when its inputs
exist. When this report is itself produced AS the handoff's final
step (Trigger path 1), S7-S8 are always PRESENT.

## Output schema

Written to `engine-data/reports/author-action-report.md` and
presented inline. If a `.docx` is requested, generate on demand
following the same delivery convention as the panel reports.

```markdown
# Author Action Report — {Title}

> Final consolidation for {Title} by {Author}
> Generated: {date} | Sources read: {list, each PRESENT or ABSENT}
> Net: {N} fixes applied automatically · {M} items need you

## ✅ Done automatically — no action needed

{One line per applied fix, grouped by tier:}

**Surgical ({count}):**
- ch{N}: {what changed, one line} [source: {persona/finding}]

**Developmental ({count}, each confirmed by you before applying):**
- ch{N}: {what was inserted/relocated} [source: {finding}]

## ⚠️ Your action required ({M} items)

{One block per item — ordered by the synthesis §3 priority where
available, else by severity. Each block:}

### {N}. {One-sentence statement of the item}
- **Where:** {chapter + line / scene, or file}
- **What to do:** {SPECIFIC recommended action — not "review
  this". e.g. "Decide whether Sean gets pre-Ch-26 interiority or
  whether institutional-horror register stands; the synthesis
  leans toward leaving it (§1)" / "Resolve the [TK] placeholder
  in ch12:204"}
- **Why you (not the engine):** {craft-decision / productive-
  conflict / placeholder-to-resolve / deferred-developmental}
- **Source:** {which finding — synthesis §5x / §1, loop deferred,
  marker scan}

## Source coverage

{Mandatory. Each of S1-S8 listed PRESENT (with item count pulled)
or ABSENT (with reason — "no synthesis run for this project",
"loop not run", "handoff not run", etc.). This is the proof that
nothing was silently skipped.}
```

## Procedure

1. **Trigger received** (handoff final step, auto at fix-cycle
   end, or user-invoked).
2. **Read each source S1-S8 with Read-Verification.** For each:
   record PRESENT (+ extract its items) or ABSENT (+ reason). Run
   `pending-marker-scan.sh` (S6) when its inputs exist; read the
   handoff checklist (S7) and gate output (S8) when the Handoff
   Protocol ran. Reading is mechanical extraction — NOT
   re-interpretation.
3. **Partition every extracted item** into Done (applied) or
   Action (remaining) per the source-set table.
4. **For each Action item, ensure the four fields** (Where / What
   to do / Why you / Source) are populated from the source. If a
   source provided an item but not its exact location, that is
   itself an Action note ("location not specified by {source} —
   locate before fixing"), never a dropped item.
5. **Order Action items** by synthesis §3 priority when present,
   else by severity.
6. **Write the report** via File-Write Hygiene (Edit/Write, never
   bash cat-and-mv); present inline.
7. **Self-check (MANDATORY):** the Source coverage section must
   account for all eight sources, and the Action-item count in the
   header must equal the number of Action blocks. A mismatch is a
   coverage failure — halt and recount, do not ship a report whose
   own numbers disagree. If S8 (gate output) reports VERDICT: FAIL,
   the report MUST surface it as the top Action item — a failed
   handoff gate outranks every content finding.

## Cross-references

- `beta-synthesis-capstone.md` §5 / §1 — the primary source of
  both applied fixes and remaining author items (S1-S4)
- `revision-loop.md` — its Final Report's "Human Decision
  Required" + deferred lists feed S5; the loop auto-invokes this
  report on exit
- `editorial-suite.md` — references this report as the closing
  delivery artifact of the editorial pipeline
- `core-pipeline.md` § Handoff Protocol — the protocol whose final
  step produces this report (Trigger path 1); sources S7
  (`handoff-checklist.md`) and S8 (`handoff-gate-output.md`)
- `scripts/handoff-gate.sh` — produces S8, the gate verdict this
  report surfaces as a top Action item when it reads FAIL
- `scripts/pending-marker-scan.sh` — S6, the inline-placeholder
  scan

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification binding
are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (sources S1-S5, S7-S8) | "Source read, items extracted" | A source is empty/malformed/absent and silently skipped → its author-action items never appear, so the report says "nothing left" while real items exist | Read-Verification per source; the MANDATORY Source-coverage section lists every S1-S8 as PRESENT or ABSENT with reason — an unaccounted source is a coverage failure (step 7). The report can omit an item ONLY by naming the source as ABSENT, never by silently not reading it. |
| Bash (pending-marker-scan, S6) | "Scan clean / N markers" | Exit-code or path-typo misread as "0 markers" → inline `[TK]` items ship unlisted | `bash-output-verification.md`: the scan's exit code is checked (0 clean / 1 markers / 2 error); a `2` (invocation error) is surfaced as "marker scan FAILED — inline items unverified", never treated as clean |
| Aggregation completeness | "All remaining items listed" | An item is double-counted, dropped, or mis-partitioned (an Action item filed as Done) → author under-acts | Step 7 self-check: header Action count == number of Action blocks; every Action item carries a Source field tracing to S1-S8; a Done item must cite an applied-fix record (loop log or §5 applied), not an assertion |
| Re-derivation guard | "Report reflects the findings" | The report RE-ANALYSES and invents a finding not in any source, or contradicts the synthesis | This report is aggregation-only (§ "What this is NOT"): every item MUST trace to a named source. An item with no source is forbidden — if it isn't in S1-S8 it does not belong in this report (it belongs in a fresh panel/synthesis run). |
| Write (the report) | "Write succeeded" | Subdir flush / partial write | File-Write Hygiene (`core-pipeline.md`); PostToolUse Engine-Data Integrity Hook re-verifies on disk |
