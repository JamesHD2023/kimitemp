---
name: screenplay-importer
description: "Fountain screenplay parser + scene-to-chapter chunker — protocol file used by the Screenplay → Novel adaptation flow"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Screenplay Importer Protocol

This is the technical protocol file for `screenplay-to-novel.md`. It
specifies how to parse a screenplay (Fountain, FDX, DOCX, or
text-layer PDF), extract story data, chunk scenes into chapters, and
hand off to the expansion-aware pipeline.

**Supported inputs:** Fountain (`.fountain`), Final Draft XML (`.fdx`),
Microsoft Word (`.docx`), and text-layer PDF (`.pdf`).
**Supported outputs:** All 5 length tiers (Short Story, Novelette,
Novella, Standard Novel, Epic Novel) and all POV modes (Single, Dual,
Multi).

## Pre-flight

Before the importer runs:

1. **Detect format.** Read the file extension:
   - `.fountain` → Fountain parser
   - `.fdx` → FDX parser
   - `.docx` → DOCX parser
   - `.pdf` → PDF parser (with text-layer probe first)
   - `.txt` → try Fountain parser (some users save Fountain as `.txt`)
   - anything else → STOP and tell the user which formats are supported

2. **Confirm the file opens and is readable.** If a permission error,
   encoding issue, or binary content is detected, STOP and alert the
   user with the specific problem.

3. **Check file size.** Reasonable ranges:
   - Fountain: 10 KB–80 KB (feature; pilots ~15 KB; epics ~80 KB)
   - FDX: 50 KB–500 KB (larger because of XML overhead)
   - DOCX: 30 KB–300 KB
   - PDF: 50 KB–5 MB (bigger because of embedded fonts/metadata)
   If the file is substantially outside these ranges, flag it for the
   user — it may be misformatted or contain non-screenplay content.

4. **Confirm no existing project exists at the target save location.**
   If one does, ask whether to create a new project next to it or
   resume the existing one.

5. **Route to the parser.** Each format has its own parser section
   below. All parsers produce the same output shape: an ordered scene
   list, a character roster, and a location bank. Downstream logic
   (character normalisation, chunking, Story Bible seeding) is
   format-agnostic.

## Format routing

**Read-Verification HARD GATE applies (see `read-verification.md`)
to every parser.** Before any parser runs, verify the Read returned
content above the per-format threshold (Fountain ≥ 50 chars,
FDX ≥ 50, DOCX ≥ 100, PDF: ≥200 chars per page → proceed, 50–199 →
proceed with warning, <50 → reject; the PDF probe tiering at
"PDF parser § Empty-page probe" is the truth source for the PDF
thresholds). Read failures are most common
on scanned-image PDFs (parser cannot extract from raster pages),
locked DOCX exports, and oversized FDX files. If the Read returned
empty or near-empty content, the importer BLOCKS and surfaces the
failure with resolution options (paste content into chat / re-upload
a text-layer-rebuilt PDF / skip and provide an alternative format).
Treating an empty Read as "screenplay absorbed" would silently
produce a zero-scene project. Per-page PDF Reads (Step 567 below)
each apply the gate independently — if the title page extracts but
later pages return empty, the partial result is still a FAILED_READ.

The importer routes to one of four parsers based on file extension.
All parsers produce the same in-memory structure (scene list, character
roster, location bank), so downstream logic runs format-agnostically.

| Extension | Parser | Complexity |
|-----------|--------|------------|
| `.fountain`, `.txt` | Fountain parser (see below) | Trivial — plain text |
| `.fdx` | FDX parser (see below) | Easy — XML with tagged elements |
| `.docx` | DOCX parser (see below) | Medium — paragraph styles + indent fallback |
| `.pdf` | PDF parser (see below) | Medium — text-layer extraction + column classification + rejection of scanned PDFs |

---

## Fountain parser

### Fountain syntax reference

Fountain is a plain-text screenplay format. See `format-fountain.md`
for the complete writing spec — the importer uses the same rules in
reverse.

Key parser-relevant elements:

| Element | Fountain syntax | Example |
|---------|-----------------|---------|
| Title page | Key-value pairs at file start | `Title: My Screenplay\nAuthor: Jane Smith\nDraft: 2024-03-15` |
| Scene heading (slugline) | Line starts with `INT.`, `EXT.`, `INT./EXT.`, `I/E`, or is force-marked with `.` | `INT. KITCHEN - DAY` |
| Action | Any line that isn't a slugline, character cue, dialogue, parenthetical, or transition | `Ben crosses to the sink. He stares at the dishes.` |
| Character cue | Line in ALL CAPS followed by dialogue; may have `(O.S.)`, `(V.O.)`, `(CONT'D)`, `(cont'd)` suffix | `BEN (CONT'D)` |
| Dialogue | Line(s) immediately after a character cue | `I already told you.` |
| Parenthetical | Wrapped in `(...)`, appears between cue and dialogue | `(softly)` |
| Transition | Line ending with `TO:` or force-marked with `>` | `CUT TO:`, `> FADE OUT.` |
| Section | Line starting with `#` | `# Act One` |
| Synopsis | Line starting with `=` | `= Ben discovers the letter.` |
| Notes | Wrapped in `[[ ... ]]` | `[[add beat here]]` |
| Boneyard | Wrapped in `/* ... */` | `/* cut scene */` |
| Centred text | Wrapped in `> ... <` | `> THE END <` |
| Emphasis | `*italic*`, `**bold**`, `***bold italic***`, `_underline_` | `She _sobs_.` |

**Parser hardening:**
- Handle Windows (CRLF), Unix (LF), and Mac (CR) line endings.
- UTF-8 default, latin-1 fallback.
- Tolerate BOM at file start.
- Tolerate empty lines between elements (required by spec).
- Reject files that are mostly non-Fountain content (e.g., PDF text
  dump without sluglines).

### Fountain parsing procedure

Work through the file sequentially. Maintain these accumulators:

- `title_page = {}` — key-value metadata from the title page
- `scenes = []` — ordered list of scene objects
- `characters = {}` — dict keyed by normalised character ID
- `locations = {}` — dict keyed by normalised location ID
- `current_scene = None` — scene being built
- `current_speaker = None` — character whose dialogue is being accumulated

### Step 1 — Title page

If the first content-bearing lines are key-value pairs (`Key: Value`),
read them into `title_page` until the first blank line or first
non-key-value line.

Expected keys: `Title`, `Author`, `Credit`, `Source`, `Draft date`,
`Contact`, `Copyright`, `Notes`. Unknown keys are preserved but unused.

If no title page, set `title_page['Title']` from the filename
(without extension, underscores replaced with spaces, title-cased).

### Step 2 — Walk scenes

For each line, classify it:

**Is this a slugline?**
A line is a slugline if (a) it starts with `INT.`, `EXT.`, `INT./EXT.`,
`I/E`, or (b) it starts with `.` (forced scene heading). When a
slugline is detected:

1. If `current_scene` is not None, push it to `scenes`.
2. Create a new scene object:
   ```
   {
     'index': N (1-based),
     'slugline': '<original text>',
     'int_ext': 'INT' | 'EXT' | 'INT/EXT',
     'location': '<parsed location>',
     'time_of_day': '<parsed>',  # e.g., 'DAY', 'NIGHT', 'MOMENTS LATER', 'CONTINUOUS'
     'action': [],      # list of action line strings
     'dialogue': [],    # list of {speaker, parenthetical, text}
     'characters_present': set(),
     'transition_out': None,
     'section': '<current section if any>',
     'synopsis': '<current synopsis if any>',
   }
   ```
3. Parse the slugline into `int_ext`, `location`, `time_of_day`:
   - Split on ` - ` (space-dash-space) or `-` for location / time.
   - Accept common time-of-day tokens: DAY, NIGHT, MORNING, AFTERNOON,
     EVENING, DAWN, DUSK, MOMENTS LATER, CONTINUOUS, LATER, SAME TIME.
   - If no time token, `time_of_day = None`.

4. Upsert the location into `locations`:
   ```
   location_id = normalise(location_string)
   if location_id not in locations:
     locations[location_id] = {
       'id': location_id,
       'canonical': location_string,
       'first_scene': N,
       'int_ext': int_ext,
       'seed_description': '',  # accumulates from action lines
       'scenes': [N],
     }
   else:
     locations[location_id]['scenes'].append(N)
   ```

**Is this a character cue?**
A line is a character cue if it is ALL CAPS (or mostly, with optional
`(O.S.)`, `(V.O.)`, `(CONT'D)`, `(cont'd)` suffixes), is followed by
dialogue on the next content line, and isn't a transition.

Normalisation: strip `(O.S.)`, `(V.O.)`, `(CONT'D)`, `(cont'd)`,
`(off)`, `(on radio)`, `(phone)` parentheticals from the name before
ID-ing the character. "BEN", "BEN (O.S.)", "BEN (CONT'D)" all map to
character ID `ben`.

When detected:
1. Set `current_speaker = normalised_character_id`
2. Upsert the character into `characters`:
   ```
   if character_id not in characters:
     characters[character_id] = {
       'id': character_id,
       'canonical_name': '<cue as written>',
       'aliases': set(),
       'dialogue_count': 0,
       'word_count': 0,
       'first_scene': N,
       'scenes': [],
     }
   ```
3. Add character to `current_scene.characters_present`.

**Is this dialogue?**
If the last non-blank line was a character cue or parenthetical, and
the current line is not another cue or a blank, it's dialogue. Append
to `current_scene.dialogue` as:
```
{
  'speaker': current_speaker,
  'parenthetical': <last parenthetical or None>,
  'text': <dialogue text, joined across consecutive lines>,
}
```
Increment `characters[current_speaker].dialogue_count` and
`word_count`. Add the scene index to
`characters[current_speaker].scenes` if not already present.

**Is this a parenthetical?**
A line wrapped in `(...)` between a cue and dialogue. Attach to the
next dialogue element.

**Is this a transition?**
A line ending in `TO:` (and in ALL CAPS), or prefixed with `>`. Attach
to `current_scene.transition_out`. Don't start a new scene — the next
slugline does that.

**Is this a section marker?**
A line starting with `#`. Update `current_section` to the text after
`#`. Any subsequent scenes inherit this section until a new `#`.

**Is this a synopsis line?**
A line starting with `=`. Attach to `current_scene.synopsis`.

**Everything else is action.**
Append to `current_scene.action` and to
`locations[location_id].seed_description` (joined with spaces, capped
at 500 chars per location to avoid bloat).

### Step 3 — Close out

After the final line, push `current_scene` to `scenes` if it's
populated.

---

## FDX parser (Final Draft XML)

### FDX format reference

FDX is Final Draft's native file format — a ZIP archive (in newer
versions) or plain XML (older versions) containing a single XML
document. The structure is semantic: every paragraph is tagged with
its element type.

Root structure:
```
<FinalDraft DocumentType="Script" Template="No" Version="1">
  <Content>
    <Paragraph Type="Scene Heading">
      <Text>INT. KITCHEN - DAY</Text>
    </Paragraph>
    <Paragraph Type="Action">
      <Text>Ben crosses to the sink.</Text>
    </Paragraph>
    <Paragraph Type="Character">
      <Text>BEN</Text>
    </Paragraph>
    <Paragraph Type="Parenthetical">
      <Text>(softly)</Text>
    </Paragraph>
    <Paragraph Type="Dialogue">
      <Text>I already told you.</Text>
    </Paragraph>
    <Paragraph Type="Transition">
      <Text>CUT TO:</Text>
    </Paragraph>
  </Content>
  <TitlePage>
    <Content>
      <Paragraph><Text>MY SCREENPLAY</Text></Paragraph>
      <Paragraph><Text>by</Text></Paragraph>
      <Paragraph><Text>Jane Smith</Text></Paragraph>
    </Content>
  </TitlePage>
</FinalDraft>
```

Paragraph `Type` attribute values:
- `Scene Heading` → slugline
- `Action` → action line
- `Character` → character cue
- `Dialogue` → dialogue
- `Parenthetical` → parenthetical (always between Character and Dialogue)
- `Transition` → transition (`CUT TO:`, `FADE OUT.`)
- `Shot` → camera direction (rare; treat as action for our purposes)
- `General` → freeform text (treat as action)

### FDX parsing procedure

1. **Handle ZIP vs plain XML.** Newer Final Draft files (FDX 4+) are
   ZIP archives containing a single XML file. Older files are plain
   XML. Detect by reading the first 4 bytes: if `PK\x03\x04` (ZIP
   signature), unzip in memory first and read the contained
   `.xml` file. Otherwise read the file directly as XML.

2. **Parse the XML.** Use a standard XML parser. Locate `<Content>`
   inside `<FinalDraft>`. This contains the script body. If present,
   also locate `<TitlePage>` → `<Content>` for title metadata.

3. **Walk `<Paragraph>` elements in order.** For each paragraph:
   - Read the `Type` attribute
   - Concatenate all `<Text>` child element content (a paragraph
     can have multiple text runs with formatting — just join their
     text)
   - Classify based on `Type`:
     - `Scene Heading` → start a new scene (push previous if any,
       parse the slugline into int_ext/location/time_of_day same as
       Fountain parser)
     - `Action` or `Shot` or `General` → append to
       `current_scene.action`
     - `Character` → set `current_speaker` (strip parenthetical
       suffixes like `(O.S.)` same as Fountain parser), upsert
       character into `characters`, add to
       `current_scene.characters_present`
     - `Parenthetical` → store as pending parenthetical for the
       next Dialogue
     - `Dialogue` → append
       `{speaker: current_speaker, parenthetical: <pending>,
        text: <joined>}` to `current_scene.dialogue`, increment
       character dialogue count + word count
     - `Transition` → attach to `current_scene.transition_out`

4. **Title page extraction.** Walk `<TitlePage>` → `<Content>` →
   `<Paragraph>` children. Collect all text into a simple string.
   Apply heuristics:
   - Look for a line matching `by <Name>` → that's the author
   - The first non-empty line before "by" is typically the title
   - Lines with a date pattern are the draft date
   If heuristics fail, set `title_page['Title']` from the filename.

5. **Handle common FDX quirks:**
   - **Dual dialogue** (two characters speaking simultaneously,
     rendered as two columns in Final Draft): represented as
     `<Paragraph DualDialogue="1">` wrapping pairs. Parse both
     columns as sequential dialogue entries in the order they
     appear (left then right). Note in the dialogue entry's
     `dual_with` field so the Writer can render them as
     overlapping exchanges in prose.
   - **Revision colours** (`RevisionID`, `Color` attributes): ignored.
   - **Scene numbers** (`Number` attribute on Scene Heading): stored
     as `current_scene.original_number` but the importer uses its
     own sequential `index`.
   - **Notes and script notes** (`<ScriptNote>`): ignored.
   - **Boneyard markers** (`<Boneyard>`): ignored (deleted content).

6. **Close out.** Push the final scene. Return the same structure as
   the Fountain parser.

### FDX error recovery

- **File is ZIP but contains no XML** → STOP, alert user that the
  file is corrupted or not a real FDX
- **XML parse fails** → STOP, show the parse error line number and
  suggest re-saving from Final Draft
- **No `<Paragraph Type="Scene Heading">` elements found** → the
  file is not a screenplay. STOP and alert.
- **No `<Paragraph Type="Character">` elements found** → the screenplay
  has no dialogue. Unusual. Ask the user to confirm this is the
  correct file.

---

## DOCX parser

### DOCX format reference

DOCX is a ZIP archive containing multiple XML files. The main content
is `word/document.xml`. Paragraph styles are defined in
`word/styles.xml` and referenced by paragraphs via `<w:pStyle>`.

Typical screenplay paragraph structure:
```
<w:p>
  <w:pPr>
    <w:pStyle w:val="SceneHeading"/>
  </w:pPr>
  <w:r>
    <w:t>INT. KITCHEN - DAY</w:t>
  </w:r>
</w:p>
```

Screenwriting-app-exported DOCX files typically use these style IDs
(with app-specific variations):

| Element | Common style IDs |
|---------|------------------|
| Scene heading | `SceneHeading`, `Scene Heading`, `Heading1`, `ScriptSceneHeading`, `FadeInSceneHeading` |
| Action | `Action`, `ScriptAction`, `FadeInAction`, `Normal` (fallback) |
| Character | `Character`, `ScriptCharacter`, `CharacterCue`, `FadeInCharacter` |
| Parenthetical | `Parenthetical`, `ScriptParenthetical` |
| Dialogue | `Dialogue`, `ScriptDialogue`, `CharacterDialogue`, `FadeInDialogue` |
| Transition | `Transition`, `ScriptTransition` |

Word-typed DOCX files (no screenwriting app) usually use only
`Normal` for everything, relying on indentation and caps to convey
structure.

### DOCX parsing procedure

1. **Unzip the DOCX.** Extract `word/document.xml` and
   `word/styles.xml` in memory. If the file is not a valid ZIP or is
   missing `document.xml`, STOP and alert the user.

2. **Read the style map.** Parse `styles.xml` to build a lookup from
   style ID to style name. This isn't strictly needed for classification
   (the style ID itself is usually enough) but helps identify
   near-matches.

3. **Walk `<w:p>` (paragraph) elements in `document.xml` in order.**
   For each paragraph:
   - Read `<w:pPr><w:pStyle w:val="..."/></w:pPr>` to get the style ID
   - Read `<w:pPr><w:ind w:left="..."/></w:pPr>` to get the left
     indent (in twentieths of a point; 1440 twips = 1 inch)
   - Concatenate all `<w:t>` element text from child `<w:r>` runs
     (join with empty string; Word may split a single sentence across
     multiple runs due to formatting)
   - Classify:

**Primary classification — style-based (reliable when present):**

Match the style ID (case-insensitive, ignoring whitespace and script
prefixes) against the tables above. If a match is found, use that
classification directly.

**Fallback classification — indent + caps heuristics:**

If the style is `Normal` or the style is unrecognised:
- Empty line → skip
- Line starts with `INT.`, `EXT.`, `INT./EXT.`, `I/E`, or `FADE IN:` →
  scene heading
- Line ends with `TO:` and is uppercase → transition
- Line is entirely uppercase, <40 characters, and the next non-empty
  paragraph has dialogue-like content → character cue
- Line is in `(parentheses)` immediately after a character cue →
  parenthetical
- Line immediately after a character cue or parenthetical → dialogue
- Everything else → action

**Left-indent heuristics (finer classification when uppercase detection
is ambiguous):**

Standard screenplay indents in Word (approximate, in inches from left
margin):
- Sluglines / action / transitions: 0.0"–0.5"
- Dialogue: 2.5"
- Parentheticals: 3.1"
- Character cues: 3.7" (or centred, which Word represents as
  `<w:jc w:val="center"/>`)

Use indent classification as a tiebreaker when caps detection is
ambiguous. If a paragraph is uppercase AND centred OR indented
~3.5"+, it's a character cue. If uppercase and flush-left, it's
probably a transition or shouted-action line.

4. **Handle Word-typed files (no styles, no clean indents):**
   If style-based classification yields <5 scene headings and <5
   character cues, the file likely has no consistent formatting.
   STOP and alert the user: *"This DOCX doesn't use screenplay
   paragraph styles and the formatting is too inconsistent to parse
   reliably. Please either (a) open it in a screenwriting app like
   Highland or Fade In, save as Fountain, and re-upload, or (b)
   re-save from your screenwriting app with proper export settings."*

5. **Handle tables.** Some Word users format screenplays in 2-column
   tables (narrator/dialogue). The parser detects `<w:tbl>` elements
   and tries to extract text row-by-row. If the result doesn't yield
   sluglines, STOP and alert.

6. **Close out.** Same as other parsers. Return scenes, characters,
   locations.

### DOCX error recovery

- **Not a valid ZIP / DOCX** → STOP, alert user
- **Style map has no recognisable screenplay styles AND indent
  heuristics fail** → STOP, ask the user to re-export from a
  screenwriting app
- **File contains revision tracking** (`<w:ins>`, `<w:del>`) → accept
  inserted content, ignore deleted content, notify the user that
  revision tracking was present so they can decide if they want to
  re-export a clean version

---

## PDF parser

### PDF text-layer probe (MANDATORY first step)

Before attempting to parse, verify the file has an extractable text
layer. Run this probe:

1. Use the Read tool on the PDF file (`pages: "1"` to read just the
   first page).
2. Count the extractable characters.
3. Decision tree:
   - **≥200 characters on page 1** → text layer present, proceed to parsing
   - **50–199 characters** → partial text layer (mixed text + image
     pages?). Proceed but warn the user at parse completion if
     later pages yield fewer characters than expected.
   - **<50 characters** → no usable text layer. STOP and reject.

### Rejection message for scanned PDFs

When the probe fails:

```
This PDF does not contain a usable text layer — it's probably scanned
or image-only.

Ideorix cannot parse scanned screenplays in the current release. To
proceed, please:

  1. Open your screenplay in your screenwriting app (Final Draft,
     Highland, WriterDuet, Fade In, Celtx, or any Fountain-aware tool)
  2. Export to Fountain (.fountain) or FDX (.fdx) — both produce
     clean imports
  3. Re-upload the exported file

If you only have the scanned PDF and no original file, your options
are:
  - Retype the screenplay in a screenwriting app (tedious but reliable)
  - Use an external OCR tool to convert the PDF to text first, then
    clean up in a screenwriting app
  - Wait for a future Ideorix release with built-in OCR (not
    planned for the current roadmap)

I've stopped here to avoid producing an unreliable parse. Let me know
how you'd like to proceed.
```

Do NOT attempt to parse a scanned PDF automatically. Even if some
pages have partial text, the result will be fragmentary and the
Writer will receive a corrupted source scene list, which the Outline
Conformance Agent cannot enforce against because the "canonical
outline" itself is broken. Rejection is the safer path.

### PDF parsing procedure (text-layer files only)

Screenplay PDFs follow industry layout conventions (US Letter or A4,
Courier 12pt, fixed margins). Every element sits at a specific
horizontal position:

| Element | Left indent (inches from page left) | Typical line width |
|---------|------------------------------------|--------------------|
| Scene heading | 1.5" | up to 7.0" |
| Action | 1.5" | up to 7.0" |
| Character cue | 3.7" (or centred) | short |
| Parenthetical | 3.1" | short |
| Dialogue | 2.5" | up to 5.5" |
| Transition | 5.9" (right-aligned) or flush-right | short |

1. **Read the PDF page by page.** Use the Read tool on the PDF. For
   each page, extract text WITH position metadata if available (line
   start X position).
2. **Build a paragraph list from lines.** Lines that share the same
   X position and are vertically contiguous form a paragraph. A blank
   line or a change in X position starts a new paragraph.
3. **Classify each paragraph by X position:**
   - X ≈ 1.5" + uppercase start + contains `INT.`, `EXT.`, `INT./EXT.`,
     `I/E` → scene heading
   - X ≈ 1.5" + other content → action
   - X ≈ 3.7" + uppercase (allowing `(O.S.)` etc.) → character cue
   - X ≈ 3.1" + wrapped in `()` → parenthetical
   - X ≈ 2.5" → dialogue
   - X ≈ 5.9"+ + uppercase + ending in `TO:` or `.` → transition
4. **Fallback for non-standard layouts:** if the X-position
   classification yields <5 sluglines from the first 10 pages, fall
   back to text-content heuristics (regex for `INT.`/`EXT.`, ALL CAPS
   detection, etc.) similar to the DOCX freehand fallback.
5. **Use the same scene-building logic** as the Fountain and FDX
   parsers once paragraphs are classified. The output structure is
   identical.

### PDF quirks

- **Header/footer text** (page numbers, episode titles, draft info
  repeated on every page) → detect by appearing at the top or bottom
  of every page at the same position. Strip before classification.
- **Title page** — usually the first page with text centred. Extract
  title and author using the same heuristics as the DOCX title page.
- **Multi-column PDFs** (rare; some TV writers use them for dual
  dialogue) → PDFs with two text columns per page need column
  detection first. If text positions suggest columns (two clusters
  of X values), split the page into columns and process left-to-right.
- **Embedded fonts that render as glyph codes** (some producer
  templates) → extraction may yield garbage characters. If >10% of
  extracted text is non-ASCII garbage, STOP and ask the user to
  re-export from their screenwriting app with Unicode embedding.

### PDF error recovery

- **Text-layer probe fails** → reject with the scanned-PDF message above
- **Glyph-code garbage** → reject with a re-export request
- **Extraction yields <5 sluglines over the full file** → probably
  not a standard screenplay format. STOP and ask the user for
  Fountain or DOCX instead.
- **Multi-column detection fails and output is mangled** → flag and
  offer the user a choice: proceed anyway with known parse errors,
  or stop and re-upload a different format.

---

## Character normalisation pass

After parsing, normalise the character roster:

1. **Detect name variants by edit distance.** If two character IDs are
   within edit distance 1 of each other and one is a subset of the
   other (e.g., `ben` and `ben harris`), ask the user whether they
   should be merged.
2. **Detect voice-over / off-screen duplicates** — already handled by
   parenthetical stripping at parse time.
3. **Rank characters by dialogue count × scene presence.** This
   becomes the default POV recommendation: the top-ranked character.
4. **Flag minor characters.** Characters with <5 dialogue lines and
   <3 scenes are marked `role: minor` — they'll appear in Story Bible
   Section 7 as supporting cast, not as primary characters.

## Story Bible seeding

Generate `engine-data/story-bible.md` from the parsed data:

**Section 1 — Project Metadata:**
- Title: from title page or filename
- Author: from title page `Author` or `Credit`, else "Unknown (adapted)"
- Adapted from: `screenplay-source.md`
- Length tier: Novella (Phase 1 locked)
- Chapter count: 16

**Section 2 — Logline:**
Derive from the first scene's synopsis if present, else the first
3-5 action lines, else prompt the user. Flag for user review.

**Section 3 — Voice Profile:**
Empty placeholder — the importer hands off to Voice Builder or voice
profile attach before chapter generation begins.

**Section 4 — Locations:**
For each entry in `locations`:
```
### {Location name}
Type: {INT | EXT | INT/EXT}
First appears: Scene {N}
Total scenes: {count}
Seed description: {seed_description or 'To be expanded during chapter generation'}
```

**Section 7 — Characters:**
For each entry in `characters`, sorted by dialogue count descending:
```
### {Canonical Name}
Role: {protagonist | supporting | minor}  # ranked, top = protagonist unless user overrides
Dialogue lines: {count}
Word count: {count}
First appears: Scene {N}
Scenes present: {list}
Aliases: {list of alternate forms seen in cues}
Voice sample: {first 3 dialogue lines}
```

**Section 12 — Chapter Outline:**
Populated by the scene-to-chapter chunker (below).

**Section 14 — Chekhov's Guns:**
Scan action lines and dialogue for objects that appear in multiple
scenes. Seed as candidate guns for user review. This is best-effort —
adaptations rarely need explicit gun tracking because the screenplay
already resolves its own setups.

Leave Sections 3, 5 (themes), 6 (tone), 8 (subplots), 9 (arc maps),
10 (beat structure), 11 (transportive setting), 13 (voice contrast),
and 15 (genre-specific) empty for the user to fill during the
setup gate.

## Length tier selection + expansion ratio calibration

After parsing, compute the source word count (sum of all action +
dialogue words across all scenes). Present the user with all 5 length
tiers and the expansion ratio for each, with warnings for ratios
outside the ideal band.

### The 5 length tiers

| Tier | Target words | Chapters | Words/chapter |
|------|--------------|----------|---------------|
| Short Story | 8,000 | 5 | 1,600 |
| Novelette | 12,500 | 9 | 1,400 |
| Novella | 40,000 | 16 | 2,500 |
| Standard Novel | 75,000 | 30 | 2,500 |
| Epic Novel | 120,000 | 40 | 3,000 |

### Expansion ratio zones

For each tier, the expansion ratio is `target_words / source_words`.
Classify:

| Ratio | Zone | Guidance |
|-------|------|----------|
| < 0.9 | **COMPRESSION** | Target shorter than source. Scenes will be dropped or compressed. Not recommended unless your screenplay is much longer than the target. |
| 0.9–1.5 | **TIGHT** | Very close adaptation. Minimal expansion room. Works for dialogue-heavy source material. |
| 1.5–3.5 | **IDEAL** | The sweet spot. Writer has room to expand interiority + sensory environment while the source plot remains dominant. |
| 3.5–6 | **STRETCH** | Significant expansion. Expect large interiority additions, heavy sensory layering, and novel-dominant voice. Still plot-faithful (OC Agent enforces this) but the novel will feel more novelistic than the source ever did. |
| > 6 | **EXTREME** | Most of the novel is new material. Writer will make many decisions the screenplay didn't. Only pick this if you want a full-length novelisation of a short concept. |

### Present the choice to the user

Show a calibration table customised to the source word count, then
use AskUserQuestion to let the user pick:

```
Source word count: {N}
Scenes parsed: {N}

LENGTH TIER OPTIONS (expansion ratio shown for your specific source):

1. Short Story  — ~8,000 words / 5 chapters    | ratio {R1}x | {zone1}
2. Novelette    — ~12,500 words / 9 chapters   | ratio {R2}x | {zone2}
3. Novella      — ~40,000 words / 16 chapters  | ratio {R3}x | {zone3}
4. Standard     — ~75,000 words / 30 chapters  | ratio {R4}x | {zone4}
5. Epic Novel   — ~120,000 words / 40 chapters | ratio {R5}x | {zone5}

RECOMMENDED: {the tier whose ratio falls in the IDEAL zone (1.5-3.5).
If multiple tiers are in IDEAL, pick the one closest to 2.5x. If none
are IDEAL, pick the closest to IDEAL from the TIGHT or STRETCH side.}

Pick a tier:
```

Warnings:
- If the user picks a COMPRESSION tier, show: *"Heads up — this tier
  is shorter than your screenplay. I'll need to drop or compress
  scenes. Confirm you want to proceed with compression?"*
- If the user picks an EXTREME tier, show: *"Heads up — this tier is
  {ratio}x your screenplay. Most of the novel will be new material
  I invent (within your screenplay's plot). The Outline Conformance
  Agent will keep me from adding new plot events, but the voice,
  interiority, and sensory layering will dominate the result.
  Confirm?"*
- If the user picks IDEAL, no warning.

Store the choice in `project-config.md` as `length_tier`.

## Scene-to-chapter chunker (all 5 tiers)

**Inputs:** `scenes` (ordered list from parse), `target_chapters`
(from tier selection), `target_words_per_chapter`, total source word
count.

**Expansion mode vs compression mode:**

- If `expansion_ratio >= 1.0` → EXPANSION MODE (standard). Scenes are
  grouped into chapters; the Writer expands each chapter beyond the
  source word count per the expansion-aware protocol in
  `screenplay-expansion.md`.
- If `expansion_ratio < 1.0` → COMPRESSION MODE. Scenes are grouped
  into chapters, but the Writer compresses or drops content per the
  compression-aware protocol (see `screenplay-expansion.md`
  Compression Mode section). This is an opt-in path the user
  explicitly chose; the importer does not default to compression.

### Chunking algorithm (works for all tiers)

1. **Compute target scenes per chapter.**
   `scenes_per_chapter = ceil(len(scenes) / target_chapters)`.
   For a 40-scene script:
   - Short Story (5 chapters): 8 scenes/chapter (heavy compression)
   - Novelette (9 chapters): 5 scenes/chapter
   - Novella (16 chapters): 2-3 scenes/chapter
   - Standard Novel (30 chapters): 1-2 scenes/chapter
   - Epic Novel (40 chapters): 1 scene/chapter (near-perfect mapping)

2. **Identify natural break points.** Walk the scene list and flag
   any scene that meets one or more of:
   - Section marker (`#` in Fountain, ACT marker in FDX, Heading1
     style in DOCX) preceded it — strong break
   - Location change from previous scene — medium break
   - Time jump from previous scene (`LATER`, `MORNING`, `NEXT DAY`,
     `DAYS LATER`, `WEEKS LATER`) — strong break
   - Transition (`CUT TO:`, `SMASH CUT:`, `DISSOLVE TO:`,
     `FADE TO:`) on the previous scene — medium break
   - Previous scene ended on a revelation / turning point (heuristic:
     last action line contains exclamation, ellipsis, or dialogue
     with `!` or `?`) — weak break

3. **Group scenes into `target_chapters` groups.** Start with even
   distribution (`scenes_per_chapter`), then shift group boundaries
   toward natural break points where possible. A group boundary
   should land on a break; if no break is available within ±1 scene
   of the target position, split at the even distribution point and
   flag the chapter as "no natural break" for user review.

   **Special case — 1 scene per chapter (Epic Novel from a ~40-scene
   feature).** When `scenes_per_chapter == 1`, every scene becomes
   its own chapter. Natural-break detection is skipped (every scene
   is its own break by definition). The Writer's expansion ratio
   per chapter becomes very high — expect a 3x–5x expansion per
   scene. Warn the user at setup that chapter structure will be
   tightly scene-locked.

   **Special case — >5 scenes per chapter (Short Story or Novelette
   from a long feature).** When `scenes_per_chapter > 5`, compression
   is heavy. The chunker still groups by natural breaks but the
   Writer will need to merge, condense, or drop content per the
   Compression Mode protocol. Warn the user explicitly.

4. **Word-balance the groups.** After break-point grouping, compute
   each group's source word count (action + dialogue). Apply the
   expansion ratio to get the target chapter word count. If any
   group is significantly over- or under-target (>1.5x deviation
   from `target_words_per_chapter`), shift a scene from the long
   neighbour to the short one — but do not split natural-break
   groupings unless absolutely necessary. Flag any chapters that
   remain significantly out of balance.

5. **Output Section 12.** Write to Story Bible:
   ```
   ## Section 12 — Chapter Outline (from screenplay adaptation)
   
   Length tier: {tier name}
   Total source word count: {N}
   Total target word count: {N}
   Global expansion ratio: {ratio}x
   Chapters: {target_chapters}
   Compression mode: {yes if ratio < 1.0, otherwise no}
   
   ### Chapter 1
   Source scenes: {N..M} ({scene_count} scenes, {source_words} source words)
   Target word count: ~{target}
   Chapter expansion ratio: {chapter_ratio}x
   POV: {pov character for this chapter — from POV assignment step below}
   Locations: {list}
   Characters present: {list}
   Chapter goal: {derived from first scene synopsis or action summary}
   Beats to deliver: {synopses from each source scene, in order}
   Natural break after: {yes/no} — {reason}
   ```

Save the detailed mapping separately to
`engine-data/scene-to-chapter-map.md` for the Architect to reference
during brief generation. The map includes the full source scene
content inline so the Architect can read scene → chapter relationships
without loading the full screenplay source each time.

## POV selection gate (all modes)

After parsing and chunking, present the POV mode options to the user.
Ideorix supports three POV modes for screenplay adaptations:

### Step 1 — Pick the POV mode

Use AskUserQuestion with these options:

```
POV MODE — how many POV characters will the novel have?

1. Single-POV — one character carries the whole novel. All
   interiority is theirs. Every chapter narrates from their head.
   Best for: character-driven stories, thrillers with a clear lead,
   romance with one POV partner.

2. Dual-POV — two characters alternate chapters (or scenes within
   chapters). Both characters' interiority is fully rendered. The
   reader sees the story from two perspectives.
   Best for: romance (two partners), two-hander thrillers, any
   story with two strong leads carrying equal dramatic weight.

3. Multi-POV (3+) — three or more characters share POV across the
   novel. Each chapter is narrated by whoever is most active in its
   source scenes. Voice contrast is critical.
   Best for: ensemble stories, epic adaptations, any screenplay
   with a large cast and distributed protagonism.

Pick a mode:
```

Store in `project-config.md` as `pov_type: single | dual | multi`.

### Step 2 — Pick the POV characters

Show the character ranking (from the normalisation pass) with
recommended counts based on the chosen mode:

```
CHARACTER RANKING (from your screenplay)

Ranked by dialogue count × scene presence:

1. BEN — 127 dialogue lines, 34 of 42 scenes (81%)
2. SARAH — 89 dialogue lines, 28 of 42 scenes (67%)
3. DETECTIVE MILLER — 31 dialogue lines, 8 of 42 scenes (19%)
4. MRS HALE — 18 dialogue lines, 6 of 42 scenes (14%)
5. JAMIE — 12 dialogue lines, 5 of 42 scenes (12%)
```

Ask the user to select POV characters based on the mode:

- **Single-POV:** "Which character carries the novel's POV?"
  Default recommendation: rank #1. Use AskUserQuestion with top 5
  + "Other (I'll name someone)".

- **Dual-POV:** "Which two characters carry the novel's POV?"
  Default recommendation: rank #1 and #2. Ask the user to confirm
  or pick a different pair from the top 5. Also ask: "How should
  chapters alternate?"
    - Strict alternation (A/B/A/B/...)
    - Scene-driven (whoever is most active in each chapter)
    - User-assigned (I'll pick POV per chapter)

- **Multi-POV:** "How many POV characters? (3, 4, or 5 recommended.
  More than 5 dilutes voice contrast.)" Then "Which characters?"
  Ask the user to pick from the top 8. Default recommendation: top
  3. Also ask: "How should chapters assign POV?"
    - Scene-driven (default — whoever is most active in each
      chapter's source scenes)
    - User-assigned

Store in `project-config.md`:
```
pov_type: {single | dual | multi}
pov_characters: [list of character IDs]
pov_assignment_mode: {alternating | scene_driven | user_assigned}
```

### Step 3 — Assign POV to each chapter

Based on the chosen `pov_assignment_mode`, populate a POV map from
chapter number to POV character ID. Write this to
`engine-data/scene-to-chapter-map.md` as a column in each chapter's
entry.

**For `alternating` (Dual-POV only):**
- Chapter 1 = first POV character, Chapter 2 = second, Chapter 3 = first,
  and so on

**For `scene_driven` (Dual or Multi):**
- For each chapter, look at the source scenes mapped to it
- Count dialogue lines per POV candidate within those scenes
- POV for that chapter = the POV candidate with the most dialogue in
  those scenes
- Tie-breaker: the POV candidate with the most scenes present
- Tie-breaker: the POV candidate ranked highest globally

**For `user_assigned`:**
- Present the user with a chapter list and ask them to pick POV per
  chapter. This is tedious for long novels but produces the most
  tailored result. Offer `scene_driven` as a "do it automatically"
  fallback.

After the POV map is built, display a summary:

```
POV ASSIGNMENT SUMMARY

Chapter  Source scenes    POV character
-------  ---------------  -------------
Ch 1     Scenes 1-3       Ben
Ch 2     Scenes 4-5       Sarah
Ch 3     Scenes 6-8       Ben
...
Ch 16    Scenes 38-42     Ben

Ben carries 10 chapters / 62% / ~25,000 words
Sarah carries 6 chapters / 38% / ~15,000 words

Confirm this assignment, or ask me to adjust?
```

### Voice contrast warning (Multi-POV only)

For Dual and Multi POV, each POV character should ideally have a
distinct voice profile. Before proceeding, warn the user:

```
⚠ VOICE CONTRAST IS CRITICAL FOR MULTI-POV

Each POV character's chapters will be narrated from inside their
head. If every POV sounds the same, readers can't tell whose chapter
they're reading without checking the heading. This is the single
biggest failure mode for multi-POV novels.

Recommended next step: run the Voice Builder to create a distinct
voice profile for each POV character, extracting voice markers from
their dialogue in the screenplay.

Would you like to:
1. Run the Voice Builder now (recommended)
2. Attach existing voice profiles from your Voice library
3. Skip voice profiles (not recommended for multi-POV)
```

## Source preservation

Save two files:

1. **`engine-data/screenplay-source.md`** — the full parsed data in a
   structured format the Architect and Outline Conformance Agent can
   read:
   ```
   # Screenplay Source — {Title}
   Author: {Author}
   Draft date: {date or 'unknown'}
   Import date: {today}
   
   Total scenes: {N}
   Total characters: {N}
   Total locations: {N}
   Total source words: {N}
   
   ## Scenes
   
   ### Scene 1 — INT. KITCHEN - DAY
   Characters: BEN, SARAH
   Action:
   {action lines}
   Dialogue:
   BEN: "..."
   SARAH (softly): "..."
   Transition: CUT TO:
   
   ### Scene 2 — EXT. PARK - DAY
   ...
   ```

2. **`imports/screenplay-export/{original-filename}.fountain`** — the
   original Fountain file, copied verbatim. Preserved for the user's
   reference and for any future re-import.

## Entity Canon Lockfile generation

After parsing, generate `engine-data/entity-canon.md` directly from
the character and location rosters. See `world-canon.md` Phase 2D for
the file format.

```
## Characters

| ID | Canonical Name | Aliases / Also Called | Role | First appears |
|----|----------------|----------------------|------|---------------|
| ch.ben | Ben | BEN, BEN (O.S.), BEN (V.O.), BEN (CONT'D) | Protagonist (POV) | Scene 1 / Chapter 1 |
| ch.sarah | Sarah | SARAH, SARAH (CONT'D) | Supporting (love interest) | Scene 3 / Chapter 1 |

## Locations

| ID | Canonical Name | Aliases | Type | First appears |
|----|----------------|---------|------|---------------|
| loc.kitchen | The Kitchen | INT. KITCHEN | dwelling | Scene 1 / Chapter 1 |
```

At this stage the Canonical Name column contains the character's cue
as written in the screenplay (e.g., "BEN"). During setup, the user
is asked to set proper canonical names (first + last name,
credentials) — the canon file is updated before Chapter 1 generation
begins. Aliases remain the screenplay cue variants plus any the user
adds.

## Reduced Phase 1 setup flow (adaptation mode)

The importer runs a reduced version of the normal Phase 1 setup
questions. Many Phase 1 questions (genre, length tier, POV, outline
source, structure type, beat selection) have already been answered by
the screenplay content itself — the importer inherits them from the
parsed source. The remaining questions are about decisions the
screenplay can't make for you: category positioning, voice, pen name,
dialect, and adaptation policy.

Run these questions in this order, one at a time, using
AskUserQuestion for each. Each question's answer is written to
`engine-data/project-config.md` before the next is asked.

### Question A — Length tier

See the "Length tier selection + expansion ratio calibration" section
above. Present all 5 tiers with calculated expansion ratios and zone
warnings. Store as `length_tier`.

### Question B — POV mode

See the "POV selection gate (all modes)" section above. Pick Single,
Dual, or Multi. Store as `pov_type`.

### Question C — POV character(s)

See the "POV selection gate" Step 2. Pick from the ranked character
roster. Store as `pov_characters`.

### Question D — POV assignment mode (Dual and Multi only)

See the "POV selection gate" Step 3. Pick alternating / scene-driven
/ user-assigned. Store as `pov_assignment_mode`. Skip this question
entirely for Single-POV.

### Question E — Genre

The screenplay gives you signals (tone, pacing, setting, tropes) but
not a genre tag. Read the first 10 scenes and the character roster,
then suggest a best-match genre from the Ideorix genre bank
(`_index.md`). Use AskUserQuestion with:
- The inferred best match (e.g., "Psychological Thriller")
- 3 plausible alternatives from related genres
- "Other — I'll pick" (falls through to the full genre list from
  `_index.md`)
- "Build a custom genre" (routes to `custom-genre.md`)

Store as `genre` (matching the genre ID used in the genre bank).

### Question F — Dialect

AskUserQuestion: American English (US) or British English (GB).
Default: infer from screenplay dialect markers (spelling of "colour"
/ "color", "neighbour" / "neighbor", "the lift" / "the elevator") —
if clear, suggest as default. If ambiguous, ask with no default.
Store as `dialect`.

### Question G — Dialogue handling policy

AskUserQuestion:
- **Preserve verbatim** — every scripted line kept exactly as
  written (default for your own screenplays)
- **Natural adaptation** — up to 20% of lines may be paraphrased for
  novel rhythm where lines read stilted (default for external
  adaptations)
- **Paraphrase freely** — scripted dialogue as guide, not script
  (looser adaptation; use sparingly)

Default recommendation: **Preserve verbatim** if the user is
adapting their own script (determined by asking Q6 first — "Is
this your own script, or are you adapting someone else's?"),
otherwise **Natural adaptation**. Store as `dialogue_handling`.

### Question H — Voice profile(s)

Behaviour depends on POV mode:

- **Single-POV:** Attach an existing voice profile, build one now
  via Voice Builder (recommended — extract voice from the POV
  character's dialogue in the screenplay), or skip. Store the
  attached profile ID in `voice_profile`.

- **Dual-POV / Multi-POV:** For each POV character, ask the same
  question. Voice contrast is strongly recommended — see the
  "Voice contrast warning" in the POV selection section. The user
  can attach, build, or skip per POV character, but skipping any
  profile produces a warning at chapter generation time. Store
  as `voice_profiles: {character_id: profile_id | null}`.

### Question I — Pen name

AskUserQuestion: Attach existing pen name, create one now via Pen
Name Studio (`pen-name.md`), or skip (use author's real name /
leave blank). Store as `pen_name`.

### Hand-off to Story Bible review gate

After all 9 questions are answered, proceed to the Story Bible
review gate:

1. Display the seeded Story Bible (Sections 1, 4, 7, 12, 14 — all
   populated from the screenplay) + the user's setup answers.
2. Flag any Story Bible sections the screenplay didn't cover
   (Section 2 logline, Section 3 voice, Section 5 themes, Section 6
   tone, Section 8 subplots, Section 9 arc maps, Section 10 beat
   structure, Section 11 transportive setting, Section 13 voice
   contrast for multi-POV, Section 15 genre-specific extensions).
3. Use AskUserQuestion: "Review and fill in the Story Bible gaps
   now (recommended) or proceed with gaps (the Architect will
   surface them per chapter)?"
4. If the user reviews now, walk them through the empty sections
   one at a time. Each answer is written directly into the Story
   Bible file.
5. If the user proceeds with gaps, write a `bible_gaps: [list]`
   field to `project-config.md` so the Architect knows to surface
   missing context per chapter.

After the Story Bible review gate, proceed to Market Scout (which
runs for adaptations same as originals — see `core-pipeline.md`
Phase 2 MARKET SCOUT section), then proceed to Phase 3 chapter
generation with `adaptation_mode: screenplay_adaptation` set.

## Hand-off to the pipeline

After parsing, chunking, Story Bible seeding, POV selection, canon
generation, and user approval:

1. **Set the mode flags.** Write to `engine-data/project-config.md`:
   ```
   source: screenplay
   source_format: {fountain | fdx | docx | pdf}
   adaptation_mode: screenplay_adaptation
   length_tier: {short_story | novelette | novella | standard_novel | epic_novel}
   target_chapters: {5 | 9 | 16 | 30 | 40}
   target_words_per_chapter: {1600 | 1400 | 2500 | 2500 | 3000}
   pov_type: {single | dual | multi}
   pov_characters: [list of character IDs]
   pov_assignment_mode: {alternating | scene_driven | user_assigned}
   dialogue_handling: {verbatim | natural | paraphrase}
   expansion_ratio: {computed — global source → target ratio}
   expansion_mode: {expansion | compression}
   screenplay_source_file: engine-data/screenplay-source.md
   scene_to_chapter_map: engine-data/scene-to-chapter-map.md

   architect_mode: true
   architect_mode_set_at: {ISO 8601 timestamp}
   architect_mode_source: screenplay-import
   import_source: screenplay
   ```

   The `architect_mode` flag is MANDATORY (v2.7.1+) for
   screenplay imports — the imported screenplay IS user-
   supplied canon, and downstream agents (Architect, Writer,
   Quality Guardian) MUST treat the screenplay scenes,
   dialogue, and character names as authoritative rather
   than as raw material to reinterpret. See
   `blueprint-protocol.md` § Architect Mode Binding,
   `prose-protocol.md` § Architect Mode Binding, and
   `quality-gate.md` § Architect Mode Binding for the
   downstream contracts.

   The screenplay source itself is also mirrored into
   `source-canon/screenplay-import/` (read-only canon, the
   engine reads but never writes back) so the Step 0
   filesystem trigger fires uniformly across BYO-canon and
   import paths.

2. **Hand off to Phase 3 (chapter generation).** Adaptation mode
   hands off to the standard chapter-generation flow (and to
   `continue-writing.md` on subsequent sessions, which resumes
   from the last-completed chapter using the same source-as-
   canonical-outline contract). The pipeline now runs exactly
   as it would for an original novel, with these differences:
   - The Architect reads `screenplay-expansion.md` and treats the
     screenplay source as the locked outline (see that file for the
     expansion-aware brief rules)
   - The Writer receives the scene-to-chapter mapping and dialogue
     handling policy; it expands scenes into chapters per the
     expansion-aware protocol
   - The Outline Conformance Agent treats the screenplay scenes
     mapped to the current chapter as the canonical outline. Any
     plot event in the brief not traceable to a scripted scene is
     a FAIL.
   - The Continuity Guardian's Canon Compliance Check runs normally
     against the auto-generated entity canon.
   - Running Banlist behaves identically.
   - Progress Dashboard shows the same Outline Conformance and
     Canon Drift lines.

3. **Skip Phase 2 Story Bible generation.** It was populated by the
   importer. But run a User Review Gate on the seeded bible so the
   user can fill in genre, tone, themes, voice choices, and any
   supporting cast details the screenplay didn't make explicit.

## Error recovery

If parsing fails at any step:

- **Slugline detection produces zero scenes** → the file is probably
  not Fountain. STOP and ask the user to export Fountain from their
  screenwriting app.
- **Character detection produces zero characters** → same as above,
  or the screenplay has no dialogue at all (unusual). Ask the user
  to confirm the file is a screenplay.
- **Expansion ratio falls outside [1.5, 5.0]** → warn the user. For
  very short screenplays (<8,000 source words), recommend waiting
  for Phase 2 shorter tiers. For very long screenplays (>25,000
  source words), recommend either splitting into multiple novels or
  waiting for Phase 2 Standard Novel tier.
- **File contains content that isn't Fountain** → the parser should
  be tolerant of leading/trailing whitespace and stray non-content
  lines, but if more than 10% of the file is unclassifiable, flag
  it and show the user the first few unclassified lines so they can
  decide whether to proceed or clean the file.
- **Character ranking has ties** → the user picks manually.

Every error surfaces to the user with the specific problem and a
suggested next action. No silent failures.
