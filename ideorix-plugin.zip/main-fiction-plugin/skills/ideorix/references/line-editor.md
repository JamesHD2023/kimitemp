---
name: line-editor
description: "Deep line-editing protocol — passive voice taxonomy, adverb preservation rules, dialogue tagging, AI paragraph architecture, cliché detection, redundancy audit, show-vs-tell, chapter endings, dialogue distinctiveness, therapy-speak, and intimate scene review"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Line Editor Protocol

## File-Write Hygiene (MANDATORY)

The Line Editor's surgical-fix Edit operations on chapter
files are bound by the chained-Edit truncation safeguard
documented in `core-pipeline.md` § Chained-Edit Truncation
Safeguard:

- **Cap individual Edit replacements at ~2 KB.** Line-level
  fixes should rarely exceed this; if a fix needs more, split
  it.
- **Run `scripts/word-count-check.sh` after every chapter file
  this protocol edits.** Word-count drift after a "single-line
  fix" is the signature of silent truncation.
- **Verify on-disk integrity via Bash** before reporting a
  chapter as line-edited.

**HARD GATE — BLOCKING.** Truncation caught at the line-edit
stage MUST be repaired before subsequent line-edits proceed
on the same file.

## Role

The Line Editor performs deep, surgical prose analysis that goes beyond what
the Prose Humaniser and Craft Standards cover. Where those skills catch AI-isms
and enforce craft rules, this protocol catches the subtler mechanical issues
that separate competent prose from publishable prose.

## Voice Profile Requirement

Before running any analysis, load the POV Voice Profile for this chapter's
narrator from Story Bible Section 3. The Line Editor must know the established voice
to distinguish between prose issues and deliberate voice choices:
- A character who speaks in fragments: short sentences are voice, not a pacing problem
- A character who intellectualises: complex sentence structures are voice, not overwriting
- A character with limited vocabulary: simple word choices are voice, not under-writing

All line editing suggestions must be checked against the Voice Profile. A
suggestion that would violate the established voice is worse than the issue
it's trying to fix. **The Voice Profile takes precedence over line editing rules.**

## When It Runs

- **During Phase 5 (Editorial)** — as a supplement to the Copy Editor stage
- **On request** — when a user asks for deeper line-editing on specific chapters
- Runs on FINISHED chapters only (after Humaniser, after verification)

## What This Skill Does NOT Cover (Handled Elsewhere)

- AI-telltale word detection → `forbidden-words.md`
- AI phrase patterns (e.g., "Something about", "Found herself") → `prose-humaniser.md`
- Structural AI-isms (chapter openings/endings) → `prose-humaniser.md`
- 7 Craft Commandments scoring → `craft-standards.md`
- Basic filter word flagging → `craft-standards.md` (Prose Craft Improver)

---

## Analysis 1: Passive Voice Taxonomy

Flag passive constructions by category. Not all are equal — each has different
fix strategies and different retention rules.

### Category 1: Progressive Constructions (was/were + -ing)

The structure **was/were + -ing verb** stretches an action across time when
simple past tense would be sharper.

**Patterns:** was [verb]-ing, were [verb]-ing, had been [verb]-ing

**Fix:** Convert to simple past with a more specific verb.

```
WEAK:  He was walking to the bank.
FIX:   He walked to the bank.

WEAK:  She was going across the room.
FIX:   She crossed the room.
```

**Retain when:** One action is genuinely ongoing while another interrupts
(e.g., *She was running down the stairs when the subway pulled in*).

### Category 2: True Grammatical Passive (be + past participle)

The subject receives the action. Built from **to be** + **past participle**,
sometimes with "by + agent."

**Patterns:** was [past participle], were [past participle], had been [past participle]

**Fix:** Identify the real actor and promote them to subject.

```
PASSIVE:  The door was slammed shut by Mark.
ACTIVE:   Mark slammed the door.

PASSIVE:  Mistakes were made.
ACTIVE:   Senior staff made serious mistakes.
```

**Retain when:** The actor is legitimately unknown, deliberately withheld
(mystery context), or when foregrounding the subject's helplessness is the
intended effect (e.g., *He was dragged into the alley*).

### Category 3: Get-Passives

**Patterns:** got [past participle], gets [past participle], getting [past participle]

**Fix:** Name the real actor.

```
WEAK:  He got hit by a stray arrow.
FIX:   A stray arrow hit him.
```

**Retain when:** Colloquial tone serves the voice, or the point is deliberately
that something happens *to* the character.

### Category 4: Weak / Hedging Verbs

Verbs that wrap a stronger action in vagueness or tentativeness.

**Patterns:** seemed to, appeared to, began to, started to, tried to, was about to

**Fix:** If the character completes the action, cut the hedge. If they fail,
show the failure explicitly.

```
WEAK:  He started to run toward the gate.
FIX:   He ran toward the gate.

WEAK:  She began to cry.
FIX:   Tears spilled down her cheeks.

WEAK:  He tried to open the door. (if he fails)
FIX:   He yanked the handle, but the door wouldn't budge.

WEAK:  He tried to open the door. (if he succeeds)
FIX:   He opened the door.
```

**Retain when:** The hedge genuinely matters — *seemed* with an unreliable
narrator, *began to* when the action is interrupted before completion.

### Category 5: Dummy Subjects (There is/was, It is/was)

Placeholder subjects that delay the real subject and flatten prose energy.

**Patterns:** There was/were, There is/are, It was/is, It was [noun] that...

**Fix:** Move the real subject to subject position.

```
WEAK:  There was a storm raging outside.
FIX:   A storm raged outside.

WEAK:  There were three guards standing at the gate.
FIX:   Three guards stood at the gate.
```

**Retain when:** The dummy subject creates meaningful emphasis or contrast,
or when identifying the real agent would require awkward restructuring.

---

## Analysis 2: Adverb Audit (with Preservation Rules)

Not every adverb is a problem. The line editor distinguishes harmful adverbs
from useful ones.

### Adverbs to FLAG and FIX

**Redundant adverbs** — add no information the verb already carries:
- "She glared at him angrily" → the glare already contains anger
- "He laughed happily" → laughter already implies pleasure
- "She wept sadly" → weeping already implies sadness

**Weak verb + adverb pairings** — a stronger verb would eliminate the adverb:
- "walked quietly" → tiptoed
- "said loudly" → shouted
- "ran quickly" → sprinted
- "smiled widely" → beamed
- "looked carefully" → scrutinised

**Intensity/degree adverbs that dilute** — prop up vague adjectives:
- "very tired" → exhausted
- "really hungry" → ravenous
- "extremely scared" → terrified
- "quite angry" → furious
- "so beautiful" → replace with a specific image

**Words to watch:** very, really, quite, extremely, totally, incredibly,
so, awfully, terribly, utterly (as vague intensifiers)

**Emotional label adverbs** — shortcut for showing behaviour:
- "She waited impatiently" → She tapped her foot, eyes flicking to the clock
- "He looked at her angrily" → His jaw set; he held her gaze without blinking
- "She smiled happily" → Show the happiness through action
- "He sighed sadly" → Show the sadness through physical detail

**Contradictory degree adverbs** — illogical qualifier + extreme adjective:
- "slightly devastated", "a bit flabbergasted", "somewhat furious"
- Fix: commit to the full weight of the adjective, or find a more accurate word

### Adverbs to PRESERVE (Do NOT flag)

- **Time/place adverbs:** yesterday, here, always, never, soon, still, already,
  sometimes, once, then, there — carry essential information
- **Meaning-changing adverbs:** barely, almost, nearly, only, exactly, just,
  truly, hardly — cutting would change what's happening in the scene
- **Voice-essential adverbs:** integral to the character's established narrative
  voice (especially first person, close third, or comedic prose)
- **Precision adverbs:** supply a compact, specific shade of meaning that would
  otherwise require an awkward workaround

---

## Analysis 3: Dialogue Tagging Audit

### Under-Tagging

In scenes with 3+ characters, or in longer two-person exchanges where the
pattern has been broken, readers may lose track of who is speaking.

**Flag:** Any passage where a speaker is not clearly identifiable from tags,
beats, or context.

### Over-Tagging

In two-person exchanges, once a conversational pattern is established and
it is absolutely clear who is speaking, some tags can be safely omitted.

**Flag:** Runs of dialogue where every single line is tagged despite the
speaker being obvious from context.

### Action Beat Opportunities

Identify adverbs or loaded dialogue tags that would work better as action beats.

```
TAGGED:  "You're late again," she said angrily.
BEAT:    "You're late again." She set her fork down hard enough to chip the plate.
```

Action beats are punctuated as separate sentences, not attached with a comma.

---

## Analysis 4: Formulaic AI Paragraph Architecture

AI-generated paragraphs often follow a five-part essay structure:
**topic sentence → context → supporting detail → example → concluding
transition or generalisation.**

These paragraphs feel internally symmetrical — they open, develop, and close
in a tidy arc. Real fiction paragraphs are messier.

### How to Detect

- Paragraph opens with a general claim or observation
- Middle sentences add context or supporting evidence
- Final sentence restates the paragraph's point in slightly different words
  or transitions smoothly to the next paragraph
- The paragraph could be rearranged or have sentences removed without
  losing meaning — a sign of padding, not purpose

### How to Fix

- Cut redundant closing sentences that restate what's already clear
- Break the symmetry — let paragraphs end mid-thought or on a detail
- Remove throat-clearing openers ("It is important to consider the ways in which...")
- Let action or dialogue interrupt the paragraph's tidy arc
- Vary paragraph length aggressively — some should be one sentence

---

## Analysis 5: Cliché Detection

### Stock Emotional Idioms

Physical reactions so formulaic they carry no fresh information:

- "heart pounded in her chest"
- "blood ran cold"
- "stomach dropped"
- "butterflies in her stomach"
- "lump in her throat"
- "her breath caught"
- "his jaw dropped"
- "mind went blank"
- "a chill ran down his spine"

**Fix:** Replace with a specific physical reaction unique to this character
and this moment. What does THIS person's anxiety look like?

### Stock Descriptive Idioms

Comparisons so overused they've lost their visual power:

- "eyes like the ocean"
- "hair like fire"
- "skin like porcelain"
- "silence was deafening" (also in Humaniser zero-tolerance list)
- "time stood still"

**Fix:** Find a comparison drawn from the character's world and experience.

### Reaction and Action Clichés

Stock behaviours used to convey emotion:

- "she rolled her eyes"
- "he clenched his jaw"
- "her hands balled into fists"
- "he let out a breath he didn't know he was holding"
- "she bit her lip"

**Fix:** Find a gesture specific to this character — something that reveals
who they are, not just what they feel.

### Narrative Summary Clichés

Lines that reach for a worn phrase to summarise a moment:

- "it had been a long night"
- "things would never be the same"
- "she knew then that everything had changed"
- "little did she know" (also in Humaniser zero-tolerance list)

**Fix:** Delete the summary and trust the scene to carry the weight.
If the scene doesn't carry it, the scene needs work — not a summary.

---

## Analysis 6: Redundancy Audit

### Internally Redundant Word Pairings

One word already contains the meaning of the other:

- "added bonus" → bonus
- "end result" → result
- "close proximity" → proximity
- "past history" → history
- "future plans" → plans
- "absolutely essential" → essential
- "completely surrounded" → surrounded
- "each and every" → each / every
- "brief moment" → moment
- "new innovation" → innovation
- "return back" → return
- "free gift" → gift

**Fix:** Cut the redundant word.

### Empty Intensifiers

Words that appear to add emphasis but drain rather than strengthen:

just, really, very, so, quite, rather, somewhat, kind of, sort of,
a bit, a little, completely, totally, absolutely, literally, basically,
actually, certainly, definitely, truly, honestly, simply, merely

**Process:** Flag every instance. If removing it doesn't change the meaning,
it's redundant.

### Emotion Named After Emotion Shown

```
REDUNDANT: "Get out," she said, her voice shaking with anger. She was furious.
           (the shaking voice and command already carry the fury)

FIXED:     "Get out." Her voice shook.
```

**Flag:** Every case where an explicit emotion word (furious, devastated,
relieved, terrified) follows action or dialogue that already implies it.

### Redundant Adverbial Explanation of Clear Action

```
REDUNDANT: She glared at him angrily.
REDUNDANT: He laughed happily.
REDUNDANT: She wept sadly.
```

**Flag:** Every case where an adverb re-explains an emotional quality
already contained in the verb.

---

## Analysis 7: Show vs. Tell

Telling is the single most common prose weakness in both AI-generated and early-draft
human writing. This analysis flags every instance where the prose names an emotion,
relationship quality, or character trait instead of rendering it through action,
dialogue, or sensory detail.

### The Camera Test

For every flagged passage, apply this test: **"Could a camera capture this?"**

A camera can capture a woman slamming her laptop shut and walking out of the room.
A camera cannot capture "She was angry." If the prose describes something a camera
couldn't film, it's telling.

### Category 1: Emotion Telling

The prose names an emotion instead of showing it through physical behaviour.

```
TELLING:  She was angry.
SHOWING:  She set her mug down hard enough to slosh coffee over the rim.

TELLING:  He felt a wave of sadness wash over him.
SHOWING:  He turned the ring on his finger, the one she'd picked out at that
          market in Bruges. The metal was warm from his skin.

TELLING:  Relief flooded through her.
SHOWING:  Her shoulders dropped three inches. She exhaled through her teeth.
```

**Flag:** Any sentence where an emotion word (angry, sad, relieved, terrified, happy,
anxious, frustrated, devastated, elated, furious, nervous, ashamed, guilty, jealous)
appears as a direct label for what a character feels.

**Exception:** Interior monologue in deep POV may name emotions briefly as part of the
character's thought stream. Flag only if the naming replaces rather than accompanies
physical detail.

### Category 2: Relationship Telling

The prose summarises a relationship quality instead of demonstrating it through
interaction.

```
TELLING:  They had always been close.
SHOWING:  She answered on the first ring, the way she always did when it was him.

TELLING:  He didn't trust her.
SHOWING:  He checked the rearview mirror twice after she gave him the address.

TELLING:  They had a complicated relationship.
SHOWING:  She brought flowers and he left them on the counter, still in the
          cellophane, until they died.
```

**Flag:** Sentences that describe the state of a relationship using summary adjectives
(close, strained, complicated, toxic, loving, distant, awkward).

### Category 3: Backstory Telling

The prose delivers backstory through narration rather than through behaviour, dialogue,
or implication.

```
TELLING:  Sarah had grown up in poverty, which made her careful with money.
SHOWING:  Sarah smoothed the receipt flat, folded it in half, and tucked it into the
          zippered pocket of her wallet where she kept all of them.

TELLING:  He'd been a soldier, and the discipline showed.
SHOWING:  He made the bed with hospital corners before the coffee finished brewing.
```

**Flag:** Exposition that explains a character's background when the information could
be delivered through specific observed behaviour.

### Category 4: Theme Telling

Characters articulate the story's themes explicitly, or the narration states the
moral lesson.

```
TELLING:  In that moment, she realised that love was about letting go.
SHOWING:  She slid the key across the table. "The locks work fine. I just won't
          be using them."

TELLING:  He understood then that power came with responsibility.
FIX:      Delete. If the scene doesn't convey this through action, the scene needs
          work — not a thesis statement.
```

**Flag:** Any sentence where a character "realises" an abstract truth, or the narrator
states a moral, lesson, or thematic conclusion.

---

## Analysis 8: Chapter Endings Evaluation

Chapter endings are the last thing readers experience before deciding to turn the
page or put the book down. Weak endings bleed momentum; strong endings create pull.

### Weak Endings (FLAG)

| Pattern | Why It's Weak | Example |
|---------|--------------|---------|
| Philosophical wrap-up | Tells the reader what to think about the chapter | "And maybe that was the thing about trust — it was never given, only earned." |
| Falling asleep | Zero tension; permission to stop reading | "She pulled the covers up and let her eyes close." |
| Transit home | Anti-climactic; energy drains | "She locked the office, walked to her car, and drove home in silence." |
| Vague reflection | Summarises instead of landing | "Things were different now. She could feel it." |
| Restating the chapter's conflict | Redundant; reader already knows | "The question was whether she could trust him. She didn't have an answer." |
| Gentle fade-out | No hook, no tension, no pull | "The afternoon light shifted and the room grew quiet." |

### Strong Endings (TARGET)

| Pattern | Why It Works | Example |
|---------|-------------|---------|
| Revelation / new information | Reader MUST know what happens next | "The second envelope had no return address. Inside was a photograph of her daughter." |
| Decision point | Stakes crystallise | "She deleted the message. Then she picked up her keys." |
| Dialogue hook | Unresolved exchange | "'I know what you did in Marseille,' he said. She set down her glass." |
| Sensory cliffhanger | Tension through atmosphere | "The floorboard behind her creaked. She hadn't locked the door." |
| Emotional gut-punch | Lands a feeling, doesn't explain it | "He waved from the platform. She waved back. The train pulled away and she realised she was still holding his coffee." |
| Subverted expectation | Twist or reversal at chapter's final beat | "The test came back negative. She read it twice, then cried harder." |

### Evaluation Process

For each chapter:
1. Read the final 3 paragraphs
2. Classify the ending type (from weak or strong lists, or name a custom type)
3. If weak: propose a specific alternative that preserves the chapter's content
4. If the weak ending is a pattern (appears in 2+ chapters): escalate to priority fix

**Do NOT make every ending a cliffhanger.** Variety matters. A quiet ending after
an intense chapter can be powerful — the issue is weak endings that lack intention.
A deliberately quiet ending is strong; a default fade-out is weak. The question is:
**did the author choose this ending, or did the chapter just stop?**

---

## Analysis 9: Dialogue Distinctiveness Test

### The Cover Test

For every scene with 2+ speaking characters, apply this test:

**Cover the dialogue tags and action beats. Can you tell who is speaking from the
dialogue alone?**

If every character sounds the same — same vocabulary, same sentence length, same
rhythm, same level of directness — the dialogue lacks distinctiveness.

### What Makes Dialogue Distinct

| Dimension | How It Varies | Example |
|-----------|--------------|---------|
| Vocabulary level | Educated vs. colloquial | "I find that improbable" vs. "No way" |
| Sentence length | Terse vs. verbose | "Fine." vs. "Well, I suppose if you think about it from that angle..." |
| Directness | Blunt vs. evasive | "You lied." vs. "That's an interesting version of events." |
| Formality | Register shifts | "We should discuss this" vs. "We need to talk" |
| Verbal tics | Character-specific patterns | Always deflects with humour, never uses contractions, starts sentences with "Look," |
| What they avoid | Evasion patterns | Never says "I love you" directly, never admits fault, never mentions the past |
| Response to conflict | Confrontational vs. avoidant | Attacks vs. changes subject vs. goes quiet |

### Process

1. Select any multi-character dialogue exchange (3+ lines)
2. Strip tags and beats
3. Read the raw dialogue — can you assign speakers?
4. If not: flag with specific note on what's identical between characters
5. Suggest one concrete voice differentiation for each character (vocabulary shift,
   verbal tic, sentence length pattern, evasion pattern)

### Therapy-Speak Detection

A specific and increasingly common form of dialogue sameness where characters
speak with clinical emotional literacy that sounds like a therapist's office
rather than real conversation.

**Flag these patterns:**

```
THERAPY:  "I hear you, and I want you to know that your feelings are valid."
REAL:     "Yeah. I get it." (Or silence. Or a subject change.)

THERAPY:  "I think what's happening here is that we're both triggered by
           our childhood attachment wounds."
REAL:     "Every time you do that thing with the door I want to scream."

THERAPY:  "I need to set a boundary. When you raise your voice, I feel unsafe."
REAL:     "Don't shout at me." (Or she leaves the room without explaining.)

THERAPY:  "I'm sorry you're going through this. It sounds really hard."
REAL:     "That's rough." (Or just sits with them. Or makes tea.)
```

**When to flag:**
- Characters diagnosing each other's behaviour using psychological terminology
- Conflict resolution that's unrealistically mature and articulate
- Emotional vocabulary that exceeds what the character would plausibly use
- Every character processing feelings at therapist-level fluency
- Apologies that read like a textbook ("I acknowledge that my actions caused...")

**When NOT to flag:**
- A character who IS a therapist, counsellor, or in that profession
- A character established as emotionally articulate (must be in Character Bible)
- A deliberate contrast between one articulate character and others who aren't

---

## Analysis 10: Intimate Scene Review

When the chapter contains intimate scenes (physical intimacy, sexual content, or
heightened romantic tension), apply these additional checks. Intimate scenes are
where prose weaknesses become most visible — readers are highly attuned to
authenticity in these passages.

### Emotional Authenticity

The physical and emotional must be intertwined. Flag scenes where:
- Physical actions happen without emotional context
- Emotion is stated rather than rendered through sensation
- The scene reads as choreography (body part A moves to position B)
- Characters' internal thoughts disappear during physical passages

```
MECHANICAL:  He kissed her neck. She ran her hands through his hair.
             He pulled her closer.
AUTHENTIC:   His mouth found the hollow below her ear — the spot that always
             made her forget what she'd been saying. Her fingers tightened in
             his hair. Not gently.
```

### Heightened Show-Don't-Tell

Intimate scenes require a stricter standard than regular prose. Emotion-telling
that might pass in a regular scene (marginal, survivable) becomes glaring here.

**Flag:** Any emotion word (desire, passion, longing, need, love, lust, want)
used as a direct label during an intimate scene. These must be rendered through
physical sensation, thought, or action — no shortcuts.

### Pacing and Rhythm

Intimate scenes need deliberate pacing control:
- **Sentence length should vary** — short punchy sentences for urgency, longer
  ones for building tension
- **Paragraph breaks matter** — a single-line paragraph after a longer passage
  creates emphasis
- **Rushed scenes** feel like a checklist; flag if major beats happen in
  consecutive sentences with no breathing room
- **Stalled scenes** lose momentum; flag if the same emotional register holds
  for more than 3 paragraphs without escalation or shift

### Cliche Purge (Intimate-Specific)

These appear almost exclusively in intimate scenes and are harder to spot because
they feel "normal" for the genre:

- "electricity coursed through her"
- "her skin burned where he touched her"
- "their bodies moved in perfect rhythm"
- "she melted into his arms"
- "fireworks exploded behind her eyes"
- "every nerve ending was on fire"
- "his touch left a trail of fire"
- "she forgot how to breathe"
- "the world fell away"
- "a moan escaped her lips"

**Fix:** Replace with a specific, character-grounded physical sensation. What does
THIS character feel, in THIS moment, given THEIR history together?

### Physical Realism

Flag passages where the physical logistics don't work:
- Impossible positions or movements given where characters were a sentence ago
- Clothing that appears or disappears without being addressed
- Actions that require more hands/limbs than characters have
- Sudden location changes (they were on the sofa; now they're in bed with no transition)

### Emotional Closure

Every intimate scene needs emotional resolution, not just physical:
- What has changed between the characters?
- How does each character feel after (not just during)?
- If the scene ends abruptly after the physical peak: flag — the emotional
  aftermath is where intimacy scenes earn their place in the story

---

## Output Format

```
LINE EDITOR REPORT — Chapter {N}

PASSIVE VOICE:
  Category 1 (Progressive): {count} found, {count} flagged
  Category 2 (True Passive): {count} found, {count} flagged
  Category 3 (Get-Passive): {count} found, {count} flagged
  Category 4 (Weak/Hedging): {count} found, {count} flagged
  Category 5 (Dummy Subject): {count} found, {count} flagged
  Retained (justified): {count}

ADVERBS:
  Flagged for removal: {count}
  Preserved (justified): {count}

DIALOGUE TAGGING:
  Under-tagged passages: {count}
  Over-tagged passages: {count}
  Action beat opportunities: {count}

AI PARAGRAPH ARCHITECTURE:
  Formulaic paragraphs detected: {count}

CLICHÉS:
  Stock emotional: {count}
  Stock descriptive: {count}
  Reaction/action: {count}
  Narrative summary: {count}

REDUNDANCIES:
  Redundant pairings: {count}
  Empty intensifiers: {count}
  Emotion after shown: {count}
  Redundant adverbs: {count}

SHOW VS. TELL:
  Emotion telling: {count}
  Relationship telling: {count}
  Backstory telling: {count}
  Theme telling: {count}

CHAPTER ENDING:
  Type: {ending type}
  Strength: [strong | weak | marginal]
  Note: {if weak, what makes it weak}

DIALOGUE DISTINCTIVENESS:
  Scenes tested: {count}
  Passed (speakers identifiable): {count}
  Failed (voices indistinct): {count}
  Therapy-speak instances: {count}

INTIMATE SCENE REVIEW: {present | not applicable}
  Emotional authenticity: [pass | flag]
  Show-don't-tell (heightened): [pass | flag with count]
  Pacing: [pass | rushed | stalled]
  Intimate clichés: {count}
  Physical realism: [pass | flag]
  Emotional closure: [present | missing]

CHANGE LOG:
For each issue:
- CATEGORY: [passive | adverb | tagging | architecture | cliché | redundancy | show-tell | ending | dialogue | therapy-speak | intimate]
- QUOTE: [exact text]
- PROBLEM: [what's wrong]
- FIX: [specific instruction — exact words to cut/change/add]
- LOCATION: [paragraph number]
```

## Integration with Pipeline

This skill supplements — does not replace — the existing editorial pipeline.
The Copy Editor in `editorial-suite.md` catches high-level prose quality issues.
The Line Editor goes deeper on the specific mechanical categories above.

When running the full editorial suite, the Line Editor analysis should be
applied AFTER the Copy Editor and BEFORE the final surgical fixes.
