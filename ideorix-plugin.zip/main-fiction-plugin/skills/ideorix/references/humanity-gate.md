---
name: humanity-gate
description: "Engine-neutral Class B binding/protocol. Subagent-dispatched semantic audit that scores every material character (or biographical subject) against a 7-criterion humanity scorecard: contradiction self-belief/behavior, independent existence, five emotional registers, private self, competing desires, surprise behavior, gap stated values vs actual behavior. Per-character verdict graduated by score (6-7=PASS, 4-5=WARN, 0-3=FAIL). Closes the fifth gap in the canon-validation Wave 4 sequence (v2.7.34; CHARACTER gap-analysis row 5). Invoked by /validate dispatcher via CLASS_B_AUDIT line; subagent return verified by subagent-output-verification HARD GATE before merge. Material-character scope: bible-listed characters first, fall back to N+ chapter heuristic if no bible roster."
version: "2.7.34"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Humanity Gate (7-Criterion Character Audit)

A Class B binding/protocol spec for the CHARACTER domain (per
`canon-validation-taxonomy.md`). Closes the fifth gap in the
Wave 4 audit-additions sequence (gap-analysis row 5). Third
Class B audit using the v2.7.32 framework — see
`injury-accumulation.md` for the canonical Class B structure.

## Why this exists

Characters fail the reader in a recognisable way: they exist
to serve the plot. Every action advances the central conflict.
They have one emotional mode (stoic, brittle, sarcastic).
What they show others is what they are inside. They never
surprise us. They believe what they say they believe. They
have no life beyond the page.

The reader doesn't always articulate the failure ("this
character feels flat") but they feel it. Trust collapses;
emotional investment flattens; the manuscript reads as
machinery.

The opposite — characters who feel like people — turns out
to be measurable. Real people have specific structural
properties: they contain contradictions, they have lives the
plot doesn't touch, they cycle through multiple emotional
registers, they have private selves that diverge from
public selves, they want incompatible things, they
occasionally surprise themselves, and their stated values
sometimes leak around the edges of their actual behaviour.
Characters who exhibit these properties read as human;
characters who don't read as functions.

The 7-criterion humanity gate operationalises the difference.
The audit scans every material character (or biographical
subject in non-fiction) against the seven criteria below,
producing a per-character scorecard with prose-cited evidence.
Scores below threshold surface as findings the writer can
respond to with targeted craft work.

## The seven criteria

Each criterion has a concrete-evidence requirement. The
subagent must cite chapter:line for any criterion it marks
PASS or FAIL — narrative-impression claims without citations
are rejected by the engine HARD GATE.

**C1. Contradiction (self-belief vs behavior).** The
character holds a self-belief that their behavior at some
point contradicts. Aida tells herself she's not afraid of
her father; she stands at his door and cannot knock. The
contradiction need not be dramatic — a small moment of
gap between what the character thinks they are and what they
do is sufficient. PASS evidence: one cited self-belief
moment + one cited contradicting-behavior moment, in the same
character, anywhere in the manuscript.

**C2. Independent existence.** The character has interests,
relationships, history, or activities that do not exist solely
to advance the plot's central conflict. Aida plays the cello;
the cello never appears in the central plot, but she
practices in chapter 6 because she's a person who plays the
cello. The detail anchors the character in a life larger
than the story. PASS evidence: at least one cited prose
moment showing the character engaged with something the
plot does not require.

**C3. Five emotional registers.** Real people cycle through
multiple emotional modes across days and conversations. Flat
characters have one default (the stoic, the bitter, the
gentle). PASS evidence: cited prose moments showing the
character in at least five distinct emotional states across
the manuscript — not five synonyms for one mood, but five
substantively different registers (e.g. tender / impatient /
amused / anxious / decisive). Distinct emotions can repeat;
the count is over distinct registers, not distinct instances.

**C4. Private self.** There is a difference between what
the character shows others and what they hold internally.
The narration shows us something about Aida — a fear, a
grief, a tenderness — that other characters in the scene
do not see. PASS evidence: at least one cited prose moment
where the narration grants access to internal state that
diverges from the character's external presentation in the
same scene. (POV characters automatically have surface area
for this; non-POV characters need narrator inference or
revealing gesture.)

**C5. Competing desires.** The character wants two things
that cannot both be satisfied. Aida wants to escape her
family AND wants her family's approval; she cannot have
both. The competing desires need not drive the central plot
— even a small competing desire (wanting solitude AND
wanting company) qualifies. PASS evidence: cited prose
moments establishing both desires in the same character;
the conflict between them need not be resolved on-page.

**C6. Surprise behavior.** The character does at least one
thing across the manuscript that surprises the reader yet
reads as in-character on reflection. The stoic character
weeps once; the careful character takes a reckless risk; the
quiet character speaks first. PASS evidence: a cited prose
moment where the character's action is not the expected
default for them, AND the action is consistent with the
deeper portrait the prose has built (not random).

**C7. Stated-values / actual-behavior gap.** The character
articulates values at some point; their behavior at another
point partially conflicts with those values. Aida tells her
sister "I would never abandon family"; in chapter 18 she
walks away. The gap need not be hypocritical — most people
have gaps between aspiration and execution. PASS evidence:
a cited stated-values moment + a cited contradicting-behavior
moment, in the same character.

## Scoring and verdict

Per-character score: count of criteria marked PASS (0-7).

Per-character verdict:
- **6-7 PASS:** the character exhibits the structural
  properties of a person; no finding emitted
- **4-5 WARN:** the character has structural depth but is
  missing 2-3 properties; finding emitted with the missing
  criteria + a one-line craft note
- **0-3 FAIL:** the character is functioning as plot
  machinery rather than a person; finding emitted; writer
  will likely want to address before publication

Aggregate audit verdict:
- **PASS:** every material character scores 6-7, OR no
  characters identified as material (e.g. analytical NF
  with no character page-time)
- **WARN:** at least one material character scores 4-5;
  no material character scores 0-3
- **FAIL:** at least one material character scores 0-3

The graduated severity is intentional. The 7-criterion gate
is a CHARACTER-DEPTH heuristic, not a binary humanity test.
A 5/7 character is a real character; the audit notes the
gaps so the writer can choose whether to add depth or
accept the trade-off (a deliberately archetypal character,
a minor character with limited page-time, a chorus figure).

## Material-character scope

Not every named character is audited. The audit's purpose
is to surface depth gaps in characters with material
page-time; minor characters with one scene are out of scope
(too little prose to evaluate; usually intentional).

Two scope-identification paths, in order:

1. **Bible-listed characters.** Read the Cast / Characters /
   Subjects section of the bible (research-bible.md NF,
   story-bible.md fiction). Every character listed is a
   candidate. If the bible classifies characters by tier
   (protagonist, supporting, minor), audit only protagonist
   + supporting tiers (skip minor).
2. **Fallback — chapter-presence heuristic.** If the bible
   has no character roster (or no tier classification),
   identify characters appearing in 3+ chapters as material.
   The threshold is intentionally generous; a character with
   3 chapters of page-time has enough surface area for the
   audit to evaluate.

Characters out of scope are listed in the return for
transparency but not scored.

## Why Class B (subagent), not Class A (bash)

A bash audit cannot perform this check:

- **Identifying material characters** requires either reading
  the bible's prose-format roster semantically or counting
  named-entity appearances across chapters with name-variant
  resolution (Aida, Aidaaa, Mrs. Roth, the woman in blue).
- **Evaluating each criterion** requires semantic
  reasoning over prose passages — recognising contradictions
  between belief and behavior, distinguishing five emotional
  registers vs five instances of one register, identifying
  the gap between public presentation and internal state.
- **Citing evidence** for every criterion requires locating
  the supporting prose moment with chapter:line precision.

The mechanical-bash version would either miss most cases
(too literal) or false-positive on every named entity
(too loose). A subagent reading the bible + prose end-to-end
with explicit per-character evaluation is the right tool.

## How Class B audits are dispatched

Per `validate-dispatcher.md` Step 4b. The bash dispatcher
emits:

```
CLASS_B_AUDIT|humanity-gate|CHARACTER|references/humanity-gate.md|-
```

The slash-command engine layer reads the line, dispatches a
subagent per the brief below, applies the engine HARD GATE on
the return, and merges the verdict into the Validation
Briefing.

## Subagent task brief (for the humanity-gate audit)

The slash-command engine constructs the following subagent
brief when this audit is dispatched. Customise only project-
specific paths.

> **Task: Humanity Gate Audit (7-criterion character scorecard)**
>
> **Background.** This audit detects CHARACTER-domain failures
> where named characters function as plot machinery rather
> than people. You are scanning the full manuscript end-to-end
> with explicit per-character evaluation against seven
> structural criteria.
>
> **Inputs.**
> - `engine-data/research-bible.md` (NF) or
>   `engine-data/story-bible.md` (fiction) — character roster
>   if present
> - `engine-data/chapters/ch*.md` — manuscript chapters in
>   chapter order
>
> **Procedure.**
>
> 1. Identify material characters using the scope rules in
>    `humanity-gate.md` § Material-character scope:
>    - Bible-listed characters at protagonist or supporting
>      tier (preferred)
>    - Fallback: characters appearing in 3+ chapters
>    Build the audited-character list. Characters out of
>    scope are recorded but not scored.
>
> 2. For each audited character, evaluate the 7 criteria
>    (definitions in `humanity-gate.md` § The seven criteria).
>    Per criterion, record:
>    - Verdict: PASS or FAIL
>    - For PASS: at least one supporting chapter:line citation
>      with a one-clause description of the cited moment
>    - For FAIL: a one-clause statement of what's absent
>      ("no cited prose moment shows Aida engaged with
>      anything the plot doesn't require")
>
> 3. Per character, compute the score (count of PASS
>    criteria, 0-7) and per-character verdict (6-7 PASS, 4-5
>    WARN, 0-3 FAIL).
>
> 4. Compute aggregate verdict per the spec's rules.
>
> 5. For each WARN/FAIL character, draft a one-line craft
>    note suggesting the targeted intervention (e.g. "C2
>    miss: add a cited moment of independent activity for
>    Aida — page-time off the central plot").
>
> **Return contract (mandatory; subagent output is rejected
> by the engine if not conformant).** Return a structured
> response with the following sections, each populated even
> if empty:
>
> ```
> ## Audited Characters
> | Character | Source | Tier (if bible) | Chapter count |
> |---|---|---|---|
> [populated rows; or single row "(no material characters
> identified — analytical NF or insufficient page-time)"]
>
> ## Out-of-Scope Characters
> [bulleted list of named characters present but below the
> material threshold; or "(none)"]
>
> ## Per-Character Scorecards
> | Character | C1 | C2 | C3 | C4 | C5 | C6 | C7 | Score | Verdict |
> |---|---|---|---|---|---|---|---|---|---|
> [one row per audited character; cells = ✓ (PASS) or ✗
> (FAIL); Verdict = PASS / WARN / FAIL]
>
> ## Per-Criterion Evidence
> For every PASS or FAIL cell in the scorecard, one citation
> entry:
>
> ### <Character> — C<N>: <criterion-name>
> **Verdict:** PASS / FAIL
> **Evidence:** [one-clause description]
> **Citation:** ch<NN>:<line> (for PASS); n/a (for FAIL)
>
> [repeat for every cell]
>
> ## Findings
> | Severity | Character | Score | Missing criteria | Craft note |
> |---|---|---|---|---|
> [one row per WARN/FAIL character; or "(no findings)"]
>
> ## Verdict
> One of: PASS | WARN | FAIL
> [aggregated per spec rules]
>
> ## One-Line Summary
> Single line for the briefing's per-audit summary. Format:
> "<verdict>: <count> material character(s) audited — <N>
> PASS, <M> WARN, <K> FAIL" or "PASS: no material characters
> identified — audit not applicable"
> ```
>
> **Discipline.**
> - Cite every PASS criterion with chapter:line. The engine
>   HARD GATE strips uncited PASS verdicts; if a character's
>   cited PASS count drops below 6 after stripping, the
>   per-character verdict is downgraded.
> - Do NOT mark a criterion PASS based on narrative impression
>   ("the prose suggests Aida is complex"); a specific cited
>   moment is required.
> - Distinguish five emotional registers from five instances
>   of one register. Five moments of "anxious" is not five
>   registers; five of {tender, impatient, amused, anxious,
>   decisive} is.
> - For C6 (surprise behavior), the action must read as
>   in-character on reflection, not random. If the surprise
>   reads as out-of-character, mark C6 FAIL and note the
>   inconsistency in the per-criterion evidence.
> - When uncertain, mark FAIL. The audit's purpose is to
>   surface clear gaps; over-marking PASS makes the audit
>   useless.

## Engine HARD GATE on subagent return

Per `subagent-output-verification.md`:

1. **Shape check.** All seven required sections present
   (Audited Characters, Out-of-Scope Characters, Per-Character
   Scorecards, Per-Criterion Evidence, Findings, Verdict,
   One-Line Summary). Missing section → reject; re-dispatch
   ONCE with amendment instruction; on second failure emit
   `AUDIT|humanity-gate|CHARACTER|FAIL|subagent return non-conformant after retry|-`.
2. **Citation discipline.** For every cell in the Per-Character
   Scorecards table marked ✓ (PASS), there must be a matching
   Per-Criterion Evidence entry with a chapter:line citation.
   Uncited PASS cells are downgraded to FAIL; per-character
   scores recomputed; per-character verdicts recomputed;
   aggregate verdict recomputed.
3. **Hallucination markers.** Reject any citation referencing
   a chapter that does not exist in `engine-data/chapters/`
   (e.g. ch20:42 when manuscript has 12 chapters). Reject
   citations to characters not in the Audited Characters list.
4. **Scope-rule consistency.** If the bible has a character
   roster, the Audited Characters list should largely match
   the protagonist + supporting tiers. Deviation is allowed
   (subagent may reasonably exclude a bible-listed character
   with no actual page-time) but should be reflected in the
   Out-of-Scope list with a note.
5. **No-material-character special case.** If Audited
   Characters is the placeholder row, the audit's PASS verdict
   is preserved with the "audit not applicable" summary; no
   further checks required.

After verification, the engine emits:

```
AUDIT|humanity-gate|CHARACTER|<verdict>|<one_line_summary>|<subagent_return_path>
```

...with the full subagent return saved at
`engine-data/reports/validate/humanity-gate-subagent.md`.

## How writers should respond to FAILs

Three reasonable responses:

1. **Targeted craft work on missing criteria.** If Aida
   scored 3/7 with C2/C3/C5/C7 missing, add specific prose
   beats: a moment of independent existence (C2), an
   emotional-register beat that breaks her default mode (C3),
   a scene where two of her wants are in tension (C5), a
   moment where stated value and behavior diverge (C7). The
   subagent's craft note suggests the intervention.
2. **Accept the trade-off.** Some characters are deliberately
   archetypal (the messenger in classical drama, the chorus
   figure, the symbol-character whose flatness is the point).
   Accept the WARN/FAIL and note the craft choice in the
   bible. Future audits can be silenced for documented
   archetypal characters by an inline marker (deferred to
   a later release if false-positive volume is intrusive).
3. **Reduce page-time.** If the character is functioning as
   machinery and adding depth would distort the structure,
   the cleanest fix is to reduce their page-time so they
   fall below the material threshold. The audit no longer
   evaluates them.

The audit does not block phase advancement. WARN findings
surface for the writer's consideration; FAIL findings
surface as clear gaps the writer almost certainly wants to
address — but the craft choice on each character is the
writer's.

## How to adopt the convention on existing projects

The audit works on any manuscript with a bible character
roster or 3+ chapter character page-time. No new conventions
or frontmatter are required. Existing projects can run the
audit immediately; results reflect the current state.

For analytical non-fiction (business, self-help, reference,
philosophy) without character page-time, the audit returns
"no material characters identified — audit not applicable"
PASS. Argumentative manuscripts that use case-study
characters are evaluated on those characters.

## Engine-neutral applicability

Both fiction and narrative non-fiction (memoir, biography,
literary journalism) carry characters / subjects who can be
evaluated on the 7 criteria. Memoir + biography subjects are
real people; the audit is evaluating prose portrayal, not the
person's actual humanity. A biography that flattens its
subject into a vehicle for a thesis fails the audit even if
the historical person was complex; the prose is the unit of
evaluation.

Analytical non-fiction without character / subject page-time
returns the no-material-character PASS.

## Failure modes prevented

Per `silent-failure-audit.md` row 30:

- **Plot-machinery character cascade** — a character whose
  every action exists to advance the plot, with no surface
  area for the reader to attach to. Caught at validate time
  when targeted craft work can add depth without restructuring.
- **Single-emotional-register flatness** — a character who
  is always stoic / brittle / sarcastic across every scene;
  the reader experiences them as a tag rather than a person.
  Caught via C3.
- **Public-without-private collapse** — characters with no
  internal life beyond what other characters see; the reader
  has no privileged access; the prose has no depth.
  Caught via C4.
- **Validation-coverage misrepresentation** — without this
  audit, CHARACTER had only Stage 9 Full-Manuscript
  Continuity Audit (fiction-only, partial coverage, named
  in the taxonomy as COVERED only for COHERENCE+CHARACTER
  intersection). With v2.7.34, CHARACTER has its first
  primary-domain audit; CHARACTER status: COVERED.
- **Subagent-hallucination cascade** — subagent claims
  evidence at non-existent chapters or for characters not
  in the audited set. Caught by the HARD GATE.

## See also

- `canon-validation-taxonomy.md` — the 10-domain index;
  CHARACTER primary-domain table now lists this audit
- `validate-dispatcher.md` Step 4b — the Class B Dispatch
  Protocol (two-phase flow); this audit is the third to use it
- `injury-accumulation.md` (v2.7.32) — first Class B audit;
  the reference implementation this spec follows
- `leitmotif-tracker.md` (v2.7.33) — second Class B audit;
  the same dispatch model
- `subagent-output-verification.md` — the HARD GATE applied
  to subagent returns
- `silent-failure-audit.md` — catalog of drift-failure shapes;
  this audit adds row 30
