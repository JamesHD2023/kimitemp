---
name: byo-canon-checklist
description: "Canonical layout for the source-canon/ subfolder when using Bring Your Own Canon (Architect mode). Tells users exactly what files to drop in and how to organise them so the engine's Step 0 absorption can extract their canon completely. Companion to byo-canon.md."
version: "2.6.11"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Bring Your Own Canon — Source Material Checklist

This is the canonical layout for the `source-canon/`
subfolder used by the **Use My Worldbuilding** flow (see
`byo-canon.md`). The engine's Outline Builder Step 0
absorbs everything in this folder as authoritative canon
before any outline construction begins.

## Where it goes

`source-canon/` lives at the top level of your project
folder, alongside `manuscript/`, `marketing/`, and
`engine-data/`:

```
~/Documents/Ideorix-Projects/[Title]/
├── source-canon/          ← YOUR prior creative work (read-only canon)
│   ├── worldbuilding/
│   ├── characters/
│   ├── voice-guide.md
│   ├── samples/
│   └── locked-scenes.md
├── manuscript/            ← engine output
├── marketing/             ← engine output
├── engine-data/           ← engine state
└── project-config.md      ← project metadata
```

The `source-canon/` folder is **read-only canon**. The
engine reads from it and never writes back. Your prior
creative work is preserved exactly as you authored it.

## What to put in each subfolder

### `worldbuilding/`

One or more files describing your world. Markdown is
preferred; plain text or Word documents (`.docx`) also
work. Common breakdown:

```
worldbuilding/
├── geography.md          ← maps, regions, climate, distances
├── political-structure.md ← factions, governance, power blocs
├── magic-system.md       ← rules, costs, limits (or "tech-system.md" for SF)
├── culture.md            ← customs, dress, food, language, religion
├── history.md            ← timeline, prior events shaping the present
└── setting-bible.md      ← consolidated world reference
```

Or, for shorter projects, a single combined worldbuilding
file covering everything is fine.

**What the engine extracts from these files (Step 0):**
- Geography (regions, distances, travel times)
- Power systems (rules, costs, limits)
- Factions, institutions, political structures
- Hard world constraints ("no teleportation", "magic has
  a cost", "the wall cannot be crossed")
- Cultural details (food, dress, language, customs)
- Timeline / historical events
- Era and social structure

**What it explicitly does NOT do:**
- Invent additional worldbuilding silently
- Modernise or simplify your world rules
- Fill gaps with genre conventions if your canon is silent
  on a question — instead, the engine asks you

### `characters/`

One file per major character is the cleanest layout, but a
single combined characters file (e.g., a `characters` markdown
document) with named sections per character also works.
Format:

```
characters/
├── 01-protagonist.md       ← the lead character
├── 02-deuteragonist.md     ← second lead / love interest / partner
├── 03-antagonist.md        ← primary opposition
├── 04-supporting-cast.md   ← multiple secondary characters
└── relationships.md        ← key relationship dynamics
```

**What each character profile should include:**

```
# {Character Name}

## Personality
- Core traits (verbatim, not paraphrased)
- What this character IS (specific, not abstract)
- What this character ISN'T (explicit negatives — "not
  brooding", "never cruel", "doesn't suffer fools")

## Voice / speech patterns
- Word choice tendencies
- Verbal tics, catchphrases, vocabulary level
- How they speak under pressure vs. at ease

## Physical description
- (If specified — engine doesn't invent)

## Relationships
- Connections to other named characters

## Arc notes (if specified)
- Any character growth the user has explicitly designed
- Note: the engine does NOT add arcs the user hasn't
  specified
```

**What the engine extracts from these files (Step 0):**
- Verbatim character traits (do NOT paraphrase, simplify,
  or reinterpret in extraction)
- Voice/speech patterns
- Physical descriptions
- Relationships to other characters
- Arc notes (only what the user has specified)
- Explicit negatives ("not brooding", "never cruel")

**What it explicitly does NOT do:**
- Add psychological frameworks the user hasn't specified
  (no "survivor's guilt", "misread self-image", etc.)
- Reframe character traits as "more interesting" versions
- Flatten warm characters to easier-to-write brooding
  versions
- Project arcs onto characters who don't have them

### `voice-guide` file

A single file describing the prose voice you want for the
manuscript. Common structure:

```
# Voice Guide for {Title}

## POV and tense
- Third-limited / first-person / etc.
- Past / present
- POV character or rotation

## Prose register
- Vocabulary level
- Sentence architecture (short / long / varied)
- Description density

## What the voice IS
- Specific qualities you want sustained

## What the voice ISN'T
- Specific qualities you want avoided

## Tone constraints
- The book IS: warm / tense / literary / cosy / etc.
- The book ISN'T: grimdark / YA / camp / etc.
```

**What the engine extracts from this file (Step 0):**
- POV type and tense
- Prose register (vocabulary level, sentence
  architecture, description density)
- What the voice IS and ISN'T
- Tone constraints

### `samples/`

Pre-written passages or sample scenes that demonstrate the
prose voice you want. These are **STYLE references, not
PLOT references**. The engine will not use them as
structural tentpoles — only as voice calibration.

```
samples/
├── 01-opening-paragraph.md
├── 02-character-introduction.md
├── 03-dialogue-sample.md
├── 04-action-sequence.md
└── 05-quiet-moment.md
```

Each sample should be 200-2000 words of finished or
near-finished prose. The engine reads these to calibrate
its voice imitation, not to anchor its plot.

**What the engine does with samples (Step 0):**
- Calibrates prose register to match the samples
- Identifies what each sample DEMONSTRATES (style, not
  plot)
- Notes the variety of registers across samples (e.g.,
  intimate quiet vs. high-tension action)

**What it explicitly does NOT do:**
- Use samples as plot points to slot into the outline
- Reverse-engineer a story from sample scenes
- Treat sample scenes as locked plot beats

If you have scenes you want to LOCK as plot points, those
go in the locked-scenes file (described next) — not in
`samples/`.

### `locked-scenes` file

Optional but recommended. This is where you list scenes
that MUST appear in the manuscript. From v2.7.0 onward,
the Outline Builder uses these as the SEED for outline
construction (must-exist scenes anchor the chapter
structure rather than being slotted into a pre-built
template).

Format:

```
# Locked Scenes for {Title}

## Scene 1: {Name / Description}

- **What happens:** [3-5 sentences describing the scene]
- **Where it happens:** [location]
- **Who is present:** [characters]
- **Why it must exist:** [what story-truth this scene
  carries — character revelation, plot turn, thematic
  payoff, etc.]
- **Chronological position:** [must be early / middle /
  late, or flexible]
- **Tonal register:** [how this scene should feel]
- **Required precursors:** [what setup makes this scene
  land]
- **Required consequences:** [what must change after this
  scene]

## Scene 2: ...
```

You can list scenes in any order — chronological or by
importance. The engine will work out optimal placement.

**What the engine does with locked-scenes.md (Step 0):**
- Reads each scene as a GOAL the outline must build
  toward — NOT an ANCHOR slotted into structural
  positions
- Notes each scene's chronological constraint and
  precursor / consequence requirements
- (v2.7.0+) Uses scenes as the SEED for outline
  construction in Step 9.5

**What it explicitly does NOT do:**
- Treat locked scenes as plot tentpoles with summary
  filler between them (that's the documented "greatest
  hits album" failure mode)
- Override locked scenes for genre convention reasons
  without surfacing the conflict to the user
- Combine multiple locked scenes into a single chapter
  unless you've authorised it

## What happens if `source-canon/` is missing or partial

**No `source-canon/` at all:** the BYO-canon flow halts and
asks the user where their material is. Without canon, there
is nothing for Architect mode to anchor to — and the engine
should not silently fall back to Creator mode (where it
would invent characters and world). Instead, the engine
offers two alternatives:
- "Move to Write a New Book" (Creator mode, engine
  originates)
- "I'll add my canon now and re-run BYO" (user adds files,
  flow re-runs)

**`source-canon/` exists but some subfolders are empty or
missing:** the engine flags the gaps explicitly and asks
how to proceed:
- "I see worldbuilding/ and characters/ but no
  voice-guide.md. Two options: (a) the engine builds a
  voice profile from sample scenes if you have any in
  samples/, (b) you write the voice guide now and re-run."
- "I see characters/ but only one file (the protagonist).
  Should I work with just this character, or do you have
  more I should add first?"

**Files in non-canonical formats** (e.g., a Word `.docx` of
your worldbuilding instead of Markdown): the engine reads
them via the same Read tool (Word documents work via the
plugin's standard parsing). No conversion needed.

## Quick-start template

If you don't have your material organised yet, here's the
minimal viable layout to get the BYO flow running:

```
source-canon/
├── worldbuilding.md      ← single file with everything about your world
├── characters.md         ← single file with named sections per character
├── voice-guide.md        ← what the prose should sound like
└── locked-scenes.md      ← (optional) scenes that must appear
```

The engine prefers the more granular layout (separate files
per character, separate files per worldbuilding aspect) for
larger projects, but the minimal layout works fine for
shorter works.

## Validation gate

When the BYO-canon flow runs Step 0, it produces a
**Source Material Audit** report that confirms what the
engine found:

```
SOURCE MATERIAL AUDIT
─────────────────────
Worldbuilding files:    [N files, total word count]
Character profiles:      [N characters identified]
Voice guide:             [present / missing]
Sample passages:         [N samples, total word count]
Locked scenes:           [N scenes identified]

CANON CONSTRAINTS EXTRACTED:
  Characters with locked traits:  [N]
  World rules:                    [N]
  Locked scenes (goals):          [N]
  Voice register specifications:  [N]
  Tone constraints:               [N]

Status: READY FOR ARCHITECT MODE / NEEDS USER INPUT
```

If status is **NEEDS USER INPUT**, the engine surfaces the
specific gaps and asks how to proceed. If status is
**READY FOR ARCHITECT MODE**, the engine displays the full
constraint checklist for user confirmation, then locks the
constraints and proceeds to outline construction.

## See also

- `byo-canon.md` — the BYO-canon entry-point spec
- `outline-builder.md` § Step 0 — Source Material
  Absorption protocol (full)
- `outline-builder.md` § Anti-Rewriting Rule — the
  Architect-mode binding that prevents canon override
- `core-pipeline.md` § File Location Discipline — canonical
  project folder structure
