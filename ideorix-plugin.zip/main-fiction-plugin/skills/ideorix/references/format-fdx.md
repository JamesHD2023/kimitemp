---
name: format-fdx
description: "FDX (Final Draft XML) export — the inverse of the screenplay-importer FDX parser. Emits a Final Draft-compatible .fdx file from the engine's normalised scene list so a screenplay round-trips losslessly between Ideorix and Final Draft / WriterDuet / Highland (which all read the FDX schema)."
version: "2.7.98"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# FDX (Final Draft XML) Export

## Purpose

Generate a Final Draft-compatible `.fdx` file from the engine's
normalised screenplay scene list. This is the inverse of the FDX
parser documented at `screenplay-importer.md § FDX parser (Final
Draft XML)` — emitter and parser share the same schema, so a
screenplay imported from a `.fdx`, edited in Ideorix, and exported
back to `.fdx` round-trips losslessly.

FDX is the de facto industry-standard interchange format. Final
Draft, WriterDuet, Highland, and Fade In all read it; many studio
submission portals require it specifically.

## When this runs

Invoked from the Screen Studio **Format & Export** menu item
(SKILL.md item 9) when the user requests `.fdx` output. Runs
after the 10-pass Pre-Delivery Sweep has passed (the same
delivery-ready precondition as the Fountain / PDF / DOCX export
paths).

## Output schema

The emitter produces plain XML matching the schema the importer
already specifies. Newer Final Draft versions read both ZIP-
wrapped and plain XML — the emitter writes **plain XML** (no ZIP
wrapper) for maximum compatibility, simplicity, and diffability;
Final Draft opens plain `.fdx` without complaint.

Root structure (mirror of `screenplay-importer.md:272–303`):

```xml
<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<FinalDraft DocumentType="Script" Template="No" Version="1">
  <Content>
    <Paragraph Type="Scene Heading">
      <Text>INT. KITCHEN - DAY</Text>
    </Paragraph>
    <Paragraph Type="Action">
      <Text>Ben crosses to the sink.</Text>
    </Paragraph>
    <Paragraph Type="Character">
      <Text>BEN</Text>
    </Paragraph>
    <Paragraph Type="Parenthetical">
      <Text>(softly)</Text>
    </Paragraph>
    <Paragraph Type="Dialogue">
      <Text>I already told you.</Text>
    </Paragraph>
    <Paragraph Type="Transition">
      <Text>CUT TO:</Text>
    </Paragraph>
  </Content>
  <TitlePage>
    <Content>
      <Paragraph><Text>{TITLE}</Text></Paragraph>
      <Paragraph><Text>by</Text></Paragraph>
      <Paragraph><Text>{AUTHOR}</Text></Paragraph>
    </Content>
  </TitlePage>
</FinalDraft>
```

## Paragraph Type mapping (engine scene-list → FDX)

The engine's normalised scene list (from the Writer / from a
prior import) carries each scene as `{slugline, action,
characters_present, dialogue: [{speaker, parenthetical, text,
dual_with?}], transition_out?, original_number?}`. Each field
maps to a Paragraph Type on emission:

| Engine field | FDX Paragraph Type | Notes |
|--------------|--------------------|-------|
| `scene.slugline` | `Scene Heading` | Emit verbatim — `INT. KITCHEN - DAY`. If `original_number` is preserved, emit `Number="<n>"` attribute (round-trip importer field) |
| `scene.action` (each paragraph) | `Action` | One `<Paragraph Type="Action">` per action paragraph. Preserve paragraph boundaries — do not collapse into one Text |
| `scene.dialogue[i].speaker` | `Character` | Uppercase; preserve `(O.S.)` / `(V.O.)` suffix if the engine stored it |
| `scene.dialogue[i].parenthetical` | `Parenthetical` | Only emit if non-empty. Always between Character and Dialogue |
| `scene.dialogue[i].text` | `Dialogue` | Verbatim; multi-line dialogue stays as one `<Text>` with newlines preserved |
| `scene.transition_out` | `Transition` | Only emit if set. `CUT TO:` / `FADE OUT.` / `SMASH CUT TO:` etc. |

## Edge cases (each one's parser-side handling is the truth-source)

These mirror the FDX quirks documented in
`screenplay-importer.md:358–371`:

1. **Dual dialogue.** When two dialogue entries carry the same
   `dual_with` group id, wrap them in
   `<Paragraph DualDialogue="1">`. Emit the two Character /
   Parenthetical? / Dialogue triplets sequentially inside the
   wrapper, left then right. The parser's left-then-right read
   order is the inverse contract.
2. **Scene numbers** (`Number` attribute). If the engine stored
   `scene.original_number` from an earlier import, emit
   `<Paragraph Type="Scene Heading" Number="<n>">`. If the
   number was assigned by the engine (no prior import), do NOT
   emit a Number attribute — let Final Draft re-number on open.
3. **Revision colours / RevisionID** — not emitted. The engine
   does not track Final-Draft-specific revision colours; the
   parser ignores them on import.
4. **ScriptNote / Boneyard** — not emitted. The engine does not
   carry these.
5. **Shot / General types** — the parser maps these to action on
   import. The emitter writes everything classified as action
   as `Type="Action"` — there is no way to recover whether the
   author originally typed `Shot` or `Action`.

## XML hygiene

- **Encoding:** UTF-8. Emit the XML declaration verbatim
  (`<?xml version="1.0" encoding="UTF-8" standalone="no" ?>`).
- **Escaping:** all `<Text>` content MUST escape `&`, `<`, `>`,
  `"`, `'` using the standard XML entities (`&amp;`, `&lt;`,
  `&gt;`, `&quot;`, `&apos;`). The parser uses a standard XML
  parser which expects escaped entities; emitting raw characters
  produces an invalid FDX that Final Draft will refuse to open.
- **Whitespace:** indent for readability (2 spaces per level)
  but never inside `<Text>` element content — Final Draft
  preserves text whitespace exactly.
- **Empty elements:** never emit
  `<Paragraph Type="..."></Paragraph>` with empty Text — skip
  the paragraph entirely. (Final Draft tolerates empties; the
  parser would create a junk dialogue/action line.)

## Title page

Populate `<TitlePage>` from the engine's title-page metadata
(`title`, `author`, `draft_date`, optional `contact_info`):

```xml
<TitlePage>
  <Content>
    <Paragraph><Text>{TITLE}</Text></Paragraph>
    <Paragraph><Text>by</Text></Paragraph>
    <Paragraph><Text>{AUTHOR}</Text></Paragraph>
    <Paragraph><Text>{DRAFT_DATE}</Text></Paragraph>
    <Paragraph><Text>{CONTACT_INFO}</Text></Paragraph>
  </Content>
</TitlePage>
```

The parser's title-page heuristic (look for `by <Name>` → author,
preceding line → title, date pattern → draft date) recovers these
fields on round-trip.

## File delivery

The exporter writes the FDX file to:

```
{project-root}/deliverables/{Title}.fdx
```

Same directory as the other delivery formats. The filename uses
the project title with spaces and punctuation passed through —
Final Draft accepts spaces in `.fdx` filenames.

## Verification

After emission, verify the file is a valid FDX:

1. **Parse the just-emitted file** with the FDX parser
   (`screenplay-importer.md § FDX parser`) and confirm:
   - Parsing succeeds without error
   - The reconstructed scene count matches the input scene count
   - The reconstructed dialogue count matches the input dialogue
     count
   This is the round-trip property the emitter exists to provide;
   verifying it catches schema drift between emitter and parser.
2. **XML well-formedness.** Run `xmllint --noout <file>.fdx` (if
   available) or any XML parser; a non-zero exit means the
   emitter wrote invalid XML and Final Draft will refuse to open
   the file. Treat as a HARD GATE on the export step.

## Routing

- **Menu:** `SKILL.md` § Screen Studio item 9 "Format & Export"
- **Sibling format specs:** `format-fountain.md` (Fountain),
  `format-pdf.md § Screenplay PDF Layout`, `format-docx.md §
  Screenplay DOCX Layout`
- **Inverse:** `screenplay-importer.md § FDX parser (Final Draft
  XML)` — the parser this emitter is the inverse of

## Silent-Failure Audit

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Write (the `.fdx` file) | "Write succeeded" | Subdir flush failure / partial write / encoding mojibake | File-Write Hygiene bash-direct write protocol per `core-pipeline.md`; PostToolUse Engine-Data Integrity Hook (`post-engine-data-write-hook.sh`) re-verifies if the write lands under `engine-data/` (the canonical delivery path is `deliverables/` which is outside that scope — so the round-trip parse-back in the Verification section above is the gate that catches partial writes) |
| Parse-back round-trip | "Round-trip parsed N scenes" | Scene count diverges from input, dialogue count diverges, or parse error in our own emitter's output | The Verification step above re-parses the emitted file with the importer; a count mismatch or parse error BLOCKS the export and surfaces the diff to the user (the emitter writes a `.fdx` that even our own parser refuses, the file is not delivery-ready) |
| XML well-formedness | "xmllint exit 0" | Unescaped `&` / `<` in dialogue text producing invalid XML | Mandatory entity-escaping in the emitter (see XML hygiene above); HARD GATE on `xmllint --noout` when available |
