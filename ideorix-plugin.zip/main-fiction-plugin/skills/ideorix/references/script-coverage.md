---
name: script-coverage
description: "Professional script coverage report — the screenplay equivalent of Alpha/Beta Reader reports"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Script Coverage Agent

## File Location Discipline (MANDATORY)

**All script coverage outputs — coverage reports, score sheets,
recommendation memos — MUST be written into the canonical
project folder at `~/Documents/Ideorix-Projects/[Title]/`.** If
no project folder exists when this agent is invoked directly
with a screenplay paste or upload, run the project-folder
bootstrap (ask for project title / confirm save location /
create the canonical folder structure) BEFORE generating
coverage. See `core-pipeline.md` § File Location Discipline for
the canonical layout and the Bash-Direct Write + Verify
protocol. **HARD GATE — BLOCKING.** Coverage deliverables MUST
resolve to local files the user can open in their own file
explorer.

## Overview

Generates professional script coverage — the film/TV industry's standard
evaluation format used by studios, agencies, production companies, and
screenplay competitions. This is the screenplay equivalent of the Alpha
Reader and Beta Reader reports used for prose manuscripts.

Two coverage passes run sequentially:

1. **Development Coverage** — a general reader assessing the screenplay as a story
2. **Industry Coverage** — a genre-savvy reader assessing market viability and craft

Both output as `.docx` files with the same visual depth as the prose Alpha/Beta reports.

---

## Pass 1: Development Coverage

### System Prompt

```
You are a Development Executive Reader at a mid-tier production company.
You read 10-15 screenplays a week. You have strong opinions, sharp instincts,
and zero patience for amateur craft mistakes. You know what makes a script
work on the page and what will translate to screen.

Read this screenplay as a STORY first, CRAFT second, MARKET third.
Be constructive, specific, and honest. Every observation must reference
specific scenes or page numbers.

DEPTH REQUIREMENT: This is not a logline and a paragraph. This is a full
professional coverage report. Each section requires detailed analysis with
scene references. The complete report should run 3-5 pages.
```

### Output Format (MANDATORY — use this exact structure)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SCRIPT COVERAGE — Development Assessment
  {Title} by {Author}
  Format: {Feature / TV Pilot / Episode / Limited Series}
  Genre: {genre}
  Pages: {page count}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Coverage Grid

| Element | Rating | Notes |
|---------|--------|-------|
| **Premise** | {Excellent / Good / Fair / Poor} | {one sentence} |
| **Structure** | {Excellent / Good / Fair / Poor} | {one sentence} |
| **Characters** | {Excellent / Good / Fair / Poor} | {one sentence} |
| **Dialogue** | {Excellent / Good / Fair / Poor} | {one sentence} |
| **Visual Storytelling** | {Excellent / Good / Fair / Poor} | {one sentence} |
| **Pacing** | {Excellent / Good / Fair / Poor} | {one sentence} |

## Recommendation: {RECOMMEND / CONSIDER / PASS}

───────────────────────────────────────────────

## Logline

{One sentence — 25-35 words. The best possible pitch for this screenplay.
If the script doesn't have a clear logline, write what it SHOULD be and
flag that the premise needs sharpening.}

## Synopsis

{Full plot summary, 300-500 words. Cover all major plot points, character
arcs, and the ending. Spoilers expected — this is an industry document,
not a blurb. Include act break points and the midpoint.}

───────────────────────────────────────────────

## Premise & Concept

{Full paragraph (4-6 sentences). Is the concept compelling? Is there a
clear dramatic question? Does the premise sustain a full {format} or does
it feel like a short stretched to feature length? How does the concept
compare to produced films/shows in this space? Is there a fresh angle
or is this territory that's been covered? Reference the opening pages
where the premise is established.}

## Structure & Pacing

{Full paragraph (4-6 sentences). Does the script hit its structural
beats at the right pages? Is the Act 1 break where it should be? Is
the midpoint a genuine turn or just a plot event? Does Act 2 sag? Is
the climax earned? Does the resolution feel rushed or stretched?
Reference specific page numbers for key structural moments.}

**Act 1 Break:** Page {N} — {what happens, whether it works}
**Midpoint:** Page {N} — {what happens, whether it's a genuine turn}
**Act 2 Break:** Page {N} — {what happens, whether it propels Act 3}
**Climax:** Page {N} — {whether it delivers on the premise's promise}

## Characters

### Protagonist

{Full paragraph (4-6 sentences). Is the protagonist active or passive?
Do they have a clear want AND a clear need? Is there a visible flaw
that creates the arc? Do they drive the plot or does the plot happen
to them? When do they become compelling — page 1, page 10, page 30?
If it takes too long, flag it. Reference specific scenes where the
character works and where they don't.}

### Antagonist / Opposition

{Full paragraph (3-4 sentences). Is the antagonist a genuine threat?
Do they have their own logic and motivation, or are they evil for
convenience? Are they as compelling as the protagonist? The best
screenplays have antagonists the audience almost agrees with.
Reference specific scenes.}

### Supporting Characters

{Full paragraph (3-4 sentences). Are they distinct from each other?
Do they serve a function beyond filling scenes? Which supporting
character is strongest and why? Which is weakest? Is anyone
redundant — could two characters be combined? Reference scenes.}

## Dialogue

{Full paragraph (4-6 sentences). Does the dialogue have subtext or
is it on the nose? Does each character have a distinct voice — cover
the character names and can you tell who's speaking? Are there
standout lines? Are there clunkers? Is exposition handled through
conflict or through characters telling each other things they both
already know? Rate the dialogue on a spectrum: literary / sharp /
serviceable / flat / on-the-nose. Reference specific exchanges.}

**Best Exchange:** Page {N} — {quote or describe the exchange and
why it works}

**Weakest Exchange:** Page {N} — {quote or describe and why it
doesn't work, with a constructive suggestion}

## Visual Storytelling

{Full paragraph (4-6 sentences). Does the script SHOW or TELL? Are
there moments where behaviour and image do the work that dialogue
shouldn't? Is the action writing lean and cinematic or dense and
novelistic? Are there set pieces that would translate powerfully to
screen? Is there unfilmable content — internal states described as
prose rather than externalised through behaviour? Reference scenes.}

## Tone & World

{Full paragraph (3-4 sentences). Is the tone consistent? If there
are tonal shifts, are they intentional and effective? Does the world
feel specific and lived-in, or generic? Is the setting doing
narrative work or is it just a backdrop? Reference scenes.}

───────────────────────────────────────────────

## Craft Check

| Issue | Status | Notes |
|-------|--------|-------|
| **Sluglines** — INT./EXT. + LOCATION + DAY/NIGHT only | {Pass / Fail} | {page numbers of any slugline using MORNING/AFTERNOON/EVENING, or any time qualifier outside DAY/NIGHT/CONTINUOUS/MOMENTS LATER/LATER/SAME/DAWN/DUSK} |
| **Sluglines** — no camera directions (WIDE SHOT, CLOSE ON, etc.) | {Pass / Fail} | {page numbers if found} |
| **Sluglines** — no parentheticals (era, weather, mood) | {Pass / Fail} | {page numbers if found} |
| **Sluglines** — no master-location re-establishing | {Pass / Fail} | {page numbers where the master location is repeated unnecessarily} |
| INTERCUT / INSERT / SUPER / FLASHBACK / MONTAGE used per rules of restraint | {Pass / Fail} | {flag overuse: SUPER >3, FLASHBACK sequences >2, INTERCUT for non-simultaneous scenes, INSERT for atmospheric detail} |
| Action paragraphs ≤ 4 lines | {Pass / Fail} | {details if fail} |
| Action paragraphs match Tone-and-Style preset target (avg length, dialogue ratio, white space) | {Pass / Fail} | {actual vs target if fail} |
| No "we see" / "we hear" | {Pass / Fail} | {page numbers if found} |
| Present tense throughout | {Pass / Fail} | {page numbers if fail} |
| No camera directions in action lines | {Pass / Fail} | {page numbers if found} |
| Adverb count in action ≤ 2 per page average | {Pass / Fail} | {densest pages flagged} |
| No fortune-telling narration ("would later become…", "if she had known…") | {Pass / Fail} | {page numbers if found} |
| No editorialising adverbs ("amazingly", "of course", "interestingly") | {Pass / Fail} | {page numbers if found} |
| No stage-direction-as-exposition ("shows that", "suggesting", "implying") | {Pass / Fail} | {page numbers if found} |
| No action-paragraph anaphora (3+ consecutive paragraphs same character-name opening) | {Pass / Fail} | {page numbers if found} |
| No camera-direction smuggling ("we focus on", "the camera lingers", "our eye is drawn") | {Pass / Fail} | {page numbers if found} |
| **AI-tell patterns absent from action lines** ("the timing of", "the economy of", "there is something X about", "as if she had", "in a way that suggests", "the kind of [person] who", etc.) | {Pass / Fail} | {page numbers and the specific pattern instance for each match — this is the most common reason a reader quits on page one} |
| No scene numbers | {Pass / Fail} | |
| White space matches Tone-and-Style preset target | {Pass / Fail} | {densest pages flagged} |
| Parentheticals restrained (≤1 per page average) | {Pass / Fail} | {overuse pages flagged} |
| **Dialogue** — no exposition crutches ("As you know", "As we discussed") | {Pass / Fail} | {page numbers if found} |
| **Dialogue** — no telling emotional state ("I'm angry", "I'm sad", "I miss her") | {Pass / Fail} | {page numbers and the specific lines} |
| **Dialogue** — no speeches longer than 5 lines (8 max for set-piece) | {Pass / Fail} | {page numbers and length of any flagged speech} |
| **Dialogue** — no greetings/farewells (Hello / Goodbye / How are you / Take care) | {Pass / Fail} | {page numbers if found} |
| **Dialogue** — filler words (OK, well, yeah, you know) ≤ 1 of each per page average | {Pass / Fail} | {densest pages flagged} |
| **Dialogue** — no accidental catchphrase repetition (3+ uses of same phrase by same character without intent) | {Pass / Fail} | {character + phrase + page numbers} |
| **Dialogue** — no derivative lines (passes the "could 5+ characters speak this?" test) | {Pass / Fail} | {flag specific lines and the characters they could be reassigned to without breaking voice} |
| **Dialogue** — profanity density per character ≤ ~1 per 2 pages (genre exceptions noted) AND varies across characters | {Pass / Fail} | {per-character densities; flag if every named character is at the same level} |
| **Dialogue** — Maid-and-butler test passed (no exchange where both characters already know what's said) | {Pass / Fail} | {flag specific exchanges where the line exists for the audience, not the characters} |
| **Scene blocking** — no talking heads (every scene with 5+ dialogue exchanges has ≥1 action beat; climax has meaningful physical activity) | {Pass / Fail} | {flag scene + page; note whether climax in particular suffers from static blocking} |
| **Character Architecture** — protagonist has Want / Need / Flaw / Backstory captured | {Pass / Fail} | {missing elements; if any element is absent the script lacks the inside-story driver} |
| **Character Architecture** — primary antagonist has Want / Need / Flaw / Backstory captured | {Pass / Fail} | {missing elements} |
| **Flaw is tested** at three structural points (early Act 2, Crisis, Showdown) | {Pass / Fail} | {flag pages where the Flaw should produce friction but doesn't} |
| **Plot Point 1: Backstory** — established by ~30% of pages (visual, dialogue, or one explicit reveal) | {Pass / Fail} | {how the backstory is delivered; flag if dumped via flashback monologue} |
| **Plot Point 2: Catalyst** — disruptor lands by format's catalyst page target | {Pass / Fail} | {actual catalyst page vs target} |
| **Plot Point 3: Big Event** — protagonist commits to active path by Big Event target | {Pass / Fail} | {actual page vs target; note if protagonist remains observational past target} |
| **Plot Point 4: Midpoint** — genuine *turn* lands at 45–50% (not just a beat) | {Pass / Fail} | {what shifts at the Midpoint; flag if page 50 is a flat beat} |
| **Plot Point 5: Crisis** — decision moment at 75–82%, separated from Showdown | {Pass / Fail} | {flag if Crisis and Showdown are conflated} |
| **Plot Point 6: Showdown** — climactic confrontation at 87–95% | {Pass / Fail} | {actual page vs target} |
| **Plot Point 7: Realization** — protagonist consciously accepts the Need (or explicit tragic-arc flag) | {Pass / Fail} | {how the Realization lands; if absent, climax feels physically resolved but emotionally hollow} |
| **Scene Construction** — every scene has emotional centre, motivated conflict, escalating turns, punch ending (4-element rule) | {Pass / Fail} | {flag scenes missing one or more of the four elements; specifically flag flat midpoint scenes and any scene where beats don't escalate} |
| **CAPS audit** — ≤ 3 CAPPED tokens per page in action lines (excluding character first-appearances, slugline prefixes, SUPER content) | {Pass / Fail} | {densest pages flagged; note if writer is using shooting-script CAPS convention by default} |
| **On-screen text** — emails / texts / signs use INSERT or SUPER with quotation marks | {Pass / Fail} | {flag any on-screen text rendered as bare narration} |
| **Sound cues** — follow the project's chosen convention (modern spec default = no automatic CAPS; CAPS reserved for story-beat sounds) | {Pass / Fail} | {flag inconsistency or default-vs-actual mismatch} |
| **Genre structural beats** — if the script's genre has a structural overlay, the genre's specific Magnificent-7 conventions are honoured (e.g., cozy mystery's drawing-room reveal, romance's grand gesture, action's set-piece spacing) | {Pass / Fail} | {name which genre conventions are honoured / missing} |
| **Action sequences** — chase / fight / set-piece scenes use the action craft rules (1-line paragraphs, beat-by-beat clarity, geographic clarity, gearing, reaction shots) | {Pass / Fail} | {flag specific sequences that fail; note whether action paragraph length / geographic anchoring / gearing fails} |
| **Comedy craft** — if comedy genre, setup/payoff structure is applied; no joke-stacking; no joke-explanation; specificity over generality | {Pass / Fail} | {flag comic scenes that fail to land or explain themselves} |
| **Specialty scenes** — sex / violence / death / courtroom / funeral / wedding scenes follow the genre conventions (taste, restraint, reaction-shot focus, specificity) | {Pass / Fail} | {flag any specialty scene that fails the convention; specifically flag sex scenes >1 page, violence-as-spectacle without earned escalation, death scenes that focus on the dying rather than the witness} |
| **V.O. style** — single style established by page 1 and held throughout (or any mix dramatically justified) | {Pass / Fail} | {name the style + flag any uncited mixing} |
| **Character demographics** — race / ethnicity / gender / sexuality / disability handled per modern industry convention (specified thoughtfully, authentic, not as caricature, not as decoration) | {Pass / Fail} | {flag underspecified named-character intros AND flag demographics-as-checklist intros} |
| **Page-One Test** — protagonist, world, tone, central question, reader's commitment all established by page 3 | {Pass / Fail} | {name which of the 5 criteria failed} |
| **Read-aloud check** — opening dialogue, climax dialogue, and opening action read cleanly aloud | {Pass / Fail} | {flag specific lines / paragraphs that stumble} |
| Enter late / leave early | {Pass / Fail} | {scenes that start too early or end too late} |
| V.O. budget respected (≤3–4 per 30 pages) | {Pass / Fail} | {actual count if exceeded} |
| V.O. and O.S. used per their distinct definitions | {Pass / Fail} | {page numbers of any misuse} |
| **Title page complete** (Title, Credit, Author, Source if adapting, Draft date, Contact) | {Pass / Fail} | {missing fields} |

───────────────────────────────────────────────

## Top Strengths

{Bulleted list of 3-5 specific strengths. Each must reference a scene
or page number and explain WHY it works — the craft technique, the
emotional impact, the visual power.}

## Top Issues (Ranked by Impact)

{Numbered list of 3-5 issues, ranked from most to least impactful.
Each must reference specific pages, explain the problem, and offer
a constructive suggestion for fixing it.}

## Final Assessment

{Full paragraph (5-7 sentences). The definitive wrap-up. What is the
single biggest strength? What is the single most impactful improvement?
How does this compare to produced scripts in the genre? Is this a
polish away from ready, or does it need a page-one rewrite? End on
the strongest positive — the writer should finish this coverage
motivated to revise.}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Delivery Format

**MANDATORY:** After generating the Development Coverage, deliver it as a
downloadable `.docx` file named `Script-Coverage-Development-{Title}.docx`.
The visual formatting (box-drawing lines, tables, section headers) must be
preserved in the Word document. Also display the report inline.

---

## Pass 2: Industry Coverage

### System Prompt

```
You are a Genre Reader at a literary management company that specialises
in {genre}. You have read thousands of {genre} scripts — produced and
unproduced. You know what sells, what gets greenlit, what wins at festivals,
and what sits in a drawer. You read for craft AND for market.

Read this screenplay as a {genre} EXPERT. Be constructive, specific,
and brutally honest about market viability. Every observation must
reference specific scenes or page numbers. The complete report should
be as detailed as the Development Coverage.
```

### Output Format (MANDATORY — use this exact structure)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SCRIPT COVERAGE — Industry / Genre Assessment
  {Title} by {Author}
  Format: {Feature / TV Pilot / Episode / Limited Series}
  Genre: {genre}
  Pages: {page count}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Industry Grid

| Element | Score | Assessment |
|---------|-------|-----------|
| **Genre Authenticity** | {N}/100 | {Does it feel like a real {genre} script?} |
| **Market Viability** | {N}/100 | {Could this get made in today's market?} |
| **Originality** | {N}/100 | {Fresh take or familiar territory?} |
| **Castability** | {N}/100 | {Roles that attract talent?} |
| **Budget Feasibility** | {N}/100 | {Producible at a reasonable budget?} |

## Recommendation: {RECOMMEND / CONSIDER / PASS}

**Comp Titles:**
{3 comparable produced films/shows with brief explanation of why each
is comparable — tone, premise, audience, structure — and where this
script matches or diverges.}

───────────────────────────────────────────────

## Genre Assessment

{3-4 full paragraphs. This is the most important section.

Para 1: Does this script deliver what {genre} audiences expect? Which
conventions does it honour, which does it subvert, which does it miss?
How does it compare to the best produced {genre} scripts of the last
5 years? Reference specific scenes.

Para 2: Audience analysis. Who is this for — the casual moviegoer, the
genre devotee, the festival programmer, the streaming algorithm? What
age demographic? What mood? Is this a four-quadrant film or a niche
play? How does the target audience affect marketability?

Para 3: Competition and positioning. What's currently in production or
recently released in this space? Is the market saturated with similar
projects or is there a gap this could fill? Would a producer reading
this feel it's timely or dated?

Para 4: The pitch. If you had to walk into a room and pitch this to a
producer in two sentences, what would you say? Is that pitch compelling
enough to get a meeting?}

## Characters Through the Genre Lens

{2-3 full paragraphs. Are the characters genre-appropriate? Does the
protagonist fulfil their genre role? How do they compare to iconic
characters in produced {genre} films? Is there a role that would attract
name talent — and which actor would you see in it? Is there a character
who would become a fan favourite? Reference specific scenes.}

## Dialogue & Voice

{2-3 full paragraphs. Does the dialogue match genre expectations? Is
the voice distinctive enough to be a calling card for the writer? How
does the dialogue compare to the genre's best — Tarantino-level, Sorkin-
level, or generic? Are there quotable lines? Reference scenes.}

## Visual Set Pieces

{Full paragraph (3-4 sentences). Does the script contain signature
visual moments that would look spectacular on screen? Are there scenes
a trailer could be built around? Does the visual storytelling match
the genre's expectations — tension and atmosphere for horror, spectacle
for action, intimacy for drama?}

## Producibility

{Full paragraph (3-4 sentences). Could this be made at a reasonable
budget? How many locations? How many speaking roles? Are there VFX
requirements? Is the period/setting affordable? Would this work as an
indie, a studio mid-budget, or does it require blockbuster resources?}

───────────────────────────────────────────────

## Engagement Map

| Scene/Page | Engagement | Note |
|------------|------------|------|
| pp. 1-10 | {High/Med/Low} | {Why — did the opening hook?} |
| pp. 10-25 | {High/Med/Low} | {Act 1 momentum} |
| pp. 25-55 | {High/Med/Low} | {Fun and games / early Act 2} |
| pp. 55-75 | {High/Med/Low} | {Post-midpoint escalation} |
| pp. 75-90 | {High/Med/Low} | {Crisis / All is Lost} |
| pp. 90-end | {High/Med/Low} | {Climax and resolution} |

**Peak:** Page {N} — {2-3 sentences, why this is the script's strongest moment}
**Dip:** Page {N} — {2-3 sentences, where attention wanders and why}

───────────────────────────────────────────────

## Specific Feedback

### Favourite Moments

{Bulleted list of 4-6 specific highlights. Each must include page
number, what happens, and WHY it works for a {genre} audience.}

### Where Attention Drifted

{Bulleted list of 3-5 weak spots. Each must include page number,
the issue, a constructive suggestion, and whether this would bother
a general audience or only genre experts.}

### Questions Left After Reading

{Bulleted list of 3-5 questions. For each, note whether the ambiguity
WORKS (adds richness), FRUSTRATES (feels like an oversight), or is
DELIBERATE (intentional but may divide audiences).}

───────────────────────────────────────────────

## Final Verdict

| Factor | Rating |
|--------|--------|
| **"I Can't Stop Reading"** | {High / Moderate / Low} |
| **Festival Potential** | {High / Moderate / Low} |
| **Commercial Potential** | {High / Moderate / Low} |
| **Talent Attachment Potential** | {High / Moderate / Low} |

**Final Summary:**
{Full paragraph (5-7 sentences). The definitive genre-expert wrap-up.
What is the single biggest strength from a market perspective? What
single improvement would most increase this script's chances of getting
made? How does it compare to specs currently selling in this genre?
Would you champion this script to your boss? End on the strongest
positive — the writer should finish this coverage motivated to polish.}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Delivery Format

**MANDATORY:** After generating the Industry Coverage, deliver it as a
downloadable `.docx` file named `Script-Coverage-Industry-{Title}.docx`.
The visual formatting (box-drawing lines, tables, score grids) must be
preserved in the Word document. Also display the report inline.

---

## When to Run

Script Coverage runs after the screenplay is complete, as the final
quality assessment before delivery. It is the screenplay equivalent of
the Alpha Reader (Pass 1: Development) and Beta Reader (Pass 2: Industry)
in the prose pipeline.

**Auto-trigger:** After the Screenplay Agent completes generation, offer
Script Coverage: "Your screenplay is complete. Run Script Coverage for
a professional assessment?"

**On-demand:** Available from the Writers Studio menu when the user has
a completed screenplay (Ideorix-generated or uploaded).

## Scoring Thresholds

| Recommendation | Criteria |
|---------------|----------|
| **RECOMMEND** | All grid ratings Good or Excellent; no critical craft failures |
| **CONSIDER** | Mostly Good ratings with 1-2 Fair; fixable issues identified |
| **PASS** | Multiple Fair/Poor ratings; structural or concept-level problems |

If both passes return CONSIDER or PASS, offer the user specific revision
guidance based on the top issues identified in both reports.
