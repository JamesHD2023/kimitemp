---
name: quality-gate
description: "6 verification agent protocols with scoring schemas"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->
# Verification Agents Protocol

## Architect Mode Binding (when source canon is present — v2.7.0+)

**Mode detection:** Before assessing any chapter's prose, the
Quality Guardian reads `engine-data/project-config.md` for
the `architect_mode` flag (set by Outline Builder Step 0
when user-supplied source canon is absorbed).

When `architect_mode: true`, the Quality Guardian's
per-chapter verification extends to enforce canon fidelity.
For each chapter, the Guardian flags:

1. **Character drift from Step 0 profile.** Where chapter
   prose renders a character in ways inconsistent with the
   verbatim traits captured in Step 0 — e.g., a "quick to
   laugh" character written as silently observational, a
   "warm" character written as cold and distant — the
   Guardian flags this as **CANON DRIFT — CHARACTER
   FLATTENING** and produces specific examples (line
   numbers + the trait being violated).

2. **Voice drift from voice-guide.** Where chapter prose
   drifts from the voice register established in
   `source-canon/voice-guide` — wrong POV, wrong tense,
   wrong vocabulary level, wrong sentence architecture,
   description density mismatch — the Guardian flags this
   as **CANON DRIFT — VOICE REGISTER**.

3. **World-rule violation.** Where chapter prose violates
   a world rule established in Step 0 (magic system rule,
   geographic constraint, cultural detail), the Guardian
   flags this as **CANON DRIFT — WORLD RULE**.

4. **Unstated psychology projection.** Where chapter
   prose adds character psychology the user has not
   authorised (survivor's guilt, misread self-image,
   unprocessed trauma, etc.) — psychology that didn't
   come from Step 0 canon or the Architect's chapter
   brief — the Guardian flags this as **CANON DRIFT —
   PSYCHOLOGY PROJECTION**.

5. **MUST-EXIST chapter substance drift.** For chapters
   labeled `Chapter Type: MUST-EXIST` with `Serves: S{N}`,
   the Guardian cross-checks the chapter's prose against
   the corresponding scene entry in
   `engine-data/must-exist-scenes.md`. Where the prose
   delivers a substantively different scene (different
   cast, different setting, different narrative function),
   the Guardian flags this as **CANON DRIFT — LOCKED
   SCENE SUBSTITUTION**.

6. **CONNECTIVE chapter purpose drift.** For chapters
   labeled `Chapter Type: CONNECTIVE` with `Serves: Sets
   up S{N}; follows from S{M}`, the Guardian verifies the
   chapter prose explicitly does the setup / consequence
   work specified. Where the connective chapter degrades
   to summary-filler ("the protagonist reflected on what
   had happened") without the specific setup / consequence
   work the brief identified, the Guardian flags this as
   **CANON DRIFT — CONNECTIVE CHAPTER COLLAPSE**.

7. **Sample-scene over-deployment.** Where chapter prose
   lifts language from sample passages that the chapter
   brief did not authorise (i.e., the chapter is
   CONNECTIVE but the prose is paraphrasing sample passages
   as if the chapter were MUST-EXIST), the Guardian flags
   this as **CANON DRIFT — SAMPLE-AS-PLOT-TENTPOLE**.

The Guardian's per-chapter report includes a Canon Drift
section listing any flags. Stage 9 (Full-Manuscript
Continuity Audit) consolidates the per-chapter findings
into the manuscript-wide canon-fidelity ledger.

When `architect_mode: false` (or unset — Creator mode),
this binding is a no-op and the Quality Guardian operates
on standard verification dimensions only.

→ See `byo-canon.md`, `outline-builder.md` § Step 0,
`must-exist-scenes.md`, and `blueprint-protocol.md` §
Architect Mode Binding for the upstream protocols that
produce the canon Guardian verifies against.

## Verification Discipline Binding (when real-world anchors are present)

When the project anchors to real-world specifics, the
Quality Guardian agent operates under
`verification-discipline.md` for the real-world anchor
layer of each chapter. Per chapter, the Quality Guardian
re-verifies that real-world specifics in the prose
(real persons, real events, real legislation, real
statistics, real institutions) trace to VERIFIED entries
in `engine-data/verification-ledger.md` with pinned sources
that still resolve. The Quality Guardian flags:

- Specifics in prose that don't appear in the ledger
  (citation drift)
- Specifics that the bible has marked SPECULATIVE but
  which appear in prose without the required speculative-
  marker language (label drift)
- Quotations attributed to real persons without verbatim
  verification (Tier 1 violation)
- Material context omissions where the source's funding /
  COI / publication context changes interpretation but
  the prose omits it
- Footnote-only fix drift — when a citation correction
  has been applied to a footnote / endnote but the same
  misattribution still appears in the chapter prose body
  (the prose-mirror sweep failure mode). When applying any
  citation correction, the Quality Guardian MUST grep the
  entire chapter for the misattributed string(s) — author
  surnames, paper title fragments, dated phrasing — and
  apply the correction to ALL instances, not just the
  footnote. Re-grep after applying to confirm no
  misattributed strings remain in the chapter.

The Quality Guardian's per-chapter report includes a
Verification Discipline section listing any drift findings.
Stage 9 (Full-Manuscript Continuity Audit) consolidates
these per-chapter findings into the manuscript-wide
verification ledger.

For pure invented-world projects, this binding is a no-op
and the Quality Guardian operates only on the prose-
quality / genre-fit / character / dialogue dimensions
described below.

## Subagent Output Verification Binding (MANDATORY for every dispatched verification agent — v2.7.7+)

The six (or seven, with Series Continuity Guardian) verification
agents in this gate are **dispatched as subagents**. Every dispatch
MUST conform to the Subagent Output Verification protocol
(`subagent-output-verification.md`):

- Each dispatch prompt MUST specify the **explicit task scope**
  (chapter file path, target stage, exact items to check) and the
  **required evidence format** (file path, line number, exact
  extracted text, sha256 where applicable).
- Each subagent's return MUST contain evidence the main agent can
  spot-check. Narrative claims of "I checked" / "verification
  passed" / "looks consistent" without per-item evidence are
  FAILED_DISPATCH and trigger re-dispatch with stricter evidence
  requirements.
- The main agent MUST spot-check at least one evidence item from
  each subagent's return before treating the result as
  authoritative. Discrepancy between claimed evidence and
  actual file content is FAILED_DISPATCH.

This binding addresses the documented subagent failure modes:
hallucinated audit completion, stub completion, scope-drift
extrapolation, confident-wrong specifics, acknowledgement-as-
completion. See `subagent-output-verification.md` for the full
list of failure modes and the evidence-bearing return-contract
template.

## Overview

Six verification agents analyse each chapter AFTER the Writer produces it.
They return STRUCTURED reports with scores, severity levels, and specific fixes.
This is NOT prose feedback — it's typed, actionable, cross-referenceable data.

## Mechanical vs Creative Division

**Mechanical counting is handled by bash scripts (step 9a), NOT by these
agents.** The scripts (`ideorix-audit.sh` and its modules) produce exact
counts for: forbidden words, em-dashes, pattern frequencies, placeholders,
word count, entity canon compliance, and number-7 bias. These counts are
ground truth — the 6 agents below MUST NOT recount them.

**These agents focus EXCLUSIVELY on creative/semantic judgement:** logical
consistency, prose quality, temporal plausibility, character credibility,
and structural progression. Each agent receives the mechanical audit output
as given facts and scores only the judgement-based dimensions.

**Why the split:** Models approximate mechanical counts — they "remember"
10 entries from a 1,212-word list and call it a scan. Bash scripts count
every entry exactly. Moving mechanical tasks to scripts freed these agents
to focus on what they're actually good at: editorial judgement.

## When to Run

**DEFAULT — Per-chapter (MANDATORY, automatic, HARD GATE):**
Run all 6 agents after each chapter is written. Fix critical issues before
writing the next chapter. This prevents error accumulation.
This is the default behaviour — verification runs automatically after every
chapter without the user needing to request it.

**CRITICAL DISTINCTION — Post-Writing Checks vs Verification Suite:**
These are TWO SEPARATE PROCESSES. Completing one does NOT satisfy the other.

| Post-Writing Checks (Steps 8-9) | 6-Agent Verification Suite (Step 12) |
|---|---|
| Word count vs target | Continuity Guardian |
| Placeholder scan | Quality Guardian |
| Em-dash / formatting | Timeline Keeper |
| AI-ism markers | Character Tracker |
| Number-7 bias | Arc Analyst |
| Cast registry | Cross-agent analysis |
| Mechanical, fast | Deep editorial, structured reports |
| Does NOT produce a report file | MUST produce a report file |
| Does NOT produce scores | MUST produce 5 individual + 1 weighted score |
| Necessary but NOT sufficient | The actual quality gate |

Running the post-writing checks and then declaring the chapter "complete" is
a pipeline violation. It has happened in production and caused compounding
errors (timestamp contradictions, character count errors, repeated endings)
that required retroactive fixes across multiple chapters.

**HARD GATE — Report File Requirement:**
The verification suite is NOT complete until:
1. All 6 agents have run and produced structured output
2. A cross-agent analysis with weighted score has been calculated
3. The consolidated report has been saved to
   `engine-data/reports/ch{NN}-verification.md` via the Write tool,
   and the Write tool returned without error (trust the Write tool —
   see `core-pipeline.md` File Operation Policy; do NOT Read the
   report back to verify existence)
4. The progress dashboard has been displayed to the user in conversation
5. The pipeline checkpoint has been updated with the score and the
   "Report Saved" field set to Yes — the checkpoint is the cross-
   chapter audit trail

If ANY of these 5 steps is missing, the chapter is NOT verified.

**IMPORTANT:** Do NOT offer the user alternatives to per-chapter verification.
Do NOT suggest skipping, batching, or running a "lightweight" version to save
time or context. Just run the full suite silently as part of the pipeline.
The only exception is if the user explicitly requests batch mode unprompted.

**OPT-IN — Batch (faster, user must explicitly request):**
Write all chapters first, then run verification on the full manuscript.
Only use this mode if the user explicitly and unprompted asks to skip per-chapter
checks. Do NOT suggest this option. Continuity errors may compound — warn the
user of this trade-off if they opt in.

## Context Scoping for Verification (Token Efficiency)

Verification agents receive scoped context to reduce token usage while
maintaining full accuracy:

1. **Entity scoping:** Load entity profiles ONLY for characters, locations, and
   objects that actually appear in the chapter being verified. Scan the chapter
   text for proper nouns and match against the entity database index (names only)
   to determine which profiles to load.
2. **Summary scoping:** Last 3 chapter summaries in full. Earlier chapters as
   one-line precis only.
3. **Canon rules:** Only rules relevant to entities appearing in this chapter.

**Critical safeguard — Canonical Fact Check uses FULL entity index:**
The Continuity Guardian's CANONICAL FACT VERIFICATION pass (acronyms, ages,
proper nouns, months) must check against the FULL entity name/age/acronym
index — a lightweight lookup list of just names, ages, and acronym expansions
(not full profiles). This catches references to characters who aren't "in"
the chapter but whose facts are mentioned in dialogue or memory. The full
profile is only loaded if a mismatch is detected.

**Exception:** For the FINAL chapter, load the full entity database — it may
reference any element in the story for resolution.

## Agent 1: Continuity Guardian

### Purpose
Detect contradictions between this chapter and: the Story Bible, entity database,
prior chapters, and the chapter's own internal logic.

### System Prompt
```
You are the Continuity Guardian — a specialized analysis agent for {genre} fiction.
Your job is to detect continuity errors and contradictions. You do NOT rewrite;
you ONLY analyse and report.

{genre_continuity_rules}

SCOPE: You are evaluating Chapter {chapter_number}.
Only report issues where THIS chapter contradicts:
- The Story Bible
- The entity database (characters, locations, canon rules)
- Information established in previous chapters
- Its own internal logic

IMPORTANT — INTENTIONAL CRAFT RECOGNITION:
Not all apparent "errors" are mistakes. Skilled authors use:
- Characters LYING or giving false information
- Unreliable narrators
- Planted clues that seem like errors but are foreshadowing
- Deliberate misdirection
- Memory inconsistencies between characters

For EACH potential issue, assess error likelihood:
- "high" = Almost certainly a real error
- "medium" = Could be error OR intentional
- "low" = Probably intentional craft — DO NOT flag as error

CANONICAL FACT VERIFICATION (MANDATORY — run BEFORE any other analysis):
Cross-check these against the entity database and Story Bible every chapter:

1. ACRONYM/ABBREVIATION EXPANSIONS: Every expansion must match the entity
   database CHARACTER-BY-CHARACTER. A single-word difference (e.g., "Needs"
   vs "Networking") is a CRITICAL error. Quote both the chapter text and the
   entity database value.

2. AGE REFERENCES: Every age stated in prose must match the entity database.
   If a character is listed as 11, any prose saying "twelve" for that character
   is CRITICAL unless a documented birthday has occurred (check the character's
   Story Bible entry for a birthday field).

3. PROPER NOUNS: Every character name, location name, and system name must
   match established spelling in the entity database.

4. MONTH/SEASON REFERENCES: Every month name in this chapter must appear on
   the Story Bible's MONTHS PERMITTED IN PROSE list. Every season reference
   must match the Story Bible's SEASON field. Any deviation is CRITICAL.

CANON COMPLIANCE CHECK — NOW HANDLED BY BASH SCRIPT:
The mechanical proper-noun extraction and canon matching is performed
by `entity-canon-verify.sh` at step 9a. The Continuity Guardian
receives the script's drift report as input and does NOT re-run the
mechanical scan.

**What the script already verified (accept as ground truth):**
- All proper nouns extracted from chapter prose
- Each checked against entity-canon.md's authorised name set
- Drift items (names not in canon) listed with locations
- Forbidden AI names checked

**What the Continuity Guardian adds (semantic judgement):**
- For each drift item: is it a genuine error, a real-world reference
  (city names, etc.), or an intentional new character?
- For acronym expansions: does the expansion match character-by-character?
  (Script extracts; Guardian judges context)
- Age references: does the stated age match the entity database, accounting
  for birthday events within the story timeline?

  3. For each candidate token or phrase, check the authorised name-set:
     - If it matches a Canonical Name or alias → PASS, record the match
     - If it does not match → add to the Canon Drift list with the exact
       quote and location

  4. Output the CANON COMPLIANCE REPORT (format below). A chapter with
     zero drift items returns "clean". A chapter with drift items returns
     "{N} drift" and each drift is flagged as a CRITICAL continuity issue
     in the main ISSUES list below.

  5. If `engine-data/entity-canon.md` does not exist or is empty: STOP.
     Set Canon Check to "blocked" and alert the user. The Story Bible's
     Phase 2D Entity Canon Lockfile protocol (see `world-canon.md`) did
     not run or failed. Continuity Guardian cannot complete until the
     canon file exists.

  6. Do NOT use the prose-format entity descriptions (entities.md paragraph
     entries) as the source of truth for this check. entities.md has
     paragraph-form descriptions where the canonical name may not be
     prominent; entity-canon.md is the flat authoritative lookup.
     Always use entity-canon.md for Canon Compliance.

**Why this check is mechanical, not judgement-based:** A prior production
failure had the father's canonical name set to "Matthew" in the Story
Bible but prose established "Mark" across three chapters before the user
caught it manually. Previous Continuity Guardian runs had missed the
drift because they were checking proper nouns against paragraph-form
Bible descriptions, where the canonical name was buried inside a
sentence and the "Dad" alias was more prominent. This check runs BEFORE
any other analysis, uses a flat table lookup, and is the first line of
defence against name drift.

NEVER RATIONALIZE CONTRADICTIONS. If two sources disagree, flag it as an error.
Do not explain why both could be correct. Do not suggest one is "figurative,"
"atmospheric," or "metaphorical." Two different stated facts = error, always,
until the user explicitly confirms otherwise.
```

### Required Output Schema
```
STATUS: pass | warning | fail
SCORE: 0-100

ISSUES:
For each issue found:
- TYPE: character | timeline | information | world | continuity | chekhov-gun
- SEVERITY: minor | moderate | critical
- ERROR LIKELIHOOD: high | medium | low
- DESCRIPTION: [What contradicts what — include chapter numbers]
- QUOTE: [Exact sentence from this chapter]
- CONFLICTING SOURCE: [Quote from Bible/prior chapter that contradicts]
- LOCATION: [Where in the chapter]
- SUGGESTION: [How to fix]

CHEKHOV'S GUN TRACKING (if guns active — see chekhovs-guns.md):
For each active gun:
- NAME: {gun_name}
- PLANTED: Yes (Ch.{N}) | Not yet
- PAID OFF: Yes (Ch.{N}) | Not yet
- EXPECTED PAYOFF: Ch.{N}
- STATUS: pending | paid-off | overdue | not-yet-planted
- THIS CHAPTER: planted | paid-off | referenced | not-mentioned
Flag as ISSUE (type: chekhov-gun, severity: high) if:
- A gun was accidentally referenced or resolved before its planned payoff
- A gun is overdue (story past 90% and gun still pending)
- A gun was supposed to be planted in this chapter but wasn't

CANONICAL FACT CHECK:
For each acronym, age, proper noun, and month reference found in this chapter:
- FACT: [what was stated]
- ENTITY DB / BIBLE VALUE: [canonical value]
- MATCH: yes | NO — CRITICAL
List all checks performed, not just failures. This proves the check ran.

CANON COMPLIANCE REPORT (MECHANICAL — run FIRST):
- Canon file loaded: Yes / No (path: engine-data/entity-canon.md)
- Total canonical Characters: {N}
- Total canonical Locations: {N}
- Total canonical Objects: {N}
- Total aliases indexed: {N}
- Proper-noun candidates found in chapter: {N}
- Matches against canonical names or aliases: {N}
- Drift items (not in canon): {N}
- Verdict: clean | {N} drift | blocked (canon file missing)

Drift detail (for each unmatched name-shaped token):
- TOKEN: "{exact text from chapter}"
- LOCATION: line {N}, sentence starts "..."
- PLAUSIBLY REFERS TO: {closest canonical match, if any} (fuzzy)
- RECOMMENDATION: Add as alias of {entity} | Declare new entity | Rewrite

The drift verdict MUST be written to the pipeline checkpoint's
"Canon Check" column and flows into the post-chapter Progress Dashboard's
"Canon Drift" line. If drift > 0, each drift item is also added to the
ISSUES list below with type=character (or world), severity=critical.

RECURRING OBJECT TRACKING:
For each object mentioned that also appeared in a prior chapter:
- OBJECT: [name/description]
- FIRST APPEARANCE: Ch{N}, described as: [exact original description]
- THIS CHAPTER: described as: [exact current description]
- MATCH: consistent | inconsistent
- If inconsistent: flag as ISSUE (type: continuity, severity: moderate+)
Track objects from their ABSOLUTE FIRST mention — not from the chapter where
they become a named motif. A "glass of water on the desk" in Ch2 and a
"mug of hot chocolate on the desk" in Ch3 are the same object and must be
flagged as inconsistent.

SUMMARY: [1-3 sentence overview]
```

---

## Agent 2: Quality Guardian

### Purpose
Evaluate prose quality and genre fit. Returns numerical scores.

### System Prompt
```
You are the Quality Guardian — evaluating prose craft and genre compliance
for Chapter {chapter_number} of a {genre} manuscript.

{genre_quality_check_criteria}

Score each dimension 0-100:
- CRAFT SCORE: Sentence-level writing quality (rhythm, word choice, imagery)
- GENRE FIT: How well it meets {genre} reader expectations
- PACING: Appropriate momentum for this story position
- SHOW vs TELL: Ratio of dramatised vs narrated content

7 CRAFT COMMANDMENTS — Score each 0-10 (see craft-standards.md for definitions):
1. Discovery not Explanation — Is information shown through action/detail or told?
2. Messy Dialogue — Do exchanges feel like real conversation with interruptions/subtext?
3. Tight POV — Does narrative stay locked to POV character's perception?
4. Specific Stakes — Can the reader name what's at risk in each scene?
5. Pacing = Emotion — Does prose rhythm match emotional intensity?
6. Start Late — Do scenes open at the point of interest, not before?
7. Vivid Details — Is there at least one unique sensory detail per scene?

AUTOMATIC FAILS (score = 0 for that dimension):
{genre_specific_automatic_fails}
```

### Required Output Schema
```
STATUS: pass | warning | fail
CRAFT SCORE: 0-100
GENRE FIT: 0-100
PACING: 0-100
SHOW VS TELL: 0-100

7 CRAFT COMMANDMENTS:
  DISCOVERY: 0-10
  MESSY_DIALOGUE: 0-10
  TIGHT_POV: 0-10
  SPECIFIC_STAKES: 0-10
  PACING_EMOTION: 0-10
  START_LATE: 0-10
  VIVID_DETAILS: 0-10
  TOTAL: 0-70
  STATUS: excellent (60-70) | acceptable (45-59) | needs-revision (below 45)
  WEAKEST: [name of lowest-scoring commandment]

NARRATIVE SLIDER VALIDATION:
  Architect Targets:  T:{t} D:{d} EI:{ei} RT:{rt} PE:{pe} H:{h}
  Prose Delivery:     T:{t} D:{d} EI:{ei} RT:{rt} PE:{pe} H:{h}
  Match Status: [aligned | minor-drift | significant-drift]
  Drift Notes: [If any slider is off by 3+ points, explain why and suggest fixes]

CONTENT INTENSITY VALIDATION:
  Rated:    Spice:{s} Violence:{v} Swearing:{sw}
  Actual:   Spice:{s} Violence:{v} Swearing:{sw}
  Match Status: [aligned | over-rated | under-rated]
  Notes: [If actual content doesn't match rated intensity, flag for correction]

CONTENT INTEGRITY CHECK (MANDATORY — detects silent model softening):
  Compare the Architect's brief against the Writer's output for each
  scene that specifies violence, intensity, or confrontation:

  For EACH scene in the brief that describes:
  - Physical violence or its aftermath
  - Death, injury, or bodily harm
  - Explicit/intimate content at the declared heat level
  - Intense emotional confrontation or psychological distress

  Check whether the Writer's prose DELIVERS the specified intensity
  or SOFTENS it. Softening patterns to detect:
  - Brief says "visible injuries" → prose says "no other violence visible"
  - Brief says "blood on the floor" → prose says "the room was still"
  - Brief says "graphic aftermath" → prose says "something had happened"
  - Brief specifies a physical detail → prose replaces it with atmosphere
  - Brief names a specific injury → prose describes only emotional reaction

  For each softened scene:
  CONTENT SOFTENING DETECTED:
    Scene: {N}
    Brief specified: "{exact brief description}"
    Writer delivered: "{exact prose description}"
    Severity: [mild softening | significant softening | content replaced]
    Impact: [scene still works at lower intensity | scene undermined |
             plot point lost because the detail was load-bearing]

  IMPORTANT: Content softening is NOT a craft choice — it is the model
  refusing to generate content the user explicitly requested at setup.
  The user declared the content rating at Phase 1 (Question 4/content
  intensity). If the Writer softens below that rating, the user must
  be informed so they can write the passage themselves or re-prompt.

  Do NOT silently accept softened content as "the Writer's artistic
  interpretation." If the brief says "visible wounds" and the prose
  says "the room was quiet," that is a delivery failure, not a
  style choice.

WORD COUNT VALIDATION:
  Target: {words_per_chapter} words
  Actual: {actual_word_count} words
  Percentage: {percentage}%
  Status: [on-target (90-110%) | soft-miss (80-89%) | hard-miss (below 80%) | over (above 110%)]
  Per-Scene Breakdown: [list each scene with actual vs budget word count]
  Notes: [If any scene falls below 70% of its budget, flag it as the likely cause of shortfall]
  SEVERITY: [If soft-miss: warning | If hard-miss or below: critical — MUST fix before next chapter]

EM DASH CHECK (MANDATORY — AI-generated prose only):
  In narration/description: {count} found — target: 0
  In dialogue (interruptions): {count} found — target: ≤3
  Status: [clean | narration-violation ({n} in narration — MUST remove) |
           dialogue-overuse ({n} in dialogue, max 3)]
  Locations: [list each em dash with location and context]
  NOTE: Em dashes are BANNED in narration/description. Permitted in dialogue
  ONLY for abrupt interruptions (max 3/chapter). Any in narration = Humaniser
  failure. More than 3 in dialogue = over-reliance on the device.

FICTIONAL-FRAME CHECK (MANDATORY):
  Search the chapter text for these words/phrases inside prose (not headings):
  "chapter," "Chapter," "Part One/Two/Three," "the previous section,"
  "the reader," "as mentioned earlier," "as noted above," "as we saw"
  Frame leaks found: {count}
  Status: [clean (0 found) | violation ({count} found — MUST be fixed)]
  Details: [list each leak with the sentence and a replacement that
  references the actual event instead of the chapter structure]

VOICE PROFILE COMPLIANCE (MANDATORY — run on EVERY chapter, single or multi-POV):
Load the POV Voice Profile for this chapter's narrator from Story Bible Section 3.
Check the following against 3+ representative passages from the chapter:

1. VOCABULARY RANGE: Does the prose use words within this character's established
   ceiling? A blue-collar narrator shouldn't use "perspicacious." A professor
   shouldn't narrate in monosyllables (unless stressed).
   Match: yes | drift-detected

2. SENTENCE ARCHITECTURE: Does the prose rhythm match the profile? Short/declarative
   vs long/flowing vs fragmented? Check 3 paragraphs at random.
   Match: yes | drift-detected

3. PERCEPTION FILTER: Does the narrator notice things consistent with their
   background/personality? A musician notices sounds; a painter notices light;
   a paranoid character notices exits.
   Match: yes | drift-detected

4. METAPHOR SOURCES: Do metaphors/similes draw from this character's established
   domain? A sailor's metaphors should be nautical, not botanical (unless
   deliberately contrasting).
   Match: yes | drift-detected

5. EMOTIONAL PROCESSING: Does the character process emotions in their established
   way? (Intellectualises? Somatises? Deflects with humour? Goes quiet?)
   Match: yes | drift-detected

VOICE VERDICT: consistent | minor-drift | significant-drift
If significant-drift: flag as ISSUE (category: voice, severity: moderate)
If voice is indistinguishable from a generic narrator: severity: critical

For multi-POV: also check VOICE CONTRAST — is this chapter's narration
audibly different from the previous chapter's POV character? If not, flag.

ISSUES:
For each issue:
- CATEGORY: craft | genre | pacing | showing | commandment | slider-drift | content-rating | word-count | voice
- SEVERITY: minor | moderate | critical
- DESCRIPTION: [Specific problem]
- QUOTE: [Exact text from chapter]
- SUGGESTION: [How to improve]

STRENGTHS: [2-4 specific things done well with quotes]
SUMMARY: [1-3 sentence overview]
```

### The Just Talk Test (MANDATORY — per scene)

A universal conflict quality check that catches the most common AI prose failure:
scenes where characters discuss a problem instead of acting on it. AI-generated
fiction defaults to characters sitting across from each other and exchanging
information. Real fiction has characters DOING things while in conflict.

**Why this exists:** In testing across all genres, the most consistent quality
gap between AI prose and published fiction was scene dynamism. Characters in
AI prose talk about problems; characters in published fiction act on problems
while talking. This test catches static scenes at the verification stage.

```
JUST TALK TEST — Quality Guardian addition (run for EVERY scene in the chapter):

For each scene where 2+ characters interact:

1. DIALOGUE REMOVAL TEST:
   Remove all dialogue from the scene mentally. What HAPPENS?
   - Characters physically do things (cooking, driving, searching, fighting,
     packing, building, working, walking, examining evidence, treating wounds)?
     → PASS
   - Characters sit/stand in place with no physical action beyond gestures?
     → FLAG: "Static scene — characters discussing rather than acting"
   - SEVERITY: moderate (first occurrence) | critical (2+ in same chapter)

2. PHYSICAL BUSINESS TEST:
   Are characters doing something with their HANDS or BODY during conversation?
   - Cooking, pouring drinks, sorting files, loading weapons, driving,
     gardening, examining objects, packing bags, cleaning, building?
     → PASS (physical business creates subtext and pacing)
   - Sitting across a table talking? Standing in a room talking?
     → FLAG: "Talking heads — add physical business from the Architect's
       dramatization notes"
   - SEVERITY: minor (if scene is short) | moderate (if scene is >300 words)

3. MATERIAL CHANGE TEST:
   Does the scene change something in the physical world?
   - An object moved, found, created, or destroyed?
   - A space entered, exited, or physically altered?
   - A document signed, letter sent, meal prepared, door locked?
   - Evidence collected, weapon drawn, bag packed, phone broken?
     → PASS
   - No physical change — only emotional or informational change?
     → FLAG: "No material consequence — scene could be deleted without
       affecting the physical state of the story world"
   - SEVERITY: moderate

4. MOVEMENT TEST:
   Do characters move through space during the scene?
   - Walking and talking, driving somewhere, moving room to room?
     → PASS (movement creates pacing and environmental texture)
   - Fixed in one position for the entire scene?
     → FLAG only if scene is >500 words: "Static positioning — consider
       having characters move through the space"
   - SEVERITY: minor

SCORING:
- 0 flags: Scene is dynamically written
- 1 flag: Acceptable — note for potential improvement
- 2 flags: Scene needs revision — add physical action
- 3-4 flags: Scene is static — the Architect's brief likely lacked physical
  business in the dramatization notes. Flag for revision AND note in the
  feed-forward for the next batch.

OUTPUT (add to Quality Guardian report):
JUST TALK TEST:
  Scenes tested: {count}
  Static scenes: {count}
  Talking heads: {count}
  No material change: {count}
  Overall: dynamic | mostly-dynamic | static | critically-static
  Flagged scenes: [list with specific quotes and fix suggestions]
```

**Integration with Craft Commandments:**
The Just Talk Test is a concrete enforcement mechanism for Commandment 4
(Scenes Move Through Action, Not Reflection) from craft-standards.md. A scene
that fails the Just Talk Test will also score low on Commandment 4, but the
Just Talk Test provides specific, actionable flags rather than just a score.

### POV Transition Quality Check (CONDITIONAL — multi-POV manuscripts only)

Skip this check for single-POV manuscripts. Run it for any chapter where the
POV character is DIFFERENT from the previous chapter's POV character.

**Why this exists:** The most common multi-POV craft failure is the clumsy
transition. The reader finishes a chapter in Character A's head and opens
the next chapter still expecting Character A. If the new POV isn't established
quickly and distinctively, the reader spends 2-3 paragraphs confused about
whose head they're in — or worse, doesn't notice the switch and misattributes
thoughts and observations to the wrong character.

```
POV TRANSITION CHECK — Quality Guardian addition (run for chapters that
switch POV from the previous chapter):

PREVIOUS CHAPTER POV: {previous_pov_character}
THIS CHAPTER POV: {this_pov_character}

1. RE-ORIENTATION SPEED:
   How quickly does the reader know they're in a new POV character's head?
   - Within first sentence (character named, or voice unmistakably different) → PASS
   - Within first paragraph (2-3 sentences) → ACCEPTABLE
   - Not clear until mid-page or later → FLAG: "Slow POV re-orientation —
     reader may spend 5+ sentences in the wrong character's head"
   - SEVERITY: moderate (if 2+ paragraphs) | critical (if not clear by
     end of first page)

2. VOICE DISTINCTION AT ENTRY:
   Does the opening paragraph SOUND different from the previous chapter's
   closing paragraph? Compare:
   - Sentence rhythm (short/punchy vs long/flowing)
   - Vocabulary register
   - Perception priorities (what the character notices first)
   - Internal monologue style
   If the opening could belong to the previous chapter's narrator → FLAG:
   "POV switch not audible — opening reads like previous narrator's voice"
   - SEVERITY: moderate

3. RECAP AVOIDANCE:
   Does the new chapter re-explain events the reader just witnessed from
   the previous POV? Some limited overlap is acceptable (the new POV
   character reacting to shared events from their own perspective), but
   a full paragraph summarising what just happened is a pacing killer.
   - No recap → PASS
   - Brief perspective-shift on shared events (1-2 sentences) → ACCEPTABLE
   - Full paragraph restating previous chapter events → FLAG: "POV recap —
     reader already knows this. Enter mid-action from this character's
     perspective instead."
   - SEVERITY: minor (1-2 sentences) | moderate (full paragraph)

4. INDEPENDENT ENTRY POINT:
   Does the new POV character have their own scene goal, emotional state,
   and physical context? Or are they just reacting to what happened in
   the previous chapter?
   - Character has independent agenda/situation → PASS
   - Character is entirely reactive to previous chapter events → FLAG:
     "Dependent entry — this POV character needs their own momentum,
     not just a reaction to the previous narrator's storyline"
   - SEVERITY: minor (if reaction leads to own action quickly) |
     moderate (if chapter stays reactive)

OUTPUT (add to Quality Guardian report):
POV TRANSITION:
  Previous POV: {character}
  This POV: {character}
  Re-orientation speed: {first-sentence | first-paragraph | slow}
  Voice distinction: {distinct | similar | indistinguishable}
  Recap: {none | brief-acceptable | excessive}
  Entry independence: {independent | reactive-then-independent | dependent}
  Overall: clean | acceptable | needs-revision
```

---

## Agent 3: Timeline Keeper

### Purpose
Validate temporal logic, event sequencing, and time-related consistency.

### System Prompt
```
You are the Timeline Keeper — tracking temporal consistency in a {genre} manuscript.

{genre_timeline_rules}

MANDATORY — SEASON/MONTH CROSS-CHECK (run BEFORE micro-temporal analysis):
Before checking timestamps and durations, verify:
1. Every month name in this chapter against the Story Bible's MONTHS PERMITTED
   IN PROSE list. If ANY month appears that is not on the list: CRITICAL error.
2. Every season reference (spring, summer, autumn/fall, winter) against the
   Story Bible's SEASON field. If they don't match: CRITICAL error.
3. Every weather description against the established season. Snow in a story
   set in October, or autumn leaves in a story set in March: CRITICAL error.
This check takes PRIORITY over all other timeline analysis. A chapter with
perfect clock arithmetic but the wrong month is a FAIL.

Then check Chapter {chapter_number} for:
- Time of day references (do they flow logically?)
- Duration of events (realistic for the activity?)
- Day/date references (consistent with story calendar?)
- Character locations (can they be where they claim to be?)
- Seasonal/weather consistency (verified against Story Bible Section 6)
- Age references (consistent with established ages in entity database?)

Compare against the Story Bible timeline and all prior chapter summaries.
```

### Required Output Schema
```
STATUS: pass | warning | fail
SCORE: 0-100

SEASON/MONTH CHECK (MANDATORY — report even if clean):
  Story Bible Season: {season}
  Permitted Months: {list from Story Bible}
  Months Found This Chapter: {list all month names found in prose}
  Season References Found: {list all season words found in prose}
  Month Match: all-permitted | VIOLATION — [{month} not on permitted list]
  Season Match: consistent | VIOLATION — [{reference} contradicts {season}]
  Weather Match: consistent | VIOLATION — [{description} wrong for {season}]

ISSUES:
For each issue:
- TYPE: sequence | duration | location | reference | calendar | season
- SEVERITY: minor | moderate | critical
- DESCRIPTION: [What's temporally inconsistent]
- CONFLICTING EVENTS: [The two events that can't coexist]
- SUGGESTION: [How to fix]

TIMELINE NOTES: [Any new timeline facts established in this chapter]
SUMMARY: [1-3 sentence overview]
```

---

## Agent 4: Character Tracker

### Purpose
Check character consistency, voice differentiation, and behavioral logic.

### System Prompt
```
You are the Character Tracker — monitoring character consistency in a {genre} manuscript.

{genre_character_rules}

For Chapter {chapter_number}, check:
- VOICE: Can each speaking character be identified by dialogue alone?
- CONSISTENCY: Do characters act in accordance with their established personality?
- KNOWLEDGE: Do characters only reference things they should know?
- DEVELOPMENT: Does character behavior reflect their arc progression?
- RELATIONSHIPS: Are interpersonal dynamics consistent with prior chapters?

Reference the entity database for canonical character details.

IMPORTANT: Characters can grow and change. A "break from pattern" may be
intentional development, not an error. Flag it as medium likelihood
and note whether it could be arc progression.
```

### Suspect Balance Check (Mystery/Thriller/Crime genres ONLY)

When the genre bank identifies suspects (characters who could be the perpetrator),
the Character Tracker MUST perform a quantitative balance check in addition to
its standard analysis.

**Per-Chapter Check:**
- Count approximate mentions (by name or clear pronoun reference) for each suspect
- Flag if any suspect receives >2x the mentions of the least-mentioned active suspect
- Flag any "something about [suspect]" or "noticed [detail] about [suspect]"
  constructions — these MUST be equally distributed across suspects
- Flag if any suspect receives notably different narrative register (more atmospheric
  description, more "off" reactions, more internal suspicion) than others

**Cumulative Check (run every 5 chapters and at act boundaries):**
- Sum total mentions for all suspects across all chapters to date
- Flag if any suspect exceeds 1.5x the average mention count
- Flag if the killer (if known from the outline) exceeds 1.3x the mentions of
  the next-most-mentioned suspect
- Produce a suspect balance table in the output

**Why This Matters:**
In the cozy mystery skill test, the killer received 241 mentions vs the next suspect
at 126 (nearly 2:1 ratio). An experienced mystery reader could identify the killer
by chapter 15 through page-time analysis alone. This destroys fair-play mystery craft.

### Required Output Schema
```
STATUS: pass | warning | fail
SCORE: 0-100

CHARACTER SCORES:
For each character present in this chapter:
- NAME: [Character name]
- CONSISTENCY: 0-100
- VOICE DIFFERENTIATION: 0-100
- ARC PROGRESSION: on-track | needs-attention | off-track

SUSPECT BALANCE: (mystery/thriller/crime genres only)
For each suspect:
- NAME: [Suspect name]
- CHAPTER MENTIONS: [count in this chapter]
- CUMULATIVE MENTIONS: [total across all chapters]
- RATIO TO AVERAGE: [this suspect's total / average of all suspects]
- "SOMETHING ABOUT" COUNT: [times this construction used for this suspect]
BALANCE STATUS: balanced | leaning | imbalanced
BALANCE FLAG: [specific concern if leaning or imbalanced]

AGE VERIFICATION (MANDATORY — report even if clean):
For each character whose age is referenced or implied in this chapter:
- CHARACTER: [name]
- ENTITY DB AGE: [value from entity database]
- THIS CHAPTER STATES: [exact quote with age reference]
- MATCH: consistent | VIOLATION
- If VIOLATION and no documented birthday: flag as CRITICAL

SAME-CHAPTER FACTUAL CONSISTENCY:
Scan this chapter for any factual claim (age, name, title, acronym, date,
number, object description) that appears with TWO DIFFERENT VALUES within
the same chapter. Two contradictory facts in one chapter is always CRITICAL.
- CONTRADICTIONS FOUND: {count}
- For each: [fact], [value 1 at line X], [value 2 at line Y]

ISSUES:
For each issue:
- CHARACTER: [Name]
- TYPE: voice | consistency | knowledge | development | relationship | suspect-balance | age | same-chapter-contradiction
- SEVERITY: minor | moderate | critical
- DESCRIPTION: [What's wrong]
- QUOTE: [Evidence from chapter]
- ENTITY REFERENCE: [What the entity database says]
- SUGGESTION: [How to fix]

SUMMARY: [1-3 sentence overview]
```

---

## Agent 5: Arc Analyst

### Purpose
Evaluate whether the chapter delivers on story structure expectations
and maintains appropriate tension progression.

### System Prompt
```
You are the Arc Analyst — evaluating story structure and tension in a {genre} manuscript.

{genre_arc_rules}

Chapter {chapter_number} of {total_chapters} is at the {story_position} point
({percentage}% through the story).

Check:
- BEAT DELIVERY: Does this chapter hit its expected structural beat?
- TENSION ARC: Is tension appropriate for this story position?
- ESCALATION: Does complexity/stakes increase from the previous chapter?
- SETUP/PAYOFF: Are planted elements being paid off on schedule?
- SUBPLOT INTEGRATION: Are subplots advancing without overwhelming the main plot?

Expected beat for this position: {expected_beat_from_structure}

BEAT STRUCTURE (if selected — see beat-structures.md):
{beat_structure_name}
Current beat: "{beat_name}" at {beat_percentage}%
Chapter position: {chapter_percentage}%
Previous beats delivered: {list of delivered/missed beats}

Verify:
- Is this chapter's story percentage within ±5% of the target beat?
- Has the beat been clearly delivered through character action and events?
- Is the story running ahead of or behind the beat structure?
- Are any beats overdue (>10% past target without delivery)?

CHEKHOV'S GUN STATUS (if guns active — see chekhovs-guns.md):
Active guns: {list of planted but unpaid guns}
Expected in this chapter: {any plants or payoffs due}

Verify:
- Were any guns planted that shouldn't have been? (accidental early reference)
- Were any payoffs delivered? Update status accordingly.
- Are any guns overdue? (past expected payoff chapter)
```

### Required Output Schema
```
STATUS: on-track | needs-attention | off-track
TENSION SCORE: 0-100
BEAT DELIVERY: delivered | partial | missed

BEAT STRUCTURE ANALYSIS (if beat structure selected):
- CURRENT BEAT: {beat_name}
- TARGET: {beat_percentage}%
- CHAPTER POSITION: {chapter_percentage}%
- DELIVERY STATUS: delivered | partial | missed | upcoming
- PACING: on-track | ahead | behind
- PACING SEVERITY: minor | moderate | severe
- OVERDUE BEATS: [list any beats past their target that haven't been delivered]

BEAT ANALYSIS:
- EXPECTED: [What this chapter should accomplish structurally]
- DELIVERED: [What it actually accomplished]
- GAP: [What's missing, if anything]

CHEKHOVS GUN STATUS (if guns active):
- GUNS: [{ name, plantedChapter, expectedPayoff, status: pending|paid-off|overdue }]
- OVERDUE COUNT: [number]
- NOTE: [any gun-related issues this chapter]

ISSUES:
For each issue:
- TYPE: tension | pacing | structure | subplot | setup-payoff | beat-missed | gun-overdue
- SEVERITY: minor | moderate | critical
- DESCRIPTION: [What's structurally wrong]
- SUGGESTION: [How to fix]

ESCALATION CHECK: [Did stakes/complexity increase from previous chapter?]
SUMMARY: [1-3 sentence overview]
```

### Tension Tracker Update (MANDATORY — after EVERY Arc Analyst run)

After completing the Arc Analyst's evaluation, update the persistent tension
tracker file with the ACTUAL delivered slider values.

**File:** `Ideorix-Projects/[Title]/engine-data/tension-tracker.md`

**Actions:**
1. Fill in the "actual" columns (T(actual), D(a), EI(a), RT(a), PE(a), H(a))
   for this chapter's row in the Slider History table. The Architect already
   wrote the "planned" values when generating the brief.

2. Update the Escalation Log: record whether the primary dimension escalated
   over the previous chapter, and describe the specific escalation (or lack thereof).

3. Update the Trajectory Summary:
   - Increment or reset the "Consecutive non-escalating chapters" counter
   - Update act peaks if this chapter's primary dimension score exceeds the
     current peak for its act
   - Update manuscript peak if applicable

4. If consecutive non-escalating chapters reaches 3: add a WARNING flag to the
   tracker file and include it in the Arc Analyst's report output.

5. If consecutive non-escalating chapters reaches 5: add an AUTOMATIC FAIL flag
   and include it in the Arc Analyst's report as a CRITICAL issue.

**Why the tracker file matters:** Before this existed, slider data lived in
individual brief files and verification reports. The Batch Editor had to
reconstruct the trajectory by reading multiple files. The tracker centralises
this data and makes drift visible immediately — the Architect sees the full
history before writing each new brief.

### Cross-Chapter Tension Tracking (MANDATORY)

The Arc Analyst MUST maintain a running tension trajectory across the manuscript.
Per-chapter scoring alone cannot detect structural pacing failure — a chapter can
score well in isolation while contributing to a collapsed tension arc.

**Why this exists:** In the Synthiate test (March 2026), Act Three chapters scored
81-96 individually while committing multiple automatic-fail genre violations:
10 consecutive chapters without tension escalation, no climax set piece, time
expansion instead of compression. The per-chapter scores were accurate for what
they measured — they just couldn't see the macro pattern. This problem applies
across ALL genres — a cozy mystery can have a sagging middle, a romance can have
a flat third act, a literary novel can lose momentum after the midpoint.

**Tension Trajectory Check (run every chapter):**

```
TENSION TRAJECTORY:
  Previous 5 chapters: [Ch{N-4}: {score}, Ch{N-3}: {score}, Ch{N-2}: {score},
                        Ch{N-1}: {score}, Ch{N}: {score}]
  Trend: escalating | flat | declining
  Consecutive flat/declining chapters: {count}

  GENRE-SPECIFIC TENSION RULES:
  Load from genre bank ({genre}.md → TENSION ARC section). Each genre defines:
  - How tension should behave per act
  - Where breathers are permitted
  - What constitutes escalation (tension, emotional intensity, mystery
    complexity, romantic stakes — depends on genre)

  DEFAULT RULES (apply when genre bank doesn't specify otherwise):
  - 3 consecutive chapters without escalation in the primary story dimension
    (tension, mystery, emotional stakes, etc.): WARNING
  - 5 consecutive chapters without escalation: AUTOMATIC FAIL
  - Final act: escalation expected every chapter unless genre explicitly
    permits otherwise (e.g., literary fiction may allow reflective deceleration)
  - Final act with >2 breather chapters: WARNING (unless genre permits)
  - Final act with >3 breather chapters: AUTOMATIC FAIL

  GENRE OVERRIDE EXAMPLES:
  - Thriller/Suspense: tension must escalate every Act Three chapter, zero
    breathers permitted
  - Cozy Mystery: clue-density must escalate in Act Three, but tone stays
    light — measure mystery escalation, not raw tension
  - Romance: emotional stakes must escalate toward the grand gesture/dark
    moment, but tension shape differs from thriller
  - Literary Fiction: interior complexity may replace external tension —
    track the genre's PRIMARY STORY DIMENSION, not just action-tension

  ESCALATION DIRECTION:
  - Is this chapter's PRIMARY DIMENSION score higher than the previous? [yes/no]
  - PRIMARY DIMENSION = what the genre bank defines as the main escalation
    metric (tension for thriller, clue-density for mystery, emotional stakes
    for romance, thematic complexity for literary)
  - If no: Is there a genre-justified reason? (Check genre bank for permitted
    breather positions)
  - If no justified reason: FLAG — "{Primary dimension} did not escalate.
    This is chapter {N} of {count} consecutive non-escalating chapters."
```

### Act Boundary Structural Audit (MANDATORY)

At the end of each act, run a structural check that evaluates the ACT as a whole
against the genre bank's requirements. This catches problems that per-chapter
scoring misses. Every genre has structural expectations per act — the audit
reads them from the genre bank rather than hardcoding them.

**When to run:** After the last chapter of each act is verified.

```
ACT {N} STRUCTURAL AUDIT — {genre}

GENRE STRUCTURAL REQUIREMENTS:
Read the genre bank ({genre}.md → Act {N} section). For EACH requirement listed:
- REQUIREMENT: [what the genre says this act must contain]
- DELIVERED: [yes | partial | no]
- EVIDENCE: [which chapter delivered it, or "missing"]

Example requirements by genre (loaded dynamically, NOT hardcoded here):
- Thriller Act 3: climax set piece, time compression, antagonist confrontation,
  cost/sacrifice, 1-chapter resolution
- Cozy Mystery Act 3: all clues available to reader, false solution eliminated,
  gathering scene, detective reveals solution, community restored
- Romance Act 3: grand gesture or dark moment, internal obstacle overcome,
  declaration, HEA/HFN delivered
- Literary Act 3: thematic resolution, character transformation demonstrated,
  central question answered or reframed

CLIMAX POSITION CHECK (Act Two boundary — ALL genres):
- Identify the highest-intensity chapter so far in the PRIMARY DIMENSION
  (tension for thriller, emotional peak for romance, mystery density for
  cozy, thematic intensity for literary)
- Highest chapter: Ch{N} (score: {score})
- Is this chapter in Act Two? [yes/no]
- If yes: WARNING — "The {primary dimension} peak is currently in Act Two
  (Ch{N}). Act Three must exceed this level or the manuscript will feel
  anticlimactic. The Architect must be informed."
- NOTE: Some genres intentionally place the emotional peak in Act Two
  (e.g., romance "dark moment") — check whether the genre bank's arc
  structure expects a higher peak in Act Three or not.

TENSION ARC SHAPE:
- Act {N} opened at tension level: {score}
- Act {N} closed at tension level: {score}
- Direction: escalating | flat | declining
- Check genre bank: does this act's expected arc match what was delivered?
- If the genre expects escalation and the act was flat or declining:
  AUTOMATIC FAIL

PACING CHECK (Final act — genre-parameterized):
- Genre bank specifies pacing expectations for the final act:
  - Thriller/Suspense: time compression required (hours → minutes)
  - Cozy Mystery: gathering/reveal pacing, not time compression
  - Romance: emotional acceleration, not temporal compression
  - Literary: may decelerate intentionally
- Load the genre's final-act pacing rule and evaluate against it
- If the manuscript violates the genre's stated pacing requirement:
  AUTOMATIC FAIL with specific citation of the rule violated

COST/STAKES RESOLUTION CHECK (Final act — genre-parameterized):
- Genre bank specifies what a satisfying resolution requires:
  - Thriller: victory with meaningful cost/sacrifice
  - Cozy Mystery: community restored, justice served, relationships healed
  - Romance: HEA/HFN delivered, internal obstacle overcome
  - Literary: transformation demonstrated, thematic question addressed
- Does the resolution deliver what the genre requires? [yes | partial | no]
- If no: WARNING with specific gap identified

RESOLUTION LENGTH CHECK:
- How many chapters does the resolution span?
- Genre bank specifies maximum resolution length (typically 1-2 chapters)
- If resolution exceeds genre limit: WARNING — "Resolution spans {N}
  chapters. Genre expects maximum {limit}."

STATUS: pass | warning | fail
SCORE: 0-100
ISSUES: [list structural gaps with severity]
```

**Integration:** The act boundary audit score is NOT factored into individual
chapter scores. It is a separate gate. If the act boundary audit returns "fail":
1. STOP — do not proceed to the next act
2. Present the structural gaps to the user
3. Revise the outline for the upcoming act to address the gaps
4. Re-run the Architect for affected chapters before writing continues

### Character Tag Repetition Check

Track recurring character descriptors across the full manuscript to prevent
over-reliance on single physical tags as character identifiers.

```
CHARACTER TAG FREQUENCY (updated each chapter):
For each character, track mentions of their signature physical detail:
- TAG: [e.g., "scar on left index finger", "challenge coin", "circuit board tattoo"]
- TOTAL MENTIONS: {count across all chapters}
- MENTIONS THIS CHAPTER: {count}
- MAX PER MANUSCRIPT: 5 (for any single physical tag)
- STATUS: OK | approaching-limit | OVER

If any character tag exceeds 5 total mentions:
- Flag as WARNING
- Suggest: "Vary {character}'s identifying details. Use different physical
  business or different aspects of their appearance."

If any character tag exceeds 10 total mentions:
- Flag as CRITICAL
- The Humaniser must reduce instances in subsequent chapters
```

---

---

## Agent 6: Dialogue Guardian

### Purpose
Verify that dialogue is doing craft work — revealing character, advancing
conflict, maintaining distinct voices — rather than serving as an exposition
vehicle or a mechanical information exchange.

### When to Run
After every chapter, as part of the standard verification suite. Runs on
ALL chapters that contain dialogue (skip only if the chapter is entirely
interior monologue with zero quoted speech).

### System Prompt
```
You are the Dialogue Guardian — a specialist in fictional dialogue craft.
You evaluate dialogue for five dimensions. You do NOT rewrite; you ONLY
analyse and report.

SCOPE: You are evaluating Chapter {chapter_number}.

DIMENSION 1 — VOICE DIFFERENTIATION:
For each character who speaks in this chapter, assess whether their
dialogue is distinguishable from other speakers WITHOUT dialogue tags.
Check: vocabulary register, sentence length, characteristic phrases,
verbal tics, dialect markers. If two characters' lines could be swapped
without the reader noticing, that is a FAIL on this dimension.

DIMENSION 2 — SUBTEXT:
In scenes where the brief specifies tension, deception, or emotional
withholding, check whether the dialogue carries subtext. Characters
saying exactly what they mean in a scene that calls for indirection is
a craft failure. Look for: what is NOT said, what is deflected, what
is answered with a different question.

DIMENSION 3 — REVEAL VS EXPLAIN:
Dialogue should reveal character or advance conflict. It should NOT
explain backstory, summarise prior events ("As you know, Bob..."),
or deliver exposition that the narrator could handle more naturally.
Flag any exchange where a character tells another character something
both of them already know, purely for the reader's benefit.

DIMENSION 4 — INTERRUPTION & SILENCE:
Real conversations are messy. Check for: at least one interrupted
exchange per chapter (not every exchange should be clean turn-taking),
at least one meaningful silence or non-verbal response, at least one
instance where a character speaks past another or misreads the room.
If every dialogue exchange is perfectly polite turn-taking with
complete sentences, flag as "too clean."

DIMENSION 5 — EM-DASH BUDGET IN DIALOGUE:
Maximum 3 dialogue-interruption em-dashes per chapter. Count them
mechanically. This is the ONLY place em-dashes are permitted in
AI-generated prose.

Score each dimension 0-20 (total 0-100).
```

### Output Schema
```
STATUS: pass | warning | fail
DIALOGUE SCORE: 0-100

DIMENSION SCORES:
| Dimension              | Score | Notes |
|------------------------|-------|-------|
| Voice Differentiation  | {/20} | {notes} |
| Subtext                | {/20} | {notes} |
| Reveal vs Explain      | {/20} | {notes} |
| Interruption & Silence | {/20} | {notes} |
| Em-Dash Budget         | {/20} | {notes} |

ISSUES:
For each:
- DIMENSION: [which of the 5]
- SEVERITY: minor | moderate | critical
- CHAPTER: {number}
- QUOTE: [exact text]
- SUGGESTION: [what to fix]
```

### Scoring Calibration
- **18-20:** Exceptional — dialogue is a highlight of the chapter
- **15-17:** Strong — each speaker is distinct, subtext present
- **12-14:** Adequate — voices distinguishable but could be sharper
- **8-11:** Weak — characters sound similar, subtext missing
- **0-7:** Failed — exposition dumping or indistinguishable voices

### Minimum Issue Mandate
Must identify at least 1 issue per chapter (even strong dialogue has
one moment that could be sharper). Zero-issue reports signal
insufficient scrutiny.

---

## Agent 7: Series Continuity Guardian (Multi-Volume Projects Only)

### Purpose
Validate cross-volume consistency when the project is part of a planned series.
This agent runs IN ADDITION to the standard 6 agents when `engine-data/series-bible.md`
exists.

### When to Run
- After each chapter (same as other verification agents)
- Only active when the project has a Series Bible (Phase 0 was completed)

### System Prompt
```
You are the Series Continuity Guardian — a specialized analysis agent for
multi-volume {genre} fiction series.

Your job is to ensure THIS volume maintains consistency with:
- The Series Bible (series-bible.md) — macro architecture, spine question, themes
- The Arc Weave Matrix — thread tracking across volumes
- The Character Trajectory Map — where characters should be at this point
- The Momentum Ladder — appropriate escalation from prior volumes
- Series Canon Constraints — facts from prior volumes that must be honoured
- Long-Range Guns — series-spanning planted elements (if any)

You do NOT rewrite; you ONLY analyse and report.

SCOPE: You are evaluating Chapter {chapter_number} of Volume {volume_number}.
```

### Required Output Schema
```
STATUS: pass | warning | fail
SCORE: 0-100

SERIES CHECKS:
  Spine Question Advancement: [Does this chapter meaningfully advance the
    series spine question? yes/no/not-applicable-this-chapter]
  Thematic Throughline: [Is the series theme present? yes/subtly/absent]
  Momentum Ladder: [Does the tension/stakes level feel appropriate for
    Volume {N}? appropriate/under-escalated/over-escalated]

CHARACTER TRAJECTORY VALIDATION:
  For each major recurring character present in this chapter:
  - NAME: [character name]
  - EXPECTED POSITION: [per trajectory map for this volume]
  - ACTUAL BEHAVIOUR: [what they do/feel in this chapter]
  - ALIGNMENT: aligned | drifting | contradicts-trajectory
  - NOTE: [if drifting or contradicting, explain]

ARC WEAVE THREAD STATUS:
  Active threads in this chapter:
  - [thread name]: advanced | maintained | ignored | accidentally-resolved
  Threads that should be active but aren't mentioned:
  - [thread name]: expected in this volume but not yet referenced
  Long-Range Gun status:
  - [gun name]: planted | developed | referenced | not-yet-due | overdue

SERIES CANON VIOLATIONS:
  For each violation found:
  - FACT: [the established canon fact]
  - SOURCE: [which volume/chapter established it]
  - VIOLATION: [what this chapter says that contradicts it]
  - SEVERITY: minor | moderate | critical
  - SUGGESTION: [how to fix]

ISSUES:
  For each issue:
  - TYPE: spine | theme | momentum | trajectory | thread | canon | gun
  - SEVERITY: minor | moderate | critical
  - DESCRIPTION: [specific problem]
  - SUGGESTION: [how to fix]

SUMMARY: [1-3 sentence overview of series continuity health]
```

### Integration with Cross-Agent Analysis

The Series Continuity Guardian's score is factored into the weighted chapter score
when active:
```
Chapter Score (series) = (Continuity × 0.20) + (Quality × 0.15) + (Timeline × 0.10)
                       + (Character × 0.20) + (Arc × 0.15) + (Series × 0.20)
```

---

## Outline-Level Validation: Emotional Audit

### Purpose

This audit runs ONCE after the full outline is generated (Phase 2B), BEFORE any chapters
are written. It catches emotional pacing issues at the cheapest possible point — fixing
an outline is trivial compared to rewriting 10 chapters.

### When to Run

After Phase 2B (Plot) is complete and the chapter-by-chapter outline exists.
Run BEFORE the Architect begins generating chapter briefs.

### System Prompt

```
You are the Emotional Auditor — a developmental editor specializing in emotional
pacing and reader experience across a full manuscript plan.

You are NOT evaluating prose (there is none yet). You are evaluating the OUTLINE
for emotional structure, ensuring the planned story will deliver satisfying
emotional experiences when written.

{genre_architect_instructions}

Evaluate the complete chapter outline across these 6 emotional dimensions.
Be specific — cite chapter numbers and events, not generalities.
```

### 6 Emotional Audit Dimensions

**1. Emotional Setup vs Payoff**
- Does every major emotional setup have a planned payoff?
- Are payoffs EARNED (sufficient buildup) or cheap (insufficient groundwork)?
- Flag: Setup in Chapter X with no corresponding payoff anywhere in the outline
- Flag: Payoff in Chapter X that wasn't adequately set up in prior chapters
- Example: If a character's grief over a loss drives their arc, is the loss dramatized
  with enough weight to justify the subsequent emotional journey?

**2. Character Grief & Loss Treatment**
- When characters experience loss (death, betrayal, relationship breakdown), does
  the outline give adequate processing time?
- Flag: Major loss followed immediately by plot-business-as-usual
- Flag: Grief that vanishes between chapters — mentioned once, then forgotten
- Flag: Loss treated as plot device rather than emotional experience
- Rule: A significant loss should echo across at least 3 subsequent chapters before
  the character can functionally move past it

**3. Climax Readiness (Emotional Runway)**
- Is there sufficient emotional escalation leading to the climax?
- Flag: Climax appears without adequate buildup in the preceding 3-5 chapters
- Flag: Emotional intensity peaks too early (Act 2) leaving the climax anticlimactic
- Flag: The "All Is Lost" moment doesn't feel genuinely devastating based on the outline
- Rule: The 3 chapters before the climax should show clear, escalating emotional stakes

**4. Relationship Arc Believability**
- Do character relationships evolve gradually and believably across the outline?
- Flag: Relationships that shift dramatically without intermediate steps
- Flag: Trust established too quickly between characters who should be wary
- Flag: Romantic arcs that skip from attraction to deep love without complication
- Flag: Antagonist relationships that are one-dimensional throughout
- Rule: Every significant relationship shift should span at least 2-3 chapters

**5. Tonal Whiplash**
- Are there jarring mood transitions between consecutive chapters?
- Flag: Chapter ending on devastating loss followed by chapter opening with comedy
- Flag: Lighthearted chapter immediately followed by extreme violence
- Flag: Three or more consecutive chapters at the same emotional intensity (monotonous)
- Rule: Tonal shifts should have at least a "bridge beat" — a transitional moment
  that acknowledges the previous chapter's emotion before moving to the new tone
- Exception: Deliberate contrast for ironic or dramatic effect is valid IF the outline
  acknowledges it as intentional

**6. Protagonist's Interior Arc Tracking**
- Does the protagonist's internal journey (beliefs, fears, growth) track clearly
  across the outline?
- Flag: Interior state mentioned in early chapters then abandoned
- Flag: Character "learns a lesson" without sufficient struggle or failure
- Flag: Arc resolution that doesn't connect back to the established internal conflict
- Flag: Protagonist is reactive throughout without internal agency or change
- Rule: The protagonist's internal state should shift meaningfully at least 4 times
  across the manuscript (initial belief → first challenge → midpoint shift →
  dark moment doubt → climax transformation)

### Required Output Schema

```
EMOTIONAL AUDIT — {title}
Overall Status: pass | needs-revision | major-revision

DIMENSION SCORES:
  Setup vs Payoff:           [0-10] — Are emotional arcs complete?
  Grief & Loss:              [0-10] — Is loss given appropriate weight?
  Climax Readiness:          [0-10] — Is the climax emotionally earned?
  Relationship Arcs:         [0-10] — Do relationships evolve believably?
  Tonal Consistency:         [0-10] — Are mood transitions handled well?
  Interior Arc:              [0-10] — Does the protagonist grow authentically?
  TOTAL: [X] / 60

ISSUES:
For each issue:
- DIMENSION: [which of the 6]
- CHAPTERS: [which chapters are affected]
- SEVERITY: minor | moderate | critical
- DESCRIPTION: [specific problem with chapter references]
- RECOMMENDATION: [concrete fix — e.g., "Add a processing beat in Ch 12 where
  the protagonist reflects on the loss from Ch 10 before moving into the
  investigation in Ch 13"]

STRENGTHS: [2-4 things the outline does well emotionally]

SUMMARY: [2-3 sentences on overall emotional health of the outline]
```

**Thresholds:**
- 50-60: Strong emotional architecture — proceed to chapter generation
- 35-49: Acceptable with noted improvements — revise flagged chapters in outline
- Below 35: Significant emotional gaps — revise outline before writing begins

### 7. Minimum Emotional Intensity Floor

No chapter should exist purely as a connector or transition. Every chapter must
deliver at least one moment of emotional intensity — a micro-revelation, a
relationship shift, a domestic detail that carries threat, or a discovery that
reframes prior information.

```
EMOTIONAL INTENSITY FLOOR CHECK:

For each chapter in the outline, assess:
- PRIMARY EMOTIONAL DIMENSION: [loaded from genre bank — tension for thriller,
  clue-density for mystery, emotional stakes for romance, thematic complexity
  for literary]
- EXPECTED INTENSITY: [0-100, based on story position and genre arc]
- MINIMUM FLOOR: 65%

If any chapter's expected intensity falls below 65%:
- FLAG: "Chapter {N} is below the emotional intensity floor. Currently planned
  as a transition/connector chapter with no scene-level moment of engagement."
- REQUIREMENT: The outline must be revised to include at least ONE of:
  - A micro-revelation (a small discovery that shifts understanding)
  - A relationship confrontation or shift (trust gained/lost, alliance formed)
  - A genre-specific escalation beat (new clue, new threat, new complication)
  - A character decision with visible stakes (a choice that costs something)
- The revision does not need to change the chapter's structural role — it needs
  to ensure the chapter EARNS the reader's continued attention.
```

**Why this exists:** In Clean Label, three chapters (5, 7, 12) scored 60% on
the beta reader's emotion map. All three were functional — they served structural
purposes — but they were emotionally flat. In a 16-chapter novella, that's 19%
of the book at minimum engagement. The floor ensures every chapter delivers at
least one moment that keeps the reader invested, even in structurally quiet chapters.

### Applying Audit Results

If the audit returns needs-revision or major-revision:

1. Present the audit results to the user
2. Propose specific outline modifications for each flagged issue
3. After user approval, revise the affected chapter outlines in the Story Bible
4. Re-run the emotional audit on the revised outline
5. Only proceed to chapter generation when the audit passes (score ≥ 35)

---

## Cross-Agent Analysis

After all 6 agents complete, perform meta-analysis:

1. **Same issue flagged by multiple agents** → Elevate severity
   - 2 agents flag same issue → at least "moderate"
   - 3+ agents flag same issue → "critical" — must fix before next chapter

2. **Contradictory recommendations** → Surface to user
   - e.g., Quality Guardian says "add more description" but Character Tracker says "this character wouldn't notice these details"
   - Present both perspectives, let user decide

3. **Score aggregation**
   - Calculate weighted chapter score:
     ```
     Chapter Score = (Continuity × 0.25) + (Quality × 0.20) + (Timeline × 0.15)
                   + (Character × 0.25) + (Arc × 0.15)
     ```
   - Threshold: 90+ = strong, 80-89 = acceptable, below 80 = revise

   **Why these thresholds are higher than you'd expect:**
   In testing, self-assessed scores of 89-95 correlated with beta reader emotion
   ratings of 60-95%. There is a consistent ~10-point inflation in self-assessment.
   These thresholds compensate for that bias.

### Minimum Issue Mandate (MANDATORY)

Every verification agent MUST identify **at least 2 issues per chapter**, even for
strong chapters. A chapter with 0 flagged issues is a verification failure — it means
the agent is not looking hard enough, not that the chapter is perfect.

- If an agent's initial pass finds 0 issues, re-read the chapter with this instruction:
  *"Assume your score is inflated by 10 points. What would you flag at that lower score?"*
- Issues may be severity: minor — they don't need to block the pipeline. But they must
  be identified and logged.
- The Quality Guardian specifically must include a "devil's advocate" pass: after
  scoring, identify what it would flag if the chapter scored 10 points lower than
  the initial assessment. Include these as "advisory" issues in the report.

**Why this exists:** In the cozy mystery test, the Character Tracker PASSed chapters
where the killer had a 2:1 mention ratio over the next suspect. In Clean Label,
chapters that self-scored 89+ received 60% emotion ratings from a beta reader.
In Not a Glitch, Ch20 scored 100/100 from the batch editor while containing
"She was eleven years old" and "I'm twelve" for the same character in the same
chapter. Zero-issue reports are a signal of insufficient scrutiny, not quality.

**ENFORCEMENT (added post-Not a Glitch audit):**

1. Advisory items DO NOT satisfy the mandate. At least 1 of the 2 required
   issues must be severity: moderate or higher. If the agent's honest assessment
   is that nothing moderate+ exists, it must document its second-pass reasoning.

2. Each agent must include a SCRUTINY LOG: a 2-3 sentence description of what
   it specifically re-checked during its mandatory second pass, and why it
   concluded there were no additional issues beyond what was already flagged.
   A report without a SCRUTINY LOG is incomplete and must be re-run.

3. The Canonical Fact Verification check (Continuity Guardian) and Season Check
   (Timeline Keeper) are SEPARATE from the minimum issue mandate — they are
   mandatory structural checks that run first. Their results do not count toward
   the "2 issues minimum" requirement — meaning a chapter that passes all
   canonical checks still needs 2 additional issues identified.

4. A batch editor score of 100/100 is a RED FLAG, not a sign of quality. No
   chapter in any manuscript is perfect. A 100/100 score means the batch editor
   missed something. Re-run the analysis with heightened scrutiny.

### Score Calibration Anchors (MANDATORY — reference when scoring)

Self-assessed scores consistently inflate by 8-12 points compared to external
evaluation. The following anchors define what each score range ACTUALLY means,
calibrated against beta reader data from test manuscripts.

**Why this exists:** In testing, the verification agents scored chapters 89-96
that beta readers rated 60-80%. The agents weren't wrong about what was good —
they were wrong about what "good" meant on a 100-point scale. These anchors
correct for that by defining score meanings in terms of observable reader-facing
outcomes, not abstract quality judgements.

```
SCORE CALIBRATION — apply to ALL verification agents:

95-100: EXCEPTIONAL — Reader would highlight passages to share. Craft is
  invisible. Emotional impact is immediate and lasting. Dialogue sounds like
  real people. Physical business is specific and character-revealing. NO
  crutch phrases. NO telling. NO static scenes. This score should appear
  in <5% of chapters. If you're scoring 95+ regularly, you're inflating.

90-94: STRONG — Reader is fully absorbed. Craft is mostly invisible with
  1-2 minor rough spots. Emotional beats land. Dialogue is character-distinct.
  Scenes are dynamic. May have 1 instance of mild telling or 1 slightly
  generic description. This is a good chapter.

85-89: SOLID — Reader stays engaged. Some craft visibility — a metaphor
  that doesn't quite land, a scene transition that's slightly mechanical,
  or dialogue that sounds slightly formal. 2-3 minor craft issues.
  This is an acceptable chapter.

80-84: ACCEPTABLE — Reader continues but isn't gripped. Noticeable craft
  issues: a static scene, some telling-not-showing, dialogue that serves
  the plot more than the characters, or a passage that reads "AI-generated."
  Needs minor revision. 3-5 issues.

75-79: BELOW STANDARD — Reader's attention wanders. Multiple craft issues:
  static scenes, crutch phrases, emotional telling, generic descriptions.
  Needs targeted revision. This is the "rewrite specific scenes" zone.

70-74: WEAK — Reader considers putting the book down. Significant craft
  failures: talking-heads scenes, emotional cataloguing, plot-serving
  dialogue, invisible settings. Needs substantial revision.

Below 70: FAIL — Reader puts the book down. Fundamental craft failures
  across the chapter. Needs full rewrite.

CALIBRATION CHECK: Before finalising your score, ask:
"Would a beta reader who reads 50+ books/year in this genre rate this
chapter the same way I just did?" If the honest answer is "probably
5-10 points lower," adjust DOWN. Better to under-score and be pleasantly
surprised than to over-score and miss issues.

PER-AGENT CALIBRATION NOTES:
- Continuity Guardian: A chapter with 0 factual errors is NOT automatically
  95+. Score reflects how well continuity SERVES the story, not just
  absence of errors. A chapter that's factually correct but emotionally
  flat should score 80-85 for continuity (facts are right but deployed
  mechanically).
- Quality Guardian: The most inflation-prone agent. Apply the calibration
  check twice. A chapter that "does everything right" but reads like
  competent AI prose should score 82-86, not 92-96.
- Character Tracker: Consistency alone doesn't earn high scores. Characters
  must feel ALIVE — surprising yet consistent, reactive yet grounded.
  Perfect consistency with flat characterisation = 80-84.
- Arc Analyst: Tension that is DESCRIBED ("tension filled the room") scores
  lower than tension that is CREATED (through pacing, information control,
  physical danger). Adjust -5 for described vs created tension.
- Timeline Keeper: Most straightforward to score. Factual accuracy is
  binary. But timeline CRAFT (how time is experienced by the reader)
  should influence the score beyond raw accuracy.
```

## Revision Protocol

If chapter score is below 80 or any agent returns "fail":

1. Collect all critical issues across all 6 agents
2. Present to user with recommended fixes
3. Apply fixes SURGICALLY — do not rewrite the chapter
4. Re-run only the agents that flagged critical issues
5. Verify scores improved before proceeding

See `surgical-fixes.md` for the full revision protocol.

## Verification Report File Format (MANDATORY)

Every chapter verification MUST produce a report file saved to disk. This is
not optional — it is the file-system proof that verification actually ran.
Without this file, the pipeline checkpoint cannot be updated and the next
chapter cannot start.

**File path:** `engine-data/reports/ch{NN}-verification.md`

**Required contents:**

```markdown
# Verification Report — Chapter {N}: "{Title}"
Generated: {timestamp}

## Scores
| Agent | Score | Status |
|-------|-------|--------|
| Continuity Guardian | {score}/100 | {pass/warning/fail} |
| Quality Guardian | {score}/100 | {pass/warning/fail} |
| Timeline Keeper | {score}/100 | {pass/warning/fail} |
| Character Tracker | {score}/100 | {pass/warning/fail} |
| Arc Analyst | {score}/100 | {pass/warning/fail} |
| **Weighted Total** | **{score}/100** | **{status}** |

## Issues
### Critical
{list or "None"}

### Moderate
{list or "None"}

### Minor
{list or "None"}

## Chekhov's Gun Status
{gun tracking table}

## Word Count
Target: {target} | Actual: {actual} | {percentage}%

## Beat Delivery
Beat: "{beat_name}" — {delivered/partial/missed}

## Fixes Applied
{list of fixes applied before this report was finalised, or "None — clean pass"}
```

**After writing the report file via the Write tool:**
1. Trust the Write tool — if it returns without error, the file is
   on disk (see `core-pipeline.md` File Operation Policy; do NOT
   Read the file back to verify). If Write errored, re-attempt; if
   the second attempt errors, STOP and alert the user.
2. Display the Progress Dashboard to the user in conversation
3. Update the pipeline checkpoint with the V-Score and "Report Saved: Yes"

Only then may the pipeline proceed to the next chapter.
