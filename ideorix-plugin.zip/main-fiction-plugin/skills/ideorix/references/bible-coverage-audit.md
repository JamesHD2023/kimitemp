---
name: bible-coverage-audit
description: "Engine-neutral binding. After BYO-canon import (or any project import that auto-builds the bible from imported prose), reconcile every named entity in the manuscript against the bible. Report unaccounted-for entities to the user as a triage list BEFORE editing begins, when the cost of a fix is lowest."
version: "2.7.24"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Bible Coverage Audit

A binding/protocol spec invoked by every flow that auto-builds a
canonical bible (story bible / research bible / entity-canon) from
imported prose. Catches partial-extraction gaps BEFORE editing begins.

## Why this exists

When a user imports an existing manuscript via BYO-canon, Scrivener
import, Plottr import, or any other extraction-based onboarding, the
extractor reads the imported documents (PDFs, DOCX, lore notes,
Scrivener research folders, etc.) and builds the bible from what it
finds. Extraction is best-effort:

- PDFs with imperfect text extraction lose entities silently
- Lore docs that imply entities through context (rather than naming
  them on a roster) get under-extracted
- Subplots referenced obliquely in prose ("after that incident in
  Vienna") may name a place/event the extractor doesn't catalogue
- Multi-pass extraction trades coverage for cost; single-pass extraction
  is faster but misses tail-of-distribution entities

The user starts editing with a bible that LOOKS complete (because the
extraction reported success) but is actually a 70-90% subset of what
the manuscript references. Then the engine, asked to generate prose
or suggest edits, sees gaps in the bible and **invents** to fill them
— "new" characters appear, "new" subplots creep in. The user catches
the invention later, after wasted work.

The Bible Coverage Audit closes this gap at import time. Every entity
the manuscript references is reconciled against the bible before the
user begins editing. Gaps are surfaced as a triage list. The cost of
fixing a gap at import time (add to bible / mark as one-off / typo
fix) is one-tenth the cost of fixing it after the engine has built
generated prose on top of the gap.

## Invocation contract

This audit is invoked by the calling flow as a **HARD GATE** between
extraction completion and the user's first editing/generation action.

**Block until the audit completes and the user reconciles flagged
entities.** Do not silently pass through. Do not allow generation
flows to start with unreconciled gaps in the bible.

Flows that MUST invoke this audit:

- Project import (`import-project.md`) — after any importer completes
  and writes the bible / entity-canon
- Per-source-tool importers (Scrivener, Plottr, Novelcrafter,
  screenplay) called by `import-project.md`
- Any BYO-canon flow that imports BOTH lore AND a manuscript (the
  manuscript prose is the surface to audit against; if the BYO-canon
  flow only imports lore with no manuscript, this audit is N/A — there
  is no prose to compare against)
- Any future import flow that auto-builds the bible from prose

Flows that DO NOT need to invoke this audit:

- Create-from-scratch projects (the bible is built turn-by-turn
  alongside the prose; coverage is ~100% by construction)
- Continuing an already-edited Ideorix project (audit ran at original
  import; subsequent edits are caught by the per-chapter Canon
  Validator, not the import-time audit)

## The audit protocol

### Step 1: Extract every named entity from the manuscript prose

Read the imported manuscript files (`manuscript/imported/*` for full-
prose imports; `engine-data/summaries/*` for outline-only imports).
Run named-entity extraction across the prose with the following
entity types:

**Entity types to extract:**

- **Person** — proper nouns referring to people (characters in fiction;
  key figures, sources, interview subjects in non-fiction)
- **Place** — geographic locations (cities, countries, regions, named
  buildings, landmarks)
- **Organisation** — institutions, companies, governments, factions,
  groups
- **Event** — named historical or fictional events ("the Battle of
  Hastings", "the Vienna Incident")
- **Recurring concept / artefact** — named objects, ideologies, or
  recurring concepts that function as canon ("the Sword of Truth",
  "the Compromise of 1850", "the Manhattan Project")

Engine-specific entity taxonomies (e.g. character-archetype roles in
fiction, source-credential tiers in non-fiction) are read from the
engine's canon spec — this audit only requires the five universal
types above for coverage assessment.

**Extraction method:** scan the prose with capitalised-multi-word
detection PLUS proper-noun pattern matching. False positives are
acceptable at this stage (better to over-extract and let the user
triage than to miss). De-duplicate near-matches ("Dr. Jane Thomson"
+ "Dr Jane Thomson" + "Jane Thomson" → one entity for review).

### Step 2: Read the canonical bible

Read the bible file(s) the import flow wrote:

- Fiction: `engine-data/story-bible.md` (or whichever file the import
  flow uses for character-and-world canon)
- Non-fiction: `engine-data/research-bible.md` + `engine-data/
  entity-canon.md` (key figures, places, organisations)

Build the bible-side entity set: every named entity the bible has
catalogued.

### Step 3: Compute the delta

```
manuscript_entities  ∩  bible_entities  =  COVERED
manuscript_entities  −  bible_entities  =  UNACCOUNTED-FOR
bible_entities       −  manuscript_entities  =  BIBLE-ONLY (informational)
```

The UNACCOUNTED-FOR set is the triage list. The BIBLE-ONLY set is
informational only — entities the bible knows about but the prose
doesn't reference yet (not necessarily wrong; could be future
material or pre-imported lore not yet woven in).

### Step 4: Present the triage list to the user

Display:

```
═════════════════════════════════════════════════════════════════
BIBLE COVERAGE AUDIT — {Project Title}
═════════════════════════════════════════════════════════════════

Found {N} named entities in your imported manuscript.
{X} of {N} are in your {bible-name}.
{Y} are unaccounted-for and need triage.

UNACCOUNTED-FOR ENTITIES ({Y}):

  1. Marcus Chen          (Person, mentioned 3× in Ch 4, Ch 7, Ch 12)
  2. the Vienna Incident  (Event, mentioned 1× in Ch 7)
  3. Brightwater Station  (Place, mentioned 2× in Ch 9, Ch 14)
  ...

For each, choose:
  (a) Add to bible — this is a real entity I want catalogued
  (b) One-off mention — appears once or as flavour, no canon entry
  (c) Typo / variant of an existing bible entity — pick which
  (d) Skip for now — flag for later, don't block editing

Or type "all-add" / "all-oneoff" / "all-skip" to bulk-handle.
═════════════════════════════════════════════════════════════════
```

### Step 5: Reconcile and persist

For each entity, apply the user's decision:

- **(a) Add to bible** — append to the appropriate bible section
  (Person → Character/Key-Figure roster; Place → Setting; etc.) with
  a stub entry the user can fill out later. Persist via bash-direct
  append (per File Operation Policy); read the bible file first to
  avoid overwriting existing content.
- **(b) One-off mention** — append to a `engine-data/oneoff-entities.md`
  list (so future audits don't re-flag it).
- **(c) Typo / variant** — log the variant under the canonical entity's
  `aka:` field in the bible, so the Source Guardian / Canon Validator
  treats them as equivalent on subsequent runs.
- **(d) Skip for now** — append to a `engine-data/audit-deferred.md`
  list with the audit timestamp; surface again on next manuscript
  clinic run.

After all entities are reconciled, write a checkpoint to
`engine-data/bible-coverage.md`:

```markdown
# Bible Coverage Audit

**Audit run:** {ISO timestamp}
**Manuscript entities found:** {N}
**Bible entities (pre-audit):** {X}
**Unaccounted-for entities (resolved):** {Y}
  - Added to bible:        {Ya}
  - Marked as one-off:     {Yb}
  - Typo / variant:        {Yc}
  - Deferred:              {Yd}
**Bible coverage (post-audit):** {(X + Ya) / N × 100}%

**Status:** RECONCILED  (editing flows unblocked)
```

### Step 6: Acknowledgement and unblock

Display:

```
✓ Bible coverage audit complete.
  Pre-audit:  {X}/{N} entities in bible ({X/N × 100}%)
  Post-audit: {X+Ya}/{N} entities in bible ({(X+Ya)/N × 100}%)
  {Yb} marked as one-off; {Yd} deferred.

Editing flows unblocked. Run `bible-coverage-audit` again any time
by saying "audit my bible coverage".
```

The HARD GATE is now lifted; downstream flows (chapter generation,
Manuscript Clinic, Edit & Revise, etc.) can proceed.

## Re-running the audit

A user can re-run the audit at any time:

- After importing additional source material
- After a major round of edits (where the prose has accumulated new
  entity references the bible doesn't track yet)
- As a sanity check before submitting / publishing

Re-running compares the current manuscript against the current bible.
Previously-deferred entities surface again. Previously-resolved
entities (added or marked one-off) do not re-flag.

## Performance and bounds

- Extraction runs over manuscript word count. For a 90,000-word
  manuscript, expect ~30 seconds of named-entity scanning.
- The triage UI is bulk-actionable — `all-add`, `all-oneoff`, and
  `all-skip` shortcuts let the user clear large lists quickly when
  the import was clean and only a few outliers need individual
  attention.
- The audit MUST NOT silently auto-resolve entries (e.g. "if entity
  appears < 3 times, mark as one-off automatically"). Auto-resolution
  is the silent-failure shape this audit is designed to prevent.
  Every flagged entity goes to the user.

## Failure modes prevented

The Silent-Failure Audit catalog (`silent-failure-audit.md`) tracks
the engine's drift-failure shapes. Bible Coverage Audit prevents:

- **BYO-canon partial-extraction cascade** — bible reports success
  but is missing 30% of the manuscript's entities; engine generates
  inventions to fill the gaps; user catches the inventions later.
  This audit catches the gap at import time when the cost of a fix
  is one append-line per entity.
- **Imported-vs-created drift asymmetry** — created-from-scratch
  projects have ~100% bible coverage by construction; imported
  projects start at 70-90% and the asymmetry is invisible to the
  user until invented content surfaces. This audit makes the
  asymmetry visible and reconcilable up-front.

## See also

- `silent-failure-audit.md` — full catalog of drift-failure shapes
- `read-verification.md` — read-side HARD GATE that runs before this
  audit (catches empty extraction; the audit catches partial
  extraction)
- `import-project.md` — the import-flow entry point that invokes this
  audit immediately after the bible is built
- The engine's per-chapter canon-drift audit (consult the engine's
  own canon-check spec) is the post-editing complement to this
  pre-editing audit. Together they bracket the writing/editing window
  on both sides — coverage in at import, drift catch on every chapter
  written.
