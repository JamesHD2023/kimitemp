---
name: romantic-comedy-genre
description: Genre-specific instructions for romantic comedy fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Romantic Comedy. Genre Plugin

## Metadata
- id: romcom
- name: Romantic Comedy
- icon: 💖
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Romancing the Beat", "Save the Cat", "Story Circle", "Three-Act Structure"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Workplace Rom-Com | Love blooms in professional settings. offices, restaurants, studios | The workplace creates forced proximity and professional stakes; career vs love tension |
| Fake Dating | Characters pretend to be a couple until pretence becomes reality | The comedy comes from maintaining the façade; every public display of affection moves the needle |
| Opposites Attract | Two fundamentally different people clash their way to love | Comedy mines the friction; the differences that annoy become the qualities they need |
| Second Chance Comedy | Former lovers or friends reconnect with comic complications | History provides depth; the comedy comes from trying to be different people than they were |
| Holiday Romance | Love catalysed by a holiday setting or seasonal event | The ticking clock of the holiday creates urgency; festive settings amplify both comedy and warmth |
| Fish Out of Water Romance | One character is comically displaced into an unfamiliar world | The displacement generates comedy; the love interest becomes guide and anchor |

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Brisk and light: comedy beats frequent, romantic tension with humor
- Must open with: Awkward meet-cute, embarrassing situation, or comedic setup
- Must close with: Laugh, romantic longing, humorous complication, or witty exchange

BEATS PER CHAPTER
1. Comedy Moment: Joke, physical comedy, witty banter, absurd situation, embarrassment
2. Romantic Tension: Attraction shown through humorous lens. awkward awareness, banter as flirtation
3. Misunderstanding or Mishap: Comedy of errors, wrong assumptions, situational humor
4. Character Humiliation: Embarrassing moment that endears or complicates
5. Banter Exchange: Witty dialogue showing chemistry and comedy skills

GENRE-SPECIFIC REQUIREMENTS
- HEA/HFN required: couple together, comedy maintained throughout
- Humor essential: if not funny, not rom-com (even if romantic)
- Light tone: even conflicts are ultimately humorous, not heavy angst
- Meet-cute memorable: often absurd, embarrassing, or unlikely
- Banter constant: wit, teasing, verbal comedy shows chemistry
- Situational comedy: circumstances create humor organically
- Physical comedy acceptable: pratfalls, slapstick, awkward physicality
- Embarrassment comedy: characters in mortifying situations
- Supporting cast funny: friends, family, coworkers provide comic relief
- Misunderstandings common: but resolved through humor and communication
- Lower stakes than drama: career, reputation, embarrassment not life/death
- Optimistic tone: reader knows couple will end up together, enjoying journey

FORBIDDEN
- Heavy angst: rom-com stays light even with obstacles
- Tragedy or darkness: tone too serious loses comedy
- Mean-spirited humor: laughing at characters vs. with them
- Cruel pranks or humiliation without redemption
- All comedy, no romance: must have genuine emotional connection
- Boring protagonist: lead must be funny or in funny situations
- Dated references: topical humor ages poorly
- Stereotypes as punchlines: diversity not comedy fodder
- Long stretches without humor: laughter frequent
- Default rom-com leads: no cookie-cutter klutzy girl meets perfect guy; characters should be specific, surprising, and real beneath the comedy

OBSTACLE LAYERING (critical even in comedy):
A romantic comedy lives and dies by its obstacles, and comedy makes them MORE interesting, not less. You need MULTIPLE obstacles layered simultaneously. internal obstacles (fear of vulnerability masked by humor, past heartbreak hidden behind jokes, self-sabotage disguised as independence) are the emotional engine beneath the laughs. External obstacles (careers, misunderstandings, geography, meddling families) provide the comedic framework. The comedy comes from the obstacles; the romance comes from overcoming them. A single misunderstanding isn't enough. layer complications until the audience is laughing AND desperately rooting for the couple.

LIGHT AND SHADE (comedy's secret weapon):
Rom-com is inherently about contrast. comedy needs emotional sincerity to land, and sincerity needs comedy to stay buoyant. After the biggest laugh, allow a genuine moment of vulnerability. After a sincere emotional beat, let humor break the tension before it becomes heavy. This isn't just good comedy structure. it's what makes rom-com romance WORK. The audience falls in love with the couple in the quiet sincere moments, then the comedy pulls them back to joy. Two purely comedic scenes back to back lose their punch; comedy followed by unexpected tenderness creates the warmth that defines the genre.

ANTI-STEREOTYPE IMPERATIVE:
The best romantic comedies feature specific, surprising, REAL people. not rom-com archetypes. Your leads can be ordinary, prickly, awkward, loud, quiet, funny, or fierce. Avoid the default charming-but-clueless heroine and the arrogant-but-secretly-sweet hero. those are shorthand, not characters. The comedy should emerge from who these specific people ARE, not from stock situations imposed on stock types.

NARRATIVE LAYERS (A/B/C stories):
Rom-com benefits from layered storytelling beyond the central romance:
- A-story: The romance itself: the couple's journey from meet-cute to HEA
- B-story: The protagonist's personal growth arc: career, friendship, family, or self-discovery that intersects with and complicates the romance
- C-story: The comedic "runner": a secondary comedy thread (eccentric neighbor's schemes, workplace chaos, wedding planning disasters) that weaves throughout and pays off at the climax
These layers create richer comedy: the A-story provides emotional stakes, the B-story deepens character, and the C-story keeps laughs consistent even when the romance turns sincere. The best rom-com climaxes happen when all three threads collide simultaneously.

SCENE CONSTRUCTION:
Every scene is a story with its own beginning, middle, and end:
- Characters enter wanting something: even in a casual coffee scene, someone has an agenda (even if it's "act normal around the person I'm falling for")
- Scenes are driven by CONFLICT (even funny conflict), not just dialogue
- Two people flirting without obstacle is pleasant but not comedy: add what makes the flirting difficult, inappropriate, or hilariously timed
- Multiple beats can exist within a single scene: a comedy beat, a romantic beat, and an emotional beat can all land in one scene when orchestrated well
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (relationship arc), Stimulation (comedic beats — laugh delivery), Captivation at set-piece scenes.

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-protocol.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE
- POV: 1st person (intimate, comedic voice) or dual 3rd limited (both perspectives)
- Tense: Past (traditional) or present (immediacy for comedy timing)
- Voice: Witty, self-deprecating, observant, warm, optimistic
- Reading level: Accessible: light, fun, quick read

PROSE IMPERATIVES
- Comedic timing in prose: setup and punchline structure
- Internal monologue funny: character's thoughts provide humor
- Banter sparkles: quick exchanges, wit, teasing, double meanings
- Physical comedy described: pratfalls, awkward movements, slapstick
- Embarrassment vivid: mortifying moments shown in excruciating detail
- Observational humor: character notices absurdity in situations
- Similes and metaphors funny: comparisons create comedy
- Self-awareness: character recognizes own ridiculousness
- Absurdity embraced: unlikely scenarios played for comedy
- Warmth underlying: humor with heart, not just jokes

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- The VOICE must be funny from sentence one: if the reader isn't smiling by paragraph two, the book has failed its audition
- Tension floor: 4 (comedy tension = "I need to know what absurd thing happens next")
- Open with character in motion, mid-disaster, or mid-thought: never with throat-clearing setup
- Dialogue density: 35%+ in Ch 1: banter establishes chemistry fast

Banter scenes (prose rhythm):
- Rapid-fire short exchanges (3-8 words per line during peak banter)
- Longer internal monologue BETWEEN volleys for comic commentary and reaction
- Interiority budget: 40%: the character's witty self-commentary IS the comedy
- One-line paragraphs for punchlines; setup gets the longer paragraph

Emotional sincerity scenes (prose rhythm):
- Sentences lengthen as humor drops: prose breathes differently when the comedy mask slips
- Paragraphs deepen; interiority shifts from wit to genuine feeling
- These moments earn power by CONTRAST with the surrounding comedy: keep them brief

Climax/resolution prose rhythm:
- Grand gesture scenes: short sentences building momentum, comic energy accelerating toward the declaration
- The comedy and the sincerity MERGE: the reader should laugh and feel simultaneously
- Final beat: one quiet, genuine line after the comedy crescendo: the landing that makes the book linger

GENRE-SPECIFIC STYLE
- Meet-cute absurd: spilled coffee, mistaken identity, caught in compromising position
- Banter as foreplay: verbal sparring shows chemistry and humor
- Embarrassing situations: character mortification reader finds charming
- Fish-out-of-water: character in wrong environment creates comedy
- Supporting cast eccentric: quirky friends, overbearing family, odd coworkers
- Misunderstandings escalate: comedy of errors building
- Internal panic humorous: overthinking, catastrophizing shown comedically
- Physical awareness awkward: attraction manifests in klutzy behavior
- Pop culture references: current but not dependent on specific knowledge
- Happy accidents: mishaps that bring couple together

FORBIDDEN WORDS/PHRASES
- Explaining jokes: if reader doesn't get it, doesn't work
- "Hilariously": show funny, don't tell it's funny
- Overused comedy words: "zany," "wacky," "quirky" tell not show
- Excessive exclamation points: undermines actual humor
- Try-hard comedy: forced jokes, overwritten for laughs
- Mean spirited: humor at character's expense without love
- Sexist/racist/ableist jokes: punching down not funny

DIALOGUE. THE POWER OF THE UNSAID (comedy edition):
- In rom-com, what characters DON'T say is often funnier AND more romantic than what they do say: the gap between obvious feelings and verbal denial IS the comedy
- Characters who deflect with humor when they mean something sincere. the joke that's actually a confession, the bit that's actually vulnerability. this is rom-com gold
- Each character must speak distinctly: their humor style, their deflection patterns, their specific way of avoiding sincerity should be as individual as a fingerprint
- The most powerful rom-com moments happen when the comedy drops and someone says exactly what they mean: and it lands because everything before was deflection

METHOD WRITING. EMOTIONAL IMMERSION (even in comedy):
- Identify what you want the reader to FEEL before writing any key scene: joy? secondhand embarrassment? the ache of watching two people who obviously belong together refuse to see it?
- Comedy that doesn't have genuine feeling underneath becomes empty slapstick. The humor matters BECAUSE the emotion is real
- Write comedy through the senses: the specific physical comedy of nervousness, the exact texture of mortification, how attraction manifests in someone who is trying desperately to be funny instead of honest
- Never be cynical about the romance beneath the comedy: don't sacrifice emotional sincerity for a joke. The best rom-coms make you laugh AND feel something real simultaneously

INTIMATE SCENES. COMEDY WITH HEART:
- Rom-com intimate scenes should illuminate character through humor: awkwardness, interrupted moments, comedy of errors, the gap between romantic expectation and messy reality
- Imperfection IS the point: the perfectly choreographed romantic moment is for other genres. Rom-com intimacy is genuine, surprising, and often funny in ways that make it more real
- Build romantic moments into the comedy landscape: the accidental touch that silences the banter, the genuine look that makes the joke die in someone's throat
- After vulnerable moments, characters often retreat to humor: track this pattern and let it evolve as the relationship deepens

THEME BENEATH THE COMEDY:
Every strong rom-com has a THEME. what the book is really about beneath the laughs and the meet-cute. Is it about learning to be vulnerable? About choosing messy real love over safe loneliness? About finding someone who sees the real you behind the comedy? Theme gives rom-com its emotional staying power. When the reader finishes laughing, it is the theme that makes them hug the book.

THE SURPRISE PRINCIPLE:
Even in rom-com where the ending is guaranteed (HEA), the comedy must surprise:
- If the reader can predict the punchline, the joke fails: find the unexpected angle
- The path to the inevitable happy ending should be completely unpredictable: the reader knows WHERE but not HOW
- Avoid the obvious comedic reaction; find the third or fourth possible response
- The best rom-com humor catches readers off guard precisely because they thought they knew what was coming
- This applies to romantic moments too: the predictable grand gesture is less satisfying than the surprising one that's perfectly specific to these characters

CONCISENESS IN COMEDY:
Rom-com prose must be lean. excess words kill comedic timing:
- Shorter sentences for punchlines; longer ones for romantic setup
- If a joke can land in fewer words, use fewer words
- The rhythm of comedy is setup (build) → beat (pause) → payoff (snap). verbose delivery flattens all three
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Actually funny. reader laughs, if not funny it's not rom-com
2. HEA/HFN delivered. couple together, optimistic ending
3. Light tone maintained. even conflicts ultimately humorous, not heavy
4. Chemistry through comedy. attraction shown via banter and humor, not just statements
5. Likable protagonist. funny but also rootable, humor doesn't hide empathy

GENRE-SPECIFIC CHECKS

Humor frequent. comedy beats every chapter minimum, reader laughs regularly
HEA/HFN present. couple together, happy, hopeful ending
Light tone. even obstacles treated with comedy lens, not prolonged angst
Banter sparkles. witty dialogue showing chemistry throughout
Meet-cute memorable. first meeting funny, absurd, or charming
Chemistry shown. attraction demonstrated through comedy, not just told
Embarrassment comedy. mortifying moments handled with warmth, not cruelty
Running gags. callbacks to earlier jokes paying off
Supporting cast funny. friends, family provide comedy beyond leads
Optimistic. hopeful tone throughout, even in conflicts

AUTOMATIC FAILS

Not funny. if reader doesn't laugh, failed as rom-com regardless of romance quality
Tragic ending. couple not together, violates genre promise
Heavy angst. prolonged darkness or serious trauma without lightness to balance
Mean-spirited. humor cruel, laughing at characters not with them
No chemistry. attraction stated, not shown through comedy and banter
Boring protagonist. lead unfunny in unfunny situations
Stereotypes as punchlines. diversity used as comedy fodder
All comedy, no romance. joke book without genuine emotional connection
Dark tone. if it feels like drama with occasional jokes, it's not rom-com
Dated badly. references so topical they're already stale

ACCEPTABLE IMPERFECTIONS

Not every joke lands. comedy is subjective
Some sweetness without humor. emotional moments earn their place
Occasional serious beat if resolved with lightness
Physical comedy might not translate to all readers

RED FLAGS TO INVESTIGATE

Long stretches without a laugh. more than two pages of pure sincerity without comedic relief
Humor telling rather than showing—"she said something hilarious" instead of actually being funny
Banter that reads as hostile rather than flirtatious. cruelty disguised as wit without underlying warmth
Comedy and romance running on parallel tracks. funny scenes separate from romantic scenes instead of intertwined
One protagonist significantly funnier than the other. comedy imbalance undermining dual chemistry
Running gags set up but never paid off. or callbacks landing without emotional resonance
Embarrassment humor without affection. mortifying moments that make the reader cringe rather than charmed
Supporting cast stealing the show. secondary characters funnier than the leads
Emotional vulnerability immediately deflected with jokes every time. the comedy shield never cracking
Grand gesture feeling generic. resolution that could belong to any rom-com rather than these specific characters
Predictable punchlines. reader seeing the joke coming before it lands, setup-payoff too obvious
Tone whiplash. sudden heavy emotional scenes jarring against established lightness without bridging
Both characters sounding identical in dialogue. same wit style, same deflection patterns, no distinct voices
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Running gags: Callback jokes, recurring comedy elements maintained throughout
2. Character quirks: Funny traits, habits, catchphrases consistent
3. Relationship milestones: Romance progression tracked like regular romance
4. Comedy setup payoffs: Jokes established early pay off later
5. Embarrassing moments: Mortifying events remembered, referenced later

GENRE-SPECIFIC TRACKING
- Running gags: Recurring jokes that build throughout story
- Character quirks: Funny habits, speech patterns, behaviors
- Embarrassing incidents: Major humiliation moments: referenced later
- Meet-cute details: First meeting specifics: becomes inside joke
- Banter evolution: How verbal sparring changes as feelings develop
- Comedy obstacles: Misunderstandings, mishaps that create conflict
- Supporting cast antics: Friends/family funny moments and arcs
- Inside jokes: Couple's private humor developing
- Failed attempts: Romantic gestures that go wrong tracked
- Comedy callbacks: Earlier jokes referenced later for payoff

ACCEPTABLE INCONSISTENCIES
- Minor physical comedy variations if character remains klutzy
- Slight dialogue style evolution as characters grow
- Comedy intensity varying by scene if overall tone maintained

ROMANCE-CRAFT CONTINUITY:
- Track what characters have SAID vs. NOT SAID about their feelings: in rom-com, humor often masks genuine feeling, so track when jokes are deflection vs. genuine comedy. When a character finally drops the comic shield to say something real, the reader must feel the weight of everything that was previously unsaid
- Track obstacle progression: comedic misunderstandings and internal fears should evolve, not repeat. The same miscommunication pattern shouldn't recur without escalation. Internal obstacles (fear of vulnerability, past heartbreak) should be chipped away progressively
- Track emotional register alternation: flag sequences that are purely comedic without emotional grounding, or sequences that become too earnest without comedic relief. Rom-com's signature rhythm is comedy-sincerity-comedy
- Track character consistency beneath the humor: a character's specific comedy style, their deflection patterns, their moments of genuine vulnerability should be consistent. Growth means the comedy evolves. the character becomes braver about sincerity. not that their personality changes
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Comedy style: How character is funny. witty, klutzy, awkward, observant. maintained
2. Likability: Protagonist funny AND rootable. humor doesn't hide empathy
3. Chemistry through banter: Verbal wit showing attraction and compatibility
4. Relatable flaws: Quirks and imperfections make comedy and endear character
5. Growth through humor: Character arc shown through comedy lens

GENRE-SPECIFIC CHARACTER ELEMENTS
- Funny or in funny situations: Protagonist makes reader laugh
- Self-awareness: Character recognizes own ridiculousness
- Quick wit: Banter skills, verbal dexterity, comedic timing
- Endearing flaws: Klutzy, socially awkward, overthinks: lovable quirks
- Optimistic: Even when things go wrong, underlying hopefulness
- Observant: Notices absurdity, makes funny connections
- Vulnerable through humor: Uses comedy as defense or coping
- Career comedy: Job provides opportunities for mishaps and humor
- Supporting cast: Funny friends, eccentric family, quirky coworkers

CHARACTER ARCS MUST
- Show romance arc: falling in love despite comedy chaos
- Demonstrate growth: overcoming fear or insecurity
- Maintain comedy throughout: character stays funny while changing
- Earn HEA through humor: resolution feels right comedically and romantically
- Build chemistry through banter: wit creates attraction
- Face embarrassment: mortifying moments test character
- Learn to be vulnerable: comedy shield lowered for love

TRACK
- Comedy style: witty, physical, awkward, observant
- Quirks and habits: funny traits maintained
- Embarrassing moments: major mortifications character remembers
- Banter evolution: how verbal sparring changes with feelings
- Career comedy: job-related mishaps and humor
- Running gags: recurring jokes involving character
- Catchphrases or verbal tics: consistent funny language
- Chemistry moments: attraction shown through comedy
- Growth areas: what character learns through humorous trials

CHARACTER BUILDING. GROUND UP:
Build each lead from the ground up BEFORE they appear on the page. even in comedy, especially in comedy:
- Background questions: What do they want out of life? What's stopping them (beyond the obvious comedic premise)? What were their formative relationships? What made them funny: is humor a defense mechanism, a worldview, or genuine joy?
- Character tests: What's in their bag? How do they react when someone is genuinely kind to them (not just funny)? When do they stop deflecting with humor?
- The vast majority of this backstory never appears on the page, but it informs every joke, every deflection, every moment where the comedy mask slips to reveal the real person underneath
- The funniest rom-com characters are funny because of who they specifically ARE: not because funny things happen to generic people

ANTI-STEREOTYPE IMPERATIVE:
Rom-com has its own dangerous defaults. the klutzy adorable heroine, the arrogant charming hero, the gay best friend who exists for quips, the meddling mother. Subvert these ruthlessly. Your leads can be ordinary, prickly, awkward, loud, quiet, or fierce. The comedy should emerge from SPECIFIC characters in SPECIFIC situations. not from stock types performing expected bits. Messy, real, surprising people are ALWAYS funnier than archetypes, because real humanity is inherently absurd and wonderful.

CHARACTER CAMP (especially the supporting cast):
Rom-com supporting casts make or break the genre. build them as fully as the leads:
- Map relationships between ALL characters, not just how they relate to the protagonist: how does the best friend feel about the love interest? What's the dynamic between the meddling parent and the protagonist's boss?
- Every recurring character should be specific enough that their comedy style is distinct: the best friend is funny differently than the coworker, who is funny differently than the rival
- Supporting characters should feel like they have their own lives, problems, and comedy happening offscreen: references to their ongoing chaos add texture and laughs
- The richest rom-com casts have invisible relationships between supporting characters that surface at surprising moments
```

## Arc Rules

```
ACT I (Chapters 1-10): Meet-Cute and Comedy Setup
- Ch 1: Meet-cute: absurd, embarrassing, memorable first encounter
- Ch 2-3: Comedy world established: characters' funny lives shown
- Ch 4-5: Chemistry through banter: wit, teasing, verbal foreplay
- Ch 6-8: Comedy obstacles: mishaps bringing together or complications
- Ch 9-10: First major milestone: kiss, date, or big comedy payoff
- Purpose: Establish comedy tone, characters meet absurdly, chemistry through humor
- Ends with: Commitment to relationship despite comedy chaos, first kiss or major comedy milestone

MIDPOINT (Chapter 15): Relationship Deepening with Comedy Complication
- Deepest intimacy so far OR biggest comedy misunderstanding
- Tonal shift: From falling to committing, or from fun to "uh oh this is real"

ACT II (Chapters 11-23): Deepening Romance Through Comedy
- Ch 11-14: Relationship blossoming: funny dates, meeting families, workplace antics
- Ch 15: MIDPOINT: major comedy complication or deepest vulnerability
- Ch 16-18: Running gags paying off, inside jokes developing
- Ch 19-21: Comedy stakes rising: misunderstanding escalating, deadline approaching
- Ch 22-23: Black moment: breakup, biggest fight, or maximum misunderstanding chaos
- Purpose: Love grows, comedy complications escalate, stakes feel real despite lightness
- Ends with: Third act breakup OR biggest misunderstanding before resolution

ACT III (Chapters 24-30): Grand Gesture and HEA
- Ch 24-25: Realization: what matters, willing to risk embarrassment for love
- Ch 26-28: Grand gesture: public declaration, running through airport, comedic romance
- Ch 29: HEA: couple together, comedy and romance resolved
- Ch 30: Epilogue: funny future glimpse, running gag payoff
- Purpose: Comedy resolution, couple reunites, lighthearted but emotionally satisfying
- Ends with: HEA: couple together, comedy callback, hopeful epilogue

GENRE PROMISE
- HEA/HFN: couple together, still funny
- Comedy beats every chapter minimum
- Light tone: even obstacles ultimately funny
- Banter: witty dialogue throughout
- Embarrassing moments: protagonist mortified charmingly
- Meet-cute memorable: absurd or unlikely
- Chemistry through comedy: attraction via humor
- Happy ending: optimistic, hopeful, satisfying
- Supporting cast funny: friends/family provide laughs
- Running gags: callbacks to earlier jokes
- No heavy angst: stays light despite conflicts

REQUIRED CHECKPOINTS
- Ch 1: Meet-cute: funny, memorable, chemistry evident
- Ch 8: Banter established: verbal chemistry clear
- Ch 10: Major comedy milestone: big laugh or romantic moment
- Ch 15: Relationship deepening AND comedy complicating
- Ch 20: Running gags paying off: callbacks landing
- Ch 23: Black moment (brief): breakup or max misunderstanding
- Ch 28: Grand gesture: public, potentially embarrassing, romantic
- Ch 30: HEA with comedy callback: satisfying, funny, hopeful

EMOTIONAL CONTRAST IN ROM-COM ARC:
Chart emotional highs and lows throughout the arc. this is comedy's superpower. After the biggest laugh, introduce a moment of genuine vulnerability that catches the reader off guard. After a sincere emotional milestone, let comedy break the tension before it becomes too heavy. After a romantic high, introduce the comedic complication that makes the reader simultaneously laugh and groan. This oscillation between hilarity and heart is what makes rom-com work. Two purely comedic scenes back to back lose impact; comedy followed by an unexpected moment of real feeling creates the warmth that defines great rom-com.

EARNED ENDINGS:
The HEA must be TRUE to the characters built throughout the story—not a generic grand gesture imposed from outside. Seed the resolution early: the inside joke that becomes the declaration, the embarrassing moment that becomes the foundation of trust, the specific vulnerability that only this particular person can see. The reader should think "of course—it HAD to end THIS way, with THESE two specific people." The grand gesture should feel earned by everything that came before, and it should be both funny AND sincere—that's the rom-com promise.

THEME BENEATH THE LAUGHTER:
Every strong rom-com weaves its theme through the comedy and the romance simultaneously. If the theme is about learning to be vulnerable, the comedy should arise FROM the character's avoidance of vulnerability, and the romance should require them to drop the comic shield. Theme gives rom-com its emotional staying power. the reason readers re-read and re-watch their favorites. It's not the jokes they return to; it's the feeling.
```

## Timeline Rules

```
TIME SCALE
- Total story duration: Weeks to few months (occasionally compressed to days/weeks)
- Chapter time span: Days to week: brisk pacing matches comedy rhythm
- Time progression: Linear: straightforward timeline suits comedy beats

GENRE-SPECIFIC TEMPORAL RULES
- Faster than heavy romance: comedy lightness allows quicker progression
- Meet-cute to love happens relatively quickly: weeks to months typical
- Misunderstandings resolve faster: comedy of errors can't drag
- Holidays or events common: weddings, holidays create comedy deadlines
- Montages acceptable: showing time passing through comedy vignettes
- Third act breakup brief: not too much angst before resolution
- Running gags need time: recurring jokes require multiple instances over weeks
- Embarrassment fades with time: but callbacks keep it funny
- Chemistry fast: rom-com can skip slow burn if comedy supports rapid connection

TRACK CAREFULLY
- Days since meet-cute: relationship timeline from absurd beginning
- Time until deadline event: wedding, presentation, holiday creating pressure
- How long between running gag instances: spacing for comedy effect
- Dates and romantic milestones: first kiss, first date tracked like regular romance
- Embarrassing incidents: when major mortifications occurred
- Comedy escalation: misunderstandings building over days/weeks
- Work deadlines or pressures: career comedy requiring specific timing
- Holiday approach: Christmas, Valentine's Day, wedding season timing

FLEXIBLE
- Exact times of day unless comedy depends on it
- Minor daily routines between comedic set pieces
- Background character schedules
```

## Genre-Specific Craft Techniques

Romantic comedy is the hardest sub-genre of romance to fake.
Romance can survive flat prose if the emotional beats land;
suspense can survive flat prose if the plot machine works;
comedy cannot. The reader must laugh — and not in the abstract
but on this specific page, at this specific line, with the
particular quality of laughter (the snort, the wince, the
ache-laugh) the moment intends. The techniques below are the
craft surface where rom-com either delivers or dies, scene by
scene.

### The Comic Escalation Engine

Each misunderstanding, mishap, lie, or coincidence compounds
the one before it. The lie that requires a bigger lie. The
favour that spirals into an obligation that requires a fake
fiancé that requires a meeting with the parents that requires
a wedding rehearsal. The accidental text that is responded to
in good faith. Comedy escalation obeys the same physics as
dramatic escalation: each beat must raise the stakes, not
merely repeat the original premise at higher volume. The craft
test is the irreversibility test — at the end of each comic
sequence, can the protagonist still walk back to the position
they held at the start? If yes, the sequence has not escalated.
The best rom-com plotting has a one-way ratchet: every comic
beat closes a door behind it, until the protagonist's only
remaining choice is the romantic truth they have been avoiding
all book. Repetition without escalation is the failure mode;
the second pratfall is half as funny as the first, the third
is not funny at all.

### The Banter as Foreplay

Witty dialogue that simultaneously entertains and builds
attraction. Great rom-com banter operates on three layers
within the same exchange: what the characters say (the visible
joke), what they mean (the subtextual feint or admission), and
what they feel (the body's response — the smile they cannot
suppress, the breath caught, the line they did not intend to
deliver). The reader should laugh and swoon in the same
exchange, not in alternating exchanges. Banter that is merely
clever without emotional subtext is sketch comedy; banter that
is merely tender without comic register is generic romance
dialogue with question marks at the end. The technique requires
that each lead has a distinct comic voice — sharper or drier or
more deflective than the other — and that their voices clash
productively (the deadpan and the chaotic, the sincere and the
ironist, the over-talker and the listener who weaponises silence).
Test: can the reader identify which lead spoke any line of
banter without the dialogue tag? If not, the voices are not
yet distinct.

### The Humiliation-to-Tenderness Turn

The comic moment that unexpectedly reveals vulnerability. The
character who falls spectacularly in public and is helped up
by someone who does not laugh. The disastrous best-man speech
that reveals genuine feeling under the wreckage. The
karaoke-induced confession the protagonist would never have
made sober. These pivot moments are where rom-com becomes
romance — the laughter catches in the throat, the reader feels
the shift before the characters have named it. The technique
requires that the humiliation be earned (genuine, embarrassing,
emotionally exposing — not a cute fall in a clean dress) and
that the tenderness be specific (the particular gesture only
this love interest would make: the napkin offered without
comment, the change of subject that protects rather than
mocks). The pivot must occur within the same scene; if the
humiliation happens in chapter eight and the tenderness arrives
in chapter twelve, the contract has been broken. The pivot's
emotional weight is exactly proportional to the humiliation's
specificity.

### The Ensemble Comedy Web

Supporting characters creating comic complications for the
couple. The meddling best friend whose advice is always
confidently wrong. The oblivious parent whose questions
unintentionally land. The rival who is more ridiculous than
threatening. The colleague who is reading the situation more
accurately than either lead. Each ensemble figure must have a
distinct comic voice (catchphrase, register, body of running
references) and a particular relationship to the romance —
supportive, sceptical, oblivious, sabotaging — that creates a
specific kind of complication. The interference should feel
organic to who they are, not invented to drive plot. Test: can
each significant supporting character generate a laugh in a
scene without the leads present? If they cannot carry their
own scene, they are scenery, not ensemble. The ensemble's
collective response also functions as the reader's chorus —
when the ensemble starts rooting for the couple, the reader
feels permitted to commit; when the ensemble starts despairing,
the third-act break feels earned by the social world rather
than by authorial fiat.

### The Laugh-Then-Ache Beat

Comedy that pivots to genuine emotion within a single line or
exchange. The joke that lands and then lingers because it
revealed something true. The throwaway aside that the reader
realises has been carrying the weight of the whole book. This
technique prevents rom-com from becoming pure farce — the
comedy serves emotional revelation, and the emotion makes the
comedy richer rather than diluting it. The craft requires
restraint: the writer must not announce the ache, must not
italicise the line, must not let the next paragraph
explain it. The reader's recognition is the recognition; the
prose that points at it kills it. The test is the laugh-cry
test: in the final pass, mark every line where the reader is
likely to laugh and every line where the reader is likely to
ache; the genre's signature pleasure is the lines that occupy
both columns. A rom-com with a high count of pure-laugh and
pure-ache lines but a low count of laugh-and-ache lines has
not yet found its register.

### The Grand Gesture Subverted

Rom-com inherits a structural beat from its filmic ancestors:
the third-act grand gesture, in which the protagonist runs
through an airport, gives a speech in front of a crowd,
arrives at a wedding to interrupt the wrong wedding, paints
"YES" on a bedsheet hung from a fire-escape. Modern rom-com
needs to handle this beat with awareness — too earnest and it
plays as parody of itself; too ironic and it lands as
emotional cowardice. The strongest rom-coms subvert the
gesture: it is interrupted, it is refused, it is met with "this
is mortifying, please come down", or the gesture is replaced
by something smaller and truer (the unannounced presence in the
hospital waiting room; the offer of help with the move because
the partner does not actually need a speech, they need
follow-through). The technique acknowledges the genre's history
while refusing the genre's lazier defaults. The replacement
gesture must still be a gesture — committed, costly, public
enough to count — but specific to who these two people are.

### Romantic Comedy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "hilarity ensued" | Show the specific comic sequence and its specific physical wreckage |
| "their banter was electric" | Show the actual witty exchange — three lines minimum, both leads contributing |
| "she was a hot mess" | Show the specific disaster in action — what is spilled, broken, lost, miscalibrated |
| "he was infuriatingly attractive" | Show the specific attractive trait that annoys her and the specific way it interrupts her thought |
| "fate had a sense of humour" | Show the specific coincidence — who, where, why these two could not have avoided this |
| "the meet-cute was straight out of a movie" | Show the specific embarrassing encounter; the genre is allowed to know it is a meet-cute, but the scene must do the work |
| "sparks flew immediately" | Show the specific charged first interaction through dialogue and body, not summary |
| "she rolled her eyes but couldn't hide her smile" | Pick one (the eye roll OR the smile) and show it; both is greedy and unspecific |
| "opposites attract" | Show the specific clash that creates chemistry — what each finds unbearable about the other on day one |
| "love was the last thing on her mind" | Show what IS on her mind in concrete detail and how the love interest disrupts it |
| "an unlikely pair" | Show the specific contrast through one scene; the unlikeliness must be lived, not asserted |
| "she could feel his eyes on her" | Show what makes her certain — the specific peripheral awareness, the change in the room's sound |
| "the chemistry was undeniable" | Stop explaining; write the scene in which the reader experiences it |
| "they finished each other's sentences" | Pick the sentence that gets finished and show the precise word that lands |
| "his smile could melt ice" | Show the smile through what it does to her body and what she does to control her response |
| "a kiss that changed everything" | Show what each is doing differently the morning after that they would not have done before |
| "love was a battlefield" | Replace with a sport-specific or activity-specific metaphor that suits these two characters |
| "she was the kind of woman who..." / "he was the kind of man who..." | Stop type-casting; show this specific person doing this specific thing |

## Genre-Specific Revision Rules

Six revision passes specific to romantic comedy, each with a
single question, run cover-to-cover before the next begins.
Comedy does not survive distracted attention — a pass that
tries to check both joke quality and romantic arc will fail
both. The rom-com reader's contract is specific (laugh on this
page, swoon on that one, ache on the third) and the writer who
delivers all three at the right frequency, in the right order,
with the right escalation has done the genre's work.

### Pass 1: Comedy Consistency Audit

Read the manuscript only for comic tone, asking whether the
humour style remains coherent from chapter one to the final
page. Identify the dominant register early (broad physical
comedy, dry observational wit, character-driven absurdism,
banter-led, ensemble-led) and verify it sustains — with
deliberate variation rather than drift. Check that darker
moments do not undercut the comedic contract: a rom-com can
include grief, illness, redundancy, family rupture, but those
beats must be handled in a register the surrounding comedy can
hold. Verify the comedy evolves: early broad humour should
refine into character-specific wit as the reader comes to know
the characters. Flag any tonal jump-cut where the comic
register switches without setup, and any chapter that abandons
comedy entirely without earning the absence (the genre permits
quiet chapters but not voiceless ones — the comic sensibility
should remain audible in the prose even when the page is not
trying to make the reader laugh out loud).

### Pass 2: Laugh Frequency Check

Mark every intended laugh moment in the manuscript with a
margin tick. Plot the distribution — are they spread across
the book or clustered in the first half? Any stretch of more
than three pages without humour in a rom-com is too long;
flag those stretches and decide whether they earn the absence
(the emotional centre, the grief beat, the rare fully-serious
exchange the romance has been working toward) or whether the
voice has simply lapsed. Check that comedy appears within
romantic scenes as well as in standalone comic scenes — the
funniest rom-coms are funny during the love story, not around
it. Test the laugh quality at sample points: does the line
still land on the second read, or did its surprise carry it?
Lines that survive the second-read test are the genre's gold;
lines that depend purely on shock-of-newness are the kind that
date the book and erode reread value.

### Pass 3: Romance-to-Comedy Balance

Verify that the romantic arc is not sacrificed for laughs. The
comedy should serve the romance, not overshadow it. Check that
the emotional climax (the declaration, the gesture, the
reunion, the recognition) earns genuine feeling despite — and
because of — the comedy that preceded it. The risk specific
to rom-com: comic momentum can carry the writer past the
romantic beats that the form requires. Audit the central
relationship: does it evolve in measurable stages (first sight,
first private conversation, first vulnerability, first kiss,
first crisis, first reconciliation, commitment)? Does each
stage have a scene the reader can name? If the comedy has
crowded out the relationship's evolution, the reader will
laugh through the book and feel nothing about whether the
couple ends together. Flag any relationship beat that occurs
off-page or in summary; in rom-com these must be earned in
scene.

### Pass 4: Banter Quality Pass

Read all dialogue between the leads aloud — in the writer's
own voice, ideally with a second person reading the other
lead's lines. Does it crackle, or is the rhythm flat? Is each
exchange distinct, or are the leads having the same witty
argument across multiple chapters in slightly different
costumes? Check banter evolution: early banter should be
defensive (deflection, point-scoring, the comic equivalent of
crossed arms); middle banter should be exploratory (the line
that admits more than the speaker meant, the silence the
other lead notices); late banter should be intimate (the
joke only these two would make, the shorthand that has built
up between them, the line that lands in front of friends and
makes the friends look at each other). Test: pull six banter
exchanges spaced across the book; can a reader unfamiliar with
the manuscript order them in story sequence based on the
relational temperature alone? If not, the banter has not
evolved.

### Pass 5: Emotional Sincerity Beneath Humour Test

Read the final act with fresh eyes — ideally after a 24-hour
gap from the rest of the manuscript. When the comedy drops
and genuine emotion surfaces (the declaration, the apology,
the choice the protagonist could not have made at the start
of the book), does it land? If the reader has been laughing
for 250 pages, the emotional payoff must be powerful enough
to shift register without feeling jarring. The best rom-com
endings make the reader cry while smiling: the emotion
arrives wearing the comedy's clothes, but it is undeniably
emotion. Test the sincerity by reading the final declaration
without its surrounding comedy: does the speech, the gesture,
or the line still mean what it needs to mean? If the
sincerity collapses without the comic scaffolding, the
emotional beat has not been written; only the comic feint
around it.

### Pass 6: The Third-Act Break Check

Rom-com has a structural pressure point: the third-act break
(the misunderstanding, the secret revealed, the choice
withheld) that separates the leads before the final reunion.
This beat is the genre's most-criticised convention, frequently
because the break is contrived, the misunderstanding is one
honest conversation away from resolution, or the secret
revealed should have been disclosed earlier. Run a dedicated
pass on this beat asking: is the break load-bearing for both
leads (each has reason to feel wronged, not only one), and
does it surface a real obstacle (a value conflict, a family
loyalty, a career fork, a wound from before the book began)
rather than a manufactured one? Test the resolution: does the
reunion require both leads to grow, or only one to apologise?
If the reunion is one apology away, the break was decorative.
The break is the genre's permission slip for the ending to
matter; if the break does not earn that mattering, the ending
will land soft.

## Names & Patterns to Avoid

### Forbidden Patterns
- **Comedy that mocks the romance**. The genre must take its own love story seriously even while being funny about everything else
- **Slapstick without emotional stakes**. Physical comedy works in rom-com only when it reveals character or advances the relationship
- **The "not like other girls" heroine**. The quirky, clumsy, relatable protagonist who is actually a wish-fulfilment fantasy; give her genuine flaws
- **The humourless love interest**. If only one half of the couple is funny, the chemistry will not work; both leads need comic timing

### Cliché Setups to Avoid
- The klutzy heroine who literally falls into the hero's arms (unless the contrivance is acknowledged and subverted)
- The misunderstanding that could be resolved with one text message
- The gay best friend whose only function is to dispense wisdom and sass
- The rival love interest who is obviously wrong from page one (give them genuine appeal)

### Naming Considerations
- Rom-com names should be memorable and fun to say. avoid names that feel heavy or ponderous
- Alliterative names can work comedically but risk feeling cartoonish
- Avoid names that are difficult to distinguish in dialogue-heavy scenes
- Consider how names sound when shouted across a room. rom-com characters call each other's names frequently

## Comp Titles

Romantic-comedy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Pride and Prejudice* — Jane Austen (1813): the wit-and-misunderstanding template that modern romcom inherits.
- *Bridget Jones's Diary* — Helen Fielding (1996): the modern romcom anchor; voice-led commercial romance.
- *Confessions of a Shopaholic* — Sophie Kinsella (2000): the chick-lit / romcom hybrid template.

### Contemporary (current best-in-class)

- *The Hating Game* — Sally Thorne (2016): enemies-to-lovers contemporary romcom; modern category-romance template.
- *The Wedding Date* — Jasmine Guillory (2018): contemporary romcom with cross-cultural specificity.
- *Get a Life, Chloe Brown* — Talia Hibbert (2019): contemporary romcom with disability representation; Brown sisters series.
- *The Bromance Book Club* — Lyssa Kay Adams (2019): meta-romcom with reading-group framing.
- *Beach Read* — Emily Henry (2020): contemporary romance-leaning romcom; voice-led modern register.
- *People We Meet on Vacation* — Emily Henry (2021): friends-to-lovers romcom; literary-adjacent voice.
- *The Bodyguard* — Katherine Center (2022): contemporary fake-relationship romcom.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. The definitive rom-com cover style. Cartoon or graphic illustration of characters in playful, comedic, or romantic scenarios. This IS the "rom-com look". bright, fun, instantly recognisable as the genre. Any rom-com not using illustrated covers is fighting against reader expectations.
- **Graphic**. Bold, colourful graphic design with playful iconography, pattern work, and strong typography. Works for concept-driven rom-coms where the premise is the hook (e.g., a dating app, a wedding disaster, a bet).
- **Typographic**. Title as the dominant design element with playful, handwritten, or decorative fonts, supported by small illustrated vignettes or icons. Effective when the title is clever or punny and the typography can carry the comedic tone alone.
- **Minimalist**. Clean, bright design with a single playful image or icon and bold typography. Works for upmarket rom-com or literary crossover where the cover needs to signal humour without looking too "genre."

### Genre Cover Aesthetics
- **Styles:** Bright, cheerful, and inviting compositions with playful energy. Character-driven illustrations showing couples in comedic or romantic situations. Flat or semi-flat illustration style with bold outlines and vibrant fills. Scenes of everyday life made charming. coffee shops, city streets, bookshops, beaches, weddings. The overall impression should be: fun, warm, approachable.
- **Colours:** Bright pastels and pops of saturated colour. coral, turquoise, sunny yellow, mint green, hot pink, lavender. White or light backgrounds keep the tone airy and fun. Colour combinations should feel fresh and contemporary, never muddy or muted. Two-to-three colour palettes with one accent pop colour are most effective.
- **Elements:** Illustrated character couples (not photographic), playful props (coffee cups, suitcases, dogs, bicycles, books, phones, wedding items), city skylines or charming town settings, seasonal motifs (summer beaches, winter snow, spring flowers), hearts and stars used playfully, food and drink elements, cute pets
- **Typography:** Handwritten, playful, or brush-script fonts for titles. often the LARGEST and most prominent element on the cover. Typography frequently takes up 40-60% of the cover space. Sans-serif companion fonts for author names. Colour in the typography itself (not just black or white). The font style should communicate "fun" and "lighthearted" immediately.

### Subgenre Variations
- **Workplace Rom-Com:** Office settings, professional attire made playful, city backgrounds, briefcases and coffee cups, power-dynamic visual cues treated with humour
- **Holiday Rom-Com:** Seasonal colour palettes dominate (Christmas red and green, Valentine's pink, summer golden), festive props and settings, cozy and celebratory mood
- **Enemies-to-Lovers Rom-Com:** Characters on opposite sides of the cover (often back-to-back or facing away), visual tension and opposition, competitive props or settings
- **Travel/Destination Rom-Com:** Landmark settings (Eiffel Tower, Italian coast, English countryside), luggage and travel props, wanderlust colour palettes, postcard aesthetic
- **Wedding Rom-Com:** Bridal elements, wedding venues, champagne, floral arrangements, wedding party chaos depicted charmingly
- **BookTok/Bookish Rom-Com:** Books and bookshops as central visual elements, literary props, cozy reading aesthetic, warm inviting palettes

### Market Positioning
Romantic comedy covers are among the most instantly recognisable in all of publishing. the illustrated style IS the genre's visual identity. Readers browsing Amazon, BookTok, or bookshop shelves identify rom-coms by their covers before reading a single word. The cover must communicate "fun, light, romantic, funny" at thumbnail size. Typography is disproportionately important in rom-com. the title font does as much genre signalling as the illustration. Bright, clean, cheerful covers outperform darker or more complex designs. The cover should make the reader smile before they even read the blurb. Series or companion novels benefit from consistent illustration style and colour palette variations.

### Cover Design DON'Ts
- Dark, moody, or atmospheric aesthetics. this immediately signals thriller, dark romance, or literary fiction, not rom-com
- Photorealistic model photography. looks wrong for rom-com and actively signals a different genre (contemporary romance, women's fiction)
- Overly serious or dramatic design. the cover must look FUN; if it doesn't make someone smile, it's not working
- Muted, desaturated, or earthy colour palettes. rom-com covers should be bright and cheerful
- Ornate, decorative, or period-style typography. fonts must feel modern, playful, and approachable
- Complex or busy compositions that obscure the title. typography must be immediately readable
- Generic stock illustration that could apply to any book. the illustrated scene should hint at THIS specific story's premise
- Horror, thriller, or suspense visual elements. even a slightly dark composition will repel rom-com readers who are shopping for joy
