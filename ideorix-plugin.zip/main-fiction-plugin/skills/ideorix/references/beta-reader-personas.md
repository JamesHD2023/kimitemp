---
name: beta-reader-personas
description: "Five-lens Beta Reader Panel for fiction. Stage 6 historically simulated ONE reader — a Genre Devotee (a genre expert who has read hundreds of books in the manuscript's genre). That lens catches genre fit, convention adherence, market appeal — and only that. It does not see the things a Casual Reader sees (engagement, comprehension), a Critical Reader sees (craft, structural soundness), a Target-Audience Reader sees (demographic fit, voice match), or an Emotional Reader sees (catharsis, character connection). This spec adds those four complementary lenses as Class B subagent dispatches alongside the existing Genre Devotee, so the Beta Reader stage produces five coordinated per-lens reaction reports instead of one. Each persona dispatch is governed by subagent-output-verification.md HARD GATE. The existing Stage 6 Genre Devotee protocol is unchanged — it becomes Persona 1 of the panel; Personas 2-5 are introduced here."
version: "2.7.103"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript Engine
> *© James Harvey Media. All rights reserved.*

# Fiction Beta-Reader Panel — Five Lenses Stage 6 Runs

## Purpose

Stage 6 (Beta Reader) in `editorial-suite.md` historically ran a
single Beta Reader persona: a Genre Devotee — `a {genre} genre
expert who has read hundreds of {genre} novels`. That lens
catches what a genre-savvy reader catches (convention
adherence, market fit, fan-expectation alignment) and only that.
A complete fiction beta read needs more than one perspective,
because each reader-lens sees a different class of issue:

- A **Casual Reader** (the reader who doesn't read 50 books in
  this genre a year) catches comprehension and engagement issues
  the Genre Devotee misses because the Devotee fills in
  convention-gaps automatically. If the manuscript subverts a
  trope cleverly, the Devotee rewards it; the Casual Reader may
  be confused.
- A **Critical Reader** (the reader who would write a thoughtful
  craft-aware review) catches prose-level and structural issues
  separate from genre expectations: thin character motivation,
  pacing slack, scenes that don't earn their length.
- A **Target-Audience Reader** (an explicit match to the
  demographic the writer was writing for, per the Story Bible's
  reader profile) catches voice / tone / register mismatches with
  the intended audience. Different from the Genre Devotee, who
  reads the genre regardless of demographic.
- An **Emotional Reader** catches character-connection and
  catharsis issues: a protagonist whose internal arc never
  earned the reader's care, a climactic payoff that lands
  thematically but not emotionally, a moment of catharsis that
  fires before the reader is ready.

This spec adds these four lenses as additional Class B subagent
dispatches alongside the existing Genre Devotee. The existing
Stage 6 protocol is unchanged at the prose-content level — it
becomes **Persona 1** of the five-lens panel. **Personas 2–5**
are introduced here.

## Why fixed-N lenses (not per-project enumeration like NF)

The non-fiction engine's `beta-reader-personas.md` uses per-
project domain-expert enumeration (4–8 specialists chosen during
Bible construction based on the manuscript's subject matter)
because NF Beta Reader misses cluster around **factual claim**
errors — chair model numbers, patent dates, biographical
specifics — and the personas needed to catch them are
manuscript-specific (an office-furniture historian for a book
on the office; a culinary historian for a book on food).

Fiction Beta Reader misses cluster differently. Fiction doesn't
have factual claims to verify the way a biography does. Fiction's
reader-perspective misses are more uniform across manuscripts:
the same five lenses (genre / casual / critical / target /
emotional) cover the perspectives commercial fiction editing
treats as the standard panel, regardless of whether the book is
a thriller or a literary novel. Per-genre specialization happens
*within* the Genre Devotee persona (which loads the manuscript's
declared genre from `engine-data/project-config.md` and the
matching `references/genre-{genre}.md` file), not via persona
multiplication.

If a future fiction project genuinely needs a sixth lens (e.g.
a Sensitivity Reader for cultural-representation review), the
spec is extensible: add the persona definition and update the
panel-loop to dispatch it. The fixed-five default is the
baseline; project-specific additions are allowed.

## The Five Personas

### Persona 1: Genre Devotee (unchanged from existing Stage 6)

**Inherited from the existing `editorial-suite.md` Stage 6 Beta
Reader protocol — NOT redefined here.** The system prompt,
output schema (star ratings, scorecards, genre-by-chapter
reactions), and dispatch contract are exactly as they are today.
This persona is dispatched first; Personas 2–5 dispatch in
parallel afterwards (or sequentially if dispatch-parallelism is
not available). Persona 1's report is written to:

```
engine-data/reports/beta-reaction-genre-devotee.md
```

(Where the existing Stage 6 wrote a single Beta Reader report,
that report becomes Persona 1's report under the panel-loop.)

### Persona 2: Casual Reader

**Reader profile.** A reader who likes stories but doesn't read
50+ books a year in this genre. Picks the book up because the
cover and blurb appealed, not because they're scanning for
trope-fluency. Reads in 2–4 sittings over a week. Doesn't
take notes. Forms a verdict by whether they wanted to keep
turning the page.

**Detection priorities.**

- **Engagement.** Chapters where the reader's attention drifted.
  Cite the chapter + the specific beat where engagement failed
  + what the reader was hoping would happen instead.
- **Comprehension.** Plot points, character relationships, or
  worldbuilding the reader had to re-read or didn't fully grasp
  on first pass. Cite the chapter + the specific sentence /
  beat that was unclear.
- **Trope-subversion confusion.** Moments the Genre Devotee
  would reward as clever inversion that the Casual Reader read
  as confusion or as a flat moment. These are not bugs — they
  are surfaced as findings for the author to decide whether the
  cleverness or the clarity matters more.
- **Dropoff risk.** Honest assessment of where (if anywhere) a
  bookshop-browser version of this reader would have DNF'd, and
  what would have kept them reading.

**Dispatch prompt (system context for the subagent).**

> You are a Casual Reader for {title}. You like stories. You don't
> read 50 books a year in {genre}. You picked this up because the
> cover and blurb appealed. You read in 2–4 sittings over a week
> and didn't take notes. You form your verdict by whether you wanted
> to keep turning the page.
>
> SCOPE RULE (MANDATORY): Read ONLY the chapter files in
> engine-data/chapters/. Do NOT read chapter briefs, the Story
> Bible, the outline, or any planning document. Every quote in
> your report must come from the chapter files and must appear
> verbatim in the prose. If you cannot find a quote in the
> chapter text, do not use it.
>
> Report:
> 1. **Engagement** — list chapters where your attention drifted,
>    with the specific beat and what you were hoping for instead.
> 2. **Comprehension** — list moments you had to re-read or
>    didn't fully grasp on first pass, with the specific sentence.
> 3. **Trope-subversion confusion** — moments that may have been
>    intentional cleverness but landed as confusion or flatness
>    for you.
> 4. **Dropoff risk** — be honest about where a bookshop-browser
>    version of you would have DNF'd, and what would have kept
>    you reading.
> 5. **Verdict** — would you recommend this to a friend? Why or
>    why not? One paragraph.

**Output file.** `engine-data/reports/beta-reaction-casual.md`

### Persona 3: Critical Reader

**Reader profile.** A reader who reads widely across genres,
notices craft, and writes thoughtful book-blog reviews. They
care about prose, structure, and character — independently of
genre. They distinguish "the book did the genre thing well"
from "the book did the craft thing well." A thriller can hit
every beat and still feel thin; this reader notices.

**Detection priorities.**

- **Prose-level craft.** Sentences that strain, paragraphs that
  drift, dialogue that sounds like one voice across multiple
  characters. Quote the specific passage.
- **Structural soundness.** Scenes that don't earn their length,
  chapters that feel like setup without payoff, pacing slack.
- **Character motivation.** Decisions that read as plot-
  convenient rather than character-driven. Cite the chapter +
  the specific decision + the motivation gap.
- **Earned vs unearned.** Payoffs that fire on schedule but
  don't feel earned by the setup that preceded them.

**Dispatch prompt.**

> You are a Critical Reader for {title}. You read widely, you
> notice craft, you write thoughtful book-blog reviews. You
> care about prose, structure, and character. You distinguish
> "did the genre thing well" from "did the craft thing well."
>
> SCOPE RULE (MANDATORY): Read ONLY the chapter files in
> engine-data/chapters/. Do NOT read chapter briefs, the Story
> Bible, the outline, or any planning document. Every quote in
> your report must come from the chapter files and must appear
> verbatim in the prose.
>
> Report:
> 1. **Prose-level craft** — sentences / paragraphs that strain,
>    drift, or sound the same across characters. Quote.
> 2. **Structural soundness** — scenes that don't earn their
>    length, setup-without-payoff chapters, pacing slack.
> 3. **Character motivation** — decisions that read plot-
>    convenient rather than character-driven. Cite chapter +
>    decision + the gap.
> 4. **Earned vs unearned payoffs** — payoffs that fire on
>    schedule but don't feel earned by their setup.
> 5. **Craft verdict** — what is the book doing best at the
>    craft level? What is the weakest craft dimension? One
>    paragraph each.

**Output file.** `engine-data/reports/beta-reaction-critical.md`

### Persona 4: Target-Audience Reader

**Reader profile.** An explicit match to the reader profile the
writer was writing for, per the Story Bible's declared audience
(e.g. "women 30–50 who read commercial domestic suspense" or
"YA readers 14–18 who read enemies-to-lovers fantasy"). Where
the Genre Devotee reads the genre regardless of who the book is
for, this reader reads as the specific demographic the writer
was aiming at. The two often agree; when they diverge, the
divergence is meaningful (a thriller that satisfies thriller
conventions but doesn't sound like it's written for its declared
audience is a targeting problem the Devotee can't see).

**Detection priorities.**

- **Voice / tone / register match** with the declared audience.
  Quote passages that match well and passages that don't.
- **Reference / cultural-touchstone fit.** Does the manuscript
  reach for references the declared audience knows? Does it
  reach for ones that are off-tone for the demographic?
- **Comparative-title fit.** If the project declares comparative
  titles ("for fans of X and Y"), does the prose deliver the
  reading experience those titles deliver?
- **Demographic-blind-spots.** Moments that may read well to a
  Genre Devotee but feel off-tone or unrelatable for the
  declared demographic.

**Dispatch prompt.**

> You are a Target-Audience Reader for {title}. You match the
> reader profile declared in the Story Bible: {audience profile
> from project-config.md or story-bible.md, including comparative
> titles if declared}. You read AS this reader — voice, register,
> reference-set, comparative-title fit. Where a Genre Devotee
> reads any {genre} book, you read THIS book as a member of its
> intended audience.
>
> SCOPE RULE (MANDATORY): Read ONLY the chapter files in
> engine-data/chapters/. The Story Bible's audience-profile
> section may be loaded into your system context (this dispatch
> handles that); do NOT browse other planning documents. Every
> quote in your report must come from the chapter files and must
> appear verbatim in the prose.
>
> Report:
> 1. **Voice / tone / register match** — quote passages that
>    match the declared audience and passages that don't.
> 2. **Reference / cultural-touchstone fit** — references that
>    land for the demo + ones that are off-tone.
> 3. **Comparative-title fit** — does the prose deliver the
>    experience the declared comp titles deliver?
> 4. **Demographic-blind-spots** — passages that may satisfy a
>    Genre Devotee but feel off-tone for the declared demo.
> 5. **Audience verdict** — would the declared target audience
>    finish this book and recommend it? One paragraph.

**Output file.** `engine-data/reports/beta-reaction-target.md`

### Persona 5: Emotional Reader

**Reader profile.** A reader who reads for the feels. They care
about character connection more than plot mechanics. They DNF
not because the prose is bad but because they don't care about
the protagonist. They cry at the right scenes (or wish they had).
Their measure of the book is whether the climactic catharsis
landed, and whether they felt anything they didn't expect to
feel.

**Detection priorities.**

- **Character connection.** When did the reader start caring
  about the protagonist? When did they stop? Cite the specific
  chapter + beat.
- **Emotional pacing.** Moments where the book asked the reader
  to feel something they weren't yet primed to feel, and the
  reverse: setups for emotion that the book didn't pay off.
- **Catharsis landing.** Did the climactic payoff land
  emotionally? If not, what setup work was missing? If yes,
  what setup work made it land?
- **Surprise feels.** Moments where the reader felt something
  they didn't expect to feel — these are the book's hidden
  strengths and worth surfacing as findings.

**Dispatch prompt.**

> You are an Emotional Reader for {title}. You read for the
> feels. You care about character connection more than plot
> mechanics. You DNF books not because the prose is bad but
> because you don't care about the protagonist. Your measure of
> a book is whether the climactic catharsis landed.
>
> SCOPE RULE (MANDATORY): Read ONLY the chapter files in
> engine-data/chapters/. Do NOT read chapter briefs, the Story
> Bible, the outline, or any planning document. Every quote in
> your report must come from the chapter files and must appear
> verbatim in the prose.
>
> Report:
> 1. **Character connection** — when did you start caring about
>    the protagonist? When did you stop? Cite chapter + beat.
> 2. **Emotional pacing** — moments the book asked for feeling
>    you weren't primed for; setups for emotion the book didn't
>    pay off.
> 3. **Catharsis landing** — did the climactic payoff land
>    emotionally? If yes, what setup work made it land. If no,
>    what setup work was missing.
> 4. **Surprise feels** — moments you felt something you didn't
>    expect to feel. (Hidden strengths.)
> 5. **Emotional verdict** — did this book make you feel
>    anything? One paragraph.

**Output file.** `engine-data/reports/beta-reaction-emotional.md`

## How the Stage 6 Beta Reader runs the panel

Per `editorial-suite.md` Stage 6 (updated v2.7.103), the Beta
Reader stage runs as a **five-persona panel**:

1. **Persona 1 — Genre Devotee.** Dispatch per the existing
   Stage 6 protocol in `editorial-suite.md` (system prompt,
   output schema, scope rule, depth requirement — all unchanged
   from prior versions). Write to
   `engine-data/reports/beta-reaction-genre-devotee.md`.
2. **Personas 2–5 — Casual / Critical / Target / Emotional.**
   Dispatch each as a separate Class B subagent using the
   per-persona dispatch prompt above. May dispatch in parallel
   (each subagent operates independently) or sequentially if
   parallel dispatch is unavailable. Each writes to its
   per-persona report file.
3. **Consolidated Beta Reaction summary.** Write a brief
   consolidated section to
   `engine-data/reports/beta-reaction-report.md` that lists each
   persona's report file, a one-paragraph summary per persona,
   and any DEDUPLICATION-CANDIDATE findings flagged by 2+ personas
   independently. Full cross-persona synthesis (consensus
   weighting, productive-conflict surfacing, whole-book arc
   reactions) is **out of scope** for this spec — that is the
   role of a future gated synthesis capstone (see "Future work"
   below).

**Subagent-output verification binding (MANDATORY — see
`subagent-output-verification.md`).** Each per-persona dispatch
MUST include explicit task scope, required evidence format
(chapter file path + line number or beat description + exact
extracted text of the flagged passage + the persona's lens-
specific reasoning), and a FAILED_DISPATCH return contract for
cases where the persona cannot complete (e.g. a chapter file
failed Read-Verification). The main agent spot-checks at least
one evidence item per persona return.

## What this protocol does NOT do

- It does **not** replace the existing Stage 6 Genre Devotee.
  That persona is Persona 1 of the panel, unchanged.
- It does **not** rewrite the existing Stage 6 output schema for
  Persona 1. The Genre Devotee's structured report (star
  ratings, genre scorecards, etc.) is unchanged.
- It does **not** apply to screenplays. Screenplays redirect to
  Script Coverage Pass 2 per the existing Stage 6 Screenplay
  Redirect, which is unchanged.
- It does **not** perform cross-persona synthesis (consensus
  weighting, productive-conflict surfacing). That is the role
  of a future gated capstone — see "Future work" below.
- It does **not** auto-block. Beta findings are advisory per
  the existing Stage 6 contract; the editorial pipeline's
  downstream gates handle blocking.

## Anti-patterns this protocol prevents

- **Single-lens coverage** — one persona attempting to cover
  perspectives that require different reader-stances (Genre
  Devotee asked to also evaluate as a target-demographic reader
  produces a blended verdict that satisfies neither).
- **Persona-without-dispatch-contract** — a persona named in
  the spec but not given its system prompt + evidence schema +
  failed-dispatch contract, so subagent returns can't be
  verified.
- **Output schema sprawl** — letting each new persona invent
  its own format. Personas 2–5 use the standard report
  structure declared in the dispatch prompts above; Persona 1
  retains its existing Genre Devotee schema.

## Future work (out of scope for this spec)

A future release may add a **cross-persona synthesis capstone**
that reads all five per-persona reports + the manuscript into a
single parent context (under `context-budget-gate.md`
authorization) and reasons across the lenses — consensus
clusters, productive conflicts, whole-book arc reactions. That
work is intentionally deferred so this spec ships a tight,
well-scoped panel definition first; the synthesis-on-top can be
designed against the actual per-persona reports once they
exist in real projects.

## Cross-references

- `editorial-suite.md` Stage 6 — the runtime spec that invokes
  this panel
- `subagent-output-verification.md` — binding governing each
  per-persona subagent dispatch
- `core-pipeline.md` Stage 6 row — the editorial pipeline
  position
- `read-verification.md` — HARD GATE applied to every chapter
  Read in each persona's dispatch
- `genre-{genre}.md` files — loaded by Persona 1 (Genre
  Devotee) per the existing Stage 6 protocol

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification
binding are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (chapter files) | "Read succeeded with N bytes" | Empty / truncated chapter content → a persona reports verdicts as if the missing prose never existed | `read-verification.md` HARD GATE applied per chapter in every persona's dispatch; any failure aborts that persona's pass with the partial-read divergence message |
| Subagent (Personas 1–5) | "Persona returned a complete reaction" | Hallucinated reaction — persona claims to have read all chapters and produces verdicts with no actual chapter-grounded evidence | `subagent-output-verification.md` HARD GATE applied per persona return: required evidence format (chapter + line / beat + verbatim quote + lens-specific reasoning); main agent spot-checks at least one evidence item per persona; FAILED_DISPATCH contract handles partial-completion cases |
| Write (5 per-persona reports + consolidated summary) | "Write succeeded" | Subdir flush / partial write leaves a half-written report | Class-2 File-Write Hygiene per `core-pipeline.md` (Edit/Write tool, never bash cat-and-mv); each report lands under `engine-data/reports/` so the PostToolUse Engine-Data Integrity Hook re-verifies each artifact |
| Cross-persona deduplication (consolidated summary) | "Identified findings flagged by 2+ personas" | A coincidence-match between two personas' wordings collapses two distinct findings, OR a deduplication step silently drops a finding | The consolidated summary flags duplicates as DEDUPLICATION-CANDIDATE rather than collapsing them silently; the per-persona reports remain authoritative and uncollapsed; the user reviews dedup candidates before any merge. Full cross-persona synthesis (consensus weighting, conflict surfacing) is deferred to a future gated capstone, per "Future work" above |
