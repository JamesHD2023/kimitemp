---
name: cover-designer
description: AI-powered book cover concept generation with market research, genre-aware aesthetics, and multi-platform image prompts
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Cover Designer — Engine Skill

## File Location Discipline (MANDATORY)

**Cover concept outputs** (concept descriptions, AI image
prompts, generation IDs / seeds, cover briefs for designers,
A+ Content imagery specs) MUST be written to
`~/Documents/Ideorix-Projects/[Title]/marketing/cover/`.
Reference imagery and seed/ID logs land in the same folder.
Generated cover images themselves are typically downloaded
by the user from the AI image provider (Ideogram /
Grok / Claude Design); save those to the same folder
when delivered to the engine. Outputs MUST NOT be written
to the parent `~/Documents/Ideorix-Projects/` folder, the
agent's working directory, or any sandbox / temporary path.
See `core-pipeline.md` § File Location Discipline and
`marketing-and-cover.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Cover Brief Gate (MANDATORY — v2.7.68+)

Before any cover image is generated, before the marketing pack
ships, before the project is declared launch-ready, the cover
brief gate verifies the structured brief exists per this spec:

```bash
bash scripts/cover-brief-gate.sh "{project-root}"
```

The gate verifies `marketing/cover/cover-brief.{md,json}` (or
any file matching `*concept*` / `*brief*` in `marketing/cover/`)
contains the required schema fields: conceptName, visualConcept,
colorPalette, typography, imagePrompt, mood. Minimum size 800
bytes (the brief must be substantive, not a stub).

If the gate fails, do NOT generate cover images or proceed to
marketing — the brief is what disambiguates "book cover" from
generic AI image output. The v2.7.67 user failure shape (cover
image came out as a 3D product render instead of a book cover)
is exactly what this gate exists to prevent.

Opt-outs: `cover_status: legacy / skip` in
`engine-data/project-config.md`.

## Purpose

The Cover Designer generates comprehensive book cover concepts that are:
- **Market-competitive** — researched against current bestseller trends
- **Genre-accurate** — signals the right genre to readers instantly
- **Print-ready** — calculated to exact trim size, spine width, and DPI specifications
- **Multi-platform** — produces optimised prompts for five user-selectable platforms: Ideogram, Grok Aurora, Claude Design (web-only at `claude.ai/design`, research preview), Leonardo.ai, and Midjourney. The engine emits prompt-blocks only for the platforms the user picks during Phase 0a (Cover Inputs Selection); see the full platform table later in this file for selection guidance.

## When to Use

Activate when:
- The user requests a cover concept or cover design
- The manuscript is complete or near-complete and moving toward publishing
- The user is in the Publishing Studio / Cover Designer interface
- **The user uploads an existing cover image for analysis, refinement, or
  reconstruction** (see Cover Audit Mode below)

## Cover Audit Mode — Upload an Existing Cover

A standalone entry point that works WITHOUT a project, manuscript, or
Story Bible. The user uploads an existing cover image (their own, a
comp title, or a rough draft) and gets a full audit.

**Triggers:**
- "Analyse this cover" / "Audit my cover" / "Review my cover"
- "Improve this cover" / "Refine this cover"
- "Score this cover" / "Rate my cover"
- An uploaded image with any cover-related request
- "Break this into Canva layers" / "Make this editable"

**Works with:**
- The user's own cover (generated in Ideogram or Grok, refined in
  Claude Design, designed in Canva, purchased from a designer, or
  drafted in Photoshop)
- A competitor/comp title cover they want to analyse
- A rough sketch or mockup they want feedback on
- A cover they've seen on Amazon and want to understand

### Minimum Context Intake (before analysis)

The cover audit needs minimum context to score accurately. If the user
has an active Ideorix project, pull context from `project-config.md`
and `story-bible.md`. Otherwise, ask the user for the minimum
required:

1. **Genre** (required for Genre Clarity scoring)
   "What genre is this cover for?" — present the standard genre list
2. **Target audience** (required for Market Hook scoring)
   "Who's the target reader? Adult / YA / Middle Grade / Children's?"
3. **Trim size** (required for aspect-ratio audit, thumbnail survival check, and layer decomposition output)
   "What trim size is this cover for? 1) 6×9 (Trade Paperback) · 2) 5.25×8 (Compact Trade) · 3) 4.25×6.87 (Mass Market) · or 'advanced' for other sizes"
   *If the user has an active project with `Cover Trim Size:` in `project-config.md`, use that and skip this question.*
4. **Title** (if not visible or ambiguous in the image)
   "I can see the title appears to be '{X}' — is that correct?"
5. **Author name** (if not visible)
   "What's the author name?"
6. **Tropes/themes** (optional — strengthens Trope Strength scoring)
   "Any specific tropes or themes the cover should signal?"

If the user doesn't answer a field, score that dimension with
"insufficient context — scored on visual merit alone" and flag it
in the recommendation.

**Why trim size matters for audit:** The aspect-ratio check, thumbnail-survival test, spine-width estimate (if wraparound is requested), and Canva layer decomposition output dimensions all depend on the trim size. An audit run without trim size loses these checks. If the user genuinely doesn't know (e.g., comparing a competitor's cover), default to **6×9** and flag in the report: "Trim size assumed 6×9 — if actual differs, aspect-ratio score may shift."

### Cover Audit Output

After context intake, Claude analyses the uploaded image and produces:

**1. Visual Analysis (what the cover is)**
- Composition (focal point, visual hierarchy, thirds/rule alignment)
- Colour palette (3-5 dominant colours with hex approximations)
- Typography (title font style, author font style, legibility)
- Imagery (style — illustration/photograph/digital painting/mixed;
  subject — figure/landscape/object/symbolic)
- Mood (emotional register the cover projects)
- Genre signalling (what genre this cover reads as at first glance)

**2. Weighted Score (same 5-criteria system as normal covers)**

```
COVER AUDIT — {Title}
Intended genre: {genre}
Target audience: {audience}

  Genre Clarity:   {N}/10 (×0.30 = {weighted})
  Visual Potency:  {N}/10 (×0.25 = {weighted})
  Trope Strength:  {N}/10 (×0.20 = {weighted})
  Market Hook:     {N}/10 (×0.15 = {weighted})
  Distinctiveness: {N}/10 (×0.10 = {weighted})

  Overall: {weighted total}/10
  Rating: {Unmarketable | Needs Work | Solid Genre Fit | Bestseller Potential}
```

**3. Specific Strengths (what's working)**
- 2-4 bullet points naming what's genuinely strong about this cover

**4. Specific Issues (what needs attention)**
- 2-5 bullet points with exact problems (e.g., "title text illegible at
  thumbnail size", "colour palette signals thriller but tropes suggest
  cosy mystery", "composition crowded in the bottom third")

**5. User's next-step menu**

```
What would you like to do next?

  A. Refinement prompt (V2) — I'll produce a prompt you can paste into
     Nano Banana 2, DALL-E edit, Ideogram Reimagine, or Claude Design
     alongside your uploaded cover. Polishes what's here
     without starting over.

  B. Canva Layer Breakdown — I'll reverse-engineer the cover into a
     layered reconstruction spec so you can rebuild it in Canva,
     Photoshop, or Figma with full control over each element.

  C. Full redesign — I'll generate three new concept directions with
     platform-ready image prompts. (Requires a manuscript or project
     context for best results — I'll ask for more info if needed.)

  D. Compare against comp titles — Upload 2-3 bestseller covers in
     your genre and I'll show you how yours stacks up visually.

  E. Refine one specific element — Tell me what bothers you (typography,
     composition, lighting, etc.) and I'll focus the audit there.
```

### Operating without a project

Cover Audit Mode does NOT require:
- A project folder
- A Story Bible
- A manuscript
- Market Scout output
- An existing `engine-data/` directory

It DOES use existing protocols when the data is available. If an
active project exists, the audit inherits:
- Genre, tropes, target audience from `project-config.md`
- Visual Beat Map (if already generated)
- Existing concept specs (if the user has run the Cover Designer before)

If the user later wants to save the audit to disk, offer to save to
`Ideorix-Projects/Cover Audits/{YYYY-MM-DD}-{slug}.md` — a shared
location for standalone audits that don't belong to a specific project.

## Architecture: Permanent vs Genre-Specific

```
Engine (this file)                      Genre Bank (per genre file)
─────────────────                       ───────────────────────────
Print specifications                    Cover aesthetic palette
Visual style taxonomy                   Recommended visual styles
AI platform formats                     Genre-specific visual motifs
Output schema                           Market positioning guidance
Prompt pipeline                         Design DON'Ts
Quality criteria                        Typography recommendations
Universal composition rules             Subgenre variations
```

The engine defines HOW covers are generated. Genre files define WHAT the cover should look like for that specific genre.

---

## Print Specifications (Universal)

### Trim Sizes

The Cover Designer offers **three recommended trim sizes** at the start of every full cover design pass (Phase 0 — see Cover Generation Pipeline). The user selects one, and the choice is persisted to `project-config.md` as `cover_trim_size` so subsequent covers (back cover, V2 refinements, marketing variants) inherit it automatically.

**Recommended sizes (presented at Phase 0):**

| ID | Dimensions | Best For | Spine Note |
|----|-----------|----------|------------|
| **6x9** | 6" × 9" | Trade Paperback (default) — epic fantasy, sci-fi, longer literary novels, multi-POV sagas | Comfortable spine on 200+ page books |
| **5.25x8** | 5.25" × 8" | Compact Trade — most popular indie size for romance, thriller, mystery, contemporary fiction, novels of all genres | Novel-like feel; better page economics |
| **4.25x6.87** | 4.25" × 6.87" | Mass Market — novellas, romance, genre series, books under ~50k words | Solves thin-spine problem on novellas |

**Selection rules:**
- Default if user doesn't specify: **6x9**
- Recommendation logic: novellas (<50k words) and romance/genre fiction → suggest **4.25x6.87**; longer or literary works → suggest **6x9**; everything else → suggest **5.25x8**
- The user can always override the suggestion and choose any of the three (or one of the advanced sizes below)

**Advanced sizes (available on request):**

| ID | Dimensions | Words/Page | Description |
|----|-----------|------------|-------------|
| 5x8 | 5" × 8" | 275 | Standard Trade Paperback (alternative compact) |
| 5.5x8.5 | 5.5" × 8.5" | 300 | Popular Trade Size (literary fiction, memoir) |
| 5.06x7.81 | 5.06" × 7.81" | 250 | Digest / B-Format (UK paperback) |
| 8.5x11 | 8.5" × 11" | 500 | Letter / Workbook |
| 7x10 | 7" × 10" | 450 | Textbook / Manual |

If the user asks for a size not on this list, accept it (KDP supports many trim sizes) but flag any non-standard ratio that may cause spine-width or aspect-ratio issues.

### Paper Types

| ID | Name | Pages/Inch | Thickness | Description |
|----|------|-----------|-----------|-------------|
| white-standard | White (Standard) | 444 | 0.00225" | 50lb / 74gsm white |
| cream-standard | Cream / Off-White | 400 | 0.0025" | 60lb / 89gsm cream |
| white-premium | White (Premium) | 380 | 0.00263" | 60lb / 89gsm premium white |
| cream-premium | Cream (Premium) | 333 | 0.003" | 70lb / 104gsm premium cream |

### Bleed & Safe Zone

- **Bleed:** 0.125" (1/8 inch) on all sides — artwork must extend beyond trim
- **Safe zone:** 0.25" (1/4 inch) from trim edges — no text or critical elements

### Spine Width Calculation

```
Spine Width = Page Count × Paper Thickness
Page Count = ceil(Word Count / Words Per Page) + Front Matter Pages
```

### Full Cover Dimensions

```
Full Cover Width = (Trim Width × 2) + Spine Width + (Bleed × 2)
Full Cover Height = Trim Height + (Bleed × 2)
Pixel Dimensions = Dimensions × DPI (300 for print, 72 for web)
```

---

## Visual Style Taxonomy (Universal)

These styles apply to ALL genres. The genre file specifies which 3-4 are most appropriate.

| ID | Name | Description |
|----|------|-------------|
| photorealistic | Photorealistic | Photo-quality imagery with realistic details |
| illustrated | Illustrated | Hand-drawn or painted artistic style |
| minimalist | Minimalist | Clean, simple design with focus on typography |
| graphic | Graphic Novel | Bold graphics and comic-style aesthetics |
| vintage | Vintage/Retro | Classic, nostalgic design elements |
| abstract | Abstract | Conceptual and symbolic imagery |
| cinematic | Cinematic | Movie poster style with dramatic lighting |
| typographic | Typography-Led | Title as the main visual element |

---

## AI Image Generation Platforms

### Platform Characteristics

| Platform | Strength | Best For | Notes |
|----------|----------|----------|-------|
| **Ideogram** | Superior text rendering | Covers WITH title/subtitle text rendered into the image | Best at rendering readable text in images |
| **Grok Aurora** | Free access, quick iteration | Rapid concept exploration; atmospheric and mood-driven concepts | Free via X; good for testing concepts |
| **Claude Design** | Design-native iteration; layered text + image with full typographic control | Iterative cover refinement; series-consistent typography; multi-layered cover compositions | Powered by Opus 4.7 vision. WEB-ONLY at `claude.ai/design` — research preview for Pro / Max / Team / Enterprise subscribers. NOT yet available on Claude Desktop or Cowork plugin. User pastes the prompt at the web interface; iterates conversationally; exports to Canva / PDF / PPTX / HTML / standalone folder. |
| **Leonardo.ai** | Style consistency across iterations; illustrated / painterly aesthetic | Genre covers needing painterly or illustrated treatments (fantasy, romance, YA, MG); covers needing stylistic continuity across a series; character-led illustrated covers | Subscription-based. Strong at illustration and painterly styles; weaker at photographic realism. Style-preset library makes series consistency trivial. |
| **Midjourney** | Highest visual quality for final-production imagery | Polished final covers needing magazine-quality imagery; atmospheric / cinematic covers (literary fiction, thriller, historical, horror, sci-fi) | Subscription-based, runs in Discord (or via web). Text-rendering on covers is unreliable — use for the IMAGE then add title/subtitle as text overlay in Canva / Photoshop. |

**The user selects which platform(s) to target during Phase 0a (Cover
Inputs Selection — see below). Phase 3 emits prompt-blocks ONLY for
the platforms the user picked, so users with a single preferred
platform are not handed four prompts they will not use.**

### Platform-Specific Prompt Formatting

**Ideogram:**
- Specify text to render in quotes: `with title text "Book Title" in [font style] at [position]`
- For books with subtitles, include both: `with title text "BOOK TITLE" and subtitle "the subtitle here" in [font style], hierarchy preserved (title prominent, subtitle smaller beneath)`
- Supports style presets and aspect ratios
- Best for covers that need text baked into the image

**Grok Aurora:**
- Direct, descriptive prompts work best
- Specify title text explicitly — e.g., `display the words "BOOK TITLE" prominently at the top in [font style] lettering`
- For books with subtitles, include both: `with "the subtitle here" beneath the title in smaller [matching font]`
- DO NOT include the author name in Grok prompts — Grok's text rendering is
  unreliable for names. The user should add the author name as a text overlay.
- Good for atmospheric and mood-driven concepts

**Claude Design (web-only, claude.ai/design — research preview):**

Claude Design is a collaborative design canvas, not a one-shot
image generator. Prompts are conversational and benefit from
full briefing rather than parameter strings. The platform is
NOT yet available via Claude Desktop or the Cowork plugin —
the engine generates a Claude-Design-flavoured prompt the user
copies to `claude.ai/design` to iterate.

**Ideorix Cover Design System (v2.7.13+ integration):**

A code-based design system optimised for Claude Design lives at
`https://github.com/JamesHD2023/ideorix-cover-design-system`.
When loaded into Claude Design via the platform's "Set up your
design system" flow (one-time configuration), the design system
provides:

- All 8 supported trim sizes as CSS custom properties (bleed,
  safe zones, 300dpi pixel dimensions calculated)
- Per-genre design tokens (palette, typography register,
  composition convention, image treatment) for 16+ fiction
  genres and 4+ NF categories
- Universal colour palette (~80 named tokens) and typography
  stacks (9 font registers)
- Reference HTML components for front, back, and wraparound
  layouts
- Spine-width formula and KDP/IngramSpark print-spec correctness

When the user has the Ideorix Cover Design System loaded in
Claude Design, the engine's emitted briefing should reference
the relevant genre file and trim size — Claude Design then
applies the matching tokens automatically. See
`docs/how-to-use-with-ideorix-engine.md` in the design system
repo for the integrated flow.

**Workflow note (display this to the user when offering Claude Design output):**
- The engine produces a Claude Design briefing prompt (below format)
- User opens `claude.ai/design` in their web browser
- If the user has the Ideorix Cover Design System loaded (one-time
  setup), they can iterate against locked print specs and genre
  tokens automatically
- User pastes the briefing into a new design session
- User iterates conversationally with Claude Design (e.g., "make
  the title typography heavier", "shift the focal element 15%
  left", "try a colour palette with more warmth in the shadows")
- When satisfied, user exports to PDF, PPTX, Canva, or HTML
- User saves the export to
  `~/Documents/Ideorix-Projects/[Title]/marketing/cover/`
  per the engine's File Location Discipline

**Prompt structure for Claude Design:**

The briefing should be a structured paragraph (or short
markdown block) covering:

1. **Product framing** — "I'm designing the cover for a
   [genre] novel titled '[Title]' by [Author Name]. Trim size:
   [size]. Heat level / target audience: [register]. The cover
   needs to read clearly at thumbnail (200×300px in a vertical
   scroll feed)."
2. **Genre conventions** — "[genre] covers in this market
   typically use [visual conventions, e.g. 'low-key lighting,
   cool palettes, single-figure focal points'] to signal
   category to readers. We want to honour those conventions
   while [differentiator: 'pushing a more painterly register'
   or 'using a more contemporary type treatment']."
3. **Visual concept** — "Central image: [specific concept,
   e.g. 'a lone figure on a rain-slick city street at dusk,
   silhouetted against a glowing window']. Mood: [mood].
   Palette: [3-5 colours with notes on register]."
4. **Typography requirements** — "Title typography: [serif /
   sans / display] with [weight] presence. Author name:
   [size relative to title, position]. The title should
   anchor the upper third / lower third / [position]."
5. **Series consistency (if applicable)** — "This is book [N]
   in a [N]-book series. Match the design system established
   in [book 1's cover, attached or described]. Series-spine
   colour: [colour]. Series typography: [carry-over]."
6. **What to AVOID** — "Avoid [stock-cover clichés relevant
   to genre, e.g. 'silhouetted couple on cliff edge', 'glowing
   embers from a fingertip']. Avoid [over-saturated palette /
   busy backgrounds / generic stock figures]."
7. **Iteration invitation** — "Show me 2-3 different concept
   directions, then I'll choose one to refine."

**Why Claude Design works well for book covers:**
- Native typography control (no "AI-rendered text" problem;
  the platform is design-aware, not just image-aware)
- Iterative refinement on the same canvas (request a 15%
  position shift; Claude Design moves it precisely)
- Layer-aware (text, image, and design elements are separable
  for export)
- Series-consistency support via team design systems applied
  automatically
- Export formats match cover-production workflows (Canva is a
  particular strength for self-publishers; PDF + PPTX work for
  traditional publishing handoffs)

**When NOT to use Claude Design:**
- The user is not on Claude Pro / Max / Team / Enterprise
  (Claude Design is subscriber-only)
- The user wants automatic one-shot image generation without
  conversational iteration (Ideogram or Grok is faster for this)
- The cover requires extreme photorealism beyond what Opus 4.7
  vision currently produces (a dedicated photorealism platform is
  more direct here)
- The user is operating in a Claude Desktop or Cowork-only
  workflow (Claude Design is web-only at present; the engine
  cannot invoke it directly)

**Leonardo.ai:**
- Style-preset-led: prompts work best when paired with a Leonardo
  style preset (e.g. `Cinematic`, `Illustration`, `Painterly`,
  `Anime`, `Photoreal`). Recommend a preset in the prompt header.
- Format: `[Style preset: <name>] · [scene description] · [composition
  notes] · [palette] · [aspect ratio]`. Example: `[Style preset:
  Painterly] · A cloaked figure standing on a windswept clifftop at
  dusk, distant lighthouse beam · centred composition, figure as
  silhouette against amber sky · palette: deep indigo, amber, slate,
  pale gold · aspect ratio 2:3`
- For books with subtitles or series titles, append a separate
  text-rendering note: `Title text "BOOK TITLE" rendered top-third in
  [font style]; subtitle "the subtitle here" smaller, beneath the
  title.` Leonardo's text rendering is improving but not as reliable
  as Ideogram — for text-heavy covers the user should prefer Ideogram
  or add text as overlay in Canva.
- Best for series consistency: once the user finds a preset that
  works for Book 1, the same preset across Books 2-N produces visibly
  continuous cover language — particularly powerful for fantasy /
  romance / YA series where painterly continuity matters.

**Midjourney:**
- Compact, image-led prompts. Format: `<scene description>,
  <composition>, <palette>, <mood>, <technical modifiers> --ar <ratio>
  --style raw --v 6.1`. Example: `a cloaked figure standing on a
  windswept clifftop at dusk, distant lighthouse beam, centred
  composition with figure as silhouette, palette of deep indigo amber
  slate pale gold, atmospheric and cinematic mood, editorial cover
  photography style --ar 2:3 --style raw --v 6.1`
- DO NOT include title / subtitle / author text in Midjourney prompts.
  Midjourney's text rendering is unreliable on covers — the IMAGE goes
  through Midjourney, the TEXT goes on as a Canva / Photoshop overlay
  afterwards. The engine's Midjourney prompt-block emits an explicit
  reminder of this at the end of the prompt: `(Note: render image only
  — add title/subtitle as text overlay afterwards in Canva or Photoshop;
  Midjourney text rendering on covers is unreliable.)`
- Aspect ratio (`--ar`) MUST match the trim size: `2:3` for 6×9 and
  most trade paperback sizes; `11:14` for 5.5×8.5; `7:10` for 7×10
  large format. Always include the `--ar` flag — the default 1:1 is
  wrong for book covers.

---

## Cover Generation Pipeline

### Phase 0: Trim Size Selection (MANDATORY)

Before any other phase runs, the Cover Designer must establish the trim size for this cover. This drives the aspect ratio passed to image-generation prompts, the spine-width calculation, the thumbnail proportions in audit reports, and the Canva layer dimensions.

**Decision tree:**

1. **Is `cover_trim_size` already set in `project-config.md`?**
   - YES → Use that size. Skip to Phase 1. Do NOT re-prompt.
   - NO → Continue to step 2.

2. **Display the trim size selection prompt:**

   ```
   Choose a trim size for this cover:

     1. 6" × 9"        — Trade Paperback (default)
                          Best for: epic fantasy, sci-fi, longer literary novels

     2. 5.25" × 8"     — Compact Trade
                          Best for: most indie fiction — romance, thriller,
                          mystery, contemporary, novels of all genres

     3. 4.25" × 6.87"  — Mass Market Paperback
                          Best for: novellas, romance, genre series,
                          books under ~50k words (solves thin-spine problem)

   My recommendation for your project: {N} — {one-line reason}

   Type 1, 2, or 3. Or say "advanced" to see other supported sizes.
   ```

3. **Generate the recommendation** based on the manuscript context:
   - Novella (<50k words) OR primary genre is romance/cozy/genre-fiction → recommend **3 (4.25" × 6.87")**
   - Word count >85k OR primary genre is literary/epic-fantasy/sci-fi → recommend **1 (6" × 9")**
   - Otherwise → recommend **2 (5.25" × 8")**

4. **Persist the choice** to `project-config.md` immediately after selection. Append (or update) these lines:

   ```markdown
   Cover Trim Size: 5.25x8
   Cover Trim Set: 2026-04-25
   ```

   Use bash-direct append per the File Operation Policy. Read the current file first to avoid overwriting other config lines.

5. **Acknowledge and proceed:**

   ```
   ✓ Trim size set: 5.25" × 8" (Compact Trade)
     This will be used for all covers in this project. To change later,
     edit project-config.md or say "change trim size".
   ```

**If the user says "advanced":** Display the full Trim Sizes table including the advanced options, then accept any selection.

**If no project-config.md exists** (Cover Audit Mode standalone, no project): Ask once, use the answer for this session, do not persist.

### Phase 0a: Cover Inputs Selection (MANDATORY)

After trim size is established, the Cover Designer collects three
additional inputs from the user — **subtitle**, **tagline**, and the
**target image-generation platform(s)**. These determine what Phase 3
emits. All three are persisted to `project-config.md` so subsequent
covers in the same project (Book 2, V2 refinements, marketing
variants) inherit the choices and skip the questions.

**Why this phase exists:** without it, Phase 3 emits prompt-blocks for
every supported platform on every run, and subtitle / tagline collection
is improvised at runtime — usually via an `AskUserQuestion` buttons
prompt that traps free-text input behind an "Other" fallback path. The
explicit phase here makes input collection deterministic and removes
the text-input trap.

**Decision tree, run sequentially:**

#### 1. Subtitle

- If `Cover Subtitle:` is already set in `project-config.md` → use it.
  Skip to step 2.
- Otherwise display:

  ```
  Subtitle for this cover?

    1. Yes — I have one (you'll type it next)
    2. No — title only, no subtitle
    3. Create one for me — engine drafts a subtitle from the
       manuscript (story bible + genre + title)

  Type 1, 2, or 3.
  ```

- **Answer 1 (Yes):** Display `Type your subtitle below:` and accept
  the next user message verbatim as a free-text response. DO NOT use
  AskUserQuestion for the subtitle text itself — subtitles are
  freeform, often contain colons / quotes / punctuation, and AskUserQuestion's
  buttons UI traps free-text behind an "Other" fallback. Use a plain
  conversational prompt and read the next user message.
- **Answer 2 (No):** Persist `Cover Subtitle: NONE`.
- **Answer 3 (Create one for me):** Read the story bible (truncated to
  3,000 chars), the title, the genre, and the trim size from
  `project-config.md`. Draft 3 candidate subtitles in the
  genre-appropriate register (high-stakes for thriller; lyrical for
  literary; evocative for romance; etc.). Present them with a one-line
  rationale per candidate, ask the user to pick one or request another
  round. On user confirm, persist the chosen subtitle.

#### 2. Tagline

- If `Cover Tagline:` is already set → use it. Skip to step 3.
- Otherwise display:

  ```
  Tagline for this cover (a short marketing line — usually 6-12 words —
  that sits above or beneath the title to hook the reader)?

    1. Yes — I have one (you'll type it next)
    2. No — skip the tagline
    3. Create one for me — engine drafts a tagline from the manuscript

  Type 1, 2, or 3.
  ```

- **Answer 1 (Yes):** Plain conversational prompt for the text, same
  protocol as subtitle (free-text on next message, NOT AskUserQuestion).
- **Answer 2 (No):** Persist `Cover Tagline: NONE`.
- **Answer 3 (Create one for me):** Same protocol as the subtitle's
  Create-for-me path — 3 candidates with rationale, user picks.

#### 3. Image-Generation Platform(s) — multi-select

- If `Cover Platforms:` is already set → use it. Skip to acknowledgement.
- Otherwise display:

  ```
  Which AI image-generation platform(s) do you want prompts formatted
  for? Select one or more — Phase 3 will emit prompt-blocks ONLY for
  the platforms you pick.

    1. Ideogram        — Best text rendering; covers with title /
                         subtitle baked into the image
    2. Grok Aurora     — Free, fast iteration via X; atmospheric
                         and mood-driven concepts
    3. Claude Design   — Design-native iteration at claude.ai/design;
                         layered text + image with full typographic
                         control (research preview — Pro / Max / Team /
                         Enterprise subscribers)
    4. Leonardo.ai     — Style consistency across iterations;
                         illustrated / painterly aesthetic (fantasy,
                         romance, YA, MG)
    5. Midjourney      — Highest visual quality for final-production
                         imagery; image-only (text added afterwards
                         in Canva)

  Type the numbers separated by commas (e.g. "1,3" for Ideogram +
  Claude Design). Or type "all" for all five (default if you skip
  this question).
  ```

- Parse the answer into a list. Accept `1,3` / `1 3` / `1, 3` / `all`
  / blank-=-default-all-five. Persist the parsed list as comma-separated
  platform keys.

#### Persistence — append (or update) these lines in `project-config.md`:

```markdown
Cover Subtitle: [the subtitle text | NONE]
Cover Tagline: [the tagline text | NONE]
Cover Platforms: ideogram, grok-aurora, claude-design, leonardo, midjourney
Cover Inputs Set: 2026-05-08
```

Use bash-direct append per the File Operation Policy. Read the current
file first to avoid overwriting other config lines.

#### Acknowledgement

```
✓ Cover inputs set:
  Subtitle: [the text | NONE | drafted: "<the drafted subtitle>"]
  Tagline:  [the text | NONE | drafted: "<the drafted tagline>"]
  Platforms: Ideogram, Grok Aurora, Claude Design  (3 of 5)
  Persisted to project-config.md. To change later, edit the file or
  say "change cover inputs".
```

**If no project-config.md exists** (Cover Audit Mode standalone, no
project): collect the three inputs once for the session, do not persist.

### Phase 1: Market Research

Load `market-scout.md` and run Market Scout with context: **"cover"**.

The cover context adapter emphasises comp title cover designs, visual trends,
dominant colours, typography styles, imagery types, and what's dated. Feed the
Market Scout Report findings into Phase 2 (Context Assembly).

See `market-scout.md` for the full protocol, report format, and fallback behaviour.

### Phase 2: Context Assembly

```
Inputs gathered:
- Book information (title, author, genre, series)
- Story overview (Story Bible, truncated to 3,000 chars)
- Key themes and main characters (see Character Visual Profile below)
- Print specifications (calculated from word count + trim size + paper type)
- Genre cover aesthetics (from genre bank file — see ## Cover Design Specifications)
- Author's creative direction (from Pre-Publishing Brief, if available)
- User's selected visual style
- Text rendering mode (text in image vs artwork only)
- Tagline (optional)
- Visual Evidence Audit (every visual claim traced to manuscript — see below)
```

#### Evidence Rule (MANDATORY)

Every visual claim about characters, settings, objects, or atmosphere
must cite a specific manuscript scene and include a short quote (under
25 words). If the detail is not explicitly stated in the manuscript,
write **"NOT FOUND"** and use a compositional workaround (silhouette,
back-turned figure, symbolic representation, atmospheric suggestion).

- CORRECT: Hair color — "dark red, almost auburn" (Ch 3, "she pushed
  the auburn hair from her eyes")
- CORRECT: Hair color — **NOT FOUND** → use silhouette or obscured angle
- WRONG: Hair color — "dark blonde" (no manuscript evidence)

**Never invent, infer, or assume visual details not explicitly in the
text.** A cover with an accurate silhouette is better than a cover
with a hallucinated face. This rule applies to all downstream phases
(Visual Beat Map, Concept Generation, Image Prompts).

#### Character Visual Profile

For each character who may appear on the cover, extract these 8 fields
from the manuscript. Apply the Evidence Rule — every field must cite
text or state NOT FOUND:

| Field | Source |
|---|---|
| Hair color/style | Manuscript quote or NOT FOUND |
| Eye color | Manuscript quote or NOT FOUND |
| Skin tone | Manuscript quote or NOT FOUND |
| Distinguishing marks | Manuscript quote or NOT FOUND |
| Signature clothing | Manuscript quote or NOT FOUND |
| Weapon or prop | Manuscript quote or NOT FOUND |
| Physical build | Manuscript quote or NOT FOUND |
| Sensory detail (how they move, sound, smell) | Manuscript quote or NOT FOUND |

NOT FOUND fields generate entries in the per-concept Do Not Include
list (Phase 3) — if hair color is unknown, the prompt must not depict
a specific hair color. Use silhouette, back-turned, partial, or
atmospheric framing instead.

### Phase 2b: Visual Beat Map

Before generating concepts, produce a Visual Beat Map — a table of the
8-12 most visually potent moments in the manuscript. This is the Art
Director's shortlist: the scenes with the strongest cover imagery.

| Chapter | Scene Description | Setting | Lighting | Key Objects | Dominant Colors | Quote from Text |
|---|---|---|---|---|---|---|
| Ch 3 | confrontation at the harbour wall | harbour, night | moonlight through fog | iron chain, lantern | steel blue, amber, black | "the chain swung once and held" |

**Rules:**
- 8-12 rows. Fewer is fine for short stories; more for novels.
- Every row must have a Quote from Text (Evidence Rule applies).
- The Dominant Colors column creates the palette pool for concepts.
- Prioritise scenes with strong visual contrast, iconic objects, or
  emotional peaks — these make the best covers.

**Reusability:** The Visual Beat Map feeds into the Video Trailer
Designer, marketing materials, and A+ Content imagery. Save to the
cover concept output for downstream use.

### Phase 3: Concept Generation

The AI generates a complete cover concept with:

1. **Market Analysis** — Genre trends, competitor covers, positioning, patterns to avoid
2. **Visual Concept** — Detailed main image/scene description
3. **Composition** — Layout, focal points, visual hierarchy (accounting for spine)
4. **Color Palette** — 5 specific colors with hex codes and psychological rationale
5. **Typography** — Font recommendations for title, author, tagline, spine
6. **Title Treatment** — Text, position, style, color, effects, size
7. **Author Treatment** — Text, position, style, color, effects, size
8. **Tagline Treatment** — (if tagline provided)
9. **Mood & Atmosphere** — Emotional impact description
10. **Key Elements** — Specific visual elements to include
11. **Do Not Include** — 5-7 misleading visual elements this concept must
    exclude, with reasons. Sources: NOT FOUND fields from Character Visual
    Profiles (don't depict unspecified features), genre DON'Ts from the
    genre bank file, and anachronism/setting traps (e.g., "no snow — story
    is set in August", "no sword — character uses magic", "no Victorian
    lampposts — setting is 1960s"). These carry into the image prompts as
    negative-prompt items or explicit exclusion instructions.
12. **Spine Design** — Spine area treatment
13. **Back Cover Concept** — Back cover design description
14. **Front Cover Image Prompt** — One comprehensive prompt per platform, **for each platform the user selected in Phase 0a** (read `Cover Platforms:` from `project-config.md`). Single version each — no A/B versioning. Each prompt uses the platform-appropriate text-rendering syntax (Ideogram/Grok/Leonardo: title and subtitle baked in; Midjourney: image-only with text-overlay reminder; Claude Design: 7-part briefing). See Phase 4 for output format.
15. **Back Cover Image Prompt** — Same selected platforms, matching front cover aesthetic. One prompt per selected platform.
16. **Wraparound Image Prompt** — Same selected platforms, full cover as single continuous image. One prompt per selected platform.
17. **Alternative Ideas** — 2 brief alternative concept directions.
    Each alternative must use a DIFFERENT dominant color from the main
    concept and from each other. **No two concepts (main + alternatives)
    may share a dominant color.** This forces genuine visual
    differentiation — three blue-toned concepts is three variations of
    one idea, not three ideas. Draw from the Visual Beat Map's Dominant
    Colors column for evidence-backed palette options.
18. **Print Notes** — Production considerations

### Phase 4: Output Format

**One comprehensive prompt per platform per face, FOR EACH PLATFORM
THE USER SELECTED IN PHASE 0a. No A/B versioning.**

Read `Cover Platforms:` from `project-config.md` to determine which
platforms get a prompt-block. Emit ONLY the user's selected platforms.
A user who picked Ideogram + Claude Design (2 of 5) gets 6 prompts
total (2 platforms × 3 faces); a user who picked all five gets 15.

Each prompt is self-contained and includes title and subtitle (if any)
integrated into the platform's text-rendering syntax (per the Platform-
Specific Prompt Formatting section above). Each platform has the
user-side ability to iterate on the result — Ideogram, Grok, and
Leonardo through re-prompting, Claude Design through its native
conversational canvas, Midjourney through its `--seed` and `/blend`
mechanics — so a single comprehensive prompt per platform is cleaner
than splitting into multiple variants.

**Author name policy:** Include the author name in the prompt ONLY if
the user explicitly requests it. By default, omit author name from the
AI prompt — author names rendered by AI almost always look wrong
(spelling, kerning, wrong font). The user should add the author name as
a text overlay afterwards in Canva or another editor. (Midjourney
prompts always omit ALL text — image-only by design.)

**Per-platform text-rendering syntax:** see the Platform-Specific Prompt
Formatting section above (line ~285) for the canonical syntax for each
of the five platforms — that section is the source of truth for prompt
shape; this Phase 4 section defines the OUTPUT WRAPPER format only.

**Present output to the user like this (only the user-selected
platforms appear; the example below shows a user who selected
Ideogram + Claude Design + Midjourney — the other two are omitted):**

```
FRONT COVER — IDEOGRAM
[full prompt — single version, includes title + subtitle (if any) +
composition + style + palette + exclusions]

FRONT COVER — CLAUDE DESIGN (paste at claude.ai/design)
[fully populated 7-part briefing paragraph: product-framing /
genre-conventions / visual-concept / typography (title + subtitle
hierarchy) / image-direction / palette / what-to-avoid /
iteration-invitation. References the relevant genre token file
and trim-size data-attribute when the Ideorix Cover Design System
is loaded.]

FRONT COVER — MIDJOURNEY (image only — add title/subtitle in Canva afterwards)
[compact image-led prompt with --ar matching trim size, --style raw,
--v 6.1; NO title/subtitle/author text in the prompt itself]
```

Repeat the same selected-platform block for back cover and wraparound.
Total output per book: `(N selected platforms) × 3 faces` prompts.

If the user selected only ONE platform, the engine emits 3 prompts
total — clean output, no platforms the user does not use.

---

## Cover Refinement Mode (V2)

After the user generates an initial cover using the prompts from Phase 3-4,
they may want to refine it rather than start over. "Refine this cover" or
"Improve this cover" or "V2 this cover" triggers this mode.

**When to use:** The user has an existing cover image (generated or
uploaded) that's 70% right — good direction, needs polishing. Starting
over would lose what works; refining fixes what doesn't.

**Output:** A refinement prompt the user pastes into an image-editing
tool alongside the uploaded cover image.

**Supported platforms:**
- **Nano Banana 2** (Google) — upload image + paste refinement prompt
- **DALL-E edit mode** — upload image + edit instructions
- **Ideogram Reimagine** — upload image + refinement prompt
- **Claude Design** — paste the existing cover into a Claude Design
  session at `claude.ai/design` and request the change conversationally;
  Claude Design supports iterative refinement natively

### Refinement Hierarchy (keep / refine / adjust / change)

The refinement prompt follows a strict hierarchy that preserves the
core design while improving execution:

**KEEP (never alter):**
- Title, subtitle, author name — exact text preserved
- General text hierarchy (title > tagline > author)
- Core focal subject (the main visual element)
- General layout direction (title-top / image-centre / etc.)
- Genre signalling
- Aspect ratio (match the original)

**REFINE (improve within the same style):**
- Typography — better font choices in the same genre register,
  stronger contrast, cleaner alignment, improved spacing/sizing
- Text legibility — especially at thumbnail scale

**ADJUST (rebalance for stronger impact):**
- Composition — rebalance element positions, improve margins,
  reorganise for stronger visual hierarchy
- Focal point emphasis — sharpen what draws the eye first

**CHANGE (upgrade while preserving mood):**
- Background — more cinematic, polished, detailed treatment of the
  same setting or symbolic motif
- Lighting — more dramatic, genre-appropriate, professional
- Color palette — enhanced contrast, depth, saturation, texture
- Overall finish — from "AI-generated" to "professional book cover"

### Trim Size Inheritance (resolve before producing the template)

The refinement prompt must lock the aspect ratio to the project's chosen
trim size so the refined image stays printable at the same dimensions as
the original cover.

1. **Read `project-config.md`** for `Cover Trim Size:`. If present, use it.
2. **Otherwise**, use the trim size the user declared in Cover Audit Mode
   this session (Minimum Context Intake — see above).
3. **If still unknown** (no project, no audit context), default to `6x9`
   and flag this in the message you send the user with the template.

Substitute `{TRIM}` and `{RATIO}` in the template using this map:

| Trim | Ratio |
|---|---|
| 6x9 | 2:3 |
| 5.25x8 | 21:32 |
| 4.25x6.87 | ~0.62:1 |
| 5x8 | 5:8 |
| 5.5x8.5 | 11:17 |
| 5.06x7.81 | ~13:20 |
| 7x10 | 7:10 |
| 8.5x11 | 17:22 |

For any trim not in this table, compute `width:height` and reduce to
lowest terms.

### Refinement Prompt Template

```
Transform this into a more striking, professional book cover while
keeping it as a recognisable variation of the same design.

KEEP: same title, subtitle, author name and text hierarchy. Same core
focal subject and general layout direction. Same genre.

REFINE: typography — better font choices in a similar genre register,
stronger contrast, cleaner alignment, improved spacing and sizing.

ADJUST: composition — rebalance where the title, subtitle, author name,
and main focal image sit on the page. Improve margins. Reorganise
elements for stronger visual hierarchy.

CHANGE: background and lighting — preserve the same mood and subject
matter but with a more cinematic, polished, detailed treatment. Enhance
color palette, contrast, depth, and texture for a refreshed, more
modern redesign of the same cover.

Do not change the wording of any text. Do not alter the genre. Keep
the aspect ratio of the original cover at {RATIO} (matching the {TRIM}
print specification). Portrait orientation.

{ADDITIONAL SPECIFIC NOTES — e.g., "the title text is garbled — re-render
it cleanly", "the figure's hand has too many fingers — fix anatomy",
"the sky is too saturated — pull it back to muted tones"}
```

**Present to the user as:** The template above, customised with any
specific issues the user flagged, with platform-specific instructions
for how to use it (upload steps for each platform).

---

## Canva Layer Breakdown (Post-Generation)

After the user generates a cover image using the prompts from Phase 3-4,
produce a **layered reconstruction spec** — a document that tells the
user exactly how to rebuild the cover in Canva (or Photoshop/Figma) as
editable layers. This bridges the gap between "I have an AI image" and
"I have a production-ready cover I can tweak without regenerating."

### When to produce

- After the user has approved a cover concept AND has a generated image
- Triggered by: "Layer breakdown", "Canva breakdown", "Make this
  editable", or any request to reconstruct the cover as layers
- Also produced automatically alongside Version B (artwork-only) prompts
  when the user has confirmed which concept they're taking forward

### Output structure

The Canva Layer Breakdown document contains:

**1. Canvas Setup**
- Dimensions (px at 300 DPI, matching the approved trim size)
- Background colour (hex, from the approved concept's palette)
- Bleed and safe-zone guides (if Canva Pro)

**2. Layer Stack (bottom to top, z-order)**

```
LAYER STACK — [Book Title]

Layer 1 (bottom):  ARTWORK BASE
  Source:          [Ideogram/Grok/Claude Design] output image
  Position:        Fill canvas, extend to bleed
  Blend mode:      Normal
  Opacity:         100%
  Notes:           This is the Version B (artwork-only) output

Layer 2:           ATMOSPHERE OVERLAY (optional)
  Type:            Gradient / vignette / texture
  Colour:          {hex} → transparent
  Direction:       Top-to-bottom / radial / edge
  Blend mode:      Multiply / Overlay / Soft Light
  Opacity:         {N}%
  Purpose:         Darken edges for text legibility

Layer 3:           TITLE TEXT
  Text:            "{EXACT TITLE}"
  Font:            {font name} (Google Fonts / Canva font)
  Size:            {N}pt at {DPI}
  Weight:          {Bold / Regular / Light}
  Colour:          {hex}
  Position:        x: {N}px from left, y: {N}px from top
  Letter spacing:  {N}% tracking
  Line height:     {N}px (if multi-line)
  Effects:         {shadow / glow / outline — specify if used}
  Alignment:       {centre / left / right}

Layer 4:           TAGLINE TEXT (if applicable)
  Text:            "{EXACT TAGLINE}"
  Font:            {font name}
  Size:            {N}pt
  Colour:          {hex}
  Position:        x: {N}px, y: {N}px
  Letter spacing:  {N}%

Layer 5:           AUTHOR NAME
  Text:            "{EXACT AUTHOR NAME}"
  Font:            {font name}
  Size:            {N}pt
  Weight:          {weight}
  Colour:          {hex}
  Position:        x: {N}px, y: {N}px
  Letter spacing:  {N}%

Layer 6 (top):     DECORATIVE ELEMENTS (optional)
  Type:            {border / frame / emblem / series badge}
  Source:           {Canva element / extracted from artwork / custom}
  Position:        {coordinates}
  Blend mode:      {mode}
  Opacity:         {N}%
```

**3. Font Stack & Fallbacks**
- Primary title font: {name} — {source: Google Fonts / Adobe / Canva built-in}
- If unavailable: {fallback 1}, {fallback 2}
- Author font: {name} — {source}
- If unavailable: {fallback 1}, {fallback 2}
- Tagline font (if different): {name}

**4. Colour Reference Card**

| Swatch | Name | Hex | RGB | Usage |
|---|---|---|---|---|
| ■ | {name} | #{hex} | {r,g,b} | {where it appears} |

Include the CMYK advisory: *"Canva Pro exports CMYK for print. Free
Canva exports RGB — some colours (especially saturated cyan, neon
green, vivid orange) shift in CMYK. If using free Canva, verify print
colours with a proof copy."*

**5. Thumbnail Verification**
- Shrink the export to 120px wide
- Check: title still readable? One dominant shape still hits? If not,
  increase title size or contrast on the atmosphere overlay layer.

**6. Seed/Prompt Pin**
- Record the exact prompt + seed/generation ID used for the approved
  artwork so the back cover, spine, and wraparound can match the
  treatment. Platform-specific:
  - Ideogram: save the generation URL + seed number
  - Grok: save the prompt text (no seed control)
  - Claude Design: save the session URL or export the design as a
    standalone folder; the design canvas preserves the conversation
    context so the back cover, spine, and wraparound iterations
    inherit the established treatment

### Why this exists

The gap this fills: a user generates a beautiful cover in Ideogram,
but the title text is slightly garbled (common), or they want to
change the author name (pen name decision), or they need to adjust
the tagline. Without a layer breakdown, their only option is to
regenerate and hope. With the breakdown, they open Canva, place the
artwork-only version as the base layer, and add text layers exactly
as specified — font, size, position, tracking, colour all pre-
calculated. Tweaking without regenerating.

---

## Genre Cover Aesthetics — How Genre Files Contribute

Each genre file in the genre bank includes a `## Cover Design Specifications` section with:

```markdown
## Cover Design Specifications

### Recommended Visual Styles
Which 3-4 of the 8 universal styles work best for this genre,
with notes on when to use each.

### Genre Cover Aesthetics
- **Styles:** 4-5 visual/design approaches characteristic of this genre
- **Colours:** 4-5 colour recommendations with genre psychology
- **Elements:** 4-5 visual motifs that signal this genre to readers
- **Typography:** Font style guidance specific to this genre

### Subgenre Variations (if applicable)
Different cover aesthetics for subgenres
(e.g., psychological thriller vs action thriller)

### Market Positioning
How covers in this genre should position on retail platforms.
What visual language signals the genre correctly.

### Cover Design DON'Ts
Genre-specific visual elements to AVOID
(elements that confuse genre signalling or alienate the target reader)
```

**Integration point:** The prompt pipeline injects genre aesthetics into the AI prompt at the "Design Requirements" section:
```
Genre Conventions: [styles from genre file]
Typical Genre Colours: [colours from genre file]
Common Genre Elements: [elements from genre file]
```

---

## Universal Quality Criteria

Every cover concept is evaluated against:

### Thumbnail Test
- Does the cover read at Amazon thumbnail size (~160×256 pixels)?
- Is the title legible at thumbnail scale?
- Does the genre register instantly?
- Does it stand out against competitors in a grid view?

### Genre Signal Accuracy
- Would a reader browsing this genre section recognise this as belonging?
- Does the cover use the visual language of the genre without being derivative?
- Is the colour palette genre-appropriate?

### Composition Rules
- **Rule of thirds** — focal point at intersection points
- **Visual hierarchy** — eye moves: title → image → author name
- **Breathing room** — not overcrowded; negative space is intentional
- **Spine integration** — wraparound designs flow naturally across the spine
- **Back cover utility** — space for blurb text (upper 60%), ISBN barcode (bottom right), publisher info (bottom centre)

### Print Production
- All critical elements within safe zone (0.25" from trim)
- Artwork extends to bleed (0.125" beyond trim)
- Spine text readable at calculated spine width (flag if spine < 0.3" — text may not fit)
- Colour mode appropriate for print (CMYK considerations noted)
- Resolution sufficient (300 DPI minimum for print)

### Market Competitiveness
- Researched against current bestseller covers in the genre
- Avoids dated trends identified in market analysis
- Positions the book to compete, not just to look attractive in isolation

### Concept Differentiation
- No two concepts (main + alternatives) share a dominant color
- Each concept targets a different reader psychology (e.g., mood-buyer
  vs plot-buyer vs character-buyer)
- Alternative concepts are genuinely different directions, not palette
  swaps of the main concept

### Concept Scoring

Score each concept on 5 weighted criteria. Present the score alongside
the concept so the user has a clear quality signal.

| Criterion | Weight | What it measures |
|---|---|---|
| Genre Clarity | 30% | Would a genre reader instantly recognise this as their genre? |
| Visual Potency | 25% | Does the image arrest attention at thumbnail scale? |
| Trope Strength | 20% | Does the cover signal the book's tropes to the target reader? |
| Market Hook | 15% | Does it compete with current bestseller covers in this genre? |
| Distinctiveness | 10% | Does it stand apart from the genre's visual clichés? |

**Rating scale:**
- ≤3: Unmarketable — fundamental genre or visual mismatch
- 4-6: Needs Work — recognisable but not competitive
- 7-8: Solid Genre Fit — would sell on a shelf
- ≥9: Bestseller Potential — arresting, distinctive, genre-perfect

**Scoring output per concept:**
```
CONCEPT SCORE: {weighted total}/10
  Genre Clarity:   {N}/10 (×0.30 = {weighted})
  Visual Potency:  {N}/10 (×0.25 = {weighted})
  Trope Strength:  {N}/10 (×0.20 = {weighted})
  Market Hook:     {N}/10 (×0.15 = {weighted})
  Distinctiveness: {N}/10 (×0.10 = {weighted})
  Rating: {label}
  Recommendation: {one sentence — what would improve the weakest criterion}
```

---

## Output Schema

```json
{
  "conceptName": "string — Creative name for the concept",
  "marketAnalysis": {
    "genreTrends": "string — Current bestseller visual trends",
    "competitorCovers": ["string — Title + why it works (3-5 entries)"],
    "marketPosition": "string — How this design competes",
    "avoidPatterns": ["string — Dated/overused trends to avoid"]
  },
  "visualConcept": "string — Detailed main visual description",
  "composition": "string — Layout and visual hierarchy",
  "colorPalette": [
    { "name": "string", "hex": "#XXXXXX", "usage": "string — Where and why" }
  ],
  "typography": {
    "titleFont": "string — Font recommendation with style notes",
    "authorFont": "string — Font for author name",
    "taglineFont": "string — Optional tagline font",
    "spineFont": "string — Font for spine text"
  },
  "titleTreatment": {
    "text": "string", "position": "string", "style": "string",
    "color": "string", "effects": "string", "size": "string"
  },
  "authorTreatment": {
    "text": "string", "position": "string", "style": "string",
    "color": "string", "effects": "string", "size": "string"
  },
  "taglineTreatment": {
    "text": "string", "position": "string", "style": "string",
    "color": "string", "effects": "string", "size": "string"
  },
  "mood": "string — Emotional atmosphere",
  "keyElements": ["string — Visual elements to include"],
  "spineDesign": "string — Spine area treatment",
  "backCoverConcept": "string — Back cover design",
  "imagePrompt": {
    "ideogram": "string", "grok": "string", "claudeDesign": "string"
  },
  "backCoverImagePrompt": {
    "ideogram": "string", "grok": "string", "claudeDesign": "string"
  },
  "wraparoundImagePrompt": {
    "ideogram": "string", "grok": "string", "claudeDesign": "string"
  },
  "doNotInclude": [
    { "element": "string — Visual element to exclude", "reason": "string — Why it's wrong for this book" }
  ],
  "score": {
    "genreClarity": "number (1-10)", "visualPotency": "number (1-10)",
    "tropeStrength": "number (1-10)", "marketHook": "number (1-10)",
    "distinctiveness": "number (1-10)", "weightedTotal": "number (1-10)",
    "rating": "string — Unmarketable | Needs Work | Solid Genre Fit | Bestseller Potential",
    "recommendation": "string — One sentence on what would improve the weakest criterion"
  },
  "alternativeIdeas": ["string — Brief alternative concept directions (each with different dominant color)"],
  "printNotes": "string — Production considerations"
}
```

---

## Platform Variant Guide

Once the user approves the main cover concept and has their hero image (the final
front cover with text baked in from their AI image generator), present this
variant guide. The hero image is the single source of truth — all variants
derive from it.

### Master Files Needed

From one approved cover, the user needs **13 variant categories**. Most are
simple resizes; a few need recomposition (image repositioned + text re-placed).

### Tier 1: Direct Resize (Same or Similar Aspect Ratio)

These platforms accept the hero image resized directly. No recomposition needed.

| Variant | Dimensions | Format | Used For |
|---------|-----------|--------|----------|
| eBook Master | 2,560 × 1,600 px | JPEG, RGB | Amazon KDP eBook |
| Apple Books | 1,600 × 2,560 px | PNG, RGB | Apple Books (same file as eBook) |
| Barnes & Noble | 2,500 × 1,600 px | JPEG, RGB | Nook (same file as eBook) |
| Kobo | 2,560 × 1,600 px | JPEG, RGB | Kobo (same file as eBook) |
| Google Play | 2,560 × 1,600 px | JPEG, RGB | Google Play Books (same file as eBook) |
| Draft2Digital | 2,560 × 1,600 px | JPEG, RGB | D2D / Smashwords (same file as eBook) |
| Goodreads | 1,000 × 1,500 px | JPEG, RGB | Goodreads listing |
| BookBub Deal | 860 × 1,300 px | JPEG, RGB | BookBub Featured Deal |
| Pinterest | 1,000 × 1,500 px | JPEG, RGB | Pinterest pin (same as Goodreads) |

**Canva instructions for Tier 1:**
1. Open Canva → Create a design → Custom size → enter dimensions
2. Upload the hero image
3. Place it to fill the canvas (drag corners to fit)
4. Download as JPEG (or PNG for Apple Books)

**Result: 1 hero image serves 9 platforms.** The eBook master file (2,560 × 1,600)
works for KDP, Apple, B&N, Kobo, Google Play, and D2D without any changes.
Goodreads and Pinterest share the same 1,000 × 1,500 resize.

### Tier 2: Recomposition Required (Different Aspect Ratio)

These variants have a significantly different aspect ratio from the standard
book cover. The hero image needs to be cropped or repositioned, and text should
be re-placed as a separate Canva text layer for optimal positioning.

| Variant | Dimensions | Aspect Ratio | Used For |
|---------|-----------|-------------|----------|
| Audiobook (ACX/Audible) | 2,400 × 2,400 px | 1:1 square | Audible listing |
| Instagram Square | 1,080 × 1,080 px | 1:1 square | Instagram / Facebook / Twitter |
| Instagram Portrait | 1,080 × 1,350 px | 4:5 | Instagram feed |
| Instagram Story | 1,080 × 1,920 px | 9:16 | Instagram Stories / Reels |
| Facebook Landscape | 1,200 × 628 px | ~1.91:1 | Facebook ads |
| Twitter/X Landscape | 1,200 × 675 px | 16:9 | Twitter/X posts |
| BookBub Ad | 300 × 250 px | 6:5 | BookBub self-serve ads |

**Canva instructions for Tier 2 — Recomposition:**

**Step 1: Set up the canvas**
1. Canva → Create a design → Custom size → enter variant dimensions
2. Set the background to the dominant colour from the cover's colour palette
   (use the hex code from the Cover Designer output above)

**Step 2: Place the hero image**
3. Upload the hero image
4. Position it within the canvas using these composition rules:

| Variant | Image Placement |
|---------|----------------|
| Audiobook square | Centre the key visual. Crop equally from top and bottom (or left and right, depending on cover composition). The title must remain fully visible. |
| Instagram square | Same as audiobook but at 1,080 px. If the full cover doesn't fit, show the top 60% (title + key visual). |
| Instagram portrait | The full cover usually fits well at 4:5. Slight crop from top/bottom. |
| Instagram story | Place the cover image in the centre of the tall canvas. Fill the top and bottom with the background colour or a subtle gradient. |
| Facebook landscape | Place the cover image on the right third. Use the left two-thirds for a text callout (tagline, "Available Now", review quote). |
| Twitter landscape | Same approach as Facebook landscape. |
| BookBub ad | Small format — use just the cover image scaled to fit, or the key visual element with a bold title overlay. |

**Step 3: Re-place the text**
5. If the title/author text was cropped or is poorly positioned after resizing:
   - Add a new text layer in Canva
   - Use the exact font, size, colour, and effects from the Typography section
     of the Cover Designer output above
   - Position the text for this specific format's composition

**Step 4: Export**
6. Download as JPEG (social media) or PNG (where transparency may be useful)

### Tier 3: Print Covers (Full Wraparound)

Print covers require the front, spine, and back as a single wraparound PDF.
These cannot be created from the hero image alone — they need additional
design work for the spine and back cover.

| Variant | Specs | Used For |
|---------|-------|----------|
| KDP Paperback | CMYK PDF, 300 DPI, 0.125" bleed | Amazon print |
| IngramSpark | PDF/X-1a CMYK, 300 DPI, 0.125" bleed | Wide print distribution |
| KDP Hardcover | CMYK PDF, 300 DPI, + case wrap allowance | Amazon hardcover |

**Spine width formula:** Page Count × Paper Thickness (per inch)
- White standard paper: Page Count × 0.00225"
- Cream standard paper: Page Count × 0.0025"

**Full cover width:** (Trim Width × 2) + Spine Width + (Bleed × 2)
**Full cover height:** Trim Height + (Bleed × 2)

**Canva instructions for print wraps:**
1. Use KDP's Cover Calculator (kdp.amazon.com) or IngramSpark's Cover Template
   Generator to get exact dimensions for your page count and trim size
2. Download their template (PDF with guides showing spine, bleed, safe zones)
3. In Canva: Create a design at the exact pixel dimensions (width × height × 300 DPI)
4. Place the template as a background layer (for guides)
5. Position the hero image on the front cover area
6. Design the spine: Title + Author Name, vertically, using the spine font from
   the Typography section above
7. Design the back cover using the back cover concept from the Cover Designer
   output above
8. Leave the barcode area clear (lower-right of back cover, 2" × 1.2")
9. Export as PDF Print (Canva Pro) or high-quality PDF
10. For IngramSpark: ensure CMYK colour space — Canva Pro supports this;
    free Canva exports RGB which IngramSpark may reject

**Important:** KDP and IngramSpark calculate spine width differently. Always use
each platform's own calculator. Do NOT use the same wraparound PDF for both.

### Tier 4: Amazon A+ Content (Enhanced Brand Content)

A+ Content uses supplementary marketing images, not the cover itself. These are
optional but significantly increase conversion on the Amazon listing page.

| Module | Dimensions | Description |
|--------|-----------|-------------|
| Banner header | 970 × 300 px | Wide banner — use cover art as background with tagline overlay |
| Standard image | 970 × 600 px | Feature image — cover detail or atmospheric scene |
| Comparison chart | 150 × 300 px per cell | Small cells — use for series book covers side by side |

**Canva instructions:**
1. Create designs at exact pixel dimensions (Amazon rejects non-matching sizes)
2. Use elements from the hero image (cropped details, colour palette) rather than
   the full cover — A+ Content should complement, not duplicate
3. Export as JPEG, under 2 MB per image

### Platform Upload Checklist

Once all variants are created, use this checklist to upload to each platform:

```
UPLOAD CHECKLIST — {Book Title}

☐ Amazon KDP eBook     → 2,560 × 1,600 JPEG (Tier 1)
☐ Amazon KDP Paperback → Wraparound PDF from KDP calculator (Tier 3)
☐ Amazon KDP Hardcover → Wraparound PDF from KDP calculator (Tier 3)
☐ ACX / Audible        → 2,400 × 2,400 JPEG square (Tier 2)
☐ IngramSpark          → Wraparound PDF/X-1a from Ingram template (Tier 3)
☐ Apple Books           → Same as eBook master (Tier 1)
☐ Barnes & Noble        → Same as eBook master (Tier 1)
☐ Kobo                  → Same as eBook master (Tier 1)
☐ Google Play           → Same as eBook master (Tier 1)
☐ Draft2Digital         → Same as eBook master (Tier 1)
☐ Goodreads             → 1,000 × 1,500 JPEG (Tier 1)
☐ BookBub Featured Deal → Uses retailer cover automatically
☐ BookBub Ads           → 300 × 250 JPEG (Tier 2)
☐ Amazon A+ Content     → Per-module sizes (Tier 4)
☐ Instagram Square      → 1,080 × 1,080 (Tier 2)
☐ Instagram Portrait    → 1,080 × 1,350 (Tier 2)
☐ Instagram Story       → 1,080 × 1,920 (Tier 2)
☐ Facebook Ad           → 1,200 × 628 (Tier 2)
☐ Twitter/X             → 1,200 × 675 (Tier 2)
☐ Pinterest             → 1,000 × 1,500 (Tier 1 — same as Goodreads)
```

### When to Present This Guide

Present the Platform Variant Guide automatically when:
- The user approves the final cover concept ("I'm happy with this", "approved",
  "let's go with this one")
- The user asks about sizes, formats, or platform requirements
- The user says "prepare for publishing" or "what do I need for upload"

Do NOT present it during the initial concept phase — wait until the cover
design is finalised.

---

## Relationship to Other Engine Files

| Engine File | Relationship |
|-------------|-------------|
| `publishing-formats.md` | Cover concepts feed into KDP metadata (cover description, visual branding) |
| `core-pipeline.md` | Cover generation happens AFTER manuscript is complete or near-complete |
| `world-canon.md` | Story Bible provides visual context (settings, characters, atmosphere) |

The Cover Designer is a **post-manuscript tool** — it consumes the Story Bible and manuscript data to create visually accurate cover concepts that represent the finished work.
