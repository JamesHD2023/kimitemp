---
name: cover-designer
description: AI-powered book cover concept generation with market research, genre-aware aesthetics, and multi-platform image prompts
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Cover Designer — Engine Skill

## File Location Discipline (MANDATORY)

**Cover concept outputs** (concept descriptions, AI image
prompts, generation IDs / seeds, cover briefs for designers,
A+ Content imagery specs) MUST be written to
`~/Documents/Ideorix-Projects/[Title]/marketing/cover/`.
Reference imagery and seed/ID logs land in the same folder.
Generated cover images themselves are typically downloaded
by the user from the AI image provider (Midjourney /
Ideogram / Leonardo / Grok); save those to the same folder
when delivered to the engine. Outputs MUST NOT be written
to the parent `~/Documents/Ideorix-Projects/` folder, the
agent's working directory, or any sandbox / temporary path.
See `core-pipeline.md` § File Location Discipline and
`marketing-and-cover.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Purpose

The Cover Designer generates comprehensive book cover concepts that are:
- **Market-competitive** — researched against current bestseller trends
- **Genre-accurate** — signals the right genre to readers instantly
- **Print-ready** — calculated to exact trim size, spine width, and DPI specifications
- **Multi-platform** — produces optimised prompts for Ideogram, Leonardo.ai, Grok Aurora, and Midjourney

## When to Use

Activate when:
- The user requests a cover concept or cover design
- The manuscript is complete or near-complete and moving toward publishing
- The user is in the Publishing Studio / Cover Designer interface
- **The user uploads an existing cover image for analysis, refinement, or
  reconstruction** (see Cover Audit Mode below)

## Cover Audit Mode — Upload an Existing Cover

A standalone entry point that works WITHOUT a project, manuscript, or
Story Bible. The user uploads an existing cover image (their own, a
comp title, or a rough draft) and gets a full audit.

**Triggers:**
- "Analyse this cover" / "Audit my cover" / "Review my cover"
- "Improve this cover" / "Refine this cover"
- "Score this cover" / "Rate my cover"
- An uploaded image with any cover-related request
- "Break this into Canva layers" / "Make this editable"

**Works with:**
- The user's own cover (generated in Ideogram/Midjourney, designed in
  Canva, purchased from a designer, or drafted in Photoshop)
- A competitor/comp title cover they want to analyse
- A rough sketch or mockup they want feedback on
- A cover they've seen on Amazon and want to understand

### Minimum Context Intake (before analysis)

The cover audit needs minimum context to score accurately. If the user
has an active Ideorix project, pull context from `project-config.md`
and `story-bible.md`. Otherwise, ask the user for the minimum
required:

1. **Genre** (required for Genre Clarity scoring)
   "What genre is this cover for?" — present the standard genre list
2. **Target audience** (required for Market Hook scoring)
   "Who's the target reader? Adult / YA / Middle Grade / Children's?"
3. **Trim size** (required for aspect-ratio audit, thumbnail survival check, and layer decomposition output)
   "What trim size is this cover for? 1) 6×9 (Trade Paperback) · 2) 5.25×8 (Compact Trade) · 3) 4.25×6.87 (Mass Market) · or 'advanced' for other sizes"
   *If the user has an active project with `Cover Trim Size:` in `project-config.md`, use that and skip this question.*
4. **Title** (if not visible or ambiguous in the image)
   "I can see the title appears to be '{X}' — is that correct?"
5. **Author name** (if not visible)
   "What's the author name?"
6. **Tropes/themes** (optional — strengthens Trope Strength scoring)
   "Any specific tropes or themes the cover should signal?"

If the user doesn't answer a field, score that dimension with
"insufficient context — scored on visual merit alone" and flag it
in the recommendation.

**Why trim size matters for audit:** The aspect-ratio check, thumbnail-survival test, spine-width estimate (if wraparound is requested), and Canva layer decomposition output dimensions all depend on the trim size. An audit run without trim size loses these checks. If the user genuinely doesn't know (e.g., comparing a competitor's cover), default to **6×9** and flag in the report: "Trim size assumed 6×9 — if actual differs, aspect-ratio score may shift."

### Cover Audit Output

After context intake, Claude analyses the uploaded image and produces:

**1. Visual Analysis (what the cover is)**
- Composition (focal point, visual hierarchy, thirds/rule alignment)
- Colour palette (3-5 dominant colours with hex approximations)
- Typography (title font style, author font style, legibility)
- Imagery (style — illustration/photograph/digital painting/mixed;
  subject — figure/landscape/object/symbolic)
- Mood (emotional register the cover projects)
- Genre signalling (what genre this cover reads as at first glance)

**2. Weighted Score (same 5-criteria system as normal covers)**

```
COVER AUDIT — {Title}
Intended genre: {genre}
Target audience: {audience}

  Genre Clarity:   {N}/10 (×0.30 = {weighted})
  Visual Potency:  {N}/10 (×0.25 = {weighted})
  Trope Strength:  {N}/10 (×0.20 = {weighted})
  Market Hook:     {N}/10 (×0.15 = {weighted})
  Distinctiveness: {N}/10 (×0.10 = {weighted})

  Overall: {weighted total}/10
  Rating: {Unmarketable | Needs Work | Solid Genre Fit | Bestseller Potential}
```

**3. Specific Strengths (what's working)**
- 2-4 bullet points naming what's genuinely strong about this cover

**4. Specific Issues (what needs attention)**
- 2-5 bullet points with exact problems (e.g., "title text illegible at
  thumbnail size", "colour palette signals thriller but tropes suggest
  cosy mystery", "composition crowded in the bottom third")

**5. User's next-step menu**

```
What would you like to do next?

  A. Refinement prompt (V2) — I'll produce a prompt you can paste into
     Nano Banana 2, Midjourney img2img, DALL-E edit, or Ideogram
     Reimagine alongside your uploaded cover. Polishes what's here
     without starting over.

  B. Canva Layer Breakdown — I'll reverse-engineer the cover into a
     layered reconstruction spec so you can rebuild it in Canva,
     Photoshop, or Figma with full control over each element.

  C. Full redesign — I'll generate three new concept directions with
     platform-ready image prompts. (Requires a manuscript or project
     context for best results — I'll ask for more info if needed.)

  D. Compare against comp titles — Upload 2-3 bestseller covers in
     your genre and I'll show you how yours stacks up visually.

  E. Refine one specific element — Tell me what bothers you (typography,
     composition, lighting, etc.) and I'll focus the audit there.
```

### Operating without a project

Cover Audit Mode does NOT require:
- A project folder
- A Story Bible
- A manuscript
- Market Scout output
- An existing `engine-data/` directory

It DOES use existing protocols when the data is available. If an
active project exists, the audit inherits:
- Genre, tropes, target audience from `project-config.md`
- Visual Beat Map (if already generated)
- Existing concept specs (if the user has run the Cover Designer before)

If the user later wants to save the audit to disk, offer to save to
`Ideorix-Projects/Cover Audits/{YYYY-MM-DD}-{slug}.md` — a shared
location for standalone audits that don't belong to a specific project.

## Architecture: Permanent vs Genre-Specific

```
Engine (this file)                      Genre Bank (per genre file)
─────────────────                       ───────────────────────────
Print specifications                    Cover aesthetic palette
Visual style taxonomy                   Recommended visual styles
AI platform formats                     Genre-specific visual motifs
Output schema                           Market positioning guidance
Prompt pipeline                         Design DON'Ts
Quality criteria                        Typography recommendations
Universal composition rules             Subgenre variations
```

The engine defines HOW covers are generated. Genre files define WHAT the cover should look like for that specific genre.

---

## Print Specifications (Universal)

### Trim Sizes

The Cover Designer offers **three recommended trim sizes** at the start of every full cover design pass (Phase 0 — see Cover Generation Pipeline). The user selects one, and the choice is persisted to `project-config.md` as `cover_trim_size` so subsequent covers (back cover, V2 refinements, marketing variants) inherit it automatically.

**Recommended sizes (presented at Phase 0):**

| ID | Dimensions | Best For | Spine Note |
|----|-----------|----------|------------|
| **6x9** | 6" × 9" | Trade Paperback (default) — epic fantasy, sci-fi, longer literary novels, multi-POV sagas | Comfortable spine on 200+ page books |
| **5.25x8** | 5.25" × 8" | Compact Trade — most popular indie size for romance, thriller, mystery, contemporary fiction, novels of all genres | Novel-like feel; better page economics |
| **4.25x6.87** | 4.25" × 6.87" | Mass Market — novellas, romance, genre series, books under ~50k words | Solves thin-spine problem on novellas |

**Selection rules:**
- Default if user doesn't specify: **6x9**
- Recommendation logic: novellas (<50k words) and romance/genre fiction → suggest **4.25x6.87**; longer or literary works → suggest **6x9**; everything else → suggest **5.25x8**
- The user can always override the suggestion and choose any of the three (or one of the advanced sizes below)

**Advanced sizes (available on request):**

| ID | Dimensions | Words/Page | Description |
|----|-----------|------------|-------------|
| 5x8 | 5" × 8" | 275 | Standard Trade Paperback (alternative compact) |
| 5.5x8.5 | 5.5" × 8.5" | 300 | Popular Trade Size (literary fiction, memoir) |
| 5.06x7.81 | 5.06" × 7.81" | 250 | Digest / B-Format (UK paperback) |
| 8.5x11 | 8.5" × 11" | 500 | Letter / Workbook |
| 7x10 | 7" × 10" | 450 | Textbook / Manual |

If the user asks for a size not on this list, accept it (KDP supports many trim sizes) but flag any non-standard ratio that may cause spine-width or aspect-ratio issues.

### Paper Types

| ID | Name | Pages/Inch | Thickness | Description |
|----|------|-----------|-----------|-------------|
| white-standard | White (Standard) | 444 | 0.00225" | 50lb / 74gsm white |
| cream-standard | Cream / Off-White | 400 | 0.0025" | 60lb / 89gsm cream |
| white-premium | White (Premium) | 380 | 0.00263" | 60lb / 89gsm premium white |
| cream-premium | Cream (Premium) | 333 | 0.003" | 70lb / 104gsm premium cream |

### Bleed & Safe Zone

- **Bleed:** 0.125" (1/8 inch) on all sides — artwork must extend beyond trim
- **Safe zone:** 0.25" (1/4 inch) from trim edges — no text or critical elements

### Spine Width Calculation

```
Spine Width = Page Count × Paper Thickness
Page Count = ceil(Word Count / Words Per Page) + Front Matter Pages
```

### Full Cover Dimensions

```
Full Cover Width = (Trim Width × 2) + Spine Width + (Bleed × 2)
Full Cover Height = Trim Height + (Bleed × 2)
Pixel Dimensions = Dimensions × DPI (300 for print, 72 for web)
```

---

## Visual Style Taxonomy (Universal)

These styles apply to ALL genres. The genre file specifies which 3-4 are most appropriate.

| ID | Name | Description |
|----|------|-------------|
| photorealistic | Photorealistic | Photo-quality imagery with realistic details |
| illustrated | Illustrated | Hand-drawn or painted artistic style |
| minimalist | Minimalist | Clean, simple design with focus on typography |
| graphic | Graphic Novel | Bold graphics and comic-style aesthetics |
| vintage | Vintage/Retro | Classic, nostalgic design elements |
| abstract | Abstract | Conceptual and symbolic imagery |
| cinematic | Cinematic | Movie poster style with dramatic lighting |
| typographic | Typography-Led | Title as the main visual element |

---

## AI Image Generation Platforms

### Platform Characteristics

| Platform | Strength | Best For | Notes |
|----------|----------|----------|-------|
| **Ideogram** | Superior text rendering | Covers WITH title/author text | Best at rendering readable text in images |
| **Leonardo.ai** | Style consistency, free tier | Illustrated/painterly covers | 150 free generations/day; supports style tags and negative prompts |
| **Grok Aurora** | Free access, quick iteration | Rapid concept exploration | Free via X; good for testing concepts |
| **Midjourney** | Highest visual quality | Final production covers | Best overall image quality; supports --ar, --style, --v parameters |

### Platform-Specific Prompt Formatting

**Ideogram:**
- Specify text to render in quotes: `with title text "Book Title" in [font style] at [position]`
- Supports style presets and aspect ratios
- Best for covers that need text baked into the image

**Leonardo.ai:**
- Use style tags for consistency
- Include negative prompt: `Negative prompt: [unwanted elements]`
- For no-text covers: negative prompt MUST include `text, letters, words, typography`

**Grok Aurora:**
- Direct, descriptive prompts work best
- For text version: specify title AND author name explicitly — e.g., `with the words
  "BOOK TITLE" displayed prominently at the top in [font style] lettering, and
  "AUTHOR NAME" at the bottom in [font style]`
- Structure the author name as a separate line the user can remove if rendering is poor
- For artwork-only version: MUST include `no text, no words, no letters, no writing,
  no typography` at the end of the prompt
- Good for atmospheric and mood-driven concepts

**Midjourney:**
- Use parameters: `--ar [ratio] --style [value] --v 6`
- For no-text covers: `--no text, words, letters, typography`
- Calculate aspect ratio: `--ar [full_width/full_height]:1` for wraparound

---

## Cover Generation Pipeline

### Phase 0: Trim Size Selection (MANDATORY)

Before any other phase runs, the Cover Designer must establish the trim size for this cover. This drives the aspect ratio passed to image-generation prompts, the spine-width calculation, the thumbnail proportions in audit reports, and the Canva layer dimensions.

**Decision tree:**

1. **Is `cover_trim_size` already set in `project-config.md`?**
   - YES → Use that size. Skip to Phase 1. Do NOT re-prompt.
   - NO → Continue to step 2.

2. **Display the trim size selection prompt:**

   ```
   Choose a trim size for this cover:

     1. 6" × 9"        — Trade Paperback (default)
                          Best for: epic fantasy, sci-fi, longer literary novels

     2. 5.25" × 8"     — Compact Trade
                          Best for: most indie fiction — romance, thriller,
                          mystery, contemporary, novels of all genres

     3. 4.25" × 6.87"  — Mass Market Paperback
                          Best for: novellas, romance, genre series,
                          books under ~50k words (solves thin-spine problem)

   My recommendation for your project: {N} — {one-line reason}

   Type 1, 2, or 3. Or say "advanced" to see other supported sizes.
   ```

3. **Generate the recommendation** based on the manuscript context:
   - Novella (<50k words) OR primary genre is romance/cozy/genre-fiction → recommend **3 (4.25" × 6.87")**
   - Word count >85k OR primary genre is literary/epic-fantasy/sci-fi → recommend **1 (6" × 9")**
   - Otherwise → recommend **2 (5.25" × 8")**

4. **Persist the choice** to `project-config.md` immediately after selection. Append (or update) these lines:

   ```markdown
   Cover Trim Size: 5.25x8
   Cover Trim Set: 2026-04-25
   ```

   Use bash-direct append per the File Operation Policy. Read the current file first to avoid overwriting other config lines.

5. **Acknowledge and proceed:**

   ```
   ✓ Trim size set: 5.25" × 8" (Compact Trade)
     This will be used for all covers in this project. To change later,
     edit project-config.md or say "change trim size".
   ```

**If the user says "advanced":** Display the full Trim Sizes table including the advanced options, then accept any selection.

**If no project-config.md exists** (Cover Audit Mode standalone, no project): Ask once, use the answer for this session, do not persist.

### Phase 1: Market Research

Load `market-scout.md` and run Market Scout with context: **"cover"**.

The cover context adapter emphasises comp title cover designs, visual trends,
dominant colours, typography styles, imagery types, and what's dated. Feed the
Market Scout Report findings into Phase 2 (Context Assembly).

See `market-scout.md` for the full protocol, report format, and fallback behaviour.

### Phase 2: Context Assembly

```
Inputs gathered:
- Book information (title, author, genre, series)
- Story overview (Story Bible, truncated to 3,000 chars)
- Key themes and main characters (see Character Visual Profile below)
- Print specifications (calculated from word count + trim size + paper type)
- Genre cover aesthetics (from genre bank file — see ## Cover Design Specifications)
- Author's creative direction (from Pre-Publishing Brief, if available)
- User's selected visual style
- Text rendering mode (text in image vs artwork only)
- Tagline (optional)
- Visual Evidence Audit (every visual claim traced to manuscript — see below)
```

#### Evidence Rule (MANDATORY)

Every visual claim about characters, settings, objects, or atmosphere
must cite a specific manuscript scene and include a short quote (under
25 words). If the detail is not explicitly stated in the manuscript,
write **"NOT FOUND"** and use a compositional workaround (silhouette,
back-turned figure, symbolic representation, atmospheric suggestion).

- CORRECT: Hair color — "dark red, almost auburn" (Ch 3, "she pushed
  the auburn hair from her eyes")
- CORRECT: Hair color — **NOT FOUND** → use silhouette or obscured angle
- WRONG: Hair color — "dark blonde" (no manuscript evidence)

**Never invent, infer, or assume visual details not explicitly in the
text.** A cover with an accurate silhouette is better than a cover
with a hallucinated face. This rule applies to all downstream phases
(Visual Beat Map, Concept Generation, Image Prompts).

#### Character Visual Profile

For each character who may appear on the cover, extract these 8 fields
from the manuscript. Apply the Evidence Rule — every field must cite
text or state NOT FOUND:

| Field | Source |
|---|---|
| Hair color/style | Manuscript quote or NOT FOUND |
| Eye color | Manuscript quote or NOT FOUND |
| Skin tone | Manuscript quote or NOT FOUND |
| Distinguishing marks | Manuscript quote or NOT FOUND |
| Signature clothing | Manuscript quote or NOT FOUND |
| Weapon or prop | Manuscript quote or NOT FOUND |
| Physical build | Manuscript quote or NOT FOUND |
| Sensory detail (how they move, sound, smell) | Manuscript quote or NOT FOUND |

NOT FOUND fields generate entries in the per-concept Do Not Include
list (Phase 3) — if hair color is unknown, the prompt must not depict
a specific hair color. Use silhouette, back-turned, partial, or
atmospheric framing instead.

### Phase 2b: Visual Beat Map

Before generating concepts, produce a Visual Beat Map — a table of the
8-12 most visually potent moments in the manuscript. This is the Art
Director's shortlist: the scenes with the strongest cover imagery.

| Chapter | Scene Description | Setting | Lighting | Key Objects | Dominant Colors | Quote from Text |
|---|---|---|---|---|---|---|
| Ch 3 | confrontation at the harbour wall | harbour, night | moonlight through fog | iron chain, lantern | steel blue, amber, black | "the chain swung once and held" |

**Rules:**
- 8-12 rows. Fewer is fine for short stories; more for novels.
- Every row must have a Quote from Text (Evidence Rule applies).
- The Dominant Colors column creates the palette pool for concepts.
- Prioritise scenes with strong visual contrast, iconic objects, or
  emotional peaks — these make the best covers.

**Reusability:** The Visual Beat Map feeds into the Video Trailer
Designer, marketing materials, and A+ Content imagery. Save to the
cover concept output for downstream use.

### Phase 3: Concept Generation

The AI generates a complete cover concept with:

1. **Market Analysis** — Genre trends, competitor covers, positioning, patterns to avoid
2. **Visual Concept** — Detailed main image/scene description
3. **Composition** — Layout, focal points, visual hierarchy (accounting for spine)
4. **Color Palette** — 5 specific colors with hex codes and psychological rationale
5. **Typography** — Font recommendations for title, author, tagline, spine
6. **Title Treatment** — Text, position, style, color, effects, size
7. **Author Treatment** — Text, position, style, color, effects, size
8. **Tagline Treatment** — (if tagline provided)
9. **Mood & Atmosphere** — Emotional impact description
10. **Key Elements** — Specific visual elements to include
11. **Do Not Include** — 5-7 misleading visual elements this concept must
    exclude, with reasons. Sources: NOT FOUND fields from Character Visual
    Profiles (don't depict unspecified features), genre DON'Ts from the
    genre bank file, and anachronism/setting traps (e.g., "no snow — story
    is set in August", "no sword — character uses magic", "no Victorian
    lampposts — setting is 1960s"). These carry into the image prompts as
    negative-prompt items or explicit exclusion instructions.
12. **Spine Design** — Spine area treatment
13. **Back Cover Concept** — Back cover design description
14. **Front Cover Image Prompt** — Per-platform (Ideogram, Leonardo, Grok, Midjourney)
15. **Back Cover Image Prompt** — Per-platform, matching front cover aesthetic
16. **Wraparound Image Prompt** — Per-platform, full cover as single continuous image
17. **Alternative Ideas** — 2 brief alternative concept directions.
    Each alternative must use a DIFFERENT dominant color from the main
    concept and from each other. **No two concepts (main + alternatives)
    may share a dominant color.** This forces genuine visual
    differentiation — three blue-toned concepts is three variations of
    one idea, not three ideas. Draw from the Visual Beat Map's Dominant
    Colors column for evidence-backed palette options.
18. **Print Notes** — Production considerations

### Phase 4: Text Rendering Modes

**ALWAYS generate BOTH versions of every prompt.** The user needs both options
because AI text rendering is unreliable — even Ideogram sometimes garbles text.
The user should be able to try the text version first, and fall back to artwork-only
if the text doesn't render cleanly.

**Version 1: With Text**
- Prompts include instructions to render title, tagline (if any), AND author name
- **Ideogram and Grok Aurora:** Include the author name in the prompt. Both platforms
  handle text rendering well enough for names. Structure the author name as a
  separate, clearly marked line at the end of the prompt so the user can easily
  remove it if the rendering is poor:
  ```
  [... main prompt ...]
  Title text: "BOOK TITLE" in [font style] at [position]
  Author text: "AUTHOR NAME" in [font style] at [position]  ← remove this line if you prefer to add the author name manually
  ```
- **Leonardo.ai and Midjourney:** Do NOT include the author name — these platforms
  are unreliable for text rendering. The user should add the author name as a
  text overlay in Canva/Photoshop.
- Ideogram is recommended for the best text rendering overall
- Prompts specify exact text content in quotes, font style, position, colour
- Example: `with title text "THE SYNTHIATE" in bold sans-serif at top centre, and author text "LIAM CROFT" in lighter weight sans-serif at bottom centre`

**Version 2: Artwork Only (No Text)**
- Prompts explicitly exclude ALL text from the image
- Every platform prompt MUST include its platform-specific no-text directive:
  - Ideogram: `no text, no words, no letters, no typography`
  - Leonardo: `Negative prompt: text, letters, words, typography, writing`
  - Grok Aurora: `no text, no words, no letters, no writing, no typography`
  - Midjourney: `--no text, words, letters, typography`
- Composition leaves clean areas at top (for title) and bottom (for author)
  so the user can add text overlay in their image editor or Canva
- This is often the better option — clean artwork + professionally added text

**Present both versions to the user like this:**

```
FRONT COVER — GROK AURORA

Version A (with title text):
[full prompt with title text instructions]

Version B (artwork only — add text in Canva/editor):
[full prompt with no-text directives]
```

Repeat this dual-version format for all 4 platforms (Ideogram, Leonardo, Grok, Midjourney)
and for all prompt types (front cover, back cover, wraparound).

---

## Cover Refinement Mode (V2)

After the user generates an initial cover using the prompts from Phase 3-4,
they may want to refine it rather than start over. "Refine this cover" or
"Improve this cover" or "V2 this cover" triggers this mode.

**When to use:** The user has an existing cover image (generated or
uploaded) that's 70% right — good direction, needs polishing. Starting
over would lose what works; refining fixes what doesn't.

**Output:** A refinement prompt the user pastes into an image-editing
tool alongside the uploaded cover image.

**Supported platforms:**
- **Nano Banana 2** (Google) — upload image + paste refinement prompt
- **Midjourney img2img** — use `--iw` parameter with the refinement prompt
- **DALL-E edit mode** — upload image + edit instructions
- **Ideogram Reimagine** — upload image + refinement prompt

### Refinement Hierarchy (keep / refine / adjust / change)

The refinement prompt follows a strict hierarchy that preserves the
core design while improving execution:

**KEEP (never alter):**
- Title, subtitle, author name — exact text preserved
- General text hierarchy (title > tagline > author)
- Core focal subject (the main visual element)
- General layout direction (title-top / image-centre / etc.)
- Genre signalling
- Aspect ratio (match the original)

**REFINE (improve within the same style):**
- Typography — better font choices in the same genre register,
  stronger contrast, cleaner alignment, improved spacing/sizing
- Text legibility — especially at thumbnail scale

**ADJUST (rebalance for stronger impact):**
- Composition — rebalance element positions, improve margins,
  reorganise for stronger visual hierarchy
- Focal point emphasis — sharpen what draws the eye first

**CHANGE (upgrade while preserving mood):**
- Background — more cinematic, polished, detailed treatment of the
  same setting or symbolic motif
- Lighting — more dramatic, genre-appropriate, professional
- Color palette — enhanced contrast, depth, saturation, texture
- Overall finish — from "AI-generated" to "professional book cover"

### Trim Size Inheritance (resolve before producing the template)

The refinement prompt must lock the aspect ratio to the project's chosen
trim size so the refined image stays printable at the same dimensions as
the original cover.

1. **Read `project-config.md`** for `Cover Trim Size:`. If present, use it.
2. **Otherwise**, use the trim size the user declared in Cover Audit Mode
   this session (Minimum Context Intake — see above).
3. **If still unknown** (no project, no audit context), default to `6x9`
   and flag this in the message you send the user with the template.

Substitute `{TRIM}` and `{RATIO}` in the template using this map:

| Trim | Ratio |
|---|---|
| 6x9 | 2:3 |
| 5.25x8 | 21:32 |
| 4.25x6.87 | ~0.62:1 |
| 5x8 | 5:8 |
| 5.5x8.5 | 11:17 |
| 5.06x7.81 | ~13:20 |
| 7x10 | 7:10 |
| 8.5x11 | 17:22 |

For any trim not in this table, compute `width:height` and reduce to
lowest terms.

### Refinement Prompt Template

```
Transform this into a more striking, professional book cover while
keeping it as a recognisable variation of the same design.

KEEP: same title, subtitle, author name and text hierarchy. Same core
focal subject and general layout direction. Same genre.

REFINE: typography — better font choices in a similar genre register,
stronger contrast, cleaner alignment, improved spacing and sizing.

ADJUST: composition — rebalance where the title, subtitle, author name,
and main focal image sit on the page. Improve margins. Reorganise
elements for stronger visual hierarchy.

CHANGE: background and lighting — preserve the same mood and subject
matter but with a more cinematic, polished, detailed treatment. Enhance
color palette, contrast, depth, and texture for a refreshed, more
modern redesign of the same cover.

Do not change the wording of any text. Do not alter the genre. Keep
the aspect ratio of the original cover at {RATIO} (matching the {TRIM}
print specification). Portrait orientation.

{ADDITIONAL SPECIFIC NOTES — e.g., "the title text is garbled — re-render
it cleanly", "the figure's hand has too many fingers — fix anatomy",
"the sky is too saturated — pull it back to muted tones"}
```

**Present to the user as:** The template above, customised with any
specific issues the user flagged, with platform-specific instructions
for how to use it (upload steps for each platform).

---

## Canva Layer Breakdown (Post-Generation)

After the user generates a cover image using the prompts from Phase 3-4,
produce a **layered reconstruction spec** — a document that tells the
user exactly how to rebuild the cover in Canva (or Photoshop/Figma) as
editable layers. This bridges the gap between "I have an AI image" and
"I have a production-ready cover I can tweak without regenerating."

### When to produce

- After the user has approved a cover concept AND has a generated image
- Triggered by: "Layer breakdown", "Canva breakdown", "Make this
  editable", or any request to reconstruct the cover as layers
- Also produced automatically alongside Version B (artwork-only) prompts
  when the user has confirmed which concept they're taking forward

### Output structure

The Canva Layer Breakdown document contains:

**1. Canvas Setup**
- Dimensions (px at 300 DPI, matching the approved trim size)
- Background colour (hex, from the approved concept's palette)
- Bleed and safe-zone guides (if Canva Pro)

**2. Layer Stack (bottom to top, z-order)**

```
LAYER STACK — [Book Title]

Layer 1 (bottom):  ARTWORK BASE
  Source:          [Ideogram/Leonardo/Grok/Midjourney] output image
  Position:        Fill canvas, extend to bleed
  Blend mode:      Normal
  Opacity:         100%
  Notes:           This is the Version B (artwork-only) output

Layer 2:           ATMOSPHERE OVERLAY (optional)
  Type:            Gradient / vignette / texture
  Colour:          {hex} → transparent
  Direction:       Top-to-bottom / radial / edge
  Blend mode:      Multiply / Overlay / Soft Light
  Opacity:         {N}%
  Purpose:         Darken edges for text legibility

Layer 3:           TITLE TEXT
  Text:            "{EXACT TITLE}"
  Font:            {font name} (Google Fonts / Canva font)
  Size:            {N}pt at {DPI}
  Weight:          {Bold / Regular / Light}
  Colour:          {hex}
  Position:        x: {N}px from left, y: {N}px from top
  Letter spacing:  {N}% tracking
  Line height:     {N}px (if multi-line)
  Effects:         {shadow / glow / outline — specify if used}
  Alignment:       {centre / left / right}

Layer 4:           TAGLINE TEXT (if applicable)
  Text:            "{EXACT TAGLINE}"
  Font:            {font name}
  Size:            {N}pt
  Colour:          {hex}
  Position:        x: {N}px, y: {N}px
  Letter spacing:  {N}%

Layer 5:           AUTHOR NAME
  Text:            "{EXACT AUTHOR NAME}"
  Font:            {font name}
  Size:            {N}pt
  Weight:          {weight}
  Colour:          {hex}
  Position:        x: {N}px, y: {N}px
  Letter spacing:  {N}%

Layer 6 (top):     DECORATIVE ELEMENTS (optional)
  Type:            {border / frame / emblem / series badge}
  Source:           {Canva element / extracted from artwork / custom}
  Position:        {coordinates}
  Blend mode:      {mode}
  Opacity:         {N}%
```

**3. Font Stack & Fallbacks**
- Primary title font: {name} — {source: Google Fonts / Adobe / Canva built-in}
- If unavailable: {fallback 1}, {fallback 2}
- Author font: {name} — {source}
- If unavailable: {fallback 1}, {fallback 2}
- Tagline font (if different): {name}

**4. Colour Reference Card**

| Swatch | Name | Hex | RGB | Usage |
|---|---|---|---|---|
| ■ | {name} | #{hex} | {r,g,b} | {where it appears} |

Include the CMYK advisory: *"Canva Pro exports CMYK for print. Free
Canva exports RGB — some colours (especially saturated cyan, neon
green, vivid orange) shift in CMYK. If using free Canva, verify print
colours with a proof copy."*

**5. Thumbnail Verification**
- Shrink the export to 120px wide
- Check: title still readable? One dominant shape still hits? If not,
  increase title size or contrast on the atmosphere overlay layer.

**6. Seed/Prompt Pin**
- Record the exact prompt + seed/generation ID used for the approved
  artwork so the back cover, spine, and wraparound can match the
  treatment. Platform-specific:
  - Ideogram: save the generation URL + seed number
  - Midjourney: save the `/imagine` prompt + `--seed` value
  - Leonardo: save the generation ID from the history
  - Grok: save the prompt text (no seed control)

### Why this exists

The gap this fills: a user generates a beautiful cover in Ideogram,
but the title text is slightly garbled (common), or they want to
change the author name (pen name decision), or they need to adjust
the tagline. Without a layer breakdown, their only option is to
regenerate and hope. With the breakdown, they open Canva, place the
artwork-only version as the base layer, and add text layers exactly
as specified — font, size, position, tracking, colour all pre-
calculated. Tweaking without regenerating.

---

## Genre Cover Aesthetics — How Genre Files Contribute

Each genre file in the genre bank includes a `## Cover Design Specifications` section with:

```markdown
## Cover Design Specifications

### Recommended Visual Styles
Which 3-4 of the 8 universal styles work best for this genre,
with notes on when to use each.

### Genre Cover Aesthetics
- **Styles:** 4-5 visual/design approaches characteristic of this genre
- **Colours:** 4-5 colour recommendations with genre psychology
- **Elements:** 4-5 visual motifs that signal this genre to readers
- **Typography:** Font style guidance specific to this genre

### Subgenre Variations (if applicable)
Different cover aesthetics for subgenres
(e.g., psychological thriller vs action thriller)

### Market Positioning
How covers in this genre should position on retail platforms.
What visual language signals the genre correctly.

### Cover Design DON'Ts
Genre-specific visual elements to AVOID
(elements that confuse genre signalling or alienate the target reader)
```

**Integration point:** The prompt pipeline injects genre aesthetics into the AI prompt at the "Design Requirements" section:
```
Genre Conventions: [styles from genre file]
Typical Genre Colours: [colours from genre file]
Common Genre Elements: [elements from genre file]
```

---

## Universal Quality Criteria

Every cover concept is evaluated against:

### Thumbnail Test
- Does the cover read at Amazon thumbnail size (~160×256 pixels)?
- Is the title legible at thumbnail scale?
- Does the genre register instantly?
- Does it stand out against competitors in a grid view?

### Genre Signal Accuracy
- Would a reader browsing this genre section recognise this as belonging?
- Does the cover use the visual language of the genre without being derivative?
- Is the colour palette genre-appropriate?

### Composition Rules
- **Rule of thirds** — focal point at intersection points
- **Visual hierarchy** — eye moves: title → image → author name
- **Breathing room** — not overcrowded; negative space is intentional
- **Spine integration** — wraparound designs flow naturally across the spine
- **Back cover utility** — space for blurb text (upper 60%), ISBN barcode (bottom right), publisher info (bottom centre)

### Print Production
- All critical elements within safe zone (0.25" from trim)
- Artwork extends to bleed (0.125" beyond trim)
- Spine text readable at calculated spine width (flag if spine < 0.3" — text may not fit)
- Colour mode appropriate for print (CMYK considerations noted)
- Resolution sufficient (300 DPI minimum for print)

### Market Competitiveness
- Researched against current bestseller covers in the genre
- Avoids dated trends identified in market analysis
- Positions the book to compete, not just to look attractive in isolation

### Concept Differentiation
- No two concepts (main + alternatives) share a dominant color
- Each concept targets a different reader psychology (e.g., mood-buyer
  vs plot-buyer vs character-buyer)
- Alternative concepts are genuinely different directions, not palette
  swaps of the main concept

### Concept Scoring

Score each concept on 5 weighted criteria. Present the score alongside
the concept so the user has a clear quality signal.

| Criterion | Weight | What it measures |
|---|---|---|
| Genre Clarity | 30% | Would a genre reader instantly recognise this as their genre? |
| Visual Potency | 25% | Does the image arrest attention at thumbnail scale? |
| Trope Strength | 20% | Does the cover signal the book's tropes to the target reader? |
| Market Hook | 15% | Does it compete with current bestseller covers in this genre? |
| Distinctiveness | 10% | Does it stand apart from the genre's visual clichés? |

**Rating scale:**
- ≤3: Unmarketable — fundamental genre or visual mismatch
- 4-6: Needs Work — recognisable but not competitive
- 7-8: Solid Genre Fit — would sell on a shelf
- ≥9: Bestseller Potential — arresting, distinctive, genre-perfect

**Scoring output per concept:**
```
CONCEPT SCORE: {weighted total}/10
  Genre Clarity:   {N}/10 (×0.30 = {weighted})
  Visual Potency:  {N}/10 (×0.25 = {weighted})
  Trope Strength:  {N}/10 (×0.20 = {weighted})
  Market Hook:     {N}/10 (×0.15 = {weighted})
  Distinctiveness: {N}/10 (×0.10 = {weighted})
  Rating: {label}
  Recommendation: {one sentence — what would improve the weakest criterion}
```

---

## Output Schema

```json
{
  "conceptName": "string — Creative name for the concept",
  "marketAnalysis": {
    "genreTrends": "string — Current bestseller visual trends",
    "competitorCovers": ["string — Title + why it works (3-5 entries)"],
    "marketPosition": "string — How this design competes",
    "avoidPatterns": ["string — Dated/overused trends to avoid"]
  },
  "visualConcept": "string — Detailed main visual description",
  "composition": "string — Layout and visual hierarchy",
  "colorPalette": [
    { "name": "string", "hex": "#XXXXXX", "usage": "string — Where and why" }
  ],
  "typography": {
    "titleFont": "string — Font recommendation with style notes",
    "authorFont": "string — Font for author name",
    "taglineFont": "string — Optional tagline font",
    "spineFont": "string — Font for spine text"
  },
  "titleTreatment": {
    "text": "string", "position": "string", "style": "string",
    "color": "string", "effects": "string", "size": "string"
  },
  "authorTreatment": {
    "text": "string", "position": "string", "style": "string",
    "color": "string", "effects": "string", "size": "string"
  },
  "taglineTreatment": {
    "text": "string", "position": "string", "style": "string",
    "color": "string", "effects": "string", "size": "string"
  },
  "mood": "string — Emotional atmosphere",
  "keyElements": ["string — Visual elements to include"],
  "spineDesign": "string — Spine area treatment",
  "backCoverConcept": "string — Back cover design",
  "imagePrompt": {
    "ideogram": "string", "leonardo": "string",
    "grok": "string", "midjourney": "string"
  },
  "backCoverImagePrompt": {
    "ideogram": "string", "leonardo": "string",
    "grok": "string", "midjourney": "string"
  },
  "wraparoundImagePrompt": {
    "ideogram": "string", "leonardo": "string",
    "grok": "string", "midjourney": "string"
  },
  "doNotInclude": [
    { "element": "string — Visual element to exclude", "reason": "string — Why it's wrong for this book" }
  ],
  "score": {
    "genreClarity": "number (1-10)", "visualPotency": "number (1-10)",
    "tropeStrength": "number (1-10)", "marketHook": "number (1-10)",
    "distinctiveness": "number (1-10)", "weightedTotal": "number (1-10)",
    "rating": "string — Unmarketable | Needs Work | Solid Genre Fit | Bestseller Potential",
    "recommendation": "string — One sentence on what would improve the weakest criterion"
  },
  "alternativeIdeas": ["string — Brief alternative concept directions (each with different dominant color)"],
  "printNotes": "string — Production considerations"
}
```

---

## Platform Variant Guide

Once the user approves the main cover concept and has their hero image (the final
front cover with text baked in from their AI image generator), present this
variant guide. The hero image is the single source of truth — all variants
derive from it.

### Master Files Needed

From one approved cover, the user needs **13 variant categories**. Most are
simple resizes; a few need recomposition (image repositioned + text re-placed).

### Tier 1: Direct Resize (Same or Similar Aspect Ratio)

These platforms accept the hero image resized directly. No recomposition needed.

| Variant | Dimensions | Format | Used For |
|---------|-----------|--------|----------|
| eBook Master | 2,560 × 1,600 px | JPEG, RGB | Amazon KDP eBook |
| Apple Books | 1,600 × 2,560 px | PNG, RGB | Apple Books (same file as eBook) |
| Barnes & Noble | 2,500 × 1,600 px | JPEG, RGB | Nook (same file as eBook) |
| Kobo | 2,560 × 1,600 px | JPEG, RGB | Kobo (same file as eBook) |
| Google Play | 2,560 × 1,600 px | JPEG, RGB | Google Play Books (same file as eBook) |
| Draft2Digital | 2,560 × 1,600 px | JPEG, RGB | D2D / Smashwords (same file as eBook) |
| Goodreads | 1,000 × 1,500 px | JPEG, RGB | Goodreads listing |
| BookBub Deal | 860 × 1,300 px | JPEG, RGB | BookBub Featured Deal |
| Pinterest | 1,000 × 1,500 px | JPEG, RGB | Pinterest pin (same as Goodreads) |

**Canva instructions for Tier 1:**
1. Open Canva → Create a design → Custom size → enter dimensions
2. Upload the hero image
3. Place it to fill the canvas (drag corners to fit)
4. Download as JPEG (or PNG for Apple Books)

**Result: 1 hero image serves 9 platforms.** The eBook master file (2,560 × 1,600)
works for KDP, Apple, B&N, Kobo, Google Play, and D2D without any changes.
Goodreads and Pinterest share the same 1,000 × 1,500 resize.

### Tier 2: Recomposition Required (Different Aspect Ratio)

These variants have a significantly different aspect ratio from the standard
book cover. The hero image needs to be cropped or repositioned, and text should
be re-placed as a separate Canva text layer for optimal positioning.

| Variant | Dimensions | Aspect Ratio | Used For |
|---------|-----------|-------------|----------|
| Audiobook (ACX/Audible) | 2,400 × 2,400 px | 1:1 square | Audible listing |
| Instagram Square | 1,080 × 1,080 px | 1:1 square | Instagram / Facebook / Twitter |
| Instagram Portrait | 1,080 × 1,350 px | 4:5 | Instagram feed |
| Instagram Story | 1,080 × 1,920 px | 9:16 | Instagram Stories / Reels |
| Facebook Landscape | 1,200 × 628 px | ~1.91:1 | Facebook ads |
| Twitter/X Landscape | 1,200 × 675 px | 16:9 | Twitter/X posts |
| BookBub Ad | 300 × 250 px | 6:5 | BookBub self-serve ads |

**Canva instructions for Tier 2 — Recomposition:**

**Step 1: Set up the canvas**
1. Canva → Create a design → Custom size → enter variant dimensions
2. Set the background to the dominant colour from the cover's colour palette
   (use the hex code from the Cover Designer output above)

**Step 2: Place the hero image**
3. Upload the hero image
4. Position it within the canvas using these composition rules:

| Variant | Image Placement |
|---------|----------------|
| Audiobook square | Centre the key visual. Crop equally from top and bottom (or left and right, depending on cover composition). The title must remain fully visible. |
| Instagram square | Same as audiobook but at 1,080 px. If the full cover doesn't fit, show the top 60% (title + key visual). |
| Instagram portrait | The full cover usually fits well at 4:5. Slight crop from top/bottom. |
| Instagram story | Place the cover image in the centre of the tall canvas. Fill the top and bottom with the background colour or a subtle gradient. |
| Facebook landscape | Place the cover image on the right third. Use the left two-thirds for a text callout (tagline, "Available Now", review quote). |
| Twitter landscape | Same approach as Facebook landscape. |
| BookBub ad | Small format — use just the cover image scaled to fit, or the key visual element with a bold title overlay. |

**Step 3: Re-place the text**
5. If the title/author text was cropped or is poorly positioned after resizing:
   - Add a new text layer in Canva
   - Use the exact font, size, colour, and effects from the Typography section
     of the Cover Designer output above
   - Position the text for this specific format's composition

**Step 4: Export**
6. Download as JPEG (social media) or PNG (where transparency may be useful)

### Tier 3: Print Covers (Full Wraparound)

Print covers require the front, spine, and back as a single wraparound PDF.
These cannot be created from the hero image alone — they need additional
design work for the spine and back cover.

| Variant | Specs | Used For |
|---------|-------|----------|
| KDP Paperback | CMYK PDF, 300 DPI, 0.125" bleed | Amazon print |
| IngramSpark | PDF/X-1a CMYK, 300 DPI, 0.125" bleed | Wide print distribution |
| KDP Hardcover | CMYK PDF, 300 DPI, + case wrap allowance | Amazon hardcover |

**Spine width formula:** Page Count × Paper Thickness (per inch)
- White standard paper: Page Count × 0.00225"
- Cream standard paper: Page Count × 0.0025"

**Full cover width:** (Trim Width × 2) + Spine Width + (Bleed × 2)
**Full cover height:** Trim Height + (Bleed × 2)

**Canva instructions for print wraps:**
1. Use KDP's Cover Calculator (kdp.amazon.com) or IngramSpark's Cover Template
   Generator to get exact dimensions for your page count and trim size
2. Download their template (PDF with guides showing spine, bleed, safe zones)
3. In Canva: Create a design at the exact pixel dimensions (width × height × 300 DPI)
4. Place the template as a background layer (for guides)
5. Position the hero image on the front cover area
6. Design the spine: Title + Author Name, vertically, using the spine font from
   the Typography section above
7. Design the back cover using the back cover concept from the Cover Designer
   output above
8. Leave the barcode area clear (lower-right of back cover, 2" × 1.2")
9. Export as PDF Print (Canva Pro) or high-quality PDF
10. For IngramSpark: ensure CMYK colour space — Canva Pro supports this;
    free Canva exports RGB which IngramSpark may reject

**Important:** KDP and IngramSpark calculate spine width differently. Always use
each platform's own calculator. Do NOT use the same wraparound PDF for both.

### Tier 4: Amazon A+ Content (Enhanced Brand Content)

A+ Content uses supplementary marketing images, not the cover itself. These are
optional but significantly increase conversion on the Amazon listing page.

| Module | Dimensions | Description |
|--------|-----------|-------------|
| Banner header | 970 × 300 px | Wide banner — use cover art as background with tagline overlay |
| Standard image | 970 × 600 px | Feature image — cover detail or atmospheric scene |
| Comparison chart | 150 × 300 px per cell | Small cells — use for series book covers side by side |

**Canva instructions:**
1. Create designs at exact pixel dimensions (Amazon rejects non-matching sizes)
2. Use elements from the hero image (cropped details, colour palette) rather than
   the full cover — A+ Content should complement, not duplicate
3. Export as JPEG, under 2 MB per image

### Platform Upload Checklist

Once all variants are created, use this checklist to upload to each platform:

```
UPLOAD CHECKLIST — {Book Title}

☐ Amazon KDP eBook     → 2,560 × 1,600 JPEG (Tier 1)
☐ Amazon KDP Paperback → Wraparound PDF from KDP calculator (Tier 3)
☐ Amazon KDP Hardcover → Wraparound PDF from KDP calculator (Tier 3)
☐ ACX / Audible        → 2,400 × 2,400 JPEG square (Tier 2)
☐ IngramSpark          → Wraparound PDF/X-1a from Ingram template (Tier 3)
☐ Apple Books           → Same as eBook master (Tier 1)
☐ Barnes & Noble        → Same as eBook master (Tier 1)
☐ Kobo                  → Same as eBook master (Tier 1)
☐ Google Play           → Same as eBook master (Tier 1)
☐ Draft2Digital         → Same as eBook master (Tier 1)
☐ Goodreads             → 1,000 × 1,500 JPEG (Tier 1)
☐ BookBub Featured Deal → Uses retailer cover automatically
☐ BookBub Ads           → 300 × 250 JPEG (Tier 2)
☐ Amazon A+ Content     → Per-module sizes (Tier 4)
☐ Instagram Square      → 1,080 × 1,080 (Tier 2)
☐ Instagram Portrait    → 1,080 × 1,350 (Tier 2)
☐ Instagram Story       → 1,080 × 1,920 (Tier 2)
☐ Facebook Ad           → 1,200 × 628 (Tier 2)
☐ Twitter/X             → 1,200 × 675 (Tier 2)
☐ Pinterest             → 1,000 × 1,500 (Tier 1 — same as Goodreads)
```

### When to Present This Guide

Present the Platform Variant Guide automatically when:
- The user approves the final cover concept ("I'm happy with this", "approved",
  "let's go with this one")
- The user asks about sizes, formats, or platform requirements
- The user says "prepare for publishing" or "what do I need for upload"

Do NOT present it during the initial concept phase — wait until the cover
design is finalised.

---

## Relationship to Other Engine Files

| Engine File | Relationship |
|-------------|-------------|
| `publishing-formats.md` | Cover concepts feed into KDP metadata (cover description, visual branding) |
| `core-pipeline.md` | Cover generation happens AFTER manuscript is complete or near-complete |
| `world-canon.md` | Story Bible provides visual context (settings, characters, atmosphere) |

The Cover Designer is a **post-manuscript tool** — it consumes the Story Bible and manuscript data to create visually accurate cover concepts that represent the finished work.
