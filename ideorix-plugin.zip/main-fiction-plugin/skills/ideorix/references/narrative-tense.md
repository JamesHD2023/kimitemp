---
name: narrative-tense
description: "Narrative tense as a deliberate, contracted canon choice (not a binary past/present flag). Defines five modes — Present, Past-Immediate, Past-Literary-Immediate, Past-Retrospective, Future-Experimental — and the tense CONTRACT each carries (immediate = no foreshadowing/hindsight; retrospective = both permitted). Chosen at outline time like POV, stored in the Story Bible, and enforced WARN-level by tense-contract-scan.sh under the CONSISTENCY domain. Fiction-novel only."
version: "2.7.125"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Narrative Tense (the contracted choice)

Tense is the sibling axis to POV, and the engine has treated it as an
afterthought — a single `past | present` flag. But the choice carries a
**contract** that governs what the prose may do, and the most consequential
distinction is invisible in a binary flag: **immediate vs retrospective**
past. This spec makes tense a deliberate choice (like POV), stores its
contract as canon, and gives the verification net something to check.

Fiction-novel only. Screenplays are present-tense by format (N/A); narrative
non-fiction could use the retrospective mode later but is out of scope here.

## The five modes

| Mode | Verbs | Narrator position | Contract |
|------|-------|-------------------|----------|
| **Present** | She walks. | Locked in the now | **Immediate** — no foreshadowing, no hindsight, no retrospective commentary |
| **Past — Immediate** (deep-POV genre standard) | She walked. | Character lives it now; past tense is invisible | **Immediate** — no "if she'd only known," no narrator looking back |
| **Past — Literary Immediate** | She walked. | Same as above, voice prioritises craft | **Immediate** — same contract, literary register |
| **Past — Retrospective** (classic) | She walked. | Narrator looks back, knows the ending | **Retrospective** — hindsight, foreshadowing, time-compression PERMITTED (used sparingly) |
| **Future — Experimental** | She will walk. | Events as predetermined | **Brief-passage only** — never a full book; strips agency |

**The load-bearing line:** in an **immediate** contract, *"if she'd only
known," "little did he know," "years later she would learn"* are **contract
violations**. In a **retrospective** contract, they are legitimate craft.
The same sentence is right or wrong depending only on the declared mode —
which is exactly why the mode must be canon, not guessed per chapter.

## Genre fit (guidance, not a gate)

- **Present** — YA contemporary/fantasy, dark/new-adult romance, atmospheric
  horror, growing in thriller. Disliked by many traditional-genre readers;
  fatigues past ~40k words; best for tight timelines.
- **Past — Immediate** — the commercial default: contemporary romance (dual
  POV), romantic suspense, urban/paranormal, modern thriller/mystery,
  women's fiction. The safe default for most genres.
- **Past — Literary Immediate** — literary / upmarket / literary-mystery /
  literary-historical.
- **Past — Retrospective** — epic fantasy (bardic look-back), traditional
  historical, detective recounting a case, coming-of-age, memoir-style.
- **Future** — experimental literary / magical realism / precognition
  premises, and brief passages in any genre (a prophecy, a vision).

## Choosing it (at outline time, like POV)

`outline-builder.md` offers tense alongside POV, **defaulting to the genre's
norm** (Past-Immediate for most commercial genres) and confirming with the
writer. The chosen mode + contract is written to the Story Bible
(`world-canon.md` §3):

```
- Narrative tense: {present | past-immediate | past-literary | past-retrospective | future}
- Tense contract: {immediate | retrospective}    (future = brief-passage only)
```

The Architect briefs to it; the Writer grounds on it; the audit reads it.

## Enforcement (conservative by design)

`scripts/tense-contract-scan.sh` (CONSISTENCY domain, per chapter) reads the
project's declared contract and, **only when the contract is `immediate`**,
scans chapter **narration** for distinctive retrospective / foreshadowing
**marker phrases** ("if she'd only known," "little did he know," "years
later he would…", "what she didn't know then…"). These are deliberately
**high-confidence, low-false-positive** phrasings.

Design discipline (the lesson `show-not-tell-tells.md` learned):

- **Marker-based, not a full base-tense statistical scan.** The heavy
  "classify every sentence's tense" check is FP-prone (dialogue is present
  inside past narration; flashbacks and italic thought legitimately shift)
  and is **deliberately deferred** until the marker check proves
  insufficient.
- **WARN, never FAIL** (exit 3) — it surfaces in the `/validate` briefing as
  a signal for the writer to judge, and never blocks phase advancement.
- **Retrospective / future contracts:** the markers are *legitimate* — the
  audit passes without scanning.
- **No declared tense:** SKIP (exit 2), never a silent PASS.

## Silent-Failure Audit

This feature uses the following primitives. For each, the success-claim,
divergence failure mode, and verification binding are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| LLM (tense choice) | "Tense selected" | A mode picked that fights the genre, or the contract mislabelled (immediate tagged retrospective) | Genre-fit guidance above; the choice is confirmed with the writer at outline time and written explicitly as `Narrative tense` + `Tense contract` |
| Write (Story Bible §3) | "Tense recorded" | Partial/truncated write loses the tense field | File-Write Hygiene (`core-pipeline.md`); re-read §3 and confirm both `Narrative tense` and `Tense contract` lines are present |
| Read (chapter narration) | "Scanned the chapter" | Empty/failed read → "clean" on zero content | `read-verification.md`: the scan operates on the chapter file the dispatcher passes; an unreadable/empty chapter yields no verdict, not a false PASS |
| Bash audit (tense-contract-scan) | "Tense is consistent" | Can't read the contract → silent PASS; or markers missed | `bash-output-verification.md`: the script states the contract it read and the chapter it scanned; no readable contract → SKIP (exit 2), never PASS; markers → WARN (exit 3), never silently swallowed |

## See also

- `world-canon.md` §3 — where the tense mode + contract is stored
- `outline-builder.md` — the deliberate tense choice (alongside POV)
- `canon-validation-taxonomy.md` — CONSISTENCY domain (tense-consistency)
- `scripts/tense-contract-scan.sh` — the WARN-level marker audit
