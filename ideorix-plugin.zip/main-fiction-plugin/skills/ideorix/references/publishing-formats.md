---
name: publishing-formats
description: "KDP metadata and export format templates"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# KDP Metadata & Export Formats Template

## File Location Discipline (MANDATORY)

**Output files:**
- KDP metadata document → `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-kdp-metadata.{ext}`
  (typically `.json` or `.txt` depending on the metadata
  profile — categories, keywords, BISAC codes, A+ Content
  blocks)
- Per-platform metadata variants (if produced) → same
  `manuscript/` folder with platform suffix
  (`{Title}-kdp-metadata.json`, `{Title}-apple-metadata.json`, etc.)

These outputs MUST be written to the canonical project's
`manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## KDP Metadata Gate (MANDATORY — v2.7.68+)

Before the project is declared KDP-ready or launch-ready, the
gate verifies the KDP metadata file exists at the spec-mandated
path and contains the fields KDP submission requires:

```bash
bash scripts/kdp-metadata-gate.sh "{project-root}"
```

The gate verifies:
- `manuscript/*-kdp-metadata.{json,txt,md}` exists, >= 500 bytes
- Contains: title, description, keywords, BISAC, comp_titles, pricing
- If JSON: keywords array has at least 7 entries (KDP requires 7)

If the gate fails, the project is NOT submission-ready — complete
the missing fields in the metadata file BEFORE attempting KDP
upload. Half-finished metadata uploaded to KDP wastes the
submission cycle.

Opt-outs: `kdp_status: legacy / skip` in
`engine-data/project-config.md`.

## KDP Info Document Structure

Generate a companion .docx containing everything needed for Amazon KDP publishing.

### Required Sections

**1. Book Information**
- Title
- Subtitle (optional)
- Series name and position (if applicable)
- Author name
- Publication date (leave as "TBD" unless specified)

**2. Amazon Book Description**
- Maximum 4,000 characters
- HTML formatting allowed: `<b>`, `<i>`, `<br>`, `<h2>`
- Structure: Hook paragraph → 2-3 premise paragraphs → Final hook/call-to-action
- Include genre keywords naturally
- End with: "Perfect for fans of [comp title 1] and [comp title 2]"

**3. Amazon Keyword Phrases (7 required)**
- 2 broad genre keywords (e.g., "cozy mystery series", "amateur sleuth mystery")
- 2 trope/theme keywords (e.g., "small town mystery", "baking mystery")
- 2 specific niche keywords (e.g., "female protagonist mystery 2024", "cat cozy mystery")
- 1 comp-based keyword (e.g., "books like [popular title]")

**4. BISAC Categories (3 suggestions)**
- Primary category (most specific match)
- Secondary category (broader reach)
- Tertiary category (cross-genre if applicable)

**5. Pricing Suggestion**
- Novella (under 30K): $0.99-$2.99
- Standard novel (30-60K): $2.99-$4.99
- Epic novel (60K+): $3.99-$5.99
- Note: $2.99-$9.99 qualifies for 70% royalty

**6. Comparable Titles (3-5)**
- Published within last 3 years
- Same genre and subgenre
- Similar tone and target audience
- Include author name and why it's comparable

**7. Target Audience**
- Age range
- Gender lean (if applicable)
- Reading preferences
- What they're looking for in this genre

**8. Cover Image Prompt**
- Style: Illustrated cozy / Photographic dramatic / Painterly fantasy (genre-appropriate)
- Specific elements to include (from the story)
- Mood and color palette
- Text placement guidance (title, author name)
- Aspect ratio: 1600 x 2560 pixels (Amazon KDP standard)
- For full cover concepts with print specs and multi-platform AI image prompts
  (Ideogram, Leonardo.ai, Grok Aurora, Midjourney), see `cover-designer.md`

---

## Export Formats

The manuscript engine supports multiple output formats. Ask the user which
formats they'd like during the delivery phase.

### Format Options

**1. DOCX (Default — Always Generated)**
- Publisher-ready formatting (see format-docx.md)
- Compatible with: Word, Google Docs, LibreOffice, Atticus
- Best for: Editing, submission to agents/publishers

**2. Atticus-Compatible DOCX**
- Modified DOCX structure optimised for Atticus import
- Chapter headings use Heading 1 style (not custom formatting)
- Scene breaks use `* * *` (Atticus auto-detects)
- No headers/footers (Atticus handles these)
- Best for: Authors using Atticus for final formatting

**3. EPUB — Universal Standard (EPUB 3.3/3.2)**
- The most widely supported vendor-independent e-book format
- Reflowable text that adapts to different screen sizes and orientations
- Required standard for nearly all major retailers
- Chapter-based navigation (Table of Contents)
- Embedded metadata (title, author, description, language)
- Best for: Wide distribution, direct upload to retailers, reading on e-readers

**4. PDF**
- Print-ready PDF with proper pagination
- Title page, chapter breaks, page numbers
- Trim size options: 5x8", 5.5x8.5", 6x9" (common KDP trim sizes)
- Best for: Print review, proof copies

**5. Markdown**
- Clean markdown with chapter headings (## Chapter N: Title)
- Scene breaks as `---`
- Preserves all formatting as markdown syntax
- Best for: Version control, plain text editing, conversion

**6. Plain Text (RTF)**
- Rich Text Format for maximum compatibility
- Basic formatting preserved (bold, italic, headings)
- Best for: Submission to outlets that require RTF

**7. SMF (Standard Manuscript Format)**
- Double-spaced, Courier 12pt
- Header: Author Name / Title / Page Number
- ~250 words per page
- Industry standard for agent/publisher submission
- Best for: Traditional publishing submission

**8. Fountain (.fountain) — Screenplay Format**
- Industry-standard plain-text screenplay markup
- Compatible with Final Draft, Highland, Fade In, WriterSolo, Arc Studio Pro
- Courier 12pt, industry margins, proper scene headings and dialogue formatting
- One page = approximately one minute of screen time
- Best for: Screenplay output, adaptation from manuscript, import into professional screenplay software

### Format Selection

During PHASE 6 (Delivery), ask:

```
Which export formats would you like?
- DOCX (Recommended — always included)
- Atticus DOCX (optimised for Atticus formatting software)
- EPUB (for e-readers and retailers)
- PDF (for print review)
- Markdown (for plain text editing)
- SMF (Standard Manuscript Format for agent submission)
- Fountain (screenplay format — for screenplay projects)
```

Allow multiple selections. DOCX is always generated regardless.

### Chapter Heading Format Options

Ask the user for their preferred chapter heading style:
- **"Chapter 1: The Discovery"** (Number + Title)
- **"Chapter 1"** (Number only)
- **"The Discovery"** (Title only)
- **"1"** (Number only, minimal)
- **"ONE: The Discovery"** (Written number + Title)

Apply consistently across all export formats.
