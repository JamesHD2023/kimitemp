---
name: character-depth
description: "Character Depth Layer — the main-cast depth schema added at Story-Bible time: the Hidden Life (specific pre-page-one wound, believes-X/under-pressure-does-Y contradiction, off-plot want, unspoken fear, primal loss), the Observable Presence (a per-character Physical Tell Register of distinct, mutually-distinct tells across five emotional registers, plus a Page-One Visual), an observable Final-Page State, and a Relationship Dynamic for co-leads. Role-scaled (full / medium / lean). Generated once; enforced by the tell-distinctness audit and the bible-coverage completeness check. Applies to novels and screenplays."
version: "2.7.124"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Character Depth Layer

A binding/protocol spec authored at **Story-Bible time** (novel:
`world-canon.md` Phase 2A §4b; screenplay: the screenplay character
build — see "Screenplays" below). It deepens the **main cast** beyond
the existing profile fields with concrete, observable, *groundable*
canon — and crucially, canon the verification net can enforce.

## Why this exists

Ideorix already builds strong character profiles (`outline-builder.md`
Steps 5-7, `world-canon.md` §4 fields + Personality Sliders, §3 POV
Voice Profiles, §11 Arcs). What it lacked was a small set of
**observable** depth fields that (a) make a character feel like a person
with a life independent of the plot, and (b) give the prose stage and the
audits concrete canon to honour and check. This layer adds exactly those
fields — no more — and is deliberately **deduped** against what already
exists (it never re-asks for voice/perception already captured in §3, or
the temperament already captured by the sliders).

The keystone is the **Physical Tell Register**: today
`show-not-tell-tells.md` audits *repeated* tells reactively and explicitly
defers cross-character and emotion-mapping detection. By defining each
main-cast character's distinct tells **as canon**, this layer supplies the
canon that `scripts/character-tell-distinctness.sh` checks — closing that
deferred "Class B" gap.

## Cast scoping (role-scaled — depth where it pays, not everywhere)

Depth costs tokens, so it is generated **once at Story-Bible time** (never
per chapter) and scaled by role:

- **Full layer** — protagonist(s) / co-leads, every POV character, and the
  primary antagonist. All sections below.
- **Medium layer** — major supporting (recurring, arc-bearing, or
  appearing in ≥3 chapters): Physical Tell Register + Core Contradiction +
  a one-line wound (the Unprocessed Event in a sentence) + Page-One Visual.
  Skip the remaining Hidden-Life sub-fields and the Relationship Dynamic
  unless they share a load-bearing relationship with a lead.
- **Lean (unchanged)** — minor characters keep the existing lean §4 profile.
  No depth layer.

Determine role from the outline/Story Bible (protagonist/antagonist/POV
flags, chapter count, arc presence). When unsure whether a character is
"major," default to **medium**.

## The schema

Written into the Story Bible as a per-character block under §4b. Dedup
rule: **do not duplicate** the §3 POV Voice Profile (vocabulary, sentence
architecture, perception filter, emotional *processing in narration*,
metaphor source) or the Personality Sliders. This layer is the
*observable / behavioural / relational* complement to those.

### A. The Hidden Life (interior reality — informs choices; need not all reach the page)

1. **The Unprocessed Event** — a *specific*, unresolved moment before page
   one, with its lingering residue. **No generic trauma categories** —
   name the exact moment ("the night the ferry left without her," not
   "childhood abandonment").
2. **Core Contradiction** — stated as *"She believes [X]. Under pressure,
   she does [Y]."* One sentence, behavioural, testable.
3. **Off-Plot Want** — what they wanted that has nothing to do with this
   story; the life they were building before it interrupted.
4. **Unspoken Fear** — a deep, specific fear they would never admit aloud.
5. **Primal Loss** — a concrete loss already suffered and still grieved.

(*"Private Self"* from the source schema is intentionally folded into the
existing §4 "personality — underneath" field; don't re-author it here.)

### B. The Observable Presence (physical reality — the page-facing canon)

6. **Physical Tell Register (MANDATORY for full + medium).** For each of
   **five emotional registers** — Fear, Anger, Grief, Desire, Resolve —
   one *specific, non-generic* observable physical tell. Constraints:
   - Tells must be concrete body-language, not labelled emotion
     ("the knuckle she presses to her teeth," not "looks afraid").
   - **Mutually distinct across the main cast**: no two main-cast
     characters may share a tell for the *same* register. (Across
     different registers, incidental overlap is acceptable.)
   - Avoid the lazy-default vocabulary `show-not-tell-tells.md` already
     polices (hands shook, jaw clenched, swallowed hard, eyes narrowed…).

   **Canonical format (so the audit can parse it — author it exactly so):**
   ```
   #### Physical Tell Register — {Character Name}
   - Fear: {specific observable tell}
   - Anger: {specific observable tell}
   - Grief: {specific observable tell}
   - Desire: {specific observable tell}
   - Resolve: {specific observable tell}
   ```
   This block is the canon `scripts/character-tell-distinctness.sh` reads;
   the five register labels and the `- Register: tell` line shape are fixed.
7. **Page-One Visual** — the snapshot as the character first appears:
   *build & physicality* (height/build/traits earned by their history),
   *face* (shape, eye colour, mouth, skin tone + undertone), *hair*
   (colour, texture, current style), *hands* (texture, scars, state),
   *clothing* (what the opening outfit reveals about their immediate
   past), *scars & marks* (with their specific physical causes). Tie at
   least one detail to the world (see Integration).

### C. The Arc (behavioural transformation)

8. **Observable Final-Page State** — what they *look like and do* on the
   final page, in observable behavioural terms. **No abstract theme
   statements** ("she finally forgives herself" is banned; "she leaves the
   porch light off and sleeps through the night" is the form). Extends the
   §11 arc endpoint; the rest of §11 (catalyst, midpoint, climax) stands.

### D. Relationship Dynamic (co-leads / duals / central romance only)

9. **Mutual Misreading** — how each lead initially misreads the other,
   rooted in their respective histories.
10. **Mutual Offering** — the specific psychological or practical thing
    each offers that the other desperately lacks.
11. **Internal Incompatibility** — the friction (fears, contradictions)
    that makes the bond hard or impossible without transformation.
12. **Arc Intersection** — how their transformations depend on and force
    change in each other.
13. **Subtext Pattern** — what they consistently *say* instead of what they
    *mean*, and the body-language pattern that betrays the real meaning.
14. **Relational Physical Anchor** — a concrete, observable proximity
    detail (a specific distance, a physical reaction to the other's
    presence) the prose can leverage to show the relationship's state
    without naming it.

## Quality gates (apply at generation; the bible-coverage audit checks them)

- **Independent Existence Test** — remove the main plot: does the character
  still read as a living person with their own history? If not, deepen the
  Hidden Life.
- **Depth Priority** — the Hidden Life must be materially more developed
  than the surface; a profile that is all Observable Presence and no
  interior fails.
- **No Clichés** — no default trauma, default looks, or stock concepts.
- **Integration (MANDATORY)** — weave `world-canon.md`'s physical and
  social rules into the body, scars, and beliefs, and align the arc with
  the project's emotional core. A depth layer disconnected from the world
  is a generic profile and must be regenerated.

## Screenplays (the observable fields carry *everything*)

Screenplays narrate nothing on the page, so characterisation lives entirely
in action lines, behaviour, and dialogue. The Hidden Life therefore stays
**off the page** but drives choices; the **Observable Presence** (Tell
Register, Page-One Visual), the **Core Contradiction**, the **Observable
Final-Page State**, and (for duals) the **Subtext Pattern** + **Relational
Physical Anchor** become the working canon the script must externalise.
`screenplay-deliverables.md` Checkpoint 6 is upgraded from the bare
Want/Need/Flaw/Backstory model to require these. For screenplay→novel
adaptation the layer is generated into the Story Bible and inherited
automatically (no separate authoring).

## Storage & flow

- **Novel:** written under `world-canon.md` Phase 2A as **§4b Character
  Depth Layer**, one block per main-cast character, inside
  `engine-data/story-bible.md`. The Page-One Visual and Tell Register are
  canon the Writer pre-loads; names already flow to
  `engine-data/entity-canon.md` (§2D) unchanged.
- **Screenplay:** the same block authored during the screenplay character
  build / Story Bible generation.
- Generated once; refreshed only on a deliberate bible edit.

## Enforcement

1. **Tell distinctness** — `scripts/character-tell-distinctness.sh` reads
   the §4b Tell Registers from the Story Bible and flags (a) two main-cast
   characters sharing a tell for the same register, and (b) a register slot
   left empty/stubbed. Class A mechanical audit under the CHARACTER domain
   (`canon-validation-taxonomy.md`), invoked by `/validate`.
2. **Completeness** — at Story-Bible review (and whenever
   `bible-coverage-audit.md` runs over the bible), verify each main-cast
   character's required depth fields **for its tier** are present, specific,
   and non-stubbed: no empty/placeholder Tell Register slot, no generic
   wound ("childhood trauma") in place of a *specific* Unprocessed Event, no
   final-page state written as an abstract theme statement. A profile that
   *claims* depth but has empty or generic fields is the failure this
   catches. (The mechanical tell half — empty slots + shared tells — is the
   distinctness audit above; this is the human-judged "is it specific?" pass.)

## Silent-Failure Audit

This feature uses the following primitives. For each, the success-claim,
divergence failure mode, and verification binding are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Subagent / LLM (depth generation) | "Depth layer written for the main cast" | Stubbed or hallucinated depth — generic trauma, empty Tell Register slots, theme-statement final state — presented as complete | `subagent-output-verification.md` evidence-bearing return contract; the **bible-coverage-audit.md** completeness check verifies fields are populated, specific, and non-stubbed; quality gates above are applied at generation |
| Write (Story Bible §4b) | "Story Bible updated" | Subdir flush / truncated write leaves the depth layer partial | File-Write Hygiene bash-direct write protocol (`core-pipeline.md`); re-read §4b after write and confirm the per-character blocks and a terminal marker are present |
| Read (source canon, BYO / adaptation) | "Read the source, built the layer" | Empty/failed read → layer invented from nothing | `read-verification.md` HARD GATE on every Read of user-supplied source before authoring the layer |
| Bash audit (tell distinctness) | "Tells are distinct / complete" | Script error or empty parse reported as PASS (no canon read) | `bash-output-verification.md`: the script states the character count and register count it actually parsed; zero-parse → error exit (2), never a silent PASS; `/validate` captures the log and surfaces PASS/FAIL |

## See also

- `world-canon.md` — §4b is authored there (Phase 2A); §11 final-page state
- `outline-builder.md` — Steps 5-7 seed the depth layer at outline time
- `screenplay-protocol.md`, `screenplay-deliverables.md` — screenplay build + Checkpoint 6
- `humanity-gate.md` — the Class B scorecard that *checks* characters for
  contradiction, independent existence, five emotional registers, private
  self, etc.; this layer **authors those same qualities as canon** so the
  gate scores something deliberately built, not hoped for
- `show-not-tell-tells.md` — the per-chapter prose tell audit; this layer
  supplies the canon its deferred cross-character "Class B" needed
- `bible-coverage-audit.md` — the import-time coverage audit this
  completeness check rides alongside
- `canon-validation-taxonomy.md`, `validate-dispatcher.md` — CHARACTER domain wiring
- `scripts/character-tell-distinctness.sh` — the canon-level distinctness audit
