# Chapter 1: Test Dirty

She felt the cold air on her skin — slowly — as she walked into
the room. She noticed the lamp was on. She heard the floorboards
creak underfoot. She realized someone had been here recently.

She was walking carefully now, was watching every shadow, was
listening for breath. Her heart pounded in her chest. Her breath
caught in her throat. Her eyes widened.

Very carefully, she really stepped forward. It was quite obvious
that someone had been here. It was really very strange.

[INSERT NEXT SCENE HERE]

TODO: figure out what she finds in the drawer.

The reader will see, in chapter one, that this is the beginning.
