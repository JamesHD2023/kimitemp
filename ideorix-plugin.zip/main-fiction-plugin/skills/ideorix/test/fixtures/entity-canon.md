# Entity Canon — Test Fixture

| Canonical | Aliases |
|---|---|
| Sarah Bellfield | Sarah |
| Marcus Bellfield | Marcus |
| The Pine House | Pine House |
| Briarmoor | Briar Moor, Briar-Moor |
