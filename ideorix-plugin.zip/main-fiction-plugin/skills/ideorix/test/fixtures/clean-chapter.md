# Chapter 1: The Departure

Sarah set the kettle on the stove and waited. Outside, rain
streaked the kitchen window in long uneven lines. The clock on
the mantel struck nine.

She poured the tea, sat at the table, and opened the letter she
had been carrying in her coat pocket for three days. The
handwriting on the envelope was her brother's. She knew it
before she broke the seal.

Marcus had written from the coast. He asked her to come north
by the end of the week. He did not say why.

Sarah folded the letter and slid it back into its envelope. She
finished the tea, rinsed the cup, and went upstairs to pack.
