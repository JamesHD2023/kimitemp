#!/bin/bash
# ============================================================
# Ideorix — Em-Dash Auto-Conversion (v2.7.89, mirrored)
#
# Deterministic em-dash → comma/period conversion for narration.
# Preserves quoted spans (dialogue / direct quotation), code
# blocks, YAML frontmatter, and markdown headings untouched.
# Honors formatting_mode: human in project-config.md — in human
# mode the script is a no-op (preserves author style).
#
# Why this exists: prior versions reported em-dashes and relied
# on LLM agents (Humaniser, Stage 8, Batch Editor) to convert
# them. Multiple pilots (v2.7.85 → v2.7.87 → v2.7.88) showed
# those agents skipping conversions or deferring "single
# em-dashes" to a human copyeditor — surfacing the same em-dash
# debt at handoff that the protocol was supposed to prevent.
# v2.7.89 adds a deterministic backstop: by the time the handoff
# gate runs, em-dashes in narration have already been removed,
# and the gate's Check 6 only verifies the result.
#
# Conversion rules (narration only, after quote-stashing):
#   em-dash before terminal punct (—. —! —?): drop em-dash
#   em-dash between spaces ( — ):              → ', ' (comma + space)
#   em-dash anywhere else (incl. word—word):   → ', '
# Comma fallback is grammatically valid in narration in the
# overwhelming majority of cases; edge-case interrupted dialogue
# sits inside quoted spans and is therefore never touched.
#
# Engine scope: the script is engine-agnostic. Fiction allows up
# to 3 em-dashes per chapter inside dialogue; NF allows up to 2
# inside direct quotations. Both rules live inside quoted spans
# that this script preserves wholesale, so a single mirrored
# script serves both engines correctly. The per-engine
# formatting-check.sh then verifies the result.
#
# Usage:
#   bash em-dash-auto-convert.sh <chapter-file> [project-root]
#
# Exit codes:
#   0  success (or no-op in human mode)
#   1  file missing / empty / write error
#   2  invalid arguments
# ============================================================

set -euo pipefail

if [ $# -lt 1 ]; then
    echo "Usage: em-dash-auto-convert.sh <chapter-file> [project-root]" >&2
    exit 2
fi

CHAPTER="$1"
PROJECT_ROOT="${2:-}"

if [ ! -f "$CHAPTER" ]; then
    echo "ERROR: chapter file not found: $CHAPTER" >&2
    exit 1
fi
if [ ! -s "$CHAPTER" ]; then
    echo "ERROR: chapter file is empty: $CHAPTER" >&2
    exit 1
fi

# Read formatting_mode from project-config.md (default: ai)
MODE="ai"
if [ -n "$PROJECT_ROOT" ] && [ -f "$PROJECT_ROOT/engine-data/project-config.md" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*formatting_mode:[[:space:]]*human\b' \
            "$PROJECT_ROOT/engine-data/project-config.md"; then
        MODE="human"
    fi
fi

if [ "$MODE" = "human" ]; then
    echo "em-dash-auto-convert: $CHAPTER: skipped (formatting_mode: human — author style preserved)"
    exit 0
fi

# Snapshot for safety (recoverable via .bak diff)
[ -e "${CHAPTER}.bak" ] || cp "$CHAPTER" "${CHAPTER}.bak"

python3 - "$CHAPTER" <<'PYEOF'
import sys
import re

path = sys.argv[1]
with open(path, encoding='utf-8') as f:
    text = f.read()

placeholders = []
def stash(s):
    placeholders.append(s)
    return f'\x00PH{len(placeholders)-1}\x00'

# 1. Stash YAML frontmatter (between first ---\n and next ---\n)
m = re.match(r'^(---\n.*?\n---\n)', text, re.DOTALL)
if m:
    text = stash(m.group(1)) + text[m.end():]

# 2. Stash fenced code blocks
text = re.sub(r'```.*?```', lambda m: stash(m.group(0)), text, flags=re.DOTALL)

# 3. Stash heading lines (line begins with #)
text = re.sub(r'^#.*$', lambda m: stash(m.group(0)), text, flags=re.MULTILINE)

# 4. Stash quoted spans (curly double then ASCII double).
#    Single-quote spans intentionally NOT stashed — the closing
#    curly single (U+2019) is also the apostrophe, so the span
#    boundary is ambiguous; collision risk outweighs the rare
#    "em-dash inside an inner single-quoted span" case.
text = re.sub(r'“[^”]*”', lambda m: stash(m.group(0)), text)
text = re.sub(r'"[^"]*"', lambda m: stash(m.group(0)), text)

# 5. Em-dash substitutions on narration text
c_endsent = len(re.findall(r'—([.!?])', text))
text = re.sub(r'—([.!?])', r'\1', text)
c_spaced = len(re.findall(r' — ', text))
text = re.sub(r' — ', ', ', text)
c_other = text.count('—')
text = text.replace('—', ', ')

total = c_endsent + c_spaced + c_other

# 6. Restore placeholders in reverse order
for i in range(len(placeholders) - 1, -1, -1):
    text = text.replace(f'\x00PH{i}\x00', placeholders[i])

with open(path, 'w', encoding='utf-8') as f:
    f.write(text)

print(f"em-dash-auto-convert: {path}: converted {total} em-dash(es) "
      f"({c_endsent} end-of-sentence; {c_spaced} mid-clause; {c_other} other; "
      f"backup at {path}.bak)")
PYEOF
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
