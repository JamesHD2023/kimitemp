#!/bin/bash
# ============================================================
# Ideorix — Handoff Gate (v2.7.86, extended v2.7.88)
# Enforces the Handoff Protocol (core-pipeline.md): before a
# manuscript is handed off for human edit, the four-step Handoff
# Protocol must have completed — and in particular Step 7.3 (the
# full editorial pipeline) must have run EVERY editorial stage,
# not collapsed to a mechanical-cleanup pass.
#
# Background: two v2.7.85 pilots demonstrated Step 7.3 collapsing
# to em-dash + forbidden-word cleanup relabelled "Editorial
# Pipeline", with twelve editorial stages skipped. The Handoff
# Protocol was LLM-contract-only with no enforcement (the gap the
# v2.7.84 Silent-Failure Audit table itself flagged). This gate
# adds the enforcement: it verifies the handoff-checklist.md
# artifact enumerates every editorial stage with a verdict.
#
# v2.7.88 extension — final mechanical re-verification.
# A v2.7.87 handoff pilot reported "0 em-dashes" in the Step 7.2
# grep sweep while ~102 single em-dashes survived in prose body:
# the orchestrator stretched Step 7.2 beyond its canonical-fact
# scope with a narrow (` — ` paired) em-dash pattern that missed
# singles, and Stage 8 deferred singles to a human copyeditor.
# Check 6 (below) binds formatting-check.sh at the gate so
# neither orchestrator drift nor a Stage 8 deferral can wave
# em-dashes past handoff — each engine's own formatting-check.sh
# applies that engine's rules (NF zero em-dashes in prose;
# fiction dialogue cap).
#
# Fail-closed: exits non-zero if the checklist is missing,
# under-populated, carries an unresolved FAIL, is not marked
# COMPLETE, or any chapter fails formatting rules at handoff.
# ============================================================
# Usage: bash handoff-gate.sh <project-root>
# - project-root: path to the volume / book directory (contains
#   engine-data/)
#
# A project passes when:
#   - project-config.md declares handoff_status: skip (documented
#     opt-out; passes with note), OR
#   - engine-data/reports/handoff-checklist.md exists with:
#       - non-zero bytes
#       - all four step sections present (7.1, 7.2, 7.3, 7.4)
#       - the Step 7.3 section enumerates >= 14 editorial stages,
#         each line carrying a verdict (PASS / WARN / FAIL /
#         SKIPPED)
#       - every uppercase FAIL verdict is matched by a resolution
#         token (RESOLVED or WAIVED) — an audit FAIL may not be
#         silently downgraded to an advisory
#       - a final status line: HANDOFF STATUS: COMPLETE
#       - mtime newer than the most recent chapter file (proves
#         the checklist reflects the current manuscript state)
#     AND
#   - every engine-data/chapters/ch*.md passes formatting-check.sh
#     (sibling script in the same scripts dir).
#
# Honest limit: the gate verifies the checklist is structurally
# complete. It cannot verify each stage verdict reflects genuine
# analysis rather than a stub entry. It converts "silently skipped
# twelve stages" into "must enumerate every stage with a verdict"
# — a large reduction in failure surface, not its elimination.
# Same ceiling as every artifact gate (silent-failure-audit.md
# row 62).
#
# Exit codes:
#   0  checklist present, complete, all stages enumerated, every
#      chapter mechanically clean (PASS)
#   1  checklist missing / incomplete / unresolved FAIL / stale /
#      chapter fails formatting-check.sh
#   2  invalid arguments

set -euo pipefail

if [ $# -lt 1 ]; then
    echo "Usage: handoff-gate.sh <project-root>" >&2
    exit 2
fi

PROJECT="$1"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

CONFIG="$PROJECT/engine-data/project-config.md"
CHECKLIST="$PROJECT/engine-data/reports/handoff-checklist.md"
CHAPTERS_DIR="$PROJECT/engine-data/chapters"
REPORTS_DIR="$PROJECT/engine-data/reports"
GATE_OUTPUT="$REPORTS_DIR/handoff-gate-output.md"
GATE_VERSION="v2.7.90"
RUN_TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)

# Minimum editorial stages the Step 7.3 section must enumerate.
# Fiction's editorial pipeline has 15 stage entries (0, 1, 2, 3, 4,
# 4.5, 5, 6, 7, 8, 9, 9.5, 10, 11, 12); non-fiction has 17 (adds
# 13, 14). A floor of 14 clears both with margin and firmly rejects
# the collapsed "Stages 2-3 only" pass the v2.7.85 pilots produced.
MIN_EDITORIAL_STAGES=14

# v2.7.90: gate_exit writes a literal verdict artifact to
# engine-data/reports/handoff-gate-output.md before exiting. The
# artifact is the gate's source-of-truth output, separate from the
# orchestrator's narrative in handoff-checklist.md. v2.7.89 pilot
# evidence: an orchestrator wrote its own "Handoff-Gate Checks"
# table into the checklist without invoking the gate, declaring
# COMPLETE while the actual gate would have failed Check 6. The
# artifact closes that gap by making the gate's actual run visible
# and time-stamped, so divergence between orchestrator narrative
# and gate reality is immediately auditable.
gate_exit() {
    local code="$1"
    local verdict="$2"
    local detail="${3:-}"
    mkdir -p "$REPORTS_DIR" 2>/dev/null || true
    {
        echo "# Handoff Gate Output"
        echo ""
        echo "**Run timestamp:** $RUN_TS"
        echo "**Project root:** $PROJECT"
        echo "**Gate version:** $GATE_VERSION"
        echo "**Verdict:** $verdict"
        echo "**Exit code:** $code"
        if [ -n "$detail" ]; then
            echo ""
            echo "## Detail"
            echo ""
            echo "$detail"
        fi
        echo ""
        echo "---"
        echo ""
        echo "This file is written by \`scripts/handoff-gate.sh\` on every invocation."
        echo "It is the gate's source-of-truth verdict, distinct from the orchestrator's"
        echo "narrative in handoff-checklist.md. Re-runs overwrite this file."
    } > "$GATE_OUTPUT" 2>/dev/null || true
    exit "$code"
}

# Documented opt-out.
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*handoff_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "HANDOFF GATE: PASS (project-config.md declares handoff_status: skip — documented opt-out honored)"
        gate_exit 0 "PASS (opt-out)" "project-config.md declares handoff_status: skip — documented opt-out honored. Gate structural and mechanical checks were not run."
    fi
fi

if [ ! -f "$CHECKLIST" ]; then
    echo "HANDOFF GATE: FAIL — no handoff-checklist.md present." >&2
    echo "  Expected: $CHECKLIST" >&2
    echo "ACTION: run the Handoff Protocol (core-pipeline.md) end-to-end and" >&2
    echo "        record all four steps in engine-data/reports/handoff-checklist.md." >&2
    echo "        Step 7.3 must enumerate every editorial stage with a verdict." >&2
    gate_exit 1 FAIL "no handoff-checklist.md present at $CHECKLIST. Run the Handoff Protocol end-to-end."
fi

if [ ! -s "$CHECKLIST" ]; then
    echo "HANDOFF GATE: FAIL — handoff-checklist.md is zero bytes." >&2
    echo "  $CHECKLIST" >&2
    gate_exit 1 FAIL "handoff-checklist.md is zero bytes at $CHECKLIST."
fi

# --- Check 1: all four step sections present ------------------
MISSING_STEPS=""
for step in '7\.1' '7\.2' '7\.3' '7\.4'; do
    if ! grep -qE "${step}([^0-9]|\$)" "$CHECKLIST"; then
        MISSING_STEPS="$MISSING_STEPS ${step//\\/}"
    fi
done
if [ -n "$MISSING_STEPS" ]; then
    echo "HANDOFF GATE: FAIL — handoff-checklist.md missing step section(s):$MISSING_STEPS" >&2
    echo "  The checklist must record all four Handoff Protocol steps (7.1-7.4)." >&2
    gate_exit 1 FAIL "Check 1 failed: handoff-checklist.md missing step section(s):$MISSING_STEPS"
fi

# --- Check 2: Step 7.3 enumerates enough editorial stages -----
# Count lines that name an editorial stage AND carry a verdict.
# "[Ss]tage" is case-tolerant; the verdict keywords are
# uppercase-only (the checklist format spec) so descriptive prose
# using lowercase "fail"/"pass" does not inflate the count.
STAGE_COUNT=$(grep -cE '[Ss]tage[[:space:]]+[0-9]+(\.5)?([^0-9]|$).*(PASS|WARN|FAIL|SKIPPED)' "$CHECKLIST" || true)
if [ "$STAGE_COUNT" -lt "$MIN_EDITORIAL_STAGES" ]; then
    echo "HANDOFF GATE: FAIL — Step 7.3 enumerates only $STAGE_COUNT editorial stage(s) with a verdict (minimum $MIN_EDITORIAL_STAGES)." >&2
    echo "  The full editorial pipeline has 15 (fiction) / 17 (non-fiction) stages." >&2
    echo "  A checklist with fewer than $MIN_EDITORIAL_STAGES stage verdicts means Step 7.3" >&2
    echo "  collapsed to a partial pass — the exact v2.7.85 pilot failure. Run every" >&2
    echo "  editorial stage (editorial-suite.md) and record a verdict for each." >&2
    gate_exit 1 FAIL "Check 2 failed: Step 7.3 enumerates only $STAGE_COUNT editorial stage(s) with a verdict (minimum $MIN_EDITORIAL_STAGES)."
fi

# --- Check 3: no unresolved FAIL ------------------------------
# Every uppercase FAIL verdict must be matched by a resolution
# token (RESOLVED or WAIVED). An audit FAIL is a blocking decision
# item — fix the chapter or record an explicit waiver; it may not
# be silently downgraded to an advisory.
#
# FAIL_COUNT counts FAIL-bearing lines that do NOT themselves carry
# a resolution token — so a resolution line that legitimately
# references the word FAIL ("Stage 9 FAIL WAIVED by author …")
# does not inflate the unresolved-FAIL count. RESOLUTION_COUNT
# counts all resolution lines. The handoff passes when every
# unresolved FAIL line is matched by a resolution line.
FAIL_COUNT=$(grep -E '\bFAIL\b' "$CHECKLIST" 2>/dev/null | grep -cvE '\b(RESOLVED|WAIVED)\b' || true)
RESOLUTION_COUNT=$(grep -cE '\b(RESOLVED|WAIVED)\b' "$CHECKLIST" || true)
if [ "$FAIL_COUNT" -gt 0 ] && [ "$RESOLUTION_COUNT" -lt "$FAIL_COUNT" ]; then
    echo "HANDOFF GATE: FAIL — handoff-checklist.md has $FAIL_COUNT FAIL verdict(s) but only $RESOLUTION_COUNT resolution(s)." >&2
    echo "  Every FAIL is a blocking decision item: fix the chapter, or record an" >&2
    echo "  explicit WAIVED entry with a stated reason. An audit FAIL (word count" >&2
    echo "  below 90%, forbidden words, integrity, etc.) may not be silently" >&2
    echo "  downgraded to an advisory." >&2
    gate_exit 1 FAIL "Check 3 failed: $FAIL_COUNT FAIL verdict(s) but only $RESOLUTION_COUNT resolution(s). Every FAIL needs RESOLVED or WAIVED."
fi

# --- Check 4: final status line ------------------------------
if ! grep -qE '^HANDOFF STATUS:[[:space:]]*COMPLETE\b' "$CHECKLIST"; then
    echo "HANDOFF GATE: FAIL — handoff-checklist.md has no 'HANDOFF STATUS: COMPLETE' line." >&2
    echo "  The checklist must end with a single status line:" >&2
    echo "    HANDOFF STATUS: COMPLETE" >&2
    echo "  If the protocol is not finished the line reads 'HANDOFF STATUS: BLOCKED'" >&2
    echo "  and the handoff is not done." >&2
    gate_exit 1 FAIL "Check 4 failed: no 'HANDOFF STATUS: COMPLETE' line present."
fi

# --- Check 5: freshness --------------------------------------
if [ -d "$CHAPTERS_DIR" ]; then
    NEWEST_CHAPTER_MTIME=0
    while IFS= read -r _chap; do
        _m=$(stat -c %Y "$_chap" 2>/dev/null || stat -f %m "$_chap" 2>/dev/null || echo 0)
        if [ "$_m" -gt "$NEWEST_CHAPTER_MTIME" ]; then NEWEST_CHAPTER_MTIME="$_m"; fi
    done < <(find "$CHAPTERS_DIR" -type f -name 'ch*.md')
    [ -z "$NEWEST_CHAPTER_MTIME" ] && NEWEST_CHAPTER_MTIME=0
    CHECKLIST_MTIME=$(stat -c %Y "$CHECKLIST" 2>/dev/null || stat -f %m "$CHECKLIST" 2>/dev/null || echo 0)
    if [ "$CHECKLIST_MTIME" -lt "$NEWEST_CHAPTER_MTIME" ]; then
        echo "HANDOFF GATE: FAIL — handoff-checklist.md is stale (older than the most recent chapter)." >&2
        echo "  A chapter has changed since the checklist was written. Re-run the" >&2
        echo "  Handoff Protocol against the current manuscript state." >&2
        gate_exit 1 FAIL "Check 5 failed: handoff-checklist.md mtime older than newest chapter mtime — checklist is stale."
    fi
fi

# --- Check 6: final mechanical re-verification ----------------
# Run formatting-check.sh on every chapter. Structural checks
# 1–5 verify the checklist's shape; this check verifies the
# manuscript's actual mechanical state at handoff, so a
# Stage 8 deferral (e.g. "single em-dashes left for human
# copyeditor") cannot survive to delivery. Sibling-script
# resolution keeps the gate engine-agnostic while each engine's
# own formatting-check.sh applies its rules.
#
# v2.7.89: reads formatting_mode: human from project-config.md
# and passes it through to formatting-check.sh. Writers Studio
# imports (human-authored prose) set formatting_mode: human to
# get the human-prose cap (≤3 em-dashes per 1,000 words narration)
# instead of the AI-mode zero-tolerance default. NF's
# formatting-check ignores the second arg (NF rule is absolute
# zero regardless of mode); fiction honors it.
FORMATTING_CHECK="$(dirname "$0")/formatting-check.sh"
FORMATTING_MODE="ai"
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*formatting_mode:[[:space:]]*human\b' "$CONFIG"; then
        FORMATTING_MODE="human"
    fi
fi
if [ -d "$CHAPTERS_DIR" ] && [ -f "$FORMATTING_CHECK" ]; then
    FAILED_CHAPTERS=()
    while IFS= read -r ch; do
        if ! bash "$FORMATTING_CHECK" "$ch" "$FORMATTING_MODE" > /dev/null 2>&1; then
            FAILED_CHAPTERS+=("$ch")
        fi
    done < <(find "$CHAPTERS_DIR" -type f -name 'ch*.md' | sort)
    if [ "${#FAILED_CHAPTERS[@]}" -gt 0 ]; then
        echo "HANDOFF GATE: FAIL — final mechanical re-verification (mode: $FORMATTING_MODE): ${#FAILED_CHAPTERS[@]} chapter(s) fail formatting-check.sh:" >&2
        FAIL_LIST=""
        for ch in "${FAILED_CHAPTERS[@]}"; do
            echo "  - $ch" >&2
            FAIL_LIST="$FAIL_LIST  - $ch"$'\n'
        done
        echo "  Run: bash scripts/formatting-check.sh <chapter> [$FORMATTING_MODE]  for per-chapter details." >&2
        echo "  For AI-generated prose: run scripts/em-dash-auto-convert.sh <chapter> <project-root>" >&2
        echo "  on each affected chapter to auto-convert narration em-dashes, then re-run this gate." >&2
        echo "  For human-authored manuscripts: set 'formatting_mode: human' in" >&2
        echo "  engine-data/project-config.md (relaxes Check 6 to the human-prose cap)." >&2
        gate_exit 1 FAIL "Check 6 failed (mode: $FORMATTING_MODE): ${#FAILED_CHAPTERS[@]} chapter(s) fail formatting-check.sh:"$'\n'"$FAIL_LIST"
    fi
fi

echo "HANDOFF GATE: PASS — handoff-checklist.md present; all four steps recorded; $STAGE_COUNT editorial stages enumerated with verdicts; no unresolved FAIL; status COMPLETE; final mechanical re-verification clean."
gate_exit 0 PASS "All 6 checks passed. Mode: $FORMATTING_MODE. Editorial stages enumerated: $STAGE_COUNT."
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
