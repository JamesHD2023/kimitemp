#!/bin/bash
# ============================================================
# Ideorix — Tense Contract Scan (v2.7.125)
#
# CONSISTENCY-domain, per-chapter, WARN-level audit of narrative tense.
# Reads the project's declared tense contract (world-canon §3, written to
# engine-data/story-bible.md) and — ONLY when the contract is `immediate`
# (present / past-immediate / past-literary) — scans chapter narration for
# distinctive RETROSPECTIVE / FORESHADOWING marker phrases that violate an
# immediate contract ("if she'd only known", "little did he know", "years
# later he would learn", "what she didn't know then").
#
# Deliberately conservative (see narrative-tense.md):
#   - marker-based, NOT a full base-tense statistical scan (FP-prone; deferred)
#   - WARN (exit 3), never FAIL — a signal for the writer to judge
#   - retrospective / future contracts: markers are legitimate -> PASS
#   - no declared tense / unreadable inputs -> SKIP (exit 2), never silent PASS
#
# Usage (CHAPTER_PROJECT signature, per the /validate dispatcher):
#   tense-contract-scan.sh <chapter_file> <project_root>
#
# Exit codes: 0 clean (or contract permits markers) · 2 SKIP · 3 WARN (markers found)
# ============================================================

set -uo pipefail

CHAPTER="${1:-}"
PROJECT_ROOT="${2:-}"

if [ -z "$CHAPTER" ] || [ ! -f "$CHAPTER" ]; then
    echo "SKIP: chapter file not found: ${CHAPTER:-<none>}" >&2
    exit 2
fi
if [ -z "$PROJECT_ROOT" ] || [ ! -d "$PROJECT_ROOT" ]; then
    echo "SKIP: project root not found: ${PROJECT_ROOT:-<none>}" >&2
    exit 2
fi

BIBLE="$PROJECT_ROOT/engine-data/story-bible.md"
if [ ! -f "$BIBLE" ]; then
    echo "SKIP: no story bible at $BIBLE — cannot read tense contract" >&2
    exit 2
fi

# Read the declared tense / contract (case-insensitive). Prefer an explicit
# "Tense contract:" line; fall back to classifying "Narrative tense:".
CONTRACT_RAW="$(grep -iE '^[-*[:space:]]*Tense contract:' "$BIBLE" | head -1 | tr '[:upper:]' '[:lower:]')"
TENSE_RAW="$(grep -iE '^[-*[:space:]]*Narrative tense:' "$BIBLE" | head -1 | tr '[:upper:]' '[:lower:]')"

CONTRACT=""
case "$CONTRACT_RAW$TENSE_RAW" in
    *retrospective*|*future*) CONTRACT="permits" ;;
esac
if [ -z "$CONTRACT" ]; then
    case "$CONTRACT_RAW$TENSE_RAW" in
        *immediate*|*present*|*literary*) CONTRACT="immediate" ;;
    esac
fi

if [ -z "$CONTRACT" ]; then
    echo "SKIP: no recognisable tense contract in $BIBLE (add 'Narrative tense:' / 'Tense contract:' per narrative-tense.md)" >&2
    exit 2
fi

echo "=== CONSISTENCY: tense contract ==="
echo "Chapter: $(basename "$CHAPTER")"

if [ "$CONTRACT" = "permits" ]; then
    echo "Contract: retrospective/future — foreshadowing & hindsight permitted; nothing to flag."
    echo "[PASS] contract permits retrospective markers"
    exit 0
fi

echo "Contract: immediate — retrospective/foreshadowing markers are violations."

# High-confidence, low-FP retrospective / foreshadowing marker phrases.
# (Distinctive narration phrasings; they essentially never occur in natural
# dialogue, so a dialogue-aware parse is unnecessary at WARN level.)
PATTERNS=(
    "if (he|she|they|i|we) (had|'?d) only known"
    "little did (he|she|they|i|we) know"
    "(he|she|they|i|we) would (later|soon|never|one day) (learn|discover|reali[sz]e|know|find out|come to)"
    "would (later|soon) come to (regret|learn|understand|reali[sz]e)"
    "what (he|she|they|i|we) (did ?n'?t|didn'?t) (yet )?know"
    "had (he|she|they|i|we) (but )?known"
    "years later"
    "looking back"
    "it would be (years|months|weeks|days) before"
)

FOUND=0
for pat in "${PATTERNS[@]}"; do
    matches="$(grep -niE "$pat" "$CHAPTER" 2>/dev/null || true)"
    if [ -n "$matches" ]; then
        if [ "$FOUND" -eq 0 ]; then
            echo ""
            echo "RETROSPECTIVE / FORESHADOWING markers (violate an immediate contract):"
        fi
        printf '  pattern "%s":\n' "$pat"
        printf '%s\n' "$matches" | sed 's/^/    /'
        FOUND=1
    fi
done

echo ""
if [ "$FOUND" -eq 0 ]; then
    echo "[PASS] no immediate-contract violations in narration"
    exit 0
else
    echo "[WARN] retrospective/foreshadowing markers in an immediate-tense project —"
    echo "       rewrite in-the-moment, or switch the project to a retrospective"
    echo "       contract if the look-back is intentional (see narrative-tense.md)."
    exit 3
fi
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
