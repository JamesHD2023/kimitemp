#!/bin/bash
# ============================================================
# Ideorix — Manuscript Renderer Chooser (v2.7.93, mirrored)
#
# Single canonical entry point for DOCX manuscript export. Detects
# which renderer is available on the user's machine and dispatches:
#
#   1. pandoc present   → markdown-to-docx-render.sh (best quality;
#                         handles every inline edge case)
#   2. python3 present  → manuscript-render.py (Python stdlib only;
#                         no external deps required)
#   3. neither          → fail with platform-specific install hint
#
# The fallback path closes the "Claude writes an ad-hoc Python
# script each session" gap: instead of the LLM re-implementing
# DOCX generation fresh every time (with whatever bugs each
# implementation happens to have), the engine ships a tested
# Python stdlib renderer that runs anywhere python3 runs — which
# is essentially every machine Ideorix users have, since the
# orchestrator already invokes Python scripts in their session.
#
# Both renderers produce output at manuscript/{title}.docx by
# default (per v2.7.92 path-discipline) and both feed into the
# existing docx-integrity-check.sh post-write gate.
#
# Usage:
#   bash manuscript-render.sh <project-root> [--output <path>]
#                              [--title <title>] [--author <name>]
#                              [--config <path>] [--template <path>]
#
# Flags are passed through verbatim. --config and --template are
# pandoc-specific; the Python renderer accepts-and-ignores them
# so a single command line works for both paths.
# ============================================================

set -euo pipefail

if [ $# -lt 1 ]; then
    echo "Usage: manuscript-render.sh <project-root> [--output <path>] [--title <title>] [--author <name>]" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANDOC_RENDERER="$SCRIPT_DIR/markdown-to-docx-render.sh"
PYTHON_RENDERER="$SCRIPT_DIR/manuscript-render.py"

if command -v pandoc >/dev/null 2>&1 && [ -x "$PANDOC_RENDERER" ]; then
    echo "[manuscript-render] pandoc detected — using pandoc renderer" >&2
    if bash "$PANDOC_RENDERER" "$@"; then
        exit 0
    fi
    echo "[manuscript-render] pandoc renderer failed (e.g. it could not write" >&2
    echo "    to a Windows/CIFS-mounted folder) — falling back to the Python" >&2
    echo "    stdlib renderer, which writes via a temp + atomic rename." >&2
fi

if command -v python3 >/dev/null 2>&1 && [ -f "$PYTHON_RENDERER" ]; then
    echo "[manuscript-render] using Python stdlib renderer" >&2
    exec python3 "$PYTHON_RENDERER" "$@"
fi

echo "ERROR: neither pandoc nor python3 is available on this machine." >&2
echo "" >&2
echo "Install one (either works; both produce a valid manuscript .docx):" >&2
echo "" >&2
echo "  macOS:" >&2
echo "    brew install pandoc       # preferred (best quality)" >&2
echo "    OR python3 is already shipped with macOS" >&2
echo "" >&2
echo "  Windows:" >&2
echo "    winget install JohnMacFarlane.Pandoc       # preferred" >&2
echo "    OR winget install Python.Python.3" >&2
echo "" >&2
echo "  Linux:" >&2
echo "    sudo apt install pandoc                    # preferred" >&2
echo "    OR sudo apt install python3" >&2
echo "" >&2
echo "After installing, re-run: bash manuscript-render.sh \"$1\"" >&2
exit 3
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
