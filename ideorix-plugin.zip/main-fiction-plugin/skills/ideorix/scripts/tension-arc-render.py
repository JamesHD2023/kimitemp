#!/usr/bin/env python3
# ============================================================
# Ideorix — Tension Arc Renderer (Python stdlib, v2.7.120)
#
# Reads engine-data/tension-tracker.md and renders the manuscript's
# pacing/tension trajectory as a standalone SVG line chart, using
# ONLY the Python 3 standard library (re, sys, os, argparse). No
# matplotlib, no plotly, no external deps — the SVG is written as
# plain text. Opens in any browser on macOS, Windows, and Linux
# with zero install step.
#
# This is the GUARANTEED-EVERYWHERE floor of the Tension Graph
# feature (see references/tension-graph.md). When the runtime
# environment offers a richer charting library (e.g. Cowork's
# sandbox), the orchestrator may produce a prettier library chart
# instead — but this script guarantees every user gets a real graph
# without depending on the environment, exactly as
# manuscript-render.py guarantees DOCX export without pandoc.
#
# Plots the ACTUAL delivered slider values where present, falling
# back to PLANNED values for chapters not yet verified. By default
# plots all six sliders as separate lines (the data already exists
# in the tracker); --single plots only the Tension line for a
# cleaner single-arc view.
#
# Sliders (tracker columns): T Tension, D Dread, EI Emotional
# Intimacy, RT Relationship Tension, PE Pacing Energy, H Humor.
#
# HONEST LABEL: the values are the engine's ASSESSED tension
# (Architect-planned, Arc-Analyst-verified 1-10 judgments), NOT a
# mechanical measurement of the prose. The chart caption says so.
# ============================================================
"""Render an Ideorix tension-tracker into a standalone SVG line chart.

Usage:
    python3 tension-arc-render.py <project-root> [--output <path>]
                                  [--single] [--title <title>]

Exit codes:
    0  SVG written
    1  tracker missing, empty, or unparseable
    2  invalid invocation
"""

import argparse
import os
import re
import sys

# Slider column order in the tracker's Slider History table, with
# display label and line colour. Plan column index / actual column
# index are 1-based offsets into the data cells (after the Ch cell).
SLIDERS = [
    # key, label,                 plan_idx, actual_idx, colour
    ("T",  "Tension",             0,        1,          "#d6336c"),
    ("D",  "Dread",               2,        3,          "#7048e8"),
    ("EI", "Emotional Intimacy",  4,        5,          "#1098ad"),
    ("RT", "Relationship Tension",6,        7,          "#f08c00"),
    ("PE", "Pacing Energy",       8,        9,          "#2f9e44"),
    ("H",  "Humor",               10,       11,         "#868e96"),
]

W, H = 1180, 640          # canvas
ML, MR, MT, MB = 70, 240, 60, 70   # margins (wide right margin for legend)
PLOT_W = W - ML - MR
PLOT_H = H - MT - MB


def parse_tracker(path):
    """Return (chapters, rows) where rows[i] is a dict of slider->value.

    A value is the ACTUAL if present (non-empty, numeric), else the
    PLANNED, else None. Returns None on unparseable input.
    """
    try:
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
    except OSError:
        return None

    chapters = []
    rows = []
    in_history = False
    for line in text.splitlines():
        s = line.strip()
        if s.lower().startswith("## slider history"):
            in_history = True
            continue
        if in_history and s.startswith("## "):
            break  # next section ends the table
        if not in_history:
            continue
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if not cells:
            continue
        # Skip header row and the markdown separator row.
        if cells[0].lower() in ("ch", "chapter"):
            continue
        if set("".join(cells)) <= set("-: "):
            continue
        ch = cells[0]
        if not ch:
            continue
        data = cells[1:]
        row = {}
        for key, _label, p_idx, a_idx, _col in SLIDERS:
            val = _pick(data, a_idx, p_idx)
            row[key] = val
        if any(v is not None for v in row.values()):
            chapters.append(ch)
            rows.append(row)
    if not rows:
        return None
    return chapters, rows


def _pick(data, actual_idx, plan_idx):
    """Actual value if numeric, else planned, else None."""
    for idx in (actual_idx, plan_idx):
        if 0 <= idx < len(data):
            m = re.search(r"-?\d+(?:\.\d+)?", data[idx])
            if m:
                try:
                    v = float(m.group())
                    if 0 <= v <= 10:
                        return v
                except ValueError:
                    pass
    return None


def _x(i, n):
    if n <= 1:
        return ML + PLOT_W / 2
    return ML + (PLOT_W * i) / (n - 1)


def _y(v):
    return MT + PLOT_H * (1 - (v / 10.0))


def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def render_svg(chapters, rows, single, title):
    n = len(chapters)
    out = []
    out.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
        f'viewBox="0 0 {W} {H}" font-family="Inter, Helvetica, Arial, sans-serif">'
    )
    out.append(f'<rect width="{W}" height="{H}" fill="#ffffff"/>')
    # Title
    out.append(
        f'<text x="{ML}" y="32" font-size="20" font-weight="600" '
        f'fill="#212529">{esc(title)}</text>'
    )
    # Y gridlines + labels (0..10)
    for v in range(0, 11):
        y = _y(v)
        out.append(
            f'<line x1="{ML}" y1="{y:.1f}" x2="{ML+PLOT_W}" y2="{y:.1f}" '
            f'stroke="#e9ecef" stroke-width="1"/>'
        )
        lab = f"{v}"
        if v == 10:
            lab = "10 (climax)"
        elif v == 5:
            lab = "5 (neutral)"
        elif v == 0:
            lab = "0 (low)"
        out.append(
            f'<text x="{ML-8}" y="{y+4:.1f}" font-size="11" text-anchor="end" '
            f'fill="#868e96">{lab}</text>'
        )
    # Neutral midline emphasis
    out.append(
        f'<line x1="{ML}" y1="{_y(5):.1f}" x2="{ML+PLOT_W}" y2="{_y(5):.1f}" '
        f'stroke="#ced4da" stroke-width="1" stroke-dasharray="4 4"/>'
    )
    # X labels (chapters) — thin out if many
    step = 1 if n <= 32 else max(1, n // 30)
    for i, ch in enumerate(chapters):
        if i % step:
            continue
        x = _x(i, n)
        out.append(
            f'<text x="{x:.1f}" y="{MT+PLOT_H+22:.1f}" font-size="10" '
            f'text-anchor="middle" fill="#868e96" '
            f'transform="rotate(45 {x:.1f} {MT+PLOT_H+22:.1f})">{esc(ch)}</text>'
        )
    # Slider lines
    sliders = [SLIDERS[0]] if single else SLIDERS
    legend_y = MT + 6
    for key, label, _p, _a, col in sliders:
        pts = []
        for i in range(n):
            v = rows[i].get(key)
            if v is None:
                continue
            pts.append((i, v))
        if not pts:
            continue
        # polyline (skips gaps by segmenting)
        d = []
        for i, v in pts:
            d.append(f"{_x(i,n):.1f},{_y(v):.1f}")
        out.append(
            f'<polyline points="{" ".join(d)}" fill="none" '
            f'stroke="{col}" stroke-width="2.5" stroke-linejoin="round"/>'
        )
        for i, v in pts:
            out.append(
                f'<circle cx="{_x(i,n):.1f}" cy="{_y(v):.1f}" r="3.2" '
                f'fill="{col}"/>'
            )
        # legend entry
        out.append(
            f'<rect x="{ML+PLOT_W+24}" y="{legend_y-9}" width="12" height="12" '
            f'rx="2" fill="{col}"/>'
        )
        out.append(
            f'<text x="{ML+PLOT_W+42}" y="{legend_y+1}" font-size="12" '
            f'fill="#343a40">{esc(label)}</text>'
        )
        legend_y += 24
    # Honest caption
    out.append(
        f'<text x="{ML}" y="{H-18}" font-size="11" fill="#adb5bd">'
        f'Values are the engine’s assessed tension (planned by the '
        f'Architect, verified by the Arc Analyst) — a craft judgment, '
        f'not a mechanical measurement of the prose.</text>'
    )
    out.append("</svg>")
    return "\n".join(out)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Render an Ideorix tension arc to SVG.")
    ap.add_argument("project_root", help="path to the project directory (contains engine-data/)")
    ap.add_argument("--output", help="output .svg path (default: engine-data/reports/tension-arc.svg)")
    ap.add_argument("--single", action="store_true", help="plot only the Tension line")
    ap.add_argument("--title", help="chart title (default: derived from tracker)")
    args = ap.parse_args(argv)

    root = args.project_root
    tracker = os.path.join(root, "engine-data", "tension-tracker.md")
    if not os.path.isfile(tracker):
        print(f"ERROR: tension-tracker.md not found at {tracker}", file=sys.stderr)
        print("       Run the editorial/generation pipeline first — the tracker", file=sys.stderr)
        print("       is populated as chapters are planned and verified.", file=sys.stderr)
        return 1

    parsed = parse_tracker(tracker)
    if parsed is None:
        print(f"ERROR: could not parse any slider rows from {tracker}", file=sys.stderr)
        return 1
    chapters, rows = parsed

    title = args.title
    if not title:
        # Try the tracker's H1 ("# Tension & Pacing Tracker — {Title}")
        try:
            with open(tracker, encoding="utf-8") as fh:
                for line in fh:
                    if line.startswith("# "):
                        m = re.search(r"—\s*(.+?)\s*$", line)
                        title = (m.group(1) if m else "Tension Arc")
                        break
        except OSError:
            pass
        title = (title or "Tension Arc") + " — Tension Arc"

    svg = render_svg(chapters, rows, args.single, title)

    out_path = args.output or os.path.join(root, "engine-data", "reports", "tension-arc.svg")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    try:
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.write(svg)
    except OSError as e:
        print(f"ERROR: cannot write {out_path}: {e}", file=sys.stderr)
        return 1

    print(f"[PASS] tension-arc-render — {len(chapters)} chapters plotted -> {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
