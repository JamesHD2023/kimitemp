#!/bin/bash
# ============================================================
# Ideorix — Chapter Integrity Check (v2.7.69)
# Post-write integrity gate for chapter markdown source files.
# Scans for NULL-byte corruption that can be silently inserted
# by certain Bash patterns (awk-with-getline + heredoc being the
# canonical offender, but the gate is root-cause-agnostic — it
# catches ANY null-byte corruption regardless of how it got there).
#
# Mirrors the v2.7.64 docx-integrity-check.sh contract on the
# DOCX side: both gates verify a successful-looking write didn't
# silently produce a corrupted artifact. The DOCX gate catches
# null bytes in word/document.xml; this one catches null bytes
# in the chapter .md source before they propagate to validation,
# voice metrics, classifier output, or export.
#
# Failure mode addressed: in a v2.7.68 user session, an inline
# `awk` invocation with getline + bash heredoc produced a chapter
# .md where one line was overwritten with NULL bytes. The Bash
# tool reported success (exit 0, no error), the file existed on
# disk, no error was raised. The engine continued — the audit
# pipeline ran on a corrupted chapter, and the user had to rebuild
# the chapter from scratch three separate times in one session
# before recognising the pattern. The recovery cost was
# substantial. This gate catches the corruption at the write
# boundary, before any downstream step operates on garbage.
# ============================================================
# Usage: bash chapter-integrity-check.sh <chapter.md>
#
# Verifies:
#   1. File exists + non-zero bytes
#   2. File contains zero NULL bytes (\x00)
#   3. File is valid UTF-8
#   4. If the file has YAML frontmatter, the frontmatter is
#      closed (an unclosed frontmatter is a strong indicator of
#      truncation mid-write)
#
# Exit codes:
#   0  chapter source clean (PASS)
#   1  null bytes / UTF-8 invalidity / truncation detected (FAIL)
#   2  invalid arguments

set -uo pipefail

CHAPTER="${1:?Usage: chapter-integrity-check.sh <chapter.md>}"

if [ ! -f "$CHAPTER" ]; then
    echo "CHAPTER INTEGRITY GATE: FAIL — file not found: $CHAPTER" >&2
    exit 1
fi

if [ ! -s "$CHAPTER" ]; then
    echo "CHAPTER INTEGRITY GATE: FAIL — file is zero bytes: $CHAPTER" >&2
    echo "  ACTION: regenerate the chapter (file was lost mid-write)." >&2
    exit 1
fi

# NULL-byte scan. Root-cause-agnostic — catches awk-getline,
# binary input to sed, accidental dd, anything that produces \x00
# in a markdown file.
# Portable NUL detection — BSD grep (macOS) has no -P, so the old
# `grep -qaP '\x00'` silently no-op'd on Mac. Count NUL bytes via tr
# (the same idiom word-count-check.sh already uses).
NULL_BYTE_COUNT=$(LC_ALL=C tr -dc '\000' < "$CHAPTER" | wc -c | tr -d '[:space:]')
if [ "${NULL_BYTE_COUNT:-0}" -gt 0 ]; then
    echo "CHAPTER INTEGRITY GATE: FAIL — NULL bytes detected in $CHAPTER" >&2
    echo "  NULL bytes found: $NULL_BYTE_COUNT" >&2
    echo "" >&2
    echo "  ROOT CAUSE: a Bash invocation that LOOKED successful (exit 0)" >&2
    echo "    silently inserted NULL bytes. The canonical pattern is" >&2
    echo "    \`awk\` with \`getline\` inside a bash heredoc — the awk-getline" >&2
    echo "    redirect interacts pathologically with the heredoc's stdin" >&2
    echo "    handling and writes \x00 to the output stream." >&2
    echo "" >&2
    echo "  ACTION:" >&2
    echo "    1. Restore the chapter from the latest snapshot at" >&2
    echo "       \`engine-data/snapshots/{stem}.pre-*\` if one exists." >&2
    echo "    2. Otherwise rewrite the chapter via a SINGLE heredoc" >&2
    echo "       (one \`cat > chapter.md <<'EOF' ... EOF\` invocation) with" >&2
    echo "       all fixes / expansions baked into the heredoc body. Do NOT" >&2
    echo "       chain awk-with-getline through a heredoc." >&2
    echo "    3. Re-run this gate to confirm the rebuild is clean." >&2
    echo "" >&2
    echo "  See \`mandatory-pipeline-rules.md\` Rule 2 (File-Write Hygiene)" >&2
    echo "    for the canonical anti-pattern catalog and the recovery" >&2
    echo "    playbook." >&2
    exit 1
fi

# UTF-8 validity. Catches the broader class of "binary garbage
# inserted into a markdown file" — null bytes are the most common
# but not the only failure mode.
if ! iconv -f UTF-8 -t UTF-8 "$CHAPTER" -o /dev/null 2>/dev/null; then
    BAD_LINE=$(iconv -f UTF-8 -t UTF-8 "$CHAPTER" -o /dev/null 2>&1 | head -1)
    echo "CHAPTER INTEGRITY GATE: FAIL — invalid UTF-8 in $CHAPTER" >&2
    echo "  iconv reports: $BAD_LINE" >&2
    echo "  ACTION: a Bash invocation produced non-UTF-8 bytes in the" >&2
    echo "    chapter source. Restore from snapshot or rewrite via a" >&2
    echo "    single heredoc. See Rule 2 in mandatory-pipeline-rules.md." >&2
    exit 1
fi

# v2.7.71 line-count collapse check. A user-reported corruption mode:
# `awk -v expfile=... '{... getline line < fname ...}' chapter > tmp`
# can produce an output file with the same byte count but with newlines
# collapsed — the file reads as a single 17KB line instead of 85
# separate lines. No NULL bytes, UTF-8 still valid, but unusable.
# Detect this by flagging any file >5 KB that has fewer than 5
# newlines. The threshold is conservative — legitimate single-paragraph
# files exist but are rarely >5 KB.
SIZE=$(wc -c < "$CHAPTER" 2>/dev/null || echo 0)
LINES=$(grep -c '' "$CHAPTER" 2>/dev/null || echo 0)
if [ "$SIZE" -gt 5000 ] && [ "$LINES" -lt 5 ]; then
    echo "CHAPTER INTEGRITY GATE: FAIL — line-count collapse detected in $CHAPTER" >&2
    echo "  File size: $SIZE bytes; newline count: $LINES (threshold: <5 lines for >5KB file)" >&2
    echo "" >&2
    echo "  ROOT CAUSE: a Bash command (typically \`awk\` used as a" >&2
    echo "    multi-file content-splicer via \`getline ... < file\`) produced" >&2
    echo "    a file with intact bytes but no newline structure. The" >&2
    echo "    chapter is unusable as markdown even though no NULL bytes" >&2
    echo "    are present and UTF-8 is valid." >&2
    echo "" >&2
    echo "  ACTION: restore from snapshot or rewrite via SINGLE heredoc" >&2
    echo "    (cat > chapter.md << 'EOF' ... EOF). Do not use awk to" >&2
    echo "    splice content from one file into another." >&2
    echo "" >&2
    echo "  See \`mandatory-pipeline-rules.md\` / core-pipeline.md \"Bash" >&2
    echo "    Anti-Pattern\" subsection for the full catalog." >&2
    exit 1
fi

# Frontmatter close check. Engine-generated chapters start with
# `---` on line 1 and a closing `---` within the first ~20 lines.
# An unclosed frontmatter is a strong truncation signal.
if head -1 "$CHAPTER" 2>/dev/null | grep -qE '^---[[:space:]]*$'; then
    # Frontmatter opened. Look for the close within the first 50 lines.
    if ! awk 'NR==1{next} /^---[[:space:]]*$/{found=1; exit} NR>50{exit} END{exit !found}' "$CHAPTER"; then
        echo "CHAPTER INTEGRITY GATE: FAIL — YAML frontmatter opened but not closed within first 50 lines: $CHAPTER" >&2
        echo "  This is a strong indicator the chapter file was truncated" >&2
        echo "  mid-write. Restore from snapshot or rewrite via a single" >&2
        echo "  heredoc." >&2
        exit 1
    fi
fi

SIZE=$(wc -c < "$CHAPTER")
echo "CHAPTER INTEGRITY GATE: PASS — $CHAPTER ($SIZE bytes, no NULL bytes, UTF-8 valid, frontmatter closed)"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
