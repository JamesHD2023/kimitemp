#!/bin/bash
# ============================================================
# Ideorix — Canon Validation Sweep Gate (v2.7.62)
# Enforces Stage 9.5 (editorial-suite.md): the manuscript-scope
# Canon Validation Sweep — running all four Class B audits at
# end of manuscript — must have completed before Phase 6 Delivery.
#
# Fail-closed: exits non-zero if the consolidated sweep report
# is missing or doesn't carry verdicts for all four audits.
# ============================================================
# Usage: bash canon-validation-sweep-gate.sh <project-root>
# - project-root: path to Ideorix-Projects/{Book}
#
# A project passes the Canon Validation Sweep gate when:
#   - project-config.md declares class_b_full_status: skip
#     (documented opt-out; passes with note), OR
#   - engine-data/reports/canon-validation-sweep.md exists with:
#       - non-zero bytes
#       - one verdict line per Class B audit (4 audits):
#         leitmotif-tracker, injury-accumulation, humanity-gate,
#         intent-preservation
#       - mtime newer than the most recent chapter file (proves
#         the sweep ran against the final manuscript, not a
#         stale earlier state)
#
# The verdict-line check prevents the silent-failure shape where
# a stub sweep report exists without actually containing the four
# audit verdicts.
#
# Exit codes:
#   0  Sweep report present, complete, and fresh (PASS)
#   1  Report missing / incomplete / stale (FAIL)
#   2  Invalid arguments

set -euo pipefail

PROJECT="${1:?Usage: canon-validation-sweep-gate.sh <project-root>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

CONFIG="$PROJECT/engine-data/project-config.md"
SWEEP="$PROJECT/engine-data/reports/canon-validation-sweep.md"
CHAPTERS_DIR="$PROJECT/engine-data/chapters"

# Documented opt-out — projects that deliberately skip Stage 9.5
# (e.g., short-form, drafting-only flows, or projects with
# class_b_delta_status: skip already declared and matched here)
# can append to engine-data/project-config.md:
#
#   class_b_full_status: skip
#
# Not recommended; the four audits are the manuscript-scale
# verification layer for the COHERENCE, PHYSICS, CHARACTER, and
# INTENT PRESERVATION domains. Opt-out is for tooling scenarios
# where the human reviewer is already running the equivalent
# check manually.
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*class_b_full_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "CANON VALIDATION SWEEP GATE: PASS (project-config.md declares class_b_full_status: skip — documented opt-out honored)"
        exit 0
    fi
fi

if [ ! -f "$SWEEP" ]; then
    echo "CANON VALIDATION SWEEP GATE: FAIL — no canon-validation-sweep.md present." >&2
    echo "ACTION: run Stage 9.5 Canon Validation Sweep before Phase 6 Delivery:" >&2
    echo "  bash scripts/validate-dispatcher.sh \"$PROJECT\" full" >&2
    echo "  (engine layer dispatches the four Class B subagents per the emitted" >&2
    echo "   CLASS_B_AUDIT marker lines; consolidated findings land at $SWEEP)" >&2
    echo "" >&2
    echo "ALTERNATIVELY (not recommended): append to $CONFIG:" >&2
    echo "  class_b_full_status: skip" >&2
    exit 1
fi

if [ ! -s "$SWEEP" ]; then
    echo "CANON VALIDATION SWEEP GATE: FAIL — canon-validation-sweep.md is zero bytes (hallucination guard)." >&2
    echo "  $SWEEP" >&2
    echo "ACTION: re-run Stage 9.5 Canon Validation Sweep so the sweep report" >&2
    echo "        actually contains the four Class B audit verdicts." >&2
    exit 1
fi

# Verdict-line check: the sweep report must carry one verdict line
# per Class B audit. We accept several formats so the engine can
# update the report's format over time without breaking the gate.
# Required markers (case-insensitive): each audit name appears
# alongside one of PASS / WARN / FAIL on the same line, OR the
# audit name appears as a section header followed by a verdict
# line within ~5 lines.
check_audit_verdict() {
    local name="$1"
    # Pattern 1: same-line verdict ("leitmotif-tracker: PASS" or
    # "| leitmotif-tracker | PASS |" or "leitmotif-tracker — verdict PASS").
    if grep -iE "${name}.*\b(PASS|WARN|FAIL)\b" "$SWEEP" >/dev/null 2>&1; then
        return 0
    fi
    # Pattern 2: section-header followed by verdict line within 5 lines.
    if grep -A5 -iE "^#+[[:space:]].*${name}" "$SWEEP" 2>/dev/null \
       | grep -iE "\b(PASS|WARN|FAIL)\b" >/dev/null 2>&1; then
        return 0
    fi
    return 1
}

REQUIRED_AUDITS="leitmotif-tracker injury-accumulation humanity-gate intent-preservation"
MISSING=""
for audit in $REQUIRED_AUDITS; do
    if ! check_audit_verdict "$audit"; then
        MISSING="$MISSING $audit"
    fi
done

if [ -n "$MISSING" ]; then
    echo "CANON VALIDATION SWEEP GATE: FAIL — canon-validation-sweep.md is missing verdict lines for:$MISSING" >&2
    echo "  $SWEEP" >&2
    echo "ACTION: re-run Stage 9.5 — the sweep report must carry a verdict line" >&2
    echo "        per Class B audit (leitmotif-tracker, injury-accumulation," >&2
    echo "        humanity-gate, intent-preservation)." >&2
    exit 1
fi

# Freshness check — the sweep must be newer than the most recent
# chapter file. Otherwise the sweep ran against an earlier draft
# state and a chapter has been rewritten since.
if [ -d "$CHAPTERS_DIR" ]; then
    NEWEST_CHAPTER_MTIME=0
    while IFS= read -r _chap; do
        _m=$(stat -c %Y "$_chap" 2>/dev/null || stat -f %m "$_chap" 2>/dev/null || echo 0)
        if [ "$_m" -gt "$NEWEST_CHAPTER_MTIME" ]; then NEWEST_CHAPTER_MTIME="$_m"; fi
    done < <(find "$CHAPTERS_DIR" -type f -name 'ch*.md')
    if [ -z "$NEWEST_CHAPTER_MTIME" ]; then
        NEWEST_CHAPTER_MTIME=0
    fi
    SWEEP_MTIME=$(stat -c %Y "$SWEEP" 2>/dev/null || stat -f %m "$SWEEP" 2>/dev/null || echo 0)
    if [ "$SWEEP_MTIME" -lt "$NEWEST_CHAPTER_MTIME" ]; then
        echo "CANON VALIDATION SWEEP GATE: FAIL — sweep report is stale (mtime older than most recent chapter — manuscript changed since the sweep ran)." >&2
        echo "  sweep:           $SWEEP" >&2
        echo "  newest chapter:  $CHAPTERS_DIR" >&2
        echo "ACTION: re-run Stage 9.5 Canon Validation Sweep against the current manuscript state." >&2
        exit 1
    fi
fi

echo "CANON VALIDATION SWEEP GATE: PASS — sweep report present, complete (4/4 audit verdicts), and fresh"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
