#!/bin/bash
# ============================================================
# Ideorix — Create Project Tree (v2.7.91, mirrored)
#
# Deterministically creates the standard project directory tree
# at "Start New Project". The Setup flow in SKILL.md previously
# relied on LLM-contract "Create the project folder structure"
# instructions; pilots showed orchestrators skipping that step
# under context pressure, leaving the user without a workspace
# until they manually directed the LLM to create it.
#
# This script makes the operation deterministic: one invocation,
# the tree is on disk, the project root path is printed on
# stdout for the orchestrator to capture.
#
# Tree layout (standalone):
#
#   {root}/{title}/
#   ├── manuscript/
#   ├── marketing/
#   ├── engine-data/
#   │   ├── reports/
#   │   ├── chapters/
#   │   ├── summaries/
#   │   └── revisions/
#   └── project-config.md
#
# Tree layout (series):
#
#   {root}/{series}/
#   ├── series-data/         ← shared series-level planning
#   └── {title}/             ← this book's workspace (same tree as standalone)
#
# Idempotent. On a re-run:
#   - directories are mkdir -p (no-op if present)
#   - project-config.md is NOT overwritten if it already exists
#     (preserves any orchestrator-added Mode / Genre / Format fields)
#
# Usage:
#   bash create-project-tree.sh <title>
#   bash create-project-tree.sh <title> --series=<series-name>
#   bash create-project-tree.sh <title> --root=<override-path>
#
# Stdout: project root path (single line, no trailing whitespace).
# Stderr: progress messages.
#
# Exit codes:
#   0  tree created (or already existed; idempotent)
#   1  unrecoverable error (cannot create directory, etc.)
#   2  invalid arguments
# ============================================================

set -euo pipefail

if [ $# -lt 1 ]; then
    echo "Usage: create-project-tree.sh <title> [--series=<name>] [--root=<path>]" >&2
    exit 2
fi

TITLE="$1"
shift

if [ -z "$TITLE" ]; then
    echo "ERROR: title is required and must be non-empty" >&2
    exit 2
fi

SERIES=""
# Cross-platform home resolution: $HOME on Linux/macOS; $USERPROFILE on
# Windows (Claude Desktop / Git-Bash where $HOME may be empty). If both
# are empty the caller MUST pass --root explicitly.
HOME_DIR="${HOME:-${USERPROFILE:-}}"
ROOT="$HOME_DIR/Documents/Ideorix-Projects"

for arg in "$@"; do
    case "$arg" in
        --series=*) SERIES="${arg#--series=}" ;;
        --root=*)   ROOT="${arg#--root=}" ;;
        *)
            echo "ERROR: unknown argument: $arg" >&2
            echo "Usage: create-project-tree.sh <title> [--series=<name>] [--root=<path>]" >&2
            exit 2
            ;;
    esac
done

# Guard: if neither $HOME nor $USERPROFILE resolved AND no --root was
# passed, ROOT begins with "/Documents/..." — a broken path. Fail loudly
# rather than silently creating the tree in the wrong place.
case "$ROOT" in
    /Documents/*)
        echo "ERROR: could not resolve a home directory (\$HOME and \$USERPROFILE both empty)." >&2
        echo "       Pass an explicit location: create-project-tree.sh <title> --root=<absolute-path>" >&2
        exit 2
        ;;
esac

if [ -n "$SERIES" ]; then
    SERIES_ROOT="$ROOT/$SERIES"
    PROJECT_ROOT="$SERIES_ROOT/$TITLE"
    mkdir -p "$SERIES_ROOT/series-data" \
        || { echo "ERROR: cannot create $SERIES_ROOT/series-data" >&2; exit 1; }
    echo "INFO: series root: $SERIES_ROOT" >&2
else
    PROJECT_ROOT="$ROOT/$TITLE"
fi

mkdir -p \
    "$PROJECT_ROOT/manuscript" \
    "$PROJECT_ROOT/marketing" \
    "$PROJECT_ROOT/engine-data/reports" \
    "$PROJECT_ROOT/engine-data/chapters" \
    "$PROJECT_ROOT/engine-data/summaries" \
    "$PROJECT_ROOT/engine-data/revisions" \
    || { echo "ERROR: cannot create project tree under $PROJECT_ROOT" >&2; exit 1; }

CONFIG="$PROJECT_ROOT/project-config.md"
if [ ! -f "$CONFIG" ]; then
    {
        echo "# Project: $TITLE"
        echo ""
        echo "Created: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "Status: Awaiting manuscript"
        if [ -n "$SERIES" ]; then
            echo "Series: $SERIES"
        fi
        echo ""
        echo "<!-- Orchestrator: append engine-specific fields below as needed -->"
        echo "<!--   Mode: Writers Studio | Full Creative Suite | Screen Studio -->"
        echo "<!--   Genre: <genre slot>  (fiction) -->"
        echo "<!--   NF Category: <category slot>  (non-fiction) -->"
        echo "<!--   formatting_mode: ai | human   (Writers Studio imports) -->"
        echo "<!--   handoff_status: skip          (documented opt-out only) -->"
    } > "$CONFIG"
    echo "INFO: wrote $CONFIG" >&2
else
    echo "INFO: $CONFIG already exists — preserved (no overwrite)" >&2
fi

echo "$PROJECT_ROOT"
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
