#!/bin/bash
# ============================================================
# Ideorix — Catalog Report Renderer
# Converts a markdown Catalog Report to .docx and/or .pdf via pandoc.
# Markdown is the canonical artifact; .docx/.pdf are conveniences.
# Graceful fallback: if pandoc is missing, save .md only with a one-
# line install hint per platform.
# ============================================================
# Usage: bash catalog-render.sh <input.md> <format> [output-dir] [mode]
#   <format>: md | docx | pdf | all
#   [output-dir]: defaults to ~/Documents/Ideorix-Projects/_catalog-reports/
#   [mode]: catalog (default) | sales-summary
#     - catalog        -> {YYYY-MM-DD}_catalog-overview.{ext}
#                         template: catalog-report-template.docx
#     - sales-summary  -> {YYYY-MM-DD}_sales-summary.{ext}
#                         template: sales-summary-template.docx
#
# The mode argument changes only the output basename and the .docx
# reference template. The input markdown is whatever the caller
# (Catalog Overview's render stage) feeds in — full report or
# sales-only — so the script stays content-agnostic.
#
# Exit codes:
#   0  success (any requested format produced, possibly with
#      pandoc-fallback to md only)
#   1  invalid arguments
#   2  input file missing or unreadable
#   3  output directory cannot be created/written
# ============================================================

set -euo pipefail

INPUT="${1:-}"
FORMAT="${2:-}"
# Cross-platform home resolution: $HOME on Linux/macOS; $USERPROFILE on
# Windows (where $HOME may be empty). Caller may override with arg 3.
HOME_DIR="${HOME:-${USERPROFILE:-}}"
OUTPUT_DIR="${3:-$HOME_DIR/Documents/Ideorix-Projects/_catalog-reports}"
MODE="${4:-catalog}"

if [ -z "$INPUT" ] || [ -z "$FORMAT" ]; then
    echo "Usage: bash catalog-render.sh <input.md> <format> [output-dir] [mode]" >&2
    echo "  format: md | docx | pdf | all" >&2
    echo "  mode:   catalog (default) | sales-summary" >&2
    exit 1
fi

case "$FORMAT" in
    md|docx|pdf|all) ;;
    *)
        echo "ERROR: unknown format '$FORMAT' — must be md, docx, pdf, or all" >&2
        exit 1
        ;;
esac

case "$MODE" in
    catalog|sales-summary) ;;
    *)
        echo "ERROR: unknown mode '$MODE' — must be catalog or sales-summary" >&2
        exit 1
        ;;
esac

if [ ! -f "$INPUT" ] || [ ! -r "$INPUT" ]; then
    echo "ERROR: input file not found or unreadable: $INPUT" >&2
    exit 2
fi

if ! mkdir -p "$OUTPUT_DIR" 2>/dev/null; then
    echo "ERROR: cannot create output directory: $OUTPUT_DIR" >&2
    exit 3
fi
if [ ! -w "$OUTPUT_DIR" ]; then
    echo "ERROR: output directory not writable: $OUTPUT_DIR" >&2
    exit 3
fi

DATE_STAMP=$(date +%Y-%m-%d)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$MODE" = "sales-summary" ]; then
    BASENAME="${DATE_STAMP}_sales-summary"
    TEMPLATE="$SCRIPT_DIR/sales-summary-template.docx"
else
    BASENAME="${DATE_STAMP}_catalog-overview"
    TEMPLATE="$SCRIPT_DIR/catalog-report-template.docx"
fi

# Pandoc detection. The .md path never depends on pandoc.
HAVE_PANDOC=0
if command -v pandoc >/dev/null 2>&1; then
    HAVE_PANDOC=1
fi

install_hint() {
    case "$(uname -s)" in
        Darwin) echo "  Install hint: brew install pandoc" ;;
        Linux)
            if command -v apt >/dev/null 2>&1; then
                echo "  Install hint: sudo apt install pandoc"
            elif command -v dnf >/dev/null 2>&1; then
                echo "  Install hint: sudo dnf install pandoc"
            else
                echo "  Install hint: see https://pandoc.org/installing.html"
            fi
            ;;
        MINGW*|MSYS*|CYGWIN*) echo "  Install hint: winget install pandoc" ;;
        *) echo "  Install hint: see https://pandoc.org/installing.html" ;;
    esac
}

write_md() {
    local out="$OUTPUT_DIR/${BASENAME}.md"
    cp "$INPUT" "$out"
    echo "  wrote $out"
}

write_docx() {
    if [ "$HAVE_PANDOC" -ne 1 ]; then
        echo "  pandoc not installed — cannot produce .docx"
        install_hint
        return 1
    fi
    local out="$OUTPUT_DIR/${BASENAME}.docx"
    local args=(-f markdown -t docx -o "$out")
    if [ -f "$TEMPLATE" ]; then
        args+=(--reference-doc="$TEMPLATE")
    fi
    pandoc "${args[@]}" "$INPUT"
    echo "  wrote $out"
}

write_pdf() {
    if [ "$HAVE_PANDOC" -ne 1 ]; then
        echo "  pandoc not installed — cannot produce .pdf"
        install_hint
        return 1
    fi
    local out="$OUTPUT_DIR/${BASENAME}.pdf"
    if pandoc -f markdown -t pdf -o "$out" "$INPUT" 2>/dev/null; then
        echo "  wrote $out"
        return 0
    fi
    if command -v wkhtmltopdf >/dev/null 2>&1; then
        if pandoc -f markdown -t pdf --pdf-engine=wkhtmltopdf -o "$out" "$INPUT" 2>/dev/null; then
            echo "  wrote $out (via wkhtmltopdf)"
            return 0
        fi
    fi
    echo "  pandoc could not produce .pdf — LaTeX engine likely missing and wkhtmltopdf fallback failed"
    echo "  Tip: install a LaTeX distribution (TeX Live or MiKTeX) or wkhtmltopdf"
    return 1
}

if [ "$MODE" = "sales-summary" ]; then
    echo "Sales Summary renderer"
else
    echo "Catalog Report renderer"
fi
echo "  input:  $INPUT"
echo "  format: $FORMAT"
echo "  output: $OUTPUT_DIR/"
echo "  mode:   $MODE"
echo ""

PRODUCED_ANY=0
case "$FORMAT" in
    md)   write_md && PRODUCED_ANY=1 ;;
    docx) write_docx && PRODUCED_ANY=1 || true ;;
    pdf)  write_pdf  && PRODUCED_ANY=1 || true ;;
    all)
        write_md && PRODUCED_ANY=1
        write_docx || true
        write_pdf  || true
        ;;
esac

if [ "$PRODUCED_ANY" -ne 1 ] && [ "$FORMAT" != "md" ]; then
    echo ""
    echo "Falling back to markdown only."
    write_md
fi

echo ""
echo "Done."
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
