#!/bin/bash
# ============================================================
# Ideorix — Screenplay Audit (v2.7.101)
# Deterministic screen-format scanner. The mechanical backstop
# for the Pre-Delivery AI-Tell Sweep in screenplay-protocol.md,
# which until now was a 100% LLM self-audit contract with zero
# backing scripts (the prose pipeline ships 6 deterministic
# scanners; the screen pipeline shipped 0). This closes that
# asymmetry for the mechanically-checkable subset.
#
# Mirrors forbidden-words-scan.sh in spirit: a Fountain-aware
# classifier followed by four deterministic checks, each named
# explicitly in screenplay-protocol.md's "Enforcement model
# (honest)" note:
#   1. Slugline grammar      (Pass 1)
#   2. Banned-substring scan (Pass 2 AI-tells + Pass 3 camera /
#                             editorialising / future-tense)
#   3. Adverb-per-page count (Pass 3: >2 per page → flag)
#   4. CAPS-per-page count   (emphasis-CAPS overuse in action)
# ============================================================
# Usage:
#   bash screenplay-audit.sh <screenplay.fountain>
#   bash screenplay-audit.sh <screenplay.fountain> --adverb-threshold 2
#   bash screenplay-audit.sh <screenplay.fountain> --caps-threshold 5
#   bash screenplay-audit.sh <screenplay.fountain> --lines-per-page 55
#
# Output: a per-check report. Findings are surfaced via
#   STATUS: WARN (advisory, matching consecutive-opener-scan.sh)
#   so the run never auto-fails an already-approved screenplay;
#   the LLM Pre-Delivery contract remains the delivery gate.
#
# Exit codes:
#   0  scan completed (clean OR findings — findings are WARN)
#   2  invalid arguments / missing file
#
# Honest limits:
# - The Fountain classifier is heuristic (no full parse). Forced
#   elements, dual dialogue, and unconventional formatting may
#   misclassify a line; findings cite line numbers for review.
# - CAPS density counts ALL standalone all-caps tokens in action,
#   which legitimately includes character introductions
#   (SARAH CHEN) and shooting-script SOUND cues (A GUNSHOT). The
#   check flags OVERUSE density, not individual tokens;
#   classification of any single token is the reader's call.
# - Adverb detection is suffix-based (-ly) with a small stoplist
#   of common non-adverbs; rare non-adverb -ly words may slip
#   through and are reviewable in the output.
# ============================================================

set -uo pipefail

SCREENPLAY=""
ADVERB_THRESHOLD=2
CAPS_THRESHOLD=5
LINES_PER_PAGE=55

while [ $# -gt 0 ]; do
    case "$1" in
        --adverb-threshold)
            ADVERB_THRESHOLD="${2:-2}"
            shift 2
            ;;
        --caps-threshold)
            CAPS_THRESHOLD="${2:-5}"
            shift 2
            ;;
        --lines-per-page)
            LINES_PER_PAGE="${2:-55}"
            shift 2
            ;;
        --help|-h)
            sed -n '/^# Usage:/,/^# =====/p' "$0" | sed 's/^# //; s/^#//'
            exit 0
            ;;
        *)
            if [ -z "$SCREENPLAY" ]; then
                SCREENPLAY="$1"
            fi
            shift
            ;;
    esac
done

if [ -z "$SCREENPLAY" ]; then
    echo "Usage: screenplay-audit.sh <screenplay.fountain> [--adverb-threshold N] [--caps-threshold N] [--lines-per-page N]" >&2
    exit 2
fi

if [ ! -f "$SCREENPLAY" ]; then
    echo "ERROR: file not found: $SCREENPLAY" >&2
    exit 2
fi

if ! [[ "$ADVERB_THRESHOLD" =~ ^[0-9]+$ ]]; then
    echo "ERROR: --adverb-threshold must be a non-negative integer (got: $ADVERB_THRESHOLD)" >&2
    exit 2
fi

if ! [[ "$CAPS_THRESHOLD" =~ ^[0-9]+$ ]]; then
    echo "ERROR: --caps-threshold must be a non-negative integer (got: $CAPS_THRESHOLD)" >&2
    exit 2
fi

if ! [[ "$LINES_PER_PAGE" =~ ^[0-9]+$ ]] || [ "$LINES_PER_PAGE" -lt 1 ]; then
    echo "ERROR: --lines-per-page must be an integer >= 1 (got: $LINES_PER_PAGE)" >&2
    exit 2
fi

python3 - "$SCREENPLAY" "$ADVERB_THRESHOLD" "$CAPS_THRESHOLD" "$LINES_PER_PAGE" <<'PYTHON'
import re
import sys
import math

path = sys.argv[1]
adverb_threshold = int(sys.argv[2])
caps_threshold = int(sys.argv[3])
lines_per_page = int(sys.argv[4])

try:
    with open(path, encoding='utf-8') as f:
        raw = f.read()
except Exception as e:
    print(f"ERROR: could not read {path}: {e}", file=sys.stderr)
    sys.exit(2)

lines = raw.split('\n')

# ---- Strip a leading Fountain title-page block (Key: Value pairs
# before the first blank line). Conservative: only if the very first
# non-empty line looks like a title-page key.
start = 0
if lines:
    first_nonblank = next((i for i, l in enumerate(lines) if l.strip()), None)
    if first_nonblank is not None and re.match(r'^[A-Z][A-Za-z ]+:\s', lines[first_nonblank]):
        # find first blank line after the key block
        j = first_nonblank
        while j < len(lines) and lines[j].strip():
            j += 1
        start = j

body = lines[start:]
body_line_count = sum(1 for l in body if l.strip())
pages = max(1, math.ceil(body_line_count / lines_per_page))

# ---- Fountain-aware line classifier ----
SLUG_RE = re.compile(r'^(INT|EXT|INT\.?/EXT|EXT\.?/INT|I/E)[\.\s]', re.IGNORECASE)
FORCED_SLUG_RE = re.compile(r'^\.[A-Za-z0-9]')
TRANS_TO_RE = re.compile(r'\bTO:\s*$')
TRANS_SET = {'FADE IN:', 'FADE OUT.', 'FADE TO BLACK.', 'CUT TO BLACK.', 'THE END'}
PAREN_RE = re.compile(r'^\(.*\)$')
# A character cue: optional @, then a token that is all-caps (letters), maybe
# multiword, optional (V.O.)/(O.S.)/(CONT'D)/(40s) suffix.
CUE_RE = re.compile(r"^@?[A-Z][A-Z0-9 .'\-]*(\s*\([^)]*\))?$")

def is_blank(s):
    return not s.strip()

# Build a typed list. Stateful: a cue starts a dialogue block until blank line.
typed = []  # (line_number_1based, type, text)
in_dialogue = False
for idx, line in enumerate(body, start=start + 1):
    s = line.strip()
    if is_blank(s):
        in_dialogue = False
        continue
    # Fountain boilerplate we never scan
    if s.startswith('#') or s.startswith('='):
        in_dialogue = False
        continue
    if s.startswith('>') and s.endswith('<'):  # centered
        in_dialogue = False
        continue
    # Transitions
    if s.startswith('>') or TRANS_TO_RE.search(s) or s in TRANS_SET:
        typed.append((idx, 'transition', s))
        in_dialogue = False
        continue
    # Sluglines
    if SLUG_RE.match(s) or FORCED_SLUG_RE.match(s):
        typed.append((idx, 'slugline', s))
        in_dialogue = False
        continue
    # Parentheticals inside a dialogue block
    if in_dialogue and PAREN_RE.match(s):
        typed.append((idx, 'parenthetical', s))
        continue
    # Dialogue continuation
    if in_dialogue:
        typed.append((idx, 'dialogue', s))
        continue
    # Character cue: all-caps line that opens a dialogue block. Require the
    # alphabetic content to equal its own uppercase (so "Sarah" is not a cue)
    # and that it is short-ish (cues are not full action sentences).
    letters = re.sub(r'[^A-Za-z]', '', re.sub(r'\([^)]*\)', '', s))
    if (letters and letters == letters.upper() and CUE_RE.match(s)
            and len(s) <= 40):
        typed.append((idx, 'character', s))
        in_dialogue = True
        continue
    # Everything else is action
    typed.append((idx, 'action', s))

action_lines = [(n, t) for (n, ty, t) in typed if ty == 'action']
slugline_lines = [(n, t) for (n, ty, t) in typed if ty == 'slugline']

findings = {'slugline': [], 'banned': [], 'adverb': [], 'caps': []}

# ---- Check 1: slugline grammar ----
PERMITTED_TIME = (r'(DAY|NIGHT|CONTINUOUS|MOMENTS LATER|LATER|SAME|DAWN|DUSK|'
                  r'MORNING|AFTERNOON|EVENING|MAGIC HOUR)')
SLUG_OK_RE = re.compile(
    r'^(INT|EXT|INT\.?/EXT|EXT\.?/INT|I/E)\.?\s+.+\s+-\s+' + PERMITTED_TIME + r'\b',
    re.IGNORECASE)
for n, t in slugline_lines:
    if FORCED_SLUG_RE.match(t):
        continue  # forced sluglines (.LIKE THIS) are author-intentional; skip
    if not SLUG_OK_RE.match(t):
        if ' - ' not in t and ' — ' not in t:
            reason = "missing ' - TIME-OF-DAY'"
        else:
            reason = "non-standard time-of-day or malformed prefix"
        findings['slugline'].append((n, t, reason))

# ---- Check 2: banned substrings in action (AI-tells + camera/editorialising) ----
BANNED = [
    r'the timing of', r'the economy of', r'the care of', r'the precision of',
    r'the weight of (a|an|someone|her|his|its|their)',
    r'the shape of (a|an|someone|her|his|its|their)',
    r"there is something", r"there's something",
    r'as if (she|he|they|it) (had|has been|had been)',
    r'in a way that (suggests|implies|hints|indicates)',
    r'the kind of (woman|man|person|silence|look|smile|stillness) (that|who)',
    # Pass 3 camera-direction smuggling
    r'we focus on', r'we see', r'we hear', r'the camera lingers',
    r'our eye is drawn',
    # Pass 3 future-tense markers
    r'would later', r'if (she|he|they) had known', r'the last time',
    r"as we'll see", r'what was about to',
    # Pass 3 editorialising sentence-starters
    r'^(surprisingly|of course|amazingly|interestingly|tragically)\b',
    # Pass 3 inference clauses
    r'\b(shows that|suggesting|implying|indicating that)\b',
]
BANNED_RE = [re.compile(p, re.IGNORECASE) for p in BANNED]
for n, t in action_lines:
    for rx in BANNED_RE:
        m = rx.search(t)
        if m:
            findings['banned'].append((n, t, m.group(0)))

# ---- Check 3: adverb density in action ----
ADVERB_STOPLIST = {
    'only', 'family', 'reply', 'apply', 'supply', 'rely', 'ally', 'july',
    'italy', 'holy', 'ugly', 'early', 'fly', 'ply', 'imply', 'multiply',
    'comply', 'belly', 'rally', 'really'  # 'really' kept out: it's a true
    # adverb but so common it skews; documented heuristic
}
adverb_hits = []
for n, t in action_lines:
    for w in re.findall(r"[A-Za-z]+ly\b", t):
        if w.lower() in ADVERB_STOPLIST:
            continue
        adverb_hits.append((n, w))
adverb_density = len(adverb_hits) / pages
if adverb_density > adverb_threshold:
    findings['adverb'] = adverb_hits

# ---- Check 4: CAPS density in action ----
caps_hits = []
for n, t in action_lines:
    for w in re.findall(r'\b[A-Z]{2,}\b', t):
        caps_hits.append((n, w))
caps_density = len(caps_hits) / pages
if caps_density > caps_threshold:
    findings['caps'] = caps_hits

# ---- Report ----
total_findings = (len(findings['slugline']) + len(findings['banned'])
                  + (1 if findings['adverb'] else 0)
                  + (1 if findings['caps'] else 0))

print(f"SCREENPLAY AUDIT: {path}")
print(f"Body: {body_line_count} non-blank lines (~{pages} page(s) @ {lines_per_page} lines/page)")
print(f"Classified: {len(slugline_lines)} slugline(s), {len(action_lines)} action line(s)")
print()

if total_findings:
    print("STATUS: WARN")
    print()

# Check 1 report
if findings['slugline']:
    print(f"-- Slugline grammar -- WARN ({len(findings['slugline'])} malformed)")
    for n, t, reason in findings['slugline']:
        print(f"   line {n}: {t!r} — {reason}")
else:
    print(f"-- Slugline grammar -- PASS ({len(slugline_lines)} slugline(s) well-formed)")
print()

# Check 2 report
if findings['banned']:
    print(f"-- Banned substrings (AI-tell / camera / editorialising) -- WARN ({len(findings['banned'])} hit(s))")
    for n, t, phrase in findings['banned']:
        print(f"   line {n}: matched {phrase!r}")
else:
    print("-- Banned substrings (AI-tell / camera / editorialising) -- PASS")
print()

# Check 3 report
if findings['adverb']:
    print(f"-- Adverb density -- WARN ({len(adverb_hits)} -ly in action, "
          f"{adverb_density:.1f}/page > {adverb_threshold}/page)")
    shown = adverb_hits[:20]
    for n, w in shown:
        print(f"   line {n}: {w}")
    if len(adverb_hits) > len(shown):
        print(f"   ... and {len(adverb_hits) - len(shown)} more")
else:
    print(f"-- Adverb density -- PASS ({adverb_density:.1f} -ly per page <= {adverb_threshold})")
print()

# Check 4 report
if findings['caps']:
    print(f"-- CAPS density -- WARN ({len(caps_hits)} all-caps tokens in action, "
          f"{caps_density:.1f}/page > {caps_threshold}/page)")
    print("   (note: includes legit character intros + shooting-script SOUND cues)")
    shown = caps_hits[:20]
    for n, w in shown:
        print(f"   line {n}: {w}")
    if len(caps_hits) > len(shown):
        print(f"   ... and {len(caps_hits) - len(shown)} more")
else:
    print(f"-- CAPS density -- PASS ({caps_density:.1f} all-caps tokens per page <= {caps_threshold})")
print()

if total_findings:
    print(f"SCREENPLAY AUDIT: WARN ({total_findings} finding group(s) across 4 checks — advisory)")
else:
    print("SCREENPLAY AUDIT: PASS (all 4 checks clean)")

sys.exit(0)
PYTHON
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
