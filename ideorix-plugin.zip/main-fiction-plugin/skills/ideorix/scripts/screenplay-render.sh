#!/bin/bash
# ============================================================
# Ideorix — Screenplay DOCX Renderer (entry point, v2.7.131)
#
# Canonical screenplay-to-DOCX export. The counterpart to
# manuscript-render.sh (novels): converts a project's Fountain
# screenplay into an industry-layout .docx via the bundled
# Python-stdlib renderer screenplay-render.py — no external
# package, no `npm`/`pip install`, no hand-written generator.
#
# Resolves the Fountain source from (first match wins):
#   <project>/deliverables/*.fountain
#   <project>/screenplay/*.fountain
#   <project>/*.fountain
# or accepts a direct path to a .fountain file.
#
# Output defaults to <project>/deliverables/{name}.docx and is
# checked with docx-integrity-check.sh.
#
# Usage:
#   screenplay-render.sh <project_root | file.fountain> [--output <path>]
#
# Exit codes: 0 ok · 2 usage / no fountain / python3 absent · 5 integrity fail
# ============================================================

set -uo pipefail

ARG="${1:-}"
OUTPUT=""
shift 2>/dev/null || true
while [ $# -gt 0 ]; do
    case "$1" in
        --output) OUTPUT="${2:-}"; shift 2 ;;
        --output=*) OUTPUT="${1#--output=}"; shift ;;
        *) shift ;;
    esac
done

if [ -z "$ARG" ]; then
    echo "ERROR: usage: screenplay-render.sh <project_root | file.fountain> [--output <path>]" >&2
    exit 2
fi

# Resolve the fountain source.
FOUNTAIN=""
if [ -f "$ARG" ]; then
    FOUNTAIN="$ARG"
elif [ -d "$ARG" ]; then
    for d in "$ARG/deliverables" "$ARG/screenplay" "$ARG"; do
        [ -d "$d" ] || continue
        for f in "$d"/*.fountain; do
            [ -f "$f" ] && { FOUNTAIN="$f"; break; }
        done
        [ -n "$FOUNTAIN" ] && break
    done
fi

if [ -z "$FOUNTAIN" ] || [ ! -f "$FOUNTAIN" ]; then
    echo "SKIP: no .fountain source found for '$ARG'" >&2
    exit 2
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "ERROR: python3 not found — required for the screenplay renderer." >&2
    echo "       Install python3, or (last resort only) hand-write a generator" >&2
    echo "       bash-direct per format-docx.md § Screenplay DOCX Layout." >&2
    exit 2
fi

# Default output: <project>/deliverables/{name}.docx (or beside the fountain).
if [ -z "$OUTPUT" ]; then
    base="$(basename "$FOUNTAIN" .fountain)"
    if [ -d "$ARG" ]; then
        mkdir -p "$ARG/deliverables" 2>/dev/null || true
        OUTPUT="$ARG/deliverables/$base.docx"
    else
        OUTPUT="$(dirname "$FOUNTAIN")/$base.docx"
    fi
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$SCRIPT_DIR/screenplay-render.py" "$FOUNTAIN" --output "$OUTPUT" || {
    echo "ERROR: screenplay render failed" >&2; exit 2; }

# Post-write integrity check (same gate as the novel renderer).
INTEGRITY="$SCRIPT_DIR/docx-integrity-check.sh"
if [ -f "$INTEGRITY" ]; then
    if bash "$INTEGRITY" "$OUTPUT" >/dev/null 2>&1; then
        echo "[screenplay-render] OK + integrity check passed: $OUTPUT"
    else
        echo "ERROR: integrity check FAILED on $OUTPUT" >&2
        exit 5
    fi
else
    echo "[screenplay-render] wrote $OUTPUT (integrity-check script not found)"
fi
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
