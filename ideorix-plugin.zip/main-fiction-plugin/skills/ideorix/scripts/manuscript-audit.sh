#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 9: Manuscript-Wide Audit
# Aggregates per-chapter counts across the full manuscript.
# Tracks running totals, Chekhov gun status, cross-chapter
# pattern density, and produces a cumulative report.
# ============================================================
# Usage: bash manuscript-audit.sh <chapters-dir> <project-path> [word-target]
# chapters-dir: path containing ch01.md, ch02.md, etc.

set -euo pipefail

CHAPTERS_DIR="${1:?Usage: manuscript-audit.sh <chapters-dir> <project-path> [word-target]}"
# Validate caller passes <project-path> even though this script's current
# pass doesn't read it; the arg is reserved for future cross-chapter project
# context lookups (e.g. forbidden-words.md location, entity-canon.md).
: "${2:?Usage: manuscript-audit.sh <chapters-dir> <project-path>}"
WORD_TARGET="${3:-2500}"

if [ ! -d "$CHAPTERS_DIR" ]; then echo "ERROR: Chapters directory not found: $CHAPTERS_DIR"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

CHAPTER_FILES=$(ls "$CHAPTERS_DIR"/ch*.md 2>/dev/null | sort)
CHAPTER_COUNT=$(echo "$CHAPTER_FILES" | grep -c "\.md$" || echo 0)

if [ "$CHAPTER_COUNT" -eq 0 ]; then
    echo "ERROR: No chapter files found in $CHAPTERS_DIR"
    exit 1
fi

TOTAL_WORDS=0
TOTAL_NARR_EMDASH=0
TOTAL_DIAL_EMDASH=0
TOTAL_THE_WAY=0
TOTAL_KIND_OF=0
TOTAL_PARTICULAR=0
TOTAL_WHICH_WAS=0
TOTAL_FILED=0

safe_count() { local c; c=$(eval "$1" 2>/dev/null) || true; echo "${c:-0}" | tr -dc '0-9'; }

echo "╔══════════════════════════════════════════════════════════╗"
echo "║  IDEORIX MANUSCRIPT-WIDE AUDIT"
echo "║  Chapters: $CHAPTER_COUNT"
echo "║  Directory: $CHAPTERS_DIR"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Per-chapter scan
echo "=== PER-CHAPTER COUNTS ==="
printf "%-6s %6s %5s %5s %5s %5s %5s %5s %5s\n" "Ch" "Words" "N-em" "D-em" "t-way" "kind" "partic" "w-was" "filed"
echo "--------------------------------------------------------------"

for chapter in $CHAPTER_FILES; do
    if [ ! -r "$chapter" ]; then
        echo "ERROR: chapter not readable: $chapter" >&2
        exit 1
    fi
    CH_NAME=$(basename "$chapter" .md)
    tr '[:upper:]' '[:lower:]' < "$chapter" > "$TMPDIR/ch_lower.txt"

    WORDS=$(wc -w < "$chapter")
    TOTAL_WORDS=$((TOTAL_WORDS + WORDS))

    # Strip YAML front matter (between opening and closing ---) and markdown headings.
    # Then normalize em-dash family imposters to U+2014. Some authoring tools
    # (Pages in some locales, certain markdown editors, copy-paste from formatted
    # web pages / PDFs) insert U+2015 HORIZONTAL BAR or other em-dash variants
    # that look identical to U+2014 but aren't matched by a literal `—` regex.
    # Without normalization, narration em-dashes in such chapters silently miss
    # the audit and ship as 0-count PASS (real-world v2.4.2 false negative).
    awk 'BEGIN{fm=0} /^---$/{fm++; next} fm==1{next} /^#/{next} {print}' "$chapter" \
        | perl -CSDA -pe 's/[\x{2015}\x{2E3A}\x{2E3B}\x{FE58}]/\x{2014}/g' \
        > "$TMPDIR/ch_body.txt"

    # Extract dialogue spans (between matching straight " ... " or curly " ... "
    # or curly ' ... '). Em-dashes inside dialogue do NOT count toward narration.
    perl -CSDA -ne '
        while (/[\x{201C}"]([^\x{201D}"]*)[\x{201D}"]/g) { print "$1\n" }
        while (/[\x{2018}]([^\x{2019}]*)[\x{2019}]/g)    { print "$1\n" }
    ' "$TMPDIR/ch_body.txt" > "$TMPDIR/ch_dial.txt" 2>/dev/null || true

    # Strip dialogue spans — what remains is narration.
    perl -CSDA -pe '
        s/[\x{201C}"][^\x{201D}"]*[\x{201D}"]//g;
        s/[\x{2018}][^\x{2019}]*[\x{2019}]//g;
    ' "$TMPDIR/ch_body.txt" > "$TMPDIR/ch_narr.txt" 2>/dev/null || true

    # Narration em-dashes (span-extracted, not line-based)
    N_EM=$(safe_count "grep -o '—' '$TMPDIR/ch_narr.txt' | wc -l")
    TOTAL_NARR_EMDASH=$((TOTAL_NARR_EMDASH + N_EM))

    # Dialogue em-dashes (span-extracted, not line-based)
    D_EM=$(safe_count "grep -o '—' '$TMPDIR/ch_dial.txt' | wc -l")
    TOTAL_DIAL_EMDASH=$((TOTAL_DIAL_EMDASH + D_EM))

    # "the way [pronoun]"
    TW=$(safe_count "grep -cE 'the way (she|he|they|it|i|we|you) ' '$TMPDIR/ch_lower.txt'")
    TOTAL_THE_WAY=$((TOTAL_THE_WAY + TW))

    # "the kind/sort/type of [X] that"
    KO=$(safe_count "grep -cE '(the kind of|the sort of|the type of|one of those) .* that' '$TMPDIR/ch_lower.txt'")
    TOTAL_KIND_OF=$((TOTAL_KIND_OF + KO))

    # "the particular [X] that/of"
    PA=$(safe_count "grep -cE 'the particular .* (that|of) ' '$TMPDIR/ch_lower.txt'")
    TOTAL_PARTICULAR=$((TOTAL_PARTICULAR + PA))

    # "which was/were"
    WW=$(safe_count "grep -cE 'which (was|were) ' '$TMPDIR/ch_lower.txt'")
    TOTAL_WHICH_WAS=$((TOTAL_WHICH_WAS + WW))

    # "filed"
    FI=$(safe_count "grep -cE '\bfiled\b' '$TMPDIR/ch_lower.txt'")
    TOTAL_FILED=$((TOTAL_FILED + FI))

    printf "%-6s %6d %5d %5d %5d %5d %5d %5d %5d\n" "$CH_NAME" "$WORDS" "$N_EM" "$D_EM" "$TW" "$KO" "$PA" "$WW" "$FI"
done

echo "--------------------------------------------------------------"
printf "%-6s %6d %5d %5d %5d %5d %5d %5d %5d\n" "TOTAL" "$TOTAL_WORDS" "$TOTAL_NARR_EMDASH" "$TOTAL_DIAL_EMDASH" "$TOTAL_THE_WAY" "$TOTAL_KIND_OF" "$TOTAL_PARTICULAR" "$TOTAL_WHICH_WAS" "$TOTAL_FILED"

echo ""
echo "=== MANUSCRIPT-WIDE CAPS ==="

FAIL=0

check_cap() {
    local label="$1" actual="$2" cap="$3"
    if [ "$actual" -gt "$cap" ]; then
        printf "  %-40s %4d / %-4d  FAIL\n" "$label" "$actual" "$cap"
        FAIL=1
    else
        printf "  %-40s %4d / %-4d  PASS\n" "$label" "$actual" "$cap"
    fi
}

check_cap "Narration em-dashes (target: 0)" "$TOTAL_NARR_EMDASH" 0
check_cap "Dialogue em-dashes (≤3 per chapter)" "$TOTAL_DIAL_EMDASH" $((CHAPTER_COUNT * 3))
check_cap "\"the way [pronoun]\" (≤6 per ms)" "$TOTAL_THE_WAY" 6
check_cap "\"the kind/sort of [X] that\" (≤3 per ms)" "$TOTAL_KIND_OF" 3
check_cap "\"the particular\" (0 — zero tolerance)" "$TOTAL_PARTICULAR" 0
check_cap "\"which was/were\" (≤2/ch, max $((CHAPTER_COUNT * 2)) total)" "$TOTAL_WHICH_WAS" $((CHAPTER_COUNT * 2))
check_cap "\"filed\" (≤4/ch, max $((CHAPTER_COUNT * 4)) total)" "$TOTAL_FILED" $((CHAPTER_COUNT * 4))

# Word count summary
echo ""
echo "=== WORD COUNT SUMMARY ==="
AVG_WORDS=$((TOTAL_WORDS / CHAPTER_COUNT))
TARGET_TOTAL=$((WORD_TARGET * CHAPTER_COUNT))
TOTAL_PCT=$((TOTAL_WORDS * 100 / TARGET_TOTAL))

echo "  Total words: $TOTAL_WORDS / $TARGET_TOTAL target (${TOTAL_PCT}%)"
echo "  Average per chapter: $AVG_WORDS (target: $WORD_TARGET)"
echo "  Chapters: $CHAPTER_COUNT"

# Chapter opening variety
echo ""
echo "=== CHAPTER OPENING VARIETY ==="
MORNING_OPENS=0
WEATHER_OPENS=0
PREV_OPEN=""

for chapter in $CHAPTER_FILES; do
    FIRST=$(head -5 "$chapter" | grep -v '^#' | grep -v '^$' | head -1 | tr '[:upper:]' '[:lower:]')
    CH_NAME=$(basename "$chapter" .md)

    IS_MORNING=$(echo "$FIRST" | grep -c "morning" || echo 0)
    IS_MORNING=$(echo "$IS_MORNING" | tr -dc '0-9')
    IS_WEATHER=$(echo "$FIRST" | grep -cE "rain|sun|wind|cloud|fog|storm|snow|cold|warm" || echo 0)
    IS_WEATHER=$(echo "$IS_WEATHER" | tr -dc '0-9')

    [ "$IS_MORNING" -gt 0 ] && MORNING_OPENS=$((MORNING_OPENS + 1))
    [ "$IS_WEATHER" -gt 0 ] && WEATHER_OPENS=$((WEATHER_OPENS + 1))

    OPEN_TYPE="action"
    [ "$IS_MORNING" -gt 0 ] && OPEN_TYPE="morning"
    [ "$IS_WEATHER" -gt 0 ] && OPEN_TYPE="weather"
    echo "$FIRST" | grep -q '^"' && OPEN_TYPE="dialogue"

    if [ "$OPEN_TYPE" = "$PREV_OPEN" ] && [ -n "$PREV_OPEN" ]; then
        echo "  $CH_NAME: $OPEN_TYPE — CONSECUTIVE REPEAT with previous chapter"
    else
        echo "  $CH_NAME: $OPEN_TYPE"
    fi
    PREV_OPEN="$OPEN_TYPE"
done

echo ""
echo "  Morning opens: $MORNING_OPENS / $CHAPTER_COUNT (cap: 4 per manuscript)"
[ "$MORNING_OPENS" -gt 4 ] && echo "  STATUS: FAIL" && FAIL=1 || echo "  STATUS: PASS"
WEATHER_PCT=$((WEATHER_OPENS * 100 / CHAPTER_COUNT))
echo "  Weather opens: $WEATHER_OPENS / $CHAPTER_COUNT (${WEATHER_PCT}%, cap: 30%)"
[ "$WEATHER_PCT" -gt 30 ] && echo "  STATUS: FAIL" && FAIL=1 || echo "  STATUS: PASS"

# Number-7 bias manuscript-wide
echo ""
echo "=== MANUSCRIPT-WIDE NUMBER-7 BIAS ==="
ALL_NUMBERS=0
ALL_SEVENS=0

for chapter in $CHAPTER_FILES; do
    NUMS=$(grep -oE '[0-9]+' "$chapter" 2>/dev/null | wc -l || echo 0)
    NUMS=$(echo "$NUMS" | tr -dc '0-9')
    SEVS=$(grep -oE '[0-9]+' "$chapter" 2>/dev/null | grep -c '7$' || echo 0)
    SEVS=$(echo "$SEVS" | tr -dc '0-9')
    ALL_NUMBERS=$((ALL_NUMBERS + NUMS))
    ALL_SEVENS=$((ALL_SEVENS + SEVS))
done

if [ "$ALL_NUMBERS" -gt 0 ]; then
    MS_PCT=$((ALL_SEVENS * 100 / ALL_NUMBERS))
    echo "  Total numbers: $ALL_NUMBERS | Ending in 7: $ALL_SEVENS (${MS_PCT}%)"
    echo "  Manuscript threshold: ≤15%"
    [ "$MS_PCT" -gt 15 ] && echo "  STATUS: FAIL" && FAIL=1 || echo "  STATUS: PASS"
else
    echo "  No numbers found in manuscript"
fi

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  MANUSCRIPT AUDIT DASHBOARD"
echo "╠══════════════════════════════════════════════════════════╣"
echo "║  Chapters: $CHAPTER_COUNT | Words: $TOTAL_WORDS"
echo "║  Narration em-dashes: $TOTAL_NARR_EMDASH (target: 0)"
echo "║  \"the way\": $TOTAL_THE_WAY / 6 cap"
echo "║  \"the kind/sort of\": $TOTAL_KIND_OF / 3 cap"
echo "║  \"the particular\": $TOTAL_PARTICULAR (zero tolerance)"
echo "║"
if [ "$FAIL" -eq 0 ]; then
    echo "║  ✓ MANUSCRIPT AUDIT: PASS"
else
    echo "║  ✗ MANUSCRIPT AUDIT: FAIL"
fi
echo "╚══════════════════════════════════════════════════════════╝"

exit $FAIL
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
