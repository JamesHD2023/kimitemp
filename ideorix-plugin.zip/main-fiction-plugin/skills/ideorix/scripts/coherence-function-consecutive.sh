#!/usr/bin/env bash
# coherence-function-consecutive.sh — flag adjacent chapters serving the same
# argumentative (NF) / dramatic (fiction) function.
#
# Part of the COHERENCE canon-validation domain (v2.7.31). Closes the
# same-function-consecutive gap from the canon-validation-taxonomy gap
# analysis (row 2).
#
# Detection model:
#   - Glob engine-data/chapter-briefs/ch*-brief.md in chapter order
#   - Per brief, extract the function declaration from the convention:
#       <!-- Function: <value> -->
#     (case-insensitive on "Function"; value is the rest of the line up to the
#     closing -->; whitespace-trimmed)
#   - Build an ordered chN → function map
#   - Flag any adjacent pair where chN.function == ch(N+1).function
#   - Report briefs missing the Function declaration as WARN (not FAIL —
#     backwards-compat with projects authored before v2.7.31 conventions)
#
# Why it matters: two consecutive chapters serving the same argumentative
# function (e.g. ch5 evidence-build, ch6 evidence-build) read as repetition;
# the manuscript loses momentum. Two consecutive chapters serving the same
# dramatic function in fiction (e.g. ch5 setup, ch6 setup) feel like the
# story is stuck. Catching adjacent duplicates at brief time costs one
# brief revision; catching them at draft time costs a chapter rewrite.
#
# v2.7.102 adds a whole-manuscript function-distribution section: it prints
# the chapter count per function and flags (as advisory INFO) any function
# spanning >= --concentration-threshold chapters (default 3). This closes the
# non-adjacent blind spot the original v2.7.31 audit deferred — but as INFO
# only, because non-adjacent repetition is often legitimate (two evidence
# chapters separated by a counter-argument). The INFO section never changes
# the pass/fail verdict; adjacency duplicates remain the only FAIL.
#
# Usage:
#   coherence-function-consecutive.sh <project-root>
#   coherence-function-consecutive.sh <project-root> --concentration-threshold N
#
# Exit codes:
#   0 — no adjacent-function duplicates detected (briefs with the Function
#       field are all distinct from their neighbours; missing-field briefs
#       reported as WARN but not failure; over-concentration is INFO, not
#       failure)
#   1 — one or more adjacent-function duplicates detected
#   2 — usage / file-not-found error / no chapter briefs found

set -uo pipefail

PROJECT_ROOT=""
CONCENTRATION_THRESHOLD=3

while [ $# -gt 0 ]; do
    case "$1" in
        --concentration-threshold)
            CONCENTRATION_THRESHOLD="${2:-3}"
            shift 2
            ;;
        --help|-h)
            echo "Usage: coherence-function-consecutive.sh <project-root> [--concentration-threshold N]"
            exit 0
            ;;
        *)
            if [ -z "$PROJECT_ROOT" ]; then
                PROJECT_ROOT="$1"
            fi
            shift
            ;;
    esac
done

if [ -z "$PROJECT_ROOT" ]; then
    echo "Usage: coherence-function-consecutive.sh <project-root> [--concentration-threshold N]" >&2
    exit 2
fi

if ! [[ "$CONCENTRATION_THRESHOLD" =~ ^[0-9]+$ ]] || [ "$CONCENTRATION_THRESHOLD" -lt 2 ]; then
    echo "ERROR: --concentration-threshold must be an integer >= 2 (got: $CONCENTRATION_THRESHOLD)" >&2
    exit 2
fi

BRIEFS_DIR="$PROJECT_ROOT/engine-data/chapter-briefs"

if [ ! -d "$BRIEFS_DIR" ]; then
    echo "ERROR: chapter-briefs directory not found: $BRIEFS_DIR" >&2
    exit 2
fi

echo "=== COHERENCE: same-function-consecutive ==="
echo "Project: $PROJECT_ROOT"
echo

# Collect briefs in chapter-number order. Files match ch{NN}-brief.md.
shopt -s nullglob
briefs=("$BRIEFS_DIR"/ch*-brief.md)
shopt -u nullglob

if [ "${#briefs[@]}" -eq 0 ]; then
    echo "[SKIP] no chapter-brief files found at $BRIEFS_DIR"
    exit 2
fi

# Sort lexically — ch01-brief, ch02-brief, ... — chapter numbers are
# zero-padded by engine convention so lexical == numerical for ch01-ch99.
sorted_briefs=()
while IFS= read -r line; do
    sorted_briefs+=("$line")
done < <(printf '%s\n' "${briefs[@]}" | sort)

# Build parallel arrays: chapter-number, function-value (or empty if missing).
chapter_nums=()
chapter_fns=()
missing_count=0

for brief in "${sorted_briefs[@]}"; do
    base="$(basename "$brief" .md)"
    # Extract chapter number from "chNN-brief".
    chN="${base#ch}"
    chN="${chN%-brief}"

    # Extract the Function declaration. Match the canonical HTML comment.
    fn_line="$(grep -m1 -iE '<!--[[:space:]]*Function:[[:space:]]*[^[:space:]]' "$brief" 2>/dev/null || true)"
    if [ -z "$fn_line" ]; then
        chapter_nums+=("$chN")
        chapter_fns+=("__MISSING__")
        missing_count=$((missing_count + 1))
        continue
    fi

    # Strip prefix up through "Function:" (case-insensitive) and suffix
    # from "-->" onward; trim whitespace.
    fn_value="$(printf '%s' "$fn_line" \
        | sed -E 's/.*[Ff]unction:[[:space:]]*//; s/[[:space:]]*-->.*//; s/^[[:space:]]+//; s/[[:space:]]+$//')"
    if [ -z "$fn_value" ]; then
        chapter_nums+=("$chN")
        chapter_fns+=("__MISSING__")
        missing_count=$((missing_count + 1))
        continue
    fi

    chapter_nums+=("$chN")
    chapter_fns+=("$fn_value")
done

# Per-chapter ledger output.
echo "Chapter function ledger:"
for i in "${!chapter_nums[@]}"; do
    if [ "${chapter_fns[$i]}" = "__MISSING__" ]; then
        printf "  ch%s : (no Function declaration)\n" "${chapter_nums[$i]}"
    else
        printf "  ch%s : %s\n" "${chapter_nums[$i]}" "${chapter_fns[$i]}"
    fi
done
echo

# Adjacency check: for each i in 0..N-2, compare i to i+1.
duplicate_pairs=()
for i in "${!chapter_nums[@]}"; do
    j=$((i + 1))
    if [ "$j" -ge "${#chapter_nums[@]}" ]; then
        break
    fi
    a="${chapter_fns[$i]}"
    b="${chapter_fns[$j]}"
    # Skip pairs where either side is missing — those are reported as WARN
    # separately, not adjacency duplicates.
    if [ "$a" = "__MISSING__" ] || [ "$b" = "__MISSING__" ]; then
        continue
    fi
    if [ "$a" = "$b" ]; then
        duplicate_pairs+=("ch${chapter_nums[$i]} + ch${chapter_nums[$j]} : both \"$a\"")
    fi
done

# Whole-manuscript function distribution (v2.7.102, advisory INFO).
# The adjacency check above catches CONSECUTIVE same-function chapters
# (momentum loss). This section closes the documented non-adjacent blind
# spot — but as ADVISORY INFO only, because non-adjacent repetition is
# often legitimate (e.g. two evidence chapters separated by a counter-
# argument). It surfaces the whole-book distribution + flags any function
# that spans CONCENTRATION_THRESHOLD+ chapters, so over-reliance on one
# function is visible. It never changes the pass/fail verdict.
uniq_fns=()
for fn in "${chapter_fns[@]}"; do
    [ "$fn" = "__MISSING__" ] && continue
    seen=0
    for u in "${uniq_fns[@]}"; do
        if [ "$u" = "$fn" ]; then
            seen=1
            break
        fi
    done
    [ "$seen" -eq 0 ] && uniq_fns+=("$fn")
done

concentration_flags=()
if [ "${#uniq_fns[@]}" -gt 0 ]; then
    echo "Function distribution (whole-manuscript):"
    for u in "${uniq_fns[@]}"; do
        chs=()
        for i in "${!chapter_fns[@]}"; do
            if [ "${chapter_fns[$i]}" = "$u" ]; then
                chs+=("ch${chapter_nums[$i]}")
            fi
        done
        printf "  %-24s %d chapter(s): %s\n" "$u" "${#chs[@]}" "${chs[*]}"
        if [ "${#chs[@]}" -ge "$CONCENTRATION_THRESHOLD" ]; then
            concentration_flags+=("$u (${#chs[@]} chapters: ${chs[*]})")
        fi
    done
    echo
fi

if [ "${#concentration_flags[@]}" -gt 0 ]; then
    echo "INFO: function over-concentration (>= ${CONCENTRATION_THRESHOLD} chapters share a function):"
    for f in "${concentration_flags[@]}"; do
        echo "  INFO: $f"
    done
    echo "      Advisory only — does NOT affect the pass/fail verdict."
    echo "      Non-adjacent repetition is often legitimate (e.g. two evidence"
    echo "      chapters separated by a counter-argument). Review whether the"
    echo "      manuscript leans too heavily on one function."
    echo
fi

# Verdict.
exit_code=0
if [ "${#duplicate_pairs[@]}" -gt 0 ]; then
    echo "ADJACENT-FUNCTION DUPLICATES (${#duplicate_pairs[@]}):"
    for pair in "${duplicate_pairs[@]}"; do
        echo "  FAIL: $pair"
    done
    echo
    exit_code=1
fi

if [ "$missing_count" -gt 0 ]; then
    echo "WARN: $missing_count brief(s) missing the Function declaration"
    echo "      Add a <!-- Function: <value> --> comment to each brief."
    echo "      See coherence-function-consecutive.md for the canonical"
    echo "      function lists (NF: argumentative; fiction: dramatic)."
    echo
fi

if [ "$exit_code" -eq 0 ] && [ "$missing_count" -eq 0 ]; then
    echo "[PASS] all ${#chapter_nums[@]} chapter brief(s) declare a Function and no adjacent pair shares one"
elif [ "$exit_code" -eq 0 ]; then
    echo "[PASS] no adjacent-function duplicates detected (${missing_count} brief(s) missing declaration — WARN above)"
else
    echo "[FAIL] ${#duplicate_pairs[@]} adjacent-function duplicate(s) detected"
    echo
    echo "Fix: vary the chapter sequence — two consecutive chapters serving"
    echo "the same function read as repetition. If the duplicate is structurally"
    echo "intentional (e.g. paired evidence chapters delivering one argument),"
    echo "document the choice in the brief and the audit can be silenced for"
    echo "that pair in a future release."
fi

exit "$exit_code"
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
