#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Master Orchestrator
# Runs all mechanical verification modules on a chapter file
# and produces a unified pass/fail dashboard.
#
# This script replaces the model's mechanical counting tasks.
# The model still handles creative/semantic judgement (quality,
# voice, continuity logic, arc analysis). This script handles
# everything that can be grep'd, counted, or compared.
# ============================================================
# Usage: bash ideorix-audit.sh [flags] <chapter-file> <project-path> [word-target]
#
# Flags (any order; must precede positional args):
#   --no-stage         suppress auto-staging to engine-data/model-health.md
#   --auto-stage       default-on; provided to make the default explicit
#   --format=text      default human-readable dashboard output (default)
#   --format=json      machine-readable JSON envelope on stdout, no dashboard
#
# project-path should contain (any of):
#   engine-data/forbidden-words.md (preferred project override)
#   forbidden-words.md             (legacy project-root override)
#   — falls back to the engine-bundled references/forbidden-words.md
#   engine-data/entity-canon.md    (if available)
#
# Example:
#   bash ideorix-audit.sh engine-data/chapters/ch01.md /path/to/project 2500
#   bash ideorix-audit.sh --format=json ch01.md /path/to/project 2500 | jq .
#
# Auto-staging hook (Cowork Phase 3 / Fix 12):
#   Default: every run appends one structured row to
#     <project-path>/engine-data/model-health.md
#   describing the audit (timestamp, chapter, words/target, modules
#   pass/fail, overall status, failed module names). The log is the
#   longitudinal record of mechanical audit health across chapters.
#   Pass --no-stage to suppress (e.g. ad-hoc / CI invocations).
#
# JSON envelope (Cowork Phase 3 / Fix 17):
#   --format=json suppresses the dashboard art and emits a single
#   JSON object on stdout describing the run. Per-module stdout +
#   stderr are captured as escaped strings so downstream tooling
#   (cowork loops, dashboards, CI) can parse the result without
#   regex-scraping the boxed text. Schema: "ideorix-audit/v1".

set -euo pipefail

# Parse leading flags before the existing positional handling.
NO_STAGE=0
FORMAT="text"
POSITIONAL=()
while [ "$#" -gt 0 ]; do
    case "$1" in
        --no-stage)        NO_STAGE=1; shift ;;
        --auto-stage)      NO_STAGE=0; shift ;;
        --format=json)     FORMAT="json"; shift ;;
        --format=text)     FORMAT="text"; shift ;;
        --format)          FORMAT="${2:?--format requires a value (text|json)}"; shift 2 ;;
        --)                shift; while [ "$#" -gt 0 ]; do POSITIONAL+=("$1"); shift; done ;;
        *)                 POSITIONAL+=("$1"); shift ;;
    esac
done
case "$FORMAT" in
    text|json) ;;
    *) echo "ERROR: --format must be 'text' or 'json' (got: $FORMAT)" >&2; exit 2 ;;
esac
if [ "${#POSITIONAL[@]}" -gt 0 ]; then
    set -- "${POSITIONAL[@]}"
else
    set --
fi

CHAPTER="${1:?Usage: ideorix-audit.sh [flags] <chapter-file> <project-path> [word-target]}"
PROJECT="${2:?Usage: ideorix-audit.sh [flags] <chapter-file> <project-path>}"
WORD_TARGET="${3:-2500}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER" >&2; exit 1; fi

# Locate reference files
# v2.7.50 fix: forbidden-words resolution had a broken-path bug — the
# project-local "core/forbidden-words.md" check was a leftover convention
# (no project layout actually creates that path) and there was no fallback
# to the engine's bundled forbidden-words.md. Audits silently ran with
# FORBIDDEN="" if no project copy existed.
FORBIDDEN=""
[ -f "$PROJECT/engine-data/forbidden-words.md" ] && FORBIDDEN="$PROJECT/engine-data/forbidden-words.md"
[ -f "$PROJECT/forbidden-words.md" ] && FORBIDDEN="$PROJECT/forbidden-words.md"
[ -z "$FORBIDDEN" ] && [ -f "$SCRIPT_DIR/../references/forbidden-words.md" ] \
    && FORBIDDEN="$SCRIPT_DIR/../references/forbidden-words.md"

CANON=""
[ -f "$PROJECT/engine-data/entity-canon.md" ] && CANON="$PROJECT/engine-data/entity-canon.md"

CHAPTER_NAME=$(basename "$CHAPTER" .md)
# Strip YAML front matter ONLY when the file actually starts with --- on line 1.
# Mirrors word-count-check.sh:21 so the orchestrator and the module agree on the
# count for chapters that have YAML frontmatter — and don't false-strip when
# mid-document Markdown scene-break --- separators are present.
if head -1 "$CHAPTER" | grep -qE '^---[[:space:]]*$'; then
    WORD_COUNT=$(awk 'NR==1{next} /^---[[:space:]]*$/ && !done {done=1; next} done{print}' "$CHAPTER" | wc -w)
else
    WORD_COUNT=$(wc -w < "$CHAPTER")
fi
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
TIMESTAMP_ISO=$(date -u '+%Y-%m-%dT%H:%M:%SZ')

# JSON-safe string escaping. Perl is universally available on macOS + Linux.
json_escape() {
    perl -CSDA -e '
        my $s = do { local $/; <STDIN> };
        $s =~ s/\\/\\\\/g;
        $s =~ s/"/\\"/g;
        $s =~ s/\x08/\\b/g;
        $s =~ s/\x09/\\t/g;
        $s =~ s/\x0a/\\n/g;
        $s =~ s/\x0c/\\f/g;
        $s =~ s/\x0d/\\r/g;
        $s =~ s/([\x00-\x1f])/sprintf("\\u%04x",ord($1))/ge;
        print $s;
    '
}

# In JSON mode the dashboard art is suppressed; only the final JSON
# envelope reaches stdout. Module stdout/stderr are still captured.
emit_text() { if [ "$FORMAT" = "text" ]; then echo "$@"; fi; }

emit_text "╔══════════════════════════════════════════════════════════╗"
emit_text "║  IDEORIX MECHANICAL AUDIT — $CHAPTER_NAME"
emit_text "║  $TIMESTAMP"
emit_text "║  Words: $WORD_COUNT | Target: $WORD_TARGET"
emit_text "╚══════════════════════════════════════════════════════════╝"
emit_text ""

TOTAL_FAIL=0
MODULES_RUN=0
MODULES_PASS=0
MODULES_WARN=0
MODULES_FAIL=0
FAILED_MODULES=()
WARNED_MODULES=()

# JSON accumulator: comma-separated object literals, joined into the
# modules array at the end.
JSON_MODULES=""

json_append_module() {
    local name="$1" status="$2" exit_code="$3" skipped="$4" stdout_file="$5" stderr_file="$6"
    local stdout_esc stderr_esc
    if [ -n "$stdout_file" ] && [ -f "$stdout_file" ]; then
        stdout_esc=$(json_escape < "$stdout_file")
    else
        stdout_esc=""
    fi
    if [ -n "$stderr_file" ] && [ -f "$stderr_file" ]; then
        stderr_esc=$(json_escape < "$stderr_file")
    else
        stderr_esc=""
    fi
    local entry
    entry="{\"name\":\"${name}\",\"status\":\"${status}\",\"exit_code\":${exit_code},\"skipped\":${skipped},\"stdout\":\"${stdout_esc}\",\"stderr\":\"${stderr_esc}\"}"
    if [ -n "$JSON_MODULES" ]; then
        JSON_MODULES="${JSON_MODULES},${entry}"
    else
        JSON_MODULES="${entry}"
    fi
}

run_module() {
    local name="$1"
    shift
    MODULES_RUN=$((MODULES_RUN + 1))
    local stdout_file stderr_file exit_code=0
    stdout_file=$(mktemp)
    stderr_file=$(mktemp)
    "$@" > "$stdout_file" 2> "$stderr_file" || exit_code=$?
    local mstatus
    if [ "$exit_code" -ne 0 ]; then
        MODULES_FAIL=$((MODULES_FAIL + 1))
        TOTAL_FAIL=1
        FAILED_MODULES+=("$name")
        mstatus="FAIL"
    elif grep -qE '^[[:space:]]*STATUS:[[:space:]]*WARN' "$stdout_file" 2>/dev/null; then
        # Module exited 0 but emitted at least one STATUS: WARN line. Surface
        # it as a third banner state instead of silently coercing to PASS.
        MODULES_WARN=$((MODULES_WARN + 1))
        WARNED_MODULES+=("$name")
        mstatus="WARN"
    else
        MODULES_PASS=$((MODULES_PASS + 1))
        mstatus="PASS"
    fi
    if [ "$FORMAT" = "text" ]; then
        echo "━━━ MODULE: $name ━━━"
        cat "$stdout_file"
        if [ -s "$stderr_file" ]; then
            echo ""
            echo "  [module errors:]"
            sed 's/^/    /' "$stderr_file"
        fi
        echo ""
    else
        json_append_module "$name" "$mstatus" "$exit_code" "false" "$stdout_file" "$stderr_file"
    fi
    rm -f "$stdout_file" "$stderr_file"
}

skip_module() {
    local name="$1" reason="$2"
    if [ "$FORMAT" = "text" ]; then
        echo "━━━ MODULE: $name — SKIPPED ($reason) ━━━"
        echo ""
    else
        local reason_esc
        reason_esc=$(printf '%s' "$reason" | json_escape)
        local entry="{\"name\":\"${name}\",\"status\":\"SKIPPED\",\"exit_code\":0,\"skipped\":true,\"reason\":\"${reason_esc}\",\"stdout\":\"\",\"stderr\":\"\"}"
        if [ -n "$JSON_MODULES" ]; then
            JSON_MODULES="${JSON_MODULES},${entry}"
        else
            JSON_MODULES="${entry}"
        fi
    fi
}

# Module 1: Forbidden Words (mandatory — fail loudly if missing)
if [ -z "$FORBIDDEN" ]; then
    echo "ERROR: forbidden-words.md not found. Expected at one of:" >&2
    echo "  $PROJECT/engine-data/forbidden-words.md (project override)" >&2
    echo "  $PROJECT/forbidden-words.md             (project-root override)" >&2
    echo "  $SCRIPT_DIR/../references/forbidden-words.md (engine fallback)" >&2
    echo "The engine ships forbidden-words.md by default; if you see this error, the plugin install is incomplete." >&2
    exit 2
fi
run_module "Forbidden Words" bash "$SCRIPT_DIR/forbidden-words-scan.sh" "$CHAPTER" "$FORBIDDEN"

# Module 2: Formatting
run_module "Formatting" bash "$SCRIPT_DIR/formatting-check.sh" "$CHAPTER" "ai"

# Module 3: Pattern Counter
run_module "Pattern Counter" bash "$SCRIPT_DIR/pattern-counter.sh" "$CHAPTER"

# Module 4: Placeholder Scan
run_module "Placeholder Scan" bash "$SCRIPT_DIR/placeholder-scan.sh" "$CHAPTER"

# Module 5: Word Count
run_module "Word Count" bash "$SCRIPT_DIR/word-count-check.sh" "$CHAPTER" "$WORD_TARGET"

# Module 6: Entity Canon
if [ -n "$CANON" ]; then
    run_module "Entity Canon" bash "$SCRIPT_DIR/entity-canon-verify.sh" "$CHAPTER" "$CANON" "${FORBIDDEN:-}"
else
    skip_module "Entity Canon" "no entity-canon.md found"
fi

# Module 7: Number-7 Bias
run_module "Number-7 Bias" bash "$SCRIPT_DIR/number-7-bias.sh" "$CHAPTER"

# Module 8: Voice Metrics (v2.7.65 — per-chapter narrator-voice measurement)
# Records FP ratio + sentence-length stats to engine-data/reports/
# voice-metrics-ledger.md. Per-chapter STATUS is informational; the
# cross-chapter trend audit is what fails on drift.
run_module "Voice Metrics" bash "$SCRIPT_DIR/voice-metrics-audit.sh" "$CHAPTER" "$PROJECT"

# Module 9: Voice Trend (v2.7.65 — boiled-frog drift detection)
# Reads the ledger Module 8 just appended to, computes window-mean +
# slope of FP ratio across the last 5 chapters. Short-circuits to INFO
# until enough data; FAILS on the boiled-frog drift shape.
run_module "Voice Trend" bash "$SCRIPT_DIR/voice-trend-audit.sh" "$PROJECT"

# Module 10: Consecutive Opener Scan (v2.7.75 — anaphora detection)
# Detects 3+ consecutive sentences starting with the same opener
# (the canonical "She looked at the door. She looked at the window.
# She looked at the clock." pattern). Emits STATUS: WARN on detection
# so existing approved chapters don't auto-fail; the verdict is
# advisory until the user / orchestrator reviews each cluster against
# its context (ritual / comedy / mystery clue cycles are legitimate
# uses). See references/prose-humaniser.md for the canonical rule.
run_module "Consecutive Openers" bash "$SCRIPT_DIR/consecutive-opener-scan.sh" "$CHAPTER"

PCT=$((WORD_COUNT * 100 / WORD_TARGET))

emit_text "╔══════════════════════════════════════════════════════════╗"
emit_text "║  MECHANICAL AUDIT DASHBOARD"
emit_text "╠══════════════════════════════════════════════════════════╣"
emit_text "║  Chapter: $CHAPTER_NAME"
emit_text "║  Words: $WORD_COUNT / $WORD_TARGET (${PCT}%)"
emit_text "║  Modules run: $MODULES_RUN"
emit_text "║  Modules passed: $MODULES_PASS"
emit_text "║  Modules warned: $MODULES_WARN"
emit_text "║  Modules failed: $MODULES_FAIL"
emit_text "║"
if [ "$TOTAL_FAIL" -eq 1 ]; then
    emit_text "║  ✗ MECHANICAL AUDIT: FAIL ($MODULES_FAIL module(s) failed)"
elif [ "$MODULES_WARN" -gt 0 ]; then
    emit_text "║  ⚠ MECHANICAL AUDIT: WARN ($MODULES_WARN module(s) warned)"
else
    emit_text "║  ✓ MECHANICAL AUDIT: PASS"
fi
emit_text "║"
emit_text "║  Model agents should focus on:"
emit_text "║  - Continuity logic (not counting)"
emit_text "║  - Voice quality & differentiation"
emit_text "║  - Pacing & emotional arc"
emit_text "║  - Character motivation & credibility"
emit_text "║  - Semantic coherence"
emit_text "╚══════════════════════════════════════════════════════════╝"

# Auto-staging hook — append one row per run to engine-data/model-health.md
# unless --no-stage was passed. Header is created on first run. The
# hook fires regardless of --format= so the long-run dashboard stays
# in sync whether the caller wanted text or JSON output.
if [ "$NO_STAGE" -eq 0 ]; then
    HEALTH_LOG="$PROJECT/engine-data/model-health.md"
    mkdir -p "$(dirname "$HEALTH_LOG")"
    if [ ! -f "$HEALTH_LOG" ]; then
        cat > "$HEALTH_LOG" <<'HDR'
# Model Health Log

Per-chapter mechanical audit history. Each run of `ideorix-audit.sh`
(unless invoked with `--no-stage`) appends one row. Use the trend to
spot drift — which modules fail most often, which chapters are
worst-affected, whether the overall failure rate is climbing.

| Timestamp | Chapter | Words | Target | % | Pass | Fail | Status | Failed modules |
|---|---|---|---|---|---|---|---|---|
HDR
    fi
    if [ "$TOTAL_FAIL" -eq 1 ]; then
        OVERALL_STATUS="FAIL"
    elif [ "$MODULES_WARN" -gt 0 ]; then
        OVERALL_STATUS="WARN"
    else
        OVERALL_STATUS="PASS"
    fi
    if [ "${#FAILED_MODULES[@]}" -gt 0 ]; then
        FAILED_STR=$(printf '%s, ' "${FAILED_MODULES[@]}")
        FAILED_STR="${FAILED_STR%, }"
    elif [ "${#WARNED_MODULES[@]}" -gt 0 ]; then
        FAILED_STR=$(printf '%s, ' "${WARNED_MODULES[@]}")
        FAILED_STR="${FAILED_STR%, } (warn)"
    else
        FAILED_STR="—"
    fi
    printf '| %s | %s | %d | %d | %d | %d | %d | %s | %s |\n' \
        "$TIMESTAMP" "$CHAPTER_NAME" "$WORD_COUNT" "$WORD_TARGET" "$PCT" \
        "$MODULES_PASS" "$MODULES_FAIL" "$OVERALL_STATUS" "$FAILED_STR" \
        >> "$HEALTH_LOG"
    emit_text ""
    emit_text "  → Auto-staged to: $HEALTH_LOG"
fi

# Emit the JSON envelope on stdout when --format=json was requested.
if [ "$FORMAT" = "json" ]; then
    if [ "$TOTAL_FAIL" -eq 1 ]; then
        ENV_STATUS="FAIL"
    elif [ "$MODULES_WARN" -gt 0 ]; then
        ENV_STATUS="WARN"
    else
        ENV_STATUS="PASS"
    fi
    FAILED_JSON=""
    if [ "${#FAILED_MODULES[@]}" -gt 0 ]; then
        for m in "${FAILED_MODULES[@]}"; do
            esc=$(printf '%s' "$m" | json_escape)
            if [ -n "$FAILED_JSON" ]; then
                FAILED_JSON="${FAILED_JSON},\"${esc}\""
            else
                FAILED_JSON="\"${esc}\""
            fi
        done
    fi
    WARNED_JSON=""
    if [ "${#WARNED_MODULES[@]}" -gt 0 ]; then
        for m in "${WARNED_MODULES[@]}"; do
            esc=$(printf '%s' "$m" | json_escape)
            if [ -n "$WARNED_JSON" ]; then
                WARNED_JSON="${WARNED_JSON},\"${esc}\""
            else
                WARNED_JSON="\"${esc}\""
            fi
        done
    fi
    CHAPTER_PATH_ESC=$(printf '%s' "$CHAPTER" | json_escape)
    PROJECT_PATH_ESC=$(printf '%s' "$PROJECT" | json_escape)
    CHAPTER_NAME_ESC=$(printf '%s' "$CHAPTER_NAME" | json_escape)
    # Top-level `overall.status` was added in v2.7.58 per Cowork
    # follow-up review BUG #2: automated JSON consumers probed
    # `overall.status` and got None because the field only lived
    # under `summary.status`. Both fields now carry the same value;
    # downstream tooling can read whichever it expects.
    cat <<JSON
{"schema":"ideorix-audit/v1","engine":"fiction","chapter":"${CHAPTER_NAME_ESC}","chapter_path":"${CHAPTER_PATH_ESC}","project_path":"${PROJECT_PATH_ESC}","timestamp":"${TIMESTAMP_ISO}","words":${WORD_COUNT},"target":${WORD_TARGET},"percent":${PCT},"overall":{"status":"${ENV_STATUS}"},"modules":[${JSON_MODULES}],"summary":{"modules_run":${MODULES_RUN},"modules_pass":${MODULES_PASS},"modules_warn":${MODULES_WARN},"modules_fail":${MODULES_FAIL},"status":"${ENV_STATUS}","failed_modules":[${FAILED_JSON}],"warned_modules":[${WARNED_JSON}]}}
JSON
fi

exit "$TOTAL_FAIL"
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
