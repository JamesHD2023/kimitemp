#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 7: Number-7 Bias Check
# Extracts all numbers, counts 7-ending frequency.
# ============================================================
# Usage: bash number-7-bias.sh <chapter-file>

set -euo pipefail

# Strip a value to digits-only, treat as integer (resolves "0\n0" or
# "00" multi-line/leading-zero artifacts from `grep -c` under `-o`),
# and default to 0. Used to scrub the output some grep builds produce
# that propagates to `[ "$X" -gt 0 ]` as an "integer expression
# expected" error under set -euo pipefail. The `* 1` arithmetic forces
# bash to evaluate the string as a base-10 integer, normalizing both
# multi-line concatenations and leading-zero display artifacts.
# Backported from NF's number-7-bias.sh after the Cowork v2.7.57
# follow-up review found this script false-FAILing every clean
# fiction chapter — also closes the cosmetic "00" display drift.
clean_int() {
    local raw="${1:-0}"
    raw=$(echo "$raw" | tr -dc '0-9')
    [ -z "$raw" ] && raw=0
    # Force base-10 arithmetic so leading zeros / multi-line digit
    # concatenations resolve to a clean integer.
    echo $((10#${raw} * 1))
}

CHAPTER="${1:?Usage: number-7-bias.sh <chapter-file>}"
if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

echo "=== NUMBER-7 BIAS CHECK ==="
echo "Chapter: $CHAPTER"
echo ""

# Extract all numeric digits from chapter
grep -oE '[0-9]+' "$CHAPTER" > "$TMPDIR/numbers.txt" 2>/dev/null || true

# Spelled-out numbers containing seven — count only "seven" standalone.
# "seventeen" and "seventy" are already captured by numeric extraction when written as digits,
# and counting them here AND via digit extraction would double-count the same concept.
grep -oEi '\bseven\b' "$CHAPTER" > "$TMPDIR/spelled_sevens.txt" 2>/dev/null || true

# Count numbers ending in 7. Every count is run through clean_int so that
# the [ -gt 0 ] tests downstream never see "0\n0" or other multi-line
# artifacts from `grep -c` / `wc -l` edge cases.
TOTAL=$(clean_int "$(wc -l < "$TMPDIR/numbers.txt" 2>/dev/null || echo 0)")
SEVENS=$(clean_int "$(grep -cE '7$' "$TMPDIR/numbers.txt" 2>/dev/null || echo 0)")
SPELLED=$(clean_int "$(wc -l < "$TMPDIR/spelled_sevens.txt" 2>/dev/null || echo 0)")

TOTAL_WITH_SPELLED=$((TOTAL + SPELLED))
SEVENS_WITH_SPELLED=$((SEVENS + SPELLED))

if [ "$TOTAL_WITH_SPELLED" -gt 0 ]; then
    PCT=$((SEVENS_WITH_SPELLED * 100 / TOTAL_WITH_SPELLED))
else
    PCT=0
fi

# Check for hours set to 7. Use grep -oE | wc -l, NOT grep -ocE. The
# `-oc` combination on some grep builds returns one count per line
# ("0\n0"), which propagates through the FAIL-test below as an integer
# expression error under set -euo pipefail — causing the orchestrator
# to report this module as failed on every clean chapter (Cowork bug
# report 2026-05-11 / v2.7.57 follow-up review).
HOUR_RAW=$(grep -oE '\b7:[0-9]{2}\b|\bseven o.clock\b' "$CHAPTER" 2>/dev/null | wc -l || true)
HOUR_SEVENS=$(clean_int "$HOUR_RAW")

echo "--- Numbers Found ---"
echo "  Numeric digits: $TOTAL"
echo "  Spelled-out sevens: $SPELLED"
echo "  Total number references: $TOTAL_WITH_SPELLED"
echo ""
echo "--- Seven Bias ---"
echo "  Ending in 7 (digit): $SEVENS"
echo "  Spelled sevens: $SPELLED"
echo "  Total seven-references: $SEVENS_WITH_SPELLED"
echo "  Percentage: ${PCT}%"
echo "  Per-chapter threshold: ≤25%"
echo ""

FAIL=0
if [ "$TOTAL_WITH_SPELLED" -lt 3 ]; then
    echo "  STATUS: N/A (fewer than 3 numbers — too small to measure)"
elif [ "$PCT" -gt 25 ]; then
    echo "  STATUS: FAIL — ${PCT}% exceeds 25% chapter threshold"
    FAIL=1
elif [ "$PCT" -gt 15 ]; then
    echo "  STATUS: WARN — ${PCT}% approaching manuscript threshold (15%)"
else
    echo "  STATUS: PASS"
fi

echo ""
echo "--- Hour-7 Check ---"
echo "  Times set to 7:xx or 'seven o'clock': $HOUR_SEVENS"
[ "$HOUR_SEVENS" -gt 0 ] && echo "  STATUS: FLAG — consider changing hour" || echo "  STATUS: PASS"

echo ""
echo "=== SUMMARY ==="
echo "Numbers: $TOTAL_WITH_SPELLED | Sevens: $SEVENS_WITH_SPELLED (${PCT}%) | Hour-7: $HOUR_SEVENS"
if [ "$FAIL" -eq 1 ]; then
    echo "STATUS: FAIL"
    exit 1
else
    echo "STATUS: PASS"
    exit 0
fi
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
