#!/bin/bash
# ============================================================
# Ideorix — Character Tell Distinctness Audit (v2.7.124)
#
# Canon-level companion to show-not-tell-tells.sh (which audits PROSE
# per chapter). This audits the STORY BIBLE's Character Depth Layer
# (references/character-depth.md §B) — the per-character Physical Tell
# Register — and flags:
#   (a) two main-cast characters sharing a tell for the SAME emotional
#       register (the "no shared tells" rule — the cross-character
#       distinctness show-not-tell-tells.md explicitly defers), and
#   (b) a register slot left empty or stubbed (TODO/TBD/placeholder).
#
# This closes the deferred "Class B" gap by checking the canon the
# Depth Layer defines, mechanically (no LLM, no subagent).
#
# Canonical format it parses (authored by world-canon §4b):
#   #### Physical Tell Register — {Character Name}
#   - Fear: {tell}
#   - Anger: {tell}
#   - Grief: {tell}
#   - Desire: {tell}
#   - Resolve: {tell}
#
# Usage:
#   character-tell-distinctness.sh <project_root | story-bible.md>
#     - a project root resolves <root>/engine-data/story-bible.md
#       (the PROJECT_ONCE signature the /validate dispatcher uses)
#     - a file path is read directly (standalone use)
#
# Exit codes: 0 clean (or no Depth Layer present) · 1 findings ·
#             2 usage / no-bible (SKIP) / present-but-unparseable
# ============================================================

set -uo pipefail

ARG="${1:-}"
if [ -z "$ARG" ]; then
    echo "ERROR: usage: character-tell-distinctness.sh <project_root | story-bible.md>" >&2
    exit 2
fi

if [ -d "$ARG" ]; then
    BIBLE="$ARG/engine-data/story-bible.md"
else
    BIBLE="$ARG"
fi

if [ ! -f "$BIBLE" ]; then
    echo "SKIP: no story bible at $BIBLE — nothing to audit" >&2
    exit 2
fi

# Parse the Tell Registers into: REGISTER \t normalized-tell \t name \t raw-tell
# Portable awk (no getline, no gawk extensions). Name is taken as whatever
# follows the header prefix with leading punctuation/dash stripped, so it is
# robust to em-dash vs hyphen.
TMP="$(mktemp "${TMPDIR:-/tmp}/wge-tells.XXXXXX")" || {
    echo "ERROR: cannot create temp file" >&2; exit 2; }
trap 'rm -f "$TMP"' EXIT

HEADER_COUNT=$(grep -c '^#### Physical Tell Register' "$BIBLE" 2>/dev/null || echo 0)
HEADER_COUNT=$(printf '%s' "$HEADER_COUNT" | tr -dc '0-9')
[ -z "$HEADER_COUNT" ] && HEADER_COUNT=0

if [ "$HEADER_COUNT" -eq 0 ]; then
    echo "=== CHARACTER: tell-register distinctness ==="
    echo "No Character Depth Layer found in $(basename "$BIBLE") — nothing to check."
    exit 0
fi

awk '
    /^#### Physical Tell Register/ {
        name = $0
        sub(/^#### Physical Tell Register/, "", name)
        gsub(/^[^A-Za-z0-9]+/, "", name)        # strip leading " — " / " - "
        gsub(/[[:space:]]+$/, "", name)
        next
    }
    /^- (Fear|Anger|Grief|Desire|Resolve):/ {
        if (name == "") next
        reg = $0
        sub(/^- /, "", reg)
        ci = index(reg, ":")
        register = substr(reg, 1, ci - 1)
        raw = substr(reg, ci + 1)
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", raw)
        norm = tolower(raw)
        gsub(/[^a-z0-9 ]/, "", norm)
        gsub(/[[:space:]]+/, " ", norm)
        gsub(/^ | $/, "", norm)
        printf "%s\t%s\t%s\t%s\n", register, norm, name, raw
    }
' "$BIBLE" > "$TMP"

REGISTER_LINES=$(grep -c . "$TMP" 2>/dev/null || echo 0)
REGISTER_LINES=$(printf '%s' "$REGISTER_LINES" | tr -dc '0-9')
[ -z "$REGISTER_LINES" ] && REGISTER_LINES=0

echo "=== CHARACTER: tell-register distinctness ==="
echo "Bible: $(basename "$BIBLE")"
echo "Parsed: $HEADER_COUNT register block(s), $REGISTER_LINES tell line(s)."

if [ "$REGISTER_LINES" -eq 0 ]; then
    echo "[ERROR] Depth Layer headers present but no tell lines parsed —" >&2
    echo "        the §4b format may be malformed. Not a silent PASS." >&2
    exit 2
fi

FAIL=0

# (b) Empty / stubbed tells.
STUBS=$(awk -F'\t' '
    { n = $2 }
    n == "" || length(n) < 6 || n ~ /^(tbd|tba|tbc|todo|xxx|placeholder|none)$/ {
        printf "  %s / %s: \"%s\"\n", $3, $1, $4
    }
' "$TMP")
if [ -n "$STUBS" ]; then
    echo ""
    echo "STUBBED / EMPTY tells (fill these in):"
    printf '%s\n' "$STUBS"
    FAIL=1
fi

# (a) Same register + same normalized tell across 2+ distinct characters.
DUPES=$(awk -F'\t' '$2 != "" { print $1 "\t" $2 "\t" $3 }' "$TMP" \
    | LC_ALL=C sort -u \
    | awk -F'\t' '
        { key = $1 "\t" $2 }
        key == prev { names = names ", " $3; count++ ; next }
        {
            if (count > 1) printf "  [%s] shared tell \"%s\" — %s\n", preg, ptell, names
            prev = key; preg = $1; ptell = $2; names = $3; count = 1
        }
        END { if (count > 1) printf "  [%s] shared tell \"%s\" — %s\n", preg, ptell, names }
    ')
if [ -n "$DUPES" ]; then
    echo ""
    echo "SHARED tells (two+ main-cast characters, same register — make distinct):"
    printf '%s\n' "$DUPES"
    FAIL=1
fi

echo ""
if [ "$FAIL" -eq 0 ]; then
    echo "[PASS] tell registers are populated and distinct across the main cast"
    exit 0
else
    echo "[FAIL] tell-register issues found — see character-depth.md §B"
    exit 1
fi
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
