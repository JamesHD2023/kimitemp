#!/bin/bash
# ============================================================
# Ideorix — DOCX Integrity Check (v2.7.64)
# Verifies a generated DOCX file is well-formed and (optionally)
# matches its source MD in word count. Catches the failure class
# from the April 2026 user report: DOCX files Word refused to
# open because of null bytes in word/document.xml, and DOCX files
# that were stale snapshots of an earlier MD state.
#
# Fail-closed: exits non-zero if any check fails.
# ============================================================
# Usage:
#   bash docx-integrity-check.sh <docx-path> [<source-md-path>]
#
# - docx-path:       absolute path to the DOCX to verify
# - source-md-path:  optional; when supplied, the DOCX's word
#                    count is compared against the MD's. Tolerance
#                    is ±5% OR ±100 words, whichever is greater
#                    (small chapters get a floor; large chapters
#                    get the percentage band).
#
# The DOCX passes when:
#   - File exists and is non-zero bytes
#   - File is a valid zip (extractable via unzip)
#   - Contains word/document.xml
#   - word/document.xml is parseable as XML (Python ET.fromstring)
#   - word/document.xml contains zero \x00 bytes
#   - (with MD) word counts agree within tolerance
#
# Exit codes:
#   0  All checks pass
#   1  One or more checks failed (FAIL)
#   2  Invalid arguments

set -euo pipefail

DOCX="${1:?Usage: docx-integrity-check.sh <docx-path> [<source-md-path>]}"
MD="${2:-}"

if [ ! -f "$DOCX" ]; then
    echo "DOCX INTEGRITY: FAIL — file not found: $DOCX" >&2
    exit 1
fi

if [ ! -s "$DOCX" ]; then
    echo "DOCX INTEGRITY: FAIL — file is zero bytes: $DOCX" >&2
    exit 1
fi

# Check the file is a valid zip + contains word/document.xml.
if ! unzip -l "$DOCX" >/dev/null 2>&1; then
    echo "DOCX INTEGRITY: FAIL — not a valid zip archive (DOCX = zipped XML): $DOCX" >&2
    echo "  Word + LibreOffice will refuse to open this file." >&2
    exit 1
fi

if ! unzip -l "$DOCX" | grep -q 'word/document.xml'; then
    echo "DOCX INTEGRITY: FAIL — archive does not contain word/document.xml: $DOCX" >&2
    echo "  This isn't a Word document; the DOCX export pipeline produced a malformed file." >&2
    exit 1
fi

# Extract document.xml to a per-run temp dir for content checks.
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
if ! unzip -p "$DOCX" word/document.xml > "$TMP/document.xml" 2>/dev/null; then
    echo "DOCX INTEGRITY: FAIL — could not extract word/document.xml from: $DOCX" >&2
    exit 1
fi

# Null-byte scan. Null bytes in document.xml were the April 2026
# Cowork-session bug — Python string operations in a DOCX-rebuild
# pipeline emitted stray \x00 between document body and section
# properties. XML spec disallows \x00; Word refuses to open the
# file. grep -c counts matching lines; using -a forces text mode
# so the null bytes don't make grep treat the file as binary.
# Portable NUL detection (BSD grep has no -P): count NUL bytes via tr.
NULL_LINES=$(LC_ALL=C tr -dc '\000' < "$TMP/document.xml" | wc -c | tr -d '[:space:]')
[ -z "$NULL_LINES" ] && NULL_LINES=0
if [ "$NULL_LINES" -gt 0 ]; then
    echo "DOCX INTEGRITY: FAIL — word/document.xml contains $NULL_LINES null byte(s) (\\x00)." >&2
    echo "  $DOCX" >&2
    echo "  Word and LibreOffice refuse to open files with null bytes in XML." >&2
    echo "  ACTION: scrub null bytes from the document body before zipping; re-export." >&2
    exit 1
fi

# XML validity check via Python's ElementTree. Defends against
# unclosed tags, mismatched namespaces, stray characters that
# break the parse.
if ! python3 -c "import xml.etree.ElementTree as ET; ET.parse('$TMP/document.xml')" 2>/dev/null; then
    PARSE_ERROR=$(python3 -c "import xml.etree.ElementTree as ET
try:
    ET.parse('$TMP/document.xml')
except ET.ParseError as e:
    print(f'  {e}')
" 2>&1 || true)
    echo "DOCX INTEGRITY: FAIL — word/document.xml does not parse as valid XML." >&2
    echo "  $DOCX" >&2
    [ -n "$PARSE_ERROR" ] && echo "$PARSE_ERROR" >&2
    echo "  ACTION: validate XML with python3 -c 'import xml.etree.ElementTree as ET; ET.parse(...)' before zipping; re-export." >&2
    exit 1
fi

# Optional word-count parity check against source MD.
if [ -n "$MD" ]; then
    if [ ! -f "$MD" ]; then
        echo "DOCX INTEGRITY: FAIL — source MD not found: $MD" >&2
        echo "  (Word-count parity check was requested but source MD path doesn't exist.)" >&2
        exit 1
    fi

    # MD word count: strip YAML frontmatter (between two --- lines
    # at file start), then wc -w on the rest. Match the convention
    # used by scripts/word-count-check.sh.
    MD_WORDS=$(awk 'BEGIN{fm=0} /^---$/{fm++; next} fm==1{next} {print}' "$MD" | wc -w)
    MD_WORDS=$(echo "$MD_WORDS" | tr -dc '0-9')
    [ -z "$MD_WORDS" ] && MD_WORDS=0

    # DOCX word count: extract text from every <w:t> run via Python,
    # then wc -w on the concatenated body. This counts the actual
    # rendered prose, not XML tag soup.
    DOCX_WORDS=$(python3 - "$TMP/document.xml" <<'PY'
import sys
import xml.etree.ElementTree as ET
ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
try:
    tree = ET.parse(sys.argv[1])
    root = tree.getroot()
    text = ' '.join(t.text or '' for t in root.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'))
    print(len(text.split()))
except Exception:
    print(0)
PY
)
    DOCX_WORDS=$(echo "$DOCX_WORDS" | tr -dc '0-9')
    [ -z "$DOCX_WORDS" ] && DOCX_WORDS=0

    # Tolerance: ±5% OR ±100 words, whichever is greater. Small
    # chapters get the 100-word floor so a 50-word delta on a
    # 500-word chapter doesn't false-fail; large chapters get the
    # 5% band so a 50-word delta on a 5000-word chapter is still
    # within tolerance.
    DELTA=$((MD_WORDS - DOCX_WORDS))
    [ "$DELTA" -lt 0 ] && DELTA=$((0 - DELTA))
    TOL_PCT=$((MD_WORDS * 5 / 100))
    TOLERANCE=$TOL_PCT
    [ "$TOLERANCE" -lt 100 ] && TOLERANCE=100

    if [ "$DELTA" -gt "$TOLERANCE" ]; then
        echo "DOCX INTEGRITY: FAIL — word-count drift exceeds tolerance." >&2
        echo "  DOCX:        $DOCX_WORDS words ($DOCX)" >&2
        echo "  Source MD:   $MD_WORDS words ($MD)" >&2
        echo "  Delta:       $DELTA words (tolerance: ±$TOLERANCE = max of ±5% [$TOL_PCT] or ±100)" >&2
        echo "  ACTION: the DOCX is likely a stale snapshot from before the MD was edited;" >&2
        echo "          regenerate the DOCX from the current MD state." >&2
        exit 1
    fi
fi

echo "DOCX INTEGRITY: PASS — XML valid, no null bytes$([ -n "$MD" ] && echo ", word count within tolerance ($DOCX_WORDS vs $MD_WORDS, delta $DELTA)")"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
