#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 10: Violation Dashboard
# Produces a summary report suitable for the Model Health
# Monitor and the Progress Dashboard. Designed to be run after
# the per-chapter audit (ideorix-audit.sh) and to feed its
# output into model-health.md.
# ============================================================
# Usage: bash violation-dashboard.sh <chapter-file> <project-path> [word-target] [model-id]
# Outputs a structured report block that can be appended to model-health.md

set -euo pipefail

CHAPTER="${1:?Usage: violation-dashboard.sh <chapter-file> <project-path> [word-target] [model-id]}"
PROJECT="${2:?Usage: violation-dashboard.sh <chapter-file> <project-path>}"
WORD_TARGET="${3:-2500}"
MODEL_ID="${4:-unknown}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

CH_NAME=$(basename "$CHAPTER" .md)
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
WORDS=$(wc -w < "$CHAPTER")
WORD_PCT=$((WORDS * 100 / WORD_TARGET))

safe_count() { local c; c=$(eval "$1" 2>/dev/null) || true; echo "${c:-0}" | tr -dc '0-9'; }

tr '[:upper:]' '[:lower:]' < "$CHAPTER" > "$TMPDIR/lower.txt"

# Strip YAML front matter and markdown headings; extract dialogue and narration
# spans correctly (handles both straight " ... " and curly " ... " quotes; em-
# dashes inside dialogue do NOT count toward narration even when they share a
# line with quoted speech). Normalize em-dash family imposters (U+2015
# HORIZONTAL BAR, U+2E3A/3B TWO/THREE-EM, U+FE58 SMALL EM) to U+2014 so the
# literal '—' grep below catches them — some authoring tools insert these
# imposters in place of real em-dashes; visually identical, regex-distinct.
awk 'BEGIN{fm=0} /^---$/{fm++; next} fm==1{next} /^#/{next} {print}' "$CHAPTER" \
    | perl -CSDA -pe 's/[\x{2015}\x{2E3A}\x{2E3B}\x{FE58}]/\x{2014}/g' \
    > "$TMPDIR/body.txt"
perl -CSDA -ne '
    while (/[\x{201C}"]([^\x{201D}"]*)[\x{201D}"]/g) { print "$1\n" }
    while (/[\x{2018}]([^\x{2019}]*)[\x{2019}]/g)    { print "$1\n" }
' "$TMPDIR/body.txt" > "$TMPDIR/dial.txt" 2>/dev/null || true
perl -CSDA -pe '
    s/[\x{201C}"][^\x{201D}"]*[\x{201D}"]//g;
    s/[\x{2018}][^\x{2019}]*[\x{2019}]//g;
' "$TMPDIR/body.txt" > "$TMPDIR/narr.txt" 2>/dev/null || true

# Core mechanical counts
NARR_EM=$(safe_count "grep -o '—' '$TMPDIR/narr.txt' | wc -l")
DIAL_EM=$(safe_count "grep -o '—' '$TMPDIR/dial.txt' | wc -l")
FRAME_LEAKS=$(safe_count "grep -ciE 'book [0-9]|book one|book two|the reader|the previous chapter|in chapter [0-9]' '$TMPDIR/lower.txt'")
THE_WAY=$(safe_count "grep -cE 'the way (she|he|they|it|i|we|you) ' '$TMPDIR/lower.txt'")
WHICH_WAS=$(safe_count "grep -cE 'which (was|were) ' '$TMPDIR/lower.txt'")
KIND_OF=$(safe_count "grep -cE '(the kind of|the sort of|the type of|one of those) .* that' '$TMPDIR/lower.txt'")
PARTICULAR=$(safe_count "grep -cE 'the particular .* (that|of) ' '$TMPDIR/lower.txt'")
FILED=$(safe_count "grep -cE '\bfiled\b' '$TMPDIR/lower.txt'")

# Forbidden words (quick count — not full scan)
# v2.7.50: resolution chain — project override → project-root override →
# engine-bundled fallback. Pre-v2.7.50 only checked PROJECT/core/forbidden-words.md
# (no project layout creates that path), so this counter silently reported 0.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FW_FILE=""
[ -f "$PROJECT/engine-data/forbidden-words.md" ] && FW_FILE="$PROJECT/engine-data/forbidden-words.md"
[ -f "$PROJECT/forbidden-words.md" ] && FW_FILE="$PROJECT/forbidden-words.md"
[ -z "$FW_FILE" ] && [ -f "$SCRIPT_DIR/../references/forbidden-words.md" ] \
    && FW_FILE="$SCRIPT_DIR/../references/forbidden-words.md"
FORBIDDEN=0
if [ -n "$FW_FILE" ]; then
    FW_PHRASES=$(grep '^- ' "$FW_FILE" | sed 's/^- //' | tr '[:upper:]' '[:lower:]')
    FORBIDDEN=$(echo "$FW_PHRASES" | while read -r phrase; do
        grep -c "$phrase" "$TMPDIR/lower.txt" 2>/dev/null || true
    done | awk '{s+=$1} END {print s+0}')
fi

# Zero-tolerance total
ZT_TOTAL=$((NARR_EM + FRAME_LEAKS + PARTICULAR))
ZT_TOTAL=$(safe_count "echo $ZT_TOTAL")

# Writer retry count (passed in or 0)
RETRIES="${5:-0}"

# Determine tier
TIER="PASS"
TIER_DETAIL=""

# STOP triggers
if [ "$NARR_EM" -ge 6 ]; then TIER="STOP"; TIER_DETAIL="6+ narration em-dashes"; fi
if [ "$FRAME_LEAKS" -gt 0 ]; then TIER="STOP"; TIER_DETAIL="frame leak detected"; fi
if [ "$ZT_TOTAL" -ge 10 ]; then TIER="STOP"; TIER_DETAIL="10+ zero-tolerance violations"; fi

# WATCH triggers (only if not already STOP)
if [ "$TIER" = "PASS" ]; then
    if [ "$NARR_EM" -ge 3 ]; then TIER="WATCH"; TIER_DETAIL="3-5 narration em-dashes"; fi
    if [ "$WORD_PCT" -lt 90 ] && [ "$WORD_PCT" -ge 85 ]; then TIER="WATCH"; TIER_DETAIL="word count 85-89%"; fi
fi

# Output structured report
echo "=== VIOLATION DASHBOARD — $CH_NAME ==="
echo "Timestamp: $TIMESTAMP"
echo "Model: $MODEL_ID"
echo ""
echo "| Metric | Value | Cap | Status |"
echo "|--------|-------|-----|--------|"
printf "| %-25s | %5d | %5s | %-6s |\n" "Word count" "$WORDS" "$WORD_TARGET" "$([ $WORD_PCT -ge 90 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "Word count %" "$WORD_PCT" "≥90%" "$([ $WORD_PCT -ge 90 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "Narration em-dashes" "$NARR_EM" "0" "$([ $NARR_EM -eq 0 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "Dialogue em-dashes" "$DIAL_EM" "≤3" "$([ $DIAL_EM -le 3 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "Frame leaks" "$FRAME_LEAKS" "0" "$([ $FRAME_LEAKS -eq 0 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "\"the way\"" "$THE_WAY" "≤6" "$([ $THE_WAY -le 6 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "\"which was/were\"" "$WHICH_WAS" "≤2" "$([ $WHICH_WAS -le 2 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "\"the kind/sort of\"" "$KIND_OF" "≤3ms" "$([ $KIND_OF -le 3 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "\"the particular\"" "$PARTICULAR" "0" "$([ $PARTICULAR -eq 0 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "\"filed\"" "$FILED" "≤4" "$([ $FILED -le 4 ] && echo PASS || echo FAIL)"
printf "| %-25s | %5d | %5s | %-6s |\n" "Forbidden word hits" "$FORBIDDEN" "0" "$([ $FORBIDDEN -eq 0 ] && echo PASS || echo FAIL)"
echo ""

echo "Model Health Tier: $TIER"
[ -n "$TIER_DETAIL" ] && echo "Trigger: $TIER_DETAIL"
echo ""

# Output line for model-health.md table
echo "--- model-health.md row ---"
echo "| $CH_NAME | $MODEL_ID | $NARR_EM | $FRAME_LEAKS | $THE_WAY | $WHICH_WAS | $FORBIDDEN | $RETRIES | ${WORD_PCT}% | pending |"

echo ""
echo "=== END VIOLATION DASHBOARD ==="

[ "$TIER" = "STOP" ] && exit 1 || exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
