---
name: market-scout
description: "Ideorix Fiction: live market intelligence for fiction. Trigger: 'Market Scout', 'Comp titles for [genre]', 'What's selling in [genre]', 'Genre demand', 'BookTok trends', 'Trope momentum', 'Current bestsellers in [genre]'. Searches the web for bestseller trends, reader demand, trending tropes, comp titles, price-point guidance, and strategic positioning. Fiction only."
---

This is a trigger entry point for the Ideorix Fiction engine. To handle
this request:

1. Read and follow `skills/ideorix/SKILL.md` from the same plugin
   (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Writers Studio flow at item 9, "Market Scout".
3. Follow `skills/ideorix/references/market-scout.md` (user-facing
   protocol) and `skills/ideorix/references/market-scout-protocol.md`
   (engine-facing search + analysis specification) for the complete
   live-market-intelligence run.

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
