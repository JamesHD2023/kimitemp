---
name: continue-writing
description: "Ideorix Fiction: resume an in-progress novel. Trigger: 'Continue writing', 'Resume my book', 'Next chapter', 'Pick up where I left off', 'Keep going on [project]'. Reads the pipeline checkpoint, runs the prior-chapter continuity pre-load HARD GATE, and dispatches the next unwritten chapter. Fiction only."
---

This is a trigger entry point for the Ideorix Fiction engine. To handle
this request:

1. Read and follow `skills/ideorix/SKILL.md` from the same plugin
   (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Writers Studio flow at item 2, "Continue Writing".
3. Follow `skills/ideorix/references/continue-writing.md` for the
   complete resume protocol (project detection, checkpoint read,
   prior-chapter continuity pre-load, next-chapter dispatch).

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
