---
name: edit-manuscript
description: "Ideorix Fiction: run the editorial pipeline on a finished novel. Trigger: 'Edit my manuscript', 'Edit my novel', 'Editorial pass', 'Proofread my book', 'Run the editor on my fiction', 'BYOM editing'. Supports both Ideorix-generated and user-written / Bring-Your-Own-Manuscript (BYOM) inputs. Fiction only."
---

This is a trigger entry point for the Ideorix Fiction engine. To handle
this request:

1. Read and follow `skills/ideorix/SKILL.md` from the same plugin
   (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Writers Studio flow at item 4, "Edit & Revise".
3. Follow `skills/ideorix/references/edit-and-revise.md` for the
   complete editorial pipeline (supports both Ideorix-generated and
   user-written / BYOM manuscripts).

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
