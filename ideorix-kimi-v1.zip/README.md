# Ideorix for Kimi Claw

**Version:** kimi-v1  
**Date:** 2026-05-18  
**Original System:** Ideorix Manuscript & Screen Engine (c) 2025 James Harvey Media

---

## What This Is

A complete port of the Ideorix writing system from Claude Code to Kimi Claw / OpenClaw. Includes all mechanical audit modules, editorial gates, reference documents, and verification disciplines from the original system, plus additional modules built for the Kimi environment.

## Requirements

- **OpenClaw** (https://openclaw.ai) — the agent runtime
- **Kimi Claw channel** — the Kimi integration for OpenClaw
- **Linux host** — scripts require bash execution

## What Will NOT Work

- Standard Kimi web chat (kimi.ai) — no filesystem access
- Kimi Desktop — unknown; likely no shell access
- Any environment without bash and local filesystem

## Installation

1. Install OpenClaw on a Linux host (local machine, VPS, or cloud instance)
2. Configure the Kimi Claw channel in OpenClaw
3. Copy this `main-fiction-plugin/` directory to your OpenClaw skills path:
   ```
   ~/.openclaw/skills/ideorix/
   ```
4. Ensure all scripts are executable:
   ```bash
   chmod +x ~/.openclaw/skills/ideorix/scripts/*.sh
   ```
5. Start a Kimi Claw session and say "Ideorix" or "Write a book"

## Contents

- **29 shell scripts** — mechanical audits, gates, and verification tools
- **100+ reference documents** — genre guides, format specifications, craft standards
- **2 document templates** — catalog report and sales summary
- **Full SKILL.md** — system entry point and session protocol

## Key Scripts

| Script | Purpose |
|--------|---------|
| `ideorix-audit.sh` | 10-module per-chapter mechanical audit |
| `batch-edit-gate.sh` | Every-5-chapters editorial gate |
| `manuscript-audit.sh` | Full-manuscript aggregated audit |
| `violation-dashboard.sh` | Model health monitoring |
| `class-b-delta-gate.sh` | Rule 1b: continuity delta verification |
| `chapter-integrity-check.sh` | Post-write corruption detection |
| `voice-metrics.sh` | Module 8: FP ratio & sentence stats |
| `voice-trend.sh` | Module 9: Boiled-frog drift detection |
| `anaphora-detect.sh` | Module 10: Consecutive opener detection |

## Differences from Original

- **+3 audit modules** (Voice Metrics, Voice Trend, Anaphora)
- **+4 gate scripts** (Class B Delta, Chapter Integrity, Config Validator, Source Canon)
- **+2 helper scripts** (Leitmotif Tracker, Injury Accumulation)
- Waiver system for known-false-positive scenarios
- Kimi-agnostic language in pipeline docs (removed Claude-specific references)

## License

The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt in the original distribution.

## Support

For licensing questions: contact James Harvey Media
