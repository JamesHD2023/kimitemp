#!/bin/bash
# ============================================================
# Ideorix Config Validator — Pre-Audit Gate
# Validates all reference files before mechanical audit runs.
# Fail-fast on malformed config = saves time on bad runs.
# ============================================================
# Usage: bash config-validator.sh <project-path>
# Exit 0 = all config valid, proceed with audit
# Exit 1 = config errors found, fix before running audit
# ============================================================

set -euo pipefail

PROJECT="${1:?Usage: config-validator.sh <project-path>}"
REFS="$PROJECT/references"
ENGINE="$PROJECT/engine-data"

ERRORS=0
WARNINGS=0

warn() { echo "  [WARN] $1"; WARNINGS=$((WARNINGS + 1)); }
error() { echo "  [ERROR] $1"; ERRORS=$((ERRORS + 1)); }

echo "=== IDEORIX CONFIG VALIDATOR ==="
echo "Project: $PROJECT"
echo ""

# --- Required directories ---
[ ! -d "$PROJECT" ] && error "Project directory does not exist: $PROJECT"
[ ! -d "$REFS" ] && warn "No references/ directory found (optional but recommended)"
[ ! -d "$ENGINE" ] && warn "No engine-data/ directory found (will be created on first run)"

[ "$ERRORS" -gt 0 ] && { echo ""; echo "STATUS: FAIL — $ERRORS error(s), $WARNINGS warning(s)"; exit 1; }

# --- Check core reference files if present ---
if [ -d "$REFS" ]; then
    echo "--- Reference File Checks ---"

    # story-bible.md or research-bible.md (pre-flight gate requirement)
    if [ ! -f "$REFS/story-bible.md" ] && [ ! -f "$REFS/research-bible.md" ]; then
        warn "Neither story-bible.md nor research-bible.md found — pre-flight gate will FAIL"
    fi

    # forbidden-words.md — must have TIER markers
    if [ -f "$REFS/forbidden-words.md" ]; then
        if ! grep -qE '<!-- TIER: [0-9] -->' "$REFS/forbidden-words.md"; then
            error "forbidden-words.md missing TIER markers (e.g., <!-- TIER: 1 -->)"
        fi
        TIER_COUNT=$(grep -cE '<!-- TIER: [0-9]+ -->' "$REFS/forbidden-words.md" || true)
        TIER_COUNT=$(echo "$TIER_COUNT" | tr -dc '0-9'); [ -z "$TIER_COUNT" ] && TIER_COUNT=0
        [ "$TIER_COUNT" -lt 1 ] && error "forbidden-words.md has no valid TIER markers"
        echo "  forbidden-words.md: $TIER_COUNT TIER section(s) — OK"
    else
        warn "forbidden-words.md not found — forbidden-words-scan will SKIP"
    fi

    # entity-canon.md — must be non-empty if present
    if [ -f "$REFS/entity-canon.md" ]; then
        if [ ! -s "$REFS/entity-canon.md" ]; then
            error "entity-canon.md exists but is empty"
        else
            echo "  entity-canon.md: present — OK"
        fi
    fi

    # project-config.md — check for key keys
    if [ -f "$REFS/project-config.md" ] || [ -f "$ENGINE/project-config.md" ]; then
        PCF="${ENGINE}/project-config.md"
        [ ! -f "$PCF" ] && PCF="${REFS}/project-config.md"
        if grep -qE '^target_word_count:|^title:|^genre:' "$PCF" 2>/dev/null; then
            echo "  project-config.md: core keys present — OK"
        else
            warn "project-config.md missing recommended keys (target_word_count, title, genre)"
        fi
    else
        warn "project-config.md not found — gates may fail without legacy flags"
    fi

    echo ""
fi

# --- Check engine-data files ---
if [ -d "$ENGINE" ]; then
    echo "--- Engine Data Checks ---"

    # pipeline-checkpoint.md — can be empty (created on first run)
    if [ -f "$ENGINE/pipeline-checkpoint.md" ]; then
        echo "  pipeline-checkpoint.md: present — OK"
    else
        echo "  pipeline-checkpoint.md: not present (will be created) — OK"
    fi

    # word-counts.md — should exist if chapters have been processed
    if [ -f "$ENGINE/word-counts.md" ]; then
        echo "  word-counts.md: present — OK"
    else
        echo "  word-counts.md: not present — OK"
    fi

    echo ""
fi

# --- Check for dead references in SKILL.md files ---
echo "--- Plugin Internal Consistency ---"
PLUGIN_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEAD_REFS=$(cd "$PLUGIN_ROOT" && bash scripts/plugin-lint.sh 2>&1 || true)
if echo "$DEAD_REFS" | grep -q "DEAD REFERENCE"; then
    echo "  plugin-lint: FAIL — dead references found"
    echo "$DEAD_REFS" | grep "DEAD REFERENCE" | sed 's/^/    /'
    WARNINGS=$((WARNINGS + 1))
else
    echo "  plugin-lint: PASS — all references resolve"
fi

echo ""

# --- Final verdict ---
if [ "$ERRORS" -gt 0 ]; then
    echo "STATUS: FAIL — $ERRORS error(s), $WARNINGS warning(s)"
    echo "ACTION: Fix errors before running mechanical audit."
    exit 1
elif [ "$WARNINGS" -gt 0 ]; then
    echo "STATUS: WARN — $ERRORS error(s), $WARNINGS warning(s)"
    echo "ACTION: Audit can proceed but some modules may SKIP or gates may FAIL."
    exit 0  # Warnings don't block — this is a pre-flight check, not a gate
else
    echo "STATUS: PASS — all configuration valid"
    exit 0
fi
