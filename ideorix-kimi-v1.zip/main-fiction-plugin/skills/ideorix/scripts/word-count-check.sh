#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Word Count Check
# Strips YAML front matter + trailing markdown emphasis before counting.
# Reliable null-byte detection via tr (grep -c $'\x00' is flaky across GNU grep versions).
# ============================================================
set -euo pipefail

CHAPTER="${1:?Usage: word-count-check.sh <chapter-file> [target-words]}"
TARGET="${2:-2500}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

# Strip YAML front matter ONLY when the file actually starts with --- on line 1.
# Without this guard, Markdown scene-break --- separators mid-chapter were
# being treated as YAML delimiters, silently dropping entire scenes from the
# word count (Cowork bug report 2026-05-01).
if head -1 "$CHAPTER" | grep -qE '^---[[:space:]]*$'; then
    ACTUAL=$(awk 'NR==1{next} /^---[[:space:]]*$/ && !done {done=1; next} done{print}' "$CHAPTER" | wc -w)
else
    ACTUAL=$(wc -w < "$CHAPTER")
fi
PCT=$((ACTUAL * 100 / TARGET))
INTERNAL=$((TARGET * 110 / 100))
INTERNAL_PCT=$((ACTUAL * 100 / INTERNAL))

LAST_CHAR=$(perl -0777 -ne 's/[\s*_]+\z//; print substr($_, -1)' < "$CHAPTER")
LAST_LINE=$(tail -n 3 "$CHAPTER" | grep -v '^$' | tail -1 | head -c 80)

FILE_SIZE=$(stat -c%s "$CHAPTER" 2>/dev/null || stat -f%z "$CHAPTER")
NULL_BYTES=$(tr -dc '\0' < "$CHAPTER" | wc -c)

echo "=== WORD COUNT CHECK ==="
echo "Chapter: $CHAPTER"
echo "File size: $FILE_SIZE bytes"
echo ""
echo "--- Word Count ---"
echo "  Published target: $TARGET"
echo "  Internal target (110%): $INTERNAL"
echo "  Actual words: $ACTUAL"
echo "  % of published target: ${PCT}%"
echo "  % of internal target: ${INTERNAL_PCT}%"

FAIL=0
if [ "$PCT" -lt 90 ]; then
    echo "  STATUS: FAIL — below 90% of target (${PCT}%)"
    FAIL=1
elif [ "$PCT" -gt 125 ]; then
    echo "  STATUS: WARN — above 125% of target (${PCT}%)"
else
    echo "  STATUS: PASS"
fi

echo ""
echo "--- File Integrity ---"
echo "  Last line: $LAST_LINE"
echo "  Last character: '$LAST_CHAR'"
case "$LAST_CHAR" in
    '.'|'!'|'?'|'"'|"'"|')'|']')
        echo "  Terminal punctuation: PASS"
        ;;
    *)
        echo "  Terminal punctuation: FAIL — file may be truncated (last char: '$LAST_CHAR')"
        FAIL=1
        ;;
esac
printf "  Null bytes: %02d\n" "$NULL_BYTES"
if [ "$NULL_BYTES" -eq 0 ]; then
    echo "  Null byte check: PASS"
else
    echo "  Null byte check: FAIL — file corrupted"
    FAIL=1
fi

echo ""
echo "=== SUMMARY ==="
echo "Words: $ACTUAL / $TARGET (${PCT}%) | File: ${FILE_SIZE}b | Null: $(printf '%02d' $NULL_BYTES)"
if [ "$FAIL" -eq 1 ]; then
    echo "STATUS: FAIL"
    exit 1
fi
echo "STATUS: PASS"
exit 0
