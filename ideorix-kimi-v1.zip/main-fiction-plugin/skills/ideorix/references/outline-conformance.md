---
name: outline-conformance
description: "Brief-time verification agent that checks whether a chapter brief conforms to the Story Bible's chapter outline — catches drift before the Writer runs"
version: "2.6.8"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Outline Conformance Agent

## Purpose

Block or flag chapter briefs that drift from Story Bible Section 12 (Chapter
Outline) **before the Writer runs**. This is the only verification agent that
runs at brief-generation time rather than at chapter-completion time — all
other verifiers (Continuity, Quality, Timeline, Character, Arc) run AFTER
prose is written. By then, drift is expensive to fix.

## Why It Exists (Root Cause)

In production testing, a manuscript drifted from its outline across three
consecutive chapters. The Architect invented a new Chekhov's gun in Ch9 that
wasn't in Section 14. Because Ideorix's discipline says all guns must be
fired, the gun consumed Ch10, Ch11, and Ch12 with a new thread. Each chapter
passed verification individually — the craft was fine, the continuity was
fine, the pacing was fine. But the Story Bible's planned Ch11 and Ch12 beats
(a pinch point, a city chase, a war-room scene) silently fell off the
calendar. The drift was invisible at every sign-off because each chapter was
a coherent continuation of the previous one.

The existing 5-verification-agent suite had no outline-conformance check.
Every agent was zoomed in to chapter-level craft. Nobody was zoomed out to
"does this brief deliver what Section 12 says this chapter is?"

This agent fills that gap.

## When It Runs

**At brief-generation time.** Specifically, between the Architect producing
the draft brief and the User Review Gate. See `core-pipeline.md` Phase 3
step 5a.

Flow:
1. Architect generates draft brief (step 5)
2. **Outline Conformance Agent runs (step 5a — NEW)**
3. User Review Gate receives BOTH the brief AND the conformance report (step 6)
4. User approves, edits, or aborts (with full drift visibility)
5. Writer runs (step 7)

## Inputs

The agent receives:

1. **The draft brief** produced by the Architect for Chapter N
2. **Story Bible Section 12's entry for Chapter N** — the canonical specification
3. **Story Bible Section 14's Chekhov gun list** — the locked gun schedule
4. **The beats-remaining ledger** — beats from Section 12 that haven't shipped
   in earlier chapters yet (loaded from `engine-data/beat-delivery-log.md`)
5. **The manuscript's total chapter count** — used for sustainability math
6. **The current chapter number (N)** — used to calculate remaining capacity

## Adaptation Mode (screenplay → novel)

**If `engine-data/project-config.md` contains
`adaptation_mode: screenplay_adaptation`, the canonical outline
source changes.** Instead of Story Bible Section 12 as the authority,
the OC Agent reads `engine-data/scene-to-chapter-map.md` and
`engine-data/screenplay-source.md` to determine which screenplay
scenes are mapped to the current chapter. Those scenes — with their
action lines, dialogue, and transitions — become the canonical
outline.

The 6 checks below still apply, with these adaptations:

- **Check A (Goal Match):** compared against the dramatic function of
  the mapped source scenes (from their synopses if present, else from
  the action arc)
- **Check B (Required Beat Delivery):** every source scene's action
  and dialogue must appear in the brief's Beats section, mapped
  explicitly to a source scene number
- **Check C (No Silent Drops):** any source scene beat not in the
  brief is a DROP → FAIL
- **Check D (No Unauthorised Additions):** any beat in the brief not
  traceable to a source scene is an ADDITION → FAIL; this includes
  new characters (must be in Entity Canon from `screenplay-importer.md`)
  and new locations
- **Check E (Zoom-Out Sustainability):** remaining screenplay scenes
  ≤ remaining chapters × average scenes-per-chapter from the chunker
- **Check F (Chekhov Gun Room):** in adaptation mode, any new gun in
  the brief that isn't from the screenplay is an UNAUTHORISED
  ADDITION (Check D failure)

See `screenplay-expansion.md` for the full adaptation-mode behaviour
across Architect, Writer, and this OC Agent.

## Checks (6 total)

### Check A — Chapter Goal Match

Compare the brief's Chapter Goal / Chapter Purpose field against Section 12's
stated goal for Ch N.

| Result | Criterion |
|---|---|
| **PASS** | Same goal, possibly with minor rewording |
| **WARN** | Overlapping goal but different emphasis (e.g., Section 12 says "Fred investigates voicemail source"; brief says "Fred examines the paper") |
| **FAIL** | Entirely different goal (e.g., Section 12 says "Pinch Point 2: voicemail fires"; brief says "Fred reads a folded paper") |

### Check B — Required Beat Delivery

For each beat Section 12 lists for Ch N, check whether the brief delivers it.

A beat is "delivered" if the brief's scene breakdown, emotional map, or
Chapter Purpose explicitly references it. A beat is NOT delivered if it is
absent or only referenced in a "maybe later" hand-wave.

| Result | Criterion |
|---|---|
| **PASS** | All Section 12 beats for Ch N are present in the brief |
| **WARN** | Most beats present, 1 minor beat deferred to a later chapter with user consent |
| **FAIL** | 1+ beat dropped without explanation, OR 2+ beats deferred |

### Check C — No Silent Drops

Any Section 12 beat for Ch N that the brief does NOT mention — at all,
anywhere — is a silent drop. This is the most dangerous drift pattern because
the beat is simply forgotten.

| Result | Criterion |
|---|---|
| **PASS** | Every Section 12 beat for Ch N appears somewhere in the brief |
| **FAIL** | Any Section 12 beat is missing from the brief without a deferral note |

### Check D — No Unauthorised Additions

Scan the brief for NEW narrative elements not in the Story Bible:

1. **New characters** not in Section 2 (Cast) — **FAIL** unless the user
   pre-approved a mid-book character addition
2. **New Chekhov guns** not in Section 14 — **FAIL** (see Check F for the
   dedicated gun check)
3. **New subplots or mystery threads** not in Section 7 (Subplots) or
   Section 12 — **FAIL**
4. **New locations** not in Section 5 (Locations) — **WARN** (new minor
   locations are often fine, but flag for user awareness)
5. **New object introductions** that feel like setups for future payoffs —
   **WARN** and ask the Architect whether this is an implicit new Chekhov gun

Any FAIL here requires user consent before the brief can proceed — either
accept the addition and update the Story Bible, or revise the brief.

### Check E — Zoom-Out Sustainability

This is the critical cumulative check.

**Beat-delivery log validation (MANDATORY — runs BEFORE sustainability
math):**

The sustainability calculation depends on `remaining_beats`, which comes
from `engine-data/beat-delivery-log.md`. If this log is inaccurate
(beats marked as delivered when the chapter didn't actually deliver
them), the math silently fails. Before using the log:

1. For each beat the log claims was delivered in the MOST RECENT chapter
   (Ch N-1), spot-check against the actual chapter file: grep the
   chapter prose for the beat's key event or character action. If the
   beat's signature content is absent from the prose, the log entry is
   stale (sourced from the brief, not the shipped chapter).
2. If any beat claim fails spot-check: flag as WARN in the conformance
   report — "Beat '{beat_name}' marked as delivered in Ch {N-1} but
   not found in chapter prose. Sustainability math may be optimistic."
3. Recalculate `remaining_beats` using only verified deliveries.

This validation adds ~10 seconds per chapter. It prevents the
sustainability check from reporting "on track" when beats have silently
accumulated.

```
remaining_chapters = total_chapters - current_chapter_number + 1
remaining_beats = count(Section 12 beats not yet delivered in prior chapters)
typical_beats_per_chapter = lookup(length_tier)  ← see table below

capacity = remaining_chapters × typical_beats_per_chapter
delivery_rate_needed = remaining_beats ÷ remaining_chapters
```

**Typical beats-per-chapter by length tier (MANDATORY lookup table):**

Derived from ~1.5 beats per 1,000 words of chapter length — the observed
density of Section 12 entries across Ideorix genre files. This scales
naturally: longer chapters have room for more beats, shorter chapters
compress tighter. The agent MUST use this exact table — not a guess.

| Length Tier | Words/Chapter | Typical Beats/Chapter |
|---|---|---|
| Short Story | ~1,600 | **3** |
| Novelette | ~1,400 | **3** |
| Novella (recommended) | ~2,500 | **4** |
| Standard Novel | ~2,500 | **4** |
| Epic Novel | ~3,000 | **5** |

Read the length tier from `engine-data/project-config.md` — it's recorded
during Phase 1 Question 6 (Length Tier) and does not change during a
project. If `project-config.md` is missing or the length tier cannot be
determined, default to **4** (Novella/Standard Novel) and log the fallback
in the conformance report so the user can confirm.

**Verdict thresholds:**

| Result | Criterion |
|---|---|
| **PASS** | `delivery_rate_needed ≤ typical_beats_per_chapter` — sustainable |
| **WARN (TIGHT)** | `delivery_rate_needed` is 1.0× to 1.5× typical — tight, compression likely needed |
| **WARN (DRIFT)** | `delivery_rate_needed` is 1.5× to 2× typical — beats will have to compress aggressively |
| **FAIL** | `delivery_rate_needed` > 2× typical — beats will be dropped; surface immediately |

Even if Check A-D all PASS, a FAIL on Check E means the manuscript will run
out of chapters before running out of beats. This catches the *slow* drift
pattern that accumulates over several chapters.

### Check F — Chekhov Gun Room

If the brief plants a NEW Chekhov gun not in Section 14, check whether
Section 14 has room for it to fire within the remaining chapters.

```
new_gun_min_chapters = 3  (minimum distance between plant and fire)
remaining_after_plant = total_chapters - current_chapter_number
has_room = remaining_after_plant >= new_gun_min_chapters AND
           there exists a free chapter in remaining chapters where the gun
           can fire without displacing a planned beat
```

| Result | Criterion |
|---|---|
| **PASS** | No new guns planted, OR Section 14 has room for the new gun to fire |
| **WARN** | New gun has tight room (fires in the penultimate chapter, displaces no beats) |
| **FAIL** | New gun has no room to fire without displacing a planned beat |

If this check FAILs, the brief must either:
1. Remove the new gun (hold for next book)
2. Explicitly request displacement of a specific planned beat from a later chapter
3. Surface the conflict to the user for a decision

**Gun deduplication check (runs alongside the room check):**

If the brief proposes a new gun, compare it against all existing guns
in Section 14. For each existing gun, check whether the new gun serves
a SIMILAR narrative function:

- Same category (both are documents, both are weapons, both are
  relationship secrets, both are financial evidence)
- Same dramatic purpose (both prove guilt, both reveal identity, both
  force a confrontation)

If a functional duplicate is detected: WARN — "Proposed gun '{new_gun}'
serves a similar function to existing gun '{existing_gun}' (both are
{category} that {purpose}). Consider whether two similar guns dilute
impact. The user should confirm this is intentional."

This is advisory (WARN), not blocking — the user may want two similar
guns for thematic emphasis. But the warning prevents accidental
redundancy.

### Check G — Scene-Level Structure

Validate that each scene in the brief has the four mandatory fields:

1. **SCENE GOAL** — specific, concrete objective (not vague)
2. **SCENE OBSTACLE** — something blocks the goal
3. **SCENE TURNING POINT** — the scene changes direction
4. **EXIT EMOTIONAL BEAT** — character's emotional state differs
   from scene start

| Result | Criterion |
|---|---|
| **PASS** | All scenes have all 4 fields populated with specific content |
| **WARN** | 1 scene missing 1 field, or a field is vague ("things develop") |
| **FAIL** | 2+ scenes missing turning points, or ALL scenes lack obstacles |

Also check word budgets: per-scene budgets must sum to ±10% of the
chapter target. If a scene's budget is <15% of the chapter, it is
too thin to be a separate scene — merge it or expand it.

## Overall Verdict

Combine the seven checks into a single verdict:

| Individual Check Results | Overall Verdict |
|---|---|
| All seven PASS | **PASS** — proceed to User Review Gate normally |
| Any WARN, no FAIL | **WARN** — proceed to User Review Gate with divergence report attached |
| Any FAIL | **FAIL** — STOP. Present divergence report to user. Require explicit user decision before proceeding. |

## Output Format (v1 — audit footer consolidated into brief file)

As of v1 of the `IDEORIX:AUDIT` footer format, the Outline Conformance
Agent does NOT write a separate `ch{NN}-outline-conformance.md` file
in the common case. Instead, the audit is appended to the chapter's
brief file (`engine-data/chapter-briefs/ch{NN}-brief.md`) as a
delimited footer using HTML comment markers:

```
<!-- IDEORIX:AUDIT:BEGIN v1 -->

## Outline Conformance Audit
Verdict: PASS | WARN | FAIL
Ran at: Chapter {N} brief-generation time
Agent: Outline Conformance Agent (6 checks)

Check A (Chapter Goal Match):         {result} — {reason if not pass}
Check B (Required Beat Delivery):     {result} — {...}
Check C (No Silent Drops):            {result} — {...}
Check D (No Unauthorised Additions):  {result} — {...}
Check E (Zoom-Out Sustainability):    {result} — {...}
Check F (Chekhov Gun Room):           {result} — {...}

{drift detail list if any}
{recommendations if any}

<!-- IDEORIX:AUDIT:END -->
```

See `core-pipeline.md` step 5a Execution Procedure for the full write
protocol and the 100-line cap + overflow handling.

### Why the footer is in the brief file (not a separate file)

The OC report used to be a standalone file at
`engine-data/reports/ch{NN}-outline-conformance.md`. This added one
file per chapter to Claude Desktop's Sources panel, cluttering the
user's view over long runs. Consolidation v1 merges the audit into
the brief file so:

- The audit travels with its brief — they're logically one artefact
- One fewer file per chapter in the Sources panel
- No information lost — all audit content is preserved in the brief
- The Progress Dashboard's Outline Conformance line still reads the
  verdict from the pipeline-checkpoint's `OC Verdict` column (same as
  before; no downstream dependency on the standalone file)

### Marker format (critical)

The delimiters use HTML-comment syntax so they render as nothing in
any markdown viewer:

```
<!-- IDEORIX:AUDIT:BEGIN v1 -->
...audit content in plain markdown (headings, tables, lists)...
<!-- IDEORIX:AUDIT:END -->
```

The `IDEORIX:AUDIT` namespace is unambiguous — no writer would type
that string into a creative brief — so the Architect's "strip audit
block" operation can safely remove everything between the markers
without risk of eating legitimate content. The `v1` version tag
allows future schema changes (e.g., adding new fields, restructuring
the verdict block) without breaking migration for older audits.

The content between the markers is plain visible markdown — headings,
tables, verdict lines, drift details. Humans reading the brief file
see the audit clearly. The markers themselves are invisible in any
markdown preview.

### 100-line cap and overflow

The audit block is capped at 100 lines between the BEGIN and END
markers (inclusive). Clean PASS audits typically fit in 20-30 lines.
WARN audits with a few findings fit in 40-60 lines. FAIL audits with
many drift items can exceed 100 lines.

**When the audit exceeds 100 lines:**

1. Write the FULL audit to `engine-data/reports/ch{NN}-oc-detail.md`
   as a standalone overflow file (single Write tool call).
2. Append a SUMMARY block (still wrapped in the IDEORIX:AUDIT markers)
   to the brief file containing:
   - The verdict line
   - The 6-check summary table
   - Top 3 drift items
   - A pointer line: "Full audit detail:
     `engine-data/reports/ch{NN}-oc-detail.md`"
3. The summary fits in <50 lines and still gives the user at-a-glance
   visibility into the finding.

Overflow is rare — FAIL cases with >10 drift items. The common case
is zero overflow files per book.

### Checkpoint OC Location field

When the OC audit completes, set the checkpoint `OC Location` field:

- `inline` — audit footer appended to the brief file (default for
  PASS and WARN, and for FAIL cases under the overflow threshold)
- `separate` — full detail written to
  `engine-data/reports/ch{NN}-oc-detail.md` using the bash-direct
  protocol; summary footer in the brief

The overflow threshold is **500 characters** of FAIL-detail content
(not counting the PASS/WARN summary header). Pre-Flight reconciliation
uses this field to know which file to verify on disk.

### Stripping the audit block when loading the brief

Downstream steps (Architect reading its own brief for reference,
Writer pre-load, batch editor) must strip the audit block when
loading the brief file so that only the original brief content is
used for downstream generation:

```
content = read("engine-data/chapter-briefs/ch{NN}-brief.md")
content = re.sub(
    r'<!-- IDEORIX:AUDIT:BEGIN v\d+ -->.*?<!-- IDEORIX:AUDIT:END -->',
    '',
    content,
    flags=re.DOTALL
).rstrip()
```

(Or the equivalent in whatever the skill runtime supports — the
important thing is that the strip is greedy across newlines and
version-tolerant.)

### Legacy format (deprecated)

Prior to v1 of the IDEORIX:AUDIT footer, the OC Agent wrote a
standalone file at `engine-data/reports/ch{NN}-outline-conformance.md`.
That file format is DEPRECATED and no longer produced in the common
case. For projects created under the old format, existing
`ch{NN}-outline-conformance.md` files are left in place (they're still
readable and auditable); new chapters use the v1 footer format.

### Legacy file structure (for reference — no longer produced)

The older standalone report used this structure:

```markdown
# Outline Conformance Report — Chapter {N}

**Verdict:** PASS | WARN | FAIL
**Generated:** {ISO timestamp}
**Brief source:** engine-data/chapter-briefs/ch{NN}-brief.md
**Story Bible reference:** Section 12, Chapter {N} entry

## Check Summary

| Check | Result | Detail |
|---|---|---|
| A. Chapter Goal Match | PASS/WARN/FAIL | {one-line summary} |
| B. Required Beat Delivery | PASS/WARN/FAIL | {one-line summary} |
| C. No Silent Drops | PASS/WARN/FAIL | {count dropped / 0} |
| D. No Unauthorised Additions | PASS/WARN/FAIL | {count additions / 0} |
| E. Zoom-Out Sustainability | PASS/WARN/FAIL | {delivery rate vs capacity} |
| F. Chekhov Gun Room | PASS/WARN/FAIL | {new guns / room check} |

## Detailed Findings

### Section 12 (Ch {N}) says:
> {verbatim Section 12 entry for this chapter}

### The brief delivers:
- {brief Chapter Purpose}
- {brief scene list highlights}

### Divergences:
{If any: itemised list of each divergence with severity and recommendation}

### Silent drops (if any):
- Beat: "{Section 12 beat text}"
  Status: Not referenced in brief
  Severity: FAIL

### Unauthorised additions (if any):
- Element: "{new character / gun / subplot}"
  Status: Not in Story Bible
  Severity: FAIL

### Sustainability math:
- Total chapters: {total}
- Current chapter: {N}
- Remaining chapters (including this one): {remaining}
- Remaining Section 12 beats (all chapters): {remaining_beats}
- Delivery rate needed: {rate} beats/chapter
- Typical capacity: {typical} beats/chapter
- Status: {PASS/WARN/FAIL}

### Chekhov gun status:
- Section 14 planned guns: {count}
- Currently planted: {count}
- Fired so far: {count}
- Unfired with <3 chapters to fire: {list}
- New guns in this brief: {list or "none"}
- Room check: {PASS/WARN/FAIL}

## User Decision Required (FAIL only)

If Verdict is FAIL, present these options to the user via AskUserQuestion:

1. **Keep brief as-is** — The drift is intentional. Update Story Bible
   Section 12 (and Section 14 if Chekhov guns are involved) to reflect the
   new narrative path. The updated Section 12 becomes the new baseline for
   all subsequent conformance checks.

2. **Revise brief to match Section 12** — Return the brief to the Architect
   with a directive: "Remove {specific drift} and deliver {specific dropped
   beats} per Section 12 Ch {N}."

3. **Abort this chapter** — Discard the brief entirely. Regenerate from
   Section 12 Ch {N} as the sole input, ignoring prior-chapter carry-forward
   state. Use this when the Architect has pulled the brief far enough from
   the plan that revision isn't feasible.

Record the user's decision in `engine-data/outline-conformance-log.md` as
an audit trail.
```

## Agent System Prompt

```
You are the Outline Conformance Agent — a specialised verification agent that
checks whether a chapter brief delivers what the Story Bible says the chapter
should deliver. You run at BRIEF-GENERATION time, before the Writer runs.

You do NOT evaluate prose craft, continuity, pacing, voice, or any other
chapter-level concern. Those are handled by other agents AFTER the chapter
is written. Your single job is: **does this brief conform to Section 12?**

Your checks are mechanical. Be strict. A PASS verdict means the brief
faithfully implements the planned chapter. A FAIL verdict means the brief
has drifted in a way the user needs to decide about before prose is written.

Do not try to be helpful by softening FAILs to WARNs. A dropped beat is a
dropped beat. A new Chekhov gun is a new Chekhov gun. Surface them clearly.

If Section 12 is ambiguous or missing for this chapter number, output a
WARN with "Section 12 incomplete — manual review required" and let the
user decide. Do not fabricate conformance against absent content.

Read Section 12 and Section 14 verbatim. Quote them in the report so the
user can see exactly what the outline says.
```

## Integration with the Existing Verification Suite

This agent is the **6th verification agent**, but it's fundamentally
different from the other five:

| Agent | Runs When | Scope |
|---|---|---|
| **Outline Conformance** | Brief time (BEFORE Writer) | Brief vs Story Bible outline |
| Continuity Guardian | Chapter complete | Chapter prose vs prior chapters |
| Quality Guardian | Chapter complete | Prose craft and genre fit |
| Timeline Keeper | Chapter complete | Temporal consistency |
| Character Tracker | Chapter complete | Character voice and behaviour |
| Arc Analyst | Chapter complete | Structural beats and pacing curve |

The other five catch problems that are already written into prose. Outline
Conformance catches problems BEFORE prose is written. This order matters:
the cheapest fix is one that never ships.

## Decision Log

All WARN and FAIL verdicts are appended to
`engine-data/outline-conformance-log.md` with:

```markdown
## Ch{NN} — {YYYY-MM-DD HH:MM}

**Verdict:** WARN | FAIL
**Divergences:** {bullet list}
**User decision:** Keep as-is / Revise / Abort
**Story Bible update:** {yes/no — which sections were updated}
**Rationale:** {user's reasoning, captured via free-text}
```

This log is the audit trail for outline drift across the manuscript. It
answers questions like: "When did the engine first diverge from the plan?
What did the user accept vs reject? What triggered the divergence?"

## Anti-Patterns

1. **Do NOT run this agent after the chapter is written.** The point is to
   catch drift before prose exists. Running it after is too late — the cost
   of discarding written prose pushes users to accept bad drifts.

2. **Do NOT silently accept new Chekhov guns.** Every new gun invented during
   brief generation is a deliberate narrative decision that affects every
   subsequent chapter. The user must explicitly approve it.

3. **Do NOT treat beat deferrals as equivalent to beat delivery.** A beat
   "moved to Ch N+1" is a deferral, not a delivery. Track deferrals in the
   ledger and flag them if they stack.

4. **Do NOT skip the zoom-out sustainability check even when Checks A-D
   pass.** Drift is usually cumulative — a single brief that looks fine can
   still push the manuscript past its capacity. The sustainability math is
   what catches that pattern.

5. **Do NOT fabricate conformance against missing Section 12 content.** If
   the outline is thin, say so. Ambiguous outlines require user clarification,
   not agent improvisation.

## Failure Modes

| Scenario | Response |
|---|---|
| Section 12 missing for Ch N | Output WARN with "Section 12 incomplete"; user must clarify |
| Section 12 too vague to check | Output WARN; user must tighten outline |
| Brief has no explicit goal | FAIL — ask Architect to regenerate with a clear goal |
| Beat delivery log not found | Generate it from prior chapter summaries before running checks |
| User insists on drift | Accept decision, update Section 12, log the decision |

## Future Enhancements

v2 will add:
- Tension curve conformance (brief vs planned tension slider trajectory)
- Character arc conformance (brief advances arcs per Story Bible Section 3)
- POV rotation conformance (brief uses the scheduled POV from Section 12)
- Automatic Story Bible update proposals when the user accepts a drift
