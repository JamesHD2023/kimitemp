---
name: silent-failure-audit
description: "Silent-Failure Audit Discipline — methodology for finding and fixing the recurring failure pattern where a primitive operation returns success metadata that diverges from its actual effect, the engine treats success-claim as success-fact, and the user catches the divergence after wasted work. This spec catalogs every audited primitive with its current verification status, defines the audit methodology for new features, and lists the canonical fix protocols. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.7"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Silent-Failure Audit Discipline

## The recurring failure pattern

Every catastrophic user-facing failure documented in production
since v2.6.7 has the same structural shape:

> A primitive operation returns success metadata that diverges
> from its actual effect. The engine treats the success-claim
> as success-fact and proceeds. The user catches the divergence
> after wasted work.

Every fix shipped between v2.6.7 and v2.7.6 names the same shape:

| Release | Primitive | Success-claim | Actual divergence | Fix binding |
|---------|-----------|---------------|-------------------|-------------|
| v2.6.7 | Edit tool (chained) | Edit succeeded | Truncation mid-paragraph | Chained-Edit Truncation Safeguard |
| v2.6.7 | File-Write tool | Write succeeded | Subdir not flushed; file invisible | File-Write Hygiene |
| v2.6.8 | Training-data recall | "I know this fact" | Fabricated citation | Verification Discipline |
| v2.7.0 | Read tool (file existence) | File exists in source-canon/ | Read of file not yet attempted | BYO-canon Step 0 (file-existence gate) |
| v2.7.3 | python-docx round-trip | DOCX written | Paragraphs silently dropped | Tracked-Changes Phase A→C protocol |
| v2.7.4 | Edit tool (typography) | Edit succeeded | Wrong byte (curly vs ASCII) inserted | Edit-Tool Typographic Fidelity |
| v2.7.6 | Read tool (content) | Read succeeded with byte-size | Zero extracted text | Read-Verification |
| v2.7.7 | WebFetch | Fetch succeeded | Paywall stub / redirect / empty / cached-stale | Web-Content Verification |
| v2.7.7 | Subagent dispatch | Subagent returned "complete" | Stub / hallucinated content with no evidence | Subagent Output Verification |

Naming the shape lets us find the rest. This spec is the
catalog of audited primitives + the methodology for auditing
new ones.

## The audit methodology — three questions per primitive

For every primitive operation the engine relies on, ask three
questions:

1. **What does this primitive's success metadata claim?**
   (return value, exit code, message, byte count, "complete"
   status, file existence, network 200)

2. **What can actually go wrong while success is reported?**
   (empty result, partial result, wrong-encoding result,
   stale-cached result, fabricated/hallucinated result,
   paywall / redirect / placeholder content, zero matches
   misread as "no failures")

3. **Does any spec verify the actual effect, not just the
   metadata?** (post-condition check, content-presence check,
   integrity verification, cross-validation, byte-count check,
   evidence-bearing verification)

If the answer to question 3 is "no" — that's a hole. Document
the hole. Decide on action: add binding / add protocol / wire
into existing protocol / accept risk with explicit rationale.

## The catalog — every audited primitive

Status legend:
- **COVERED** — explicit binding/protocol verifies actual effect
- **PARTIAL** — some flows verify; others don't
- **UNAUDITED** — no verification beyond success metadata
- **ACCEPTED** — risk acknowledged; no fix planned (with rationale)

| # | Primitive | Status | Binding / Spec | Notes |
|---|-----------|--------|----------------|-------|
| 1 | Edit tool (chained) | COVERED | Chained-Edit Truncation Safeguard | core-pipeline.md § File-Write Hygiene |
| 2 | Write tool | COVERED | File-Write Hygiene binding | core-pipeline.md § File-Write Hygiene |
| 3 | Edit tool (typography) | COVERED | Edit-Tool Typographic Fidelity | core-pipeline.md § Edit-Tool Typographic Fidelity |
| 4 | Read tool (user files) | COVERED | Read-Verification binding | read-verification.md (v2.7.6) |
| 5 | python-docx round-trip | COVERED | Tracked-Changes Phase A→C | tracked-changes.md (v2.7.3+) |
| 6 | Training-data factual recall | COVERED | Verification Discipline | verification-discipline.md (v2.6.8) |
| 7 | WebSearch (fabrication) | COVERED | Verification Discipline two-phase WebSearch | verification-discipline.md |
| 8 | WebFetch (paywall / empty / stale) | COVERED | Web-Content Verification | web-content-verification.md (v2.7.7) |
| 9 | WebSearch (transient empty) | COVERED | Web-Content Verification | web-content-verification.md (v2.7.7) — distinguishes "search returned zero" from "search failed" |
| 10 | Subagent dispatch (file-writing) | COVERED | File-Write Hygiene "Subagent dispatch FORBIDDEN" rule | core-pipeline.md |
| 11 | Subagent dispatch (evidence-bearing) | COVERED | Subagent Output Verification | subagent-output-verification.md (v2.7.7) |
| 12 | Bash exit codes (find/grep/awk) | COVERED | Bash-Output Verification | bash-output-verification.md (v2.7.8) |
| 13 | Glob / Grep result lists | COVERED | Bash-Output Verification | bash-output-verification.md (v2.7.8) — nullglob discipline + expected-shape check |
| 14 | AskUserQuestion (ambiguity) | COVERED | AskUserQuestion Disambiguation | ask-user-disambiguation.md (v2.7.8) |
| 15 | PDF page-by-page Read | COVERED | Read-Verification (per-page extension) | read-verification.md § Page-by-page PDF Read discipline (v2.7.8) |
| 16 | File-freshness post-write | COVERED | File-Write Hygiene (post-write extension) | core-pipeline.md § File-Freshness Post-Write Discipline (v2.7.8) |
| 17 | Skill / reference file load | COVERED at build time | spec-lint Check 3 + Check 5 | Runtime missing-file returns Read error — surfaced |
| 18 | TodoWrite | ACCEPTED | none needed | Local in-process state; failure is explicit error |
| 19 | Pipeline-checkpoint state | COVERED | core-pipeline.md per-stage HARD GATE | Each stage verifies checkpoint reflects prior stage completion |
| 20 | Engine-internal file Reads (e.g. running-banlist, summaries) | ACCEPTED | none needed | File-Write Hygiene verifies at write time; subsequent Reads in same session are reliable |

## Discipline for NEW features

Every new feature spec MUST contain a **Silent-Failure Audit**
section that answers the three audit questions for every
primitive the feature uses. The section is mandatory; it's
checked structurally by `spec-lint.sh` Check 10.

### Required structure

```markdown
## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification
binding are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read | "Read succeeded with N bytes" | Empty extraction | read-verification.md HARD GATE invoked at step X |
| Write | "Write succeeded" | Subdir flush failure | File-Write Hygiene bash-direct write protocol applied at step Y |
| WebFetch | "200 OK with N bytes" | Paywall stub / redirect | web-content-verification.md applied at step Z |
| ... | ... | ... | ... |
```

If a primitive used by the feature is not in the catalog
above, the feature spec MUST either:
- Add a new entry to the catalog (extend this spec), OR
- Document why the primitive's success metadata is sufficient
  (i.e. no verification needed — explicit ACCEPTED rationale)

### When to invoke an existing binding vs add a new one

- **Reuse existing binding:** if the primitive already has a
  COVERED status in the catalog, the feature spec just cites
  the existing binding and points to the relevant step where
  it's invoked.
- **Add new binding:** if the primitive is UNAUDITED, the
  feature can either (a) defer to Wave 2 with explicit
  acceptance, or (b) author a new canonical protocol spec
  (mirror set if engine-agnostic) and update this catalog.

### What this discipline prevents

- New features shipping with the same shape of failure modes
  v2.6.7-v2.7.7 spent eight releases fixing.
- Implicit reliance on success metadata that doesn't verify
  actual effect.
- Drift between "we know this primitive can fail silently" and
  "the new spec doesn't address that".

## Wave 2 audit (shipped in v2.7.8)

All four Wave 2 items are now COVERED:

1. **Bash-output verification** — `bash-output-verification.md`
   (v2.7.8). Per-invocation expected-shape verification;
   distinguish "search ran with zero results" from "search
   broken"; HARD GATE on FAILED_BASH; pipefail discipline;
   nullglob discipline.

2. **AskUserQuestion disambiguation** — `ask-user-disambiguation.md`
   (v2.7.8). Single-decision-per-ask rule; AMBIGUOUS-response
   confirmation echo; ambiguity-detection heuristics;
   HARD GATE on ambiguous-without-confirmation.

3. **Page-by-page PDF Read iteration** — extension to
   `read-verification.md` § Page-by-page PDF Read discipline
   (v2.7.8). Per-page threshold check during `pages: "N"`
   iteration; below-threshold pages flagged in `FAILED_READS`;
   resolution-paste format for missing pages.

4. **File-freshness post-write** — extension to
   `core-pipeline.md` § File-Freshness Post-Write Discipline
   (v2.7.8). Per-session ledger of (path, mtime, sha256) at
   write time; mtime comparison before re-Read; surface
   external modifications to user before any subsequent
   write; re-Read invokes Read-Verification.

## Anti-patterns this discipline prevents

- **Implicit success-claim trust** — "the tool returned no
  error, so the operation worked" without checking actual
  effect.
- **Silent-failure cascade** — empty/partial result absorbed
  as canonical, downstream agent fabricates against missing
  foundation, user discovers after wasted work.
- **One-off fix without binding** — fix the immediate symptom
  in the spec where the bug surfaced, leaving the same
  primitive's other call sites still vulnerable.
- **Discipline drift in new features** — new spec shipped
  without auditing its primitive use; the eighth fix of the
  same shape in nine releases.

## Cross-cutting bindings — current count

Five canonical cross-cutting bindings address silent-failure
modes:

1. Architect Mode binding (byo-canon.md in fiction; Q13 = Research Bible Only in NF; plus Quality Guardian)
2. Verification Discipline binding (`verification-discipline.md`)
3. File-Write Hygiene binding (`core-pipeline.md` § File-Write Hygiene)
4. Edit-Tool Typographic Fidelity binding (`core-pipeline.md` § Edit-Tool Typographic Fidelity)
5. Read-Verification binding (`read-verification.md`)

Two bindings introduced in v2.7.7:

6. Web-Content Verification binding (`web-content-verification.md`)
7. Subagent Output Verification binding (`subagent-output-verification.md`)

Two bindings introduced in v2.7.8:

8. Bash-Output Verification binding (`bash-output-verification.md`)
9. AskUserQuestion Disambiguation binding (`ask-user-disambiguation.md`)

Plus two extensions to existing bindings in v2.7.8:

- Read-Verification binding extended with page-by-page PDF
  Read discipline (`read-verification.md` § Page-by-page PDF)
- File-Write Hygiene binding extended with file-freshness
  post-write discipline (`core-pipeline.md` § File-Freshness
  Post-Write Discipline)

The number is not the goal. The goal is **zero silent-failure
modes from primitives the engine relies on**. As of v2.7.8 the
catalog shows COVERED for every primitive in active use. The
discipline is complete (until a new primitive is introduced —
which the methodology and Check 10 then catch before it ships).
