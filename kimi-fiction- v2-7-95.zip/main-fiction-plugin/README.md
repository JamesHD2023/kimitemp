# Ideorix — The Manuscript & Screen Engine

AI-powered fiction and screenwriting with 68 genre plugins, a 12-stage editorial
pipeline, 14 specialized agents, professional-grade prose, industry-format
screenplay output (Fountain / FDX / PDF / DOCX), and bidirectional novel ↔
screenplay adaptation.

## Quick Start

**Novels:**
- `/write-a-book` — Start a new fiction manuscript from scratch
- `/continue-writing` — Resume an in-progress manuscript
- `/edit-manuscript` — Run the editorial pipeline on your manuscript
- `/design-cover` — Create book cover concepts with AI image prompts
- `/market-scout` — Live market intelligence for any genre

**Screenplays:**
- "Write a screenplay" — Original screenplay (feature / TV / short)
- "Adapt my novel to screenplay" — Convert manuscript to script
- "Adapt my screenplay to novel" — Convert script to prose (any length tier)
- "Script coverage" — Development + Industry coverage passes

Or just say "Write a book" or "Write a screenplay" and the engine walks you
through everything. Say "Ideorix" to open the Front Gate (Writers Studio /
Screen Studio / Full Creative Suite).

## What's Inside

- **68 genre plugins** with genre-specific guardrails, craft rules, and editorial checks
- **12-stage editorial pipeline** from proofreading through publication readiness
- **14 AI agents** working your manuscript: Architect, Writer, Humaniser, 5 verification agents, 5 editorial agents, plus on-demand tools
- **28 beat structure templates** for every story shape
- **Voice profiles** that maintain your style across the entire manuscript
- **KDP-ready output** with metadata, cover concepts, and marketing materials

## Requirements

- Claude Desktop or Claude Code
- Claude Pro, Team, or Enterprise subscription

© 2025 James Harvey Media. All rights reserved.
