---
name: write-a-book
description: "Start a new fiction manuscript from scratch"
---

Start the full Ideorix fiction pipeline. Launch Phase 1 (Interactive Setup) beginning with genre selection. See `write-a-book.md` in references for the complete protocol.
