---
name: market-scout
description: "Run live market intelligence for any genre"
---

Launch Market Scout. Searches the web for current bestseller trends, reader demand, trending tropes, comp titles, price point guidance, and strategic positioning. See `market-scout.md` and `market-scout-protocol.md` in references for the complete protocol.
