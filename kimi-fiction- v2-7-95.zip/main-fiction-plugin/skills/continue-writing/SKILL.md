---
name: continue-writing
description: "Resume an in-progress manuscript"
---

Resume an in-progress Ideorix manuscript. Check the Ideorix-Projects folder for existing projects, read the pipeline checkpoint, and resume from where the user left off. See `continue-writing.md` in references for the complete protocol.
