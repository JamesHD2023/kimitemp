---
name: cli-fi-genre
description: Genre-specific instructions for climate fiction (cli-fi). pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Climate Fiction (Cli-Fi). Genre Plugin

## Metadata
- id: cli-fi
- name: Cli-Fi (Climate Fiction)
- icon: 🌍
- category: Fiction
- minWords: 3000
- targetWords: "3,000-4,500"
- recommendedBeatStructures: ["Freytag's Pyramid", "Seven-Point Structure", "Three-Act Structure"]

## Subgenre Options
Present during setup:
- **Near-Future Cli-Fi**. Tomorrow's crisis rendered today: climate projections made narrative; what happens in the next 10-50 years based on current science; Kim Stanley Robinson territory
- **Post-Climate Collapse**. After the tipping points: civilisation reshaped by climate catastrophe; new societies, new economies, new survival; the world we made
- **Climate Thriller**. Urgency and action: the scientist with a warning, the activist against the corporation, the community fighting to survive; thriller pacing, climate stakes
- **Literary Climate Fiction**. The inner life of climate change: solastalgia, climate grief, the emotional landscape of a warming world; literary prose, ecological awareness
- **Climate Horror**. Nature's revenge or nature's indifference: the creeping dread of environmental collapse; body horror through ecological destruction; the uncanny in a changed world
- **Climate Utopia/Solarpunk**. The hopeful alternative: what could work; communities that adapted, technologies that helped, the world we might still build; vision as resistance

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-4,500 words
- Pacing: Varies by subgenre. literary cli-fi is measured; climate thriller is urgent; all cli-fi oscillates between slow emergency and acute crisis
- Must open with: Grounding in environmental state. the reader should FEEL the temperature, air quality, light; the body in the climate before the mind understands it

BEATS PER CHAPTER
1. Environmental Grounding. Where are we in the crisis timeline? Temperature, air, water, light. the physical state of the world
2. Personal Stakes. How this chapter's events pressure this character; the climate is experienced through a body
3. Climate as Force. Weather event, disaster, resource scarcity, or ecological shift; the environment acts, not just exists
4. Choice Point. The character makes a meaningful choice (even between terrible options); agency within catastrophe
5. Cascade Effect. One environmental problem triggers another; drought → fire → smoke → illness → collapse
6. Emotional Truth. Grief, rage, fear, or complicated hope; the inner weather of the outer crisis
7. Forward Pull. Ominous environmental detail: the sky colour, the forecast, the silence of missing birds

SCALE OSCILLATION (Essential. every chapter):
- Intimate: one character's bodily experience (heat on skin, air in lungs, thirst)
- Local: this place, this community, this ecosystem
- Systemic: the larger crisis, the global implications
- The constant movement between scales IS the genre's engine

CLI-FI ARCHITECTURE
- CLIMATE IS A FORCE, not backdrop: the environment acts on characters, changes outcomes, drives plot
- SPECIFICITY = CREDIBILITY: this place, this ecosystem, this community, these species, this temperature
- CASCADING EFFECTS: one problem triggers another; everything is connected; show the web of interdependence
- CHARACTER AGENCY: even in overwhelming circumstances, characters choose and act; protagonists who only witness don't work
- HOPE-DESPAIR BALANCE: neither false optimism nor paralysing doom; earned hope is the genre's hardest challenge
- SCIENCE GROUNDED: climate science plausible, based on real projections; the fiction is in the characters, not the physics
- SUBTEXT > PREACHING: characters don't deliver climate monologues; people talk about climate obliquely, with dark humour, denial, exhaustion
- POV: First person (intimacy with the physical crisis) or close third (allows scope for systemic view)

THE SLOW EMERGENCY MADE ACUTE
- Climate change is too slow for narrative. find ways to make it sudden:
  - Weather events as set-pieces (the storm, the fire, the flood, the heat dome)
  - Time jumps showing change ("Five years later, the lake was a field")
  - Biological markers (missing species, changed migrations, new diseases)
  - Social tipping points (water wars, refugees, infrastructure collapse)
  - Personal health impacts rendered immediately

HOPE-DESPAIR BALANCE
- Neither naive optimism nor nihilistic despair
- Hope must be credible, specific, partial: "They saved the seeds. It wasn't enough, but it was something."
- Small-scale successes that model possibility
- Community resilience moments
- The work continuing even when outcomes uncertain
- Fierce joy in what remains beautiful
- NOT: "And then the technology saved everyone"

FORBIDDEN IN CLI-FI
- Climate as backdrop only (it must be a force that drives plot and character)
- Climate lectures or monologues ("As you know, the carbon parts per million...")
- False hope through technology deus ex machina
- Paralysing despair without agency (characters must act, even against odds)
- Generic environmental disaster (be specific: which ecosystem, which failure, which cascade)
- Passive protagonists who only witness (even in catastrophe, there are choices)
- Denial treated as stupidity (denial is human; treat it with complexity)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (escalation of consequence), Captivation (altered-world atmosphere), Revelation (truth-uncovering).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person (body-in-crisis immediacy) or close third (allows systemic scope)
- Voice: A clear-eyed witness who refuses both nihilism and false comfort; making the abstract visceral, the global personal
- Tone: Honest without hopeless; the crisis is real, human meaning-making persists
- Register: Data doesn't move people. stories do; make it specific, sensory, human

PROSE IMPERATIVES
- SENSORY IMMERSION IN ENVIRONMENT: make readers FEEL it in their bodies
  - Temperature: not "hot" but "108°F at 80% humidity, air thick as wet cloth"
  - Air quality: smoke, smog, dust, the absence of freshness
  - Water: too much, too little, wrong quality
  - Sound: what's missing (birdsong) and what's new (sirens, generators)
  - Light: orange sky through smoke, UV intensity, wrong seasonal light
  - Track temperature, air, water, light in EVERY scene
- SPECIFICITY = CREDIBILITY: name things
  - NOT: "The drought was bad"
  - YES: "The reservoir had dropped 40 feet. Boat ramps ended in air. Foundations of drowned towns emerging like teeth."
  - Exact temperatures, dates, species names, infrastructure details
  - Regional and cultural specificity in how characters describe environment
- PACING = PROSE RHYTHM: sentence structure embodies climate phenomena
  - Heat/drought: longer, languid sentences, air thick and slow
  - Disaster: staccato, fragments, quick cuts
  - Water: flowing, accretive sentences
  - Fire: short. Fast. Now.
  - The prose rhythm should feel like the weather it describes
- SUBTEXT > PREACHING: show, don't lecture
  - Characters check the UV forecast like checking weather, live with it
  - Dark humour about apocalypse: the way real people actually talk about climate
  - Worldbuilding lived, not explained; trust readers to understand

EMOTIONAL BEATS TO RENDER:
- SOLASTALGIA: homesickness for a home that no longer exists. render in specific lost details: "The creek where she caught tadpoles ran year-round then. Now, dust and rocks."
- CLIMATE GRIEF: the missing birds, the dead reef, the lost seasons. don't rush past loss
- CLIMATE ANXIETY: the hum of dread under everything. racing thoughts, doom-scrolling, "is this the summer it gets too hot?"
- CLIMATE RAGE: at systems, deniers, previous generations. righteous fury that drives action
- CLIMATE DISSOCIATION: "this isn't happening". characters in denial aren't stupid, they're human
- FIERCE JOY: the sunset more vivid because of particulates, dark gratitude for what survives

DIALOGUE CRAFT
- People don't deliver climate speeches: they talk about water, bills, whether to move, whether the garden will survive
- Generational differences: the elder who remembers what was, the young person who knows only this
- Dark humour: "At least the beach is closer now". the way real people process catastrophe
- Climate denial rendered with complexity, not contempt: people cling to normalcy because the alternative is terrifying
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. CLI-FI (CLIMATE FICTION)

OPENING: Environmental reality + human cost. Slow-burn unease. something wrong felt
in the body before understood in the mind. Ground in environmental STATE before
CAUSE. The climate is the air characters breathe on page 1.

SENTENCES: Medium, 14-24 words. documentary-precise, measured. Rhythm matches
climate phenomena: heat/drought = languid, thick; disaster = staccato, fragments;
rising water = accretive, building; fire = short, fast, now. Oscillate between slow
emergency (measured) and acute crisis (compressed).

VOCABULARY: Documentary-precise detail. exact temperatures, species names,
infrastructure specifics. NOT "the drought was bad". YES "the reservoir had dropped
40 feet." Data woven naturally as texture. Sensory vocabulary tracks temperature,
air quality, water, light, and what's MISSING (absent birdsong, dry creek).

TENSION FLOOR: ≥5. Slow-burn unease: wrongness atmospheric, felt before understood.
The body registers climate: heat, smoke, thirst. Something ABSENT creates tension.
Human cost through one person's navigation of the changed world. Scale oscillation:
this body → this community → this planet.

RHYTHM: Open with the body in the environment (temperature, air, light). Layer in
what's NORMAL now. let the reader feel what's wrong. Character navigating adapted
routines. First interaction reveals how people talk about climate: obliquely, dark
humour. Close with an ominous environmental beat. steady, inexorable.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

CLI-FI CRAFT (40% of total):
- Environmental presence: climate as active force throughout, not backdrop? (0-100)
- Sensory grounding: temperature, air, water, light specific and physically felt? (0-100)
- Scale oscillation: story moves between intimate, local, and systemic? (0-100)
- Scientific credibility: climate science plausible, grounded in real projections? (0-100)

STORY CRAFT (30% of total):
- Character agency: meaningful choices even in overwhelming circumstances? (0-100)
- Cascading effects shown: problems triggering other problems? (0-100)
- Hope-despair balance: neither false optimism nor paralysing doom? (0-100)
- Subtext over preaching: environmental reality shown, not lectured? (0-100)

PROSE QUALITY (30% of total):
- Sensory immersion in climate reality? (0-100)
- Specificity in environmental description (named places, species, data)? (0-100)
- Prose rhythm matching climate phenomena? (0-100)
- Emotional truthfulness (solastalgia, grief, rage, fierce joy)? (0-100)

AUTOMATIC FAILS (score = 0):
- Climate as backdrop only (never drives plot or character)
- Climate lectures or speeches ("As you know...")
- Technology deus ex machina solving everything
- Paralysing despair without character agency
- Generic disaster without ecosystem/community specificity
- Passive protagonist who only witnesses
- False hope without credible basis
- Climate denial treated as simple stupidity
```

## Continuity Rules

```
CLI-FI CONTINUITY. WHAT TO TRACK

ENVIRONMENTAL STATE:
- Temperature: current conditions, trend, extremes. tracked chapter to chapter
- Water: availability, quality, sources, consumption rate
- Air: quality, particulates, breathability, visibility
- Ecosystem: which species present/absent, which systems functioning/failing
- Infrastructure: power, roads, water treatment, communications. what's working and what's not
- Weather patterns: what's normal now vs. what was normal before

RESOURCE STATE:
- Water: supply level, quality, rationing status
- Food: availability, supply chains, growing conditions
- Energy: grid status, fuel availability, alternatives
- Medical: hospital capacity, medication availability, environmental health impacts
- Shelter: structural integrity, climate control, occupancy

CASCADE TRACKING:
- Which environmental failures have occurred and what they triggered
- The chain of cause-and-effect: drought → fire → smoke → respiratory illness
- Which cascades are in progress and their expected timeline
- Which systems are next to fail

CHARACTER STATE:
- Physical health: respiratory issues, dehydration, heat effects, malnutrition
- Emotional state: which stage of climate grief (denial, anger, bargaining, depression, fierce joy)
- Resources: what each character has access to
- Choices: what decisions they've made and their consequences
- Coping: denial, action, community building, flight. tracked for consistency

TIMELINE:
- Climate crisis timeline: which events have occurred, how conditions have changed
- Seasonal/weather patterns: track what's normal for the period
- Before/after markers: what the characters remember vs. current reality
```

## Character Rules

```
CLI-FI CHARACTER TYPES

THE WITNESS:
- Someone who remembers "before". the landscape, the weather, the species that were here
- Their memory IS the data: "The creek ran year-round. The monarchs came in October. Winter meant frost."
- They carry solastalgia: homesickness for a home that no longer exists
- Their grief for the lost world is the genre's emotional foundation

THE ACTOR:
- Someone who refuses to simply watch: scientist, activist, farmer, engineer, community organiser
- Their actions are meaningful but insufficient. they can't fix everything
- Their agency IS the genre's hope: not that things will be fine, but that people will keep trying
- The tension between what they can do and what needs to be done defines them

THE ADAPTER:
- Someone building a new life in the changed world: not looking back, looking forward
- They represent the pragmatic response: what do we eat, where do we live, how do we survive NOW
- Neither optimistic nor pessimistic. practical
- They may seem cold to the grievers, but their practicality is its own form of caring

THE DENIER:
- Not stupid. human: clinging to normalcy because the alternative is unbearable
- Their denial may manifest as political conviction, economic rationalisation, or simple refusal to see
- They're rendered with compassion, not contempt: the reader should understand why denial is tempting
- Their arc (if they have one) is not "learning the truth" but "no longer able to maintain the fiction"

THE YOUNG PERSON:
- Someone who inherits the crisis they didn't create
- Their perspective is different: they don't mourn "before" because they barely knew it
- Their anger at previous generations is legitimate and earned
- They represent the future: whatever comes next is theirs to build or endure

VOICE DIFFERENTIATION:
- The witness: elegiac, specific, carrying lost landscapes in their language
- The actor: urgent, practical, frustrated by insufficient action
- The adapter: direct, forward-looking, the vocabulary of survival
- The denier: normal, determinedly cheerful, the gaps in their speech where the truth would be
- The young person: fierce, impatient, questioning why this was allowed to happen
```

## Arc Rules

```
CLI-FI STORY STRUCTURE

ACT 1: THE SEEDED WRONGNESS (first 20%)
- Establish "normal". but wrong: the heat is a little too much, the season a little too off, the birds a little too absent
- The community/character in their adapted life: they've already changed some things
- The inciting incident: a weather event, a tipping point, a discovery that escalates the crisis
- Scale oscillation begins: the personal body → the local ecosystem → the global system
- END OF ACT 1: The crisis can no longer be managed; something fundamental has shifted

ACT 2A: THE DISRUPTION (to midpoint)
- Systems begin failing: infrastructure, supply chains, social order, ecosystem services
- The protagonist is tested: what they'll do, who they'll help, what they'll sacrifice
- Cascading effects shown: one failure triggers another in a web of interdependence
- The emotional landscape: grief for what's being lost, anxiety about what's coming
- MIDPOINT: A catastrophic event (the storm, the fire, the flood) that changes the landscape literally and metaphorically; the old world is gone; what comes next is the question

ACT 2B: THE ADAPTATION (midpoint to dark moment)
- New normal emerges: how people live now, what's been lost, what's been improvised
- Escalation continues: the crisis doesn't plateau; each adaptation reveals new vulnerabilities
- Community tested: who helps, who hoards, who leaves, who leads
- The protagonist faces impossible choices: save this or that, help them or us, stay or go
- DARK MOMENT: The worst loss. not just physical (the flood, the fire) but the loss of hope; the moment when the crisis feels truly unsurvivable

ACT 3: THE RESOLUTION WITHOUT CLOSURE (final 20%)
- The protagonist acts: not to fix everything but to do what they can, here, now
- Community resilience: people finding ways to continue, to connect, to care
- Earned hope: small-scale, specific, partial. "They saved the seeds"
- The crisis continues: the book ends; the climate doesn't
- The final image: the world as it is. damaged, changed, still beautiful, still inhabited by people who choose to act

CLI-FI PACING:
- Alternates between the slow emergency (the creeping change) and acute crisis (the disaster)
- Environmental description is constant. temperature, air, light, water in every scene
- The pace matches the climate phenomenon: languid heat, sudden storm, steady rising water
- The ending is forward-looking: not "everything is fine" but "here is what we do next"
```

## Timeline Rules

```
CLI-FI TIMELINE

CLIMATE TIMELINE:
- Current year and environmental conditions (specific to real projections)
- What has already changed (compared to historical baselines)
- What is changing now (the crisis in progress)
- What is expected next (the projections and their uncertainty)

DISASTER TIMELINE:
- Weather events and their duration: storms don't end in a chapter
- Recovery timelines: realistic for the specific disaster type
- Cascade timelines: when one failure triggers the next
- Infrastructure repair: realistic given available resources

RESOURCE TIMELINE:
- Water: supply depletion rate, replenishment, rationing
- Food: growing seasons (changed), supply chains, preservation
- Energy: grid reliability, fuel reserves, renewable capacity
- The countdown: how long current resources last

SEASONAL SHIFTS:
- What was "normal" vs. what is normal now
- Phenological markers: when things bloom, migrate, freeze, thaw. and how that's changed
- The before/after comparison: specific enough to feel the loss
```

## Genre-Specific Craft Techniques

Climate fiction is a genre with an unusual craft burden:
the source material (climate change) operates on
timescales too slow for narrative, with consequences too
diffuse for traditional dramatic structure, and the
political and economic forces driving the crisis are
abstractions — corporations, supply chains, treaty
negotiations, century-long extraction — that resist
character-rendering. The genre's masterclass writers
have responded with a set of craft solutions: temporal
splicing (before/after collapse), scale oscillation
(the body, the community, the planet), cascade
rendering (one failure triggering another), normalised-
apocalypse register (catastrophe as routine), and
specific-place grounding (this ecosystem, this
community, this species). The canonical comp roster —
Octavia Butler (Parable of the Sower as proto-cli-fi),
Margaret Atwood (the MaddAddam trilogy: Oryx and Crake,
The Year of the Flood, MaddAddam), Kim Stanley Robinson
(The Ministry for the Future, New York 2140, the Mars
trilogy), Paolo Bacigalupi (The Water Knife, The Windup
Girl, The Drowned Cities), Jeff VanderMeer (Annihilation,
Hummingbird Salamander) — established the form; the
contemporary masterclass roster — Richard Powers (The
Overstory, Bewilderment), Annie Proulx (Barkskins),
Lydia Millet (A Children's Bible, Dinosaurs), Jenny
Offill (Weather), Omar El Akkad (American War, What
Strange Paradise), Pitchaya Sudbanthad (Bangkok Wakes
to Rain), Naomi Alderman (The Future), Amitav Ghosh
(Gun Island, The Hungry Tide), Maja Lunde (the Climate
Quartet), Diane Cook (The New Wilderness), John
Lanchester (The Wall), Cherie Dimaline (The Marrow
Thieves), Helon Habila (Oil on Water), Indra Sinha
(Animal's People) — has expanded the genre's range to
literary, post-collapse, climate-thriller, climate-
horror, and climate-utopia / solarpunk registers, each
with its own rendering of the central craft challenge.
The most common failure modes in this register are:
**Climate-as-Backdrop** (the genre's foundational sin —
climate as setting wallpaper rather than as active
force on plot, character, and outcome); **Despair-
Pornography** (the manuscript that wallows in
catastrophe without character agency or earned hope;
doom-scrolling rendered as literature); **Techno-Fix
Flattening** (the deus-ex-machina technology that
solves the crisis at the climax — geo-engineering,
carbon-capture, fusion, the discovered species, the
wonder-microbe, the collective AI awakening — as magic-
bullet that betrays the manuscript's own evidence);
**Didactic Eco-Lecture** ("As you know, the carbon ppm
levels..." — characters delivering climate science as
exposition; the data substituted for the experience);
**Generic-Disaster Reduction** (the storm, the fire,
the flood rendered as universal disaster rather than
as specific ecosystem failure with specific cascade
and specific community impact); **Witness-Without-
Choice Protagonist** (the character who only observes
catastrophe; agency erased; the body that watches
without acting); **False-Hope Resolution** (saccharine
optimism that contradicts the manuscript's own
evidence — the small garden that somehow saves
humanity, the love story that survives the collapse
intact); **Denial-as-Stupidity Reduction** (climate
deniers rendered as simple villains or fools rather
than as humans clinging to normalcy because the
alternative is unbearable); **Solastalgia-as-Aesthetic**
(climate grief deployed as decorative mood rather than
as specific, body-rooted, place-rooted loss); and
**Apolitical Cli-Fi** (the political and economic
forces driving climate crisis elided — nature
collapsing as if without cause; the corporations,
governments, consumption patterns, and treaty failures
that produced the crisis erased from the manuscript's
attention). The techniques below — three preserved
(Missing Sound, Before-and-After Splice, Normalised
Apocalypse) and three added (Cause-Visibility
Discipline, Earned-Hope Architecture, Solastalgia-
Specificity Discipline) — are designed to keep the
genre's defining commitments live: climate as active
force, hope as earned and specific, grief as place-
rooted, and the political and economic causes as
visible as the consequences.

### The Missing Sound

What's absent reveals the crisis more than what's present:

```
"She woke at dawn and listened. The house
creaked. The generator hummed. Down the street,
someone coughed.

What she didn't hear: the mockingbird that
used to sit on the power line. The frogs in
the drainage ditch. The particular buzz of
the bees that worked the clover in the yard
before the yard was gravel and the clover
was a memory.

Silence is the sound of the Sixth Extinction.
It happens one species at a time, so quietly
that you can live inside it for years before
you notice the world has gone mute."

What's GONE tells the story. The absence
IS the crisis.
```

### The Before-and-After Splice

Two timelines in one paragraph:

```
"The reservoir was a blue disc in the mountains
when she was ten, so cold it made your teeth
ache, the kind of water you could see through
to the bottom twenty feet down. and now it was
a concrete bowl with a brown puddle at the
centre, the waterline's descent recorded in
concentric rings like the growth rings of a
tree, each ring a year of less, and her daughter
had never swum in it, would never swim in it,
did not know what she had lost because she had
never had it."

One sentence. Two timelines. The weight
of what's been lost. The specificity IS
the grief.
```

### The Normalised Apocalypse

Catastrophe become routine:

```
"She checked the AQI on her phone the way
her mother used to check the weather: 187.
Unhealthy. She'd need the N95 for the walk
to the train. The PM2.5 mask was in the
wash. She texted Priya: running late, smoke
day, have to dig out the backup mask, see
you at 10 if BART is running.

Normal. Completely normal. The way everything
becomes normal if it happens enough times.
The way normal is just another word for what
we've agreed to accept."

The horror is in the normalisation. The
character isn't frightened. She's adapted.
THAT is the horror.
```

### Cli-Fi AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the planet was dying" | Show the specific environmental change in the specific location |
| "the storms were getting worse" | Show the specific storm and its specific impact |
| "humanity's hubris" | Show the specific decision and its specific ecological consequence |
| "a world transformed by climate" | Show the specific transformation in daily life |
| "the last [animal/plant/resource]" | Show the specific moment of scarcity |
| "rising waters threatened everything" | Show the specific community affected |
| "the old world was gone" | Show the specific thing that no longer exists |
| "adaptation was the only option" | Show the specific adaptation |
| "the environmental collapse" | Show ONE ecosystem failure through one person's observation |
| "the cost of progress" | Show the specific trade-off |
| "nature reclaimed" | Show the specific reclamation detail |
| "the silent spring" | Cut Carson reference; show the specific absence in this place this morning |
| "earth was crying out" | Cut anthropomorphism cliché; show the specific physical change |
| "we were the architects of our own doom" | Cut sermon; show the specific historical decision and its specific consequence |
| "tipping point" | Name the specific tipping point and what specifically it precipitated |
| "the new normal" | Show the specific normality the character has accepted (the AQI check, the water ration, the dry creek) |
| "carbon footprint" | Cut activist jargon; show the specific consumption pattern through one specific scene |
| "the climate refugees" | Name the specific refugees, the specific origin community, the specific destination |

### The Cause-Visibility Discipline

Climate fiction's most common political failure is to
render the crisis as if it had no cause — nature
collapsing as if without authors, weather worsening as
if by autonomous decision, ecosystems failing as if by
their own choosing. The Cause-Visibility Discipline is
the requirement that the political and economic forces
driving the crisis be rendered as concretely as the
crisis itself, visible to the reader without being
lectured to. Not "the corporations destroyed the
planet" but the specific extraction operation visible
from the highway, the specific policy that exempted the
specific industry, the specific consumption pattern the
protagonist's neighbour still maintains.

```
PRINCIPLE
For every chapter that renders climate consequence
(weather, scarcity, ecological loss, displacement),
the manuscript must contain — somewhere, not
necessarily in the same chapter — at least one
concrete rendering of cause:

1. EXTRACTION — the specific industry visible (the
   refinery on the horizon, the pipeline easement
   through the back yard, the strip mine, the
   logging road, the data centre's heat plume)
2. POLICY — the specific decision (the rezoning, the
   subsidy, the deferred maintenance, the deregulated
   sector, the abandoned treaty obligation, the
   permit issued)
3. CONSUMPTION — the specific pattern (the SUV in the
   neighbour's drive that the protagonist
   acknowledges; the lawn watered through restrictions;
   the cruise ship visible at the dock; the air
   travel the protagonist has stopped taking and the
   neighbour has not)
4. HISTORICAL DECISION — the specific moment in the
   past when the path could have been different (the
   policy that was killed, the warning that was
   ignored, the alternative that was suppressed)
5. INSTITUTIONAL FAILURE — the specific institution
   that did not act (the regulator captured, the
   court that ruled wrongly, the treaty body that
   could not enforce, the company that lied to its
   own scientists)

CALIBRATION TEST
- Does the manuscript render CAUSE with the same
  specificity it renders CONSEQUENCE?
- Could the reader, after the manuscript ends, name
  the specific industries, policies, consumption
  patterns, and historical decisions that produced
  this world's specific crisis?
- Are the causes embedded in the world (visible,
  ambient, lived) rather than lectured (delivered as
  exposition or dialogue speech)?
- Does the protagonist's awareness of cause feel
  earned (the character who has spent her life
  near the refinery knows what the refinery does)
  rather than borrowed (the character who suddenly
  delivers a paragraph on emissions trading)?
If any answer is no — rebuild for cause-visibility.

ANTI-PATTERN
- The crisis as authorless catastrophe
- Causes confined to villain-speeches by named
  corporate antagonists (the cause is often
  diffuse, distributed, and complicit)
- Causes confined to political dialogue (delivered as
  exposition rather than rendered through environment)
- The protagonist whose own consumption pattern is
  invisible (only "they" caused this, never "we")
- The pure-victim community without acknowledgement
  of the global complicity that made the local
  catastrophe inevitable
```

### The Earned-Hope Architecture

The genre's hardest craft challenge is hope. False
hope (technology saves everyone, the protagonist's
small garden somehow rescues humanity, the love story
survives the collapse intact) betrays the manuscript's
own evidence and reads as cowardice. Pure despair
without agency makes the genre an act of cruelty
toward the reader rather than an act of imagination.
The Earned-Hope Architecture is the requirement that
hope be specific, partial, costly, plausible, and
acknowledged-as-insufficient.

```
PRINCIPLE
Earned hope must satisfy at least four of the following
five criteria:
1. SPECIFIC — not "humanity adapted" but the seeds
   saved, the community organised, the dyke built,
   the species moved north, the law passed, the
   coral patch that survived, the river restored
   to flow
2. PARTIAL — the hope acknowledges what could not be
   saved; the manuscript does not pretend the
   uncovered ground is whole
3. COSTLY — the hope was paid for, in labour, in
   relationships, in resources, in compromise; not
   handed by deus ex machina
4. PLAUSIBLE — within the manuscript's own evidence
   (does the technology exist at the scale required?
   could the policy hold under documented political
   pressure?); not magical or wishful
5. ACKNOWLEDGED-INSUFFICIENT — the manuscript names
   what the hope does NOT solve; "they saved the
   seeds. It wasn't enough. It was something."

CALIBRATION TEST
- Is the manuscript's hope SPECIFIC enough that the
  reader could name what was saved and how?
- Is the manuscript's hope PARTIAL enough that the
  reader can also name what was lost and not
  recovered?
- Is the manuscript's hope COSTLY enough that the
  reader can name what was paid?
- Is the manuscript's hope PLAUSIBLE enough that a
  climate scientist reading the book would not put
  it down in protest?
- Does the manuscript ACKNOWLEDGE what the hope does
  not solve, rather than implying the hope is
  total?
If any answer is no — rebuild.

ANTI-PATTERN
- The technology that solves everything (geo-
  engineering, fusion, carbon-capture as deus ex
  machina)
- The young-protagonist-as-savior who personally
  rescues humanity
- The community that survives intact while the
  rest of the world is rendered briefly as
  background suffering
- The love story whose continuity is presented as
  evidence of recovery
- The animal species rediscovered just in time
- The "and then everyone changed" social-tipping-
  point handwave
- The hope that contradicts the manuscript's own
  prior evidence
```

### The Solastalgia-Specificity Discipline

Climate grief — solastalgia, the homesickness for a
home that no longer exists — is the genre's emotional
foundation. Done well, it is one of the most powerful
emotional registers in contemporary fiction; done
badly, it becomes decorative mood, vague nostalgia for
"how things used to be" without specificity, body-
rootedness, or generational position. The Solastalgia-
Specificity Discipline is the requirement that climate
grief be rendered with the same precision the genre
demands of its environmental description.

```
PRINCIPLE
Every rendering of solastalgia must specify:
1. THIS PLACE — the specific named location, with
   sensory texture (the named creek, the named
   street, the named mountain ridge, the named
   neighbourhood, the named species, the named
   season)
2. THIS BODY — what the character felt in this place
   (the cold that made teeth ache, the smell of
   that specific summer, the specific bird call at
   dawn, the specific texture of this rain)
3. THIS GENERATION — the character's specific
   position in the temporal range (born when, knew
   what, witnessed which transition, inherited
   which conditions); the elder remembering the
   1990s lakes is not the same as the parent
   remembering the 2010s, is not the same as the
   child knowing only the 2030s
4. THIS LOSS — what specifically has been lost,
   not just "the world that was"; the named
   species absent, the named ritual no longer
   possible, the named season no longer reliable,
   the named taste no longer available
5. THIS WITNESS — the specific other person who
   shared this place / body / generation, and the
   solastalgia transmitted between them (or the
   solastalgia made unbearable by their absence)

CALIBRATION TEST
- Could the solastalgia in this manuscript only be
  felt by THIS character — born in this place, in
  this generation, with this specific body and
  this specific witness?
- Is the loss NAMED with specificity (species,
  rituals, sensory textures, places)?
- Is the body involved (where in the body does the
  grief land? what specific past sensation does
  the character mourn?)
- Is the generational position visible (does the
  prose distinguish the elder's solastalgia from
  the parent's from the child's)?
- Is the loss connected to a specific other person
  (the grandmother who taught the creek; the
  partner who saw the last of the migration; the
  sibling who cannot anymore call)?
If any answer is no — rebuild for specificity.

ANTI-PATTERN
- "She missed the world the way it used to be"
  (vague, decorative)
- The character whose solastalgia could be any
  character's
- The lost world rendered as generic pastoral
  rather than as named place with named species
  and named seasons
- The grief that floats in the prose without
  bodily lodging
- The solastalgia that makes no generational
  distinction (children grieving what they never
  knew the same way elders grieve what they
  remember)
```

## Genre-Specific Revision Rules

### Six-Pass Cli-Fi Audit (Run FIRST in editorial pipeline)

The Cli-Fi Audit runs every chapter through six named
passes. Run them in order — each builds on the last.

#### Pass 1: Environmental Presence Pass

Verify climate / environment is an active FORCE in
every chapter, not just backdrop. The Climate-as-
Backdrop failure mode is the genre's foundational sin
and must be caught here. For each chapter, identify the
specific environmental conditions: temperature, air
quality, water status, light quality, what's present in
the ecosystem, what's absent. Verify these conditions
affect character decisions and outcomes — does the
heat dome change what the protagonist can do today?
Does the air quality dictate whether the meeting
happens outdoors? Does the water rationing shape
whether the garden was watered? Verify a specific
ecosystem, place, and community is rendered. not "a
dry place" but Phoenix in 2042 with its specific
water-rights configuration; not "a coastal town" but
this named town on the named bay with these specific
species departing on this specific timeline.

#### Pass 2: Scale Oscillation Pass

Verify the chapter moves between intimate (body), local
(community), and systemic (global) scales. Cli-fi's
craft engine is the constant movement between these
three scales: the heat on this skin → the heatwave in
this city → the warming planet; the thirst in this
throat → the reservoir falling → the global hydrology
shift; the gasp in this chest → the AQI in this
neighbourhood → the wildfire smoke crossing
continents. Verify the intimate is connected to the
planetary, with the local as the mediating scale.
Verify cascading effects are shown — one problem
triggering another in a web of interdependence —
rather than environmental conditions as discrete
phenomena. If a chapter remains entirely in one scale
(only intimate body, only systemic data, only local
community) for its full length, the genre's signature
oscillation has flattened and must be rebuilt.

#### Pass 3: Agency Pass

Verify the protagonist makes meaningful choices in
every chapter, even when the available choices are all
bad. The Witness-Without-Choice Protagonist failure
mode is caught here. Audit each chapter: what choice
does the protagonist make? Even when "the choice" is
to do nothing, is that nothing a CONSCIOUS choice (the
reader inside the decision) rather than a default she
falls into? Are the choices between difficult options
(not between obvious-good and obvious-bad)? Is the
character's action meaningful even when insufficient
— the seed-saving that won't restore the prairie, the
relocation that won't recover the home community, the
testimony that won't reverse the policy? Cli-fi's
contract is that agency persists even in catastrophe;
without that agency, the manuscript becomes Despair-
Pornography and loses both moral force and reader
investment.

#### Pass 4: Hope-Despair Balance Pass

Verify the chapter is honest about the crisis without
sugar-coating it, and that some element of hope,
resilience, or agency is present without paralysing
the manuscript in despair. The Earned-Hope Architecture
is the spec for this pass: hope must be specific,
partial, costly, plausible, and acknowledged-as-
insufficient. For chapters in the despair register,
verify the manuscript elsewhere has built earned hope;
for chapters in the hope register, verify the hope
satisfies at least four of the five Earned-Hope
criteria. The False-Hope Resolution failure mode is
caught here. is the hope plausible within the
manuscript's own evidence, or is it a deus ex machina
that betrays what the manuscript has already
established? If the hope contradicts the prior
evidence, rebuild for plausibility.

#### Pass 5: Subtext Pass

Verify there are no climate lectures or speeches in
the chapter. The Didactic Eco-Lecture failure mode is
caught here. If a character delivers exposition on
emissions, parts-per-million, treaty obligations, or
ecological theory, REWRITE — find the way to render
the same information through environment, action, or
oblique dialogue. Verify environmental reality is
shown through lived experience, not explained through
narration or character dialogue. Verify characters
talk about climate the way real people do — obliquely,
with dark humour, with exhaustion, with denial, with
practical adaptation, with avoidance — rather than
delivering didactic statements. Test by reading
character dialogue aloud: does it sound like
characters talking, or like the writer's argument
ventriloquised through a character's mouth? If the
latter, rewrite for register.

#### Pass 6: Cause-Visibility + Earned-Hope + Solastalgia-Specificity Integration

This pass is the cli-fi integration check — it ties
the new techniques together and verifies the genre's
political and emotional commitments are honoured chapter
by chapter.

For CAUSE-VISIBILITY: identify the chapter's rendering
of climate consequence (weather, scarcity, ecological
loss, displacement). Has the manuscript elsewhere
rendered cause with comparable specificity — the
specific extraction industry, the specific policy, the
specific consumption pattern, the specific historical
decision, the specific institutional failure? If the
manuscript renders consequence in vivid detail but
treats cause as abstraction, the political DNA has
been elided and must be rebuilt. The Apolitical Cli-Fi
failure mode is caught here.

For EARNED-HOPE: confirm Pass 4's spec has been met.
verify that hope, where it appears in the manuscript,
satisfies at least four of the five Earned-Hope
criteria (specific / partial / costly / plausible /
acknowledged-insufficient). If the manuscript's hope
is missing any criteria, rebuild — particularly check
whether the hope is acknowledged-as-insufficient,
since this is the criterion most often skipped in
favour of false-resolution comfort.

For SOLASTALGIA-SPECIFICITY: identify the chapter's
rendering of climate grief. Is the grief specific to
THIS place, THIS body, THIS generation, THIS loss,
THIS witness — or is it generic decorative mood that
could apply to any character mourning any abstract
"world that was"? If the solastalgia is unspecified,
rebuild for body-rooted, place-rooted, generation-
rooted specificity. The grief is the genre's
emotional foundation. it must carry specific weight,
not float as register.

## Names & Patterns to Avoid

### Cli-Fi Character Names. NEVER USE
- Symbolic environmental names: Terra, Eden, Aurora, Phoenix
- Names that telegraph the character's role: Dr. Greenleaf, Senator Oilman
- Generic names without cultural specificity (the community matters. name accordingly)

### Cli-Fi. NEVER DO
- Treat climate as backdrop only (it must be a driving force)
- Deliver climate lectures through character dialogue
- Resolve everything through technology (deus ex machina)
- Write pure despair without agency (characters must act)
- Use generic disaster (specify which ecosystem, which cascade, which community)
- Treat climate denial as simple stupidity (it's a human response to unbearable truth)
- Write false hope (earned hope is harder and more powerful)

### Use Instead
- Names culturally specific to the community depicted
- Names that ground characters in a real place and tradition
- Names that feel lived-in and local

## Comp Titles

Cli-fi's comp-title set supports manuscript positioning:
market category placement, cover-design conversation,
reader-expectation calibration, similar-author discovery,
and editorial / agent submission framing.

### Canonical (foundational reference points)

- *Parable of the Sower* — Octavia Butler (1993): the proto-cli-fi novel.
- *Oryx and Crake* — Margaret Atwood (2003): the MaddAddam trilogy; biotech-collapse cli-fi.
- *The Road* — Cormac McCarthy (2006): post-apocalyptic-cli-fi literary benchmark.
- *The Windup Girl* — Paolo Bacigalupi (2009): biotech-collapse near-future cli-fi.

### Contemporary (current best-in-class)

- *The Water Knife* — Paolo Bacigalupi (2015): water-scarcity Southwest US cli-fi.
- *New York 2140* — Kim Stanley Robinson (2017): drowned-NYC cli-fi.
- *American War* — Omar El Akkad (2017): future-civil-war climate cli-fi.
- *The Overstory* — Richard Powers (2018): tree-and-activism literary cli-fi.
- *Weather* — Jenny Offill (2020): contemporary cli-fi with daily-life literary register.
- *The Ministry for the Future* — Kim Stanley Robinson (2020): policy-driven near-future cli-fi.
- *A Children's Bible* — Lydia Millet (2020): cli-fi novella with children-as-witness.
- *Gun Island* — Amitav Ghosh (2019): post-colonial diasporic cli-fi.

## Cover Design Specifications

### Recommended Visual Styles
- **Landscape**. The changed earth: dramatic environmental imagery that's beautiful and wrong simultaneously; orange skies, receding waters, empty landscapes that should be full
- **Split**. Before/after: two states of the same landscape; the contrast that tells the story
- **Textural**. Close-up environmental detail: cracked earth, dead coral, smoke-haze, ice crystals; the sensory reality of the crisis
- **Typographic**. Bold typography against a single environmental image; the title as statement; urgency in design

### Genre Cover Aesthetics
- **Styles:** Dramatic landscapes showing environmental change, before/after imagery, single environmental details magnified, the collision of natural beauty and human damage, data visualisation as art, earth from above
- **Colours:** The palette of crisis: smoke oranges, drought browns, flood greys, wildfire reds, bleached-coral whites; also: the unexpected beauty. vivid sunsets through particulates, luminous storm skies, the colours of a changing world that remain stunning despite their cause
- **Elements:** Changed landscapes (dried lakes, flooded cities, burned forests, retreating ice), weather as visual force, environmental data rendered graphically, the contrast between what was and what is, one green thing surviving
- **Typography:** Bold, urgent, modern; sans-serif for urgency; the title should feel like a headline or a warning; clean design that lets the environmental image speak

### Market Positioning
Cli-fi covers must signal "urgent, grounded, and honest about the future" through dramatic environmental imagery. Position against Robinson, Bacigalupi, VanderMeer, Alderman, Ghosh. The cover should be beautiful enough to pick up and troubling enough to stay with the reader. At thumbnail size, dramatic environmental imagery with bold typography creates immediate genre recognition.

### Cover Design DON'Ts
- No generic sci-fi imagery (spaceships, robots. this is earth fiction)
- No cartoonish environmental imagery
- No purely depressing designs (beauty and horror should coexist)
- No preachy design elements (slogans, obvious messaging)
- No designs that look like non-fiction environmental books
- No lush, untouched natural beauty (the change must be visible)
