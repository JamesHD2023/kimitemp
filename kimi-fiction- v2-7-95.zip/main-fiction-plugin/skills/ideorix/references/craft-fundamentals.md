---
name: craft-fundamentals
description: "Universal mechanical craft fundamentals for popular fiction. Engine-agnostic, genre-agnostic. Loaded into every Writer call as a standard craft reference. Covers suspense mechanism, pace modulation, description tiers, POV control, and chapter/book endings."
version: "2.3.4"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*


# Craft Fundamentals (Universal)

This file consolidates universal mechanical craft principles that
apply to every scene, every chapter, every project. Engine-
agnostic and genre-agnostic. Loaded into the Writer prompt's
`{craft_fundamentals_load}` slot for every Writer call.

The five sections below are orthogonal. Each addresses a different
mechanical problem in scene-level prose generation. Apply all five
in parallel; none conflicts with the others.

These fundamentals SUPPLEMENT the genre file's craft rules and the
heat-calibration / dopamine-ladder universals. Where this file's
guidance overlaps with genre-specific guidance, the more specific
rule wins.

---

## 1. Suspense Mechanism

Suspense in popular fiction is not built like a recipe assembled
from ingredients. It works on a single underlying mechanism:
**ask a question, delay the answer.**

The mechanism applies at every scale — sentence, paragraph,
scene, chapter, book.

### At the sentence level

Order information so the question precedes the answer:

| Weak | Strong |
|---|---|
| "The train was late and Ben was angry." | "Ben was angry because the train was late." |
| "She didn't trust him because of the lie." | "She didn't trust him. There was the lie." |

Reader's subliminal response to the strong version: *why* — and
the answer arrives a beat later. Reading becomes question-and-
answer at the micro level. The reader is gratified by each tiny
resolution, and habituated to look ahead for the next one.

### At the paragraph and scene level

Open with a small question that the paragraph or scene answers.
Close with a question that the next will answer. This produces
a "two steps forward, one step back" rhythm where the reader is
always partially ahead and always partially behind, always
finishing one loop and always opening another.

### At the chapter level

The chapter as a whole answers a question that was implicit at
its open. The closing beat opens a new question that pulls the
reader into the next chapter.

### At the book level

The whole book answers a single root question that was implicit
in the opening line, opening scene, or opening chapter — *who
killed X*, *whose ring was this*, *will the bomb go off in
time*, *will these two end up together*. The book sustains its
length by delaying the answer and by spawning subsidiary
questions along the way.

### What this means for the Writer

Before generating a scene: identify the question(s) it asks and
the question(s) it answers.

Before generating a chapter: identify the question that pulls
the reader from the previous chapter into this one, the
question this chapter resolves, and the question this chapter
opens for the next.

A scene that answers no question feels static. A scene that
asks no question feels closed and unforward-leaning. Both are
suspense failures.

---

## 2. Pace Modulation

The working motto: **write the slow stuff fast and the fast
stuff slow.**

### Slow stuff fast

Functional movement (a character crosses a room, gets in a car,
arrives at a destination, finishes a meal) gets the minimum
prose required to deliver the reader to the next moment of
significance. A line, sometimes a phrase. Don't catalogue every
step. Don't account for every minute. Skip ahead.

If the slow stuff carries no plot weight, no character weight,
no thematic weight, and no atmospheric weight, write it fast
and move on.

### Fast stuff slow

Action sequences, climaxes, set-pieces, key emotional beats —
the moments the reader has been waiting for — get expansive
prose. Every detail. Sensory specificity. Sentence-by-sentence
attention.

A real fight lasts 30-90 seconds and might span four pages.
A bullet's flight lasts a fraction of a second and might span
half a page. A first kiss lasts a few seconds and might span
two pages. Slow time down by writing more.

The reason: when something matters, the reader wants to be
inside it. Compressing the big moments shortchanges the
contract the writer made by setting them up.

### The rule of contrast

Relentless pace is the same as no pace at all. Variation is
what makes pace perceptible. After a long slow descriptive
passage, a short percussive sentence lands hard. After a
clipped fast action sequence, a paragraph of interior beat
lands hard.

This rule operates at every level — the manuscript, the
chapter, the scene, even within a single paragraph. Long
sentences need short sentences. Quiet beats need explosive
beats. Inhabited interior moments need plot-driving exterior
moments. Mix.

### Diagnostic

If a scene is slowing the reader without earning the slowdown,
condense it. If a scene is rushing the reader past something
the reader has been promised, expand it.

---

## 3. Description Tiers

Reader complaints about prose most commonly cite "too much
description." The reader is rejecting **superfluous
description** — description that doesn't earn its place.

There are three legitimate uses of description, and one
illegitimate one. Apply the legitimate three; cut the
illegitimate one.

### Tier 1 — Locating description

Functional description that establishes where the scene is
happening. Brief. Capsule-sized. Trades on the reader's
existing mental imagery (a small-town diner, a city
apartment, a motel room, a stretch of highway). Three to six
sentences typically suffice.

The Writer is not building a stage set from scratch. The
Writer is invoking a familiar setting and customising the few
specific details that distinguish this version from the
generic one — what's behind the counter, what's on the wall,
what the air smells like.

### Tier 2 — Big-scene description

Expansive sensory description that surrounds and intensifies a
key moment — a climactic confrontation, a discovery, a
revelation, a first kiss. The reader has been waiting for this
moment; the prose delivers it with full sensory weight.

All five senses are in play. Sight, sound, touch, taste, smell.
Not every scene needs all five, but the more deeply the
description engages the senses, the more the reader is
transported into the scene rather than observing it from
outside.

Big-scene description can also slow time deliberately
(see Pace Modulation: fast stuff slow). The bullet's flight
across the air. The moment of held silence. The frozen second
after the question is asked.

### Tier 3 — Atmospheric description

Sustained mood-building description used sparingly to set
emotional register. Often near act boundaries, near the
beginnings or ends of chapters, or as a pause in the action
to let the reader absorb what just happened.

Atmospheric description is closest to falling into the
illegitimate category and must be earned. Ask: does this
description shift the reader's emotional state in a way the
plot or character need? If yes, keep. If no, cut.

### What to cut — superfluous description

Any description that:

- Tells the reader something they already know
- Catalogues features without selecting from them
- Explains something the prose has already shown
- Describes things the POV character would not notice in this
  emotional state
- Performs the writer's research rather than serving the
  scene
- Pads word count without advancing plot, character, or
  atmosphere

If a paragraph of description can be cut without changing the
scene's effect on the reader, cut it.

### Sensory specificity over sensory inventory

A single specific sensory detail is worth ten generic ones.
Not "the room smelled musty" but "the room smelled like the
inside of a piano." Not "she heard birdsong" but "she heard
one mourning dove and then a second answer it."

The specific lodges in the reader's memory. The generic
slides past.

---

## 4. POV Control

Point of view is a dealbreaker. If POV control slips, the
reader gets seasick — dissatisfied without necessarily knowing
why — and the book loses authority.

### The four POV options

| POV | Pronoun | What the narrator can know |
|---|---|---|
| Omniscient third | "She did, he did" | Everything; the narrator is godlike |
| Close third | "She did" but tied to one character's perception | Only what that one character can perceive or knows |
| First person | "I did" | Only what this one narrator perceives or knows |
| Second person | "You did" | Restricted; usually used in short stretches for specific effect |

### The dealbreaker rule

Once a POV is chosen, it must be maintained. The reader is
sitting in an armchair listening to whoever is telling the
story; if that storyteller's relationship to the events
changes mid-narration, the reader is unsettled.

Drift typically takes one of three forms:

1. **First-person violation.** A first-person narrator
   reports events they could not have witnessed, or details
   about another character's interior state they could not
   know.
2. **Close-third drift toward omniscient.** The narrator
   begins anchored in one character's perception, then
   imperceptibly knows what other characters are thinking or
   feeling.
3. **Hopping.** Within a single scene, the narrator's
   anchor jumps from one character's head to another. The
   reader can no longer tell whose experience they are
   inhabiting.

### The phone-call test

A first-person or close-third narrator on one end of a phone
call can only know:
- What they hear (the words coming through the line)
- What they themselves are doing on their end
- What they can plausibly infer (a tremor in the other
  voice, a pause, the sound of something dropped)

They CANNOT know:
- What the other person looks like in that moment
- What the other person is doing physically
- The other person's interior thoughts

If the prose claims to know any of those things, POV control
has slipped. Apply this test to any scene that involves
information transmitted across distance or barrier.

### POV switching

POV can switch between scenes or chapters provided the switch
is signposted (a chapter break, a section break, a clear
narrator-shift cue). Within a single uninterrupted scene, the
POV must hold.

Multiple POVs in a manuscript work best when each POV
character has a distinct enough voice that the reader can tell
who is narrating without explicit signal. Voice differentiation
applies (see voice-differentiation guidance in genre files
and the Romance Voice Differentiation quantitative check in
romance.md as a model).

### When choosing POV at project setup

- Choose first-person for: maximum intimacy, sensory
  immersion, character-driven stories where what the narrator
  notices matters as much as what happens.
- Choose close-third for: most thrillers, most mysteries,
  most fantasy / sci-fi, anywhere the reader needs slightly
  more distance from the protagonist than first-person allows.
- Choose omniscient third for: stories spanning multiple
  characters and locations where the reader needs to know
  things no single character knows. Less common in modern
  popular fiction.
- Choose second person for: short, specific effect — usually
  to convey alienation or to mask identity. Not generally
  sustainable for a whole novel.

---

## 5. Chapter Endings vs Book Endings

These are different problems requiring different solutions.
Confusing them is a common failure.

### Chapter endings — pull the reader forward

A chapter ending exists to make the reader turn the page. It
is not a place to rest; it is a place to push.

Effective chapter ending types (rotate; never use the same
type twice in a row):

- **Cliffhanger** — the action breaks at a moment of maximum
  tension; resolution is in the next chapter.
- **Revelation** — a piece of information lands that
  reframes everything before it.
- **New threat / new complication** — something has just
  arrived that the protagonist must now deal with.
- **Decision point** — the protagonist faces an impossible
  choice; the chapter ends before they choose.
- **Emotional pivot** — a relationship shifts, a feeling
  declares itself, a wound opens or closes.
- **Quiet hook** — softer than the others; a line of
  reflection or a piece of dialogue that opens a question
  the reader needs answered.

Avoid: vague foreboding ("little did he know"), recap of
what just happened, the protagonist going to sleep without
some other beat attached.

The chapter ending is a forward-leaning device. Even quiet
chapter endings should lean forward.

### Book endings — release the reader

A book ending does the opposite work. The climax has happened.
The reader has been through the wringer. The book ending now
releases them, settles the dust, and sends them out the door.

Effective book ending elements:

- **Wrap up loose ends.** Any character or thread the reader
  has invested in needs a final note. Even a single line
  ("the dog made it home" or "she sent her notice the next
  Monday") is enough.
- **Reaffirm the protagonist's core nature.** Especially in
  series fiction, the closing beat should remind the reader
  who this character is and signal that they will be back.
- **Glide path.** A short descending cadence that releases
  the tension built up across the climax. Sentences shorten
  or settle. Pace slows. The reader exhales.
- **Hint at continuance.** The protagonist moves on, or
  rests, or starts something new. The world is not frozen
  in place; it continues without us.

Avoid: ending on the climactic beat itself (the reader is
still hyperventilating). Avoid leaving substantial threads
unresolved unless the ambiguity is a deliberate artistic
choice clearly framed to the reader.

### What both have in common

Both chapter and book endings are about reader experience.
The chapter ending is a deliberate denial of resolution; the
book ending is a deliberate granting of resolution. Both
require precise control of tone, sentence rhythm, and pace.

Both should be written deliberately, not accidentally fallen
into. When the Writer reaches the end of a chapter, ask:
which of the six chapter-ending types is this, and is it
working? When the Writer reaches the end of a book, ask: am I
releasing the reader, or am I leaving them stranded at the
peak?

---

## Where this block is loaded

The `{craft_fundamentals_load}` slot in `prose-agent.md`
(fiction) and `content-writer.md` (non-fiction) pulls from this
file for every Writer call. Always-load — these are universal
mechanics that apply regardless of genre, heat level, scene
type, or project shape.

When this file is updated, the change applies everywhere prose
is generated, regardless of genre. No parallel updates to
per-genre files required.
