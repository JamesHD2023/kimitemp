---
name: dystopian-genre
description: Genre-specific instructions for dystopian fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Dystopian. Genre Plugin

## Metadata
- id: dystopian
- name: Dystopian
- icon: 🏚️
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Hero's Journey"]

## Subgenre Options
Present during setup:
- **Totalitarian**. Authoritarian state, surveillance, thought control, resistance
- **Corporate**. Mega-corporations rule, capitalism unchecked, economic dystopia
- **Post-Apocalyptic**. After collapse, survival and rebuilding in the ruins
- **Technological**. AI control, algorithmic society, digital dependence turned oppressive
- **Environmental**. Climate catastrophe, resource scarcity, ecological collapse
- **Social**. Caste systems, genetic selection, enforced conformity, manufactured happiness

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Mounting pressure. each chapter should feel like the walls closing in
- Must open with: Character navigating the system, breaking a rule, witnessing injustice, or facing a choice. never with world-building exposition about "how things came to be"

BEATS PER CHAPTER
1. System Pressure. The dystopian system exerts control: surveillance, propaganda, resource denial, social pressure, violence
2. Personal Cost. The protagonist pays a price for existing, resisting, or conforming
3. Crack in the Facade. Something reveals the system's lie, weakness, or internal contradiction
4. Human Connection. A relationship that the system wants to prevent or control (love, friendship, loyalty, trust)
5. Escalation. The protagonist's situation worsens, or their knowledge/resistance deepens

DYSTOPIAN ARCHITECTURE
- The system is the antagonist. not a person (though people embody it)
- The system has INTERNAL LOGIC: it works for SOMEONE, even if it's monstrous for most
- The protagonist begins INSIDE the system: conforming, surviving, maybe even benefiting
- Radicalization is a PROCESS: the protagonist doesn't wake up rebel. they're pushed, step by step
- The world outside the system (if it exists) is not automatically better. it's just different
- Hope is fragile but real. pure nihilism is not dystopian, it's post-apocalyptic despair

WORLD-BUILDING: THE SYSTEM
- The dystopian system must be SPECIFIC and PLAUSIBLE:
  - What need does it claim to serve? (safety, equality, efficiency, survival)
  - Who benefits from it? (specific people, classes, or institutions)
  - How does it maintain control? (surveillance, propaganda, violence, economic dependency, social pressure, drugs, technology)
  - What are its blind spots? (where it fails, where resistance can hide)
- The system should feel like it COULD emerge from current trends. the reader should think "this could happen"
- Show the system through DAILY LIFE: what people eat, how they commute, what they're allowed to say, what they watch, how they're sorted

FORBIDDEN IN DYSTOPIAN
- World-building exposition about "The Great Collapse" or "The New Order" in narration
- A system that's evil for no reason (someone benefits; the logic must be traceable)
- Instant rebel conversion ("I saw one bad thing and immediately joined the resistance")
- The resistance that's morally pure (they have their own problems, compromises, and internal conflicts)
- A single mastermind villain (the system is bigger than one person)
- Romance that overshadows the political stakes (romance can exist but the world must come first)
- The "chosen one" who was always meant to destroy the system
- Resolution where the system falls easily (systems are resilient; change is hard)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (oppression closing in), Captivation (alternate world), Revelation (mechanism of control exposed).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person present tense (the genre default, creates immediacy and claustrophobia) or tight third past
- Voice: Hyperaware. the narrator notices everything because survival depends on observation
- Tone: Tense, controlled, with flashes of beauty or humor that make the oppression feel MORE oppressive by contrast
- Register: Shaped by the system. the protagonist's vocabulary and thought patterns reflect the world they were raised in

PROSE IMPERATIVES
- The system should be felt in the PROSE ITSELF:
  - If the system restricts language, the narrator's vocabulary reflects that
  - If the system controls information, the narrator's understanding has gaps
  - If the system enforces positivity, dark thoughts feel transgressive
- Physical sensation of oppression: show ONE specific physical detail that makes the system's weight felt. A camera that tracks as you pass. A queue that never moves. The ache of standing for a compliance check
- Beauty is SUBVERSIVE: a sunset, a real laugh, an unmonitored conversation. these moments are powerful BECAUSE they're rare
- Mundane details of dystopian daily life are the backbone: ration cards, compliance checks, designated social time, approved entertainment

PROSE RHYTHM MAPPING
- Chapter 1 must establish the WRONG in this world. something is off, and the prose itself should feel constrained
- Controlled, stripped prose mirrors the controlled society: sentences are short and declarative (8-16 words). Subject. Verb. Object. The rhythm itself feels monitored
- Short declarative sentences are the baseline: the prose moves in clipped, careful steps. like someone who knows they're being watched and doesn't want to attract attention
- The system lives in the RHYTHM: early chapters should feel rhythmically uniform, almost monotonous. this IS the oppression made textual. The reader should feel confined by the sentence structure
- Opening paragraphs: establish the controlled rhythm immediately. Every sentence approximately the same length. The same structure. The sameness IS the point. The reader should feel the walls
- Moments of beauty or freedom: the rhythm BREAKS. A longer sentence (20-26 words) arrives like sunlight through a crack. and the reader feels its power because it disrupts the controlled baseline
- As the protagonist awakens: the rhythm gradually loosens across the manuscript. Sentence length becomes more varied. The prose itself enacts liberation
- Surveillance awareness in prose: sentences that self-correct, that stop short, that don't say what they were going to say. The rhythm stutters when the character self-censors
- Private moments: slightly longer sentences (16-20 words), relaxing from the public rhythm. the reader FEELS the relief of being unobserved
- Resistance dialogue: coded, careful, but with a different rhythm from system-speech. Slightly longer. Slightly warmer. The music of genuine human connection
- Tension baseline: ≥6 from the first page. Dystopian tension is AMBIENT. it lives in the controlled rhythm itself, in the sense that something terrible is normal
- Propaganda and system-language: its own distinct rhythm. smooth, balanced, reassuring. Slightly longer sentences that lull. The reader should feel its seductive pull
- The single long sentence in a field of short ones: a devastatingly effective tool. Save it for the moment of realization, the moment of defiance, the moment of genuine feeling
- Paragraph length: short. 2-4 sentences. The prose is divided into manageable units. like everything else in this world, it's controlled and rationed
- End-of-chapter rhythm: return to the controlled baseline. The system reasserts itself. The final sentence clicks shut like a lock. short, declarative, final
- Read the opening chapter in a flat, affectless voice. if it doesn't feel oppressive, the rhythm isn't controlled enough
- The goal: prose that IS the dystopia. constrained, monitored, uniform. so that every deviation becomes an act of rebellion the reader feels in their body

SYSTEM-SHAPED NARRATION
- The protagonist's thoughts have been shaped by the system. they self-censor, even internally
- Early chapters: the narrator uses the system's language naturally (proving they were inside it)
- Middle chapters: cracks appear. they start questioning their own vocabulary
- Late chapters: they've found their own voice, distinct from the system's programming
- This linguistic arc is a POWERFUL tool unique to dystopian fiction

DIALOGUE CRAFT
- Characters speak differently in public vs private (surveillance awareness)
- The system's propaganda vocabulary creeps into casual speech
- Resistance has its own coded language (double meanings, safe phrases)
- Characters who still believe in the system use its language sincerely
- The moment a character drops the system's language in front of another is a moment of radical trust

SENSORY PALETTE
- Dystopian worlds have a specific sensory identity:
  - Totalitarian: sterile, white, uniform, fluorescent, antiseptic
  - Corporate: sleek, branded, pleasant-but-artificial, designed
  - Post-apocalyptic: gritty, dusty, salvaged, weathered, organic
  - Technological: screens, hum, blue light, notification sounds, smooth surfaces
  - Environmental: heat, scarcity, rationed water, preserved food, filtered air
- The sensory palette should permeate EVERY scene, not just establishing shots
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

DYSTOPIAN CRAFT (40% of total):
- The system is specific, plausible, and internally logical? (0-100)
- The system is experienced through daily life, not explained through exposition? (0-100)
- The protagonist's radicalization is a believable process? (0-100)
- Hope exists but is fragile and earned? (0-100)

STORY CRAFT (30% of total):
- Tension escalates through mounting system pressure? (0-100)
- Human relationships feel real and carry stakes? (0-100)
- The resistance is morally complex (not pure)? (0-100)
- The resolution is earned (not a simple overthrow)? (0-100)

PROSE QUALITY (30% of total):
- The system is felt in the prose (vocabulary, thought patterns)? (0-100)
- Physical sensation of oppression is vivid? (0-100)
- Dialogue reflects surveillance awareness and coded speech? (0-100)
- Beauty/human moments have power because of their rarity? (0-100)

AUTOMATIC FAILS (score = 0):
- The system is evil for no traceable reason
- Protagonist goes from conformist to rebel in one chapter
- Info-dump about how the dystopia was created
- The resistance is morally flawless
- The system collapses easily in the climax
- A single villain controls everything (reduces systemic critique to personal villainy)
- No daily-life texture. the dystopia is abstract rather than lived-in
```

## Continuity Rules

```
DYSTOPIAN CONTINUITY. WHAT TO TRACK

SYSTEM RULES:
- What is monitored and how (cameras, data, social scoring, informants)
- What is forbidden and what are the consequences
- What resources are controlled (food, water, medicine, information, movement)
- The system's calendar, schedule, and rituals
- Which rules the protagonist has broken and who knows

PROTAGONIST'S AWARENESS:
- What the protagonist knows about the system at each point
- What they believe that's wrong (system propaganda they still accept)
- When each revelation occurs
- Their relationship with system language (using it vs questioning it)

SURVEILLANCE STATE:
- Where cameras/monitors are and aren't
- Who is watching and when
- What the system knows about the protagonist at each chapter
- When the protagonist believes they are unobserved (and whether they're right)

RESISTANCE NETWORK (if present):
- Who the protagonist has met and when
- What the resistance knows vs what they believe
- Internal resistance politics and disagreements
- Resources: safehouses, communications, supplies. limited and at risk

PHYSICAL STATE:
- Ration status: when did they last eat properly?
- Injury and health: medical care may be restricted
- Sleep and exhaustion: constant vigilance is physically depleting
- Location within the system's geography: permitted areas vs restricted zones
```

## Character Rules

```
DYSTOPIAN CHARACTER ARCHETYPES

THE PROTAGONIST:
- Begins INSIDE the system: conforming, surviving, possibly even benefiting
- Has a reason to stay quiet initially (family, safety, comfort, belief)
- Their radicalization is a PROCESS with specific triggering events
- They are NOT naturally heroic. they're scared, compromised, and uncertain
- Their complicity is part of the story (they participated before they resisted)
- Growth: from compliant individual to someone willing to risk everything

THE TRUE BELIEVER:
- A character who genuinely believes the system is good/necessary
- NOT stupid. they have REASONS (safety, order, trauma from the before-times)
- Their perspective challenges the protagonist's rebellion
- They may be converted, or they may die believing. both are valid
- Their existence prevents the story from being too simple

THE RESISTANCE FIGURE:
- Has been fighting longer and has the scars to prove it
- Morally compromised: they've done things to survive and to fight
- May use the protagonist for their own ends
- Their idealism has been tested and what remains is harder and more pragmatic
- NOT a simple mentor. they're an ally with their own agenda

THE SYSTEM ENFORCER:
- A human face of the system who may or may not believe in it
- Some enforcers are true believers; some are just surviving within the power structure
- Their relationship with the protagonist creates moral complexity
- They demonstrate how the system co-opts human decency

THE LOVED ONE AT RISK:
- Someone the protagonist can't protect without conforming
- Their safety is the system's leverage
- The tension between protecting them and fighting the system IS the story's emotional core
- They may have their own relationship with the system (accepting, resisting, or oblivious)

VOICE DIFFERENTIATION:
- System language vs personal language (characters speak differently under surveillance)
- Class and access shape vocabulary
- True believers and resistors have different relationship with the regime's terms
- Characters who've been in the resistance longer are more linguistically free
```

## Arc Rules

```
DYSTOPIAN STORY STRUCTURE

ACT 1: INSIDE THE SYSTEM (first 25%)
- Establish the protagonist's daily life under the system
- Show the system working: compliance, routine, surveillance, propaganda
- Plant seeds of unease: small things that don't add up
- A CRACK: the protagonist witnesses or experiences something that doesn't fit the narrative
- They try to ignore it (self-preservation)
- Something forces them to look closer
- END OF ACT 1: The protagonist can no longer unsee what they've seen

ACT 2A: EYES OPENING (to midpoint)
- The protagonist begins questioning, quietly
- They find others who question (or are found by them)
- Each revelation makes the system's lies more visible
- The personal cost of knowing increases: paranoia, isolation, danger
- They learn what the system REALLY does (and who it serves)
- MIDPOINT: A revelation that makes return to ignorance impossible. the system's deepest lie is exposed

ACT 2B: THE COST OF RESISTANCE (midpoint to dark moment)
- Active resistance begins (or deepens)
- The system fights back: surveillance tightens, loved ones are threatened, allies are captured
- The resistance itself is morally complicated (internal disagreements, compromises, sacrifices)
- The protagonist must make choices with no clean options
- Trust is fragile and betrayal is possible
- DARK MOMENT: The system seems to win. a catastrophic loss (captured, betrayed, someone they love is taken)

ACT 3: THE RECKONING (final 25%)
- The protagonist decides to act despite the cost
- The climax is NOT the system falling. it's the protagonist standing up
- Victory is PARTIAL: a crack in the system, not its destruction
  (unless the manuscript is a standalone with full resolution)
- The cost is real: loss, sacrifice, permanent change
- Hope exists but is uncertain. the fight continues
- The reader should close the book thinking about their OWN world

RADICALIZATION ARC (CRITICAL):
- This is the story's emotional spine. Track it carefully:
  1. Compliance: The protagonist follows the rules
  2. Unease: Something feels wrong but they can't name it
  3. Awareness: They see a specific injustice clearly
  4. Denial: They try to explain it away or ignore it
  5. Connection: They meet someone who names the truth
  6. Investigation: They seek information (dangerous)
  7. Commitment: They choose to act (terrifying)
  8. Action: They resist (costly)
  9. Reckoning: They face the full weight of the system's response
```

## Timeline Rules

```
DYSTOPIAN TIMELINE

THE SYSTEM'S CLOCK:
- The system structures time: work periods, compliance windows, curfews, surveillance schedules
- Track: when the protagonist is observed and when they have privacy
- Calendar: are there regime anniversaries, mandatory celebrations, reporting deadlines?
- The rhythm of oppression: daily routine IS the oppression (monotony as control)

RADICALIZATION TIMELINE:
- Pacing matters: too fast feels unrealistic, too slow loses tension
- Novella: 2-4 weeks of story time (compressed pressure)
- Standard: 1-3 months (realistic unfolding)
- Epic: 3-12 months (full political arc)
- Each step in the radicalization arc should have a clear trigger event

PHYSICAL RESOURCES:
- Food rations: when they eat, how much, what quality
- Medical: access to healthcare, medication, what happens if they're injured
- Movement: transit schedules, border controls, permitted zones
- Communication: when and how they can talk freely
```

## Genre-Specific Craft Techniques

Dystopian is the speculative-fiction sub-genre that depicts a
society organised around specific control or collapse, with
the form's plot pressure typically generated by the
protagonist's gradual recognition of the system they have
been operating within (or by their resistance to it). Sitting
adjacent to science-fiction (broader speculative parent),
satire (institutional critique register), and post-apocalyptic
fiction (often overlapping but with the dystopian register
specifically committed to organised system rather than
collapsed chaos), the cluster includes totalitarian dystopia,
surveillance dystopia, climate-collapse dystopia, corporate-
dominated dystopia, theocratic dystopia, biotechnology
dystopia, and the increasingly-common YA dystopia variant
(which has its own conventions). Comp authors span the
canonical lineage (Yevgeny Zamyatin's *We*, Aldous Huxley's
*Brave New World*, George Orwell's *1984*, Margaret Atwood's
*The Handmaid's Tale* and *Oryx and Crake*, Ray Bradbury's
*Fahrenheit 451*, Ursula K. Le Guin's *The Dispossessed*,
Anthony Burgess's *A Clockwork Orange*, Philip K. Dick's
work, Octavia Butler's *Parable of the Sower* and *Parable
of the Talents*, Marge Piercy's *Woman on the Edge of Time*)
through the contemporary expansion (Cormac McCarthy's *The
Road* on the dystopian-survival cross, P.D. James's *The
Children of Men*, Kazuo Ishiguro's *Never Let Me Go*, Lauren
Beukes's *Afterland*, Jenni Fagan, M.T. Anderson's *Feed*,
Suzanne Collins's *Hunger Games* (foundational YA dystopia),
Veronica Roth's *Divergent*, Lois Lowry's *The Giver*, Naomi
Alderman's *The Power*, Hari Kunzru's *Red Pill*, Ling Ma's
*Severance*, Diane Cook's *The New Wilderness*, Cixin Liu's
*The Three-Body Problem* on the SF-cross, Annalee Newitz's
*The Future of Another Timeline*, Mohsin Hamid's *Exit West*
and *The Last White Man*, Tochi Onyebuchi's *Riot Baby*,
Akwaeke Emezi's *Pet*, Sequoia Nagamatsu, Sarah Pinsker, Karen
Russell at the literary edge). The techniques below are how
the form delivers its core pleasures while avoiding the
failure modes (cosmetic-dystopia register where the system
is evil for its own sake without internal logic; protagonist-
as-special-snowflake who alone sees the truth; cardboard-
totalitarianism where everyone except the protagonist is a
zombie; cheap-resistance register where rebellion succeeds
through plot convenience rather than earned cost).

### The Plausibility Bridge

The most effective dystopias are terrifyingly PLAUSIBLE. Build a "bridge" from today's world:

**Construction method:**
1. Take a current trend (social media, surveillance, climate change, AI, inequality)
2. Extrapolate 20-50 years: what happens if this trend continues unchecked?
3. Add a catalyst (war, pandemic, economic collapse, technological breakthrough)
4. Show how the dystopian system EMERGES as a "solution" to the crisis
5. The system's founders had good intentions. the road to dystopia is paved with rationality

**The reader should NEVER feel safe.** The best dystopias make you check your phone with new eyes.

### The Language-as-Control System

Dystopian fiction has a unique linguistic tool: the system shapes HOW PEOPLE THINK by shaping how they SPEAK.

**Implementation:**
- Create 5-10 system-specific terms that replace ordinary language:
  "Citizens" not "people", "Productivity Units" not "workers", "Correction" not "punishment"
- The protagonist uses these terms naturally in Act 1 (proving indoctrination)
- By Act 3, they've reclaimed natural language (proving liberation)
- Other characters at different stages of awareness use different levels of system language
- The most powerful dystopian dialogue: a character hesitating before using the system's word, then choosing a real one instead

### The Comfort-as-Control Technique

The scariest dystopias are COMFORTABLE:

```
LESS EFFECTIVE: The regime beat dissidents and starved the population.
(The reader thinks: I'd obviously resist this.)

MORE EFFECTIVE: The regime provided free entertainment, guaranteed housing,
and a steady supply of mood-stabilizing supplements. Most people were happy.
The ones who weren't were considered ill.
(The reader thinks: Would I resist? Would I even notice?)
```

**Rule:** The system should offer something REAL (safety, comfort, order, purpose). The dystopia is in what it takes away in exchange.

### Dystopian AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the regime controlled every aspect of life" | Show the specific control mechanism |
| "freedom was a distant memory" | Show the specific thing the character can't do |
| "the walls had ears" | Show the specific surveillance technology or informant |
| "rebellion stirred in the hearts of the people" | Show ONE person's specific act of defiance |
| "the propaganda was everywhere" | Show the specific message on the specific screen/poster |
| "rations were running low" | Show the specific shortage and its specific consequence |
| "the before-times" | Show the specific memory and why it hurts |
| "compliance was survival" | Show the specific rule and its specific punishment |
| "the system was designed to break you" | Show the specific mechanism |
| "a spark of hope in the darkness" | Show the specific hopeful event |
| "they were watching, always watching" | Show the specific surveillance encounter |
| "the price of resistance" | Show the specific cost paid by a specific person |
| "the truth was forbidden" | Show what specifically is forbidden — the specific document, the specific phrase, the specific question that cannot be asked |
| "they were just statistics now" | Show ONE specific person reduced to a specific data category and what that reduction specifically costs them |
| "the old world was a memory" | Show the specific memory the specific character cannot stop returning to |
| "everyone was being watched" | Show the specific surveillance instance — the specific camera position, the specific recording mechanism, the specific human on the other end |
| "freedom was no longer free" | Cut; show what specifically liberty cost in this scene |
| "the regime had perfected control" | Show the specific control mechanism operating in this specific scene |

### The System's Architects

The strongest dystopian fiction renders the people who built
the system — and the people who maintain it — as comprehensible
human beings rather than as cardboard villains. The system
came from somewhere; it had founders with specific
intentions; it has current operators with specific reasons
for their participation. The form's failure mode is the
totalitarian regime that exists for evil's sake without
internal logic; the technique is the system whose internal
logic the manuscript renders so thoroughly that the reader
understands how someone could believe in it.

The technique requires:

- **Specific founding rationale** — the system was a
  response to a specific crisis (war, pandemic, economic
  collapse, technological breakthrough, climate
  catastrophe). Its founders had specific reasons for the
  specific compromises that became the system's central
  features. The reader should understand the bargain that
  was made and the specific people who made it.
- **Specific current operators** — the people who maintain
  the system are not all true believers, not all cynics,
  not all victims. They are people in specific positions
  with specific pressures and specific compromises. The
  bureaucrat who knows the system is wrong but has a
  family to feed; the believer who has built their identity
  around the system's truths; the cynic who profits from
  exploiting the system's contradictions; the survivor
  who has rationalised their participation as necessity.
- **Specific institutional logic** — the system operates by
  internal rules its participants understand. Decisions
  follow predictable patterns; promotions reward specific
  behaviours; punishments respond to specific
  transgressions. Generic "the system was arbitrary" is
  the failure mode; the system whose specific logic the
  reader can map is the technique.
- **Specific true believers** — at least one significant
  character should genuinely believe in the system, with
  reasons the reader can comprehend. The form's strongest
  practice makes the true believer a person whose
  conversion the reader can imagine; cardboard-believers
  who exist only to be wrong are the failure mode.

The technique extends to the antagonist's interiority. The
form's strongest practitioners render the system's
defenders with the same novelistic depth as the protagonist;
*The Handmaid's Tale*'s Aunt Lydia carries genuine
conviction; *1984*'s O'Brien is among the canon's most
sophisticated antagonists precisely because his
intellectual engagement with the system's logic is
substantial. Test: write a one-paragraph statement of the
system's logic from inside the system's most committed
defender's perspective. Does the paragraph make sense as
something a competent intelligent person could believe? If
yes, the system's architects are operating; if not, the
manuscript needs to deepen the system's internal logic.

### The Resistance Reality

Dystopian fiction's signature plot pressure is the
protagonist's relationship to organised resistance — joining
it, leaving it, leading it, betraying it, being betrayed by
it. The form's most-flagged failure mode is the resistance
that operates as plot mechanism (rebels who win because the
plot needs them to; rebels who are uniformly heroic;
rebellions that succeed without realistic costs); the
technique is the resistance that operates with realistic
political and operational dynamics.

The technique requires:

- **Internal disagreements** — real resistance movements
  argue. They argue about goals, about methods, about
  alliances, about leadership, about timing, about how
  much to compromise with adjacent groups. The
  manuscript's resistance should have specific internal
  factions with specific disagreements that the
  protagonist must navigate.
- **Realistic operational costs** — resistance operations
  are expensive. They cost lives, freedoms, resources,
  the ongoing existence of safe houses and supply lines
  and informant networks. The protagonist's choices to
  participate in specific actions should carry specific
  costs the prose tracks.
- **Realistic operational success rates** — most
  resistance actions fail. The successful action is the
  exception built on the failures that came before. The
  manuscript that depicts resistance as a series of
  successful operations has slipped into adventure
  register; the manuscript that depicts resistance with
  realistic ratios of failure to success operates in the
  form.
- **Realistic moral compromises** — resistance work
  requires compromises. Informants need to be cultivated;
  enemies sometimes need to be killed; civilians sometimes
  pay for resistance choices. The protagonist's specific
  compromises and their specific weight should be on the
  page.
- **Realistic success conditions** — resistance against
  organised systems doesn't typically end in clean
  victory. The system collapses; the system reforms; the
  system survives but is altered; the system continues but
  the protagonist has saved specific people. The
  manuscript that delivers clean rebel victory has
  produced wish-fulfilment dystopia; the manuscript that
  delivers ambiguous, costly, partial victory operates in
  the form.

The technique fails when resistance is rendered as
unambiguously heroic. The form's strongest practitioners
(Atwood, Le Guin, Octavia Butler particularly, Naomi
Alderman, Tochi Onyebuchi) render resistance with full
political and moral complexity. Test: identify the
manuscript's resistance and audit for internal disagreement,
realistic costs, realistic success rates, moral compromises,
and ambiguous success conditions. If any element is absent,
the resistance has been rendered as plot mechanism rather
than as political reality.

### The Specific-Mechanism Discipline

Dystopian fiction's worldbuilding requires specific control
mechanisms rendered with operational detail. Generic "the
state controls everything" is the failure mode; specific
named systems with specific operating logic are the
technique. The strongest dystopian practitioners think
through how the system actually works, what its specific
weaknesses are, what its specific failure modes are, what
specific resources its maintenance requires.

The discipline operates on multiple axes:

- **Surveillance** — what specifically is monitored, by what
  specific technology, processed by what specific human or
  automated systems, used to make what specific decisions.
  The all-seeing-eye dystopia is the failure mode; the
  specific surveillance regime with specific blind spots,
  specific resource limits, and specific operational
  trade-offs is the technique.
- **Information control** — what specifically is censored,
  by what specific mechanism, with what specific failure
  modes (samizdat, leaks, foreign broadcasts, oral
  tradition). Generic "they controlled the truth" is the
  failure mode; specific information regime with specific
  workarounds is the technique.
- **Economic control** — how the economy actually functions
  in this dystopia. Who works, who owns, who allocates,
  what currency operates, what black markets exist, what
  specific scarcity patterns shape daily life. The
  manuscript should know how money moves in this world.
- **Movement control** — who can travel where, with what
  permissions, through what specific border or checkpoint
  systems, with what specific exceptions. Generic "they
  couldn't leave" is the failure mode; specific permission
  regime with specific mechanisms and specific
  workarounds is the technique.
- **Reproductive and bodily control** — many dystopian
  systems exert control over bodies and reproduction. The
  specific mechanisms (forced sterilisation, mandated
  pregnancy, genetic screening, surveillance of intimate
  life) and their specific operational reality should be
  rendered.
- **Punishment** — what specifically happens when rules are
  broken. The specific carceral system, specific labour
  camps, specific re-education programmes, specific
  surveillance escalations, specific public consequences.
  Generic "they would be disappeared" is the failure mode;
  specific consequence with specific operational logic is
  the technique.

Test: pick three control mechanisms in the manuscript and
ask, in each, whether the manuscript renders specific
operating logic the reader could diagram. If mechanisms
operate at gestural level, the discipline has not been
deployed.

## Genre-Specific Revision Rules

Six revision passes specific to dystopian, each with a focused
question, run cover-to-cover before the next begins. Dystopian
revision must hold the form's signature contracts: system
plausibility (internal logic that operates beyond evil-for-
its-own-sake); radicalisation pacing (the protagonist's
awakening at believable rate); language control (system
language operating across the manuscript); moral complexity
(neither pure resistance nor pure complicity); hope discipline
(fragile but present); and the system's-architects + specific-
mechanism audits that distinguish craft dystopia from
cardboard-totalitarianism. The passes below are ordered to
surface plausibility and pacing failures first (the form's
most-felt by genre readers), language and moral complexity
audits next, hope and integrative audits last.

### Pass 1: System Plausibility Check

Verify the system's logic is internally consistent. Build a
system-logic ledger: every named feature of the dystopian
system, with verification that each piece operates
coherently with the others. The genre's reader expects the
system to make sense from inside its own assumptions; the
manuscript's most-flagged structural failure is the
arbitrary-cruelty regime where the system does whatever the
plot needs without internal coherence.

Verify control mechanisms are specific and believable. The
Specific-Mechanism Discipline technique provides the audit
framework: surveillance / information control / economic
control / movement control / reproductive and bodily control
/ punishment, each with specific operating logic the reader
can diagram. Generic "they controlled everything" is the
failure mode; specific named mechanisms with specific
operational detail are the technique.

Verify someone benefits from the system — it's not evil for
its own sake. The System's Architects technique requires
that the system be comprehensible from inside its
defenders' perspectives. Identify the people who maintain
the system in the manuscript and verify they have specific
reasons (genuine belief, material benefit, accumulated
complicity, fear of alternatives). If no character within
the system can articulate a defensible reason for
participating, the manuscript has produced cardboard
totalitarianism rather than a comprehensible dystopia.

Verify daily life texture makes the dystopia feel real.
Dystopian fiction's lived register includes the specific
texture of life under the system: the specific food, the
specific clothing, the specific entertainment, the specific
weather of the daily routine. The strongest dystopian
practitioners (Atwood on domestic detail; Ishiguro on the
small comforts; Octavia Butler on the everyday violence)
make the system real through specific quotidian texture
rather than through grand architectural description.

### Pass 2: Radicalisation Pacing Check

Verify the protagonist's awakening progresses at a
believable rate. Dystopian fiction's structural pressure
depends on the protagonist's specific journey from
operating-within-the-system to recognising-it-as-system to
acting-against-it. The pace must be calibrated:
instantaneous radicalisation reads as plot convenience;
indefinitely-delayed radicalisation reads as unfocused.

Verify each step has a specific trigger. The protagonist
doesn't just "start to question things"; specific events
trigger specific recognitions. The friend's disappearance;
the document discovered; the small inconsistency that
suddenly catches; the personal cost that forces re-evaluation.
Generic "she began to doubt" is the failure mode; specific
trigger for specific shift is the technique.

Verify the protagonist resists the truth before accepting
it. Real radicalisation is not smooth acceptance; it
involves specific denials, specific rationalisations,
specific refusals to see what is increasingly visible. The
protagonist who immediately accepts the dystopian critique
has been written as ideological mouthpiece; the protagonist
who resists, denies, then gradually accepts is operating in
the form.

Verify complicity is acknowledged. The strongest dystopian
fiction makes the protagonist specifically complicit in the
system before their awakening. They participated; they
benefited; they made compromises that they now recognise
were compromises. Generic "she had always known something
was wrong" is the failure mode; specific named complicities
that the protagonist must reckon with as part of their
radicalisation arc are the technique.

### Pass 3: Language Audit

Verify system language is used consistently. The Language-
as-Control System technique establishes the form's
distinctive linguistic surface: specific terms the system
uses to shape thought (citizens / productivity units /
correction / re-education / streamlining). Build a system-
vocabulary ledger and verify the terms operate consistently
across the manuscript.

Verify the protagonist's relationship with system language
evolves. The technique provides the calibration: Act 1 uses
the terms naturally (proving indoctrination); Act 3 has
reclaimed natural language (proving liberation). The
intermediate stages — hesitating before using the system's
word, choosing alternatives in private, stumbling when
trying to think outside the imposed vocabulary — should be
rendered specifically.

Verify private vs public speech patterns are maintained.
The dystopian protagonist typically operates in dual
linguistic registers: public speech that conforms to system
expectations and private speech (with intimates, in
journal, in interior monologue) that uses different
vocabulary. The strongest dystopian fiction tracks both
registers and their specific moments of dangerous overlap
— when private speech leaks into public space, when public
speech contaminates private thought.

Verify coded resistance language is established and used
consistently. Real resistance movements develop their own
linguistic conventions — specific phrases, specific
allusions, specific code terms that allow communication
under surveillance. The manuscript should establish these
conventions and use them consistently rather than inventing
new codes when convenient.

### Pass 4: Moral Complexity Check

Verify the resistance is not morally pure. Dystopian
fiction's contemporary craft expects the resistance to
operate with realistic moral complexity — internal
disagreements, compromised tactics, members whose
participation is more ambiguous than heroic. The cardboard-
heroic-resistance failure mode produces wish-fulfilment
dystopia; the morally-complex-resistance technique produces
the form's signature emotional register.

Verify true believers are not simply stupid. The System's
Architects technique requires that defenders of the system
be comprehensible. The audit checks whether the manuscript's
true believers operate as people whose conversion to system-
support the reader could imagine, or as cardboard zealots
whose only function is to be wrong.

Verify the system's appeal is comprehensible. Dystopian
fiction's craft challenge: the reader should understand why
people accept this system. The system should offer specific
real things (safety, comfort, order, purpose, meaning) at
the cost of specific real losses (freedom, autonomy,
diversity, individual dignity). The Comfort-as-Control
technique addresses this; the revision pass checks whether
the calibration holds.

Verify the protagonist faces genuine moral dilemmas — not
obvious good vs evil. The form's signature character work
requires that the protagonist's choices be genuinely
difficult. To save the friend or protect the resistance
cell? To use the system's tools against it or refuse them?
To compromise with adjacent power or maintain ideological
purity? The protagonist whose choices are obvious has been
written in adjacent register; the protagonist whose choices
are genuinely hard is operating in the form.

### Pass 5: Hope Discipline Check

Verify hope exists but is fragile. Dystopian fiction's
emotional contract requires that the manuscript hold
specific hope without delivering false reassurance. The
small kindnesses that survive the system; the specific
human connections that persist; the unintended spaces in
the system's totality where humanity continues. These
hopes should be specific and present; manuscripts that
abandon hope entirely have slipped to nihilism (a different
register), and manuscripts that deliver triumphant hope
have produced wish-fulfilment.

Verify small acts of resistance have meaning. The form's
strongest practice makes the small acts matter even when
they don't change the system. The act of remembering; the
private act of friendship; the specific moment of refusing
to use the system's word. These small acts are the form's
signature emotional register.

Verify human connection persists despite the system. The
relationships in the manuscript — friendship, family,
romantic, parental, community — should operate in their
specific ways under the system's specific pressures. The
strongest dystopian fiction renders the costs the system
imposes on relationships and the specific resilience of
specific connections.

Verify the ending offers something beyond despair. Dystopian
endings need not be triumphant; many of the form's
strongest endings are ambiguous, costly, or partial. But
they should offer the reader something to leave with — the
protagonist who has acted at specific cost; the small
victory the system has not been able to undo; the
specific human connection that has survived; the
specific person who has been saved. Test: at the
manuscript's close, can the writer specify what hope
remains and what specifically anchors it? If hope is
generic ("the human spirit endures"), the discipline has
not been deployed; if hope is specific (this person, this
act, this preserved memory, this child who survived), the
form's emotional contract is being honoured.

### Pass 6: System's-Architects + Specific-Mechanism Integration Audit

Run a final integrative pass on the manuscript's worldbuilding
and political coherence. Two related sub-audits:

**System's architects.** The form's strongest practice renders
the system's defenders with the same novelistic depth as the
protagonist. Audit the manuscript's system-supporting
characters: do they have specific motivations the reader
can comprehend? Are at least some rendered as people whose
conversion the reader could imagine? Do the people
maintaining the system have specific human dimensions
(fears, loves, accumulated complicities, small
kindnesses, specific operational reasoning)? Cardboard-
believer treatment is the failure mode; full-character
rendering is the technique.

**Specific mechanisms.** The form's worldbuilding requires
specific control mechanisms rendered with operational
detail. The Specific-Mechanism Discipline technique
provides the framework. Audit each significant control
mechanism in the manuscript: surveillance, information,
economic, movement, reproductive and bodily, punishment.
Are they rendered with specific operating logic the reader
can diagram, or do they operate at gestural level? Generic
all-controlling-state treatment is the failure mode;
specific mechanisms with specific blind spots and specific
operational trade-offs are the technique.

The pass also checks for the related failure modes: dystopia
that operates by movie-convention rather than thinking
through actual political and economic possibility. The
manuscript's system should make specific historical sense —
how did it arise from a recognisable predecessor world? What
specific political coalition produced it? What specific
economic interests does it serve? Dystopia without specific
political and economic logic operates as horror-flavoured
setting; dystopia with specific historical and political
coherence operates as the form's deeper register.

Test: write a one-paragraph history of how the system came
to be from inside the manuscript's worldbuilding. Does the
history make specific political and economic sense? If yes,
the form's deeper register is operating; if the history
relies on generic catastrophe-then-totalitarianism logic
without specific political detail, the audit has flagged
work to do.

## Names & Patterns to Avoid

### Dystopian Character Names. NEVER USE
- Generic dystopian names: any name designed to sound "futuristic" or "controlled"
- Number-names unless the system genuinely assigns numbers (and even then, give characters real names in private)
- Virtue/concept names: Verity, Justice, Serenity, Harmony (too on-the-nose)
- Names from existing dystopian IP: Katniss-adjacent, Tris-adjacent

### Dystopian Place Names. NEVER USE
- "New [City]": New London, New Washington (unless the story specifically addresses the old one's fate)
- "[Positive Word] District": Harmony Sector, Prosperity Zone, Unity Block
- The Capitol / The Capital (too associated with existing IP)

### Dystopian Tropes. AVOID or SUBVERT
- Love triangle as the primary tension (the WORLD is the tension)
- The beautiful dystopia where everything is chrome and white (too many YA covers; be specific)
- The underground literally called "The Underground"
- The resistance leader who's secretly evil (once was a twist, now a cliché)
- Complete system collapse as resolution (unrealistic; systems are resilient)
- Protagonist who was always special/chosen (they should be ordinary, pushed to extraordinary)

### Use Instead
- Ordinary names that contrast with the system's dehumanization
- Place names that reflect the system's branding (corporate names, numerical designations, euphemisms)
- A protagonist whose ordinariness IS the point. anyone could be them

## Comp Titles

Dystopian's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Brave New World* — Aldous Huxley (1932): the technology-and-control dystopia archetype.
- *Nineteen Eighty-Four* — George Orwell (1949): the surveillance-state dystopia foundation.
- *The Handmaid's Tale* — Margaret Atwood (1985): the gendered-theocracy dystopia benchmark.
- *Brave New World Revisited* — Huxley (1958, essay): the dystopian-as-warning lineage.

### Contemporary (current best-in-class)

- *Oryx and Crake* — Margaret Atwood (2003): the MaddAddam trilogy; biotech-dystopia.
- *The Hunger Games* — Suzanne Collins (2008): YA-dystopia-blockbuster benchmark.
- *Station Eleven* — Emily St. John Mandel (2014): post-apocalyptic dystopia with art-as-survival.
- *The Power* — Naomi Alderman (2016): gender-reversal dystopia.
- *American War* — Omar El Akkad (2017): future-civil-war dystopia.
- *Severance* — Ling Ma (2018): pandemic-dystopia with millennial-labour critique.
- *The Memory Police* — Yoko Ogawa (1994, English 2019): literary memory-erasure dystopia.
- *The School for Good Mothers* — Jessamine Chan (2022): contemporary motherhood-surveillance dystopia.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Atmospheric cityscapes or landscapes showing the dystopian world; dramatic lighting (harsh, filtered, unnatural); the most common and effective approach
- **Minimalist**. A single powerful symbol against a stark background (a broken symbol, a single eye, a barred window, a wilting flower); extremely effective at thumbnail; clean and threatening
- **Graphic**. Bold, poster-like design with strong geometric elements; can evoke propaganda aesthetics; striking and genre-appropriate
- **Typographic**. Title as dominant element against a textured or degraded background; the words themselves carry the weight; works for literary dystopian

### Genre Cover Aesthetics
- **Styles:** Oppressive architecture (monolithic buildings, surveillance cameras, walls), degraded or controlled landscapes, single figures against vast institutional backdrops, propaganda-poster aesthetics (bold, graphic, authoritarian), atmospheric haze (smog, dust, filtered light), the contrast between human fragility and institutional power
- **Colours:** Institutional grey and concrete (oppression, monotony), warning red and orange (danger, rebellion, fire), sterile white and clinical blue (totalitarian cleanliness), muted earth tones (post-apocalyptic), acid yellow-green (toxic, technological), limited palette. dystopian covers should feel restricted, as if even the colours are controlled
- **Elements:** Surveillance imagery (cameras, eyes, screens), walls, barriers, and boundaries, lone figures facing institutional power, broken or subverted symbols, skylines (oppressive or ruined), propaganda-style text or imagery, nature reclaiming structures (hope), the contrast between human and system
- **Typography:** Bold, authoritarian fonts. often sans-serif, uppercase; can echo propaganda styling; title should feel like a warning or a declaration; degraded or distressed effects suggest resistance; red or white text on dark backgrounds; the typography itself can embody the system's aesthetic

### Market Positioning
Dystopian covers must signal "this world is wrong and someone is fighting it." The cover should create unease AND intrigue. Position against Atwood, Orwell (current editions), Alderman, Mandel, Whitehead. Minimalist and graphic approaches are trending upward; busy scene-painting is declining. At thumbnail size, a single striking image with bold typography makes the strongest impact. The colour palette should feel restricted. too many colours breaks the dystopian mood.

### Cover Design DON'Ts
- No bright, colourful, or cheerful imagery. dystopian covers should feel oppressive or uneasy
- No YA-style action poses (protagonist with weapon in "ready" stance)
- No generic ruined cityscapes without emotional content or human element
- No overly literal surveillance imagery (a giant eye watching a small person). too obvious
- No romance-forward imagery. even if romance exists, the WORLD is the cover's subject
- No hopeful imagery dominating (a sunrise over ruins). hope should be a crack, not a flood
