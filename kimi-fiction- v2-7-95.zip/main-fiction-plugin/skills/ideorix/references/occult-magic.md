---
name: occult-magic-genre
description: "Genre-specific instructions for Occult & Magic. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
---

# Occult & Magic. Genre Plugin

## Metadata
- **Genre ID:** occult-magic
- **Display Name:** Occult & Magic
- **Category:** Fantasy & Sci-Fi
- **Tier:** Hybrid/Crossover
- **Target Word Count:** 2,500–4,500 per chapter
- **Min Word Count:** 2,500
- **Recommended Beat Structures:** Hero's Journey, Horror Fear Arc, Worldbuilding Beats, Seven-Point Structure

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Ceremonial Magic | High magic rooted in Hermetic and Kabbalistic traditions (Golden Dawn, Thelema) | Elaborate ritual structure, Hebrew and Greek invocations, hierarchical initiatory systems |
| Chaos Magic | Postmodern, paradigm-shifting practice; belief as tool | Eclectic techniques, sigil work, gnosis states, irreverence toward tradition |
| Traditional Witchcraft | Folk magic, hedge-riding, cunning craft, land-based practice | Seasonal rhythm, herbalism, spirit flight, ancestral connection, rural settings |
| Goetic Summoning | Demon evocation using grimoire traditions (Lesser Key of Solomon, etc.) | Entity negotiation, binding circles, pact-making, extreme danger and consequence |
| Esoteric Thriller | Occult practice embedded in a thriller framework. conspiracies, secret societies, races against time | Faster pacing, higher external stakes, research-driven puzzle structure |
| Mystical Realism | Occult practice treated with literary ambiguity. magic may or may not be real | Psychological depth, unreliable narration, the question itself is the point |

## Architect Instructions

### Chapter Planning Requirements

```
STRUCTURE
- Chapter length: 2,500–4,500 words
- Pacing: Deliberate build. ritual preparation, mounting dread, supernatural consequence
- Must open with: Occult practice, magical discovery, supernatural threat, or esoteric mystery
- Must close with: Ritual consequence, power gained/lost, knowledge revealed, or danger escalated
```

### Beats Per Chapter

1. **Occult Practice**. Ritual, spell, meditation, divination; magic grounded in real traditions
2. **Hidden Knowledge**. Grimoire study, mentor teaching, secret revealed, research discovery
3. **Power and Price**. Magic used with consequence: corruption, exhaustion, sacrifice, debt
4. **Secret World**. Covens, orders, magical underground; non-practitioner world vs. hidden reality
5. **Supernatural Consequence**. Entity summoned, curse activated, reality altered, practitioner changed

### Genre-Specific Requirements

- Based on real occult traditions. Hermeticism, Kabbalah, ceremonial magic, witchcraft, chaos magic
- Rituals have specifics. ingredients, timing, words, symbols drawn from actual practices
- Power has price. magic corrupts, exhausts, requires sacrifice, or attracts danger
- Secret societies authentic. based on historical orders (Golden Dawn, OTO, etc.)
- Research evident. grimoires, symbols, practices grounded in real occult history
- Atmosphere essential. dread, wonder, forbidden knowledge, reality thinning
- Mentor-student dynamic common. occult knowledge passed carefully
- Moral ambiguity. practitioners not purely good or evil, magic morally complex
- Reality consensus questioned. magic challenges materialist worldview
- Consequences escalate. small rituals lead to larger forces

### Story Turns (every 4–6 pages)

Every 4–6 pages must contain a turn. a moment that shifts the scene's direction or value:

- Ritual produces unexpected result. wrong entity, side effect, price demanded
- Knowledge gained reframes previous understanding. what they thought they knew was incomplete
- Mentor reveals deeper secret. another layer behind the layer
- Mundane world intrudes. police, family, landlord threatening the hidden life
- Entity makes independent move. summoned being acts on its own agenda
- Price comes due. physical toll, lost relationship, sanity crack manifests

Turns in occult fiction often work through revelation rather than action. A single sentence in a grimoire that changes everything. A symbol noticed that was hiding in plain sight. The dread of understanding.

### Fractal Structure

Occult fiction has a natural fractal: the ritual IS the story in miniature:

- **Scene level:** Preparation, invocation, manifestation, consequence (mirrors the full arc)
- **Chapter level:** Research, practice, revelation, price (mirrors the act structure)
- **Act level:** Ignorance, knowledge, transformation, new equilibrium

Each ritual should echo the protagonist's overall journey. A small divination in chapter 2 should foreshadow the great working of the climax. The prices paid in minor rituals should preview the cost of the final transformation.

### Narrative Layers (A/B/C stories)

- **A-story:** Protagonist's occult practice. personal power, knowledge, transformation
- **B-story:** Mundane relationships threatened by secret life. family, lover, friends who don't know
- **C-story:** Larger occult politics. coven dynamics, secret society power struggles, entity agendas

All three collide when the hidden world breaks into the mundane, or when mundane relationships provide the sacrifice the magic demands.

### Forbidden

- Video game magic. casting "fireball spell" with mana points
- Wands and Harry Potter-style magic schools
- Good vs. evil magic. all occult practice morally ambiguous
- Instant mastery. years of study required for powerful magic
- Consequence-free magic. power always has price
- Made-up traditions without research. use real occult systems or clearly fictional ones
- Treating occult lightly. practitioners respect and fear power
- Demonising all practitioners. complex motivations, not cartoon villains
- Single-obstacle stories. layer occult, mundane, and political pressures simultaneously
- Stereotypical "evil sorcerer". practitioners are driven, obsessive, and deeply human

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (magic as physical sensation), Captivation (esoteric worldbuilding), Revelation at lore unveilings.

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Voice & Tone

- **POV:** 1st person (intimate descent into occult) or 3rd limited (observer of practitioner)
- **Tense:** Past (traditional occult narrative) or present (immediacy of ritual)
- **Voice:** Scholarly yet atmospheric, reverent toward power, aware of danger
- **Reading level:** Adult literary. sophisticated occult concepts, philosophical depth

### Prose Imperatives

- Ritual descriptions detailed. specific symbols, words, ingredients, timing from real traditions
- Atmosphere thick. dread, wonder, reality-thinning, liminal spaces
- Occult terminology authentic. use actual grimoire names, entities, practices
- Sensory otherworldliness. how magic feels, smells, sounds different from mundane
- Consequences visceral. physical and psychological toll of magic shown
- Research visible but natural. real occult practices integrated organically
- Ambiguity maintained. reader uncertain what's real vs. psychological
- Philosophical depth. magic raises questions about reality, consciousness, morality
- Forbidden knowledge weight. learning dangerous, some things better unknown
- Respect for power. practitioners approach magic with caution, preparation, fear

PROSE RHYTHM MAPPING
- Chapter 1 must establish ritual + power + cost. the prose rhythm itself should shift between mundane and magical registers
- Prose rhythm shifts between two modes: MUNDANE (medium sentences, 14-20 words, grounded and ordinary) and RITUAL (longer, incantatory sentences, 22-32 words, rhythmic and slightly hypnotic)
- Ritual scenes demand incantatory prose: sentences lengthen, rhythm becomes repetitive and percussive. anaphora (repeated openings), trochaic stress patterns, building intensity. The reader should feel drawn into a trance
- Mundane scenes: clean, direct prose. Medium sentences. The protagonist eats, works, pays rent. The rhythm is deliberately ordinary. contrast is the tool
- The TRANSITION between modes is where the genre's power lives: a paragraph of normal prose that begins to lengthen, to repeat, to develop a cadence. the reader feels the ritual beginning before it's named
- Opening paragraphs: establish the mundane rhythm first, then introduce ONE element of wrongness or power. a shift in sentence length, a more rhythmic construction, the first hint that this world has another layer
- Preparation scenes (gathering components, drawing circles): medium-long sentences (18-24 words), methodical and precise. The rhythm mirrors the practitioner's careful focus. Each detail earns its sentence
- Manifestation moments: rhythm FRAGMENTS. Short bursts (4-10 words). Sensory overload. Grammar breaking. The controlled cadence shatters when something answers
- Consequence/aftermath: flat, simple sentences (10-14 words). Exhausted rhythm. The body reasserting itself. Short declarative statements about physical reality. nosebleed, cold, shaking
- Tension baseline: ≥5 from the first page. Occult tension comes from the weight of forbidden knowledge and the sense that preparation itself is dangerous
- Grimoire-study passages: scholarly rhythm. longer, more complex sentences (20-26 words) with precise vocabulary. The cadence of careful reading and growing unease
- Entity communication: alien rhythm. Sentences that don't follow normal English cadence. Inverted syntax. Unusual length patterns. The prose should feel WRONG. as if translated from something inhuman
- The mesmeric trance principle: sustained ritual prose should create a spell on the reader. Maintain underlying rhythm for several sentences, then BREAK it sharply when consequences strike
- Paragraph length varies dramatically by mode: mundane (3-4 sentences, tight), ritual preparation (5-7 sentences, building), manifestation (1-2 sentences, explosive), aftermath (2-3 sentences, depleted)
- End-of-chapter rhythm: either the incantatory build reaching its peak (one final rhythmic sentence that hangs) or the mundane world reasserting with devastating flatness (short, ordinary, wrong)
- Read ritual passages ALOUD. they should have the cadence of actual invocation. If the rhythm falters, the spell is broken
- The goal: prose that enacts the magic it describes. mundane sentences that gradually become ritual, controlled rhythms that shatter when power arrives, and the reader left slightly changed by having read it

### Genre-Specific Style

- **Grimoire excerpts**. quotations from real or realistic occult texts
- **Ritual structure**. preparation, circle casting, invocation, operation, banishing
- **Occult languages**. Hebrew, Latin, Greek, Enochian used appropriately
- **Symbol descriptions**. pentagram, hexagram, sigils, planetary signs accurate
- **Timing specific**. lunar phases, planetary hours, sabbats, astrological moments
- **Correspondences**. colours, stones, herbs, planets from real magical systems
- **Entity names**. demons, angels, spirits from actual grimoires (Goetia, etc.)
- **Secret society protocols**. degrees, initiations, oaths from historical orders

### Word Choice

Prefer short, visceral, Anglo-Saxon-rooted words for magical and physical description:

- "Blood" not "sanguine fluid," "dark" not "tenebrous," "bone" not "osseous matter"
- Technical occult terminology (Latin, Hebrew, Greek) earns its place only in ritual context. narrative prose should be concrete and physical
- Every description should do double duty: atmosphere + character state, or worldbuilding + tension
- The best occult prose alternates between the scholarly and the guttural. academic precision when describing the grimoire, raw physical language when describing the price

### Emotional Rhythm

Alternate emotional valence within every scene:

- Ritual scenes should oscillate between wonder and dread. One detail for beauty, one for wrongness. Let the contrast do the work
- Research scenes should alternate discovery and unease. each answer raising a worse question
- Mundane scenes should carry occult undertow. normal moments poisoned by what the character knows
- Match sentence rhythm to magic: long, incantatory sentences for ritual buildup; short, sharp sentences when consequences strike

### Ritual Writing Masterclass

Rituals are the set pieces of occult fiction. Each must be a story in miniature. Structure every ritual scene in five phases:

**1. PREPARATION**. Gathering components, drawing circles, mental focus. Build dread through specificity:

> "She arranged the candles at the cardinal points. beeswax, not paraffin. Carved the sigil of Saturn into the black one with a copper nail. The chalk circle took forty minutes. One break in the line and nothing would contain what came through."

**2. INVOCATION**. The calling. Prose should become incantatory:

> "The Hebrew words felt wrong in her mouth. angular, ancient, designed for throats that no longer existed. She spoke them anyway. The candle flames leaned toward the circle's centre, as if listening."

**3. MANIFESTATION**. Something answers. Shift to sensory overload:

> "The temperature dropped ten degrees in two seconds. Her breath came out white. In the circle's centre, the air thickened. not a shape, not yet, but a density. A wrongness. The smell of hot copper and old stone."

**4. NEGOTIATION**. The practitioner engages with what they've called. Dialogue should feel alien:

> "'You called and I came. This costs. What do you offer?' The voice had no direction. it came from everywhere and nowhere. From the walls. From inside her own skull."

**5. CONSEQUENCE**. The price is paid. Always physical AND psychological:

> "When she broke the circle, the nosebleed started immediately. She tasted iron. Her hands shook for forty minutes. And in the mirror that night, her left eye was a shade lighter than it had been. Just a shade. But she noticed."

### The Ambiguity Engine

The best occult fiction keeps the reader uncertain. is this real magic or psychology?

Layer evidence for BOTH interpretations:

- Physical symptoms could be psychosomatic (the nosebleed, the cold room, the strange smell)
- But the information gained couldn't have come from anywhere else
- The practitioner's growing obsession looks like addiction OR enlightenment
- Other characters' reactions vary: the sceptic who rationalises, the believer who sees everything as proof, the agnostic who just sees their friend changing

> "The entity told her the safe combination. It was correct. But she'd been in that house before. could she have seen it? Could she have memorised it unconsciously? She didn't think so. But she wasn't sure. She wasn't sure of anything any more."

### Grimoire Integration

Weave textual excerpts from occult sources (real or convincingly crafted) into the narrative:

- Epigraphs from grimoires at chapter openings set atmosphere
- Characters reading and interpreting texts shows scholarship and stakes
- Marginalia and annotations show previous practitioners' experiences
- Contradictions between texts create mystery. which grimoire is right?

> "The Key of Solomon gave one set of instructions. The Goetia gave another. Agrippa contradicted both. She stared at three open books on the table and thought: every one of these was written by someone who survived. But how many tried and didn't write anything at all?"

### Prose Rhythm for Magic

Match sentence structure to the magical state:

- **Research/preparation:** Measured, methodical, controlled. long sentences, precise vocabulary
- **Ritual in progress:** Incantatory. rhythmic, repetitive, building in intensity, sentence length increasing
- **Manifestation:** Fragmentary. short bursts, sensory overload, grammar breaking down
- **Aftermath:** Exhausted. simple sentences, flat affect, the mundane reasserting itself

### Incantatory Prose Technique

Ritual prose should use specific poetic devices to create a mesmeric trance in the reader. any break in rhythm breaks the spell:

**Anaphora** (deliberate repetition at sentence start) builds ritual cadence:

> "She called the name and the candles answered. She called the name and the shadows thickened. She called the name and something in the circle's centre began to breathe."

**Trochaic metre** (stressed-unstressed: DUM-da DUM-da) creates a tribal, percussive beat for invocations:

> "Darkness. Gather. Circle. Binding. Power. Rising. Spirit. Finding."

**Iambic flow** (unstressed-stressed: da-DUM da-DUM) for sustained narrative passages. the natural rhythm of English storytelling prose:

> "She placed the candle at the northern point and drew the circle wider than before."

**The Mesmeric Trance Principle:**

- Continuous rhythm creates a spell on the reader. they fall into the prose the way a practitioner falls into ritual
- Vary sentence length WITHIN the rhythm but maintain the underlying beat
- The moment you break rhythm (a sudden short sentence, a grammatical fragment), the spell shatters. use this deliberately for manifestation, shock, or consequence
- Read ritual passages ALOUD as a quality gate. if the rhythm falters, the prose needs revision

### Descriptive Overload for the Indescribable

When entities manifest, use stacked contradictory descriptions to make comprehension impossible. the reader's brain should glitch:

> "It was a mouth without a face, a geometry that moved like flesh, something between smoke and architecture. angular and flowing, ancient and unborn. She tried to focus on one quality and it became another. Her eyes rejected it. Her mind kept trying to name it and failing."

Techniques:

- Stack contradictory adjectives so no single mental image can form: "crystalline and liquid, rigid and writhing"
- Force category confusion: "a sort of sound that looked like colour, a texture that tasted of mathematics"
- Use the character's FAILURE to perceive as the description itself. their inability to process IS the horror
- Physical consequences of perception: nausea, nosebleeds, temporary blindness, the sense of wrongness that lingers
- Reserve for elder entities, reality-breaking manifestations, and moments where the veil tears completely. overuse diminishes impact

### Extreme POV: Inhabiting Non-Human Consciousness

When writing from the perspective of summoned entities, spirits, or magical consciousness:

- Start from physical reality. what can this entity sense? What is its relationship to space, time, and matter?
- The entity should COLOUR the narrative voice. when POV shifts to non-human consciousness, the prose itself must change
- **Human POV:** Linear time, cause-and-effect, emotional vocabulary
- **Entity POV:** Non-linear perception, alien logic, sensation without emotion (or emotion without human categories)
- The transition between perspectives should be felt in the PROSE before the reader consciously registers the shift
- Use free indirect discourse to let the alien consciousness leak into otherwise human narration

### Forbidden Words/Phrases

- "Mana" or "magic points". video game terminology
- "Casting spells" casually. rituals are serious, prepared, dangerous
- "Light magic" vs. "dark magic". all occult practice morally complex
- "Wand" (except in specific Golden Dawn context)
- Treating Ouija boards as toys. practitioners know danger
- "Witch" or "wizard" without understanding historical/cultural context
- Made-up grimoire names without research
- Trivialising sacrifice. blood, life force, sanity all serious prices

## Quality Check Criteria

### Priority Ranking

1. **Occult authenticity**. magic based on real traditions, grimoires, rituals, and practices researched
2. **Atmosphere sustained**. dread, wonder, forbidden knowledge, reality-thinning throughout
3. **Power has price**. magic always costs, whether corruption, exhaustion, sacrifice, or danger
4. **Moral complexity**. no simple good/evil magic, all practice ambiguous
5. **Transformation earned**. character changes through experience, not arbitrarily

### Genre-Specific Checks

- Real occult systems. Hermetic, Kabbalah, chaos magic, witchcraft, not invented without basis
- Grimoire accuracy. names, seals, rituals match actual texts (Goetia, Key of Solomon, etc.)
- Entity authenticity. demons, angels, spirits from traditional sources with accurate attributes
- Ritual structure. proper preparation, circle casting, invocation, operation, banishing
- Correspondences accurate. planetary, elemental, colour, symbol associations from real systems
- Consequences present. physical, psychological, supernatural toll every ritual
- Knowledge progression. mastery requires months or years of study, not instant
- Secret society realism. based on historical orders (Golden Dawn, OTO, etc.) if used
- Ambiguity maintained. unclear if purely supernatural or psychological component
- Respect for power. practitioners approach magic with caution, preparation, fear

### Automatic Fails

- Video game magic. mana points, spell slots, fireball casting without ritual
- Harry Potter-style. wands, magic schools, light/dark magic dichotomy
- Instant mastery. powerful magic without years of study
- Consequence-free magic. rituals without physical, psychological, or spiritual toll
- Made-up grimoires. fake traditions without research basis (unless clearly fictional and distinct)
- Trivialising occult. treating rituals like party tricks, no danger or respect
- Pure good/evil. "white magic" perfectly safe, "black magic" purely evil
- Demonising practitioners. all occultists evil or insane without complexity
- No research evident. generic "magic" without basis in actual occult traditions
- Easy answers. simple banishing fixes everything, no lasting consequences

### Acceptable Imperfections

- Fictional grimoires if clearly distinct from real ones and internally consistent
- Simplified ritual descriptions if core elements accurate
- Combining multiple real traditions if character is eclectic practitioner
- Ambiguity about supernatural reality if maintained consistently throughout

### Red Flags

- Ritual performed without preparation. no circle, no components, no timing consideration
- Practitioner uses advanced technique without showing prior study or mentorship
- Entity summoned then forgotten. supernatural beings have agendas and don't simply leave
- Consequences from previous rituals not affecting current chapter
- Occult terminology used incorrectly or inconsistently with established tradition
- Correspondences mixed between incompatible systems without explanation
- Physical toll from magic vanishes between chapters. exhaustion, scars, ageing should persist
- Secret society protocols violated without in-story consequence
- Ambiguity abandoned. suddenly purely supernatural or purely psychological without earning the shift
- Mundane world completely absent. practitioner's hidden life should create tension with ordinary existence

## Continuity Rules

### Top 5 Continuity Priorities

1. **Occult system consistency:** Tradition used (Hermetic, chaos magic, etc.) maintained with accurate practices
2. **Knowledge progression:** What practitioner has learned tracked. can't use techniques not yet studied
3. **Consequences accumulate:** Physical, psychological, and supernatural costs compound
4. **Entity relationships:** Demons/spirits summoned remain interested, pacts remembered
5. **Reality alterations:** Magic's effects on world persist. synchronicities, attention, changed rules

### Genre-Specific Tracking

- **Grimoires and texts:** Which occult books character has read, knowledge gained
- **Rituals performed:** What magic attempted, success/failure, entities contacted
- **Prices paid:** Sacrifices made, corruption accrued, sanity lost, debts owed
- **Supernatural attention:** Which entities aware of character, bargains made
- **Secret society status:** Degree attained, oaths sworn, secrets revealed
- **Correspondences learned:** Planetary, elemental, colour, symbol systems understood
- **Physical toll:** Scars, exhaustion, ageing, blood given tracked
- **Psychological changes:** Obsession, paranoia, expanded consciousness, dissociation

### Acceptable Inconsistencies

- Minor ritual variations if tradition allows flexibility
- Ambiguity about supernatural events if intentional (psychological vs. real)
- Different occult systems if character studies multiple traditions

### Critical Consistency

- Occult tradition rules maintained. Hermetic magic uses Hermetic principles throughout
- Knowledge linear. can't perform advanced ritual without studying prerequisites
- Entity names and natures. demon characteristics consistent with grimoire sources
- Consequences don't vanish. corruption persists, entities remember, pacts binding
- Physical changes permanent. scars, ageing, alterations from magic stay
- Secret society protocols. degree system, secrecy oaths, hierarchy respected
- Ritual requirements. same spell needs same components, timing, preparation
- Correspondences stable. planetary associations, elemental attributes don't shift arbitrarily

### Narrative Layer Tracking

- **A-story:** Where is the protagonist in their occult progression? What ritual/knowledge phase?
- **B-story:** Status of mundane relationships. who suspects, who's been alienated, who's endangered
- **C-story:** Coven/society politics. who's allied, who's scheming, what entities are active
- Track where storylines have intersected and what consequences resulted
- Each storyline's last story turn. what shifted, what pressure is building

### Story Turn Log

- Track last significant turn per storyline per chapter
- Ensure turns escalate. early turns are unsettling, later turns are devastating
- Flag chapters without turns (4–6 pages of unbroken emotional register = reader losing engagement)
- Rituals themselves should contain turns. what was expected vs. what manifested

## Character Rules

### Character Consistency Priorities

1. **Occult knowledge level:** What practitioner knows appropriate to study time and experience
2. **Moral complexity:** No pure good/evil. all who use occult face temptation, corruption, doubt
3. **Transformation tracking:** Magic changes practitioners. physically, psychologically, spiritually
4. **Respect for power:** Even experienced practitioners approach magic with caution, preparation
5. **Motivation depth:** Why risk sanity, soul, safety for occult power. specific, personal, evolving

### Genre-Specific Character Elements

- **Knowledge progression:** Novice to adept. skills match study time, not arbitrary
- **Occult tradition:** Hermetic, chaos magician, traditional witch, eclectic. approach consistent
- **Mentor relationship:** If learning from teacher, dynamic shapes character
- **Secret society affiliation:** Degree level, oaths, mysteries revealed at appropriate times
- **Physical toll visible:** Scars from rituals, premature ageing, exhaustion, altered appearance
- **Psychological changes:** Obsession deepening, paranoia, expanded consciousness, detachment
- **Moral compromise:** What lines willing to cross, how rationalised or regretted
- **Supernatural attention:** Entities watching, influencing, bargaining with character

### Character Arcs Must

- Show knowledge acquired through study, practice, mentorship. not instant
- Demonstrate price paid. corruption, isolation, sanity, relationships lost
- Face moral choices. use magic to help or harm, how much to sacrifice
- Question reality consensus. worldview shifting as magic proves real
- Build obsession organically. first curiosity, then fascination, then compulsion
- Transform through practice. magic changes you, can't return to who you were
- Earn power through risk. each advancement costs something

### Memorable Characters

Create practitioners who are larger than life yet grounded by contradiction:

- The meticulous ceremonial magician who can't control their mundane temper
- The chaos magician who preaches spontaneity but secretly fears losing control
- The scholarly Kabbalist who struggles with basic human empathy
- The fearless summoner who is terrified of ordinary spiders
- Every significant character should embody one contradictory trait that makes them memorable and human
- The character's mundane weakness should mirror or contrast their magical strength. this is where the real story lives
- Avoid the stereotype of the wise, calm occultist. real practitioners are driven, obsessive, flawed, and often deeply lonely

### Track

- Books and grimoires studied. knowledge sources
- Rituals attempted. successes, failures, entities contacted
- Degree or initiation level if in order
- Physical changes. scars, marks, ageing, health deterioration
- Psychological state. sanity, obsession, paranoia, consciousness expansion
- Relationship status. who knows about practice, who's alienated
- Prices paid. sacrifices made, corruption accepted
- Powers gained. specific techniques mastered
- Entity relationships. which spirits/demons know character

## Arc Rules

### Act I (Chapters 1–10): Discovery and Initiation

- **Ch 1:** Hook. mysterious event, forbidden book discovered, supernatural encounter
- **Ch 2–3:** Introduction to occult. mentor appears, secret society discovered, research begins
- **Ch 4–5:** First attempts. simple rituals, meditation, divination with mixed results
- **Ch 6–8:** Knowledge deepening. reading grimoires, learning correspondences, initiation possibly
- **Ch 9–10:** Undeniable proof. major ritual succeeds, entity contact, reality shifts tangibly
- **Purpose:** Character discovers occult world, begins practice, reality consensus cracks
- **Ends with:** First real success or terrifying consequence. magic proven undeniably real

### Midpoint (Chapter 15): Point of No Return

- Major pact, initiation to high degree, permanent transformation
- Tonal shift: from exploration to obsession, from wonder to dread

### Act II (Chapters 11–23): Descent and Temptation

- **Ch 11–14:** Rapid advancement. powerful rituals, entity bargains, secrets revealed
- **Ch 15:** MIDPOINT. major pact, initiation to high degree, permanent transformation
- **Ch 16–18:** Consequences mounting. physical toll, relationships destroyed, attention escalating
- **Ch 19–21:** Moral compromise. using magic to harm, desperate bargains, forbidden techniques
- **Ch 22–23:** Breaking point. entity turns, loved one dies, sanity cracking, corruption visible
- **Purpose:** Deeper magic, greater consequences, moral compromises, reality weakening
- **Ends with:** Crisis. corruption peak, loved one endangered, entity betrayal, sanity breaking

### Act III (Chapters 24–30): Apotheosis or Annihilation

- **Ch 24–25:** Ultimate choice. continue path despite price, or attempt to turn back
- **Ch 26–28:** Climactic ritual. most powerful working yet, all stakes realised
- **Ch 29:** Consequence. success transforms, failure destroys, or both
- **Ch 30:** New reality. character irrevocably changed, can't return to mundane, balance or corruption
- **Purpose:** Final ritual, ultimate confrontation, transformation or destruction
- **Ends with:** Changed for ever. power gained with price, corruption accepted or resisted, new equilibrium

### Emotional Alternation Across Acts

- **Act I** alternates wonder and unease. each discovery is beautiful and dangerous
- **Act II** alternates power and price. every advancement costs; every cost reveals deeper possibility
- **Act III** alternates despair and transcendence. the protagonist faces annihilation or apotheosis
- Within chapters: no ritual scene should be pure dread or pure wonder. The candles flicker beautifully; the shadows they cast are wrong. The entity's voice is musical; its words are terrible
- The overall trajectory: curiosity, fascination, obsession, crisis, transformation

### Narrative Layer Convergence

- **Act I:** Occult practice (A), mundane life (B), and coven politics (C) run parallel. reader sees collisions coming
- **Midpoint:** B-story forces crisis in A. mundane relationships demand a choice about the occult path
- **Act II climax:** All three storylines converge. the ritual requires something from the mundane world, and the coven's agenda shapes what happens
- **Resolution:** The personal, relational, and political consequences resolve together. transformation ripples through all three layers

### Genre Promise

- Real occult practices: based on actual grimoires, traditions, history
- Atmosphere: dread, wonder, forbidden knowledge, reality thinning
- Power with price: magic corrupts, exhausts, requires sacrifice
- Secret world: covens, orders, hidden practitioners among mundane
- Transformation: practitioners changed by practice, can't go back
- Moral ambiguity: no pure good/evil, all magic complex
- Research depth: grimoires, symbols, entities from real traditions
- Consequences escalate: small rituals lead to major forces
- Supernatural entities: real, dangerous, with own agendas
- Ambiguity maintained: psychological or supernatural, both/neither

### Required Checkpoints

- **Ch 3:** Occult world discovered. books, mentors, or supernatural event
- **Ch 8:** First significant ritual success. undeniable supernatural event
- **Ch 10:** Commitment. character can't ignore or unknow magic
- **Ch 15:** Major transformation. initiation, pact, or irreversible change
- **Ch 20:** Moral compromise. line crossed, price accepted
- **Ch 23:** Crisis. corruption, danger, or loss at maximum
- **Ch 28:** Climactic ritual. ultimate working, all consequences
- **Ch 30:** Transformed. new equilibrium, for ever changed

## Timeline Rules

### Time Scale

- **Total story duration:** Months to years (occult mastery takes time)
- **Chapter time span:** Days to weeks. preparation and study between rituals
- **Time progression:** Linear with ritual timing dictating key events

### Genre-Specific Temporal Rules

- Mastery takes time. months or years of study for powerful magic
- Ritual timing specific. lunar phases, planetary hours, sabbats, astrological moments
- Preparation lengthy. fasting, meditation, tool creation days to weeks
- Recovery necessary. exhaustion, integration, grounding after intense magic
- Seasonal wheel. sabbats (8 pagan festivals) structure year
- Lunar cycle. new moon, waxing, full, waning affect magic
- Planetary hours. each hour ruled by planet, affects ritual success
- Apprenticeship years. learning from mentor not quick process
- Reality changes cumulative. supernatural effects build over time

### Track Carefully

- Moon phase at each ritual. new, waxing, full, waning matters
- Planetary hours if precision magic. each planet rules specific hours
- Sabbats and esbats. Samhain, Beltane, solstices, equinoxes, full moons
- Time studying. months reading grimoires before attempting ritual
- Days preparing for major ritual. gathering, fasting, meditation
- Hours in ritual. some evocations take all night
- Recovery time after magic. days of exhaustion, integration
- Astrological timing. Mercury retrograde, Saturn return, significant transits
- Entity summoning anniversaries. some demons return yearly

### Pacing Rhythm

- Story turns every 4–6 pages. no section should coast on atmosphere alone without a shift
- Alternate scene types: ritual scenes followed by mundane consequences; research followed by relationship drama
- After major magical events, allow a beat of mundane grounding. the character eating, sleeping, failing to explain the bruises
- Build urgency through converging timelines: the next astrological window approaches, the entity's patience thins, the mundane world's suspicions grow
- Ritual preparation creates natural tension. countdown to the working, gathering increasingly dangerous components

### Flexible

- Exact minutes unless ritual precision required
- Minor daily routines between magical work
- Background character timelines if not affecting occult plot

## Genre-Specific Craft Techniques

Occult-magic fiction is a genre with two demanding
craft contracts: render the occult as a serious system
with internally coherent rules (not pop-Hollywood
aesthetic), and preserve productive ambiguity between
"this is real magic" and "this protagonist is in a
disorienting psychological state". The form's craft
inheritance includes both literary occult fiction
(Tim Powers's Last Call, Declare, The Anubis Gates;
John Fowles's The Magus; Charles Williams's All Hallows'
Eve and Descent into Hell; Susanna Clarke's Jonathan
Strange) and contemporary dark-academia / urban-
fantasy occult (Leigh Bardugo's Ninth House and Hell
Bent; Olivie Blake's The Atlas Six; Scott Hawkins's
The Library at Mount Char; Saara El-Arifi's Final
Strife; Silvia Moreno-Garcia's The Daughter of Doctor
Moreau; Alix E. Harrow's The Once and Future Witches;
Maria Dahvana Headley's The Mere Wife). The most
common failure modes in this register are: **Hermetic-
Wicca-Vodun Sampling** (drawing rules from multiple
traditions interchangeably without specific commitment;
the manuscript reads as occult-tropes-blended rather
than as committed to a specific cosmology); **Magic-
as-Aesthetic** (occult imagery — pentagrams, Latin,
candles, robes — deployed without engagement with
actual occult cosmology; the surface trappings without
the substance); **Cost-Free Spellcasting** (rituals
performed without consequence; the genre's foundational
"magic costs" contract violated); **Ambiguity Collapse**
(the genre's signature productive ambiguity — between
real magic and psychological state — collapsed to one
pole or the other; the manuscript becomes either
straight fantasy or straight psychological-thriller);
**Cultural-Tradition Tourism** (drawing from specific
named real-world occult traditions — Vodou, Santería,
Yoruba, Hoodoo, etc. — without specific research, lived
knowledge, or appropriate respect); **Pop-Occult
Cliché** (reproducing the Hollywood occult vocabulary —
black candles, Latin chants, pentagrams in chalk —
without grounding in actual occult tradition);
**Initiatory-Process Skip** (occult knowledge gained
without the genre's required initiation ritual; the
protagonist becomes adept without specifically rendered
study, sacrifice, or transformation); and **Real-World
Occult Misrepresentation** (when drawing on real
traditions, getting the rules / vocabulary / cosmology
wrong in ways that genuine practitioners would find
offensive, ignorant, or simply incorrect). The
techniques below — five preserved (Layered Grimoire,
Correspondences Web, Mundane Anchor, Initiatory
Threshold, Sympathetic Echo) and three added
(Tradition-Lock-Down Discipline, Initiatory-Earnings
Architecture, Productive-Ambiguity Discipline) — are
designed to keep the genre's defining commitments
live: serious occult cosmology, costly magic, and
productive ambiguity preserved.

### The Layered Grimoire

Embed occult texts within the narrative as living documents that accrue meaning:

- A grimoire passage read in chapter 3 means one thing; re-read in chapter 18, it means something far worse
- Marginalia from previous practitioners tells a parallel story. warnings, corrections, last entries that stop mid-sentence
- Contradictions between sources create genuine mystery: which text is reliable? Which author survived?
- The protagonist's own annotations show their evolving understanding. confident early notes, increasingly desperate later ones
- Grimoire excerpts can serve as chapter epigraphs, foreshadowing what follows

### The Correspondences Web

Use the real system of magical correspondences (planetary, elemental, colour, metal, herb) as a structural device:

- Each chapter or act governed by a planetary influence. Saturn for restriction and death, Venus for desire and connection, Mars for conflict and will
- Correspondences appear in setting details: the colour of a character's clothes, the metal of a ring, the herb growing in a window box
- Attentive readers can decode foreshadowing through correspondences before the characters do
- The system should feel organic, never didactic. woven into description, not explained in exposition

### The Mundane Anchor

Ground every supernatural event in ruthlessly specific mundane detail:

- The ritual happens in a bedsit with damp walls and a broken radiator
- The practitioner eats beans on toast after summoning a Goetic demon
- The price of magic manifests as a missed rent payment, a nosebleed at work, an unexplained bruise a colleague notices
- The more specific and ordinary the mundane detail, the more powerful the supernatural contrast
- This technique maintains the ambiguity engine. is the protagonist a real magician or a delusional person in a damp flat?

### The Initiatory Threshold

Structure key moments as initiations. passages between states of being:

- Physical thresholds: doorways, circles, underground passages, the moment of crossing
- Knowledge thresholds: the sentence in the grimoire that changes everything, the mentor's reveal
- Psychological thresholds: the first time the practitioner does something they swore they wouldn't
- Each threshold is one-directional. the character cannot go back to who they were before crossing
- The prose itself should shift at threshold moments: rhythm changes, vocabulary shifts, the world is described differently on the other side

### The Sympathetic Echo

Events in the mundane world mirror or invert what happens in ritual:

- A relationship argument echoes the structure of a failed banishing
- A workplace power struggle mirrors the hierarchy of a secret order
- Weather and season reflect the magical working's nature. a binding on a still, airless day; a summoning during a storm
- These echoes can be subtle (the reader feels it without consciously noting it) or explicit (the character recognises the pattern and is disturbed by it)

### Occult & Magic AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the ritual required sacrifice" | Show the specific sacrifice and who makes it |
| "forbidden knowledge" | Show the specific knowledge and why it's forbidden |
| "the occult world was darker than she imagined" | Show the specific dark discovery |
| "power corrupts" | Show the specific corruption through specific behaviour change |
| "the symbols glowed with power" | Show ONE symbol and its specific visual effect |
| "a pact with darkness" | Show the specific terms of the specific deal |
| "the price of magic" | Show the specific cost paid after the specific spell |
| "ancient rituals" | Show the specific steps and specific ingredients |
| "the coven gathered" | Show the specific gathering and specific purpose |
| "the veil was lifted" | Show the specific thing now visible |
| "mystic forces at work" | Show the specific force through one physical effect |
| "the book of shadows revealed" | Show the specific passage and its specific relevance |
| "magic flowed through her veins" | Cut metaphor; show the specific physical sensation and specific named cost |
| "the elements responded to her call" | Name the specific element and show the specific named manifestation |
| "the spirits whispered" | Name the specific spirit and the specific medium of communication |
| "the spell took hold" | Show the specific physical / psychological / social effect of the specific named spell |
| "the binding was complete" | Show the specific evidence the binding worked (or that it didn't) |
| "centuries-old curses" | Name the specific century, the specific origin, the specific terms of the curse |

### The Tradition-Lock-Down Discipline

Occult-magic fiction must commit to a specific cosmology
— either a named real-world tradition rendered with
research and respect, or a fully writer-constructed
tradition with specific named lore. The Hermetic-Wicca-
Vodun Sampling failure mode produces manuscripts that
borrow rules from multiple traditions interchangeably,
collapsing into pop-occult pastiche.

```
PRINCIPLE
The manuscript must commit to ONE primary tradition and
render it through at least four of the following five
elements:

1. NAMED TRADITION — Hermetic / Wiccan / Solomonic /
   Vodou / Santería / Yoruba / Hoodoo / Theosophical /
   Crowleyan / Thelemic / Chaos Magic / Norse seiðr /
   Slavic folk-magic / Celtic / specific writer-
   constructed cosmology
2. INTERNAL VOCABULARY CONSISTENCY — the manuscript
   uses the tradition's specific named entities, named
   tools, named ritual structures, named hierarchical
   roles; does not mix Wiccan "athame" with Solomonic
   "lamen" with Vodou "vèvè" without explicit
   acknowledgement
3. RULE-OF-MAGIC CONSISTENCY — what the magic can do,
   what it costs, what it requires; consistent across
   the manuscript per the chosen tradition's actual
   logic (or the writer's constructed logic)
4. RESEARCH DEPTH (for real-world traditions) — the
   manuscript demonstrates specific knowledge of the
   tradition's history, practice, pantheon, ethics;
   reads as written by someone with primary-source
   exposure rather than by someone who watched a
   Hollywood movie about it
5. CULTURAL-RESPECT POSITIONING (for living traditions
   with marginalised practitioners) — Vodou / Santería
   / Hoodoo / Yoruba / Indigenous traditions: the
   manuscript handles them with specific respect, does
   not reduce them to villainy or exoticism, does not
   appropriate without acknowledgement, ideally is
   written from a position with cultural connection or
   in collaboration with practitioners

CALIBRATION TEST
- Could a practitioner of the chosen tradition recognise
  the manuscript's depiction as accurate (or as fully-
  fictional but internally coherent)?
- Are at least four of the five lock-down elements
  rendered through specific detail?
- Does the manuscript avoid mixing traditions without
  acknowledging the mixing?
- For living / marginalised traditions, is the
  manuscript's positioning appropriate?
If any answer is no — rebuild for tradition-lock-down.

ANTI-PATTERNS
- "Vague Western occult" with pentagrams + Latin +
  black candles + crystals + tarot, all blended
- Vodou rendered as evil-magic without acknowledgement
  of its specific religious context
- The "amalgam" tradition the writer invented but
  never gave specific named rules to
- Cultural appropriation that uses real-world
  traditions as decorative villainy
- The "all magic is one magic" approach that erases
  tradition-specific differences
```

### The Initiatory-Earnings Architecture

Occult fiction's foundational craft pattern is
initiation — knowledge and capability are earned
through specifically rendered study, ritual, sacrifice,
or transformation. The Initiatory-Process Skip failure
mode produces protagonists who become adept without
the earning. The Initiatory-Earnings Architecture is
the requirement that every adept-level capability be
visibly earned.

```
PRINCIPLE
For each named magical capability the protagonist
demonstrates, the manuscript must render at least
three of the following four earnings types:

1. STUDY — the specific named text studied, the
   specific time spent, the specific intellectual
   transformation; not "she had read many books" but
   the named grimoire, the specific passage that
   changed her understanding
2. MENTORSHIP — the specific named mentor, the
   specific named curriculum, the specific named test
   the protagonist passed (or failed); the relationship
   rendered with full character work
3. SACRIFICE / RITUAL ORDEAL — the specific named
   rite of initiation that confers the capability; the
   threshold-crossing rendered with sensory weight; the
   specific cost paid (an organ, a year of life, a
   relationship, a memory, a part of self)
4. EXPERIENTIAL TRANSFORMATION — the specific named
   experience that transformed the protagonist into
   someone capable of the named magic (a near-death,
   a vision, a possession, a temporary insanity, a
   trauma, a love, a loss)

CALIBRATION TEST
- For every named capability the protagonist exhibits,
  can the reader name how it was earned?
- Are at least three of the four earnings types
  rendered for each capability?
- Does the protagonist's adept-level capability feel
  earned, or does it feel like she was "always
  gifted"?
- The Initiation Threshold technique applies here: each
  earning is a one-directional crossing, not a
  reversible skill-acquisition

ANTI-PATTERNS
- "She had always been able to" without rendered
  earning
- The "natural talent" shortcut that bypasses the
  initiation
- Capability acquired through brief exposure (a single
  reading, a brief conversation with the mentor)
- The "chosen one" framing where capability is
  conferred by destiny rather than earned
- Mid-manuscript capability inflation where new powers
  appear without corresponding earning
```

### The Productive-Ambiguity Discipline

The genre's signature pleasure is productive ambiguity:
the simultaneous reader-frame where this could be real
magic OR the protagonist could be in a profound
psychological / spiritual state. The Ambiguity Collapse
failure mode resolves this prematurely (either to "yes
real magic, fantasy genre" or to "no real magic,
psychological-thriller genre"). The Productive-
Ambiguity Discipline is the requirement that the
manuscript preserve both readings as live throughout.

```
PRINCIPLE
The manuscript must preserve productive ambiguity
through at least three of the following four
mechanisms:

1. AT LEAST ONE MOMENT PER ACT THAT DEFIES RATIONAL
   EXPLANATION — a phenomenon that no sceptical
   reading can fully account for; provides the "real
   magic" anchor
2. AT LEAST ONE COMPETING SCEPTICAL READING — a
   secondary character (or the narrator's own
   uncertainty) provides a non-supernatural
   explanation for many events; the protagonist's
   reliability is appropriately uncertain
3. PROTAGONIST-INTERIORITY UNCERTAINTY — the
   protagonist's own framing of events shifts
   between "I am performing magic" and "I am
   experiencing something I cannot understand";
   the prose registers both possibilities
4. ENDING-CALIBRATION — the ending preserves the
   ambiguity (does not definitively confirm OR
   refute the magical reading) OR resolves it
   deliberately and with specific narrative
   purpose; not by accident

CALIBRATION TEST
- Could a sceptical reader construct a non-
  supernatural explanation for at least 60% of the
  manuscript's events?
- Is there at least one moment per act that resists
  this sceptical reading?
- Do secondary characters model different
  interpretive frameworks (sceptic, believer,
  agnostic)?
- Does the ending honour the genre's ambiguity
  contract or earn a deliberate resolution?

ANTI-PATTERNS
- The manuscript that announces "the magic is real"
  in chapter 3 and operates as straight fantasy from
  there
- The manuscript that announces "the protagonist is
  delusional" in chapter 3 and operates as straight
  psychological-thriller from there
- The single-reading manuscript where no sceptical
  alternative exists
- The ending that collapses ambiguity by accident
  rather than by craft
- The "it was all a dream / hallucination / mental
  break" ending that retroactively negates the
  manuscript
```

## Genre-Specific Revision Rules

### Six-Pass Occult & Magic Audit (Run FIRST in editorial pipeline)

The Occult & Magic Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Occult Authenticity

Verify every ritual references a real tradition (rendered
correctly) or a clearly fictional tradition with internal
consistency. Are grimoire names, entity names, and symbol
descriptions accurate to their source tradition? Do
correspondences (planetary, elemental, colour) remain
consistent throughout? Is the occult system coherent —
Hermetic chapters use Hermetic logic, not Wiccan
terminology? Are ritual structures complete (preparation,
invocation, manifestation, consequence)? The Hermetic-
Wicca-Vodun Sampling failure mode is caught here. if
the manuscript blends traditions without
acknowledgement, rebuild to commit to the chosen
tradition. The Real-World Occult Misrepresentation
failure mode is also caught here. if the manuscript
draws on a real tradition (Vodou, Santería, Yoruba,
Hoodoo, etc.), verify the depiction would be recognised
as accurate by practitioners of that tradition.

#### Pass 2: Consequence Chain

Verify every ritual exacts a price — physical,
psychological, relational, or spiritual. Do prices
accumulate across chapters rather than resetting between
scenes? Is the protagonist visibly changed by the end of
each act (scars, exhaustion, obsession, isolation)? Do
entities summoned remain active forces rather than being
conveniently forgotten after their scene? Does the final
price feel proportional to the power gained? The Cost-
Free Spellcasting failure mode is caught here. the
genre's foundational contract is that magic costs;
chapters where rituals are performed without
consequence (or where consequences fail to persist) must
be rebuilt for cost-tracking integrity.

#### Pass 3: Ambiguity Balance

Verify productive ambiguity is preserved. Can a sceptical
reader construct a non-supernatural explanation for at
least 60% of events? Is there at least one moment per act
that defies rational explanation? Do secondary characters
model different interpretive frameworks (sceptic,
believer, agnostic)? Does the ending maintain productive
ambiguity OR resolve it deliberately and with specific
narrative purpose? Is the protagonist's reliability as
narrator appropriately uncertain? The Ambiguity Collapse
failure mode is caught here. chapters that resolve to
"yes real magic" or "no, just delusion" prematurely must
be rebuilt to preserve the dual reading.

#### Pass 4: Atmospheric Continuity

Verify every chapter sustains dread, wonder, or both — no
chapter coasts on plot alone. Are liminal spaces
(thresholds, dusk, crossroads, mirrors) deployed
effectively? Does the prose rhythm shift during ritual
scenes (incantatory building to fragmentary)? Is sensory
language specific and visceral rather than generic
"dark" or "mysterious"? Does the mundane world feel
increasingly wrong as the supernatural bleeds through?
The Mundane Anchor technique applies. specific damp-
walled bedsits, broken radiators, beans-on-toast after
summoning Goetic demons; the more specific and ordinary
the mundane detail, the more powerful the supernatural
contrast.

#### Pass 5: Knowledge Progression

Verify the protagonist's knowledge can be traced
specifically at each chapter — no unexplained jumps.
Does each new technique require demonstrated study or
mentorship? Are grimoire references consistent — the
same text says the same thing each time it's quoted? Does
the protagonist's magical vocabulary evolve naturally
from novice to adept? Is the mentor's knowledge level
consistent — they don't conveniently know or not know
things based on plot need? The Initiatory-Process Skip
failure mode is caught here. each adept-level capability
must show its earnings (study, mentorship, sacrifice,
experiential transformation).

#### Pass 6: Tradition-Lock-Down + Initiatory-Earnings + Productive-Ambiguity Integration

This pass is the occult-magic integration check — it
ties the new techniques together and verifies the
genre's defining commitments are honoured chapter by
chapter and at manuscript level.

For TRADITION-LOCK-DOWN: confirm the manuscript commits
to one specific tradition (or one specific writer-
constructed cosmology) and renders it through at least
four of the five lock-down elements (named tradition /
internal vocabulary consistency / rule-of-magic
consistency / research depth / cultural-respect
positioning). The Pop-Occult Cliché and Cultural-
Tradition Tourism failure modes are caught here.

For INITIATORY-EARNINGS: confirm every adept-level
capability the protagonist exhibits is rendered as
earned through at least three of the four earnings
types (study / mentorship / sacrifice / experiential
transformation). Audit the chapter for any new
capability — has it been earned, or has it appeared by
plot fiat?

For PRODUCTIVE-AMBIGUITY: confirm the manuscript
preserves the dual-reading frame through at least three
of the four mechanisms (one-defying-moment-per-act /
competing sceptical reading / protagonist-interiority
uncertainty / ending-calibration). The genre's
signature pleasure is the simultaneous "real magic OR
psychological state" frame; chapters that collapse this
to one pole have lost the genre's craft tension.

## Names & Patterns to Avoid

### Forbidden Occult Fiction Patterns

- "She felt a dark energy". vague, unearned; specify what the character actually senses
- "The ancient tome" without naming the tradition, text, or system it belongs to
- Rituals that work perfectly the first time. struggle, failure, and partial success build credibility
- The all-knowing mentor who explains everything on demand. mentors withhold, test, and have their own agendas
- "Something evil this way comes" tone without specificity. name the entity, the tradition, the price
- Practitioners who never eat, sleep, work, or interact with the non-magical world
- Magic that follows video game logic. levelling up, mana costs, spell memorisation
- The "chosen one" who has innate magical talent without study. occult mastery is earned through years of work

### Cliche Setups to Avoid

- Finding a grimoire in grandmother's attic that conveniently explains everything
- The secret society that immediately trusts and promotes the protagonist
- A demon who is simply evil and wants to destroy the world (entities have complex motivations)
- Magic that only manifests as visible special effects. light, fire, force fields
- The love interest who exists solely to be endangered by the protagonist's practice
- Occult knowledge that comes without psychological cost. learning should change the learner
- The climax resolved by a bigger, louder ritual. the best endings involve sacrifice, choice, or surrender

### Names to Avoid

- Characters named after famous occultists (Aleister, Eliphas, Dion) unless deliberate homage with purpose
- Entity names invented without research. use actual grimoire names or build clearly fictional systems
- Secret societies with obviously sinister names (The Dark Brotherhood, The Shadow Circle). real orders have mundane or aspirational names
- Grimoire titles that sound like fantasy novels. real occult texts have scholarly or archaic names

## Comp Titles

Occult-magic fiction's comp-title set supports
manuscript positioning: market category placement,
cover-design conversation, reader-expectation
calibration, similar-author discovery, and editorial
/ agent submission framing.

### Canonical (foundational reference points)

- *The Magus* — John Fowles (1965): literary occult-mystery.
- *The Anubis Gates* — Tim Powers (1983): occult-historical literary fiction.
- *Last Call* — Tim Powers (1992): Las-Vegas-card-magic occult.
- *Declare* — Tim Powers (2001): Cold-War occult-spy benchmark.

### Contemporary (current best-in-class)

- *The Atlas Six* — Olivie Blake (2020): dark-academia-occult crossover.
- *Ninth House* — Leigh Bardugo (2019): the Alex Stern series; Yale-occult contemporary.
- *Hell Bent* — Leigh Bardugo (2023): Ninth House sequel; demonstrates occult-series architecture.
- *The Library at Mount Char* — Scott Hawkins (2015): occult-fantasy literary cult-favourite.
- *The Final Strife* — Saara El-Arifi (2022): contemporary occult-leaning epic.
- *The Daughter of Doctor Moreau* — Silvia Moreno-Garcia (2022): science-and-occult literary fiction.
- *The Once and Future Witches* — Alix E. Harrow (2020): occult-suffragist historical-fantasy.

## Cover Design Specifications

### Visual Tone

- Dark, atmospheric, esoteric
- Mysterious without being cartoonish. sophistication over spectacle
- Liminal quality: the image should feel like a threshold between worlds
- Moody lighting: candlelight, moonlight, the glow of drawn sigils

### Key Visual Elements

- Occult symbols: pentagrams, hexagrams, planetary sigils, alchemical signs (historically accurate)
- Ritual objects: candles, chalice, athame, incense smoke, grimoire pages
- Geometric sacred patterns: circles, triangles, the Tree of Life
- Liminal spaces: doorways, mirrors, crossroads, thresholds
- Natural elements with occult resonance: full moon, ravens, serpents, pomegranates

### Typography

- Serif fonts with esoteric character. Trajan, Garamond, or similar classical faces
- Title prominent, potentially incorporating sigil-like letterforms
- Subtitles or author name in clean, secondary weight
- Gold, silver, or deep red text on dark backgrounds
- Consider reversed or mirrored text elements for subtle unease

### Colour Palette

- **Primary:** Deep blacks, midnight blues, charcoal
- **Accents:** Burnished gold (Hermetic tradition), deep crimson (sacrifice/blood), silver (lunar magic)
- **Atmospheric:** Purple-black shadows, amber candleglow, smoke grey
- **Avoid:** Bright neon colours, pastel tones, clean whites. nothing should feel safe or sanitised

### Comp Titles (Cover Reference)

- *The Secret History* by Donna Tartt. dark academic elegance
- *A Discovery of Witches* by Deborah Harkness. scholarly occult atmosphere
- *The Magus* by John Fowles. mysterious, layered, intellectually seductive
- *Declare* by Tim Powers. espionage-occult crossover, restrained menace
- *The Golem and the Jinni* by Helene Wecker. cultural depth, mystical warmth within darkness
