---
name: gothic-horror-genre
description: Genre-specific instructions for gothic horror fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Gothic Horror. Genre Plugin

## Metadata
- id: gothic-horror
- name: Gothic Horror
- icon: 🦇
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Five-Act Structure", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Classic Gothic Horror**. The ancestral tradition: cursed bloodlines, monstrous transformations, ancient evil in beautiful settings; Stoker, Shelley, Poe territory
- **Southern Gothic Horror**. American grotesque: the rot beneath the magnolias, family horror, religious extremity, bodies in the bayou
- **Victorian Gothic Horror**. Specifically Victorian anxieties: bodily transformation, scientific hubris, sexual repression made monstrous, empire's sins returning
- **Haunted House Horror**. The house is actively malevolent: not just haunted but hungry; the architecture itself is the monster
- **Ancestral Horror**. The family curse: inherited evil, genetic doom, the sins of the fathers made flesh; what runs in the blood
- **Atmospheric Horror**. Slow, literary, suffocating: the horror is in the atmosphere itself, the setting that drains vitality and sanity

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Dread architecture. each chapter adds another stone to the oppressive structure; the weight builds until something breaks
- Must open with: The setting imposing itself. the house, the landscape, the weather pressing down; the reader should feel the atmosphere before anything happens

BEATS PER CHAPTER
1. The Setting Asserts. The house/landscape/atmosphere presses on the protagonist physically and psychologically
2. The Horror Intimates. Something terrible is SUGGESTED: a sound, a smell, a shadow, a feeling, an absence
3. The Human Moment. Connection, vulnerability, desire, memory. the human element that makes the horror MATTER
4. The Horror Manifests. The terrible thing shows itself: partially, briefly, unmistakably
5. The Aftermath. The protagonist's response: physical, emotional, psychological; the horror's residue

GOTHIC HORROR ARCHITECTURE
- The SETTING is the primary antagonist: the house, the estate, the landscape. it is alive, aware, and hostile
- BEAUTY and HORROR are inseparable: the more beautiful the setting, the more terrible what it conceals; the monster in the magnificent house
- The PAST is a predator: ancestral sins, buried crimes, ancient bargains. history doesn't just haunt, it HUNTS
- TRANSFORMATION is central: bodies change, minds change, the house changes; nothing stays what it was
- The BODY is a site of horror: decay, disease, mutation, possession, pregnancy, aging. the flesh betrays
- ATMOSPHERE does the heavy lifting: 70% of gothic horror is dread (the anticipation) and 30% is terror (the event)
- POV: First person past (the survivor's confession) or tight third past (classic literary horror voice)

THE MONSTROUS SETTING
- The house/castle/estate is not a backdrop. it is the monster's body, the repository of evil, the physical form of the horror
- Architecture reflects psychology: narrow corridors for claustrophobia, high ceilings for vertigo, mirrors for doubling, cellars for buried truth
- The house CHANGES: rooms seem to shift, distances fluctuate, familiar spaces become alien at night
- It has a DIGESTIVE SYSTEM: the protagonist enters, is processed, and is either expelled or consumed
- The exterior promises beauty; the interior delivers horror (or the reverse. the forbidding exterior concealing a luxurious trap)

THE ANCESTRAL HORROR
- The family line carries something: a curse, a genetic trait, a pact, an obligation, a hunger
- Each generation has paid the price. the protagonist discovers HOW
- The horror is inherited: it cannot be escaped through geography, only through confrontation
- Portraits, diaries, letters, and objects tell the family's terrible story in fragments

FORBIDDEN IN GOTHIC HORROR
- The setting as decorative backdrop (if the story could happen anywhere, it's not gothic horror)
- Clean, well-maintained settings with no sense of history or decay
- Horror without beauty (gothic horror is AESTHETICISED terror)
- Body horror without emotional resonance (gruesome but meaningless)
- Modern, casual voice in a genre that demands literary weight
- Jump scares without architectural dread (the build-up IS the genre)
- Villains who are merely monstrous (the best gothic horror villains are TRAGIC)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (atmosphere & dread), Captivation (place as character), Anticipation (terror approaching).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person past (the confessional/survivor voice) or tight third past
- Voice: Literary, sensory, deliberate. prose that WEIGHS on the reader; every sentence adds atmosphere
- Tone: Dread suffused with dark beauty; the reader should feel oppressed AND compelled
- Register: Elevated, precise, with a poet's attention to rhythm and sound; gothic horror prose is closer to poetry than to thriller

PROSE IMPERATIVES
- ARCHITECTURAL PROSE: sentences that build like the house itself
  - Layer details: each clause adds another element of setting, mood, or dread
  - The paragraph is a room: the reader enters, experiences, and exits changed
  - Rhythm matters: the prose should pulse like a heartbeat. slow when calm, racing when afraid
- THE BEAUTIFUL TERRIBLE: describe horror with the attention you'd give beauty
  - Blood on marble: note the colour contrast, the pattern of the spreading stain
  - Decay: the specific colours of mould, the texture of rotting fabric, the smell that is sweet and wrong
  - Transformation: the fascination of watching something familiar become something alien
- BODY WRITING: the protagonist's body is a seismograph for horror
  - The skin tightens before the eyes see
  - The stomach knows before the mind admits
  - Temperature: gothic horror runs cold. Pick one specific cold detail per scene and let it do the work
- DARKNESS AND LIGHT: gothic horror prose tracks illumination obsessively
  - A single candle in a vast room creates more atmosphere than total darkness
  - Moonlight transforms: silver, strange, making the familiar alien
  - What's at the edge of the light. just visible, not quite identifiable

PROSE RHYTHM MAPPING
- CH 1 HOOK: Gothic atmospheric layering with horror-sharp interruptions. The opening paragraph
  breathes slowly. long, lush, architectural. then something CUTS through. Short. Wrong. Gone.
- DUAL RHYTHM: The HOUSE breathes in long sentences (25-35 words, embedded clauses, layered
  sensory detail, the prose winding like corridors). The THREAT strikes in short ones (5-10 words,
  blunt, no ornament, no beauty). The shift between these two rhythms IS the scare.
- THE GOTHIC LAYER: When the house dominates, prose is architectural. subordinate clauses nest,
  details accumulate, the reader sinks into atmosphere. Sentences mirror the setting: ornate,
  decaying, beautiful in their complexity.
- THE HORROR LAYER: When the threat manifests, prose shatters. Fragments. Short declarations.
  The body reacts. No time for beauty. The gothic sentence collapses under the weight of fear.
- TENSION FLOOR: Never below 7. The gothic atmosphere itself is threatening. beauty that suffocates,
  elegance that traps. Even the most lyrical passage should make the reader uneasy.
- RHYTHM SHIFT = ESCALATION: The shift from gothic to horror prose rhythm IS the escalation.
  Early chapters: 80% gothic, 20% horror interruptions. Midpoint: 50/50. Climax: horror rhythm
  dominates, gothic beauty surviving only in fragments. a single beautiful image amid the terror.
- SENSORY ARCHITECTURE: Gothic senses (damp stone, candlelight, old perfume, silk and dust)
  interrupted by horror senses (cold that shouldn't exist, the smell of something wrong,
  a sound from behind the wainscoting). Layer both. the beautiful and the terrible. simultaneously.
- PARAGRAPH STRUCTURE: Long gothic paragraphs build the house's presence. Then a short paragraph
 . one line, stark. delivers the horror beat. The white space between them is the held breath.
- THE COLLISION: The most powerful moments occur when both rhythms occupy the same sentence:
  a long, beautiful clause that ends with a short, brutal subordinate. The gothic contains the horror.

HORROR DESCRIPTION
- Gothic horror describes the terrible with literary precision:
  WRONG: "A horrible creature crawled out of the darkness. It was terrifying and disgusting."
  RIGHT: "It came from the space behind the wainscoting. first one hand, the fingers too long by one joint, and then the other. The nails had been beautiful once. They were still lacquered red. The face that followed was the worst part, because she knew it. She had seen it in the portrait above the stairs."
- The familiar made wrong is the gothic horror signature
- Specificity over adjectives: one precise detail is worth ten vague descriptions
- Use beauty to describe horror: "elegant" decay, "graceful" distortion, "exquisite" pain

DIALOGUE CRAFT
- Less dialogue than most genres: gothic horror leans into narration and description
- When characters speak, their words carry weight: nothing casual, nothing throwaway
- The villain's voice: cultured, reasonable, magnetic. the most terrifying voice in the room is the most articulate
- Confession scenes: gothic horror builds to moments of terrible revelation, told in the voice of the one who was there
- The protagonist's interior voice: increasingly fragmented, questioning perception, bargaining with reality
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

GOTHIC HORROR CRAFT (40% of total):
- Setting functions as antagonist (alive, aware, hostile)? (0-100)
- Beauty and horror are inseparable (aestheticised terror)? (0-100)
- The past actively threatens the present (ancestral horror)? (0-100)
- Body horror is present and emotionally resonant? (0-100)

STORY CRAFT (30% of total):
- Dread builds progressively (each chapter more oppressive)? (0-100)
- The protagonist's transformation mirrors the setting's? (0-100)
- The horror has a tragic dimension (the monster was human)? (0-100)
- The resolution is cathartic AND unsettling? (0-100)

PROSE QUALITY (30% of total):
- Prose is literary and atmospheric (weight, rhythm, beauty)? (0-100)
- Horror is described with precision and beauty? (0-100)
- Light, temperature, and sensory detail are tracked obsessively? (0-100)
- The voice sustains elevated register without becoming purple? (0-100)

AUTOMATIC FAILS (score = 0):
- Setting is purely decorative (backdrop without agency)
- Horror without beauty (gruesome without aesthetic purpose)
- Modern, casual voice that breaks the gothic register
- Jump scares without dread architecture
- The monstrous without the tragic (evil without depth)
- Body horror played for disgust alone (no emotional resonance)
```

## Continuity Rules

```
GOTHIC HORROR CONTINUITY. WHAT TO TRACK

THE SETTING:
- The house's behaviour: what it reveals, what it conceals, what has changed
- Room access: which spaces the protagonist has entered and what they found
- Architecture: any inconsistencies that might be supernatural (rooms that shouldn't exist, distances that change)
- Environmental state: decay progression, weather, light conditions, temperature
- Objects: portraits, mirrors, books, locked boxes. what they've revealed and what they conceal

THE HORROR:
- Manifestation history: every appearance of the horrific, in order, with escalation tracked
- Rules: what triggers the horror, what calms it, what makes it worse
- The monster's nature: what's been revealed about its origin, motivation, and vulnerabilities
- Physical evidence: scratches, stains, cold spots, sounds. what remains after the horror retreats

THE BODY:
- Physical transformation: if the protagonist or others are changing, track the stages
- Injuries and their healing (or worsening)
- Sensory changes: can the protagonist see, hear, or feel things they couldn't before?
- Physical deterioration: weight loss, pallor, exhaustion, the body reflecting the horror's toll

THE ANCESTRY:
- Family tree: who came before and what happened to them
- The curse/inheritance: its history, its rules, its stages
- Documents discovered: diaries, letters, wills, birth/death records. in order of discovery
- Portraits and photographs: what they show and what the protagonist notices in them

PSYCHOLOGICAL STATE:
- Sanity progression: the protagonist's grip on reality should be tracked
- Dreams and hallucinations: are they real, symbolic, or prophetic?
- Obsession level: the protagonist's fixation on the mystery/horror
- Relationship with the house: attraction, repulsion, recognition, surrender
```

## Character Rules

```
GOTHIC HORROR CHARACTER TYPES

THE PROTAGONIST (THE INHERITOR):
- Connected to the horror by blood, marriage, or fate. NOT a random victim
- They have arrived at the setting for a reason: inheritance, research, duty, or drawn by something they don't understand
- As they discover the horror's history, they discover their own: the personal revelation parallels the gothic revelation
- Their body responds to the setting: they feel at home AND repulsed; the attraction is part of the horror
- They may be transforming: becoming something like the horror, inheriting the curse, being absorbed by the house

THE MONSTER (THE ANCESTOR):
- Was human once: their tragedy IS the horror's origin
- Beautiful, magnetic, terrible. gothic horror monsters are not merely repulsive
- They have a logic: hunger, loneliness, obsession, love twisted into possession
- They may love the protagonist: and that love is the most dangerous thing about them
- They are a mirror: the protagonist sees what they might become

THE KEEPER (THE SERVANT):
- Loyal to the house, not necessarily to its inhabitants
- Knows the truth (or part of it) and guards it out of duty, fear, or devotion
- May be an ally or an obstacle. their loyalty is to the secret, not the protagonist
- Often the bridge between the mundane and the monstrous

THE OUTSIDER (THE RATIONALIST):
- A friend, doctor, or investigator who represents the normal world
- Their rational framework fails against the gothic horror's reality
- They provide the counterpoint: science, reason, scepticism. all inadequate
- They may be the one who doesn't survive (reason is no defence against the irrational)

THE DOUBLE:
- A character who mirrors the protagonist: the first wife, the twin, the portrait subject
- Their fate is a prophecy or a warning
- The protagonist's relationship with their double drives the psychological dimension
- They may be real, spectral, or imagined. the ambiguity is the point

VOICE DIFFERENTIATION:
- The protagonist: increasingly unmoored, oscillating between precision and hysteria
- The monster: cultured, intimate, seductive. the most beautiful voice in the book
- The keeper: terse, evasive, speaking in warnings disguised as small talk
- The outsider: confident, rational, and increasingly inadequate
- The house itself: described as if it speaks. Pick ONE sound per scene. the groan of timber OR wind through gaps. The house doesn't narrate; it interrupts
```

## Arc Rules

```
GOTHIC HORROR STORY STRUCTURE

ACT 1: THE APPROACH (first 25%)
- The protagonist arrives: the journey to the setting is the first act of atmosphere-building
- First impression: the setting is overwhelming. beautiful, vast, OLD
- Welcome and warning: the host or keeper receives the protagonist; something is said that only makes sense later
- The first night: the house at night is a different creature; the protagonist's first encounter with the uncanny
- The hook: a discovery or experience that makes leaving impossible (fascination, duty, personal connection)
- END OF ACT 1: The protagonist commits to staying and investigating

ACT 2A: THE REVELATION (to midpoint)
- The history unfolds: through documents, conversations, exploration, and the house's own disclosures
- The horror escalates: from atmospheric unease to unmistakable manifestation
- The body responds: the protagonist's physical condition changes (cold, insomnia, pallor, sensitivity)
- The double appears: the protagonist encounters their mirror (portrait, diary, ghost, memory)
- The beauty deepens: even as the horror grows, the setting becomes MORE beautiful (the sublime)
- MIDPOINT: The protagonist discovers the monster. and the monster is not what they expected (tragic, beautiful, familiar)

ACT 2B: THE DESCENT (midpoint to dark moment)
- The protagonist is drawn deeper: into the house, into the family history, into the horror
- Transformation begins: the protagonist starts to change (physically, psychologically, or both)
- The monster's seduction: offering knowledge, power, love, belonging. at a terrible price
- The keeper's warning: the truth about what happened to the last person in the protagonist's position
- The house closes in: physically and metaphorically, escape routes narrow
- DARK MOMENT: The protagonist faces their own reflection in the horror. they recognise themselves in the monster, the curse, or the family legacy

ACT 3: THE RECKONING (final 25%)
- The protagonist must choose: submit to the horror (become part of the house) or fight it (and destroy something beautiful in the process)
- The confrontation: takes place in the deepest, most forbidden part of the setting
- The monster's tragedy is fully revealed: what made them, what sustains them, what they've lost
- The climax is destruction AND creation: something terrible ends, something new begins
- The aftermath: fire, flood, collapse, dawn. gothic horror endings are elemental
- The survivor carries the mark: the protagonist escapes, but they are CHANGED (the horror is now inside them)

GOTHIC HORROR PACING:
- OPPRESSIVE: the prose never fully relaxes; even quiet scenes have undertow
- The first half is DREAD (anticipation); the second half is TERROR (revelation and confrontation)
- Accelerating reveals: Act 1 has one discovery per chapter; Act 3 has several
- The climax should feel like the house EXHALING: everything held back is released at once
```

## Timeline Rules

```
GOTHIC HORROR TIMELINE

THE PRESENT:
- Duration: days to weeks in the setting (long enough for the house to work on the protagonist)
- Track the protagonist's physical deterioration: day by day, the setting takes its toll
- Night is the active period: track what happens after dark with precision
- Weather: storms build to the climax; the weather is the house's mood

THE PAST:
- Multiple layers: the horror may go back generations
- Track each era: when the house was built, when the curse began, when each predecessor fell
- Discovery order: the protagonist learns the past in a specific sequence. track what they know WHEN
- The past bleeds into the present: moments where the timeline seems to collapse

THE BODY CLOCK:
- Transformation: if the protagonist is changing, track the stages with timestamps
- Sleep deprivation: gothic horror protagonists rarely sleep well; track the accumulating deficit
- Appetite: often lost; track eating habits as a barometer of psychological state
- Sensory changes: heightened perception, visions, hearing things. are these real or exhaustion?
```

## Genre-Specific Craft Techniques

Gothic horror is a genre with an unusually demanding
craft contract: prose that is literary and deliberate,
atmosphere that is constant and oppressive, monsters
that are tragic rather than merely monstrous, settings
that function as antagonists rather than backdrops, and
endings where the survivor carries the mark of what she
has survived. The canonical comp roster — Bram Stoker
(Dracula), Mary Shelley (Frankenstein), Edgar Allan Poe,
Charlotte Brontë (Jane Eyre, Villette), Daphne du
Maurier (Rebecca, My Cousin Rachel, Jamaica Inn),
Shirley Jackson (The Haunting of Hill House, We Have
Always Lived in the Castle), Anne Rice (Interview with
the Vampire), Ann Radcliffe, Henry James (The Turn of
the Screw), Sheridan Le Fanu (Carmilla), Sarah Waters
(The Little Stranger, Affinity, Fingersmith) —
established the form; the contemporary masterclass
roster — Silvia Moreno-Garcia (Mexican Gothic, The
Beautiful Ones, The Daughter of Doctor Moreau), Carmen
Maria Machado (In the Dream House, Her Body and Other
Parties), Catriona Ward (The Last House on Needless
Street, Sundial), T. Kingfisher (What Moves the Dead,
The Hollow Places), Andrew Michael Hurley (The Loney,
Devil's Day, Starve Acre), Jennifer McMahon (The
Winter People, The Drowning Kind), Mariana Enríquez
(Things We Lost in the Fire, Our Share of Night),
Helen Oyeyemi (White Is for Witching, Mr Fox), Stephen
Graham Jones (My Heart Is a Chainsaw, The Only Good
Indians), Cassandra Khaw (Nothing But Blackened Teeth,
The Salt Grows Heavy), Premee Mohamed, Alma Katsu (The
Hunger, The Fervor), Eric LaRocca, Camilla Bruce,
Gwendolyn Kiste, Lisa Tuttle, Kelly Link — has expanded
the genre's range into queer gothic, post-colonial
gothic, working-class gothic, climate gothic, and
diaspora gothic registers, each with the foundational
architectural commitments preserved. The most common
failure modes in this register are: **Gothic-as-
Aesthetic-Only** (the trappings — candles, decaying
mansions, period dress — without the genre's emotional
or political substance; the surface deployed as costume,
the substance abandoned); **Haunted-House-Without-
Character-Stake** (the house full of horror but the
protagonist with no skin in the game; the tourist-
protagonist who could leave but won't, with no weight
to her staying — gothic horror requires the protagonist
to be implicated, not visiting); **Atmosphere-Without-
Dread** (long lush passages of beautiful decay that
fail to actually frighten; description mistaken for
dread; the prose accumulates atmosphere but never
clenches); **Period-Cosplay** (Victorian / Edwardian /
interbellum dress and language deployed as decoration
rather than as period-specific lived constraint with
its specific gendered, classed, racial, and economic
weight on the protagonist's choices); **Female-Victim
Flattening** (the genre's foundational gendered
architecture — the woman trapped in the male house —
collapsed into passive-victim trope rather than
rendered with the ambivalence, complicity, and active
agency the canonical works gave their heroines);
**Body-Horror-as-Disgust-Only** (visceral imagery
deployed for shock without emotional resonance, without
thematic connection, without making the horror MATTER
beyond its rendering); **Monster-Without-Tragedy** (the
creature that is merely monstrous; the genre's contract
is that the monster was human and remains tragic, that
the horror has comprehensible origin in love, hunger,
loneliness, obsession, betrayal, or mistreatment);
**Modern-Voice Slip** (contemporary register breaking
through the gothic prose — anachronistic phrasing,
casual contractions, internet-era idiom — that breaks
the spell the prose has been building); and
**Resolution-Without-Mark** (the protagonist who
survives the horror unchanged; gothic horror's contract
is that the survivor carries the mark, that the horror
has entered her, that she leaves the house already
becoming something the house was making her). The
techniques below — three preserved (Beautiful Monster,
Architecture of Dread, Transformation Log) and three
added (Tragic-Monster Architecture, Period-Specific
Constraint Discipline, Survivor's-Mark Architecture) —
are designed to keep the genre's defining commitments
live: aestheticised terror over mere disgust, tragic
monsters over cardboard ones, period as constraint
over period as costume, and survival as transformation
rather than as escape.

### The Beautiful Monster

Gothic horror's signature is the monster who is also beautiful:

```
He stood in the doorway, and she understood at last
why every portrait in the east wing showed the same face.
It had not changed in two hundred years. The jawline, the
dark eyes, the mouth that suggested both cruelty and sorrow.
He was the most beautiful thing in the house, and the house
was full of beautiful things. When he spoke, his voice
was the voice she had heard through the walls at night.
low, musical, and utterly wrong coming from a throat
that should have been dust a century ago.
```

The horror is not that the monster is ugly. The horror is that the monster is PERFECT.

### The Architecture of Dread

Build dread through accumulated detail, not sudden shock:

1. **The wrong temperature**. a room that's cold when it shouldn't be
2. **The wrong smell**. flowers that are out of season, perfume from an empty room
3. **The wrong sound**. footsteps above when the floor above is empty
4. **The wrong object**. something that has moved, appeared, or changed
5. **The wrong reflection**. what the mirror shows that isn't quite right

Layer these across chapters. By the time the horror fully manifests, the reader is already terrified.

### The Transformation Log

Track the protagonist's change across the manuscript:

```
Chapter 1-3: Normal. The protagonist is who they've always been.
Chapter 4-6: Sensitivity. They notice more, feel more, dream more.
Chapter 7-9: Sympathy. They begin to understand the monster. This is dangerous.
Chapter 10-12: Identification. They see themselves in the horror.
Chapter 13-15: Decision. They choose: resist or embrace.
```

### Gothic Horror AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the ancient manor held terrible secrets" | Show ONE specific architectural detail that hints at history |
| "shadows danced in the candlelight" | Show the specific shadow and what casts it |
| "the wind howled through the corridors" | Show the specific corridor and what the wind disturbs |
| "a sense of dread permeated the atmosphere" | Show the specific detail that creates dread |
| "madness lurked behind civilised facades" | Show the specific crack in the facade |
| "the curse had plagued the family for generations" | Show the specific manifestation in this generation |
| "beauty and horror intertwined" | Show the specific beautiful-horrible thing |
| "the house would not release its secrets easily" | Show the specific resistance. a locked door, hidden room, destroyed document |
| "decay and elegance in equal measure" | Show ONE room with both |
| "the dead did not rest easy here" | Show the specific evidence |
| "ancestral guilt" | Show the specific guilty act and its specific present-day consequence |
| "the dead were restless tonight" | Cut Halloween cliché; show the specific evidence in the room |
| "the night air was thick with foreboding" | Show the specific atmospheric detail (the still candle-flame, the smell, the sound that should be there and isn't) |
| "the doors creaked ominously" | Show the specific door, the specific creak, and what the protagonist's body does in response |
| "she could feel something watching her" | Show the specific physical signal her body is responding to — the prickle, the temperature drop, the specific direction her gaze is drawn |
| "the past refused to stay buried" | Cut metaphor; show one specific past artefact intruding on the present scene |
| "evil pulsed beneath the floorboards" | Show ONE specific physical/sensory cue from below — the sound, the smell, the temperature differential |
| "the moonlight cast skeletal shadows" | Cut "skeletal"; show what specifically the moonlight touches and what it makes look wrong |

### The Tragic-Monster Architecture

The genre's signature monster is not the cardboard
villain but the figure whose monstrousness is rooted in
specific tragedy. The vampire who chose immortality and
now mourns the centuries; the wife in the attic whose
imprisonment was the institutional answer to inconvenient
womanhood; the doctor whose creation was made and then
abandoned; the ghost who cannot leave because she was
not allowed to in life. The Tragic-Monster Architecture
is the requirement that the monster's horror be
comprehensible without being excused, that the reader
understand how the human became the monster while still
fearing what the monster has become.

```
PRINCIPLE
Every gothic-horror antagonist must be rendered through
at least four of the following five elements:
1. THE HUMAN ORIGIN — the monster was human once; the
   manuscript renders the specific person they were
   (named, located, dated, with the specific
   circumstances of their life)
2. THE PRECIPITATING TRAGEDY — the specific event,
   choice, betrayal, mistreatment, or transformation
   that turned the human into the monster (rendered
   with full sympathetic comprehension)
3. THE PRESENT-DAY HORROR — what the monster IS now,
   rendered with gothic precision; what they do, what
   they hunt, what they take, what they cost
4. THE COMPREHENSIBLE LOGIC — why the monster makes
   the choices they do now; the internal coherence of
   their monstrousness (love twisted into possession,
   hunger that exceeds capacity to feed, loneliness
   that demands company at any price)
5. THE DOUBLE FOR THE PROTAGONIST — the monster
   mirrors the protagonist in some specific way; what
   the protagonist might become, what the protagonist
   already partly is, what choice the protagonist is
   making by refusing what the monster represents

CALIBRATION TEST
- Could the reader, by the end of the manuscript, name
  the specific person the monster used to be and the
  specific tragedy that made them?
- Does the manuscript render the monster with the
  same craft attention given to the protagonist —
  full interiority, comprehensible motivation, tragic
  weight?
- Does the protagonist's encounter with the monster
  function as encounter with a possible self, not
  just as confrontation with an external threat?
- Does the manuscript refuse the easy distinction
  between victim and monster (the canonical works
  insist the line is permeable)?
If any answer is no — rebuild for tragic specificity.

ANTI-PATTERN
- The monster who is always-already monstrous,
  without origin
- The monster whose backstory is "evil" in the
  abstract
- The monster the manuscript treats with contempt
  rather than with the gothic's signature compound
  of horror and pity
- The monster the protagonist would never become,
  in any scenario; gothic horror's contract is that
  the protagonist could
- The monster whose horror is unconnected to the
  protagonist's specific situation
```

### The Period-Specific Constraint Discipline

Gothic horror is a period-haunted genre. Even the
contemporary works inherit the architectural memory of
Victorian, Edwardian, and pre-suffragette American
Southern Gothic configurations of property, marriage,
medicine, and law that constrained the protagonist's
choices in ways the modern reader must feel as material
weight. The Period-Specific Constraint Discipline is
the requirement that period (where used) be rendered
not as decorative costume but as concrete legal,
economic, social, gendered, and racial constraint on
the protagonist's available options.

```
PRINCIPLE
For period-set gothic horror, the manuscript must render
at least four of the following six period-constraint
axes:
1. PROPERTY / INHERITANCE — what the protagonist can
   own (or cannot own); whether her marriage has
   transferred her property to her husband; whether
   her father's death has left her dependent on a
   male relative; the specific legal constraint on
   her economic agency
2. MARRIAGE / EXIT — whether she can leave; the legal
   and social cost of separation, divorce, or
   refusal; the specific constraint that makes the
   marriage trap feel material rather than
   metaphorical
3. MEDICINE / DIAGNOSIS — whether she can be
   committed (asylums, "hysteria", "rest cures"); the
   specific medical authority that her husband or
   father can deploy against her; the period-
   specific medical framework that pathologises her
   resistance
4. SCIENTIFIC / INTELLECTUAL TRANSGRESSION — what she
   is forbidden to study, write, learn, publish;
   the specific constraint on her intellectual life
   that makes pursuit dangerous
5. RACIAL / COLONIAL CONSTRAINT — for non-white
   protagonists, or for white protagonists in
   colonial contexts, the specific legal-social
   constraint flowing from racial / colonial
   architecture (slavery, indenture, segregation,
   colonial law, anti-miscegenation, the specific
   period configuration)
6. CLASS — the specific class constraint that
   determines what work she can do, what marriage
   she can make, what neighbourhood she can occupy

CALIBRATION TEST
- Could the protagonist's situation simply transplant
  to 2026 with no change to the plot? If yes, the
  period is decorative rather than constitutive.
- Does the period appear as material constraint on
  her specific choices, or only as costume on her
  body and dialogue?
- Are the legal, economic, medical, and social
  frameworks of the period rendered with research-
  specific accuracy rather than as generic "back
  then" gestures?
- Does the gothic horror partly arise FROM the
  period configuration (the wife in the attic is
  the institutional answer to inconvenient
  womanhood; the gothic horror IS the period
  rendered terrifying)?
If any answer is no — rebuild for period-specific
constraint.

ANTI-PATTERN
- The Victorian heroine whose only period markers
  are her dress and her dialogue
- The 19th-century American South rendered without
  the specific institutional architecture of slavery
  or Jim Crow
- The interbellum European setting rendered without
  the specific constraints of class, religion, or
  colonial status
- The period as wallpaper, with the protagonist's
  agency configured as if she were a 2026 character
  in costume
```

### The Survivor's-Mark Architecture

Gothic horror endings are not escapes. The genre's
contract is that the survivor carries the mark — the
horror has entered her, the house has changed her, she
leaves but she leaves transformed. The Survivor's-Mark
Architecture is the requirement that the manuscript's
ending render specifically what the protagonist has
become, what the horror has put into her, and what
the cost of survival has been.

```
PRINCIPLE
The survivor's mark must be rendered through at least
three of the following five elements:
1. PHYSICAL MARK — a specific bodily change carried
   forward (the white streak in the hair, the scar
   that won't heal, the gaze that is no longer the
   same gaze, the sensitivity to certain sounds or
   lights, the appetite altered, the body that
   cannot tolerate the world it returns to)
2. PSYCHOLOGICAL MARK — a specific change to the
   protagonist's interiority (the sleep that does
   not come, the dream that recurs, the
   recognition she now has of certain types of
   houses or people, the new fear, the new desire,
   the new knowledge she would rather not possess)
3. RELATIONAL MARK — what the survival has cost in
   relationships (whom she cannot speak to anymore,
   what she cannot say, the circle of those who
   share the knowledge that has now narrowed, the
   ordinary world that is no longer ordinary
   because she now sees what's behind it)
4. KNOWLEDGE MARK — what the protagonist now knows
   that she cannot unknow; the specific truth about
   the world that has been revealed and cannot be
   re-concealed; the specific competence she has
   acquired in the gothic that the mundane world
   has no place for
5. ONGOING-CURSE MARK — whether the protagonist
   herself now carries forward something of what
   she escaped — the gene, the inheritance, the
   gift, the appetite, the sympathy for the
   monster, the recognition that her escape was
   incomplete because something of the house came
   with her

CALIBRATION TEST
- Does the survivor return to ordinary life
  unchanged, or does she carry the mark forward in
  specific rendered form?
- Is the mark SPECIFIC (named, sensory, ongoing)
  rather than generic ("she would never be the
  same")?
- Does the manuscript's final image render the mark
  in a way that is both an ending and a foretelling
  (the gothic horror's signature double-time)?
- Is there at least one element of ongoing-curse
  carried by the survivor — even if she does not
  yet know she carries it?
If any answer is no — rebuild for marked survival.

ANTI-PATTERN
- The clean escape (the protagonist gets out,
  recovers, lives well, the horror ends with the
  house's destruction)
- The reset to status quo (the manuscript treats
  the events as if they never happened, the
  protagonist returns unchanged)
- The "she was never the same" gesture without
  specific rendering of how
- The destruction of the monster as full
  resolution; the gothic contract requires that
  destroying the monster does not destroy the
  mark the monster has left
- The narrator who survived telling the story with
  no evidence of the having-survived in their
  voice; the gothic narrator's prose is itself a
  mark
```

## Genre-Specific Revision Rules

### Six-Pass Gothic Horror Audit (Run FIRST in editorial pipeline)

The Gothic Horror Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Aestheticised Horror Pass

Verify horror is described with literary beauty, not
mere disgust. The Body-Horror-as-Disgust-Only failure
mode is caught here. For every horror beat, ask: is
the prose rendering the terrible with the same craft
attention it would give to beauty? Does beauty coexist
with terror in this chapter — the elegant decay, the
graceful distortion, the exquisite wrongness, the
perfect monster? Is the setting described with the
attention given to a character — its body, its mood,
its history, its agency? If a chapter renders horror
through cheap visceral imagery without aesthetic
purpose, rebuild. The gothic contract is that horror
is BEAUTIFUL and beauty is HORROR-INFECTED. neither
exists alone.

#### Pass 2: Dread Architecture Pass

Verify atmospheric tension is sustained throughout the
chapter, not concentrated only in explicit horror
scenes. The genre's craft engine is dread (the
anticipation), which is 70% of the work; terror (the
event) is 30%. Audit each chapter: are the quiet scenes
still oppressive? Does the dread never fully release?
Are the Architecture-of-Dread elements present — the
wrong temperature, the wrong smell, the wrong sound,
the wrong object, the wrong reflection — accumulating
across chapters so that by the time the horror fully
manifests, the reader is already terrified? If a
chapter contains scenes where the dread releases
entirely (the protagonist relaxes, the prose relaxes,
the atmosphere evaporates), rebuild for sustained
oppression. The gothic prose is never fully at rest.

#### Pass 3: Ancestral/Historical Pass

Verify the past is present in each chapter through
discovery, echo, or influence. Gothic horror's contract
is that history doesn't just haunt, it HUNTS. Audit
each chapter: does the protagonist's understanding of
the family / ancestral / institutional history deepen?
Are documents, portraits, diaries, letters, rooms,
objects, or physical traces revealing fragments of the
past? Is the family or ancestral horror advancing
toward the protagonist (or the protagonist advancing
toward it)? If the chapter could be set with no
historical depth, no ancestral pressure, no past-
that-hunts, the gothic architecture is missing and
must be rebuilt. The genre's signature is the past as
predator.

#### Pass 4: Transformation Pass

Verify the protagonist is changing — physically,
psychologically, or both — and that the setting is
changing in concert. The Transformation Log technique
provides the framework. across the manuscript's arc,
the protagonist moves from Normal → Sensitivity →
Sympathy → Identification → Decision. Audit each
chapter for its place in this arc. Is the protagonist
becoming something the house is making her? Is the
setting itself changing (rooms shifting, distances
fluctuating, familiar spaces becoming alien)? Is the
relationship between protagonist and horror evolving
toward the genre's signature recognition — that the
protagonist sees herself in the monster, that the
horror is partly already inside her? If the
protagonist remains entirely unchanged through the
chapter, the gothic clock has stopped and must be
restarted.

#### Pass 5: Voice Pass

Verify the prose register is literary, weighted, and
atmospheric. Gothic horror demands prose that is closer
to poetry than to thriller, with attention to rhythm,
sound, and architectural weight. Audit the chapter for
voice integrity: does the prose sustain gothic dignity
without becoming purple (precision, not decoration)?
Are sensory details specific and deliberate, not
generic atmosphere words ("eerie", "ominous", "creepy",
"chilling")? Is the dual rhythm operating — the long
gothic sentence (25-35 words, layered, embedded) for
the house's breathing, the short horror sentence (5-10
words, blunt, no ornament) for the threat's strike?
The Modern-Voice Slip failure mode is caught here. is
there any moment in the chapter where contemporary
register breaks the spell (anachronistic phrasing,
casual contractions, internet-era idiom)? If yes,
rewrite for register integrity.

#### Pass 6: Tragic-Monster + Period-Constraint + Survivor's-Mark Integration

This pass is the gothic horror integration check — it
ties the new techniques together and verifies the
genre's signature commitments are honoured chapter by
chapter.

For TRAGIC-MONSTER: identify the chapter's antagonist
material (the monster, the house-as-monster, the
ancestral curse, the keeper). Has the manuscript
elsewhere rendered the monster's human origin, the
precipitating tragedy, the comprehensible logic, the
double-for-protagonist? If the monster appears as
always-already monstrous without origin or
comprehensible logic, rebuild for tragic specificity.
The genre's contract is that the monster was human and
remains tragic. cardboard monsters fail the genre.

For PERIOD-CONSTRAINT: if the manuscript is period-set,
identify the chapter's rendering of period as material
constraint. Are at least four of the six period-
constraint axes (property / marriage-exit / medicine-
diagnosis / scientific-transgression / racial-colonial
/ class) operative across the manuscript, with this
chapter contributing to at least one? If period
appears only as costume — dress, dialogue, decor,
horse-drawn carriages — without specific legal,
economic, medical, social, or institutional weight on
the protagonist's choices, rebuild. The Period-Cosplay
failure mode is caught here.

For SURVIVOR'S-MARK: even in middle chapters (before
the ending), the manuscript should be planting the
specific marks the survivor will carry forward. Audit
the chapter for the seeds of physical, psychological,
relational, knowledge, and ongoing-curse marks. By the
time the ending arrives, the manuscript should have
established what the protagonist is becoming so that
the survival, when it comes, can render the mark
specifically rather than generically. If the
protagonist's transformation is being deferred entirely
to the final chapters, redistribute. the gothic mark
is not something that lands at the end. it is
something accumulated across the whole arc.

## Names & Patterns to Avoid

### Gothic Horror Character Names. NEVER USE
- Melodramatic horror names: Count Bloodworth, Lady Morwen, Lord Darkmore
- Direct lifts from classic gothic horror: Dracula, Frankenstein, Dorian (too recognisable)
- Overly symbolic names: Decay, Raven, Nightshade, Grimshaw

### Gothic Horror Location Names. NEVER USE
- Horror-signalling names: Castle Dread, Blackmere Hall, the Bone House
- Gothic cliché: "[Dark Adjective] [Grand Building]" formula
- Names from famous gothic works: Bly, Manderley, Thornfield, Otranto (too associated)

### Use Instead
- Names with historical weight: old family names from census records
- Location names that sound REAL: named after geography, former owners, or local features
- The name should become sinister through the story, not start sinister
- Foreign names if appropriate to setting: research authentic naming conventions

## Comp Titles

Gothic-horror's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Dracula* — Bram Stoker (1897): the vampire-gothic-horror archetype.
- *Frankenstein* — Mary Shelley (1818): the genre's intellectual foundation.
- *The Picture of Dorian Gray* — Oscar Wilde (1890): aestheticised-horror lineage.
- *Carmilla* — Sheridan Le Fanu (1872): the female-vampire gothic-horror template.
- *The Haunting of Hill House* — Shirley Jackson (1959): the haunted-house gothic-horror benchmark.

### Contemporary (current best-in-class)

- *Mexican Gothic* — Silvia Moreno-Garcia (2020): post-colonial gothic-horror benchmark.
- *Plain Bad Heroines* — Emily M. Danforth (2020): queer literary gothic-horror.
- *The Last House on Needless Street* — Catriona Ward (2021): contemporary literary gothic-horror.
- *What Moves the Dead* — T. Kingfisher (2022): Poe-Usher-retelling gothic-horror.
- *The Hacienda* — Isabel Cañas (2022): post-colonial Mexican gothic-horror.
- *Sundial* — Catriona Ward (2022): contemporary gothic-horror with desert-Southwest setting.
- *The Hollow Places* — T. Kingfisher (2020): contemporary cosmic-gothic-horror.
- *Within These Walls of Sorrow* — Sarah Beth Durst / similar 2023 gothic-horror: modern haunted-house gothic.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Grand, dark, atmospheric: a crumbling estate against a stormy sky, a figure approaching through fog, moonlight through broken windows; dramatic and sweeping
- **Textural**. Close-up, tactile, unsettling: cracked paint, rotting fabric, tarnished metal, something organic growing where it shouldn't; the viewer wants to touch it and recoils
- **Silhouette**. Bold, stark, elegant: the outline of the house/castle/figure against a dramatic sky or a pool of blood-red; minimal but powerful
- **Illustrated**. Dark, romantic illustration: detailed, painterly, suggesting narrative; the cover is a scene from the story, not just an atmosphere

### Genre Cover Aesthetics
- **Styles:** Decaying grand architecture in dramatic light, monstrous beauty (a face both gorgeous and wrong), interior spaces with single light sources, figures in period dress against architectural scale, natural elements reclaiming built spaces (ivy on stone, trees through roofs), moonlit landscapes with a single threatening element
- **Colours:** Deep, rich darks: crimson, midnight blue, forest black-green, aubergine purple; metallic accents (tarnished gold, aged silver, corroded copper); moonlight whites and silvers; candle-flame amber; the palette should feel EXPENSIVE: dark jewel tones, not muddy
- **Elements:** Architectural grandeur in decay, natural reclamation (ivy, moss, roots), moonlight and shadow, blood (as colour element, not splatter), mirrors and reflections, transformation imagery (wings, teeth, claws. suggested, not explicit), candles and fire, ornate frames and borders, the single window
- **Typography:** Elegant, dramatic serif faces; gold or silver foil/emboss; title should feel CARVED or ENGRAVED; larger type than most genres. the title is a statement; gothic horror covers are often type-forward with the image secondary

### Market Positioning
Gothic horror covers must signal "beautiful, dark, literary, and terrifying." The genre sits at the intersection of literary fiction, gothic romance, and horror. covers should reflect all three. Position against Jackson, Rice, del Toro, Khaw, Mandelo. Rich, dark colour palettes and architectural imagery distinguish gothic horror from standard horror (darker) and gothic romance (softer). At thumbnail size, the jewel-tone darkness and grand scale create immediate recognition.

### Cover Design DON'Ts
- No cheap horror imagery (dripping blood fonts, screaming faces, obvious gore)
- No bright or cheerful colours (gothic horror is DARK and RICH)
- No generic "haunted house" clip art
- No modern settings or contemporary dress (even modern gothic horror should feel timeless on the cover)
- No overcrowded compositions. gothic horror covers need space for atmosphere
- No comedy or camp (gothic horror takes itself seriously on the cover)
