---
name: contemporary-fiction-genre
description: Genre-specific instructions for contemporary fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Contemporary Fiction. Genre Plugin

## Metadata
- id: contemporary
- name: Contemporary Fiction
- icon: 🏙️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Seven-Point Story Structure", "Dan Harmon Story Circle"]

## Subgenre Options
Present during setup:
- **Domestic Contemporary**. The home as the stage: marriages, families, households. the drama of the people you live with and what happens when the door is closed
- **Social Contemporary**. The wider world matters: community, workplace, neighbourhood, culture. the individual in their social context
- **Relationship Contemporary**. Friendships, love affairs, parent-child bonds. a single relationship explored in depth
- **Issue-Driven Contemporary**. A contemporary issue (addiction, immigration, technology, climate) explored through character, not polemic
- **Comic Contemporary**. The absurdity of modern life rendered with wit: satirical edge, warm heart, sharp observation
- **Dual-Timeline Contemporary**. Past and present in conversation: a contemporary protagonist dealing with the echoes of a past event, era, or person

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: The rhythm of contemporary life. scenes move between intimate moments and external pressures; the balance between inner life and outer demands
- Must open with: A character in their NOW. contemporary fiction is grounded in the present moment, the current world, the texture of modern life

BEATS PER CHAPTER
1. Present-Moment Beat. The character is HERE, now, in the specific reality of their life: their commute, their phone, their kitchen, their world
2. Pressure Beat. Something bears down: a deadline, a conflict, an expectation, a text message that changes the day
3. Relationship Beat. An interaction that reveals, tests, or changes a relationship
4. Reflection Beat. The character processes: what does this mean, what do I want, who am I becoming?
5. Choice Beat. A decision is made (or avoided) that moves the story forward

CONTEMPORARY FICTION ARCHITECTURE
- The PRESENT is vivid: contemporary fiction is set NOW, and the specifics of now matter (technology, culture, politics, language)
- REALISM is the foundation: the world operates by the rules readers recognise from their own lives
- RELATIONSHIPS are the plot: the central drama is between people, not between people and external forces
- The ORDINARY is the material: contemporary fiction finds the drama in everyday life. it doesn't need a murder or a quest
- SOCIAL CONTEXT matters: characters exist in communities, workplaces, neighbourhoods, and online spaces
- The INTERNAL and EXTERNAL are in tension: what the character shows the world vs. what they feel inside
- POV: First person (intimate, confessional, voice-driven) or close third (slightly more distance, more room for irony)

THE CONTEMPORARY WORLD
- Technology is present: phones, social media, email, GPS, streaming. characters live in the same technological reality as readers
- Don't fetishise or demonise technology. it's just THERE, the way it is in actual life
- Cultural references anchor the time: music, TV shows, news events, fashion. used sparingly for texture, not as shortcuts
- The economy is felt: housing costs, healthcare, job insecurity, student debt. these are not background, they're story
- Social dynamics: class, race, gender, sexuality. rendered through character experience, not authorial commentary

FORBIDDEN IN CONTEMPORARY FICTION
- The Luddite protagonist: a character in a contemporary novel who inexplicably doesn't use a phone or the internet
- Nostalgia as plot: "things were better before" is not a story
- Unlikeable characters with no compensating interest (compelling ≠ likeable, but the reader needs SOMETHING)
- Social issues as the story rather than the SETTING for a story (characters first, issues second)
- Dialogue that sounds like a podcast discussion about social issues
- A perfectly curated, Instagram-aesthetic life presented without irony
- Ignoring the specific reality of the contemporary world (generic settings, undated atmosphere)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (primary), Captivation, Revelation through character realisation.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the contemporary cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  contemporary cues below apply directly.VOICE & TONE
- POV: First person (dominant. the confessional contemporary voice) or close third
- Voice: Contemporary, natural, specific. should sound like a real person you'd want to have a long conversation with
- Tone: Ranges from warmly comic to quietly devastating; the best contemporary fiction does both
- Register: Matches the character: a 25-year-old sounds different from a 55-year-old; a teacher sounds different from a tech worker

PROSE IMPERATIVES
- CONTEMPORARY SPECIFICITY: the world is THIS world, right now
  - Brand names: not gratuitous, but present. people drink oat milk lattes, not just "coffee"
  - Technology: integrated naturally, the way it is in life (checking phones, sending texts, scrolling)
  - Cultural texture: what's on TV, what's in the news, what's trending. used as seasoning, not the meal
- CONVERSATIONAL AUTHORITY: the prose should feel like someone TALKING to you
  - Direct address can work: "You know the feeling" or the implied reader
  - Digression as technique: the way real people tell stories, circling back, adding context
  - But CONTROLLED: the digressions are deliberate, not indulgent
- THE TEXTURE OF DAYS: contemporary fiction renders the actual experience of being alive now
  - The 6 AM alarm, the commute, the workplace small talk, the scroll through social media at 11 PM
  - These mundane details are not filler. they are the MATERIAL
  - The skill is finding the extraordinary within the ordinary
- EMOTIONAL PRECISION: name the feeling EXACTLY
  - Not "sad" but the specific shade: disappointed, bereft, melancholy, hollow, wistful, gutted
  - The feeling should be rendered through behaviour and physicality, not just named
  - Complex emotions: the simultaneous relief and guilt of avoiding someone

PROSE RHYTHM MAPPING
- Ch 1 hook: Relatable voice + immediate stakes (personal, not global)
- Prose rhythm: Clean, accessible, modern. no flourishes for their own sake
- Sentence length: 12-20 words average
  - The prose should feel like a smart friend telling you what happened
  - Conversational without being sloppy; controlled without being stiff
- Interiority: Moderate. 50-70 words per beat
  - Enough to know the character, not so much that pace stalls
- Dialogue: Natural and frequent. 40% by word count
  - Text messages, interruptions, subject changes all count
- Tension: ≥5 for Ch 1
- Paragraph rhythm: Medium paragraphs (3-5 sentences)
  - Breaks for dialogue-heavy passages
  - Occasional single-line paragraph for emotional punch

DIALOGUE CRAFT
- Contemporary dialogue should sound like people ACTUALLY talk
- Interruptions, incomplete sentences, subject changes, phone calls mid-conversation
- Text messages and emails as dialogue: format them as they'd actually appear
- The gap between what people say in person and what they text IS character
- Humour: contemporary fiction uses humour naturally. people are funny, even in difficult situations
- Avoid expository dialogue: real people don't explain things to each other that they both know
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

CONTEMPORARY CRAFT (40% of total):
- The world feels specifically NOW (technology, culture, social reality)? (0-100)
- The ordinary is rendered with precision and interest? (0-100)
- Relationships drive the plot (human connection is the subject)? (0-100)
- Social context is present and felt (not just background)? (0-100)

STORY CRAFT (30% of total):
- The protagonist is compelling and specific? (0-100)
- Stakes are personal and genuinely felt? (0-100)
- The narrative arc is satisfying (change, growth, or revelation)? (0-100)
- Pacing is engaging (scenes justify their length)? (0-100)

PROSE QUALITY (30% of total):
- Voice is distinctive and sustained? (0-100)
- Dialogue sounds like real contemporary speech? (0-100)
- Details are specific and purposeful? (0-100)
- Emotional precision (feelings named exactly, not approximately)? (0-100)

AUTOMATIC FAILS (score = 0):
- Generic, undated setting (could be any time in the last 30 years)
- Social issues delivered as lecture through dialogue
- Characters with no technology in a contemporary setting
- Dialogue that sounds like written prose (no one talks like that)
- Emotional vagueness (telling us a character is "upset" without specificity)
- The protagonist's life is perfect except for one neat problem
```

## Continuity Rules

```
CONTEMPORARY FICTION CONTINUITY. WHAT TO TRACK

DAILY LIFE STATE:
- Work schedule: when the character works, their colleagues, their projects
- Living situation: who they live with, rent/own, neighbourhood, commute
- Financial state: income, debts, constraints, spending habits
- Health: physical and mental, ongoing conditions, medications, exercise habits
- Routine: the daily rhythm that establishes normal before you disrupt it

RELATIONSHIP STATE:
- Every significant relationship: its current temperature, recent events, unresolved tensions
- Communication: when characters last spoke, texted, or saw each other
- Power dynamics: who's up, who's down, who owes whom
- Group dynamics: friend groups, family systems, workplace hierarchies
- What's unsaid: the things characters are avoiding discussing

TECHNOLOGY STATE:
- Characters' relationship with technology: heavy user, reluctant user, generational differences
- Communication records: texts, emails, social media posts that have been mentioned
- Online presence: what characters have posted, shared, or seen online
- Devices: what they use and how (iPhone vs. Android can be characterisation)

TEMPORAL STATE:
- Day of week and time of day: contemporary fiction is specific about when things happen
- Duration between scenes: hours, days, or weeks. keep track
- Upcoming events: appointments, deadlines, birthdays, holidays
- Seasonal markers: weather, cultural events, the rhythm of the year

EMOTIONAL STATE:
- Character's mood trajectory across chapters
- Unprocessed events: things that happened but haven't been dealt with
- Coping mechanisms: what the character does under stress (drink, exercise, call a friend, scroll)
- The gap between presented self and actual self at each point in the story
```

## Character Rules

```
CONTEMPORARY FICTION CHARACTER CONSTRUCTION

THE PROTAGONIST:
- A specific person in a specific life: age, job, living situation, cultural background, all rendered
- Their VOICE is the novel: the way they observe, describe, and interpret their world IS the experience
- They are imperfect in recognisable ways: they procrastinate, they avoid difficult conversations, they self-medicate with wine or Netflix
- They want something they're not sure they deserve (or not sure they want)
- Their relationship with technology is characterisation: the compulsive phone-checker vs. the deliberate digital minimalist
- They have an internal monologue that differs from their external presentation

SUPPORTING CHARACTERS:
- The best friend who sees through the protagonist's performance
- The family member who represents the life the protagonist is trying to escape (or return to)
- The colleague who represents an alternative path
- The romantic interest who disrupts the protagonist's equilibrium
- Each has their own life happening OFF-PAGE: they're not waiting for scenes with the protagonist

THE ANTAGONIST:
- In contemporary fiction, the antagonist is often a SITUATION rather than a person
- If a person: they're not evil, they're CONFLICTING. their needs clash with the protagonist's
- The antagonist may be the protagonist themselves: their own avoidance, fear, or self-sabotage
- Social systems as antagonist: housing markets, healthcare, workplace hierarchies

VOICE DIFFERENTIATION:
- Generation matters: a Boomer speaks differently from a Millennial from Gen Z
- Education and class affect vocabulary, reference points, and communication style
- Cultural background affects idiom, humour, and what's considered normal
- Emotional register: some characters are articulate about feelings; others express through action or avoidance
```

## Arc Rules

```
CONTEMPORARY FICTION STORY STRUCTURE

ACT 1: LIFE AS IT IS (first 25%)
- The protagonist's current life in full detail: job, home, relationships, routine
- What works and what doesn't: the existing tensions and satisfactions
- The voice establishes itself: the reader settles into the character's consciousness
- The disruption: something changes or arrives that destabilises the equilibrium
- END OF ACT 1: The protagonist must engage with the change (they can't just go back to normal)

ACT 2A: ENGAGEMENT (to midpoint)
- The protagonist grapples with the new situation
- Relationships are tested: the change affects everyone around them
- New connections form; old ones strain
- The protagonist tries their usual coping strategies (which don't work this time)
- MIDPOINT: A moment of clarity or crisis. the protagonist sees their situation for what it really is

ACT 2B: COMPLICATION (midpoint to dark moment)
- The real problem emerges: it's not the surface disruption, it's what the disruption revealed
- Relationships reach crisis points: the things that weren't said must now be said
- The protagonist's self-image is challenged: they're not who they thought they were
- External pressures compound: work, money, health, family. contemporary life piles on
- DARK MOMENT: The protagonist faces the truth they've been avoiding

ACT 3: RESOLUTION (final 25%)
- The protagonist makes a choice that reflects genuine change (not just circumstantial resolution)
- The difficult conversation happens: the one they've been avoiding for 250 pages
- Relationships resolve: not necessarily happily, but honestly
- The protagonist's life has shifted: same job or different, same relationship or not. but THEY are different
- The ending is grounded in the same specific reality as the opening, but the character's relationship to that reality has changed

CONTEMPORARY FICTION PACING:
- Scenes reflect the rhythm of contemporary life: some are short (a text exchange), some are long (a family dinner)
- Pace accelerates when decisions are being made
- Transitions can jump days or weeks without explanation (the reader lives in the same temporal reality)
- The climax of a contemporary novel is often a CONVERSATION, not an event
```

## Timeline Rules

```
CONTEMPORARY FICTION TIMELINE

CALENDAR-GROUNDED:
- Track the day of the week and month: contemporary fiction is specific about when things happen
- Work schedules, school terms, holidays. these structure the characters' lives
- Seasons affect mood, activity, and social patterns

COMMUNICATION TIMELINE:
- When texts, emails, and calls happened: these are plot events in contemporary fiction
- Response times are characterisation: the person who texts back immediately vs. the person who waits three hours
- Social media posts have timestamps and consequences

DURATION:
- Contemporary fiction typically spans weeks to months
- The pace of modern life means things move fast: a relationship crisis can unfold over a weekend
- Track weekdays vs. weekends: different rhythms, different possibilities
```

## Genre-Specific Craft Techniques

Contemporary fiction is the register of the present-day world
rendered with novelistic attention. It sits adjacent to literary
fiction (which prioritises prose voice and structural ambition)
but with a distinct contract: the world IS the contemporary
moment, the texture IS recognisable to the reader's own life,
and the form's pleasure is the recognition of one's own time
in another mind's seeing. The cluster includes book-club
contemporary, women's fiction, upmarket contemporary, family
saga in present-day register, and the broader contemporary-
adjacent ranges. Comp authors span the literary edge (Sally
Rooney, Anne Tyler, Curtis Sittenfeld, Jonathan Franzen, Maggie
O'Farrell, Tessa Hadley) through book-club mainstream (Liane
Moriarty, Celeste Ng, Taylor Jenkins Reid, Emily Henry, Bonnie
Garmus, Gabrielle Zevin, Catherine Newman, Gail Honeyman, Nina
Stibbe) and into the contemporary-with-genre-edge work
(Brit Bennett, Yaa Gyasi on the literary side; Kiley Reid,
Naoise Dolan, Coco Mellors, Raven Leilani, Mateo Askaripour
on the social-observation register). The techniques below are
how the form delivers its core pleasures while avoiding the
failure modes (contemporary-flavoured prose without
contemporary specificity; technology gestured at rather than
inhabited; emotional shorthand that flattens experience to
labels; the mundane treated as merely mundane rather than as
the form's natural medium).

### The Technology-as-Character Technique

Technology reveals character. The genre's distinctive register
includes the small specific behaviours contemporary technology
has produced — the checking, the scrolling, the curating, the
lingering on a notification, the deliberate not-looking. Each
of these is character work; the strongest contemporary fiction
treats technology not as setting but as the medium through
which contemporary characters are revealed.

```
She checked her phone seventeen times during dinner. Not
because she expected a message. Because checking her phone
was what her hands did when her mouth couldn't say the
thing it needed to say. Her husband had stopped noticing.
That was worse than if he'd been angry about it.
```

The technique requires specificity to particular technologies,
particular platforms, particular behaviours. Generic "she
scrolled" or "he checked his phone" is the failure mode; the
particular thing the protagonist is checking, the particular
moment of friction in the interface, the particular feeling
that prompted the check, the particular meaning that emerges
from the check or non-check is the technique. The craft test:
read three technology beats in the manuscript and ask, in each,
whether the specific technology and specific behaviour reveal
something about THIS character that a different character would
not have done. If the technology beats are interchangeable
across characters, the technique is operating at decorative
level.

### The Mundane Magnification

The extraordinary in the ordinary. Contemporary fiction's
deepest emotional register is the everyday moment that, when
attended to with sufficient specificity, opens onto a larger
truth about the character's interior. The cereal aisle.
The kitchen sink. The walk back from the bus stop. The
moment after dropping the kids at school.

```
NOT CONTEMPORARY FICTION:
"She had a crisis of identity and questioned everything
about her life."

CONTEMPORARY FICTION:
"She stood in the cereal aisle for eleven minutes, holding
a box of the granola he liked, and tried to remember if
she had ever bought cereal for herself. She couldn't. She
put it back. She picked up something with chocolate in it
and felt, briefly and absurdly, free."
```

The technique requires that the mundane detail be specific
enough to be recognisable (this exact cereal aisle; the
"eleven minutes" that means real lingering; the specific
"his cereal" recognition) and emotionally weighted without
being labelled. The form's signature failure mode is
contemporary-fiction-as-list-of-domestic-detail without the
emotional through-line; the strongest contemporary fiction
makes the mundane carry weight that asserted-emotion register
could not. Test: pick three significant emotional moments in
the manuscript and ask, in each, whether the specific mundane
detail does the emotional work. If the prose reaches for
emotional vocabulary alongside the detail, the magnification
has not been trusted; if the detail alone carries the weight,
the technique is operating.

### The Dual Register

Characters present one self publicly and think another
privately. The form's distinctive interior craft: the gap
between what is said in the world and what is felt in the
self, with the prose tracking both registers and trusting the
reader to feel the friction.

```
"I'm fine," she said. "Honestly, I'm great. It was the
right decision."

She was not fine. She had eaten a family-sized lasagna
at 2 AM and cried during a car insurance commercial. But
"I'm fine" was what you said, and she'd been saying it
long enough to almost believe it on Tuesdays and Thursdays.
```

The technique requires that both registers be specific. Public
register that is generic (the protagonist who says generic
things in social settings) reads as flat; private register
that is generic (the protagonist whose interior is generic
ennui) reads as cliché. The strongest contemporary fiction
makes both registers character-particular: this exact public
performance with its exact tells, this exact private interior
with its exact specific recurrent thoughts.

The technique also extends to digital register: the public
performance of social-media presence vs the private experience
of scrolling; the curated photograph vs the day it documents;
the message that took twenty minutes to compose vs the casual
read it produces. Test: pick three significant moments where
public and private register diverge. In each, can the writer
specify what each register reveals that the other does not?
If both registers say the same thing in different words, the
technique has not been deployed.

### The Recognisable Moment

Contemporary fiction's most direct relationship to its reader
is the recognition moment — the specific scene that makes the
reader nod, laugh, wince, or stop reading because what is on
the page has named something they themselves have felt without
language. The genre's commercial life turns on this register;
book club discussion guides exist because the form generates
moments specifically designed to be recognised and discussed.

The technique requires deliberate cultivation of recognisable
moments without sliding into truism. The "I do that too"
moment — the protagonist who automatically apologises for not
working when they're on holiday; the partner who has stopped
mentioning the thing because mentioning it has become its own
problem; the parent who has internalised contradictory
parenting advice and now operates on no advice at all; the
friend group where the absence of one specific person changes
everything — these are the moments the genre's strongest
practitioners cultivate. They are character-specific
manifestations of widely-shared experience, not generic
observations about contemporary life.

The technique fails when recognition is sought generically
("everyone is so busy these days"; "kids today don't
understand"; "modern relationships are complicated"). It
succeeds when the prose finds the precise scene that would
not occur in any other era and would not occur to any other
character. Test: pick three intended recognition moments and
ask, in each, whether the moment is specifically THIS
character's manifestation of a recognisable experience, or a
generic statement about contemporary life. The first is the
technique; the second is the failure mode.

### The Time-Stamp Discipline

Contemporary fiction has an inverse-aging problem: the more
specifically contemporary the manuscript is, the faster it
dates. The novel referencing TikTok in 2024 risks reading as
a period piece by 2030; the novel that references nothing
specific risks reading as set nowhere in particular and
losing the genre's signature recognition-pleasure. The
discipline is calibration.

The strongest contemporary fiction time-stamps deliberately,
with each specific reference doing specific work. A character
checking Twitter / X in 2024 is a different character from
one checking Instagram, who is different from one checking
TikTok, who is different from one not on social media at
all — and the genre's reader registers each choice as
characterisation. Generic "she checked her phone" without
specificity is universal and ages slowly; specific platform
references age faster but do more characterisation work.

The technique calibrates by separating durable and dating
references. Durable contemporary references: the smartphone
itself; basic email; the broad shape of remote work; the
genericised platform behaviour. Dating contemporary references:
specific platforms by name; specific viral moments; specific
political figures by name; specific ongoing news events;
specific cultural-moment slang. Use durable references for
the manuscript's spine; use dating references where they do
specific character work and where the writer accepts the
trade-off (the book that perfectly captures 2024 may be a
2024 book; the book that captures contemporary life durably
may be more diffuse but ages better).

Test: count the dating references in the manuscript per
chapter. Are they doing character work, or are they
decorative? If decorative, replace with durable references;
if doing work, accept the trade-off and ship the book of its
moment. The choice must be deliberate.

### The Emotional Register Calibration

Contemporary fiction operates across an emotional spectrum
from the quiet (Anne Tyler's small-domestic register; Tessa
Hadley's understated middle-class observation) through the
warmly-comic (Nina Stibbe; Bonnie Garmus's *Lessons in
Chemistry*; Gail Honeyman's *Eleanor Oliphant*) to the
emotionally direct (Liane Moriarty's family-secret
revelations; Celeste Ng's domestic crisis; Taylor Jenkins
Reid's curated-glamour drama). The manuscript must commit to
its emotional register and hold it.

A novel that operates quietly through 250 pages and reaches
for high-melodrama emotion at the climax has broken its
calibration; a novel that operates at maximum emotional
density throughout exhausts the reader's investment.
Calibration is not just intensity — it is also tone: the
warmly-comic register is not interchangeable with the
domestically-tense register; the literary-quiet register is
not interchangeable with the upmarket-revelatory register.
Each carries its own pacing, dialogue style, prose density,
and reader-expectation contract.

Test: write a one-sentence statement of the manuscript's
emotional register. Does the statement describe a recognisable
contemporary-fiction position, or is it generic
("emotional, real, observational")? If generic, the
calibration has not been chosen. Read three chapters spaced
across the book and ask whether they operate at the chosen
register or drift between registers. Drift is the failure
mode; sustained register is the form.

### Contemporary Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "in this day and age" | Show the specific modern detail |
| "the world had changed but some things stayed the same" | Show the specific change and specific constant |
| "she scrolled through her phone, feeling disconnected" | Show the specific content on the phone and its effect |
| "modern life was exhausting" | Show the specific exhausting moment |
| "they were all just trying to figure it out" | Show ONE person's specific attempt |
| "the city hummed with energy" | Show ONE specific city sound or sight |
| "relationships were complicated" | Show the specific complication |
| "she posted a photo, curating her life" | Show the specific photo and specific gap between image and reality |
| "adulting was hard" | Show the specific adult responsibility that overwhelms |
| "the algorithm knew her better than she knew herself" | Show the specific eerily accurate recommendation |
| "it was a sign of the times" | Name the specific sign |
| "she didn't recognise herself in the mirror" | Show the specific feature she's looking at and the specific change |
| "they had drifted apart" | Show the specific moment that crystallised the drift |
| "she had it all" | Cut; show what specifically she has and what specifically she doesn't |
| "in the era of [trend]" | Cut; render the trend through specific behavioural detail in scene |
| "she texted him goodnight, like always" | Show the specific text or what's different about this one |
| "everyone seemed to be doing better than her" | Show ONE specific person doing one specific thing that triggers the comparison |
| "she'd been on autopilot for months" | Show the specific routine and the specific moment she notices it |

## Genre-Specific Revision Rules

Six revision passes specific to contemporary fiction, each with
a single question, run cover-to-cover before the next begins.
Contemporary revision must hold the form's distinct contracts:
contemporary specificity (the world IS now); relationship
engine (the form's plot pressure is interpersonal); voice
authenticity (dialogue and interiority sound like contemporary
people); mundane-to-meaningful (the everyday carrying weight);
emotional precision (specific shades, not generic labels); and
calibrated emotional register held throughout. The passes
below are ordered to surface contemporary-specificity and
relationship failures first (the most-felt by genre readers),
voice and mundane craft next, emotional precision and
register-calibration last.

### Pass 1: Contemporary Specificity Check

Verify the world is specifically NOW — that the manuscript's
contemporary positioning is doing work, not gestured at.
Could this chapter be set in 2005 without changing anything?
If yes, add contemporary texture. The genre's failure mode is
contemporary-fiction-set-in-an-unspecified-recent-past; the
distinctive register requires that the present be inhabited,
not just dated. Verify technology is present naturally — not
fetishised (chapter-long descriptions of someone's phone) and
not absent (the contemporary character who somehow doesn't
own a smartphone) but treated as the medium it actually is in
contemporary life.

Check for the silent date-erasers: the protagonist whose
work life is described in terms that could be 1995; the
relationship dynamics that don't account for digital
communication; the city setting that omits any specific
contemporary marker; the family that operates by 1990s
defaults. Each is a place where the contemporary contract has
slipped. The fix is integration — convert generic
contemporary detail into specific present-day detail that
also does character or scene work.

Test: at three points spaced across the manuscript, can the
reader name a specific contemporary detail (a platform, a
phrase, a current cultural reference, a specific
contemporary working condition, a specific contemporary
domestic configuration) that grounds the scene in NOW? If
none, the specificity has not been deployed.

### Pass 2: Relationship Engine Check

Contemporary fiction's primary plot engine is interpersonal.
Verify at least one significant relationship advances,
strains, or reveals in every chapter. The form's failure mode
is the chapter that operates as character-alone-with-thoughts
without genuine interpersonal pressure; even introspective
contemporary fiction sustains its plot through relationships
the protagonist is in, anticipating, avoiding, or grieving.

Verify interactions between characters are specific and
dynamic. Generic dialogue-as-information-delivery is the
failure mode; conversations that are themselves the form of
the relationship (the same disagreement repeating in
different words; the unsaid that both parties hear; the
shift in register that signals a new phase) are the
technique. Verify the unsaid matters as much as the said —
contemporary fiction's distinctive dialogue craft is the gap
between what people say and what they mean, with the prose
trusting the reader to feel both registers.

Test: read three significant interpersonal scenes asking, in
each, what changes in the relationship between scene-start
and scene-end. If the relationship is the same after as
before, the scene has not done relationship work. The
strongest contemporary fiction makes the small interpersonal
shift the chapter's actual event.

### Pass 3: Voice Check

Read all dialogue and internal monologue aloud, with attention
to whether they sound like contemporary people speaking and
thinking. Verify the narrative voice is distinctive and
consistent. Check that dialogue sounds like actual human
speech — including the verbal tics, the trailing-off, the
thing-said-in-place-of-the-thing-meant, the half-finished
sentences, the platform-specific register (work email vs
text vs in-person vs voice note). Generic literary dialogue
that no one would actually say is the failure mode; specific
contemporary dialogue that captures how this character speaks
in this moment is the technique.

Verify the character's internal voice is distinct from their
external presentation. The dual-register technique above is
the form's signature character-craft; the revision pass
checks whether the gap is consistently maintained across the
manuscript, with the public register and private register
each particular to this character.

Test: pick three dialogue exchanges from spaced points in
the manuscript and three internal-monologue passages.
Without attribution, can the reader identify each as
belonging to this character? If not, the voice has not been
distinguished. Compare the voice to recent contemporary-
fiction comp authors the writer cites — does the manuscript
sound like contemporary fiction or like generic literary
prose with contemporary furniture?

### Pass 4: Mundane-to-Meaningful Check

Verify there is at least one mundane detail per chapter that
carries emotional weight. The Mundane Magnification
technique is the form's deepest emotional craft — the
ordinary moment attended to with specificity that opens onto
larger meaning. The revision pass checks that the technique
is operating per chapter, not concentrated in one set-piece.

Check that everyday activities are rendered with enough
specificity to interest the reader. Chapter-spanning
descriptions of household tasks done genericly are the
failure mode (the reader's eye glazes); the specific
household task done in this protagonist's specific way with
this protagonist's specific attention is the technique. The
test: would the rendered domestic / work / commute / errand
detail be recognisable to a reader in the protagonist's
demographic, AND would it surprise the reader by noticing
something they hadn't articulated about their own life?

Verify the chapter finds drama in the ordinary. Contemporary
fiction's signature pleasure is the recognition that the
small moment contains the larger life; chapters that wait
for a Big Event before doing emotional work have not yet
trusted the form. Test: in each chapter, identify the
mundane moment that carries the chapter's emotional weight.
If no such moment exists, the chapter is operating at
narrative-only level and may need revision toward the
form's distinctive register.

### Pass 5: Emotional Precision Check

Audit the manuscript for emotional vocabulary. Are emotions
named specifically — not "happy", "sad", "angry" but the
precise shade (the relief that has guilt mixed in; the
anger that is actually grief; the love that comes with
specific resentment; the homesickness for a place that no
longer exists)? Generic emotional labels are the form's
quickest decay; the strongest contemporary fiction names
emotions with specificity that the reader recognises but
hadn't articulated.

Verify feelings are shown through behaviour and physicality
rather than asserted. Contemporary fiction inherits literary
fiction's earned-emotion discipline — the reader should
arrive at the emotion through specific rendered detail, not
be told what to feel. The protagonist who "felt
overwhelmed" has been served a label; the protagonist whose
hands shook over the wrong section of the menu while the
date was happening has been rendered.

Verify the emotional complexity of situations is honoured
rather than simplified. Contemporary fiction's strongest
work refuses tidy emotional resolution: the protagonist who
wins the argument and feels worse for winning; the breakup
that produces relief but also disorientation; the
homecoming that is both wanted and impossible. The form
permits — and is deepened by — emotions that exist in
contradiction with each other; manuscripts that resolve
contradictions tidily lose the form's signature truth.

### Pass 6: Emotional Register Calibration

Identify the manuscript's emotional register from its opening
chapters and verify the register holds across the book.
Contemporary fiction operates across a wide spectrum from the
quiet (Anne Tyler / Tessa Hadley / Maggie O'Farrell quietly-
observed register) through the warmly-comic (Nina Stibbe /
Bonnie Garmus / Gail Honeyman) to the emotionally direct
(Liane Moriarty / Celeste Ng / Taylor Jenkins Reid). The
chosen register must be calibrated and sustained.

A novel that opens quietly and reaches for high-melodrama at
the climax has broken its calibration. A novel that operates
warmly-comic throughout but turns devastating at the climax
without preparation has produced unintentional whiplash. The
strongest contemporary practitioners hold their register
across 300+ pages, with deliberate variation (the comedy
that briefly aches; the quiet that briefly intensifies)
rather than register-drift.

Verify the chosen register is appropriate to the
manuscript's content. Heavy material (grief, illness,
family rupture) can be handled in the quiet register or the
warmly-comic register or the emotionally-direct register —
each works — but the register must be intentional and the
content must trust the register. Quiet-register novels of
illness can be devastating precisely because of restraint;
emotionally-direct novels of grief can be devastating
precisely because they do not look away.

Test: read three chapters spaced across the manuscript and
identify the register each operates in. If the chapters
disagree where they shouldn't, calibration has slipped. If
the manuscript deliberately employs register shifts at
specific structural points, verify each shift is earned by
the dramatic material rather than arriving as drift.

## Names & Patterns to Avoid

### Contemporary Fiction Character Names. NEVER USE
- Names that signal type: "Brayden" for a frat boy, "Willow" for a free spirit
- All-white-American names for a diverse cast
- Names that date to a different generation (unless that's the point)

### Contemporary Fiction. NEVER DO
- Begin with the character's alarm clock going off (the most overused contemporary opening)
- Describe the protagonist looking at themselves in a mirror
- Use dream sequences as lazy characterisation
- Have characters explain social media to each other

### Use Instead
- Names appropriate to the character's age, background, region, and cultural heritage
- Names their parents would actually have chosen in the year the character was born
- Research naming trends for the character's birth year and cultural context

## Comp Titles

Contemporary fiction's comp-title set supports
manuscript positioning: market category placement,
cover-design conversation, reader-expectation
calibration, similar-author discovery, and editorial
/ agent submission framing.

### Canonical (foundational reference points)

- *White Teeth* — Zadie Smith (2000): contemporary multi-cultural literary benchmark.
- *Olive Kitteridge* — Elizabeth Strout (2008): contemporary linked-stories form.
- *Anywhere But Here* — Mona Simpson (1986): contemporary mother-daughter benchmark.
- *Empire Falls* — Richard Russo (2001): small-town American contemporary.

### Contemporary (current best-in-class)

- *Normal People* — Sally Rooney (2018): millennial-contemporary literary benchmark.
- *Conversations with Friends* — Sally Rooney (2017): contemporary literary friendship-affair.
- *A Little Life* — Hanya Yanagihara (2015): contemporary literary epic.
- *Big Little Lies* — Liane Moriarty (2014): contemporary suburban ensemble.
- *Beautiful World, Where Are You* — Sally Rooney (2021): epistolary contemporary literary.
- *Tomorrow, and Tomorrow, and Tomorrow* — Gabrielle Zevin (2022): contemporary friendship-and-work.
- *Lessons in Chemistry* — Bonnie Garmus (2022): contemporary literary-commercial benchmark.
- *Maggie O'Farrell — The Marriage Portrait* (2022): historical-contemporary literary.

## Cover Design Specifications

### Recommended Visual Styles
- **Photographic**. Evocative lifestyle photography: a moment captured that suggests the story's emotional world; warm, specific, contemporary
- **Illustrated**. Modern illustration: bold, graphic, stylised; contemporary fiction covers are increasingly illustration-forward
- **Typographic**. Bold, confident typography with a single colour or image accent; clean and commercially appealing
- **Graphic**. Design-forward: colour blocks, geometric shapes, a single striking element; the cover as visual brand

### Genre Cover Aesthetics
- **Styles:** Contemporary settings (apartments, cafés, city streets, suburban homes), figures in modern dress, everyday objects rendered significant, screen-influenced design (flat colours, clean lines), photographic textures, mixed-media collage effects
- **Colours:** Bright, contemporary palettes: coral, teal, mustard, millennial pink, sage green; bold single colours with white; warm, inviting combinations; colours that photograph well for social media
- **Elements:** Modern life objects (coffee cups, keys, phones, bicycles), urban and suburban landscapes, figures in contemporary fashion, hand-lettered elements, graphic patterns, the suggestion of a moment in a specific life
- **Typography:** Bold, modern fonts (both serif and sans-serif); title is prominent and readable; playful arrangements for comic tones; elegant for serious tones; the typography should feel CURRENT

### Market Positioning
Contemporary fiction covers signal "this book is about YOUR life" through recognisable settings, modern aesthetics, and accessible design. Position against Rooney, Sittenfeld, Haywood, Center, Holmes. The cover should look good on Instagram (this is commercial reality for contemporary fiction). At thumbnail size, bold colour and clean typography create immediate commercial appeal. The tone of the cover should match the tone of the book: warm and witty, or spare and serious.

### Cover Design DON'Ts
- No period imagery or historical references (unless dual-timeline)
- No genre signifiers (no blood, no swords, no spaceships, no romance clinch)
- No dark, moody palettes (contemporary fiction is visually bright and accessible)
- No clip art or stock imagery
- No "woman from behind looking at a landscape" (the most overused cover composition)
- No design that looks dated. contemporary fiction covers must feel CURRENT
