---
name: comedy-genre
description: "Genre-specific instructions for Comedy Fiction. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
---

# Comedy Fiction. Genre Plugin

## Metadata
- **Genre ID:** comedy
- **Display Name:** Comedy Fiction
- **Category:** Other
- **Tier:** Core
- **Target Word Count:** 4,000–5,000 per chapter
- **Min Word Count:** 3,500
- **Recommended Beat Structures:** Save the Cat, Story Circle, Three-Act Structure, Freytag's Pyramid

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Situational | Absurd situations, mistaken identity, escalating chaos | Humour arises from external circumstances spiralling out of control |
| Character Comedy | Personality-based, voice-driven, observational | Humour comes from WHO people are, not just what happens to them |
| Satirical | Mocking institutions, behaviours, ideas | Clear target of critique; exaggeration reveals truth |
| Absurdist | Logic abandoned, surreal, meaningless as funny | Internal consistency within illogic; deadpan presentation of impossible |
| Dark Comedy | Humour from morbid subjects, uncomfortable laughter | Understatement of horrific; matter-of-fact treatment of terrible |
| Parody | Mocking specific works or genres | Requires deep knowledge of source material; loving mockery vs. contempt |

## Architect Instructions

### Chapter Planning Requirements

PRIMARY GOAL: Make readers laugh consistently while potentially offering insight.

**Comic Structure Options:**

The Escalating Disaster:
- Small problem becomes catastrophic
- Each fix makes it worse
- Climaxes in chaos

The Fish Out of Water:
- Character in unfamiliar environment
- Cultural clash creates comedy
- Their perspective highlights absurdity

The Quest/Journey (Picaresque):
- Series of comic episodes
- Character moves through world
- Each encounter reveals something

The Day in the Life:
- Follow character through period
- Ordinary rendered extraordinary
- Episodic structure

**Comic Timing on Page:**
- SETUP: Establish expectation, build tension
- PUNCHLINE: Subvert expectation at sentence/paragraph end
- BEAT/PAUSE: Space before/after joke (paragraph break)
- ESCALATION: Building absurdity, accelerating rhythm
- DEFLATION: Puncture pomposity, anticlimax

**Rule of Three:**
- Two setups, third is punchline
- Or three escalating examples
- Comic rhythm that feels complete

**Each Chapter Needs:**
- Consistent laughs throughout (not just setup)
- Character-based humour (sustainable)
- Fresh observations or situations
- Rhythm and pacing variety
- Setup and payoff balanced
- Breathing room (not relentless)

**Key Beats to Plan:**
- Opening: Establish comic voice/perspective immediately
- Each Scene: What's the comedic engine? (character, situation, observation)
- Escalation Points: Where does absurdity build?
- Set Pieces: Big comic moments (plan carefully)
- Quieter Beats: Pauses between intensity
- Ending: Final laugh or observation

### Narrative Layers (A/B/C Stories)

Comedy novels benefit enormously from layered storytelling:
- **A-story:** The protagonist's main journey. the central comedic problem or quest that drives the plot
- **B-story:** A secondary storyline (relationship, rival, parallel situation) that intersects with and complicates the A-story
- **C-story:** The "runner". a comedic thread weaving throughout the book that seems minor but pays off spectacularly at the end

These layers should collide: the A-story crisis is sharpened by B-story complications, while the C-story runner provides consistent laughs AND an unexpected payoff. The collision of all three storylines at the climax is where maximum comedy lives.

### Scene Construction

Every scene is a story with its own beginning, middle, and end:
- A character enters the scene WANTING something specific
- They face opposition. another character who wants something different, or circumstances that block them
- The scene escalates through CONFLICT, not through conversation
- Scenes are driven by what characters DO and WANT, not by what they say
- Dialogue-driven scenes without underlying conflict are conversation, not comedy
- Multiple beats can exist within a single scene. don't limit each scene to one comic moment when three could collide

### External Conflict Drives Comedy

Internal conflict alone produces drama, not comedy. Comedy requires EXTERNAL pressure:
- Characters forced into situations they can't escape
- Obstacles that are visible, physical, social, or circumstantial
- The gap between what a character wants and what stands in their way is the comedy engine
- Internal fears and flaws FUEL the comedy, but external situations IGNITE it
- A character who is secretly insecure is dramatic; a character whose insecurity is exposed at the worst possible moment in front of the worst possible audience is comedy

### Genuine Stakes

If the outcome feels predetermined and the reader can see it coming, tension dies. and comedy without tension is just jokes in a row:
- Comedy storylines need genuinely uncertain outcomes. the reader should wonder HOW this resolves, not just WHEN
- Even in absurdist comedy, characters must believe the stakes are real
- Trivial stakes treated with life-or-death seriousness can be hilarious, but the characters' investment must be genuine
- Test every storyline: if the reader doesn't care whether it works out, the comedy has no engine

### Avoid in Planning
- One-note humour (same joke repeated)
- Explaining jokes
- Forcing humour (trying too hard)
- Long stretches without laughs
- Inconsistent tone (unless intentional shift)

## Writer Craft Rules

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (sharp opening images), Affection
  (primary — readers stay for voice), Validation at comedic
  beats.

### Voice and Perspective

VOICE PERSONA: A writer who understands comedy is serious art. laughter is as worthy as crying. Humour illuminates truth. Comic timing on page is crucial. Character-based humour outlasts gags. Best comedy contains insight beneath laughs.

GENRE POSITIONING: Comedy fiction is literature where humour is the primary goal and organising principle. narrative exists to generate laughter, situations and characters constructed for comic effect.

### The 10 Comedy Commandments

1. **Voice and Perspective Are Foundation**. Comic lens through which story is told. How narrator sees and describes world. This is what makes comedy COMEDY. Can be: deadpan, manic, elegant, observational, absurd.

2. **Character-Based Humour Sustains**. Comedy from WHO people are, not just what happens. Personality, perceptions, reactions. Voice-driven, not just situation-driven. Stays fresh across pages.

3. **Timing and Rhythm Are Everything**. Comedy is music on the page. Setup → Pause → Payoff. Sentence-level timing matters. Paragraph breaks as beats. Know when to land the joke and MOVE ON.

4. **Specificity Is Funnier Than General**. Exact right detail beats vague humour. "Blue Honda Civic" funnier than "car." The mundane detail that reveals absurdity.

5. **Consistency of Tone**. Reader must know what kind of comedy this is. Maintain your comic register. Tonal shifts must be purposeful. Commitment to the bit.

6. **Intelligence and Wit**. Respect reader's mind. Sophisticated humour valued. Clever > obvious. Layered meanings. Comedy can be smart.

7. **Fresh Perspective Required**. See what others miss. Familiar things seen newly. Originality in observation. Not retreading old jokes.

8. **Commit Fully**. Inhabit your comic world completely. No apologising for the comedy. Play it straight (makes it funnier). Characters take absurdity seriously.

9. **Structure Serves Comedy**. Even loose comedy needs shape. Pacing matters enormously. Build to set pieces. Vary intensity (not relentless).

10. **Truth Underneath**. Best comedy illuminates reality. Satire critiques. Absurdism reveals meaninglessness. Character comedy shows human nature. Funny because it's TRUE.

### Prose Style Options

| Style | Description | Masters |
|-------|-------------|---------|
| Deadpan/Dry | Absurdity in matter-of-fact tone | Adams, Pratchett |
| Exuberant/Manic | Energetic, excessive, over-the-top | Fielding, early Roth |
| Elegant/Witty | Sophisticated, polished, clever | Wodehouse, Wilde |
| Conversational | Friendly, direct, accessible | Hornby, Sedaris |
| Experimental | Playing with form for comic effect | Vonnegut, Jasper Fforde |

### Sentence Structure for Comedy
- **Setup-punchline:** Build through sentence, deliver at end
- **Absurdity:** Convoluted or unexpectedly simple
- **Deadpan:** Matter-of-fact delivery of ridiculous
- **Escalation:** Sentences that build and spiral
- **Contrast:** Short punchy vs. long elaborate

### Dialogue Rules
- Character-based (each talks distinctively funny)
- Subtext and misunderstanding
- Wit and wordplay
- Non sequiturs
- Escalation (conversations spiral)
- The straight man (reacts to absurdity)

### Light and Shade

The best comedy fiction shifts from hilarious to genuinely moving within the same chapter. and this contrast elevates it beyond joke delivery:
- After sustained comedy, an unexpected moment of genuine emotion floors the reader
- After a sincere beat, returning to comedy creates relief and warmth
- This tonal shift is NOT inconsistency. it's the contrast that makes BOTH registers hit harder
- Comedy without any emotional depth becomes exhausting; emotion without comedy becomes drama
- The funniest chapter should also contain the moment that catches the reader off guard with how much they suddenly care

### The Surprise Principle

If the reader can predict the punchline, the joke has already failed:
- Comedy must surprise. subvert expectations at the precise moment of delivery
- Don't telegraph jokes; the funniest moments catch readers completely off guard
- Avoid the obvious follow-up, the expected reaction, the predictable outcome
- The best comedy writers find the THIRD or FOURTH possible response. not the first one that comes to mind
- If you can see it coming, rewrite it

### Conciseness in Comedy

Comedy prose must be lean. excess words kill timing:
- Every sentence should earn its place; verbose comedy dies on the page
- Shorter, precise sentences for punchlines; longer sentences for setup (the contrast creates rhythm)
- If a joke can be told in fewer words, use fewer words
- Cut adjectives and adverbs ruthlessly. specificity of nouns and verbs is funnier than modification
- The space between jokes matters as much as the jokes themselves. paragraph breaks are beats, white space is timing

### Word Count and Structure
- Comedy novels: 70,000–90,000 typical (can be shorter)
- Chapters: 3,000–5,000 words
- Pacing: Generally needs to move
- Not long without jokes, but needs breathing room
- Vary intensity throughout

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. COMEDY

OPENING: FUNNY from sentence 1. The comic voice is the hook. it must land
immediately. The reader laughs before the first paragraph ends. No throat-clearing.
Establish the comic perspective (HOW this narrator sees the world) before plot.

SENTENCES. COMIC TIMING ON PAGE:
- Setup: medium (14-22) building expectation. Punchline: SHORT (4-10). deliver then stop
- Paragraph breaks = comedic beats (white space IS timing)
- Escalation: sentences lengthen building absurdity, then snap short
- Deadpan: the calmest prose for the most absurd content

VOCABULARY: Specificity funnier than generality ("Blue Honda Civic" > "car"). Exact
nouns and verbs carry the joke. cut adjectives ruthlessly. Lean prose: excess words
kill timing. Mundane detail revealing absurdity is the secret weapon.

DIALOGUE DENSITY: 50%+. Comedy is social: people talking, misunderstanding,
escalating. Each character distinctively funny. Conversations SPIRAL. Straight man's
reaction = comedy gold.

TENSION FLOOR: ≥3. Something wanted + something blocking = comedy engine. Stakes
trivial but treated with life-or-death seriousness. External conflict drives comedy.

RHYTHM: Open with comic voice demonstrated (not described). 2-3 laughs in the first
two pages. Dialogue early. Close on punchline or escalation. Rule of three at least
once: two setups, third subverts.
```

## Quality Check Criteria

### Priority Ranking
1. **Comic voice and perspective**. Distinctive narrative lens that is funny in itself, not just funny things happening
2. **Laugh frequency and consistency**. Genuine humour landing throughout; no 3+ page dead zones; variety of humour types
3. **Character-based humour**. Comedy arising from WHO characters are, not just from imposed situations
4. **Timing and rhythm**. Setup-pause-payoff working on page; paragraph breaks as beats; punchlines at sentence/paragraph ends
5. **Specificity over generality**. Precise, concrete details inherently funnier than vague descriptions

### Genre-Specific Checks
- **Escalation curve:** Comedy builds across the chapter. later scenes funnier than earlier ones
- **External conflict driving comedy:** Humour from characters forced into situations, not internal monologue alone
- **Surprise principle:** Punchlines subvert expectations; reactions are not the obvious ones
- **Light and shade:** Moments of genuine emotion between comedy beats
- **Commitment to the bit:** Characters take absurd situations seriously
- **Conciseness:** Prose lean; punchlines tight; no verbose setup where brevity would serve
- **Dialogue distinctiveness:** Each character speaks in recognisably different funny voice
- **Stakes present:** Something matters to characters, even if trivial
- **Subgenre consistency:** Satirical. target clear; Absurdist. illogic maintained; Dark. punching up not down

### Automatic Fails
- Explaining jokes. any line that explains why something is funny kills the comedy
- Characters breaking character to deliver a joke. humour must arise from consistent personality
- One-note humour. same type of joke repeated without variation or escalation
- No stakes. nothing matters, so nothing is funny
- Relentless without breathing room. wall-to-wall jokes with no space to laugh
- Trying too hard. forced humour that telegraphs "this is supposed to be funny"
- Generic humour. vague, could-be-anyone comedy without specific voice
- Predictable punchlines. if the reader sees the joke coming, the comedy has failed

### Acceptable Imperfections
- Minor plot logic stretched for a good joke (comedy audiences forgive more than drama audiences)
- Slightly heightened character reactions in key comic scenes (exaggeration is a valid tool)
- Tone shifting briefly for emotional beats (light and shade is a feature)
- Background details varying if the gag is worth it

### Red Flags
- 3+ pages without a genuine laugh
- Humour coming only from situations, never from character voice
- All characters funny in the same way
- Setup planted but punchline never delivered
- Comic antagonist absent or purely functional
- Dialogue interchangeable between characters
- Emotional moments that undercut the comedy rather than complementing it

## Continuity Rules

### Top 5 Continuity Priorities

1. **Running Gag Consistency:** Running gags are the backbone of comedy continuity. If a gag uses specific wording, the wording must be EXACT each time. variation kills the callback. Track every running gag's setup, exact phrasing, and each recurrence. Gags must escalate or vary with each use, never just repeat identically.

2. **Character Comic Identity:** Each character's comic type, specific flaws, and voice must remain consistent across chapters. If the protagonist is an Obsessive type who relates everything back to their fixation, they can't suddenly become a laid-back Everyman in Chapter 12.

3. **Setup-Payoff Completion:** Every setup MUST pay off. If Chapter 3 establishes that the protagonist's boss collects porcelain cats, those cats must matter later. Planted setups that never deliver are worse in comedy than drama. readers feel actively cheated.

4. **Escalation Logic:** Comedy must escalate. each complication bigger and funnier than the last. Track the escalation curve: if the Chapter 8 disaster is bigger than the Chapter 15 disaster, the comedy is deflating.

5. **Comic World Rules:** Every comedy establishes its own logic. how absurd things can get, what characters accept as normal. Once established, these rules must hold. If characters accept talking animals in Chapter 2, they can't be shocked by one in Chapter 18.

### Running Gag Registry
- Log each running gag when introduced: exact wording, setup context, character involved
- Track each recurrence: chapter number, exact wording used, variation/escalation applied
- Rule of Three: third use is typically the payoff. biggest version or the subversion
- Callbacks should reward attentive readers without requiring memory
- Flag any gag used 4+ times without variation (going stale)

### A/B/C Story Thread Tracking
- **A-story (Main Plot):** Current status of central comedic problem
- **B-story (Secondary):** How it intersects with and complicates A-story
- **C-story (The Runner):** Minor comedic thread. track each appearance, build toward climax payoff
- All three threads should advance each chapter. flag if any goes 3+ chapters without attention
- Climax should involve collision of all three

### Setup-Payoff Ledger
- Log every comic setup when planted (chapter, description, type: gag/situation/character/plot)
- Track which setups have paid off and which are still pending
- Setups older than 5 chapters without payoff need attention
- Flag orphaned setups. planted but abandoned

### Acceptable Inconsistencies
- Minor background details varying for a good joke
- Characters slightly smarter or dumber as a scene requires (heightening)
- Exact timing of events if not plot-critical
- Secondary character behaviour varying slightly between appearances
- Realistic logistics bent for comic effect

### Critical Consistency (Never Break)
- Running gag exact wording (readers memorise these)
- Character comic type and core flaws
- Protagonist's voice and perspective
- The Straight Man's relative sanity
- Setup-payoff promises
- Comic world rules and tone register
- Escalation direction (complications get bigger, not smaller)
- A/B/C story thread status (no silent abandonment)
- Satirical target and critique angle (if applicable)

## Character Rules

### Comic Protagonist Types

| Type | Description | Comedy Source | Examples |
|------|-------------|---------------|----------|
| The Fool/Innocent | Naïve, world happens to them | Misunderstanding, taking things literally | Candide, Chance the Gardener |
| The Cynic/Observer | Sees absurdity others miss | Perspective and observation | Groucho Marx characters |
| The Incompetent | Tries hard, fails spectacularly | Gap between effort and result | Inspector Clouseau, David Brent |
| The Obsessive | Single-minded to absurd degree | Everything relates back to obsession | Sheldon Cooper, Ignatius J. Reilly |
| The Con Artist/Rogue | Schemes that backfire or compound | Elaborate plans meeting reality | Basil Fawlty |
| The Pompous Intellectual | Deflation of pretension | Gap between self-image and reality | Frasier, Hyacinth Bucket |
| The Everyman | Sanity in insane circumstances | Reasonable reaction to unreasonable world | Arthur Dent |

### Core Character Requirements
- Flawed in SPECIFIC, FUNNY ways (not just "has flaws")
- Either oblivious to own ridiculousness OR hyper-aware but unable to stop
- Distinctive voice that's funny in its own right
- Capacity for dignity loss
- Takes themselves seriously (playing it straight makes it funnier)

### Character Flaws That Generate Comedy
- Misplaced confidence (sure they're right, always wrong)
- Selective blindness (can't see obvious thing everyone else sees)
- Inappropriate reactions (overreacts to small, underreacts to big)
- Self-sabotage patterns (always does the one thing that makes it worse)
- Verbal tics or patterns that compound
- Misaligned priorities (cares intensely about wrong things)

### The Supporting Cast

**The Straight Man (Essential):**
- Reacts to absurdity with something like sanity
- Grounds the comedy. without them, jokes float away
- Often the audience's perspective character
- Can be funny too, but differently (dry reactions, deadpan)

**Comic Foils:**
- Characters whose traits contrast/conflict with protagonist
- Interactions between different comic styles generate humour
- Their collisions should escalate, not just repeat

**Scene Stealers:**
- Secondary characters disproportionately funny
- Use sparingly. limited screen time but maximum impact
- One signature trait or bit that always works

**The Antagonist:**
- Can be ridiculous themselves (incompetent villain)
- OR straight figure protagonist bounces off
- OR satirical target (representing what's being mocked)
- Whatever role, must be comic, not just obstacle

### Character Camp

Build detailed backstory for EVERY recurring character, not just leads. Map relationships between ALL characters. how does every possible pair interact? No "minor" characters. every recurring person should be specific enough that you know how they'd react in any situation.

### Character Evolution

Modern readers expect character journeys even in comedy. static comic types feel like caricatures:
- Characters should grow, learn, and change through the story's events
- Growth doesn't mean becoming LESS funny. the comedy evolves as the character does
- The protagonist who hid behind sarcasm in chapter 1 should be capable of sincerity by the climax
- Track what each character LEARNS and when

### Exposition Through Action

Introduce characters through the protagonist's journey, never through separate setup scenes:
- Let the reader discover each character through action, reaction, and collision
- The best character introductions reveal who someone IS through what they DO when first seen

## Arc Rules

### Five-Phase Comedy Arc (30 Chapters)

**Phase 1. Comic World Establishment (Ch 1–5, 0–15%)**
- Comic voice and perspective established IMMEDIATELY. reader knows what kind of comedy this is within the first chapter
- Protagonist's comic type revealed through action, not description
- Comedy's world rules established: how absurd can things get? What do characters accept as normal?
- Supporting cast introduced through collision with protagonist
- Inciting incident: the problem, quest, or disaster that will escalate (planted by Ch 3–5)
- A/B/C stories seeded
- Laugh density: Medium. establishing voice and world
- Set pieces: 1–2 smaller comic sequences

**Phase 2. First Escalation (Ch 6–10, 15–35%)**
- The inciting problem gets worse. protagonist's attempts to fix it make it funnier
- Each fix creates a new complication (the comedy snowball)
- Character flaws now actively generating problems
- B-story begins intersecting with A-story
- Running gags established and getting first callbacks
- Laugh density: Rising
- Set pieces: 2–3 medium comic sequences

**Phase 3. Comic Midpoint (Ch 11–15, 35–50%)**
- MIDPOINT: Major comic setback, revelation, or reversal that kicks absurdity to new level
- Protagonist's approach has clearly failed. they need a new strategy (which will also fail, funnier)
- B-story fully entangled with A-story
- C-story runner getting regular appearances, building toward eventual payoff
- Light and shade: At least one moment of genuine emotion
- The funniest chapter so far should live here
- Laugh density: High. peak comedy territory

**Phase 4. Maximum Complications (Ch 16–22, 50–75%)**
- Multiple storylines colliding simultaneously. compounding disasters
- Every character's worst trait actively making everything worse
- Protagonist's comic flaw at its most destructive
- All running gags should get peak use. biggest escalation or most unexpected variation
- DARK MOMENT (Ch 20–22): Comedy pauses briefly for genuine moment. protagonist faces real consequences
- Light and shade at its most powerful
- Laugh density: Highest
- Set pieces: 3–5 major sequences, biggest laughs in the book

**Phase 5. Climax and Resolution (Ch 23–30, 75–100%)**
- CLIMAX (Ch 25–28): ALL THREE STORYLINES COLLIDE simultaneously
  - A-story crisis reaches peak absurdity
  - B-story complication explodes at worst possible moment
  - C-story runner delivers spectacular payoff
- Protagonist uses their comic flaw as a STRENGTH. the very trait that caused problems resolves them
- All major setups pay off
- Character growth visible but still funny
- FINAL LAUGH: The very last beat should be funny. a callback, observation, or perfect comic moment
- Resolution type: happy (most common), ironic, absurdist, or bittersweet

### Comedy-Specific Arc Elements
- **The Comic Flaw Arc:** Protagonist's flaw causes problems (Act I–II), reaches destructive peak (Act III), becomes unexpected solution (Climax)
- **The Escalation Principle:** Every complication bigger/funnier than the last; if comedy deflates, the arc is broken
- **The C-Story Payoff:** Minor runner thread delivering spectacular surprise at climax. one of comedy's most satisfying structural moves
- **Ensemble Collision:** Multiple characters' individual comic threads crash into each other spectacularly
- **The Earned Sincerity:** At least one moment where comedy drops away and something real is felt

## Timeline Rules

### Top 5 Timeline/Pacing Priorities

1. **Laugh Frequency Rhythm:** Comedy requires consistent laughs but not relentless ones. no more than 2–3 pages without humour landing
2. **Setup-Payoff Timing:** The space between setup and punchline matters enormously. too short feels rushed, too long loses connection
3. **Escalation Curve:** Comedy builds. small absurdities compound into chaos. Each act funnier than the last
4. **Breathing Room:** Readers need space to laugh. Back-to-back-to-back jokes exhaust. Quieter character moments between intensity let humour land
5. **Set Piece Pacing:** Major comic sequences need buildup. don't sprint into funniest scenes without setup tension

### Laugh Frequency Guidelines

| Zone | Description | Target |
|------|-------------|--------|
| Optimal | Something genuinely funny | Every 1–2 pages |
| Warning | Readers may disengage | 3+ pages without a laugh |
| Relentless | Exhausting, diminishing returns | Jokes every paragraph |
| Variety | Mix quick laughs with slower-building humour | Throughout |

### Chapter-by-Chapter Pacing Guide

**Act I (Ch 1–8): Establish Comic World**
- Ch 1–2: Comic voice established IMMEDIATELY (don't wait)
- Ch 3–5: Inciting incident. the escalating problem
- Ch 6–8: Stakes established, characters committed
- Laugh density: Medium
- Set pieces: 1–2 smaller sequences

**Act II (Ch 9–22): Escalating Disaster**
- Ch 9–12: First escalation. things get worse (and funnier)
- Ch 13–15: MIDPOINT. major comic setback, absurdity kicks up
- Ch 16–19: Multiple threads colliding, chaos compounding
- Ch 20–22: Maximum complications before resolution attempt
- Laugh density: High. this is where comedy peaks
- Set pieces: 3–5 major sequences, biggest laughs

**Act III (Ch 23–30): Resolution and Final Laughs**
- Ch 23–25: Attempt to resolve chaos (may fail first)
- Ch 26–28: Maximum chaos / climactic comic sequence
- Ch 29–30: Resolution. order restored (or not), final observations
- Laugh density: High at climax, can gentle for ending
- Set pieces: 1–2, including climactic sequence

### Set Piece Spacing
- Don't cluster big scenes. readers need recovery time
- Each set piece should top or equal the previous
- Build to set pieces. don't drop readers into chaos cold
- After big scenes, give breathing room before next escalation

### Flexible (Won't Break Comedy)
- Exact time progression (comedy often compresses or stretches time)
- Realistic scheduling (characters can be wherever the joke needs them)
- Minor continuity if the gag is worth it
- Time jumps between scenes

## Genre-Specific Craft Techniques

Comedy is a register that operates across nearly every genre,
but a comedy novel — comedy as the primary mode rather than as
seasoning — has its own distinct craft surface. The form
ranges from the subtle observational (Anita Brookner-with-
laughs, Nina Stibbe, Helen Fielding's *Bridget Jones* in its
wry-confession register) through the social-comedy mid-range
(David Lodge, Jonathan Coe, Mick Herron's Slough House series
in its black-comic mode, Tom Sharpe at his sharpest) to broad
farce (Carl Hiaasen, Christopher Buckley, the screwball
inheritance from Wodehouse). The techniques below are how the
form sustains laugh-rate, escalation, and emotional truth
across whatever register the writer has chosen — and how it
avoids the genre's failure modes (jokes-as-replacement-for-
plot, character-broken-to-serve-punchline, comedy-without-
stakes that floats off the page, and the ethical lapses
unfunny comedy commits when it does not know what its targets
are).

### The Escalating Disaster Engine

The core comedy structure: a small problem becomes
catastrophic through the protagonist's attempts to fix it.
Each "solution" creates a larger problem; the protagonist's
character-determined response to the larger problem creates
larger still; the layers compound until everything detonates
at once. The technique is structural at scene level (the lie
that requires the bigger lie within five pages) and at book
level (the character's defining flaw drives every escalation
across thirty chapters).

**How it works:**
1. Small, manageable problem appears
2. Protagonist's attempt to fix it creates a new, larger problem
3. Fix for problem two creates problem three (bigger still)
4. Each layer of "solution" compounds the original disaster
5. Climax: all compounded problems detonate simultaneously

**Key rule:** Each escalation must be both surprising AND
logical in retrospect. The reader should think "of COURSE
that would happen" while being caught off guard. The
"surprising" is the comic payoff; the "logical in retrospect"
is what distinguishes comedy from chaos. If the reader
anticipates each escalation, the engine has gone slack; if the
reader cannot reconstruct why each escalation happened, the
engine has gone random. The craft test: at any point in the
book, can the writer name the character flaw that is driving
this escalation? If the escalations are happening to the
protagonist rather than because of the protagonist, the
character is wallpaper and the engine has failed.

### The Callback Architecture

Comedy rewards attention. The strongest comedy novels reward
the reader who has been paying attention to the small details
nobody else has bothered with — the running joke that returns
twenty chapters later in a context that recontextualises both
appearances; the throwaway line that turns out to have been the
title's true meaning; the minor character whose final
appearance redeems three earlier scenes the reader thought
were filler. The technique requires deliberate planting: the
detail that will pay off must be unobtrusive enough not to
feel telegraphed when introduced, specific enough to be
recognised when it returns.

- **Setup (Ch 2):** Mention the porcelain cat collection in passing
- **Reminder (Ch 8):** Another brief mention, establishing pattern
- **Payoff (Ch 22):** The porcelain cats become crucial to the climactic disaster
- **Meta-payoff (Ch 28):** One final reference that recontextualises everything

The architecture works on multiple scales simultaneously: the
scene-level callback (the line that closes a scene by echoing
its opening), the chapter-level callback (the joke that
bookends a chapter's events), and the book-level callback (the
detail in chapter two that detonates the climax). The strongest
comic novelists run several callback arcs at once, layered so
that the careful reader feels rewarded multiple times across
the book without the casual reader feeling lost. Test: pick
three setups from the first quarter; can the writer locate
each one's payoff in the final act? Orphaned setups and
unprepared payoffs are equally damaging.

### The Comic Reversal

The moment where the reader's expectation is completely
upended. Comedy depends on the gap between what was expected
and what occurred — and the comic reversal is where that gap
is opened deliberately, sized for maximum impact, and closed
in a way that converts surprise into laugh.

- Build toward an expected outcome with careful setup
- At the precise moment of expected delivery, reverse everything
- The reversal must feel both surprising and inevitable
- Works best when the character's established flaw is what causes the reversal

The "inevitable" is the test that distinguishes the comic
reversal from arbitrary plot interruption. The reader's laugh
arrives because, in the moment of reversal, they recognise that
this character — given everything they have shown us about
themselves — could only have produced this outcome. If the
reversal is generic ("and then a piano fell on him"), the
comedy is sketch-level and not earning the novel's investment.
If the reversal is character-driven ("and so, naturally, he
told the truth — for the first time in the book — at exactly
the wrong moment, because that is the kind of person he has
been all along"), the comedy is the novel's emotional climax
arriving in comic form. Test every reversal in the manuscript:
which character flaw caused this? If the answer is "none",
the reversal is decoration.

### The Straight Man Anchor

Without grounding, comedy floats into meaninglessness. The
reader needs at least one character whose register is closer
to ordinary perception than to the surrounding absurdity —
someone whose reactions calibrate the reader's own. The
straight man does not have to be humourless; they often
deliver the book's driest, sharpest lines precisely because
they are the only character clear-eyed enough to see what is
happening.

- At least one character must react to absurdity with something approaching sanity
- Their incredulity validates the reader's own reaction
- They don't need to be humourless. dry reactions and deadpan commentary are comedy gold
- The straight man's eventual breaking point (when even they succumb to the absurdity) is one of the most powerful comedy beats

The technique scales: the entire ensemble can rotate through
the straight-man role (one character is the anchor in this
scene; another is the anchor in the next), or the role can be
held throughout by a single character whose final breakdown
becomes the book's emotional crescendo. The failure mode: a
book in which everyone is equally absurd, equally over-the-
top, equally invested in the comic register — the reader has
nowhere to stand, and the laughs stop landing because there is
no contrast to land them against. Comedy is comparison; without
the straight figure, the comic figures lose their measure.

### Displaced Seriousness Technique

Characters treating trivial stakes with life-or-death gravity.
The technique converts disproportion itself into the source of
comedy: when a character's emotional, intellectual, or moral
investment is wildly disproportionate to the actual stakes,
both the investment and the stakes become funny.

- The character who approaches a parking dispute with the intensity of a war crime investigation
- The family whose Scrabble game escalates into genuine psychological warfare
- The neighbour whose campaign against a bin-day infraction has the tactical apparatus of a national-security operation
- The colleague whose stationery-cupboard rivalry with a co-worker has lasted eleven years

The technique requires that the character's seriousness be
genuine — not performed, not knowingly absurd, not played for
the camera. The character must believe (or have come to
believe, through whatever path the book has charted) that the
parking dispute matters. The reader's laugh comes from the gap
between the character's interior conviction and the reader's
exterior measure. Generic "stakes-don't-matter" satire is the
failure mode; specific, character-true investment in trivial
stakes is the technique. Test: would this character explain
their seriousness, in their own voice, in a way the reader
could understand even if they could not share? If yes, the
displaced seriousness is operating; if not, the character is
being mocked rather than animated.

### The Cruelty Calibration

Every comedy novel makes ongoing, often unstated, decisions
about what its humour will and will not do — to its
characters, to its world, to the people who resemble its
characters in literal life. This calibration is the genre's
ethical surface and the most-detected craft failure when it
goes wrong. Strong comedy knows what it is targeting and why:
the character flaws of empowered figures, the absurdities of
institutions, the specific behaviours of named offenders, the
self-importance of those who can afford to be made fun of.
Weak comedy targets without knowing it is targeting: the
joke at the expense of a character the writer has not bothered
to make a person, the laugh at a group whose specifics the
book has flattened, the cruelty toward characters the writer
treats as scenery while pretending they are people. The
genre's distinction — the difference between comedy that ages
and comedy that embarrasses its readers a decade later — is
almost always located here.

The calibration operates on three axes:

- **Direction.** Is the comedy "punching up" (toward power,
  pretension, hypocrisy of those who can afford the hit) or
  "punching down" (toward the vulnerable, the marginal, the
  already-mocked)? The genre's mainstream contemporary
  consensus is that punching up ages well; punching down ages
  badly even when the laughs land at publication.
- **Specificity.** Is the comedy targeting the specific
  behaviour of a specific (real or invented) figure, or is it
  generalising across a category of person? Specific targets
  read as observational; categorical targets read as bigotry,
  even when the writer's intent was the opposite.
- **Awareness.** Does the manuscript know what it is doing?
  When the comedy makes a hard call (the joke that requires
  the writer's choice about what is permissible), is the
  decision visible in the prose, or has the writer relied on
  defaults? The choices made knowingly can be defended; the
  choices made by default cannot.

Test: pick three of the manuscript's hardest-laughing
sequences and ask, in each, who pays for the laugh. If the
answer is "the powerful, the pretentious, the hypocritical, the
specific named offender", the calibration is sound. If the
answer is "people the book has not bothered to render", the
calibration is the book's most urgent revision.

### Comedy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "hilarity ensued" | Show the specific comic sequence beat by beat |
| "the situation went from bad to worse" | Show the specific escalation and its specific cause |
| "comic timing was everything" | SHOW the comic timing through scene pacing and paragraph break |
| "the joke practically wrote itself" | Write the joke. Don't announce it. |
| "laughter filled the room" | Show what caused the laughter — the specific funny moment, the specific listeners |
| "awkwardness reached new heights" | Show the specific awkward moment and the specific physical wreckage |
| "a comedy of errors" | Show the specific error chain |
| "the punchline landed" | Show the specific line and the specific reaction |
| "the absurd situation" | Show the specific absurdity, named and located |
| "she couldn't help but laugh" | Show what triggers the laughter and her specific physical reaction |
| "the room erupted" | Show what specifically the room did — the precise sound, the named person who started it |
| "his deadpan delivery was perfect" | Show the line and let it land; "deadpan" is what writers say when they cannot write the line |
| "everyone burst out laughing" | Pick the named characters who reacted, show each one's specific response |
| "she made a face" | Show the specific face — the eyebrow, the corner of the mouth, the held breath |
| "wittily" / "drily" / "wryly" / "sardonically" (as adverb) | Cut the adverb; if the line is witty, the line is witty without the label |
| "the comic timing was off" / "his timing was perfect" | Stop telling the reader; let the prose carry the timing |
| "in true British / American / Australian fashion" | Cut nationality stereotype shorthand; show the specific behaviour |
| "the irony was lost on him" | Show what he did or said that demonstrates obliviousness; "irony" telegraphs the joke |

## Genre-Specific Revision Rules

Six revision passes specific to comedy, each with a single
question, run cover-to-cover before the next begins. Comedy
revision has a particular discipline: laughter cannot be faked
in revision the way emotional weight sometimes can. A scene
that does not generate the intended reaction at first read
will not generate it at fourth read either; the fix is not
more polish on the existing line but recomposition of the
comic logic underneath. The passes below are ordered to
surface the failures of comic engine and timing first
(without which the rest is decoration), then character and
escalation discipline, then setup-payoff and ethical
calibration.

### Pass 1: Comedy Audit

Read every page aloud — comedy is an oral form even on the
page, and the eye lies where the ear does not. Does each page
generate a genuine reaction (laugh, smile, surprise, raised
eyebrow, the in-breath that means a beat has landed)? Mark
every page without a humorous beat in the margin. If more than
two or three consecutive pages run dry, the comedy has lapsed
and the reader has begun to skim regardless of how strong the
prose is at sentence level. Check that humour comes from both
character AND situation — not one alone. Situation comedy
without character roots becomes thin within ten pages
(slapstick fatigue); character comedy without situation roots
becomes stagy and airless. Verify jokes aren't telegraphed: if
the reader can complete the punchline before reaching it, the
laugh has been spent in setup. The fix for telegraphing is
almost always to add a feint — a beat that points the reader
toward an expected outcome and then arrives at a different
one. Test specifically: where the manuscript flagged "this is
the joke" through narrator language ("of course", "naturally",
"as anyone could have predicted"), the joke has been
pre-announced and lost.

### Pass 2: Timing Tightening

Comedy timing is paragraph-shape and sentence-shape work.
Examine every punchline location: is the laugh at the END of
the sentence, paragraph, or scene that earned it? Punchlines
that sit mid-paragraph almost never land — the reader's eye
has already moved past them by the time the comic register
arrives. Check for excess words between setup and delivery and
trim ruthlessly: comic prose is denser than non-comic prose,
and any word between the setup and the punch that does not
contribute to either is dead weight blunting the impact.
Verify paragraph breaks are creating beats: a paragraph break
is a quarter-second of reader's silence, the prose equivalent
of comic pause. The strongest comic prose deploys paragraph
breaks deliberately to set up timing — short paragraph,
shorter paragraph, single-line paragraph that lands the joke.
Ensure variety: quick laughs mixed with slower-building
comedy. A book that delivers only fast laughs becomes
exhausting; a book that delivers only slow laughs lacks
energy. The mix is the rhythm. Test scene-level: pick three
scenes spaced across the book and identify the comic peak in
each — is the peak landing at the structural position that
gives it most impact, or has it been buried mid-scene?

### Pass 3: Character Consistency

Read each character's dialogue in isolation, ignoring
attribution and surrounding scene. Is their comic voice
distinct, recognisable across chapters, recognisable from
other characters? In strong comedy, every significant
character has a particular comic register (deadpan, hyperbolic,
naive, weary, righteous, oblivious, cunning) and a particular
relationship to the comic register (some characters know they
are funny; most do not; the funniest are usually the most
sincere). Check that the protagonist's comic type is
consistent across all chapters: protagonists who shift comic
register without explanation read as the writer's voice
intruding rather than the character's. Verify the straight man
is present in every act and remains grounded. Confirm no
character breaks established pattern without returning to it,
or without the return being itself a payoff. The genre's
strongest practitioners maintain comic-voice continuity even
through emotional scenes: the deadpan character's grief sounds
like deadpan grief, not generic-sad-protagonist; the
hyperbolic character's quiet moment is hyperbolically quiet.

### Pass 4: Escalation Verification

Track the escalation curve chapter by chapter, scoring each
chapter's comic intensity on a 1–5 scale. The curve should
ascend across the book — Act II should be funnier than Act I
not less; the climactic sequence should be the biggest laugh
in the book; the final scene should re-locate the comic
register against the (now achieved) emotional resolution. Map
the placement of major set pieces (the comic centerpieces) —
are they spaced for maximum impact, with quieter chapters
between to let the reader recover and the running gags
accumulate? Check that all running gags escalate or vary
across the book and never just repeat: a running gag that
appears identical in chapters 4, 12, 20, and 28 has been
deployed as wallpaper rather than as architecture. Test:
list every running gag and verify each appearance both
echoes the prior and adds something new (a variation, a
recontextualisation, an escalated version, a reversal of the
pattern). The strongest running gags pay off most in their
final appearance, where the reader's accumulated knowledge of
the pattern is what makes the final variation land.

### Pass 5: Setup-Payoff Completion

List every setup planted in the manuscript. Verify each one
pays off; no orphaned promises. The strongest comedies plant
heavily in the first third — small details, throwaway lines,
minor character traits, named objects, oddly specific
references — and pay them off across the second half with
multiplying density. The reader's pleasure in returning to
chapter two for the inheritance plot in chapter twenty-eight
is comedy's deep loyalty mechanism. Check that biggest payoffs
land in the final act and that the climactic sequence resolves
multiple setup threads simultaneously (the porcelain cats, the
parrot's vocabulary, the unread legal notice, the wedding
booking, all detonating in the same scene). Confirm the C-
story runner — the secondary subplot tracked across the book
— delivers a spectacular climax payoff. Test: pick three
setups from the first quarter and locate each payoff in the
final act. Any setup without a payoff is a promise to the
reader the book has broken. Any payoff without a setup is the
writer cheating.

### Pass 6: The Cruelty Calibration Audit

Run a dedicated final pass on the comedy's targets. For each
of the manuscript's hardest-laughing sequences, ask: who pays
for this laugh? Is the laugh at the expense of the powerful,
the pretentious, the hypocritical, the specific-named-
offender — or is it at the expense of a character the book
has not bothered to render as a person? Direction (punching
up vs down), specificity (named target vs categorical
generalisation), and awareness (knowing the call vs default
choice) are the three axes. Flag every sequence where the
laugh depends on a stereotype, a category-wide generalisation,
or a character treated as scenery while pretending to be a
person. The pass is not asking the manuscript to be politer
or less ambitious; it is asking the manuscript to know what
it is doing. Comedy that knows its targets ages well; comedy
that does not ages badly even when the laughs land at
publication. Test specifically: read the final chapter as the
ending it is, and ask whether the world the book has
constructed is one the writer wants the reader to leave with
affection or with discomfort. Both are legitimate endings; the
choice between them must be deliberate.

### Comedy-Specific Red Flags in Revision

- Any line that EXPLAINS why something is funny — delete immediately
- Characters breaking established personality solely to deliver a joke
- Two or more characters who are funny in the same way — differentiate or merge
- Running gag wording changed between uses (readers notice)
- Act II less funny than Act I (escalation failure)
- Jokes at the expense of characters the author doesn't respect (punching down)
- Adverbs doing the comedy work the verbs and dialogue should be doing ("she said wittily")
- Setup planted without payoff (orphan promises) or payoff without setup (unearned punchline)
- Comedy that requires footnoting (cultural reference, in-joke, regional shorthand) where the reader will not have the context to laugh
- Sincerity displaced into irony at the moments where the reader needs the book to mean what it says

## Names & Patterns to Avoid

### Forbidden Comedy Patterns
- "He/she couldn't help but laugh". don't tell us it's funny, show us
- Characters who are aware they're being funny (breaks the fourth wall)
- Explaining the joke after delivering it
- The word "hilarious" used to describe anything happening in the story
- "Comedy of errors" as a descriptor within the text
- Characters described as "witty" without demonstrating wit
- Forced catchphrases that don't arise organically

### Cliché Comedy Setups to Avoid
- The entirely predictable misunderstanding that could be resolved with one sentence
- The "overhearing half a conversation" gag (unless brilliantly subverted)
- Slapstick without character motivation (falling down isn't inherently funny)
- The drunk scene as easy comedy
- Pop culture references as substitutes for original humour
- Breaking the fourth wall without establishing that as part of the comic contract

### Names to Avoid
- Overtly "funny" names that telegraph comedy (Seymour Butts, etc.). unless parody requires them
- Names that are themselves the joke (one-note comedy)
- Generic placeholder names that don't reveal character

## Comp Titles

Comedy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Three Men in a Boat* — Jerome K. Jerome (1889): foundational British comic novel.
- *Catch-22* — Joseph Heller (1961): satirical war-comedy literary benchmark.
- *A Confederacy of Dunces* — John Kennedy Toole (1980): Pulitzer-winning literary comedy.
- *Hitchhiker's Guide to the Galaxy* — Douglas Adams (1979): SF-comedy benchmark.

### Contemporary (current best-in-class)

- *Less* — Andrew Sean Greer (2017): contemporary literary comedy; Pulitzer-winning.
- *Where'd You Go, Bernadette* — Maria Semple (2012): epistolary contemporary comedy.
- *Eleanor Oliphant Is Completely Fine* — Gail Honeyman (2017): contemporary comedy with mental-health depth.
- *Lessons in Chemistry* — Bonnie Garmus (2022): historical comedy benchmark.
- *The Rosie Project* — Graeme Simsion (2013): neurodivergent contemporary comedy.
- *A Man Called Ove* — Fredrik Backman (2012): grumpy-old-man comedy benchmark.
- *Anxious People* — Fredrik Backman (2019): contemporary comedy-drama.
- *Yellowface* — R.F. Kuang (2023): publishing-industry satirical comedy.

## Cover Design Specifications

### Visual Tone
- Bright, eye-catching colours (yellows, oranges, teals)
- Illustrated or stylised artwork (often preferred over photographic)
- Typography-forward designs with playful, bold fonts
- Whimsical or irreverent visual elements

### Key Visual Elements
- Characters in absurd or compromising situations
- Objects that suggest the comedic premise
- Visual puns or sight gags on the cover
- Clean, uncluttered compositions that let the title breathe

### Typography
- Bold, playful serif or hand-lettered fonts for title
- Often larger title text than other genres
- Subtitle or tagline space for a one-liner that sets the tone
- Author name in complementary but secondary position

### Colour Palette
- Primary: Warm, inviting colours (sunshine yellow, coral, turquoise)
- Avoid: Dark, moody palettes (unless dark comedy, then pair dark with one bright accent)
- High contrast between title and background
- White space used generously. comedy covers shouldn't feel busy

### Comp Titles (Cover Style Reference)
- *A Man Called Ove* by Fredrik Backman. illustrated, warm, character-driven
- *The Thursday Murder Club* by Richard Osman. bold type, bright, playful
- *Anxious People* by Fredrik Backman. whimsical illustration, pastel palette
- *Good Omens* by Pratchett/Gaiman. irreverent, slightly chaotic, genre-blending
- *The Hitchhiker's Guide to the Galaxy* by Douglas Adams. iconic, bold, instantly recognisable
