---
name: trope-library
description: 188 fiction tropes organised by category with pairing suggestions and pre-built starter bundles. Used during Phase 1 setup to shape Architect and Writer prompts.
version: "1.0"
user-invocable: false
---
<!-- (c) 2025 James Harvey Media / Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Trope Library — Fiction Trope Reference

188 tropes across 10 categories. Each trope has genre compatibility, heat-level tags, and complementary pairing suggestions.

**Genre tags:** `all` = universal across all genres | specific genre IDs = only relevant for those genres
**Heat tags:** `all` = any heat level | `steamy+` = steamy and above only | `dark` = dark romance only

---

## How Tropes Are Used in the Engine

1. **Phase 1 Setup** — User selects 3–7 tropes (or picks a starter bundle)
2. **Story Bible** — Selected tropes are embedded as thematic pillars
3. **Architect** — Each chapter brief references active tropes; the Architect plans scenes that deliver on them
4. **Writer** — Trope expectations inform prose: pacing, tension, payoff timing
5. **Verification** — Arc Analyst checks trope delivery across the manuscript
6. **Editorial** — Genre review validates trope execution against reader expectations

### Trope Selection Rules

- **Minimum:** 1 trope (even non-romance genres benefit from structural tropes)
- **Recommended:** 3–5 tropes for a focused, satisfying read
- **Maximum:** 7 tropes (more than this dilutes each one)
- **Pairing suggestions** are recommendations, not requirements
- **Heat-restricted tropes** should only be offered when the heat level matches

---

## 1. Relationship Dynamics

*How the central relationship develops — the core arc readers expect.*

### Classic Arcs

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Enemies to Lovers | Start antagonistic, attraction builds through conflict | all | all | Forced Proximity, Only One Bed, Grumpy-Sunshine, Workplace Rivals |
| Friends to Lovers | Existing friendship evolves into romance | all | all | Belated Love Epiphany, Childhood Sweethearts, Roommates |
| Strangers to Lovers | Meet and fall in love (insta or slow burn) | all | all | Vacation Romance, Forced Proximity, Fish Out of Water |
| Second Chance Romance | Exes reunite, get a second shot at love | all | all | Return to Hometown, Single Parent, Marriage in Trouble |
| Love/Hate Relationship | Intense attraction mixed with genuine conflict | all | all | Enemies to Lovers, Forced Proximity, Workplace Rivals |
| Forbidden Love | External forces say they can't be together | all | all | Star-Crossed, Feuding Families, Class Differences |
| Star-Crossed Lovers | Circumstances or fate working against them | all | all | Forbidden Love, Feuding Families, Immortal/Mortal |
| Unrequited Love (Becomes Requited) | One pines, eventually reciprocated | all | all | He Falls First, Best Friend's Sibling, Belated Love Epiphany |

### Friendship-Based

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Best Friend's Sibling | Hero/heroine is sibling of best friend | all | all | Forbidden Love, Slow Burn, He Falls First |
| Brother's Best Friend | Hero is brother's best friend (or vice versa) | all | all | Age Gap, Forbidden Love, Slow Burn |
| Childhood Sweethearts | Grew up together, always loved each other | all | all | Second Chance, Return to Hometown, Small Town |
| Reunion Romance | Reconnect after years apart (not necessarily exes) | all | all | Return to Hometown, Second Chance, Found Family |

### Pacing

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Slow Burn | Attraction builds gradually over time — delayed gratification | all | all | Enemies to Lovers, Friends to Lovers, Forbidden Love |
| Instalove / Insta-Lust | Immediate intense attraction or connection | all | all | Fated Mates, Strangers to Lovers, Vacation Romance |
| He/She Falls First | One character falls before the other | all | all | Grumpy-Sunshine, Enemies to Lovers, Unrequited Love |
| Belated Love Epiphany | Suddenly realises they've been in love all along | all | all | Friends to Lovers, Unrequited Love, Best Friend's Sibling |

### Progression Patterns

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Love Triangle | Torn between two love interests (divisive trope) | all | all | Forbidden Love, Second Chance |
| Fake Dating | Pretend dating that becomes real | all | all | Enemies to Lovers, Grumpy-Sunshine, Forced Proximity |
| Fake Engagement | Pretend engaged for family/work/social reasons | all | all | Fake Dating, Forced Proximity, Only One Bed |
| Marriage of Convenience | Marry for practical reasons, love develops | all | all | Arranged Marriage, Slow Burn, Forced Proximity |
| Arranged Marriage | Families or society arrange the match | all | all | Enemies to Lovers, Marriage of Convenience, Forbidden Love |
| Accidental Marriage | Wake up married (Vegas, magic, drunken mistake) | all | all | Strangers to Lovers, Forced Proximity, Comedy |
| Marriage in Trouble | Married couple reconnects, saves their relationship | all | all | Second Chance, Emotional Growth, Healing |

---

## 2. Character Archetypes

*Personality types and character roles that define the leads.*

### Hero Personalities

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Alpha Hero | Dominant, commanding, protective, takes charge | all | all | Feisty Heroine, Bodyguard, Possessive |
| Beta Hero | Gentle, supportive, emotionally available | all | all | Strong Heroine, Friends to Lovers, Healing |
| Cinnamon Roll Hero | Sweet, soft, too precious for this world | all | all | Grumpy Heroine, Sunshine Hero, Friends to Lovers |
| Grumpy Hero | Scowling, growling, gruff exterior hiding a soft heart | all | all | Sunshine Heroine, Grumpy-Sunshine, Forced Proximity |
| Sunshine Hero | Optimistic, cheerful, lights up the room | all | all | Grumpy Heroine, Grumpy-Sunshine, Friends to Lovers |
| Wounded Hero | Emotionally damaged, needs healing through love | all | all | Healing, Slow Burn, Trust Issues |
| Morally Grey Hero | Does questionable things, not pure good | all | all | Dark Tone, Redemption, Forbidden Love |
| Anti-Hero | Protagonist who lacks traditional heroic qualities | all | all | Morally Grey Hero, Redemption, Enemies to Lovers |
| Rake / Player Reformed | Playboy who settles down for the right person | all | all | Virgin/Experienced, Slow Burn, Emotional Growth |
| Cocky / Arrogant Hero | Confident to the point of irritating | all | all | Feisty Heroine, Enemies to Lovers, Workplace Rivals |
| Nerdy / Geeky Hero | Smart, awkward, niche interests | all | all | Opposites Attract, Friends to Lovers, Slow Burn |

### Heroine Personalities

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Feisty Heroine | Sassy, fights back, won't be pushed around | all | all | Alpha Hero, Enemies to Lovers, Cocky Hero |
| Sunshine Heroine | Bright, optimistic, cheerful | all | all | Grumpy Hero, Grumpy-Sunshine, Cinnamon Roll |
| Grumpy Heroine | Prickly, defensive, scowling | all | all | Sunshine Hero, Grumpy-Sunshine, Cinnamon Roll |
| Strong / Badass Heroine | Physically capable, fighter, doesn't need saving | all | all | Beta Hero, Alpha Hero, Enemies to Lovers |
| Independent Heroine | Self-sufficient, doesn't need saving | all | all | Slow Burn, Enemies to Lovers, Beta Hero |
| Snarky Heroine | Sharp tongue, witty comebacks | all | all | Cocky Hero, Enemies to Lovers, Comedy |
| Damaged Heroine | Trauma survivor, trust issues | all | all | Healing, Wounded Hero, Trust Issues |

### Dynamic Pairings

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Grumpy-Sunshine | One grumpy, one cheerful — opposites attract dynamic | all | all | Forced Proximity, Enemies to Lovers, He Falls First |
| Opposites Attract | Fundamentally different people drawn together | all | all | Enemies to Lovers, Forced Proximity, Slow Burn |
| Same Wavelength | So similar they finish each other's sentences | all | all | Friends to Lovers, Slow Burn, Instalove |

---

## 3. Situations & Settings

*Physical circumstances that force characters together or create tension.*

### Proximity Tropes

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Forced Proximity | Stuck together by circumstance | all | all | Enemies to Lovers, Only One Bed, Grumpy-Sunshine |
| Only One Bed | Forced to share a bed (classic tension builder) | all | all | Forced Proximity, Enemies to Lovers, Fake Dating |
| Roommates | Living together platonically (for now) | all | all | Friends to Lovers, Forced Proximity, Slow Burn |
| Snowed In / Stranded | Weather or disaster traps them together | all | all | Forced Proximity, Only One Bed, Strangers to Lovers |
| Road Trip | Journey together forces bonding | all | all | Forced Proximity, Enemies to Lovers, Friends to Lovers |

### Location Tropes

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Small Town | Everyone knows everyone, community matters | all | all | Return to Hometown, Found Family, Second Chance |
| Return to Hometown | Going back to where it all began | all | all | Second Chance, Small Town, Childhood Sweethearts |
| Vacation Romance | Holiday fling that becomes more | all | all | Strangers to Lovers, Instalove, Fish Out of Water |
| Fish Out of Water | Character in unfamiliar environment | all | all | Small Town, Vacation Romance, Opposites Attract |

### Professional Tropes

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Boss/Employee | Power dynamic in the workplace | all | all | Age Gap, Forbidden Love, Alpha Hero |
| Workplace Rivals | Competing for same promotion/account/position | all | all | Enemies to Lovers, Grumpy-Sunshine, Cocky Hero |
| Bodyguard | Protecting the love interest (or protected by them) | all | all | Alpha Hero, Forced Proximity, Forbidden Love |
| Co-Workers | Colleagues who fall for each other | all | all | Friends to Lovers, Slow Burn, Workplace Rivals |
| Small Business | Running a shop, bakery, bookstore, etc. | all | all | Small Town, Found Family, Cozy |

### Life Situations

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Single Parent | Raising kids alone, love complicates things | all | all | Second Chance, Found Family, Slow Burn |
| Widow/Widower | Finding love after loss | all | all | Second Chance, Healing, Slow Burn |
| College/University | Campus setting romance | all | all | Friends to Lovers, Enemies to Lovers, Age Gap |
| Military/Service | Active duty or veteran romance | all | all | Wounded Hero, Forced Proximity, Bodyguard |

---

## 4. Emotional & Thematic Tropes

*The emotional core and thematic underpinning of the story.*

### Emotional Journeys

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Healing | Love helps characters heal from trauma/past | all | all | Wounded Hero, Damaged Heroine, Slow Burn |
| Redemption | Character seeks to atone for past wrongs | all | all | Morally Grey Hero, Anti-Hero, Second Chance |
| Trust Issues | One or both characters struggle to trust | all | all | Slow Burn, Healing, Wounded Hero |
| Emotional Growth | Character matures emotionally through the relationship | all | all | Enemies to Lovers, Slow Burn, Marriage in Trouble |
| Self-Discovery | Character finds themselves through the love story | all | all | Fish Out of Water, Coming of Age, Independence |
| Sacrifice for Love | Willing to give up something important for the other | all | all | Forbidden Love, Star-Crossed, Fated Mates |

### Social Themes

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Class Differences | Rich/poor, noble/common divide | all | all | Forbidden Love, Cinderella, Boss/Employee |
| Feuding Families | Romeo & Juliet — families at war | all | all | Forbidden Love, Star-Crossed, Enemies to Lovers |
| Age Gap | Significant age difference between leads | all | all | Boss/Employee, Brother's Best Friend, Forbidden Love |
| Found Family | Characters build a chosen family | all | all | Healing, Small Town, Reunion Romance |

### Tone & Atmosphere

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Comedy / Romantic Comedy | Humour drives the story | all | all | Fake Dating, Grumpy-Sunshine, Accidental Marriage |
| Angst | Emotional intensity, yearning, pain | all | all | Forbidden Love, Star-Crossed, Slow Burn |
| Dark Tone | Morally complex, gritty, intense | all | all | Morally Grey Hero, Anti-Hero, Possessive |
| Cozy | Warm, comforting, feel-good | all | all | Small Town, Found Family, Friends to Lovers |
| Swoony | Swoon-worthy romantic gestures and declarations | all | all | Slow Burn, He Falls First, Cinnamon Roll |

---

## 5. Fantasy & Paranormal Tropes

*Supernatural and fantasy-specific tropes for SFF romance and fantasy genres.*

### Bonds & Destiny

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Fated Mates | Destined by magic/bond to be together | fantasy, paranormal-romance, sci-fi | all | Enemies to Lovers, Slow Burn, Possessive |
| Claiming Mark | Physical mark appears when mates bond | fantasy, paranormal-romance | steamy+ | Fated Mates, Possessive, Alpha Hero |
| Soul Bond | Magical connection between two people | fantasy, paranormal-romance | all | Fated Mates, Star-Crossed, Slow Burn |
| Immortal/Mortal | One lives forever, one doesn't (ticking clock) | fantasy, paranormal-romance | all | Star-Crossed, Forbidden Love, Sacrifice for Love |

### Fantasy Roles

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Chosen One | Prophecy or destiny marks the protagonist | fantasy, paranormal-romance | all | Found Family, Quest, Enemies to Lovers |
| Fae Romance | Romance involving fae/fairy court beings | fantasy | all | Court Intrigue, Forbidden Love, Morally Grey Hero |
| Shifter Romance | Werewolves, shapeshifters, animal forms | paranormal-romance, fantasy | all | Fated Mates, Alpha Hero, Possessive |
| Vampire Romance | Vampire love interest (dark, immortal) | paranormal-romance | all | Immortal/Mortal, Forbidden Love, Dark Tone |
| Court Intrigue | Political machinations in royal/fae courts | fantasy | all | Enemies to Lovers, Arranged Marriage, Morally Grey Hero |

### Fantasy Situations

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Quest | Epic journey drives the plot | fantasy, sci-fi | all | Found Family, Enemies to Lovers, Slow Burn |
| Portal Fantasy | Character transported to another world | fantasy | all | Fish Out of Water, Chosen One, Strangers to Lovers |
| Forced Marriage (Fantasy) | Married off for political alliance or peace treaty | fantasy | all | Enemies to Lovers, Arranged Marriage, Slow Burn |
| Academy / Magic School | Learning magic while falling in love | fantasy, paranormal-romance | all | Enemies to Lovers, Friends to Lovers, Chosen One |

---

## 6. Spice & Intimacy Tropes

*Tropes that affect heat level and intimate dynamics. Filter by heat level.*

### Tension Builders

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Unresolved Sexual Tension | So much tension you could cut it with a knife | all | all | Slow Burn, Enemies to Lovers, Forced Proximity |
| Touch Starved | Craves physical contact, melts at gentle touch | all | all | Healing, Slow Burn, Wounded Hero |
| Forbidden Desire | Wants someone they know they shouldn't | all | all | Forbidden Love, Boss/Employee, Age Gap |
| Jealousy | Seeing love interest with someone else triggers possessiveness | all | all | Enemies to Lovers, Love Triangle, Possessive |

### Heat-Specific

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Virgin/Experienced | One experienced, one not | all | steamy+ | Slow Burn, Age Gap, Rake Reformed |
| Possessive | "You're mine" energy, claiming, territorial | all | steamy+ | Alpha Hero, Fated Mates, Enemies to Lovers |
| Praise Kink | Words of affirmation as intimacy driver | all | steamy+ | Slow Burn, Touch Starved, Beta Hero |
| Forced Marriage (Dark) | Non-consensual marriage, captor/captive dynamic | romance, fantasy | dark | Dark Tone, Enemies to Lovers, Alpha Hero |
| Kidnapping Romance | One character takes the other (dark romance) | romance | dark | Dark Tone, Possessive, Enemies to Lovers |
| Bully Romance | Romantic interest through bullying dynamic | romance | dark | Enemies to Lovers, College, Dark Tone |
| Mafia/Mob Boss | Criminal underworld romance | romance | dark | Alpha Hero, Possessive, Dark Tone |

---

## 7. Historical & Period Tropes

*Tropes specific to historical settings.*

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Wallflower | Overlooked woman who blooms | historical-romance | all | Rake Reformed, Slow Burn, He Falls First |
| Compromise | Caught in compromising position, must marry | historical-romance | all | Arranged Marriage, Enemies to Lovers, Slow Burn |
| Bluestocking | Intellectual woman in an era that discourages it | historical-romance | all | Beta Hero, Enemies to Lovers, Independent Heroine |
| Mail-Order Bride | Sent to marry a stranger (Western, frontier) | historical-romance, western | all | Strangers to Lovers, Forced Proximity, Fish Out of Water |
| Cowboy / Rancher | Rugged, outdoorsy, land-working hero | western | all | Fish Out of Water, Grumpy Hero, Slow Burn |

---

## 8. Thriller & Suspense Tropes

*Tropes for romantic suspense and thriller-adjacent stories.*

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Heroine in Danger | Female lead targeted, hero protects | romantic-suspense, thriller | all | Bodyguard, Alpha Hero, Forced Proximity |
| Dangerous Enemy | External threat forces heroes together | romantic-suspense, thriller | all | Forced Proximity, Bodyguard, Trust Issues |
| Undercover | One character has a secret identity/mission | romantic-suspense, thriller | all | Trust Issues, Enemies to Lovers, Forbidden Love |
| Witness Protection | Hiding from danger, new identity | romantic-suspense, thriller | all | Forced Proximity, Strangers to Lovers, Fish Out of Water |
| Survival | Must survive together against the odds | all | all | Forced Proximity, Strangers to Lovers, Snowed In |
| Injury / Recovery | One character injured, the other cares for them | all | all | Bodyguard, Touch Starved, Slow Burn |

---

## 9. Sci-Fi & Futuristic Tropes

*Tropes for science fiction romance and futuristic settings.*

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Alien Romance | Romance with a non-human species | sci-fi | all | Fated Mates, Forced Proximity, Fish Out of Water |
| Cyborg / Android | Romance with synthetic or enhanced being | sci-fi | all | Touch Starved, Slow Burn, Opposites Attract |
| Space Opera | Vast galactic setting, big stakes | sci-fi | all | Found Family, Quest, Enemies to Lovers |
| Dystopian | Oppressive society, love as rebellion | sci-fi, dystopian | all | Forbidden Love, Chosen One, Survival |
| Time Travel | Love across timelines | sci-fi, fantasy | all | Star-Crossed, Fish Out of Water, Slow Burn |

---

## 10. Multi-Partner & Non-Traditional

*Relationship configurations beyond traditional monogamy.*

| Trope | Description | Genres | Heat | Pairs Well With |
|-------|-------------|--------|------|----------------|
| Reverse Harem | One heroine, multiple heroes (3+), all in relationship | romance, fantasy, paranormal-romance | steamy+ | Why Choose, Fated Mates, Found Family |
| Why Choose | Heroine doesn't choose — keeps them all | romance, fantasy, paranormal-romance | steamy+ | Reverse Harem, Fated Mates, Found Family |
| Ménage à Trois | Three-person relationship | romance | steamy+ | Why Choose, Found Family |
| Polyamory | Multiple partners, ethical non-monogamy | all | all | Found Family, Why Choose |

---

## Starter Bundles

Pre-built trope combinations for common subgenres. Users can pick a bundle as a starting point and customise from there.

| Bundle Name | Tropes |
|-------------|--------|
| **Contemporary Rom-Com** | Enemies to Lovers, Forced Proximity, Grumpy-Sunshine, Fake Dating, He Falls First, Comedy, Only One Bed |
| **Small-Town Sweet** | Return to Hometown, Second Chance, Single Parent, Small Town, Friends to Lovers, Slow Burn, Cozy |
| **Steamy Billionaire** | Boss/Employee, Age Gap, Virgin/Experienced, Possessive, Alpha Hero, Only One Bed, Class Differences |
| **Sports Romance** | Enemies to Lovers, Forced Proximity, Grumpy Hero, Slow Burn, He Falls First, Injury/Recovery, Swoony |
| **Dark Mafia** | Forced Marriage (Dark), Kidnapping Romance, Enemies to Lovers, Possessive, Mafia/Mob Boss, Dark Tone, Alpha Hero |
| **Bully Romance** | Bully Romance, Enemies to Lovers, College/University, Possessive, Jealousy, Angst, Dark Tone |
| **Fated Mates Fantasy** | Fated Mates, Enemies to Lovers, Chosen One, Found Family, Slow Burn, Possessive, Claiming Mark |
| **Reverse Harem** | Reverse Harem, Fated Mates, Chosen One, Found Family, Enemies to Lovers, Why Choose, Court Intrigue |
| **Epic Quest Romance** | Enemies to Lovers, Found Family, Quest, Slow Burn, Chosen One, Morally Grey Hero, Sacrifice for Love |
| **Fae Court Intrigue** | Fae Romance, Court Intrigue, Enemies to Lovers, Forbidden Love, Morally Grey Hero, Slow Burn, Arranged Marriage |
| **Cozy Found Family** | Found Family, Small Town, Healing, Friends to Lovers, Cozy, Small Business, Grumpy-Sunshine |
| **Regency Romance** | Wallflower, Rake Reformed, Slow Burn, Enemies to Lovers, Compromise, Class Differences, Arranged Marriage |
| **Western Romance** | Mail-Order Bride, Cowboy/Rancher, Fish Out of Water, Strangers to Lovers, Forced Proximity, Slow Burn, Survival |
| **Romantic Suspense** | Bodyguard, Heroine in Danger, Enemies to Lovers, Forced Proximity, Trust Issues, Slow Burn, Dangerous Enemy |
| **Space Opera Romance** | Enemies to Lovers, Found Family, Forced Proximity, Star-Crossed, Morally Grey Hero, Slow Burn, Survival |
| **Universal Crowd-Pleaser** | Enemies to Lovers, Forced Proximity, Grumpy-Sunshine, Slow Burn, Found Family, Fake Dating, He Falls First |

---

## Integration Notes for Agents

### Architect Agent
When planning chapter briefs, the Architect should:
- Reference selected tropes as thematic anchors for scene design
- Plan trope "delivery beats" — key moments where tropes are advanced or subverted
- Ensure trope setups in early chapters have corresponding payoffs later
- Use pairing synergies (e.g., Enemies to Lovers + Forced Proximity = shared-space tension scenes)

### Writer Agent
When executing prose, the Writer should:
- Embody trope expectations in dialogue, internal monologue, and scene construction
- Match trope pacing to the story's pace (slow burn = gradual; instalove = immediate chemistry)
- Deliver trope-specific "money moments" (the first-touch scene, the confession, the grovel)
- Avoid cliché execution — deliver the trope promise but with fresh specifics

### Arc Analyst (Verification)
When reviewing chapters, the Arc Analyst should:
- Track which tropes have been serviced and which are underserved
- Flag if a selected trope hasn't appeared by the midpoint
- Verify trope payoffs land in the final act
- Check for trope contradictions (e.g., "slow burn" story with a chapter-2 love scene)

### Genre Review (Editorial)
When reviewing the full manuscript, editorial should:
- Assess whether selected tropes are executed to reader expectations
- Identify any unselected tropes that emerged organically (note but don't penalise)
- Score trope delivery as part of genre-fit assessment
