---
name: steampunk-genre
description: Genre-specific instructions for steampunk fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Steampunk. Genre Plugin

## Metadata
- id: steampunk
- name: Steampunk
- icon: ⚙️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "The Hero's Journey"]

## Subgenre Options
Present during setup:
- **Victorian Steampunk**. London-centric (or London-analogue), class-stratified society, the Industrial Revolution reimagined with impossible steam technology
- **Gaslamp Fantasy**. Steampunk aesthetic with genuine supernatural elements: alchemy that works, clockwork that runs on captured souls, automatons with consciousness
- **Diesel Punk / Interwar**. The aesthetic pushed forward to the 1920s-1940s: Art Deco, diesel engines, early aviation, pulp adventure energy
- **Clockpunk**. Renaissance or Enlightenment era, Leonardo da Vinci-inspired mechanical marvels, earlier period technology
- **Western Steampunk**. Frontier setting with steam technology: train-based adventures, mining towns with mechanical augmentation, the clash between wilderness and industry
- **Afro-Steampunk / Non-Western**. Steampunk technology through non-European cultural lens: West African, South Asian, East Asian, or Indigenous engineering traditions

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Victorian-adventure rhythm. exploration and social manoeuvring punctuated by action set-pieces
- Must open with: Sensory immersion. a character IN the world, experiencing it through one or two specific physical details. Never with a technology manual

BEATS PER CHAPTER
1. Mechanism Beat. A piece of technology is used, built, repaired, or fails; the reader sees HOW things work through action
2. Social Stratification Beat. The distance between classes is felt: a factory worker's hands vs. an aristocrat's gloves, access denied or granted
3. Discovery/Invention Beat. Something new is revealed, built, or understood; the sense of wonder at what's possible
4. Atmospheric Beat. The world is experienced through its physical reality: smoke, brass, fog, gaslight, the smell of coal and machine oil
5. Consequence Beat. Technology has costs: pollution, exploitation, displacement, danger

STEAMPUNK ARCHITECTURE
- Technology is MECHANICAL and VISIBLE: gears, pistons, boilers, springs, clockwork. the reader can imagine how it works
- The aesthetic is Victorian (or equivalent period) but the technology is impossible: difference engines that think, airships that shouldn't fly, automatons that move too smoothly
- Class is CENTRAL: who builds the machines, who owns them, who is ground up by them
- The British Empire (or equivalent) is a presence. steampunk often engages with colonialism, industrialization, and their human costs
- Science is adventure: exploration, invention, discovery. there is genuine WONDER at what can be built
- The natural world is under siege: smoke, pollution, deforestation. or nature fights back
- POV: Third-person past (dominant. suits the period voice) or first-person past (for memoir/journal framing)

THE MACHINE AESTHETIC
- Machines are BEAUTIFUL and DANGEROUS: polished brass and exposed gears, but also scalding steam and crushing pistons
- Technology is analogue: no microchips, no digital. everything is mechanical, pneumatic, hydraulic, or clockwork
- Size matters: steampunk technology is often LARGE (airships, locomotives, walking machines, factory engines)
- Sound and smell: steam technology is LOUD (hissing, clanking, whistling) and PUNGENT (coal smoke, machine oil, hot metal)
- Imperfection: machines break, leak, need constant maintenance. they are temperamental, not reliable

SOCIAL STRUCTURE
- The aristocracy/upper class: patrons of invention, owners of industry, arbiters of society
- The middle class/professionals: engineers, inventors, doctors, natural philosophers. the people who BUILD
- The working class: factory workers, miners, street vendors, servants. the people who POWER the machines
- The underclass: orphans, criminals, the displaced, the people the machines have made obsolete
- Women in steampunk: navigate the tension between period-accurate restriction and genre-enabled agency
- Non-European characters: address colonialism honestly, don't use steampunk as an excuse to erase it

FORBIDDEN IN STEAMPUNK
- Modern sensibilities pasted onto period characters without earning it (characters who sound like 21st-century people in top hats)
- Technology that works perfectly with no maintenance, fuel, or consequence
- Steampunk as pure AESTHETIC (goggles and gears on everything) without engaging with the social and technological implications
- Ignoring the period's real inequalities: class, gender, race, empire
- Gear-glued-on-a-hat worldbuilding: decoration without function
- Clean, pollution-free industrial cities (the smoke IS the genre)
- Exposition through "let me explain how my invention works" monologues
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (atmosphere & invention), Anticipation (mystery / mission), Stimulation at set-pieces.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Third-person past tense (dominant) or first-person past (memoir/journal frame)
- Voice: Literate, precise, with the cadence of the period. but not stiff; character voice should feel lived-in
- Tone: Adventure and wonder undercut by awareness of cost; the marvel of the machine AND the cost of the machine
- Register: Period-appropriate vocabulary without becoming a costume. Use the language naturally, not as decoration.

PROSE IMPERATIVES
- THE MACHINE IN MOTION: when technology appears, the reader should see, hear, and feel it working
  - Gears meshing, steam venting, pistons driving, clockwork ticking, boilers rumbling
  - The physical reality of mechanical technology: heat, vibration, noise, smell
- PERIOD TEXTURE: the world feels Victorian (or equivalent) in its DETAILS
  - Cobblestones, gaslight, hansom cabs, top hats. but also cholera, child labour, fog thick enough to taste
  - Manners and social codes that constrain characters: who can speak to whom, where they can go, what they can wear
- SENSORY LAYERING: steampunk worlds are rich and specific
  - The taste of coal dust in the air; the warmth of a boiler room; the cold of a brass railing in winter
  - Gaslight casts specific shadows. warm, flickering, imprecise
  - The smell of a workshop: oil, solder, wood shavings, hot metal
- WONDER AND DREAD: the same technology that inspires awe also threatens
  - An airship is beautiful. and one spark near the gas envelope ends everything
  - An automaton is marvellous. and its hands could crush a skull
  - A factory is productive. and the workers' lungs are black by forty

PROSE RHYTHM MAPPING
- Chapter 1 must establish inventive wonder + period voice. the reader should feel the era's cadence and the marvel of impossible machines
- Medium ornate sentences form the baseline: 18-26 words, with a Victorian-adjacent cadence that favours subordinate clauses, balanced constructions, and a measured, literate flow
- Victorian cadence ADAPTED, not mimicked: the prose should evoke the period's rhythms without becoming pastiche. Sentences are longer and more structured than modern fiction, but never impenetrable
- Machine-in-motion passages: the rhythm becomes percussive. medium sentences (16-22 words) with strong stressed syllables mimicking mechanical rhythm. THUMP-hiss-THUMP of pistons can live in the sentence structure itself
- Opening paragraphs: establish the period voice immediately. measured, observant, slightly formal, with one specific sensory detail that grounds the reader in the world of steam and brass
- Wonder moments (seeing a new invention): sentences stretch slightly (22-28 words), becoming more elaborate. the prose mirrors the machine's intricacy
- Action/danger sequences: sentences compress (12-18 words) but retain period vocabulary. The rhythm quickens without the voice becoming modern. "She ran" not "she bolted"
- Dialogue rhythm varies by class: aristocratic speech uses longer, more balanced constructions (20-28 words per speech); working-class speech is shorter, more direct (8-14 words); inventor speech oscillates between precise brevity and enthusiastic elaboration
- Social scenes (drawing rooms, clubs): measured, controlled rhythm. medium-long sentences that mirror the social dance of propriety and restraint
- Workshop/laboratory scenes: a more energetic rhythm. medium sentences with technical precision, the prose moving with the purpose of someone building
- Tension baseline: ≥5 from the first page. Steampunk tension comes from the wonder-cost dynamic: every marvel carries danger, every advancement costs someone something
- The wonder-cost seesaw in rhythm: a long, admiring sentence describing a machine's beauty, immediately followed by a shorter sentence noting its threat. This pattern should recur throughout
- Paragraph construction: slightly longer than modern default. Period-appropriate paragraphs hold 5-7 sentences, creating a denser, more immersive texture
- Avoid both extremes: too short feels modern and wrong for the period; too long feels like actual Victorian prose and alienates readers
- End-of-chapter rhythm: a measured, resonant final sentence (18-24 words) that carries the weight of what was discovered, built, or threatened. delivered with quiet period authority
- Read passages aloud with the deliberation of someone who lived before the telephone. the pace of thought should be slightly slower, more considered, than contemporary fiction
- Sensory machine details: give them one full sentence each. Don't rush past the physical reality of steam technology. the rhythm demands SPACE for sensation
- The goal: prose that feels like a beautifully engineered mechanism itself. every part purposeful, every joint precise, running with satisfying rhythm and occasional, thrilling bursts of speed

PERIOD VOICE (without parody)
- Use period vocabulary where natural: "ought", "shall", "I confess", "indeed"
- Avoid anachronisms: no "okay", "guys", "stressed out", "awesome"
- But DON'T write in full Victorian pastiche. this is fiction, not parody
- The goal is EVOCATION of period, not replication
- Different classes speak differently: an aristocrat's polished sentences vs. a dock worker's clipped slang
- Educated characters may use Latin phrases, literary allusions, or scientific terminology naturally

TECHNOLOGY PROSE
- Describe machines through INTERACTION, not specification:
  WRONG: "The Difference Engine Mark IV was a 12-ton analytical device powered by a Watt & Boulton triple-expansion steam engine."
  RIGHT: "She fed the punch cards in one at a time, feeling the machine accept each with a click and a shudder. Steam vented from the brass exhaust pipe, warming her left side, and the engine's analytical drums began to turn. a sound like a hundred clocks agreeing on the time."
- Technology should feel TACTILE: characters touch, adjust, maintain, and struggle with their machines
- When something breaks, describe the failure through ONE dominant detail: the grinding, OR the whistle of steam, OR the sudden silence. Let the single sensation carry the moment

DIALOGUE CRAFT
- Aristocrats: formal, controlled, saying more between the lines than in them
- Engineers/Inventors: enthusiastic, precise, occasionally incomprehensible to non-specialists
- Working class: direct, colourful, practical. dialect without becoming caricature
- Villains: polished, reasonable, utterly convinced of their own rightness
- Period forms of address: "sir", "madam", "my lord", "miss". used naturally, not excessively
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

STEAMPUNK CRAFT (40% of total):
- Technology is mechanical, visible, and described through sensation? (0-100)
- The period setting feels authentic without becoming parody? (0-100)
- Class and social stratification are present and felt? (0-100)
- Wonder and consequence coexist (marvels are also dangers)? (0-100)

STORY CRAFT (30% of total):
- Plot engages with the genre's themes (invention, class, empire, progress)? (0-100)
- Characters have agency within period-appropriate constraints? (0-100)
- The world feels lived-in (not a museum tour)? (0-100)
- Pacing balances adventure with world-building and character? (0-100)

PROSE QUALITY (30% of total):
- Period voice is evoked without pastiche or parody? (0-100)
- Sensory detail is rich and specific (sight, sound, smell of steam tech)? (0-100)
- Machines are described through interaction, not exposition? (0-100)
- Dialogue is class-differentiated and period-appropriate? (0-100)

AUTOMATIC FAILS (score = 0):
- Steampunk aesthetic without social or technological engagement ("gears glued on")
- Modern voice/attitude in period costume (characters sound 21st-century)
- Technology that works perfectly with no cost, maintenance, or consequence
- Ignoring class entirely. everyone is wealthy and comfortable
- Pure exposition about how machines work (technology lectures)
- Victorian England copied with no engagement with colonialism, class, or gender
```

## Continuity Rules

```
STEAMPUNK CONTINUITY. WHAT TO TRACK

TECHNOLOGY STATE:
- What machines/inventions exist, who built them, and their current condition
- Fuel supply: coal, gas, water for steam. tracked and finite
- Maintenance: machines need tending; track who maintains what and when
- Breakdowns: if a machine fails, track the consequence chain
- Invention timeline: new devices should build on established technology, not appear from nowhere

SOCIAL STATE:
- Class positions: which characters are aristocracy, middle class, working class, underclass
- Social mobility: has anyone's position changed? Track the cause and consequence
- Reputation: in period society, reputation is currency. track gains and losses
- Relationships: alliances, enmities, debts, obligations. social networks matter
- Gender restrictions: what women/marginalised characters can and cannot do in this setting

ECONOMIC STATE:
- Funding: who pays for the inventions, expeditions, and adventures?
- Employment: who works for whom, and under what conditions?
- Industrial ownership: which factories, mines, or workshops belong to which characters?
- Debts and patronage: financial obligations drive plot

GEOGRAPHIC/ENVIRONMENTAL STATE:
- Pollution level: industrial areas get worse over time, not better
- Weather and fog: London fog was partly coal smoke; it has character and consequence
- Districts: wealthy areas vs. industrial zones vs. slums. track movement between
- Travel: by airship, train, carriage, or foot. mode affects time and experience

PHYSICAL STATE:
- Industrial injuries: burns from steam, deafness from factory noise, lung damage from coal
- Period-appropriate illness: cholera, typhus, consumption
- Fatigue from physical labour or adventure
- Clothing damage: period clothing was expensive and hard to replace
```

## Character Rules

```
STEAMPUNK CHARACTER TYPES

THE INVENTOR/ENGINEER:
- Driven by curiosity and the desire to BUILD
- May be brilliant but socially awkward (not a requirement. avoid the stereotype)
- Their workshop is their second home: describe it in detail
- They have a complicated relationship with their patrons (who fund them) and the workers (who build their designs)
- Their invention is personal: it represents their vision of how the world SHOULD work

THE ARISTOCRAT:
- Born to privilege but not necessarily to villainy
- Navigates society's rigid expectations: duty, marriage, inheritance
- May be a patron of science (progressive) or a defender of tradition (conservative)
- Their power is social AND economic: they control access, funding, reputation
- Internal conflict: maintaining their position vs. doing what's right

THE WORKER/ARTISAN:
- Skills are their currency: a machinist, a clockmaker, a boiler operator
- They understand technology from the inside. they BUILD it and MAINTAIN it
- Caught between: the marvel of what they create and the conditions under which they work
- Community matters: pub, neighbourhood, trade associations, mutual aid
- Physical reality: callused hands, coal dust, chronic cough, pride in craft

THE ADVENTURER/EXPLORER:
- Drawn to the edges of the map and the limits of technology
- May be military, scientific, or freelance
- Practical skills: navigation, combat, survival, improvisation
- Their relationship with empire and colonialism must be addressed (not all explorers are innocent)
- What they discover changes them. exploration is transformation

THE SOCIAL REFORMER:
- Sees the costs of industrial progress: child labour, pollution, exploitation
- May work within the system (philanthropy, politics) or against it (activism, sabotage)
- Conflict between gradual reform and radical action
- Period-appropriate: suffragettes, abolitionists, trade unionists, Chartists

VOICE DIFFERENTIATION:
- Aristocrats: polished, indirect, relying on implication and social code
- Engineers: precise, enthusiastic, lapsing into technical language when excited
- Workers: direct, practical, colourful slang, possibly dialectal
- Military: clipped, formal, rank-conscious
- Scientists: careful, qualified, referencing evidence and precedent
```

## Arc Rules

```
STEAMPUNK STORY STRUCTURE

ACT 1: THE WORLD AND THE WONDER (first 25%)
- Establish the world through LIVING in it: the character's daily reality
- The technology is present and functional: the reader sees machines in use
- Social position is clear: where the protagonist fits in the class structure
- The inciting event introduces a POSSIBILITY: a new invention, a mysterious commission, a discovery, a challenge
- Stakes are established: what the protagonist has to gain and lose
- END OF ACT 1: The protagonist commits to the adventure/quest/invention

ACT 2A: THE ASCENT (to midpoint)
- The project/adventure/quest gains momentum
- Technology is pushed further: bigger machines, wilder inventions, unexplored territories
- Social barriers are encountered and navigated (or broken)
- Allies are gathered from different classes (the inventor needs the worker needs the patron)
- The wonder of the world deepens: the reader sees more, understands more, marvels more
- MIDPOINT: A revelation that changes the stakes. the invention is dangerous, the expedition has a hidden purpose, the patron has ulterior motives

ACT 2B: THE COST (midpoint to dark moment)
- The costs of progress become visible: pollution, exploitation, danger
- The technology turns against its creators: machines malfunction, inventions are weaponized, progress demands sacrifice
- Social structures push back: the establishment resists change
- Personal costs: relationships strained, health damaged, principles compromised
- The villain's plan becomes clear. and it's rational (progress at any cost, empire above humanity, profit over people)
- DARK MOMENT: The protagonist's greatest creation is destroyed, corrupted, or turned to ill purpose

ACT 3: THE RECKONING (final 25%)
- The protagonist must choose: what kind of progress do they believe in?
- Technology is used CREATIVELY. not just bigger and louder, but smarter and more human
- Class barriers are crossed or broken for the climax (the aristocrat gets their hands dirty, the worker takes command)
- The climax is mechanical AND human: a machine must work AND a moral choice must be made
- Resolution addresses the social question: has anything changed for the better?
- The world continues to turn. progress doesn't stop, but its direction may have shifted

STEAMPUNK PACING:
- Alternates between: exploration/wonder scenes and action/danger scenes
- Social scenes (drawing rooms, clubs, workshops) drive plot as much as action scenes
- Technology demonstrations build in complexity and danger across the story
- The pace accelerates in the final third: more action, higher stakes, faster resolution
```

## Timeline Rules

```
STEAMPUNK TIMELINE

PERIOD TIMELINE:
- Steampunk stories typically span weeks to months (the duration of a project, expedition, or social season)
- Track the time of year: seasons affect everything (fog in autumn, cold in winter, social seasons)
- Days of the week matter: Sunday is different from a workday; social events have schedules
- Time of day matters: gaslight changes the world at night; factories run on shifts

TECHNOLOGY TIMELINE:
- Inventions take TIME to build: materials must be sourced, components machined, prototypes tested
- Track the development stages: concept → design → prototype → testing → refinement
- Maintenance schedules: boilers need cleaning, gears need oiling, coal needs replenishing
- Fuel supply: coal, gas, and water are not infinite. track usage and resupply

SOCIAL TIMELINE:
- The social calendar: balls, exhibitions, parliamentary sessions, court dates
- Letters and messages take time to deliver (no instant communication unless invented)
- Travel time is significant: London to Edinburgh by train is a day; by airship maybe less (but establish it)
- Social reputation changes slowly: a scandal takes weeks to spread, a ruined reputation takes months to rebuild

INDUSTRIAL TIMELINE:
- Factory shifts: 12-16 hour days for workers, often 6 days a week
- Construction projects: bridges, railways, buildings take months or years
- Economic cycles: boom and bust, seasonal employment, market fluctuations
```

## Genre-Specific Craft Techniques

Steampunk is the historical-speculative register that
projects a what-if-the-Victorian-industrial-revolution-had-
gone-differently logic onto a recognisable past, with the
form's signature aesthetic blending Victorian / Edwardian
material culture, working machinery, alternate-history
political reality, and the moral weight of industrial
exploitation. The cluster includes traditional steampunk
(typically British 19th century setting), American steampunk,
silkpunk (East Asian register, popularised by Ken Liu),
gaslamp fantasy (overlapping with steampunk but typically
with magical rather than mechanical premise), clockpunk
(Renaissance-era predecessor variant), dieselpunk (1920s-50s
inheritance with combustion-engine register), and the
broader retro-futurist range. Comp authors span the canonical
lineage (William Gibson and Bruce Sterling's *The Difference
Engine*, K.W. Jeter's *Infernal Devices*, Tim Powers's *The
Anubis Gates*, James Blaylock's *Homunculus*, Mary Robinette
Kowal's *Ghost Talkers* and *Glamourist Histories*) through
contemporary expansion (Cherie Priest's *Boneshaker*, Cassandra
Clare's *Infernal Devices* trilogy, Mark Hodder's Burton and
Swinburne novels, Gail Carriger's *Soulless* and *Parasol
Protectorate*, Scott Westerfeld's *Leviathan*, Philip Reeve's
*Mortal Engines*, Jay Lake's *Mainspring*, Stephen Hunt, Ekaterina
Sedia, China Miéville's *Perdido Street Station* on the
adjacent New Weird edge, Ken Liu's *Grace of Kings* on the
silkpunk register, P. Djèlí Clark's Cairo novellas at the
contemporary diverse edge, Tasha Suri at the colonial-era
edge, Genevieve Cogman's *Invisible Library*, Theodora Goss's
*Athena Club*, Robert Jackson Bennett's *Foundryside* on the
secondary-world steampunk-adjacent register). The techniques
below are how the form delivers its core pleasures while
avoiding the failure modes (cosmetic-aesthetic register —
goggles and brass without the form's deeper concerns; period-
parody pastiche; uncritical-Victorian-nostalgia that elides
the era's specific exploitations the form should be
reckoning with; technology-as-decoration without the form's
signature wonder-cost tension).

### The Machine in Motion

Every significant machine should be experienced through at least three senses:

```
The press started with a shudder that travelled through the floor
and into her boots. The drive shaft turned. slowly at first, then
faster, until the flywheel blurred into a silver disc and the air
filled with the smell of hot oil and the rhythmic THUMP-THUMP-THUMP
of the stamp descending. The heat from the boiler turned the near
side of her face pink.

Touch (vibration) → Sight (flywheel blur) → Smell (hot oil) →
Sound (stamp rhythm) → Touch again (heat)
.  Machines are EXPERIENCED, not described.
```

### The Wonder-Cost Seesaw

Every scene of technological marvel should be paired with its cost:

- The airship is magnificent. and the hydrogen is one spark from explosion
- The automaton plays piano beautifully. and the children who assemble its tiny gears go blind by twenty
- The Difference Engine can calculate the tides. and its coal consumption darkens the sky over Lambeth
- The mechanical limb gives the veteran his hand back. and the fitting left him screaming for three days

**Rule:** No wonder without cost. No cost without wonder. The tension between them IS steampunk.

### The Class Lens

Every scene should be filterable through class perspective:

- Who built this machine? Who owns it? Who profits from it? Who is harmed by it?
- When an aristocrat admires an invention, a worker sees the overtime it demanded
- When an inventor celebrates a breakthrough, a factory owner calculates the profit
- When a reformer sees exploitation, an industrialist sees employment

### Steampunk AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "gears turned and steam hissed" | Show ONE specific machine and what it's doing |
| "Victorian elegance met industrial might" | Show the specific juxtaposition through one room or outfit |
| "the clockwork mechanism whirred to life" | Show what the mechanism actually does |
| "brass and copper gleamed" | Show the specific device and its specific purpose |
| "the age of invention" | Show the specific invention and its impact on this person |
| "airships dotted the sky" | Show one airship from one character's perspective |
| "the aristocracy clung to power" | Show the specific political act |
| "steam-powered [anything]" | Show the specific machine's limitations and quirks |
| "the inventor's workshop was a marvel" | Show ONE specific project in progress |
| "the empire's reach extended" | Show the specific colonial or industrial action |
| "goggles and top hats" | Show the specific outfit and what it signals about the wearer |
| "the smog of London hung heavy" | Show what the specific smog does to specific characters in this specific moment (the cough; the visibility; the smell of specific industrial origin) |
| "the great clockwork tower struck the hour" | Show what the strike does to the surrounding city (who hears it / whose schedule it shapes / what work it announces) |
| "her corset constrained her" | Specific functional constraint with specific consequence in this scene; cliche-corset-suffering is the form's most-tired feminist gesture |
| "the workshop was a wonderland of contraptions" | Show ONE specific contraption and what it does, not generalised wonder |
| "the inventor's vision would change everything" | Show the specific change to specific people through specific consequence |
| "Empire was at its zenith" | Cut; show specific imperial action with specific colonial consequence |
| "she was a woman ahead of her time" | Cut; show what specifically she does that her time would have made difficult |

### Period Immersion Without Parody

The balance between authentic period voice and readable modern fiction:

```
WRONG (too modern):
"Look," she said, "I don't care about your class issues.
I'm going to build this thing whether you like it or not."

WRONG (too period. pastiche):
"My dear Lord Pemberton, I must confess that I am
most dreadfully vexed by your implication that a mere
woman cannot comprehend the principles of pneumatic engineering."

RIGHT (period-evocative, readable):
"Lord Pemberton." She set down the spanner and met his
gaze. "I have read Babbage. I have corresponded with Lovelace.
And I have built three working models while you were at your club.
I believe I shall continue."
```

### The Alternate-History Discipline

Steampunk operates in a world that diverges from actual
history at specific identifiable points. The form's
strongest practice makes the divergence specific, traceable,
and load-bearing — the alternate Victorian world is not
just "Victorian-ish with airships" but a world whose
specific differences from actual history have specific
political, economic, social, and technological consequences.

The discipline:

- **Specific divergence point** — the manuscript should be
  able to identify where its world diverged from actual
  history. Babbage's Difference Engine actually built and
  deployed (Gibson / Sterling's premise); a specific
  technological discovery made earlier or differently;
  a specific historical figure's different choice;
  a specific political event resolved differently.
  Generic "alternate Victorian" without specific divergence
  is the failure mode.
- **Cascading consequences** — the divergence's specific
  effects radiate. If the Difference Engine works, the
  information economy of the period changes; if airships
  are practical commercial transport, geography and trade
  routes change; if a specific colonial event went
  differently, the political map differs. The reader
  should be able to feel the ripple effects across the
  alternate world.
- **Plausible technology** — steampunk's machinery should
  operate by plausible mechanical logic even when its
  historical premise is fictional. Steam-powered automata
  can plausibly do specific things (computation, repetitive
  task) within actual physics; they cannot plausibly do
  arbitrary things the writer wants. The form's technical
  reader notices when machinery violates its own
  established mechanical logic.
- **Acknowledgement of inheritance** — the form's strongest
  contemporary practitioners acknowledge that they are
  building on a Victorian / Edwardian aesthetic whose
  actual political reality included specific colonial
  violence, specific gendered constraint, specific class
  exploitation, specific racial hierarchy. The alternate-
  history premise need not preserve all these
  specifics, but the manuscript's choices about what to
  preserve and what to alter should be deliberate and
  visible.

The discipline's failure mode: the alternate-history that
operates as Victorian costume drama with technology
sprinkled in. The strongest steampunk operates as
genuinely speculative fiction that takes its alternate-
history premise seriously and follows its consequences.

Test: identify the manuscript's primary divergence point
and trace its three most significant consequences in the
alternate world. If the divergence is gestured at without
specific cascading effects, the discipline has not been
deployed.

### The Decolonial Reckoning

Contemporary steampunk has a particular cultural concern
the form's earlier generation did not always engage with:
the Victorian / Edwardian period the form aestheticises was
the era of British imperial peak, with specific colonial
violence underwriting the industrial wonders the form
celebrates. The cotton in the airship's gasbag came from
specific plantations operated by specific exploited
labour; the rubber in the new pneumatic systems came from
specific Congo extraction; the tea in the inventor's cup
came from specific Indian plantations operated under
specific colonial economic structures.

Contemporary steampunk practice acknowledges this without
becoming didactic. The form's strongest contemporary
practitioners (P. Djèlí Clark on Cairo / Egyptian-context
steampunk; Ken Liu on silkpunk's specifically-non-
Eurocentric premise; Tasha Suri on colonial-era diverse
register; the broader contemporary diverse-perspective
movement in the form) engage with the era's actual
political reality rather than rendering a sanitised
Victorian dreamspace.

The technique requires that the manuscript's choices about
who appears, who has agency, and whose perspective shapes
the prose are deliberate. A steampunk set in 1880s London
with no characters of colour, no servants with interiority,
no colonial subjects with voice has chosen — by absence —
to render the Victorian-aesthetic dreamspace rather than the
actual Victorian world. That choice may be deliberate
(homage; specific narrative reasons), but it should be
conscious, not default.

The technique extends to engagement rather than
acknowledgement. Including a colonial subject as a minor
character whose interior is never accessed is gestural; the
strongest contemporary steampunk gives historically-
positioned characters full novelistic interiority and
agency. Test: identify the manuscript's significant
characters and audit demographic and geopolitical
composition. If the cast operates within Victorian-aesthetic
default (predominantly white-British; servants without
voice; colonial subjects absent or reduced to background),
the inherited-default register is operating. The fix is not
tokenism — it is the deliberate rendering of the alternate-
period's actual political and demographic complexity.

## Genre-Specific Revision Rules

Six revision passes specific to steampunk, each with a focused
question, run cover-to-cover before the next begins. Steampunk
revision must hold the form's signature contracts: machine
presence (technology experienced rather than described); period
authenticity (period voice without parody); wonder-cost
balance (the form's central tension); class engagement (the
era's actual social structure rendered); exposition control
(worldbuilding through action not lecture); and the alternate-
history + decolonial-reckoning audits that distinguish craft
steampunk from cosmetic steampunk. The passes below are
ordered to surface machine and period failures first (the
form's most-felt by genre readers), wonder-cost and class
audits next, exposition and integration audits last.

### Pass 1: Machine Presence Check

Verify at least one significant interaction with technology
per chapter. Steampunk's structural register requires
continuous machine presence; chapters that abandon the
technology have shifted out of register. Build a machine
ledger: each chapter's significant technological encounter,
with verification that the machine is operating in scene
rather than gestured at as setting.

Verify machines are described through sensation, not
specification. The Machine in Motion technique requires
that machinery be experienced through at least three senses
(sight, sound, smell, touch, occasionally taste); generic
"steam-powered" or "clockwork" descriptions without specific
sensory rendering are the failure mode. Test: pick three
significant machine moments and verify each operates
through specific multi-sensory detail.

Verify technology has visible function — no decorative
gears or purposeless brass. The form's most-flagged failure
mode is decorative-aesthetic steampunk where machinery
exists as visual interest without operational logic. Each
significant machine should do something specific that the
prose makes visible; if the gear's function cannot be
named, the gear is decoration.

### Pass 2: Period Authenticity Check

Verify the voice evokes the period without lapsing into
parody or modern register. The Period Immersion Without
Parody technique provides the calibration: period-evocative
but readable, with specific attention to vocabulary, sentence
structure, and registers of speech that signal the era
without descending into "my dear Lord Pemberton" pastiche.
Read three dialogue exchanges aloud and listen for slippage
into either modern colloquialism ("look, I don't care
about your class issues") or pastiche-Victorian.

Verify social constraints are present and felt. The
Victorian / Edwardian period operated under specific class,
gender, and propriety constraints; the form's strongest
practice makes these constraints operate functionally on
characters' available choices rather than gesturing at them
as period-flavour. The female inventor in 1880s London
faces specific institutional barriers; the working-class
character cannot enter specific spaces; the colonial subject
in the metropole faces specific rendering. Generic "the
period was constrained" without specific operational
constraint on specific characters is the failure mode.

Verify setting details are specific and sensory, not
generic "Victorian streets". The form's strongest period
texture comes from specific neighbourhood, specific kind of
gas-lit street, specific kind of rain, specific kind of
fog at specific time of day, specific architectural detail,
specific transport mode at this specific historical moment.
Generic-Victorian-London is the failure mode; specific named
place with specific period-and-place texture is the technique.

### Pass 3: Wonder-Cost Balance Check

Verify technological marvels are present — the reader feels
the excitement of invention. Steampunk's first contract is
wonder; manuscripts that lose the form's signature
excitement at machinery have slipped into adjacent
historical register. Each significant technological encounter
should produce specific wonder in the protagonist (and
through them, the reader) that the prose registers.

Verify costs are visible — pollution, exploitation, danger,
social disruption. The Wonder-Cost Seesaw technique
requires that every wonder come with specific cost; manu-
scripts that render the era's industrial wonder without
its specific industrial cost have produced uncritical-
Victorian-nostalgia, which contemporary steampunk practice
specifically excludes.

Verify neither wonder nor cost dominates. The form's
distinctive emotional weight comes from holding both
simultaneously: the airship is magnificent AND the hydrogen
is one spark from explosion; the automaton is brilliant AND
the children who assemble its gears go blind by twenty.
Manuscripts that tilt entirely to wonder produce gee-whiz
gadgetry; manuscripts that tilt entirely to cost produce
Victorian-era despair without the form's signature
imaginative pleasure.

Test: pair each significant technological encounter in the
manuscript with its specific cost. If the pairing is
absent or generic, the seesaw has not been deployed.

### Pass 4: Class Engagement Check

Verify characters from different classes appear or are
referenced. Steampunk's distinctive social register includes
multiple class positions; the form's failure mode is the
single-class manuscript (typically aristocratic-or-
inventor-class) where servants exist as background, workers
appear only as victims of machinery, and colonial subjects
are absent. The strongest steampunk includes characters
from the era's actual class spectrum with specific
interiority for each.

Verify social position affects what characters can do, where
they can go, who they can speak to. The Class Lens technique
requires that class operate functionally rather than
decoratively. The aristocratic protagonist's available
movements differ from the working-class protagonist's
available movements; the prose should render the
difference. Manuscripts where class appears but doesn't
constrain are operating at decorative level.

Verify the class implications of technology are addressed.
Who benefits from this invention; who is harmed; whose
labour produced it; whose body bears the cost of operating
it. The form's strongest practitioners track these
implications across the manuscript, with the technology's
political and economic consequences operating as ongoing
narrative material rather than gesture.

### Pass 5: Exposition Control Check

Verify technology is shown in use, not explained in
lectures. Steampunk's worldbuilding density risk is
significant; the form requires that the alternate-historical
world's specific particulars be conveyed through scene
rather than narrator exposition. The chapter that pauses
to explain how the Difference Engine works has produced an
exposition lump; the chapter that shows the protagonist
operating the Engine, with its specific quirks and limits
becoming visible through use, is operating within the form.

Verify world-building is woven into action and character,
not delivered in blocks. The discovery protocol from fantasy
applies: the protagonist encounters specific world detail,
works with it imperfectly, and the reader absorbs the world
through the protagonist's specific working-it-out. Generic
exposition paragraphs that tell the reader about the
alternate world's politics / economics / technology are the
failure mode; specific embedded detail through scene is
the technique.

Verify period details emerge naturally from the scene, not
from narrator asides. The narrator who pauses to explain
that women in this period had specific constraints has
produced a textbook moment; the prose that shows the
specific constraint operating in this specific scene
through specific behaviour is operating within the form.
Test: pick three significant exposition moments and ask, in
each, whether the information arrives through scene-action
or through narrator commentary. If commentary, the control
has slipped.

### Pass 6: Alternate-History + Decolonial-Reckoning Integration Audit

Run a final integrative pass on the manuscript's specificity
and political reckoning. Two related sub-audits:

**Alternate-history specificity.** The Alternate-History
Discipline technique requires that the manuscript's
divergence from actual history be specific, traceable, and
load-bearing. Audit: can the writer identify the specific
divergence point and trace its specific cascading
consequences? Generic "alternate Victorian" without
specific divergence is the failure mode; specific divergence
with specific ripple effects is the technique. Verify also
that machinery operates by plausible mechanical logic even
when its premise is fictional; arbitrary technology that
does whatever the writer needs is the failure mode.

**Decolonial reckoning.** The Decolonial Reckoning technique
addresses contemporary steampunk's relationship to the
Victorian / Edwardian era's actual colonial reality. Audit:
does the manuscript engage with the era's actual political
context, or does it render a sanitised Victorian dreamspace?
Are characters of colour, working-class characters with
interiority, and colonial subjects with voice present and
rendered with full novelistic depth? The pass is not asking
the manuscript to be didactic about colonial history; it
is asking the manuscript to know what it is doing — to
make deliberate choices about what to include, what to
acknowledge, and what to render rather than defaulting to
inherited Victorian-aesthetic conventions that elide the
era's actual political reality.

Comp examples for contemporary practice: P. Djèlí Clark
on Cairo / Egyptian-context steampunk; Ken Liu on silkpunk's
specifically-non-Eurocentric premise; Tasha Suri on
colonial-era diverse register; the broader contemporary
diverse-perspective movement in the form. Manuscripts that
operate within Victorian-aesthetic default
(predominantly-white-British; servants without voice;
colonial subjects absent or background-only) have chosen,
by absence, to render the inherited dreamspace rather than
the actual alternate-history-and-its-actual-political
reality.

Test: identify three demographic / political / historical
choices in the manuscript and ask, for each, whether the
choice was deliberate and whether the rendering operates
with depth or with default. If choices are default and
renderings are stereotypical, the inherited-default register
is operating; if choices are deliberate and renderings are
specific, the form's contemporary practice is being
honoured.

## Names & Patterns to Avoid

### Steampunk Character Names. NEVER USE
- Over-the-top Victorian names: Bartholomew Q. Cogsworth, Lady Brassingworth, Professor Steamington
- Pun names: Gears McGearface, Penny Farthing, Art E. Ficial
- Names that describe their role: Inventor Smith, Captain Courage, Dr. Brilliant
- Names from famous Victorian works without transformation: Twist, Copperfield, Holmes

### Steampunk Place Names. NEVER USE
- "[Material] + [Feature]": Brasstown, Copperville, Irongate District
- Obvious steampunk compounds: Gearford, Steamhaven, Clockwork Quarter
- Real London locations used as if the reader's never heard of them (if using real London, get the geography right)

### Use Instead
- Period-appropriate names from census records and naming conventions of the era
- Place names with historical feel: named after real trades, landmarks, or geography
- Fictional cities with their own identity (not "London but with more gears")
- Workshop and pub names that feel organic: "The Brass Compass", "Whitfield & Son, Machinists"

## Comp Titles

Steampunk's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Difference Engine* — William Gibson & Bruce Sterling (1990): the steampunk founding text.
- *Perdido Street Station* — China Miéville (2000): New Weird-steampunk crossover; the Bas-Lag novels.
- *His Dark Materials* — Philip Pullman (1995-2000): steampunk-adjacent alternate-history fantasy.

### Contemporary (current best-in-class)

- *The Anubis Gates* — Tim Powers (1983): retro-steampunk benchmark.
- *Soulless* — Gail Carriger (2009): the Parasol Protectorate; Victorian-comedy steampunk-romance.
- *The Invisible Library* — Genevieve Cogman (2014): librarian-steampunk-mystery hybrid.
- *Karen Memory* — Elizabeth Bear (2015): queer western-steampunk.
- *Everfair* — Nisi Shawl (2016): post-colonial Belgian-Congo steampunk.
- *Of Cinder and Bone* — Kyoko M. (2016): magical-steampunk with diverse cast.
- *The Glass Magician* — Caroline Stevermer (2020): contemporary steampunk-fantasy.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Grand machines in period settings: airships over London skylines, massive clockwork mechanisms, fog-shrouded industrial landscapes; dramatic and atmospheric
- **Graphic**. Intricate mechanical illustrations: cutaway diagrams, blueprint aesthetics, ornate brass and iron designs; detailed and elegant
- **Illustrated**. Period-style artwork: Victorian book illustration influence, detailed pen-and-ink or digital painting of characters amid technology; narrative and inviting
- **Typographic**. Ornate Victorian-influenced typography with mechanical embellishments: gears incorporated into letterforms, industrial motifs framing the title; refined and genre-signalling

### Genre Cover Aesthetics
- **Styles:** Grand industrial machinery, airships in dramatic skies, clockwork close-ups, fog-laden cityscapes, figures in period dress interacting with impossible technology, workshop interiors lit by gaslight and sparks, cross-section mechanical diagrams
- **Colours:** Warm brass and copper tones (the signature steampunk palette), rich sepia and umber, deep burgundy and mahogany, charcoal and gunmetal grey, accents of verdigris green (oxidised copper), amber gaslight glow, touches of midnight blue for sky and distance
- **Elements:** Gears and cogwheels (used purposefully, not decoratively), steam clouds, brass instruments and gauges, Victorian architectural details, airships and dirigibles, pocket watches and chronometers, goggles and leather, maps and navigation tools, factory smokestacks, gas lamps
- **Typography:** Ornate Victorian serif faces, industrial stencil fonts, mechanical/blueprint lettering; embossed or metallic effects; title should feel like it belongs on a Victorian broadsheet or a brass nameplate; readable at all sizes despite ornamentation

### Market Positioning
Steampunk covers must signal "Victorian ingenuity and impossible machines" instantly. The warm brass/sepia palette is the genre's visual signature. use it but find a distinctive angle. Position against Priest, Carriger, Miéville, Westerfeld, Hodder. At thumbnail size, the combination of warm metal tones, mechanical elements, and period silhouettes creates immediate genre recognition. Avoid the "goggles on a top hat" cliché unless the design elevates it.

### Cover Design DON'Ts
- No modern/digital aesthetics. everything should feel mechanical and analogue
- No random gears glued onto an otherwise generic cover (the #1 steampunk design cliché)
- No dark, gritty colour palettes that read as grimdark or horror. steampunk has WARMTH
- No characters in modern clothing with a single steampunk accessory
- No generic Victorian portraits without technological elements
- No overly busy designs where gears and pipes obscure the title or central image
