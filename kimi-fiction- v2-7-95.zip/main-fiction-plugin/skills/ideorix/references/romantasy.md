---
name: romantasy-genre
description: Genre-specific instructions for romantasy fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Romantasy. Genre Plugin

## Metadata
- id: romantasy
- name: Romantasy
- icon: 💫
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Romance Beat Sheet", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Fae Romance**. Faerie courts, bargains, glamour, morally grey fae love interests
- **Enemies-to-Lovers Fantasy**. Opposing sides, forced proximity, war and desire
- **Chosen One Romance**. Prophecy and world-saving with a central love story
- **Dark Romantasy**. Morally complex, intense power dynamics, higher spice levels
- **Court Intrigue Romance**. Political marriage, alliances, court conspiracies with romance at the core
- **Mate Bond/Fated**. Magical connection between destined partners (the bond IS the plot)

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Dual engine. plot tension and romantic tension must BOTH advance every chapter
- Must open with: Character interaction, conflict, or magical event. never with world-building exposition or internal musing about the love interest when apart

BEATS PER CHAPTER
1. Romance Beat. The central relationship advances: chemistry, tension, vulnerability, argument, or physical escalation (EVERY chapter must move the romance forward, even during plot-heavy sequences)
2. Fantasy Plot Beat. The external conflict advances: world-threatening stakes, political moves, magical discoveries, battles
3. Emotional Vulnerability. At least one moment where a character drops their guard (internally or with another character)
4. Power Dynamic Shift. The balance between the romantic leads shifts. who has leverage, who yields, who surprises
5. World Experience. A fantasy detail that enhances or mirrors the romantic dynamic

ROMANTASY ARCHITECTURE
- The romance and the fantasy plot are INSEPARABLE. they feed each other
  - The external conflict creates the conditions for the romance (forced proximity, shared danger, opposing loyalties)
  - The romance complicates the external conflict (divided loyalties, emotional vulnerability, distraction from duty)
  - The climax resolves BOTH. the romantic resolution and the plot resolution are the same scene or sequence
- POV: Single first person (dominant) or dual first person (alternating chapters)
  - If dual POV: the romantic leads must narrate different chapters, never the same scene from both
  - Each POV has a DISTINCT voice. different observations, different emotional processing
- The love interest is a FULL character with their own arc, goals, and agency. not a prize

ROMANCE ARC INTEGRATION (CRITICAL)
- The romance follows a recognizable arc that readers can FEEL progressing:
  1. **Awareness**. Physical/magical awareness of the other person
  2. **Resistance**. Reasons not to feel this (duty, history, danger, identity)
  3. **Connection**. Forced intimacy reveals the person beneath the mask
  4. **Vulnerability**. One or both characters reveal something real
  5. **Setback**. The external plot drives them apart or creates a betrayal
  6. **Choice**. They choose each other despite the cost
  7. **Union**. Physical and emotional culmination (timing depends on spice level)
  8. **Black Moment**. All seems lost for BOTH the romance and the world
  9. **Resolution**. Love enables or empowers the final triumph
- This arc must be VISIBLE to the reader. they should always know where they are in the romance

SPICE CALIBRATION
- Spice levels (0-5) set during setup apply to the entire manuscript
- The Architect assigns per-chapter spice ratings that escalate across the arc:
  - Act 1: Awareness and tension (Spice 0-2 regardless of overall level)
  - Act 2A: Building chemistry, first physical contact (Spice 1-3)
  - Act 2B: Consummation or near-miss (peak spice for the manuscript)
  - Act 3: Spice serves emotional stakes (not gratuitous. the relationship is earned)
- If overall spice is 4-5: explicit scenes are character-driven, emotional, and advance the relationship
- If overall spice is 0-2: chemistry is conveyed through proximity, dialogue, looks, and brief touch

MAGIC AND ROMANCE OVERLAP
- Magic should ENHANCE the romantic dynamic:
  - Magical bonds that create physical awareness
  - Power sharing that requires trust and vulnerability
  - Magical conflict that mirrors emotional conflict
  - Spells that reveal truth or emotion
- The magic system should create romantic OBSTACLES as well as connections
- Magical abilities should be COMPLEMENTARY between romantic leads (not identical)

FORBIDDEN IN ROMANTASY
- Romance without genuine fantasy stakes (this isn't contemporary romance with costumes)
- Fantasy without genuine romance stakes (this isn't epic fantasy with a side romance)
- Love interest who is a blank slate with no personality beyond "attractive and powerful"
- Protagonist who loses all agency in the presence of the love interest
- "Not like other girls" as character establishment
- Abusive behavior reframed as romantic (controlling, stalking, rage)
- Consent violations played for chemistry
- Romance that could be removed without affecting the plot (it must be INTEGRAL)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (worldbuilding), Affection (relationship arc), Anticipation (combined romance + quest tension).

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-agent.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE
- POV: First person past or present tense (genre standard); dual first person for two-POV
- Voice: Emotionally rich, sensually aware. the narrator notices beauty, danger, and desire in equal measure
- Tone: Lush but grounded. the prose should be immersive and atmospheric without becoming purple
- Register: Elevated for fantasy settings but emotionally immediate. the reader should FEEL everything

PROSE IMPERATIVES
- Physical awareness is CONSTANT when the romantic leads are in the same scene:
  - Not just "he was handsome" but specific physical reactions: breath catching, skin heating, awareness of proximity
  - The protagonist's body responds to the love interest before their mind accepts it
  - Physical awareness intensifies across the manuscript. early chapters: a glance; late chapters: a touch that sets them trembling
- Emotional interiority is the genre's engine. the reader must be INSIDE the protagonist's emotional experience
- Fantasy elements are sensually described: magic has texture, taste, colour, and sensation
- The world should feel romantic: not saccharine, but beautiful, dangerous, and heightened

PROSE RHYTHM MAPPING
- Chapter 1 must balance world + chemistry + stakes. the rhythm serves a dual engine from the first page
- Dual rhythm is the genre's signature: fantasy passages use medium-long sentences (18-26 words) for world-building, atmosphere, and magic; chemistry moments use shorter, sharper sentences (10-16 words) that mirror the protagonist's heightened physical awareness
- The SHIFT between these rhythms is a tool: when the love interest enters a scene, sentence length should subtly compress. the protagonist's attention narrows, and the prose reflects it
- Opening paragraphs: establish the fantasy world's rhythm first (medium-long, atmospheric), then introduce the romantic element with a rhythmic disruption. a shorter sentence, a catch of breath
- Chemistry scenes: sentences shorten when physical awareness spikes. "He was close. Too close. She could feel the heat of him." This staccato signals attraction the character hasn't yet acknowledged
- World-building passages: longer, more flowing sentences that establish the world's beauty and danger. These should feel lush but controlled. romantic without being purple
- Action/battle scenes: short and kinetic (8-14 words), but with moments where awareness of the love interest intrudes. a slightly longer sentence amid the combat rhythm that reveals the protagonist's divided attention
- Emotional interiority: medium rhythm (14-20 words), intimate and immediate. The reader is inside the feeling, not observing it
- Banter and charged dialogue: quick exchanges. Short sentences that volley. The rhythm accelerates when the romantic leads spar verbally
- Vulnerability moments: sentences slow and lengthen (18-24 words). when a character drops their guard, the prose opens up, becomes more exposed
- Tension baseline: ≥5 from the first page. In romantasy, tension is DUAL. both the world's danger and the romantic pull must be active
- Balance is critical: no more than 2 consecutive paragraphs of pure world-building without a chemistry beat; no more than 2 consecutive paragraphs of pure romance without a fantasy-stakes beat
- The paragraph of first physical awareness: rhythm should be distinctive. a longer atmospheric sentence followed by a short, sharp physical reaction. This pattern recurs with increasing intensity
- End-of-chapter rhythm: either a fantasy-stakes pull (medium-fast, forward-driving) or a romantic-tension pull (one devastating short sentence that lingers). alternate across chapters
- Read chemistry scenes aloud. the rhythm should feel like a quickened heartbeat. If it doesn't accelerate naturally, tighten the sentences
- Avoid uniform rhythm across an entire chapter. the power of romantasy prose comes from the CONTRAST between its two modes. If every sentence is the same length, neither engine is firing
- The goal: prose that makes the reader feel both the sweep of a fantasy world and the visceral pull of attraction. two rhythms braided into one irresistible forward momentum

CHEMISTRY CRAFT (CRITICAL)
- Chemistry is built through SPECIFIC interactions, not narrated attraction
- The 5 Chemistry Tools:
  1. **Banter**. Sharp, intelligent, revealing dialogue where both characters are fully present
  2. **Proximity**. Physical closeness that neither can fully control (training together, shared quarters, healing touch)
  3. **Vulnerability**. Moments where the mask drops and the real person is visible
  4. **Competence**. Seeing the other person be excellent at something; respect as an aphrodisiac
  5. **Sacrifice**. Small or large acts that prove the other person MATTERS
- Each chemistry scene should use at least 2 of these tools
- Chemistry builds through ACCUMULATION. it's not one scene, it's twenty small moments

SPICE WRITING (when applicable)
- Intimate scenes are CHARACTER-driven: they reveal personality, power dynamics, vulnerability
- The emotional context matters MORE than the physical act
- Use the character's VOICE. a bookish protagonist describes intimacy differently from a warrior
- Anticipation and aftermath are as important as the act itself
- Consent is explicit and SEXY (characters who ask are attractive, not mood-killing)
- Physical description is specific but not clinical. sensation over anatomy
- If the scene could belong to any two characters, it's not good enough. it must be THESE two people

DIALOGUE CRAFT
- Romantic dialogue crackles with subtext: what they're saying vs what they mean
- Arguments between romantic leads should feel charged. anger and attraction coexist
- Terms of address shift across the arc: formal titles → first names → endearments → private names
- The love interest's dialogue reveals depth gradually. early mystery, later vulnerability
- Wit and intelligence in dialogue are romantic. smart people falling for each other's minds

FANTASY WORLD PROSE
- World-building should feel ROMANTIC: beautiful and dangerous, magical and sensual
- Court scenes combine political tension with personal chemistry
- Battle and danger heighten emotional stakes. near-death creates emotional honesty
- Magic described through sensation, not mechanics (unless hard magic system)
- Clothing, architecture, and ritual should be lush and specific
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

ROMANCE CRAFT (40% of total):
- Chemistry builds through specific interactions (not narrated)? (0-100)
- Romantic arc progresses visibly chapter to chapter? (0-100)
- Both romantic leads are fully realized characters? (0-100)
- Emotional vulnerability is earned and authentic? (0-100)

FANTASY INTEGRATION (30% of total):
- Romance and plot are genuinely inseparable? (0-100)
- Magic system enhances the romantic dynamic? (0-100)
- World-building delivered through experience, not exposition? (0-100)
- Stakes are real for both the world and the relationship? (0-100)

PROSE QUALITY (30% of total):
- Physical awareness and chemistry are effectively conveyed? (0-100)
- Emotional interiority is rich and authentic? (0-100)
- Dialogue crackles with subtext and wit? (0-100)
- Sensory detail creates immersion? (0-100)

AUTOMATIC FAILS (score = 0):
- Romance could be removed without affecting the plot
- Love interest has no personality, goals, or arc beyond being attractive
- Protagonist loses all agency around the love interest
- Abusive behavior presented as romantic
- Consent violation played for chemistry
- No genuine fantasy stakes (costumes + contemporary romance)
- Exposition dumps about world-building or magical lore
- Spice scenes that are generic and could belong to any characters
```

## Continuity Rules

```
ROMANTASY CONTINUITY. WHAT TO TRACK

ROMANCE PROGRESSION (CRITICAL):
- Physical escalation: what have they done, when, and how it changed things
- Emotional milestones: first vulnerability, first trust, first betrayal, first "I love you"
- Terms of address: track the shift from formal to familiar
- Pet names or private references: once established, use consistently
- Physical awareness level: early chapters have less; it must escalate, not plateau
- Arguments and reconciliations: track what was said, what was forgiven, what festers

MAGIC SYSTEM:
- All magical rules, costs, and limitations
- How magic interacts with the romantic bond (if magical bond exists)
- Power levels of both romantic leads
- Any magical limitations on the relationship

POWER DYNAMICS:
- Who has political/magical/social power at each story point
- How the power balance shifts between romantic leads
- External forces that threaten the relationship
- Secrets: who knows what, and how will revelation change things

FANTASY WORLD:
- Political alliances and their bearing on the romance
- Cultural rules about relationships (are they forbidden? required? complicated?)
- Geography and travel times
- Magical objects, prophecies, or bonds affecting the couple

PHYSICAL CONTINUITY:
- Character appearances: both romantic leads should be specifically described and consistent
- Injuries and scars (especially meaningful ones from protecting each other)
- Clothing and adornment (romantasy readers notice these details)
- Sensory details associated with each character (scent, warmth, texture)
```

## Character Rules

```
ROMANTASY CHARACTER REQUIREMENTS

THE PROTAGONIST:
- Has their own GOALS independent of the love interest (duty, survival, discovery, vengeance)
- Competent in their own right. they bring something to the table
- Has a reason to RESIST the romance (loyalty, fear, practical danger, identity)
- Their growth across the story is personal, not just relational
- Flawed in specific ways: stubbornness, trust issues, self-sacrifice, pride
- Their internal monologue is engaging, witty, and occasionally wrong about the love interest

THE LOVE INTEREST:
- FULL character with their own arc, goals, fears, and growth
- Their mystery unravels gradually. layers, not a wall
- Competent and dangerous (competence is romantic)
- Vulnerable in ways they only show the protagonist
- Has a specific reason for their initial resistance to the romance
- Their behaviour must be consistently romantic, not intermittently abusive
- If "morally grey": their grey areas are specific, understandable, and NOT directed at the protagonist's wellbeing

THE RIVAL/COMPLICATION (if present):
- Not cartoonishly awful. they must be a genuine contender or complication
- Their relationship with either romantic lead is plausible
- They serve the plot, not just the romance (political alliance, magical necessity)
- The protagonist's choice of their true love interest must feel EARNED, not inevitable

SECONDARY CHARACTERS:
- A confidant for the protagonist (friend, sibling, mentor) who provides perspective on the romance
- Political allies and enemies who complicate the romantic dynamic
- Characters who have their own love stories (briefly; the main romance takes priority)

VOICE DIFFERENTIATION:
- If dual POV: the two narrators must sound COMPLETELY different
  - Different vocabulary, different priorities, different ways of processing emotion
  - One might be wry and internal; the other direct and physical
  - Their observations of the SAME events highlight different details
- All characters should be identifiable by dialogue alone
```

## Arc Rules

```
ROMANTASY DUAL-ARC STRUCTURE

ACT 1: COLLISION (first 25%)
- Establish protagonist in their world: duty, obligation, or crisis
- The romantic leads MEET (or re-meet) under circumstances that create friction
- Physical awareness is immediate but unwelcome
- The external conflict is established: war, political crisis, magical threat
- The romance obstacle is established: they're on opposite sides, it's forbidden, it's dangerous
- Early banter and friction establish chemistry
- END OF ACT 1: Forced proximity or shared purpose throws them together

ACT 2A: RESISTANCE AND CONNECTION (to midpoint)
- The romantic leads are together but fighting it
- Chemistry builds through proximity, banter, and shared danger
- Glimpses of vulnerability: cracks in the armour
- The external plot creates situations that force trust
- The first significant physical contact (hand grab, healing touch, training spar)
- MIDPOINT: First kiss or equivalent emotional milestone. AND a plot revelation that changes everything

ACT 2B: DEEPENING AND CRISIS (midpoint to dark moment)
- The romance deepens: vulnerability, trust, physical intimacy escalates
- The external threat becomes more dangerous BECAUSE of the romance (enemies exploit the attachment)
- Secrets begin to surface
- The protagonist faces a choice between duty and desire
- Spice escalation (if applicable). peak physical intimacy
- ROMANTIC BLACK MOMENT: Betrayal, revelation, or forced separation
  - This must be EARNED. the reader should understand why it happened
  - The pain must be real. it feels like the romance is truly over
  - It's connected to the external plot (not a manufactured misunderstanding)

ACT 3: CHOICE AND UNION (final 25%)
- Separation and individual reckoning
- Both romantic leads must grow SEPARATELY before they can come together
- The external climax requires BOTH of them (together or in complementary roles)
- The romantic reunion happens in the context of the climactic conflict
- They CHOOSE each other despite the cost. this choice must mean something
- The resolution proves that together they are more than they are apart
- HEA (Happily Ever After) or HFN (Happy For Now). this is NON-NEGOTIABLE for romantasy
  - The romance MUST resolve positively
  - The couple must be together at the end
  - For series: HFN is acceptable with clear forward momentum

DUAL-ARC SYNCHRONIZATION:
| Story Point | Plot Arc | Romance Arc |
|------------|----------|-------------|
| Inciting Incident | External threat appears | Romantic leads meet/collide |
| Act 1 Turn | Protagonist committed to fight | Forced proximity begins |
| Midpoint | Plot revelation | First kiss / emotional milestone |
| Act 2B Crisis | Military/political defeat | Romantic betrayal or separation |
| Dark Moment | All seems lost | The relationship seems destroyed |
| Climax | Final battle/confrontation | Romantic reunion enables victory |
| Resolution | World saved/changed | Couple together, HEA/HFN |
```

## Timeline Rules

```
ROMANTASY TIMELINE

ROMANCE PACING:
- First awareness: Chapter 1-3
- First banter/friction: Chapter 2-5
- First forced proximity: By Act 1 turn
- First physical contact (non-combat): By 30%
- First kiss: 40-55% (midpoint area)
- First explicit scene (if applicable): 55-75%
- Black moment/separation: 70-80%
- Reunion: 85-90%
- HEA/HFN: Final chapters

ESCALATION TIMELINE:
- Physical awareness MUST escalate, never plateau for more than 2 chapters
- After first kiss: scenes of proximity should have heightened tension
- After first explicit scene: emotional vulnerability should deepen
- Post-black-moment: the absence of the other person should be physically felt

FANTASY TIMELINE:
- Track standard fantasy timeline elements (travel, seasons, political events)
- The fantasy timeline should CREATE romantic opportunities (forced travel together, diplomatic events, shared combat)
- Magical events can affect the romance (bond strengthening, prophetic visions, magical jealousy)
```

## Genre-Specific Craft Techniques

Romantasy is the fastest-growing market segment in commercial
romance and the most demanding hybrid in the form. Its readers
have arrived from two directions — fantasy readers who want
emotional centrality the genre's traditional gatekeepers
denied them, romance readers who want world-building scale the
contemporary register cannot provide — and they have brought
both genres' standards with them. The bar is high in both
directions: the magic system must be coherent enough that a
fantasy reader takes it seriously; the romance must be felt
deeply enough that a romance reader closes the book having
been emotionally satisfied. The current commercial leaders
(Sarah J. Maas's *A Court of Thorns and Roses* and *Throne of
Glass*; Rebecca Yarros's *Fourth Wing*; Jennifer L. Armentrout;
Carissa Broadbent; Raven Kennedy; Holly Black for the upper-YA
crossover; Stephanie Garber on the soft-magic end; Elise Kova;
Jennifer Estep; Rachel Gillig; Olivie Blake) have established
craft standards that newer entrants must meet. The techniques
below are how the dual contract is delivered without slipping
into the genre's failure modes (fantasy-with-decorative-romance
that disappoints romance readers; romance-with-decorative-
magic that disappoints fantasy readers; or wallpaper hybrid
where both genres are gestured at without being committed to).

### The Dual-Engine System

Romantasy runs on TWO engines that must fire in every chapter.
Single-engine chapters break the genre contract immediately —
fantasy-only chapters read as fantasy novel that lost its
romance plot; romance-only chapters read as the writer
abandoning the world for a few pages of intimacy. The reader
came for both and expects both, sustained, alongside each
other.

**Engine 1: Fantasy Stakes**
- What threatens the world / kingdom / characters?
- What moved forward in the external plot?
- What new obstacle or complication appeared?

**Engine 2: Romantic Stakes**
- What changed between the romantic leads?
- What new chemistry moment occurred?
- What new obstacle to the romance appeared?

**The Check:** After writing each chapter, verify both engines
are running. If a chapter is ALL fantasy with no romantic
progression, add a chemistry moment. If ALL romance with no
plot advancement, add a fantasy complication. The strongest
romantasy further demands that the engines drive each other:
the fantasy event causes the chemistry moment; the chemistry
moment alters the fantasy plot. Mere coexistence (both engines
running but in separate scenes) is the form's middle-tier
craft; integration (each engine's beat is also the other's
beat) is the upper tier.

### The Tension Ratchet

Romantic tension must escalate across the manuscript through a
specific toolkit of escalation moves, not through narrator
assertion that things are getting more intense. The tools are
calibrated, sequential, and used in deliberate rotation rather
than at random:

1. **Physical proximity** — they are physically close and
   aware of each other's body
2. **Interrupted moments** — they almost touch / kiss / confess
   but something interrupts (the fantasy plot's signature
   contribution to the genre's tension architecture)
3. **Charged silence** — they're alone together and NOT
   talking about the tension
4. **Jealousy or possessiveness** — another character creates
   awareness of what they might lose
5. **After-action vulnerability** — post-battle, post-escape,
   the adrenaline makes them honest in ways daylight would not
   permit
6. **Caretaking** — one tends the other's wounds, creating
   enforced intimacy that crosses the genre's standard
   physical-distance rules

Use at least 2-3 per chapter in Act 2, escalating from mild
(glances, proximity, the awareness of breath) through middle
(interrupted moments, charged silence, jealousy) to intense
(near-kisses, confessions, the first explicit scene that
follows the genre's chosen spice tier). The technique requires
deliberate rotation — using the same tool five times in a row
flattens the ratchet — and deliberate placement: peak tools
should land at chapter ends, scene ends, and at the structural
beats the architecture has set up for them. Test: chart every
tension-escalation move in the manuscript and ask whether the
deployed sequence reads as gradient or as random.

### Dual-Arc Integration Rules

The fantasy plot and romance plot must INTERFERE with each
other, not just coexist. This is the single largest craft
difference between romantasy and fantasy-with-romance-subplot:
in romantasy, every fantasy decision is shaped by the romance,
and every romance decision is shaped by the fantasy.

**The Integration Test (run per chapter):**
- "If I removed the love interest from this chapter, would the
  fantasy plot work exactly the same?" → If yes, the romance
  isn't integrated.
- "If I removed the fantasy crisis from this chapter, would the
  romantic development work exactly the same?" → If yes, the
  fantasy isn't integrated.

**How fantasy complicates romance:**
- Political allegiance → attraction is betrayal
- Magic system → forced proximity, involuntary connection,
  dangerous vulnerability (the bond that strengthens with
  proximity; the magic that surfaces under emotional pressure;
  the prophecy that names them)
- War / conflict → every moment on romance is a moment not
  saving lives
- Court intrigue → public affection is political weapon;
  private affection is liability
- Quest / mission → must work together while unable to trust
  each other

**How romance complicates fantasy:**
- Growing trust → sharing information they shouldn't,
  weakening strategic position
- Vulnerability → caring about someone gives enemies leverage
- Shifting loyalty → decisions to protect the other instead of
  serving the mission
- After The Turn → every strategic decision is compromised by
  acknowledged feelings

The integration is the genre's deepest craft pleasure when
operating; it is the most-flagged failure when not. Test:
read three chapters spaced across the book and ask, in each,
whether each engine's beat is also (or causes) the other
engine's beat.

### The 60% Rule (Enemies / Rivals / Forbidden Tropes)

For enemies-to-lovers, rivals-to-lovers, or forbidden-romance
tropes — the genre's three commercially dominant configurations
— the antagonism or barrier must be GENUINE and SUSTAINED for
at least 60% of the manuscript. The rule reflects a hard-
earned market truth: romantasy readers identify "fake enemies"
within the first three chapters and lose investment for the
remainder of the book.

**What genuine antagonism looks like:**
- They disagree about real things — values, methods,
  allegiances, what's worth sacrificing
- Conflict rooted in who they ARE, not in misunderstanding
- Both have legitimate reasons for their position
- Moments of connection feel like betrayals of their own
  principles

**What fake antagonism looks like (AVOID):**
- Bickering that's obviously just flirting
- Conflict based on a misunderstanding one honest conversation
  could fix
- One is clearly wrong and just needs to come around
- "Enemies" part lasts 3 chapters before secret pining
- Arguing in public and making out in private by chapter 6

**Backslide triggers** (after every moment of closeness, at
least ONE must pull apart):
- External threat (discovered, attacked, duty calls)
- Internal fear (too close, too fast, can't trust this)
- New information reframing the other person (a secret, a past
  action, loyalty conflict)
- Fantasy plot demands opposing actions from them
- Third party complication (rival, obligation, ally who
  questions the connection)

The 60% threshold is not arbitrary — it correlates with the
genre's structural beat (The Turn) and with reader-survey data
on the point at which "they should be together by now" anxiety
overwhelms reading pleasure. Books that resolve antagonism
before 60% read as having abandoned the trope they marketed;
books that maintain it past 75% read as withholding a pleasure
the reader has earned.

### The Turn Architecture

"The Turn" (~60% mark) is the moment the romantic dynamic
fundamentally shifts. It is the genre's signature structural
beat and the most-misunderstood by writers approaching from
adjacent forms.

**What The Turn is NOT:**
- A dramatic confession
- A single switch-flip event
- A scene that resolves the tension
- An external declaration

**What The Turn IS:**
- A private, internal realisation, often unspoken
- Triggered by a fantasy plot event (specifically — the genre's
  rule is that fantasy stakes precipitate the romantic
  recognition)
- The moment the character knows they're in trouble — this
  isn't just attraction any more
- A scene that creates MORE tension, not less, because now they
  cannot pretend
- The moment after which the protagonist's strategic decisions
  are compromised in ways the reader can track

The Turn must occur on the page (not summarised across a
chapter break) and must be witnessed by the POV character's
interior even when not articulated by their dialogue. Test:
locate The Turn in the manuscript. Is it on the page, in
scene? Is it triggered by a fantasy event rather than a purely
romantic one? Does tension increase rather than decrease in
the chapters immediately following? If any answer is no, The
Turn has not been correctly placed and the back half of the
book will read as winding down rather than escalating.

### The Slow-Burn Mathematics

Romantasy's pacing is structurally slower than contemporary
romance, and the slow burn is part of what readers have
specifically come for. The genre's commercial leaders run
roughly the following intimacy curve in a 400–500 page book:

- **Chapters 1-5 (10-15%):** Initial encounter, hostile
  attraction, the first sustained scene of physical awareness
  that neither protagonist is ready to name. No physical
  contact beyond accidental.
- **Chapters 6-12 (15-30%):** Forced proximity is established
  (mission, captivity, school, court placement); the tension
  ratchet's mild tools deploy regularly. First deliberate
  physical contact (typically incidental — a hand caught while
  steadying, the brief touch in a sword-training scene); first
  charged silence.
- **Chapters 13-20 (30-50%):** Tension ratchet's middle tools
  deploy. The first interrupted moment lands somewhere in this
  zone, typically chapter 14-17. Backslides intensify. The
  protagonists begin to acknowledge, internally, what they are
  refusing to acknowledge externally.
- **Chapters 21-26 (50-65%):** The Turn occurs in this window,
  triggered by a fantasy event. The first kiss often follows
  the Turn within 1-3 chapters. This is the genre's most-paced
  zone — too fast and the slow-burn contract has been broken;
  too slow and the reader has waited beyond their patience.
- **Chapters 27-32 (65-80%):** First explicit scene if the
  spice tier supports it. The relationship is now operating
  but is under maximum strain from the fantasy plot. Major
  fantasy crisis lands in this window.
- **Chapters 33-40+ (80-100%):** The fantasy climax and the
  romantic resolution converge. The HEA / HFN is delivered in
  the final chapter or epilogue, after the fantasy resolution
  has paid out.

The mathematics are calibrated to reader expectation; the
genre's failure modes cluster at points of deviation. First-
kiss-in-chapter-five mis-genres the book into contemporary
paranormal romance and loses the romantasy reader; first-kiss-
in-chapter-thirty-five exhausts the reader's patience before
delivery. Test: chart every romantic milestone in the
manuscript against the percentage of the book at which it
occurs. The curve should resemble the genre's expected pacing,
with deliberate variation rather than accident.

### Romantasy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "Something about [them] drew me..." | Name the specific thing |
| "I couldn't explain the pull I felt" | Show the pull through physical reaction |
| "Electricity crackled between us" | Find a fresh image for THIS couple |
| "Their eyes darkened" | Describe what the POV character actually sees |
| "Something shifted between us" | Show what shifted. a gesture, a word, a silence |
| "Ancient power thrummed through..." | What does THIS magic feel like to THIS character? |
| "His/her presence filled the room" | Through whose senses? What specifically? |
| "A dangerous smile" (more than once) | Describe the actual smile. What makes it dangerous? |
| "Shadows danced in his/her eyes" | What is the POV character seeing? A flicker? A stillness? |
| "The bond hummed/pulsed/sang" | What does it physically feel like? Where in the body? |
| "Power rolled off them in waves" | What does the POV character perceive? Heat? Static? |
| "My magic recognised theirs" | How? What's the sensation? Be specific. |
| "He/she let out a breath they didn't know they were holding" | Delete. Every time. |
| "A smirk played on his/her lips" | Describe the actual expression |
| "His magic was unlike anything I'd ever felt" | Show the specific magical sensation through the POV's body |
| "Their gazes locked" | Show what each is doing with their face, what each is registering |
| "A silence stretched between them" | What is each hearing, looking at, holding back from saying? |
| "He was carved from stone" / "She was made of fire" | Sculptural / elemental shorthand for "I have not characterised this person"; replace with specific behaviour |

## Genre-Specific Revision Rules

Six revision passes specific to romantasy, each with a single
question, run cover-to-cover before the next begins. Romantasy
revision must hold both genres' standards simultaneously: the
fantasy reader's tolerance for magic-system inconsistency is
nil; the romance reader's tolerance for unfelt emotional beats
is nil. The passes below are ordered to surface the structural
integration failures first (Pass 1, the genre's signature
audit), the fantasy-craft failures next (magic system,
worldbuilding density), then the romance-craft failures
(spice, character, consent), and the trope-discipline failures
last when the rest of the book is stable enough to support
the question.

### Pass 1: Romantasy Audit (Run FIRST in editorial pipeline)

For EVERY chapter, verify:

1. **Dual-Engine Check**
   - Both romance and fantasy plot advance in every chapter
   - Romance could NOT be removed without breaking the plot
   - Fantasy plot could NOT be removed without breaking the romance

2. **Chemistry Audit**
   - Chemistry is SHOWN through interaction, not told through narration
   - At least 2 chemistry tools per scene with both romantic leads
   - Physical awareness escalates across the manuscript
   - Banter is sharp and character-specific (not generic flirting)

3. **Love Interest Audit**
   - The love interest has goals, fears, and growth independent of the protagonist
   - Their behavior is consistently characterised (not randomly hot/cold)
   - "Morally grey" traits are specific and comprehensible
   - No abusive behavior framed as romantic

4. **Spice Calibration**
   - Intimate scenes match the assigned spice level
   - Emotional context is present (not just physical)
   - Scenes are character-specific (could only be THESE two people)
   - Consent is clear and not mood-killing

5. **HEA/HFN Guarantee**
   - The romance resolves positively
   - The couple is together at the end
   - The resolution feels earned, not rushed

6. **Arc Integration Check**
   - For each chapter: if the love interest were removed, would the fantasy plot
     work exactly the same? If yes → romance not integrated
   - If the fantasy crisis were removed, would the romance work the same?
     If yes → fantasy not integrated
   - Fantasy events must affect romance AND romantic developments affect fantasy

7. **60% Rule Verification** (enemies/rivals/forbidden tropes)
   - Antagonism or barrier is genuine and sustained for 60%+ of the manuscript
   - Count the chapter where The Turn happens. if before 55%, it's too early
   - Backslides are organic and character-driven, not manufactured misunderstandings

### Pass 2: Magic System Coherence Audit

Romantasy readers have arrived from fantasy and bring fantasy
readers' standards for magic-system rigour. Build a magic-
system ledger: every named ability, limitation, cost, condition,
exception, and edge case appearing anywhere in the manuscript,
with the chapter and page where each first appears. Read the
manuscript against the ledger and flag every instance where
convenience has overridden consistency — typically the
climactic chapter, where a writer reaches for a power level
the rules have not allowed. The genre permits soft-magic
systems (the ambient atmospheric magic of Garber's Caraval,
the felt-rather-than-explained register of much romantasy) and
hard-magic systems (the strictly-rule-governed register of
Sanderson-influenced fantasy), but the chosen tier must be
held throughout. A book that signals soft-magic in the early
chapters and then tries to deploy hard-magic mechanics at the
climax has broken its contract; a book that signals hard-magic
and then waves through a climactic mechanic has broken its
contract. Verify also: the magic system's relationship to the
romance must be specific. Bonded magic, paired magic,
magic-amplified-by-emotion, prophecy-named lovers, soul-magic,
fated-bond mechanics — each requires its own internal logic,
and the romantic mechanics deriving from the magic system must
follow the magic system's stated rules. Where the magic does
romantic work, that work is constrained by the magic's
limitations; where the romance pulls the magic in directions
the rules cannot support, the rules need expansion or the
romance needs revision.

### Pass 3: Worldbuilding Density Calibration

Romantasy's worldbuilding density is calibrated differently
from straight fantasy: the reader needs the world (geography,
political structure, courts, factions, magical institutions,
species relations, history) sufficient to follow the fantasy
plot and feel its stakes — but the romance pacing cannot
absorb the exposition density a comparable straight-fantasy
novel might carry. Audit every world-building stretch and ask:
does this passage advance the romance, the fantasy plot, or
both? If neither, the stretch is exposition lump and must be
either dramatised, distributed across multiple scenes, or cut.
Check chapter-level density: any chapter where exposition
exceeds 25% of the page count without being woven into action
or emotional beat is over-loaded. The genre's leaders teach
the world through scene action — Yarros's *Fourth Wing*
teaches dragon-rider mechanics through training scenes that
also do romantic work; Maas teaches court politics through
balls, conflicts, and assignations rather than through council
sessions in chambers. Where the manuscript has accumulated
exposition lumps, the fix is integration — convert the
worldbuilding into something the protagonist is doing,
deciding, or fearing — not summary cuts that leave the reader
under-informed. Test: pick three worldbuilding-heavy passages
and rewrite each as a single scene in which the protagonist
actively engages with the material.

### Pass 4: Spice and Intimacy Authenticity

Romantasy operates across multiple spice tiers (closed-door,
fade-to-black, open-door restrained, open-door explicit, very-
explicit) and the chosen tier must be calibrated and
sustained. Audit every intimate scene: does each match the
declared spice level (no surprise explicit content in a
fade-to-black book; no anti-climactic curtain-drop in an
explicit one)? Is emotional context present in every scene,
not merely the physical mechanics? Are scenes character-
specific — could this exchange only have occurred between
THESE two people, or is it generic — would the same dialogue
fit any couple in any book? Is consent clear and continuous
without being mood-killing — the genre's contemporary standard
requires both legibility and integration; the consent is
visible but it is not announced in language that breaks the
register. Verify intimacy scenes do scene work beyond the
intimacy itself: a romantasy intimate scene at minimum reveals
something new about the characters, advances the relationship,
and (in the strongest examples) carries the fantasy plot
forward by altering the protagonist's strategic position
through what has now occurred. Flag any intimate scene where
the calibrated power dynamic was suspended for the duration
and resumed afterward; flag any scene that could be cut without
plot consequence (those are scenes the book did not need but
included from genre habit); flag any scene that uses the
genre's most-detected stock phrases (the flat-handed "the
bond hummed", the "magic surged", the "it had never been like
this before") without earning them through specific sensation.

### Pass 5: Trope-Stack Discipline

Romantasy is heavily trope-driven — enemies-to-lovers, forced
proximity, fated mates, chosen one, only-one-bed, court
intrigue, forbidden romance, bonded magic, hidden identity —
and the form's commercial success is partly built on the
deliberate stacking of multiple tropes within a single book.
But trope-stacking can collapse into algorithmic checklist
when the writer treats tropes as boxes to tick rather than as
narrative engines to combine. Run a dedicated trope-discipline
pass:

- List every trope deployed in the manuscript with the chapters
  where each is active
- Verify each trope is doing specific work that the others do
  not — there is no redundant trope-stacking (two tropes both
  serving the same function)
- Verify each trope is given enough page time to register —
  the only-one-bed gag deployed for half a chapter and never
  referenced again is decoration; the only-one-bed scenario
  developed across three chapters with consequences is engine
- Verify trope reversals or subversions are deliberate — where
  the manuscript subverts an expected trope move (the enemies-
  to-lovers couple who genuinely realise mid-book they don't
  want each other; the chosen one who refuses the prophecy),
  the subversion must be earned and committed to, not
  performative
- Check trope-fatigue: the genre's heavily-deployed tropes
  (fated mates, bonded magic, chosen one prophecy) require
  fresh execution to land in current market — readers have
  encountered each many times and notice when the writer is
  reaching for the trope to do narrative work the writer
  should be doing themselves

### Pass 6: The Reader's Investment Test

Final pass with the dual-genre reader specifically in mind:
would a reader who came primarily for the fantasy still be
reading at the climax? Would a reader who came primarily for
the romance still be reading at the climax? Both answers must
be yes. Test by removal: imagine a reader who, halfway through
the book, has lost interest in one of the two engines. Does
the other engine still hold them? Romantasy's commercial truth
is that most readers came for both — but each individual
reader privileges one engine over the other, and the book's
job is to keep both kinds of reader engaged across 400+
pages. Run the test specifically at three structural points:
the 25% mark (the reader has just enough information to
choose to keep going or abandon); the 50% mark (the reader is
deep enough to require sustained reward); and the 75% mark
(the reader is positioned for the climactic delivery and
must believe both engines will pay out). Where any of these
checkpoints reveals one engine running thin, the manuscript
needs structural work, not surface revision. The genre's
strongest practitioners run both engines with comparable
intensity throughout; the genre's most-flagged failure is the
"abandoned engine" book in which one register dominated the
final third while the other was perfunctory.

8. **Chemistry Specificity Scan**
   - Search for generic attraction language ("something about," "drawn to,"
     "couldn't explain"). replace EVERY instance with specific, surprising detail
   - Chemistry shown through interaction, not narration

9. **Climax Causality Check**
   - Fantasy resolution and romantic resolution are causally linked
   - Not just happening at the same time. one enables or requires the other

## Names & Patterns to Avoid

### Romantasy Character Names. NEVER USE
- AI fae names: Azriel, Cassian, Rhysand (too closely associated with existing popular IP)
- "-iel" angel/fae suffix cluster: Sariel, Auriel, Thaniel, Zeriel
- Overused romantasy names: Kael, Thorne, Aelin, Feyre, Briar, Raven
- The "powerful monosyllable" for love interests: Cain, Vex, Nyx, Dex, Zev

### Romantasy Place Names. NEVER USE
- "[Night/Moon/Star] + [Court/Kingdom]": Night Court, Moon Kingdom, Starfall Palace
- Fae realm clichés: Under Hill, The Eternal Wood, The Twilight Realm
- "[Season] + [Royal Place]": Winter Palace, Autumn Court, Spring Kingdom

### Romantasy Tropes. HANDLE WITH CARE
- Mate bond: can be done well if it creates OBSTACLES, not just confirms the ship
- "Not like other girls": the protagonist can be exceptional without other women being lesser
- Love triangle: only if both options are genuine and the choice reveals character
- Morally grey love interest: "grey" must be SPECIFIC (what did they do, why, do they regret it?)
- "I could destroy you" energy: power imbalance is romantic ONLY if the powerful character consistently chooses restraint and the less-powerful character has genuine agency

### Use Instead
- Names with cultural specificity based on the world's linguistic roots
- Place names that reflect the world's geography and politics
- Romantic dynamics built on MUTUAL respect and genuine partnership

## Comp Titles

Romantasy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Outlander* — Diana Gabaldon (1991): time-travel-fantasy-romance hybrid; the proto-romantasy.
- *A Discovery of Witches* — Deborah Harkness (2011): witch-vampire literary-romantasy lineage.
- *A Court of Thorns and Roses* — Sarah J. Maas (2015): the modern romantasy explosion's foundational text; faerie-romance with epic-fantasy worldbuilding.

### Contemporary (current best-in-class)

- *Throne of Glass series* — Sarah J. Maas (2012-2018): epic-fantasy-romance ensemble series.
- *From Blood and Ash* — Jennifer L. Armentrout (2020): vampire-romantasy with kingdom-stakes; massive commercial success.
- *House of Earth and Blood* — Sarah J. Maas (2020): the Crescent City series; multi-species romantasy.
- *The Atlas Six* — Olivie Blake (2020): dark-academia-romantasy hybrid; online-serialised viral success.
- *Plated Prisoner series* — Raven Kennedy (2021-): faerie dark-romantasy.
- *Fourth Wing* — Rebecca Yarros (2023): dragon-rider-academy romantasy; current commercial benchmark.
- *Iron Flame* — Rebecca Yarros (2023): same series; demonstrates romantasy-series architecture.
- *A Study in Drowning* — Ava Reid (2023): literary-romantasy with academic frame.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. The DOMINANT style for romantasy; rich, atmospheric illustrations featuring romantic leads or symbolic imagery; often digitally painted with a lush, dreamy quality; signals the genre immediately
- **Cinematic**. Dramatic lighting, romantic composition, a couple or lone figure against a fantasy backdrop; the "movie poster" aesthetic works well for romantasy's dual-genre appeal
- **Graphic**. Stylized, design-forward covers with bold colours and iconic imagery; popular for modern romantasy with a fresh, distinctive brand
- **Minimalist**. An iconic object (a crown with thorns, a dagger wrapped in roses, a magical symbol) against a rich colour; clean but evocative; growing trend in romantasy

### Genre Cover Aesthetics
- **Styles:** Atmospheric romantic imagery with fantasy elements, close-up of a figure with magical effects, symbolic objects representing both romance and power, lush textural detail (fabric, flowers, magical light), couples in dramatic or intimate poses against fantasy settings, silhouettes with magical backdrops
- **Colours:** Deep romantic jewel tones. burgundy, wine, and deep rose (passion, danger), midnight blue and indigo (mystery, magic, desire), dark emerald and forest (fae, nature, enchantment), rich gold and amber (power, warmth, desire), dusky purple and plum (magic, sensuality), black with metallic accents (dark romantasy)
- **Elements:** Crowns and tiaras (power dynamics), flowers. especially roses and thorns (beauty and danger), weapons intertwined with natural elements (swords with vines), magical effects (glowing hands, ethereal light, sparks), symbolic animals (wolves, ravens, dragons), silk, velvet, and flowing fabric, keys and locks, intertwined hands or silhouettes
- **Typography:** Decorative, romantic fonts. often with flourishes, thorns, or vine details; metallic finishes (gold foil is VERY common); title is large and ornamental; author name prominent; series branding elegant and consistent; the typography itself should feel romantic and magical

### Subgenre Variations
- **Fae Romantasy**. Nature elements dominant (vines, flowers, forest), ethereal lighting, greens and golds, whimsical but slightly dangerous aesthetic
- **Dark Romantasy**. Darker palette (black, blood red, silver), sharper imagery (thorns, blades), more dramatic lighting, fewer soft elements
- **Court Intrigue**. Regal elements (crowns, thrones, sigils), rich fabrics and jewel tones, candlelit interior atmosphere, political power symbols
- **Enemies-to-Lovers**. Visual tension: two elements in opposition (fire/ice, sword/flower, light/dark), dynamic composition suggesting conflict and attraction

### Market Positioning
Romantasy is one of the FASTEST-GROWING genres. Covers must signal BOTH romance and fantasy immediately. readers browse for this specific combination. Position against Maas, Aster, Penelope Douglas (fantasy end), and Bardugo. Illustrated covers with rich colour and romantic symbolism dominate the market. At thumbnail size, a striking colour palette and decorative typography are more important than scene detail. Series consistency is critical. romantasy readers are loyal to series with strong visual branding.

### Cover Design DON'Ts
- No pure fantasy covers without romantic signalling (crown alone without roses/romantic symbolism)
- No pure romance covers without fantasy elements (couple embracing with no magical context)
- No photorealistic couple covers. this signals contemporary romance, not romantasy
- No dark, grim, or grimdark aesthetics. romantasy covers should be lush and rich, not bleak
- No cluttered scenes with too many characters. focus on 1-2 figures or symbolic objects
- No childish or cartoonish illustration. romantasy readers expect sophisticated, atmospheric art
- No generic "pretty girl in a dress" without fantasy context or emotional resonance
