---
name: western-romance-genre
description: Genre-specific instructions for western romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Western Romance. Genre Plugin

## Metadata
- id: western-romance
- name: Western Romance
- icon: 🤠
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Romancing the Beat", "Save the Cat", "Three-Act Structure", "Seven-Point Structure"]

## Subgenre Options

Western romance encompasses a broad range of settings and tonal registers, each with distinct reader expectations. The subgenre chosen determines which western elements take precedence. the land, the community, the history, or the danger. and how the romance is shaped by those elements.

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Contemporary Ranch Romance | Modern-day ranching and rural life as the romantic setting | Real agricultural challenges ground the romance; the land itself is a character |
| Historical Western Romance | 19th-century frontier setting with period-appropriate social constraints | Combines western and historical romance conventions; the frontier offers freedom and danger |
| Cowboy Romance | The iconic cowboy figure. rodeo riders, ranch hands, trail bosses | The cowboy code (honour, independence, stoicism) creates the romantic obstacle |
| Small Town Western Romance | Love in tight-knit rural communities where everyone knows your business | Community interference drives comedy and conflict; reputation matters in small towns |
| Western Suspense Romance | Romance on the frontier with a thriller or mystery element | The isolation of the western landscape makes danger more acute; help is far away |
| Military/Veteran Western Romance | Former military personnel finding peace and love in the rural West | PTSD and healing through connection to land and community; the West as sanctuary |

### Subgenre Selection Guidance

**Contemporary Ranch Romance** suits authors who want to explore modern agricultural realities. drought management, sustainable ranching, the economics of rural life. alongside a love story grounded in physical labour and seasonal rhythms. The tension between tradition and modernity provides natural conflict.

**Historical Western Romance** requires rigorous period research but rewards with rich dramatic possibilities. Social constraints of the era (limited roles for women, racial hierarchies, lawlessness) create organic obstacles to the romance. The frontier setting offers a unique space where social rules could be bent or broken.

**Cowboy Romance** centres on the archetype and what it means to love someone defined by a code of conduct. The rodeo subvariant adds adrenaline and showmanship; the ranch hand variant emphasises quiet competence and loyalty; the trail boss variant layers in leadership and responsibility.

**Small Town Western Romance** is ideal for ensemble casts and series potential. Each book can feature a different couple whilst the town itself remains a constant, beloved character. Community dynamics. the gossip, the traditions, the feuds. drive both comedy and emotional stakes.

**Western Suspense Romance** raises the stakes beyond the emotional. Cattle rustling, land disputes turning violent, missing persons in vast wilderness, or organised crime reaching into rural communities add urgency. The isolation of the western setting intensifies danger. the nearest help may be hours away.

**Military/Veteran Western Romance** explores themes of homecoming and healing. The rural West offers space, silence, and purpose. all therapeutic for characters carrying trauma. The romance becomes part of the healing journey, and the land itself serves as a place of restoration.

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-5,000 words
- Pacing: Slow-burn romance paced by the rhythms of ranch life and the land: tension builds through proximity and shared work, erupting during crises forced by weather, animals, or conflict
- Must open with: Western setting established through sensory immersion, character introduced through action or labor, romantic lead's world disrupted by arrival or change
- Must close with: Romantic tension heightened, western stakes raised (land, livestock, livelihood), intimacy earned through shared experience, or obstacle deepened by western values

BEATS PER CHAPTER
1. Land and Setting: The western landscape as active presence. weather, terrain, isolation, vastness shaping mood and forcing decisions
2. Romantic Connection: Chemistry built through proximity, shared labor, competence shown, vulnerability glimpsed beneath stoicism
3. Western Stakes: Ranch survival, land disputes, livestock crises, community conflicts, rodeo competition, frontier dangers. the external problem that tests and reveals character
4. Physical Labor as Intimacy: Working side by side creates bonds. mending fence, breaking horses, calving season, roundup. shared sweat instead of shared words
5. Values Collision or Alignment: Western independence vs. romantic vulnerability, tradition vs. change, stubbornness vs. compromise, city vs. country. the internal tension the landscape illuminates

GENRE-SPECIFIC REQUIREMENTS
- The land is a character: vast open spaces, harsh weather, isolation, and natural beauty must be tangible on every page, not backdrop decoration
- Romance MUST be central: not a western with a love interest tacked on, the emotional engine of the story alongside the western problem
- HEA/HFN required: couple together, usually rooted to the land, the ranch saved or the new life chosen
- Both the romantic arc AND the western problem must resolve: saving the ranch AND finding love, proving yourself AND earning trust
- Western authenticity required: accurate ranching, horsemanship, livestock handling, weather patterns, small-town dynamics, equipment, and land management
- Animals integral: horses especially, also cattle, dogs; the relationship with animals reveals character and creates connection
- Physical labor as bonding: working together on the ranch creates intimacy through shared effort, not shared conversation
- Community matters: small-town dynamics, gossip, neighborly support, everyone knowing everyone's business affects the romance
- Seasons and land dictate story rhythm: calving season, roundup, drought, winter storms, spring thaw provide natural structure and crisis
- Western values as both attraction AND obstacle: independence, stoicism, loyalty, honor, stubbornness, self-reliance create tension between desire and vulnerability
- Isolation forces proximity: remote ranch life means characters cannot avoid each other, creating slow-burn tension
- Competence is the first attraction: skill with horses, cattle, land, or survival earns respect before desire
- Historical westerns must respect the era: isolation, danger, limited medical care, Indigenous perspectives, women's limited legal rights
- Contemporary westerns balance modern life with traditional ranch culture: pickup trucks and smartphones alongside horse training and cattle drives

FORBIDDEN
- Western aesthetics without authenticity: cowboy hats and boots do not make a western; the land, labor, and lifestyle must be real
- Romance without western substance: cannot be a contemporary romance where someone happens to own a ranch
- City character who never adapts: fish-out-of-water must show genuine growth, not permanent incompetence played for laughs
- Insta-love without earned respect: attraction may be immediate, but love requires demonstrated character through action
- Cowboys as caricatures: no generic strong-silent-type without depth, complexity, and specific individual humanity
- Animal cruelty or neglect played casually: western romance readers are passionate about animal welfare
- Ranch work as quaint backdrop: labor must be real, difficult, and consequential, not picturesque set dressing
- Ignoring the harshness of the land: weather, isolation, physical danger, and economic precariousness are real
- Stereotypical Native American portrayal: if Indigenous characters appear, they must be fully human with agency, not mystical guides or obstacles
- Tragic endings: western romance keeps the HEA/HFN promise; the land may be harsh, but love endures
- Single-obstacle stories: layer internal emotional barriers alongside the western problem; the ranch crisis is the external obstacle, the characters' wounds are the internal ones
- Relentless hardship without warmth: even in the harshest landscape, you need moments of beauty, humor, and unexpected tenderness; a sunset after a grueling day, laughter after a near-disaster, quiet companionship by a fire
- Modern sensibilities anachronistically imposed on historical settings: or historical attitudes unexamined in contemporary settings
- Love interest who has no connection to the land: at least one romantic lead must understand and respect the western way of life

LIGHT AND SHADE IN WESTERN ROMANCE

Emotional contrast is your most powerful tool. After a scene of grueling ranch work or dangerous crisis. a blizzard, a difficult calving, a confrontation over land rights. allow a moment of surprising warmth: dry humor over coffee at dawn, unexpected tenderness while doctoring a horse, the vast quiet of a starlit night shared in comfortable silence. After a scene of genuine connection or intimacy, introduce a complication that tests the bond: a stubborn refusal to accept help, an old wound reopened, the arrival of someone from the past. This alternation is what makes western romance work: the reader relaxes into the beauty of the land and the warmth of the connection only to feel the ground shift, and braces for hardship only to find unexpected comfort. Two grueling ranch scenes back to back exhaust; hardship followed by tenderness creates the emotional rhythm that hooks readers permanently.

OBSTACLE LAYERING

Western romance has powerful built-in external obstacles (ranch survival, land disputes, economic hardship, distance from civilization, dangerous weather and terrain), but these alone are not enough for the romance. Layer INTERNAL obstacles that the western setting illuminates: stoicism that prevents emotional honesty, fierce independence that resists needing anyone, past loss that makes loving again feel like risking everything, generational expectations about how a rancher should live. The harsh beauty of the land should test the relationship itself. isolation reveals who people really are, and the demands of ranch life strip away every pretense. The more obstacles between the couple. western AND emotional. the more the reader yearns for their connection.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (relationship arc), Captivation (landscape & code), Anticipation (frontier stakes).

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-agent.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE
- POV: Close 3rd limited (both leads in alternating chapters) or 1st person (intimate, character-driven)
- Tense: Past (traditional western romance weight) or present (heightened intimacy and immediacy)
- Voice: Spare, grounded, sensory: the prose of someone who notices the land, the weather, and the way a person moves before they notice their own feelings. Poetic precision over purple excess.
- Reading level: Adult: authentic western detail, mature romantic content, emotional complexity beneath surface simplicity

PROSE IMPERATIVES
- Land described through ONE dominant sense per scene. Not a sensory catalogue, but the single detail that anchors the moment: sage after rain OR wind-scoured skin OR the low sound of cattle. Let one detail stand alone
- Physical labor rendered with specificity: mending fence has particular motions, breaking a horse has specific stages, calving has real urgency; generic ranch work reads false
- Stoicism shown through what is NOT said: western characters communicate through action, glances, presence; the gap between feeling and speaking IS the tension
- Weather as mood and plot: a blizzard is not decoration, it is a scene partner that forces choices, creates danger, and traps characters together
- Animals described with knowledge and affection: horses are individuals with personalities, cattle have specific behaviors, dogs are working partners; animal interactions reveal character
- Physical awareness built through work: noticing strength, competence, hands, the way someone sits a horse, the steadiness under pressure; attraction through demonstrated capability
- Silence given weight: in western romance, silence is not absence; it is communication, comfort, tension, or invitation
- Landscape metaphors for emotional state. vast spaces for loneliness, storms for turmoil, sunrise for hope, deep roots for commitment. but earned, not forced
- Sensory specificity over generic beauty: not "the beautiful sunset" but "the sky bleeding out over the Absarokas, turning the snow peaks the color of old copper"
- Economy of language: western prose is lean; every word carries weight, like a good saddlebag

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- Landscape AND independence AND chemistry from the opening page: the land, the person, the pull
- Tension floor: 5 (the reader must feel the vastness, the self-reliance, and the first charged awareness)
- Open with a character working, arriving, or confronting the land: never with passive reflection
- Dialogue density: 20-30%: western characters are economical with words; silence does the heavy lifting

Ranch/landscape scenes (prose rhythm):
- Medium sentences with frontier cadence: spare, grounded, rhythmic like hoofbeats or fence work
- ONE dominant sensory detail per scene: open sky, dust, leather, distance, sage, cold iron
- Silence given weight on the page: paragraph breaks where conversation would be in other genres
- Interiority budget: 30%: western characters think in images and physical sensation, not analysis

Intimacy/vulnerability scenes (prose rhythm):
- Sentences shorten when emotional walls crack: the stoic character's control breaking in fragments
- Dialogue understated: what's NOT said carries the weight; a single honest sentence after chapters of restraint
- Sensory detail shifts inward: body warmth against cold, roughened hands gentle, the sound of breathing in silence
- The land remains present: wind against the cabin, horses in the barn, the vast quiet that makes two voices enormous

Climax/resolution prose rhythm:
- Crisis (blizzard, fire, confrontation): short, urgent, physical: the land and the danger demand action
- Declaration: spare and direct: no eloquence, just truth; western love is spoken plainly or shown through sacrifice
- Resolution: the prose settles like land after rain: medium sentences, earned warmth, the rhythm of two lives joined

GENRE-SPECIFIC STYLE
- Ranch morning routines as scene-setting: coffee before dawn, the sound of horses in the barn, the day's work laid out by weather and season
- Horseback scenes as intimacy: riding together, the rhythm of horses, teaching someone to ride, trust between rider and horse mirroring trust between characters
- Campfire and porch scenes: the western tradition of storytelling, confession, and quiet companionship in firelight or under stars
- Pickup truck and tack room conversations: confined spaces where western characters finally talk because they cannot walk away
- Small-town dynamics: the cafe where everyone knows your business, the feed store where news travels, the church supper where the community watches
- Rodeo scenes: competition, physical courage, the intoxicating danger and skill that draws admiration and fear
- Working cattle: the partnership of roundup, the physical reality of shared labor
- Seasonal rhythms: calving season's sleepless intensity, summer haying, fall roundup, winter's enforced isolation; the land dictates the story's pace
- Western hospitality and manners: the codes of behavior that govern interaction, the respect shown through actions not words
- Historic western settings: frontier towns, soddie homesteads, cattle drives, mining camps, each with specific sensory reality
- Dance hall and social scenes: the rare occasions when western characters dress up, let down their guard, and the formality creates its own tension
- Veterinary and animal care scenes: tending sick animals as intimacy, the tenderness shown to a creature revealing the tenderness hidden from people
- Landscape as emotional mirror: the wide-open spaces that dwarf human problems and simultaneously amplify human loneliness
- Dawn and dusk as transitional: western romance lives in the golden hours, the liminal times when the land is most beautiful and characters most vulnerable

FORBIDDEN WORDS/PHRASES
- "Cowboy" used every other paragraph: vary with rancher, hand, rider, or use their name
- "Orbs" for eyes: say eyes, gaze, or specific color
- "Ruggedly handsome" as the entire physical description: show specific, individual attractiveness through detail
- Purple prose during physical labor: clarity and visceral specificity over ornate description
- Modern urban slang in historical settings: maintain period-appropriate voice
- "The vast expanse stretched before them" and other generic landscape cliches: make every description specific to THIS land, THIS moment
- Telling attraction: "She found him attractive" instead of showing the physical awareness through specific reaction
- "Said" alternatives overused: "drawled" once per chapter maximum; western characters speak plainly
- Romanticizing poverty or hardship: ranch life is hard; acknowledge both its beauty and its cost without glamorizing suffering

WESTERN ROMANCE TENSION
- Proximity without privacy: Ranch life forces closeness. sharing meals, sharing work, sharing storms. while western propriety and emotional reserve prevent acknowledgment of desire
- Competence as foreplay: Watching someone handle a spooked horse, rope a calf, build a fence in silence: skill demonstrated is the western romance equivalent of a love letter
- Stoicism as obstacle: Characters who show love through action (fixing the barn roof, staying up all night with a sick horse, driving through a blizzard to bring supplies) but cannot say "I need you"
- The land as rival: The ranch, the lifestyle, the demanding work competes with the relationship for time, energy, and loyalty: choosing love may mean compromising independence
- Outsider/insider tension: The newcomer who must earn the right to belong. to the community, to the land, and to the person they love. through demonstrated commitment and adaptation
- Shared crisis as accelerant: A blizzard, a fire, a stampede, a difficult birth: western emergencies strip away social masks and force raw honesty
- Community pressure: Everyone watching, everyone with an opinion, gossip as both obstacle and matchmaker
- Generational weight: Family land, family expectations, the pressure of tradition both binding and suffocating

INTIMACY IN WESTERN CONTEXT
- Romantic scenes carry the weight of earned trust: in a world where vulnerability is dangerous, letting someone close is an act of courage
- Physical intimacy as natural as the land: honest, direct, grounded in the body rather than artifice; passion with callused hands
- Tenderness amplified by surrounding harshness: gentleness means more from someone whose daily life demands toughness
- The first touch matters enormously: hands brushing during work, steadying someone on a horse, tending a wound; each accidental contact charged with weeks of proximity and restraint
- Hayloft and tack room encounters earn their place through built tension: private spaces on a ranch are few and precious
- Post-crisis intimacy: after surviving a storm, saving an animal, or facing danger together, emotional walls crumble and physical connection becomes inevitable
- Morning-after scenes grounded in ranch reality: chores still need doing, coffee still needs making, and the relationship must survive daylight and daily life

INTIMATE SCENES. CHARACTER REVELATION THROUGH VULNERABILITY

- Intimate scenes in western romance must serve the relationship and character development: not merely provide heat
- Ask: what does this moment reveal about characters who spend their lives armored in competence and self-reliance? What does vulnerability look like in someone who has been strong for so long?
- The best intimate scenes in western romance contain emotional rawness: the stoic rancher whose control finally breaks, the independent woman who lets herself need someone, the awkwardness of bodies more accustomed to labor than tenderness
- Build physical intimacy into the emotional landscape: it should feel like the natural culmination of weeks or months of shared work, shared hardship, and growing trust
- Sensory writing is essential: the specific textures of work-roughened hands, the smell of hay and leather and woodsmoke, the contrast between outdoor cold and body heat
- The western setting should be present even in intimate moments: the sound of wind against the cabin, horses shifting in the barn, the vast silence of the land that makes two heartbeats deafening

METHOD WRITING. EMOTIONAL TRUTH

- Identify what you want the reader to FEEL before writing any key scene: the ache of wanting someone who is standing right beside you and a thousand miles away emotionally? The fierce tenderness of watching someone be gentle with an animal? The specific loneliness of vast beauty with no one to share it?
- If the writer is not feeling the emotion while writing, the reader will not feel it while reading: that is the signal to go back and find what is blocking the feeling
- Write through all five senses with western specificity: what does the barn smell like at four in the morning? What is the exact sensation of cold leather warming under your hands? How does the light change when clouds move over the mountains?
- Never be cynical about emotion: do not manufacture a ranch crisis or a relationship conflict purely for drama. Genuine emotion, earned through character investment and authentic western detail, is what makes readers fall in love with both the characters and the land

DIALOGUE. THE POWER OF THE UNSAID

- Western characters rarely say what they mean about their feelings: they deflect with dry humor, change the subject to ranch business, or simply go silent
- This restraint gives ENORMOUS resonance to the moments when characters finally speak honestly: a declaration of love from someone who has spent the entire book communicating through actions carries more weight than any eloquent speech
- Each character should speak distinctly: the laconic rancher whose sentences are as spare as the landscape, the newcomer whose verbal abundance contrasts with the local economy of words, the old-timer whose wisdom comes wrapped in stories
- Conversations between romantic leads should function as verbal sparring. advance and retreat, what is risked and what is withheld. with the western setting adding stakes to every exchange (a conversation during a cattle drive carries different weight than one over dinner)
- Western dialogue has its own music: rhythms shaped by the land, by isolation, by long hours of silence broken by necessity; honor this without descending into caricature
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Western authenticity. setting, ranch life, animals, weather, and land management rendered with genuine knowledge and sensory specificity, not cowboy costume drama
2. Romance central. love story drives every chapter, not a western with romantic subplot but the emotional engine alongside the western problem
3. HEA/HFN delivered. couple together at end, usually rooted to the land, relationship and western problem both resolved
4. Land as character. the western landscape actively shapes plot, mood, and relationship, not interchangeable backdrop
5. Both plots resolved. western problem (ranch survival, land dispute, proving oneself) AND romance both satisfyingly concluded

GENRE-SPECIFIC CHECKS

Western setting tangible. land, weather, animals, ranch work rendered with specificity and sensory detail
Romance every chapter. relationship advances, no chapters without romantic development or charged tension
Animals present and authentic. horses, cattle, dogs described with knowledge and as individuals with personality
Ranch work real. labor specific, difficult, consequential, not picturesque set dressing
Seasons and weather active. climate shapes events, creates crises, forces proximity and decisions
Small-town dynamics. community watching, gossip flowing, neighborly obligations affecting the romance
Western values in tension. independence, stoicism, honor, loyalty both attracting and obstructing the couple
Competence demonstrated. both leads show specific skills that earn respect and create attraction
Physical labor as bonding. working together creates intimacy, shown not told
Stoicism with depth. emotional restraint a barrier to be overcome, not a character substitute, vulnerability glimpsed beneath
Emotional authenticity beneath surface. characters communicate through action and restraint, breakthroughs earned not manufactured

AUTOMATIC FAILS

No genuine western. contemporary romance where someone happens to live on a ranch, no authentic land, ranch, or animal detail
No real romance. western with attraction subplot, couple not central emotional engine
Tragic ending. couple not together or ranch lost without hope, violates genre promise
Cowboy caricature. male lead is a generic strong-silent-type without individual depth or vulnerability
Animal cruelty or neglect treated casually. western romance readers will not forgive this
Ranch work absent or generic. no authentic labor, no specific detail, no understanding of the life
City character never adapts. fish-out-of-water remains incompetent throughout, no growth, no earned belonging
Weather and land as decoration. setting interchangeable with any location, no western specificity
Insta-love without earned respect. characters declare love without demonstrated character through action and crisis
One plot abandoned. western problem resolved but romance dropped, or romance concluded but ranch crisis forgotten

ACCEPTABLE IMPERFECTIONS

More romance than western chapters (or vice versa) if both substantial and satisfying
Heat level varies. some western romance explicit, some closed door, some fade-to-black
Historical accuracy slightly simplified if core period authenticity maintained
Small-town cast not fully developed if main characters and key community members vivid

RED FLAGS TO INVESTIGATE

Ranch life feeling like backdrop rather than lived experience—generic references to "chores" without the specific, sensory detail of actual labor
Animals mentioned but not characterized. horses unnamed, cattle as abstract concept, no individual animal personalities
Competence told rather than demonstrated—"she was a skilled rider" replacing a scene showing her handle a spooked horse
Weather described but not consequential. storms and seasons as atmosphere without affecting decisions, travel, or the relationship
Stoicism as flatness. laconic characters who are simply uninteresting rather than concealing deep feeling beneath practiced reserve
Romantic milestones disconnected from western context. relationship moments that could happen in any contemporary romance without the land, animals, or ranch work
Physical labor montaged rather than rendered. work scenes summarized instead of shown with the same specificity as romantic scenes
Community absent. the couple existing in isolation without the small-town dynamics, gossip, and neighborly obligations that shape ranch life
Outsider adaptation happening offscreen. fish-out-of-water character gaining competence between chapters rather than through shown, struggled learning
Landscape descriptions generic—"beautiful mountains" and "wide-open spaces" replacing the specific sensory reality of THIS particular western land
Financial stakes vague. ranch economic pressure mentioned without specific, tangible consequences that create urgency
One protagonist significantly more developed than the other. rancher fully realized but love interest feeling like a tourist in their own story
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Ranch and land geography: Property layout, buildings, pastures, water sources, distances between locations, neighboring ranches. established early and maintained consistently
2. Relationship progression: Emotional intimacy deepens logically through shared work and crises. trust earned through demonstrated action, not assumed or accelerated without cause
3. Animal continuity: Horses by name, personality, and role; cattle herd size and condition; dogs and their behavior. animals are characters and must be tracked
4. Seasonal and weather progression: The story moves through identifiable seasons with appropriate ranch work, weather patterns, and environmental conditions. no calving in autumn or roundup in winter without explanation
5. Western problem escalation: The external conflict (ranch survival, land dispute, drought, community conflict) progresses logically with cause-and-effect consequences

GENRE-SPECIFIC TRACKING
- Romance milestones: First meeting, first moment of respect/admiration, first physical contact, first kiss, first vulnerability shared, declaration, commitment: each tied to western context
- Ranch operations: What work is being done, what season, what equipment, what the daily routine looks like: established and maintained
- Animal status: Named horses' locations and conditions, herd health, dogs' behaviors, any pregnant or sick animals tracked
- Property details: House layout, barn configuration, outbuildings, fences, water sources, pasture rotation: once described, consistent
- Weather and season: Current season, recent weather, upcoming weather threats, how conditions affect work and mood
- Equipment and supplies: Vehicles, tack, feed supplies, fencing materials, veterinary supplies: availability tracked
- Community relationships: Who knows whom, who is feuding, who is allied, town dynamics, gossip currently circulating
- Character skills: What each person can do on the ranch: riding ability, roping, veterinary knowledge, mechanical skills, cooking
- Financial situation: Ranch economic health, debts, income sources, market conditions: if established, maintained
- Historical period details (if historical): Technology available, social norms, legal constraints, transportation methods
- Newcomer adaptation: If a fish-out-of-water character, track specific skills learned, mistakes made, competence growing

ACCEPTABLE INCONSISTENCIES
- Minor descriptions of background landscape if core geography maintained
- Slight variation in daily routine timing if season and workload consistent
- Small-town character appearances if core cast well-established

CRITICAL CONSISTENCY
- Horse names and personalities: a horse described as gentle does not suddenly become dangerous without cause
- Ranch layout: if the barn is east of the house in chapter 3, it is east of the house in chapter 20
- Seasonal work: calving season, haying, roundup happen at the right time of year for the region
- Character riding ability: someone who cannot ride in chapter 5 does not rope cattle expertly in chapter 10 without shown learning
- Weather consequences: a blizzard in chapter 8 means snow and cold in chapter 9, not sudden warmth
- Financial stakes: if the ranch is about to be foreclosed, money does not appear conveniently
- Relationship intimacy level: first kiss happens once, trust once broken must be rebuilt through action
- Community knowledge: if the town gossips about the couple in chapter 12, they know about it
- Animal health: if a horse was injured, track the healing; if a cow was lost, the herd count reflects it
- Equipment: if the truck broke down, it needs repair; if fencing was damaged, it needs mending
- Distance and travel times: if town is thirty miles away, the drive takes consistent time
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Western competence: Characters' ranch skills, riding ability, livestock knowledge, and land sense are established and maintained. competence grows through practice, not by authorial convenience
2. Stoicism with depth: Emotional restraint is consistent but not static. vulnerability emerges through specific moments of trust, crisis, or intimacy, and once revealed, cannot be fully re-hidden
3. Relationship to the land: Each character's connection to the western landscape. love, resentment, dependence, freedom. is specific and persistent, informing their choices and conflicts
4. Animal relationships: How each character interacts with horses, cattle, and dogs reveals their nature. tracked consistently, with animals responding to characters in established patterns
5. Physical capability: What each character can and cannot do on a ranch. tracked through the story, with skills developing through shown practice and instruction

CHARACTER BUILDING. GROUND UP FOR WESTERN ROMANCE

Build each protagonist from the ground up BEFORE the romance begins. The character must exist fully in relation to the land and the western life:
- Background questions: What is their relationship with the land. born to it, chose it, fled to it, forced onto it? What do they want from this life? What are they afraid of. and is it the land, the loneliness, the vulnerability of loving, or something they left behind? What do they carry. both in their pockets and in their hearts?
- Character tests: How do they handle a spooked horse? What do they do when a neighbor needs help? What is their response to a sick calf at 2 AM? What is in their truck, their tack room, their kitchen? What do they reach for when afraid: work, silence, the bottle, the barn?
- These details inform everything: how they show affection (fixing something, feeding someone, standing watch), how they express anger (cold silence, physical labor, walking away to the horses), what specific vulnerabilities the western life exposes
- Messy, flawed characters create richer western romance: a rancher whose independence is actually fear of intimacy, a newcomer whose enthusiasm masks grief, a rodeo rider whose courage on horseback does not extend to matters of the heart

ANTI-STEREOTYPE IMPERATIVE

Avoid default western romance archetypes: no generic strong-silent cowboy whose only character trait is being ruggedly handsome and good with horses; no helpless city girl whose only function is to be educated about ranch life. Both protagonists need specific, individual complexity. The rancher can be uncertain, exhausted, financially terrified, or terrible at asking for help. The newcomer can be competent in their own right. bringing skills that the ranch desperately needs. The most compelling western romance characters are ordinary, imperfect people placed in an extraordinary landscape that strips away every pretense. Stereotypes flatten both the western and the romance.

GENRE-SPECIFIC CHARACTER ELEMENTS
- Relationship with horses: How each character rides, which horse they choose, how they handle fear or trust in the saddle: this is character revelation as important as dialogue
- Work ethic: In western romance, how someone works IS who they are: lazy, dedicated, skilled, learning, stubborn, adaptable; observed by the love interest
- Stoic exterior with specific cracks: Each character's emotional armor has particular weak points: the mention of a lost parent, the sight of a foal being born, a specific song, children, the land at sunset
- Physical toughness with human limits: Characters who push through exhaustion, cold, injury: but not infinitely; breaking points reveal character
- Independence as identity: Self-reliance is not just a trait but a core belief: and romance threatens it by requiring someone to need another person
- Community role: Each character has a place in the small-town ecosystem: the reliable neighbor, the grudge-holder, the newcomer, the one who left and came back
- Family legacy: In western romance, land often carries generational weight: expectations, debts, promises made to dead parents, the pressure to carry on a way of life
- Regional specificity: Montana rancher is different from Texas rancher is different from Wyoming rancher: region shapes character, speech, and culture
- Historical characters: Must reflect the realities of their era. women's limited options, racial dynamics, the actual dangers of frontier life. while maintaining agency and complexity
- Practical wisdom: Western characters know weather, animals, land, and people through observation and experience, not formal education; intelligence shown through applied knowledge

CHARACTER ARCS MUST
- Show vulnerability arc: initial stoicism or independence through crisis-forced honesty to chosen vulnerability with the person they love
- Demonstrate competence arc: respect earned through demonstrated skill and reliability, growing from grudging acknowledgment to genuine admiration to attraction
- Navigate the land's demands: the ranch, the weather, the animals testing and shaping the relationship; the couple must prove they can handle the western life together
- Confront what they are avoiding: past loss, fear of intimacy, guilt about leaving or staying, family expectations; the land and its demands strip away every hiding place
- Earn belonging: the outsider earns their place through work, persistence, and genuine adaptation; the insider learns that belonging is not the same as being trapped
- Choose love despite cost: knowing that loving someone on a ranch means hardship, isolation, and tying your life to unpredictable land; choosing it anyway
- Transform through shared labor: characters at end fundamentally changed by both the relationship and the western experience
- Maintain agency: both characters make choices that affect the ranch AND the relationship; no passive recipients of either hardship or love

TRACK
- Riding ability: how each character sits a horse, what they can handle, growth in skill
- Ranch skills: what each can do (rope, mend fence, handle cattle, doctor animals, drive equipment) and how this evolves
- Physical condition: injuries, exhaustion, weather exposure, calluses, sunburn; bodies show the effects of ranch life
- Emotional walls: what triggers vulnerability, what rebuilds defenses, which walls have been permanently lowered
- Relationship with specific animals: their horse, the ranch dogs, specific cattle; these relationships are subplot
- Community standing: how the town views each character, reputation, trust level with neighbors
- Family obligations: debts, promises, expectations, legacy pressure; tracked across chapters
- Skills the other admires: what specifically draws each character to observe and respect the other
- Secrets held: from each other and from the community; when revealed and how
- Adaptation markers (for fish-out-of-water): first successful ride, first solo chore, first emergency handled; track growth specifically
```

## Arc Rules

```
ACT I (Chapters 1-10): Arrival and the Lay of the Land
- Ch 1: Western world established through sensory immersion: the land, the ranch, the daily rhythm; protagonist's world is about to change (arrival, loss, crisis, opportunity)
- Ch 2-3: Second lead introduced through action or western competence; initial friction or reluctant attraction; the western problem established (ranch threatened, land disputed, proving oneself needed)
- Ch 4-5: Forced proximity on the ranch: shared work begins, competence observed, first grudging respect; the land itself creates the first crisis (weather, animal emergency, equipment failure)
- Ch 6-8: Working together deepens connection: physical labor side by side, quiet moments during long rides, competence-as-attraction building; western problem escalating (financial pressure, rival's aggression, community tension); first moment of unexpected vulnerability from one or both leads
- Ch 9-10: First genuine romantic moment earned through shared crisis: a storm survived together, an animal saved at great effort, a confrontation weathered as allies; the western problem becomes personal, intertwining with the growing relationship
- Purpose: Establish BOTH western authenticity and romantic chemistry as co-equal forces: the land shapes the love story
- Ends with: Mutual respect undeniable, attraction acknowledged internally if not spoken, western stakes clear, the ranch and the relationship both in motion

MIDPOINT (Chapter 15): The Land and the Heart Demand a Choice
- A major western crisis AND a significant romantic turning point collide: the ranch faces its greatest threat (drought, fire, foreclosure, dangerous confrontation) at the same moment the couple must acknowledge what exists between them
- Physical or deep emotional intimacy earned through the crisis: walls broken by exhaustion, danger, or the raw honesty that western hardship demands
- Tonal shift: From "can I survive this place / this person?" to "do I want to build a life here / with them?": the question changes from possibility to commitment

ACT II (Chapters 11-23): The Testing Season
- Ch 11-14: Romance deepening through the rhythms of ranch life: shared meals, shared labor, quiet evenings; small acts of caring (fixing something, bringing coffee, tending a wound) communicate what words cannot; the community begins to notice and react (support, gossip, interference)
- Ch 15: MIDPOINT: major western crisis AND romantic turning point collide; the couple must work together to face the threat, and in doing so reveal their deepest feelings
- Ch 16-18: Complications from the western problem: the land dispute intensifies, the financial pressure mounts, the rival makes their move, the community takes sides; the relationship is tested by external pressure and the question of whether love can survive on this unforgiving land
- Ch 19-21: Internal obstacles surface: stoic refusal to accept help, fear of vulnerability, past loss making love feel dangerous, family expectations pulling in different directions, the question of belonging (will the outsider stay? can the insider let someone in?); the western problem threatens to destroy everything including the relationship
- Ch 22-23: Black moment. the western crisis reaches its peak AND the relationship shatters or is tested to breaking point; the couple separates (physically or emotionally) because of the very values that brought them together. independence, stubbornness, pride, fear of loss
- Purpose: Romance intensifies BECAUSE the western stakes escalate: each crisis reveals more of who the characters are and what they mean to each other
- Ends with: Darkest hour: the ranch may be lost, the relationship may be over, and the choice between independence and love seems impossible

ACT III (Chapters 24-30): Coming Home
- Ch 24-25: Choosing each other despite the cost: one or both must overcome their deepest fear (vulnerability, commitment, staying, needing someone) and reach for the other; this choice should require sacrifice of the independence or stoicism that defined them
- Ch 26-28: The western problem resolved through partnership: the couple faces the threat together, combining their individual strengths (ranch knowledge + business sense, riding skill + courage, local standing + outsider perspective); the community rallies or the rival is defeated through the couple's united effort
- Ch 29: Aftermath: the ranch saved (or a new beginning chosen), the relationship committed, scars acknowledged, the land that tested them now holding them
- Ch 30: Earned HEA/HFN: the couple together on the land, the daily rhythm of ranch life now shared, a final scene that shows both the love and the landscape; the western world that challenged them is now their home together
- Purpose: Resolve the western problem AND cement romantic commitment: love earned through shared labor, shared crisis, and chosen vulnerability
- Ends with: HEA/HFN: couple together, rooted to the land, the ranch and the relationship both survived; the western world continues in all its harsh beauty, now shared

GENRE PROMISE
Western Romance readers expect:
- Authentic western setting: the land, the ranch, the animals, the weather real and tangible, not costume
- Central romance: not subplot, the emotional spine of the story
- HEA/HFN: couple together, usually rooted to the land
- Competence-based attraction: respect earned through skill and work before desire acknowledged
- Slow-burn tension built through proximity and shared labor
- Stoicism overcome by love: the guarded character finally letting someone in
- Animals as characters: horses with names and personalities, dogs with loyalty and purpose
- Community matters: small-town dynamics affecting the romance
- Physical labor as intimacy: working together as the western love language
- The land shapes everything: weather, seasons, isolation, beauty all driving the story

REQUIRED CHECKPOINTS
- Ch 3: Western setting established AND romantic chemistry or friction undeniable
- Ch 5: First shared crisis: weather, animal emergency, or confrontation weathered together
- Ch 8: Competence observed and respected: attraction building through demonstrated skill
- Ch 10: First genuine romantic moment earned through shared experience on the land
- Ch 13: Community dynamics affecting the romance: gossip, support, or interference
- Ch 15: Major western crisis AND romantic turning point: walls breaking under pressure
- Ch 18: Western problem threatening to destroy both the ranch and the relationship
- Ch 23: Black moment: separation driven by western values (independence, pride, fear of loss)
- Ch 25: Choosing love: the guarded character reaches for the other despite the cost to their independence
- Ch 28: Western problem resolved through partnership: the couple's combined strengths prevailing
- Ch 30: HEA/HFN: together on the land, the daily rhythm now shared, love and landscape unified

EMOTIONAL CONTRAST IN ARC STRUCTURE

Chart the emotional arc as alternating peaks and valleys of hardship and tenderness. After every major western crisis (storm, financial blow, confrontation, animal loss), provide a breathing space where the couple connects. even briefly: dry humor over fence-mending, unexpected gentleness with an animal, a shared silence under stars that says more than words. After every moment of genuine connection or intimacy, introduce a complication that tests the bond: a stubborn retreat into independence, an old wound reopened by circumstance, a western problem that demands attention and separates them. This rhythm mirrors the western landscape itself. brutal storms followed by heartbreaking sunsets, back-breaking labor followed by the quiet beauty of the land at rest. Two consecutive hardship scenes exhaust; hardship followed by warmth creates the emotional rhythm that makes western romance irresistible.

EARNED ENDINGS

The HEA/HFN must be earned through everything the characters have endured. on the land and in each other. The couple's victory should require the specific strengths their relationship has forged: the outsider's fresh perspective combined with the insider's deep knowledge, the stubborn rancher's courage combined with the newcomer's willingness to try. The ending should feel like the inevitable destination of THESE specific characters who were shaped by THIS specific land. Seed the resolution early: if the ranch is saved through a particular strategy, plant those capabilities in earlier chapters so the victory feels earned, not convenient. A western romance ending should feel like coming home. to the land, to each other, to a life that is hard and beautiful and chosen.

THEME BENEATH THE WESTERN

Every western romance benefits from a THEME running beneath the surface. what the story is really about beyond the ranch crisis and the love story. Is it about what home really means? About the courage it takes to put down roots or pull them up? About whether the old ways can survive in the modern world? About what the land gives and what it takes? About finding where you belong? Theme adds a dimension that makes western romance resonate beyond the genre. the reader should close the book feeling something true about love, land, and the human need to belong.
```

## Timeline Rules

```
TIME SCALE
- Total story duration: Weeks to months, sometimes spanning a full year of seasons (western romance benefits from experiencing the land through seasonal change)
- Chapter time span: Days to weeks: ranch life has its own rhythm that cannot be rushed
- Time progression: Linear with the seasons, occasionally with flashbacks revealing backstory or history of the land

GENRE-SPECIFIC TEMPORAL RULES
- Ranch seasons dictate pacing: calving season (late winter/early spring) is sleepless intensity, summer is long days of hard work, fall roundup is communal effort, winter is isolation and enforced proximity
- Weather creates temporal urgency: a blizzard bearing down, drought deepening, wildfire approaching provide natural deadlines
- Animal needs are relentless: feeding schedules, calving watches, veterinary emergencies cannot be postponed for romance; this is GOOD for the story because it forces the couple together at inconvenient emotional moments
- Small-town events mark time: church suppers, county fairs, rodeo weekends, holiday celebrations provide temporal structure and community scenes
- Dawn-to-dark work rhythm: ranch days start before sunrise and end after sunset; evenings and early mornings are the windows for personal connection
- Travel takes real time: distances between ranches, to town, to the nearest city are significant and should be felt
- Healing takes ranch time: injuries from horse accidents, ranch mishaps, or weather cannot be waved away; a broken arm means weeks of limited work
- Historical timelines must respect travel and communication of the era: no telegraphs before they existed, no railroads before the tracks were laid
- Romance accelerated by forced proximity is realistic on a remote ranch: weeks of daily contact creates genuine depth
- Market and economic cycles: cattle prices, feed costs, seasonal income variation are real temporal pressures

TRACK CAREFULLY
- Current season and month: ranch work must match the time of year
- Days since significant events: when the newcomer arrived, when the crisis began, when the first kiss occurred
- Weather patterns: storms do not appear and vanish without aftermath; drought persists until rain; winter conditions accumulate
- Animal schedules: feeding times, calving watch rotations, training sessions, veterinary appointments
- Work progress: fence lines being mended, fields being worked, buildings being repaired take days or weeks
- Distance and travel: how long to reach town, the nearest neighbor, the hospital, the county seat
- Community event calendar: church, school, rodeo, county fair, harvest festival, holiday gatherings
- Financial deadlines: mortgage payments, auction dates, lease renewals, cattle market timing
- Seasonal transitions: the story should feel the change from one season to the next with appropriate environmental and work shifts
- Healing timelines: injuries heal at realistic rates; exhaustion requires actual rest

FLEXIBLE
- Exact hours of routine daily tasks if general rhythm maintained
- Minor scheduling details between established events
- Precise ages of livestock if general herd condition tracked
```

## Genre-Specific Craft Techniques

Western romance is the integration of two registers the reader
has come for in equal measure: the romance contract (emotional
truth, escalating intimacy, earned commitment) and the western
register (landscape, work, community, the specific texture of
rural and frontier life rendered with authority). The form
ranges from the historical-frontier tradition (Diana Palmer's
Texas Long Tall series, Linda Lael Miller's McKettrick books
and the broader cowboy-romance backlist) through the
contemporary-ranch register (Joanne Kennedy, Carolyn Brown,
Maisey Yates's Copper Ridge and Gold Valley series, Lori
Wilde) and into the modern-rural literary-adjacent edge
(B.J. Daniels at the suspense-cross point, Jessica Clare,
Stacey Lynn, Joanna Davidson Politano on the Christian-
romance side). The form's craft inheritance runs through
Zane Grey, Louis L'Amour, Larry McMurtry's *Lonesome Dove*,
Ivan Doig, Jim Harrison, and contemporary literary western
voices (Annie Proulx, Kent Haruf, Téa Obreht, Rachel Kushner)
on the western-genre side, and through the romance-craft
tradition on the other. The techniques below are how the form
holds both registers without either collapsing into the other
— neither generic-romance-with-cowboy-hat nor literary-western-
with-decorative-romance.

### The Land as Love Language

The western landscape expressing and shaping the romance. The
sunrise ride that creates shared wonder. The storm that forces
shelter-sharing. The vast emptiness that makes two people feel
like the only humans alive. The land is not backdrop — it is
the medium through which love is communicated. The genre's
strongest practitioners treat the western landscape as a third
character in the romance, with its own moods, demands, and
contributions to what unfolds upon it.

Every significant romantic beat should be anchored to a
specific place on the property or in the surrounding
wilderness. The reader should be able to map the love story
onto the geography: the creek where they first argued, the
ridge where they first kissed, the barn where they made their
declaration. The cumulative effect is that the protagonists'
shared interior map of the property becomes the geography of
the relationship; in the climactic chapters, returning to a
named location automatically retrieves the emotional history
of what happened there. Generic landscape ("they walked
through the fields") is the failure mode; specific, named,
returnable places ("the alder grove at the bend of Cottonwood
Creek where the cattle drink in summer") are the technique.

When the landscape is woven into the emotional arc, the romance
feels rooted in something older and larger than two
individuals. Use seasonal shifts to mirror the relationship's
evolution: the thaw of spring for tentative connection, the
blaze of summer for passion, the harvest for commitment, the
first frost for reckoning. The land should feel as though it
has opinions about the love story unfolding upon it. Test:
pick three romantic beats spaced across the manuscript and
ask, in each, whether the specific landscape is doing
emotional work the prose could not have done from indoors. If
the same scene could occur in a generic interior, the
landscape is not yet the love language.

### The Stoic Unravelling

Breaking down the laconic western hero's emotional defences.
This must be gradual and costly — each word of feeling
extracted like a splinter. The stoic character does not
suddenly become articulate about emotions; they show love
through action, protection, sacrifice, and the rare,
devastating honest sentence. The genre's signature character
is deeply visible in the inheritance — the laconic cowboy who
speaks once when others would speak ten times, whose silences
are more eloquent than other men's speeches — and the romance
turns on the protagonist's slow access to what lies behind
that silence.

Track the progression carefully: early chapters should feature
actions that speak louder than dialogue, middle chapters
should crack the reserve with moments of inadvertent honesty
(the line that escapes him before he can stop it), and the
climactic emotional reveal should feel like a dam breaking,
not a tap turning on. The progression has visible stations: the
first unfunny truth admitted, the first apology offered without
prompting, the first request made (the stoic asks for nothing,
so the first ask is enormous), the first spoken endearment, the
first declaration that uses the word the genre has been
withholding.

The reader must feel that this person has never said these
words to anyone, and likely never will again. Catalogue the
small betrayals of composure: the hand that lingers a moment
too long, the unnecessary detour past someone's property, the
project that conveniently requires a second pair of hands, the
particular silence that has become specific to her. The body
confesses what the mouth refuses to. Test the depth: can the
reader, in the climactic chapter, look back at a moment in
chapter five and see the feeling that was already there, just
unspeakable? If yes, the unravelling has been earned. If the
emotion arrived in chapter twenty without preparation in
chapter five, the reveal is unmotivated and the genre's
signature pleasure has been forfeited.

### The Work as Courtship

Ranch work, livestock management, and outdoor labour as
romantic activity. Mending fences together. The calving scene
that reveals tenderness. Breaking a horse as metaphor for the
relationship. Physical work creates proximity, shared purpose,
and mutual respect — all foundations of western romance. The
form's distinctive contribution to the broader romance genre
is the recognition that cooperative competence under
demanding conditions is itself a form of intimacy that
indoor genres cannot reproduce.

The key is specificity: readers want to feel the weight of
the fence post, smell the hay in the barn, hear the calf's
first bawl, taste the trail dust at the back of the throat,
register the precise muscle exhaustion of a long day in the
saddle. When the labour is rendered with sensory precision,
the romance embedded within it gains authenticity; when the
labour is rendered as generic outdoor activity, the courtship
floats. Each work scene should also have a specific operational
purpose — the cattle moved, the barn rebuilt, the foal born,
the hay cut and baled — that the reader can track. Generic
work ("they worked the ranch all morning") is the failure
mode; specific tasks with concrete outcomes are the technique.

Competence is deeply attractive in this genre — show characters
excelling at difficult, physical, meaningful work, and the
attraction writes itself. The shared meal after hard labour,
the quiet satisfaction of a job completed together, the trust
built by relying on someone in a crisis with livestock or
weather — these are the romantic set pieces of western
romance. Test: pick three work scenes and ask, in each,
whether the competence on display is specific (this exact task
done in this exact way), earned (the character has plausibly
become this competent), and visible to the romantic partner
(the partner is watching, registering, and being affected
without the prose telling the reader so). If all three are
yes, the work is courting; if any is no, the labour is
backdrop.

### The Community Witness

The small town or ranching community observing and influencing
the romance. The diner where gossip travels. The general store
owner who dispenses wisdom. The neighbour who notices the
protagonist's truck at the love interest's property at dawn.
The feed store proprietor who saw who was buying what for whom.
Community creates both support and pressure, and the
protagonists' relationship plays out before this audience
whether they choose it to or not.

In western romance, privacy is scarce and reputation is
currency. The community functions as both Greek chorus and
obstacle — celebrating matches it approves of, obstructing
those it does not. Treat the community as ensemble: each
significant member has a name, a place in the town's social
structure, a specific relationship to the central couple, and
an opinion (sometimes shifting across the book) about whether
this match should happen. The town should feel like a living
organism with its own memory and values, remembering old
feuds, celebrating new unions, and holding opinions about who
belongs with whom.

Use the ensemble cast to create humour, warmth, and tension in
equal measure, and remember that in a small town, every
romantic gesture has an audience — and an interpretation. The
craft requires that community members be people first and
plot devices second: the diner waitress is a person with her
own life, who happens to also notice things; the rancher
neighbour is a person with their own concerns, who happens to
have an opinion. Test: can the writer, for each named
recurring community member, name three things about that
person that have nothing to do with the romance? If not, the
community is chorus, not ensemble, and the witness function
is operating without the depth the genre's strongest
practitioners deploy.

### The Frontier Choice

The moment of choosing this life — the land, the hardship, the
isolation — and choosing the person who embodies it. This
choice must cost something: the city career abandoned, the
comfortable life rejected, the family expectation defied, the
income reduction accepted, the medical access traded for the
quiet. The frontier demands commitment, and so does the love.
The genre's commercial life and emotional resonance both turn
on this choice; without it, the love story occurs in a
landscape rather than being shaped by one.

This is the thematic heart of western romance: the idea that
the most meaningful life is not the easiest one. The happily-
ever-after is not a fairy tale ending but a clear-eyed
decision to embrace difficulty alongside beauty. The choice
must be specific (this particular city career, this particular
expected match, this particular life the protagonist had been
walking toward), made on the page (not summarised across a
chapter break), and acknowledged by the partner (the
recognition that the partner is choosing the harder life and
choosing the protagonist within it).

Write the choice scene with the full weight of what is being
surrendered and what is being gained. The reader should feel
that this love is worth the calloused hands and the early
mornings. The best western romances make the reader briefly
consider abandoning their own life for a ranch in Montana —
that is the power of the frontier choice rendered with
conviction. Test: at the moment of choice, can the writer
specify in two sentences what the protagonist is leaving and
what they are taking? Both columns must contain specific,
named, costly items; if either is generic, the choice is
unfelt.

### The Modern Frontier Calibration

Contemporary western romance has an inherited problem: the
genre's archetypes, from the laconic cowboy to the threatened
ranch to the small town that knows everyone, were largely
formalised in twentieth-century western fiction operating on
mid-twentieth-century rural assumptions. Today's American West
is not that West, and contemporary western romance must
calibrate against current rural reality without abandoning the
genre's mythos. The technique is balance, not replacement: the
form's enduring archetypes still work because they speak to
something true (the relationship between people and land, the
specific intimacy of cooperative labour, the moral weight of
community witness), but the surrounding texture must be
contemporary.

Specifically, contemporary western romance must engage with:
the financial precarity of small ranches and family farms; the
displacement pressures from corporate agriculture, oil-and-gas
extraction, and rural-to-urban land conversion; the climate
shifts altering grazing seasons, wildfire risk, and water
availability; the demographic changes reshaping rural towns
(the school that has closed, the clinic an hour further away,
the broadband access that hasn't arrived, the Spanish-speaking
ranch hand whose family has worked this land for generations);
the cultural shifts in western communities that the genre's
inheritance sometimes pretends are not happening (LGBTQ
ranchers and farmhands, the Indigenous communities whose
relationship to the land precedes and complicates the cowboy
inheritance, the Black western tradition long erased from
mainstream genre and now being rewritten back in by Beverly
Jenkins, Vanessa Riley, and others). The ranch in 2025 is
not the ranch in 1955; the genre's strongest contemporary
practitioners render the difference without abandoning what
the form does well.

The technique fails in two directions. The nostalgic-only
register pretends the contemporary West is unchanged from
mid-century myth and reads as a costume drama set in a
fictional past; the corrective-only register handles
contemporary issues without giving the genre's archetypal
pleasures, and reads as a contemporary novel that wandered
into a western-romance imprint. The calibrated middle —
contemporary realities visible in the texture of the prose,
genre archetypes operating in the structure — is where the
form's strongest current practitioners work. Test: does the
manuscript's rural world contain at least three concrete
markers of the present (a specific economic pressure, a
specific demographic reality, a specific environmental shift,
a specific cultural change), and are those markers shaping
character choices rather than sitting on the page as
acknowledgement?

### Western Romance AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the rugged cowboy melted her defences" | Show the specific gentle act |
| "the vast open land mirrored her freedom" | Show the specific landscape through her emotional state |
| "a man of few words but deep feelings" | Show the feeling through ONE specific action |
| "the ranch was a world of its own" | Show ONE specific ranch detail that matters |
| "dust and desire" | Show the specific dusty moment and the specific attraction within it |
| "the sunset painted the sky" | What is the character DOING during the sunset? |
| "he tipped his hat" | Show a more specific, less cliched gesture |
| "the frontier demanded strength" | Show the specific challenge |
| "wild horses couldn't drag her away" | Show the specific choice to stay and what it costs |
| "under the stars, they found each other" | Show the specific nighttime moment |
| "his calloused hands were surprisingly gentle" | Show the specific gentle action; "calloused but gentle" is the genre's most-collapsed line |
| "she'd never met a man like him" | Show what specifically distinguishes him through her observation |
| "the cowboy code demanded he protect her" | Cut "the cowboy code"; show his specific protective decision |
| "the open range called to her soul" | Show what specifically about this landscape stops her in her tracks |
| "a real cowboy" / "an authentic rancher" | Stop authenticating; show the specific competence in action |
| "the dust kicked up beneath the horse's hooves" | Show what the dust does in this specific moment — what the rider feels, what the landscape shows |
| "she felt at home for the first time" | Show the specific moment of homecoming through body and observation, not declaration |
| "the small town had a charm of its own" | Cut; show ONE specific charming detail through specific observation |

### Romance Masterclass — Western-Romance Calibration

The romance master file (romance.md) holds the canonical
romance frameworks: Heat Level Calibration, the 7-Element
Chemistry Scene Construction, the 6 Romance Character
Archetypes with character-build tests, Obstacle Layering
Quantitative, Light and Shade Heart-Monitor Rule, the
Differentiation Imperative, Hope-as-Resolution Calibration,
and Series Architecture. All apply directly to western-
romance, calibrated below to the genre's specific frontier-
constrained register.

**7-Element Chemistry Scene — Western-Romance calibration:**

- **Element 1 (Setup):** frontier hardship and isolation
  establish the stakes. Each Chemistry Scene must
  register the specific frontier conditions — weather,
  distance, livestock pressure, water-rights stress,
  raid threat, law-vs-justice frame, displaced-community
  context. The Setup must render the frontier as
  material weight on both leads' available choices.
- **Element 2 (Approach):** often through shared
  physical labour or shared danger — the cattle drive,
  the homestead repair, the wagon train, the storm
  shelter, the wounded animal needing care, the raid
  defended together. The proximity-pretext is
  frequently the work or the threat, not social
  occasion.
- **Element 3 (Banter Beat):** laconic register;
  frontier-specific subtext. The dialogue often carries
  embedded frontier-craft knowledge (livestock,
  weather-reading, terrain, shooting, herbal medicine,
  Indigenous-language fragments) that reveals character
  through fluency or struggle with the frontier
  vernacular.
- **Element 4 (Awareness Spike):** typically arrives
  during shared physical labour, shared danger, shared
  survival, or shared grief. The Spike is rendered
  through the body's competence under stress — the
  way one lead handles the rein, the way one loads
  the rifle, the way one binds the wound, the way one
  reads the weather.
- **Element 5 (Pull-Back):** the load-bearing pull-back
  is carried by frontier consequence — drought,
  raid, distance preventing return, unsettled law,
  displaced-community pressure, post-Civil-War or
  post-frontier trauma resurfacing. The leads cannot
  act because the frontier itself holds them
  separate or in danger.
- **Element 6 (Aftermath):** the work continues; the
  leads carry the moment forward into the next chore,
  the next ride, the next threat. Western-romance
  Aftermath beats often unfold against ongoing
  physical labour rather than in social retreat.
- **Element 7 (Hook):** the next frontier challenge —
  the cattle drive milestone, the weather change, the
  legal hearing, the next encounter with displaced
  communities, the message arriving from distant kin.

**6 Character Archetypes — Western-Romance calibration:**

- **The Wounded Lead** is trail-hardened, post-war
  (Civil War or earlier conflicts), displaced (loss
  of home community, forced migration), or grieving
  (recent loss of spouse, family member, way of life).
  The wound is structurally tied to frontier conditions
  — the work, the violence, the migration, the loss
  endemic to the period.
- **The Opposite Lead** configurations: the contrast
  outsider (Eastern visitor, schoolteacher, doctor,
  journalist), the returnee (coming back to the
  frontier after time away), the Indigenous figure
  with different relationship to the land (requires
  specific cultural research and respectful rendering),
  the rancher-vs-homesteader pairing, the lawman-vs-
  outlaw pairing.
- **The External Antagonist Force** is the frontier
  itself — drought, raid, blizzard, distance, unsettled
  law, settler-vs-Indigenous land conflict, post-Civil-
  War political pressure, the railroad as institutional
  force, the cattle baron, the absentee Eastern
  landowner.
- **The Found Family** in western-romance is often
  the homestead community, the trail crew, the small
  town network, the post-war unit, or the chosen
  family of survival. Frontier conditions produce
  tight kinship configurations.

**Obstacle Architecture — Western-Romance dominant obstacles:**

The Obstacle Layering Quantitative rules apply. For
western-romance, the dominant obstacle types are:

1. **Frontier hardship** (drought, distance, weather,
   isolation, livestock pressure, water rights)
2. **Land pressure** (homestead vulnerability, cattle
   range, water access, the railroad's path)
3. **Settler / Indigenous / displaced-community frame**
   (the genre's most ethically loaded obstacle
   architecture; requires specific research and
   respectful, complex rendering — never reduced to
   sympathetic-savage or threat-without-context tropes)
4. **Post-Civil-War or post-frontier trauma** (one or
   both leads carrying war-wound, post-conflict moral
   compromise, displaced-community grief)
5. **Distance and communication delay** (the frontier's
   structural separation — letters that take weeks,
   journeys that take months, news that arrives after
   it could change anything)

**Differentiation Imperative — Western-Romance specific axes:**

- Specific era (pre-Civil-War vs Civil-War-aftermath
  vs post-frontier vs modern-Western — each with
  specific constraint architecture)
- Specific geography (Texas, Montana, Wyoming, Oregon
  trail, California, Mexican borderlands — each with
  specific cultural and ecological texture)
- Specific ethical framing of the period's racial /
  Indigenous / settler architecture (the genre's
  ethical responsibility is to render this specifically
  and respectfully rather than as backdrop)

**Ending Calibration — Western-Romance patterns:**

Western-romance typically delivers HEA in contemporary
Western register and HFN in trail-or-frontier-set
western-romance where the broader frontier context
remains active. The Hopeful ending is more common in
literary western-romance dealing with displacement,
loss, or the genre's reckoning with settler-Indigenous
history — where conventional union may not be the
genre's most honest resolution. Where the manuscript
delivers Hopeful, it must satisfy romance.md's three
requirements (earned, specific, resonant).

## Genre-Specific Revision Rules

Six revision passes specific to western romance, each with a
single question, run cover-to-cover before the next begins.
Western romance has two reader populations whose tolerances
differ and whose detection thresholds for failure are
unusually low: rural and equestrian readers who detect
ranching, livestock, and horse-handling errors faster than the
writer who researched online; and readers who came for the
mythos and detect the moment the genre's archetypes have
slipped into pastiche. The passes below are ordered to
surface technical authenticity failures first (the rural
reader's territory), landscape and character depth next
(where the genre's craft pleasures concentrate), and
romanticisation balance last (the question of how the genre's
mythos and current rural reality are calibrated against each
other).

### Pass 1: Western Authenticity Audit

Verify every ranching, agricultural, and rural detail in the
manuscript: livestock management, seasonal work cycles,
equipment, terminology, breeds, regional crops and grasses,
fence types, water rights, brand registration, equipment
maintenance, weather patterns by region and season, distances
between locations, firearms and ammunition appropriate to the
era and place, vehicle types, tack and saddle particulars,
horse gaits and handling, herd dynamics, calving and lambing
season specifics, hay and feed cycles, and the actual
logistics of running a ranch or farm at the scale the book
depicts.

Build a fact ledger during revision: every checkable claim,
with the source the writer is relying on and a reliability
assessment. Cross-reference the specific region's geography,
climate, and agricultural practices — Wyoming ranching is not
Texas ranching is not New Mexico ranching is not the Pacific
Northwest is not the Sonoran Desert. Confirm that distances
between locations are plausible (the protagonist who drives
"into town" for milk in a setting where the nearest town is
ninety minutes each way is wrong); that weather patterns match
the season and setting (the snowstorm in southern Arizona in
April; the spring calving in a region whose calving is fall);
that any firearms, vehicles, or tools mentioned are appropriate
to the period and place.

Pay particular attention to horse handling. Western romance
readers are often equestrians who will notice incorrect tack,
impossible gaits, unrealistic horse behaviour, dangerous
practice (the protagonist who tied a horse to a moving vehicle;
the rider who pulled hard on a curb bit; the foal turned out
with a mare in heat). A character galloping for hours on end
without changing horses, saddling a horse incorrectly, or
mounting from the wrong side will break trust immediately.
Where the manuscript depicts livestock work in detail, verify
the procedure is correct (the calving difficulty resolved as a
veterinarian would actually resolve it, not as the writer
imagined the procedure). Where the manuscript invents details
to avoid technical depth, the reader will sense the avoidance
and lose confidence; the genre rewards specificity.

### Pass 2: Landscape Integration

Read every scene for setting presence. The western landscape
should be felt in every chapter — weather, terrain, light,
distance, sound, scent, the specific quality of air at this
elevation in this season. Check that the environment actively
shapes the romantic encounters rather than merely decorating
them.

Characters should relate to the land as a living presence with
its own moods, demands, and effects. Flag any chapter where
the setting could be swapped for a generic location without
altering the scene. In strong western romance, the landscape
determines what happens: the blizzard that traps two people
together, the drought that threatens the ranch, the wildfire
that demands cooperation, the spring runoff that floods the
crossing they had planned to use, the dust storm that turns
day into night and forces them indoors. The landscape is the
plot's collaborator, not its scenery.

If the romance could unfold identically in a city flat, the
western element is not pulling its weight. Verify that at
least one sensory detail per scene anchors the reader in the
specific western environment — one detail, not a catalogue.
The strongest western romance prose is dense in sensory
particulars at the level of the line: the smell of hay after
a thunderstorm, the specific cold of high-desert nights in
summer, the sound a horse makes recognising the rider in a
dark barn, the colour of light through stock-trailer slats.
Test: pick three scenes spaced across the manuscript and
identify the single sensory detail in each that could not have
appeared in a non-western book. If any scene lacks one, the
landscape integration is uneven.

### Pass 3: Stoic Character Depth Check

Review the laconic character's dialogue and actions across the
manuscript. Silence must be characterised — there is a
difference between a character who cannot articulate feelings,
one who has been taught not to, one who chooses not to in
specific company, and one who simply is not a verbal person.
Each of these silences sounds different on the page, and the
character's specific kind of silence must be consistent and
legible. Check that emotional revelations are earned through
the full arc and not delivered in a sudden out-of-character
monologue.

Map the progression of emotional openness across chapters: it
should be a clear upward trajectory with setbacks that feel
motivated by character rather than plot convenience. The
setbacks are not failures of progression but part of it — the
stoic character closes back down after a rare moment of
opening because that is what stoic characters do, and the
reclosure makes the next opening cost more. Verify that the
stoic character's internal life, whether shown through
narration or action, is rich enough that the reader understands
what is being withheld; a stoic character whose interior is
also empty is not stoic, just under-imagined.

Count the character's words in key scenes. A stoic character
who delivers a three-paragraph speech about their feelings has
broken character. The most powerful emotional moments in
western romance often contain fewer than ten words: "I was
wrong"; "Stay"; "I needed you here"; "It's yours, if you'll
have it." The genre's contract trades the missing speech for
the weight of what is said. Ensure the dialogue stays lean
and the emotions stay enormous. Test: pick the manuscript's
three most emotionally significant moments and count the stoic
character's words in each. If any exceeds thirty, the
character has been broken to deliver a beat the prose should
have carried.

### Pass 4: Community Voice Consistency

Verify that the small-town ensemble speaks and behaves
consistently across the manuscript. Each community member
should have a distinct voice and role. Check that community
interference feels organic rather than contrived. The town
should feel lived-in, not populated with stock characters
from a writers'-conference handout (the wise old rancher; the
gossipy diner waitress; the suspicious sheriff; the loyal best
friend with no interior life of her own).

Review each secondary character for consistency of dialect,
opinion, and behaviour across their appearances. Confirm that
the community's collective response to the romance evolves
naturally. A town that universally approves or disapproves
from page one is less interesting than one where opinions
shift as the relationship develops, where some neighbours come
around and others don't, where the elderly rancher who said
nothing publicly turns out to have made the introduction at the
right moment. The community is most interesting when its
members disagree with each other about the central romance.

Check that the community serves the romance without
overwhelming it. Secondary characters should illuminate the
central couple — the old-timer who sees the truth before the
protagonists do, the rival who forces a declaration, the
friend who provides a sounding board, the family member whose
disapproval gives the choice its weight. If any community
member exists only for comic relief, deepen them or cut them.
Test: pick three named recurring community members and write
two sentences for each describing their interior life as you
imagine it — the concerns they have that have nothing to do
with the romance, the events of their day before they
encountered the protagonists, the things they want for
themselves. If the writer cannot answer these for any
recurring named character, that character is chorus, not
ensemble.

### Pass 5: Rural Life Romanticisation Balance

Ensure the manuscript neither over-romanticises nor dismisses
rural life. The beauty of the landscape should coexist with
genuine hardship — the isolation, the financial precariousness,
the physical exhaustion, the medical access two hours away,
the school that has closed, the broadband that hasn't arrived.
Authentic western romance finds beauty in difficulty, not
despite it.

Check for scenes that acknowledge the real costs of this life:
the veterinary bill that cannot be paid; the loneliness of
winter when the road is closed for three days; the physical
toll of decades of manual labour visible in a parent's
walking; the stillborn calf and the loss of the year's
margin; the auction of a neighbour's property after the
drought made the operation impossible to sustain. The happily-
ever-after should feel earned precisely because the reader
understands what this life demands.

Romance without realism is fantasy; realism without romance is
misery. The balance point is specificity — a sunset is
romantic, but a sunset watched from a porch after fourteen
hours of fencing in August heat, with sore muscles and a cold
beer that has finally cooled in the fridge after the
generator came back on, is western romance. Verify that the
joy in this manuscript is the particular joy of people who
have worked hard for the right to rest together. Test: pick
three of the manuscript's most romantic moments and ask, in
each, whether the surrounding context has earned the moment
through difficulty acknowledged. The romantic moments should
land as relief and reward, not as the only register the book
operates in.

### Pass 6: The Modern Reality Audit

Contemporary western romance has a particular failure mode the
historical sub-genre does not: the temptation to write today's
West as if it were 1955's West with cell phones added.
Verify that the manuscript's contemporary setting is in fact
contemporary, with current rural realities visible in the
texture of the prose. Specifically check:

- **Economic context** — small ranches and family farms operate
  under different financial conditions than mid-century
  generational ranches. Land prices, beef and crop markets,
  insurance, healthcare, succession planning, the consolidation
  pressure from corporate operations, the specific mathematics
  of profitability for a small operation in this region. Where
  the manuscript depicts a ranch operation, can it survive on
  what is shown? If the family ranch generates the lifestyle
  shown without the prose acknowledging where the money
  actually comes from (the off-ranch job, the inherited
  capital, the side income from a Forest Service contract or a
  guest cabin), the economic reality has been obscured.
- **Demographic context** — the contemporary American West is
  not exclusively white, exclusively English-speaking, or
  exclusively settler-descended. Spanish-speaking ranch hands
  whose families have been on this land longer than the
  protagonists'; Indigenous communities whose relationship to
  the land precedes the cattle industry; Black ranchers and
  cowboys whose history was largely erased from twentieth-
  century western fiction and whose contemporary presence
  contemporary western romance must acknowledge if the genre's
  realism is to be credible; LGBTQ rural communities present in
  every state. Where the manuscript's West is monochromatic in
  ways the actual region is not, the demographic reality has
  been obscured.
- **Environmental context** — climate change is reshaping
  rural western life: wildfire risk and season length, water
  availability and rights conflicts, grazing season shifts,
  insurance availability or its loss, the species moving in or
  out of regions where they did or did not previously occur.
  Where the manuscript treats environment as static (the
  reliable spring runoff, the eternal grass, the dependable
  weather), the environmental reality has been obscured.
- **Cultural context** — rural values, political alignments,
  religious life, family configurations, generational
  attitudes vary across regions and have shifted within
  regions over the past two decades. Generic "small-town
  values" treatment misses the specifics that make today's
  rural communities recognisable as themselves.

The pass is not asking the manuscript to abandon the genre's
mythos — the genre's archetypal pleasures still work — it is
asking the texture to be contemporary where the book is
contemporary. Test: identify three concrete markers of the
present in the manuscript (specific economic pressure,
specific demographic reality, specific environmental shift,
specific cultural change). Are they shaping character choices
rather than sitting on the page as acknowledgement? If the
markers are not present at all, or are present only as
gestures the protagonists do not have to reckon with, the
book has shaded toward the nostalgic register and the genre's
contemporary contract has not been honoured.

## Names & Patterns to Avoid

### Forbidden Patterns
- **The city slicker transformation**. The urban character should not abandon all sophistication; the best western romances find synthesis between urban and rural values rather than treating city life as inherently hollow
- **The noble savage**. Indigenous characters must be fully realised people, not spiritual guides or plot devices for settler protagonists; their stories deserve their own complexity and agency
- **Poverty as picturesque**. Financial hardship in ranching should feel real and stressful, not charmingly rustic; the leaking roof and the unpaid feed bill are not quaint details
- **The lone cowboy cliché**. Ranching is community-dependent; the completely self-sufficient loner is a myth that undermines the genre's strength in depicting interdependence
- **The magical animal**. Horses and dogs should behave like real animals, not like furry therapists who intuitively sense emotional states and intervene at dramatically convenient moments
- **The woman who just needs taming**. Any suggestion that a strong-willed female character needs to be subdued or domesticated by a cowboy belongs in the previous century; mutual respect is non-negotiable

### Cliché Setups to Avoid
- The city woman who inherits a ranch from a relative she never met and must learn to love the land from a handsome neighbouring rancher
- The cowboy who has never been to a city and is comically baffled by technology, reducing a competent professional to a punchline
- The ranch that is about to be foreclosed unless someone saves it through a conveniently timed rodeo victory or inheritance
- The rodeo champion who is too proud to admit injury or ask for help, creating conflict through stubbornness alone rather than genuine values in tension
- The conveniently timed thunderstorm that forces the couple into a cabin together within the first three chapters
- The mean ex-girlfriend from the city who exists solely to make the rural love interest look wholesome by comparison
- The elderly relative who dispenses folksy wisdom in aphorisms and exists solely to nudge the protagonists together

### Naming Considerations
- Western names should feel grounded and regional. avoid names that feel too urban or cosmopolitan for the setting and period
- Ranch and property names carry weight in western romance; choose names that evoke the landscape and the family history tied to the land
- Avoid names that are too similar to iconic western characters (no more Wyatts, Docs, or Sundances) unless deliberately invoking and subverting the tradition
- Consider heritage-appropriate naming for the specific region. Texas, Montana, Wyoming, and Colorado have distinct naming cultures shaped by their settlement histories
- Nicknames and shortened forms are common in rural communities; let characters earn their names through relationship and familiarity
- Town names should feel authentic to the region. consider geological features, founding families, or historical events as naming roots rather than generic pastoral labels
- Avoid alliterative ranch names (Sunny Springs, Peaceful Pastures) that feel manufactured; real ranch names tend to be blunt and descriptive (Broken Fence, Red Mesa, Two Creek)

## Comp Titles

Western-romance's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Lonesome Dove* — Larry McMurtry (1985): the literary-western lineage; informs the romance subgenre's frontier register.
- *The Searchers* — Alan Le May (1954): the western archetype that romance-western draws structural texture from.
- *Brokeback Mountain* (story) — Annie Proulx (1997): queer western register with romance-arc; broader western-romance lineage.

### Contemporary (current best-in-class)

- *The Cowboy and the Heiress* — Linda Lael Miller / similar 2010s western-romance: the Stetson-and-stables category benchmark.
- *Catch and Release* — Lauren Layne / Marie Force similar contemporary cowboy-romance.
- *Yellowstone-adjacent contemporary western-romance* — various 2018+: rancher-romance with modern setting.
- *Rules for a Cowboy* — Anne McAllister: classic Harlequin western-romance template.
- *Buffalo Soldier* — various: the Civil-War-aftermath western-romance.
- *The Cowboy Way* — Robyn Carr (2017+): small-town-western with romance series architecture.

## Cover Design Specifications

### Recommended Visual Styles
- **Photorealistic**. The dominant style for western romance; real couples, real landscapes, real horses convey the authenticity readers demand from this genre
- **Illustrated**. Works beautifully for lighter or historical western romance; hand-painted landscapes, watercolor sunsets, and stylized cowboy silhouettes signal warmth and nostalgia
- **Vintage**. Ideal for historical western romance; aged textures, sepia tones, and retro typography evoke the frontier era and classic western storytelling
- **Cinematic**. Widescreen landscape compositions with dramatic lighting; suits epic-scale ranch sagas and multi-generational western romance series

### Genre Cover Aesthetics
- **Styles:** Sun-drenched landscapes with golden hour lighting, rugged textures (leather, wood, denim), wide-open compositions emphasizing vast sky and land, intimate couple poses against sweeping backdrops, silhouette figures on horseback at sunset
- **Colours:** Dusty browns and warm tans (leather, earth, sand), sunset oranges and burnt amber, denim blues and faded indigo, sage green and prairie gold, warm copper and weathered bronze. the palette should feel sun-warmed and grounded
- **Elements:** Cowboys and cowgirls (hats, boots, belt buckles), horses (saddled, galloping, or nuzzling), ranch buildings (barns, fences, windmills), vast open landscapes (mountains, prairies, rolling hills), sunsets and golden light, lassos and tack, pickup trucks on dusty roads
- **Typography:** Weathered serif or slab-serif fonts with weight and presence; sometimes rope-textured or branded-style lettering for the title; author name typically in a complementary clean serif; script fonts used sparingly for romantic emphasis

### Subgenre Variations
- **Contemporary Western Romance**. Photorealistic dominates; modern clothing mixed with cowboy boots and hats; pickup trucks alongside horses; slightly brighter, cleaner colour palette
- **Historical Western Romance**. Vintage textures and aged colour treatment; period-appropriate clothing; frontier landscapes; sepia or warm-toned overlays; more illustrated options
- **Cowboy Romance (light/sweet)**. Brighter palette, more illustrated style acceptable; emphasis on charm and warmth over ruggedness; softer sunset tones
- **Ranch Romance (steamy)**. Photorealistic shirtless cowboy imagery; darker, moodier tones; close-up couple compositions; more dramatic lighting

### Market Positioning
Western romance covers must immediately signal "authentic western + passionate romance" on Amazon thumbnails. The landscape or western elements should be visible even at small size. a horse silhouette, a cowboy hat, a barn against a sunset. Warm earth-tone palette distinguishes western romance from other romance subgenres at a glance. Readers scroll quickly; the combination of rugged western imagery with romantic couple posing or warm lighting is the instant genre signal. Series should maintain consistent landscape/colour treatment across all volumes to build brand recognition.

### Cover Design DON'Ts
- No urban settings, city skylines, or modern architecture. the cover must feel rural and western
- No cold colour palettes (icy blues, grays, stark whites). western romance is warm-toned
- No gothic or dark horror aesthetics. wrong emotional register entirely
- No modern technology visible (smartphones, laptops). even contemporary westerns should feel timeless on the cover
- No cartoonish or comic-style illustrations. the genre demands a degree of seriousness and authenticity
- No overly polished, studio-lit glamour photography. western romance covers should feel natural, sun-weathered, and grounded
- No generic romance couple without western signifiers. without a hat, horse, barn, or landscape, it could be any romance subgenre
- No neon or fluorescent colours. the palette should come from the land, not a nightclub
