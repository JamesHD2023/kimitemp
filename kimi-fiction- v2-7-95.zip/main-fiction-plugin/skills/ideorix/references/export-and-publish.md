---
name: export-and-publish
description: "Format your manuscript for publishing — DOCX export, KDP metadata, and submission-ready files"
user-invocable: false
---
<!-- (c) 2025 James Harvey Media / Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with `> **Powered by Ideorix** — The Manuscript & Screen Engine` before any other output.

# Export & Publish

Prepare your finished manuscript for publication or submission.

## File Location Discipline (MANDATORY — HARD GATE — applies to every output this flow produces)

**All Phase 6 deliverables MUST be written into the
canonical project folder structure.** Specifically:

- **Manuscript exports** (DOCX, Atticus DOCX, EPUB, PDF,
  RTF, Markdown, SMF, Fountain, FDX) →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.{ext}`
- **KDP metadata** →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-kdp-metadata.{ext}`
- **Marketing assets** (cover concepts, blurbs, social
  pack, query letters, trailer assets) →
  `~/Documents/Ideorix-Projects/[Title]/marketing/...`
- **Editorial / verification reports** generated during
  Phase 6 →
  `~/Documents/Ideorix-Projects/[Title]/engine-data/reports/...`

See `core-pipeline.md` § File Location Discipline for the
full canonical project layout.

**HARD GATE — BLOCKING.** Outputs MUST NOT be written to:

- The agent's working directory
- The parent `~/Documents/Ideorix-Projects/` folder (the
  most common bug — files end up alongside other projects
  instead of inside this project's subfolder, making them
  effectively invisible to the user when looking in the
  project folder)
- A sandbox or temporary path
- Any non-canonical location

The user MUST be able to open every Phase 6 deliverable
in their own file explorer at the canonical project
subfolder the moment processing completes. The Phase 6
Delivery flow has historically been vulnerable to dropping
manuscript exports in the parent `Ideorix-Projects/`
folder rather than the project's `[Title]/manuscript/`
subfolder; this section is the explicit counter-protocol.

When invoking any of the per-format specs below
(`format-docx.md`, `format-epub.md`, etc.), this
File Location Discipline binds them — each format spec
also reiterates its specific destination, but THIS gate
is the authoritative one and supersedes any ambiguity.

## Typography Sweep Gate (MANDATORY — HARD GATE — runs before every prose export)

Before assembling the final manuscript file (DOCX, EPUB, PDF,
SMF, RTF, Markdown, Atticus DOCX), run `typography-sweep.sh`
against **every chapter file** in
`~/Documents/Ideorix-Projects/[Title]/manuscript/chapters/` (or
the equivalent chapter source directory).

```sh
for chapter in ~/Documents/Ideorix-Projects/[Title]/manuscript/chapters/*.md; do
    bash scripts/typography-sweep.sh "$chapter" || FAIL=1
done
```

**HARD GATE — BLOCKING.** If any chapter fails the sweep:

1. Halt the export flow.
2. Report the per-chapter artifact list to the user.
3. Wait for resolution (user normalizes, or explicitly opts-in
   to ASCII target via `--target ascii` re-run).
4. Re-run the gate before proceeding.

**Rationale:** the engine's Edit-tool typographic-fidelity
discipline (`core-pipeline.md` § Edit-Tool Typographic Fidelity)
is preventive — it stops curly-vs-ASCII mismatches from being
inserted during normal Edits. The sweep is the detective layer:
even if an artifact slips through (paste-in, importer, partial
Edit, manual user touch-up), the sweep catches it before any
publishable file is assembled. See `typography-sweep.md` for
the full spec, exit codes, and category list.

**Skipped only when:**

- The user has explicitly declared ASCII typography for the
  manuscript (rare — typically technical / programming books
  with heavy code blocks). In that case the gate runs with
  `--target ascii` and inverts.
- The output format is intentionally raw text without typography
  enforcement (e.g. Fountain screenplay, where Courier-style
  ASCII is the format convention — Fountain exports skip this
  gate and route to their own format spec).

## Available formats

| Format | Use case |
|--------|----------|
| **DOCX** | Industry-standard manuscript format (Shunn-style) with proper margins, headers, page breaks |
| **EPUB 3.3/3.2** | Universal vendor-independent e-book format for all major retailers |
| **PDF** | Print-ready with proper pagination and trim sizes |
| **Fountain** | Screenplay format — plain-text markup compatible with Final Draft, Highland, Fade In |
| **Markdown** | Clean plain text for version control and editing |
| **SMF** | Standard Manuscript Format for agent/publisher submission |
| **RTF** | Rich Text Format for maximum compatibility |
| **KDP Metadata** | Amazon Kindle Direct Publishing — title, subtitle, description, keywords, BISAC categories |
| **Query Package** | Query letter + synopsis + sample chapters for agent submissions |

For full format specifications, see `publishing-formats.md`.

## How to start

Say any of:
- "Export my manuscript as DOCX"
- "Generate KDP metadata"
- "Prepare my book for Amazon"
- "Create a query package"
- "Format for submission"

## What gets generated

### DOCX Export
- Title page with author name and word count
- Properly formatted chapter headings
- Standard manuscript margins (1 inch)
- Double-spaced, 12pt Times New Roman / Courier
- Page headers with author name and title

### KDP Package
- Book title and subtitle suggestions
- HTML-formatted book description
- 7 keyword phrases (optimized for Amazon search)
- BISAC category recommendations
- Pricing tier suggestion based on word count

> **Tip:** Always run the editorial pipeline before exporting. Clean prose makes a better first impression.
