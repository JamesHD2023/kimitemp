---
name: catalog-overview
description: "Cross-project status console — auto-discovers every project in ~/Documents/Ideorix-Projects/, reports per-project state and cross-catalog patterns. Engine-agnostic; mirrored across fiction and non-fiction engines."
version: "2.3.0"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*


# Catalog Overview

## Purpose

A cross-project status console that scans every project in
`~/Documents/Ideorix-Projects/` (fiction, non-fiction, screenplay;
current-schema and legacy), reports what's been done and what's
missing per project, surfaces gap and opportunity patterns across
the catalog, and saves a date-stamped **Catalog Report** in `.md`,
`.docx`, or `.pdf` on demand.

Catalog Overview is **trigger-invoked from any session**. Users
reach it via direct trigger phrases ("Catalog status",
"Project status", "Show me everything", "Status report",
"What's done and what's not", and others — see SKILL.md
Direct Triggers > Catalog / Status). It is no longer
surfaced on the Front Gate menu (demoted at v2.3.5 — running
the full catalog scan is slow relative to its frequency of
use; most users only need cross-project status occasionally,
and the direct-trigger access is the right level for that
frequency).

For per-project status (the much more common need), users
typically ask "what's the status of project X?" in any
session and get a focused, fast answer without invoking the
catalog-wide scan. Catalog Overview remains the right tool
when a true cross-project view is wanted.

**Catalog Overview is engine-agnostic.** The same logic runs from
either the fiction or non-fiction engine because it scans all
project types. Spec files are byte-identical across engines and
enforced by `spec-lint.sh` Check 7 (`check_mirror_identity`).

## When to Use

- **"Studio overview"** / **"Catalog status"** / **"Project status"**
  — direct trigger phrases routing to Catalog Overview
- **"Show me everything"** / **"Where am I?"** / **"All my projects"**
  / **"Status report"** / **"What's done and what's not"** — natural
  language triggers, all routed to Catalog Overview
- Mid-session, when the user wants a cross-project view without
  losing their current project context

## Capabilities

| Capability | Behaviour |
|---|---|
| Auto-discovery | Scans `~/Documents/Ideorix-Projects/` recursively (`maxdepth 2`) for project folders of any age |
| Type classification | Three-stage classifier: explicit `project-config.md` → filesystem fingerprinting → mtime sweep for activity |
| Per-project status | Phases (Setup → Bible → Generation → Editorial → Delivery), tools run, components produced, age, dormancy |
| Legacy handling | Pre-schema projects flagged `[legacy]`; missing fields report as "unknown — pre-schema" rather than "missing — needs work" (no nagging) |
| Cross-catalog patterns | Series potential, genre concentration, world-building economy, comp drift, production bottlenecks, screenplay-novel pairs |
| Manual sales tracking | Optional per-project `sales-log.md` (markdown table; ebook / KU / print / audio + ad spend; multi-currency); see `sales-log-format.md` |
| Per-pen-name aggregation | Last-month net margin per pen name, one row per currency (no conversion) |
| Sales-derived flags | 6 opportunity flags (ebook-no-audio, audio-no-sales-6mo, low-performer-net, stale-log-only-if-started, ad-spend-≥80%, KU-heavy-no-audio); only fire on projects with a log present |
| Export | Markdown / `.docx` / `.pdf` via the catalog render script (pandoc-based with markdown-only fallback when pandoc not installed) |
| Sales Summary export | Dedicated sales-only export (`{YYYY-MM-DD}_sales-summary.{md,docx,pdf}`) — share figures with an accountant without exposing manuscript state. Same pandoc pipeline, narrower template (`sales-summary-template.docx`). |

## Input Requirements

- **None.** Catalog Overview is read-only and requires no input
  beyond the project folder existing on disk.
- If `~/Documents/Ideorix-Projects/` does not exist, the engine
  offers to create it and reports an empty catalog.

## Output

- **On-screen dashboard** — primary table (one row per project),
  per-pen-name aggregation block, gap / opportunity flags
- **Catalog Report file** (optional, on save prompt) — `.md`
  always available, `.docx` and `.pdf` via pandoc; saved to
  `~/Documents/Ideorix-Projects/_catalog-reports/{YYYY-MM-DD}_catalog-overview.{md,docx,pdf}`
- **Sales Summary file** (optional) — sales-only, narrower
  export for sharing with an accountant without exposing
  manuscript state. Triggered by `"Sales summary"` / `"Sales
  report"` / `"Print sales"` phrases or by picking option 5 in
  the save prompt at the end of a Catalog Overview run.
  Saved to `~/Documents/Ideorix-Projects/_catalog-reports/{YYYY-MM-DD}_sales-summary.{md,docx,pdf}`.

  **Important caveat:** Sales Summary is a *snapshot view*, not
  a tax / accounting document. It captures last-month figures,
  totals, trends. It does NOT include the fields a tax filing
  needs (transaction dates, jurisdictions, expenses, capital
  gains calculations). For "see / share my numbers in a clean
  printable format," it is sufficient. For "file my taxes from
  this," it is not. Tax-grade export is a separate, future
  feature.

## Routing

- **Protocol:** `→ See catalog-overview-protocol.md` for the full
  scan + render pipeline
- **Sales-log format:** `→ See sales-log-format.md` for the
  optional per-project `sales-log.md` markdown table schema

## Boundaries (out of scope for v2.3.0)

- **No project schema migration.** Catalog Overview reports legacy
  state read-only. Migration tool pending platform integration.
- **No external sales data parsing.** No KDP CSV, no ACX reports,
  no platform API integration.
- **No automated monthly performance loops.** On-demand only.
- **No tax / accounting export grade.** The report is a snapshot
  view (last-month figures, totals, trends) — not a tax filing.

## No-Nag Principle

Catalog Overview never nags. Pre-schema projects are reported as
`[legacy]` with `unknown — pre-schema` for fields they don't have,
rather than `missing — needs work`. Tools that have never been run
are noted but never demanded. The user picks what to act on.

**Sales tracking is opt-in.** Projects without a `sales-log.md`
are reported as `(no log)` and never flagged as needing action.
The Front Gate never asks for sales data. Catalog Overview never
prompts the user to log. The stale-data flag fires only on
projects that already have a log started — never on projects
that simply never began tracking.
