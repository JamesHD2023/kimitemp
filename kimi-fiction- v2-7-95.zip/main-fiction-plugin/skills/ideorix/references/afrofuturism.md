---
name: afrofuturism-genre
description: Genre-specific instructions for Afrofuturist fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Afrofuturism. Genre Plugin

## Metadata
- id: afrofuturism
- name: Afrofuturism
- icon: 🌌
- category: Fiction
- minWords: 3000
- targetWords: "3,000-4,500"
- recommendedBeatStructures: ["The Hero's Journey", "Three-Act Structure", "Seven-Point Story Structure", "Worldbuilding Beats"]

## Subgenre Options
Present during setup:
- **Space Afrofuturism**. Black futures among the stars: interstellar travel, alien contact, space colonisation reimagined through African and diaspora perspectives; Octavia Butler, Nnedi Okofor territory
- **Tech Afrofuturism**. Technology shaped by African innovation and philosophy: AI, biotech, virtual reality, advanced materials; Wakanda-adjacent futures where African knowledge drives the tech
- **Ancestral Afrofuturism**. Past, present, and future collapse: ancestral knowledge as advanced science, spiritual connection as technology, African cosmology as physics; the ancestors were the first futurists
- **Post-Colonial Afrofuturism**. Africa after liberation: what does the continent become without the colonial interruption? Imagined nations, recovered technologies, healed histories
- **Diaspora Afrofuturism**. The scattered future: Black communities globally reimagining their possibilities; the Middle Passage as science fiction, the diaspora as interstellar journey
- **Mythic Afrofuturism**. African mythology as speculative framework: Orishas, Anansi, Mami Wata as future entities; the gods reimagined in technological contexts

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-4,500 words
- Pacing: Varies by subgenre. space opera pacing for adventure, literary pacing for ancestral work; always: the rhythm should reflect the specific cultural tradition being drawn from
- Must open with: A moment of cultural specificity rendered in a speculative context. the reader should feel BOTH the African/diaspora tradition AND the future; the familiar made futuristic, the futuristic made home

BEATS PER CHAPTER
1. Cultural Grounding Beat. African or diaspora cultural specificity: language, custom, philosophy, art, food, community practice; rendered in the speculative context
2. Speculative Beat. The future technology, world, or condition that distinguishes this world from ours; the speculative element that carries the story
3. Ancestral/Memory Beat. Connection to the past: ancestors, history, cultural memory, the thread from Africa through diaspora to future; time is not linear
4. Liberation Beat. The question of freedom: colonial legacies confronted, systemic oppression reimagined, liberation as ongoing project
5. Wonder Beat. The beauty of the world: Afrofuturism creates BEAUTIFUL futures; the aesthetic pleasure of imagining Black excellence and possibility

AFROFUTURISM ARCHITECTURE
- CULTURAL SPECIFICITY is foundational: not generic "African" but WHICH culture, WHICH tradition, WHICH language, WHICH cosmology
- The PAST IS THE FUTURE: African knowledge systems, philosophies, and technologies are not primitive. they're advanced; the genre reimagines them as the basis for future development
- LIBERATION is always present: Afrofuturism exists because Black futures were systematically denied; every story is an act of imagining what was forbidden to imagine
- BEAUTY is political: creating beautiful Black futures is resistance; the aesthetic choices are never merely decorative
- COMMUNITY over individualism: African philosophy (Ubuntu, collective responsibility, extended family) shapes how the future works; the isolated hero is not the default
- TECHNOLOGY reflects CULTURE: the tech in Afrofuturist worlds should feel shaped by African aesthetics, philosophy, and values. not just Western tech with a different skin
- DIASPORA AWARENESS: the story may be set in Africa, in space, in the diaspora. but the awareness of dispersal, connection, and recovery runs through it
- POV: First person (intimate, often the voice of someone navigating between worlds) or third person (allows scope for world-building and community perspective)

WORLD-BUILDING PRINCIPLES
- Technology inspired by African innovation: not just computers but systems that reflect communal values, oral tradition, ecological thinking
- Social structures based on African political philosophy: not Western democracy or dictatorship by default
- Architecture and design reflecting African aesthetics: not glass-and-steel generic futurism
- Music, art, and culture as living practices, not museum exhibits
- Spiritual systems as legitimate frameworks (not superstition to be overcome)
- Language: African languages as working languages of the future, not ornamental

THE ANCESTRAL THREAD
- The ancestors are not dead. they are a resource, a connection, a technology
- Memory is not nostalgia. it's data, it's infrastructure, it's the root system of the future
- The Middle Passage, colonialism, slavery. these are not just history; they're the science fiction that already happened
- Afrofuturism heals by imagining: what was taken, what survived, what could be

FORBIDDEN IN AFROFUTURISM
- Generic "African" without cultural specificity (which culture? which language? which cosmology?)
- Western tech with a cosmetic African layer (the technology should THINK differently)
- The "primitive past vs. advanced future" framework (African knowledge IS advanced)
- Erasing the diaspora (the global Black experience is part of the story)
- Ignoring the political (Afrofuturism is inherently about liberation; apolitical Afrofuturism is a contradiction)
- Cultural tourism (the genre requires genuine engagement with specific traditions, not a sampling menu)
- The lone hero without community (Ubuntu. I am because we are)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (worldbuilding & cultural reimagining), Revelation (reframe of identity / history), Affection (community & lineage).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person (intimate navigation between worlds, cultures, timelines) or close third (scope for world-building and community)
- Voice: Culturally grounded, speculative, carrying the rhythms of the specific tradition; the voice should feel like it BELONGS to this world
- Tone: Visionary. simultaneously grounded in real cultural tradition and reaching toward imagined possibility; never cynical about Black futures
- Register: Literary to accessible depending on subgenre; the language should be enriched by the specific cultural tradition without being inaccessible

PROSE IMPERATIVES
- CULTURAL VOICE: the prose carries the tradition
  - Proverbs, idioms, and speech patterns from the specific culture woven into the narrative voice
  - Oral tradition rhythms: the storyteller's cadence, the griot's structure, the call-and-response pattern
  - African language words used naturally (not italicised, not footnoted. they belong)
  - The music of the culture audible in the prose rhythm: if drawing from Yoruba tradition, the tonal quality; if Igbo, the proverbial density; if diaspora, the adaptive inventiveness
- SPECULATIVE DESCRIPTION: the future rendered with cultural specificity
  - Technology described through its cultural aesthetic: how it LOOKS, FEELS, and FUNCTIONS reflects its cultural origin
  - Architecture and space: not generic sci-fi but shaped by the specific tradition's spatial thinking
  - Bodies in the future: Black bodies described with beauty and specificity, not through the white gaze
  - Nature/ecology: the relationship to the land, to water, to the ecosystem shaped by cultural philosophy
- TEMPORAL FLUIDITY: time is not Western-linear
  - Past, present, and future coexist (as in many African cosmologies)
  - Ancestors are present, not past; their knowledge is current, not archival
  - Memory is not flashback. it's a technology, a way of knowing, a form of power
  - Prophecy is not supernatural. it's the ancestors speaking forward
- THE AESTHETIC OF POSSIBILITY: beauty as political act
  - Describe the future world with wonder: the reader should WANT to live there
  - Black joy, Black excellence, Black beauty. not as exception but as the world's foundation
  - The aesthetic choices (clothing, music, art, architecture) should create a DESIRE for this future

DIALOGUE CRAFT
- Characters speak from their cultural position: the elder's proverbs, the tech-worker's hybrid slang, the ancestor's formal register
- Code-switching between African languages and English (or whatever the primary language is) treated as normal
- Community conversation: group decision-making, debate, consensus-building as dialogue scenes
- The ancestor's voice: when ancestors speak, their register carries the weight of the tradition
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. AFROFUTURISM

OPENING: Afrocentric world-vision + technology + cultural rootedness. The reader
feels BOTH tradition AND speculative future simultaneously. The familiar made
futuristic, the futuristic made home. Cultural specificity is architecture.

SENTENCES: Rhythm varies with the specific tradition. Medium (14-22) as baseline;
longer (24-35) for lyrical passages; shorter (8-14) for technological precision.
Oral tradition cadence available: griot's build, call-and-response. Prose rhythm
reflects the SPECIFIC cultural tradition being drawn from.

VOCABULARY: African language words used naturally. not italicised, not explained.
Technology described through cultural aesthetic. Proverbs and idioms woven into voice.
Bodies described with beauty, never through the white gaze. Sensory palette rich and
culturally grounded: named foods, instruments, materials; architecture shaped by the
tradition's spatial thinking.

TENSION FLOOR: ≥5. Tradition and innovation in productive tension. Liberation
present: colonial legacies confronted. Community dynamics: collective responsibility
meets individual desire. The past insists on the present.

RHYTHM: Open with cultural specificity in the speculative context. Ground through
one tradition-rooted sensory experience. Speculative element already woven in. not
revealed. Layer the ancestral thread. Close with the beauty of this future.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

AFROFUTURISM CRAFT (40% of total):
- Cultural specificity: drawn from identifiable tradition (not generic "African")? (0-100)
- Technology/world reflects cultural values (not Western tech with African skin)? (0-100)
- Liberation present: colonial legacies addressed, freedom imagined? (0-100)
- Ancestral connection: past and future linked, memory as resource? (0-100)

STORY CRAFT (30% of total):
- Community over individualism: Ubuntu, collective, extended family visible? (0-100)
- The speculative world is beautiful (the reader wants to be there)? (0-100)
- The story is both specific (this culture) and universal (human truths)? (0-100)
- Stakes are both personal and communal? (0-100)

PROSE QUALITY (30% of total):
- Cultural voice sustained (proverbs, rhythms, language patterns)? (0-100)
- Speculative elements described with cultural specificity? (0-100)
- Temporal fluidity operating (past/present/future non-linear)? (0-100)
- Beauty and wonder rendered (the aesthetic of possibility)? (0-100)

AUTOMATIC FAILS (score = 0):
- Generic "African" without cultural specificity
- Western technology with cosmetic African layer
- "Primitive past vs. advanced future" framework
- Lone hero without community context
- Cultural tourism (sampling without depth)
- Apolitical Afrofuturism (liberation erased)
- Black bodies described through the white gaze
- African language treated as exotic (italicised, footnoted, explained)
```

## Continuity Rules

```
AFROFUTURISM CONTINUITY. WHAT TO TRACK

CULTURAL STATE:
- Which specific tradition(s) the world draws from (must be consistent)
- Cultural practices: rituals, customs, greetings, food, music. tracked for consistency
- Language use: which words from which languages, how they're used
- Social structures: family, community, governance. how they work in this world
- Spiritual/cosmological framework: the world's metaphysics, consistent with the tradition

TECHNOLOGY STATE:
- What technology exists and how it works (consistent with cultural logic)
- What the technology CAN'T do (limitations tied to the world's values)
- How technology is distributed (who has access, how it reflects social values)
- The aesthetic of technology: visual language, interface, design philosophy

ANCESTRAL STATE:
- Which ancestors have been contacted or are present
- What knowledge they've provided
- The rules of ancestral communication (consistent across the story)
- The relationship between the protagonist and their ancestral line

POLITICAL STATE:
- Colonial/liberation history: what happened, what was recovered, what remains unresolved
- Power structures: who governs, how, by what philosophy
- External pressures: other cultures, other powers, other agendas
- The community's relationship to its past: what's been healed, what hasn't

WORLD STATE:
- Geography: the specific places, their significance, their history
- Ecology: the natural world, the community's relationship to it
- Economy: how resources are produced, shared, and valued
- Art and music: the creative expressions that define the culture
```

## Character Rules

```
AFROFUTURISM CHARACTER TYPES

THE NAVIGATOR:
- Someone who moves between worlds: the traditional and the futuristic, the African and the diaspora, the past and the future
- Their strength is in connection: linking knowledge systems, translating between cultures
- They're often the bridge the story needs: the person who can hold both the old knowledge and the new technology
- Their struggle is belonging: where is home when you exist between worlds?

THE ELDER/ANCESTOR:
- Not a relic. a resource: their knowledge is cutting-edge because it's been tested across generations
- They may be alive, dead, or in a state between (many African cosmologies don't draw a hard line)
- Their role is GUIDANCE, not direction: they point; the protagonist must walk
- They represent continuity: the thread from the first village to the space station

THE INNOVATOR:
- Someone creating the new from the old: technology, art, social structures, medicine
- Their innovation draws from cultural tradition (not despite it)
- They represent the genre's core argument: African knowledge + imagination = future
- They may face resistance from both traditionalists and external forces

THE COMMUNITY:
- Not background. participant: the community acts, decides, supports, challenges
- Ubuntu made narrative: "I am because we are" shapes how problems are solved
- The community's collective wisdom may be the protagonist's greatest resource
- Diversity within the community: elders, youth, innovators, traditionalists, diaspora returnees

THE ANTAGONIST:
- May be colonial legacy (a system, not just a person)
- May be someone within the community who has internalised oppressive frameworks
- May be an external force that seeks to control or exploit
- Should be comprehensible: their logic, if wrong, should be visible

VOICE DIFFERENTIATION:
- The elder: proverbial, rhythmic, the storyteller's cadence
- The innovator: hybrid. traditional references mixed with technical language
- The navigator: code-switching, multilingual, the voice that adapts to context
- The community: the collective voice. debate, consensus, the sound of people deciding together
- The ancestor: formal, weighty, carrying the authority of tradition
```

## Arc Rules

```
AFROFUTURISM STORY STRUCTURE

ACT 1: THE WORLD ESTABLISHED (first 25%)
- The speculative world rendered with cultural specificity: this place, this people, this technology
- The protagonist in their community: their role, their relationships, their desires
- The ancestral thread introduced: the connection to the past that will shape the future
- The disruption: a threat, a discovery, a calling that demands the protagonist act
- END OF ACT 1: The protagonist commits to the journey (which is both personal and communal)

ACT 2A: THE QUEST AND THE TRADITION (to midpoint)
- The protagonist draws on cultural knowledge and new capability
- The community is involved: allies, elders, the collective wisdom
- The speculative world reveals its depth: the beauty, the technology, the philosophy
- The ancestral connection deepens: the past provides resources for the present challenge
- MIDPOINT: A revelation. about the protagonist's heritage, the true nature of the threat, or the hidden cost of the future; the story deepens from adventure to meaning

ACT 2B: THE CRISIS AND THE CHOICE (midpoint to dark moment)
- The threat intensifies: the colonial legacy, the external force, the internal corruption
- The protagonist must choose between competing goods: tradition and innovation, community and self, safety and liberation
- Cultural values are tested: does Ubuntu hold under pressure? Does the ancestral knowledge work?
- The beauty of the world is threatened: what's been built could be lost
- DARK MOMENT: The protagonist faces the possibility that the future they've imagined might not be achievable. but the ancestors/community provide the thread to hold on to

ACT 3: THE LIBERATION AND THE CONTINUITY (final 25%)
- The protagonist acts from the place where tradition and innovation meet
- The community contributes to the resolution: it's not a solo victory
- The antagonist is confronted not just with force but with a different VISION of the world
- Liberation is advanced (not necessarily completed. liberation is ongoing)
- The ending: the world continues, enriched by what was recovered and imagined; the ancestors are honoured; the future is open and beautiful

AFROFUTURISM PACING:
- The pace reflects the cultural tradition: oral storytelling builds differently from Western narrative
- Community scenes (debate, ceremony, collective decision) deserve full weight. they're not filler
- Action sequences carry cultural specificity: how this world fights, resists, and celebrates
- The ending should feel like a beginning: the future stretches forward, inviting
```

## Timeline Rules

```
AFROFUTURISM TIMELINE

TEMPORAL FRAMEWORK:
- Time may not be linear: African cosmologies often understand time as cyclical, spiral, or layered
- The ancestral timeline is present: the past is not behind. it's beneath, around, within
- Historical markers: the specific events (colonialism, diaspora, liberation) that shaped this future
- The speculative timeline: how far ahead, what's changed, what was recovered

CULTURAL CALENDAR:
- Festivals, ceremonies, seasonal markers specific to the tradition
- Coming-of-age, initiation, community milestones
- Agricultural or ecological cycles tied to cultural practice
- The rhythm of daily life: what's been preserved, what's evolved

TECHNOLOGY TIMELINE:
- When innovations occurred and what inspired them
- The development arc of key technologies
- How technological change affected cultural practice (and vice versa)
```

## Genre-Specific Craft Techniques

Afrofuturism is a genre with an explicit political and
philosophical mandate: to imagine Black futures that
were systematically denied, to rebuild the imaginative
frame on African and diaspora cultural foundations
rather than on Western default frames, and to treat the
ancestral past as advanced technology rather than as
primitive prehistory. The canonical comp roster —
Octavia Butler (Kindred, Parable of the Sower, the
Patternist series, Lilith's Brood), Samuel R. Delany
(Stars in My Pocket Like Grains of Sand, Dhalgren),
Charles Saunders (Imaro, originator of Sword and Soul),
Steven Barnes (Lion's Blood), Walter Mosley (Futureland)
— established the form; the contemporary masterclass
roster — N.K. Jemisin (Broken Earth, The City We Became),
Nnedi Okorafor (Binti, Akata Witch, Who Fears Death),
Tochi Onyebuchi (Riot Baby, War Girls, Goliath), Tade
Thompson (Rosewater), P. Djèlí Clark (Ring Shout, A
Master of Djinn), Akwaeke Emezi (Pet, Freshwater,
Bitter), Rivers Solomon (An Unkindness of Ghosts, The
Deep), Marlon James (Black Leopard Red Wolf trilogy),
Namwali Serpell (The Old Drift), Tomi Adeyemi (Children
of Blood and Bone), Sheree Renée Thomas, Sofia Samatar,
Cadwell Turnbull, Maurice Broaddus, Lesley Nneka Arimah
— has expanded the genre's range to space opera,
literary, mythic, body-horror-adjacent, post-colonial,
diaspora-spanning, and ancestral-procedural registers,
each with its own specific cultural grounding. The most
common failure modes in this register are: **Generic-
Africa Reduction** (the genre's foundational sin — an
undifferentiated "Africa" rather than specific Yoruba,
Igbo, Akan, Zulu, Wolof, Amharic, Swahili, Hausa,
Mandinka, Kongo, Xhosa, etc., specific lineages within
those, specific diaspora communities each with their own
configuration); **Western-Tech-with-African-Skin** (the
technology in the world is structurally Western — its
distribution logic, its values, its interface conventions
are imported; only its surface is African); **Past-as-
Primitive Framework** (despite the genre's explicit
refusal of this framework, it sneaks back in as the
colonial mind's default — the African past treated as
"before the future" rather than as the future's
foundation); **Lone-Hero-Without-Community** (Western
individual-hero structure imported despite Ubuntu and
African philosophical traditions of collective — the
solo protagonist who solves the problem on her own
without the council, the elders, the lineage, the
community as material force); **Cultural-Tourism Tasting
Menu** (sampling tropes from multiple African cultures
without committing to any in depth — Yoruba names with
Akan customs and Wolof food and Zulu architecture
collapsed into a generic "African" world); **Apolitical
Afrofuturism** (the genre's foundational political DNA
elided; Afrofuturism without liberation is a
contradiction in terms); **White-Gaze Bodies** (Black
bodies described through the lexicon of Western beauty
standards or exotic othering or colour-as-spectacle
rather than rendered with cultural specificity from
inside — adornment named through the wrong tradition's
vocabulary, beauty rendered for an outside reader's
gaze); and **Italicised-African Othering** (African
language words italicised, footnoted, or glossed — the
genre's signature formal commitment is that these words
are the working vocabulary of the world and belong
unmarked, not exotic loan-words requiring translation).
The techniques below — three preserved (Ancestral
Technology, Beautiful Future, Ubuntu Moment) and three
added (Specific-Tradition Discipline, Decolonial-
Imagination Discipline, Black-Joy Architecture) — are
designed to ensure the genre's defining commitments:
specific cultural lineages rendered in depth, the
imaginative frame rebuilt on African foundations rather
than decorated with African surface, and Black futures
rendered as beautiful, abundant, communal, and
politically alive.

### The Ancestral Technology

Knowledge from the past functioning as advanced capability:

```
"Grandmother's memory palace was not a metaphor.
It was an architecture of recall so precise that
the Quantum Archive project had reverse-engineered
its structure for their storage systems in 2187.

She had shown me the technique when I was eight:
visualise the compound, walk its corridors, place
each memory in its room. I had thought it was an
old woman's game. The Archive engineers called it
'distributed neural indexing.' Grandmother called
it 'the way we remember.'

The future had spent forty years trying to
build what my grandmother carried in her head."

The past IS the technology. The tradition
IS the innovation. The ancestor IS the
scientist.
```

### The Beautiful Future

The aesthetic of possibility rendered with specificity:

```
"Abuja's new skyline followed the mathematics
of Igbo uli patterns: fractals spiralling from
the ground, each tower a variation on a theme
the master architects had drawn from body
painting traditions older than the pyramids.

At sunset the towers caught the light and the
city looked like it was wearing uli on its skin,
the ancient and the titanium-and-glass dancing
together, and for a moment. standing on the
observation deck with the Harmattan wind warm
against my face. I understood what they meant
when they said the future remembers."

The reader should WANT this future. The
beauty is the argument. The aesthetic is
the politics.
```

### The Ubuntu Moment

The community solving what the individual cannot:

```
"I had come with a problem I couldn't solve.
The council sat for three hours. Grandmother
spoke first, as was custom. Then Eze, who
disagreed with everything Grandmother said
and had for sixty years. Then the engineers.
Then the children (who in this village always
spoke, because the future belongs to them).

By evening they had not given me an answer.
They had given me seven answers, contradictory
and insufficient and beautiful, and somewhere
in the overlap of all seven was the thing I
needed, which none of them could have found
alone and which I could not have found without
all of them."

The community IS the intelligence. Ubuntu
IS the technology. "I am because we are"
IS the solution architecture.
```

### Afrofuturism AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the fusion of technology and tradition" | Show the specific tech-tradition integration |
| "ancestral wisdom guided the future" | Show the specific ancestral practice in the future context |
| "a utopia built on African ingenuity" | Show the specific innovation |
| "the diaspora connected across stars" | Show the specific cultural link across distance |
| "reclaiming the narrative" | Show the specific counter-narrative through action |
| "technology rooted in culture" | Show the specific tech and its specific cultural origin |
| "the spirits of the ancestors" | Show the specific ancestral interaction |
| "a world shaped by African philosophy" | Show the specific philosophy in daily practice |
| "the future was bright and Black" | Show the specific achievement in the specific society |
| "tradition and innovation in harmony" | Show the specific moment where both coexist |
| "the rhythm of the diaspora" | Show the specific rhythmic practice — a specific dance, a specific drum pattern, a specific call-and-response |
| "the soul of Africa" | Cut entirely; show the specific cultural moment in the specific tradition |
| "echoes of the motherland" | Show the specific echo through one specific named practice |
| "the rich tapestry of African culture" | Cut "rich tapestry"; name the specific cultures and what specifically they contribute |
| "vibrant African colours" | Name the specific colours (indigo, kente gold, adinkra red) and their specific cultural meaning |
| "ancient wisdom met modern technology" | Show ONE specific ancient practice integrated with ONE specific technology, with the join visible |
| "drumming in their blood" | Cut the cliché; show the specific drumming tradition the character knows by name and by hand |
| "the spirit of Ubuntu" | Cut "spirit of"; show one specific Ubuntu act in the chapter — the council, the contribution, the consensus, the carry |

### The Specific-Tradition Discipline

Afrofuturism's foundational requirement is cultural
specificity: not "African" as a monolith, but THIS
Yoruba village's particular cosmology, THIS Igbo town's
particular naming traditions, THIS Akan diaspora
community's particular spiritual practice, THIS Kongo
ceremonial vocabulary, THIS Wolof rhetorical structure.
The Specific-Tradition Discipline is the requirement
that the manuscript commit to one or two named cultural
lineages and render them in depth, with internal
plurality and contemporary fluency, rather than
sampling tropes across a generic "African" surface.

```
PRINCIPLE
The chosen tradition(s) must be rendered through at
least five concrete specifics:
1. NAMED CULTURE(S) — Yoruba, Igbo, Akan, Kongo, Wolof,
   Amharic, Hausa, Zulu, Xhosa, Mandinka, etc., with
   sub-tradition specificity (not "Yoruba" as monolith
   but the specific Yoruba lineage / region / diaspora
   community)
2. NAMED LANGUAGE(S) — used as working vocabulary,
   unmarked, with the specific cadences and proverbial
   density of the tradition
3. NAMED COSMOLOGY — the specific spiritual / metaphysical
   framework (Ifa divination; Orisha pantheon; Egungun
   ancestors; Ndebele beliefs; Vodun loa; specific
   diaspora syncretisms)
4. NAMED PRACTICE — specific named ceremonies, festivals,
   rites, council structures, kinship terms, food, dress,
   craft, art form
5. NAMED PLACE — specific Lagos, specific Accra, specific
   New Orleans, specific Salvador, specific Kingston,
   specific Brixton — with the specific neighbourhood,
   the specific street, the specific market

CALIBRATION TEST
- Could a reader identify the SPECIFIC cultural lineage
  this manuscript draws from, and could a member of that
  lineage recognise it as their own?
- Are at least two named cultures rendered with internal
  plurality (not collapsed into a single "African" wash)?
- Is the language used as working vocabulary, not
  italicised exotica?
- Is the cosmology consistent with itself, with named
  practices and named entities, not generic
  "ancestors / spirits / gods"?
If any answer is no — rebuild for cultural specificity.

ANTI-PATTERN
- Yoruba names with Akan customs and Wolof food
  collapsed without acknowledgement of the join
- Generic "African" elders, ceremonies, drums
- The single ancestor / spirit / god without specific
  pantheon location
- Italicised African words (othering)
- Glossed translations in parentheses (othering)
- "African names" picked from a baby-name list without
  internal logic
- The "African" diaspora character whose specific
  diaspora community is unnamed
```

### The Decolonial-Imagination Discipline

Afrofuturism is not "African aesthetic added to Western
sci-fi". it is the imaginative frame itself rebuilt on
African foundations. The Decolonial-Imagination
Discipline is the requirement that the manuscript
actively reconstruct the world's frame — its political
philosophy, its economic logic, its social organisation,
its technology's value-system, its narrative shape —
rather than merely decorate a Western frame with African
surface. This is the genre's core craft challenge and
its most common failure point.

```
PRINCIPLE
For every major worldbuilding element, the manuscript
must answer: HOW DOES THIS WORK IF THE COLONIAL
INTERRUPTION HAD NOT HAPPENED, OR HAS BEEN ACTIVELY
UNDONE? Specifically:

1. POLITICAL STRUCTURE — what governance reflects
   African political philosophies? (consensus councils,
   age-grade systems, queen-mother dyads, kinship-
   federated governance, pre-colonial empires
   re-imagined; not Western parliamentary democracy by
   default)
2. ECONOMIC LOGIC — what economy reflects African
   value-systems? (gift economies, communal land
   tenure, kinship-based redistribution, post-cash
   alternatives; not capitalism-with-African-faces
   by default)
3. KNOWLEDGE SYSTEMS — what counts as knowledge, who
   keeps it, how it is transmitted? (oral tradition
   as data, divination as analytical method, ancestor
   communication as research; not Western academic
   knowledge structures by default)
4. TECHNOLOGY VALUES — what does the tech optimise
   for, what does it refuse? (communal benefit over
   individual extraction; ecological balance over
   limitless growth; embodied use over disembodied
   abstraction; not Silicon-Valley logic with African
   skin)
5. NARRATIVE SHAPE — what story arcs does the
   tradition support? (cyclical / spiral / multi-
   generational / collective; not three-act
   individualism by default)
6. AESTHETIC DEFAULTS — what is beautiful, what is
   adorned, what is honoured? (cultural specifics from
   the chosen tradition, not Western beauty standards)

CALIBRATION TEST
- For each major worldbuilding element, can you point
  to the African philosophical foundation rather than
  the Western default that has been "decorated"?
- Does the world's logic flow from the chosen
  tradition rather than from the unmarked Western
  frame?
- Are the colonial legacies (where present in the
  story) rendered as historical force the world is
  recovering from, not as invisible defaults the
  world simply inherits?
- Could the world's decision structures, technology,
  and narrative arc be MISTAKEN for a Western frame
  with African characters? If yes, rebuild.

ANTI-PATTERN
- The "Wakanda problem" without the genre's earlier
  foundation: pure technocratic monarchy with African
  surface
- Western parliamentary politics with African flag-
  planting
- Capitalist extraction with African-named corporations
- Three-act individualist hero arc with collective
  rhetoric pasted on
- Western beauty aesthetics with African models
- Silicon Valley UX with kente borders
```

### The Black-Joy Architecture

Afrofuturism is a literature of beauty and possibility,
not just resistance. The Black-Joy Architecture is the
requirement that joy, abundance, ordinariness, humour,
celebration, intimacy, and excellence be rendered with
the same craft attention given to liberation struggle.
Mundane Black happiness — the family dinner, the
wedding, the festival, the quiet evening, the kitchen-
table joke, the dance, the meal cooked for a friend,
the lover's gaze — given the same prose weight, the
same specificity, and the same narrative space as the
genre's traditional sources of pain and resistance.

```
PRINCIPLE
For every chapter that contains a beat of struggle,
oppression, colonial-legacy confrontation, or
liberation pressure, the manuscript must contain at
least one beat — somewhere, not necessarily in the
same chapter — of:
1. SPECIFIC JOY (not "they were happy" but the
   specific named festival, the specific dance, the
   specific shared meal, the specific moment of
   recognition)
2. SPECIFIC ABUNDANCE (the world rendered as having
   ENOUGH — food, time, community, beauty,
   creativity — rather than as scarcity-dominated
   even when scarcity is the political subject)
3. SPECIFIC ORDINARINESS (the protagonist living
   her ordinary life: the school run, the market,
   the laundry, the morning routine, the everyday
   rituals of the named tradition)
4. SPECIFIC EXCELLENCE (named achievements rendered
   with full prose weight — the engineer's specific
   solution, the scholar's specific book, the
   artist's specific work, the athlete's specific
   victory; Black excellence as world's foundation,
   not exception)
5. SPECIFIC INTIMACY (Black love and friendship and
   kinship rendered with full craft attention; the
   tenderness, the laugh, the long silence between
   old friends; the kiss in the kitchen; the
   grandmother's hand on the grandchild's head)
6. SPECIFIC HUMOUR (the in-group joke, the
   community wit, the elder's deadpan, the cousin's
   teasing — humour as texture, not relief)

CALIBRATION TEST
- If you removed every instance of struggle /
  oppression / colonial-legacy from the manuscript,
  would Black life still be visible at all?
- Does the manuscript contain SPECIFIC Black joy
  rendered with the same craft as Black struggle?
- Is the world a place a reader would WANT to live
  in (not just sympathise with)?
- Are abundance, ordinariness, excellence, intimacy,
  and humour rendered as foundation rather than as
  decoration?
If any answer is no — rebalance for joy-equity.

ANTI-PATTERN
- The struggle-only Afrofuturist narrative
- The world rendered entirely through scarcity even
  when the genre's argument is abundance
- Black excellence treated as exception (the "first
  Black X") rather than as foundation
- Romance / intimacy fade-to-black where a non-
  Afrofuturist romance would not
- The world that is sympathetic but not desirable;
  Afrofuturism's contract is that the reader should
  WANT this future
- Joy as relief from struggle (joy as the margin)
  rather than joy as foundation
```

## Genre-Specific Revision Rules

### Six-Pass Afrofuturism Audit (Run FIRST in editorial pipeline)

The Afrofuturism Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Cultural Specificity Pass

Verify a specific cultural tradition is identifiable in
each chapter — not generic "African". The Specific-
Tradition Discipline supplies the spec: named culture,
named language, named cosmology, named practice, named
place. Audit each chapter for these five specifics. If
the chapter could be set in any African or diaspora
context interchangeably, it has slipped into Generic-
Africa Reduction and must be rebuilt. Verify the
language is used as working vocabulary (unmarked, not
italicised, not glossed in parentheses). Verify the
cosmology is consistent and named (specific Orisha
pantheon, specific Vodun loa, specific Ifa divination
structure, specific Igbo chi system, etc.) rather than
generic "ancestors" or "spirits". Verify the speculative
world is SHAPED by the tradition (its political
philosophy, economic logic, technology values flow from
the tradition) rather than merely DECORATED by it
(Western world with African surface).

#### Pass 2: Liberation Pass

Verify the political dimension is present. Afrofuturism's
foundational commitment is to imagining what was
forbidden to imagine, and the apolitical Afrofuturist
manuscript is a contradiction in terms. Audit each
chapter for the liberation thread: is the colonial
legacy addressed as historical force (not as background
texture)? Is freedom imagined concretely (specific
political alternatives, specific economic alternatives,
specific knowledge-system alternatives) rather than
theoretically (vague "freedom" as slogan)? Are the
stakes both personal and communal — does the
protagonist's struggle resonate with the community's
struggle, and vice versa? If a chapter has no political
dimension, no liberation pressure, no recovery of what
colonial interruption took, the manuscript has drifted
into Apolitical Afrofuturism and must be rebuilt.

#### Pass 3: Ancestral Connection Pass

Verify the past-future thread is visible in each
chapter. Afrofuturism collapses linear time. the
ancestors are present, the past is technology, memory
is infrastructure, prophecy is the ancestors speaking
forward. Audit each chapter: is the ancestral connection
rendered (a specific named ancestor, a specific named
practice, a specific named transmission)? Are ancestors
and tradition treated as RESOURCES (current, useful,
analytically productive) rather than as RELICS (museum
pieces, nostalgia objects, things to be honoured but
not used)? Does the temporal framework reflect the
cultural cosmology — cyclical or spiral or layered
where the tradition is cyclical or spiral or layered,
rather than collapsed into Western linear time? If the
chapter could be set in a present that was severed from
its past, the ancestral thread has been lost and must
be rebuilt.

#### Pass 4: Beauty Pass

Verify the world is rendered with aesthetic wonder. The
Beautiful Future technique is the spec for this pass:
the reader should WANT to inhabit this future. Audit
each chapter: does the prose render the world's beauty
with specificity — the architecture, the clothing, the
food, the music, the art, the bodies, the landscape?
Are Black bodies described with cultural specificity
from inside the tradition rather than through the white
gaze (the lexicon of Western beauty standards, exotic
othering, colour-as-spectacle)? Is the aesthetic
political (beauty as resistance, abundance as
imaginative claim, joy as foundation) rather than
decorative? If the world is sympathetic but not
desirable — if the reader pities the protagonist
rather than envies her — the Beauty Pass has failed
and the manuscript must be rebuilt for aesthetic
specificity.

#### Pass 5: Community Pass

Verify community is visible and active in each chapter.
Ubuntu and African collective philosophies require the
protagonist to be embedded in relationships, in
councils, in lineage, in shared decision-making. The
Lone-Hero-Without-Community failure mode is caught
here. Audit each chapter: who is the protagonist's
community (named, specific, plural)? When does the
community contribute to a decision, an action, or an
analysis the protagonist could not have reached alone?
Are decisions collective where culturally appropriate?
Does the community have its own voice, its own
disagreements, its own internal plurality (elders,
innovators, children, traditionalists, returnees,
diaspora) — or is it a flat backdrop of "the community"
as singular entity? If the protagonist solves problems
alone in chapters where the tradition would call a
council, rebuild for collective process.

#### Pass 6: Specific-Tradition + Decolonial-Imagination + Black-Joy Integration

This pass is the Afrofuturism integration check — it
ties the new techniques together and verifies the
genre's defining commitments are honoured chapter by
chapter.

For SPECIFIC-TRADITION: confirm Pass 1's spec has been
met through five concrete specifics (named culture,
named language, named cosmology, named practice, named
place). Verify at least two named cultures are rendered
with internal plurality, that the language is unmarked
working vocabulary, and that the cosmology is internally
consistent with named entities and named practices. If
the chapter samples across cultures without
acknowledgement of the join (the Cultural-Tourism
Tasting Menu failure), rebuild.

For DECOLONIAL-IMAGINATION: identify the chapter's
worldbuilding elements (political structure, economic
logic, knowledge systems, technology values, narrative
shape, aesthetic defaults). For each, ask whether the
element flows from the chosen African foundation or
from a Western default with African decoration. If the
chapter's logic would be more at home in a Western
sci-fi context with African characters than in an
imaginatively rebuilt Afrofuturist frame, rebuild.
The decolonial imagination is the genre's hardest
craft; the manuscript must do this work, not gesture
at it.

For BLACK-JOY: identify the chapter's emotional
distribution. If the chapter contains struggle /
oppression / colonial-legacy confrontation /
liberation pressure, has the manuscript elsewhere
rendered specific Black joy, abundance, ordinariness,
excellence, intimacy, or humour with comparable craft?
If the manuscript has been narrowed entirely to
struggle and resistance, rebalance — find the
specific joy and render it with the specificity given
to the pain. The genre's contract is not "Black
suffering with hope at the end". it is "Black life
rendered fully", which includes the Tuesday morning
in Lagos, the wedding in Kingston, the kitchen joke
in Brixton, the family dinner in Accra, the council
in the diaspora — all rendered with the same craft as
the resistance and the struggle.

## Names & Patterns to Avoid

### Afrofuturism Character Names. NEVER USE
- Generic fantasy names (this is not Tolkien)
- Western names as default (use names from the specific tradition)
- Names chosen for "exotic" sound without cultural meaning
- Stereotypical "African" names without specificity

### Afrofuturism. NEVER DO
- Use generic "Africa" without cultural specificity
- Apply Western technology with African decoration
- Frame the past as primitive and the future as advanced
- Write a lone hero without community
- Ignore the political (Afrofuturism is inherently about liberation)
- Treat African spirituality as superstition
- Italicise or footnote African language words (they belong)
- Describe Black bodies through the white gaze

### Use Instead
- Names from the specific cultural tradition, with their cultural significance understood
- Names that carry generational connection (named after ancestors, with family meaning)
- Names that the characters themselves would use (including shortened forms, honorifics, and kinship terms)

## Comp Titles

Afrofuturism's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Kindred* — Octavia Butler (1979): the time-travel-and-slavery foundational Afrofuturist text.
- *Stars in My Pocket Like Grains of Sand* — Samuel R. Delany (1984): literary Afrofuturist-SF.
- *Imaro* — Charles Saunders (1981): originator of Sword and Soul Afrofuturist subgenre.
- *Parable of the Sower* — Octavia Butler (1993): Afrofuturist proto-cli-fi.

### Contemporary (current best-in-class)

- *Who Fears Death* — Nnedi Okorafor (2010): post-apocalyptic Afrofuturism with West-African-rooted magic.
- *Binti* — Nnedi Okorafor (2015): Afrofuturist novella series; first contact through Himba culture.
- *The Fifth Season* — N.K. Jemisin (2015): the Broken Earth trilogy; Hugo-sweeping Afrofuturist epic.
- *Black Sun* — Rebecca Roanhorse (2020): Afrofuturist-Indigenous-blended epic fantasy.
- *Riot Baby* — Tochi Onyebuchi (2020): Afrofuturist novella with US racial-justice frame.
- *Pet* — Akwaeke Emezi (2019): YA Afrofuturism with utopia-with-shadow architecture.
- *The Old Drift* — Namwali Serpell (2019): multigenerational Afrofuturist literary epic.
- *The Deep* — Rivers Solomon (2019): Afrofuturist novella reframing the Middle Passage.

## Cover Design Specifications

### Recommended Visual Styles
- **Afrofuturist Aesthetic**. Bold, vibrant, culturally grounded: African art traditions (uli patterns, kente geometries, adinkra symbols) rendered in futuristic materials and contexts
- **Space/Technology**. The African future in space: spacecraft, cityscapes, technology that visually draws from African design traditions; the visual language of Black excellence in the cosmos
- **Portrait**. A Black figure in their future: beautiful, powerful, adorned with cultural markers and futuristic elements; the face of the future
- **Mythic**. African mythology reimagined: Orishas in space, ancestral spirits as holograms, the gods in chrome and light

### Genre Cover Aesthetics
- **Styles:** Vibrant, bold, celebratory; African art traditions fused with science fiction imagery; Black figures in powerful poses; spacecraft and cityscapes with African architectural influence; traditional patterns rendered in futuristic materials; digital art that honours handcraft traditions
- **Colours:** Rich, saturated, joyful: golds, deep purples, electric blues, sunset oranges, earth reds; metallics (gold, bronze, copper) representing both tradition and technology; the palette should feel ALIVE. warm and vibrant, not the cold blue of Western sci-fi
- **Elements:** African patterns (geometric, fractal, textile-inspired), traditional adornment rendered futuristically, spacecraft with organic African design influences, ancestral figures, natural elements (baobab, savannah, ocean) in speculative contexts, technology that looks grown rather than built
- **Typography:** Bold, often custom or hand-rendered; may incorporate African script influences; the title should feel ceremonial and powerful; metallic effects; the author name as cultural authority

### Market Positioning
Afrofuturism covers must signal "visionary, culturally grounded, and beautiful" through vibrant colour and bold Afro-centric design. Position against Butler, Okofor, Jemisin, Older, Solomon. The cover should announce a future that's specific, joyful, and powerful. At thumbnail size, rich colour, cultural pattern, and bold typography create instant visual identity distinct from both generic sci-fi and African literary fiction.

### Cover Design DON'Ts
- No cold blue/grey Western sci-fi palettes
- No generic sci-fi imagery without cultural grounding
- No stereotypical or reductive African imagery
- No designs that look like academic texts on Afrofuturism
- No dark, dystopian-only imagery (Afrofuturism imagines BEAUTY)
- No designs that could be mistaken for fantasy (the future, not the past)
