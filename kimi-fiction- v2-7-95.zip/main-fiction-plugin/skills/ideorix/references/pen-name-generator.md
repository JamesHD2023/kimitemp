---
name: pen-name-generator
description: "Pen name creation and management system"
user-invocable: false
---
<!-- (c) 2025 James Harvey Media / Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->

# Pen Name Generator

## Overview

Creates genre-appropriate pen names with professional author bios. Pen names persist
across projects in the local backup directory and can be selected during project setup.

## Storage

All pen names are stored locally:

```
~/Documents/Ideorix-Projects/
└── .pen-names/
    ├── index.md                    # Master list of all pen names
    └── profiles/
        ├── elena-blackwood.md      # Individual pen name profile
        ├── james-carrington.md
        └── ...
```

## Pen Name Generation Protocol

### Step 1: Gather Requirements

Use AskUserQuestion to collect:

```
PEN NAME BRIEF:
  Genre:       {genre — from current project or user-specified}
  Gender:      {male / female / gender-neutral / surprise me}
  Cultural:    {any cultural background preference, or "no preference"}
  Vibe:        {serious / literary / approachable / edgy / classic / playful}
  Initials:    {any preferred initials, or "no preference"}
```

### Step 2: Generate Candidates

Produce **5 pen name candidates**, each following these genre-informed principles:

**Genre-Name Mapping:**
| Genre Family | Name Characteristics | Examples |
|---|---|---|
| Romance | Warm, melodic, approachable — soft consonants, flowing rhythm | Evelyn Hart, Lily Sinclair, Rose Calloway |
| Thriller / Crime | Sharp, authoritative — strong consonants, short punchy surnames | Jack Reeve, Cole Ashford, Dana Steele |
| Literary Fiction | Understated, classic — timeless names that suggest depth | Eleanor Marsh, Thomas Wren, Frances Hale |
| Fantasy / Sci-Fi | Distinctive, memorable — slightly unusual but not outlandish | Rowan Kestrel, Sage Blackthorn, Cade Morrow |
| Horror / Gothic | Dark, atmospheric — names with weight and shadow | Vera Hollow, Silas Crane, Maren Voss |
| Mystery / Cozy | Friendly, trustworthy — names you'd want as a neighbour | Harriet Bloom, Maggie Cross, Arthur Penn |
| Historical | Period-appropriate, dignified — names that age well | Catherine Ashworth, Edmund Hale, Margaret Stone |
| YA / Children's | Fresh, contemporary, relatable — names that feel current | Ava Chen, Riley Park, Jordan Blake |
| Erotica / Dark Romance | Bold, alluring — names with edge and confidence | Raven Fox, Scarlett Devereaux, Kai Wolfe |

**Name Construction Rules:**
- First + surname only (middle names are optional, offered if requested)
- Surname must be easy to spell and pronounce
- Google the name pattern — avoid collision with famous authors in the same genre
- Avoid names that sound too similar to the user's real name (if known)
- Consider shelf placement — surnames starting A-F get better physical bookshelf positioning
- Check against the forbidden-words.md and authenticity-guard.md avoidance lists
- No surnames ending in "s" if the possessive form will look awkward (e.g., "James's")

**Presentation format for each candidate:**
```
1. [PEN NAME]
   Genre fit:   Why this name works for {genre}
   Shelf note:  Where it lands alphabetically
   Sound:       How it reads aloud (rhythm, alliteration, flow)
```

### Step 3: User Selection

Present all 5 candidates via AskUserQuestion. Options:
- Select one of the 5
- Mix and match (e.g., first name from #2, surname from #4)
- Request 5 more candidates
- Provide their own pen name (engine generates the bio for it)

### Step 4: Bio Preferences

Before generating any bio content, use AskUserQuestion to collect the user's
preferences. Present this as a brief questionnaire:

```
BIO PREFERENCES FOR {Pen Name}:

1. Backstory approach:
   a) Fully fictional persona (invented background, hobbies, location)
   b) Based on my real details (I'll tell you what to include)
   c) Keep it vague (genre credentials and writing focus only — no personal details)

2. Any real details you'd like included?
   (e.g., "I live in Scotland", "I have a cat", "I used to work in law enforcement",
    or "none — make it all up")

3. Author voice / brand feel:
   a) Warm and approachable
   b) Mysterious and minimal
   c) Professional and authoritative
   d) Witty and irreverent
   e) Other (describe)

4. Anything you specifically do NOT want in your bio?
   (e.g., "no pets", "no mention of coffee", "no fictional degrees")
```

### Step 4b: Generate Author Bio

Using the preferences from Step 4, generate **3 bio variants**:

**Short Bio (50-75 words)** — For Amazon author pages, back-of-book:
```
{Pen Name} writes {genre} fiction that {unique angle}. When not writing,
{hobby/lifestyle detail that fits the genre persona}. {Pen Name} lives in
{location — vague enough to be fictional}. {Optional: series/book reference}.
```

**Medium Bio (100-150 words)** — For author websites, press kits:
```
Expanded version with more personality, writing journey narrative,
influences, and what draws them to the genre. Include a signature
closing line that reflects the author's brand.
```

**Long Bio (200-300 words)** — For query letters, speaking engagements:
```
Full professional bio with writing philosophy, genre expertise,
reader connection, any fictional credentials (e.g., "former
investigative journalist" for a thriller writer — only if the
user selected fictional persona in Step 4).
```

**Bio Construction Rules:**
- Bios must feel authentic — no AI-telltale phrases from forbidden-words.md
- Include 1-2 specific sensory details (favourite writing spot, drink, pet)
- Genre-appropriate tone (thriller bio is sharp; romance bio is warm)
- Never claim real credentials the user doesn't have
- Fictional lifestyle details should be plausible and consistent across all 3 variants
- Respect all exclusions from the user's "do NOT want" list in Step 4

### Step 4c: Bio Review & Approval

Present ALL 3 bio variants to the user via AskUserQuestion. Display them clearly
with headers (Short / Medium / Long) so the user can read and compare.

**Options:**
1. **Approve all** — proceed to save
2. **Edit one** — tell me which bio (short/medium/long) and what to change
3. **Regenerate all** — generate 3 fresh variants using the same preferences
4. **Write my own** — user provides their own bio text (engine formats it into
   the 3 lengths, or user provides all 3 manually)
5. **Adjust preferences** — go back to Step 4 and change bio preferences

Do NOT proceed to Step 5 until the user has explicitly approved the bios.
If the user edits one bio, re-present all 3 (with the edit applied) for
final confirmation before saving.

### Step 5: Save Profile

Write the complete pen name profile to disk:

```markdown
# Pen Name Profile — {Pen Name}

## Identity
- **Pen Name:** {name}
- **Created:** {date}
- **Genre Affinity:** {primary genre}
- **Secondary Genres:** {if applicable}

## Bios
### Short Bio
{short bio text}

### Medium Bio
{medium bio text}

### Long Bio
{long bio text}

## Persona Notes
- **Voice:** {how this author "speaks" — formal, casual, witty, etc.}
- **Social Media Tone:** {how they'd post on Instagram, Twitter/X, TikTok}
- **Author Photo Style:** {guidance for AI image generation or stock selection —
  e.g., "moody studio portrait, dark background, wearing a leather jacket"}

## Voice Profile
- **Voice file:** {voices/{slug}-voice.md or "Not yet created"}
- **Voice summary:** {3-5 sentence summary, or "No voice profile — build one with Voice Builder"}

## Usage History
| Project | Date | Role |
|---------|------|------|
| {book title} | {date} | Author |
```

Save to: `~/Documents/Ideorix-Projects/.pen-names/profiles/{slugified-name}.md`

Update: `~/Documents/Ideorix-Projects/.pen-names/index.md` with the new entry.

### Step 6: Offer Voice Builder

After saving the pen name profile, offer to build a voice:

```
Pen name saved! Would you like to build a writing voice for {Pen Name}?

A voice profile controls how your manuscripts SOUND — sentence rhythm, vocabulary,
dialogue style, pacing. It's different from the persona notes above (which are
about author branding). The voice profile is what makes your prose distinctive.

1. Yes — build a voice now (launches Voice Builder, linked to this pen name)
2. Not now — I'll build one later (say "Voice Builder" any time)
```

If the user selects (1), launch the Voice Builder protocol (`voice-builder-protocol.md`)
with the pen name pre-linked. Pass the genre affinity and persona voice note as
context to inform the voice defaults.

## Index File Format

```markdown
# Pen Name Index

| Pen Name | Genre | Created | Projects | Voice |
|----------|-------|---------|----------|-------|
| Elena Blackwood | Romance | 2026-01-15 | 2 | Yes |
| Jack Reeve | Thriller | 2026-02-03 | 1 | No |
```

## Pen Name Selection During Setup (Q12 Integration)

When triggered from Phase 1 Question 12:

1. Check if `~/Documents/Ideorix-Projects/.pen-names/index.md` exists
2. If pen names exist, present options:
   - **Select an existing pen name** → show the index, user picks one
   - **Create a new pen name** → run the full generation protocol above
   - **Use my real name** → skip pen name assignment
   - **Decide later** → skip for now, can assign before export
3. If no pen names exist:
   - **Create a pen name** → run the generation protocol
   - **Use my real name** → skip
   - **Decide later** → skip

When a pen name is selected or created:
- Record it in the project's Story Bible metadata
- Use it in all generated marketing materials, KDP metadata, and DOCX author fields
- Update the pen name profile's usage history

## Standalone Studio Mode

When accessed from the main menu (not during project setup):

Present these options:
1. **Create a new pen name** — full generation protocol
2. **View my pen names** — list all saved pen names with bios and voice status
3. **Edit a pen name** — modify name, bios, or persona notes
4. **Delete a pen name** — remove (with confirmation)
5. **Generate new bios** — create fresh bio variants for an existing pen name
6. **Build a voice** — launch the Voice Builder (see `voice-builder-protocol.md`)
7. **Back to main menu**

## Anti-Patterns

- Do NOT generate names that are obviously fictional (e.g., "Blade Nightshade")
- Do NOT use names from forbidden-words.md or authenticity-guard.md avoidance lists
- Do NOT create bios that claim real-world credentials without user approval
- Do NOT generate the same name twice across different profiles
- Do NOT use overly common names that would be impossible to search for online
