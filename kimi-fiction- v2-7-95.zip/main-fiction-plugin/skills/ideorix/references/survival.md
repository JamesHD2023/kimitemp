---
name: survival-fiction-genre
description: Genre-specific instructions for survival fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Survival Fiction. Genre Plugin

## Metadata
- id: survival
- name: Survival Fiction
- icon: 🏔️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Fichtean Curve"]

## Subgenre Options
Present during setup:
- **Wilderness Survival**. The protagonist vs. nature: shipwreck, plane crash, lost in wilderness; the body and mind against the elements
- **Post-Apocalyptic Survival**. Civilization has collapsed: the rules are gone, resources are scarce, other survivors may be the greatest threat
- **Castaway**. Isolation survival: alone or with few others, cut off from help; the Robinson Crusoe tradition
- **Disaster Survival**. A catastrophic event: earthquake, flood, epidemic, fire; surviving the event and its immediate aftermath
- **Captivity Survival**. Imprisoned or trapped: the psychology and physicality of endurance under confinement
- **Urban Survival**. Surviving in a hostile city: homelessness, collapse, siege, breakdown of order; civilisation as wilderness

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: The rhythm of survival. urgency punctuated by exhaustion; the body's cycle of effort and collapse
- Must open with: The moment everything changes. the crash, the flood, the realization that help isn't coming; or the protagonist already deep in survival, the reader dropped into the struggle

BEATS PER CHAPTER
1. Threat Beat. The environment or situation threatens: weather, predators, thirst, injury, other survivors, structural collapse
2. Resource Beat. Finding, rationing, or losing something essential: water, food, shelter, fire, tools, medicine
3. Problem-Solving Beat. The protagonist uses intelligence and skill to overcome a specific challenge
4. Body Beat. The physical cost: hunger, cold, pain, exhaustion, dehydration, illness. the body's deterioration
5. Will Beat. The psychological dimension: hope, despair, determination, the choice to keep going

SURVIVAL FICTION ARCHITECTURE
- The BODY is the story: every chapter is experienced through physical sensation
- RESOURCES are finite: track everything the protagonist has, uses, and loses
- The ENVIRONMENT is the antagonist: nature is not malicious but it IS indifferent and lethal
- INTELLIGENCE matters more than strength: survival is solved by thinking, observing, and adapting
- TIME is the enemy: dehydration kills in 3 days, starvation weakens in a week, hypothermia can kill in hours
- ISOLATION magnifies everything: alone, the smallest setback is catastrophic; alone, the mind becomes both ally and enemy
- REALISM is essential: if the protagonist starts a fire, they need materials, technique, and time; no magic solutions
- POV: First person present (maximum immediacy) or tight third past

THE SURVIVAL CLOCK
- The reader should always know (approximately) how long the protagonist can survive at current resource levels
- Water: 3 days without → cognitive decline → organ failure
- Food: weeks without, but strength, cognitive ability, and mood decline within days
- Shelter/warmth: hypothermia in hours (cold) or heat stroke in hours (heat)
- Injury: infection timeline, blood loss, mobility reduction
- The clock creates the urgency that drives the genre

FORBIDDEN IN SURVIVAL FICTION
- Unlimited resources or convenient discoveries (survival is about SCARCITY)
- Instant expertise (the protagonist shouldn't know everything; they learn by trial and error)
- Ignoring the body (hunger, thirst, cold, pain, fatigue. these are not background)
- Hollywood survival (pretty people with torn clothes but perfect health)
- Nature as malicious (it's indifferent. the absence of malice is MORE frightening)
- Easy rescue (if help arrives, it should be earned, not delivered)
- Psychological stability under extreme stress (the mind cracks; show it)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (immediate physical stakes), Anticipation (next threat), Validation (hard-won small wins).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person present (maximum visceral immediacy) or tight third past
- Voice: Raw, stripped-down, increasingly fragmented as the protagonist deteriorates
- Tone: Visceral and honest; moments of beauty in the landscape contrast with the brutality of survival
- Register: Simple, direct, body-focused. as the protagonist's condition worsens, the prose simplifies

PROSE IMPERATIVES
- THE BODY IN DETAIL: survival prose is the most physically grounded in any genre
  - Every sensation matters: the exact quality of the cold, the specific ache of hunger, the taste of dirty water
  - The body deteriorates across the manuscript: early chapters are fully sensory; late chapters are dimmer, slower, simpler
  - Pain is described functionally: how it affects what the protagonist can DO, not just how it feels
- RESOURCE PROSE: the language of having and not having
  - Quantities matter: "half a water bottle," "three matches," "enough food for one more day"
  - The mathematics of survival: calories in vs. energy out; water found vs. water lost through sweat
  - The emotional weight of resources: the last match is not just a match. it's fire, warmth, life
- ENVIRONMENTAL PROSE: nature described with precision and respect
  - Weather: not "it rained" but the specific rain. cold, warm, horizontal, drizzle, downpour. and its consequences
  - Terrain: described tactically. what offers shelter, water, food, danger
  - Beauty: the wilderness is terrifying AND beautiful; acknowledging both is essential
- DETERIORATION PROSE: the voice changes as the body fails
  - Early: full sentences, varied vocabulary, complete thoughts
  - Middle: shorter sentences, narrower focus, repetitive concerns (water, warmth, food)
  - Late: fragments, confusion, dream-logic intruding, the world going soft

DIALOGUE CRAFT (if applicable)
- Alone: interior monologue, talking to oneself, arguing with oneself (a sign of both coping and cracking)
- With others: dialogue stripped to essentials ("Water?" "No." "Tomorrow." "If.")
- Delirium: conversations with people who aren't there (dead companions, memories, hallucinations)
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. SURVIVAL FICTION

OPENING: Threat + resource scarcity from page 1. Physical sensation dominates over
thought. The reader feels the environment on the protagonist's skin, lungs, bones.
No philosophical preamble. the survival clock starts immediately.

SENTENCES: Short sentences dominate: 6-14 words. sparse, urgent, stripped to
function. Fragments for bodily impact: "Cold. Wet. Dark." Medium (15-20) only for
problem-solving: assessing, planning, deciding. Prose mirrors the body: clipped when
desperate, slightly longer when briefly stable. No decorative language.

VOCABULARY: Physical, concrete, functional. Sensory language is king: the exact
quality of cold, the specific taste of bad water. Resources named precisely: "half
a litre," "three matches." No abstractions. "fear" becomes "shaking hands";
"despair" becomes "sat down and didn't get up."

TENSION FLOOR: ≥7. The survival clock audible from page 1: how long can they last?
Environmental threat immediate and specific: THIS cold, THIS thirst, THIS injury.
Physical sensation > thought. Death genuinely possible. Scarcity visible. what they
do NOT have matters more than what they do.

RHYTHM: Open with the body under siege. one dominant physical sensation. Layer in
assessment: what they have, what they lack. A micro-problem demands immediate
action. Short physical sentences track the attempt. Close with the survival clock
ticking: what comes next if they don't solve the next problem.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

SURVIVAL CRAFT (40% of total):
- Physical experience is visceral and specific? (0-100)
- Resources are tracked and finite? (0-100)
- The environment is rendered with accuracy and respect? (0-100)
- Problem-solving is intelligent and realistic? (0-100)

STORY CRAFT (30% of total):
- The survival clock creates genuine urgency? (0-100)
- The protagonist's deterioration is tracked across the manuscript? (0-100)
- The will to survive is tested and its source explored? (0-100)
- The resolution is earned (not convenient)? (0-100)

PROSE QUALITY (30% of total):
- Body writing is specific and functional? (0-100)
- The prose deteriorates as the protagonist does? (0-100)
- Environmental description is precise and tactile? (0-100)
- Resource language carries emotional weight? (0-100)

AUTOMATIC FAILS (score = 0):
- Convenient resource discoveries that solve problems too easily
- Protagonist remains healthy and strong despite deprivation
- Instant expertise in survival skills
- Nature portrayed as malicious rather than indifferent
- Easy rescue without the protagonist earning survival
- No physical deterioration across the manuscript
```

## Continuity Rules

```
SURVIVAL FICTION CONTINUITY. WHAT TO TRACK

RESOURCE STATE:
- Water: exact amount, when found, rate of consumption
- Food: type, quantity, caloric value, when last eaten
- Fire: ability to make it, fuel available, matches/lighter status
- Shelter: current shelter quality, exposure level
- Tools: what's available, condition, improvised items
- Medical: any first aid supplies, their diminishing quantity

BODY STATE:
- Hydration level: track precisely against the 3-day clock
- Nutrition: days since last substantial meal, caloric deficit
- Injuries: location, severity, infection risk, impact on function
- Exposure: temperature effects, sunburn, frostbite, wet clothing
- Sleep: hours since last rest, quality of sleep, accumulated deficit
- Cognitive state: confusion, hallucination, impaired judgment (correlates with dehydration/starvation)

ENVIRONMENTAL STATE:
- Weather: current conditions and forecast (if observable)
- Terrain: the protagonist's mental map of their surroundings
- Water sources: known, suspected, distance
- Dangers: predators, terrain hazards, weather threats
- Time of year: affects temperature, daylight hours, food availability

PSYCHOLOGICAL STATE:
- Motivation: what's keeping them going (a person, a promise, stubbornness, fear)
- Hope level: realistic assessment of rescue/survival chances
- Mental deterioration: confusion, hallucination, paranoia, resignation
- Coping mechanisms: rituals, routines, self-talk, goals
- The breaking point: how close are they?

TIMELINE:
- Day count: precisely tracked (the protagonist often counts days)
- Hours since last water, food, sleep
- Distance traveled and distance remaining (if they're heading somewhere)
- Weather patterns: is it getting colder, wetter, hotter?
```

## Character Rules

```
SURVIVAL CHARACTER TYPES

THE SURVIVOR:
- An ordinary person: not Bear Grylls; someone with LIMITED skills who must LEARN
- Has a REASON to survive: a person waiting for them, a promise, a child, an unfinished life
- Resourceful: they observe, adapt, and improvise with what's available
- Vulnerable: they make mistakes, panic, and break down. then get up again
- Their pre-survival life provides unexpected skills (a chemistry teacher knows about water purification; a chef knows about nutrition)
- The survival experience reveals who they REALLY are beneath the social self

THE COMPANION (if present):
- Creates dialogue and conflict (survival with another person is different from alone)
- Complementary or conflicting skills and temperament
- Trust is tested: when resources are scarce, cooperation is not guaranteed
- Their loss (through death, separation, or conflict) is the story's most powerful weapon

THE ENVIRONMENT:
- Nature is not a villain. it's a system with rules that can be learned
- It is indifferent: it doesn't care about the protagonist; this is more terrifying than malice
- It provides and denies: the same forest that shelters can freeze; the same ocean that provides fish can drown
- It is specific: not generic "wilderness" but THIS mountain, THIS desert, THIS ocean

VOICE (internal):
- Early: coherent, problem-solving, rational self-talk
- Middle: bargaining, pleading, arguing with oneself
- Late: fragmented, confused, the boundaries between thought and hallucination blurring
- The voice the protagonist uses to keep going: "One more step. One more hour. One more day."
```

## Arc Rules

```
SURVIVAL FICTION STORY STRUCTURE

ACT 1: THE CATASTROPHE (first 25%)
- The event: crash, storm, collapse, stranding. rendered with visceral immediacy
- Assessment: what does the protagonist have? Where are they? What are the immediate threats?
- First decisions: shelter, water, fire. the survival priorities established
- The reality sinks in: help is not coming (or not coming soon enough)
- END OF ACT 1: The protagonist commits to survival and makes their first plan

ACT 2A: THE STRUGGLE (to midpoint)
- Daily survival: the routines of staying alive (water collection, food gathering, shelter maintenance)
- Each chapter introduces a new challenge: weather, injury, predator, equipment failure
- Skills develop through trial and error: failures teach lessons
- The body begins to show the strain: weight loss, weakness, injury effects
- MIDPOINT: A major setback. the shelter destroyed, a serious injury, water source gone, companion lost. that threatens everything built so far

ACT 2B: THE DECLINE (midpoint to dark moment)
- Resources dwindle to critical levels
- The body deteriorates: the protagonist can do less each day
- The mind begins to crack: hallucination, confusion, despair
- A desperate gamble: an attempt to reach safety, find resources, or signal rescue
- DARK MOMENT: The lowest point. injured, starving, lost, and out of ideas; the will to survive is all that remains (and it may not be enough)

ACT 3: THE RESOLUTION (final 25%)
- The protagonist draws on everything they've learned
- A final effort: the last climb, the last walk, the last signal
- Rescue or self-rescue: EARNED through the protagonist's actions, not luck
- The return: the shock of civilization, the inability to communicate the experience
- What survival cost: the physical and psychological toll assessed
- The person who survives is not the person who started

SURVIVAL PACING:
- ACT 1 is fast: the catastrophe and its immediate aftermath
- ACT 2A settles into the rhythm of daily survival (slower, more detailed)
- ACT 2B accelerates as resources fail and decisions become desperate
- ACT 3 is a sustained push: everything the protagonist has left, spent at once
```

## Timeline Rules

```
SURVIVAL FICTION TIMELINE

DAY COUNT:
- Track days precisely: survival stories are measured in days
- Each day has a rhythm: dawn assessment, daylight activity, dusk preparation, night endurance
- The day count is the story's calendar

BODY CLOCK:
- Dehydration: symptoms by day 2, serious cognitive impairment by day 3, organ failure by day 5
- Starvation: energy decline by day 3, muscle wasting by week 2, cognitive decline throughout
- Sleep deprivation: hallucination by day 3, micro-sleeps by day 4, dangerous impairment by day 5
- Injury: infection timeline depends on wound type and conditions
- Hypothermia: minutes to hours in severe cold; hours in moderate cold with wet clothing

RESOURCE CLOCK:
- Water: consumption rate, source replenishment, storage capacity
- Food: caloric intake vs. output, gathering efficiency
- Fire: fuel consumption, fire-starting ability
- Shelter: structural integrity over time, weather resistance
```

## Genre-Specific Craft Techniques

Survival is the discomfort-register fiction sub-genre,
distinct from adventure (action-driven journey) and thriller
(threat-driven tension) in centring the protagonist's
sustained grinding endurance against environmental hostility.
The form's signature pleasure is the close-grain rendering
of physical and psychological deterioration alongside the
specific competence required to keep operating despite it.
The cluster includes wilderness survival, post-apocalyptic
survival, shipwreck and castaway fiction, polar expedition,
mountaineering / climbing disaster, desert survival,
maritime survival, urban survival in collapse scenarios,
prison-escape survival, and the broader literary survival
range. Comp authors span the canonical lineage (Jack London's
*To Build a Fire* and *The Call of the Wild*, Ernest
Hemingway's *The Old Man and the Sea*, Joseph Conrad's
maritime survival, Daniel Defoe's *Robinson Crusoe*, Yann
Martel's *Life of Pi*, James Dickey's *Deliverance*) through
the contemporary expansion (Andy Weir's *The Martian*, Hugh
Howey's *Wool*, Cormac McCarthy's *The Road*, Emily St. John
Mandel's *Station Eleven*, Lauren Beukes's *Afterland*, Tea
Obreht's *Inland*, Diane Cook's *The New Wilderness*, Ling
Ma's *Severance*, Eleanor Catton's bush-survival in *The
Rehearsal*, Madeline Miller's mythical survival register,
Karen Russell, Alexandra Christo, Erin Morgenstern at the
fantasy-cross edge, Peter Heller's *The Dog Stars* and *The
River*, James A. Michener's expedition-survival, Sebastian
Junger on real-world survival narrative, Jon Krakauer on
real-world disaster, Laurence Gonzales's *Deep Survival* on
the psychology). The techniques below are how the form
delivers its core pleasures while avoiding the failure
modes (action-adventure register applied where survival
discomfort should operate; hero-narrative competence-porn
that voids the form's specific endurance focus; deterioration
asserted not rendered; wilderness as backdrop rather than
antagonist).

### The Countdown

The reader should always feel the survival clock. Survival
fiction's signature tension structure: the protagonist's
remaining time / water / food / fuel / battery / heat /
medication is calculable, and the reader's awareness of the
calculation IS the form's tension. Generic "she was running
out of supplies" is the failure mode; specific countable
resources tracked across pages with each consumption felt
is the technique.

```
Day 1: She had a half-litre of water. Enough for
today if she was careful.

Day 3: The water was gone. Her tongue was thick. The
stream she'd found was salt. She had maybe twelve
hours before her kidneys started to shut down, and
she knew this because she was a nurse, and knowing
made it worse.

The precision IS the tension.
```

The technique requires that the writer know the actual
survival math. Hypothermia onset times in specific cold
conditions; dehydration timelines in specific climates;
calorie deficit consequences across days; the specific
temperature at which frostbite begins on exposed skin; the
specific blood-sugar level at which clear thinking fails;
the specific water-loss percentage at which kidney function
deteriorates. Survival fiction readers include outdoor
practitioners, medical professionals, and serious survival
literature readers who detect imprecise survival math
immediately.

The technique also requires that the reader feel the
calculation alongside the protagonist. The protagonist who
checks their water and thinks "I have maybe six hours" is
operating within the form; the protagonist whose specific
counting is shown — the bottle held up to the light, the
finger marking the level, the calculation of how many
swallows remain — is the form's deeper register.

Test: identify the manuscript's survival countdowns and
verify each operates with specific numbers and specific
real-world physiology. Generic countdowns ("she didn't have
much time left") are the failure mode; specific countdowns
with realistic math are the technique.

### The Micro-Victory

In survival fiction, small achievements are huge. The form's
distinctive pacing: tasks that adventure or thriller would
dispatch in a sentence — building a fire, finding water,
catching a fish, making shelter — become the form's
structural beats, with each successful completion carrying
the weight of the protagonist's continued existence.

```
NOT SURVIVAL FICTION:
"She successfully built a fire."

SURVIVAL FICTION:
"The tinder caught. A curl of smoke, then a thread
of flame no bigger than a fingernail. She held her
breath. The flame wavered. Held. Grew. She fed it
a splinter of wood, then another, then a stick the
width of her little finger. She was crying. She
didn't notice until the tears hissed on the rock
beside the fire."

Starting a fire is not a task. It's a TRIUMPH.
```

The technique requires that the writer slow down for the
micro-victories. Generic "she got the fire going" loses the
form's central pleasure; the beat-by-beat rendering of the
process — including the failures along the way, the hands
shaking, the specific physical detail of the tinder
catching — is the technique. The reader's emotional
investment is in the protagonist's continued capacity to
keep operating, and each micro-victory is a confirmation
that the protagonist is still capable.

The technique also requires that micro-victories be earned.
The protagonist who effortlessly succeeds at survival tasks
has not been through the form's pressure cooker; the
protagonist whose first fire-attempt fails (the tinder too
damp, the spark not catching, the wind taking the flame),
who tries again with adjusted approach, who finally gets
the fire going through specific incremental skill —
demonstrates the competence the form's reader has come for.

Test: pick three significant survival tasks in the
manuscript and verify each is rendered as specific multi-
step process with possible failure modes addressed. If
tasks resolve in a sentence, the form's signature pacing
has been short-circuited.

### The Mind Cracks

As the body fails, the prose reflects cognitive decline.
Survival fiction's signature interior craft: deterioration
of the body produces deterioration of mind, and the prose
should track the cognitive shift through changes in
sentence structure, attention range, memory access, and
emotional register. The protagonist of day five does not
think the same way as the protagonist of day one, and the
prose should make this difference visible.

```
Day 1: "She needed to find water, build shelter,
and signal for rescue. In that order. She could
survive three days without water. She had roughly
eight hours of daylight."

Day 5: "Water. She needed. There was a sound like
water. Everything sounded like water now. The wind
was water. Her own breath was water. She walked
toward the sound and it was her boots on gravel,
just her boots on gravel, and she sat down because
standing was. Difficult."
```

The technique requires deliberate prose-rhythm shifts as
the deterioration progresses. Day-one prose can be
structured, planning-oriented, complete-sentence; day-five
prose fragments, repeats, loses through-line, surrenders
the protagonist's habitual register. The transitions
between these states should be calibrated so the reader
feels the slow degradation rather than encountering an
abrupt switch.

The technique also requires accurate rendering of specific
deterioration patterns. Hypothermic mental decline operates
differently from dehydration's; severe hypoglycaemia
produces specific cognitive symptoms; sleep deprivation
across days follows known progressions; oxygen deprivation
at altitude has its specific signature; specific deficiency
states (thiamine, electrolyte imbalance) have specific
cognitive presentations. Survival fiction readers include
specialists who detect generic-cognitive-decline rendering;
the strongest survival prose researches the specific
deterioration pattern operating.

Test: identify the manuscript's cognitive-deterioration
moments and verify each renders the specific kind of
decline the protagonist's specific physical condition
would produce. If the decline reads generically, research
the specific physiology and revise.

### The Hostile Environment as Antagonist

Survival fiction's signature relationship to setting:
unlike adventure (where setting is a participant in the
action) or thriller (where setting is backdrop for human
threat), survival treats the environment AS the antagonist.
The mountain isn't the setting for the climb — it is the
antagonist. The storm isn't weather — it is the active
force opposing survival. The cold isn't atmosphere — it is
the killer.

The technique requires that the environment have specific
capabilities, specific patterns, specific vulnerabilities
that the protagonist must learn. The strongest survival
prose makes the environment legible to the reader as a
presence with its own logic:

- **Specific dangers** — what specifically can kill in
  this environment (the wet cold worse than the dry cold;
  the still water where the leeches are; the cliff face
  where the rock fall comes from a specific direction; the
  specific snake whose bite has the specific timeline).
- **Specific patterns** — when the dangers operate (the
  storm season; the time of day when the ice cracks; the
  hours when predators are active; the wind that comes
  from the same direction every afternoon).
- **Specific vulnerabilities** — what the protagonist can
  exploit about this specific environment (the cave the
  bear has not visited yet; the spring the deer use; the
  specific plant that's edible and the very-similar plant
  that's not).

The technique fails when the environment operates as
generic "wilderness" or "ocean" or "desert"; it succeeds
when the environment operates with specific named
particulars only this terrain has. Test: pick three
environmental encounters in the manuscript and verify each
operates with terrain-specific particulars rather than
generic wilderness convention.

### The Physiology Discipline

Survival fiction has the strictest physiology requirements
of any commercial fiction sub-genre. Real survival
literature readers will accept genre conventions in many
forms but will not accept survival prose that gets the
basic physiology wrong. The discipline:

- **Hypothermia operates by stages.** Mild (shivering,
  clumsiness), moderate (mental confusion, paradoxical
  undressing), severe (unconsciousness, potential cardiac
  arrest). The progression is specific; survival fiction
  must render the stages.
- **Dehydration timelines are specific.** Three days
  without water is the rough survival limit, but
  performance degrades on day one, severely on day two,
  and dramatically on day three. Heat / exertion / altitude
  shorten the timeline. Survival fiction must know the
  conditions and the consequences.
- **Calorie deficits compound across days.** Twenty-four
  hours without food is uncomfortable; seventy-two hours
  is reduced capacity; one week is significant
  physiological stress; two weeks begins systemic
  consequences. The protagonist who has not eaten for ten
  days does not perform at full capacity.
- **Frostbite stages.** Frostnip (reversible);
  superficial frostbite (skin damage); deep frostbite
  (tissue death). Specific temperatures, specific exposure
  durations, specific recovery requirements.
- **Sleep deprivation effects.** Twenty-four hours
  reduces cognitive performance; forty-eight produces
  micro-sleeps; seventy-two produces hallucinations and
  severe cognitive impairment. The protagonist on day five
  of poor sleep is not operating at full faculty.
- **Altitude sickness onset and progression.** Acute
  mountain sickness, high-altitude pulmonary oedema,
  high-altitude cerebral oedema — each at specific
  altitudes, with specific symptoms, with specific
  treatments.

The discipline requires research. The strongest survival
fiction is researched against actual survival literature,
medical sources, and (where possible) practitioner
consultation. The form's failure mode is the writer who
imagines what survival would feel like rather than
researching what it actually is.

Test: identify three physiological events in the manuscript
(hypothermia onset, dehydration progression, frostbite
development, altitude sickness, calorie deficit, sleep
deprivation, infection development). For each, verify the
manuscript's rendering matches actual medical / survival
science.

### The Survivor's Identity

Survival fiction's signature character work: the protagonist
who survives is not the protagonist who started. The form
asks what survival costs at the level of identity — what
the protagonist had to become, give up, do, and live with
to keep operating. The strongest survival fiction makes
this question central to the form's emotional weight rather
than incidental to its plot.

The technique requires:

- **Specific costs** — what the protagonist did that
  someone they were before would not have done. The food
  taken from another survivor. The companion left
  behind. The mercy not given. The small lie that
  preserved their position. Each is a specific cost the
  manuscript must register.
- **Specific accumulations** — the protagonist's
  cumulative sense of who they have become. The strongest
  survival prose tracks this across the book, with the
  protagonist's interior register shifting as the
  cumulative costs accrue.
- **Specific aftermath** — when survival is achieved (or
  when the protagonist comes to terms with not being
  rescued), the form's contract requires that the prose
  acknowledge what was paid. The protagonist who emerges
  unchanged from the survival ordeal has not been through
  the form's pressure; the protagonist whose specific
  capacity for ordinary life has been altered has been
  through it.
- **Refused-redemption permission** — survival fiction
  permits — and is often deepened by — protagonists who
  do not get redemption from what they did to survive.
  The form does not require that the protagonist be
  forgiven, find peace, or fully reintegrate. The
  protagonist who has done what they did and now lives
  with it as the cost of breathing is the form's deeper
  register.

Test: at the manuscript's close (or at the survival
ordeal's end if the book continues afterward), can the
writer specify what the protagonist had to become, what
they paid, and how they now live with it? If the answers
are generic, the survivor's-identity work has not been
deployed.

### Survival Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "every day was a fight for survival" | Show the specific daily survival task |
| "resources were scarce" | Show the specific resource count |
| "nature was the ultimate adversary" | Show the specific natural threat |
| "the will to survive" | Show the specific motivation. person, memory, goal |
| "hunger gnawed at her" | Show the specific physical effect of hunger |
| "shelter was essential" | Show the specific shelter-building or finding |
| "the elements were merciless" | Show the specific weather effect on the body |
| "isolation took its toll" | Show the specific psychological effect |
| "a moment of hope in the wilderness" | Show the specific hopeful discovery |
| "every decision could mean life or death" | Show the specific decision and stakes |
| "she was running on fumes" | Show the specific physical state through specific behaviour (the hands no longer responding cleanly; the vision narrowing) |
| "the cold was bone-deep" | Show specifically what the cold is doing to the body in this moment (the chest-cold; the fingers no longer fine-motor capable; the breath-pattern shifted) |
| "she pushed through the pain" | Show what specifically the pushing-through cost (the specific functional impairment that follows) |
| "her instincts saved her" | Show what specifically the protagonist registered (the change in the wind; the specific pattern recognition; the trained response) |
| "she'd never been so tired" | Show specific markers of the exhaustion (the micro-sleeps; the foot-tripping; the difficulty assembling sentences) |
| "the wilderness was vast" | Show ONE specific detail that makes it specifically vast (the stretch of horizon without a tree; the specific kind of silence; the absence of any sound that wasn't the wind) |
| "she had to keep going" | Cut; show what specifically motivates the continuation in this moment |
| "death was always one mistake away" | Show the specific mistake the protagonist is conscious of avoiding right now |

## Genre-Specific Revision Rules

Six revision passes specific to survival fiction, each with a
single question, run cover-to-cover before the next begins.
Survival revision must hold the form's signature contracts:
resource tracking (every resource counted across pages); body
deterioration (the protagonist's physical state worsening
across the manuscript); problem-solving authenticity
(intelligent realistic solutions); psychological state
consistency (mind tracking body); environmental accuracy
(specific researched terrain); and the survivor's-identity
audit (what survival cost). The passes below are ordered to
surface resource and body failures first (the form's most-
felt by genre readers), problem-solving and psychology next,
environment and identity last as integrative final checks.

### Pass 1: Resource Tracking Check

Build the manuscript's resource ledger. Every survival-
relevant resource — water, food, fire / fuel, shelter
materials, medical supplies, tools, weapons, clothing,
batteries, signal devices, transportation, currency where
applicable — with its quantity at each significant point in
the manuscript. Read the manuscript against the ledger.

Verify all resources are accounted for. Has anything been
consumed, lost, or found since the last chapter? Generic
"she checked her supplies" without specific count is the
failure mode; specific count tracked across chapters is the
technique. Verify the reader knows the protagonist's supply
level at any given moment. If the reader has lost track of
what the protagonist has, the form's tension engine has
slipped.

The form's strongest practitioners turn the depleting
resource into its own tension engine. The protagonist who
has three matches left makes lighting a fire matter
differently from the protagonist who has unlimited matches.
The protagonist whose water bottle is at one-third and
whose next water source is a day's walk faces decisions the
unlimited-water protagonist never faces. Test: pick three
significant decisions in the manuscript and verify each is
shaped by the resource state at that moment.

### Pass 2: Body Deterioration Check

Verify the protagonist's physical condition is worse than
the previous chapter. Survival fiction's structural pressure
depends on continuous deterioration; the protagonist who is
in the same condition at chapter twenty as chapter five
has not been through the form's pressure cooker. Build a
deterioration ledger: each significant physical condition
(hypothermia, dehydration, hunger, exhaustion, frostbite,
infection, altitude sickness, specific injuries) and its
progression chapter by chapter.

Verify injuries are persistent and affecting function. The
sprained ankle in chapter four still affects the
protagonist's mobility in chapter twelve, with specific
operational consequences (the slower pace; the inability to
run; the specific gait that protects the joint and tires
the rest of the body). Generic "her ankle hurt" is the
failure mode; specific functional impairment operating
across chapters is the technique.

Verify the body clock is tracked: days without water, days
without food, hours of sleep, days of exposure. The
protagonist who is on day five without sleep operates
differently from the protagonist on day one. The reader
should know — and the protagonist's behaviour should
reflect — the cumulative state.

Test: pick three chapters spaced across the manuscript and
verify the protagonist's physical state has measurably
deteriorated from the prior. If chapters show static
physical state, the deterioration ledger has not been
deployed.

### Pass 3: Problem-Solving Check

Verify the protagonist faces a specific survival challenge
in each chapter. Survival fiction's plot pressure is
problem-solving — the cumulative encounter with situations
that the protagonist must work out how to handle. Generic
"she struggled to survive" without specific problems is
the failure mode; specific problems with specific
parameters and specific available materials is the
technique.

Verify the solution is intelligent and realistic — no magic
solutions. Survival readers detect implausible solutions
immediately. The protagonist who lights a fire in a
rainstorm without specific tinder preparation has done the
implausible; the protagonist who lights a fire in a
rainstorm using specific researched techniques (the dry
inner wood from a standing dead tree; the bark shaving for
tinder; the wind-shielded position) has demonstrated the
form's signature competence.

Verify the protagonist learned something from failure. The
strongest survival fiction shows the protagonist's
competence growing across the manuscript through specific
on-page failure-then-success cycles: the snare that didn't
hold the rabbit because the loop was wrong; the next snare
set with the loop adjusted; the rabbit caught. The
protagonist who succeeds at every survival task has not
been challenged; the protagonist whose competence was
earned through specific visible failures has been through
the form's actual pressure.

Test: pick three problem-solving moments and verify each
shows specific available materials, intelligent realistic
solution, and (across the manuscript) growing competence
through visible failure.

### Pass 4: Psychological State Check

Verify the protagonist's mental state is consistent with
their physical condition. The Mind Cracks technique
requires that cognitive deterioration track the body's
deterioration. The protagonist who is severely dehydrated
should not be operating with full cognitive faculty; the
protagonist who has been awake 72 hours should be
hallucinating, making poor decisions, and missing obvious
threats. Mismatch between body state and mind state is
the form's most-flagged technical failure.

Verify coping mechanisms are visible. Survival fiction's
distinctive interior craft includes the specific
psychological strategies the protagonist uses to keep
operating: specific memories returned to repeatedly;
specific mantras or self-talk; specific physical rituals;
specific small comforts maintained against the larger
hardship. These are character work; their specific
deployment reveals who the protagonist is under maximum
pressure.

Verify deterioration (if applicable) is reflected in the
prose style. The prose-rhythm shift across the manuscript
from coherent planning-oriented prose at the start to
fragmented, repetitive, attention-narrowed prose at peak
deterioration is the form's signature interior-rendering
technique. Manuscripts where the prose register stays
constant despite the protagonist's mental decline have
missed the form's deepest interior craft.

Test: read three first-person passages spaced across the
manuscript (early, deterioration peak, recovery or end).
Are they written in different prose registers reflecting
the protagonist's different cognitive states? If the prose
sounds the same throughout, the technique has not been
deployed.

### Pass 5: Environmental Accuracy Check

Verify the environment is specific and accurately
described. Survival fiction's reader includes outdoor
specialists who detect imprecise terrain immediately. Build
an environment ledger: every significant terrain feature,
weather condition, plant, animal, geological detail, with
verification against actual real-world particulars of the
chosen setting.

Verify weather, terrain, and wildlife are realistic for
the setting. Generic "the desert was hot and dry" without
specific Sonoran-versus-Saharan-versus-Atacama
particulars is the failure mode; specific named flora and
fauna, specific known weather patterns, specific
geological detail is the technique. Where the manuscript
fictionalises terrain, internal consistency is the
standard.

Verify the environment actively creates challenges, not
just backdrop. The Hostile Environment as Antagonist
technique requires that the place specifically threaten
and specifically constrain. Test: pick three environmental
beats in the manuscript and verify each operates with
terrain-specific particulars rather than generic
wilderness convention.

The pass also catches the common failure: protagonists who
behave as tourists rather than as survivors. The
protagonist in genuine survival should know the
environment they're in (or be specifically rendered as not
knowing — which is itself a survival problem). The
protagonist who walks through the Amazon without
acknowledging insect life has been written by someone who
has not been there. The protagonist whose specific
attention to specific environmental particulars
demonstrates the form's signature situational awareness.

### Pass 6: Survivor's Identity Audit

Run a final pass on the protagonist's identity arc across
the survival ordeal. The strongest survival fiction asks
what the protagonist had to become, give up, do, and live
with to keep operating. Audit the manuscript:

- **What specific costs has the protagonist incurred?**
  Each cost should be on the page: the specific food taken
  from another survivor; the specific companion abandoned;
  the specific mercy not given; the specific lie told;
  the specific moral compromise made. Generic "survival
  changed her" is the failure mode; specific named costs
  are the technique.
- **How have the costs accumulated in the protagonist's
  interior register?** The strongest survival fiction
  shows the protagonist's cumulative awareness of who they
  have become. By the climax, the protagonist should have
  a specific sense — articulable in the prose, even if not
  spoken aloud — of the distance between who they were
  and who they are now.
- **What is the aftermath?** When survival is achieved (or
  when the protagonist comes to terms with not being
  rescued), the prose should acknowledge what was paid.
  Specific markers: the inability to eat certain foods; the
  specific dreams that recur; the specific way the
  protagonist now responds to specific stimuli; the
  relationships they cannot quite return to as before.
- **Has the manuscript permitted refused-redemption?**
  Survival fiction does not require that the protagonist be
  forgiven, find peace, or fully reintegrate. The form's
  deeper register often has protagonists who have done
  what they did and now live with it as the cost of
  breathing. Manuscripts that force tidy reintegration
  may be undercutting their own emotional truth.

Test: at the manuscript's close, can the writer specify
what the protagonist had to become, what they paid, and
how they now live with it? Each answer should be specific
and traceable to events on the page. If answers are
generic ("she had been changed by the experience"), the
survivor's-identity work has not been deployed and the
form's deepest emotional register has been forfeited.

## Names & Patterns to Avoid

### Survival Fiction. NEVER DO
- Give the protagonist a convenient background (ex-Navy SEAL, survival instructor) unless earned
- Let the protagonist find perfectly useful items at convenient moments
- Skip the boring parts (repetitive survival tasks ARE the genre)
- Maintain pretty prose as the character starves (the prose should deteriorate too)
- Rescue the protagonist through pure luck (rescue must be earned)

### Use Instead
- Names grounded in the character's pre-survival life
- The protagonist's ordinary background that provides unexpected advantages

## Comp Titles

Survival fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Robinson Crusoe* — Daniel Defoe (1719): the survival-novel archetype.
- *Lord of the Flies* — William Golding (1954): the social-collapse survival benchmark.
- *Hatchet* — Gary Paulsen (1986): YA wilderness-survival template.
- *The Road* — Cormac McCarthy (2006): post-apocalyptic survival literary benchmark.

### Contemporary (current best-in-class)

- *Station Eleven* — Emily St. John Mandel (2014): post-pandemic literary survival.
- *Wanderers* — Chuck Wendig (2019): contemporary epidemic-survival doorstop.
- *The Marrow Thieves* — Cherie Dimaline (2017): Indigenous post-apocalyptic survival.
- *The River* — Peter Heller (2019): wilderness literary-survival.
- *Severance* — Ling Ma (2018): pandemic-survival with millennial-labour critique.
- *The New Wilderness* — Diane Cook (2020): cli-fi survival literary benchmark.
- *American War* — Omar El Akkad (2017): future-war survival literary fiction.
- *The Light Pirate* — Lily Brooks-Dalton (2022): cli-fi-survival literary benchmark.

## Cover Design Specifications

### Recommended Visual Styles
- **Landscape**. The environment as adversary: vast, beautiful, and lethal; a tiny figure against an overwhelming natural world
- **Textural**. Extreme close-up: cracked earth, ice crystals, rough bark, salt-crusted skin; the tactile reality of survival
- **Minimalist**. A single object against emptiness: a match, a knife, a water bottle, footprints; the essentials stripped bare
- **Dramatic**. The moment of crisis: a storm, a wave, a cliff edge; the visual equivalent of the survival clock ticking

### Genre Cover Aesthetics
- **Styles:** Vast natural landscapes dwarfing human figures, extreme weather conditions, the isolation of a single figure in wilderness, close-up textures of natural environments, the contrast between human fragility and natural power
- **Colours:** Natural palettes taken to extremes: ice blues and whites, desert golds and reds, ocean grey-blues, forest dark greens; harsh, unforgiving natural light; the colour of the specific environment pushed to its most dramatic
- **Elements:** Natural environments at their most dramatic, lone figures or footprints, survival equipment (minimal), weather as visual force, the horizon as both threat and hope, maps or topographic imagery
- **Typography:** Clean, bold, readable against dramatic backgrounds; sans-serif for modern survival, serif for literary survival; the title should feel urgent; sometimes the title is the only design element against vast emptiness

### Market Positioning
Survival fiction covers must signal "alone against nature" through dramatic landscape imagery and the contrast between human scale and environmental scale. Position against Krakauer, Grann, Owens, Brown. The environment should be immediately identifiable (ocean, mountain, arctic, desert). At thumbnail size, the lone figure against vast landscape is the genre's visual signature.

### Cover Design DON'Ts
- No comfortable or inviting natural settings
- No action-movie aesthetics
- No bright, cheerful colours
- No cluttered compositions (survival is about emptiness and scarcity)
- No technology or equipment prominently displayed (the person matters, not the gear)
- No designs that look like travel brochures
