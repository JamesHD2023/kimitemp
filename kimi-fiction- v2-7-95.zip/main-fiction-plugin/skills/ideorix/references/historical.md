---
name: historical-fiction-genre
description: Genre-specific instructions for historical fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Historical Fiction. Genre Plugin

## Metadata
- id: historical
- name: Historical Fiction
- icon: 🏛️
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Three-Act Structure", "Five-Act Structure", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Epic Historical**. Grand scope: wars, empires, revolutions; individual lives caught in the sweep of history
- **Intimate Historical**. Personal stories against a historical backdrop: the domestic, the daily, the human-scale experience of a specific time
- **Historical Mystery**. A crime or puzzle set in a past era; the period isn't backdrop, it's a constraint that shapes the investigation
- **Biographical Historical**. Fictionalised life of a real person; the challenge of imagining interior life from documented exterior events
- **Dual Timeline**. Past and present in dialogue: a contemporary protagonist connected to a historical mystery, person, or place
- **Revisionist Historical**. Centering perspectives traditionally marginalised in historical narratives: women, people of colour, LGBTQ+ individuals, the working class

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-5,000 words (historical fiction needs room for world-building and context)
- Pacing: Period-appropriate rhythm. an 1810 novel moves differently from a 1940 novel; match the pace to the era's sensibility
- Must open with: A character IN the period. not a lecture about it; the reader should feel the era through sensation, action, and voice before understanding it intellectually

BEATS PER CHAPTER
1. Period Immersion Beat. The era is felt through the senses: what characters see, hear, smell, touch, taste; the PHYSICAL experience of living in this time
2. Historical Pressure Beat. The larger historical context presses on the personal: war, plague, law, social change, revolution. history isn't background, it's active force
3. Character Agency Beat. Within historical constraints, the protagonist ACTS: makes choices, takes risks, pursues desires
4. Social Reality Beat. The period's social structures are felt: class, gender, race, religion, power. who has it, who doesn't, what it costs
5. Human Connection Beat. Amidst the historical, the universally human: love, friendship, family, fear, hope

HISTORICAL FICTION ARCHITECTURE
- ACCURACY is foundation: the facts, dates, technology, social norms, and material culture must be correct
- But accuracy is NOT sufficient: the historical world must feel LIVED-IN, not researched
- The PERIOD shapes the story: characters can only do what people of their time and place could do
- ANACHRONISM is the enemy: not just in facts but in attitudes, language, and assumptions
- Characters are OF their time: they don't share modern values or modern knowledge; they have their OWN values
- HISTORY is not backdrop: the historical events and conditions actively shape the plot
- The READER needs bridges: historical details must be conveyed naturally, not through info-dumps
- POV: Third person past (dominant. gives the period appropriate distance and scope) or first person past (for intimate/memoir framing)

RESEARCH INTO FICTION
- Research informs but doesn't dominate: for every hour of research, a few sentences make it into the prose
- The iceberg principle: the reader should feel the depth of knowledge without seeing all of it
- Material culture matters most: what people eat, wear, use, sit on, travel in. these create the period
- Avoid the museum effect: characters don't notice their own era as remarkable (they LIVE in it)

FORBIDDEN IN HISTORICAL FICTION
- Characters with modern attitudes in period costume ("she was a feminist in 1740". she might resist her constraints, but she'd think about it DIFFERENTLY from a modern feminist)
- Info-dumps: paragraphs of historical context that stop the story cold
- The museum-guide narrator who explains everything to the reader
- Anachronistic language: "okay" in medieval England, "stressed out" in Victorian London
- Perfect historical figures: real historical people were as flawed and contradictory as anyone
- History as tourism: the plot could happen in any era, and the period is just colourful backdrop
- Ignoring the period's cruelties: slavery, colonialism, gender oppression. these existed and affected everyone
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation through period detail, Anticipation, Affection with the protagonist, Revelation through period-specific theme.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the historical cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  historical cues below apply directly.VOICE & TONE
- POV: Third person past (gives the period appropriate weight) or first person past (memoir/journal framing)
- Voice: Period-evocative without being period-pastiche; the language should FEEL like the era without imitating it
- Tone: Matches the story's emotional register AND the era's sensibility
- Register: Elevated for earlier periods, more conversational for modern history; always CHARACTER-specific

PROSE IMPERATIVES
- MATERIAL CULTURE: the world is built through THINGS
  - What characters wear (fabric, cut, condition. class in cloth)
  - What they eat (ingredients, preparation, who serves, who eats first)
  - What they touch (tools, surfaces, objects. the texture of daily life)
  - What they travel in/on (and how long it takes)
- SENSORY PERIOD: each era has its own sensory palette
  - Medieval: woodsmoke, tallow, unwashed wool, mud, bread baking, church incense
  - Georgian/Regency: beeswax candles, horse manure, lavender water, coal fires, ink
  - Victorian: coal smoke, gas lamps, gin, machine oil, carbolic soap, fog
  - WW2: diesel, cordite, powdered egg, blackout darkness, wireless static
  - Each era SMELLS, SOUNDS, and FEELS different from ours
- LANGUAGE CALIBRATION: period-evocative, not period-pastiche
  - Use period vocabulary where natural: "fortnight," "I dare say," "vexed"
  - Avoid modern idioms: no "okay," "stressed," "awesome," "issues," "triggered"
  - But DON'T write full period prose: readers need to READ it, not decode it
  - The goal: a reader should forget they're in the 21st century without struggling with the language
- THE LIVED-IN WORLD: characters don't notice their era as remarkable
  - A Victorian woman doesn't think "I live in a patriarchal society". she navigates specific restrictions
  - A medieval peasant doesn't marvel at castles. they're just WHERE THE LORD LIVES
  - Show the era through habituation, not wonder

DIALOGUE CRAFT
- Period vocabulary: use it naturally, not excessively
- Class and gender affect speech: an aristocrat sounds different from a servant; these patterns were STRONGER in the past
- Avoid direct translation of period speech (don't write in full Middle English or thieves' cant)
- The balance: dialogue that FEELS right for the period without being inaccessible
- What people DON'T say is period-specific: topics avoided, words not used, feelings not expressed
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. HISTORICAL FICTION

OPENING: Period immersion through character's senses, NOT exposition. No dates in
italics. a person breathing, seeing, smelling their world before context is given.

SENTENCES: Medium-formal, 16-24 words average. Longer (25-35) for atmosphere;
shorter (8-12) for impact beats. Period cadence. weight and measure, not modern
staccato. Sentence openings vary: sensory, action, environmental observation.

VOCABULARY: Period-flavoured but accessible ("fortnight" not "two weeks," "vexed"
not "annoyed"). No words that didn't exist in the period. Latinate for formality,
Anglo-Saxon for physicality. Sensory language grounded in the era's materials:
tallow, linen, coal-smoke, beeswax. Vocabulary suggests POV character's class.

TENSION FLOOR: ≥5. Displacement tension. the character's ordinary is about to
break. Period-specific threats seed dread: disease, social ruin, political upheaval.
The world has teeth beneath its beauty. Unanswered questions sustain momentum.

RHYTHM: Open with sensory grounding (3-5 sentences in the physical world). Layer
in character's concern or action. Introduce historical pressure through specific
detail, not summary. Close the opening page on an image that signals stakes.
Dialogue arrives earned. period voices establishing the world.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

HISTORICAL CRAFT (40% of total):
- The period is felt through material culture and sensory detail? (0-100)
- Historical accuracy is maintained (dates, technology, social norms)? (0-100)
- Characters are OF their time (not modern people in costume)? (0-100)
- History shapes the plot (not just decorates it)? (0-100)

STORY CRAFT (30% of total):
- Character has agency within historical constraints? (0-100)
- Stakes are clear and compelling? (0-100)
- Plot and character serve each other? (0-100)
- The ending is satisfying and historically plausible? (0-100)

PROSE QUALITY (30% of total):
- Language is period-evocative without pastiche? (0-100)
- Sensory detail creates immersion? (0-100)
- Research is invisible (iceberg principle)? (0-100)
- Dialogue feels period-appropriate and accessible? (0-100)

AUTOMATIC FAILS (score = 0):
- Modern attitudes in period costume (anachronistic values)
- Info-dumps of historical context
- Anachronistic language
- History as tourism (the period is interchangeable backdrop)
- Ignoring the period's cruelties and inequalities
- Characters who notice their own era as remarkable
```

## Continuity Rules

```
HISTORICAL FICTION CONTINUITY. WHAT TO TRACK

HISTORICAL ACCURACY:
- Dates of real events mentioned: verify against historical record
- Technology available: what exists and what doesn't at this specific date
- Social norms: what's acceptable, scandalous, illegal, or impossible
- Political context: who's in power, what laws apply, what conflicts are active
- Economic conditions: cost of things, currency, employment patterns

MATERIAL CULTURE:
- Clothing: what characters wear and how it changes (season, occasion, class)
- Food: what's available, what's seasonal, how it's prepared
- Transport: how characters get places and how long it takes
- Domestic items: lighting (candle, gas, electric?), heating, communication
- Technology: track what's been invented and what hasn't at THIS date

SOCIAL STATE:
- Class positions: rigid or fluid? Who can speak to whom?
- Gender constraints: what can women/men do, where can they go?
- Racial/ethnic dynamics: who has power, who's marginalised?
- Religious context: how does religion affect daily life?

GEOGRAPHICAL STATE:
- Place names: period-correct names (Constantinople vs. Istanbul, Bombay vs. Mumbai)
- Physical geography: buildings, streets, landmarks that exist at this date
- Political geography: borders, colonies, territories as they were THEN
- Travel times: realistic for the period's transport

LANGUAGE TRACKING:
- Period vocabulary established: ensure consistency
- Words NOT to use: modern terms that didn't exist yet
- Character speech patterns: maintain class/gender/regional differences
```

## Character Rules

```
HISTORICAL FICTION CHARACTER TYPES

THE PROTAGONIST:
- A person OF their time: shaped by their era's values, assumptions, and constraints
- Their desires are universal but their expression is period-specific
- They have agency WITHIN historical constraints (not unlimited freedom)
- Their moral framework is their own era's, not ours
- If they're progressive for their time, show WHY (education, experience, personality). not just because it makes them more sympathetic to modern readers

THE HISTORICAL FIGURE (if present):
- Research deeply: know more than you'll use
- Imagine their private self: what the historical record doesn't show
- They must feel human: flawed, contradictory, surprising
- Don't use them as mouthpieces for modern ideas
- What they don't know matters: historical figures didn't know what happened next

THE WITNESS:
- An ordinary person caught in extraordinary historical events
- Their perspective shows history from the ground level
- What they see is partial: they don't have the historian's overview
- Their survival matters more than their understanding

VOICE DIFFERENTIATION:
- Class: vocabulary, sentence structure, confidence, deference
- Gender: what each gender is permitted to say and how
- Region: dialect, accent, local knowledge
- Education: Latin phrases from the learned, practical language from workers
- Age: the young speak differently from the old in EVERY era
```

## Arc Rules

```
HISTORICAL FICTION STORY STRUCTURE

ACT 1: THE WORLD BEFORE (first 25%)
- Immerse the reader in the period through character and action
- Establish the protagonist's place: class, gender, occupation, community
- Show what's at stake personally and historically
- The historical context is felt, not explained
- END OF ACT 1: A historical event or personal crisis disrupts the equilibrium

ACT 2A: INTO HISTORY (to midpoint)
- Historical events press on personal lives
- The protagonist is tested by their era's specific challenges
- Research details deepen the world naturally
- Relationships develop under historical pressure
- MIDPOINT: History turns. a battle, a law, a revolution, a death. and everything changes

ACT 2B: THE COST (midpoint to dark moment)
- History exacts its price: war, famine, persecution, displacement
- The protagonist faces impossible choices shaped by their era
- Personal and historical stakes converge
- The period's cruelties are felt directly
- DARK MOMENT: The protagonist faces what their era demands and what they're willing to sacrifice

ACT 3: RESOLUTION (final 25%)
- The protagonist acts decisively within historical possibility
- The resolution is historically PLAUSIBLE (no magical solutions)
- Personal resolution and historical context align
- What history demanded and what the character chose
- The ending acknowledges what came next (the reader knows the future; the character doesn't)

HISTORICAL FICTION PACING:
- Earlier periods: slower pace, more descriptive, larger chapters
- Modern historical (20th century): faster pace, more dialogue
- Battle/crisis sequences: compressed, intense, sensory
- Domestic/social sequences: expanded, detailed, atmospheric
```

## Timeline Rules

```
HISTORICAL FICTION TIMELINE

HISTORICAL TIMELINE:
- Create a master timeline of real events that intersect with the story
- Track: what has happened, what's happening, what's about to happen historically
- The protagonist's timeline against the historical one
- Travel times: realistic for the period

SEASONAL TIMELINE:
- Agriculture, weather, and daylight hours matter more in historical settings
- Seasonal activities: harvest, hunting, social seasons, religious festivals
- Weather affects everything: travel, health, battle, mood

AGING AND DURATION:
- Historical lifespans were often shorter: track ages accurately
- Pregnancy, illness, and injury have different timelines in different periods
- Healing: no antibiotics before 1928; no anaesthesia before 1846
```

## Genre-Specific Craft Techniques

Historical fiction is the genre that depicts a past period with
research-grounded specificity, sitting adjacent to historical
romance (already covered separately), historical fantasy
(speculative-historical), historical crime (mystery-cross),
and biographical fiction (real-historical-figure register)
but with a distinct contract: the period itself, rendered
with material accuracy and lived texture, is the form's
primary commitment. The cluster includes literary historical
fiction (the form's prestige register), commercial historical
fiction (broader market), period-specific specialisations
(WWII fiction; ancient-world fiction; Civil War / War of
Independence fiction; medieval fiction; Tudor fiction;
Regency fiction at the literary edge; 20th-century
specialisations), regional historical (Latin American /
African / Asian / Indigenous historical traditions), and the
broader period-specific narrative range. Comp authors span
the canonical lineage (Hilary Mantel's *Wolf Hall* trilogy
on Cromwell, Pat Barker's *Regeneration* trilogy and
*Silence of the Girls*, Penelope Fitzgerald's quiet
historical work, William Boyd, Sebastian Faulks's
*Birdsong*, Bernard Cornwell's procedural-historical, Ken
Follett's *Pillars of the Earth*, Edward Rutherfurd, Michelle
Moran, Jean Plaidy, Mary Renault on the ancient-world
register, Robert Graves's *I, Claudius*, Marguerite
Yourcenar's *Memoirs of Hadrian*, Gore Vidal's American
historical sequence, Susan Sontag's *In America*, Tracy
Chevalier's *Girl with a Pearl Earring*) through the
contemporary expansion (Hilary Mantel continuing through
*The Mirror and the Light*, Maggie O'Farrell's *Hamnet* and
*The Marriage Portrait*, Anthony Doerr's *All the Light We
Cannot See*, Anthony Marra, Anthony Beevor (non-fiction-
adjacent), Geraldine Brooks's *People of the Book*, *March*,
*Caleb's Crossing*, *Year of Wonders*, Sarah Waters's
Victorian work, Andrew Miller's *Pure*, Eleanor Catton's
*The Luminaries*, James McBride, Brit Bennett, Yaa Gyasi's
*Homegoing*, Min Jin Lee's *Pachinko*, Ta-Nehisi Coates's
*The Water Dancer*, Esi Edugyan's *Washington Black*,
Hernan Diaz's *In the Distance* and *Trust*, Téa Obreht's
*Inland*, Lauren Groff's *Matrix* and *Vaster Wilds*,
Madeline Miller's *Circe* and *The Song of Achilles*,
Madeline Thien's *Do Not Say We Have Nothing*, Anuradha Roy,
Kamila Shamsie's *Home Fire*, Mohsin Hamid, Akwaeke Emezi,
Patrick deWitt's *Undermajordomo Minor*, Andrea Levy's
*Small Island* and *The Long Song*, Bernardine Evaristo on
historical-experimental edge, Jesmyn Ward's *Let Us
Descend*). The techniques below are how the form delivers
its core pleasures while avoiding the failure modes (tourist
register where characters notice their own era;
anachronistic-sensibility retrofit where contemporary moral
framework operates in period setting; research-as-info-dump
where the writer's research breaks scene; period-as-
costume-drama where the era's aesthetic appears without its
specific political and social texture).

### The Habituation Technique

Characters don't notice their own era:

```
WRONG (tourist):
"She gazed in wonder at the magnificent gas lamps that
lined the cobblestone street, marvelling at how they
cast their warm glow against the Victorian architecture."

RIGHT (inhabitant):
"The lamp on the corner was out again. She'd have to walk
the dark stretch past the chandler's, and she didn't fancy
it. not after what happened to Mrs. Prewitt last week."
```

### The Period Through the Body

History is physical:

```
The stays dug into her ribs. She'd been laced too tight.
Mary's fault, pulling when she should have held. and now
every breath was a negotiation. By four o'clock she'd
have the headache. By six she'd have loosened the laces
in the necessary and damn the silhouette.

The reader learns about corsets through WEARING one.
No info-dump needed.
```

### The Knowledge Gap

The character doesn't know what the reader knows:

```
"It'll be over by Christmas," he said, and she believed
him, because everyone did, because it was August 1914
and the world had not yet learned what it was capable of.

The reader knows. The character doesn't. The gap IS the emotion.
```

### Historical Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "those were different times" | Show the specific historical difference through daily life |
| "the weight of history" | Show the specific historical event's impact on this person |
| "the past came alive" | Show the specific sensory detail of the period |
| "the era was one of great change" | Show the specific change through one person's experience |
| "the customs of the time dictated" | Show the specific custom in action |
| "history would remember this day" | Show what the characters feel, not future importance |
| "the old world was passing away" | Show the specific institution or practice ending |
| "honour and duty above all" | Show the specific conflict between honour and desire |
| "the sights and sounds of [era]" | Show ONE specific sight or sound |
| "a world on the brink of change" | Show the specific tension between old and new |
| "the social order was rigid" | Show the specific rule and its specific enforcement |
| "in those days, women had no rights" | Show the specific legal or social constraint operating in this specific scene through the specific character's specific encounter |
| "the king's word was law" | Show the specific royal decision and its specific enforcement |
| "history was being made" | Cut; show the specific event without the meta-commentary on its historical significance |
| "war was on the horizon" | Show the specific signs the specific characters specifically register |
| "the smell of [period] hung in the air" | Cut "[period]"; render the specific smell from specific sources (specific food / fuel / industrial process / animal / sanitation reality of this specific place) |
| "she was bound by tradition" | Show the specific tradition operating in the specific decision the character is making |
| "the new century brought new ideas" | Cut; show one specific new idea encountering one specific character's resistance or reception |

### The Period-Specific Voice Calibration

Historical fiction requires a voice register that signals
period without descending into pastiche. The discipline:
the prose should evoke the period through rhythm, vocabulary,
sentence structure, and cultural reference without becoming
faux-period imitation. Generic literary English with
occasional "thee" and "forsooth" is the failure mode;
period-evocative-but-readable prose is the technique.

The calibration operates on multiple axes:

- **Sentence rhythm** — different periods favour different
  prose rhythms. 19th-century English literary prose
  operates with longer periodic sentences than 21st-century
  literary English; 18th-century pre-Romantic prose
  operates differently again; medieval-era prose (when
  rendered in modern English) operates with paratactic
  rather than hypotactic structure. The strongest
  historical fiction calibrates to the period's prose
  expectations without producing pastiche.
- **Vocabulary** — period-specific words used naturally
  rather than gestured at. The 1850s English domestic
  scene's specific vocabulary (the specific kinds of
  furniture, the specific kinds of fabric, the specific
  kinds of food, the specific household-management
  terminology) operates in scene; the writer who has
  researched well uses these words without explanation,
  trusting the reader to absorb meaning from context.
- **Cultural reference** — what characters reference. The
  18th-century French character references their cultural
  world (specific theatre, specific philosophical
  controversies, specific political figures, specific
  religious tensions); the 20th-century American character
  references theirs. Generic universal cultural reference
  is the failure mode; specific period-and-place-and-class
  cultural reference is the technique.
- **Modes of speech** — different periods used different
  registers for different social situations. Formal
  Victorian dinner-party speech operates differently from
  formal medieval-court speech operates differently from
  formal 1920s drawing-room speech. The strongest historical
  fiction renders these specific modes with specific
  attention to their specific operating logic.

The calibration fails in two directions. **Costume-drama
register** uses period flavour at the surface (occasional
"my dear" or "indeed") without the deeper rhythmic and
structural calibration. **Pastiche register** over-corrects
toward faux-period prose that no actual period speaker
would have used. The strongest historical fiction (Mantel
on Tudor period, Pat Barker on WWI period, Penelope
Fitzgerald across her range) operates in period-evocative
register that reads as readable contemporary literary prose
while bearing the specific period inflection.

Test: read three dialogue exchanges and three narrative
passages aloud. Do they evoke the period through specific
rhythm, vocabulary, and cultural reference? Or do they
deploy generic period-flavour without deeper calibration?

### The Researched-Specificity Discipline

Historical fiction's research demands are unusually high.
The form's reader includes serious history readers,
academic specialists in the chosen period, descendants of
the period's communities, and general readers with
specific historical knowledge. Research mistakes break the
spell faster than character or plot mistakes because they
signal the writer doesn't know the world they're writing
about.

The discipline operates on multiple axes:

- **Material culture** — specific objects, specific
  technologies, specific agricultural practices, specific
  manufacturing processes, specific transportation, specific
  food, specific clothing, specific architecture of the
  period. Generic period flavour ("she wore a long dress")
  is the failure mode; specific named items with period-
  specific accuracy ("she wore the sage-green wool dress
  Aunt Margaret had cut down for her in '03") is the
  technique.
- **Daily-life logistics** — how laundry actually got done;
  how food actually got cooked; how households actually
  managed money; how children actually got to school; how
  letters actually got delivered; how travellers actually
  travelled. The strongest historical fiction renders the
  specific logistics with attention; the failure mode is
  the manuscript that operates as if the period had
  contemporary infrastructure with cosmetic period detail
  on top.
- **Political and economic context** — specific political
  conditions of the chosen period. Who held power? What
  was contested? What were the specific economic forces?
  What was the specific institutional landscape? The
  specific class and racial and gender hierarchies and
  their specific operating logic? Generic "times were
  hard" is the failure mode; specific researched political
  and economic reality is the technique.
- **Linguistic accuracy** — the language of the period
  (when rendered in modern English, the specific
  inflections that signal period; when rendered in
  source language, the specific period-appropriate
  vocabulary). The OED first-attestation of any phrase
  the writer is uncertain about; verification that
  historical figures' actual speech patterns inform their
  rendered dialogue.
- **Geographical accuracy** — specific places existed
  where the manuscript places them; specific neighborhoods
  had specific characters; specific landmarks were where
  they were at the specific dates the manuscript depicts.

The discipline requires that research be visible at the
detail level without being visible at the structural
level. The reader should encounter the specific researched
detail in scene without recognising it as researched
material; the researched detail should operate as the
character's lived reality. Test: pick three significant
period-specific elements and verify each is researched
specifically against historical sources.

### The Decolonial-Period Reckoning

Historical fiction has a particular cultural concern:
many of the periods the form aestheticises (especially
the British / European / American imperial periods and
their colonial counterparts) involved specific violence,
exploitation, and erasure that the form has sometimes
elided. Contemporary historical fiction practice
acknowledges this without becoming didactic.

The technique requires that the manuscript's choices about
who appears, who has interiority, who has agency, and
whose perspective shapes the prose are deliberate. A
historical novel set in 1850s plantation South with no
characters of colour with interiority; a Tudor-period novel
that elides the Catholic / Protestant violence and the
specific deaths it required; a colonial-era Indian novel
told entirely from British perspectives — each has chosen,
by absence, to render the dominant-culture's view of the
period rather than the actual period.

Contemporary historical fiction's strongest practice
includes the period's actual political and demographic
complexity. Comp examples: Toni Morrison on antebellum and
postbellum America; James McBride on African American
historical experience; Ta-Nehisi Coates's *The Water
Dancer*; Andrea Levy's *The Long Song* and *Small Island*;
Geraldine Brooks's *March* on the Civil War from the
Marches' perspective; Yaa Gyasi's *Homegoing* on the slave
trade across centuries; Esi Edugyan's *Washington Black*;
Brit Bennett's *The Vanishing Half* on twentieth-century
American racial reality; Jesmyn Ward's *Let Us Descend* on
the slave trade; Marlon James's *The Book of Night Women*;
NoViolet Bulawayo's *Glory*; Mohsin Hamid's *The Last
White Man*; Madeline Miller's reframings of mythic-period
women's interiority; Akwaeke Emezi's range; Bernardine
Evaristo's historical-experimental work.

The technique extends to engagement rather than
acknowledgement. Including a historically-erased character
as a minor figure whose interior is never accessed is
gestural; the strongest contemporary historical fiction
gives historically-positioned characters full novelistic
interiority and agency. Test: identify the manuscript's
significant characters and audit demographic and political
composition. If the cast operates within dominant-culture
default for the chosen period, the inherited-erasure
register is operating. The fix is not tokenism — it is
the deliberate rendering of the actual period with its
actual people.

## Genre-Specific Revision Rules

Six revision passes specific to historical fiction, each with
a focused question, run cover-to-cover before the next begins.
Historical revision must hold the form's signature contracts:
accuracy (dates, events, technology, social norms);
immersion (period felt through sensory detail); anachronism
discipline (no modern intrusions); research visibility
(iceberg principle maintained); agency (protagonist operating
within historical constraints); and the period-voice
calibration + decolonial-reckoning audits that distinguish
craft historical fiction from costume-drama register. The
passes below are ordered to surface accuracy and immersion
failures first (the form's most-felt by genre readers),
anachronism and research audits next, agency and integrative
audits last.

### Pass 1: Accuracy Check

Verify all dates, events, and historical details are correct.
Build a fact ledger during revision: every checkable claim
in the manuscript with its source and reliability assessment.
The historical-fiction reader includes academics, period
specialists, and serious history readers who detect
inaccuracies immediately and lose confidence in the rest of
the book.

Verify technology is appropriate for the specific year. The
form's most-flagged failure mode is anachronistic technology:
the morning coffee that arrived in England decades before
the heroine's birth; the locomotive that does not yet exist
in the year of the scene; the telephone reference that pre-
dates the technology's availability in the specific
location; the specific rifle model that did not exist at the
specific date depicted. Period research must be specific to
year, not to era — the 1840s differ materially from the
1880s differ from the 1910s.

Verify social norms are period-accurate. Specific class,
gender, racial, religious, and political constraints
operating in the specific period. The 1850s Boston upper-
middle-class household operates by different norms than the
1930s Boston upper-middle-class household; the manuscript
should know which period it depicts and render the period's
specific norms. Generic "Victorian propriety" is the failure
mode; specific researched norms are the technique.

The pass also catches the related failure mode: anachronistic
psychology. Period characters experiencing emotions in
contemporary therapeutic vocabulary; period characters
reasoning about their world in contemporary moral framework;
period characters anticipating contemporary political
positions without specific reasons. These are emotional
anachronisms; the Period Psychology Check from historical-
romance.md applies here too.

### Pass 2: Immersion Check

Verify the period is felt through sensory detail rather than
explained. The Habituation Technique is the form's signature
craft requirement: characters inhabit their era rather than
tour it. The protagonist who notices Victorian gas lamps as
exotic detail has been written as tourist; the protagonist
who notices that one specific lamp is out and complains
about the dark stretch past the chandler's has been written
as inhabitant. Read the manuscript and flag any moment
where the prose treats period detail as remarkable to the
character.

Verify material culture details are specific and accurate.
The Researched-Specificity Discipline technique requires
specific named items with period-specific accuracy. Generic
"she wore a long dress" is the failure mode; specific
material with specific provenance ("she wore the sage-green
wool dress Aunt Margaret had cut down for her in '03") is
the technique. Audit the manuscript for material-culture
specificity.

Verify the character inhabits their era, not tours it.
Test: pick three significant scenes and ask whether the
character's interior register treats period detail as their
ordinary experience or as exotic novelty. If exotic, the
habituation is failing; if ordinary, the technique is
operating.

The Period Through the Body technique is the related
discipline: history is rendered physically. The corset's
specific constraint operating across the day; the
horseback travel's specific bodily cost; the specific
quality of the specific period light and the specific
quality of unrefrigerated food in summer and the specific
quality of pre-electric darkness. Verify the manuscript
renders these embodied period realities rather than
gesturing at them.

### Pass 3: Anachronism Check

Scan for modern words or phrases. Flag and replace. The
historical-fiction reader detects anachronistic vocabulary
immediately. Search specifically for:

- **Linguistic anachronisms** — words and phrases whose first
  attested use postdates the period. Use the OED first-
  attestation date for any phrase that gives the slightest
  pause. Common categories: business/finance metaphors that
  did not exist; sports vocabulary that postdates the era;
  therapeutic language; "no problem", "got it", "I'm fine",
  "okay" all of which are 20th-century constructions.
- **Material anachronisms** — objects, foods, drinks, fabrics,
  tools, weapons, transportation, medicines, technologies
  that did not yet exist or had not yet reached the
  location.
- **Conceptual anachronisms** — categories of thought that
  did not exist in the period. "Teenager" (1944),
  "homosexuality as identity" (late 19th century), "the
  unconscious" (post-Freud), "the economy" as discrete
  domain (19th century), "race" as biology (18th-19th
  century formalisation), "boundaries" as therapeutic
  concept (late 20th century), "trauma" as named psychiatric
  category in current sense (mid-20th century).
- **Emotional anachronisms** — period characters with
  contemporary therapeutic vocabulary, contemporary
  feminist consciousness, contemporary attitudes toward
  class/race/sexuality without period-appropriate framing.
- **Institutional anachronisms** — schools, hospitals,
  banks, professions, legal frameworks (divorce, custody,
  inheritance, women's property, voting rights) that did
  not yet exist in their depicted forms.

Verify any technology or objects that don't exist yet are
absent. The Period Authenticity Discipline from historical-
romance.md applies: every checkable detail verified
against period sources.

### Pass 4: Research Visibility Check

Verify research is not visible as info-dump anywhere. The
historical-fiction reader's tolerance for exposition is
finite — typically about half a page in concentrated form
before attention fragments. Every piece of period detail
must arrive through character experience: the protagonist
encountering, navigating, struggling with, or being changed
by the period detail rather than having it explained.

Scan specifically for:

- **"As you know" dialogue** — period characters explaining
  to other period characters what both already know, for the
  reader's benefit
- **Encyclopedia paragraphs** — the prose's voice shifting
  into encyclopedia register to deliver historical
  information the writer wanted on the page
- **POV-character interior monologue used as exposition
  vehicle** — the protagonist suddenly recalling, in the
  middle of a tense moment, the entire history of the war
  for the reader's benefit
- **Narrator-as-historian paragraphs** — the narrator
  pausing to explain period context that the character
  themselves would not have articulated

Verify the iceberg principle is maintained. The reader needs
the surface (enough to follow the plot, feel the stakes,
trust the world); the reader does not need the iceberg (the
writer's full systems document on the period). The strongest
historical practitioners (Mantel, Pat Barker, Penelope
Fitzgerald, Maggie O'Farrell) embed historical material so
thoroughly into character experience that the reader
absorbs the period without ever feeling they were taught
it.

Verify the narrator does not explain things the character
would take for granted. The 1850s domestic scene's
character would not pause to explain how the kitchen range
works; the 1920s office scene's character would not pause
to explain typewriting. Where the narrator explains
period mechanics, the manuscript has slipped into tourist
register.

### Pass 5: Agency Check

Verify the protagonist has agency within historical
constraints. Historical fiction's character craft requires
characters to operate within their period's actual
constraints rather than transcending them. The protagonist
who behaves as if they have contemporary autonomy in a
period that didn't permit it has been written
anachronistically; the protagonist whose choices operate
within specific period constraints — choosing which path
within available paths — operates within the form.

Verify constraints are real, not artificially imposed or
removed. Period constraints should match the actual period:
the actual legal limits on what women could own / inherit /
bequeath in the specific period; the actual social
consequences of specific choices in the specific community;
the actual economic conditions shaping the specific class
position. Generic "the times were difficult" is the failure
mode; specific researched constraint with specific operating
logic is the technique.

Verify the character's choice matters against the historical
backdrop. Historical fiction's signature emotional register
holds the individual's specific choices against the larger
historical forces, with the choice mattering precisely
because the historical forces are larger. Manuscripts where
the character's agency seems to operate independently of
historical context have lost the form's signature texture;
manuscripts where the character's specific choices are
visibly constrained by and affecting the historical reality
operate within the form.

### Pass 6: Period-Voice + Decolonial-Reckoning Integration Audit

Run a final integrative pass on the manuscript's period
voice and political reckoning. Two related sub-audits:

**Period-voice calibration.** The Period-Specific Voice
Calibration technique provides the audit framework: sentence
rhythm, vocabulary, cultural reference, modes of speech, all
calibrated to the specific period without descending into
pastiche. Audit the manuscript: does the prose evoke the
period through deeper rhythmic and structural calibration,
or does it deploy surface period-flavour without the deeper
calibration? Costume-drama register is the failure mode at
one end; pastiche register is the failure mode at the
other; period-evocative-but-readable prose is the form's
signature.

**Decolonial reckoning.** The Decolonial-Period Reckoning
technique addresses contemporary historical fiction's
relationship to the periods it aestheticises. Audit: does
the manuscript engage with the period's actual political
and demographic reality, or does it render a dominant-
culture's view? Are characters from historically-erased
groups (people of colour, working-class characters,
colonial subjects, women in periods that constrained
them, religious minorities, sexual minorities where
applicable) present and rendered with full novelistic
depth? Or has the manuscript defaulted to the period's
dominant-culture viewpoint?

Comp examples for contemporary practice: Toni Morrison,
James McBride, Ta-Nehisi Coates, Andrea Levy, Geraldine
Brooks's *March*, Yaa Gyasi, Esi Edugyan, Brit Bennett,
Jesmyn Ward, Marlon James, NoViolet Bulawayo, Mohsin Hamid,
Madeline Miller's reframings, Akwaeke Emezi, Bernardine
Evaristo. The pass is not asking the manuscript to be
didactic about historical injustice; it is asking the
manuscript to know what it is doing — to make deliberate
choices about what to include, what to acknowledge, and
what to render rather than defaulting to inherited
historical-fiction conventions.

Test: identify three demographic / political / historical
choices in the manuscript and ask, for each, whether the
choice was deliberate and whether the rendering operates
with depth or with default. If choices are default and
renderings are stereotypical, the inherited-default register
is operating; if choices are deliberate and renderings are
specific, the form's contemporary practice is being
honoured.

## Names & Patterns to Avoid

### Historical Fiction Character Names. NEVER USE
- Modern names in historical settings (no "Jayden" in 1850s England)
- Famous historical names for fictional characters (no "Elizabeth" in Tudor England unless she IS Elizabeth)
- Names that didn't exist in the period/culture

### Historical Fiction. NEVER DO
- Open with a date and location in italics like a history textbook ("London, 1888")
- Have characters explain their own era to each other
- Use modern idioms in dialogue
- Make the protagonist a proto-modern person who shares all our values
- Ignore the ugly parts of history (slavery, colonialism, misogyny)

### Use Instead
- Research period naming conventions: parish records, census data, naming dictionaries
- Names appropriate to class, region, religion, and era
- The name should ground the character in their time and place

## Comp Titles

Historical fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *War and Peace* — Leo Tolstoy (1869): the literary-historical-fiction foundation.
- *Wolf Hall* — Hilary Mantel (2009): the modern literary-historical benchmark.
- *The Remains of the Day* — Kazuo Ishiguro (1989): literary-historical interiority benchmark.
- *Beloved* — Toni Morrison (1987): post-slavery historical-literary masterpiece.
- *Cold Mountain* — Charles Frazier (1997): literary Civil-War historical benchmark.

### Contemporary (current best-in-class)

- *Hamnet* — Maggie O'Farrell (2020): contemporary literary historical benchmark.
- *The Marriage Portrait* — Maggie O'Farrell (2022): Renaissance-Italy literary historical.
- *The Underground Railroad* — Colson Whitehead (2016): historical-with-magical-realism literary.
- *Lessons in Chemistry* — Bonnie Garmus (2022): mid-century historical commercial-literary.
- *The Marrow Thieves* — Cherie Dimaline (2017): post-historical Indigenous literary.
- *Pachinko* — Min Jin Lee (2017): Korean-Japanese multi-generation historical.
- *The Books of Jacob* — Olga Tokarczuk (2014, English 2021): Eastern-European literary historical.
- *Trust* — Hernan Diaz (2022): metafictional historical literary; Pulitzer-winning.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Grand, atmospheric imagery evoking the period: landscapes, architecture, figures in period dress; epic scope, immersive mood
- **Painterly**. Art that evokes the period's own visual culture: oil painting style for Renaissance, watercolour for Regency, photography for 20th century
- **Textural**. Period-appropriate textures and materials: aged paper, worn leather, faded fabric; the cover FEELS old
- **Typographic**. Period-appropriate typography as the primary element: the font choice signals the era

### Genre Cover Aesthetics
- **Styles:** Period architecture and landscapes, figures in historically accurate dress, objects of the era (maps, letters, tools, weapons), dramatic historical moments suggested rather than depicted, painterly or photographic depending on the era
- **Colours:** Period-appropriate palettes: sepia and earth tones for older periods, muted colours for wartime, rich colours for aristocratic settings; the colour palette should FEEL like the era
- **Elements:** Maps, letters, period objects, architectural details, silhouettes in period dress, historical landscapes, period-appropriate artwork
- **Typography:** Period-appropriate font choices: blackletter for medieval, serif for Georgian/Victorian, art deco for 1920s-30s; the font signals the era before the reader opens the book

### Market Positioning
Historical fiction covers must signal "immersive period experience" through atmospheric imagery and period-appropriate design. Position against Mantel, Hicks, Quinn, Follett, Gabaldon. The era should be immediately identifiable from the cover design. At thumbnail size, one clear period element (architecture, dress, landscape) creates instant recognition.

### Cover Design DON'Ts
- No anachronistic elements (modern fonts on a medieval story)
- No costumey, Halloween-quality period dress
- No generic landscapes that could be any era
- No overcrowded compositions trying to show everything
- No modern, minimalist design that strips away the period feel
- No inaccurate period details on the cover (wrong clothing, wrong architecture)
