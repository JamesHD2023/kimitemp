---
name: plottr-import
description: "Import a Plottr project — beats, characters, places, subplots, and timeline become a complete Story Bible ready for chapter generation"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the user-facing skill. The technical implementation protocol lives in `plottr-importer.md` (same folder) — loaded by reference once the user triggers an import.


> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with `> **Powered by Ideorix** — The Manuscript & Screen Engine` before any other output.

# Plottr Import

Bring your Plottr outline straight into Ideorix. The importer parses your
beats, characters, places, subplots, and timeline, then builds a complete
Story Bible ready to feed into chapter generation. Unlike importing a
manuscript (Novelcrafter, Scrivener), Plottr is OUTLINE-ONLY — there are
no chapters yet, only the structural blueprint. The importer skips
straight to Story Bible review and hands off to chapter generation as
soon as you approve it.

## What it does

| Task | What happens |
|------|-------------|
| **Beats → chapter outline** | Main Plot beats become Section 12 (Chapter Outline). The engine groups them into chapters using your chosen length tier (3-5 beats per chapter). |
| **Storylines → subplots** | Non-Main-Plot tracks (e.g. "Teens", "Killer") become Story Bible Section 7 subplot tracks. |
| **Template tracks → beat structure** | Plottr beat sheet templates (Save the Cat, Hero's Journey, etc.) populate Section 13 (Beat Structure). |
| **Characters → cast** | Each character becomes a full Section 2 entry — name, aliases (from Nickname), description, traits derived from age/job/habits/goals/fears. |
| **Alias preservation** | Your character nicknames (with parenthetical context) flow through to the Continuity Guardian and Prose Humaniser. |
| **Places → locations** | Each Plottr place becomes a Section 5 location entry. |
| **Day headers → timeline** | Plottr's day-grouped timeline becomes Story Bible Section 11. |
| **Reduced Phase 1 setup** | Skips outline source, beat structure, and Chekhov gun questions (already provided). Only asks for what Plottr doesn't record: genre, dialect, length tier, POV, voice, pen name. |
| **Hand off to Story Bible review** | The assembled Story Bible is presented for approval. Once approved, you proceed to chapter generation with the full Outline Conformance Agent in place. |

## How to start

Say any of:
- "Import from Plottr"
- "Import my Plottr project"
- "Bring my Plottr outline across"
- "Plottr import"
- "I have a Plottr project"
- "I planned my book in Plottr"

Or pick **Import Project** from the Writers Studio or Full Creative Suite
menu, then choose **Plottr** as the source.

## How to prepare your Plottr export

Before running the importer:

1. Open your project in Plottr
2. **File → Export → Word document**
3. Tick the defaults (Outline, Characters, Places, Notes)
4. Save the resulting `.docx` file
5. Place the `.docx` in `~/Documents/Ideorix-Projects/imports/` (the
   importer finds it automatically) or have the full file path ready

**Why Word export and not the native `.pltr` JSON format?** The Word
export is stable across all Plottr versions and subscription tiers,
human-readable, and uses predictable markers that make parsing rock-solid.
The `.pltr` JSON schema has changed across major Plottr releases — Word
export is the more robust target.

## What gets imported

From a Plottr Word export, the importer brings across:

- **Outline beats** — every beat in every storyline, in chronological order, with summaries
- **Storyline tracks** — Main Plot becomes the chapter spine; everything else (subplots) becomes Section 7
- **Beat sheet templates** — Save the Cat, Hero's Journey, Cozy Mystery, etc. — populated as the project's beat structure
- **Characters** — name, nicknames (with parenthetical context preserved as aliases), description, category, age, gender, race, appearance, religion, education, job title, habits, goals, fears
- **Places** — name, description, category, notes, custom fields
- **Day-grouped timeline** — preserved as Section 11
- **Book title** — pulled from the Plottr file name

## What is NOT imported

- **Plottr template instructional content** — the "What does your protagonist want?" boilerplate Plottr pastes into template beats is automatically stripped (everything below `--- Add Your Details Above this Line ---` is recognised and removed)
- **Embedded character images** — Plottr character thumbnails are not used by Ideorix
- **Custom Plottr tags and labels** — v1 ignores them; v2 will support them
- **Multi-book Plottr projects** — currently imports one book at a time; v2 will handle series
- **Manuscript prose** — Plottr doesn't store prose, only structure. To import a written manuscript, use Novelcrafter or Scrivener import instead.

## What Ideorix will ask you after import

Plottr doesn't record certain things Ideorix needs for its agent pipeline.
After the import completes, you'll be asked for:

1. **Genre** — controls which genre plugin loads (craft rules, tropes, quality checks)
2. **Dialect** — US or GB English
3. **Length tier** — controls the chapter grouping heuristic (how many beats per chapter)
4. **POV preference** — first / third close / omniscient / mixed
5. **Voice** — attach an existing voice profile, build one now, or skip
6. **Pen name** — attach an existing pen name, create one, or skip
7. **Romance subplot? Heat level? Tropes?** — standard Phase 1 questions

Skipped (Plottr already provides the answer):
- Outline source — Plottr is the outline
- Beat structure — template tracks already detected
- Chekhov's guns — asked separately during Story Bible review

## What you get back

A fully populated Ideorix project workspace ready for chapter generation:

```
~/Documents/Ideorix-Projects/{Your Title}/
├── project-config.md              Project metadata + setup answers
├── manuscript/                    (empty — chapters generated next)
├── engine-data/
│   ├── story-bible.md             Full Story Bible from Plottr data
│   ├── entities/
│   │   ├── characters.md          Character bios with aliases
│   │   └── places.md              Location entries
│   ├── outline.md                 Section 12 chapter outline
│   ├── beat-structure.md          Section 13 template tracks
│   ├── trope-plan.md              Tropes you confirmed during setup
│   └── imports/
│       └── plottr-export/         Original .docx (kept for reference)
├── marketing/
└── ...
```

From there you go straight into Phase 3 (chapter generation) with the
Outline Conformance Agent watching every brief against the chapter
outline you imported from Plottr. No setup phase to slog through —
Plottr already did the structural work.

## Why this is uniquely valuable

Plottr users plan their books carefully. They invest hours in beats,
character bios, and timelines. With this importer, that planning work
isn't wasted — it becomes the **canonical Story Bible** that the Outline
Conformance Agent uses to keep every chapter on plan. The chain:

> **Plot in Plottr → Import to Ideorix → Write with the Outline Conformance Agent enforcing your plan → Manuscript that delivers what you planned.**

That workflow doesn't exist anywhere else.

> Protocol: `plottr-importer.md`
