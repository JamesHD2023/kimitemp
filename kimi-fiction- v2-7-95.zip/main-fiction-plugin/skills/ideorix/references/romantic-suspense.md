---
name: romantic-suspense-genre
description: Genre-specific instructions for romantic suspense fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Romantic Suspense. Genre Plugin

## Metadata
- id: romantic-suspense
- name: Romantic Suspense
- icon: 🔐
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Romancing the Beat", "Thriller 12-Beat Structure", "Three-Act Structure", "Save the Cat"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Witness Protection Romance | Protagonist hidden from danger falls for their protector or a local | Isolation creates forced proximity; the false identity adds layers of deception and vulnerability |
| Serial Killer Hunt Romance | Two investigators or an investigator and civilian drawn together whilst hunting a killer | The escalating body count creates urgency; shared trauma bonds the couple |
| Cold Case Romance | Reopening an old case brings together two people with connections to the original crime | The past and present interweave; secrets from years ago threaten the present relationship |
| Bodyguard Romance | Professional protector falls for the person they are guarding | The professional boundary is the primary obstacle; duty vs desire drives every scene |
| Undercover Romance | One partner's secret identity threatens to destroy the genuine love that develops | The lie at the heart of the relationship creates unbearable dramatic irony |
| Stalker Suspense Romance | A threatening pursuer forces the protagonist into proximity with a protector or ally | Fear is constant; trust becomes the most romantic act possible |

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-5,000 words
- Pacing: Romance-driven with suspense punctuation: emotional scenes are the backbone, danger scenes are the accelerant
- Must open with: Romantic tension under threat, dangerous meet-cute, or emotional vulnerability exposed by peril
- Must close with: Intimacy deepened through shared danger, trust tested, new threat raising romantic stakes, or cliffhanger that endangers the relationship

BEATS PER CHAPTER
1. Romance Moment: Chemistry, vulnerability, emotional connection. relationship MUST advance every chapter
2. Danger Escalation: Threat increases, new evidence surfaces, antagonist moves closer. but filtered through romantic lens
3. Trust Building: Characters rely on each other, share secrets, lower walls BECAUSE danger demands vulnerability
4. Investigation/Clue: Plot progression. evidence discovered, suspect identified, pattern recognized. often during intimate moments
5. Vulnerability Window: Danger strips pretense. characters reveal true selves when survival is at stake

DUAL-PLOT ARCHITECTURE
- Romance is the A-plot (60-65% of page time). Suspense is the B-plot (35-40%)
- Every suspense beat must advance the romance: danger forces proximity, reveals character, tests trust
- Every romance beat must raise suspense stakes: falling in love gives the villain leverage, creates new targets
- The plots are BRAIDED, not alternating: never a pure suspense chapter or pure romance chapter
- Suspense creates the REASON characters cannot walk away from each other
- Romance creates the REASON the danger feels personal and terrifying

GENRE-SPECIFIC REQUIREMENTS
- HEA/HFN mandatory: couple together and committed at the end, threat neutralized
- Dual POV strongly preferred: both romantic leads' inner worlds shown
- Suspense forces intimacy: safe houses, protection details, going into hiding together
- Danger escalates romantic stakes: what they have to lose grows as they fall deeper
- Heroine (or second lead) must have agency: not merely a victim to be rescued
- Both leads contribute to solving the threat: competence is attractive
- Sexual tension heightened by adrenaline: fear and desire share neurochemistry
- Trust is the bridge between both plots: earned through danger, tested by secrets
- The villain threatens BOTH the relationship and physical safety
- Secrets between leads create dual tension: romantic misunderstanding AND suspense misdirection

FORBIDDEN
- Suspense overshadowing romance: if readers forget about the couple during action scenes, balance is wrong
- Romance pausing for action: relationship must progress DURING danger, not between danger
- Gratuitous violence or gore: violence serves emotional stakes, not shock value
- Too Stupid To Live heroine: characters make reasonable choices; bad outcomes come from smart plans gone wrong
- The competent hero solving everything alone while the love interest watches
- Romantic conflict that could be solved by a single honest conversation
- Villain existing only as plot device: antagonist needs clear motivation
- Love interest as the secret villain (unless extraordinarily well-executed with foreshadowing)
- Danger that never feels genuinely threatening: stakes must be real
- Resolving the romance before the suspense or vice versa: both must climax together
- Default romantic suspense leads: no cookie-cutter traumatized heroine and stoic protector without depth beyond those roles

OBSTACLE LAYERING (critical for romantic suspense):
A romantic suspense story needs MULTIPLE obstacles layered simultaneously. the external danger is the framework, but internal obstacles are the emotional engine. Fear of vulnerability after past betrayal, trust issues magnified by the dangerous circumstances, self-sabotage dressed as self-protection, the terror of needing someone when needing someone has always led to pain. The suspense provides the external pressure; the internal wounds provide the romantic tension. Each new obstacle should make the reader YEARN more desperately for the couple to find their way to each other. and fear more acutely that they won't.

LIGHT AND SHADE:
Even romantic suspense needs emotional contrast. If a chapter ends in terrifying danger, the next should offer an unexpected moment of tenderness, humor, or connection in the aftermath. If the couple shares a moment of genuine intimacy, follow it with a suspense beat that reminds them. and the reader. that safety is an illusion. This contrast amplifies both the romance and the fear. Two suspense-heavy scenes back to back numb the reader; danger followed by a moment of surprising warmth makes both register at full force.

ANTI-STEREOTYPE IMPERATIVE:
The best romantic suspense features specific, surprising, REAL people. not the standard bodyguard-and-victim archetypes. Your protector can be uncertain, your person-in-danger can be the emotionally braver one, your leads can be ordinary, complicated, and surprising. Avoid the default strong-silent-type hero and the feisty-but-vulnerable heroine. those are starting points, not characters. The romance should emerge from who these specific people are, not from the roles the suspense assigns them.

THE ETERNAL TRIANGLE:
Love triangles are one of the most powerful forces in romantic suspense. and the most versatile. A love triangle isn't just romantic complication; it's a structural device that creates motivation, misdirection, and emotional complexity simultaneously:
- The romance must never overshadow the suspense, but love is a most powerful force and can motivate people to act in the most extraordinary ways. A love triangle provides that motivation naturally
- One kind of triangle provides the entire motivation for the crime: jealousy, obsession, possession. Another kind distracts from the real motive altogether, so that readers are looking at romantic entanglements while the actual reason for the danger hides in plain sight
- Overlapping triangles multiply complexity: A pines for B, who is chased by C, who in turn is loved by D: each connection creating new motives, new suspects, new emotional stakes
- The triangle must serve BOTH plots. Romantic jealousy should also be a potential motive for violence. Suspicion of a romantic rival should also be suspicion of a more dangerous kind
- When well-constructed, the triangle's romantic tensions quite nicely distract from the real motivation for the threat: which is the best kind of misdirection

SETTING AS CRUCIBLE:
The best romantic suspense settings force unlikely people together under circumstances that demand both intimacy and vigilance:
- Holiday resorts, luxury hotels, cruise ships, isolated retreats: places where strangers who would never meet in ordinary life eat and sleep under one roof. Fate forces them to talk to one another, which makes your job easier
- These settings naturally cross social boundaries: a security consultant makes small talk with an art dealer, a prosecutor shares a dining table with a journalist. These pairings create the variety your suspect pool needs AND the unlikely romantic chemistry your love story demands
- Closed settings serve both plots: they limit who could have committed any crime (the killer must be among the guests) AND they force the romantic leads into proximity they can't escape
- The atmosphere of the setting should enhance both the romance and the suspense. A remote island is both paradise and prison. A mountain lodge is both cozy and claustrophobic. A rain-lashed safe house is both threatening and intimate
- Travel settings add dimension: crossing international borders introduces different ideas about justice, different cultural expectations, different kinds of danger. A journey creates natural act breaks as the setting itself changes
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (peril) + Affection (bond) — twin engines, alternating per scene; Stimulation at peril set-pieces.

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-agent.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE
- POV: Dual 3rd limited strongly preferred (both romantic leads); alternating 1st person acceptable
- Tense: Past tense (genre standard for both romance and suspense traditions)
- Voice: Emotionally intimate with an undercurrent of tension: warmth laced with unease, desire shadowed by fear
- Reading level: Adult: emotional complexity, mature themes, intimate content, violence appropriate to threat level

PROSE IMPERATIVES
- Emotional interiority is DEEP: readers must feel every flutter of attraction and spike of fear from inside the character
- Suspense scenes filtered through romantic lens: "She checked the locks not for herself, but because he was asleep on her couch, trusting her"
- Physical chemistry heightened by danger: adrenaline makes every touch electric, every glance weighted
- Fear and desire use the same body language: racing heart, heightened senses, hyperawareness of the other person
- Internal monologue reveals the push-pull: wanting closeness vs. fear of vulnerability, needing to trust vs. instinct to self-protect
- Show competence as attractive: watching your love interest handle a crisis IS foreplay in this genre
- Vulnerability after danger is where the deepest romance lives: the quiet moments after the storm

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- DUAL tension from page one: danger AND attraction both active in the opening scene
- Tension floor: 7 (inherits thriller Ch 1 gate: suspense must grip immediately)
- Open mid-situation: a threat unfolding, a charged first encounter, or both simultaneously
- Dialogue density: 40%+: rapid exchanges establish both competence and chemistry

Danger scenes (prose rhythm):
- Short, urgent sentences: 8-15 words during active threat: fragments permitted
- Sensory detail sharp and tactical: exits, distances, sounds, the specific quality of fear
- When romance intrudes during danger, sentences alternate rhythm: short threat/medium breathless awareness
- Interiority budget: 25% in danger (awareness of the other person WITHIN tactical assessment)

Romance scenes (prose rhythm):
- Medium sentences: breath returns, observation deepens, the body's hypervigilance re-channels into awareness of the other person
- Longer paragraphs for emotional landing after danger: the transition from survival to feeling
- Interiority budget: 45%: the push-pull of wanting closeness vs. self-protection

Climax/resolution prose rhythm:
- Dual climax (threat + relationship): sentences compress as both crises peak simultaneously
- Resolution earns its length: longer, warmer prose as safety arrives and emotional truth surfaces
- Final beat: the quiet after the storm: trust earned, bodies close, danger past but the bond permanent

TENSION-TO-TENDERNESS TRANSITIONS
- After action scenes, ALWAYS include an emotional landing: characters process danger through the lens of what they almost lost
- Adrenaline crash leads to emotional honesty: walls come down when survival strips away pretense
- Physical comfort after danger (tending wounds, holding each other, checking for injury) is deeply intimate
- The transition should feel organic: fear metabolizes into relief, relief into awareness of the other body, awareness into desire
- Never jump-cut from gunfire to sex: earn the emotional bridge between them
- Post-danger vulnerability is where "I almost lost you" becomes "I can't lose you": track this escalation

SENSORY WRITING: FEAR AND DESIRE
- Fear: cold sweat, tunnel vision, metallic taste, stomach dropping, hypervigilance, time distortion
- Desire: warmth pooling, skin prickling with awareness, breath catching, gravitational pull toward the other person
- OVERLAP them: "Her heart hammered: from the footsteps in the hallway or from his hand on her waist, she couldn't tell anymore"
- Environment carries both moods: rain as both ominous and romantic, darkness as both threatening and intimate
- Scent is powerful in both registers: gunpowder and cologne, blood and perfume, fear-sweat and clean skin

POV DISCIPLINE
- Each POV chapter should reveal something the other character cannot know: a secret, a fear, a growing feeling
- Hero's POV shows protective instincts warring with respect for heroine's autonomy
- Heroine's POV shows attraction complicated by the need to remain alert, trust issues, independence
- Switch POV at moments of maximum tension: leave one character in danger, shift to the other's desperate response
- Internal thoughts during danger reveal priorities: thinking of the love interest when you should be thinking of survival

DIALOGUE UNDER STRESS
- Banter persists even in danger: humor as coping mechanism reveals character and builds chemistry
- Arguments during crisis expose real feelings: "Why do you CARE what happens to me?" is a love confession in this genre
- Interrogation-style conversations do double duty: gathering clues AND revealing attraction through body language
- Whispered conversations in hiding are inherently intimate: forced quiet, close proximity, shared breath
- Characters reveal more under stress than they intend: danger is truth serum
- Professional dialogue (cop talk, investigation jargon) contrasted with tender private moments shows range

FORBIDDEN WORDS/PHRASES
- "She didn't know why she trusted him": SHOW the evidence that builds trust
- "Despite everything, she felt safe": show what creates safety, don't summarize it
- "He vowed to protect her": show protection through action, not internal oath
- Purple prose for violence: keep danger visceral, not poetic
- "Chemistry" stated outright: demonstrate it through reaction and interaction
- Telling fear instead of showing it: "She was terrified" vs. showing the terror through physical response
- Generic thriller language that could exist in any non-romance suspense: every line should feel like THIS couple's story

INTIMATE SCENES IN CONTEXT OF DANGER
- Sex and intimacy heightened by mortality awareness: "we might not survive tomorrow" urgency
- Consent remains essential even in heightened circumstances: especially in heightened circumstances
- Intimate moments as emotional release from sustained tension: catharsis through connection
- The setting carries suspense atmosphere even during romance: locked safe house, rain against windows, gun on the nightstand
- Vulnerability in intimacy mirrors vulnerability in danger: same courage required for both

INTIMATE SCENES. CHARACTER REVELATION:
- Intimate scenes must illuminate something about these specific characters and their relationship: what does physical closeness reveal about trust, about the power dynamic, about what each person fears and needs?
- Awkwardness and imperfection make intimacy more authentic than choreographed perfection: especially under duress. The trembling hand, the nervous laugh, the moment someone is braver than they expected to be
- Post-intimacy vulnerability is critical in romantic suspense: the emotional exposure AFTER the physical act mirrors the vulnerability of being in danger. Track how characters respond: do they retreat to safety? Reach for closeness? Pretend it didn't matter?

METHOD WRITING. EMOTIONAL IMMERSION:
- Identify what you want the reader to FEEL before writing any key scene: dread? desperate tenderness? the exquisite agony of falling in love when safety isn't guaranteed?
- If you aren't feeling the emotion as you write it, the reader won't feel it either: that's the signal to go deeper
- Write through ALL senses: the exact quality of a safe house at night, the specific texture of fear transforming into desire, how hypervigilance sharpens awareness of another person's body
- Never manufacture danger purely for shock or a romantic crisis purely for drama. The emotion must serve the characters' truth

DIALOGUE. THE POWER OF THE UNSAID:
- What characters DON'T say carries enormous weight: the gap between what is felt and what is spoken IS the tension in romantic suspense
- Characters under threat rarely say what they mean: they deflect with competence, hide behind professionalism, express love through tactical decisions. "Stay behind me" means "I can't lose you." Holding back gives devastating resonance to the moment someone finally speaks their truth
- Each character must speak distinctly: their verbal patterns under stress, their specific deflections, their way of expressing care without admitting it should be as individual as a fingerprint

THEME BENEATH THE LOVE STORY:
Every strong romantic suspense has a THEME. what the story is really about beneath the danger and the falling-in-love. Is it about learning to trust after betrayal? About the courage required for both love and survival? About what we're willing to risk for the people we care about? Theme feeds into voice and plot, adds a dimension that stays with the reader. When the suspense fades and the HEA settles, it is the theme that lingers.
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Romance-suspense balance. romance is the primary genre (60-65% of emotional real estate), suspense deepens the relationship rather than distracting from it
2. HEA/HFN delivery. couple together and committed by end, threat neutralized, resolution earned through trust built under shared danger
3. Romance arc completeness. chemistry established early and escalates consistently, emotional progression from attraction through vulnerability to love and commitment
4. Suspense tension. threat credible and escalating, antagonist with clear motivation, clues and red herrings planted fairly
5. Emotional depth. internal monologue rich and character-specific, fear and desire intertwined, vulnerability after danger present and authentic

GENRE-SPECIFIC CHECKS

Both plots progress in every chapter. no pure-action or pure-romance chapters
Both characters have clear internal obstacles to love, not just external danger
Declaration of feelings explicit and emotionally resonant
Grand gesture or proof of love integrated with suspense climax
Danger creates genuine fear for both safety AND the relationship
Forced proximity or protection scenario leveraged for intimacy
Competence shown as attractive. both leads capable under pressure
Secrets between leads serve both romantic tension AND suspense misdirection
Adrenaline-to-tenderness transitions present and emotionally earned
Villain threatens the relationship specifically, not just physical safety in general
Both leads contribute meaningfully to resolving the threat
Post-danger emotional processing scenes included, not just "on to the next crisis"

AUTOMATIC FAILS

Suspense overshadows romance. more than 50% of chapter is pure action or investigation without romantic lens
No chemistry between leads. attraction told, not shown
HEA/HFN absent or ambiguous. romance genre promise broken
Heroine is passive victim with no agency in resolving the threat
Violence gratuitous. graphic beyond what emotional stakes require
Romantic conflict trivially solvable—"just TALK to each other" as the only obstacle
Danger pauses conveniently for romance, or romance pauses for danger. they must be braided
Characters act incompetently to create artificial danger (Too Stupid To Live)
Trust between leads never genuinely tested by the suspense plot

ACCEPTABLE IMPERFECTIONS

Slightly more romance than suspense (or vice versa) if both plots substantial
Formulaic structure if execution is strong and characters feel fresh
Some familiar tropes (bodyguard romance, witness protection, detective/witness) if well-executed
Heat level varies. from closed-door to explicit, all valid if emotionally connected

RED FLAGS TO INVESTIGATE

Romance and suspense running on parallel tracks. danger scenes and romantic scenes alternating without intertwining or informing each other
One lead significantly more developed than the other. protector fully realized but person in danger feels like accessory, or vice versa
Danger scenes that could exist in any thriller. suspense sequences where the romantic relationship has no bearing on the tension or stakes
Adrenaline-to-tenderness transitions missing or abrupt. jumping from gunfire to intimacy without the emotional bridge between them
Emotional wounds mentioned in backstory but never activated by the plot. past betrayal that doesn't inform trust dynamics with the love interest
Villain feeling generic. antagonist threatening physical safety without specifically targeting the relationship
Secrets between leads serving only one plot. a hidden past that creates romantic tension but has no suspense implications, or vice versa
Competence imbalance. one lead consistently solving problems while the other watches or waits
Post-danger scenes skipped. moving to the next crisis without characters processing what they survived and what it means for the relationship
Chemistry stated rather than demonstrated—"she felt the pull" replacing shown physical awareness, loaded dialogue, and protective instincts
Forced proximity not leveraged. characters in close quarters but intimacy not advancing through the circumstance
Emotional register stuck on one note. consecutive chapters of relentless danger without tenderness, or sustained romance without suspense intruding
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Romance milestone tracking: Every romantic first (first touch, first kiss, first "I love you") happens ONCE and is remembered—characters reference these moments
2. Suspense evidence chain: Clues discovered, evidence gathered, suspects identified. nothing appears or disappears without explanation
3. Character knowledge synchronization: Who knows what about BOTH the relationship and the threat. no character acts on information they haven't received
4. Emotional continuity through danger: Fear and trust levels carry forward. a character who was terrified in chapter 5 doesn't forget that experience in chapter 6
5. Dual-plot progression: Both romance and suspense must advance chapter to chapter. neither can stall while the other progresses

ROMANCE CONTINUITY TRACKING
- Attraction markers: When did each character first notice the other? What specific traits attract them?
- Trust progression: What has each character revealed? What secrets remain? When did walls start lowering?
- Physical intimacy timeline: First accidental touch → deliberate touch → kiss → intimate scene (if applicable) → comfort touching
- Emotional intimacy timeline: Surface banter → personal revelation → vulnerability → emotional dependence → love declaration
- Pet names or private jokes: Once established, maintain consistently
- Relationship status: Are they acknowledging the attraction? Denying it? Acting on it? Where does each character THINK they stand?
- Past relationship references: If either character has been hurt before, those wounds must inform current behavior consistently

SUSPENSE CONTINUITY TRACKING
- Evidence log: Every clue discovered, who found it, what it means, who knows about it
- Red herring status: False leads must be planted deliberately and resolved: don't leave them dangling
- Antagonist movements: Where is the villain? What do they know? When did they learn it?
- Threat escalation: Each danger must be equal to or greater than the last: no regression in stakes
- Investigation steps: What has been tried? What failed? What's the current theory?
- Law enforcement involvement: If police/FBI are involved, their investigation must track logically
- Weapon/resource inventory: If a character has a gun, phone, evidence: track its location at all times

CROSS-PLOT CONTINUITY (Most Critical)
- Secrets serving both plots: A character hiding their past serves romantic tension AND may be suspense-relevant
- Trust earned in danger carries into romance: If he saved her life in chapter 8, she references that trust in chapter 12
- Danger knowledge affects romantic behavior: Characters who know someone is hunting them don't casually go to restaurants
- Romantic distraction acknowledged: If characters are falling in love during a crisis, other characters or internal monologue should note the complicated timing
- Protection dynamics: If one character is protecting the other, that power dynamic must be addressed in the romance
- Shared trauma bonding: Surviving danger together creates emotional shortcuts: track these

ACCEPTABLE INCONSISTENCIES
- Minor details of exact dialogue recalled from earlier (paraphrasing is natural)
- Slight variations in peripheral character descriptions
- Small timeline compressions if emotional pacing requires it

CRITICAL CONSISTENCY
- A character cannot know a clue they weren't present to discover
- Romance milestones cannot repeat (first kiss happens once)
- A character who was injured must show recovery time or pain in subsequent scenes
- If a location was established as unsafe, characters need a REASON to return
- Emotional breakthroughs don't reset: if a character admitted fear, they don't pretend it didn't happen
- The villain's capabilities must remain consistent: can't suddenly have skills or resources not established
- Phone/communication access must be tracked: if no cell service was established, it doesn't suddenly work

ROMANCE-CRAFT CONTINUITY:
- Track what characters have SAID vs. NOT SAID about their feelings across chapters: the unsaid carries enormous weight in romantic suspense, and when feelings are finally spoken, the reader must feel the accumulated pressure of everything that was held back
- Track obstacle progression: internal emotional wounds and external dangers should evolve together. A trust issue established in chapter 3 doesn't disappear by chapter 10 without earned development; healing happens through action under pressure, not through conversation alone
- Track emotional register alternation: flag sequences where multiple chapters carry the same emotional tone. After intense danger, there should be tenderness. After romantic connection, suspense should intrude. The signature rhythm of romantic suspense is fear-tenderness-fear
- Track character consistency: a character who was vulnerable in chapter 8 doesn't revert to complete emotional shutdown in chapter 12 without narrative reason. Growth is forward-moving, with setbacks that are motivated, not arbitrary
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Dual protagonists with romantic appeal AND competence under pressure. both must be attractive AND capable
2. Chemistry tracking. attraction markers, trust progression, vulnerability escalation must be consistent chapter to chapter
3. Complementary skills. each lead brings different strengths to BOTH the romance and the investigation
4. Emotional wound consistency. past trauma that creates romantic obstacles must also inform response to danger
5. Agency balance. neither character is merely a victim or merely a protector for the entire story

ROMANTIC LEAD #1 (often the protector/investigator figure)
- Professional competence: Law enforcement, military, security, PI: skilled at threat assessment
- Emotional barrier: Past loss, failed protection, trust betrayal: fears failing someone they love
- Romantic tension: Attraction conflicts with professional obligation or protective instinct
- Character flaw: Over-controlling protectiveness, emotional unavailability, lone wolf tendency
- Growth arc: Learning that love requires vulnerability, not just strength; that partnership is stronger than solo protection
- Physical presence: Described through the other character's attracted gaze: strong hands, alert eyes, controlled power
- Must demonstrate: Competence (attracts the other lead), vulnerability (deepens the romance), respect for partner's autonomy (earns trust)

ROMANTIC LEAD #2 (often the person in danger or connected to the case)
- NOT a passive victim: has skills, intelligence, courage even if not combat-trained
- Emotional barrier: Independence threatened by needing protection, trust issues, past betrayal
- Romantic tension: Attraction to the protector complicated by power imbalance of the situation
- Character flaw: Stubbornness mistaken for independence, difficulty accepting help, secret-keeping
- Growth arc: Learning that accepting help isn't weakness; that trust is a choice, not a surrender
- Must contribute meaningfully to solving the threat: knowledge, connections, insight, courage
- Must challenge Lead #1's assumptions and methods: not merely grateful for rescue

VILLAIN/ANTAGONIST
- Must threaten BOTH the relationship and physical safety: not just a murder plot, but a threat to what the couple is building
- Clear motivation: Obsession, revenge, greed, power: not evil for evil's sake
- Personal connection: The threat should feel personal, not random: tied to one or both leads' past or present
- Escalation pattern: Starts with warnings or indirect threats, builds to direct confrontation
- Intelligence: A credible villain makes smart moves: the couple wins through partnership, not villain stupidity
- If the villain targets the relationship specifically (threatening the love interest to control the other), this raises both suspense AND romantic stakes simultaneously

SECONDARY CHARACTERS
- Best friend/confidant: Provides romantic sounding board AND may assist with investigation: dual utility
- Partner/colleague: Professional ally who notices the romantic tension, may disapprove or encourage
- Suspects: Characters who could be the villain: reader suspects them, creating paranoia that infects the romance
- Family: Background that explains emotional wounds; may be endangered to raise stakes
- Each secondary character should serve BOTH plots where possible: the best friend who is also a potential suspect

CHARACTER CHEMISTRY MARKERS (track consistently)
- Eye contact patterns: Do they hold gazes? Look away first? Can't stop staring?
- Physical proximity: Standing closer than necessary, accidental touches, gravitational pull
- Voice changes: Softer when speaking to each other, breathless after shared danger
- Protective gestures: Unconscious shielding, checking for injury, positioning between partner and threat
- Humor under pressure: Private jokes during stressful moments: bonding through shared dark humor
- Jealousy responses: Reaction to others showing interest in their partner: even before they've acknowledged their own feelings
- Scent recognition: Knowing partner's scent, finding it comforting or distracting

CHARACTER KNOWLEDGE MANAGEMENT
- Track what each character knows about the threat vs. what they've shared with their partner
- Secrets between leads must serve both romantic and suspense tension
- When secrets are revealed, the ROMANTIC fallout matters as much as the plot implication
- Characters should act consistently with their knowledge state: no convenient ignorance or impossible awareness
- Trust broken by discovered secrets must be rebuilt through action, not just apology

EMOTIONAL WOUND INTEGRATION
- Each lead's backstory wound should create BOTH romantic hesitation AND a specific vulnerability the villain can exploit
- Example: A character with abandonment issues both fears romantic commitment AND is susceptible to isolation tactics by the villain
- Healing the emotional wound through romance makes the character STRONGER against the threat: love as armor, not liability
- The climax should require each character to overcome their specific wound to save both the relationship and their lives

CHARACTER BUILDING. GROUND UP:
Build each romantic lead from the ground up BEFORE they appear on the page:
- Background questions: What do they want from life beyond this crisis? What shaped them? What were their formative relationships: and how do those inform both their romantic hesitation and their response to danger?
- Character tests: What's in their bag? How do they react when someone shows them unexpected kindness? When someone they've started to trust lets them down? What do they do in the first quiet moment after danger passes?
- The vast majority of this backstory never appears on the page, but it informs every reaction, every moment of vulnerability, every instinct to protect or to run
- Messy, contradictory characters are ALWAYS more compelling than archetypes: the tough protector who falls apart in private, the supposed victim whose emotional courage outstrips the hero's

ANTI-STEREOTYPE IMPERATIVE:
Romantic suspense has its own dangerous defaults. the alpha protector and the woman in peril. Subvert these. Your protector can be uncertain, your person in danger can be the emotionally braver one. Both leads should be specific, surprising, and real. not defined by the roles the suspense plot assigns them. The romance should emerge from who these particular people ARE, not from a bodyguard-falls-for-client template. Ordinary, prickly, awkward, fierce. all more interesting than the expected archetype.
```

## Arc Rules

```
FOUR-ACT STRUCTURE FOR ROMANTIC SUSPENSE
(Adapted for dual-plot architecture: Romance primary, Suspense secondary)

ACT I: DANGEROUS MEETING (Chapters 1-7, ~20% of manuscript)

Chapter 1-2: THE INCITING COLLISION
- Romantic leads meet under dangerous or high-stakes circumstances
- Meet-cute infused with threat: crime scene, protection assignment, witness to danger, fleeing attacker
- Immediate chemistry noted BY BOTH characters (even if reluctantly)
- The threat is established or hinted: something is wrong, someone is in danger
- First impression creates both attraction AND complication: "Of all the people to be stuck with..."
- Establish each character's normal world briefly: this is the last time things are "normal"

Chapter 3-4: FORCED PROXIMITY BEGINS
- Circumstances force characters together: safe house, investigation partnership, can't be left alone
- Initial friction: different approaches, personality clashes, attraction they're fighting
- Suspense plot deepens: second incident, first real clue, threat confirmed as serious
- Both characters demonstrate competence in their domain: mutual respect begins
- First vulnerability glimpse: one character sees behind the other's professional mask

Chapter 5-7: STAKES ESTABLISHED
- The threat becomes personal: directed at one or both leads specifically
- Romantic tension undeniable: banter, loaded glances, accidental touches, denied attraction
- Trust issue introduced: a secret one character is keeping that would affect both plots
- First genuine danger scene: threat is REAL, someone could get hurt
- ACT I CLIMAX: A dangerous event forces physical closeness AND emotional honesty
- By end of Act I: Reader is invested in BOTH the couple getting together AND surviving

---

ACT II-A: FALLING WHILE FIGHTING (Chapters 8-15, ~25% of manuscript)

Chapter 8-10: ATTRACTION UNDER FIRE
- Characters begin to acknowledge the pull toward each other (internally, then to each other)
- Investigation/threat-response puts them in close quarters repeatedly
- Shared danger scenes where they must work together: competence as aphrodisiac
- Each chapter reveals new layers: his backstory wound, her hidden strength, shared values
- Suspense escalation: the threat is bigger than initially thought, or a new victim appears

Chapter 11-13: WALLS LOWERING
- First kiss or major physical intimacy milestone: earned through emotional and suspense buildup
- Vulnerability exchange: characters share their deepest fears, past traumas, real selves
- A significant clue or breakthrough in the case: often discovered during an intimate moment
- The villain becomes aware of the romantic connection and begins to weaponize it
- Internal conflict peaks: "I can't fall for someone while someone is trying to kill me/them"

Chapter 14-15: MIDPOINT REVELATION
- MIDPOINT: A major revelation that reshapes BOTH the romance and the suspense
- Could be: The secret one character has been keeping is exposed. The villain's identity becomes clearer. The real scope of the threat is revealed. A betrayal. real or perceived. rocks the growing trust.
- The revelation must challenge the romance: "Can I trust someone who kept this from me?"
- The revelation must escalate the suspense: The danger is now more personal, more imminent, or more complex
- After the midpoint, the romance shifts from "falling" to "fighting for": the relationship now requires active commitment
- The stakes are now clear: losing this person would be devastating, and the threat is capable of causing that loss

---

ACT II-B: DARK TERRITORY (Chapters 16-22, ~25% of manuscript)

Chapter 16-18: COMMITTED BUT TESTED
- Characters have chosen each other despite the midpoint revelation: but trust is fragile
- Romantic relationship deepens: full intimacy (emotional and/or physical), declarations approach
- Suspense tightens: the villain is closing in, options are narrowing, time pressure increases
- New suspects or red herrings introduced to maintain mystery: doubt infects the romance
- Characters begin making sacrifices for each other: proof of love through action

Chapter 19-20: THE NOOSE TIGHTENS
- Direct attack on the relationship: villain uses one character against the other
- A secondary character is endangered or harmed: the threat becomes real and costly
- Investigation reveals the full picture: but the truth is worse than expected
- Characters must make impossible choices: safety vs. justice, running vs. fighting, protecting partner vs. respecting their autonomy
- The emotional and physical toll of sustained danger is visible: exhaustion, fear, desperation

Chapter 21-22: THE DARK MOMENT (Dual Crisis)
- ROMANCE DARK MOMENT: The relationship appears to shatter: a lie exposed, a forced separation, a sacrifice that feels like betrayal, "I'm leaving to protect you" moment
- SUSPENSE DARK MOMENT: The villain gains the upper hand: a character is captured, evidence is destroyed, the plan fails catastrophically
- BOTH dark moments must happen simultaneously or in rapid sequence: the relationship breaks BECAUSE of the danger, the danger escalates BECAUSE of the relationship
- This is the "all is lost" beat: the couple is separated, the villain is winning, hope is at its lowest
- Reader must believe, just for a moment, that neither the romance nor the survival is guaranteed

---

ACT III: LOVE UNDER FIRE (Chapters 23-30, ~30% of manuscript)

Chapter 23-24: CHOOSING LOVE DESPITE EVERYTHING
- One or both characters realize that losing the relationship is worse than the danger
- The decision to fight for love DESPITE the risk: "I'd rather face the danger WITH you than be safe WITHOUT you"
- Characters reconcile, not through conversation alone, but through ACTION: showing up when it counts
- A new plan forms: the couple will face the threat TOGETHER, combining their strengths
- This is where the emotional wound healing completes: the character must become the person the relationship needs AND the person the climax requires

Chapter 25-27: THE CLIMAX (Romance and Suspense Converge)
- The couple faces the villain together: partnership is their greatest weapon
- Each character uses their specific skills and growth to contribute to victory
- The villain targets the relationship one final time: trying to use love as weakness
- Love proves to be STRENGTH: trust enables the plan, commitment provides courage, partnership defeats isolation
- The suspense resolution is physical (confrontation, escape, arrest, defeat of villain)
- The romance resolution is emotional (choosing each other is proven through action under ultimate pressure)
- Declaration of love in the crucible: if not said before, it happens here; if said before, it's PROVEN here

Chapter 28-29: RESOLUTION AND AFTERMATH
- Immediate aftermath: safety confirmed, villain neutralized, wounds (physical and emotional) tended
- Emotional landing: the couple processes what they survived: grief for losses, relief, gratitude for each other
- Loose ends tied: investigation concluded, secondary characters' fates addressed, justice served
- The relationship recalibrated for a world without constant danger: "Who are we when we're not running?"
- Commitment confirmed: explicit discussion of future together, not just survival relief

Chapter 30: EPILOGUE. THE HEA EARNED
- Show the couple in their new normal: together, healing, building
- Reference the danger they survived as foundation of their bond, not a trauma that defines them
- Demonstrate that both characters are changed: stronger individually AND as a couple
- If series, hint at next couple or unresolved thread; if standalone, provide full emotional closure
- The final image should capture both the romance and the strength: "safe at last, together at last"

---

GENRE PROMISE
- HEA/HFN mandatory: the couple is together, committed, and safe
- Suspense resolved satisfyingly: villain defeated, mystery solved, justice served
- Both leads demonstrate growth: the protector learned vulnerability, the protected proved their strength
- Love tested by danger: and found unbreakable
- The romance is what the reader came for: the suspense is what kept them up all night

REQUIRED CHECKPOINTS
- Ch 2: Chemistry undeniable AND threat established
- Ch 7: Forced proximity active, trust beginning to build, danger is personal
- Ch 10: Attraction acknowledged (at least internally), investigation producing leads
- Ch 15: MIDPOINT revelation reshaping both plots: relationship tested, danger escalated
- Ch 18: Full romantic commitment (emotional and/or physical), villain closing in
- Ch 22: DARK MOMENT: relationship shattered AND villain ascendant
- Ch 25: Couple reunites to face threat together: love as weapon, not weakness
- Ch 28: Both plots resolved: villain defeated, couple committed
- Ch 30: HEA: safe, together, healed, and looking forward

PACING RHYTHM
- Chapters should alternate emphasis (not content): romance-heavy chapter → suspense-heavy chapter → romance-heavy
- BOTH elements present in every chapter, but one leads while the other supports
- Tension should never fully release until the epilogue: even tender moments carry awareness of danger
- The final quarter accelerates: shorter scenes, faster cuts, higher stakes in both plots simultaneously

EMOTIONAL CONTRAST IN ARC STRUCTURE:
Chart emotional highs and lows throughout both arcs. After a scene of terrifying danger, allow an unexpected moment of tenderness, humor, or connection that reminds the reader what these characters are fighting for. After a beautiful romantic milestone, shatter the calm with a suspense beat that raises the stakes. Lure readers into false security, then crash their hopes. and vice versa. This oscillation between fear and love, danger and tenderness, is what makes romantic suspense emotionally addictive.

EARNED ENDINGS:
The HEA must be TRUE to the characters built throughout the story. Seed the resolution early: the moment of trust that will be remembered in the climax, the specific strength that will prove crucial, the vulnerability that had to be overcome. The reader should think "of course—it HAD to end this way." The couple earns their happy ending not by surviving the danger, but by becoming the people who DESERVE each other through the crucible of the story. Survival is the suspense resolution; becoming worthy of each other is the romantic resolution.

THEME AS THROUGH-LINE:
Every strong romantic suspense weaves its theme through both the romance and the danger arcs. If the theme is about trust, the suspense should test trust in one register while the romance tests it in another. If it's about courage, physical bravery and emotional bravery should echo each other. Theme unifies the dual-plot structure and gives the story resonance that outlasts the specific events.
```

## Timeline Rules

```
TIME SCALE
- Total story duration: 1-4 weeks typical (suspense creates urgency; drawn-out investigations lose tension)
- Chapter time span: Hours to 2-3 days maximum: romantic suspense moves FAST
- Time progression: Linear with minimal flashback: suspense requires forward momentum

DUAL TIMELINE ARCHITECTURE
Romantic Suspense requires tracking TWO timelines simultaneously:

ROMANCE TIMELINE (emotional clock):
- How long have the characters known each other? Hours? Days? Weeks?
- How fast is intimacy developing relative to acquaintance time?
- Is the pace justified by circumstances? (Danger accelerates emotional bonding: this is scientifically valid and genre-expected)
- When did each romance milestone occur relative to story time?
- Are characters acknowledging the speed? ("I know it's only been five days, but...")

SUSPENSE TIMELINE (threat clock):
- When was the inciting threat established?
- How much time between attacks/incidents? (Must escalate in frequency)
- Investigation steps mapped chronologically: what was discovered when?
- Villain's timeline: what is the antagonist doing in parallel?
- Deadline pressure: Is there a ticking clock? (Trial date, next attack predicted, escape window closing)

TIME PRESSURE EFFECTS ON ROMANCE
- Danger compresses romantic timeline: falling in love in a week is believable when you might die tomorrow
- Adrenaline bonding is real: shared survival experiences create deep attachment quickly
- Sleep deprivation and sustained stress affect judgment: acknowledge this in character behavior
- Characters should occasionally note the surreal speed: "A week ago I didn't know your name"
- Time apart during the danger period creates desperate longing: even hours feel long
- The "normal world" outside the danger bubble moves at regular speed: acknowledge the disconnect

INVESTIGATION CHRONOLOGY
- Track the logical sequence of evidence discovery: what led to what
- Police/FBI response times must be realistic: forensics take days, warrants take hours
- Communication has realistic delays: calling for backup, waiting for lab results
- Travel time between locations must be accounted for: characters can't teleport
- If working overnight, show fatigue affecting both investigation and romance

TRACK CAREFULLY
- Exact day count since characters met: critical for romance believability
- Time of day during danger scenes: daylight vs. darkness affects mood and tactics
- Meal/sleep cycles: characters under sustained threat still need to eat and rest (or the lack of it shows)
- Communication timeline: when were calls made, texts sent, messages left?
- Injury recovery: wounds sustained need appropriate healing time before physical activity (including intimacy)
- Travel durations between key locations: safe house, crime scene, hospital, police station
- Villain's movements in parallel: what is the antagonist doing during the characters' romance scenes?
- Media/public awareness timeline: if the threat makes news, when does public involvement complicate things?

FLEXIBLE
- Exact minutes during low-tension scenes
- Background characters' precise schedules
- Minor travel times between nearby locations
- Exact meal times if no plot significance
```

## Genre-Specific Craft Techniques

Romantic suspense is two genres locked into the same scene
demanding contradictory things from the prose. Suspense
demands forward velocity, withheld information, the reader's
sustained uncertainty about who survives. Romance demands the
slow accumulation of trust, the moments of pause where two
people see each other clearly, the eventual certainty that
this love will be made. Neither can be served at the other's
expense. The techniques below are how the form holds both
demands at the level of the line, the scene, and the chapter
without letting either collapse the other.

### The Dual-Tension Engine

Suspense and romance must escalate simultaneously, never
alternating. The kiss interrupted by the gunshot. The
confession made during the stakeout. The tender moment
shattered by the threatening phone call. The post-coital
realisation that the safehouse is no longer safe. Both
tensions must be present in nearly every scene — not traded
chapter by chapter — and the reader's experience of each
should be sharpened by the other's pressure. When one thread
goes quiet while the other dominates, the genre contract
fractures: pure-romance chapters read as breathing-room the
suspense should not have allowed; pure-thriller chapters read
as the romance writer stepping aside while a thriller writer
takes over. The craft test: pick any scene at random and ask
whether both registers are doing work. The romantic scenes
should carry the awareness of threat (the door watched, the
phone left on, the road home rehearsed); the suspense scenes
should carry the awareness of the relationship (the look
across the room when the team breaches, the glance that
checks the partner is still alive after the shot). The reader
picked up this book for both pleasures at once and will feel
abandoned in either direction.

### The Danger-Intimacy Bridge

Life-threatening situations create forced vulnerability.
Characters who would never open up emotionally are stripped
bare by crisis: the adrenaline of survival sharpens desire,
the controlled professional becomes raw under threat, the
person who has built their life around independence suddenly
needs another body's heat to survive the night. Physical
proximity demanded by protection scenarios — safe houses,
shared hotel rooms under aliases, guarded convoys, the bedroom
they must share because there is only one entrance to defend —
becomes the crucible where emotional walls crumble. The danger
does not pause for the romance; the romance blazes because of
the danger. The technique requires that the bridge be earned
in both directions: the suspense partner (operative,
investigator, protector) must encounter the civilian in
exposure that costs their professional discipline; the
civilian must encounter the suspense partner in exposure that
costs their assumed safety. Test: would this couple have
fallen in love in ordinary life, on the same timeline, with
the same intensity? If yes, the danger is decoration. If no,
the bridge is doing the work the genre asks of it.

### The Trust-Under-Pressure Test

Can you love someone when your life depends on them? Trust in
romantic suspense carries literal life-or-death weight. Every
act of trust — sharing information, turning your back, falling
asleep in their presence, accepting the drink they made,
following them down the corridor without checking the room
first — becomes a romantic gesture because the stakes are
mortal. Conversely, every withheld piece of information, every
late call returned, every moment of ambiguous loyalty
amplifies into existential threat: withholding a clue is not
merely dishonest, it is potentially lethal. The dual register
transforms ordinary relationship milestones into extraordinary
dramatic moments — first sleep together becomes first time
trusting another person with unconsciousness; first
disagreement becomes first moment one of them might leave the
other exposed. The technique requires that trust be tested
specifically and incrementally, not declared. A character who
"trusted him with her life" without having concretely done so
on the page has not earned the line.

### The Secret That Threatens Love

The suspense-plot secret that could destroy the romance. The
undercover identity. The handler the love interest has been
reporting to. The hidden connection to the antagonist. The
past crime never confessed. The contract on the protagonist's
life that the love interest accepted before they met. This
secret must be genuinely threatening to the relationship — its
revelation should feel as though it could end the love story
permanently — and the reader must believe the couple might
not survive the truth. If the secret is trivially forgivable
("I was secretly working as your bodyguard but I do love you"
is the genre's most-collapsed beat), it cannot bear the weight
the form places upon it. The strongest secrets carry both
moral weight (the betrayed character has reason to feel
genuinely betrayed) and structural weight (the secret has been
shaping the suspense plot, not merely sitting in the
character's pocket). Stage the secret's hold and release: the
reader is let in to its presence early; the betrayed
character is let in late; the reveal occurs at maximum
asymmetric damage; the aftermath gets sufficient page time to
matter. A secret revealed and forgiven within the same scene
is a secret the book did not need.

### The Climactic Convergence

Suspense climax and romantic commitment must coincide. The
rescue that is also a declaration. The confrontation with the
villain that proves the depth of love. The moment in which
the protagonist must choose between the partner's safety and
the operational objective and, in choosing, reveals what they
have become. Both genre climaxes must land simultaneously,
resolving the danger while sealing the romance. A staggered
resolution — the villain defeated in chapter twenty-eight, the
couple reunited in chapter thirty — deflates both storylines:
the suspense ends without emotional weight, the reunion lacks
the pressure the danger was supposed to supply. The moment of
greatest peril must be the moment of greatest emotional truth.
The convergence requires plotting that earns the alignment:
the secret revealed in the antagonist's presence, the choice
forced when both are pinned, the rescue that requires the
partner to be the one who saves rather than be saved. Test:
can the writer sketch the climactic page in two columns —
suspense action / romantic recognition — with both columns
populated by the same beats? If the columns can only be
filled by separate scenes, the convergence has not been
constructed.

### The Investigator-Civilian Asymmetry

Most romantic suspense pairs an operative or investigator
(FBI, MI6, ex-military, private security, homicide detective,
former black-ops) with a civilian (the witness, the target,
the journalist, the academic, the lover of the missing
person). This asymmetry is the form's structural engine and
its most-mishandled element. The investigator brings competence
under pressure, lethal capacity, and the trauma of the work;
the civilian brings the moral framework, the social network,
and the version of normal life the investigator has long since
lost. Both must be load-bearing. The civilian who exists
purely to be protected — a body shipped from set-piece to
set-piece — voids the romance; the investigator who never
lapses, never doubts, never reveals the cost of what they do
voids the genre's emotional work. Test: at the climax, what
does the civilian contribute that the investigator could not
provide for themselves? If the answer is "moral support" or
"love", the asymmetry has not been balanced. The civilian
must do something at the climax — observe the detail the
investigator missed, take the shot the investigator could not,
make the call the investigator's training prevented — that
materially turns the outcome.

### Romantic Suspense AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "danger and desire made a heady combination" | Show the specific moment where both collide — the body's signals indistinguishable, the next action ambiguous |
| "she couldn't trust him. but she wanted to" | Show the specific evidence for and against trust the protagonist is weighing in this scene |
| "the attraction was dangerous" | Show the specific operational risk it creates — the call missed, the position revealed, the cover compromised |
| "their passion burned despite the peril" | Show the specific moment of vulnerability amid threat — what each is willing to do that they would not have done before |
| "he was either her saviour or her destroyer" | Show the specific action that could be read either way and the reader's specific uncertainty about which |
| "the mystery deepened, and so did their connection" | Show the specific shared discovery and what each understood differently from it |
| "she let her guard down" | Show the specific moment, the immediate consequence, and what she will do next time |
| "adrenaline fueled their attraction" | Show the specific post-danger physical awareness — shaky hands, hyper-clarity, the appetite that follows survival |
| "trust was a weapon in this game" | Show the specific trust test and what it costs both partners |
| "dark secrets threatened their love" | Name the specific secret, who knows what now, and the specific clock running on its disclosure |
| "the line between ally and enemy blurred" | Show the specific ambiguous action; ambiguity must be earned by readable behaviour, not asserted |
| "her training kicked in" | Show the specific trained behaviour — the door cleared, the weapon checked, the sightlines mapped — and her interior voice doing the training |
| "he had to keep her safe at all costs" | Show what the cost is in this specific scene and whether he is willing to pay it |
| "she was a complication he didn't need" | Show the specific operational complication she creates and his concrete reaction (extra patrols, missed call, revised cover) |
| "the case was getting personal" | Show the specific moment the personal entered the case — what changed, what cannot be undone |
| "their cover was about to be blown" | Show the specific clue the antagonist now has and the specific countermeasure available |
| "she had a bad feeling" | Show what specifically alerted her — the parked car, the missed check-in, the partner's unusual silence |
| "the safe house wasn't safe anymore" | Show the specific breach indicator and the precise sequence of decisions that follow |

## Genre-Specific Revision Rules

Six revision passes specific to romantic suspense, each with a
single question, run cover-to-cover before the next begins.
The genre's reader is dual-experienced — has read enough
thrillers to detect suspense that does not threaten and enough
romance to detect intimacy that does not earn — and any pass
that tries to check both registers at once will catch failures
in neither. The passes below are ordered so that the
structural failures (balance, pacing) are caught before the
relational failures (authenticity, secret-handling) and the
climactic test runs last with the rest of the book stable
behind it.

### Pass 1: Dual-Tension Balance Audit

Map suspense beats and romance beats across all chapters in a
single chart, marking each chapter's primary register
(suspense / romance / both-active). Neither register should
dominate for more than two consecutive chapters; both should be
present in nearly every chapter. Verify that suspense scenes
contain romantic awareness (the partner remembered, the safety
of the other tracked, the look exchanged before the breach)
and that romantic scenes contain suspense awareness (the door
watched, the phone left within reach, the awareness that this
moment is stolen from threat). The couple should never feel
completely safe until the final pages — even the quiet scenes
should be quiet in a particular way, the quiet of borrowed
time. If any chapter reads as pure romance (the threat has
been forgotten) or pure thriller (the relationship has been
put aside while the operational beats run), it needs reweaving.
The braided structure is not optional in this genre; it is the
genre.

### Pass 2: Suspense Pacing Check

Chart the threat escalation from inciting incident to climax.
Does danger increase consistently in a curve the reader can
feel, or does it plateau in the middle (the genre's
characteristic structural failure)? Check that clues and
revelations are distributed to maintain momentum: at minimum
one significant disclosure per third, ideally one per quarter.
Verify the antagonist or threat remains credible throughout —
present, active, intelligent, and capable of finding the
protagonist before the protagonist finds them. The danger must
feel genuinely life-threatening, not merely inconvenient: if
the reader ever stops believing someone could die, the suspense
has failed and will not recover. False alarms and
misdirections should heighten tension rather than dissipate it
— each one must shift the reader's understanding of where the
real threat lies, not merely delay an obvious threat the
reader has already identified. Test the antagonist's
intelligence: the reader should believe the antagonist is
making competent choices the protagonist must out-think, not
incompetent choices that conveniently allow the protagonist's
plan.

### Pass 3: Romance-Under-Threat Authenticity

Review every romantic scene asking whether the ambient danger
informs the intimacy. Characters who forget they are in danger
during romantic moments break the genre contract. Even the
most tender scenes should carry an undercurrent of awareness
that this moment is stolen from danger — the room scanned
before the kiss begins, the weapon within reach in the bedside
table, the morning departure planned even as the night is
spent. Check that physical intimacy is earned through emotional
vulnerability, not merely proximity: a couple who have been
forced into the same hotel room and slept together by chapter
six without earned trust have skipped the work the genre
demands. The romance must feel inevitable because of the
danger, not despite it: each romantic beat should be a
specific consequence of what the suspense has put the couple
through. Flag any romantic scene that could be lifted intact
into a contemporary romance without losing meaning; that scene
has not been written for this book.

### Pass 4: Secret Revelation Timing

If one character holds a secret structural to the suspense
plot, chart exactly when it is revealed and to whom. Build a
disclosure ladder: the reader knows X by chapter Y; the
betrayed character knows X by chapter Z; the antagonist knows
the secret is in danger by chapter A. The revelation to the
betrayed character should come at the point of maximum
emotional damage — late enough that genuine love has developed
(otherwise the betrayed character has nothing to lose), early
enough that the reaction can drive the final act (otherwise
the reveal lands too close to resolution and the betrayal has
no work to do). Verify that sufficient clues exist for the
reader to feel the revelation is fair — the secret-keeper's
behaviour must, in retrospect, make sense. Check that the
aftermath of the revelation receives adequate page time:
rushing past betrayal undermines both the suspense (the secret
should have had structural consequence) and the romance (the
reconciliation should have required real work). Flag any
revelation that is forgiven within the same scene; that secret
was decoration, not stakes.

### Pass 5: Dual Climax Satisfaction Test

Read the climactic sequence as a continuous block — ideally in
one sitting, with no breaks between the suspense climax and
the romantic climax. Does the suspense resolution feel
thrilling? Does the romantic resolution feel earned? Are they
the same scene, or have they been staggered into separate
chapters? If either genre's climax feels rushed or subordinate,
restructure: the reader should close the book having received
a complete thriller AND a complete romance, with both
deliveries occurring within the same climactic sequence. Test
by asking: would this ending satisfy a reader who came only
for the suspense? Only for the romance? Both answers must be
yes — and a third question must also resolve: would this
ending satisfy a reader who came for the integration, who
wants the suspense climax to be the romantic climax? If the
two climaxes can be summarised separately without losing
meaning, the convergence has not been written.

### Pass 6: The Operational Authenticity Audit

Romantic suspense readers are frequently law-enforcement,
former military, intelligence-community, or serious-thriller
readers in their own right; they detect operational nonsense
faster than civilian readers. Run a dedicated pass on the
operational elements: weapons handled correctly, tactical
movements that obey current doctrine, communications protocols
respected, agency jurisdiction observed (the FBI does not
investigate that kind of crime in that location; the local
PD does not have that resource), evidence chain-of-custody
preserved, undercover protocols realistic for the period. Where
the manuscript fictionalises an agency or invents an
operational detail, internal consistency is the standard. Where
the manuscript depicts real agencies (FBI, DEA, ATF, Secret
Service, MI5, MI6, GCHQ, Mossad, CSIS), the depiction must
not contradict publicly known fact. Flag any tactical scene
where the operative does something a working professional in
that role would not do (entering a room without clearing it;
using a weapon they would not actually carry; making a call
on a compromised line; sharing intelligence without
authorisation in a way that would end a real career). The
suspense reader's trust in the protagonist's competence is
the genre's foundation; one operational mistake by the writer
costs more than the reader's tolerance can carry.

## Names & Patterns to Avoid

### Forbidden Patterns
- **Romance pausing for suspense**. If the love story stops whilst the investigation happens, the two genres are not integrated; the book is merely a thriller with romantic interludes
- **The TSTL (Too Stupid To Live) protagonist**. Characters who walk into obvious danger alone for plot convenience insult the reader and break suspense; competence is attractive and essential
- **Suspense resolved by love**. The villain cannot be defeated by the power of the couple's love; the resolution must be earned through competence, courage, and credible action
- **The disposable threat**. If the antagonist or danger is not genuinely frightening, the romance built under threat has no foundation; the villain must be worthy of the heroes

### Cliché Setups to Avoid
- The protagonist who does not call the police for no credible reason. contrivance erodes trust in the narrative
- The "detective who has been burned by love before" without genuine psychological depth behind the wound
- The twist where the love interest was the villain all along without sufficient setup and a satisfying romantic resolution elsewhere
- The competent heroine who becomes helpless in the final act solely so the hero can rescue her. agency must be maintained throughout
- The villain who monologues their plan instead of acting. romantic suspense demands credible, intelligent antagonists

### Naming Considerations
- Protagonist names should feel competent and grounded. avoid names that undercut the suspense tone; no bubbly diminutives for serious investigators unless the contrast is deliberately characterised
- Villain names should not telegraph their role. subtlety in naming preserves the mystery; avoid overtly sinister surnames
- Law enforcement characters benefit from surnames that feel authoritative without being cartoonish or clichéd
- Romantic leads' names should sound well together when spoken aloud. the reader will encounter the pairing hundreds of times

## Comp Titles

Romantic-suspense's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Rebecca* — Daphne du Maurier (1938): the romantic-suspense template; secret-of-the-house with marriage frame.
- *Madam, Will You Talk?* — Mary Stewart (1955): Mary Stewart's romantic-suspense canon; modern genre's foundation.
- *Nine Coaches Waiting* — Mary Stewart (1958): governess-romantic-suspense template.

### Contemporary (current best-in-class)

- *Behind Closed Doors* — B.A. Paris (2016): domestic-suspense with romance frame; modern category benchmark.
- *The Couple Next Door* — Shari Lapeña (2016): contemporary couple-in-jeopardy suspense.
- *The Wife Between Us* — Greer Hendricks & Sarah Pekkanen (2018): twist-driven romantic-suspense.
- *Verity* — Colleen Hoover (2018): romantic-suspense with manuscript-as-evidence frame; viral commercial success.
- *The Last Time I Lied* — Riley Sager (2018): summer-camp romantic-suspense.
- *The Plot* — Jean Hanff Korelitz (2021): writer-protagonist romantic-suspense with literary-thriller crossover.

## Cover Design Specifications

### Recommended Visual Styles
- **Photorealistic**. The genre standard; real couples in moody, atmospheric settings convey both romance and danger simultaneously
- **Cinematic**. Film-poster compositions with dramatic lighting, lens flare, and depth of field; suits high-stakes romantic suspense with strong thriller elements
- **Typographic**. Bold, layered typography over atmospheric background imagery; works for established authors where the name sells and the design signals mood
- **Vintage**. Retro noir-inspired treatments for romantic suspense with classic mystery undertones; muted palettes with film-grain textures

### Genre Cover Aesthetics
- **Styles:** Moody atmospheric lighting with romantic warmth underneath, couples in dramatic poses against threatening landscapes, silhouettes in rain or fog, dark backgrounds with selective warm lighting on figures, tension-charged compositions where closeness implies both intimacy and danger
- **Colours:** Deep navy and midnight blue (danger), warm gold and amber (romance), smoky gray and charcoal (atmosphere), muted burgundy and wine red (passion under threat), storm-cloud purple. darker than standard romance but warmer than pure thriller
- **Elements:** Couples in protective or intimate poses, threatening landscapes (stormy skies, isolated roads, shadowy buildings), rain and wet surfaces, city lights blurred in background, single figures looking over shoulder, mysterious doorways or windows, dramatic weather
- **Typography:** Strong serif or modern sans-serif fonts; title often in metallic or embossed effect; author name prominent; sometimes a tagline hinting at both love and danger; lettering may have subtle texture or shadow suggesting depth

### Subgenre Variations
- **Bodyguard/Protection Romance**. Closer couple compositions, protective posing (one figure slightly behind/shielding the other), more urban settings, deeper shadows
- **Small-Town Romantic Suspense**. Slightly warmer palette, rural or coastal threatening landscapes, isolated houses or churches, more atmospheric than urban
- **Military/Law Enforcement Romantic Suspense**. Stronger thriller elements in design, tactical clothing or uniforms suggested, more cinematic and high-contrast
- **Gothic Romantic Suspense**. Darker palette, isolated mansions or estates, fog and moonlight, more vintage and illustrated options viable

### Market Positioning
Romantic suspense covers must signal "romance first, danger real" on Amazon thumbnails. The couple or romantic element should be the primary visual, with danger conveyed through atmosphere (lighting, weather, setting) rather than weapons or action imagery. The cover must be clearly distinguishable from both pure romance (too soft/bright) and pure thriller (too cold/clinical). Moody lighting with warm undertones is the signature look. At thumbnail size, the romantic element and the atmospheric threat should both register. Series consistency in colour treatment and typography style builds reader trust and brand recognition.

### Cover Design DON'Ts
- No pure action imagery without romantic elements. this is not a thriller; the romance must be visible
- No bright, cheerful, sun-drenched aesthetics. the mood must carry an undercurrent of danger
- No overly sweet or cozy design treatments. soft pastels and whimsical fonts signal the wrong genre
- No graphic violence, weapons prominently displayed, or blood. threat is atmospheric, not explicit
- No cold, clinical design without warmth. there must be romantic energy in the colour palette and composition
- No cartoon or illustrated styles. photorealistic and cinematic dominate this market
- No solo male figure in action-hero pose without romantic context. this signals thriller, not romantic suspense
- No generic stock-photo couple without atmospheric setting. the danger element must be present in the environment
