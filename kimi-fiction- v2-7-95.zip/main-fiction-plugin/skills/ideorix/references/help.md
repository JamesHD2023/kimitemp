---
name: help
description: "Quick reference for all Ideorix commands, features, and workflow phases"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with the branding lines (including copyright). On the FIRST interaction of a session, also show the license check (see core-pipeline.md License Verification Display).

# Ideorix Help

## Quick Start

Say **"Write a book"** to begin. The engine walks you through everything step by step.

Say **"Menu"** or **"Back"** at any time to return to the Front Gate.

## Front Gate

The engine opens with two paths:

| Path | What's inside |
|------|--------------|
| **A. Writing Studio** | Write, plan, edit, and publish manuscripts |
| **B. Management Tools** | Market research, analysis, names, and marketing |

## Writing Studio

| Action | What it does |
|--------|-------------|
| **Write a New Book** | Full pipeline — genre selection, setup, Story Bible, chapter generation, editorial, delivery. Or **Story Bible Only** mode for writers who want to write it themselves. |
| **Continue Writing** | Resume an in-progress manuscript from the next unwritten chapter |
| **Edit & Revise** | Run editorial agents (proofreader, copy editor, dev editor, line editor, alpha/beta readers) |
| **Heritage Text** | Modernize public domain texts — update spelling, fix OCR artifacts, preserve original voice |
| **Export & Publish** | DOCX formatting, KDP metadata, query packages |

## Management Tools

| Action | What it does |
|--------|-------------|
| **Marketing & Cover** | Cover concepts, blurbs, Amazon descriptions, social media, query letters, book trailers |
| **Analyze a Book** | Reverse-engineer any novel into a reusable structural blueprint |
| **Manuscript Clinic** | Scored manuscript analysis across 6 axes |
| **Market Scout** | Live market intelligence for any genre |
| **Pen Name Studio** | Create, manage, and select author pen names |
| **Character Name Generator** | Historically accurate, culturally appropriate character names |
| **Company & Business Name Generator** | Era-accurate, region-specific fictional business names |

## Pipeline Phases

| Phase | Name | What happens |
|-------|------|-------------|
| 0 | Series Architecture | (Optional) Plan multi-volume series arcs |
| 1 | Interactive Setup | 14 questions that configure the engine |
| 2 | Story Bible | World, characters, plot, and continuity reference |
| 3 | Chapter Generation | Architect plans → Writer drafts → each chapter |
| 4 | Verification | 6 agents check continuity, quality, timeline, characters, arcs |
| 5 | Editorial | Proofreader → Copy Editor → Dev Editor → Alpha/Beta Readers |
| 6 | Delivery | Final manuscript with editorial report |
| 7 | Publishing Studio | (Optional) Cover, marketing, trailers, export |

## Supported Genres

68 genres across 8 categories: Mystery & Crime, Fantasy & Sci-Fi, Romance, Literary & Contemporary, Horror & Gothic, Historical & Adventure, YA & Children's, and Specialty genres.

## Revision Snapshots

The engine automatically snapshots your manuscript before every destructive operation
(chapter generation, batch editing, editorial fixes). Snapshots are stored in
`engine-data/revisions/` with timestamps and stage labels.

| Command | What it does |
|---------|-------------|
| **"Restore from snapshot"** | List available snapshots and restore one to `chapters/` |
| **"Roll back to [timestamp]"** | Restore a specific snapshot |
| **"Compare snapshots"** | Diff any two revision points |
| **"Show snapshots"** | List all available revision snapshots |

## Tips

- Say **"skip"** to use defaults for any setup question
- Say **"rewrite chapter N"** to redo a specific chapter
- Say **"status"** to see where you are in the pipeline
- Say **"restore from snapshot"** to roll back to a previous version of your manuscript
- You approve each phase before the engine proceeds — nothing runs without your OK
