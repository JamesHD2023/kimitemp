---
name: historical-fantasy-genre
description: Genre-specific instructions for historical fantasy fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Historical Fantasy. Genre Plugin

## Metadata
- id: historical-fantasy
- name: Historical Fantasy
- icon: ⚔️
- category: Fantasy & Sci-Fi
- tier: Hybrid/Crossover
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Epic Fantasy Arc", "Hero's Journey", "Three-Act Structure", "Worldbuilding Beats"]

## Subgenre Options
Present during setup:

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| **Alternate History Fantasy** | Magic rewrites documented events; the divergence IS the plot | Heavy research burden; must track exactly where and why history changed |
| **Mythic Historical** | Gods, demigods, and mythological beings walk through real eras | Mythological source fidelity matters; divine intervention shapes the power scale |
| **Folk Magic Historical** | Hedge witches, cunning folk, charms, and local superstition woven into daily life | Magic is small, practical, and rooted in landscape; stakes are personal, not apocalyptic |
| **Alchemical / Occult Historical** | Hermetic philosophy, alchemy, secret societies, and esoteric knowledge | Intellectual magic system; protagonists are scholars, physicians, or court magicians |
| **Epic Historical Fantasy** | Large-scale warfare, empire-level stakes, and sweeping magical forces across real civilisations | Longest form; requires multiple POVs, battlefield logistics, and geopolitical consequence |
| **Dark Historical Fantasy** | Horror-adjacent supernatural elements in grim, researched settings | Tone skews towards dread; magic is dangerous, costly, and often malevolent |

## Architect Instructions

```
You are architecting a Historical Fantasy chapter that must stand on two equally strong foundations: rigorous historical authenticity and seamlessly integrated magical elements. Neither pillar can be decorative. the history must be real and researched, and the magic must matter to the outcome.

DUAL-FOUNDATION STRUCTURE:
Every chapter must establish its historical grounding BEFORE introducing or escalating magical elements. The reader must feel the weight of the real period. its politics, its dangers, its daily textures. so that the intrusion of the supernatural carries genuine power. Magic that arrives in a vacuum of historical detail feels like generic fantasy wearing a costume.

CHAPTER BEAT ARCHITECTURE:
Structure each chapter around these five essential beats, though their order may vary:

1. HISTORICAL EVENT. Anchor the chapter in a real or period-plausible event: a battle, a coronation, a plague outbreak, a trade negotiation, a religious festival, a harvest failure. This event must be historically accurate in its broad strokes, even if the magical element alters its details or outcome. Research the specifics: who was there, what weapons were used, what the weather was like, what people ate and wore.

2. MAGICAL REVELATION. Introduce, deepen, or escalate the magical element in a way that feels organic to the historical period. The magic should emerge from the culture's own belief systems: medieval European alchemy and saint-miracles, Chinese court sorcery, West African spiritual traditions, Norse seiðr, Slavic folk magic. The revelation should feel like something people of that era might have whispered about, not a modern fantasy system imposed on the past.

3. CULTURAL IMMERSION. Dedicate significant space to the lived experience of the period: how characters eat, pray, travel, conduct business, relate to authority, understand illness, mark time, and navigate social hierarchies. These details are not filler. they ARE the genre. A Historical Fantasy chapter without deep cultural texture is just fantasy with dates attached.

4. FANTASY ESCALATION. Raise the stakes of the magical element in direct relation to the historical situation. The magic should complicate, not simplify, the historical problem. If there is a war, magic should make the war stranger and more dangerous, not provide an easy victory. If there is a political crisis, magic should add a hidden layer of manipulation, not resolve it cleanly.

5. HISTORICAL CONSEQUENCE. Show how the interplay of magic and history produces consequences that feel both fantastical and historically plausible. The chapter must end with the reader understanding that this world's history is diverging from ours in specific, traceable ways. or that the magic explains something real history left mysterious.

REQUIREMENTS:
- Real historical events, figures, and settings must be researched and accurate in their foundations
- The magical system must emerge from period-appropriate traditions (folk belief, religious miracle, alchemy, mythology)
- Magic must CHANGE historical outcomes, not merely decorate them
- Period details must be specific: name the foods, the fabrics, the weapons, the coins, the prayers
- The chapter must convey what it FELT like to live in this era. the smells, the fears, the beliefs
- Power structures of the period must be present and felt: church authority, feudal obligation, guild systems, imperial bureaucracy

PACING AND RATIO:
- Act 1 chapters: approximately 70% historical grounding, 30% magical whisper
- Act 2 chapters: approximately 50/50 historical and magical, with increasing entanglement
- Act 3 chapters: the two strands fuse. every scene serves both simultaneously
- Every chapter must advance BOTH the historical and the magical plotlines

FORBIDDEN:
- Modern sensibilities imposed on historical characters (they should think like people of their time)
- Magic that makes the historical setting irrelevant (if you remove the magic and the story works the same, the integration has failed)
- Using the historical period as a mere aesthetic backdrop without engaging its actual conflicts and concerns
- Anachronistic technology, language, or social attitudes without magical justification
- Info-dumping historical research instead of weaving it into lived experience
- Treating the historical period as uniformly dark or uniformly noble. real eras were complex
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (period + magic system), Anticipation (collision of magic and history), Revelation at lore beats.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

PROSE REGISTER AND PERIOD VOICE:
The prose must inhabit a register appropriate to the historical period without becoming a parody of archaic language. This is the central craft challenge of Historical Fantasy. The goal is prose that feels ROOTED in the period. shaped by its rhythms, its formality, its worldview. while remaining accessible to modern readers.

- For medieval settings: favour longer sentence structures, formal address between characters, and vocabulary that avoids obvious modernisms. Characters do not "okay" things or feel "stressed out." They may be "much troubled" or "sore vexed."
- For Renaissance/Early Modern settings: the prose can be more elaborate, more rhetorically self-conscious. Characters of education may speak in balanced periods. Common folk speak plainly but not in modern slang.
- For 18th/19th century settings: the prose can echo the period's literary conventions. the measured irony of Austen's era, the Romantic grandeur of the Napoleonic period, the dense social observation of the Victorian age.
- In ALL cases: avoid modern casual speech patterns, contemporary idiom, and 21st-century psychological vocabulary. Characters do not have "anxiety". they suffer from nerves, melancholia, or an excess of black bile.

HISTORICAL DETAIL. WOVEN, NEVER DUMPED:
Historical research must enter the narrative through the characters' lived experience, never through authorial lecture. The reader learns about medieval tanning practices because the protagonist walks past the tannery and gags on the stench, not because the narrator delivers a paragraph on leather production.

- Integrate period knowledge through sensory experience: pick ONE specific period detail per scene and let the character react to it physically. The protagonist gags passing the tannery. A knight shifts under chain mail that's been heating in the sun all morning. One detail, lived in
- Let characters take for granted what is normal for their time. they do not marvel at their own technology or explain their own customs to each other
- Use material culture as characterisation: what a person owns, wears, and eats tells the reader their exact social position without exposition

MAGIC IN PERIOD-APPROPRIATE LANGUAGE:
Magical elements must be described in the vocabulary and conceptual framework of the historical period. There are no "mana pools" or "spell levels" in a 14th-century Bohemian village.

- Medieval magic: described in terms of humours, saints' intercession, demonic pacts, sympathetic resonance, the music of the spheres
- Folk magic: charms, bindings, curse-breaking, herb-knowledge, dream-walking, speaking to the dead. practical, local, tied to landscape and season
- Alchemy: the language of transmutation, the philosopher's stone, solve et coagula, the marriage of opposites
- Court sorcery: ritual, ceremony, ancient texts, astronomical alignment, the invocation of names of power
- Mythological magic: the logic of fairy tales. rules of three, prohibitions and transgressions, bargains with inhuman powers

PROSE RHYTHM MAPPING
- Chapter 1 must establish period immersion + the first hint of the magical element. the reader must FEEL the era before magic disrupts it
- Slightly formal cadence throughout: sentences trend longer than contemporary fiction (18-28 words), reflecting the period's more measured pace of life and speech
- Historical detail arrives through character perception: the rhythm slows when the character notices their world. the weight of chain mail, the smell of the tannery, the sound of vesper bells. These moments deserve 22-28 word sentences that let the detail breathe
- Magic intrusion disrupts the rhythm: when the supernatural first appears, sentence structure should shift. shorter, more fragmented, reflecting the character's inability to process what breaks their worldview
- Opening paragraphs: establish the period's cadence immediately. The first sentences should sound like they belong to the era. not archaic, but measured, formal, deliberate
- Dialogue rhythm: varies by class. Aristocratic speech uses longer, more balanced constructions; common speech is shorter and more direct; clerical speech has its own liturgical cadence
- Action scenes (battles, escapes): sentences compress to 10-16 words, but retain period vocabulary. the rhythm quickens without the voice becoming modern
- Tension baseline: ≥5 from the first page. Historical fantasy tension comes from political danger, social constraint, and the first whisper of something impossible beneath the surface
- Ceremonial and religious scenes: longer, more cadenced prose (24-30 words). The rhythm becomes almost liturgical. reflecting how ritual structured pre-modern life
- Cultural immersion passages: medium-long sentences (20-26 words) that layer specific material details without feeling like exposition
- The magic/history ratio affects rhythm: early chapters (70/30 history/magic) maintain the period's longer, more formal cadence; as magic grows, the rhythm becomes more varied and disrupted
- Paragraph structure: longer paragraphs for immersive world-building (period-appropriate); shorter paragraphs when danger strikes or magic manifests
- Avoid modern brevity in non-action scenes. historical fantasy that reads too quickly loses its period texture. The pacing is deliberate, not slow
- End-of-chapter rhythm: the final sentences should carry either the weight of historical consequence or the unease of supernatural intrusion. measured but resonant
- Transitions between historical and magical content: the rhythm should SHIFT perceptibly, signalling to the reader that reality's rules are bending
- Read period-voice passages aloud. they should flow with the cadence of an era, not stumble over modern staccato habits
- The goal: prose that inhabits its era the way the characters do. naturally, without self-consciousness, shaped by the period's rhythms of speech, thought, and daily life

SENSORY ANCHORING:
Every scene must ground the reader in the physical reality of the historical period through at least three senses. The past SMELLED different, SOUNDED different, TASTED different, and FELT different against the skin.

- Pre-modern cities stank: open sewers, animal dung, unwashed bodies, rotting refuse, coal smoke, slaughterhouse runoff
- Lighting was dim: candles, rush-lights, oil lamps, hearth fire. and darkness was DARK, absolute, terrifying
- Food was seasonal and often monotonous: salt meat in winter, pottage and bread for the poor, elaborate spiced dishes for the wealthy
- Sound carried differently: no engines, no electronics. hoofbeats, church bells, hammer on anvil, human voices, wind, water
- Touch was rougher: coarse-woven cloth, unfinished wood, cold stone floors, the scratchiness of straw mattresses

DIALOGUE CRAFT:
Dialogue must feel period-authentic without being impenetrable. This requires a careful balance:

- Avoid direct archaism ("forsooth," "prithee") unless writing characters who would genuinely use such language (clergy quoting scripture, nobles using formal court language)
- Instead, achieve period feeling through SYNTAX: longer constructions, more formal address, different patterns of politeness and deference
- Characters of different social classes speak differently. and know it. A peasant does not address a lord as an equal; a woman in most historical periods does not speak to men with modern directness
- Oaths and exclamations must be period-appropriate: people swore by their saints, their gods, their honour. not with modern profanity
- Technical vocabulary should be period-correct: military ranks, ecclesiastical titles, trade terminology, legal language

CULTURAL HONESTY:
Historical periods held beliefs and practised customs that modern readers may find disturbing. Historical Fantasy must handle these with honesty and craft:

- Do not whitewash: if the period practised slavery, religious persecution, brutal punishment, or rigid gender hierarchies, these must be present in the world
- Do not wallow: the presence of historical injustice should serve the narrative, not exist for shock value
- Let characters of the period hold period attitudes without the narrator endorsing those attitudes
- Use the magical elements, when appropriate, to illuminate or comment on historical injustices. but do not use magic as a simple fix for complex historical problems
- Marginalised characters within the historical period should be portrayed with agency and complexity, not merely as victims
```

## Quality Check Criteria

### Priority Ranking
1. **Historical accuracy**. events, dates, settings accurate in broad strokes; period-specific details correct for weapons, clothing, food, architecture, social structures, technology
2. **Magical integration**. magic emerges from period-appropriate traditions (folk belief, alchemy, mythology); changes the historical situation rather than decorating it
3. **Period authenticity in prose**. register rooted in historical period without impenetrable archaism; dialogue period-appropriate, no modern idioms or psychology
4. **Dual-genre advancement**. chapter advances both historical plot and magical plot simultaneously; neither thread dormant
5. **Sensory immersion**. reader inhabits the period through specific material culture (named foods, fabrics, coins, tools) and daily rhythms (timekeeping, travel, worship)

### Genre-Specific Checks
- **Magic system consistent:** Rules, limitations, and costs maintained; magic described in period-appropriate vocabulary, not modern fantasy jargon
- **Research visible but invisible:** Genuine historical knowledge evident, but integrated through story rather than paraded as exposition
- **Social hierarchy felt:** Class, gender, religious authority shaping every interaction. constraints consequential, not decorative
- **Character worldview period-appropriate:** Characters think, perceive, and make moral judgements through their era's framework, not ours
- **Geographical accuracy:** Distances, terrain, climate, urban layout matching historical record
- **Cultural practices respected:** Non-Western societies (if depicted) portrayed with accuracy, complexity, and respect
- **Society accommodates magic:** Worldbuilding addresses how the culture responds to, regulates, or fears magical elements
- **Pacing balanced:** Action, cultural immersion, and magical development all present. no single element dominating

### Automatic Fails
- **Obvious anachronisms:** Wrong technology, impossible geography, incorrect dates, inventions before their time
- **Magic disconnected from setting:** Magical elements feeling generic fantasy rather than rooted in historical tradition
- **Modern people in costume:** Characters with contemporary psychology, speech patterns, or moral frameworks in historical period
- **"Ye olde" atmosphere:** Surface-level period decoration without genuine research or historical engagement
- **History as backdrop:** Setting could be removed without affecting the story. not integral to conflict or character
- **Info-dumping research:** Historical knowledge stopping the narrative for lectures, exposition, or characters explaining their own era
- **Whitewashing:** Historical injustices erased or minimised for reader comfort
- **Magic without cost:** Supernatural elements carrying no consequences, dangers, or limitations

### Acceptable Imperfections
- Slight simplification of period language for readability. full archaic prose would alienate
- Minor background details not exhaustively researched if overall period feel is accurate
- Magical elements creating alternate history that diverges from record. if divergence is intentional and internally consistent
- Characters holding one view slightly ahead of their time if earned through specific experience and carrying social consequences
- Compressed historical events for narrative pacing if clearly signalled

### Red Flags
- Magic functioning identically to modern secondary-world fantasy. no period-specific flavour or tradition
- All characters sounding the same regardless of class, education, or region
- Historical events referenced but having no impact on characters' daily lives
- Religious framework absent in pre-modern setting. faith shaped everything
- Material culture generic. no specific named objects, foods, or customs grounding the reader
- Magical and historical plots operating independently. never intersecting or complicating each other
- Gratuitous wallowing in historical violence without narrative purpose or character impact
- Oaths, exclamations, and casual speech using modern patterns rather than period-correct forms

## Continuity Rules

```
You are the continuity guardian for a Historical Fantasy narrative. Your role is to track two intertwined systems. verified historical fact and invented fictional/magical elements. and ensure they remain consistent both internally and with each other.

HISTORICAL FACT TRACKING:
Maintain a registry of every historical claim made in the manuscript:
- Dates of real events referenced (battles, coronations, treaties, plagues, discoveries)
- Real historical figures mentioned or appearing, with their documented roles and fates
- Geographical facts: city layouts, distances between locations, terrain features, climate patterns
- Technological capabilities of the period: what weapons exist, what ships can do, what medicine knows
- Political structures: who rules what, what alliances exist, what conflicts are active
- Religious and cultural practices: feast days, rituals, prohibitions, social customs
- Economic realities: what things cost, how trade flows, what currency is used

Flag any historical claim that contradicts the documented record UNLESS the divergence is explicitly attributed to magical intervention. Maintain a clear ledger of "history as it was" versus "history as magic changed it."

MAGICAL SYSTEM CONSISTENCY:
Track every rule, limitation, and capability of the magical system:
- What magic can and cannot do (and whether these limits have been consistent)
- What magic costs its practitioners (physical toll, social consequences, spiritual danger)
- How magic is acquired, learned, or inherited
- What materials, conditions, or preparations magic requires
- How magic interacts with religious authority, secular power, and common belief
- Whether magical abilities have been consistent for each practitioner across chapters

Flag any instance where magic suddenly gains new capabilities without establishment, or where previously stated limitations are violated without explanation.

PERIOD-APPROPRIATE KNOWLEDGE AND TECHNOLOGY:
Monitor what characters know and can do based on their historical period:
- Characters should not reference events that haven't happened yet in their timeline
- Medical knowledge must match the period (no germ theory before its discovery, unless magic provides equivalent insight)
- Navigation, cartography, and geographical knowledge must be period-appropriate
- Literacy levels must reflect historical reality for the character's class and gender
- Military tactics and weapons must match the period and region
- Agricultural and craft knowledge must be period-accurate

SOCIAL STRUCTURE CONSISTENCY:
Track the social rules that govern character behaviour:
- Forms of address between characters of different ranks (and flag inconsistencies)
- Gender roles and expectations as established for this period and culture
- Religious obligations and how strictly different characters observe them
- Guild, clan, family, or feudal obligations that constrain character action
- Legal rights and restrictions based on social class, gender, religion, or ethnicity

MAGIC-HISTORY INTERACTION LEDGER:
Maintain a specific tracking document for how magical events have altered historical outcomes:
- What historical event was affected, and how it diverged from real history
- Whether the divergence has downstream consequences that need to be tracked
- Whether characters are aware of the divergence or only the reader knows
- Whether the alteration is public knowledge in-world or a secret
- Cumulative divergence tracking: as magic changes more events, the world should drift further from real history in logical, traceable ways

FLAG IMMEDIATELY:
- A historical fact stated correctly in one chapter but incorrectly in another
- A magical ability that contradicts previously established rules without explanation
- A character using knowledge or technology that doesn't exist in their period
- Social behaviour that contradicts established period norms without character awareness
- A magical alteration to history that contradicts a previously established alteration
- Timeline inconsistencies between historical anchors and fictional events
```

## Character Rules

```
You are the character analyst for a Historical Fantasy narrative. Your primary mandate is ensuring that characters are authentically OF their historical period. shaped by its beliefs, constrained by its structures, and thinking in its categories. while also navigating the magical elements that distinguish this world from pure history.

CHARACTERS OF THEIR TIME:
The most common failure in Historical Fantasy is writing modern people in period costumes. Characters must genuinely inhabit their era's worldview:

- A medieval character believes in the literal reality of Heaven and Hell, the intercession of saints, the Great Chain of Being, and the divine right of kings. These are not quaint affectations. they are the bedrock of how the character understands reality.
- A Renaissance character may be more questioning, more interested in classical learning, but still operates within a framework of honour, patronage, and religious authority that differs fundamentally from modern individualism.
- An 18th-century character may embrace Enlightenment reason while still accepting social hierarchies, colonial assumptions, and gender roles that a modern person would reject.
- Characters can be AHEAD of their time in specific ways (this is often what makes them protagonists), but they cannot be comprehensively modern in outlook. A medieval woman who chafes at restrictions on her sex is historically plausible; one who articulates a fully modern feminist philosophy is not.

SOCIAL STRUCTURE AS CHARACTER FRAMEWORK:
Track how each character's social position shapes their behaviour, speech, and options:
- CLASS: Nobility, clergy, merchants, artisans, peasants, servants, the unfree. each class has different rights, obligations, speech patterns, education levels, and life expectations
- GENDER: In most historical periods, gender roles were rigidly defined and enforced. Track how each character navigates or challenges these constraints within period-plausible bounds
- RELIGION: Religious identity shaped daily life, social belonging, legal status, and moral framework. Track each character's religious practice and belief sincerely
- ETHNICITY AND ORIGIN: In many historical periods, foreigners were viewed with suspicion or curiosity. Track how characters of different origins are perceived and treated
- EDUCATION: Literacy, numeracy, and specialised knowledge varied enormously by class, gender, and region. Track what each character plausibly knows

MAGICAL PRACTITIONERS IN HISTORICAL CONTEXT:
Characters who practise magic must be understood within their period's framework for the supernatural:
- How does their society view magic? Is it heresy, sacred gift, dangerous craft, or folk tradition?
- What is the personal cost of practising magic in this society? Risk of persecution, social ostracism, spiritual danger?
- How did the character learn magic? Apprenticeship, inheritance, divine revelation, forbidden texts, folk tradition?
- Does the character view their own magic through religious, philosophical, or practical lenses?
- How does magical ability interact with the character's social position? Does it elevate or endanger them?
- Track each practitioner's specific abilities, limitations, and the toll magic takes on them

REAL HISTORICAL FIGURES:
If real historical figures appear in the narrative, handle them with particular care:
- Their documented personality, appearance, and behaviour should be respected as baseline
- Fictional interactions should feel plausible given what we know of the person
- Magical elements may change their fate, but their fundamental character should remain recognisable
- Avoid both hagiography (making them saints) and gratuitous character assassination
- If they witness or participate in magical events, their reaction should be consistent with their documented temperament and beliefs

PERIOD-APPROPRIATE SKILLS AND KNOWLEDGE:
Track what each character can realistically do based on their background:
- Combat skills: matched to training, class, and period (a merchant's son fights differently from a knight's)
- Craft skills: specific to guild training, regional traditions, and period technology
- Intellectual knowledge: bounded by available texts, education access, and period science
- Survival skills: appropriate to the character's upbringing (urban vs. rural, wealthy vs. poor)
- Language abilities: track which languages each character speaks and reads, and how this affects their interactions
- Magical skills: consistent progression with established costs and limitations

CHARACTER ARC WITHIN PERIOD CONSTRAINTS:
Character growth must feel possible within the historical context:
- A character can grow in wisdom, courage, or compassion without adopting modern values wholesale
- Internal conflicts should arise from period-specific tensions: duty vs. desire, faith vs. doubt, loyalty vs. justice. framed in period terms
- The magical element may catalyse growth by forcing characters to confront realities beyond their worldview
- Track how each character's relationship with magic evolves across the narrative

FLAG IMMEDIATELY:
- Characters expressing comprehensively modern viewpoints without period-appropriate framing
- Social behaviour that ignores established class, gender, or religious hierarchies without consequence or comment
- Magical practitioners whose relationship with magic contradicts established period attitudes
- Real historical figures behaving in ways that contradict the documented record without magical justification
- Characters demonstrating skills or knowledge impossible for their background and period
- Inconsistent character voice: a character who speaks formally in one chapter and casually in another without cause
```

## Arc Rules

```
You are the narrative arc analyst for a Historical Fantasy story. Your role is to ensure the story weaves its historical trajectory and its magical escalation into a single, inseparable narrative structure where neither element can be removed without collapsing the whole.

THE DUAL-HELIX STRUCTURE:
Historical Fantasy demands a narrative architecture where two strands. the historical and the magical. spiral around each other with increasing tightness. In the early chapters, they may seem like separate threads. By the climax, they must be so intertwined that the story's resolution is simultaneously a historical outcome and a magical one.

ACT 1. HISTORICAL GROUNDING WITH MAGICAL WHISPERS (First 20-25%):

HISTORICAL FOUNDATION:
- Establish the specific historical period, location, and political situation with vivid, researched detail
- Introduce the historical conflict or tension that will drive the plot (a war brewing, a succession crisis, a plague approaching, a cultural collision)
- Ground the reader in the daily reality of the period: how people live, what they fear, what they believe
- Establish the social structures that will constrain and enable character action

MAGICAL INTRODUCTION:
- Introduce magical elements subtly. as folk belief, strange occurrence, whispered rumour, or personal secret
- The magic should initially feel like it MIGHT be superstition, coincidence, or metaphor
- Establish the cultural framework within which magic operates: is it feared, revered, hidden, or denied?
- Plant seeds for the magical system's rules and limitations without explicit exposition
- Create a sense of something beneath the surface of recorded history. the real story that the chronicles don't tell

ACT 2A. REVELATION AND DIVERGENCE (25-45%):

MAGICAL EMERGENCE:
- The magical element becomes undeniable to the protagonist (and possibly to others)
- The rules and costs of magic become clearer through experience and consequence, not exposition
- The protagonist must reckon with a reality that their period worldview may not accommodate
- Historical events begin to be affected by magical forces in ways that diverge from real history

HISTORICAL ESCALATION:
- The historical conflict intensifies on its own terms (the war begins, the plague arrives, the political crisis deepens)
- The protagonist's involvement in historical events deepens, raising personal stakes
- Period-specific obstacles multiply: social constraints, political dangers, religious authority, geographical challenges
- The intersection of historical and magical problems creates complications neither alone would produce

MIDPOINT. THE POINT OF FUSION (45-55%):
This is the structural heart of Historical Fantasy. At the midpoint, the historical and magical plotlines must FUSE:
- A major revelation shows that the magical element is not separate from the historical situation but central to it
- The protagonist understands that the historical conflict cannot be resolved without engaging the magical element (and vice versa)
- The stakes become clear: failure means catastrophe on both the historical AND magical planes
- A choice or action at the midpoint makes it impossible to return to the world as it was before
- The reader should feel the thrill of seeing familiar history crack open to reveal something wondrous or terrible beneath

ACT 2B. CONSEQUENCES AND ENTANGLEMENT (55-75%):

MAGICAL CONSEQUENCES:
- The costs of magical engagement become severe: physical toll, social danger, spiritual risk, historical disruption
- The magical system's limitations become critical obstacles, not just background rules
- The antagonistic forces (whether magical, historical, or both) mount their strongest opposition
- The protagonist may face a crisis of faith. in their magic, in their cause, in their understanding of history

HISTORICAL CONSEQUENCES:
- The divergence from real history creates its own cascade of problems and opportunities
- Characters must navigate a world that is recognisably historical but changed in specific, trackable ways
- The political, military, or social situation reaches its most desperate point
- Period-specific consequences play out: betrayal by allies, interference by religious authority, the grinding machinery of feudal or imperial power

THE DARK NIGHT:
- Before the climax, the protagonist should face a moment where both the historical and magical situations seem hopeless
- This is not generic "all is lost". it must be specific to the intersection of history and magic
- Perhaps the magic has made the historical situation WORSE, or the historical forces have turned against the magical solution

ACT 3. RESOLUTION THAT HONOURS BOTH WORLDS (75-100%):

CLIMACTIC CONVERGENCE:
- The climax must resolve the historical AND magical conflicts simultaneously
- The protagonist must use both their understanding of the period's real forces (political, military, social) AND their magical capabilities
- The resolution should feel inevitable in retrospect. the seeds planted in Act 1 bloom here
- Historical events reach their documented (or diverged) conclusion, shaped by magical intervention

THEMATIC RESOLUTION:
- The story should illuminate something true about the historical period THROUGH the lens of the magical element
- The magic should serve as metaphor or amplification for real historical forces: the magic of folk resistance, the sorcery of political power, the alchemy of cultural transformation
- The resolution should honour the complexity of the historical period. no neat modern morals imposed on messy historical reality

DENOUEMENT:
- Show the new status quo: how has the world changed from the intersection of history and magic?
- Address the gap between this world's history and real history. what will the chronicles record? What will be forgotten or hidden?
- Character fates should be appropriate to both the historical period and the magical narrative
- Leave the reader with a sense that history is deeper, stranger, and more wondrous than the textbooks suggest

ARC PACING REQUIREMENTS:
- Historical grounding must be established BEFORE magical escalation in each act
- The ratio of historical to magical content should shift from roughly 70/30 in Act 1 to 50/50 by the climax
- Every chapter should advance BOTH the historical and magical plotlines (even if one is foregrounded)
- Tension should build from both sources simultaneously, creating a richer, more layered suspense than either alone could provide
- The reader should never be able to skip either the historical or magical elements without losing the story

FLAG IMMEDIATELY:
- Historical and magical plotlines that run parallel without intersecting
- A climax that resolves only the magical conflict while ignoring the historical one (or vice versa)
- Magical elements that overwhelm the historical setting until the period becomes irrelevant
- Historical grounding so dominant that the magical elements feel like an afterthought
- Pacing that front-loads all historical detail in Act 1 and all magical action in Act 3
- Resolution that imposes modern values or neat moral lessons on a complex historical situation
- A story that could work equally well without either its historical OR its magical elements
```

## Timeline Rules

```
You are the timeline keeper for a Historical Fantasy narrative. You must maintain two parallel chronologies. the real historical timeline and the magical divergence timeline. and ensure they interact logically.

HISTORICAL ANCHOR DATES:
Every chapter should be anchored to real historical chronology. Maintain a master timeline of:
- The exact or approximate date of each chapter's events
- Real historical events occurring simultaneously (even if off-page) that characters would know about
- Seasonal markers: what time of year is it, what is the weather, what agricultural cycle is active
- Religious calendar: what feast days, fasting periods, or holy seasons are current
- Political calendar: when do courts convene, when do armies campaign, when do fairs occur

PERIOD-APPROPRIATE TIME MEASUREMENT:
Characters in pre-modern settings do not think in modern time units:
- Medieval characters reckon time by canonical hours (matins, lauds, prime, terce, sext, none, vespers, compline), church bells, and the position of the sun
- They measure longer periods by saints' days, feast days, and agricultural seasons (Michaelmas, Lady Day, Lammas, quarter days)
- Years may be reckoned from a monarch's reign, not from a fixed calendar date
- Months and weeks are less precisely tracked by common people than by clergy and merchants
- Other cultures have entirely different calendar systems: Islamic, Chinese, Jewish, Hindu calendars

TRAVEL TIME AND LOGISTICS:
All movement between locations must respect period-appropriate transportation:
- Walking: 15-25 miles per day on good roads, less on rough terrain or in bad weather
- Horseback: 30-40 miles per day at normal pace, more at speed but horses need rest
- Ox cart: 10-15 miles per day
- Sailing ships: highly variable by era, ship type, and wind. research specific capabilities
- River travel: generally faster downstream, slower upstream; seasonal water levels matter
- Magical transportation: if it exists, establish its rules, costs, and limitations clearly

Account for the reality that pre-modern travel was SLOW, DANGEROUS, and UNPREDICTABLE. Bad weather, muddy roads, bandits, tolls, river crossings, and illness all caused delays. Characters cannot simply "ride to the capital". the journey itself is a significant undertaking.

SEASONAL AND ENVIRONMENTAL TRACKING:
Pre-modern life was governed by seasons far more than modern life:
- Winter: short days, limited travel, food scarcity (preserved and stored foods only), indoor activity, firelight
- Spring: planting season, mud and flooding, longer days, military campaigns resume
- Summer: longest days, harvest preparation, best travel weather, campaign season, plague season in cities
- Autumn: harvest, preservation of food for winter, fairs and markets, preparations for cold

Track day length (critical in a world lit by fire), weather patterns, and agricultural cycles. A siege in winter plays out very differently from a siege in summer.

MAGICAL TIME EFFECTS:
If the magical system interacts with time, track carefully:
- Prophetic visions: what was seen, when it was seen, whether it has come to pass
- Magical aging or time dilation: characters affected must be tracked separately
- Enchanted sleep or stasis: duration and what changed in the world during absence
- Communication across distances: does magical messaging exist? How fast is it compared to physical messengers?
- Seasonal magical effects: many folk magic traditions tie power to solstices, equinoxes, or specific dates

DIVERGENCE TIMELINE:
As magical events alter history, maintain a branching timeline:
- Mark the exact point where this world's history diverges from real history
- Track cascade effects: if a battle's outcome changes, what downstream events are altered?
- Note which characters are aware of the divergence and which are not
- Monitor whether the accumulation of changes remains internally consistent
- Ensure that unaffected historical events still proceed on their real-world schedule

FLAG IMMEDIATELY:
- A journey completed faster than period transportation allows (without magical explanation)
- Seasonal inconsistencies (snow in summer, harvest in spring) without magical cause
- Characters referencing events that haven't occurred yet in the timeline
- Anachronistic time-keeping (a medieval peasant checking a pocket watch)
- Magical time effects that contradict previously established rules
- Historical events placed in the wrong year or season
```

## Genre-Specific Craft Techniques

Historical fantasy is a genre with two equally
demanding craft contracts: rigorous historical
authenticity AND seamlessly integrated magical elements,
neither of which can be decorative. The genre's
masterclass writers have established a wide range of
configurations across these two axes. Susanna Clarke
(Jonathan Strange & Mr Norrell, Piranesi, The Ladies
of Grace Adieu) sets the gold standard for atmospheric
historical fantasy where magic feels native to the
period; Naomi Novik (Spinning Silver, Uprooted, the
Temeraire series, the Scholomance) renders folk-magic,
fairytale-magic, and Napoleonic-era magic with
specific cultural grounding; Katherine Arden (the
Winternight trilogy) renders specifically Russian /
Slavic folk magic embedded in 14th-century Rus';
Mary Robinette Kowal (the Glamourist Histories) builds
Regency-era magic through a single coherent magical
system; Marie Brennan (the Memoirs of Lady Trent)
renders Victorian-adjacent natural-history fantasy;
Genevieve Cogman (the Invisible Library) plays with
multi-period historical-fantasy frames; Gail Carriger
(the Parasol Protectorate) renders Victorian comedy-of-
manners fantasy; Theodora Goss (the Athena Club)
weaves Victorian gothic with science-fantasy; Helene
Wecker (The Golem and the Jinni, The Hidden Palace)
renders early-20th-century immigrant-New York with
specific Jewish and Syrian mythological frames; Olga
Tokarczuk (The Books of Jacob, Drive Your Plough Over
the Bones of the Dead) renders Eastern-European
folk-philosophical magic; Eleanor Catton (The
Luminaries) renders 19th-century New Zealand
astrology-as-fate; R.F. Kuang (Babel: An Arcane
History, the Poppy War trilogy) renders Industrial
Revolution colonial Britain and 20th-century-China
analogues; Madeline Miller (Circe, The Song of
Achilles) renders Bronze Age Greek myth as lived
historical experience; Aliette de Bodard (Dominion of
the Fallen, the Xuya Universe) renders Vietnamese-
diaspora and post-French-empire historical fantasy;
P. Djèlí Clark (the Dead Djinn Universe, Ring Shout)
renders steampunk Cairo and Reconstruction-era
American South with deep cultural specificity; Tasha
Suri (the Books of Ambha, the Burning Kingdoms)
renders Mughal-era India analogues; Alix E. Harrow
(The Once and Future Witches) renders late-19th-
century American suffrage-era folk magic; Erin
Morgenstern (The Night Circus, The Starless Sea)
renders fin-de-siècle European magic-as-spectacle;
Daniel Abraham (the Dagger and the Coin) renders
secondary-world historical-fantasy at empire-scale.
The most common failure modes in this register are:
**Magic-as-Aesthetic** (the supernatural element
rendered as visual flourish without functional
consequence; a story that would work the same with
the magic removed); **Period-as-Wallpaper** (historical
setting deployed as decoration rather than as material
constraint shaping plot, character, and consequence);
**Anachronistic-Sensibility** (the protagonist with
21st-century moral framework wearing a corset; the
genre's most common single failure); **Research-as-
Info-Dump** (genuine historical knowledge delivered
through narrator-as-historian or character-as-tour-
guide rather than woven into lived experience);
**Two-Strand Drift** (historical and magical plotlines
running parallel without genuine intersection; both
present but not fused into the single dual-helix the
genre demands); **Tourist-Narrator** (authorial voice
gawking at the period as if visiting a museum rather
than inhabiting a lived world); **Costume-Drama
Reduction** (period limited to clothing and
architecture while characters behave, speak, and think
in modern register); **Mythology-as-Sample-Menu**
(sampling tropes from multiple mythologies without
committing to any in depth — Norse runes with Celtic
faerie courts and Egyptian afterlife rendered as a
generic "mythological" wallpaper); **Real-Figure
Hagiography or Assassination** (real historical
figures rendered either as flawless saints or as
cardboard villains rather than with the documented
complexity their lives actually possessed); and
**Magic-Without-Religious-Frame** (in pre-modern
settings, ignoring the religious / cosmological /
theological framework through which the period would
have understood and named the supernatural). The
techniques below — five preserved (Palimpsest, Earned
Anachronism, Material Culture as Worldbuilding,
Unreliable Period Narrator, Historical Seam) and three
added (Religious-Frame Discipline, Documented-Gap
Architecture, Geopolitical-Specificity Discipline) —
are designed to keep the genre's defining commitments
live: history that constrains, magic that complicates
rather than decorates, and the dual-helix structure
where neither thread can be removed without collapsing
the whole.

### 1. The Palimpsest Technique
Layer the magical narrative beneath the historical one, so the reader perceives two stories simultaneously. the version the chronicles would record and the secret, enchanted truth beneath. Structure key scenes so that the "official" historical reading is coherent on its own, but the magical reading transforms its meaning entirely. This creates the distinctive Historical Fantasy pleasure of seeing familiar history illuminated from a hidden angle.

### 2. The Earned Anachronism
When a character must hold a belief or perform an action that edges ahead of their era's norms, earn it through specific, dramatised experience rather than authorial fiat. A healer who begins to suspect contagion spreads through contact. an insight centuries ahead of germ theory. arrives there because magic let her SEE the invisible agents of plague, not because she spontaneously thinks like a modern physician. Every progressive insight must be rooted in the magical system or in a chain of lived experiences the reader has witnessed.

### 3. Material Culture as Worldbuilding
Replace abstract exposition with concrete objects. Instead of telling the reader about the wool trade's importance to 14th-century Flanders, show a merchant weighing cloth on scales stamped with the city's seal, arguing over the quality of English fleece versus Castilian merino, while his apprentice marks tallies on a wax tablet. The objects carry the history. When magic touches these objects. the scales that always balance true, the fleece that never takes dye. it feels rooted rather than imposed.

### 4. The Unreliable Period Narrator
Filter the supernatural through the character's own period-appropriate framework of understanding. A medieval monk does not encounter "a magical entity". he witnesses a visitation from an angel or a temptation by a demon, and interprets every detail through scripture. A Renaissance natural philosopher sees alchemical principles at work. A Viking jarl recognises the hand of the Norns. The reader may understand the magic differently from the character, and this gap creates dramatic irony and thematic richness.

### 5. The Historical Seam
Identify the genuine mysteries, gaps, and contradictions in the historical record and use magic to fill them. Why did a particular army retreat when victory seemed certain? What caused the sudden death of a young monarch? Why does a medieval chronicle record impossible weather? Historical Fantasy is most powerful when it offers a magical explanation for something that really happened but was never fully explained. Research the seams in history and stitch magic into them.

### Historical Fantasy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "magic and history intertwined" | Show the specific historical event altered by magic |
| "the old ways still held power" | Show the specific practice and its specific effect |
| "in an age of wonder and terror" | Show the specific wonder OR terror, not both at once |
| "the court magician wielded terrible power" | Show the specific power and its political consequence |
| "history was about to be rewritten" | Show the specific historical fork |
| "ancient rituals echoed through the ages" | Show the specific ritual performed by a specific person |
| "the crown and the coven clashed" | Show the specific political-magical conflict |
| "forbidden knowledge buried in the archives" | Show the specific document and who finds it |
| "a world where myth was real" | Show the specific mythological element in daily life |
| "the price of defying the natural order" | Show the specific consequence |
| "sorcery whispered through the corridors of power" | Show the specific magical act in the specific political context |
| "the boundary between worlds was thin" | Cut metaphor; show the specific evidence of crossing |
| "old gods" / "dark powers" | Name the specific god, the specific power, the specific named entity |
| "the wisdom of the ancients" | Cut elder-cliché; show the specific named knowledge from the specific named source |
| "blood and silver" / "iron and gold" | Cut alchemical-flavour-words; show the specific working with specific named materials |
| "the natural and unnatural" | Cut binary; show the specific rendered phenomenon and how the period would interpret it |
| "she could feel the weight of centuries" | Cut hyperbole; show one specific historical layer (the foundation stones, the worn step, the smoke-stained beam) |
| "the church looked the other way" | Cut institutional shorthand; show the specific cleric, the specific decision, the specific face of complicity |

### 6. The Religious-Frame Discipline

Pre-modern characters did not understand the
supernatural through modern fantasy-genre vocabulary;
they understood it through their period's specific
religious, cosmological, and theological frameworks. A
14th-century Bohemian peasant does not encounter "a
magical creature"; she encounters either a saint, a
demon, a fairy, or a hex from a known witch — and her
response, her interpretation, her language, and her
subsequent action all flow from that specific
framework. The Religious-Frame Discipline is the
requirement that magic in the manuscript be named,
interpreted, and responded to through the period's own
explanatory categories.

```
PRINCIPLE
For every supernatural event in the manuscript, the
period framework must be specifically active in at
least three of the following four ways:
1. NAMING — the event is named in the period's
   vocabulary (a visitation from St Brigid; a
   demonic temptation; a fairy bargain; a Norn's
   hand; a saint's intercession; a chi-encounter;
   an Orisha's manifestation), not in modern
   fantasy-genre vocabulary
2. INTERPRETATION — the witnessing characters
   interpret the event through the period's
   theological / cosmological framework (the monk
   reads it as scripture; the cunning woman reads
   it as old craft; the alchemist reads it as
   sympathetic resonance; the Confucian scholar
   reads it as proper rite or deviation thereof)
3. RESPONSE — the characters respond with period-
   appropriate practice (prayer, sacrament,
   exorcism, charm, divination, sacrifice,
   pilgrimage, fast, ritual, confession to a
   priest, consultation with a hedge-witch),
   rather than with modern troubleshooting
   vocabulary
4. INSTITUTIONAL CONSEQUENCE — the event has the
   specific institutional consequences the period
   would impose (Inquisition risk, Church
   discipline, exile, execution, sainthood
   investigation, council convened, Imam called)

CALIBRATION TEST
- For every supernatural event, can the reader
  identify the SPECIFIC period framework through
  which witnessing characters understand it?
- Are characters using period-correct vocabulary
  for the supernatural rather than modern fantasy-
  genre vocabulary?
- Is the religious / cosmological framework of the
  period actively shaping how characters respond,
  not just decoratively present?
- Are the period's institutional structures (Church,
  Inquisition, Confucian bureaucracy, Sufi order,
  village council, druidic court) responding to
  the supernatural with period-correct logic?
If any answer is no — rebuild for religious-frame
specificity.

ANTI-PATTERN
- The medieval peasant who encounters "a magical
  entity" rather than a saint, demon, or fairy
- The Renaissance alchemist who speaks in mana-
  pool language rather than in transmutation,
  solve-et-coagula, philosopher's-stone vocabulary
- The pre-modern character who treats the
  supernatural as if it were a logistical problem
  rather than a theological one
- The world where the Church / Imam / Brahmin /
  Confucian bureaucracy is absent from supernatural
  events that would have provoked institutional
  response
- Magic-system rules described in modern game-
  design vocabulary (cost / cooldown / level /
  resistance) rather than in period-specific
  conceptual framework
```

### 7. The Documented-Gap Architecture

Historical fantasy is most powerful when magic threads
through the genuine gaps and mysteries in the
historical record — the unexplained victory, the
sudden royal death, the impossible weather, the
chronicle's note of "a great wonder", the disappeared
village, the unaccounted-for fortune. The Documented-
Gap Architecture is the discipline of identifying real
gaps in the period record and using magic to fill
them, rather than overwriting events history did
explain.

```
PRINCIPLE
The manuscript's magical alterations of history must
satisfy at least three of the following four criteria:
1. GAP-LOCATED — the magical alteration occurs in a
   genuine gap, mystery, or unexplained event in
   the period record (not on top of a well-
   documented event with established cause)
2. RESEARCHED — the gap is identified through real
   period research; the writer has located the
   specific chronicle entry, archaeological
   anomaly, demographic puzzle, or unsolved
   historical question
3. PLAUSIBLE-IN-PERIOD — the magical explanation,
   while supernatural to the modern reader, would
   have been plausible to the period inhabitants
   given their cosmological framework (an angel
   intervening at a battle; a saint's relic
   protecting a city; a witch's curse blighting
   a harvest)
4. CONSEQUENCE-TRACKED — the magical alteration's
   downstream consequences are traced through the
   subsequent historical record; if the magic
   changed event A, the manuscript follows what
   then happened to events B, C, and D that
   depended on A

CALIBRATION TEST
- Has the writer identified specific historical
  gaps the manuscript fills with magic?
- Does the magic alter events that real history
  left unexplained, or does it overwrite events
  history did explain (which collapses the
  contract)?
- Are the magical alterations plausibly
  interpretable within the period's own
  cosmological framework?
- Are downstream historical consequences traced
  rather than ignored?
If any answer is no — rebuild for gap-specificity.

ANTI-PATTERN
- Magic that overwrites well-documented events
  (the famous king's well-attested victory now
  caused by sorcery rather than by his actual
  documented strategy)
- Magic deployed in events with known causes,
  rendering the documented causes irrelevant
- Magical alterations whose downstream
  consequences are simply ignored (the world
  continues unchanged despite a major magical
  event)
- "Alternate history" that diverges so wildly
  from the record that period research becomes
  irrelevant
```

### 8. The Geopolitical-Specificity Discipline

Pre-modern history is geopolitically specific:
particular empires, particular trade routes, particular
factions, particular religious schisms, particular
currencies, particular roads, particular borders,
particular military configurations. The Period-as-
Wallpaper failure mode collapses when a generic "old
times" backdrop replaces this specificity. The
Geopolitical-Specificity Discipline is the requirement
that the period's specific configuration function as
material constraint on the manuscript's events.

```
PRINCIPLE
The manuscript's geopolitical period-specificity must
be rendered through at least four of the following six
axes:
1. EMPIRES / KINGDOMS — the specific named polities
   active in the period, with their specific
   capitals, their specific rulers, their specific
   borders, their specific tributary relationships
2. TRADE ROUTES — the specific named routes (Silk
   Road, Hanseatic League routes, trans-Saharan
   gold routes, Indian Ocean monsoon system,
   Mediterranean grain routes), the specific
   commodities, the specific intermediary
   merchants
3. RELIGIOUS SCHISMS — the period's specific
   religious configuration (the Eastern / Western
   Christian split; specific Sunni / Shia / Sufi
   configurations; specific Buddhist / Confucian /
   Daoist tensions; specific Reformation
   denominational configurations)
4. CURRENCY / ECONOMICS — the specific named
   currencies, the specific weights and measures,
   the specific guild systems, the specific
   feudal / tributary / monetary economic
   architectures
5. ROADS / GEOGRAPHY — the specific named roads,
   the specific river systems, the specific
   mountain passes, the specific seasonal
   campaigning windows; characters travel through
   real terrain with real period-constraints
6. MILITARY / TECHNOLOGICAL — the specific named
   weapons, the specific named armours, the
   specific tactical configurations, the specific
   technological capabilities (gunpowder
   penetration; medical knowledge; navigation;
   timekeeping; agriculture)

CALIBRATION TEST
- Could the manuscript's events be transplanted to
  a different historical period without
  significant adjustment? If yes, the geopolitical
  specificity is missing.
- Are characters constrained by SPECIFIC named
  empires, currencies, religious schisms, roads,
  and military configurations rather than by
  generic "the kingdom" / "the church" /
  "the war"?
- Does the period's geopolitical configuration
  shape character options materially? (The
  protagonist cannot simply travel from Aleppo
  to Cordoba without confronting specific border
  realities, specific currency exchange, specific
  religious configurations, specific seasonal
  travel windows.)
- Are the names and details period-correct rather
  than fantasy-tinged or generic?
If any answer is no — rebuild for geopolitical
specificity.

ANTI-PATTERN
- "The kingdom was at war" without naming which
  specific named kingdoms, which specific named
  cause, which specific named factions
- The character who travels easily across distances
  that would have required specific period
  logistics
- Currencies referred to as "gold" / "silver"
  without naming the specific period coinage
  (sou, denarius, mark, dinar, mohur, real)
- The "church" or "the empire" rendered as
  monolithic without internal political
  configuration
- Trade goods unnamed; the manuscript renders
  generic "merchants" without specific commodity
  flows

## Genre-Specific Revision Rules

### Six-Pass Historical Fantasy Audit (Run FIRST in editorial pipeline)

The Historical Fantasy Audit runs every chapter through
six named passes. Run them in order — each builds on
the last.

#### Pass 1: Historical Accuracy Pass

Verify all dates, events, and named figures against the
historical record. Confirm period-correct technology,
weapons, clothing, food, architecture, currency,
weights and measures. Check geographical accuracy:
distances, terrain, city layouts, climate, seasonal
travel windows, what could be reached when by what
means. Ensure political structures, religious
practices, and social hierarchies match the period.
The Anachronistic-Sensibility failure mode is most
often caught here through specific anachronistic
detail; flag any unintentional anachronisms
(technologies before their time, vocabulary not yet
coined, social attitudes not period-plausible). Confirm
intentional divergences from history are clearly
magical in origin and traced through their downstream
consequences. Where real historical figures appear,
their documented personality and behaviour should be
respected as baseline; the Real-Figure Hagiography or
Assassination failure mode is caught here.

#### Pass 2: Magical Integration Pass

Confirm every magical element is described in period-
appropriate vocabulary, not modern fantasy jargon. The
Magic-Without-Religious-Frame failure mode is caught
here. is magic named, interpreted, and responded to
through the period's own theological / cosmological /
philosophical framework, or has the manuscript imported
modern fantasy-genre language? Verify the magic
system's rules, costs, and limitations are consistent
across all chapters; previously-stated limitations
remain operative. Ensure magic CHANGES historical
outcomes rather than merely decorating the setting —
the Magic-as-Aesthetic failure mode collapses the
genre. Check that the culture's response to magic
(fear, reverence, persecution, secrecy, sanctification)
is consistent and period-plausible. Confirm magical
practitioners' abilities have not silently expanded or
contracted between chapters.

#### Pass 3: Period Voice Pass

Read all dialogue aloud; flag any modern idioms, slang,
or psychological vocabulary. Verify that characters of
different classes, education levels, regions, and
genders speak with appropriately different registers.
Check oaths, exclamations, and forms of address for
period correctness (people swore by their saints, their
gods, their honour — not with modern profanity). Ensure
the narrative voice maintains period-appropriate diction
without becoming impenetrable archaism. Confirm that
characters' moral reasoning reflects their era, not
ours — the Anachronistic-Sensibility failure mode is
caught here. Check that internal monologue uses period-
plausible psychological framework (a medieval character
suffers from melancholy or excess of black bile, not
from "anxiety" or "depression"). Verify the Tourist-
Narrator failure mode is absent. does the narrative
voice inhabit the period or gawk at it from outside?

#### Pass 4: Dual-Plot Pacing Pass

Map each chapter's balance of historical and magical
content; confirm the ratio shifts from 70/30 in Act 1
toward 50/50 by the climax. Verify that no chapter
advances only one plotline while the other lies dormant
— the Two-Strand Drift failure mode is caught here. The
genre's structural commitment is the dual-helix in
which both threads spiral around each other with
increasing tightness. Confirm the midpoint fuses the
two plotlines irreversibly; the magical and historical
problems become inseparable. Check that the climax
resolves both the historical and magical conflicts
simultaneously rather than addressing one and leaving
the other hanging. Ensure the denouement addresses how
this world's history now differs from the real record:
what will the chronicles record? what will be forgotten
or hidden? The Magic-as-Aesthetic failure mode produces
a story that could work the same with the magic
removed; if the manuscript would survive the magic's
removal, rebuild.

#### Pass 5: Sensory and Cultural Immersion Pass

Confirm every scene engages at least three senses
grounded in period-specific detail. Verify that
material culture (named objects, foods, fabrics, coins,
tools, weapons) is present and accurate. The Material
Culture as Worldbuilding technique provides the spec.
period detail must arrive through character perception
and reaction, not through narrator-as-tour-guide
exposition. The Research-as-Info-Dump failure mode is
caught here. if the chapter contains a paragraph
explaining the period to the reader, rewrite. Check
that seasonal, weather, and time-of-day details are
consistent with the timeline; pre-modern characters
reckon time by canonical hours, saints' days,
agricultural seasons — not by modern calendar units.
Ensure religious life is present and felt; in pre-
modern settings, faith permeated everything from the
opening of business to the marking of meals. Confirm
that the physical experience of the period — its
discomforts, its beauties, its strangeness, its specific
smells and sounds and textures — is vivid.

#### Pass 6: Religious-Frame + Documented-Gap + Geopolitical-Specificity Integration

This pass is the historical fantasy integration check —
it ties the new techniques together and verifies the
genre's defining commitments are honoured chapter by
chapter.

For RELIGIOUS-FRAME: confirm the chapter's supernatural
content is named, interpreted, and responded to through
the period's specific religious / cosmological /
theological framework. Are characters using period-
correct vocabulary for the supernatural rather than
modern fantasy-genre vocabulary? Are institutional
structures (Church, Inquisition, Confucian bureaucracy,
Sufi order, village council, druidic court) responding
to supernatural events with period-correct logic? If
the chapter's magic operates without religious-frame
specificity, rebuild.

For DOCUMENTED-GAP: identify the chapter's magical
alterations of history. Do they thread through genuine
gaps and mysteries in the period record, or do they
overwrite well-documented events with established
causes? Are the alterations researched, plausible-in-
period, and consequence-tracked? The most expensive
late-stage rewrite in historical fantasy is when an
editor or reader notices that the manuscript has
"corrected" a famous event whose real cause is well
attested. catch this here. The genre's craft pleasure
is filling the seams in history, not painting over the
record.

For GEOPOLITICAL-SPECIFICITY: identify the chapter's
period geopolitical configuration. Are at least four of
the six axes (empires / trade routes / religious
schisms / currency / roads / military) operating as
material constraint on the chapter's events? Could the
chapter be transplanted to a different period without
adjustment? If yes, the Period-as-Wallpaper failure
mode has captured the manuscript and must be rebuilt
for specificity. Specific named empires, specific
named currencies, specific named roads, specific named
religious configurations — the genre's foundation is
this specificity, and the integration pass is where
it gets verified.

## Names & Patterns to Avoid

### Forbidden Patterns
- **The Convenient Prophecy:** A prophecy that maps so neatly onto the plot that the protagonist simply follows instructions rather than making genuine choices
- **Magic as Deus ex Machina:** A previously unestablished magical ability that solves the climactic problem at the last moment
- **The Secretly Modern Protagonist:** A character whose values, speech, and outlook are indistinguishable from a 21st-century person despite living in the 12th century
- **The Tourist Narrator:** An authorial voice that gawks at the historical period as though visiting a museum rather than inhabiting a lived world
- **History as Costume Drama:** Period details limited to clothing and architecture while characters behave, speak, and think in entirely modern ways
- **The Noble Savage / Exotic Other:** Non-Western cultures depicted through a romanticised or Orientalist lens rather than with genuine research and complexity

### Cliche Setups to Avoid
- A witch trial where the accused is actually magical (unless the execution subverts the reader's expectations about how magic works in this world)
- A street urchin who turns out to be the lost heir to the throne
- A wise old mentor figure who conveniently dies after delivering all necessary exposition
- A love story where the only obstacle is that the lovers are from different social classes (the historical period offers far richer conflicts)
- A magical artefact that the protagonist must find/destroy/activate to save the world (this is secondary-world fantasy logic, not historical fantasy logic)
- Plague or war used solely as dramatic backdrop without engaging the actual human experience of epidemic or combat

### Names to Avoid
- Obviously modern names in pre-modern settings (e.g., "Brandon" in 6th-century Wales, "Tiffany" in Viking-age Scandinavia. although "Tiffany" is genuinely medieval, readers won't believe it)
- Names from the wrong culture or period (e.g., Norman French names in pre-Conquest Anglo-Saxon England)
- Fantasy-style invented names in a historical setting (e.g., "Aelithryn" or "Zarkoth" alongside real historical figures)
- Names that are accurate but so similar to each other that readers confuse characters (many historical periods reused a small pool of names. differentiate with bynames, titles, or nicknames)

## Comp Titles

Historical-fantasy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Jonathan Strange & Mr Norrell* — Susanna Clarke (2004): the gold-standard atmospheric historical-fantasy.
- *The Mists of Avalon* — Marion Zimmer Bradley (1983): Arthurian historical-fantasy foundation.
- *Outlander* — Diana Gabaldon (1991): time-travel historical-fantasy benchmark.

### Contemporary (current best-in-class)

- *The Bear and the Nightingale* — Katherine Arden (2017): Russian-folkloric historical-fantasy.
- *Spinning Silver* — Naomi Novik (2018): folkloric Eastern-European historical-fantasy.
- *The Golem and the Jinni* — Helene Wecker (2013): early-20th-century immigrant New York historical-fantasy.
- *The Books of Jacob* — Olga Tokarczuk (2014, English 2021): Eastern-European literary historical-fantasy.
- *Babel* — R.F. Kuang (2022): Industrial-Revolution Britain dark-academia historical-fantasy.
- *The Dead Djinn Universe* — P. Djèlí Clark (2017-): steampunk Cairo historical-fantasy.
- *The Once and Future Witches* — Alix E. Harrow (2020): suffrage-era American historical-fantasy.
- *The Night Circus* — Erin Morgenstern (2011): fin-de-siècle European historical-fantasy.
- *Circe* — Madeline Miller (2018): Bronze-Age Greek myth as historical-fantasy.

## Cover Design Specifications

### Visual Tone
Atmospheric, layered, and richly textured. The cover should feel like a door opening onto a real historical world with something luminous and strange shimmering beneath its surface. Neither purely historical nor purely fantastical. the magic should be suggested rather than shouted.

### Key Elements
- A historically accurate architectural or landscape element (castle, cathedral, ancient forest, harbour, walled city) rendered with period-correct detail
- A subtle magical element integrated into the historical scene: a faint glow, runes barely visible on stone, mist that forms a shape, an impossible light source, a figure that is slightly more-than-human
- Period-appropriate costuming or weaponry if figures are present
- A sense of depth and atmosphere. fog, candlelight, firelight, twilight, storm-light

### Typography
- Serif fonts with historical character: Garamond, Caslon, Baskerville, or similar typefaces with genuine period lineage
- Title lettering may incorporate subtle period-appropriate ornamentation (uncial letterforms for medieval settings, copperplate flourishes for 18th-century settings)
- Avoid modern sans-serif or overtly fantasy-style display fonts
- Author name in a complementary but restrained serif

### Colour Palette
- **Primary:** Aged parchment tones, deep earth colours (umber, sienna, ochre), tarnished gold
- **Secondary:** Midnight blue, forest green, oxblood, charcoal
- **Magical accent:** A single, carefully chosen supernatural colour. pale silver-blue, faint emerald, or warm amber glow. that contrasts with the historical palette
- **Avoid:** Bright neon magical effects, oversaturated colours, modern gradients, pure black backgrounds

### Comp Titles (Cover Style References)
- *Jonathan Strange & Mr Norrell* by Susanna Clarke. the gold standard for atmospheric Historical Fantasy covers
- *The Golem and the Jinni* by Helene Wecker. historical urban setting with subtle magical luminescence
- *Piranesi* by Susanna Clarke. minimalist but deeply atmospheric
- *The Bear and the Nightingale* by Katherine Arden. folk-magic-infused historical atmosphere
- *The Poppy War* by R.F. Kuang. historical epic with restrained magical imagery
