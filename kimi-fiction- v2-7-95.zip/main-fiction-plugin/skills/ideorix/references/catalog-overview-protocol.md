---
name: catalog-overview-protocol
description: "Full scan + render protocol for Catalog Overview — project discovery, type classification, per-project status, cross-catalog heuristics, dashboard rendering, and export pipeline."
version: "2.3.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*


# Catalog Overview Protocol

This is the implementation pipeline for the `catalog-overview.md`
entry-point spec. Renders Front Gate option C ("Catalog Overview").

## Pipeline (5 stages)

### Stage 1 — Discover projects

Scan `~/Documents/Ideorix-Projects/` recursively with `maxdepth 2`
to catch both top-level projects (`Ideorix-Projects/Project Name/`)
and one-level-nested projects (`Ideorix-Projects/subfolder/Project
Name/`).

A directory qualifies as a project if it contains any of:

- `project-config.md`
- `engine-data/` directory (with any contents)
- `manuscript/` directory (with any contents)
- `chapters/` directory (with any contents)
- A `*.fountain` file (screenplay)

Directories starting with `_` (underscore) are skipped — those are
meta-folders like `_catalog-reports/`.

If `~/Documents/Ideorix-Projects/` does not exist, offer to create
it and report an empty catalog.

### Stage 2 — Classify project type

Three-stage classifier per project, graceful degradation when
fields are missing:

**Stage 2a — explicit config.** Read `project-config.md` if
present. Use the `engine_type` / `project_type` field if it
exists. Definitive when found.

**Stage 2b — filesystem fingerprint** (covers legacy projects with
no config or older schemas):

| Signal | Inferred type |
|---|---|
| `engine-data/research-bible.md` exists | non-fiction |
| `engine-data/story-bible.md` exists | fiction novel |
| `*.fountain` in `manuscript/` OR `engine-data/screenplay-source.md` | screenplay |
| `manuscript/` populated, no Bible files | legacy fiction novel (default for pre-schema projects) |
| Multiple Bible files | mixed — flag for user, do not silently pick one |

**Stage 2c — activity classification via mtime sweep** of all
files under the project folder:

- Most recent file mtime ≤ 30 days → **active**
- 30–180 days → **dormant**
- > 180 days → **stalled**

### Stage 3 — Per-project status fields

Derived entirely from existing files (no new state to maintain):

| Field | Source | Universal / per-type |
|---|---|---|
| Title, type, pen name, age | `project-config.md` (or folder + inference) | universal |
| Phase | priority chain — see "Phase resolution priority chain" below | universal |
| Chapters drafted / total | count `chapters/ch*.md` | fiction novel + NF |
| Pages drafted / total | last `.fountain` page count | screenplay |
| Cover concepts | `marketing/` content | universal |
| Marketing pack | `marketing/` content | universal |
| Final-assembly DOCX present | search book root + `manuscript/` + `marketing/` — see "Final-assembly DOCX detection" below | universal |
| Manuscript Clinic last run | `engine-data/reports/clinic-*` mtime | universal |
| Market Scout last run | `engine-data/market-pulse.md` mtime | universal |
| Authority Builder profile | `engine-data/authority-profile.md` exists | NF |
| Voice Builder profile | `engine-data/voice-profile.md` exists | fiction |
| Script Coverage | `engine-data/script-coverage-*.md` | screenplay |
| Editorial pipeline | `engine-data/reports/editorial-*` | universal |
| Permissions outstanding | `engine-data/source-management.md` | NF |
| Sales log present + last entry month | `sales-log.md` (top-level of project, optional) | universal |
| Last-month gross / ad spend / net (per currency) | parsed from `sales-log.md` rows | universal |
| Format mix (ebook / KU / print / audio share) | parsed from `sales-log.md` | universal |

For legacy projects, fields the project does not have report as
**"unknown — pre-schema"** rather than "missing — needs work".

#### Phase resolution priority chain

The Phase field for each project is determined by reading
**three sources in priority order**, taking the first that yields
a definitive answer:

1. **`project-config.md` Status: field** *(PRIMARY — authoritative)*
   - Status text contains `✅ COMPLETE` or `✓ COMPLETE` or
     `COMPLETE` (with a word-count and/or final-assembly date) →
     Phase = **Delivered**
   - Status text contains `Phase {N}` → Phase = inferred from N
     (Phase 1 = Setup, Phase 2 = Bible, Phase 3 = Generation,
     Phase 4 = Editorial, Phase 5+ = Delivery)
   - Status text contains `Awaiting` / `Paused` / `On hold` /
     `Blocked` → Phase = pause-state with the literal status
     text surfaced
   - Status text contains `In progress` / `Active` / `Drafting`
     without explicit phase → Phase = **In progress**

2. **`pipeline-checkpoint.md`** *(SECONDARY — used if Status field
   is absent or unparseable)*
   - Read the most recent phase marker

3. **Filesystem inference** *(LAST FALLBACK — used only when both
   above are absent)*
   - The previous Stage-2 fingerprinting rules apply:
     `manuscript/` populated + Bible files = "Generation or
     later"; chapters present + editorial reports = "Editorial";
     etc. Surfaced as **inferred — verify** so the user knows
     this Phase value carries lower confidence.

The priority chain prevents false negatives where a completed
project's `manuscript/` folder is empty (because the final DOCX
lives in the book root or `marketing/` — see Final-assembly DOCX
detection below) and the absence is misread as "incomplete".

#### Final-assembly DOCX detection

A project may store its delivered manuscript in any of three
locations. The protocol searches all three:

- Book root: `{Project}/{Title}.docx`,
  `{Project}/{Title} - post-clinic.docx`,
  `{Project}/{Title} v{N}.docx`
- `{Project}/manuscript/{Title}.docx` and variants
- `{Project}/marketing/{Title}.docx` and variants
  (some delivery flows place the final assembly in the marketing
  bundle for distribution)

The first match in any of the three locations counts as
final-assembly DOCX present. The location is also recorded
because the Config Drift flag (Stage 4 Layer 1) uses it.

The rule applies to both `.docx` and other final-format
extensions if the project type calls for them (e.g.
`.fountain` for screenplays).

### Stage 3a — Sales-log parsing (when present)

When a project root contains `sales-log.md`, the scan loop reads
and parses the markdown table per `sales-log-format.md`:

1. Read the file. If absent → record `(no log)` and continue
   to next project. **No nagging.**
2. Locate the markdown table header (canonical 8-column shape:
   `Month | Curr | Ebook | KU | Print | Audio | Ad Spend |
   Notes`).
3. Iterate data rows. For each row:
   - Extract `Month`, `Curr`, and per-format `units / amount`
     pairs. KU uses `pages / amount`.
   - Extract `Ad Spend` (amount only, in row currency).
   - Empty cells are valid (format had no activity that month).
   - Malformed cells / wrong column count / unrecognised
     currency → skip row, log `(parse error in row N)`,
     continue.
4. Aggregate per currency:
   - Latest-month gross
   - Latest-month ad spend
   - Latest-month **net** (gross − ad spend)
   - Trend vs prior month (net-to-net), one of `↑`, `↓`, `→`
   - Format mix (ebook / KU / print / audio share of gross)
5. Surface `(no data yet)` distinct from `(no log)` — header
   present but no data rows means the user started a log but
   has not filled it in.

Parser is fragile-but-tolerant. Catalog Overview never crashes
on a malformed sales log; it reports what it could read and
shows `(parse error in row N)` on the project's sales cell.

### Stage 4 — Cross-catalog heuristics

Three layers, ordered by depth:

**Layer 1 — Per-project gaps** (mechanical, deterministic):

- Tools never run (no Manuscript Clinic, no Market Scout cache,
  no cover concepts, no Authority/Voice profile)
- Stale data (Market Scout > 6 months old, Editorial pipeline
  never run on completed manuscript)
- Incomplete components (chapters drafted but no editorial;
  manuscript delivered but no marketing pack)
- **Config drift** — `project-config.md` Status field disagrees
  with filesystem evidence. Triggers when:
  - Status says "Awaiting" / "Paused" / "In progress" / a
    specific early phase BUT a final-assembly DOCX is present
    (per Final-assembly DOCX detection in Stage 3) AND/OR
    editorial reports exist from a later phase than the
    Status claims.
  - Status says `✅ COMPLETE` BUT no final-assembly DOCX is
    present anywhere AND no editorial reports exist (false-
    positive direction; rare but worth catching).

  The flag tells the user the config is stale and needs
  reconciling. **Does NOT silently override the config** —
  surfaces the contradiction so the user resolves it. Phase
  field continues to display per the priority chain
  (Status field wins) but with a `[config drift]` annotation
  appended so the user sees both the declared and the
  evidence-based view at a glance.

**Layer 2 — Per-pen-name patterns:**

- Pen names with no Pen Name Studio profile but multiple projects
  under them
- Pen names where genre/category has shifted significantly across
  projects (potential brand drift)

**Layer 3 — Cross-catalog opportunities:**

- **Series potential** — multiple standalone projects sharing
  setting / cast / world signals (cross-reference Bible files
  for shared entity names)
- **Genre concentration** — % of catalog by genre/category;
  flag over- or under-indexing
- **World-building economy** — projects sharing setting that
  lack a Series Bible
- **Comp drift** — Market Scout cached comp sets that have aged;
  suggest refresh
- **Production bottlenecks** — too many projects in editorial vs
  none in active writing (or vice versa)
- **Screenplay-novel pairs** — fiction novels with screenplay
  potential (or screenplay → novel candidates already covered by
  the existing Adaptation flow)

**Layer 3 — Sales-derived opportunity flags** (only fire on
projects with a `sales-log.md` present):

1. **Ebook only, no audiobook produced** — Project has ebook
   revenue but no audio production in `marketing/` or no
   audiobook component in the publishing artefacts.
2. **Audio produced but no audiobook sales logged in 6+ months**
   — Audiobook exists but isn't selling or isn't being logged.
3. **Low performer in healthy category** — Cross-references
   Market Scout cached data. If the category is healthy (good
   demand, active comp set) but this project's last 3 months of
   **net margin** are bottom-quartile of the user's catalog,
   flag as needs-attention. Net not gross so high-ad-spend
   projects don't masquerade as high earners.
4. **Stale sales data > 3 months** — *Only fires if the project
   already has a `sales-log.md` file.* The most recent entry is
   more than 3 months old. Projects with no sales log at all
   are NEVER flagged (no-nag principle).
5. **Ad spend ≥ 80% of gross** — Ad spend dominates revenue.
   Only fires when ad spend is logged for at least 2 of the
   last 3 months (catches a sustained trend, not a one-off
   high-spend launch month).
6. **KU-heavy revenue with no audio** — KU page reads dominate
   revenue (> 60% of project's total). Audience is heavy
   borrowers, who often consume audio too. Flag as audio-launch
   opportunity.

### Stage 5 — Render and save

**On-screen dashboard** — render in this order:

1. Header: total project count, active / dormant / stalled split
2. Main project table with columns:
   `PROJECT | PHASE | COVER | EDIT | CLINIC | LAST MONTH (NET) | AGE`

   `LAST MONTH (NET)` cell content rules:
   - No `sales-log.md` → `(no log)`
   - Header present, no data rows → `(no data yet)`
   - Latest month has data, no ad spend → gross only, e.g. `$359`
   - Latest month has data + ad spend → net headline with
     gross in parentheses, e.g. `$247 net ($359 gross)`
   - Multi-currency → primary currency total + indicator,
     e.g. `$247 + £35`
   - Trend arrow when prior month exists, comparing net-to-net:
     `↑` `↓` `→`
   - Why net not gross: a project earning $400 gross with $300
     in ads isn't doing well. Net is the actionable number;
     gross stays visible in parentheses so the full picture is
     preserved.

3. Per-pen-name revenue aggregation block (when any project has
   a sales log). Grouped by pen name; one row per currency the
   pen name has revenue in:

   ```
   PEN NAME REVENUE — last month (Sep 2026)

     J. Harvey
       USD   $289.58 net ($401.78 gross, $112.20 ads)   (2 of 3 projects logged)
       GBP   £35.40 net (no ads)                         (1 of 3 projects logged)
     M. Lake                                             (no sales logged)
   ```

   No USD-equivalent / GBP-equivalent conversion across
   currencies. Each currency stays explicit. Author-count
   parenthetical shows logged-versus-total project ratio so the
   user sees at a glance where data is missing.

4. Gap / opportunity flag list (Layer 1 → 2 → 3 + sales-derived)
5. Save prompt:

```
Save the Catalog Report as:
  1. Markdown (.md)            — fastest, version-controllable
  2. Word document (.docx)     — for sharing / review
  3. PDF                       — for archive / print
  4. All three
  5. Sales Summary PDF only    — sales tables, no editorial dashboard
  6. Skip — don't save
```

Option 5 routes through the same renderer in `sales-summary`
mode and produces a sales-only artifact suitable for sharing
with an accountant without exposing manuscript state. The
input markdown for sales-summary mode is built from the
sales-only sections of the dashboard (per-project sales rows +
per-pen-name aggregation block + sales-derived flags) —
Catalog Overview prepares the narrower markdown before passing
it to the script.

**Save** — invoke `scripts/catalog-render.sh` with the chosen
format. The script handles pandoc detection, the `.docx`
reference-doc template, and the `.pdf` engine fallback (LaTeX →
wkhtmltopdf → markdown-only).

Two render modes:

- **`catalog`** (default) — full Catalog Report.
  Output: `{YYYY-MM-DD}_catalog-overview.{md,docx,pdf}`
  Template: `catalog-report-template.docx`
- **`sales-summary`** — sales-only narrower export. Used when
  the user picks "Sales Summary PDF only" at the save prompt
  or invokes the dedicated `Sales summary` / `Sales report` /
  `Print sales` trigger phrases.
  Output: `{YYYY-MM-DD}_sales-summary.{md,docx,pdf}`
  Template: `sales-summary-template.docx`

The mode flag changes the output basename and the `.docx`
reference template. The input markdown is whatever Catalog
Overview prepares — full report or sales-only — so the renderer
stays content-agnostic.

Output directory:

```
~/Documents/Ideorix-Projects/_catalog-reports/
```

If pandoc is not installed when `.docx` or `.pdf` requested,
fall back to `.md` only with a one-line install hint
(`brew install pandoc` / `apt install pandoc` /
`winget install pandoc`). Same fallback applies to both modes.

## Edge cases

| Edge case | Handling |
|---|---|
| Project folder exists but is empty | "empty — placeholder?" |
| Project has files but no `project-config.md` | Inferred type, marked `[legacy]`, status fields show "unknown — pre-schema" |
| User has 50+ projects | Dashboard truncates to top 20 by activity recency, summary line "+30 dormant projects (run 'show all' to see)" |
| `~/Documents/Ideorix-Projects/` doesn't exist | Engine offers to create it, then reports empty |
| Pandoc not installed | Detected at save time, `.md` only with install hint |
| Mixed-type project (Story Bible + Research Bible) | Flagged for user — uncommon, do not silently pick one |
| Pen Name Studio profiles with zero projects | "registered but no project history" |
| Project in subfolder | `maxdepth 2` glob covers `Ideorix-Projects/subfolder/Project Name/` |
| Catalog Overview from inside a project session | Trigger phrases handle it — bypass Front Gate, no project context loss |
| Both engines installed (fiction + NF) | Same Catalog Overview from either — mirrored spec, identical output. spec-lint enforces mirror once `check_mirror_identity` lands. |
| `sales-log.md` malformed (missing column, bad cell, wrong currency) | Parser skips bad row, logs warning, continues. `(parse error in row N)` on sales cell. Never crashes. |
| `sales-log.md` empty (header only, no data rows) | `(no data yet)` — distinct from `(no log)`, helps distinguish "started tracking, hasn't filled in yet" from "never started" |
| 4+ currencies for one pen name | Pen-name aggregation block lists each currency on its own line. No conversion. Output stays honest. |
| Mismatched `primary_currency:` across pen-name's projects | Per-row `Curr` is what's parsed. The `primary_currency:` header is informational only and never reconciled. |
