---
name: authenticity-guard
description: "Universal AI name and pattern avoidance rules"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Universal Names & Patterns Avoidance

## Overview

LLMs have strong biases toward certain names, places, and patterns.
These read as "AI-generated" to experienced readers and publishers.
This list supplements genre-specific avoidance lists in the genre bank.

## Female Names — NEVER USE

Elara, Luna, Aurora, Willow, Sage, Ivy, Wren, Ember, Rowan, Juniper,
Seraphina, Isolde, Evangeline, Cordelia, Celestia, Dahlia, Lyra, Aria,
Brynn, Elowen, Maeve, Cassandra, Astrid, Freya, Rhiannon, Sable, Calla,
Thalia, Nyx, Althea, Zara, Calista

## Male Names — NEVER USE

Thorne, Ash, Jasper, Hawthorne, Sterling, Orion, Caspian, Silas, Gideon,
Alaric, Dorian, Lucian, Zephyr, Atlas, Beckett, Declan, Kai, Ronan,
Oberon, Lysander, Evander, Callum, Rhys, Soren, Leander

## High-Frequency AI Names — NEVER USE

These names are not fantasy-sounding but are statistically overused in
LLM-generated fiction. Experienced readers recognise them as AI tells.

**Given names:** Marcus, Ethan (for adult characters), Elena, Liam, Aiden,
Caleb, Nora, Clara, Elise, Maya, Mira, Kira, Ava, Lena, Raven

**Surnames (especially for villains, secondary characters, or "diverse" casting):**
Chen, Okafor, Voss, Webb, Hayes, Cross, Blackwell, Ashworth, Reeves,
Nakamura, Petrov, Morales, Singh (as generic diversity marker),
Kim (as generic diversity marker), Patel (as generic diversity marker)

**AI "diversity combo" patterns — NEVER USE:**
- [Western given name] + [Non-Western surname] used as a shortcut for diversity
  without cultural depth (e.g., "Marcus Chen", "Elena Okafor", "Liam Nakamura")
- These combos are the single most recognisable AI-fiction fingerprint.
  If a character is multicultural, build genuine cultural depth into their
  background, speech patterns, and family dynamics — don't just bolt a
  non-Western surname onto a Western given name.

## Name Patterns — NEVER USE

- Names ending in: -wyn, -ael, -ienne, -elle, -ara, -ris
- "Old soul" names: Any name that sounds like it belongs to an elf
- Virtue names: Valor, Serenity, Haven, Justice, Verity (unless period-appropriate)
- Nature-word names: River, Storm, Rain, Frost, Blaze, Phoenix

## Place Names — NEVER USE

Willowbrook, Maplewood, Ravenwood, Thornfield, Briarwood, Shadowvale,
Moonhaven, Starfall, Crystalbrook, Silvermist, Whispering Pines,
Enchanted Hollow, Rosemary Lane, Lavender Hill, Evergreen Falls,
Misty Harbor, Golden Meadow, Crimson Peak, Ivory Tower

## Place Name Formulas — NEVER USE

- [Tree] + [Landscape Feature]: Oakdale, Elmhurst, Birchwood
- [Mystical Word] + [Geographic]: Shadowmere, Moonvale, Starhollow
- [Color] + [Nature]: Greenfield, Blackwater, Silverstone (unless real place)
- "The [Adjective] [Noun]": The Whispering Woods, The Silent Lake

## Business Names — NEVER USE

### High-Frequency AI Business Name Patterns

These are the business-name equivalents of "Marcus Chen" — they signal
AI-generated fiction to experienced readers:

**Formula patterns:**
- "The Cozy [Noun]": The Cozy Corner, The Cozy Cup, The Cozy Nook
- "The Enchanted [Noun]": The Enchanted Garden, The Enchanted Page
- "[Whimsy] & [Whimsy]": Whiskers & Wands, Petals & Prose, Brambles & Brew
- "The [Adjective] [Animal]": The Gilded Fox, The Crimson Owl, The Silver Stag
- "[Abstract Noun] + [Tech Suffix]": Nexus Technologies, Apex Systems,
  Pinnacle Solutions, Zenith Dynamics, Vanguard Analytics, Horizon Dynamics
- "[Greek/Latin Root] + [Corp]": Helix Corp, Omni Industries, Proteus Global,
  Aether Dynamics, Solaris Ventures
- "The [Adjective] [Craft Noun]": The Rustic Spoon, The Gilded Quill,
  The Velvet Curtain, The Polished Stone
- "[Colour] + [Gemstone/Metal]": Crimson Sapphire, Obsidian & Gold

**Specific AI-favourite business names — NEVER USE:**
Nexus, Apex, Pinnacle, Zenith, Vanguard, Horizon, Sentinel, Eclipse,
Meridian, Catalyst, Onyx, Prism (as standalone company names or with
generic suffixes like Technologies, Dynamics, Solutions, Systems, Global,
Industries, Ventures, Analytics, Corp, Enterprises)

### Real-World Collision Rule

All fictional business names MUST be checked against real-world companies.
See `company-name-generator.md` Step 4 for the full collision protocol.
A fictional business name that matches a real well-known company breaks
reader immersion and creates legal risk.

## Book Title Words — AVOID

Whispers, Shadows, Secrets, Embers, Thorns, Binding, Veil, Echo,
Cursed, Fated, Twisted, Shattered, Hidden, Broken, Forgotten,
Woven, Between, Beneath, Beyond, Crimson, Obsidian, Ivory

## What to Use Instead

### Real Names
Source from: census data, yearbooks, phone books for the target era.
- 1950s-60s: Barbara, Patricia, Linda, James, Robert, John
- 1970s-80s: Jennifer, Michelle, Stephanie, Michael, Christopher, David
- 1990s: Jessica, Ashley, Amanda, Joshua, Matthew, Tyler
- 2000s: Emily, Madison, Hannah, Jacob, Noah, Owen
- Mixed: Karen, Denton, Millbrook, Harlan, Prescott, Frank, Diane

### Real Places
- Use places that could exist on Google Maps
- Name businesses after owners, streets, or literal descriptions:
  Brennan's Bakery, Main Street Diner, The Flour Mill
- Use real naming patterns: Fairfield, Glendale, Port Chester, Milltown

### The Phone Book Test
Before finalizing ANY name: "Could I find this in a phone book or on Google Maps?"
If it sounds like it belongs in a fantasy novel, change it.
(Exception: actual fantasy novels — but even then, avoid the lists above.)

## Mandatory Cross-References

This file MUST be checked during:
1. **Story Bible generation (Phase 2A)** — every character name in the Story Bible
   must be validated against ALL lists above before presentation to the user
2. **Character Name Generator** — all 5 candidates must pass every list above
3. **Company Name Generator** — all 5 candidates must pass every list above,
   plus the real-world collision check
4. **Outline Builder (Steps 3-7)** — all names generated in concept seeds,
   protagonist/antagonist/supporting cast bios must pass every list above
5. **Chapter generation** — any new character or business introduced mid-manuscript
   must be checked before the Writer executes

If a name appears on ANY list above, it MUST be replaced before the user sees it.
Do NOT present banned names as candidates and then note they're banned — generate
compliant names from the start.

## Genre-Specific Overrides

Each genre bank file has its own `## Names & Patterns to Avoid` section
that supplements this universal list. For example:
- **Fantasy** adds overused fantasy name patterns
- **Romance** adds overused romance name patterns
- **Thriller** adds overused villain/agent name patterns
- **Historical** adds anachronistic name patterns for the period
