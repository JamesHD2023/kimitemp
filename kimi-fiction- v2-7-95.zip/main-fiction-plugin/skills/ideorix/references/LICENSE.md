IDEORIX PROPRIETARY SOFTWARE LICENCE

Copyright (c) 2025 James Harvey Media. All rights reserved.

1. GRANT OF LICENCE

James Harvey Media ("Licensor") grants the original purchaser ("Licensee")
a non-exclusive, non-transferable, revocable licence to use the Ideorix
manuscript engine software ("Software") on a single installation for the
Licensee's own manuscript generation purposes.

2. RESTRICTIONS

The Licensee shall NOT:

  a. Copy, reproduce, distribute, publish, or share the Software or any
     part thereof, in any form, to any third party;
  b. Sell, resell, sublicence, lease, rent, or otherwise transfer the
     Software or access to it;
  c. Modify, adapt, reverse-engineer, decompile, or create derivative
     works based on the Software;
  d. Remove, alter, or obscure any copyright notices, licence headers,
     watermark notices, or proprietary markings;
  e. Use the Software to create a competing product or service;
  f. Share, publish, or redistribute individual files, prompts, genre
     specifications, agent protocols, or any other component of the
     Software, whether in original or modified form;
  g. Upload the Software or any part thereof to any public repository,
     file-sharing service, or training dataset.

3. INTELLECTUAL PROPERTY

The Software, including all code, text, specifications, protocols,
genre files, agent definitions, and documentation, is the exclusive
intellectual property of James Harvey Media. This licence does not
transfer any ownership rights. The Licensee's generated manuscripts
remain the Licensee's property.

4. DIGITAL WATERMARKING

All Ideorix system files carry persistent steganographic watermarks
tied to the Licensee's licence. Unauthorised redistribution will be
traced to the originating licence.

5. TERMINATION

This licence terminates immediately if the Licensee breaches any term.
Upon termination, the Licensee must destroy all copies of the Software.
James Harvey Media may revoke access at any time for cause.

6. NO WARRANTY

THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
NON-INFRINGEMENT. IN NO EVENT SHALL JAMES HARVEY MEDIA BE LIABLE FOR
ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THE
SOFTWARE.

7. GOVERNING LAW

This licence shall be governed by and construed in accordance with the
laws of Northern Ireland. The Licensee submits to the exclusive
jurisdiction of the courts of Northern Ireland, without prejudice to
the Licensor's right to seek injunctive relief or enforce judgments in
any court of competent jurisdiction worldwide.

8. INTERNATIONAL COPYRIGHT

The Software is protected by copyright laws and international treaty
provisions, including but not limited to the Berne Convention for the
Protection of Literary and Artistic Works and the WIPO Copyright
Treaty. Unauthorised reproduction or distribution may result in civil
and criminal penalties under applicable law in the jurisdiction where
the infringement occurs.

9. ENTIRE AGREEMENT

This licence constitutes the entire agreement between the parties
regarding the Software and supersedes all prior agreements and
understandings.

---
Ideorix — The Manuscript Engine
James Harvey Media
