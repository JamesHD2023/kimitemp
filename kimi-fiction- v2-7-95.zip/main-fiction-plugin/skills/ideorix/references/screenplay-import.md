---
name: screenplay-import
description: "Adapt a screenplay you own into a novel — import scenes, dialogue, characters, and locations from Fountain, FDX, DOCX, or PDF, then run the full Ideorix pipeline with expansion-aware prose generation"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with `> **Powered by Ideorix** — The Manuscript & Screen Engine` before any other output.

# Screenplay → Novel (Adaptation Studio)

Bring a screenplay you own and turn it into a novel. Ideorix parses
your script (Fountain, FDX, DOCX, or text-layer PDF), extracts scenes,
characters, locations, and dialogue, then runs the full manuscript
pipeline with expansion-aware prose generation — adding the interiority,
sensory detail, POV narration, and pacing that a novel needs while
keeping every plot beat faithful to the source.

## Supported input formats

| Format | How to get it | Reliability |
|--------|---------------|-------------|
| **Fountain** (`.fountain`) | Export from Final Draft, Highland, Slugline, WriterDuet, Celtx, Fade In, or any Fountain-aware tool | Highest — plain-text semantic format |
| **FDX** (`.fdx`) | Final Draft's native format (`File → Save As → Final Draft Document`) | Highest — XML, scene/character/dialogue are tagged elements |
| **DOCX** (`.docx`) | Export from any screenwriting app (Final Draft, Highland, WriterDuet, Fade In, Celtx) or `File → Save As → Word Document` from most apps | High — reads paragraph styles when present, falls back to indent heuristics when not |
| **PDF** (`.pdf`) | Export from any screenwriting app; industry-standard layout expected (Courier 12pt, standard margins) | Medium — only text-layer PDFs (not scanned). See PDF handling below. |

**Rule of thumb:** if your screenwriting app offers it, Fountain or FDX
give the cleanest results. DOCX is reliable. PDF works for text-layer
files from screenwriting apps but is not recommended for scripts typed
or scanned into PDF by other means.

## PDF handling (important)

PDF is a layout format, not a semantic format. Before parsing, the
importer runs a text-layer probe on the first page:

- **Text layer found, industry-standard layout** → parse cleanly using
  column-position classification (character cues at ~3.7" from left,
  dialogue at ~2.5", sluglines flush-left)
- **Text layer found, non-standard layout** → fall back to indent
  heuristics, flag any ambiguous classifications for review
- **No text layer or fewer than 50 characters extracted per page** →
  **REJECT** with a clear message: *"This looks like a scanned PDF with
  no text layer. Export your screenplay to Fountain, FDX, or DOCX from
  your screenwriting app and re-upload — those formats produce reliable
  imports."*

Scanned PDFs are not supported. OCR of scanned screenplays is slow,
unreliable, and produces output that needs extensive manual cleanup
before the pipeline can use it. If you only have a scanned script, the
cleanest path is to open it in your screenwriting app (or retype into
Highland/Fade In/Final Draft) and export Fountain.

## Output length tiers

Once your screenplay is parsed, you pick the target novel length. The
importer reports the source word count and recommends the best-fit
tiers based on expansion ratio:

| Tier | Target | Chapters | Typical expansion (from 15k-word feature) |
|------|--------|----------|-------------------------------------------|
| **Short Story** | ~8,000 words | 5 | **0.5x — COMPRESSION** (drops scenes — not recommended unless your screenplay is a short film under 20 pages) |
| **Novelette** | ~12,500 words | 9 | **0.8x — TIGHT** (minor compression; works for leaner features) |
| **Novella** ⭐ | ~40,000 words | 16 | **2.7x — IDEAL** (standard novelisation; the source remains prominent) |
| **Standard Novel** | ~75,000 words | 30 | **5x — STRETCH** (significant new interiority and sensory layering) |
| **Epic Novel** | ~120,000 words | 40 | **8x — EXTREME** (most of the novel will be new material) |

Novella is the recommended default for feature screenplays because the
2.5x–3x ratio keeps the source's plot prominent while giving the Writer
enough wordage to add what novels are for (POV interiority, sensory
environment, subtext).

**Out-of-range warnings:** the importer calculates the exact expansion
ratio for your specific source word count and warns you if it falls
outside the ideal zone:

- **Ratio below 0.9 (compression)** — your target novel is shorter
  than your screenplay. You will lose scenes. The importer recommends
  stepping up one or more tiers.
- **Ratio 0.9–1.5 (tight)** — very close adaptation. Works but
  expect limited room for interiority expansion.
- **Ratio 1.5–3.5 (ideal)** — the sweet spot. The Writer preserves
  the screenplay's plot while adding novelistic depth.
- **Ratio 3.5–6 (stretch)** — large expansion. The novel will
  contain more content than the screenplay. Expect the Writer to
  add substantial new interiority, sensory layering, and pacing
  variation. Still faithful to plot (the Outline Conformance Agent
  enforces this) but the "voice" of the novel will dominate.
- **Ratio above 6 (extreme)** — most of the novel will be new
  material. Works if you want a full novelisation of a short concept,
  but expect the Writer to make many decisions the screenplay didn't
  make. Recommended only if you have a specific reason for an epic-
  length target.

You can override the warning and proceed with any tier — the importer
surfaces the ratio honestly but doesn't block.

## POV modes

Novels need a POV decision that screenplays don't. The importer asks:

- **Single-POV** — one character carries the novel's narrative
  throughout. All interiority is that character's. All chapters are
  written in close third (or first person, if chosen) locked to them.
  The importer ranks candidates by dialogue count × scene presence
  and suggests the top one as default. Best for character-driven
  stories, thrillers with a clear protagonist, romance adaptations.

- **Dual-POV** — two characters alternate chapters or scenes. The
  importer suggests the top two and asks if you want strict alternation
  (A/B/A/B), scene-driven (whoever is most active in the chapter's
  source scenes), or user-assigned per chapter. Best for romance
  adaptations, two-hander thrillers, any story with two strong leads.

- **Multi-POV (3+)** — three or more POV characters. The importer
  suggests the top-ranked candidates and uses scene-driven assignment
  by default (each chapter narrated by whoever is most active in its
  source scenes). Best for ensemble stories, epic adaptations, any
  screenplay with a large cast and distributed protagonism.

For multi-POV, each POV character should ideally have a distinct voice
profile. The Voice Builder runs after the POV selection and helps you
build voice profiles from each character's dialogue in the screenplay
(or attach existing profiles from your Voice library).

## What it does

| Task | What happens |
|------|-------------|
| **Format detection** | The importer reads the file extension and content to pick the right parser (Fountain / FDX / DOCX / PDF) |
| **Parsing** | Extract scenes, characters, locations, dialogue, action lines, parentheticals, transitions, and title page metadata |
| **Character normalisation** | Dedupe character cue variants (`BEN`, `BEN (O.S.)`, `BEN (V.O.)`, `BEN (CONT'D)` → one character entry) |
| **Scene-to-chapter chunking** | Group scenes into the chosen length tier's chapter count, respecting natural breaks (location changes, time jumps, transitions, section markers) |
| **Story Bible seeding** | Populate Sections 1, 4, 7, 12, and 14 of the Story Bible from parsed data |
| **Entity Canon Lockfile** | Auto-generate `engine-data/entity-canon.md` from the character + location rosters so the Continuity Guardian catches name drift mechanically |
| **Source preservation** | Save the parsed data to `engine-data/screenplay-source.md` and the chapter mapping to `engine-data/scene-to-chapter-map.md` for the Architect and Outline Conformance Agent |
| **Expansion-aware pipeline** | The normal Architect → Writer → Humaniser → Verification pipeline runs, with a screenplay-adaptation mode that locks plot to the source and gives the Writer an expansion licence for interiority, sensory detail, and subtext |

## How to start

Say any of:
- "Adapt a screenplay" / "Adapt my screenplay"
- "Novelise my screenplay" / "Novelize my script"
- "Screenplay to novel" / "Script to book"
- "Convert screenplay to book"
- "I have a Fountain file to novelise"
- "I have a Final Draft file" / "I have an FDX file"
- "I have a screenplay in Word"
- "Turn this script into a novel/novella"

Or pick **Screenplay → Novel** from the Writers Studio or Full Creative
Suite menu.

## How to prepare your screenplay file

**Fountain (recommended):** Already a plain text file with `.fountain`
extension. Open in any text editor to verify it contains sluglines
(`INT. KITCHEN - DAY`), action lines, character cues in CAPS, and
dialogue. No preparation needed.

**FDX (Final Draft):** Your native Final Draft file (`.fdx`). Save
from Final Draft as usual. No preparation needed. The importer reads
the tagged XML directly.

**DOCX (any screenwriting app + Word):** Best case — the file was
exported from Final Draft, Highland, WriterDuet, Celtx, Fade In, or
similar. These apps include paragraph styles (`Scene Heading`,
`Action`, `Character`, `Dialogue`, `Parenthetical`, `Transition`)
that make parsing clean. Medium case — the file was typed directly
in Word without styles: the importer falls back to indent heuristics
and works ~80% of the time on clearly-formatted scripts. Worst case —
the file uses no consistent formatting at all: the importer will
flag the ambiguity and ask you to re-export from a screenwriting app.

**PDF:** Must have a text layer. To check: open the PDF in any viewer
and try to select and copy a line of dialogue. If you can select text,
the file has a text layer. If selection gives you a box around the
page but no actual text, it's a scanned PDF — re-export from your
screenwriting app to Fountain or DOCX and use that instead.

For any format, place the file at
`~/Documents/Ideorix-Projects/imports/` (the importer will find it
automatically) or have the full file path ready to give.

## What gets imported

From your screenplay (any format), the importer brings across:

- **Every slugline** as a scene object (INT/EXT, location, time of day)
- **Every action line** as seed description for the scene
- **Every character** that speaks or is referenced in action lines,
  deduplicated across name variants
- **Every line of dialogue** preserved, attached to its speaker and
  scene, with parentheticals preserved as interior performance notes
- **Every location** from sluglines, with associated action lines
  providing seed description
- **Transitions** preserved as scene boundaries
- **Title page metadata** (Title, Author, Draft date) where available

## What's NOT imported

- **Scanned PDFs** (no text layer) — rejected with a clear message.
  Re-export from your screenwriting app to Fountain or DOCX.
- **Final Draft / Fade In notes and revisions** — note bubbles, revision
  marks, and coloured-page annotations are not imported. If your script
  has meaningful revision marks (e.g., production draft with changes
  for shooting), export a clean version first.
- **Embedded images** — screenplays sometimes contain production stills
  or storyboard panels. These are ignored.
- **TV pilot episode-specific structures** — the importer treats a
  pilot script as a feature-style screenplay. If your pilot has
  runner plots, B-story arcs, or act-break tags, those are read as
  sections but not given special episodic treatment. Supported but
  not specialised.
- **Series / multi-script bundles** — one screenplay per import. For
  a trilogy or series, import each script separately into its own
  Ideorix project.

## What Ideorix will ask you after parsing

1. **Length tier** — Short Story / Novelette / Novella / Standard Novel
   / Epic Novel. The importer calculates your specific expansion ratio
   and recommends the best-fit tier, with out-of-range warnings for
   tiers that will compress or stretch too far.
2. **POV mode** — Single-POV / Dual-POV / Multi-POV (3+). The importer
   ranks characters by dialogue count × scene presence and suggests
   defaults for each mode.
3. **POV character(s)** — which character(s) carry the narrative.
   Default: the top-ranked character (Single) or top two/three
   (Dual/Multi).
4. **Genre** — what genre should the novel be? The importer reads
   tone, pacing, and content signals and suggests a best match; you
   confirm or override.
5. **Dialect** — US or GB English.
6. **Voice profile(s)** — for Single-POV, one voice; for Multi-POV,
   a voice per POV character. Attach existing, build from the
   character's dialogue in the screenplay, or skip.
7. **Pen name** — attach existing, create new, or skip.
8. **Dialogue handling policy**:
   - **Preserve verbatim** — every line of dialogue kept exactly as
     written (recommended for your own screenplays)
   - **Natural adaptation** — dialogue kept verbatim 80%+ of the
     time, with minor paraphrasing for novel rhythm where lines
     read stilted in prose (recommended for external adaptations)
   - **Paraphrase freely** — use scripted dialogue as a guide, not
     a script (for looser adaptation)
9. **Scene density** — the chunker offers a default scene → chapter
   mapping for your chosen tier. You can override.

## Rights

**Only adapt screenplays you own or have rights to.** This includes
your own scripts (whatever their production status), screenplays you
have an option on, screenplays in the public domain, or screenplays
where you have explicit written permission from the rights-holder.

The importer cannot verify rights. You are the rights-holder of
record for any output. Ideorix takes no position on the legal status
of any adaptation — that's between you and the screenplay's owner.

## What you get back

A fully populated Ideorix project workspace:

```
~/Documents/Ideorix-Projects/{Your Title}/
├── project-config.md                     Project metadata + setup answers
├── manuscript/
│   └── (chapter files generated as the pipeline runs)
├── engine-data/
│   ├── story-bible.md                    Seeded from the screenplay
│   ├── entity-canon.md                   Characters + locations from script
│   ├── screenplay-source.md              The parsed screenplay (for the Outline Conformance Agent)
│   ├── scene-to-chapter-map.md           Which screenplay scenes feed which chapters
│   ├── entities/                         Structured character + location data
│   └── summaries/                        Generated chapter summaries
├── marketing/
└── imports/screenplay-export/
    └── {original-filename}.{ext}          Preserved original (Fountain/FDX/DOCX/PDF)
```

From there, the normal pipeline runs: Authority Builder (or voice
profile attach) → Chapter 1 brief → Outline Conformance check → User
Review Gate → Writer (expansion-aware mode) → Humaniser → 6-agent
Verification → Progress Dashboard → next chapter. Rule 9 applies:
one chapter at a time, user approval between each.

## The adaptation promise

**Faithful plot, new prose.** Every plot event, every character beat,
every scene's core dramatic action traces to the source screenplay.
What the novel adds is what novels are for — the reader's seat inside
a character's head, the sensory layering a camera couldn't capture,
the pacing choices that breathe, the subtext that a performance would
have carried.

The Outline Conformance Agent (hardened to a HARD GATE) treats the
screenplay as the canonical outline. Any chapter brief that invents a
plot event, introduces a character, or drops a scripted beat is
blocked before the Writer runs. The Entity Canon Lockfile (also a
mechanical hard-gate) catches any name drift at verification time.
You cannot accidentally drift away from the source — the engine
physically prevents it.

> Protocol: `screenplay-importer.md`
> Architect + Writer expansion rules: `screenplay-expansion.md`
