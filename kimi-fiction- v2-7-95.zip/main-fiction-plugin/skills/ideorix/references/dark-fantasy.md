---
name: dark-fantasy-genre
description: Genre-specific instructions for dark fantasy fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Dark Fantasy. Genre Plugin

## Metadata
- id: dark-fantasy
- name: Dark Fantasy
- icon: 🗡️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Dan Harmon Story Circle"]

## Subgenre Options
Present during setup:
- **Grimdark**. Morally grey world, brutal consequences, no heroes; Abercrombie, Cook territory
- **Gothic Fantasy**. Crumbling estates, cursed bloodlines, atmospheric dread, beauty in decay
- **Horror Fantasy**. Eldritch horrors, cosmic dread, body horror woven into a fantasy world
- **Sword & Sorcery**. Morally ambiguous protagonists, dangerous magic, personal stakes over world-saving
- **Dark Court**. Fae courts, demonic hierarchies, divine politics. all of them cruel
- **Apocalyptic Fantasy**. The world is ending or already ended; survival in a broken magical landscape

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Deliberate build punctuated by violence. long tension with explosive release
- Must open with: Consequence, violence, discovery, or moral compromise. never with peaceful worldbuilding

BEATS PER CHAPTER
1. Cost Beat. Something is lost, damaged, or permanently changed (a life, a principle, a relationship, an innocence)
2. Moral Compromise. A character makes a choice with no clean option; the reader should feel the weight
3. World-As-Wound. The setting reflects the story's darkness through physical detail (rot, rust, blood, bone, ash)
4. Human Moment. One beat of genuine human connection amid the darkness (humor, tenderness, loyalty). this is the contrast that makes the darkness meaningful
5. Escalation. The situation worsens, or a new dimension of the threat emerges

DARK FANTASY ARCHITECTURE
- POV: 1-4 characters depending on length; unreliable narrators are welcome
- Morality is a SPECTRUM. there are no white hats and few black hats; everyone operates in grey
- Consequences are PERMANENT. deaths stay dead, wounds leave scars, betrayals aren't forgiven easily
- Power corrupts: magical power, political power, even moral certainty. all come with a price
- The world was broken BEFORE the story started. characters navigate existing damage

MAGIC AS CORRUPTION
- Magic is dangerous, costly, and often monstrous
- Every use of magic changes the user. physically, mentally, or morally
- The more powerful the magic, the greater the cost (and the more horrifying the manifestation)
- Magic is NOT a clean tool. it's a bargain, an addiction, a disease, or a curse
- Healing magic costs something equivalent to what it heals (or more)
- Some magic requires sacrifice. literal sacrifice, not metaphorical

VIOLENCE CRAFT
- Violence has CONSEQUENCES: physical, emotional, social, political
- Fight scenes are ugly, chaotic, and physically specific. not choreographed elegance
- The aftermath is as important as the act: trauma, guilt, physical recovery
- Every death matters. even unnamed characters die for reasons that serve the story
- Torture, if present, is about what it does to the TORTURER as much as the victim
- Gore serves the story's theme of cost. never gratuitous

MORAL ARCHITECTURE
- The reader should disagree with EVERY character at some point
- The protagonist does terrible things for understandable reasons
- The antagonist does reasonable things for terrible reasons (or vice versa)
- Questions are more important than answers: the book asks "what would YOU do?"
- No moral safety net. the story doesn't reassure the reader that everything will be okay
- BUT: nihilism is not depth. The darkness must MEAN something.

FORBIDDEN IN DARK FANTASY
- Gratuitous sexual violence (if sexual violence exists, it must serve theme and is never eroticised)
- Darkness for shock value with no thematic purpose
- Nihilism presented as sophistication (grey morality requires moral ENGAGEMENT, not absence)
- Heroes who are secretly good all along (undermine the moral complexity)
- "Clean" magic that works perfectly with no cost
- The "grimdark" checklist: gratuitous rape, torture porn, edgelord dialogue for the sake of it
- Powerless female characters whose suffering exists only to motivate male characters
- The "it was all meaningless" ending (the story must MEAN something, even if what it means is bleak)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (dread & violence), Captivation (worldbuilding), Revelation (cost of power).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Third close past tense (dominant) or first person (especially for unreliable narrators)
- Voice: Stark, precise, unsentimental. let the events carry the emotion; the prose doesn't need to weep
- Tone: Weight. Every sentence should feel like it costs something. The prose is lean, physical, and unflinching.
- Register: Can vary from gutter to courtly depending on POV, but always specific to the character

PROSE IMPERATIVES
- PHYSICAL detail over emotional label: dark fantasy shows what violence, magic, and loss DO to bodies
- The body is always present: hunger, cold, pain, exhaustion, the smell of blood and fire
- Beauty exists in dark fantasy. and is MORE powerful because of the surrounding darkness:
  "The sunset over the burning city was the most beautiful thing she'd seen in a year."
- Weather, landscape, and architecture reflect internal states without being heavy-handed
- Silence and stillness are tools. not every scene needs action; some of the darkest moments are quiet

SENSORY SPECIFICITY
- Dark fantasy lives in the senses that make readers uncomfortable:
  - SMELL: rot, blood, sweat, smoke, infection, rain on stone
  - TEXTURE: rust, bone, wet leather, the grit of ash between teeth
  - SOUND: the specific sound of a sword entering a body, screams that stop mid-breath, silence after battle
  - TASTE: copper (blood), bile, the metallic tang of fear, bad water
- Make the reader FEEL the world physically. comfort is rare and therefore precious

DIALOGUE CRAFT
- Characters speak like people under pressure: terse, evasive, cutting
- Dark humour is a survival mechanism. gallows jokes among soldiers, bitter wit from the damned
- Dialogue reveals character through what people WON'T say
- Power dynamics in every conversation: who can afford to speak freely, who can't
- Formal speech from those in power; blunt speech from those with nothing to lose
- No speechifying about morality. characters show their morality through choices, not lectures

VIOLENCE PROSE
- Short sentences during violence: the rhythm mimics adrenaline and shock
- Specific physical detail: not "he was wounded" but "the blade caught his forearm, just above the bracer. she could see tendons"
- Aftermath prose is LONGER: the body processes what happened; details arrive in a rush
- Violence is NEVER elegant: characters stumble, panic, make mistakes, fight dirty
- The emotional response to violence varies by character: a veteran is numb, a civilian is shattered, a fanatic is exalted

PROSE RHYTHM MAPPING
- Chapter 1 must establish moral ambiguity + visceral stakes. the prose is darker and grittier than standard fantasy from the first line
- Short sentences dominate violence: 6-12 words. Blunt. Physical. No ornamentation. The rhythm mimics the shock of impact
- Medium sentences (16-22 words) for moral wrestling: when characters weigh impossible choices, the prose stretches slightly. not languid, but deliberate, giving the weight of thought
- The overall rhythm is LEANER than epic fantasy. dark fantasy prose doesn't luxuriate. It observes. It records. It moves on
- Opening paragraphs: establish a controlled, watchful rhythm. The narrator is someone who has learned not to linger. Sentences are purposeful, not decorative
- Moments of beauty (and they must exist) use slightly longer sentences. their rarity makes the length shift powerful. The reader feels the protagonist noticing something worth slowing for
- Dialogue in dark fantasy: clipped. Characters under pressure don't speak in complete sentences. Let fragments and interruptions carry the tension
- Moral compromise scenes: the rhythm should feel tight, almost uncomfortable. medium sentences that don't resolve cleanly, mirroring the ethical bind
- Aftermath prose runs longer than combat prose: after violence, the body and mind process. sentences stretch to 18-25 words as details arrive in a delayed rush
- Silence and stillness: use very short paragraphs (1-2 sentences) to create rhythmic pauses. The absence of words carries dread
- Body-awareness passages: medium-short rhythm. The prose stays close to physical sensation. hunger, cold, pain. without elaboration
- Tension baseline: ≥6 from the first page. Dark fantasy opens with stakes already pressing. No gentle introductions
- Avoid lyrical excess. dark fantasy prose that becomes too beautiful undercuts its own grit. Beauty is earned through contrast, not sustained
- The paragraph as weapon: single-sentence paragraphs hit hard. Use them for revelations, deaths, and moral turning points
- End-of-chapter rhythm: either a slow, heavy final sentence (the weight of what just happened) or a sharp, cut-short fragment (the horror of what comes next)
- Read violence passages at speaking pace. if you can't deliver them in one breath per sentence, they're too long
- Gallows humor moments: quick rhythm, almost staccato. the joke lands and moves on before the darkness swallows it
- The goal: prose that feels like a blade. precise, economical, and capable of cutting deep when it needs to
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

DARK FANTASY CRAFT (40% of total):
- Moral complexity: no pure heroes or pure villains? (0-100)
- Consequences are permanent and felt? (0-100)
- Magic system is costly and dangerous? (0-100)
- Violence serves theme, not shock value? (0-100)

EMOTIONAL ARCHITECTURE (30% of total):
- Human moments contrast effectively with darkness? (0-100)
- The reader cares about characters despite (because of) their flaws? (0-100)
- Tension builds through moral weight, not just physical danger? (0-100)
- The darkness MEANS something (not nihilistic posturing)? (0-100)

PROSE QUALITY (30% of total):
- Physical, sensory prose that grounds the reader? (0-100)
- Dialogue is sharp, pressured, and character-specific? (0-100)
- Pacing alternates tension and release effectively? (0-100)
- Violence prose is specific and unflinching without being gratuitous? (0-100)

AUTOMATIC FAILS (score = 0):
- Gratuitous sexual violence or suffering for shock value
- Nihilism with no thematic purpose ("everything is meaningless" as the point)
- Magic without cost solving critical problems
- Female characters whose only role is to suffer and motivate male characters
- Darkness that reads as edgy adolescent posturing rather than genuine moral exploration
- The protagonist is secretly a good person all along (collapses the moral tension)
- Violence that is choreographed and elegant rather than ugly and consequential
```

## Continuity Rules

```
DARK FANTASY CONTINUITY. WHAT TO TRACK

CONSEQUENCES (CRITICAL):
- Every injury, death, betrayal, and moral compromise persists
- Characters do NOT bounce back. recovery is slow, incomplete, or changes them
- Political consequences of violence: killing a lord has faction repercussions
- A character who commits atrocity cannot be redeemed by a single act of kindness
- Reputation: what a character has done follows them; people remember

MAGIC CORRUPTION TRACKING:
- For each magic user: what they've used, what it cost them, what's changed
- Cumulative magical damage: track physical, mental, and moral degradation
- If magic has visible signs (veined skin, white eyes, premature aging), these persist and worsen
- Magical objects: who has them, what they've done, and what they're doing to the wielder

DEATH REGISTER:
- Named characters who die stay dead
- The manner and context of each death (was it meaningful? wasteful? heroic? pointless?)
- How survivors respond to each death. and how that response changes them
- Secondary effects: who inherits, who grieves, who benefits, who avenges

MORAL LEDGER (per POV character):
- What moral lines have they crossed?
- What do they tell themselves about those choices?
- What lines are they approaching but haven't crossed yet?
- How other characters respond to their moral choices
- Are they getting worse, better, or more numb?

PHYSICAL STATE:
- Scars, missing limbs, chronic injuries. track every permanent wound
- Nutritional state: are characters eating? In dark fantasy, hunger is real
- Magical corruption signs: what's visible, what's worsening
- Equipment degradation: armor is dented, swords are nicked, boots are worn
```

## Character Rules

```
DARK FANTASY CHARACTER ARCHETYPES

THE PROTAGONIST:
- Morally compromised. has done things that would make them a villain in another genre
- Understandable motivations: survival, loyalty to a few people, revenge, the last scraps of principle
- A SPECIFIC skill set: soldier, thief, mage, politician. not a generalist hero
- The flaw is REAL and creates REAL consequences (not "too brave" or "too loyal")
- Capable of change. but change is slow, costly, and not always for the better
- The reader roots for them not because they're good, but because they're HUMAN

THE ANTAGONIST:
- Has a point. The best dark fantasy antagonists are people the protagonist almost agrees with.
- Their methods are the problem, not necessarily their goals
- They are COMPETENT. they succeed at things, they plan well, they're dangerous
- They have people who love them, follow them, believe in them
- The reader should occasionally think: "they might be right"

THE MORALLY AMBIGUOUS ALLY:
- Valuable and dangerous in equal measure
- Their loyalty is conditional (on what? track this)
- They bring capabilities the protagonist lacks. at a cost
- When they betray (if they betray), the reader should have seen it coming AND still feel it

THE INNOCENT (if present):
- Exists to show what the darkness costs. their suffering has weight
- NOT a passive victim. they make choices within their limited power
- If they survive, they are changed. If they don't, their death has consequences.
- Beware the "woman/child in peril" trope. innocence should not be gendered

VOICE DIFFERENTIATION:
- Soldiers speak differently from nobles, who speak differently from mages
- Characters under stress reveal their true register
- Dark humour varies by character: gallows humour (soldiers), bitter wit (scholars), black comedy (the nihilistic)
- What characters WON'T say is as distinctive as what they will
```

## Arc Rules

```
DARK FANTASY STORY STRUCTURE

ACT 1: THE COST OF ENTRY (first 25%)
- Establish the world as already damaged. this is not a paradise being corrupted
- The protagonist is surviving, not thriving
- The inciting incident makes their situation WORSE (not "adventure calls")
- Establish the moral landscape: what passes for justice, who has power, what it costs
- Magic introduced through its CONSEQUENCES (not its wonders)
- The reader should understand within 3 chapters: this is a world where choices hurt
- END OF ACT 1: The protagonist is forced into action not by heroism but by necessity

ACT 2A: DEEPER IN (to midpoint)
- Each chapter requires a harder choice than the last
- Alliances formed out of need, not trust
- The scope of the threat becomes clearer. and it's WORSE than expected
- At least one significant death (named character, felt by protagonist)
- The magic system's true cost becomes apparent
- MIDPOINT: A revelation that raises the moral stakes. the "right" thing to do might also be the worst thing

ACT 2B: THE DESCENT (midpoint to dark moment)
- The protagonist compromises further to survive or achieve their goal
- Allies are lost, betrayed, or revealed to have their own agendas
- The physical world deteriorates: siege, plague, corruption, war
- The protagonist's defining flaw creates a catastrophic setback
- Other characters pay for the protagonist's choices
- DARK MOMENT: Not just defeat. moral reckoning. The protagonist confronts what they've become.

ACT 3: THE RECKONING (final 25%)
- Resolution comes through SACRIFICE, not triumph
- The protagonist uses everything they've learned. including the terrible things
- Victory, if it comes, is incomplete and costly
- Not everything is fixed. Some damage is permanent. Some people don't come back.
- The world continues, changed but not saved. surviving, like the protagonist
- The ending can be hopeful. but the hope must be EARNED through everything that came before

THE LIGHT IN THE DARK:
- Dark fantasy that is ONLY dark is exhausting and ultimately meaningless
- The moments of human connection. loyalty, tenderness, dark humor, a meal shared in silence. are what give the darkness weight
- These moments should be rare, brief, and therefore PRECIOUS
- The contrast between the world's cruelty and these small human acts IS the theme
```

## Timeline Rules

```
DARK FANTASY TIMELINE

CONSEQUENCES OVER TIME:
- Injuries take realistic time to heal (or don't heal fully)
- Armies need supply lines that span weeks and months
- Political shifts take time. coups have aftershocks, wars have logistics
- Magical corruption progresses: track the rate of degradation

RESOURCE TRACKING:
- Food, water, ammunition, magical supplies. dark fantasy worlds are SCARCE
- Characters can't fight if they haven't eaten in three days
- Supply lines determine strategy as much as courage does
- Track what each character has and when they'll run out

SEASONAL AND ENVIRONMENTAL:
- Dark fantasy seasons tend toward bleakness: hard winters, scorching droughts, plague seasons
- Environmental degradation from magic or war should progress over the timeline
- Bodies of the dead don't vanish. they create disease, political problems, and psychological weight

POLITICAL TIMELINE:
- Power vacuums don't last. someone always fills them
- Alliances shift as circumstances change
- Treaties have durations and conditions
- Succession crises play out in real time
```

## Genre-Specific Craft Techniques

Dark fantasy is a genre with an unusually demanding
ethical contract: it demands moral grey rather than
moral absence; it demands violence with consequence
rather than violence as spectacle; it demands magic
with cost rather than magic as solution; it demands
permanence rather than reset; and it demands hope only
when hope has been earned through sacrifice. The
canonical comp roster — Joe Abercrombie (The First Law
trilogy, Best Served Cold, The Heroes, Red Country),
Mark Lawrence (The Broken Empire, Red Sister, Book of
the Ancestor), Glen Cook (The Black Company chronicles),
Steven Erikson (Malazan Book of the Fallen), Robin Hobb
(the Farseer trilogy, the Liveship trilogy, the
Tawny Man), R. Scott Bakker (the Prince of Nothing,
the Aspect-Emperor), Andrzej Sapkowski (the Witcher
saga), Richard K. Morgan (A Land Fit for Heroes), Anna
Smith Spark (Court of Broken Knives), Brent Weeks (the
Night Angel trilogy), Michael R. Fletcher — established
the form; the contemporary masterclass roster — Tasha
Suri (the Books of Ambha, the Burning Kingdoms), Tamsyn
Muir (the Locked Tomb), V.E. Schwab (Vicious, the
darker Shades of Magic books), Jay Kristoff (the
Empire of the Vampire, the Nevernight chronicle),
Tochi Onyebuchi (War Girls, Riot Baby, Goliath),
Rebecca Roanhorse (Black Sun, the Between Earth and
Sky trilogy), S.A. Chakraborty (the Daevabad trilogy),
Nicholas Eames (the Band, the Kings of the Wyld),
Anna Stephens (the Godblind trilogy), Devin Madson
(the Reborn Empire), Mike Brooks, Christopher Buehlman
(the Black Tongue Thief), K.D. Edwards (the Tarot
sequence) — has expanded the genre's range to queer
dark fantasy, post-colonial dark fantasy, dark fantasy
of the diaspora, and dark fantasy that interrogates the
genre's own conventions. The most common failure modes
in this register are: **Edgelord-Aesthetic** (the
grimdark "bingo card" — gratuitous rape, cackling
madness, torture porn, profanity-as-sophistication —
deployed as substance rather than as a register the
craft must transcend; the genre's signature failure
mode); **Nihilism-as-Depth** (the "everything is
meaningless" position presented as moral sophistication,
when the genre's contract is that grey morality
requires moral ENGAGEMENT, not moral absence); **Gendered-
Suffering Default** (women as objects of violence whose
function is to motivate male characters — the genre's
most common ethical failure, fridging by another name);
**Cost-Free Magic** (magic that solves problems without
genuine cost; the magic-as-bargain contract violated;
the protagonist who casts and recovers in the same
chapter); **Choreographed-Combat Failure** (elegant
martial-arts violence rather than ugly, panicked, dirty
fighting; the genre's contract is that violence is
awful, not balletic); **Hidden-Hero Reveal** (the
protagonist who turns out to have been secretly good
all along — the kind of betrayal of moral grey that
the genre exists to prevent); **Aftermath-Skip** (the
act of violence rendered with full attention, the
aftermath glossed; the genre's contract is that
aftermath matters at least as much as the act);
**Dark-As-Wallpaper** (the world rendered as bleak
monotone without specific damage, specific cost,
specific consequence — bleakness as setting rather
than as material force); **Permanent-Death Violation**
(named characters dying and then being narratively
undone through retcon, miraculous healing, supernatural
revival; the genre's permanence contract broken); and
**Moral-Lecture Voice** (characters speechifying about
morality rather than demonstrating it through choices;
the dark-fantasy character does not philosophise — she
chooses, and the reader sees the choice). The
techniques below — two preserved (Moral Weight System,
Beauty-in-Darkness Technique) and three added (Cost-
Tracked Magic Discipline, Permanence Architecture,
Earned-Hope Calibration) — are designed to keep the
genre's defining commitments live: cost without
cliché, consequence without reset, hope without
betrayal of the moral grey.

### The Moral Weight System

Every significant chapter should include a MORAL WEIGHT moment:

**Categories of Moral Weight:**
| Type | Example | Effect on Character |
|------|---------|-------------------|
| **The Necessary Evil** | Killing a prisoner to prevent discovery | Character justifies it; reader questions |
| **The Impossible Choice** | Save the village or save the ally | Whatever they choose, something is lost |
| **The Slow Corruption** | Each small compromise leads to the next | Character doesn't notice how far they've gone |
| **The Price of Power** | Magic costs something real and permanent | Power gained = humanity lost |
| **The Betrayal** | Breaking faith for survival or advantage | Trust is the most expensive currency |
| **The Witness** | Being forced to watch and unable to act | Powerlessness as a form of damage |

**Rule:** The protagonist should face at least 6-8 of these across a standard novel, escalating in severity.

### Beauty-in-Darkness Technique

The most effective dark fantasy writing creates moments of unexpected beauty:

```
WRONG: Everything was bleak and terrible and the world was a ruin of ash and bone.
       (This is monotone. the reader goes numb)

RIGHT: The garden had gone wild behind the burned-out manor. Three years of neglect,
       and the roses had claimed the whole south wall, thorns thick as a man's thumb,
       blooming red and white through the charred window frames. Kael sat on the
       broken fountain lip and ate his stolen bread in silence. It was, he thought,
       the most peaceful place left in the province.
       (The beauty makes the destruction more poignant, not less)
```

### Dark Fantasy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "darkness consumed [character]" | Show the specific moral compromise |
| "the price of power" | Show the specific cost. what was lost |
| "the line between monster and man" | Show the specific moment of moral ambiguity |
| "the world was broken beyond repair" | Show the specific damage in a specific place |
| "blood magic demanded sacrifice" | Show the specific ritual and specific cost |
| "corruption seeped into everything" | Show the specific corruption in one person or institution |
| "the abyss stared back" | Show the specific psychological consequence |
| "a world without hope" | Show one person's specific reason to keep going |
| "the darkness within was more terrifying than any monster" | Show the specific internal struggle through action |
| "mercy was a luxury they couldn't afford" | Show the specific decision |
| "the gods had abandoned them" | Show the specific evidence. a prayer unanswered, a temple fallen |
| "darkness within his soul" | Cut soul-cliché; show one specific compromised act |
| "the world drank blood" | Cut metaphor; show the specific carnage and its specific consequence |
| "she was a survivor of a thousand wars" | Cut hyperbole; show ONE specific battle and what it left |
| "no light could reach this place" | Cut; show the specific quality of the place's bleakness |
| "the cost of war on the soul" | Cut soul-cliché; show one specific bodily or psychological mark |
| "they were beyond redemption" | Cut; show the specific act that closes the door |
| "his hands knew only violence" | Cut character-through-hands cliché; show the specific gesture |

### The Cost-Tracked Magic Discipline

Dark fantasy's foundational contract is that magic
costs. The Cost-Free Magic failure mode collapses the
genre because cost is what distinguishes dark fantasy
from epic fantasy in its magical texture. The Cost-
Tracked Magic Discipline is the requirement that every
use of magic in the manuscript carry a specific running
cost visible in the prose, and that costs accumulate
across the manuscript rather than reset.

```
PRINCIPLE
For every use of magic by every character, the
manuscript must specify at least three of the
following five cost categories:
1. BODILY — the physical toll registered in the
   body (blood from the nose, the dropped weight,
   the hair gone white, the limb that won't fully
   move again, the seizure, the fever, the years
   subtracted)
2. TEMPORAL — the time the body needs to recover,
   rendered specifically (three days bedridden, a
   week unable to cast again, the lingering tremor
   that does not go away within the manuscript)
3. PSYCHOLOGICAL — the mental toll (the memory
   lost, the personality fragment that drifts away,
   the dream that is no longer hers, the
   recognition that something inside her has been
   quietly traded)
4. RELATIONAL — what the magic costs in
   relationships (the lover who cannot bear to look
   at the marks; the brother who watches and
   understands what she has become; the priest who
   refuses her now)
5. MORAL — the line crossed by performing the magic
   (the sacrifice required; the consent not given;
   the body fed to the working; the cumulative
   moral position the character now occupies)

REQUIREMENTS
- The cost must be SPECIFIC (named, sensory,
  located in the body)
- The cost must be PERSISTENT (visible in
  subsequent chapters; not reset by the next
  morning)
- The cost must be CUMULATIVE (later spells cost
  more, or the cumulative total is now visible in
  the body, mind, or relationships)
- The most powerful magic must cost the most
  (the cost-power gradient is monotonic; not
  random)

CALIBRATION TEST
- For every magic-use scene, can the reader name
  the specific cost paid?
- Across the manuscript, can the reader trace the
  cumulative cost of magic on each user (named
  scars, named losses, named relational damage,
  named moral position shifts)?
- Does the protagonist's most powerful magic cost
  more than her smallest? Is the gradient
  monotonic?
- Could a magic scene be removed from the
  manuscript without the rest of the manuscript
  noticing? If yes, the cost has not persisted.
If any answer is no — rebuild for cost-tracking.

ANTI-PATTERN
- Magic cast and recovered from in the same chapter
- The protagonist who casts in chapter 3 and shows
  no sign of it in chapter 4
- Cost mentioned generally ("magic was tiring")
  without specific bodily, temporal, psychological,
  relational, or moral rendering
- Healing magic that costs nothing
- The character who casts increasingly powerful
  spells without increasingly visible damage
- Magic-as-tactical-resource (point spent, point
  recovered, no scar)
```

### The Permanence Architecture

The genre's defining structural commitment is that
consequences persist. Deaths stay dead. Wounds leave
scars. Betrayals are not forgiven by a single act of
kindness. Political consequences play out across the
manuscript. The Permanent-Death Violation and the
Aftermath-Skip failure modes both emerge when the
manuscript fails to track and render permanence; the
Permanence Architecture is the discipline that
enforces it.

```
PRINCIPLE
The manuscript must track and render permanence across
at least four of the following five categories:
1. DEATH REGISTER — every named character death
   tracked, with manner, context, and ongoing
   consequence (who grieves, who inherits, who
   benefits, who avenges); resurrection or revival
   only if it is the genre's explicit subject (and
   even then with cost)
2. INJURY REGISTER — every significant injury
   tracked, with realistic recovery time and
   permanent residue (limb gone is gone; eye lost
   is lost; chronic pain persists; gait is changed;
   the scar is visible in subsequent chapters)
3. BETRAYAL REGISTER — every betrayal tracked,
   with specific relational damage; trust does not
   simply rebuild; the betrayed character carries
   the betrayal forward; the betrayer's standing
   in the group has shifted permanently
4. POLITICAL REGISTER — the consequences of every
   political act rendered across chapters; the
   killing of a lord triggers faction repercussions
   that play out; the broken treaty has aftershocks;
   the coup creates a power vacuum that someone
   fills
5. MORAL REGISTER — every moral compromise tracked
   in the moral ledger; characters do not bounce
   back from atrocity; the choice made in chapter
   12 is still operative in chapter 28

CALIBRATION TEST
- Can a reader, after the manuscript ends, point to
  every named death, every significant injury,
  every betrayal, and every moral compromise, and
  trace its persistence across the chapters?
- Does the manuscript ever undo a death or a
  serious injury through narrative convenience? If
  yes, the contract has been broken.
- Does the protagonist who killed in chapter 4 show
  the mark of that killing in chapter 24?
- Does the political consequence of chapter 8's
  violence still operate in chapter 28's plot?
- Does the betrayed character behave like someone
  who was betrayed, in every subsequent scene with
  the betrayer?
If any answer is no — rebuild for permanence.

ANTI-PATTERN
- The character who is grievously wounded in
  chapter 6 and fully healed by chapter 9 with no
  ongoing residue
- The named-character death that is later revealed
  to have been a fake-out
- The betrayal forgiven without specific work
- The killing that does not mark the killer
- The political event whose consequences end with
  the chapter
- The chronic injury that the protagonist
  remembers when convenient and forgets when
  inconvenient
```

### The Earned-Hope Calibration

Dark fantasy that is purely dark exhausts the reader
and ultimately renders the darkness meaningless. The
genre's signature emotional shape is darkness with
small precious moments of human connection — the
gallows joke, the meal shared in silence, the loyalty
maintained against pressure, the brief tenderness — and
endings that, if hopeful, are hopeful only because the
hope has been earned through sacrifice and continues to
coexist with permanent damage. The Earned-Hope
Calibration is distinct from cli-fi's earned hope: dark
fantasy's hope must arrive through specific cost paid,
must remain partial, and must not betray the moral grey.

```
PRINCIPLE
Hope in the manuscript must satisfy at least four of the
following five criteria:
1. PAID-FOR — hope arrives through specific
   sacrifice; what was given to earn it is named and
   permanent (the friend dead, the limb lost, the
   moral compromise that closed the door, the magic
   used that cannot be unmade)
2. PARTIAL — hope coexists with what was not saved;
   the manuscript names what is still broken, what
   continues to suffer, what has been irrevocably
   lost
3. SCARRED — the survivors of the hopeful ending
   carry the marks of what they survived; their
   bodies, minds, and relationships show the cost
4. CONTINGENT — the hope is not guaranteed; the
   manuscript's ending acknowledges that the
   hope could fail; the world's grey continues
5. SMALL — the hope is human-scale (a meal shared
   in peace, a child playing safely, a wound that
   no longer bleeds, a name remembered, a quiet
   moment unguarded) rather than cosmic-scale
   (the world saved, the dark lord defeated
   forever, the curse lifted from all generations)

CALIBRATION TEST
- Can the reader name what was paid to earn the
  manuscript's hope?
- Is the hope partial — does the manuscript
  acknowledge what was not saved?
- Are the survivors visibly marked by what they
  survived, and does the prose render the marks?
- Could the manuscript's hopeful ending be
  reversed in a sequel without contradicting its
  internal logic? (If yes, the contingency is
  honoured.)
- Is the hope human-scale rather than cosmic-scale?
If any answer is no — rebuild.

ANTI-PATTERN
- The "and they all lived" ending in dark fantasy
- The hope that arrives without specific sacrifice
- The hope that erases the prior darkness from the
  characters' bodies and minds
- The cosmic hope (the dark lord defeated, the
  curse lifted, the world made whole) without
  paid-for cost
- The protagonist who emerges from the darkness
  unmarked
- Pure-bleak ending with no human moment of
  connection — the inverse failure mode (the
  genre's contract is that small precious moments
  are the foundation, even when the overall
  shape is bleak)
```

## Genre-Specific Revision Rules

### Six-Pass Dark Fantasy Audit (Run FIRST in editorial pipeline)

The Dark Fantasy Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Moral Complexity Pass

Verify the protagonist is morally compromised — not
secretly good, not redeemable through a single act of
kindness, not a hero in costume. The Hidden-Hero
Reveal failure mode is caught here. for the manuscript
to be dark fantasy rather than epic-fantasy-with-
darker-aesthetic, the protagonist must do terrible
things for understandable reasons, and the reader must
remain in moral discomfort rather than cheering her on.
Audit each chapter: does the antagonist have
comprehensible motivations the protagonist could
almost agree with? Are moral choices presented without
authorial judgment? Is darkness serving theme rather
than spectacle? The Edgelord-Aesthetic and Nihilism-
as-Depth failure modes are caught here. if the
darkness is gratuitous or if the manuscript's position
is "everything is meaningless", rebuild for moral
engagement.

#### Pass 2: Consequence Persistence Pass

Verify the manuscript's permanence contract. The
Permanence Architecture provides the spec — death
register, injury register, betrayal register, political
register, moral register. Audit each chapter: do deaths
stay dead? Do wounds leave scars that persist into
subsequent scenes? Do betrayals have lasting relational
impact? Do political acts produce ongoing consequences?
Are characters who committed violence changed by it in
visible, specific ways? The Aftermath-Skip and
Permanent-Death Violation failure modes are caught
here. if the manuscript ever undoes a death or fully
heals an injury through narrative convenience, the
contract has been broken and must be rebuilt.

#### Pass 3: Tone Balance Pass

Verify the manuscript's tonal architecture is varied,
not a single monotone of bleakness. The genre's
contract is that the moments of human connection —
gallows humour, brief tenderness, loyalty maintained,
the meal shared in silence — give the darkness weight
through contrast. Audit each chapter for at least one
moment of human connection (or its absence rendered
specifically; the lack of these moments must be
deliberate rather than accidental). Is the darkness
varied across chapters or is the prose monotone? Does
the manuscript make the reader FEEL, not just observe?
Is there hope (however fragile) alongside the despair?
The Dark-As-Wallpaper failure mode is caught here. if
the manuscript reads as bleak in a single tonal
register without specific moments of contrast, rebuild.

#### Pass 4: Violence Audit Pass

Verify every violent scene serves the story's themes
and is rendered with the genre's specific commitments.
Is the violence ugly and consequential rather than
elegant or cool? Are characters fighting dirty, panicked,
making mistakes? Is the body specific — the precise
wound, the precise physical detail, the precise sound?
Is aftermath given as much weight as the act? Are
characters' emotional responses to violence varied by
character (the veteran is numb; the civilian is
shattered; the fanatic is exalted)? The Choreographed-
Combat Failure is caught here. if the violence reads
as choreographed martial-arts elegance, rebuild for
the genre's signature ugliness. Crucially: is there any
gratuitous suffering, especially gendered suffering? If
sexual violence appears, does it serve theme rather
than spectacle, and is it never eroticised? The
Gendered-Suffering Default failure mode is the genre's
most common ethical failure. catch it ruthlessly.

#### Pass 5: Magic Corruption Tracking Pass

Verify every use of magic is logged with its cost.
The Cost-Tracked Magic Discipline provides the spec —
bodily, temporal, psychological, relational, moral.
Audit each chapter: for every magical act, is the
cost specific (named, sensory, located in the body)?
Does the cost persist into subsequent scenes? Is the
cumulative cost on each magic-user visible across the
manuscript? Does the most powerful magic cost the
most? The Cost-Free Magic failure mode is caught here.
if magic solves problems without genuine cost, the
genre's foundational contract has been violated and
must be rebuilt. Also verify: corruption signs (veined
skin, white eyes, premature aging) where present, do
they persist and worsen? Magical objects tracked, with
their effects on the wielder visible across chapters?

#### Pass 6: Cost-Tracked + Permanence + Earned-Hope Integration

This pass is the dark fantasy integration check — it
ties the new techniques together and verifies the
genre's defining commitments are honoured chapter by
chapter, with particular attention to the manuscript's
shape.

For COST-TRACKED: confirm Pass 5's spec has been met
across the manuscript. Across all magic-users, are at
least three of the five cost categories visible
(bodily / temporal / psychological / relational /
moral)? Are the costs specific, persistent, and
cumulative? Could the manuscript's magic be removed
without the world noticing the absence?

For PERMANENCE: confirm Pass 2's spec across the
manuscript's full register categories. Can a reader
trace every named death, every significant injury,
every betrayal, every political act, every moral
compromise from its origin to its persistence
across the chapters?

For EARNED-HOPE: at the manuscript level (not just
chapter level), audit whether the ending's hope (if
present) satisfies at least four of the five Earned-
Hope criteria — paid-for, partial, scarred,
contingent, small. If the manuscript's ending is
purely bleak, verify there are still small precious
moments of human connection that gave the darkness
weight throughout. If the manuscript's ending is
hopeful, verify the hope is paid-for through
specific sacrifice, that survivors carry visible
marks, and that the hope is human-scale rather than
cosmic-scale. The "and they all lived" ending
collapses the genre; the all-bleak ending without
human contrast also collapses the genre. The genre's
shape is precarious balance, and Pass 6 is where
that balance is verified.

## Names & Patterns to Avoid

### Dark Fantasy Character Names. NEVER USE
- Edgelord names: Darkblade, Shadowkill, Grimjaw, Bloodraven, Deathwhisper
- Generic grim names: Thane, Kael, Bron, Ash, Grim, Scar
- Faux-medieval: Aldric, Cedric, Lysander, Seraphina (too clean for dark fantasy)

### Dark Fantasy Place Names. NEVER USE
- "[Death/Dark/Blood] + [Feature]": Deathmarsh, Bloodmoor, Darkhollow
- "[Ruin/Ash/Bone] + [Structure]": Ashkeep, Ruinspire, Boneforge
- Generic apocalyptic: The Wastes, The Blight, The Desolation

### Dark Fantasy Tropes. AVOID or SUBVERT
- The "grimdark bingo card": gratuitous rape, cackling madness, torture as plot
- The anti-hero who is actually just a hero pretending to be dark
- The "hard man making hard decisions" who never suffers consequences
- Women as objects of violence to motivate male characters (fridging)
- Evil races/species (if a group is presented as uniformly evil, the story isn't dark. it's lazy)
- The revenge plot that justifies everything

### Use Instead
- Names that sound WORN: shortened, nicknames, names given by others rather than parents
- Place names that tell a history: "The Crossroads" (where three armies met), "Salt Flat" (an inland sea that died), "The Mark" (a border scar)
- Characters whose "dark" traits are specific human failings: cowardice, addiction, selfishness, grief that became rage

## Comp Titles

Dark-fantasy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Black Company* — Glen Cook (1984): the grimdark mercenary-fantasy template.
- *Last Call* — Tim Powers (1992): occult dark-fantasy benchmark.
- *Gardens of the Moon* — Steven Erikson (1999): the Malazan Book of the Fallen; literary dark-epic.
- *The Blade Itself* — Joe Abercrombie (2006): the First Law trilogy; modern grimdark benchmark.

### Contemporary (current best-in-class)

- *Prince of Thorns* — Mark Lawrence (2011): the Broken Empire; protagonist-as-villain dark-fantasy.
- *Court of Broken Knives* — Anna Smith Spark (2017): literary grimdark.
- *Empire of the Vampire* — Jay Kristoff (2021): vampire dark-fantasy doorstop.
- *The Poppy War* — R.F. Kuang (2018): military dark-fantasy with non-Western framing.
- *Jade City* — Fonda Lee (2017): the Green Bone Saga; East-Asian-rooted dark-crime-fantasy.
- *Realm Breaker* — Victoria Aveyard (2021): YA-leaning dark-fantasy.
- *Black Leopard, Red Wolf* — Marlon James (2019): literary African dark-fantasy.
- *The Locked Tomb* (Gideon the Ninth) — Tamsyn Muir (2019): queer necromancer-dark-fantasy.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Dark, atmospheric landscapes with dramatic lighting; lone figure against a blighted world; the DOMINANT style for dark fantasy; should feel like the poster for a film you'd be afraid to watch alone
- **Minimalist**. A single striking symbol (broken crown, bloody sword, skull, thorned vine) against a dark textured background; powerful at thumbnail; increasingly popular for grimdark
- **Illustrated**. Dark, painterly illustration with visible brushwork; not the clean illustration of epic fantasy but rougher, more expressionist; good for conveying the genre's rawness
- **Abstract**. Symbolic imagery (a single drop of blood on snow, a sword point-down in earth, smoke rising from ruins); literary end of the genre; understated but evocative

### Genre Cover Aesthetics
- **Styles:** Lone figures in desolate landscapes, dramatic chiaroscuro lighting, weathered textures (rust, blood, ash), minimal composition with heavy atmosphere, environmental storytelling through ruined architecture or scarred terrain, silhouettes against burning or stormy skies
- **Colours:** Charcoal and ash grey (the dominant tone), blood red and rust (violence, sacrifice), sickly amber and ochre (decay, corruption), cold steel blue (weapons, winter, despair), bone white accents (death, prophecy), very limited palette. dark fantasy covers are NOT colourful
- **Elements:** Weapons (always used, not decorative. nicked blades, bloody hilts), single figures (battle-worn, cloaked, scarred), ruined landscapes, fire and smoke, bones and skulls (sparingly), armor and heraldry (battered, not polished), ravens and wolves, dead trees and scorched earth
- **Typography:** Bold, weathered, distressed fonts; title as if carved or burned into the cover; metallic effects (silver, iron, dark gold) rather than bright gold; series branding should feel like a battle standard; nothing clean or elegant. the typography should match the world's roughness

### Market Positioning
Dark fantasy covers must signal "this will cost you something to read". weight, consequence, moral complexity. The cover should feel heavy and atmospheric, not exciting or inviting. Position against Abercrombie, Cook, Lawrence, Erikson, Gwynne. Dark backgrounds with a single bright element (fire, blood, a blade's edge) create the strongest thumbnails. The trend is toward simpler, more symbolic covers rather than detailed scenes. a broken crown says more than a painted battle.

### Cover Design DON'Ts
- No bright, warm colours. dark fantasy is muted, cold, and heavy
- No heroic poses. nobody stands triumphant on a dark fantasy cover; they survive, barely
- No clean, polished aesthetics. everything should look used, worn, damaged
- No elaborate fantasy scenes with multiple characters and monsters. simpler is stronger
- No romance elements (embracing couples, flowing hair). this signals dark romance, not dark fantasy
- No cute or whimsical elements. this is not grimdark comedy (usually)
- No Tolkien-esque pastoral elements. dark fantasy worlds are not beautiful places to visit
