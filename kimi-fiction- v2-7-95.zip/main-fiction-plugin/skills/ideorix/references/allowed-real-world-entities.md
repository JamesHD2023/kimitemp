---
name: allowed-real-world-entities
description: "Allowlist of real-world places, brands, public bodies, and document terminology that may appear in any chapter without counting as entity-canon drift"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Real-World Entities Allowlist

This file is loaded by `scripts/entity-canon-verify.sh` alongside the
project's `engine-data/entity-canon.md`. Capitalised tokens listed
here are recognised as legitimate real-world references and do NOT
count as canon drift when they appear in chapter prose.

Project-specific entities (characters, fictional places, fictional
companies) belong in the project's own `entity-canon.md`, not here.

The script tokenises this file by extracting any capitalised word
appearing in any list, table, or paragraph below. Multi-word names
are split into their constituent capitalised tokens so partial
matches register as allowed (e.g. "Manchester Piccadilly" allows
"Manchester" and "Piccadilly" individually).

## UK cities and regions

London, Edinburgh, Glasgow, Cardiff, Belfast,
Manchester, Liverpool, Birmingham, Leeds, Sheffield, Bristol, Newcastle,
Bradford, Coventry, Nottingham, Leicester, Stoke, Sunderland, Plymouth,
Southampton, Portsmouth, Brighton, Hove, Reading, Oxford, Cambridge,
Norwich, Bath, Exeter, York, Durham, Carlisle, Chester, Lancaster,
Aberdeen, Dundee, Inverness, Stirling, Perth,
Swansea, Newport, Wrexham,
Cheshire, Yorkshire, Lancashire, Merseyside, Greater Manchester,
West Midlands, East Midlands, North Yorkshire, South Yorkshire,
West Yorkshire, Surrey, Kent, Sussex, Essex, Norfolk, Suffolk,
Devon, Cornwall, Somerset, Dorset, Wiltshire, Hampshire,
Northumberland, Cumbria, County Durham, Tyne and Wear,
Highlands, Lowlands, Borders, Hebrides, Orkney, Shetland,
Snowdonia, Brecon Beacons, Lake District, Peak District,
Cotswolds, Yorkshire Dales

## US, Canadian, Australian, NZ, Irish cities and regions

New York, Los Angeles, Chicago, Houston, Phoenix, Philadelphia,
San Antonio, San Diego, Dallas, San Jose, Austin, Seattle, Denver,
Boston, Detroit, Miami, Atlanta, Minneapolis, San Francisco,
Washington, Baltimore, Cleveland, Pittsburgh, Portland,
California, Texas, Florida, New Jersey, Virginia, Massachusetts,
Toronto, Montreal, Vancouver, Calgary, Ottawa, Edmonton,
Quebec, Ontario, Alberta, British Columbia,
Sydney, Melbourne, Brisbane, Perth, Adelaide, Auckland, Wellington,
Dublin, Cork, Galway, Limerick, Belfast, Derry

## European and global cities

Paris, Berlin, Madrid, Rome, Vienna, Amsterdam, Brussels, Stockholm,
Copenhagen, Helsinki, Oslo, Lisbon, Athens, Warsaw, Prague,
Budapest, Munich, Hamburg, Frankfurt, Cologne, Milan, Naples,
Florence, Venice, Geneva, Zurich, Barcelona, Seville, Dublin,
Tokyo, Beijing, Shanghai, Mumbai, Delhi, Cairo, Lagos, Johannesburg,
Nairobi, Cape Town, Singapore, Hong Kong, Seoul, Bangkok,
Mexico City, Buenos Aires, São Paulo, Rio de Janeiro

## UK streets, landmarks, and infrastructure terms

Street, Road, Avenue, Lane, Drive, Crescent, Close, Square, Terrace,
Hill, Mews, Gardens, Place, Way, Walk, Park, Common, Green,
Bridge, Station, Junction, Roundabout, Motorway, Bypass, Highway,
Piccadilly, Oxford Circus, Trafalgar Square, Leicester Square,
Westminster, Whitehall, Downing Street, Parliament,
Buckingham Palace, Tower Bridge, London Bridge,
King Cross, Paddington, Euston, Waterloo, Victoria, Liverpool Street,
Heathrow, Gatwick, Stansted, Luton

## Brands and companies (UK + global, public knowledge)

Tesco, Sainsbury, Asda, Morrisons, Waitrose, Aldi, Lidl, Coop,
Boots, Superdrug, Iceland, Marks Spencer, John Lewis, Argos,
Apple, Microsoft, Google, Amazon, Meta, Facebook, Instagram,
Twitter, WhatsApp, Netflix, Spotify, YouTube, TikTok, LinkedIn,
Yale, Nokia, Samsung, Sony, Panasonic, LG, Bosch, Siemens, Philips,
Visa, Mastercard, American Express, PayPal, Stripe,
HSBC, Barclays, Lloyds, NatWest, Halifax, Santander, Nationwide,
BBC, ITV, Channel, Sky, Virgin, BT, EE, Vodafone, Three,
Disney, Pixar, Marvel, Warner, Universal, Paramount,
BMW, Audi, Ford, Vauxhall, Volkswagen, Toyota, Honda, Mercedes,
Hyundai, Kia, Nissan, Mazda, Subaru, Tesla, Porsche, Jaguar,
Land Rover, Volvo, Renault, Peugeot, Citroen, Fiat, Mini,
Nike, Adidas, Puma, Reebok, Levi, Gap, Zara, Primark, Next,
Costa, Starbucks, Pret, Greggs, Wetherspoons, Nando, McDonald,
Burger King, KFC, Subway, Domino, Pizza Hut

## UK public bodies, institutions, and document terminology

Parliament, Commons, Lords, Government, Cabinet, Minister, Secretary,
Crown, Court, Coroner, Inquest, Tribunal, Ombudsman,
Royal Mail, National Health Service, NHS, Land Registry,
Companies House, HMRC, Inland Revenue, DVLA, DWP, Home Office,
Foreign Office, Treasury, Ministry of Defence, MoD,
Council, Borough, District, Parish, County, Authority,
Constabulary, Police Service, Police Force, Metropolitan Police,
West Midlands Police, Greater Manchester Police, Cheshire Constabulary,
Northumbria Police, North Wales Police, Police Scotland, Garda,
Civil Service, Whitehall, Westminster,
University of, College of, School of, Academy of,
Cause, Finding, Signed, Case, Deceased, Born, Died, Director,
Registered, Witness, Statement, Subject, Reference, Date, Time,
Address, Postcode, National Insurance, Birth Certificate,
Death Certificate, Marriage Certificate, Passport, Driving Licence,
Probate, Will, Estate, Executor, Beneficiary, Trustee

## Transport networks and operators

Northern, Southern, Western, Eastern, Central, Underground, Overground,
TfL, Transport for London, Transport for Wales,
Metrolink, Tramlink, Supertram, Nexus,
Network Rail, Avanti, LNER, GWR, Cross Country, ScotRail, TransPennine,
Greater Anglia, South Western, Southeastern, Thameslink, Chiltern,
National Express, Megabus, Stagecoach, Arriva, FirstGroup,
British Airways, Virgin Atlantic, EasyJet, Ryanair, Jet, Wizz,
Eurostar, Eurotunnel,
Highway, Motorway, A-Road, B-Road

## Newspapers, journals, broadcasters

Times, Guardian, Telegraph, Independent, Mail, Mirror, Express,
Sun, Star, Metro, Standard, FT, Financial Times, Observer,
Liverpool Echo, Manchester Evening News, Yorkshire Post,
Western Mail, Scotsman, Herald, Belfast Telegraph,
Spectator, New Statesman, Private Eye, Economist,
Saturday Live, Today, Newsnight, Question Time,
Reuters, Bloomberg, Associated Press, AFP

## Languages, nationalities, demonyms

British, English, Welsh, Scottish, Irish, Northern Irish, Cornish,
American, Canadian, Australian, New Zealand, Kiwi,
French, German, Italian, Spanish, Portuguese, Dutch, Belgian,
Swiss, Austrian, Polish, Czech, Hungarian, Greek, Russian, Ukrainian,
Swedish, Norwegian, Danish, Finnish, Icelandic,
Chinese, Japanese, Korean, Vietnamese, Thai, Filipino, Indonesian,
Malaysian, Singaporean, Indian, Pakistani, Bangladeshi, Sri Lankan,
Egyptian, Moroccan, Algerian, Tunisian, Libyan, Sudanese,
Nigerian, Ghanaian, Kenyan, Tanzanian, Ugandan, Ethiopian,
South African, Zimbabwean, Zambian, Botswanan,
Mexican, Brazilian, Argentinian, Chilean, Peruvian, Colombian,
Venezuelan, Cuban, Puerto Rican, Jamaican, Trinidadian,
Catholic, Protestant, Anglican, Methodist, Baptist, Pentecostal,
Jewish, Muslim, Hindu, Sikh, Buddhist

## Calendar and clock

Spring, Summer, Autumn, Fall, Winter,
Easter, Christmas, Eve, New Year, Halloween, Bonfire Night,
Diwali, Eid, Hanukkah, Passover, Ramadan, Lent,
Olympics, World Cup, Six Nations, Wimbledon, Glastonbury,
Edinburgh Festival, Notting Hill Carnival,
Greenwich Mean Time, GMT, BST, UTC, EST, PST

## Currency

Pound, Sterling, Pence, Penny, Dollar, Cent, Euro, Yen, Yuan,
Bitcoin, Ethereum

## Common Western personal names appearing in passing

(Names of well-known historical / cultural figures the prose may
reference without intending them as canon entities. Project should
add specific characters to its own entity-canon.md.)

Christ, Jesus, Mary, Joseph, Moses, Abraham, Adam, Eve,
Shakespeare, Dickens, Austen, Bronte, Hardy, Eliot,
Newton, Darwin, Einstein, Hawking, Curie, Galileo,
Lincoln, Washington, Churchill, Thatcher, Blair, Obama,
Beatles, Rolling Stones, Beethoven, Mozart, Bach
