---
name: craft-standards
description: "Universal prose craft rules and 7 Craft Commandments"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Universal Prose Craft Standards

## Overview

These rules apply to ALL genres. They are the baseline craft expectations
that every chapter must meet. Genre-specific rules (from the genre bank)
may override or supplement these, but never lower the bar.

## The Eight Rules

### Rule 1: Emotions Are Physical, Not Named

```
WRONG: She felt nervous about the meeting.
WRONG: A wave of anxiety washed over her.
WRONG: Fear gripped her heart.

RIGHT: She checked her phone three times in the elevator. Adjusted her collar.
       The doors opened and she walked out before they'd finished.
```

Show what the emotion DOES to the body. The reader identifies the feeling.

### Rule 2: World-Building Through Daily Life

```
WRONG: The town of Millbrook had been a fishing village for three generations.
       The economy had shifted to tourism in the 1990s, but many old families...

RIGHT: Frank still kept his nets hung behind the bait shop, though the last
       time he'd taken the boat out, most of the dock had been converted
       to kayak rentals.
```

Demonstrate the world through characters living in it.

### Rule 3: Theme Lives in Action, Not Dialogue

```
WRONG: "I think the real problem with our generation is that we've forgotten
        how to trust each other," she said, staring at the skyline.

RIGHT: She saw the old man drop his wallet. Three people walked past.
       She picked it up, jogged after him, and pressed it into his hand.
       He counted the bills before thanking her.
```

Theme emerges from what characters DO, not what they SAY about society.

### Rule 4: Scenes Move Through Action, Not Reflection

```
WRONG: She thought about everything that had happened yesterday. The argument
       with Marcus had been painful. She remembered how he'd looked at her...

RIGHT: The coffee was cold. She'd been staring at the same paragraph for
       twenty minutes. Her phone buzzed — Marcus again — and she flipped
       it face-down.
```

Open mid-action. Internal reflection comes through physical behavior.

**The Just Talk Test (enforcement corollary):**
For any scene with 2+ characters: mentally remove all dialogue. If nothing
HAPPENS — no physical action, no material change, no movement through space —
the scene is static. Characters must DO things while talking: cook, drive,
search, build, walk, pack, examine evidence, treat wounds. If they're just
sitting across a table exchanging information, add physical business that
creates subtext or advances the plot. The Quality Guardian's Just Talk Test
(see `quality-gate.md`) formally scores this. The Writer should apply it
during generation to avoid the fix at verification.

### Rule 5: Dialogue Is Behavior, Not Information

Every line of dialogue must do AT LEAST two of:
- Advance the plot
- Reveal character
- Build tension
- Establish relationships
- Misdirect (in mystery/thriller)

```
WRONG: "I've been working at the bakery for fifteen years," she said.
       "My mother started it in 1985."

RIGHT: "Fifteen years I've been up at four AM for this place." She slid
       the tray in hard enough to rattle the rack. "Mom never mentioned
       that part when she handed me the keys."
```

### Rule 6: The Familiar Is a Character

Pets, recurring objects, rituals — these are not decoration.
They have consistent personality and serve the story.

```
WRONG: The cat meowed. She petted the cat. The cat purred.

RIGHT: Barnaby sat on the manuscript pages, as he always did when she needed
       them. He'd learned that the rustling sound meant she'd come to his
       level, and he'd been training her for six years.
```

### Rule 7: No Identical Sentence Constructions

Vary sentence length and structure. Three short sentences in a row create urgency.
A long sentence after short ones creates a breath. Use this intentionally.

```
WRONG: She walked to the door. She opened the door. She stepped through
       the door. She looked around the room.

RIGHT: She walked to the door. Opened it. The room beyond was darker than
       she'd expected, and the smell hit her before she found the light —
       copper and something sweet, like rotting fruit.
```

### Rule 8: Specific Over Generic

```
WRONG: She drove a nice car. He wore expensive clothes. The restaurant was fancy.

RIGHT: She drove a 2019 Volvo XC90 — the kind of car that said money but
       not flash. His jacket was Barbour, waxed and softened from actual use.
       The restaurant didn't list prices.
```

Specific details create believability. Generic descriptions create nothing.

### Rule 9: The Aftermath Rule

AI writing resolves significant events (violence, betrayal, revelation, intimacy)
and moves on. Published fiction spends MORE time on the aftermath than the event
itself. The shaking hands after a confrontation. The inability to eat after a
discovery. The way a door that used to be just a door is now a threat.

```
WRONG: The fight was over. She picked herself up and went to meet David.

RIGHT: The fight was over. She sat in the car for eleven minutes. Her hands
       wouldn't stop shaking, so she gripped the steering wheel until her
       knuckles turned white, and then she watched them turn white, and that
       was somehow worse. She was eight minutes late to meet David. He didn't
       ask why. She didn't offer.
```

**The rule:** Every significant event (violence, betrayal, revelation, intimate
moment, major decision) must have proportional aftermath. The aftermath is where
character is revealed — how someone REACTS after the adrenaline drops shows who
they really are. Events without aftermath have no weight.

**Enforcement:**
- After any scene rated Tension 7+ in the Architect's sliders, the NEXT scene must
  include at least one aftermath beat (physical recovery, emotional processing through
  action, changed behavior toward another character)
- After intimate or vulnerable scenes, at least one character's subsequent behavior
  must be visibly different (awkwardness, tenderness, regret, a new guard, quiet
  certainty — NOT a return to baseline)
- The Writer should never transition directly from a high-intensity scene to an
  unrelated new plot thread without at least 2-3 sentences of aftermath grounding

---

## The 7 Craft Commandments

These are the Writer agent's operating principles. Every chapter is evaluated
against them. The Quality Guardian scores each commandment per chapter.

### Commandment 1: DISCOVERY, NOT EXPLANATION

The reader discovers the world, the characters, and the stakes through action,
detail, and implication — never through the narrator explaining things.

```
VIOLATION: The town had been struggling economically for years. Many shops
           had closed, and the remaining residents felt a sense of decline.

CORRECT:   Three storefronts on Main Street had their windows papered over.
           The hardware store still opened at seven, but Frank spent most
           mornings reading the paper behind the counter, the bell above
           the door quiet until lunch.
```

**Enforcement:** Flag any paragraph where the narrator tells the reader something
that could be shown through character action, sensory detail, or environmental
storytelling. Every piece of worldbuilding, backstory, and character information
must arrive through DISCOVERY — the reader figuring it out from what they see,
not being told by the narrator.

### Commandment 2: MESSY DIALOGUE

Real people interrupt, talk over each other, change the subject, answer questions
that weren't asked, and leave sentences unfinished. Dialogue on the page should
feel like overheard conversation, not a scripted exchange.

```
VIOLATION: "What happened last night?" she asked.
           "I went to the bar and saw Tom. He told me about the accident.
            It was very upsetting," he replied.

CORRECT:   "What happened last—"
           "Nothing. I went out."
           "Tom said he saw you at—"
           "Tom should mind his own business." He opened the fridge, stared
           into it. "Is there any of that soup left?"
```

**Enforcement:** Every dialogue exchange of 4+ lines must include at least ONE of:
- An interruption or cut-off sentence (using ellipsis or a period mid-sentence)
- A non-answer (character responds to a different question than was asked)
- A subject change (character redirects the conversation)
- Overlapping agendas (each character is trying to get something different)
- Physical business between lines (action that interrupts the verbal exchange)

Dialogue should never feel like two people politely taking turns delivering
information. Conversation is a negotiation, an argument, a dance — never a Q&A.

### Commandment 3: TIGHT POV

The narrative lens stays locked to the POV character. The reader sees only what
this character sees, knows only what they know, and interprets everything through
their specific emotional and psychological filter.

```
VIOLATION: She didn't notice that Marcus was watching her from across the room,
           his jaw tight with anger he'd been carrying since their argument.

CORRECT:   She scanned the room, the usual Thursday crowd. Her gaze passed
           over Marcus without stopping. The wine list had changed again.
```

**Enforcement:**
- NEVER describe what the POV character doesn't perceive
- NEVER reveal another character's internal state directly
- NEVER include information the POV character couldn't know at this point
- Other characters' emotions are conveyed through observable behavior only
- The POV character's biases, blind spots, and priorities shape WHAT they notice
  (a chef notices food; a cop notices exits; a parent notices children)
- When the POV character misinterprets something, the reader may see the truth
  through the gap between what's described and what's concluded

### Commandment 4: SPECIFIC STAKES

At every point in the story, the reader must be able to answer: "What does this
character stand to lose RIGHT NOW?" The stakes must be nameable in one sentence,
concrete (not abstract), and escalating.

```
VIOLATION: She knew everything was on the line. The stakes had never been higher.

CORRECT:   If she didn't file the motion by five o'clock, her client would spend
           the weekend in county lockup — and the judge wouldn't forget that she'd
           missed a deadline.
```

**Enforcement:**
- **Scene-level:** Every scene must have a clear, specific goal and a clear,
  specific consequence of failure
- **Chapter-level:** Each chapter must escalate at least one stake from the
  previous chapter (something is more urgent, more personal, or more costly)
- **Manuscript-level:** Stakes must escalate across acts — Act 1 stakes should
  feel small compared to Act 3 stakes
- Abstract stakes ("everything was at risk") must be replaced with concrete
  ones ("the house, the kids, and the last twelve years of her life")
- If you can't name the stake in one sentence, the scene lacks focus

### Commandment 5: PACING = EMOTION

The pace of the prose — sentence length, scene duration, chapter length — must
match the emotional intensity of the moment. Fast moments get short, choppy prose.
Slow moments get longer, more contemplative prose. The rhythm IS the emotion.

#### Sentence Rhythm Patterns (Reference Guide for the Writer)

**When tension is rising** — Short sentences. Fragments. The rhythm accelerates.
```
She checked the hallway. Empty. The stairwell. Empty. The office at the end —
the door was closed. It shouldn't have been closed.
```

**When dread is building** — Longer sentences that carry the reader through unease
without letting them pause. The reader can't stop mid-sentence, and that's the point.
```
She stood in the parking garage for eleven minutes, watching the elevator
indicator cycle through floors — three, five, nine, five, three, ground —
and she couldn't tell if someone was coming down or if the elevator was simply
moving through its nightly routine, the kind of mechanical pattern that means
nothing until the night it means everything.
```

**During revelation** — One clean, devastating sentence after buildup. Let the
sentence land alone. No commentary after it.
```
The files went back three years. She'd been watching him since before they met.
```

**During action** — Ultra-short. Sensory fragments. Physical detail only.
```
Glass. Floor. Hands on tile. Ringing in the left ear. Movement in the doorway.
```

**During emotional intimacy** — Medium sentences with sensory texture and interiority.
The physical world mirrors the inner world.
```
The house was quieter than she remembered. She'd expected it to feel smaller,
the way childhood places always do, but the kitchen was exactly the same size.
The same crack in the tile by the stove.
```

**During almost-moments** (any genre with emotional/romantic tension) — The near-miss,
the hand that almost reaches out, the sentence that almost becomes a confession.
Structure: physical proximity → interruption or choice to pull back → the residue
(the moment AFTER, where both characters vibrate) → consequences (behavior changes).
```
His hand was on the table between them. Close enough to touch. She watched his
fingers curl inward — slowly, deliberately — and pull back to his side.
"You were going to say something," she said.
"I was going to make a mistake."
The candle between them guttered. Neither of them moved to fix it.
```

```
FAST (danger, action, urgency):
  She ran. Glass broke behind her. The door — locked. She hit it again.
  Again. The handle gave and she was through, wet grass under her feet,
  the car twenty yards away.

SLOW (grief, intimacy, reflection):
  The house was quieter than she remembered. She'd expected it to feel
  smaller, the way childhood places always do, but the kitchen was exactly
  the same size. The same crack in the tile by the stove. The same hook
  where her mother's apron had hung, empty now, the nail casting a thin
  shadow in the afternoon light.
```

**Enforcement:**
- Action sequences: Average sentence length UNDER 12 words. Short paragraphs.
  Minimal internal monologue. Physical detail only.
- Emotional beats: Average sentence length 15-25 words. Sensory detail.
  Internal observation through physical environment.
- Breather scenes: Can be longer, but must still advance character or plant
  information for later chapters.
- NEVER use frantic pacing for low-stakes scenes or languid pacing for
  high-stakes scenes (unless deliberately creating ironic contrast).

### Commandment 6: START LATE

Every scene opens as late as possible. Skip the arrival, skip the small talk,
skip the settling in. Start at the moment of friction, decision, or discovery.

```
VIOLATION: Sarah arrived at the restaurant at seven. She found a table by the
           window and ordered a glass of wine while she waited. She checked her
           phone. At seven-fifteen, Marcus walked in and sat down across from her.
           "Hi," he said.
           "Hi," she replied.
           There was a pause. Then he said, "I need to tell you something."

CORRECT:   "I need to tell you something." Marcus hadn't taken his coat off.
           The waiter was hovering, but he waved him away without looking.
           Sarah's wine was already half gone.
```

**Enforcement:**
- The first sentence of every scene must contain action, dialogue, or a
  specific sensory detail — never setup, arrival, or temporal orientation
- Delete everything before the first moment of tension or interest
- The reader can infer that the character arrived, sat down, and ordered —
  they don't need to see it
- If a chapter opens with the character waking up, getting ready, or
  traveling to a location, CUT to where the chapter actually begins

### Commandment 7: VIVID DETAILS

Every scene must contain at least one sensory detail that could only exist in
THIS specific world, at THIS specific moment, for THIS specific character.
Generic details (the sun was warm, the room was dark) do nothing.

```
VIOLATION: The kitchen smelled good. It was warm and cozy.

CORRECT:   The kitchen smelled like burnt sugar and fennel seed. Her
           grandmother's pizzelle iron had been going since dawn, and
           the counters were lined with cooling racks, each waffle-thin
           cookie dusted with powdered sugar that drifted onto the floor
           when the back door opened.
```

**Enforcement:**
- **One unique detail per scene minimum** — a detail so specific it could
  only belong to THIS story (not interchangeable with any other novel)
- **Sensory hierarchy:** Prioritize smell, touch, and taste over sight
  (sight is the default sense; the others are more vivid and immersive)
- **Character-filtered:** The POV character notices details consistent
  with their personality, profession, and emotional state
- **Earned specificity:** Specific brand names, measurements, and technical
  terms should only appear when the POV character would know them
- **Environmental storytelling:** The physical environment should communicate
  information about the characters who inhabit it (a tidy desk vs. a
  cluttered desk tells a story without a word of exposition)

---

### Quality Guardian — 7 Craft Commandments Scoring

After each chapter, the Quality Guardian evaluates:

```
CRAFT COMMANDMENTS SCORECARD:
1. Discovery not Explanation: [0-10] — Is information shown through action/detail or told by narrator?
2. Messy Dialogue: [0-10] — Does dialogue feel like real conversation with interruptions, subtext, agenda?
3. Tight POV: [0-10] — Does the narrative stay locked to the POV character's perception?
4. Specific Stakes: [0-10] — Can the reader name what's at risk in each scene?
5. Pacing = Emotion: [0-10] — Does prose rhythm match emotional intensity?
6. Start Late: [0-10] — Do scenes open at the point of interest, not before?
7. Vivid Details: [0-10] — Is there at least one unique, specific sensory detail per scene?

Total: [X] / 70
```

**Thresholds:**
- 60-70: Excellent craft — proceed
- 45-59: Acceptable — note weaker commandments, proceed
- Below 45: Craft issues — the Writer should revise before proceeding

---

## Dialogue Craft Standards

### Tags
- Default to "said" — it's invisible to readers
- Use action beats instead of tags when possible:
  ```
  "I don't believe you." She set down her glass.
  ```
- NEVER use: "exclaimed", "declared", "stated", "queried", "opined"
- Sparingly use: "asked", "whispered", "shouted" (only when acoustics matter)

### Voice Differentiation
Every named character should be identifiable by their dialogue alone:
- Vocabulary level (educated vs. colloquial)
- Sentence length (terse vs. verbose)
- Verbal tics or patterns
- What they talk about vs. what they avoid
- How they respond to conflict (deflect, confront, joke)

### Subtext Architecture
The most powerful dialogue says one thing and means another:
```
"Nice apartment." (Meaning: I can see you're struggling.)
"It's temporary." (Meaning: Please don't judge me.)
```

**How to write subtext:**
- Characters talk AROUND the real subject — the direct statement is the one they avoid
- Pauses, redirections, and subject changes carry meaning
- Physical behavior contradicts verbal behavior (hands say what mouths won't)
- Questions are answered with questions (deflection IS communication)
- One character pushes; the other deflects — the PATTERN is the real conversation

**Dialogue tells for deception** (any genre):
- Over-specificity: too much detail about an alibi or explanation
- Deflection: answering a different question than the one asked
- Rehearsed quality: words sound prepared, too polished for the context
- Physical tells: NOT obvious ("looked away") — subtler: adjusting a watch,
  reorganising items, becoming very still, touching the face
- Register shift: formal language where casual is natural, or vice versa

**Dialogue tells for truth** (the contrast is the key):
- Simpler language (lies are complex, truth is plain)
- Shorter sentences
- Unexpected admissions against their own interest
- Physical release: a breath, a slump, hands unclenching

**Power dynamics in dialogue:**
- The powerful character speaks less, uses shorter sentences, doesn't explain
- The less powerful character fills silence, justifies, asks questions
- In physical space: who stands vs sits, who controls the exit, who takes up space
- When a character who normally "wins" the exchange suddenly has no comeback,
  the reader knows something fundamental has shifted

**Enforcement:** Every important conversation (3+ exchanges between characters with
stakes) should have an identifiable subtext layer. The Quality Guardian should be
able to articulate what's being said beneath the surface.

### Therapy-Speak Detection (UNIVERSAL — All Genres)

AI characters communicate with impossible emotional maturity, using vocabulary from
therapy and self-help that real people rarely use in conversation — especially under
stress. This breaks immersion in any genre and any era.

**Flag and rewrite dialogue containing:**
- "I hear what you're saying" / "I want to validate your feelings"
- "You're projecting your [abandonment/trust/control] issues"
- "I need to set boundaries" / "That's a boundary violation"
- "I'm processing my feelings" / "I need space to process"
- "That's a red flag" / "That's toxic"
- "I need to do the work" / "I'm doing the inner work"
- "I deserve better" / "You deserve better"
- "It's not my job to fix you" / "You need to fix yourself"
- "I feel seen" / "I feel heard" / "I feel validated"
- "This is a safe space" / "I'm creating a safe space"
- "That triggered me" (outside of actual trauma context)

**What to replace with:**
Characters under emotional stress communicate MESSILY:
- They deflect, deny, attack, go silent, change the subject, make jokes
- They say the wrong thing, or the right thing badly
- They circle the same argument without resolution
- They express hurt through anger, or anger through withdrawal
- They don't have language for what they're feeling — they show it through action

**The test:** Would a real person actually say this, out loud, in this situation?
If it sounds like a therapy session transcript, rewrite it as a human conversation.

**Exception:** Characters who are ACTUALLY therapists, counsellors, or in therapy
may use this vocabulary — but only in professional or therapeutic contexts, not in
casual conversation.

## Forbidden Words Enforcement

The engine maintains a comprehensive **Forbidden Words List** (`forbidden-words.md`)
containing ~1,170 words and phrases that statistically mark text as AI-generated.

**How it integrates:**
- The **Writer agent** receives the forbidden words list as a negative constraint
  and must avoid all listed words in narration and description
- The **Prose Humaniser** scans output for surviving forbidden words and replaces them
  using the concrete-and-specific replacement strategy
- The **Quality Guardian** counts forbidden word violations as a quality metric —
  more than 3 violations per chapter triggers a "needs-revision" flag

**See `forbidden-words.md` for the complete list.**

The Anti-AI-ism Checklist below covers PATTERNS (structural and phrase-level)
that go beyond individual word avoidance — these are about construction and frequency.

---

## Anti-AI-ism Checklist

### Zero Tolerance (NEVER write — 0 allowed per manuscript)

- "A sense of [emotion]"
- "There was something about [person/place]"
- "Little did [they] know" / "Unbeknownst to [them]"
- "The air was thick with [abstraction]"
- "[They] couldn't help but [verb]"
- "A [emotion] [they] couldn't quite name"
- "And in that moment, [they] understood..."
- "In that moment"
- "The silence was deafening"
- "Eyes that held [abstraction]"
- "The weight of [abstraction] settled on [their] shoulders"
- "The shape of [abstraction/feeling]"

### Frequency-Limited (track across full manuscript)

| Pattern | Max Per Manuscript | Why It's a Tell |
|---------|-------------------|----------------|
| "Something about [person/place]" | 2 | LLMs use this as a hedge instead of naming specifics |
| "The weight of [abstraction]" | 1 | Overused metaphor for emotional burden |
| "Found herself [verb]ing" | 3 | Passive voice that distances from the action |
| "The kind of [X] that [Y]" | 3 | Formulaic comparison structure |
| "As though" | 10 | Not inherently bad, but LLMs overuse dramatically |
| "It was as if [elaborate simile]" | 2 | Elaborate similes are an LLM signature |
| "A shiver ran down [their] spine" | 1 | Physical cliche |
| "[Character] filed this away" | 2 | Internal processing tic |
| "Couldn't quite [verb]" | 3 | Hedging construction |
| "Not for the first time" | 2 | Only keep if genuinely referencing a prior scene |

### Structural AI-ism Patterns

These are harder to detect than phrase-level patterns because they're about
repetition and formula across chapters rather than individual words:

- **Chapter opening formula:** If >30% of chapters start with weather, time-of-day,
  or temporal markers ("Monday morning arrived with..."), the Humaniser must vary them
- **"Morning" in openings:** Maximum 4 chapter openings across the full manuscript
  can contain "morning" in the first sentence
- **Character processing tic:** If a character has a repeated internal phrase
  (e.g., "filed this away", "not a judgment yet"), cap at 2 uses per manuscript
- **Paragraph-ending formula:** If >20% of paragraphs end with the same construction
  type (e.g., ellipsis trailing thought, single-word fragment), vary them
- **Chapter-ending formula:** If >30% of chapters end with the same technique
  (walking home, reflective single sentence, philosophical observation), vary them
- **Dialogue attribution formula:** If "said" + action beat follows the same pattern
  >5 times per chapter, vary the construction
- **Triple-beat lists:** "the warmth, the comfort, the safety" — max 3 per manuscript.
  LLMs default to three-item comma-separated lists with articles.

### Stage-Direction Atmosphere (CRITICAL — 0 allowed per manuscript)

Long, comma-chained sensory descriptions that catalogue an environment and then
editorialize about it. These read like production notes or set dressing rather
than a character experiencing a place.

```
AI TELL: The hotel lobby smelled of carpet cleaner and filter coffee and the
         particular neutral fragrance that hotels use when they want to smell
         like nothing at all.

AI TELL: The office had that specific late-afternoon quality where the
         fluorescent lights haven't been turned on yet but the daylight
         through the blinds has gone grey enough that everything looks
         slightly underwater.

AI TELL: The bar had the kind of deliberate dimness that exists specifically
         so that people can have the kind of conversations they wouldn't have
         in daylight.
```

**Why it's a tell:** Real characters don't narrate atmosphere with analytical
precision. They notice one or two things filtered through their mood, not an
exhaustive sensory inventory with meta-commentary about why the smell/light/mood
exists. The giveaway is the "and the particular..." or "the kind of X that
exists so that..." clause — the narrator steps back and EXPLAINS the detail
instead of just showing a character reacting to it.

**The fix:**
- Pick ONE sensory detail, filtered through the POV character's state
- Cut the meta-commentary ("the kind that...", "the particular...", "that
  specific quality where...")
- Let the reader infer the atmosphere from one concrete observation

```
FIXED:   The lobby carpet had been shampooed recently. She could taste it.

FIXED:   The blinds were down but nobody had turned the lights on. She
         squinted at her screen.

FIXED:   Two of the three bulbs over the bar had burned out, or been
         removed on purpose.
```

**Detection test:** If a sensory description (a) chains 3+ details with "and",
(b) includes a clause explaining WHY the environment is the way it is, or
(c) reads like it was written by someone describing a film set rather than a
character living in the scene — flag it.

### What These Patterns Have in Common

Every AI-ism on this list shares one trait: **vagueness masquerading as depth.**
The fix is always the same: **be specific.** Name the emotion. Describe the
physical detail. Show what the character actually does. Cut the hedge.

## Metonymy — Prose Enrichment

Metonymy substitutes a related attribute for the thing itself. It is one of the
clearest positive signals of human writing — AI almost never uses it unprompted,
defaulting instead to literal, explicit language.

**What it is:**
- "The Crown" instead of "the monarchy"
- "Whitehall" instead of "the British government"
- "Pen to paper" instead of "started writing"
- "The bench" instead of "the judiciary"
- "Boots on the ground" instead of "soldiers deployed"
- "The bottle" instead of "alcoholism"

**Why it matters:** Metonymy compresses meaning, sounds natural, and signals
that the narrator (or POV character) is embedded in their world. A detective
says "the badge" not "the police force." A soldier says "brass" not "senior
officers." A lawyer says "the bar" not "the legal profession." The choice of
metonym reveals the character's relationship to what they're describing.

### Genre-Specific Metonyms

The Writer should draw from metonyms natural to the genre and setting:

**Crime / Thriller:**
the badge, the bureau, the bench, the bar, the beat, the wire, the brass,
suits (management), the street (criminal world), the chair (execution/authority)

**Fantasy:**
the throne, the tower, the blade, the crown, the keep, the forge, the circle
(magic users), the cloth (priesthood), the march (border territory)

**Romance:**
the ring, the altar, the aisle, the veil, the heart (not as metaphor but as
metonym for romantic commitment)

**Historical:**
the Crown, the cloth (clergy), the colours (military service), the bench,
the yard (Scotland Yard), the Hill (Parliament/Congress), the Exchange (finance)

**Literary / Contemporary:**
Place-as-institution metonyms specific to the setting — "the village" (community),
"the office" (corporate culture), "the hill" (local politics)

**Cozy Mystery:**
the village, the fête, the committee, the surgery (GP's office), the green
(community gathering space)

### Usage Rules

- **Target:** 3-5 metonyms per chapter. Enough to enrich, not enough to show off.
- **POV-appropriate:** A child wouldn't say "Whitehall." A farmer wouldn't say
  "the bar." The metonym must belong to the character's vocabulary and world.
- **First use clarity:** On first appearance in the manuscript, the context must
  make the meaning clear. Don't assume the reader knows "the brass" means
  senior officers — let the scene establish it.
- **Don't force it:** If a literal term works better, use the literal term.
  Metonymy is a seasoning, not the main ingredient.
- **Vary the device:** Don't use the same metonym repeatedly. If "the Crown"
  appears 15 times, it stops being craft and becomes a tic.

### Humaniser Check

The Prose Humaniser should note metonymy usage as a **positive craft signal**.
If a chapter has zero metonyms across 2,500+ words, flag it as an enrichment
opportunity — the prose may be too literal. This is not a violation; it's a
suggestion for the Prose Craft Improver to act on if the user opts in.

## Em-Dash Policy (Two-Tier)

Em-dash handling depends on the project mode:

### AI-Generated Prose (Full Pipeline)

**Em-dashes (—) are BANNED in narration and description. Target: 0 in narrative prose.**

Do not use em-dashes in narration, description, or any non-dialogue prose output.
Replace every em-dash with the construction that best fits the context:
- **Subordinate clause:** "which", "who", "where" for non-essential information
- **Parenthetical commas:** For brief asides within a sentence
- **Colon:** For elaboration or explanation
- **Semicolon:** For connecting related independent clauses
- **Period + new sentence:** For strong breaks or emphasis
- **Nothing:** Many em-dash phrases can simply be cut or restructured

**DIALOGUE EXCEPTION — Interrupted Speech:**
Em dashes ARE permitted in dialogue for abrupt interruptions only, where a
character is cut off mid-sentence by another character, an event, or their
own action. This is the one context where no other punctuation works:
- Interrupted: `"I swear I didn't see the—" The lawyer cut him off.`
- Interrupted: `"If you think I'm going to just sit here and—" The door slammed.`
- NOT this (trailing off): `"I thought maybe we could..." She looked away.`

An ellipsis means trailing off (the speaker chooses to stop). An em dash means
cut off (something external stops them). These are different meanings.

**Dialogue em dash limit:** Maximum 3 per chapter. More than 3 interrupted-speech
em dashes per chapter means the dialogue is over-relying on the device.

Any em-dash found in narration or description is a violation and must be removed.

### Human-Written Prose (Writers Studio / Edit & Revise on user manuscripts)

**Em-dashes are permitted but density-limited. Target: ≤3 per 1,000 words.**

Em-dashes are a legitimate punctuation tool. When editing human-written prose:
- **Do NOT remove** em-dashes that are used correctly for abrupt interruptions,
  sharp parenthetical asides, or sudden shifts in thought
- **Flag for review** if density exceeds 3 per 1,000 words — suggest alternatives
  for the weakest uses while preserving the strongest
- **Always flag** incorrect em-dash usage (where a comma, colon, or period is the
  correct punctuation) regardless of density

### How to Detect Project Mode

- **Full Pipeline** (Phases 1–6): AI-generated → em-dash ban applies
- **Writers Studio**: Human-written → density limit applies
- **Edit & Revise**: Check the source — if the user uploaded/pasted their own manuscript,
  apply the density limit. If editing AI-generated chapters from the pipeline, the ban applies.
- **Story Bible Only returning for editorial**: Human-written → density limit applies

## Punctuation Standards (12-Point Reference)

These rules apply to ALL prose — AI-generated and human-written. The Proofreader
enforces mechanical rules (1–7). The Copy Editor enforces stylistic rules (8–12).

### Mechanical Rules (Proofreader)

**1. Direct Address Commas**
Always set off a name or title with commas when a character is being addressed.
- Wrong: "Let's go Paul."
- Right: "Let's go, Paul."
- Wrong: "It's time to eat Grandfather."
- Right: "It's time to eat, Grandfather."

**2. Apostrophe Accuracy**
Use apostrophes for contractions and possessives only — never for plurals.
- Wrong: "I bought three apple's." → Right: "I bought three apples."
- "its" = possessive (like "his"). "it's" = "it is". Never confuse them.
- Possessive of singular nouns ending in s: add 's (James's hat) per Chicago Manual.

**3. Reported Speech**
Indirect questions end with a period, not a question mark.
- Wrong: He asked me if I was going to the party?
- Right: He asked me if I was going to the party.
- Direct questions keep the question mark: He asked, "Are you going to the party?"

**4. Colon Preceded by Complete Sentence**
A colon MUST follow a complete sentence. If you can remove the colon and the
sentence still works, the colon is unnecessary.
- Wrong: My favourite flavours are: vanilla, chocolate, and strawberry.
- Right: I only like three flavours: vanilla, chocolate, and strawberry.
- Right: My favourite flavours are vanilla, chocolate, and strawberry.

**5. Introductory Phrase Commas**
After an introductory phrase of four or more words, use a comma before the main clause.
- Wrong: Despite the warning signs posted every ten feet the scout kept moving.
- Right: Despite the warning signs posted every ten feet, the scout kept moving.
- Short phrases (under four words) may omit the comma if no ambiguity results.

**6. En Dash vs. Hyphen**
Hyphens (-) join compound words. En dashes (–) show ranges or connections.
- Wrong: The 1914-1918 war (hyphen for range)
- Right: The 1914–1918 war (en dash for range)
- Wrong: The London-Paris flight (hyphen for connection)
- Right: The London–Paris flight (en dash for connection)
- Hyphens: well-known, forty-five, self-aware
- En dashes: pages 10–20, years 1990–1995, the Dover–Calais crossing

**7. Slash Filter**
Slashes (/) do not belong in fiction prose. They feel informal or academic.
- Wrong: The room was small/cramped and dark/dingy.
- Right: The room was cramped and dingy.
- Exception: Slashes are acceptable in technical dialogue, signs, or documents
  that a character reads within the story.

### Stylistic Rules (Copy Editor)

**8. Dialogue Tags vs. Action Beats**
Use a comma if the next word is a speaking verb (said, whispered, muttered).
Use a period if the next phrase is a physical action.
- Tag: "I've never seen this map before," he said.
- Beat: "I've never seen this map before." He traced the faded ink with a finger.
- Wrong: "I don't think we're alone," he gripped his sword.
- Right: "I don't think we're alone." He gripped his sword.
- The rule: if the character isn't speaking the next word, use a period.

**9. Em Dash vs. Ellipsis in Dialogue**
Em dashes show abrupt interruption. Ellipses show trailing off or hesitation.
These are different meanings and must not be conflated.
- Interrupted (em dash): "I swear I didn't see the—" The lawyer cut him off.
- Trailing off (ellipsis): "I thought maybe we could..." She looked away.
- WRONG: "I swear I didn't see the..." the witness began, but the lawyer cut him off.
  (Ellipsis implies trailing off. The lawyer cutting him off requires an em dash.)
- Do not stack ellipses: "I... I don't know..." she said... "Maybe..." → use action
  beats instead: "I... I don't know," she said. She looked down. "Maybe."
- In AI-generated prose: em dashes are permitted in dialogue for interruptions
  (max 3 per chapter). Em dashes remain BANNED in all narration and description.

**10. Semicolon Usage**
Semicolons connect two independent clauses that are closely related in theme.
If you can't replace it with a period, it's used incorrectly.
- Wrong: The desert heat was a physical weight, the horizon shimmered like a fever dream. (comma splice)
- Right: The desert heat was a physical weight; the horizon shimmered like a fever dream.
- Never use semicolons in dialogue — characters don't speak in semicolons.

**11. Exclamation Mark Discipline**
Exclamation marks indicate extreme emotion, emphasis, or volume. Overuse ("exclamation
exhaustion") tells the reader something is intense rather than showing it.
- Overloaded: "He's got a knife! Run! Get help! Hurry!" she screamed.
- Disciplined: "He's got a knife," she whispered. "Run. Get help. Hurry."
- If the dialogue tag already indicates volume (shouted, screamed, yelled), a period
  maintains narrative control. Use exclamation marks very sparingly to preserve impact.
- Limit: 1 per chapter in narration. In dialogue, flag if >3 per chapter.

**12. Ellipsis Strategy**
Ellipses indicate trailing off, significant hesitation, or omitted text. They are
not a catch-all pause marker.
- Correct: "I... I don't know," she said.
- Overused: "I... I don't know..." she said... "Maybe..."
- If a character is cut off mid-word, use an em dash (or ellipsis in AI-generated prose).
- If a character is thinking slowly, use one ellipsis then action beats for further pauses.
- Limit in narration: 3 per chapter. In dialogue: flag if >5 per chapter.

## Number Anti-Bias

LLMs default to the number 7 for "random" choices.
Actively distribute numbers across ALL ending digits:
- Ages, times, dates, quantities, addresses, durations, prices
- If you notice multiple 7-ending numbers, change some

## Prose Craft Improver Protocol (Optional)

When activated, runs a two-step process AFTER the Prose Humaniser.
The Humaniser removes AI-isms; the Craft Improver elevates prose quality.

**Step 1 — Analyse:** Read the chapter and produce a list of specific craft issues:

*Sentence-Level:*
- Adverb density (flag sentences with unnecessary adverbs)
- Passive voice (flag and suggest active alternatives; acceptable if <15% of sentences)
- Show-vs-tell violations (flag and suggest physical alternatives)
- Filter words ("noticed", "felt", "seemed", "wondered", "realized") — flag if >5 per chapter
- Dialogue tag issues (flag non-"said" tags: "exclaimed", "declared", "queried")

*Rhythm and Variety:*
- Sentence rhythm problems (flag monotonous constructions — 3+ same-length sentences in a row)
- Sentence length distribution — target ranges:
  - Short (1-5 words): 15-25%
  - Medium (6-15 words): 35-45%
  - Long (16-25 words): 20-30%
  - Very long (25+ words): 10-15%
  If very long sentences are below 8%, flag — the prose lacks rhythmic variety
- Paragraph opening variety — flag if >5% of paragraphs begin with "[Character name] [verb]ed"

*Repetition:*
- Crutch phrases (flag any phrase used 3+ times in a chapter)
- Character verbal tics — if any character-specific phrase appears >2 times
  with near-identical wording, vary or remove extras
- Em-dash check (AI-generated: flag ANY, target is 0. Human-written: flag if >3 per 1,000 words. See Em-Dash Policy above)

*Dialogue:*
- Attribution variety — "said" should be ~60% of tags, action beats ~30%, other ~10%
- Voice differentiation — can each speaking character be identified by dialogue alone?
  Check: vocabulary level, sentence length patterns, verbal tics, topic preferences
- Subtext check — does dialogue do at least 2 things per line?

**Step 2 — Apply:** For each issue in the analysis:
- Locate the exact text
- Apply the minimum fix
- Preserve the author's voice — the chapter should read like the same writer
- Do NOT rewrite surrounding paragraphs
- Do NOT "improve" text that wasn't flagged — resist scope creep
- Word count must stay within 5% of original
