---
name: write-a-book
description: "Start a new manuscript from scratch — genre selection, setup, and full pipeline. Or build a Story Bible for writing it yourself."
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with `> **Powered by Ideorix** — The Manuscript & Screen Engine` before any other output.

# Write a New Book

Start the Ideorix manuscript engine from the beginning.

## Two ways to work

### Full Pipeline (default)
Ideorix writes the entire manuscript — you approve each chapter brief and
prose draft, with full verification and editorial passes.

### Story Bible Only
Ideorix builds the complete creative skeleton — Story Bible, character profiles,
chapter outline, beat structure, trope plan, and genre craft notes — then delivers
a comprehensive **Writer's Companion** document. You write the book yourself, in
your own voice. When you're done, bring your manuscript back for professional
editing and analysis, powered by the Story Bible the engine already built with you.

## What happens

**Full Pipeline:**
1. **Genre Selection** — Choose from 68 genres across 8 categories, or mash up 2–3 genres into a custom hybrid
2. **13 Setup Questions** — Romance subplot, heat level, tropes, length, series position, style, outline, beat structure, Chekhov's guns, pen name, setting, project mode
3. **Story Bible (Phase 2)** — Auto-generated world, characters, plot, and continuity reference

   Phase 2 runs these substeps in order. All must complete before the Approval Gate:
   - **2A — Market Scout** — populates `engine-data/market-pulse.md`
   - **2B — Entity Extraction** — from brief + research
   - **2C — Trope Plan** — populates trope selections in the Story Bible
   - **2D — Entity Canon Lockfile** — creates `engine-data/entity-canon.md`
   - **2E — Running Banlist Initialization** — creates `engine-data/running-banlist.md`.
     **This file must exist before Chapter 1's Writer runs.** Without it, the Writer
     pre-load at Phase 3 step 6a fails.

   Phase 2 Approval Gate: present the completed Story Bible, Entity Canon, and
   Running Banlist to the user. Chapters cannot begin until the user approves.

4. **Chapter Generation** — Architect plans each chapter, Writer drafts it, Verification checks it
5. **Editorial Pipeline** — Proofreader, Copy Editor, Dev Editor, Alpha & Beta Reader passes
6. **Delivery** — Final manuscript with editorial report

**Story Bible Only:**
1. **Genre Selection** — Choose from 68 genres across 8 categories, or mash up 2–3 genres into a custom hybrid
2. **13 Setup Questions** — Same setup, choosing "Story Bible Only" at the end
3. **Story Bible** — Auto-generated world, characters, plot, and continuity reference
4. **Writer's Companion** — Complete creative brief delivered as .docx
5. **You write the book** — At your own pace, in your own voice
6. **Return for editing** — Bring your manuscript back for Story Bible-aware editorial

## How to start

Say any of:
- "Write a book"
- "Write a [genre] novel"
- "I want to write a book"
- "Start a new manuscript"
- "Build a story bible"
- "Plan a book for me to write"

The engine will walk you through every step interactively. You approve each phase before it proceeds.

## What you'll need to decide

| Question | What it controls |
|----------|-----------------|
| Genre (single or mash-up of 2–3) | Voice, pacing, word counts, craft rules. Mash-up stacks multiple genres' rules with a Primary acting as the tie-breaker. |
| Romance subplot | Whether a love arc is woven in |
| Heat level | On-page intimacy (fade-to-black → explicit) |
| Tropes | Story patterns and reader expectations |
| Length | Novella (25K) → Epic (150K+) |
| Series position | Standalone vs. series starter vs. continuation |
| Style guide | Prose voice and author comparisons |
| Outline | Generate new or paste your own |
| Beat structure | Save the Cat, 3-Act, Hero's Journey, etc. |
| Chekhov's guns | Planted details that pay off later |
| Pen name | Author name for publishing |
| Setting | Transportive setting atmosphere |
| Project mode | Full Pipeline or Story Bible Only |

> **Tip:** You can skip any question by saying "skip" — the engine will use smart defaults.
