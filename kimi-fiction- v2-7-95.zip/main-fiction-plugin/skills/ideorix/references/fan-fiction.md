---
name: fan-fiction-genre
description: "Genre-specific instructions for Fan Fiction. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
---

# Fan Fiction. Genre Plugin

## Metadata
- **Genre ID:** fan-fiction
- **Display Name:** Fan Fiction
- **Category:** Other
- **Tier:** Core
- **Target Word Count:** 4,000–4,500 per chapter
- **Min Word Count:** 3,500
- **Recommended Beat Structures:** Three-Act Structure, Save the Cat, Story Circle

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Canon-Compliant | Fills gaps within established timeline | Must fit seamlessly; no contradictions; enriches rather than alters |
| Alternate Universe (AU) | Diverges from canon at a specific point | Clear divergence point; logical ripple effects; "what if" exploration |
| Fix-It | Addresses fan-dissatisfying canon outcomes | Respectful of why fans were dissatisfied; provides more satisfying resolution |
| Missing Scene | Fills specific gaps between canon events | Tight timeline fit; explains character behaviour seen in canon |
| Shipping/Romance | Explores romantic relationships | Character chemistry authentic to canon selves; heat level as tagged |
| Crossover | Merges two or more canons | Both source worlds respected; intersection point logically established |

## Architect Instructions

### Chapter Planning Requirements

**Structure:**
- Chapter length: 1,500–4,000 words (varies by fandom and story type)
- Pacing: Match source material's genre. action for action fandoms, slow-burn for character studies
- Must open with: Immediate grounding in canon universe OR clear AU premise established
- Must close with: Character moment, relationship development, or canon-divergence point

**Beats Per Chapter:**
1. **Canon Grounding:** Reference establishing time/place in universe, character dynamics from source
2. **New Content:** Scene, conversation, or development not in original. your contribution
3. **Character Authenticity:** Behaviour/dialogue proving you understand these characters
4. **Relationship Development:** Exploring dynamic central to fic (romantic, platonic, familial, rivalry)
5. **Canon Integration:** How this fits with or diverges from established events/characterisation

### Genre-Specific Requirements
- Canon knowledge evident. references, world details, character history accurate to source
- Character voices match original. speech patterns, vocabulary, humour, worldview consistent
- Established relationships honoured. history between characters acknowledged
- World rules respected. magic systems, technology, social structures from canon
- If AU: clear divergence point explained, ripple effects logical
- If canon-compliant: fits seamlessly into timeline, no contradictions
- If fix-it: respectful of why fans were dissatisfied, addresses specific issues
- Shipping tags honest. relationship dynamics and heat level as promised
- Content warnings where appropriate

### Forbidden in Planning
- Bashing characters beloved by fandom without justification
- Ignoring major canon events or characterisation without AU explanation
- Out-of-character behaviour for cheap plot advancement
- Violating established world rules without explanation
- Misrepresenting promised content (ship, rating, genre)
- Plagiarising other fanfics or canon dialogue extensively

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (canon love), Validation (character truth honoured), Captivation (familiar world reimagined).

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Voice and Tone
- **POV:** Match source material OR clearly signal departure
- **Tense:** Match source OR establish your convention consistently
- **Voice:** Capture tone of original. humorous, dark, epic, intimate as appropriate
- **Reading level:** Match source material's sophistication

### Prose Imperatives
- Character voices distinct and true to canon. speech patterns, vocabulary, verbal tics
- Dialogue captures each character's unique way of speaking from source material
- Narrative voice suits universe. modern slang in period piece breaks immersion
- Canon references natural, not forced. integrate world details organically
- Show canon knowledge through details, not exposition dumps
- New scenes feel like they could exist in canon (if canon-compliant)
- Balance homage and originality. reference but don't just retell
- Internal monologue matches character's canonical thought patterns
- Action and description suit source genre
- Respect established narrative style of original work

### Character Voice Authenticity

The non-negotiable core of fan fiction craft:
- Each character sounds like themselves. Hermione ≠ Harry ≠ Ron
- Verbal tics from canon present (catchphrases, speech patterns)
- Internal voice matches external. character thinks like they speak
- Emotional reactions proportional to canonical personality
- Knowledge base appropriate. character doesn't know things they shouldn't
- Speech patterns reflect age, class, background from canon
- Humour style matches character (sarcastic vs. wholesome vs. dark)

### Canon Integration
- Reference events readers know without over-explaining
- Use established relationships as foundation for development
- Respect character arcs unless fix-it explicitly diverging
- World rules (magic, tech, society) consistent with source
- If contradicting canon, acknowledge AU or divergence point clearly

### Forbidden Words and Phrases
- Modern slang in historical/fantasy settings without AU justification
- Character names wrong or inconsistent with canon spelling
- Misusing canon terminology or getting world details wrong
- Purple prose that doesn't match source tone
- Author's notes mid-chapter breaking immersion
- Explaining canon to readers as if they don't know source

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. FAN FICTION

OPENING: Voice-match to source material from sentence 1. The reader must feel they
are BACK in the canon universe immediately. Your contribution arrives AFTER they
trust your canon mastery.

SENTENCES. MIRROR THE SOURCE:
- Match the source's sentence length, complexity, and narrative rhythm
- Action canon: shorter (8-16), kinetic. Literary canon: medium-longer (16-28)
- YA canon: immediate, punchy (10-18). Epic fantasy: measured, layered (16-30)
- If the source uses fragments, use fragments; flowing prose, flow
- The prose rhythm IS genre identification. readers recognise fandom through FEEL

VOCABULARY: Canon terminology precise and correct from page 1. Character-specific
verbal tics and catchphrases present. World-specific language natural. never
explained (readers already know). Narrative register matches source. No modern slang
in historical/fantasy settings without AU justification.

TENSION FLOOR: Varies by source genre. Action ≥6, Romance ≥4, Mystery ≥5, Character
study ≥3. Match whatever tension the SOURCE would establish in its chapter 1.

RHYTHM: Open with immediate canon grounding. familiar voice, place, dynamic.
Demonstrate voice authenticity in first dialogue. Introduce YOUR contribution
organically. it should feel like it belongs. Close proving you understand these
people. The reader should forget it's fan fiction and feel they're reading the source.
```

## Quality Check Criteria

### Priority Ranking
1. **Canon accuracy**. Characters, world, timeline consistent with source material (unless deliberate AU)
2. **Character voice authenticity**. Each character sounds like themselves from canon
3. **In-character behaviour**. Actions and reactions consistent with canon personality
4. **Clear fic type**. Reader knows if canon-compliant, AU, fix-it, etc.
5. **Original contribution valuable**. Additions enhance rather than contradict or repeat canon

### Genre-Specific Checks
- Character voices distinct and recognisable
- Canon knowledge evident through references and details
- World rules respected (magic/tech systems, social structures, geography)
- Timeline placement clear
- Relationships canon-based with history acknowledged
- Canon events referenced accurately
- Terminology correct (canon-specific terms, spellings, names)
- Tone matches source
- If AU: divergence clear
- If shipping: chemistry authentic to canon personalities

### Automatic Fails
- Major canon contradictions without AU explanation
- Wildly OOC behaviour for plot convenience
- Canon terminology wrong (misspelling character names, places, magic/tech terms)
- World-breaking: violating fundamental rules of canon universe
- Anachronisms without AU justification
- Bashing without cause: making beloved characters villains to prop up favourites
- Plagiarism: copying other fanfics or excessive unattributed canon dialogue

### Acceptable Imperfections
- Minor canon detail variations if not contradicting major facts
- Interpretation of ambiguous canon moments
- Filling in gaps canon left open
- Adding depth to under-explored characters
- Romance between characters who didn't interact much in canon (if chemistry plausible)

### Canon Accuracy Verification
- Character names spelled correctly and consistently?
- Major canon events referenced accurately?
- World rules consistent with source?
- Character ages appropriate to timeline placement?
- Established relationships acknowledged?
- Geography and locations accurate?
- Canon terminology used correctly?
- Time period details accurate?

### Character Voice Verification (Per Character)
- Vocabulary level and word choice match canon?
- Speech patterns (formal, casual, verbose, terse) authentic?
- Humour style consistent with canon personality?
- Catchphrases or verbal tics present if canon had them?
- Internal monologue matches thought patterns?
- Emotional reactions proportional?
- Knowledge base appropriate?

## Continuity Rules

### Top 5 Continuity Priorities
1. **Canon compliance:** If canon-compliant, no contradictions with source timeline, characterisation, or world rules
2. **Character consistency:** Personalities, histories, and relationships match original unless AU divergence explained
3. **World rules maintained:** Magic/tech systems, social structures, geography from canon respected
4. **AU divergence tracking:** If AU, divergence point clear and ripple effects logical
5. **New additions consistent:** Your original content (OCs, plot points, relationships) internally coherent

### Canon Accuracy and World Rules
- Canon timeline placement consistent with prior chapters
- Canon events referenced accurately; dates/order correct
- World rules (magic, tech, social structures, geography) maintained
- Canon terminology spelled correctly
- Canon history/backstory elements referenced accurately
- Fic type (canon-compliant/AU/fix-it) maintained throughout

### Character Voice and Knowledge
- Core traits, values, fears, motivations from source preserved
- Verbal tics, catchphrases, vocabulary, formality level match canon per character
- What each character knows appropriate to timeline (no future knowledge)
- Skills and powers match canon unless training/change shown
- Established dynamics (allies, rivals, family) acknowledged
- Any development builds logically from canon personality

### AU and Divergence Tracking
- Where/when story splits from canon clearly established and maintained
- Consequences of divergence tracked logically across subsequent chapters
- Canon elements kept despite AU change remain internally consistent
- Alterations applied consistently, not selectively forgotten
- Distinguish between actual source material and popular fan interpretations (fanon)

### Internal Story Consistency
- Details established in YOUR earlier chapters maintained
- Timeline of your plot tracks logically day-to-day
- Emotional continuity: characters' feelings carried forward, not reset
- Established stakes honoured or addressed
- Subplot tracking: secondary threads maintained alongside main plot

### Red Flags (Investigate Immediately)
- Character knows information they couldn't have at this canon timeline point
- Major canon event ignored without AU explanation
- Character personality shifts arbitrarily to serve plot (OOC without earned development)
- World rule violated (magic/tech doing something canon established it cannot)
- Canon relationship dynamic contradicted without development shown
- Fanon treated as canon fact without acknowledgement
- AU divergence effects applied inconsistently
- Character's canon speech pattern disappears
- Original content contradicts your own earlier chapters
- Tone shifts dramatically without narrative justification

## Character Rules

### Character Consistency Priorities
1. **Canon personality maintained:** Core traits, values, fears, motivations from source
2. **Voice authenticity:** Speech patterns, vocabulary, humour style match canon
3. **Established relationships honoured:** History and dynamics with other characters acknowledged
4. **Character knowledge:** What they know/don't know consistent with timeline placement
5. **Growth stays in-character:** Development builds logically from canon foundation

### Character Arcs Must:
- Build from canon personality. don't create a different person
- Justify any major personality shifts with significant events
- Maintain character's core even while growing
- Respect canon arcs unless explicitly fix-it or AU
- Show how canon events affected character emotionally
- Keep relationships consistent with established dynamics

### Out-of-Character (OOC) Avoidance
- Would this character actually say/do this? Check against canon
- Is personality shift justified by events in your fic?
- Does dialogue sound like this character or like you?
- Are you maintaining character's flaws, not just virtues?
- Does character's knowledge match what they'd have at this point?
- Are you making character OOC to force plot forward?

### Canon Character Types
- **Protagonist:** Maintain POV, personality, growth arc from source
- **Love interest:** Keep their canon personality. not just perfect partner
- **Supporting cast:** Even minor characters need canon-accurate portrayal
- **Antagonists:** Respect their canon motivations. not cardboard villains unless canon made them so
- **Original characters (OCs):** Fit naturally into world; don't overshadow canon characters

### Relationship Dynamics
- Canon relationships: acknowledge established dynamics. don't ignore history
- New relationships: build naturally from canon personalities and circumstances
- Shipping: character chemistry must feel authentic to their canon selves
- Enemies-to-lovers: requires believable evolution given canon animosity reasons
- Found family: development earned through shared experiences, not instant

## Arc Rules

### Five-Phase Fan Fiction Arc (30 Chapters)

**Phase 1. Canon Grounding and Premise (Ch 1–6)**
- Ch 1: Canon immersion. familiar world, characters, dynamics established immediately
- Ch 2: Fic premise introduced. the new element becomes visible
- Ch 3: Character voices confirmed. reader hears canon personalities authentically
- Ch 4: Stakes established. what this fic is exploring
- Ch 5: Your contribution clear. the gap being filled, the "what if" being explored
- Ch 6: Investment earned. reader cares because you've demonstrated canon mastery AND original vision

**Phase 2. Development and Deepening (Ch 7–13)**
- Ch 7: Deeper exploration. additions gain complexity
- Ch 8: Relationship development. central dynamic deepens
- Ch 9: Canon enrichment. reveals something that makes canon feel richer
- Ch 10: Emotional investment peaks
- Ch 11: Complication introduced
- Ch 12: Character depth. side of characters canon didn't explore
- Ch 13: Stakes raised. fic's central question sharpens

**Phase 3. Conflict and Testing (Ch 14–20)**
- Ch 14: Central conflict crystallises
- Ch 15 (MIDPOINT): Emotional or plot revelation that changes everything
- Ch 16: Aftermath. characters process with authentic responses
- Ch 17: Conflict deepens
- Ch 18: Character under pressure. canon personalities face unique crisis
- Ch 19: Darkest complication
- Ch 20: Turning point. character gains understanding setting up resolution

**Phase 4. Climax and Resolution (Ch 21–26)**
- Ch 21: Movement toward resolution
- Ch 22: Emotional climax. the moment readers have been waiting for
- Ch 23: Fic's promise fulfilled
- Ch 24: Immediate aftermath. authentic emotional responses
- Ch 25: Consequences settled
- Ch 26: New understanding. characters (and readers) see canon differently

**Phase 5. Denouement and Canon Integration (Ch 27–30)**
- Ch 27: New normal. post-fic state, connection to broader canon
- Ch 28: Relationship resolution. central dynamic in new equilibrium
- Ch 29: Canon bridge. connect to or replace what comes next in source
- Ch 30: Closing image. final moment capturing what fic was about

### Canon Fidelity Gradient
- Phase 1: Strict canon adherence (100%). prove you know the source
- Phase 2: Canon enriched (90%). adding depth within canon framework
- Phase 3: Canon tested (80%). unique circumstances strain familiar ground
- Phase 4: Canon honoured through transformation (85%). resolution respects source
- Phase 5: Canon integration (95%). reconnect to source, enriched

### Transformative Value Architecture
- Phase 1: Demonstrate mastery of source (reader trusts you)
- Phase 2: Add something canon didn't show (justify your fic's existence)
- Phase 3: Create emotional stakes canon never explored (your unique contribution)
- Phase 4: Deliver payoff that enriches understanding of characters/world
- Phase 5: Leave reader seeing canon differently because of what you wrote

**The best fan fiction doesn't just retell. it REVEALS.**

## Timeline Rules

### Time Scale
- Total story duration: Varies by type. missing scene (hours), slow-burn romance (months/years)
- Chapter time span: Match pacing of canon genre. episode-like for TV fandoms, etc.
- Time progression: Linear OR match canon's style (flashbacks if canon uses them)

### Genre-Specific Temporal Rules
- Story placement in canon timeline clear. before/during/after which events?
- If during canon: fits between established events without contradicting
- If post-canon: acknowledges time passed, what's changed
- If pre-canon: respects established backstory and character formation
- Character ages accurate to timeline placement
- Seasonal/calendar references align with canon setting

### Canon Timeline Integration
- **Pre-canon:** Shows how characters became who they are in canon
- **Missing scenes:** Fills gaps between canon episodes/chapters. fits perfectly
- **Canon-divergence:** Clear when divergence happens, tracks forward from there
- **Post-canon:** Accounts for time passed and development from canon end
- **AU with canon basis:** May follow similar timeline with AU changes
- **Complete AU:** Creates own timeline but character ages/relationships logical

### Relationship Development Timelines
- **Slow-burn:** Months to years. feelings develop gradually with realistic setbacks
- **Friends-to-lovers:** Time as friends established before romantic shift
- **Enemies-to-lovers:** Sufficient time for animosity to believably shift
- **Established relationship:** Time together acknowledged through history references

## Genre-Specific Craft Techniques

Fan fiction is a genre with an unusual craft tradition:
its primary canon is not a literary corpus but the
combined practice of AO3 (Archive of Our Own),
fanfiction.net, LiveJournal-era fic communities, Wattpad,
and the wider participatory-fiction ecosystem. The
genre's craft has been theorised primarily through
Henry Jenkins (participatory culture, textual
poaching), Francesca Coppa (transformative works
theory), and the OTW (Organization for Transformative
Works), and refined through millions of practitioner-
hours across fic-archives. Published authors who
emerged from this tradition include Naomi Novik (whose
Master and Commander fic culture preceded Temeraire),
Cassandra Clare (Mortal Instruments), Anna Todd (the
After series, originally One Direction fic), Ali
Hazelwood (originally Star Wars fic), Casey McQuiston
(Red White & Royal Blue, deeply rooted in fic culture),
Tamsyn Muir (the Locked Tomb), Olivie Blake (the Atlas
Six, online-serialised), Becky Albertalli, Christina
Lauren, Mariana Zapata — and the fic tradition itself
has theorists, archivists, and craft-mentors operating
at a sophistication often invisible to outside-genre
readers. The most common failure modes in this
register are: **Canon-Inaccuracy Foundation Failure**
(the genre's first-signal failure — character names
misspelled, world rules violated, canon events
misremembered, terminology wrong; the reader's
immediate signal that the writer doesn't actually know
the source); **OOC-for-Convenience** (out-of-character
behaviour deployed to advance plot rather than to
render character; the genre's deepest-cut reader-trust
violation); **Fanon-as-Canon Confusion** (treating
popular fan interpretations as if they were source
canon without acknowledging the fanon as fanon —
characters' breakfast preferences, secondary-character
backstories, ship dynamics that exist in collective
fic-imagination but not in the source); **Mary-Sue /
Gary-Stu OC** (original character who outshines canon
characters in beauty, intelligence, skill, romantic
appeal; the OC who exists to be admired rather than to
function within the canon world); **Bashing-Without-
Cause** (turning a canon character into a cardboard
villain to prop up a favourite; the fandom's most
relationship-burning failure mode, particularly for
shipping fics); **Canon-Recap Substitution** (rehashing
canonical scenes verbatim without transformative
purpose; consuming reader time to retell what they
already know); **Author-Insertion / Soapbox** (using a
character as mouthpiece for the author's opinions,
often via lengthy monologue or author's-note-in-
narrative; breaking the diegetic frame); **Divergence-
Without-Consequence** (AU divergence announced in
chapter 1 but not tracked through ripple effects across
chapters; the canon-divergence point declared but the
world otherwise unchanged); **Tag-Promise Failure**
(delivering content that contradicts the fic's tags —
the promised slow-burn becomes instant-relationship,
the promised canon-compliant turns AU midway, the
promised fluff becomes unexpected angst, the promised
no-archive-warnings turns into archive-warning content);
**Source-Blindness / Tourism** (the writer who does not
actually know the source treating it as decoration —
the AO3 comment "I don't think you've actually read
the books" is fan fiction's most ego-bruising review);
and **Voice-Flattening** (all characters sounding like
the author; the cover-name test failing because every
line of dialogue could plausibly belong to any
character). The techniques below — four preserved
(Voice Capture Method, Canon Gap Architecture,
Divergence Cascade, Earned OOC Moment) and three added
(Reader-as-Co-Author Discipline, Tag-as-Contract
Architecture, Transformative-Justification Discipline)
— are designed to keep the genre's defining commitments
live: canon mastery as the foundation of reader trust,
tags as binding contracts, and every fic justifying
its existence beyond retelling.

### The Voice Capture Method

The most critical skill in fan fiction. making characters sound like themselves:

1. **Study the source:** Before writing, re-read/re-watch key scenes for each character's speech patterns
2. **Create a voice sheet:** For each character, note: sentence length preference, vocabulary level, verbal tics, humour style, formality level, favourite topics/fixations
3. **The cover test:** Read dialogue with names removed. can you tell who's speaking? If not, the voice isn't captured
4. **The "would they" test:** For every line of dialogue, ask: "Would this specific character actually say this, in this way?" If the answer is uncertain, rewrite

### The Canon Gap Architecture

Building stories in the spaces canon left:

- **Identify the gap:** What happened between scenes? What was a character thinking during a pivotal moment? What conversations happened off-page?
- **Make it necessary:** The best missing-scene fics make the reader think "That MUST be what happened"
- **Respect the seams:** Your scene must end exactly where canon picks up again. characters in the right emotional state, in the right place, knowing the right things
- **Add depth without contradiction:** Enhance understanding of canon events without changing them

### The Divergence Cascade

For AU/canon-divergence fics, tracking ripple effects:

1. **Identify the point of departure:** One specific moment where your story breaks from canon
2. **Map first-order effects:** What immediately changes?
3. **Map second-order effects:** What changes BECAUSE of those changes?
4. **Map character reactions:** How does each character respond to the altered reality?
5. **Track what DOESN'T change:** Not everything is affected. some events/dynamics would happen regardless

### The Earned OOC Moment

Sometimes a character needs to do something unexpected:

- The action must be prepared for. subtle hints across preceding chapters
- The reason must be proportional. only extreme circumstances justify extreme departures
- The core must hold. even in their most OOC moment, something essential about the character remains
- The return must happen. character reflects on their uncharacteristic behaviour; pattern reasserts

### Fan Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the familiar world expanded" | Show the specific expansion detail |
| "exploring the space between canon moments" | Show the specific scene with specific characters |
| "a love that canon denied them" | Show the specific romantic interaction |
| "the character's hidden depths" | Show the specific depth through action |
| "what if things had gone differently?" | Show the specific divergence point |
| "the AU was complete" | Show the specific alternate detail |
| "a missing scene that explains everything" | Show the specific scene |
| "the ship sailed" | Show the specific romantic moment |
| "canon-compliant with a twist" | Show the specific twist |
| "the fandom's favourite scenario" | Make it fresh. show your specific version |
| "the canon characters" | Name them; canon characters are not a category |
| "in this universe" | Cut; show the specific universe-marker |
| "fans of the show would recognise" | Cut breaking-frame meta; trust the reader |
| "exactly as it had happened in canon" | Cut canon-recap; either show it transformatively or skip it |
| "the trio reunited" | Cut formulaic groupings; show the specific reunion |
| "their iconic dynamic" | Cut "iconic"; show the specific dynamic in this scene |
| "everyone in the fandom knew" | Cut breaking-frame; trust the reader's canon knowledge |
| "this was different from the source material" | Cut author-comment; show the specific difference |

### The Reader-as-Co-Author Discipline

Fan fiction's most distinctive craft contract is that
the reader brings extensive canon knowledge, emotional
history with the characters, and specific genre-
convention expectations to the fic. Unlike literary
fiction where the writer must build the reader's
relationship with characters from zero, fan fiction
inherits years (sometimes decades) of established
relationship between reader and source. The Reader-as-
Co-Author Discipline is the requirement that the
manuscript trust the reader's expertise, lean on their
canon knowledge, and refuse to over-explain.

```
PRINCIPLE
The manuscript must satisfy at least four of the
following five Reader-as-Co-Author criteria:
1. CANON ASSUMED — references to source canon are made
   without explanation; the reader knows what Hogwarts
   is, who Spock is, what Voldemort did. The fic does
   not pause to remind them.
2. RELATIONSHIP HISTORY ASSUMED — established
   character dynamics are honoured without
   recap; the reader knows the Daenerys-Jon
   relationship history, the Aziraphale-Crowley
   six-thousand-year friendship, the Sherlock-John
   trauma-bond. The fic builds on this rather
   than re-establishing it.
3. EMOTIONAL INVESTMENT ASSUMED — the reader
   cares about these characters before page one;
   the fic does not need to "earn" the reader's
   investment in the protagonist; it inherits it.
4. GENRE-CONVENTION FLUENCY ASSUMED — the reader
   knows what a coffee-shop AU is, what enemies-
   to-lovers means, what slow-burn promises, what
   "no beta we die like men" implies; the fic
   does not explain its own conventions.
5. TROPE-AWARENESS ASSUMED — the reader recognises
   tropes (mistletoe, fake-dating, hurt/comfort,
   five-times, wing-fic, A/B/O) and the writer
   can play with reader expectations. subvert,
   double-down, or recombine.

CALIBRATION TEST
- Does the manuscript explain canon to the reader?
  If yes, the contract is broken (the reader's
  expertise is being patronised).
- Does the manuscript pause to recap relationship
  history the reader already knows?
- Does the manuscript over-explain its tropes or
  conventions?
- Does the manuscript treat the reader as someone
  who needs introducing to characters they have
  loved for years?
If any answer is yes — rebuild for reader-trust.

ANTI-PATTERN
- "As fans of the show know..." — breaking the
  diegetic frame to address the reader's canon
  knowledge
- A paragraph explaining who the protagonist is
  before the action begins
- Recap of the source's events at the start of
  the fic
- Footnote-style explanations of canon
  terminology
- Author's-note-in-narrative explaining "this is
  an AU where..." (the AU should be visible
  through the writing, not announced)
- Treating the reader like a stranger to the
  characters rather than someone returning to
  them
```

### The Tag-as-Contract Architecture

Fan fiction's tags (rating, content warnings, pairings,
tropes, canon-position, additional-tags) are not
decorative metadata. They are binding contracts the
manuscript must honour. The Tag-Promise Failure mode
is one of the most common reader-trust violations in
the genre, and it is structurally caught by the Tag-
as-Contract Architecture.

```
PRINCIPLE
The manuscript must honour every promise made by its
tags across at least five of the following six
categories:
1. RATING — the content rating (G / Teen / Mature /
   Explicit) must accurately describe the manuscript's
   most intense content; an Explicit-tagged fic
   delivers explicit content; a Teen-tagged fic does
   not deliver Explicit content; honesty about the
   most-mature content in the fic
2. ARCHIVE WARNINGS — the four AO3 archive warnings
   (Major Character Death; Graphic Depictions of
   Violence; Rape/Non-Con; Underage) must be applied
   accurately or "Choose Not To Use" applied
   honestly; readers with specific avoid-tags need
   to be able to trust the writer's tagging
3. PAIRINGS — the relationships tagged must be
   delivered with the dynamic the tag promises;
   tagged Background Pairings should appear as
   background; tagged Endgame pairings should be
   the endgame; "Friendship" tags should not deliver
   romance
4. TROPE TAGS — tropes the fic tags (Coffee Shop AU,
   Slow Burn, Fake Dating, Hurt/Comfort, Found
   Family, Mutual Pining, etc.) must be delivered
   with their conventional structure; readers
   selecting on these tags expect the conventional
   experience
5. CANON-POSITION TAG — Canon-Compliant, Canon-
   Divergent, AU, Pre-Canon, Post-Canon, Missing
   Scene tags must accurately describe the fic's
   relationship to the source; mid-manuscript
   shifts (a tagged Canon-Compliant fic that
   becomes AU in chapter 12) must be re-tagged
6. ADDITIONAL-TAG TONE — tone tags (Fluff, Angst,
   Crack, Hurt/Comfort with Happy Ending,
   Bittersweet, Slow Burn) must accurately
   describe the manuscript's emotional shape;
   the fluff fic does not turn unexpectedly into
   prolonged trauma

CALIBRATION TEST
- For every tag on the fic, can a reader who
  selected on that tag trust they will get what
  the tag promised?
- Does the rating accurately describe the most-
  mature content in the manuscript?
- Are archive warnings applied accurately or
  Choose-Not-To-Use applied honestly (rather
  than omitted to surprise the reader)?
- Does the manuscript's emotional shape match
  its tone tags?
- If the manuscript's content shifts mid-fic,
  has the writer re-tagged?
If any answer is no — rebuild for tag honesty.

ANTI-PATTERN
- Surprise major character death in a fluff fic
- Surprise sexual content in a Teen-tagged fic
- The slow-burn that resolves in chapter 3
- The canon-compliant fic that goes AU without
  re-tagging
- "Choose Not To Use Archive Warnings" deployed
  as cover for content that needed warnings
- Tags omitted to "preserve the surprise"
- Pairings tagged as primary that are actually
  background, or vice versa
```

### The Transformative-Justification Discipline

Every fan fiction must justify its existence beyond
canon retelling. The Canon-Recap Substitution failure
mode is the most basic violation. fic that simply
retells what the source already provided, without
transforming it, has no reason to exist. The
Transformative-Justification Discipline is the
requirement that the manuscript add something specific
that the source did not give.

```
PRINCIPLE
The manuscript must satisfy at least three of the
following five transformative-justification criteria:
1. PERSPECTIVE — the manuscript provides perspective
   on canon events that the source did not give;
   the antagonist's POV; the minor character's
   experience; the off-page witness; the
   diasporically-distant observer
2. DEPTH — the manuscript provides emotional or
   psychological depth that the source's pacing
   could not afford; the long aftermath of a
   battle; the months of grief the source skipped;
   the political ramifications the source
   summarised
3. ALTERNATIVE — the manuscript provides a
   what-if; the AU branch from a specific
   moment; the fix-it that addresses what
   readers found unsatisfying; the role-swap
   that examines characters from new angles
4. MISSING CONTEXT — the manuscript provides
   the off-page conversation, the unwritten
   letter, the interior moment that explains
   the canonical action the reader saw
5. STRUCTURAL REFRAMING — the manuscript
   reframes canon through a structural device
   the source did not use; epistolary; five-
   times-and-once; coda; dossier; oral
   history; documentary

CALIBRATION TEST
- Could the reader, after the manuscript ends,
  name the SPECIFIC thing the manuscript
  added that canon did not provide?
- Does the manuscript do more than retell?
- Has the writer earned the reader's time
  beyond the source's existing material?
- Would the manuscript still be worth reading
  if the source itself were freely available
  (which it is)?
If any answer is no — rebuild for transformative
weight.

ANTI-PATTERN
- The retelling of canon events from the same
  POV, with the same pacing, with no addition
- The novelization-of-the-show that simply
  transcribes
- The fic that adds a single original scene
  surrounded by paragraphs of canon recap
- The "missing scene" that adds nothing
  canon's existing scenes did not already
  imply
- The AU whose AU-element is purely cosmetic
  (the same plot, but in a coffee shop, with
  no actual reframing of character
  relationships)
- The fic whose only justification is "I
  wanted to see them kiss" without rendering
  the kiss with specific character-revealing
  attention
```

## Genre-Specific Revision Rules

### Six-Pass Fan Fiction Audit (Run FIRST in editorial pipeline)

The Fan Fiction Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Canon Accuracy Pass

Verify all character names, place names, and canon
terminology are spelled correctly and used consistently
with the source. The Canon-Inaccuracy Foundation
Failure mode is caught here. for fan fiction, this is
the genre's lowest-tolerance pass; misspelled character
names or violated world rules signal to the reader that
the writer does not actually know the source. Check all
canon event references for accuracy. dates, order,
involved parties, outcomes. Confirm world rules (magic
systems, technology, social structures, geography)
consistent with source. Verify timeline placement
creates no impossible overlaps (a character cannot be
in school during a chapter set after their graduation;
events the canon shows happening cannot have already
been concluded). The Fanon-as-Canon Confusion failure
mode is also caught here. is anything treated as canon
that is actually a popular fan interpretation? If so,
either acknowledge it as fanon or remove.

#### Pass 2: Voice Authenticity Pass

Apply the Voice Capture Method's cover test to every
character's dialogue in the chapter: read each
character's lines with names removed; can the reader
identify who is speaking? If not, the voice is not
captured and must be rebuilt. Check internal monologue
matches each character's canonical thought patterns.
the Hermione-monologue does not sound like a Harry-
monologue. Verify verbal tics, catchphrases, and speech
patterns from canon are present in characters where
canon established them. Confirm no character sounds
like the author rather than themselves. The Voice-
Flattening failure mode is caught here. if every
character's dialogue could plausibly belong to any
character, the manuscript has been written with one
voice rather than with the source's polyphony.

#### Pass 3: Fic Type Consistency Pass

If canon-compliant, verify no contradictions with
source emerge in this chapter; the timeline placement
remains coherent; characters' knowledge bases match
what they would know at this canon point. If AU,
confirm the divergence point established in Phase 1 is
maintained and its effects are being tracked logically;
the Divergence-Without-Consequence failure mode is
caught here. If fix-it, verify the fix being delivered
addresses the specific dissatisfaction the manuscript
promised to address; the fix should be earned, not
hand-waved. Check that tags and promises are fulfilled
in the chapter; if the chapter contains content that
exceeds the rating or contradicts the tags, either
restructure the content or re-tag honestly. The Tag-
Promise Failure mode is caught at chapter level here
as well as at manuscript level in Pass 6.

#### Pass 4: Transformative Value Pass

Audit the chapter for transformative contribution.
does it add something canon did not show? The Canon-
Recap Substitution failure mode is caught here. if
the chapter retells canonical events without
transforming them, restructure or cut. Is the chapter
justified — does it earn its existence beyond
retelling? Does the reader's understanding of
characters or world deepen as a result of reading
this chapter? Apply the Transformative-Justification
criteria: is at least one of perspective / depth /
alternative / missing-context / structural-reframing
operating? If the chapter could be removed without
the manuscript losing transformative weight, either
remove it or rebuild it to add transformative
function.

#### Pass 5: Internal Consistency Pass

Check the manuscript's own continuity, not just
canon's. The fic establishes its own facts —
characterisation choices, AU-specific worldbuilding,
relationship histories — and these must remain
consistent across chapters. Verify emotional states
carry forward between chapters; if the protagonist
ended chapter 8 distraught, chapter 9 cannot open
with her cheerful unless something specific intervened.
Confirm subplot threads are maintained alongside the
main plot; the secondary character's arc, the political
backdrop, the side relationship continue developing
even when the main plot dominates. Check that
established stakes are honoured. if the manuscript
established that a particular consequence would
follow, the consequence must arrive or be explicitly
addressed.

#### Pass 6: Reader-as-Co-Author + Tag-as-Contract + Transformative-Justification Integration

This pass is the fan fiction integration check — it
ties the new techniques together and verifies the
genre's defining commitments are honoured chapter by
chapter and at manuscript level.

For READER-AS-CO-AUTHOR: audit the chapter for moments
where the manuscript over-explains canon, recaps
relationship history the reader already knows, breaks
the diegetic frame to address the reader's canon
knowledge, or treats the reader as a stranger to
characters they have loved for years. The Source-
Blindness / Tourism failure mode is caught here. if
the manuscript reads as if written by someone
introducing the characters rather than by someone
returning to them, rebuild for reader-trust.

For TAG-AS-CONTRACT: at manuscript level, audit the
fic's tags against the manuscript's actual content.
Does the rating accurately describe the most-mature
content? Are archive warnings applied accurately or
Choose-Not-To-Use applied honestly? Are pairings
tagged as primary actually primary? Are tropes
delivered with their conventional structure? Does the
canon-position tag remain accurate as the manuscript
develops? The Tag-Promise Failure mode is the genre's
most relationship-burning failure with readers; catch
it ruthlessly. If content has shifted to require new
tags, re-tag honestly.

For TRANSFORMATIVE-JUSTIFICATION: at manuscript level,
audit whether the fic adds something specific the
source did not give. Could the reader, after finishing
the manuscript, name the SPECIFIC perspective, depth,
alternative, missing context, or structural reframing
the manuscript provided? If the manuscript's only
justification is "I wanted to read this scene" without
specific transformative contribution, rebuild to add
the missing dimension. The genre's contract is that
fan fiction reveals rather than retells; the
integration pass is where that contract is verified.

## Names & Patterns to Avoid

### Forbidden Fan Fiction Patterns
- Explaining canon to the reader (they already know; trust them)
- Author's notes embedded in the narrative ("A/N: I know this is OOC but...")
- Rehashing canonical scenes verbatim without transformation
- Making a character a mouthpiece for the author's opinions
- "Character bashing". making a character into a villain solely to prop up a favourite
- Using fanon (popular fan interpretations) as if it's canon without acknowledgement
- Info-dumping canon facts the reader already knows

### Cliché Setups to Avoid
- "Character wakes up and describes themselves in the mirror"
- "Character from the future tells past self everything" (removes all tension)
- Mary Sue/Gary Stu OCs who outshine all canon characters
- "Fixing" canon by simply removing the character the author dislikes
- Modern music/pop culture references in non-modern settings without AU framing
- "Reading the books/watching the show" fic format (low transformative value)

### Names to Avoid
- Misspelling canon character names (cardinal sin in fan fiction)
- OC names that are too similar to existing canon characters
- OC names that break the naming conventions of the canon world

## Comp Titles

Fan-fiction's comp-title context is unusual: the
genre's primary "canon" is not a literary corpus but
the practice of AO3 / fanfiction.net / participatory-
fiction archives. Comps below reference notable
published-from-fic crossovers, theoretical foundations,
and influential original works that shape the
contemporary fan-fiction-into-original publishing
pipeline.

### Canonical (foundational reference points)

- *Textual Poachers* — Henry Jenkins (1992): the foundational theory of participatory culture.
- *The Fanfic Reader's Guide* — Francesca Coppa et al.: transformative-works theoretical foundation.
- AO3 (Archive of Our Own, 2008-): the genre's primary archive; OTW-operated.

### Contemporary (current best-in-class — published-from-fic and fic-shaped originals)

- *Red, White & Royal Blue* — Casey McQuiston (2019): contemporary romance with fic-cultural sensibility.
- *Fifty Shades of Grey* — E.L. James (2011): the most commercially successful published-from-fic crossover (Twilight-origin).
- *After* — Anna Todd (2014): One-Direction-fic-to-publish phenomenon; YA category.
- *The Atlas Six* — Olivie Blake (2020): online-serialised fic-sensibility original; viral-Reddit-to-print.
- *The Locked Tomb* (Gideon series) — Tamsyn Muir (2019-): fic-culture-rooted original SF/F.
- *The Mortal Instruments* — Cassandra Clare (2007-): published-from-fic Harry-Potter-fic origin.
- *The Love Hypothesis* — Ali Hazelwood (2021): Star-Wars-fic-origin contemporary romance.

## Cover Design Specifications

### Visual Tone
- Evocative of source material's visual aesthetic
- Artistic interpretation rather than direct screenshot/image reproduction
- Emotional tone matching fic type (dark for angst, warm for fluff, dramatic for adventure)
- Professional quality that honours the source material

### Key Visual Elements
- Imagery suggesting the fic's specific premise without spoiling
- Characters depicted in ways recognisable to fandom
- Canon world elements present (settings, objects, symbols)
- Fic-specific additions visible (AU elements, relationship dynamics)

### Typography
- Clean, readable fonts appropriate to source material's genre
- Title prominent; fandom/series identifiable
- Rating/content indicators visible if applicable
- Author name present but secondary to title

### Colour Palette
- Draw from source material's visual palette
- Adjust for fic tone: warmer for romance, darker for angst, brighter for comedy
- High contrast for readability
- Cohesive with fandom visual language

### Comp Titles (Cover Style Reference)
- AO3 aesthetic: clean, artistic, fandom-specific imagery
- Published fan fiction (serial numbers filed off): genre-appropriate professional covers
- Fandom art commissions: character-focused, emotionally evocative
