---
name: story-analysis
description: Reverse-engineers existing novels into reusable structural blueprints — extracts genre, tropes, character arcs, plot structure, and produces genericized plot templates
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Story Analysis Protocol (Structure Scanner)

## Purpose

Analyse an existing novel or manuscript to extract its structural DNA — genre,
tropes, character arcs, plot beats, worldbuilding patterns, and pacing profile.
Then produce a **genericized plot template** that can be used as a blueprint
for writing a similarly-structured original story.

This is NOT plagiarism assistance. The output strips all specific names, places,
and plot details, leaving only the structural skeleton — the same way "Hero's
Journey" describes Star Wars, The Matrix, and Harry Potter simultaneously.

## When to Use

- **"I want to write something like [book X]"** — Analyse the reference book,
  extract its structure, use as a template for the new project
- **Study mode** — Author wants to understand what makes a book work
- **Genre research** — Extracting patterns from multiple books in a genre
- **Self-analysis** — Author wants to analyse their own completed manuscript

## Two-Phase Process

### Phase 1: Chapter-by-Chapter Micro-Analysis

Process each chapter individually (split by H1 headers or chapter markers).

#### System Prompt

```
You are an expert literary analyst performing a structural autopsy of a published
novel. Your job is to extract the craft decisions, not to judge quality.

For each chapter, produce a precise structural analysis that another writer could
use to understand HOW this book works at the scene level.

Be specific. Quote the text. Name the techniques. A useful analysis is one that
teaches craft, not one that summarises plot.
```

#### Per-Chapter Analysis Output

```
CHAPTER {N}: "{title or first line}"

SUMMARY: [3-5 sentences — what happens, not interpretation]

CHARACTERS PRESENT:
- [Name] — Role in this chapter: [POV | antagonist | ally | witness | mentioned]
  - Motivation this chapter: [What do they want RIGHT NOW?]
  - Emotional state: [entering] → [exiting]

SETTING:
- Primary location: [where]
- Time: [when — time of day, season, relative to story timeline]
- Sensory details used: [list the specific senses the author engages]

CONFLICT:
- Type: [internal | interpersonal | societal | environmental | mystery]
- Specific conflict: [one sentence]
- Resolution status: [resolved | escalated | deferred | transformed]

TROPES DEPLOYED:
- [Trope name] — [How it manifests in this chapter]
- [Trope name] — [Subverted, played straight, or inverted?]

KEY CRAFT TECHNIQUES:
- [Technique] — [Specific example with brief quote]
  (e.g., "Unreliable narrator: protagonist claims 'I barely noticed him' while
  spending 3 paragraphs describing his appearance")

PACING SLIDERS (estimated from prose):
  Tension: [1-10]  Dread: [1-10]  Emotional Intimacy: [1-10]
  Relationship Tension: [1-10]  Pacing Energy: [1-10]  Humor: [1-10]

CONTENT INTENSITY:
  Spice: [0-5]  Violence: [0-5]  Swearing: [0-5]

MARKETABLE QUOTES: [1-2 standout lines that represent the book's voice]
```

### Phase 2: Full-Manuscript Analysis

After all chapters are analysed, perform two analysis passes on the complete data.

#### Pass 1: Literary Analysis

```
You are a literary analyst examining the complete structural profile of a novel.
You have the chapter-by-chapter analysis below.

Produce a comprehensive structural analysis covering:

1. GENRE IDENTIFICATION
   - Primary genre and subgenre
   - Genre conventions followed
   - Genre conventions subverted
   - Comparable titles ("readers who liked X will like this")

2. TROPE INVENTORY
   - All tropes used across the manuscript
   - How each trope is set up and paid off
   - Which tropes are subverted vs played straight
   - Trope interactions (how tropes combine for effect)

3. CHARACTER ARC MAPPING
   For each major character:
   - WANT: What they pursue consciously
   - NEED: What they actually need (often opposite of want)
   - FLAW: The internal limitation they must overcome
   - ARC TYPE: transformation | growth | fall | steadfast | disillusionment
   - KEY ARC BEATS: [chapter numbers where the arc shifts]
   - RELATIONSHIP MAP: How they relate to every other major character

4. THEME EXTRACTION
   - Primary theme (stated as a question the story asks)
   - How the theme is explored through character action (not dialogue)
   - Thematic resolution (what answer the story suggests)
   - Secondary themes and their vehicles

5. PLOT DEVICE INVENTORY
   - Foreshadowing instances (plant chapter → payoff chapter)
   - Chekhov's Guns (objects/details that become significant later)
   - Red herrings (if mystery/thriller)
   - Dramatic irony (what the reader knows that characters don't)
   - Reversals and twists (chapter, type, effectiveness)

6. STRUCTURAL BEAT MAPPING
   Map the story against standard beat structures:
   - Inciting Incident: Chapter __ ({percentage}% through)
   - First Plot Point / Point of No Return: Chapter __
   - First Pinch Point: Chapter __
   - Midpoint: Chapter __
   - Second Pinch Point: Chapter __
   - All Is Lost / Dark Moment: Chapter __
   - Climax: Chapter __
   - Resolution: Chapter __
   - Note which beats land on-target and which are early/late

7. PACING PROFILE
   - Tension arc across chapters (use slider data from Phase 1)
   - Where the "breathing room" chapters are
   - Pacing rhythm pattern (e.g., "tension-tension-breather" or "steady escalation")
   - Chapter length variation and its effect on pacing
```

#### Pass 2: Plot Template Generation (Genericized Blueprint)

```
You are a story architect. Using the literary analysis above, create a
GENERICIZED PLOT TEMPLATE — a reusable structural blueprint stripped of
all specific names, places, and details.

The template should be written so that another author in the same genre
could use it as a starting framework for an ORIGINAL story.

CRITICAL RULES:
- Replace ALL character names with role labels (The Protagonist, The Mentor,
  The Antagonist, The Love Interest, The Best Friend, etc.)
- Replace ALL location names with function labels (The Safe Haven, The Danger
  Zone, The Workplace, The Secret Meeting Place)
- Replace ALL specific plot events with structural descriptions
  ("The protagonist discovers evidence of betrayal" not "Sarah finds the emails")
- Preserve the EMOTIONAL and STRUCTURAL logic, not the content
- Include WHY each structural element works, not just WHAT it is
```

#### Plot Template Output Format

```
PLOT TEMPLATE: [Genre] [Subgenre] — [Structural Pattern Name]
Based on: [Original title — for reference only, not for copying]
Recommended length: [word count range]
Chapter count: [recommended range]

PREMISE PATTERN:
[One paragraph describing the structural premise without specific details]

CHARACTER ROLES REQUIRED:
For each role:
- ROLE: [label]
- FUNCTION: [what this character does for the story]
- ARC TYPE: [transformation | growth | fall | steadfast]
- RELATIONSHIP TO PROTAGONIST: [how they challenge/support the protagonist]
- ESSENTIAL TRAIT: [one trait this role MUST have for the structure to work]

ACT STRUCTURE:

ACT 1 — [Structural purpose] (Chapters 1-{N}, ~{percentage}% of manuscript)
  Chapter-by-chapter structural beats:
  Ch 1: [Structural function — e.g., "Establish protagonist's ordinary world
         and the specific dissatisfaction that makes them vulnerable to the
         inciting incident"]
  Ch 2: [Structural function]
  ...

ACT 2A — [Structural purpose] (Chapters {N}-{N})
  ...

MIDPOINT — [What changes and why]

ACT 2B — [Structural purpose] (Chapters {N}-{N})
  ...

ACT 3 — [Structural purpose] (Chapters {N}-{N})
  ...

SUBPLOT FRAMEWORK:
For each subplot type used:
- TYPE: [romance | investigation | family | professional | internal]
- INTEGRATION POINTS: [which main-plot chapters it surfaces in]
- PURPOSE: [how it serves the main plot and theme]
- RESOLUTION TIMING: [before, during, or after main climax]

TROPE FRAMEWORK:
- [Trope] — When to deploy: [structural position]. How to use: [straight/subverted]

PACING BLUEPRINT:
[Chapter-by-chapter slider targets based on the analyzed book's pacing profile]

CONTENT INTENSITY ARC:
[Chapter-by-chapter content rating targets showing how intensity escalates]

KEY STRUCTURAL INSIGHTS:
[3-5 specific observations about WHY this structure works — the non-obvious
craft decisions that made the original book effective]
```

## Output Files

Write analysis results to:
- `Ideorix-Projects/[Title]/engine-data/analysis/chapter-analysis.md` — Phase 1 per-chapter data
- `Ideorix-Projects/[Title]/engine-data/analysis/literary-analysis.md` — Phase 2 Pass 1
- `Ideorix-Projects/[Title]/engine-data/analysis/plot-template.md` — Phase 2 Pass 2

## Using a Plot Template for New Projects

When the user wants to write a story using an extracted plot template:

1. Load the plot template into Phase 1 (Setup) as the structural framework
2. During Phase 2A (Foundation), map the user's characters to the template's role slots
3. During Phase 2B (Plot), use the template's act structure and beat positions as
   targets for the chapter outline
4. The template is GUIDANCE, not prescription — the author can deviate where their
   story demands it. The value is in the structural logic, not rigid adherence.

## Multi-Book Analysis (Genre Research)

When analysing multiple books in the same genre:

1. Run the full analysis on each book individually
2. After all books are analysed, perform a cross-book comparison:
   - Common structural patterns across all books
   - Genre-specific trope frequencies
   - Typical pacing profiles for this genre
   - Character role patterns (what roles appear in every book?)
   - Content intensity norms for this genre
3. Produce a **Genre Structural Profile** — a composite template representing
   the genre's conventions, useful for planning genre-conformant stories

## Limitations

- This protocol requires the full text of the book to analyse. It cannot work
  from summaries, reviews, or partial excerpts.
- Analysis quality depends on chapter-level access. Books without clear chapter
  breaks may need manual splitting.
- The genericized template is a structural tool, not a creative one. It provides
  scaffolding; the author provides the story, characters, and voice.
