---
name: general-fiction-genre
description: Genre-specific instructions for general fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# General Fiction. Genre Plugin

## Metadata
- id: general
- name: General Fiction
- icon: 📖
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Dan Harmon Story Circle", "Save the Cat"]

## Subgenre Options
Present during setup:
- **Character-Driven**. The story IS the characters: their choices, relationships, growth, and struggles define every chapter; plot serves character, not the reverse
- **Plot-Driven**. A compelling situation or mystery drives the narrative: strong hooks, clear stakes, satisfying twists; character reveals through action
- **Ensemble**. Multiple protagonists whose stories interweave: each perspective illuminates the others; the connections between stories are the architecture
- **Slice-of-Life**. The drama of everyday existence: no explosions, no conspiracies. just the extraordinary difficulty of being human, rendered with precision and empathy
- **High-Concept**. A single "what if" premise that drives everything: the concept is the hook, the execution is the craft; accessible, commercially minded
- **Hybrid/Cross-Genre**. Elements from multiple genres blended into something that doesn't fit neatly into any category; the freedom to draw on any tradition

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Varies by approach. character-driven stories breathe; plot-driven stories accelerate; the key is CONSISTENCY within the chosen rhythm
- Must open with: A character in a specific situation that raises a question the reader wants answered; voice and world established in the first paragraph

BEATS PER CHAPTER
1. Character Beat. Who is this person RIGHT NOW: their emotional state, their want, their obstacle
2. Tension Beat. Something resists the character: another person, circumstances, their own nature
3. Discovery Beat. Something is learned, revealed, or understood that changes the situation
4. Connection Beat. A relationship is tested, deepened, broken, or begun; general fiction lives in the space between people
5. Movement Beat. The story advances: a decision is made, a situation changes, a threshold is crossed

GENERAL FICTION ARCHITECTURE
- STORY is king: no genre conventions to lean on, no built-in audience expectations; the story must be compelling on its own merits
- CHARACTER is the engine: readers follow people, not plots; every character must be specific, contradictory, and alive
- VOICE matters more than in genre fiction: the narrative voice IS the experience; a distinctive, confident voice can carry anything
- STAKES can be small if they're real: a marriage in trouble, a friendship tested, a career at a crossroads. these matter because they're UNIVERSAL
- THE WORLD is our world (usually): general fiction is set in recognisable reality, which means the details must be PRECISE
- THEME emerges from story: don't start with a message; start with characters in situations and let meaning arise
- POV: Any. first, second, third, single, multiple, close, distant; general fiction has the widest POV freedom

THE ACCESSIBLE STORY
- General fiction must be accessible WITHOUT being simple
- The reader should understand the characters' situations, even if they've never lived them
- Emotional truth is universal: a reader who's never divorced can still feel the pain of a marriage ending
- Avoid insider knowledge requirements: the story should make sense to any intelligent adult reader
- The hook must work on the first page: who is this person, what do they want, what's in their way?

FORBIDDEN IN GENERAL FICTION
- Navel-gazing: characters thinking at length without doing, feeling, or interacting
- Plot for plot's sake: twists and events that serve the story's mechanics but not its meaning
- Passive protagonists: characters who observe life rather than engaging with it
- Sentimentality: emotion that's unearned (the reader should CRY, but because you made them, not because you told them to)
- Cliché situations without fresh angles: the midlife crisis, the estranged family reunion, the road trip. these work ONLY with a distinctive approach
- Theme-first writing: stories that exist to prove a point rather than to illuminate experience
- Homogeneous cast: general fiction should reflect the world's diversity naturally
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (texture of the everyday), Affection (character intimacy), Revelation (insight).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Flexible. choose the POV that serves the story, not convention
- Voice: DISTINCTIVE. in general fiction, voice is your primary tool; the reader should recognise your narrator within a paragraph
- Tone: Varies. but must be consistent within the manuscript; a comic novel stays comic, a sombre novel stays sombre
- Register: Match the characters and world; a blue-collar protagonist sounds different from an academic one

PROSE IMPERATIVES
- SPECIFICITY: general fiction lives in the details
  - Not "a car" but "a 2019 Corolla with a dent above the left rear wheel and a parking pass from a hospital she hadn't visited in six months"
  - Not "she was sad" but "she sat at the kitchen table and ate cereal standing up because the chair was where he used to sit"
  - Every detail does double duty: physical reality AND emotional content
- SCENE CRAFT: every scene must justify its existence
  - Who wants what? Who's preventing it? What changes?
  - Enter late, leave early: start the scene where the tension begins, end when the question is raised
  - If nothing changes in a scene, cut the scene
- DIALOGUE IS CHARACTER: people reveal themselves through what they say and HOW they say it
  - Speech patterns: rhythm, vocabulary, sentence length, interruption habits
  - Subtext: what they're NOT saying is often more important
  - Dialogue should advance plot AND reveal character simultaneously
- THE INVISIBLE LINE: craft that doesn't call attention to itself
  - The reader should be IN the story, not admiring the prose
  - Clarity over cleverness: every sentence should communicate clearly
  - The writing should feel effortless (which means the craft is excellent)

PROSE RHYTHM MAPPING
- Ch 1 hook: Character + situation that compels. this is the catch-all genre
- Prose rhythm: Adapt to the story's needs. no single rhythm prescription
  - BUT: establish a consistent voice by end of Ch 1 that the reader can settle into
  - Whatever rhythm you choose in Ch 1, maintain it consistently throughout
- Sentence length: 14-22 words average
  - Variation serves the story, not the writer's ego
  - Match the character: a terse character gets terse prose; a reflective one gets longer lines
- Dialogue: 30-40% by word count
  - Each character's speech pattern identifiable without tags
  - Subtext: the gap between said and meant is where drama lives
- Tension: ≥4 for Ch 1
- Paragraph rhythm: Medium (3-5 sentences)
  - Consistent with the chosen voice and tone
  - Scene-and-sequel rhythm: active scenes (short paragraphs) followed by reactive processing (longer ones)
- The key rule: consistency. general fiction earns trust through reliable prose rhythm

DESCRIPTION CRAFT
- Describe the world through the character's consciousness:
  - What they notice reveals who they are
  - A chef notices the smell of the restaurant; a real estate agent notices the square footage; a mother notices the child's plate
  - The same setting described differently by different characters IS characterisation
- Economy: one perfect detail beats three adequate ones
- Movement: descriptions should be dynamic, not static. characters interact with their environment, they don't pose in it

DIALOGUE CRAFT
- Each character has their own speech pattern: rhythm, vocabulary, sentence structure, verbal tics
- Subtext: the gap between what's said and what's meant is where the drama lives
- Silence is dialogue: when a character doesn't respond, it speaks volumes
- Exposition through conflict: characters reveal backstory when arguing, defending, explaining, or lying. never through neutral information exchange
- Balance: dialogue and narration should alternate; long dialogue blocks without narrative grounding float away from the scene
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

CHARACTER CRAFT (40% of total):
- Characters are specific, contradictory, and alive? (0-100)
- Character voice is distinctive and consistent? (0-100)
- Relationships feel dynamic and authentic? (0-100)
- Character growth/change is earned through events? (0-100)

STORY CRAFT (30% of total):
- Every scene advances plot, reveals character, or both? (0-100)
- Stakes are clear, personal, and genuinely felt? (0-100)
- The narrative voice is distinctive and confident? (0-100)
- Pacing is appropriate and consistent? (0-100)

PROSE QUALITY (30% of total):
- Details are specific and do double duty (physical + emotional)? (0-100)
- Dialogue sounds like real people (differentiated, subtext-rich)? (0-100)
- Description is dynamic and character-filtered? (0-100)
- The writing is clear, precise, and invisible (doesn't distract from the story)? (0-100)

AUTOMATIC FAILS (score = 0):
- Passive protagonist who observes but doesn't act or choose
- Sentimentality: telling the reader what to feel instead of creating the feeling
- Characters who all sound the same in dialogue
- Scenes where nothing changes (no tension, no movement, no revelation)
- Theme delivered as lecture rather than emerging from story
- Vague, generic descriptions that could apply to any character or setting
```

## Continuity Rules

```
GENERAL FICTION CONTINUITY. WHAT TO TRACK

CHARACTER STATE:
- Each character's emotional arc: where they are psychologically at each chapter
- Relationships: the current state of every significant relationship
- Knowledge: what each character knows, when they learned it, and who told them
- Wants and obstacles: what each character is pursuing and what's blocking them
- Contradictions: internal conflicts that haven't been resolved

WORLD STATE:
- Setting details: specific physical descriptions that must remain consistent
- Time of year, weather, and how the world looks/feels at this point
- Social context: jobs, living situations, financial states, community
- Cultural specifics: regional details, social norms, local colour

TIMELINE:
- When events happened and in what order
- Character ages and how they relate to each other
- Backstory events: dates and details mentioned in flashback or conversation
- Seasonal markers: holidays, school terms, weather changes, cultural events

EMOTIONAL CONTINUITY:
- Characters' emotional states should evolve logically from scene to scene
- A fight in chapter 3 should affect behaviour in chapter 4
- Grief, joy, anger, and love have afterlives. they don't appear and vanish
- The emotional temperature of the manuscript should track a coherent arc

OBJECT/DETAIL CONTINUITY:
- Specific objects mentioned (a ring, a photograph, a scar) must remain consistent
- Physical descriptions: hair colour, height, age, distinguishing features
- Locations: layout of houses, geography of towns, distances between places
- Habits: if a character drinks tea in chapter 1, they don't switch to coffee without reason
```

## Character Rules

```
GENERAL FICTION CHARACTER CONSTRUCTION

THE PROTAGONIST:
- Specific: not an everyperson but a THIS-person; age, job, habits, history, fears, contradictions
- Active: they make choices, take actions, and face consequences
- Flawed: their weaknesses drive the plot as much as their strengths
- Growing: they are different at the end than at the beginning (even if only by inches)
- Sympathetic (not necessarily likeable): the reader understands WHY they do what they do
- Want vs. Need: what they think they want is often different from what they actually need

SUPPORTING CHARACTERS:
- Each has their own agenda: they don't exist solely to serve the protagonist's story
- They challenge the protagonist: by disagreeing, competing, or offering an alternative worldview
- They're specific: speech patterns, physical habits, contradictions, and histories of their own
- They CHANGE the protagonist: through conflict, love, example, or opposition

THE ANTAGONIST (if applicable):
- In general fiction, the antagonist may be a person, a situation, or an internal conflict
- If a person: they have their own valid perspective; they're not wrong, they're different
- Their opposition creates the story's central tension
- They may be sympathetic. the reader should understand their position

CHARACTER VOICE:
- Every character's dialogue should be identifiable without attribution tags
- Voice reveals: education, region, personality, emotional state, relationship to the listener
- Characters surprise: they say things the reader didn't expect but immediately recognises as true
- Inner voice: the protagonist's internal monologue has a different register from their spoken dialogue

ENSEMBLE DYNAMICS (if multiple POVs):
- Each POV character sees the world differently: the same event from two perspectives
- The connections between characters' stories should feel organic, not engineered
- Each storyline should be compelling on its own; they enhance each other but don't depend on each other
- Differentiate POVs through voice, not just content
```

## Arc Rules

```
GENERAL FICTION STORY STRUCTURE

ACT 1: THE WORLD AS IT IS (first 25%)
- Establish the protagonist in their ordinary world with full specificity
- Show what they want (their conscious desire) and hint at what they need (their deeper requirement)
- Introduce the central tension: the relationship, the situation, the conflict that will drive the story
- The inciting event: something disrupts the equilibrium; the story begins
- Establish the voice and tone: the reader knows what kind of book this is by the end of Act 1
- END OF ACT 1: The protagonist is set on a path (by choice or circumstance) that will change them

ACT 2A: THE ENGAGEMENT (to midpoint)
- The protagonist pursues their want: actively engaging with the situation
- Complications arise: not just obstacles, but COMPLICATIONS (things that make the situation more complex)
- Relationships develop: alliances, romances, friendships, enmities
- The protagonist's flaws create problems: they make mistakes that are CHARACTERISTIC
- The world expands: the reader learns more about the context, community, and history
- MIDPOINT: A revelation or event that shifts the protagonist's understanding of their situation

ACT 2B: THE COMPLICATION (midpoint to dark moment)
- The gap between WANT and NEED becomes visible: the protagonist is pursuing the wrong thing
- Consequences accumulate: earlier choices come back with interest
- Relationships are tested: betrayal, disappointment, the failure of trust
- The protagonist's worldview is challenged: their assumptions about themselves and others are wrong
- External pressure intensifies: deadlines, threats, competitive forces
- DARK MOMENT: The protagonist faces the full truth about their situation, their relationships, or themselves

ACT 3: THE RESOLUTION (final 25%)
- The protagonist must choose: what they want vs. what they need, who they've been vs. who they could be
- The climactic scene is emotional, not (necessarily) physical: a conversation, a decision, a realisation
- Relationships resolve: not necessarily happily, but truthfully
- The change is visible: the protagonist acts differently than they would have in Act 1
- The world has shifted: even if externally unchanged, the protagonist's relationship to it has
- The ending feels both surprising and inevitable: "of COURSE it ended this way"

GENERAL FICTION PACING:
- Varies by subgenre: character-driven is slower, plot-driven is faster
- Scene-and-sequel rhythm: an active scene (tension) followed by a reactive sequel (processing)
- The pace should accelerate through Act 2 and especially Act 3
- Quiet moments are not slow moments: a conversation can be as tense as a chase scene
```

## Timeline Rules

```
GENERAL FICTION TIMELINE

FLEXIBLE TIMELINE:
- General fiction spans days to decades depending on the story
- Track the passage of time precisely: characters age, seasons change, the world moves
- If using time jumps: signal clearly and reorient the reader

SEASONAL/CALENDAR:
- Time of year affects mood, activity, and available metaphors
- Holidays and cultural events provide natural story beats
- The relationship between personal timeline and cultural calendar matters

BACKSTORY TIMELINE:
- Track when key backstory events occurred
- How old characters were during formative events
- The order in which backstory is revealed to the reader (different from chronological order)

PARALLEL TIMELINES (if applicable):
- Multiple POV characters may be on different timelines
- Ensure temporal consistency when stories intersect
- Track where each character is at key moments
```

## Genre-Specific Craft Techniques

General fiction is the most demanding genre in one specific
sense: it has no genre conventions to lean on. Where a
thriller has chase-and-stakes, a romance has chemistry-and-
pull-back, a fantasy has worldbuilding-and-magic-system,
general fiction has only what the writer brings to the page
— voice, character, specificity, scene craft, and the
discipline of universal-resonance through specific-rendering.
The masterclass roster spans the literary-commercial axis:
Anne Tyler, Richard Russo, Elizabeth Strout, Ann Patchett,
Anthony Doerr, Donna Tartt, Curtis Sittenfeld, Roxane Gay,
Maggie O'Farrell, Lauren Groff, Jennifer Egan, Nicole
Krauss, Colson Whitehead, Tayari Jones, Tommy Orange, Brit
Bennett, Imbolo Mbue, Yaa Gyasi, Tessa Hadley, Tessa
McWatt, Bonnie Garmus, Gabrielle Zevin, Liane Moriarty,
Jodi Picoult, Fredrik Backman, John Grisham, Kristin
Hannah, Delia Owens, Karen Joy Fowler, Jess Walter — each
operating at a different point on the literary-commercial
spectrum, each demonstrating that general fiction's craft
discipline is to make the specific universal and the
universal specific. The most common failure modes in this
register are: **Genre-Drift** (the manuscript trying to be
General when it should commit to a specific genre — the
mystery without commitment to mystery's tension architecture,
the romance without commitment to romance's emotional
architecture, the thriller without commitment to thriller's
pacing); **Stake-Vagueness** (the absence of genre
constraints means stakes get unfocused — the reader is
asked to care without being given a specific reason to);
**Voice-Generic** (general fiction's hardest craft: a
distinctive voice without the genre register that does
voice-work in other categories; the narrator who sounds
like everyone and therefore like no one); **Theme-Lecture**
(general fiction without theme drifts; with theme delivered
as message it becomes pap; the genre demands theme that
emerges from story rather than is announced through it);
**Detail-Generic** (the universal-applicable detail rather
than the character-specific one — "the room was small"
rather than "the room had the kind of small that meant the
landlord called it cosy"); **Pacing-Drift** (no genre
pacing template means the writer must impose pacing
discipline rather than inherit it); **Sentimentality**
(without genre conventions to mediate emotion,
sentimentality is the constant risk — the prose telling
the reader what to feel rather than creating the feeling);
**Cliché-Situation-Without-Fresh-Angle** (the midlife
crisis, the divorce, the road trip, the estranged-family
reunion — universal situations that need specific
treatment to escape banality); **Narration-Floats** (without
genre constraints, narration disconnects from action;
characters think rather than choose; the manuscript
becomes interior monologue rather than story); and
**Character-Without-Specificity** (the everyperson
protagonist whose lack of specific texture means the
reader has nothing to grip; the universal-resonance
contract collapses when the specifics are missing). The
techniques below — three preserved (Double-Duty Detail,
Scene Justification Test, Invisible Craft) and three
added (Specificity Imperative, Universal-Specific
Calibration, Voice-as-Genre Discipline) — are designed to
keep the genre's defining commitments live: specificity
where genre would otherwise carry weight, universal-
resonance through specific-rendering, and voice that does
the work genre register does elsewhere.

### The Double-Duty Detail

Every significant detail should serve two purposes:

```
SINGLE DUTY (weak):
"She wore a blue dress."
(Physical description only)

DOUBLE DUTY (strong):
"She wore the blue dress she'd bought for the interview
she never went to."
(Physical description + backstory + emotional state)

TRIPLE DUTY (excellent):
"She wore the blue dress she'd bought for the interview
she never went to. Her mother would have said it was too
short. Her mother would have been right."
(Physical + backstory + character relationship + voice)
```

### The Scene Justification Test

Every scene must pass this test:

1. **Who wants what?** (If no one wants anything, cut the scene)
2. **Who or what opposes them?** (If there's no opposition, cut the scene)
3. **What changes by the end?** (If nothing changes, cut the scene)
4. **What does the reader learn about the character?** (If nothing, strengthen the scene)

### The Invisible Craft

General fiction prose should be transparent. the reader looks THROUGH it to the story:

```
VISIBLE CRAFT (distracting):
"The cerulean sky stretched its gossamer canopy above
the undulating emerald meadow as she contemplated the
byzantine machinations of her erstwhile companion."

INVISIBLE CRAFT (immersive):
"The sky was the kind of blue that made you feel stupid
for staying inside. She sat on the hill and thought about
Mark. She thought about what he'd said and what he'd meant,
which were, as always, different things."
```

The second version is technically HARDER to write. That's the point.

### General Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the story unfolded" | Delete. Just tell the story. |
| "little did they know" | Delete. Show what happens next. |
| "destiny had other plans" | Show the specific event that changes plans |
| "the truth was more complicated than expected" | Show the specific complication |
| "everything changed in an instant" | Show the specific instant |
| "the journey was just beginning" | Show the specific first step |
| "some things can't be explained" | Show the specific unexplained thing |
| "the world would never be the same" | Show the specific change |
| "nothing could have prepared them" | Show what they face. let the reader feel the unpreparedness |
| "a story of love, loss, and redemption" | Delete. Show each through action. |
| "in the end, what mattered most was" | End on the specific thing, not the announcement of it |
| "she felt a profound sense of" | Cut "profound sense of"; show the specific feeling through specific behaviour |
| "the room had a strange atmosphere" | Show the specific detail that creates the atmosphere |
| "their eyes told a different story" | Cut character-through-eyes cliché; show the specific gesture or action |
| "she found herself wondering" | Cut "found herself"; just write the thought |
| "the silence stretched between them" | Show what fills the silence (the held breath, the unfinished sentence, the ticking clock) |
| "her past haunted her" | Cut metaphor; show the specific past intruding on the specific present moment |
| "in that moment, she knew" | Cut announcement; show what specifically tells her she knows |

### The Specificity Imperative

In genre fiction, the genre's conventions carry load-
bearing weight: thriller readers know thriller-pacing,
romance readers know romance-architecture, fantasy readers
know magic-system rules. In general fiction, the writer
has none of that. The Specificity Imperative is the
discipline that does the load-bearing work genre would
otherwise do: every detail, character, situation, and
moment must be specifically rendered.

```
PRINCIPLE
For every named element in the manuscript, the writer
must satisfy at least three of the following four
specificity criteria:
1. NAMED — the element has a specific name, brand,
   model, place, or identifier (not "a car" but "a
   2014 Honda Civic"; not "a town" but "Ardmore,
   Oklahoma"; not "her sister" but "Lena, who was
   three years older and had always been the
   responsible one")
2. SENSORY — the element is rendered through specific
   sensory texture (smell, sound, touch, taste, or
   sight rendered with precision)
3. CHARACTER-FILTERED — the element is described
   through THIS character's specific consciousness; a
   chef notices different things from a real-estate
   agent from a mother
4. CONSEQUENTIAL — the element matters to plot,
   character, theme, or scene-function in a way the
   reader can name; if the detail were removed, the
   manuscript would lose something specific

CALIBRATION TEST
- Could the chapter's details be removed and replaced
  with generic equivalents without the manuscript
  losing anything specific? If yes, the Specificity
  Imperative has not been honoured.
- Are details NAMED rather than referred to in the
  abstract?
- Are details FILTERED through the POV character's
  specific consciousness rather than rendered in
  authorial omniscient?
- Do details CONSEQUENTIALLY function in the
  manuscript rather than appearing as decoration?
If any answer is no — rebuild for specificity.

ANTI-PATTERNS
- "A car," "a building," "a town," "a feeling," "a
  conversation" — abstract category-words instead of
  specific named instances
- The detail that could appear in any character's
  POV interchangeably
- The decorative detail that could be cut without
  the manuscript noticing
- The everyperson protagonist who lives in everyplace
  and notices nothing in particular
```

### The Universal-Specific Calibration

The genre's signature tension is the discipline of
making the specific universal and the universal specific
— rendering THIS particular life with enough texture
that it resonates beyond itself, while keeping the prose
specific enough that it does not collapse into the
abstract. The Universal-Specific Calibration is the
craft balancing act that distinguishes general fiction
from both niche-particular literary fiction and
generic-everyperson commercial fiction.

```
PRINCIPLE
Every chapter must hold both poles in tension:
1. THE SPECIFIC POLE — this character, in this place,
   at this time, with this history, facing this
   particular situation; the rendering must be
   specific enough that the reader can SEE it
2. THE UNIVERSAL POLE — what this specific situation
   illuminates about the human condition; the
   resonance that lets a reader who has never lived
   this life still feel that life

CALIBRATION
- Specificity without universality = niche fiction
  (the reader who shares the situation can engage;
  the reader who does not is excluded)
- Universality without specificity = generic fiction
  (the everyperson at everyplace doing everything;
  the reader has nothing to grip)
- Both poles together = general fiction at its
  highest craft

WORKED CALIBRATION TEST
For every scene, ask:
- Is the specific texture rendered with named, sensory,
  character-filtered, consequential detail?
- Does the scene's emotional or thematic charge
  extend BEYOND the specifics — does the reader
  recognise something universal in the specific?
- Could the universal resonance be felt without the
  specific rendering? (If yes, the universality is
  abstract.)
- Could the specific rendering be appreciated without
  the universal resonance? (If yes, the specificity
  is niche.)

ANTI-PATTERNS
- The marriage-trouble novel that could be any
  marriage-trouble novel (universal without
  specific)
- The novel set in such specific texture that the
  outside reader cannot follow (specific without
  universal)
- The "every reader will see themselves" pitch that
  produces the everyperson protagonist
- The "this is a story about [universal theme]"
  framing that announces the universal rather than
  letting the specific reveal it
```

### The Voice-as-Genre Discipline

In genre fiction, the genre register IS partly the
voice (the noir voice, the romance voice, the thriller
voice, the literary voice). In general fiction, the
writer has no inherited register; the voice must be
invented, sustained, and recognisable as itself. The
Voice-as-Genre Discipline is the requirement that the
narrative voice do the work that genre register does
elsewhere — establishing tone, pacing the prose,
filtering the world, and signalling what kind of book
the reader is in.

```
PRINCIPLE
The narrative voice must satisfy at least four of the
following five criteria:
1. RECOGNISABLE — a reader could identify the voice in
   a blind test against three other voices, by
   sentence structure, vocabulary range, characteristic
   devices
2. CONSISTENT — the voice maintains its character
   across the manuscript; tone shifts by scene, but
   the voice's underlying rhythm and register hold
3. CHARACTER-ROOTED — the voice is shaped by the
   POV character's specific consciousness, education,
   class, region, era, or psychology
4. RHYTHMIC — the voice has a discernible prose
   rhythm — sentence-length pattern, paragraph
   pattern, dialogue-narration alternation — that
   the reader settles into
5. SIGNALLING — the voice signals to the reader what
   kind of story this is (comic, sombre, sharp,
   warm, ironic, devotional) within the first few
   pages

CALIBRATION TEST
- Read a paragraph aloud. Does it sound like THIS
  narrator and only this narrator?
- Could the voice belong to any of the manuscript's
  characters, or is it specific to the POV
  consciousness?
- Does the voice maintain across the manuscript with
  a consistent rhythm and register?
- Does the voice do tonal work that signals story-
  type to the reader without genre conventions doing
  it?
If any answer is no — rebuild voice from the POV
character's specific interiority outward.

ANTI-PATTERNS
- The voice that sounds like the writer rather than
  the narrator
- The voice that drifts (literary in chapter 2,
  commercial in chapter 14, ironic in chapter 21)
- The voice with no rhythm — sentences of similar
  length, no characteristic devices, no settling
  pattern
- The voice that signals nothing — the reader cannot
  tell from the prose whether this is a comic novel,
  a sombre one, a sharp one, a warm one
- The voice borrowed without earning (the Tartt-
  voice, the Strout-voice, the Rooney-voice
  imitated rather than constructed from this
  specific manuscript's character base)
```

## Genre-Specific Revision Rules

### Six-Pass General Fiction Audit (Run FIRST in editorial pipeline)

The General Fiction Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Scene Justification Pass

Verify every scene passes the Scene Justification Test —
desire, opposition, change. The Narration-Floats failure
mode is caught here. for every scene, ask: who wants
what? who or what opposes them? what changes by the end?
what does the reader learn about the character? If any
of these questions cannot be answered, either rebuild
the scene to deliver them or cut. General fiction has no
genre-pacing template to lean on; the discipline of
scene-level desire-opposition-change is the manuscript's
forward-motion engine. Passes where nothing wants
anything, nothing opposes anything, or nothing changes
must be removed. The Pacing-Drift failure mode is caught
here too — the manuscript that cannot articulate why
this scene exists has lost its pacing discipline.

#### Pass 2: Character Vitality Pass

Verify characters are specific, contradictory, and alive.
The Character-Without-Specificity failure mode is the
genre's deepest failure — the everyperson protagonist
whose lack of specific texture means the reader has
nothing to grip. Audit each chapter: do characters sound
different from each other in dialogue? Is the protagonist
making active choices rather than observing? Are
supporting characters three-dimensional with their own
agendas, voices, and arcs? Does each character's
behaviour reveal specific psychology rather than generic
type? If a character's dialogue could be reassigned to
another character without notice, the voice has flattened
and must be rebuilt for character specificity.

#### Pass 3: Specificity Pass

Verify details are specific and revealing, not generic.
The Specificity Imperative provides the spec — every
detail must be NAMED, SENSORY, CHARACTER-FILTERED, and
CONSEQUENTIAL. Audit the chapter: are objects, places,
people, and situations referred to with specific
identifiers rather than abstract category-words? Are
sensory details rendered through the POV character's
consciousness? Does the setting feel like a REAL place
with specific texture? Are emotions shown through
specific behaviour rather than labelled? The Detail-
Generic failure mode is caught here. if a chapter's
details could be removed and replaced with generic
equivalents without the manuscript losing anything,
rebuild for specificity.

#### Pass 4: Voice Consistency Pass

Verify the narrative voice is distinctive, consistent,
and doing the work genre register would do elsewhere.
The Voice-as-Genre Discipline provides the spec —
recognisable, consistent, character-rooted, rhythmic,
signalling. Audit the chapter: would a reader recognise
this voice in a blind test against three other voices?
Does the voice maintain across the manuscript? Is the
voice character-rooted rather than authorial-imposed?
Does the prose rhythm settle the reader into a
discernible pattern? Does the voice signal to the reader
what kind of story this is? The Voice-Generic failure
mode is caught here. if the narrator could be any
narrator, the voice has not been built and must be
rebuilt from the POV character's specific interiority
outward.

#### Pass 5: Emotional Truth Pass

Verify characters' emotional responses are proportionate
and authentic; emotion is earned through events and
character rather than imposed by narration. The
Sentimentality failure mode is the genre's signature
risk — the prose telling the reader what to feel
rather than creating the feeling through specific
rendering. Audit each emotional moment: is the feeling
shown through specific physical, behavioural, or
sensory detail, or is it labelled in the abstract? Does
the emotional arc of the chapter unfold logically from
the events and characters? Are emotional responses
proportionate to the events that produced them? Is the
manuscript trusting the reader to feel the emotion
rather than instructing them to? The Cliché-Situation-
Without-Fresh-Angle failure mode is caught here too —
universal situations (midlife crisis, divorce, road
trip) need specific treatment to escape banality.

#### Pass 6: Specificity-Imperative + Universal-Specific + Voice-as-Genre Integration

This pass is the general fiction integration check — it
ties the new techniques together and verifies the
manuscript honours its specific commitments at the
manuscript level.

For SPECIFICITY-IMPERATIVE: confirm Pass 3's spec has
been met across the manuscript. Are at least three of
the four specificity criteria (named / sensory /
character-filtered / consequential) satisfied for the
manuscript's significant elements? If the manuscript's
texture has gone abstract or category-word, rebuild for
specific rendering.

For UNIVERSAL-SPECIFIC: at the manuscript level, audit
whether the specific texture is producing universal
resonance. Could the manuscript's emotional or thematic
charge be felt by a reader who has not lived the
specific situation? Conversely, is the specificity
sufficient that the reader can see the situation
clearly? The genre's craft is in holding both poles —
neither niche-particular nor everyperson-generic but
both at once.

For VOICE-AS-GENRE: confirm Pass 4's spec across the
manuscript. Is the voice doing the work that genre
register does elsewhere — establishing tone, pacing
the prose, filtering the world, signalling story-type?
The Genre-Drift failure mode is caught here. if the
manuscript would benefit from committing to a specific
genre's register and conventions, the writer must
either commit fully to general fiction's voice-led
approach or migrate to the genre that fits. The
manuscript that wants to be a thriller but lacks
thriller pacing, or a romance but lacks romance
chemistry, or a mystery but lacks mystery architecture,
is general fiction by default rather than by craft —
and the reader feels the absence of the genre's
load-bearing weight.

## Names & Patterns to Avoid

### General Fiction Character Names. NEVER USE
- Names chosen for obvious symbolism: Hope, Grace, Chase, Chance, Destiny
- Names that signal the character's role: the villain named Blake, the love interest named Rose
- Overly exotic names in ordinary settings (unless the character's background justifies it)

### General Fiction Location Names. NEVER USE
- Generic small-town names: Millbrook, Oakville, Riverside (unless deliberately generic)
- Names that telegraph theme: Fallen Oaks, Broken Bridge, Still Waters
- Fictional towns that feel like sets rather than places

### Use Instead
- Names appropriate to the character's age, culture, and background
- Real place names or fictional names that feel real (researched, consistent with regional naming patterns)
- Names that become significant through the story, not names that arrive pre-loaded with meaning

## Comp Titles

General fiction's comp-title set supports manuscript
positioning across the literary-commercial spectrum:
market category placement, cover-design conversation,
reader-expectation calibration, similar-author discovery,
and editorial / agent submission framing. Because
general fiction lacks specific genre conventions, comps
draw from the broader literary-commercial landscape.

### Canonical (foundational reference points)

- *To Kill a Mockingbird* — Harper Lee (1960): the literary-commercial foundation.
- *East of Eden* — John Steinbeck (1952): family-saga literary masterpiece.
- *The Remains of the Day* — Kazuo Ishiguro (1989): literary unreliable-narrator benchmark.
- *Olive Kitteridge* — Elizabeth Strout (2008): literary-commercial linked-stories form.
- *A Little Life* — Hanya Yanagihara (2015): contemporary literary epic.

### Contemporary (current best-in-class)

- *The Vanishing Half* — Brit Bennett (2020): contemporary literary-commercial benchmark.
- *Lessons in Chemistry* — Bonnie Garmus (2022): literary-commercial crossover benchmark.
- *Tomorrow, and Tomorrow, and Tomorrow* — Gabrielle Zevin (2022): contemporary literary-commercial.
- *Hamnet* — Maggie O'Farrell (2020): historical literary benchmark.
- *Demon Copperhead* — Barbara Kingsolver (2022): contemporary American literary-commercial.
- *The Lincoln Highway* — Amor Towles (2021): contemporary literary-commercial.
- *Tom Lake* — Ann Patchett (2023): literary-commercial benchmark.
- *Trust* — Hernan Diaz (2022): metafictional literary benchmark.

## Cover Design Specifications

### Recommended Visual Styles
- **Photographic**. Evocative photography: a scene, a figure, a landscape that captures the emotional world of the novel; warm, inviting, or striking
- **Typographic**. The title IS the design: beautiful, confident typography with minimal imagery; signals literary quality and commercial accessibility
- **Illustrated**. Contemporary illustration style: not literal scene depiction but emotional interpretation; modern, distinctive, art-forward
- **Graphic**. Bold, clean design with a single striking image or colour choice; the cover as poster; confident and commercially savvy

### Genre Cover Aesthetics
- **Styles:** Evocative photographs (landscapes, objects, figures from behind or in profile), bold typography with subtle imagery, contemporary illustration, graphic design with emotional colour choices, scenes that suggest story without depicting specific moments
- **Colours:** Warm palettes for hopeful/comic tones (ambers, corals, yellows), cool palettes for serious/contemplative tones (slates, teals, muted blues), bold single-colour statements for high-concept (red, black, white), pastel for lighter literary tones, rich jewel tones for dramatic stories
- **Elements:** Everyday objects rendered significant (a house, a table, a road, a window, a key), figures in evocative poses (back to viewer, in motion, silhouetted), landscapes that suggest emotional territory, typography as the primary design element, white space used boldly
- **Typography:** Modern serif or sans-serif fonts; the title should be large, readable, and styled; typography often IS the cover design in general fiction; font choice signals tone (playful, serious, elegant, bold); author name prominently placed

### Market Positioning
General fiction covers must signal "this is a GOOD STORY" without relying on genre signals. Position against Backman, Moriarty, Picoult, Grisham, Baldacci. or literary: Strout, Tyler, Russo. The cover should suggest the emotional experience of the book. At thumbnail size, a bold typographic choice or single striking image against clean design creates the commercial signal. General fiction covers compete on design quality, not genre recognition.

### Cover Design DON'Ts
- No genre-specific imagery that mispositions the book (no swords, no blood, no spaceships)
- No clip-art quality imagery
- No cluttered designs with competing elements
- No clichéd "woman looking at horizon" or "person walking alone on beach" (unless the execution is exceptional)
- No dark, moody palettes that signal thriller or horror (unless the story warrants it)
- No tiny, unreadable text. general fiction titles should be BOLD
