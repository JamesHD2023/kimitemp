---
name: writers-studio
description: "Ideorix Writers Studio — the complete manuscript toolkit for writers who write their own prose. Story bible, editorial, continuity, marketing, naming — everything except the writing."
user-invocable: false
---
<!-- (c) 2025 James Harvey Media / Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — Writers Studio
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with `> **Powered by Ideorix** — Writers Studio` before any other output.

# Writers Studio

**You write. We handle everything else.**

Writers Studio gives you the full power of the Ideorix engine — story bible
creation, genre intelligence, professional editorial, continuity tracking,
market research, naming tools, and publishing preparation — without generating
a single word of your prose. Every word in your manuscript is yours.

---

## Who This Is For

- Writers who want to write their own prose but need professional-grade editorial infrastructure
- Writers who want AI to handle the *business* of writing — not the *craft* of writing
- Writers who want to plan meticulously before they write (story bible, outline, beat structure)
- Writers returning a manuscript they wrote from an Ideorix Story Bible
- Self-published authors who need editorial, marketing, and export tools
- Writers who want AI-ism detection on their own prose (the patterns are contagious)

---

## Menu — Choose an Action

### 1. Story Bible Workshop
Build the complete creative skeleton for your novel — world, characters, plot
architecture, timeline, relationships, genre-specific extensions — through a
guided interactive process. The engine builds it; you write from it.

**What you get:**
- Full Story Bible (15 sections — see `world-canon.md`)
- Character Bible with physical details, speech patterns, relationships
- Beat structure mapped to your genre (28 templates available)
- Trope plan with pairing suggestions
- Genre-specific planning extensions (mystery: clue schedules; romance: relationship
  arc maps; fantasy: magic system cards; thriller: threat escalation timelines)
- Writer's Companion document — your complete creative brief as a portable reference
- Chekhov's Gun lifecycle tracking
- Transportive setting atmosphere profiles

**How to start:** "Plan a book", "Build a story bible", "Story bible workshop"
→ Loads `write-a-book.md` in **Story Bible Only** mode, then `world-canon.md`,
`outline-builder.md`, `beat-structures.md`, `writers-companion.md`

### 2. Outline Validator
Bring your own outline and have it evaluated against genre conventions, beat
structure expectations, and pacing patterns. The engine doesn't write your
outline — it tells you where it's strong, where it has gaps, and what your
genre's readers expect.

**What you get:**
- Beat mapping against your chosen structure (Save the Cat, 3-Act, Hero's Journey, etc.)
- Missing beat identification with specific recommendations
- Pacing assessment — where tension rises, falls, and potentially stalls
- Genre convention check — does your structure meet reader expectations?
- Comparison against successful comp titles in your genre

**How to start:** "Validate my outline", "Check my outline", "Review my plot structure"
→ Loads genre file + `beat-structures.md` + `craft-standards.md`

### 3. Edit & Revise
The full editorial pipeline — proofreader, copy editor, developmental editor,
line editor, alpha reader, beta reader — run on your manuscript.

**What you get:**
- Voice Profile extracted from YOUR prose (protects your style throughout editing)
- Genre, POV, tense, and dialect auto-detection
- 6 editorial agents (run all or choose individual agents)
- Chapter-range targeting (edit chapters 8-12 only)
- Continuity audit — builds entity database from your manuscript, then validates
  internal consistency (characters, timeline, locations, relationships)
- Line Editor with 10 deep analyses:
  1. Passive Voice Taxonomy (5 categories)
  2. Adverb Audit (with preservation rules)
  3. Dialogue Tagging Audit
  4. AI Paragraph Architecture Detection
  5. Cliché Detection (4 categories)
  6. Redundancy Audit (4 categories)
  7. Show vs. Tell (Camera Test — 4 categories)
  8. Chapter Endings Evaluation (weak vs. strong)
  9. Dialogue Distinctiveness Test (Cover Test + Therapy-Speak Detection)
  10. Intimate Scene Review (6 dimensions)

**If you built a Story Bible first:** The engine reconnects to it and validates
your manuscript against established canon — flagging where you followed the plan
and where you departed. You decide what's intentional and what needs fixing.
This produces significantly better editing than a cold manuscript review.

**How to start:** "Edit my manuscript", "Run the editorial pipeline", "Proofread chapter 3"
→ See `edit-and-revise.md` for full details.

### 4. Manuscript Clinic
A diagnostic consultation — not editing, but analysis. Upload your manuscript
(complete or partial) for a scored assessment across 6 axes.

**What you get:**
- Structure & Pacing score (0-100) with specific chapter-level feedback
- Character Depth score with examples
- Dialogue Quality score
- Voice & Style score
- Market Viability score
- Genre Fit score
- 3 actionable recommendations per axis
- Interactive expert session to discuss findings
- Optional handoff to Editorial, Line Editor, or Marketing

**How to start:** "Manuscript clinic", "Analyse my manuscript", "How's my book?"
→ See `manuscript-clinic.md` for details. Protocol: `manuscript-clinic-protocol.md`

### 5. AI-ism Detection (Prose Humaniser)
Scan your prose for patterns that mark text as AI-generated — even in
human-written work. Writers who read AI-generated content are unconsciously
absorbing these patterns. This tool shows you where.

**What it detects:**
- ~1,170 forbidden words and phrases (statistical AI markers)
- Phrase-level AI-isms ("Something about X", "The weight of", "Found herself")
- Robotic transitions (Furthermore, Moreover, Notably — essay-mode connectives)
- Stage-direction atmosphere (sensory catalogues with analytical tails)
- Structural patterns (repetitive openings/endings, triple-beat lists)
- Punctuation anomalies (em-dash overuse, semicolons in dialogue)
- Genre-specific AI crutch phrases (loaded from your genre's bank)

**Your Voice Profile protects intentional patterns.** If "as though" is part of
your established voice, it won't be flagged. The Humaniser catches *unintentional*
machine patterns, not stylistic choices.

**How to start:** "Scan for AI patterns", "Run the humaniser", "Check my prose for AI-isms"
→ Loads `prose-humaniser.md` + `forbidden-words.md` + genre file

### 6. Analyze a Book
Reverse-engineer any published novel (or your own completed manuscript) into a
structural blueprint — genre, tropes, beats, character arcs, pacing, and a
reusable plot template.

**What you get:**
- Chapter-by-chapter structural analysis
- Full-manuscript literary analysis (genre, tropes, character arcs, theme, plot devices)
- Genericized plot template — reusable blueprint stripped of names and specifics
- Beat mapping against standard structures
- Pacing profile with tension tracking

**Use this to:** Study published books in your genre, understand your own manuscript's
architecture, extract templates from books you admire.

**How to start:** "Analyze this book", "Reverse-engineer [title]", "What's the structure of this?"
→ See `analyze-a-book.md` for details. Protocol: `story-analysis.md`

### 7. Market Scout
Live market intelligence for any genre — current bestseller trends, reader demand,
trending tropes, comp titles, price points, and strategic positioning.

**What you get:**
- Current bestseller analysis for your genre
- Trending tropes and reader demand signals
- Comp title identification with positioning strategy
- Price point guidance
- Gap analysis — underserved niches with reader demand

**How to start:** "Market Scout", "What's selling in [genre]?", "Genre trends"
→ See `market-scout.md` for details. Protocol: `market-scout-protocol.md`

### 8. Marketing & Cover Design
Generate cover concepts, blurbs, Amazon descriptions, social media packs, query
letters, and book trailer storyboards — from your finished manuscript.

**What you get:**
- Cover concepts with AI image generation prompts (genre-aware aesthetics)
- Back-cover blurb (3 lengths)
- Amazon book description (A+ content ready)
- Social media announcement pack
- Query letter for agent submissions
- Book trailer storyboard with scene-by-scene video prompts
- Audience analysis and keyword strategy

**How to start:** "Design a cover", "Write a blurb", "Marketing", "Query letter"
→ See `marketing-and-cover.md` for details.

### 9. Export & Publish
Format your manuscript for publishing platforms or agent submissions.

**What you get:**
- DOCX (publisher-ready)
- Atticus-compatible DOCX
- EPUB 3
- Print-ready PDF
- Standard Manuscript Format
- Markdown / RTF
- KDP metadata generation
- Query package preparation

**How to start:** "Export my manuscript", "Prepare for KDP", "Format as DOCX"
→ See `export-and-publish.md` for details.

### 10. Heritage Text
Modernize public domain texts — update archaic spelling, fix OCR artifacts, apply
Chicago Manual of Style formatting while preserving the original voice. For
writers working with source material, adaptations, or retellings.

**How to start:** "Clean up this classic text", "Modernize the spelling", "Fix OCR errors"
→ See `heritage-text.md` for details. Protocol: `heritage-text-refiner.md`

### 11. Pen Name Studio
Create and manage author pen names with genre-appropriate professional bios.
Pen names persist across projects.

**How to start:** "Pen name", "Create a pen name"
→ See `pen-name.md` for details. Protocol: `pen-name-generator.md`

### 12. Voice Builder
Build a reusable author voice profile — from scratch through guided conversation,
extracted from your existing writing, or both. Link voices to pen names.

**How to start:** "Build a voice", "Voice Builder", "Create a voice profile"
→ See `voice-builder.md` for details. Protocol: `voice-builder-protocol.md`

### 13. Character Name Generator
Historically accurate, culturally appropriate character names — researched by
era, region, culture, and social class.

**How to start:** "Name a character", "Character name"
→ See `character-name-generator.md` for details.

### 14. Company & Business Name Generator
Era-accurate, region-specific fictional company, shop, pub, restaurant, and
organisation names — verified against real-world companies.

**How to start:** "Name a business", "I need a shop name"
→ See `company-name.md` for details. Protocol: `company-name-generator.md`

### 15. Help
Quick reference for all commands, features, and supported genres.
→ See `help.md` for details.

---

## Trigger Phrases

Activate Writers Studio when the user says ANY of:
- "Writers Studio" / "Writer's Studio" / "Studio mode"
- "I write my own books" / "I don't want AI to write for me"
- "Edit my manuscript" / "Run the editorial pipeline"
- "Plan a book" / "Build a story bible" / "Story bible workshop"
- "Validate my outline" / "Check my outline" / "Review my plot structure"
- "Manuscript clinic" / "Analyse my manuscript"
- "Scan for AI patterns" / "Check my prose for AI-isms" / "Run the humaniser"
- "Market Scout" / "What's selling in [genre]?" / "Genre trends"
- "Design a cover" / "Write a blurb" / "Marketing" / "Query letter"
- "Export my manuscript" / "Prepare for KDP"
- "Analyze this book" / "Reverse-engineer [title]"
- "Heritage text" / "Clean up this classic text" / "Modernize the spelling"
- "Pen name" / "Create a pen name"
- "Build a voice" / "Voice Builder" / "Create a voice profile"
- "Name a character" / "Character name"
- "Name a business" / "Company name"
- "Help" / "What can you do?"

---

## How It Works

```
Pre-Writing:    Story Bible Workshop → [You write the book] → Return for Editorial
Cold Import:    Upload manuscript → Auto-detect genre → Voice Profile → Editorial
Story Bible     Upload manuscript → Reconnect to Story Bible → Validate → Editorial
  Return:
Diagnostic:     Upload manuscript → Manuscript Clinic → Optional Editorial handoff
```

### What Writers Studio Does NOT Do

Writers Studio does **not** generate prose for your manuscript. Specifically:

- No chapter generation (Architect + Writer agents are not available)
- No prose drafting, rewriting, or expansion of your manuscript text
- No "write this scene for me" or "draft this chapter"

If you want AI-assisted prose generation, use `Ideorix` (the full engine)
instead. Say "Write a book" to switch to the full pipeline.

### What Writers Studio DOES Do

Everything else:

| Category | Capabilities |
|----------|-------------|
| **Plan** | Story Bible, outlines, beat structures, trope planning, genre extensions, Chekhov's guns, transportive settings |
| **Track** | Character bibles, relationships, timelines, locations, world rules, objects, continuity, canonical facts |
| **Edit** | 6 editorial agents, 10 line-editing analyses, AI-ism detection, craft scoring (7 Commandments) |
| **Analyse** | Manuscript clinic (6-axis scoring), book analysis (reverse-engineering), market intelligence |
| **Name** | Pen names, character names, company/business names |
| **Market** | Cover concepts, blurbs, Amazon descriptions, social media, query letters, book trailers, audience analysis |
| **Export** | DOCX, EPUB, PDF, Markdown, RTF, Standard Manuscript Format, KDP metadata |

---

## Skill Loading Protocol

Writers Studio loads the same reference files as the full engine, on demand:

**Always active:**
- `craft-standards.md` — Universal prose rules
- `authenticity-guard.md` — AI pattern avoidance
- `forbidden-words.md` — Banned AI phrases
- Selected genre file (when genre is identified)

**Loaded per action:** Each menu item loads only its required skill files.

## Instruction Hierarchy

When instructions conflict, this order applies (highest priority first):
1. User's explicit instructions in the current conversation
2. Genre-specific rules from the selected genre file
3. This skill file (writers-studio.md)
4. Sub-skill reference files
5. General craft standards

## Output Location

All generated files are saved to the user's **local filesystem**.
Default: `~/Documents/Ideorix-Projects/[Book Title]/`

```
~/Documents/Ideorix-Projects/
└── [Book Title]/
    ├── manuscript/          # User's manuscript files
    ├── marketing/           # Cover & marketing assets
    └── engine-data/         # Story Bible, entity database, editorial reports
```

---

## Genre Bank

Writers Studio has access to the full 68-genre bank. Genre intelligence informs:
- Story Bible extensions (mystery clue schedules, romance arc maps, etc.)
- Beat structure recommendations
- Editorial standards and craft rules
- AI crutch phrase detection (genre-specific patterns)
- Market Scout analysis and comp title research

See `_index.md` for the full genre list and inheritance map.

---

*Ideorix Writers Studio — Copyright © 2025 James Harvey Media. All rights reserved. See LICENSE.txt.*
