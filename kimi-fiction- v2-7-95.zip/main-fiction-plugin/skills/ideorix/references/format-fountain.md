---
name: format-fountain
description: "Fountain screenplay format generation template"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Fountain Format Generation Template

## Overview

Generate screenplays in Fountain (.fountain) — the industry-standard plain-text
markup for screenplays. Fountain files are human-readable in raw form and import
directly into Final Draft, Highland, Fade In, WriterSolo, Arc Studio Pro, and
virtually all modern screenplay software.

**Why Fountain:** It's plain text (no binary format issues), universally
compatible, and the open standard for screenplay interchange. Any text editor
can create and edit Fountain files. It's the ideal format for AI-generated
screenplays because it's fully specified and universally importable.

## Fountain Syntax Reference

### Title Page

Title page metadata goes at the very top of the file as key-value pairs:

```fountain
Title: THE TITLE OF THE SCREENPLAY
Credit: Written by
Author: Author Name
Source: Based on the novel by Original Author
Draft date: 03/31/2026
Contact:
    Author Name
    email@email.com
    (555) 123-4567
```

- Multi-line values (like Contact) are indented with tab or 3+ spaces
- A blank line separates the title page from the screenplay body

### Scene Headings (Slug Lines)

```fountain
INT. COFFEE SHOP - DAY
EXT. MOUNTAIN TRAIL - NIGHT
INT./EXT. CAR (MOVING) - CONTINUOUS
INT. SARAH'S APARTMENT - KITCHEN - NIGHT
```

- Must begin with `INT.`, `EXT.`, `INT./EXT.`, or `I/E.`
- Format: PREFIX + LOCATION + dash + TIME OF DAY
- **Time of day is `DAY` or `NIGHT`** in the overwhelming majority of
  professional spec scripts. Permitted alternatives:
  - **Continuity markers:** `CONTINUOUS`, `MOMENTS LATER`, `LATER`,
    `SAME` / `SAME TIME`. Use these for time-relationship between
    consecutive scenes, not as standalone times.
  - **Sparing exceptions:** `DAWN`, `DUSK` — only when the specific
    quality of dawn or dusk is dramatically essential. Otherwise prefer
    `DAY` or `NIGHT` and convey the time-of-day quality through action
    lines.
- **Do NOT use in sluglines** (these read as amateur to industry readers):
  - `MORNING`, `AFTERNOON`, `EVENING`, `LATE NIGHT`, `EARLY MORNING` —
    the quality of morning light belongs in action, not the slugline.
  - Camera directions: `WIDE SHOT`, `CLOSE ON`, `AERIAL`, `POV`,
    `ANGLE ON`, `TRACKING SHOT`, `INSERT`. Camera direction is a separate
    direction line, never embedded in a slugline.
  - Era / period parentheticals: `(PRESENT DAY)`, `(1962)`,
    `(20 YEARS AGO)`, `(FLASHBACK)`. Era jumps use a SUPER (overlay text),
    a transition line (`> FLASHBACK TO:`), or are established in action.
  - Weather / mood / descriptive parentheticals: `(RAINING)`, `(QUIET)`,
    `(EMPTY)`. Action lines.
- **Location-hierarchy rule (no re-establishing).** Once a master
  location is established (e.g., `EXT. SMALL TOWN MAIN STREET - DAY`),
  subsequent scenes that stay within that master location slug to the
  **specific** sub-location only. The next interior scene inside the
  diner on that street is `INT. DINER - DAY`, NOT
  `INT. SMALL TOWN - DINER - DAY`. Repeating the master location is a
  classic AI-tell.
- Force any line as a scene heading with a leading period: `.FLASHBACK`
- Moving vehicles: `INT. SARAH'S CAR (MOVING) - DAY`
- Keep location names consistent throughout the script

### Action (Description)

```fountain
Sarah crosses the room, picks up the letter. Her hands tremble.

She reads it once. Reads it again. Sets it down carefully, as if
it might detonate.
```

- Plain paragraphs with no prefix
- Always present tense
- Separated by blank lines
- Maximum 4 lines per paragraph
- Character names in ALL CAPS on first appearance:
  `SARAH CHEN (30s), sharp-eyed with a surgeon's calm, strides in.`
- **Sound cues — school of thought matters**:
  - **Modern spec default (recommended):** sounds appear in lower
    case in action lines, like any other observable element. Trust
    the production's sound department.
    `A gunshot echoes across the valley.`
  - **Shooting-script / older spec convention:** SOUNDS in CAPS to
    flag audio cues for the sound department.
    `A GUNSHOT echoes across the valley.`
  - **When to break the modern default and CAP a sound:** when the
    sound itself is a story beat the audience must register — a
    gunshot nobody on screen reacts to, a slammed door mid-sentence,
    a phone buzzing as the cue for the closing image. Reserve CAPS
    for sound that *acts* in the scene.
  - The Ideorix engine generates in modern-spec default. Users who
    want shooting-script convention (every sound CAPPED) flip the
    setting at Tone and Style (S5) or via project-config.

### Character Cues and Dialogue

```fountain
SARAH
I never asked for this.

JACK
Nobody does.
```

- Character name uppercase, on its own line, preceded by a blank line
- Dialogue immediately follows, no blank line between
- Force non-standard names with `@` prefix: `@McCALLISTER`

### Parentheticals

```fountain
SARAH
(whispering)
I never asked for this.

JACK
(to the bartender)
Another round.
```

- Wrapped in parentheses between character name and dialogue
- Use sparingly — only when the line would be misread without guidance
- Never for directing the actor's emotion

### Dual Dialogue (Simultaneous)

```fountain
SARAH
I can't believe you said that.

JACK ^
Well, I did.
```

- The caret `^` after the second character name signals side-by-side dialogue

### Extensions

```fountain
SARAH (V.O.)
I didn't know it then, but that was the last time.

JACK (O.S.)
I'm in the kitchen!

SARAH (CONT'D)
And another thing--
```

- `(V.O.)` — Voice Over: character narrating, not present in scene
- `(O.S.)` — Off Screen: character present but not visible
- `(CONT'D)` — dialogue continues after action interruption (most software auto-generates this)

### Transitions

```fountain
> FADE TO:

> SMASH CUT TO:
```

- Preceded by `>` and ending with `:`
- Use sparingly — scene headings imply cuts
- `FADE IN:` is always the first line of the screenplay body
- `FADE OUT.` (with period) is the last line

### Special slugline variants

These are real industry tools for specific dramatic situations.
Use sparingly and with intent (see `screenplay-agent.md` Sluglines
special variants table for the rules of restraint).

#### INTERCUT — for parallel/simultaneous scenes (e.g., a phone call)

The standard phone-call pattern: establish each location with its own
slugline, then declare the INTERCUT, then alternate dialogue between
the two locations with secondary headings or character cues. The
master `INTERCUT - PHONE CONVERSATION` heading is acceptable; the
scenes-named variant is more common in modern spec.

```fountain
INT. SARAH'S KITCHEN - DAY

Sarah picks up the phone, presses it to her ear.

SARAH
You said you'd call yesterday.

INT. JACK'S CAR - DAY (CONTINUOUS)

Jack grips the steering wheel, phone wedged against his shoulder.

JACK
I know. Something came up.

INTERCUT - SARAH'S KITCHEN / JACK'S CAR

SARAH
Define "something."

JACK
Don't.

SARAH
You're driving. I can hear the road.
```

**Phone-call alternative pattern (Trottier's preferred form):** declare
the intercut up front with the master heading, then write each
character's dialogue under their location's secondary heading.

```fountain
INTERCUT - PHONE CONVERSATION

INT. SARAH'S KITCHEN - DAY
Sarah leans against the counter.

SARAH
You said you'd call yesterday.

INT. JACK'S CAR - DAY
Jack grips the wheel.

JACK
I know. Something came up.

INT. SARAH'S KITCHEN
Sarah closes her eyes.

SARAH
Define "something."
```

Both forms are accepted by industry readers. After the `INTERCUT`
line (in either form), dialogue alternates between the two locations
without re-slugging each cut. End the intercut with a normal scene
heading for the next discrete scene, or with `END INTERCUT`.

#### Secondary scene headings — direct attention without camera direction

Within a master location, use **secondary scene headings** to shift
the camera's implicit framing. This is the spec-script substitute for
camera directions like `CLOSE ON RICK` or `ANGLE ON THE BAR`.

```fountain
INT. RICK'S CAFE - NIGHT

The room hums. Cigarette smoke under the lamps.

AT THE BAR

RICK pours a drink. Eyes on the door.

GAMING ROOM

A couple dice at the corner table. The croupier never blinks.

RICK

He sets the bottle down. Watches her cross the room.
```

**Rules:**
- A secondary heading is on its own line, in CAPS, no period.
- It can name a sub-location (`AT THE BAR`, `THE KITCHEN`, `IN THE
  HALLWAY`) or a character name (`RICK`, `SARAH`) — naming a
  character implicitly puts the camera on them until the next
  heading.
- Use within an established master scene, not to introduce a new
  master location (use a full slugline for that).

#### On-screen text — emails, texts, signs, computer screens

When the audience must read text on screen, use either INSERT (for
close-up, dominant-frame text) or SUPER (for brief overlay text), and
**always wrap the text in quotation marks**.

**Email or letter (INSERT):**

```fountain
INT. SARAH'S APARTMENT - NIGHT

Sarah sits cross-legged on the bed, laptop open.

INSERT - EMAIL FROM JACK

Subject line: "WE NEED TO TALK"

Body: "Sarah — I tried to call. Three times.
I'm in town until Sunday. The same hotel.
— J"

BACK TO SCENE

She closes the laptop. Doesn't move.
```

**Text-message exchange (INSERT):**

```fountain
INSERT - SARAH'S PHONE

A text from JACK: "I made a mistake."

She types. Deletes. Types again.

Her reply: "Which one?"

BACK TO SCENE
```

**Newspaper / sign / inline screen (action-line description):**

```fountain
She glances at the headline: "MAYOR INDICTED."
```

```fountain
The neon sign above the door reads: "BACK IN 5."
```

**Date / location label / overlay (SUPER):**

```fountain
SUPER: "TWO YEARS LATER"
```

```fountain
SUPER: "BERLIN — 1989"
```

The quotation marks are mandatory for any text the audience reads on
screen. Without them, the format reads as the writer's narration, not
as on-screen words. This is one of the small format details industry
readers spot immediately.

#### INSERT — for a tight close-up on an object/text/screen

```fountain
INT. KITCHEN - DAY

Sarah opens the envelope. Slides out a photograph.

INSERT - PHOTOGRAPH

A young woman at the beach. Smiling. The date stamp reads 8/14/97.

BACK TO SCENE

Sarah stares. Sets it down. Stares again.
```

Use INSERT only when the audience genuinely needs to see the specific
image in close-up. Atmospheric objects belong in action lines, not
INSERTs. Always pair an INSERT with `BACK TO SCENE` on the next line
unless the next slugline starts a fresh scene.

#### SUPER — overlay text on the image (date, location, attribution)

```fountain
EXT. CITY STREET - DAY

SUPER: "BERLIN — 1989"

Crowds gather. Television cameras. The Wall stands behind them.
```

Use SUPER for period jumps, location labels, and factual attributions
instead of slugline parentheticals like `(1989)`. SUPERs render as
on-screen overlay text. Use sparingly — three SUPERs across a full
screenplay is the upper bound; more reads as the writer leaning on
the device instead of dramatising the transitions.

#### MONTAGE — sequence of compressed visual beats

```fountain
MONTAGE - SARAH BUILDS THE CASE

-- She pins photographs to a corkboard.

-- She reads case files at 3 AM. Empty coffee cups.

-- She interviews a witness in a parking lot. Rain.

-- She runs five miles before dawn. The same route every day.

END MONTAGE
```

A montage typically runs ½ to 2 pages and compresses time-passage or
pattern-establishing beats. Each line begins with `--` (or `*`) to
mark a montage beat. End with `END MONTAGE` on its own line.

#### FLASHBACK — wrap a flashback sequence

```fountain
> FLASHBACK TO:

INT. HOSPITAL ROOM - DAY

Sarah, ten years younger, holds her dying father's hand.

> END FLASHBACK
```

For multi-scene flashbacks, wrap with `> FLASHBACK TO:` and `> END FLASHBACK`
(or `> BACK TO PRESENT`). For a single-scene flashback, you may use
`INT. HOSPITAL ROOM (FLASHBACK) - DAY` instead. Maximum two flashback
sequences in a feature; more suggests the structure should be reordered.

### Emphasis

```fountain
*italics*
**bold**
***bold italics***
_underline_
```

### Centered Text

```fountain
> THE END <
```

### Page Breaks

```fountain
===
```

Three or more equals signs force a page break.

### Sections and Synopses (Outlining — Not Printed)

```fountain
# Act One
## Sequence A — The Setup
= Sarah discovers the letter and her world unravels.
```

- `#` headers for act/sequence organization (not rendered in output)
- `=` for synopsis lines (not rendered, used for outlining/notes)

### Notes (Not Printed)

```fountain
[[This scene may need restructuring in revision.]]
```

### Boneyard (Commented Out — Not Printed)

```fountain
/*
This entire scene was cut in the second draft.
*/
```

### Lyrics

```fountain
~Somewhere over the rainbow
~Way up high
```

## Complete Example

```fountain
Title: FOOD VS YOU
Credit: Screenplay by
Author: Daniel Ford
Draft date: 03/31/2026
Contact:
    James Harvey Media
    info@jamesharvey.media

FADE IN:

SUPER: "1962"

EXT. SUBURBAN STREET - DAY

Early light. A milk float trundles past terraced houses.
Everything is still. A BLACKBIRD sings from a television aerial.

INT. GRANDMOTHER'S KITCHEN - CONTINUOUS

Eleven things on the shelves. Flour. Sugar. Butter. Eggs. Milk.
Tea. Salt. Pepper. Cooking oil. Oats. A tin of condensed milk.

MARGARET CHEN (60s), hands like leather, rolls pastry on a
floured board without looking down.

> MATCH CUT TO:

SUPER: "PRESENT DAY"

INT. MODERN KITCHEN - NIGHT

SARAH CHEN (35), Margaret's granddaughter, opens a cupboard.
The shelves groan with packets, bars, jars. She picks up a
protein bar. Turns it over. Reads the label.

Seventeen ingredients. She can't pronounce three of them.

SARAH (V.O.)
My grandmother's kitchen had eleven
things in it. I don't mean eleven
appliances. I mean eleven ingredients.

She sets the bar down. Opens the fridge. More packets. More
labels. More ingredients she doesn't recognise.

SARAH (V.O.)
Something changed between her kitchen
and mine. This is the story of what.

FADE OUT.
```

## Industry Page Layout (for PDF Generation)

When converting Fountain to PDF, apply these exact measurements:

| Element | Left Margin | Right Margin | Width |
|---------|-------------|--------------|-------|
| Action | 1.5" | 1.0" | 6.0" |
| Character Name | 3.7" from left | — | — |
| Dialogue | 2.5" | 2.5" | 3.5" |
| Parenthetical | 3.1" | 2.9" | 2.5" |
| Transition | right-aligned | 1.0" | — |
| Scene Heading | 1.5" | 1.0" | 6.0" |
| Page Number | top right | 0.5" from top | — |

- **Font:** Courier 12pt (or Courier Prime)
- **Top margin:** 1.0"
- **Bottom margin:** 0.5" to 1.0"
- **Paper:** US Letter (8.5" x 11")
- **Line spacing:** single-spaced within elements; one blank line between
- **Page numbers:** top right corner, followed by period (e.g., `23.`)
- **First page:** no page number

## Platform Compatibility

| Platform | Import | Export | Notes |
|----------|--------|--------|-------|
| Final Draft | .fountain, .fdx | .fdx, PDF | Industry standard ($250) |
| Highland | .fountain native | .fountain, .fdx, PDF, .docx | John August's tool (Mac, $50) |
| Fade In | .fountain, .fdx | .fountain, .fdx, PDF | Cross-platform ($80) |
| WriterSolo | .fountain, .fdx | .fountain, .fdx, PDF | Free, web-based |
| Arc Studio Pro | .fountain, .fdx | .fountain, .fdx, PDF | Cloud-based, free tier |
| Celtx | .fdx, PDF | .fdx, PDF | Indie/student use |

## File Delivery

Save as: `{Title}.fountain`
Also generate: `{Title}-screenplay.pdf` and `{Title}-screenplay.docx`

The `.fountain` file is the primary deliverable — it imports cleanly into
any professional screenplay software. The PDF and DOCX are convenience
formats for reading and sharing.
