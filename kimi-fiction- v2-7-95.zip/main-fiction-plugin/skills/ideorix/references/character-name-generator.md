---
name: character-name-generator
description: "Culturally and historically accurate character name generator"
user-invocable: false
---
<!-- (c) 2025 James Harvey Media / Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->

# Character Name Generator

## Overview

Generates character names that are historically accurate, culturally appropriate, and
geographically authentic based on the character's date of birth, region, and cultural
background. Integrated into Story Bible generation (Phase 2A) and available on demand
during chapter writing.

## When It Runs

- **Automatically:** During Phase 2A (Story Bible Foundation) when characters are created
- **On demand:** When the user says "name a character", "generate character names", or
  when a new character is introduced mid-manuscript

## Name Generation Protocol

### Step 1: Gather Character Context

For each character requiring a name, collect or derive these parameters:

```
CHARACTER NAME BRIEF:
  Birth Year:      {year or approximate era — e.g., 1987, "early 1920s", "medieval"}
  Gender:          {male / female / non-binary}
  Region:          {geographic region — e.g., "West Africa", "rural Mississippi",
                    "Victorian London", "Seoul", "Nordic"}
  Culture:         {specific cultural background — e.g., "Yoruba", "Irish-American",
                    "Ashkenazi Jewish", "Han Chinese", "Māori"}
  Social Class:    {working class / middle class / upper class / nobility / clergy —
                    affects naming conventions in many cultures}
  Role:            {protagonist / antagonist / love interest / mentor / minor character}
  Story Genre:     {from project setup — affects name "feel"}
  Existing Cast:   {names already assigned to other characters — for differentiation}
```

**If the story is set in a secondary/fantasy world:** Switch to the Constructed Names
protocol (see below) instead of historical lookup.

### Step 2: Historical and Cultural Name Research

Apply these research layers in order:

**Layer 1 — Era-Appropriate Given Names**

Names go in and out of fashion. A character born in 1952 should not have a name that
peaked in 2015. Use these guidelines:

| Era | Naming Trends | Examples (English-speaking, as baseline) |
|-----|---------------|----------------------------------------|
| Pre-1900 | Biblical, classical, family names passed down | Margaret, William, Edith, Henry, Florence |
| 1900-1930 | Traditional with early modern shifts | Dorothy, Harold, Ruth, Clarence, Mildred |
| 1930-1960 | Post-war classic names | Barbara, Robert, Patricia, James, Shirley |
| 1960-1980 | Boomer/Gen X — simpler, casual names | Karen, Michael, Lisa, David, Jennifer |
| 1980-2000 | Millennial — creative spellings, nature/virtue names | Jessica, Christopher, Ashley, Brandon, Brittany |
| 2000-2020 | Gen Z — surname-as-first-name, unisex, vintage revival | Mason, Harper, Olivia, Liam, Aria |
| Future | Extrapolate trends — shorter names, global blends, neo-classical | Kai, Nova, Zara, Ren, Sol |

**These are English-language baselines.** Every culture has its own naming trends
by era. The engine must research the SPECIFIC culture's naming conventions for the
character's birth year.

**Layer 2 — Regional Authenticity**

Names must match the geographic region and its naming traditions:

| Region | Naming Conventions |
|--------|-------------------|
| **East Asia** | Family name first (Zhang Wei, Kim Soo-jin, Tanaka Yuki). Generational names in some families. Characters may have both a given name and an English/Western name. |
| **South Asia** | Varies by religion and region. Hindu: meaning-based (Arjun, Priya). Muslim: Arabic-origin (Farhan, Aisha). Sikh: gender-neutral first names + Singh/Kaur. Patronymic vs surname systems vary. |
| **West Africa** | Day-names (Akan: Kofi = Friday-born male). Praise names. Family names. Islamic influence in some regions (Ibrahim, Fatima). |
| **East Africa** | Swahili names, tribal names, Arabic influence. Patronymic systems (Ethiopian: father's first name as surname). |
| **Middle East / North Africa** | Arabic naming: ism (given) + nasab (patronymic) + laqab (descriptor). Persian: different name stock. Turkish: surname law of 1934 changed conventions. |
| **Latin America** | Two surnames (father's + mother's). Catholic saint names common. Indigenous names in some regions. Diminutives as daily names (Alejandro → Alex). |
| **Eastern Europe** | Patronymics (Russian: Ivanovich/Ivanovna). Diminutives (Ekaterina → Katya). Name-day traditions. Czech/Polish diacritics. |
| **Western Europe** | Highly variable by country. French: strict legal name lists until 1993. German: compound names. Scandinavian: patronymic/matronymic surnames. |
| **Indigenous / First Nations** | Culturally sensitive — use only with research. Many nations have naming ceremonies. Some names are sacred and should not be used casually in fiction. When in doubt, use English/colonial-era names that Indigenous characters might use in daily life, with cultural names referenced respectfully. |
| **Caribbean** | Blend of African, European, and Indigenous traditions. Double-barrelled names. Nicknames as primary identifiers. |
| **Oceania** | Polynesian: significance-based names. Aboriginal Australian: culturally sensitive, research-specific. |

**Layer 3 — Social Class Markers**

Names signal social position in most cultures and eras:

```
SOCIAL CLASS NAMING PATTERNS:
  Upper class:    Longer, traditional names. Multiple given names. Family names
                  as first names. Formal naming (never shortened in public).
  Middle class:   Aspirational naming — slightly above their station. Follow
                  trends but 2-3 years behind the upper class.
  Working class:  Shorter, practical names. Nicknames as legal names. Regional
                  dialect forms (e.g., "Billy" not "William").
  Nobility:       Dynastic names. Numbered (e.g., "the Third"). Title + name
                  conventions specific to the culture.
  Clergy:         Often take new names upon ordination. Religious name stock.
```

### Step 3: Generate Candidates

Produce **5 name candidates** for each character, with:

```
1. [FULL NAME]
   Given name origin:  {language, meaning, era of popularity}
   Surname origin:     {etymology, regional/cultural origin}
   Era accuracy:       {why this name fits the birth year}
   Cultural accuracy:  {why this name fits the region/culture}
   Class fit:          {why this name fits the social position}
   Pronunciation:      {phonetic guide if non-obvious}
   Nickname options:   {2-3 natural shortenings or pet names}
   Cast check:         {confirms no collision with existing character names —
                        different first letter, different syllable count,
                        different sound profile}
```

### Step 4: Differentiation Check

Before presenting candidates, verify against the existing cast:

```
NAME DIFFERENTIATION RULES:
  1. No two characters share a first initial (unless cast > 10 characters)
  2. No two names with the same syllable count AND stress pattern
     (e.g., "Marcus" and "Darius" — both 2-syllable, stress on first)
  3. No surnames that rhyme or near-rhyme with existing surnames
  4. No names that could be confused when spoken aloud
  5. Protagonist and antagonist names should contrast phonetically
     (hard vs soft sounds, short vs long)
  6. Names should look distinct on the PAGE — different lengths,
     different letter shapes (avoid "Clara" and "Ciara" in the same book)
```

### Step 5: User Selection

Present candidates via AskUserQuestion:
- Select one of the 5
- Mix and match (first name from #1, surname from #3)
- Request 5 more candidates with adjusted parameters
- Provide their own name (engine validates it for era/cultural accuracy and flags
  any issues, but respects the user's choice)

## Constructed Names Protocol (Fantasy / Sci-Fi / Secondary Worlds)

When the story is set in a secondary world without real-world cultural mapping:

### Linguistic Consistency

1. **Establish a sound palette** for each culture/nation in the world:
   ```
   CULTURE: [Name]
   PHONETIC PALETTE:
     Consonants:  {dominant consonants — e.g., "k, th, r, n" for a harsh culture}
     Vowels:      {dominant vowels — e.g., "a, o, u" for deep/warm feel}
     Syllables:   {typical count — e.g., 2-3 for common folk, 4-5 for nobility}
     Endings:     {common endings — e.g., "-an", "-el", "-ra"}
     Banned:      {sounds that DON'T belong in this culture}
   ```

2. **Generate names within the palette** — all names from one culture should sound
   like they belong together

3. **Contrast between cultures** — different factions should have audibly different
   naming conventions (e.g., the forest people use liquid sounds: Liriel, Meranu;
   the desert warriors use hard stops: Kadesh, Torak, Brin)

4. **Readability test** — if the name cannot be pronounced on first read by an
   English-language reader, simplify it. Accessibility > authenticity in fantasy.

5. **The "coffee shop test"** — could a barista spell it after hearing it once?
   If not, the name is too complex for a POV character. Side characters can be
   more exotic.

## Integration with Story Bible (Phase 2A)

During Phase 2A character creation, the character name generator runs automatically:

1. The Story Architect defines each character's role, background, and approximate age
2. From the age and the story's timeline, derive the character's birth year
3. From the story's setting, derive the geographic region and culture
4. Run the name generation protocol for each named character
5. Present all character names together for user approval before proceeding
6. Save approved names to the Story Bible and entity database

**System prompt injection for Phase 2A:**
```
CHARACTER NAMING: For every character you create, DO NOT assign a name directly.
Instead, define the character's role, age, background, region, and cultural context.
The Character Name Generator will produce historically and culturally accurate name
candidates for the user to select. Assign placeholder labels (e.g., "PROTAGONIST",
"LOVE INTEREST", "MENTOR") until names are confirmed.
```

## On-Demand Usage (Mid-Manuscript)

When a new character appears during chapter generation:

1. The Architect flags the new character in the chapter brief
2. Before the Writer executes, run the name generator for the new character
3. User approves the name
4. Name is added to the entity database
5. Writer receives the confirmed name in its prompt

Trigger phrases:
- "Name a character"
- "Generate character names"
- "I need a name for..."
- "What would a [culture] [era] character be called?"

## Anti-Patterns

- Do NOT default to English/American names for non-English-speaking characters
- Do NOT use stereotypical "exotic" names (e.g., "Sakura" for every Japanese female character)
- Do NOT assign names without checking the existing cast for collisions
- Do NOT use names from the genre file's "Names to Avoid" section
- Do NOT use names from forbidden-words.md or authenticity-guard.md
- Do NOT invent "ethnic-sounding" names — research real naming conventions
- Do NOT assign all characters names from the same decade regardless of their birth years
- Do NOT give fantasy characters real-world cultural names unless the world explicitly
  draws from that culture
