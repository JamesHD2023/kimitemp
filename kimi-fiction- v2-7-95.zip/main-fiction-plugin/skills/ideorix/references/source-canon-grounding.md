---
name: source-canon-grounding
description: "Source Canon Grounding Protocol — evidence-bearing artifact that proves the orchestrator is grounded in current source-canon file content, not stale memory, before any dependent-on-canon generation (outline, chapter briefs, character development)."
version: "2.8.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Source Canon Grounding Protocol

## Purpose

Prevent the documented production failure mode where the orchestrator reads
source-canon files early in a session, retains vague surface knowledge, and
then generates outlines or chapters from that stale memory rather than from
the actual current file content. This produces "greatest hits albums of canon
moments with summary connecting them" instead of genuinely grounded fiction.

The protocol creates an **evidence-bearing grounding artifact** that the
deterministic gate can verify. The gate catches:
- Stale memory (sha256 mismatch = file changed since read)
- Fabricated grounding (verbatim samples that don't exist in the source file)
- Missing grounding (insufficient samples per file)
- Missing files (artifact claims files that don't exist on disk)

## When It Runs

**MANDATORY before any dependent-on-canon generation:**
- Outline Builder Step 9+ (after concept seeds, before chapter outline generation)
- Phase 2 Story Bible generation (when source-canon is present)
- Character development steps that reference uploaded profiles
- World-building steps that reference uploaded worldbuilding files
- Any step where the user has said "use my worldbuilding" or "adopt my canon"

**Opt-in control:** `source_canon_grounding: enabled` in `project-config.md`.
Default is `disabled` for in-flight projects; new projects default to `enabled`.

## The Grounding Artifact

**File:** `engine-data/reports/source-canon-grounding.yaml`

**Produced by:** The orchestrator, immediately before the dependent generation step.

**Structure:**

```yaml
# Source Canon Grounding Artifact
# Generated: {ISO8601 timestamp}
# For step: {step name — e.g., "Outline Builder Step 10"}
# Project: {project title}

project: {title}
step: {step name}
generated_at: {ISO8601}

files:
  - path: source-canon/worldbuilding/geography.md
    sha256: {sha256 of current file content}
    sample_count: 3
    samples:
      - "{exact verbatim substring from the file, 20–80 words}"
      - "{exact verbatim substring from the file, 20–80 words}"
      - "{exact verbatim substring from the file, 20–80 words}"
    key_facts:
      - "{claimed fact extracted from the file}"
      - "{claimed fact extracted from the file}"

  - path: source-canon/characters/finn-profile.md
    sha256: {sha256}
    sample_count: 3
    samples:
      - "{verbatim substring}"
      - "{verbatim substring}"
      - "{verbatim substring}"
    key_facts:
      - "{claimed fact}"

  - path: source-canon/voice-guide.md
    sha256: {sha256}
    sample_count: 3
    samples:
      - "{verbatim substring}"
      - "{verbatim substring}"
      - "{verbatim substring}"
    key_facts:
      - "{claimed fact}"

# Minimum requirements
min_samples_per_file: 3
min_files_with_samples: 1
required_total_samples: 3
```

**Sample selection rules:**
- Each sample MUST be an exact verbatim substring of the source file (not a summary, not a paraphrase)
- Samples must be distributed across the file (beginning, middle, end) — not clustered in one section
- Samples should include specific named elements: character names, place names, dates, rules, constraints
- Samples must be 20–80 words each (long enough to be unique, short enough to be unmistakably from the file)
- The orchestrator MUST re-read the file to extract samples; samples from memory are forbidden

## The Deterministic Gate

**Script:** `scripts/source-canon-grounding-gate.sh`

**Run by:** The orchestrator, immediately after producing the artifact.

**What it verifies:**

1. **Artifact exists.** `engine-data/reports/source-canon-grounding.yaml` is present and parseable.
2. **SHA256 matches.** For each declared file, compute the current sha256 and compare to the artifact. If any mismatch, FAIL — the file changed since the orchestrator claimed to read it, or the orchestrator is using stale memory.
3. **Verbatim samples are real.** For each declared sample, verify it is an actual substring of the current file content. If any sample is not found, FAIL — the orchestrator fabricated the sample (generated it from memory, not from the file).
4. **Minimum samples met.** Each file has ≥ `min_samples_per_file` samples. Total ≥ `required_total_samples`.
5. **Files exist.** Each declared `path` resolves to an existing file.

**Exit codes:**
- `0` = PASS — all verifications succeeded. Proceed to dependent generation.
- `1` = FAIL — one or more verifications failed. Block generation.
- `2` = NO ARTIFACT — artifact missing. Block generation.
- `3` = NOT ENABLED — `source_canon_grounding: disabled` in config. Skip (return 0 with warning).

**On FAIL, the orchestrator MUST:**
1. Re-read ALL source-canon files in full.
2. Produce a fresh grounding artifact.
3. Re-run the gate.
4. Only proceed when the gate passes.

The orchestrator CANNOT bypass this by claiming "I already read them" — the gate verifies via sha256 and substring matching, not self-reported reading.

## Integration with Pipeline

### Phase 1, Question 9 (Outline Source)

After Step 0 (Source Material Absorption) completes and user confirms constraints,
but BEFORE any outline generation begins:

1. Orchestrator produces `source-canon-grounding.yaml`
2. Gate runs
3. If PASS → proceed to Step 1 (Preference Gathering) and onward
4. If FAIL → re-read files, regenerate artifact, re-run gate

### Phase 2 (Story Bible Generation)

When source-canon is present and Story Bible generation begins:

1. Orchestrator produces `source-canon-grounding.yaml`
2. Gate runs
3. If PASS → generate Story Bible
4. If FAIL → re-read files, regenerate artifact, re-run gate

### Chapter Brief Generation (Step 5a)

Before the Architect writes each chapter brief:

1. Orchestrator produces `source-canon-grounding.yaml` for the relevant canon files
2. Gate runs
3. If PASS → write brief
4. If FAIL → re-read files, regenerate artifact, re-run gate

## Why This Works

**The memory problem:** LLMs retain vague summaries of long documents. When asked
to generate from those documents later, they produce content that feels correct
but contradicts specific details, constraints, or voice rules.

**Why sha256 + samples catches it:**
- **sha256:** If the file changed since the orchestrator read it, the hash mismatches. The orchestrator must re-read.
- **Verbatim samples:** If the orchestrator is generating from memory, it cannot produce exact substrings that match the file. Memory is paraphrase; the file contains exact words. The gate demands exact words.
- **Minimum counts:** Ensures the orchestrator actually engaged with the file, not just read the first paragraph.
- **Distributed samples:** Catches the "read the beginning, ignore the rest" pattern.

**Why the orchestrator can't game it:**
- The samples must be from the CURRENT file version (verified by sha256)
- The samples must be EXACT substrings (verified by grep)
- The samples must be DISTRIBUTED (beginning, middle, end — enforced by the gate's check for sample spread)
- The gate is deterministic and runs in bash, not in the LLM. The LLM cannot influence its verdict.

## Project Config Integration

```yaml
# In project-config.md
source_canon_grounding: enabled   # or disabled
```

**Migration path for existing projects:**
- Existing projects default to `disabled` until user enables
- New projects default to `enabled`
- User can toggle at any time

## Anti-Patterns This Prevents

1. **"I read it" (but from memory):** The orchestrator claims to have read the user's worldbuilding files, but generates an outline where the magic system costs don't match, character voices are flattened, or world rules are violated.
2. **"Greatest hits album":** The outline contains scenes that reference canon moments but as disconnected tentpoles, not as an integrated plot.
3. **"Sample scene as plot":** The orchestrator reverse-engineers a plot from the user's voice-guide sample scenes, treating prose examples as structural templates.
4. **"Psychology projection":** The orchestrator adds "survivor's guilt", "misread self-image", or "unprocessed trauma" that the user never specified.
5. **"Threat summary":** The antagonist is "mentioned in notices" instead of shown as dangerous on-page.

## File Location

- **Spec:** `references/source-canon-grounding.md`
- **Gate script:** `scripts/source-canon-grounding-gate.sh`
- **Artifact output:** `engine-data/reports/source-canon-grounding.yaml`

## See Also

- `byo-canon.md` — Step 0 (Source Material Absorption)
- `outline-builder.md` — Outline Builder protocol
- `core-pipeline.md` — Phase 1 and Phase 2 workflow
- `read-verification.md` — Read tool verification (catches empty returns)
- `subagent-output-verification.md` — Evidence-bearing return contracts
