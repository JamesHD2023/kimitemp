# Ideorix — Setup Guide

Welcome to Ideorix, your AI-powered manuscript engine. This guide will get you writing in under 5 minutes.

## What You Need

1. **A Claude account** — Sign up at [claude.ai](https://claude.ai) (Pro or Max plan required)
2. **Your Ideorix access token** — Included in your purchase confirmation email
3. **Claude Code** — Available at [claude.ai/code](https://claude.ai/code) or as a CLI tool

## Setup (One Time Only)

### Option A: Claude Code on the Web (Recommended)

This is the easiest option. No software to install.

1. Open [Claude Code on the web](https://claude.ai/code)
2. When asked, paste this setup command:

```
Download and run the Ideorix setup. My token is: [PASTE YOUR TOKEN HERE]
```

3. Claude will set everything up automatically
4. When it's done, say: **"Write a book"**

### Option B: Claude Code CLI (Advanced)

If you prefer the terminal:

1. Install Claude Code: `npm install -g @anthropic-ai/claude-code`
2. Download the setup package (link in your purchase email)
3. Unzip it and run:

```bash
chmod +x setup.sh
./setup.sh
```

4. Follow the prompts — enter your token when asked
5. Open the workspace in Claude Code:

```bash
cd ~/ideorix-workspace
claude
```

6. Say: **"Write a book"**

## How It Works

Once set up, Ideorix **automatically updates** every time you start a new session. You'll see a message like:

```
[Ideorix] Engine is up to date.
[Ideorix] Ready — engine a3f2b1c (2026-03-14)
[Ideorix] Say 'Write a book' to begin.
```

If we've released improvements, you'll see:

```
[Ideorix] Update found — pulling latest engine...
[Ideorix] Engine updated.
```

No action needed — it's automatic.

## Writing Your First Book

Just say **"Write a book"** and Ideorix will walk you through:

1. **Genre** — Choose from 68 genres (mystery, fantasy, romance, sci-fi, literary, and more)
2. **Story details** — Tropes, romance level, beat structure, style guide
3. **Structure** — Book length, chapter count, series planning
4. **Atmosphere** — Pick a transportive setting (Fog-Wrapped Coastal Town, Neon-Lit Metropolis, and 11 more)
5. **Author identity** — Create or select a pen name, or use your real name
6. **Special features** — Chekhov's Guns, style matching, outline builder

Then it writes — chapter by chapter, with built-in quality checks. Character names are generated through a research-backed system that matches each character's birth year, region, and cultural background.

## Quick Commands

| Say this... | To do this... |
|---|---|
| "Write a book" | Start a new manuscript from scratch |
| "Continue writing" | Pick up where you left off |
| "Edit my manuscript" | Run the full editorial pipeline |
| "Export to docx" | Generate a publisher-ready document |
| "Design a cover" | Create cover concept art directions |
| "Analyse this novel" | Reverse-engineer an existing book's structure |
| "Create a pen name" | Open the Pen Name Studio |
| "Name a character" | Generate culturally accurate character names |
| "Market Scout" | Run live market intelligence for any genre |

## Your Files

```
ideorix-workspace/
├── manuscripts/          ← Your books live here
├── .claude/skills/       ← Engine skills (auto-managed)
├── genre-bank/           ← 68 genre plugins (auto-managed)
├── engine-sync.sh        ← Update script (auto-runs)
└── CLAUDE.md             ← Workspace instructions
```

**Important:** Don't edit files in `.claude/skills/` or `genre-bank/` — they'll be overwritten on the next update. Your manuscripts in `manuscripts/` are always safe.

## Troubleshooting

### "Config file not found"
Run `setup.sh` again. Your token may not have been saved correctly.

### "Could not check for updates"
Your internet connection may be down. Ideorix will use the last downloaded version — you can keep writing.

### "Token expired" or authentication errors
Your access token may have expired. Contact support for a replacement token.

### Engine won't update
Try deleting the cached engine and restarting:
```
rm -rf .ideorix-engine
```
The next session will re-download everything.

## Support

- Email: [your-support-email]
- Include your token name (not the token itself) when contacting support

## Cost

Ideorix uses your Claude subscription. There are no additional per-use fees beyond your Claude Pro/Max plan.
