---
name: screenplay-agent
description: "Screenplay generation and manuscript-to-screenplay adaptation agent"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Screenplay Agent

## File-Write Hygiene (MANDATORY)

Screenplay generation produces large `.fountain` / `.fdx`
files that often exceed 30 KB once a feature-length script is
complete. The chained-Edit truncation safeguard documented in
`core-pipeline.md` § Chained-Edit Truncation Safeguard applies
in full to every screenplay write:

- **Prefer Write over chained Edit for scene / act / full-script
  rewrites.** A bash-heredoc + mv Write per scene is safer than
  accumulating Edit patches on a growing screenplay file.
- **Cap individual Edit replacements at ~2 KB** for line-level
  dialogue or action revisions.
- **Run `scripts/word-count-check.sh` after every screenplay
  file this agent writes or edits.** Page-count drift after a
  scene revision is the signature of silent truncation.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) before declaring a generation phase complete.

**HARD GATE — BLOCKING.** Truncation in a screenplay file MUST
be repaired (clean Write of the full intended content,
post-write integrity verification) before the agent reports
generation success.

## File Location Discipline (MANDATORY — HARD GATE — runs FIRST, before any generation)

**Before any screenplay generation / adaptation / write-cycle
work begins, this agent MUST confirm or establish a canonical
project folder at `~/Documents/Ideorix-Projects/[Title]/`.**
The screenplay file (`.fountain` / `.fdx`), formatted PDF, beat
breakdown, character bible, scene cards, and every supporting
deliverable MUST be written into that folder structure (see
`core-pipeline.md` § File Location Discipline for the canonical
layout and the Bash-Direct Write + Verify protocol).

**If no project folder exists** (e.g., the user invoked the
agent directly with a manuscript paste, treatment text, or
spec request without prior project setup), run the project-
folder bootstrap BEFORE proceeding: ask for the project title,
confirm the save location, create the canonical folder
structure, and only then begin generation.

**HARD GATE — BLOCKING.** Outputs MUST NOT be written to the
agent's working directory, a sandbox path, or any temporary
location. The Fountain / FDX / PDF deliverables MUST resolve to
local files the user can open in their own file explorer the
moment generation completes.

## Alpha/Beta Reader Routing Rule

**MANDATORY:** If a user requests "Alpha Reader," "Beta Reader," or "editorial
pipeline" on a screenplay project, route to **Script Coverage** instead:
- Alpha Reader request → Script Coverage Pass 1 (Development Coverage)
- Beta Reader request → Script Coverage Pass 2 (Industry Coverage)

The prose Alpha/Beta Reader templates are designed for manuscripts and will
produce incorrect assessments on screenplay format. Script Coverage is the
screenplay equivalent — same depth, different craft criteria.

## Overview

Generates original screenplays or adapts existing manuscripts into professional
screenplay format. Outputs in Fountain (.fountain), PDF, and DOCX. Supports
short film, TV (half-hour, hour, limited series), and feature film (90/120 min).

Uses the Ideorix genre bank for tone, tropes, beat structures, and character
archetypes — the same foundation that drives prose generation, now applied to
visual storytelling.

## Modes

### Mode A: Original Screenplay
Generate an original screenplay from scratch using the genre bank and
interactive setup. The user provides a concept; the engine builds a beat
sheet, writes scene-by-scene, and outputs a spec-ready script.

### Mode B: Manuscript Adaptation
Convert an existing Ideorix manuscript (or any pasted/uploaded manuscript)
into screenplay format. The engine analyses the source, identifies the
spine, collapses characters, compresses timeline, and produces a script
at the target length.

---

## Interactive Setup (Both Modes)

### S1: Format Selection

```
What are you creating?

  A. Feature Film — 90 minutes (~90 pages)
  B. Feature Film — 120 minutes (~110-120 pages)
  C. TV Pilot — Half-hour (~25-35 pages)
  D. TV Pilot — Hour (~55-65 pages)
  E. TV Episode — Half-hour (requires series context)
  F. TV Episode — Hour (requires series context)
  G. Limited Series — 6-8 episodes (~55-65 pages each)
  H. Short Film — specify target minutes
```

### S2: Source

```
Where is the story coming from?

  A. Original concept — I'll describe my idea
  B. Adapt my Ideorix manuscript — convert an existing project
  C. Adapt external manuscript — I'll paste or upload the text
  D. Adapt from outline only — I have a treatment or synopsis
```

If B: Load the Story Bible, entity database, and chapter summaries from the
existing project. These become the adaptation source material.

### S3: Genre Selection

Load the genre file from the Ideorix genre bank. The genre configures:
- Tone and atmosphere rules
- Trope library (which tropes translate to screen)
- Beat structure recommendations
- Character archetype guidance

### S4: Structure Selection

Present screenplay-appropriate beat structures based on format and genre:

**For Feature Film:**
- Save the Cat (15 beats — the Hollywood standard)
- Three-Act Structure (traditional)
- The Sequence Method (8 sequences of ~15 pages)
- Hero's Journey (mythic structure)

**For TV Half-Hour:**
- Cold Open + 2 Acts + Tag (network comedy)
- Cold Open + 3 Acts (streaming comedy/dramedy)
- Continuous narrative (streaming, no act breaks)

**For TV Hour:**
- Teaser + 5 Acts + Tag (network drama)
- Teaser + 4 Acts (cable drama)
- Continuous narrative (streaming/prestige)
- Dan Harmon's Story Circle (episodic)

**For Limited Series:**
- Feature structure spread across episodes
- Each episode gets its own internal arc + series arc contribution

### S5: Tone and Style

```
How should this screenplay feel?

  A. Lean and muscular — Cormac McCarthy, Taylor Sheridan
  B. Dialogue-driven — Aaron Sorkin, Greta Gerwig
  C. Atmospheric and visual — Denis Villeneuve, Terrence Malick
  D. Sharp and comedic — Emerald Fennell, Taika Waititi
  E. Tense and precise — David Fincher, Christopher Nolan
  F. Raw and naturalistic — Barry Jenkins, Andrea Arnold
  G. Describe your own style
```

#### Mechanical configuration per preset (MANDATORY — apply during writing)

The preset is not atmospheric; it is a measurable configuration the
Writer applies on every scene. Each preset has a hard target the
Quality Gate verifies.

| Preset | Action paragraph length (avg) | Dialogue-to-action ratio | White space target | Description style | Sentence length signature |
|---|---|---|---|---|---|
| **A. Lean / Muscular** (McCarthy / Sheridan) | 1–2 lines | 30–40% | ≥ 55% | Stripped — concrete nouns, strong verbs, almost no modifiers; landscape and weather carry mood | Short. Often fragmented. Periods as the dominant punctuation. |
| **B. Dialogue-driven** (Sorkin / Gerwig) | 1–2 lines | 60–75% | ~45% | Minimal — set the room, get out of the way; the talk does the work | Mid-length, rhythmic in dialogue; action lines deliberately understated |
| **C. Atmospheric / Visual** (Villeneuve / Malick) | 2–4 lines | 20–35% | ~45% | Rich sensory specificity — light, air, texture, scale; the image is the storytelling | Variable; longer sentences for tableau, short for impact |
| **D. Sharp / Comedic** (Fennell / Waititi) | 1–3 lines | 50–65% | ~50% | Punchy with comic specificity — odd details, contrast, rhythm; setups and pays | Short setups, quick payoffs; comic timing through line breaks |
| **E. Tense / Precise** (Fincher / Nolan) | 1–3 lines | 40–55% | ~50% | Cold and exact — clinical vocabulary, no atmosphere words, mechanical detail | Declarative. Precise verbs. No ornament. |
| **F. Raw / Naturalistic** (Jenkins / Arnold) | 2–3 lines | 35–50% | ~50% | Sensory and immediate — the body in space, breath, touch, the immediate physical world | Variable; close to lived rhythm; fragments allowed for present-tense intimacy |
| **G. User-defined** | User specifies | User specifies | User specifies | User specifies | User specifies |

The Writer MUST hit the action-paragraph and dialogue-ratio targets
within ±10% across the whole script. Quality Gate Format Compliance
includes a per-preset check (see Quality Gate below).

**If the user picks G**, ask four questions:
1. What's your average action paragraph length?
2. What dialogue-to-action ratio are you targeting?
3. What white-space density do you want (tighter / standard / generous)?
4. Three reference scripts that capture the feel.

Save the user's answers as the preset configuration for this project.

---

## Character Architecture (MANDATORY before writing — both modes)

Trottier's *Screenwriter's Bible* insists every central character has
**two parallel drivers**, not one. Tracking only the goal produces
characters who *function* in the plot but don't feel earned. The
engine captures both drivers for every protagonist and every major
antagonist before scene generation begins.

### The four-element character architecture

| Element | What it is | What it drives |
|---|---|---|
| **Want** | The conscious external goal — what the character is chasing on the surface | The **outside story** — plot, scenes, action |
| **Need** | The unconscious internal lesson — what would actually make them whole | The **inside story** — character arc, theme, emotional payoff |
| **Flaw** | The trait blocking the Need — what they have to overcome | The arc's *resistance* — every scene tests it |
| **Backstory** | The defining past wound that explains the Flaw | The character's *origin* — answers "why are they like this?" |

### Worked examples (Trottier's)

| Character | Want | Need | Flaw | Backstory |
|---|---|---|---|---|
| Rick (*Casablanca*) | Stay neutral, stay out of trouble | To love and trust again | Cynicism, emotional shutdown | Ilsa walked out on him in Paris |
| Clarice (*Silence of the Lambs*) | Catch Buffalo Bill | To silence the screaming lambs of her childhood | Self-doubt, vulnerability under pressure | Witnessed slaughter as a child; powerless |
| Andy (*Shawshank*) | Escape | Hope; to be free internally even when caged externally | Resignation; the belief that the system has won | Wrongful conviction; lost everything in one night |

### When to capture each driver

**Mode A (Original screenplay):** during Interactive Setup, after S5
(Tone and Style), prompt the user for each protagonist:

```
Tell me about your protagonist:

  Name and brief description: ___
  Want (what they're chasing): ___
  Need (what they actually have to learn): ___
  Flaw (what's blocking the Need): ___
  Backstory (the wound that created the Flaw): ___
```

If the user provides only the Want, ask for the others one at a time.
Do not proceed to writing until all four are captured. If the user
genuinely doesn't know the Need yet, offer to derive it from the
Want+Flaw pair: *"If your character's Want is X and their Flaw is Y,
their Need is usually the opposite of the Flaw — Z. Does that fit?"*

**Mode B/C (Adapting from manuscript):** the Architect
(`blueprint-agent.md` / `screenplay-expansion.md`) extracts the
four-element architecture from the source manuscript or Story Bible
and presents it for user confirmation before scene generation.

### Antagonists and major secondary characters

The full architecture (all four elements) is mandatory for the
**protagonist** and the **primary antagonist** (the human or
human-equivalent opposition). Secondary characters with their own
arcs (love interest, sidekick, mentor) get at minimum a Want and a
Flaw — Need and Backstory are optional but recommended.

### How the architecture drives the script

- **Want** → drives *what* the character does scene-by-scene.
- **Flaw** → drives the *resistance* the protagonist meets in their
  pursuit of the Want. Every major scene puts pressure on the Flaw.
- **Need** → drives the *Realization* (one of the seven plot points
  in Beat Anchoring below). The protagonist's arc is the journey from
  pursuing the Want to accepting the Need.
- **Backstory** → seeded into the script through visual references,
  off-hand dialogue, or one explicit reveal — never a flashback dump.

### Scenes that test the Flaw (MANDATORY — at least 3 across the script)

The protagonist's Flaw is named in the Character Architecture and
**must be tested** at three structural points in the script:

1. **Early Act 2** (after the Big Event) — the Flaw causes a setback
2. **Around the Crisis (~85% in)** — the Flaw produces the lowest
   point; the protagonist's failure is *because of the Flaw*
3. **At the Showdown / Realization** — the protagonist either
   confronts the Flaw and acts in alignment with the Need (positive
   arc), or fails to confront it (tragic arc — flag explicitly)

The Quality Gate verifies these three scenes exist.

---

## Adaptation Protocol (Mode B/C)

When adapting from an existing manuscript:

### Step 1: Spine Identification

Read the full manuscript (or Story Bible + chapter summaries) and identify:
- **The core story** — protagonist's central want, need, and transformation
- **The essential conflict** — what drives every scene
- **The emotional arc** — the journey the audience must feel

Everything that doesn't serve the spine is expendable.

### Step 2: Character Consolidation

- Map all characters from the source
- Identify which are essential to the spine
- **Collapse characters** who serve similar functions (a novel's 6 friends become 2-3)
- Flag which characters the user considers non-negotiable
- Present the proposed character map for approval

### Step 3: Subplot Triage

- List all subplots from the source
- Rank by relevance to the spine and theme
- **Keep:** The B-story that most illuminates the theme
- **Cut:** Everything else (flag for user approval)
- A 300-page novel typically retains 1-2 subplots in a 120-page screenplay

### Step 4: Timeline Compression

- Events spanning months/years in prose may compress to days/weeks on screen
- Identify time skips that can be collapsed
- Flag any timeline changes that affect character motivation

### Step 5: Visual Translation

Convert prose-specific elements to screen equivalents:
- **Internal monologue** → V.O. narration, or externalise through behaviour
- **Narrator voice** → Tone achieved through visual storytelling
- **Backstory exposition** → Dramatise into scenes, or seed through visual details
- **Sensory description** → Character behaviour (wrinkling nose = smell, etc.)
- **Abstract themes** → Embody in character action and conflict

### Step 6: Beat Sheet Generation

Map the adapted story onto the selected structure framework with page targets.
Present to user for approval before writing.

**Each beat in the sheet must include a target page count.** The sum of all
beat page targets must equal the overall target (e.g., 30 pages for a
30-minute short, 110 pages for a feature). This prevents the first draft
from landing severely under-length.

---

## Writing Protocol

### Page Budget (MANDATORY — enforced before writing begins)

**Before writing a single scene**, calculate the page budget:

| Format | Target Pages | Minimum First Draft |
|--------|-------------|-------------------|
| Short Film (custom) | ~1 page per minute of target | 80% of target pages |
| Half-Hour TV | 25-35 pages | 25 pages |
| Hour TV | 55-65 pages | 50 pages |
| Feature 90 min | 85-95 pages | 80 pages |
| Feature 120 min | 110-120 pages | 100 pages |

**Custom short film examples:** A 10-minute comedy sketch = 8-12 pages
(minimum first draft: 8). A 15-minute drama = 13-17 pages. A 45-minute
featurette = 40-50 pages. Calculate from the user's stated runtime using
the ~1 page per minute rule, then apply the 80% minimum for the first draft.

**The first draft MUST hit the minimum.** Do not write a lean first pass
and plan to expand later — expansion passes produce padding, not organic
storytelling. Write to the target from the start.

**How to hit the target:**
- Divide the total page target across the beat sheet beats
- Each scene should have a target page count BEFORE writing
- Track running page count as you write (Fountain: ~56 lines per page)
- If you finish the beat sheet and are under target, the scenes are too
  thin — add visual detail, breathing room, reaction beats, and texture
  WITHIN the existing scene structure, not by adding filler scenes
- Dialogue-heavy scripts may run longer per page in screen time — factor
  this in (a page of dialogue plays faster than a page of action)

**V.O. Budget:** Maximum 3-4 V.O. blocks per 30-page screenplay. V.O.
should add what the camera cannot show — not narrate what's already visible.
If adapting from prose, convert internal monologue to visual behaviour first;
use V.O. only where visual storytelling genuinely cannot carry the moment.

**Beat Anchoring — The Magnificent 7 Plot Points (MANDATORY page targets):**

Per Trottier's *Screenwriter's Bible*, every screenplay anchors seven
mandatory structural moments. Six of them appear on the page; one
(Backstory) is established before page 1 and revealed selectively
through the script. The engine enforces all seven, scaled to format.

### The 7 Plot Points

| # | Beat | What it is | What changes | Page target (110-page feature) |
|---|---|---|---|---|
| 1 | **Backstory** | The defining past wound that creates the protagonist's Flaw | Established before page 1; seeded into the script through visual references, dialogue, one explicit reveal | before p.1 (revealed by ~p.30) |
| 2 | **Catalyst** | A specific event that disrupts the status quo | The protagonist's normal life is interrupted | p.10 |
| 3 | **Big Event** | The act break — protagonist crosses into a new world or commits to a new path in response to the Catalyst | The story's central question is now unmistakable | p.20–30 |
| 4 | **Midpoint / Pinch** | The point of no return — motivations clarify, stakes raise, the protagonist either fully commits or has the rug pulled | The script's *direction* shifts; what they thought they wanted is reframed | p.50–55 |
| 5 | **Crisis** | The low point — the protagonist's Flaw produces a failure that forces a decision | The protagonist has to choose: stay in the Flaw, or change | p.85–90 |
| 6 | **Showdown** | The climactic confrontation — the protagonist acts on the Crisis decision | External plot resolves; the Want is achieved or definitively lost | p.95–105 |
| 7 | **Realization** | The protagonist consciously accepts the Need (or, in tragic structure, fails to) | Internal arc resolves; the audience sees the *change* | during/after Showdown |

### Format-scaled targets

The page-percentage anchors hold across formats; literal page numbers
scale. Express each target as a percentage of total pages:

| Beat | % of total pages | Notes |
|---|---|---|
| Catalyst | 8–10% | "by p.10 in a 110-page feature" |
| Big Event | 18–27% | Act 1 → Act 2 transition |
| Midpoint | 45–50% | The half-way turn |
| Crisis | 75–82% | Act 2 → Act 3 transition / "all is lost" |
| Showdown | 87–95% | The climactic confrontation |
| Realization | 90–100% | During or immediately after Showdown |

| Format | Catalyst | Big Event | Midpoint | Crisis | Showdown |
|---|---|---|---|---|---|
| Short film (30 pages) | p.3 | p.6–8 | p.15 | p.23 | p.27 |
| TV half-hour pilot | p.3–4 | p.5–8 | p.13–15 | p.22–25 | p.27–30 |
| TV hour pilot | p.5–6 | p.10–15 | p.27–32 | p.45–50 | p.55–60 |
| Feature 90 min | p.7–9 | p.18–22 | p.42–45 | p.68–73 | p.80–85 |
| Feature 120 min | p.10–12 | p.22–30 | p.50–55 | p.85–90 | p.95–105 |
| Limited series episode | p.5–7 | p.10–18 | p.27–32 | p.45–50 | p.55–60 |

### Definitions and traps

- **Catalyst** is the disruptor (the death, the call, the letter,
  the diagnosis, the stranger arriving). It happens *to* the
  protagonist — they don't choose it.
- **Big Event** is the protagonist's *response* to the Catalyst that
  crosses them into Act 2. They commit to a path. Often called the
  "Goal Lock" in commercial structure work — it is the moment the
  protagonist becomes *active*. *(This is the milestone we previously
  tracked as "Goal Lock"; it is preserved here under its Trottier
  name.)*
- **Midpoint must be a turn**, not just a beat. A scene can sit on
  page 50 and not be a Midpoint. The Midpoint is the moment something
  *shifts* — the protagonist learns the truth that reframes their
  goal, the antagonist gains the upper hand, a relationship breaks,
  the apparent victory is exposed as false. If page 50 is a flat
  beat, the structure is broken.
- **Crisis ≠ Showdown.** The Crisis is the *decision moment* —
  protagonist at their lowest, choosing whether to act in alignment
  with the Need (and confront the Flaw) or stay defeated. The
  Showdown is the *action* that flows from that decision. They are
  separated by 10–15% of pages. Conflating them produces a thin Act 3.
- **Realization is the inside-story payoff.** It is the moment the
  protagonist *consciously knows* what they have learned — what the
  Need was. It can be a line of dialogue, a look, a single action. It
  is the script's emotional truth landing. Without it, the climax
  feels physically resolved but emotionally hollow.

### How the 7 plot points interlock with Character Architecture

| Plot point | Character Architecture link |
|---|---|
| Backstory | Establishes the Flaw |
| Catalyst | Disrupts the life the Flaw built |
| Big Event | Protagonist commits to the Want (still gripped by the Flaw) |
| Midpoint | The Want is reframed; the Need begins to surface |
| Crisis | The Flaw produces failure; the Need becomes undeniable |
| Showdown | The protagonist acts (in alignment with the Need or against it) |
| Realization | The protagonist *knows* the Need was the truth |

This interlock is what makes a script feel *earned* — every
structural beat is doing character work, not just plot work.

### Multi-track / ensemble (Patterns B/C/D)

Every POV track needs its own 7 plot points, relative to that track's
introduction page. The Showdown should converge tracks (per Pattern
C/D rules). Realizations may stagger but must all land within the
Showdown window.

### In Medias Res

If the script opens after the original Catalyst (e.g., on Day 1,423
of captivity), the script must substitute a *new* dramatic question
by the Catalyst page target. The original Backstory is the
pre-existing situation; the substitute Catalyst is what disrupts the
*static* opening situation (a rescue planned, a contact made, a
deadline imposed). All 7 plot points still apply, anchored to the
substitute Catalyst.

The Quality Gate verifies all 7 milestones (see Quality Gate below)
and the Pre-Delivery Sweep includes a Beat-Anchoring pass.

### Scene-by-Scene Generation

For each scene in the beat sheet:

1. **Write the scene heading** — strict format `INT.` / `EXT.` + LOCATION + ` - ` + `DAY` or `NIGHT` (or one of CONTINUOUS / MOMENTS LATER / LATER / SAME). See Sluglines under Craft Standards below for the full ruleset and the location-hierarchy rule.
2. **Write action lines** — present tense, lean, visual, max 4 lines per paragraph. Filter every sentence through the AI-Tell Patterns ban-list (Craft Standards) before moving on.
3. **Write dialogue** — subtext over on-the-nose, distinct voices per character
4. **Apply "enter late, leave early"** — start at conflict, end at impact

### Craft Standards (MANDATORY — enforced on every scene)

These separate professional from amateur screenwriting. Violations are caught
and fixed before delivery.

**Sluglines (Scene Headings) — STRICT:**
- Format: `INT.` / `EXT.` / `INT./EXT.` / `I/E.` + LOCATION + ` - ` + TIME
- **Time-of-day is `DAY` or `NIGHT`** in 95%+ of cases. Anything else carries
  industry-amateur signal. Permitted alternatives:
  - `CONTINUOUS` — scene continues directly from the previous scene, same time
  - `MOMENTS LATER` — small time jump (seconds to a minute)
  - `LATER` — same location, later in the day
  - `SAME` / `SAME TIME` — parallel action in another location
  - `DAWN` / `DUSK` — only when the specific quality of dawn or dusk is
    dramatically essential to the scene (not just "it's morning")
- **NEVER in slugline — these are amateur tells:**
  - Camera directions: `WIDE SHOT`, `CLOSE ON`, `AERIAL`, `POV`, `ANGLE ON`,
    `TRACKING SHOT`, `INSERT`, `CRANE`. If a camera direction is genuinely
    essential, it is a separate direction line BETWEEN sluglines, never
    embedded in the slugline itself.
  - Time qualifiers `MORNING`, `AFTERNOON`, `EVENING`, `LATE NIGHT`,
    `EARLY MORNING`. These belong in action lines, not sluglines. The
    quality of morning light is conveyed by what the camera sees, not by
    the slugline.
  - Era / period parentheticals: `(PRESENT DAY)`, `(1962)`, `(FLASHBACK)`,
    `(20 YEARS AGO)`. Era jumps use a SUPER (overlay text), a transition
    line (`> FLASHBACK TO:`), or are established in action.
  - Weather, mood, or descriptive parentheticals: `(RAINING)`, `(QUIET)`,
    `(HOSPITAL ROOM)`. Action lines.
- **Location-hierarchy rule (no re-establishing):** Once a master location
  is established (e.g., `EXT. SMALL TOWN MAIN STREET - DAY`), subsequent
  scenes that stay within that master location slug to the **specific**
  sub-location only. The next scene inside the diner on that street is
  `INT. DINER - DAY`, **not** `INT. SMALL TOWN - DINER - DAY`. Repeating
  the master location reads as the writer not trusting the reader.
- Use the same LOCATION name consistently — `INT. SARAH'S APARTMENT` stays
  `SARAH'S APARTMENT` for every scene, not `SARAH'S PLACE` then `SARAH'S
  FLAT`.

**Sluglines — special variants (use sparingly, with intent):**

These are real industry tools for specific dramatic situations. Each
serves a precise purpose; misuse marks the script as amateur.

| Variant | Purpose | Example | When to use |
|---|---|---|---|
| `INTERCUT - {scenes}` or `INTERCUT BETWEEN:` followed by location list | Rapid cutting between two simultaneous scenes (most commonly a phone call) | `INTERCUT - SARAH'S KITCHEN / JACK'S CAR - DAY` then dialogue alternates between the two | Phone calls, parallel action that must read as simultaneous, montage build |
| `INSERT - {object/text/screen}` | Cut to a close-on-an-object that the script needs the audience to see clearly | `INSERT - NEWSPAPER HEADLINE: "MISSING SINCE TUESDAY"` | Newspaper, phone screen, photo, document, wedding ring on table — anything where the reader (and the camera) must see the specific image |
| `BACK TO SCENE` | Return to the master scene after an INSERT or short interruption | After `INSERT - PHONE SCREEN: "DAD CALLING"`, the next slugline is `BACK TO SCENE` | Pairs with INSERT or with a short flashback. Without it, the next slugline must re-establish the master location, which costs white space. |
| `SUPER: "{text}"` | Overlay text on the image — typically a date, location label, or attribution | `SUPER: "BERLIN — 1989"` or `SUPER: "Three weeks earlier"` | Period jumps, location labels for new cities, factual attributions. **Use SUPER instead of slugline parentheticals like (1989) — see Sluglines rules above.** |
| `> FLASHBACK TO:` then `> END FLASHBACK` (or `> BACK TO PRESENT`) | Wrap a flashback sequence | `> FLASHBACK TO:` then scenes from the past, then `> END FLASHBACK` | Multi-scene flashbacks. Single-scene flashbacks may use `INT. CLASSROOM (FLASHBACK) - DAY` if briefer. |
| `MONTAGE - {topic}` then `END MONTAGE` | A sequence of short visual beats compressed into a stylised passage | `MONTAGE - SARAH BUILDS THE CASE` followed by 4–8 short images, then `END MONTAGE` | Training sequences, time passing, pattern-establishing visuals. A montage typically runs ½ to 2 pages. |

**Secondary scene headings — direct attention without camera direction:**

Trottier teaches a professional technique for moving the camera
within a master location *without* writing camera directions. Use
**secondary scene headings** — short, capitalised location-or-character
labels that shift the implicit framing.

```fountain
INT. RICK'S CAFE - NIGHT

The room hums with conversation. Cigarette smoke curls under the lamps.

AT THE BAR

RICK pours a drink, eyes on the door.

GAMING ROOM

A couple dice at the corner table.

RICK

He sets the bottle down. Watches her cross the room.
```

**Rules:**

- A secondary heading is on its own line, in CAPS, with no period.
- It can name a sub-location (`AT THE BAR`, `THE KITCHEN`, `IN THE
  HALLWAY`) or a character (`RICK`, `SARAH`) — naming a character
  implicitly puts the camera on them until the next heading.
- Use to shift focus within an established master scene, not to
  introduce a new master location (use a full slugline for that).
- This is the spec-script substitute for `CLOSE ON RICK` or
  `ANGLE ON THE BAR` — gets the same camera placement without the
  camera direction.

**On-screen text — emails, texts, signs, computer screens:**

When the audience must read text on screen — an email, a text
message, a newspaper headline, a sign, a screen — use either INSERT
or SUPER, with the text in quotation marks.

| Format | When to use | Example |
|---|---|---|
| `INSERT - {description}` followed by quoted text, then `BACK TO SCENE` | When the text is shown in close-up and dominates the frame | `INSERT - EMAIL FROM SARAH` then `"I'm not coming home tonight."` then `BACK TO SCENE` |
| `SUPER: "{text}"` | Brief overlay text, dates, location labels, on-screen captions | `SUPER: "TWO YEARS LATER"` or `SUPER: "1 NEW MESSAGE"` |
| Inline action description | When the text is part of the visible scene but not in close-up | `She glances at the headline: "MAYOR INDICTED."` |

The quotation marks are mandatory for text the audience reads. Without
them, the format reads as the writer's narration, not as on-screen
words.

**Worked example — text-message exchange:**

```fountain
INT. SARAH'S APARTMENT - NIGHT

Sarah sits on the bed, phone in hand. Stares at the screen.

INSERT - SARAH'S PHONE

A text from JACK: "I made a mistake."

She types. Deletes. Types again.

Her reply: "Which one?"

BACK TO SCENE

She drops the phone face-down on the duvet.
```

**Rules of restraint:**
- Use INTERCUT only when the parallel scenes must read as truly simultaneous. Otherwise, alternate scenes with normal sluglines.
- Use INSERT only for an image the script genuinely needs the audience to see in close-up detail. Don't INSERT atmospheric objects — those go in action lines.
- Use SUPER instead of slugline parentheticals for period/location labels (per Sluglines rules above). One SUPER per major time/place jump is standard; more than three in a script signals the writer is leaning on the device instead of dramatising the transitions.
- Use FLASHBACK sparingly. If the screenplay has more than two flashback sequences, consider whether the structure should be reordered to put the past in chronological place.

**Action Lines:**
- Present tense always. Never past tense.
- Maximum 4 lines per action paragraph. 2-3 lines preferred. The Tone-and-Style preset (S5 above) sets the per-script target.
- No "we see" or "we hear" — everything in a screenplay is seen and heard
- No "begins to" or "starts to" — write the action directly
- No "suddenly" — the action itself should feel sudden
- Active, specific verbs: "storms in" not "comes into the room angrily"
- Specific visual details: "Pizza boxes tower on the coffee table" not "the room is messy"
- Sound cues — **school of thought matters here**:
  - **Default (modern spec — recommended):** Don't capitalise sounds in action lines. Trust the production's sound department to identify cues from the prose. *"A gunshot echoes across the valley."* / *"The phone buzzes."*
  - **Shooting-script convention (older / production):** SOUNDS in CAPS to flag audio cues. *"A GUNSHOT echoes across the valley."* / *"The phone BUZZES."*
  - **When to break the default and CAP a sound:** when the sound itself is a story beat the audience must register — a gunshot that nobody on screen reacts to, a door that slams while someone is mid-sentence, a phone buzzing as the cue for the ending. Reserve CAPS for sound that *acts* in the scene, not for routine ambient sound.
  - **Engine default:** modern spec. Apply CAPS sparingly, only for story-beat sounds. The user can flip the default to shooting-script convention at S5 (Tone and Style) if they specifically want every sound capped.

**Action Lines — additional amateur tells (NEVER write):**

These are lower-frequency than the AI-tell family but each is a known
industry tell that flags a script as amateur.

| Pattern | Example (rewrite) | Why |
|---|---|---|
| **Adverb overuse** in action — `walks quickly`, `says angrily`, `looks nervously`, `moves carefully` | "She walks quickly to the door." → **Rewrite:** "She strides to the door." | Pro screenwriting picks the verb that means the adverb. If you can't find a verb, the action probably isn't precise enough. Hard cap: 2 adverbs per page. |
| **Fortune-telling narration** — `what would later become`, `if she had known`, `as we'll see in Act III`, `the last time he would ever` | "She crosses the threshold of what will become her own crime scene." → **Rewrite:** "She crosses the threshold." | Action lines describe NOW. The future-tense reveals break present-tense discipline and tell the audience the writer thinks they're cleverer than the story. |
| **Editorialising adverbs** — `amazingly`, `of course`, `interestingly`, `tragically`, `surprisingly` | "Surprisingly, the door opens." → **Rewrite:** "The door opens." | Writer-to-reader commentary; nothing on screen. If the moment is surprising, the audience will feel the surprise without being told. |
| **Stage-direction-as-exposition** — `the bedroom is messy and shows that Sarah is depressed`; `the office is empty, suggesting Mark has been fired` | "The kitchen is spotless, suggesting Sarah's obsessive control." → **Rewrite:** "The kitchen is spotless. Three sponges aligned at right angles by the sink." | "Shows that" / "suggesting" / "implying" all tell the audience what to think. Show the detail; let the audience read it. |
| **Action-paragraph anaphora** — three or more consecutive paragraphs that open with the same character name | `She walks to the door. / She picks up the keys. / She looks back.` → **Rewrite:** Vary the subject or restructure. Use action chains, sound cues, sensory details, or other characters' reactions to break the pattern. | Visual rhythm tell. Reader's eye snags on the repetition. |
| **Director-of-actor instructions** — `she is angry`, `he feels betrayed`, `she is conflicted` | "She is angry." → **Rewrite:** "She doesn't slam the door. She closes it slowly. The latch clicks." | Same family as Unfilmable Content. The actor's job is to find and play the emotion; the script's job is to give them the action. |
| **Camera-direction smuggling** — `we focus on her hand`, `the camera lingers on the photo`, `our eye is drawn to the gun` | "Our eye is drawn to the wedding ring on the table." → **Rewrite:** "On the table: a wedding ring." (Sentence-fragment focus. Or use a one-line action paragraph: "The wedding ring sits on the table.") | This is the same prohibition as no-camera-directions, dressed as prose. Use sentence structure and paragraph isolation to direct attention; don't tell the director where to put the camera. |

**Dialogue:**
- Subtext over on-the-nose — characters talk around the thing, not about it
- Each character must have a distinct voice (cover the names; can you tell who's speaking?)
- No characters explaining plot to each other for the audience's benefit
- Parentheticals used sparingly — only when the line would be misread without guidance
- Never direct the actor's emotion: no "(angrily)" "(sadly)" "(with feeling)"

**Dialogue — anti-patterns (NEVER write):**

| Pattern | Example (rewrite) | Why |
|---|---|---|
| **Exposition crutches** — `As you know,` / `As we discussed,` / `Remember when` / `As I told you yesterday,` | "As you know, our daughter is missing." → **Rewrite:** Have one character act on the information; let context carry it. Or cut the exposition entirely if the audience already knows. | If both characters know it, the line exists for the audience. The audience can tell. |
| **Telling emotional state** — `I'm angry` / `I'm sad` / `I miss her` / `I'm scared` | "I'm so angry right now." → **Rewrite:** "Get out." (or whatever a furious person actually says — usually something tangential, deflecting, or controlled) | Performance shows emotion. Lines should carry subtext. The exception: a character genuinely incapable of subtext (a child, a character on the autism spectrum, a character in extremis) — flag the choice. |
| **Long speeches** — any single dialogue block longer than 5 lines | A 12-line monologue mid-scene. → **Rewrite:** Break with action beats, interjections from another character, a parenthetical with movement. Or trim. | Industry red flag unless deliberately a set-piece (and even then, max 8 lines). Long speeches almost always mean the character is speech-making, not interacting. |
| **Greetings / farewells** — `Hello`, `How are you`, `Goodbye`, `Take care`, `Have a good one`, `See you later` | "Hi, Sarah." / "Hi, Jack. How was your day?" → **Rewrite:** Cut. Enter the scene at the moment of conflict, exit at the moment of impact. | "Enter late, leave early" applied to dialogue. Greetings and farewells are scene-pad. |
| **On-the-nose questions** — `Did you do it?` / `Are you angry with me?` / `Why are you sad?` (when answered straightforwardly) | "Are you angry with me?" / "Yes." → **Rewrite:** Replace with the deflection or tangential exchange that real people use to avoid direct confrontation. Pro dialogue circles around the question. | Direct Q&A drains the scene of subtext. Real conflict is sideways. |
| **Filler word overuse** — `OK`, `well`, `yeah`, `you know` appearing more than once per page | Five "well"s on page 4. → **Rewrite:** Cut. Filler is the writer's hesitation, not the character's. | Filler-word overuse is the most common amateur dialogue tell after exposition. Audit before delivery: max ~1 of each per page on average. |
| **Catchphrase repetition** — same character phrase used 3+ times | Sarah saying "Right, OK" four times in 30 pages. → **Rewrite:** Vary. Catchphrases happen on purpose (signature lines), not by accident. | A character verbal tic used 3+ times without intent reads as the writer's tic, not the character's. Flag intentional ones in the Character Map. |
| **Derivative dialogue** — lines so generic any character could speak them | "I'm going to kill you." / "Why? Because I didn't blindly follow orders." → **Rewrite:** Insert character-specific specificity — a reference only this character would make, a vocabulary peculiar to them, a unique syntax, a detail tied to their history or expertise. *"I'm going to kill you."* could become *"You think you're walking out of this room."* (Specific to a Marine's interrogation register.) | The Bible's Sin #7. Test: cover the character cue. Could 5+ named characters in this script speak this line interchangeably without breaking voice? If yes, rewrite. |
| **Profanity density / register** — every character uses profanity at the same density | Five characters across five different ranks/backgrounds all averaging 3 fucks per page. → **Rewrite:** Profanity should serve characterisation. Rank-and-file marines may swear constantly; their officer may not. The genteel character who swears once, in extremis, lands harder than the character who swears every line. | The Bible's Sin #3. Default cap: ~1 profanity per 2 pages of dialogue per character. Genre exceptions (noir, war, prison, hard-boiled crime, gangster) raise the cap. Test: cover the character cue across all profane lines — do they sound like the same person? If yes, vary by character. |

**Maid-and-butler test (apply BEFORE writing every dialogue exchange):**

Before committing a dialogue line to the page, ask the question the
Bible asks: *"Do both of these characters already know what's being
said?"* If yes, the line exists for the audience, not the characters.
This is the **maid-and-butler trap** — characters narrating
information to each other for the audience's benefit, often without
phrase markers like "As you know" that would trip the literal scan
in the Pre-Delivery Sweep.

The fix is not always "cut the line" — the audience often does need
the information. The fix is to **find another way to deliver it**:

| Symptom | Better delivery |
|---|---|
| Helen tells Clara that Rosemary watched Phyllis at the fête | Show Rosemary watching Phyllis in an earlier action beat. Helen's line becomes a confirmation Clara already half-suspects, not new exposition. |
| Tuk'Zee informs the Captain "I am offering you an existence above annihilation" | Show the captain's existing situation (cells, atrocities, broken communication) and let Tuk'Zee make a much shorter, harder offer ("Or this." with a gesture). |
| Mission briefing dump ("You're to infiltrate the prison, locate Tanner…") | Show the planning materials on a table — map, dossier, a photograph — and let the briefing be the characters reacting to those materials, not a narrator. |
| One character explains the world's history to another for the audience | Cut the explanation. Let the world prove its rules through what characters do, what objects exist, what's normal vs. forbidden. The audience will infer faster than dialogue can explain. |

If the test reveals the line exists for the audience, the dialogue
needs to be reshaped — not just to remove "As you know" markers, but
to remove the underlying narration-by-character.

**Scene Construction — the four mandatory elements:**

Per Trottier, every scene must carry four elements. A scene that
misses one feels flat; a scene that misses two doesn't earn its
place in the script.

| Element | What it means | Test |
|---|---|---|
| **Emotional centre** | The POV character feels *something specific* in this scene — not "vaguely uneasy" but a named emotion the actor can play | What does the POV character feel at the *start* of this scene, and what do they feel at the end? |
| **Motivated conflict** | Even minor scenes have opposition. Two characters can share a goal but disagree on method, urgency, or interpretation | What does each character in the scene want, and how do those wants collide? |
| **Escalating turns** | Every beat raises stakes vs. the previous beat. The scene builds, not plateaus | Does beat 4 feel more pressurised than beat 1? |
| **A punch at the end** | The scene closes on tension that propels into the next scene — a question, a reversal, a decision, an unresolved emotion | Why does the audience need to keep watching after this scene? |

**Worked example — escalating turns (from *Some Like It Hot*):** Jerry
needs to talk Osgood out of marrying him. Each objection escalates:
- "I've been living with a saxophone player." (Reasonable.)
- "I can't have children." (Personal.)
- "I'm a *man*." (The reveal.)
- Osgood: *"Well, nobody's perfect."* (The punch.)

Each beat raises the stakes — escalation is the engine of comedy and
drama alike. A scene where the third beat doesn't pressure harder
than the first is a scene that has flatlined.

**Subtext in scene construction:**

A scene with all four elements still fails if the dialogue is
on-the-nose. Trottier's example: in *Double Indemnity*, the seduction
scene is conducted entirely as a conversation about a *speeding
ticket*. ("I'd have to drive it around the block a couple of times.")
The scene's emotional centre is sexual tension; the dialogue is about
traffic violations. The audience hears both.

**The pre-write spine — apply BEFORE drafting any scene:**

Before generating a scene, sketch its spine in this order:

1. **What is the emotional state at the *start*?** (one word per character present)
2. **What does each character want in this scene?** (one phrase each)
3. **What's the conflict?** (one sentence — the collision of wants)
4. **What are the 3–5 turns?** (numbered list, each one harder than the last)
5. **What's the punch?** (the line, image, or beat that closes the scene)
6. **Is anything carrying subtext?** (what the scene is *really* about, beneath the surface)

Only after the spine is set does the writer draft action and dialogue.
Scenes built without a spine produce talking heads, flat openings,
and unearned emotional moments.

**Scene Blocking — avoid talking heads (MANDATORY):**

A "talking heads" scene is one where dialogue carries the entire
dramatic load while characters remain physically static — sitting,
standing, facing each other, no action beats. The Bible's verdict is
direct: *"Avoid talking heads."* Static dialogue scenes drain
cinematic energy and signal a writer who hasn't translated from prose
to screen.

The rules:

- **Every scene with 5+ dialogue exchanges must include at least one
  action beat** between exchanges. An action beat is character
  movement, gesture with intent, prop interaction, environmental
  reaction, or a deliberate stillness that contrasts an earlier
  movement (the silence after the pacing).
- **The climax / confrontation / revelation scene must have meaningful
  physical activity**, not static positions. The Bible's specific
  remedy: *"Move the action through space; give characters physical
  activity that mirrors or contrasts the emotional content."* If your
  village-hall accusation, your courtroom verdict, your final
  confrontation, or your confession scene is delivered while everyone
  sits in chairs, it will read as a stage play.
- **The action beats must do work, not just punctuate**. Characters
  don't pick up coffee cups for no reason. The action either:
  - **Mirrors** the emotional content (the careful unwrapping of
    something fragile during a careful conversation about something
    fragile)
  - **Contrasts** it (cheerful tea-pouring while someone reveals a
    devastating betrayal)
  - **Reveals** something (a hand that won't stop shaking; a gaze
    fixed on the door)
  - **Builds** something (someone preparing food, repairing an
    object, walking a route that ends at a meaningful destination)

**Examples of busy-but-purposeful blocking (good):**
- Two characters discuss a betrayal while one washes and dries the
  same plate three times.
- A confession scene where the accused arranges and rearranges items
  on a table — and at the moment of confession, sets one item down
  and leaves it.
- A confrontation where one character keeps walking and the other has
  to follow — the geography becomes the dynamic.

**Examples of talking heads (rewrite):**
- Two characters seated at a table, exchanging dialogue with no action
  beats for 10 lines.
- A confrontation in a kitchen where neither character moves until the
  scene ends.
- A revelation scene where a character delivers a 200-word monologue
  while the listener sits motionless.

**The fix when generating:** before writing a dialogue scene, sketch
the **physical spine** — what each character is doing with their body
during the conversation, what objects are in play, what the
geography forces. Write the scene with the spine first, then layer
dialogue. A scene can be entirely silent and still work; a scene that
is entirely talk almost never works on screen.

**Action sequence craft (chase / fight / set piece):**

Action sequences run on different rules from regular scenes. Reading
density, paragraph length, and visual clarity all shift to keep the
sequence legible at speed.

The discipline:

| Rule | Why |
|---|---|
| **One-line action paragraphs during fast action** | Pages with short paragraphs read fast. White space is pace. A 1-line paragraph reads in a beat; a 4-line paragraph reads in a breath. |
| **Beat-by-beat physical clarity** — every move legible | "They fight" is a dodge. The reader needs to see what hits land, who moves where, who has the upper hand. |
| **Geographic clarity — name locations and positions** | Where is each character in the space? Who has the high ground? Where's the door, the gun, the weak point? Re-anchor every 3-5 beats. |
| **Gearing — physicality escalates through the sequence** | Beat 1 is a punch. Beat 5 is a chair. Beat 9 is the window. Each escalates in scale or stakes. |
| **Reaction shots earn the action** | An explosion lands when we see someone respond to it. Cut to the watcher's face after the impact, not just the impact. |
| **Sound cues at impact moments** | Action is the one place where sound CAPS pays off even in modern spec. The GUNSHOT, the CRASH, the WINDOW SHATTERING. Use sparingly even here — only at the moments that *act* in the scene. |
| **Short sentence verbs, no adverbs** | "Slams." not "Slams it hard against the wall." The verb alone carries the action. |
| **No dialogue during the action's peak** | The moment of maximum physical violence is silent (or a single line, or a non-verbal sound). Dialogue belongs at the start or end of the sequence, not its centre. |

**Worked example — opening of a fight (good):**

```
Sarah turns. Sees the knife.

She drops.

The blade goes over her shoulder. Punches the wall.

She comes up under his guard. Elbow to the jaw.

He staggers. She grabs the lamp.
```

Each paragraph is one beat. Each beat is physically clear. Geography
is implicit (close range, a wall behind her, a lamp within reach).
Gearing builds — knife, dodge, elbow, lamp.

**Action paragraph length cap during fast sequences:** maximum 2 lines.
Outside fast sequences, the standard 4-line cap applies.

**Comedy craft — beyond Rule of Threes:**

Comedy on screen is a craft of **timing**, **specificity**, and
**setup-payoff structure**. The Rule of Threes (setup, pattern,
twist) is the base unit; the larger craft layers on top.

| Technique | Example | Rule |
|---|---|---|
| **Setup / payoff (within scene)** | Setup: a character's allergy is mentioned. Payoff (3 minutes later): the antagonist's flowers trigger a sneezing fit at the worst moment. | Plant setups specifically. Payoffs land harder when the audience has half-forgotten the setup. |
| **Setup / payoff (across the script)** | Setup: a casual line on page 8. Payoff: the line returns as the punchline of the climax. | The bigger the gap between setup and payoff, the bigger the laugh — provided the audience just barely remembers the setup. |
| **Callbacks** | Same line / image / gesture returns at a key later moment with new meaning | Callbacks reward attention. They tell the audience the writer is in control of the joke they thought was over. |
| **Comic timing through line breaks** | The punchline gets its own line. The setup doesn't. | The visual silence before the punchline does the timing work that delivery would do on screen. |
| **Specificity over generality** | "He drives a Toyota Corolla with a bumper sticker for a community theatre production of *Cats*." beats "He drives a sad car." | Comedy lives in specifics. Generic descriptions never land. |
| **Status play** | A high-status character does something low-status (the CEO trips); a low-status character does something high-status (the intern corrects the boss). | Comic friction is often a status mismatch played straight. |
| **Dramatic irony as comedy mechanism** | The audience knows what one character doesn't (the surprise party they're walking into; the lie they're about to be told). | The audience laughs because they're ahead of the character. |
| **Physical comedy described by the action, not the laugh** | "He sits on the cake." NOT "Hilariously, he sits on the cake." | Don't tell the audience to laugh. Show the cake. They'll laugh. |
| **The rule of two** (when threes feels overworked) | Sometimes two beats land harder than three. Setup, twist. No pattern in between. | Use threes as the default; deploy twos when you want the punch faster. |

**Comic-scene anti-patterns:**

- Stacking jokes — every line is a punchline. Comedy needs straight
  lines too. Aim for ~1 punchline per 3-5 dialogue exchanges.
- Explaining the joke — never describe why something is funny.
- Wide jokes / cheap jokes — pop-culture references that date the
  script. Use sparingly.
- Repeated joke structures — if your last three jokes were Rule of
  Threes, the fourth needs to be something else.

**Specialty scenes — sex, violence, death, courtroom, funeral, wedding:**

These are the scenes most often badly written by inexperienced
screenwriters. Each has specific craft conventions and audience
contracts the writer must honour.

### Sex scenes

| Rule | Why |
|---|---|
| **Imply, don't describe** | The audience does the work. The bedroom door closes; we cut. We re-enter the next morning. |
| **One concrete sensory detail beats five generic ones** | The catch of breath, the specific item of clothing, the look exchanged before — one specific image carries more than a paragraph of choreography. |
| **No camera-angle prurience** | "Camera lingers on her hip" is the writer being a creep. The camera looks; we don't direct it. |
| **The emotional content is the scene** | Why is this scene in the script? If the answer is "to be sexy," cut it. If the answer is "to dramatise the relationship's turning point," write the turning point. |
| **Tasteful brevity** | Half a page is almost always enough. A full page is rare. More than a page is almost certainly a craft failure. |

### Violence

| Rule | Why |
|---|---|
| **Escalation through the scene** | Beat 1 sets the stakes; beat 5 transforms them. Violence should change the world of the scene by the end. |
| **Reaction shots are the moral content** | Violence earned by showing the cost — the witness, the survivor, the perpetrator's face after. |
| **Violence as punishment of character** is dangerous | Violence inflicted on a character to motivate another character (the murdered wife, the assaulted sister) is a tired trope. Be careful. |
| **Specific over generic** | One specific wound (the knife enters under the ribs; she gasps once, very small) lands harder than a paragraph of carnage. |
| **The thing not shown is the most violent** | What the camera cuts away from — what the audience imagines — is often more visceral than what's depicted. |

### Death scenes

| Rule | Why |
|---|---|
| **The camera is on the survivor, not the dying** | The audience grieves through the witness. Stay on the face that watches. |
| **One detail does the work** | A trembling hand, a single word, a final small gesture. Avoid speeches. |
| **The reaction shot follows the silence** | Sound design (the absence of sound; the held breath) carries the moment. |
| **No final monologues unless the script earns it** | Most "I love you" deathbed speeches are a craft failure. The unsaid thing is the loss. |

### Courtroom scenes

| Rule | Why |
|---|---|
| **Procedural accuracy matters** | Industry readers know courtroom procedure. Misuse "objection," cross vs. direct examination, or the order of proceedings and the script reads as amateur. |
| **The objection rhythm sets the pace** | Build interruptions into the rhythm. The witness's answer is shaped by what they're allowed to say. |
| **The witness-interrogation arc is its own structure** | Setup (establish the witness's authority/credibility), pressure (the line of questioning that destabilises), break (the moment they reveal too much). |
| **Verdict scenes are reaction scenes** | The camera is on the defendant when the verdict is read, not on the foreman. |

### Funeral / wake / wedding scenes

| Rule | Why |
|---|---|
| **One specific detail, not generic mourning/celebration** | The hymn nobody knows; the tie that doesn't quite match; the hand on the shoulder of the wrong person. The specific carries the universal. |
| **Action through the ceremony, not commentary on it** | What the protagonist *does* during the ceremony — what they pick up, who they avoid, what they whisper — is the scene. The ceremony itself is backdrop. |
| **The eulogy / vow problem** | Speeches at funerals and weddings are easy to write badly. If you must write one, give it to a character who is genuinely under-prepared (or over-prepared) — the awkwardness *is* the scene. |
| **Reaction shots build the relationship map** | Who looks at whom during the vows / the eulogy tells the audience more than the words. |

**Engine application:** when generating any scene that fits these
categories, the writer applies the relevant rules above before
drafting. Pre-Delivery Sweep includes a specialty-scenes check (see
Pass 6 — Scene craft).

**V.O. vs O.S. — when to use which:**

These are not interchangeable. Each signals something different to the
reader (and ultimately the audience).

| Extension | Meaning | Use when | Don't use when |
|---|---|---|---|
| `(V.O.)` Voice Over | The character is speaking but is NOT in the scene at all — narrator, internal monologue rendered as voice, recorded message, character writing the journal we hear | **Narrator framing** ("My grandmother's kitchen had eleven things in it…"); **internal monologue made audible** when visual storytelling can't carry the reflection; **letters / journals / recordings** the audience hears as though spoken | The character is present in the scene but off-camera. Use O.S. for that. |
| `(O.S.)` Off Screen | The character IS in the scene but is not visible in the current shot — calling from the next room, on the other side of a door, behind the camera | A character calling "I'm in the kitchen!" from the kitchen while the camera stays on Sarah in the hallway. The character exists in the same physical space; the camera just isn't on them. | The character isn't physically in the scene. That's V.O. |
| `(CONT'D)` Continued | A character continues speaking after an action interruption | Most software auto-generates this — only manually add when needed for clarity | As an aesthetic choice; it should be mechanical |

**V.O. budget reminder:** Maximum 3–4 V.O. blocks per 30-page
screenplay (already specified in Page Budget). V.O. should add what
the camera cannot show — never narrate what's already visible. If
adapting from prose, convert internal monologue to visual behaviour
first; reach for V.O. only when visual storytelling genuinely cannot
carry the moment.

**O.S. has no hard cap** — use it whenever the geography of the scene
naturally produces off-camera dialogue. It is a spatial choice, not a
narrative one.

**V.O. styles — the right tool for the right narration:**

V.O. is not a single technique. Different V.O. styles produce
different effects and have different craft rules.

| Style | What it is | When it works | Craft note |
|---|---|---|---|
| **Standard narrator V.O.** | A single character (usually the protagonist) tells the story in voice-over | Memoir-driven scripts; coming-of-age; period pieces | Keep it lean. The V.O. should add what the camera can't show — interiority, reflection, time-collapsing summary. |
| **Future-tense V.O.** ("Years later, I would learn…") | The narrator is older / wiser than the on-screen character; tells the story from a future vantage | When hindsight is the script's actual subject (regret, loss, dawning understanding) | The future-tense framing is a contract — the script must eventually arrive at the moment the narrator is speaking from, or explain why it doesn't. |
| **Unreliable narrator V.O.** | The V.O. tells a version of events that the visuals contradict | Mystery, psychological thriller, dark comedy | The unreliability must be paid off — the audience must learn at some point that the V.O. has been lying or wrong. Earned through visual contradictions seeded throughout. |
| **Multiple V.O. characters** | Two or more characters take turns narrating | Ensemble pieces; dual-protagonist stories | Each V.O. character must have a distinct voice (vocabulary, rhythm, perception filter). Cover the speaker; can you tell who's narrating? Same blind-test rule as dialogue. |
| **Diary / letter V.O.** | The V.O. is text being read or written — a journal, a letter, an email | When the act of *writing* or *reading* is dramatically significant | Format the V.O. cue with the source: `SARAH (V.O.) (reading)` or `JACK (V.O.) (writing)`. The audience needs to know the V.O. is text, not internal voice. |
| **Documentary / mockumentary V.O.** | An external narrator in documentary register | Faux-doc framing (mockumentary), historical drama with a documentary frame | The documentary register has its own conventions — third person, present or past tense, evaluative tone. Different rhythm from character V.O. |

**Picking the right style:** the V.O. style is part of the project's
voice. Establish it on page 1 and stay with it. Mixing styles
mid-script (a documentary V.O. that suddenly becomes the
protagonist's internal monologue) requires explicit dramatic
justification.

**Style is constrained by genre and Tone preset:** noir leans
narrator V.O. (often unreliable); coming-of-age leans future-tense
("when I was eleven, I learned…"); period adaptations often use
diary / letter V.O. The Genre Translation Notes section lists which
style fits each genre.

**Spec Script Rules:**
- No scene numbers (those are for shooting scripts)
- No camera directions (CLOSE UP, PAN TO, TRACKING SHOT) unless essential for story
- No "CUT TO:" between every scene — the scene heading implies the cut
- No CONTINUED at page breaks
- This is a spec script, not a shooting script

**Character Introductions:**
- NAME in ALL CAPS on first appearance in action lines
- Brief, vivid, visual description — what the camera sees, not backstory
- Age in parentheses, ranges for minor characters
- Good: `SARAH CHEN (30s), sharp-eyed with a surgeon's calm, strides in wearing scrubs spotted with blood.`
- Bad: `SARAH CHEN (30) enters. She is a nice person who has always wanted to be a doctor.`

**Character demographics — race, ethnicity, gender, sexuality, disability:**

Modern industry expectation has shifted on how character demographics
are specified in introductions. The current professional practice:

| Rule | Explanation |
|---|---|
| **Specify when it matters to the story; specify thoughtfully when it doesn't** | If a character's race, ethnicity, gender, sexuality, or disability is integral to the story (a script about the immigrant experience, a queer love story, a war veteran's PTSD), name it explicitly in the introduction. If it doesn't drive the story, the older convention was "leave it open"; the modern convention is "specify anyway, because 'unspecified' defaults to 'white, cis, straight, able-bodied' in casting, which restricts the talent pool and the story's reach." |
| **Authentic, not decorative** | Specify because you've thought about the character — not as a checkbox. *"MAYA (40s, Indian-American, sharp-eyed and slightly impatient"* is authentic. *"MAYA (40s, ethnic, no specific reason"* is decorative. |
| **Visible, not biographical** | The introduction describes what the camera sees. Race and ethnicity are usually visible; sexuality usually isn't (and shouldn't be in the intro unless it's foregrounded by behaviour or context). Disability is visible if it shapes the body in scene; not visible if it's invisible (chronic illness, neurodivergence). Choose what's introduced based on what the camera will show on first appearance. |
| **No caricature** | Dialect, accent, cultural specificity rendered with respect to actual speech patterns. *Read it aloud. Would the character recognise themselves?* If unsure, consult or omit. |
| **Disability portrayal** | Specify the disability if visible and integral. Avoid the "inspirational disabled person" trope — the disability is part of the character, not their entire identity. Same character-architecture rules apply (Want / Need / Flaw / Backstory). |
| **Gender and pronouns** | Specify gender when introducing the character. Use the character's pronouns consistently in action lines. For transgender or non-binary characters, the pronoun choice in the script itself is part of the characterisation. |

**Examples — modern industry-acceptable introductions:**

```
MAYA SHARMA (40s, Indian-American, sharp-eyed and slightly impatient)
strides into the conference room.
```

```
JACK (60s, Black, missing his left arm at the elbow) tunes a guitar
one-handed. Faster than most people do it with two.
```

```
RILEY (20s, non-binary, wiry build, bleached eyebrows) checks the
back door. Then the front. Then the back again.
```

**Avoid:**
- Specifying demographics as the *first* descriptor of every
  character in the script (reads as a checklist). Lead with the
  character's *behaviour* or *defining visual* most often; weave in
  demographics naturally.
- Using sexuality / gender identity as the character's *defining
  feature* unless it actually is the central characterisation.
- Pre-emptively explaining the demographic ("MARIA, who is Latina,
  enters." — just *"MARIA, in her late thirties, …"* and let context
  reveal what's relevant).

**When unsure:** the "if it doesn't matter, don't specify" rule is
acceptable for minor characters (one-scene roles). For named
characters with arcs, specify thoughtfully and let casting open up
to the talent pool that fits.

**White Space:**
- Target ~50% white space per page
- Dense pages signal amateur writing to professional readers
- White space controls pacing: more space = faster pace

**Unfilmable Content — NEVER write:**
- "Sarah feels regret about her childhood" — How does the camera show this?
- "He thinks about whether to trust her" — Externalise through behaviour
- "The room had a sense of foreboding" — Show what creates the foreboding
- Any internal state must be converted to visual behaviour or V.O.

**AI-Tell Patterns — NEVER write (this is the AI's signature, and readers
spot it on page one):**

These patterns share one disease: they describe a character through
**inferences the camera cannot film** — psychology, backstory, "the
quality of someone who…" — dressed up as observation. Replace every
match with what the camera literally sees in this moment.

| Forbidden pattern | Example (rewrite) | Why |
|---|---|---|
| `the [timing / economy / care / precision] of [a person] who has…` | "She has the timing of a woman who has been watching for precisely this moment." → **Rewrite:** "She steps out the second the door swings — like she's been counting." | The camera can film *her timing*. It cannot film *that she has been watching.* |
| `there is something [adjective] about the way [she/he] [verbs]…` | "There is something careful about the way she moves." → **Rewrite:** "She sets each foot down flat, weight checked before she shifts it." | "Something careful about" is the writer's inference, not the camera's image. |
| `the [economy / weight / shape] of [a person] who has [recently / always / never] [verb-past]…` | "the economy of a woman who has recently started over." → **Rewrite:** "Her bag holds three things. She keeps a hand on the strap." | "Recently started over" is biography, not visual. |
| `as if [she/he] [verb-past]…` (when used to imply backstory) | "She closes the door as if she has done it a thousand times." → **Rewrite:** "She closes the door without looking — palm flat, no slam." | "As if she has done it a thousand times" is inference. The action is the action. |
| `in a way that suggests / implies / hints at…` | "He smiles in a way that suggests an old grief." → **Rewrite:** "He smiles. The corners don't lift." | The camera does not film suggestion. It films faces. |
| `[She/he] is the kind of [person] who…` | "She is the kind of woman who notices doors." → **Rewrite:** "She clocks every door as she crosses the lobby." | Type-statement, not behaviour. |
| `it [is / was] the kind of [thing] that…` | "It was the kind of silence that made you check the locks." → **Rewrite:** "Silence. He gets up. Checks the deadbolt." | Same disease. |

**The test:** read each action line aloud and ask, "Could the camera
film exactly this, with no inference?" If the answer requires the
audience to infer a psychology, a history, or a quality, the line is
unfilmable and reads as AI even if it is grammatically perfect. The
fix is always the same: **show the literal action that would create
that inference**, and let the audience do the inferring.

### Page Timing Awareness

The "one page = one minute" rule is a guideline, not exact:
- **Action-heavy scenes** undercount: a line describing an explosion may be 30 seconds on screen
- **Dialogue-heavy scenes** overcount: dense dialogue pages may only be 40-50 seconds
- Balance action and dialogue scenes to maintain accurate timing
- Track running page count against target throughout generation

---

## TV-Specific Protocol

### Episode Structure

**Half-Hour (Network):**
```
COLD OPEN (1-3 pages)
ACT ONE (8-12 pages)
ACT TWO (8-12 pages)
TAG (0.5-2 pages)
```

**Half-Hour (Streaming):**
```
COLD OPEN (optional, 1-5 pages)
Continuous narrative (20-30 pages)
TAG (optional)
```

**Hour (Network):**
```
TEASER (2-5 pages)
ACT ONE (10-15 pages)
ACT TWO (10-15 pages)
ACT THREE (10-15 pages)
ACT FOUR (8-12 pages)
ACT FIVE (5-10 pages)
TAG (1-2 pages, optional)
```

**Hour (Streaming/Prestige):**
```
COLD OPEN (optional, 1-7 pages)
Continuous narrative (50-65 pages)
```

### Act Break Rules

Every act break must be a moment of maximum tension:
- **Revelation** — a secret uncovered
- **Reversal** — the situation flips
- **Escalation** — stakes jump
- **Emotional peak** — a relationship breaks
- **Decision point** — cut before the choice

### Pilot vs Episode

**Pilot scripts must:**
- Establish the world, all major characters, the series premise, and the tone
- Demonstrate the "engine" — what generates new episodes
- Tell a compelling standalone story simultaneously
- May run 5-10 pages longer than a standard episode

**Episode scripts must:**
- Assume the audience knows the characters
- Match the showrunner's established voice and format
- Advance serialized arcs while telling a self-contained A-story

### Limited Series

Structure a complete story across 6-8 episodes:
- Episode 1: Setup (Act 1 of the larger story)
- Episodes 2-3: Complications and deepening
- Episodes 4-5: Midpoint reversal and escalation
- Episodes 6-7: Crisis and dark night
- Episode 8: Climax and resolution

Each episode still needs its own internal arc and satisfaction.

---

## Multi-POV / Ensemble Features

Most features are single-protagonist. A meaningful subset are not —
ensemble pieces, parallel-track structures, rotating-protagonist
scripts. The engine supports three patterns, asked at S2 if the user
indicates an ensemble or multi-track concept.

**Detection trigger:** during interactive setup (S2 Source), if the
user describes the concept and it includes phrasing like "three
characters whose stories collide", "ensemble", "parallel storylines",
"told from multiple perspectives", "told from her side and his side",
"cross-cutting between", or "intersecting lives" — ask:

```
This sounds like a multi-track structure. Which pattern fits?

  A. Single-protagonist with strong supporting cast
     (default — one POV throughout, others orbit)

  B. Rotating protagonist
     (each major chapter or sequence centres on a different character;
     Pulp Fiction, Cloud Atlas, Magnolia structure)

  C. Parallel tracks
     (2–3 characters whose stories run in parallel and intersect at
     key moments; Crash, Babel, 21 Grams)

  D. True ensemble
     (no single lead; the group is the protagonist; The Big Chill,
     Glengarry Glen Ross, Knives Out)
```

If A, proceed normally. If B/C/D, the structure section of the beat
sheet uses ensemble-specific rules.

### Pattern B: Rotating Protagonist

- Each act or sequence is anchored on a single character.
- Beat sheet allocates pages per character per act; the sum hits the
  total page target.
- Each character gets at least one full sequence (~10–15 pages) where
  they own the screen.
- All POV characters appear in the opening 15 pages — the audience
  learns the rules ("we'll be moving between people").
- Climax brings POV characters into shared geography or interleaved
  cross-cutting, even if their stories were previously separate.

### Pattern C: Parallel Tracks

- 2–3 tracks introduced in the first 10 pages (one scene per track).
- The script alternates between tracks throughout — never spend more
  than ~6–8 pages on one track without cutting back.
- Tracks intersect at the midpoint (one character enters another's
  track, or an event affects multiple tracks).
- Tracks converge in the climax — all tracks resolve in or near the
  same moment.
- Each track has its own internal arc that pays off, plus the
  cross-track payoff at convergence.

### Pattern D: True Ensemble

- No single character occupies more than ~25% of dialogue lines.
- Group-scenes dominate over solo-scenes — most pages have 3+
  characters present and active.
- The dramatic question is about the group, not a single arc
  (Glengarry: who survives the leads board; Knives Out: who killed
  Harlan; The Big Chill: do these friends still know each other).
- Voice contrast is critical — every named character gets a distinct
  vocabulary, rhythm, and behavioural tic in the Character Map.
  Without distinct voices, ensemble dialogue collapses into one voice.
- Scene construction emphasises overlap, interruption, and the
  mechanics of a group in conversation.

### Beat sheet adjustments for B/C/D

When a multi-track pattern is selected, the beat sheet:
1. Lists every beat with its anchor character (or "ENSEMBLE" if a
   group beat).
2. Tracks per-character page count alongside total page count.
3. Includes explicit "intersection beats" for Pattern C.
4. Includes an "all-POV" reference page for Pattern B (the sequence
   where every POV character must have appeared by).
5. Verifies that no track / no POV character disappears for more
   than 25 consecutive pages without the user being warned.

The Quality Gate (below) gains corresponding multi-track checks.

## Series Bible Generation (TV Projects)

When creating a TV project, generate a Series Bible (10-30 pages):

1. **Logline** — one sentence that sells the series
2. **Series Overview** — 2-3 paragraphs: premise, world, tone, what makes it unique
3. **Tone and Style** — comp shows, visual references
4. **World-Building** — rules, setting details, what the audience needs to know
5. **Character Bios** — for all series regulars: want, need, flaw, arc across the season
6. **Pilot Summary** — detailed episode breakdown (1-2 pages)
7. **Episode Summaries** — one paragraph each for episodes 2-8/10/13
8. **Season Arc** — the larger story across the season
9. **Future Seasons** — brief trajectories (1-2 paragraphs each)
10. **Thematic Framework** — what the series is really about

---

## Title Page (MANDATORY — generated before delivery)

Every screenplay ships with a complete title page. Missing or partial
title page = unsubmitted-looking script. Required fields:

| Field | Required? | Source |
|---|---|---|
| `Title:` | YES | Project working title (uppercased) |
| `Credit:` | YES | "Written by" (or "Screenplay by", or "Story by … Screenplay by …" — confirm with user if not specified) |
| `Author:` | YES | Author name as it should appear on the title page |
| `Source:` | If adapting | "Based on the {novel/story/play/article} by {Original Author}" |
| `Draft date:` | YES | Today's date in MM/DD/YYYY |
| `Draft:` | Optional | "First Draft" / "Second Draft" / "Polish" / "Production Draft" — only if user specifies |
| `Contact:` | YES | Author or representative contact (name, email, phone). If user has not provided, ask once before generating; do not invent. |

**If the user has not provided Contact information**, prompt at the
delivery step: *"Title page needs contact details. Use {project author
name} only, or add email and phone? You can change this anytime by
editing the .fountain file's title block."*

The title block is generated as Fountain title-page syntax (see
`format-fountain.md` Title Page section) and rendered in PDF/DOCX with
the field layout specified in the screenplay PDF/DOCX format files.

## Genre Translation Notes (when generating from genre file)

The genre bank was authored for novels. When `screenplay-agent.md`
loads a genre file (S3), apply these translation notes — what works
on the page in prose vs. what works on screen.

| Genre | Translates well | Translates poorly | Adjust on screen |
|---|---|---|---|
| **Cozy mystery** | Setting as character (small town, café, bookshop), amateur sleuth dynamic, comic supporting cast, low-stakes warmth | Long internal-deduction passages, extended cosy-procedural chapters, narrator-as-detective interior voice | Externalise deduction through dialogue; lean on sight gags and ensemble interplay; visual signature for the setting |
| **Thriller / psychological thriller** | Visual paranoia (off-frame threats, distorted POV), set pieces, ticking-clock structure, action-line tension | Internal monologue of the suspecting/suspected character, long flashback sequences, prose-rendered dread | Convert paranoia to behaviour (checking locks, scanning crowds, mirror glances); render dread through framing notes (action-line space and silence) |
| **Horror** | Sound design cues, what's NOT shown, build-and-release, atmosphere via setting | Description of what the character feels (terror, dread, panic), supernatural lore-dumps, internal explanation of the rules | Sound cues in CAPS for every threat-beat; trust the audience with rules; let bodies do the reacting; cut explanation by 70% |
| **Romance / romantic comedy** | Banter, physical proximity choreography, look-and-touch beats, public-private contrast | Internal pining monologues, narrator commentary on the romance, multi-page emotional reflection | Externalise want through behaviour (the look, the touch, the deflection); compress internal beats into dialogue subtext |
| **Fantasy / sci-fi** | Visual worldbuilding, set pieces, signature creature/tech moments | Worldbuilding lore-dumps, magic-system explanations, narrator-as-anthropologist | Show systems through use, never explain them; one piece of vocabulary per scene maximum; characters live in the world, they don't describe it |
| **Historical** | Period detail rendered visually (costume, set, tools, manners), authentic dialogue rhythm | Period vocabulary lessons, narrator framing the era for modern readers, footnote-style asides | SUPER for date/place; period through behaviour and object; resist the urge to teach the era |
| **Literary / upmarket** | Performance-driven scenes, silence, the unsaid, controlled atmosphere | Long interior reflection, prose-rhythm dependence, abstract emotional registers | Lean on actor-friendly silence and pause; one strong visual signature per act; trust the camera with what novels render in interior monologue |
| **Crime / noir** | Hard-boiled dialogue, urban geography, light and shadow, procedural detail | Voice-over crutch (overused noir trope), internal narration of suspicion | V.O. permitted but counted strictly against the budget (max 3–4 in 30 pages); favour visual storytelling; let geography do work |
| **Action / adventure** | Set pieces, geography, kinetic verbs, escalating physical stakes | Internal-stakes prose, character backstory in action sequences, prose-paced movement | Beat-by-beat physical clarity; one-line action paragraphs in fight/chase sequences; choreography legible on first read |
| **YA / coming-of-age** | Peer dynamics, school/home contrast, signature objects (phones, lockers, songs), generation-specific texture | Adult-narrator framing of teen experience, internal essays on identity, lesson-style resolutions | First-person feel through close perspective in scene construction; resist adult voice creeping into action lines or dialogue |
| **Comedy** | Visual gags, comic timing through line breaks, escalation, character-based humour | Witty narrator description, prose puns, observational humour from the writer's voice | Comedy on screen is timing + setup-payoff + character; the page must score the joke through line breaks and one-paragraph beats |
| **Drama (general)** | Conflict between characters with opposing wants, sustained two-handers, stakes that compound | Interior reflection scenes, journal-rendered emotional beats, prose-paced confrontations | Two-handers for confrontation; stakes visible in what characters DO, not what they say; cut emotional reflection by 60% |
| **Memoir / based-on-true-story** | Verifiable events, signature real-world details, period and place specificity | Narrator-as-the-real-person voice if it dominates; lecture-style background | V.O. permitted but disciplined (3–4 max per 30 pages); dramatise events even if they happened differently in life; flag major dramatisation in the Source line on the title page |

For genres not listed (subgenres, hybrids, niche), apply the closest
match and flag at delivery: *"Genre {X} doesn't have a screen
translation note in the engine. Applied {nearest match} guidance.
If you have a strong reference film/show in this genre, name it and
I'll calibrate to that reference instead."*

## Genre-Specific Structural Beats

The Magnificent 7 plot points are universal. *Where they land within
the script* and *what specific scene types occupy them* varies by
genre. The Beat Anchoring pass cross-checks the script against the
genre's structural conventions when the genre matches one below.

### Cozy mystery

| Beat | Conventional content |
|---|---|
| Catalyst | The body is found. Almost always before page 10. |
| Big Event | Amateur sleuth commits to investigating (often against authority's wishes). |
| Midpoint | Suspect short-list narrows; protagonist's theory is reframed by a new reveal. |
| Crisis | Wrong-suspect arrest or false-resolution moment; sleuth is doubted, sometimes in danger. |
| Showdown | **Gathering of suspects** in a single location — drawing room, parish hall, café. The killer is named. |
| Realization | Reveal of motive — usually grief, love, or money — that the audience can recontextualise against earlier scenes. |

**Genre-specific signature:** the **piece-of-evidence reveal** at the
Showdown — the ledger, the brooch, the photograph, the Christmas card
postmark. Plant it in the first act; pay it off in the Showdown.

### Thriller / psychological thriller

| Beat | Conventional content |
|---|---|
| Catalyst | The threat is revealed (the call, the photograph, the threat letter, the body). |
| Big Event | Protagonist commits to investigation OR realises they cannot trust the authorities. |
| Midpoint | **False-friend reveal** — someone the protagonist trusted is part of the threat. The world is more dangerous than they thought. |
| Crisis | Pursuit reverses — protagonist is now hunted; isolated; ticking clock activated. |
| Showdown | Confrontation, often in a charged location (the antagonist's home / lair / a place of personal significance). |
| Realization | The protagonist's *own* role in causing the threat (or in surviving it) is named. |

**Genre-specific signature:** the **ticking clock** activated by the
Midpoint and counted down explicitly through Act 3.

### Horror

| Beat | Conventional content |
|---|---|
| Catalyst | First incident — the rules of the world are violated. |
| Big Event | The threat is named (the entity, the curse, the killer). |
| Midpoint | **The rules of the monster are revealed** — what works, what doesn't, what the threat wants. |
| Crisis | First major character death OR the protagonist's plan fails catastrophically. |
| Showdown | Survivor(s) confront the threat — often using the rules established at Midpoint. |
| Realization | The monster's victory, the survivor's transformation, or the cycle restarting. |

**Genre-specific signature:** the **rules-of-the-monster reveal** at
or near the Midpoint. Without it, the audience can't engage in
problem-solving with the protagonist.

### Romance / romantic comedy

| Beat | Conventional content |
|---|---|
| Catalyst | **Meet-cute** — the leads encounter each other under specific, charged circumstances. |
| Big Event | They commit to spending time together (the date, the assignment, the bet). |
| Midpoint | **Commitment test** — first emotional risk; first kiss; declaration of feelings. The relationship deepens. |
| Crisis | **The breakup** — usually because of a misunderstanding, a lie revealed, or an external pressure forcing separation. |
| Showdown | **The grand gesture** — one lead pursues the other (the airport, the wedding, the rain). |
| Realization | They each name what they learned — about themselves, about love, about what was blocking them. |

**Genre-specific signature:** the **misunderstanding / withheld
information** that triggers the Crisis breakup. Plant it earlier; pay
it off at the Crisis.

### Action / adventure

| Beat | Conventional content |
|---|---|
| Catalyst | The mission is given OR the inciting violence is committed. |
| Big Event | Protagonist commits to the mission (often against orders or expectations). |
| Midpoint | **Set piece reversal** — the biggest action sequence of Act 2. The protagonist's plan changes. |
| Crisis | **Lowest physical point** — wounded, captured, isolated, or the team is broken. |
| Showdown | **Final set piece** — biggest of the script. Geography legible, gearing maxed. |
| Realization | The cost is named — what the protagonist gave up, what they earned. |

**Genre-specific signature:** **set-piece spacing** — major action
sequences land approximately every 15-20 pages. Each escalates in
scale and stakes (the **gearing** rule).

### Heist / caper

| Beat | Conventional content |
|---|---|
| Catalyst | The job is described (the target, the score, the deadline). |
| Big Event | The crew is assembled (often through a sequence of recruitment scenes). |
| Midpoint | **The plan is laid out** — a beat-by-beat walkthrough the audience uses as a roadmap. |
| Crisis | **Something goes wrong** during execution — a member is compromised, the timing fails, the target moves. |
| Showdown | The job's actual outcome — often differs from the plan in a way that reveals a hidden layer. |
| Realization | The **real plan** is revealed. The audience realises they were watching a different story all along. |

**Genre-specific signature:** **dual structure** — the audience is
shown the plan, then the execution diverges, then the *real* plan is
revealed. Plant the divergence early so the reveal lands as earned.

### Coming-of-age / teen drama

| Beat | Conventional content |
|---|---|
| Catalyst | An event marks the protagonist as no longer a child (a death, a betrayal, a discovery, a first sexual experience). |
| Big Event | Protagonist commits to a path that the adult world doesn't endorse. |
| Midpoint | **First adult act** — the protagonist makes a choice with adult-scale consequences. |
| Crisis | The cost of the adult act lands — the parent figure, the friendship, the romantic relationship is at risk. |
| Showdown | Confrontation with the adult world — the parent, the school, the institution. |
| Realization | What the protagonist is now becoming, and what they leave behind. |

**Genre-specific signature:** the **threshold moment** — a specific
scene where the protagonist crosses from child-perspective to
adult-perspective. Often a single image (a closed door, a worn-out
toy, a mirror).

### War / military

| Beat | Conventional content |
|---|---|
| Catalyst | Deployment, assignment, or first contact. |
| Big Event | The unit's mission is named. Stakes are personal as well as strategic. |
| Midpoint | **The cost is shown** — major loss, betrayal of trust, or moral compromise. The war stops being abstract. |
| Crisis | The mission appears unwinnable; protagonist's leadership / judgment / loyalty is tested. |
| Showdown | The defining engagement. Often pyrrhic. |
| Realization | What the survivors carry home (or what they've become). |

**Genre-specific signature:** the **moral compromise** at the
Midpoint — a moment where doing the right tactical thing requires
doing the wrong human thing.

### For other genres

If the script's genre isn't listed above, the engine applies the
universal Magnificent 7 anchoring without genre-specific structural
overlays. Flag at delivery: *"Genre {X} doesn't have a structural
beat overlay in the engine. Applied universal Magnificent 7 anchoring
only. Name a reference film and I'll calibrate to its specific
structure if you'd like."*

## Quality Gate

After completing the screenplay, run these checks:

### Format Compliance
- [ ] All scene headings use INT./EXT. + LOCATION + DAY/NIGHT (or CONTINUOUS / MOMENTS LATER / LATER / SAME)
- [ ] No camera directions in any slugline (WIDE SHOT, CLOSE ON, AERIAL, POV, etc.)
- [ ] No parentheticals in any slugline (era, weather, mood)
- [ ] No re-establishing of master locations already established in a previous scene
- [ ] No MORNING / AFTERNOON / EVENING / LATE NIGHT in sluglines (those qualities go in action lines)
- [ ] INTERCUT / INSERT / SUPER / FLASHBACK / MONTAGE used per the rules of restraint (Sluglines special variants)
- [ ] Character names CAPS on first appearance in action
- [ ] No scene numbers (spec script)
- [ ] No camera directions in action lines (unless story-essential)
- [ ] Sound cues follow the project's chosen convention (modern spec default = no automatic CAPS; CAPS reserved for story-beat sounds only — see Action Lines)
- [ ] No "CUT TO:" between scenes (unless a specific stylistic choice)
- [ ] No CONTINUED at page breaks
- [ ] Action paragraphs match the Tone-and-Style preset target (see S5 mechanical configuration table)
- [ ] Action paragraphs max 4 lines (hard cap regardless of preset)
- [ ] Dialogue-to-action ratio within ±10% of the Tone-and-Style preset target
- [ ] White space density within ±5% of the Tone-and-Style preset target
- [ ] Parentheticals used sparingly (fewer than 1 per page average)
- [ ] V.O. budget respected (≤3–4 blocks per 30 pages)
- [ ] V.O. and O.S. used per their distinct definitions (see V.O. vs O.S.)
- [ ] Title page complete: Title, Credit, Author, Source (if adapting), Draft date, Contact

### Craft Compliance
- [ ] All action lines present tense
- [ ] No "we see" / "we hear" / "begins to" / "suddenly"
- [ ] Adverb count in action lines ≤ 2 per page average
- [ ] No fortune-telling narration ("what would later become…", "if she had known…")
- [ ] No editorialising adverbs ("amazingly", "of course", "interestingly")
- [ ] No stage-direction-as-exposition ("the room shows that…", "suggesting…")
- [ ] No action-paragraph anaphora (no 3+ consecutive paragraphs starting with same character name)
- [ ] No camera-direction smuggling in action lines ("we focus on", "the camera lingers on")
- [ ] No unfilmable content (thoughts, feelings described as internal states)
- [ ] **No AI-tell patterns in action lines** (see AI-Tell Patterns section AND Pre-Delivery AI-Tell Sweep below)
- [ ] Every scene enters late and leaves early
- [ ] Every scene has conflict and a turn
- [ ] Dialogue has subtext — no on-the-nose exposition
- [ ] No exposition crutches in dialogue ("As you know", "As we discussed", "Remember when")
- [ ] No dialogue lines that tell emotional state ("I'm angry", "I'm sad")
- [ ] No dialogue blocks longer than 5 lines (unless a deliberate set-piece, max 8)
- [ ] No greetings/farewells (Hello / Goodbye / How are you / Take care)
- [ ] Filler words (OK, well, yeah, you know) ≤ 1 of each per page on average
- [ ] No accidental catchphrase repetition (no character verbal tic used 3+ times without intent)
- [ ] **No derivative dialogue** — every line passes the "could 5+ characters speak this?" test
- [ ] **Profanity density per character** ≤ ~1 per 2 pages (genre exceptions noted); variance across characters confirmed
- [ ] **Maid-and-butler test passed** — no exchange where both characters already know what's being said and the line exists for the audience
- [ ] **No talking heads** — every scene with 5+ dialogue exchanges has at least one action beat; the climax/confrontation has meaningful physical activity
- [ ] **Scene Construction** — every scene has emotional centre, motivated conflict, escalating turns, and a punch at the end (4-element rule)
- [ ] **Character Architecture** — every protagonist and primary antagonist has Want / Need / Flaw / Backstory captured before scene generation
- [ ] **Flaw is tested at 3 structural points** — early Act 2, Crisis, Showdown
- [ ] **All 7 plot points land on time** (Backstory seeded by ~30%; Catalyst, Big Event, Midpoint, Crisis, Showdown, Realization at format-scaled page targets)
- [ ] **Midpoint is a genuine turn**, not just a beat at 45–50%
- [ ] **Crisis ≠ Showdown** — separated by 10–15% of pages; Crisis is decision, Showdown is action
- [ ] **Realization** — protagonist consciously accepts the Need (or explicit tragic-arc flag if not)
- [ ] **CAPS audit** — ≤ 3 CAPPED tokens per page in action lines (excluding character first-appearances, slugline prefixes, SUPER content)
- [ ] **Genre structural beats** — if the script's genre has a structural overlay (Cozy mystery / Thriller / Horror / Romance / Action / Heist / Coming-of-age / War), the genre's specific Magnificent-7 content is honoured (see Genre-Specific Structural Beats)
- [ ] **Action sequences** — chase / fight / set-piece scenes use the action-sequence craft rules (1-line paragraphs during fast action, beat-by-beat clarity, geographic clarity, gearing, reaction shots)
- [ ] **Comedy craft** — if genre is Comedy or Romantic Comedy, setup/payoff structure and Rule of Threes (or rule of two) are applied; no joke-stacking; no joke-explanation
- [ ] **Specialty scenes** — sex / violence / death / courtroom / funeral / wedding scenes follow the specific craft conventions (taste, restraint, reaction-shot focus, specificity over generality)
- [ ] **V.O. style** — if V.O. is used, a single style is established by page 1 and held throughout (or any style mix is dramatically justified)
- [ ] **Character demographics** — race / ethnicity / gender / sexuality / disability handled per modern industry convention (specified thoughtfully, authentically, not as caricature, not as decoration)
- [ ] **Page-One Test passed** — protagonist, world, tone, central question, reader's commitment all established by page 3
- [ ] **Read-aloud check passed** — opening dialogue, climax dialogue, and opening action read cleanly aloud
- [ ] Character voices are distinct (blind identification test)
- [ ] White space target met per Tone-and-Style preset

### Multi-Track Compliance (Patterns B / C / D only)
- [ ] Every POV character / track introduced in the opening 15 pages
- [ ] No POV character / track absent for more than 25 consecutive pages without an explicit user warning
- [ ] Per-character page allocation matches the beat sheet plan (within ±10%)
- [ ] Pattern C: explicit intersection beat at midpoint
- [ ] Pattern C: convergence beat at climax
- [ ] Pattern D: no single character occupies more than ~25% of dialogue lines

### Timing Compliance
- [ ] Total page count within target range for format
- [ ] Act breaks at correct page positions (if applicable)
- [ ] Beat sheet targets hit within 2-3 page tolerance
- [ ] Action/dialogue balance appropriate for genre

### Adaptation Compliance (Mode B/C only)
- [ ] Spine preserved from source material
- [ ] Character consolidation approved by user
- [ ] Internal monologue converted to visual storytelling or V.O.
- [ ] No unfilmable prose carried over
- [ ] **No "novelistic" metaphor or psychological inference carried over** —
      prose-style sentences like *"There is something X about the way she
      moves"* or *"the timing of a woman who has been watching"* must be
      rewritten into camera-visible action when adapting from a manuscript
- [ ] Spirit and emotional truth of source maintained

### Story Logic Check
- [ ] Every plot event has a visible cause on screen — no unexplained knowledge
- [ ] If Character A knows something, the audience saw how they learned it
- [ ] Anonymous actions (notes, threats, theft) have a plausible mechanism
      the audience can reconstruct — if not, add a scene establishing it
- [ ] No character acts on information from a scene they weren't in
      (unless an on-screen information transfer occurred)
- [ ] Timeline is consistent — events happen in a logically possible order
- [ ] Every planted question is either answered or deliberately left open
      (flag deliberately open questions for Script Coverage to assess)

---

## Pre-Delivery AI-Tell Sweep (MANDATORY — BLOCKING)

The Quality Gate checklist above is necessary but not sufficient. Industry
readers spot AI-generated screenplays on **page one** because of two
specific signatures: bad sluglines and metaphor-as-inference action lines.
Run this sweep before delivery — it cannot be skipped.

### Pass 1 — Slugline scan

For every scene heading in the screenplay:

1. Does it match the strict slugline grammar from Craft Standards above?
   `INT.` / `EXT.` / `INT./EXT.` / `I/E.` + LOCATION + ` - ` + `DAY` / `NIGHT` / `CONTINUOUS` / `MOMENTS LATER` / `LATER` / `SAME` / (rare) `DAWN` / `DUSK`.
2. Does it contain a camera direction, parenthetical, time qualifier other
   than the permitted set, or era marker? **Rewrite.**
3. Does it re-establish a master location already established in the
   previous scene? **Narrow it to the specific sub-location.**

Any slugline that fails scan must be rewritten before delivery. No
exceptions.

### Pass 2 — Action-line AI-tell scan

For every action paragraph, scan for the **AI-Tell Patterns** listed in
Craft Standards. Specifically search for these literal substrings:

- `the timing of`
- `the economy of`
- `the care of`
- `the precision of`
- `the weight of [a / someone / her / his]`
- `the shape of [a / someone / her / his]`
- `there is something` / `there's something`
- `as if [she / he] [had / has been]`
- `in a way that suggests` / `in a way that implies` / `in a way that hints`
- `the kind of [woman / man / person / silence / look / smile] that`
- `the kind of [woman / man / person] who`

For every match, perform the rewrite using the rule from the AI-Tell
Patterns table: **show the literal action that would create that
inference**, and let the audience do the inferring. Do not delete the
action beat — replace the inference-prose with what the camera literally
sees in that moment.

### Pass 3 — Action-line amateur-tell scan

For every action paragraph, scan for the patterns in **Action Lines —
additional amateur tells**. Specifically search for:

- Adverb hits (`-ly` ending in action, excluding dialogue) — count per
  page; if any page exceeds 2, rewrite.
- Future-tense markers in action: `would later`, `if she had known`,
  `the last time`, `as we'll see`, `what was about to`. Rewrite to
  present-only.
- Editorialising tokens at sentence start: `Surprisingly`, `Of course`,
  `Amazingly`, `Interestingly`, `Tragically`. Cut.
- "Shows that" / "suggesting" / "implying" / "indicating that" inside
  set-description action. Show the detail; cut the inference clause.
- Action-paragraph anaphora: scan for 3+ consecutive paragraphs whose
  first word matches a character name. Rewrite to vary the subject.
- Camera-direction smuggling: `we focus on`, `we see`, `we hear`,
  `the camera lingers`, `our eye is drawn`. Rewrite to sentence-fragment
  focus or one-line action paragraph.

### Pass 4 — Dialogue anti-pattern scan

For every dialogue block, scan for:

- Exposition crutches: `As you know`, `As we discussed`, `Remember when`,
  `As I told you`. Rewrite (have the character act on the information
  instead, or cut).
- Telling emotional state lines: `I'm angry`, `I'm sad`, `I'm scared`,
  `I miss her`, `I'm confused`. Rewrite to subtext, deflection, or the
  behaviour the emotion produces.
- Long speeches: any single dialogue block exceeding 5 lines. Break
  with action beats or trim.
- Greetings/farewells at scene start or end: `Hello`, `Hi`, `How are
  you`, `Goodbye`, `Take care`. Cut and re-enter the scene later.
- Filler-word density: count `OK`, `Well`, `Yeah`, `You know` per page;
  if any one exceeds 1 per page on average, trim.
- Catchphrase repetition: any character verbal tic used 3+ times
  without an explicit intent flag in the Character Map. Vary or flag
  as intentional.

**Pass 4b — Maid-and-butler test (qualitative re-read):**

For every multi-line dialogue exchange, ask the Bible's question:
*"Do both of these characters already know what's being said?"* If
yes, the line exists for the audience. The fix is not always to cut —
it's often to redeliver the information through action, object,
visual evidence, or a much shorter exchange where one character
confirms what the other already half-knows. See the **Maid-and-butler
test** table in Craft Standards for symptom-to-fix patterns.

**Pass 4c — Derivative dialogue scan:**

For every dialogue line, cover the character cue mentally and ask:
*Could 5+ named characters in this script speak this line
interchangeably without breaking voice?* If yes, rewrite with
character-specific specificity (a reference, vocabulary, syntax, or
detail tied to that character's history or expertise — see the
**Derivative dialogue** entry in the Dialogue anti-patterns table).

Particular attention to confrontations, threats, declarations of
love, motivational speeches, and final-act reckonings — these are the
scene types where derivative writing concentrates because the writer
defaults to the genre's stock phrasings.

**Pass 4d — Profanity density check:**

For each named character, count profanity instances and divide by
that character's dialogue page count.

- Default cap: ~1 profanity per 2 pages of dialogue per character.
- Genre exceptions raise the cap: noir, war, prison, hard-boiled
  crime, gangster, military.
- **Cross-character variance check:** if every named character is at
  the same density (everyone swears 3 times per page), profanity is
  no longer characterising — it's the writer's default register.
  Vary by character: rank, background, register, the character who
  *doesn't* swear is as defining as the one who does.

**Test:** cover the character cue across all profane lines in the
script. Do they sound like the same person? If yes, redistribute.

### Pass 5 — Slugline variant misuse scan

For every special variant (INTERCUT / INSERT / SUPER / FLASHBACK /
MONTAGE):

- Confirm the variant is the right tool for the dramatic situation
  (per the Sluglines special variants table).
- Confirm restraint targets are met:
  - INTERCUT: only when scenes are truly simultaneous.
  - INSERT: only for an image the audience genuinely needs in close-up.
  - SUPER: ≤3 across the full screenplay.
  - FLASHBACK: ≤2 sequences across the full screenplay (otherwise
    consider chronological restructure).

### Pass 6 — Scene craft (construction, blocking, escalation)

For every scene, verify the **four mandatory elements** from Scene
Construction (Craft Standards):

1. **Emotional centre** — the POV character feels something specific
   at start and end (not "vaguely uneasy"). Flag scenes where neither
   bookend has a named emotion.
2. **Motivated conflict** — even minor scenes have opposition. Flag
   scenes where every character wants the same thing in the same way.
3. **Escalating turns** — beat 4 should pressure harder than beat 1.
   Flag scenes that flatline (beats with no escalation curve).
4. **Punch at the end** — the closing line/image/beat propels into
   the next scene. Flag scenes that close on a flat resolution
   instead of a propulsive moment.

**Talking-heads check (subset of #2 and #3):** for every scene with
**5+ dialogue exchanges**, confirm at least one **action beat**
appears between exchanges. An action beat is character movement,
gesture with intent, prop interaction, or environmental reaction.

For the **climax / confrontation / revelation** scene specifically,
the threshold drops to **3** — and the action must do work
(mirror / contrast / reveal / build per Craft Standards). A climax
delivered in chairs is the most damaging instance and gets a separate
flag.

**Fix protocol:** for any scene that fails the four-element check,
re-derive the scene from the **pre-write spine** (Scene Construction
section). Do not patch a flat scene with cosmetic action beats —
rebuild it.

### Pass 7 — Beat-anchoring verification (7 plot points)

Confirm all 7 of Trottier's plot points land on time per the Beat
Anchoring page-target table in the Writing Protocol:

| # | Beat | Verification |
|---|---|---|
| 1 | **Backstory** | The protagonist's defining wound is established (visual reference, dialogue, or one explicit reveal) by ~30% of pages. The backstory explains the Flaw. |
| 2 | **Catalyst** | A specific disrupting event has occurred by the catalyst page target. |
| 3 | **Big Event** | The protagonist has crossed into Act 2 by the Big Event target — they are *active*, not just observing. (This is the milestone we previously called "Goal Lock.") |
| 4 | **Midpoint** | A genuine *turn* lands at 45–50%. Verify it is a turn, not just a beat — something must shift (truth revealed, alliance broken, stakes raised, false victory exposed). A flat scene at the midpoint is a structural fail. |
| 5 | **Crisis** | The protagonist's Flaw produces a failure at 75–82%. This is a *decision moment* — the protagonist at their lowest, choosing whether to confront the Flaw or stay defeated. |
| 6 | **Showdown** | The climactic confrontation lands at 87–95%. The Crisis decision flows into action; external plot resolves. |
| 7 | **Realization** | The protagonist consciously accepts the Need (or, in tragic structure, fails to) during or immediately after the Showdown. Without a Realization, the climax feels physically resolved but emotionally hollow. |

**Cross-check with Character Architecture:**

- The Flaw is tested at 3 structural points (early Act 2, Crisis, Showdown). Verify each.
- The Need surfaces at the Midpoint and is consciously named at the Realization. Verify continuity.
- The Backstory is *seeded* (visual references, off-hand dialogue, one explicit reveal) — never dumped in a flashback monologue.

If the script fails any milestone, the rewrite is structural. The
Pass 7 report names the failed beats, the actual page where the
nearest equivalent landed, and the page where it should have landed.

### Pass 8 — CAPS audit (≤ 3 per page)

Trottier's spec-script CAPS rule: minimal CAPS. Permitted:
- Character names on first appearance in action lines (mandatory).
- Sounds — *only* when the engine's sound-cue convention is
  "shooting-script" (per S5 setting); modern-spec default is lowercase
  for ambient sound, CAPS reserved for story-beat sounds.
- SUPER text — `SUPER: "TWO YEARS LATER"`.
- Slugline / scene heading prefixes (INT./EXT.) — these are part of
  the format and don't count toward the cap.

Forbidden:
- Props or objects in CAPS for "emphasis" (shooting-script convention,
  amateur signal).
- Setting elements in CAPS (`THE LARGE BAY WINDOW`, `THE OAK DESK`).
- Action verbs in CAPS for emphasis (`She SLAMS the door` if the
  sound-cue convention is modern-spec).

**Detection:** count CAPPED tokens per page in action lines (excluding
slugline prefixes, character first-appearances, SUPER content). If any
page exceeds **3 CAPPED tokens**, flag for review.

**Fix:** lower-case anything that isn't a character first-appearance,
a story-beat sound (only if that convention is enabled), or SUPER text.

### Pass 9 — Page-One Test (formal opening criteria)

The first 3 pages of the script decide whether a reader keeps reading.
Industry readers — and most agents and managers — will form an opinion
inside the opening before they commit to the rest. Pass 9 verifies the
opening accomplishes the five things every reader looks for.

For pages 1–3, confirm each of the following has landed:

| # | Criterion | Detection |
|---|---|---|
| 1 | **Protagonist established** | A named character has appeared in action, with a brief vivid descriptor and a hint of personality / agency. The reader knows who to follow. |
| 2 | **World established** | Where, when, what's normal in this world. Setting is specific (one location, one rendered moment) — not a montage of scenes setting up the universe. |
| 3 | **Tone established** | The reader can name the genre (or recognisable hybrid) by page 3. Voice, rhythm, and visual specificity match the Tone-and-Style preset (S5). |
| 4 | **Central question hinted** | Something is *off*, *at stake*, *unresolved*, or *implied* — the dramatic question the script will explore. Need not be the Catalyst yet; just the seed. |
| 5 | **Reader's commitment earned** | After page 3, the reader has a reason to turn to page 4. Not "what is this?" but "I want to see what happens." |

**Detection:**
- For each criterion, identify the specific scene / line / image that
  satisfies it. If unsatisfied, name what's missing.
- Common Page-One failures:
  - Opens on weather, geography, or atmospheric description with no
    character (criterion 1 fails)
  - Opens with V.O. exposition explaining the world (criteria 1, 2, 5
    weak — exposition is not earned commitment)
  - Opens on dream/flashback (almost always a craft failure; flag)
  - Opens on a wide montage of every world the script will visit
    (criterion 2 fails — pick *one* world)
  - Opens on dialogue between two characters whose relationship the
    audience doesn't yet care about (criterion 5 weak)

**Fix:** Page-One failures are structural. The fix is rewriting the
opening to deliver the five criteria in pages 1–3, not patching the
existing opening. The opening sequence must earn the read.

### Pass 10 — Read-aloud + Filmability re-read

Final pass before delivery. Combines two activities: read the script
aloud (in your head), and re-read for filmability.

**Read-aloud check (dialogue):**

For every dialogue line in the first 10 pages and every dialogue line
in the climax sequence:

- **Read it aloud.** Does it trip off the tongue, or does it stumble?
- Flag any line that:
  - Requires a second pass to parse (the actor will stumble too)
  - Sounds written, not spoken (formal syntax in casual contexts;
    perfect grammar where colloquial would land)
  - Has consonant clusters or rhythmic awkwardness ("the prerequisite
    statistical aggregation" — say it aloud and you hear the problem)
  - Sounds nothing like the character's established voice
- Rewrite flagged lines to match natural speech for that character.

**Read-aloud check (action lines):**

For every action paragraph in the first 5 pages and every action
paragraph in the climax sequence:

- **Read it aloud.** Does it parse on first read? Does the reader's
  eye stumble at any clause?
- Flag any sentence that:
  - Requires a re-read to understand
  - Has nested clauses (the action gets buried)
  - Has metaphor that lands as inference (the AI-tell family — Pass 2
    should have caught these, but Pass 10 is the safety net)

**Filmability re-read:**

Re-read the entire first 3 pages and the climax. For every action
sentence, ask: *Could a director and a camera operator and an actor
produce exactly this, with nothing inferred from prose?* If a sentence
requires the audience to infer psychology, history, or quality,
rewrite it.

The first three pages decide whether a reader keeps going (Pass 9
verified the opening; Pass 10 confirms it reads aloud cleanly). Most
professional readers will quit on page one if AI-tells, awkward
dialogue, or unfilmable description are present. Pass 10 is the
non-negotiable final gate.

---

## Output

Deliver the completed screenplay in all requested formats:

1. **Fountain (.fountain)** — plain-text file, compatible with all screenplay software
   See `format-fountain.md` for the generation template.

2. **PDF** — formatted screenplay PDF using Courier 12pt, industry margins
   Generated from the Fountain source.

3. **DOCX** — Word document with Courier 12pt formatting for users who prefer Word

Additionally deliver:
- **Beat Sheet** — the structural outline used to generate the screenplay, with all 7 plot points anchored to page numbers
- **Character Map** — all characters with descriptions and first appearance, including Want / Need / Flaw / Backstory for protagonist and primary antagonist
- **Series Bible** (TV projects only)
- **Industry Submission Packet** — see `screenplay-deliverables.md` for the full set: logline, query letter, one-sheet, short treatment, 25-Checkpoint Revision Checklist, and Production Notes. Generated automatically alongside the screenplay; user can decline any.

## Polish Note — Show This With Every Delivery

After delivering the screenplay, show the user this exact block:

```
─────────────────────────────────────────────────────────
This is a complete first draft that has passed Format,
Craft, Story Logic, and AI-Tell sweeps. For industry
submission (manager, agent, festival, contest, production
company), expect a final human polish pass — typically
20% of total work for an 80% AI draft.

Highest-value polish targets, in order:

  1. Dialogue idiom — read aloud in each character's voice
     and tighten any line that sounds like a writer wrote
     it rather than the character speaking it.
  2. Voice contrast — cover the character cues and re-read
     a few exchanges. Can you tell who's talking? If not,
     sharpen the weaker voice.
  3. Action-line verbs — replace any verb that's "fine" with
     the verb that's exactly right. "Walks" / "moves" /
     "looks" are placeholder verbs.
  4. Scene-end / scene-open seams — every scene should enter
     late and leave early. Trim the first or last beat of
     scenes that feel padded.

Run Script Coverage next to identify the highest-value
revision opportunities — it will give you a RECOMMEND /
CONSIDER / PASS verdict and a ranked top-issues list.
─────────────────────────────────────────────────────────
```

## Post-Completion: Script Coverage

After the screenplay is complete, automatically offer to run **Script Coverage** —
the screenplay equivalent of Alpha/Beta Reader reports.

See `script-coverage.md` for the full protocol.

Script Coverage runs two passes:
1. **Development Coverage** — general story/craft assessment (like Alpha Reader)
2. **Industry Coverage** — genre expert/market viability assessment (like Beta Reader)

Both deliver as `.docx` files with professional formatting, coverage grids,
scene-by-scene analysis, and a RECOMMEND / CONSIDER / PASS recommendation.
