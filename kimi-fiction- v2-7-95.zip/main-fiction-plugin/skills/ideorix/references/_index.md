---
name: genre-index
description: "Master index of all available genres"
user-invocable: false
---

# Genre Bank. Index

## How to Use

When the user selects a genre, read the corresponding file from its category subfolder.
Each file contains genre-specific instructions for ALL agents in the pipeline.

**Category folders:**
- `mystery-crime/`. Mystery & Crime genres
- `romance/`. Romance genres
- `fantasy-scifi/`. Fantasy & Sci-Fi genres
- `literary-contemporary/`. Literary & Contemporary genres
- `horror-gothic/`. Horror & Gothic genres
- `historical-adventure/`. Historical & Adventure genres
- `ya-childrens/`. YA & Children's genres
- `other/`. Other genres

## Available Genres

### Mystery & Crime
| ID | Name | File | Status |
|----|------|------|--------|
| cozy-mystery | Cozy Mystery | cozy-mystery.md | Ready |
| mystery | Mystery | mystery.md | Ready |
| domestic-thriller | Domestic Thriller | domestic-thriller.md | Ready |
| psychological-thriller | Psychological Thriller | psychological-thriller.md | Ready |
| thriller | Thriller | thriller.md | Ready |
| crime | Crime Fiction | crime.md | Ready |
| noir | Noir | noir.md | Ready |
| espionage | Espionage | espionage.md | Ready |
| legal-thriller | Legal Thriller | legal-thriller.md | Ready |
| speculative-mystery | Speculative Mystery | speculative-mystery.md | Ready |

### Fantasy & Sci-Fi
| ID | Name | File | Status |
|----|------|------|--------|
| fantasy | Fantasy | fantasy.md | Ready |
| epic-fantasy | Epic Fantasy | epic-fantasy.md | Ready |
| urban-fantasy | Urban Fantasy | urban-fantasy.md | Ready |
| dark-fantasy | Dark Fantasy | dark-fantasy.md | Ready |
| romantasy | Romantasy | romantasy.md | Ready |
| science-fiction | Science Fiction | science-fiction.md | Ready |
| space-opera | Space Opera | space-opera.md | Ready |
| dystopian | Dystopian | dystopian.md | Ready |
| cyberpunk | Cyberpunk | cyberpunk.md | Ready |
| steampunk | Steampunk | steampunk.md | Ready |
| paranormal | Paranormal | paranormal.md | Ready |
| litrpg | LitRPG | litrpg.md | Ready |
| cozy-fantasy | Cozy Fantasy | cozy-fantasy.md | Ready |
| occult-magic | Occult & Magic | occult-magic.md | Ready |
| historical-fantasy | Historical Fantasy | historical-fantasy.md | Ready |

### Romance
| ID | Name | File | Status |
|----|------|------|--------|
| romance | Contemporary Romance | romance.md | Ready |
| historical-romance | Historical Romance | historical-romance.md | Ready |
| dark-romance | Dark Romance | dark-romance.md | Ready |
| gothic-romance | Gothic Romance | gothic-romance.md | Ready |
| horror-romance | Horror Romance | horror-romance.md | Ready |
| romantic-comedy | Romantic Comedy | romantic-comedy.md | Ready |
| romantic-suspense | Romantic Suspense | romantic-suspense.md | Ready |
| romantic-thriller | Romantic Thriller | romantic-thriller.md | Ready |
| sport-romance | Sport Romance | sport-romance.md | Ready |
| western-romance | Western Romance | western-romance.md | Ready |
| paranormal-romance | Paranormal Romance | paranormal-romance.md | Ready |
| erotica | Erotica | erotica.md | Ready |

### Literary & Contemporary
| ID | Name | File | Status |
|----|------|------|--------|
| general | General Fiction | general.md | Ready |
| literary | Literary Fiction | literary.md | Ready |
| contemporary | Contemporary Fiction | contemporary.md | Ready |
| womens-fiction | Women's Fiction | womens-fiction.md | Ready |
| coming-of-age | Coming of Age | coming-of-age.md | Ready |
| family-saga | Family Saga | family-saga.md | Ready |
| upmarket | Upmarket Fiction | upmarket.md | Ready |
| dark-academia | Dark Academia | dark-academia.md | Ready |
| lgbtq-fiction | LGBTQ+ Fiction | lgbtq-fiction.md | Ready |
| religious-fiction | Religious Fiction | religious-fiction.md | Ready |

### Horror & Gothic
| ID | Name | File | Status |
|----|------|------|--------|
| horror | Horror | horror.md | Ready |
| gothic | Gothic | gothic.md | Ready |
| gothic-horror | Gothic Horror | gothic-horror.md | Ready |
| supernatural | Supernatural | supernatural.md | Ready |
| vampire | Vampire Fiction | vampire.md | Ready |
| zombie | Zombie Fiction | zombie.md | Ready |

### Historical & Adventure
| ID | Name | File | Status |
|----|------|------|--------|
| historical | Historical Fiction | historical.md | Ready |
| adventure | Action Adventure | adventure.md | Ready |
| western | Western | western.md | Ready |
| war | War Fiction | war.md | Ready |
| survival | Survival Fiction | survival.md | Ready |

### YA & Children's
| ID | Name | File | Status |
|----|------|------|--------|
| middle-grade | Middle Grade | middle-grade.md | Ready |
| ya-contemporary | YA Contemporary | ya-contemporary.md | Ready |
| ya-fantasy | YA Fantasy | ya-fantasy.md | Ready |

### Other
| ID | Name | File | Status |
|----|------|------|--------|
| drama | Drama | drama.md | Ready |
| satire | Satire | satire.md | Ready |
| magical-realism | Magical Realism | magical-realism.md | Ready |
| cli-fi | Climate Fiction | cli-fi.md | Ready |
| afrofuturism | Afrofuturism | afrofuturism.md | Ready |
| comedy | Comedy Fiction | comedy.md | Ready |
| fan-fiction | Fan Fiction | fan-fiction.md | Ready |

## Genre File Format

Every genre file follows the same structure (see ARCHITECTURE.md for full spec):

```
# [Genre Name]. Genre Plugin
## Metadata
## Architect Instructions
## Writer Craft Rules
## Quality Check Criteria
## Continuity Rules
## Character Rules (optional)
## Arc Rules (optional)
## Timeline Rules (optional)
## Genre-Specific Craft Techniques
## Genre-Specific Revision Rules
## Names & Patterns to Avoid
```

## Creating New Genre Plugins

Users can create their own custom genres via the **Custom Genre Builder**
(see `genre-builder.md`). a guided interview that produces a fully-formed
genre file, optionally inheriting from 1–3 built-in parents as a scaffold.
The builder is reachable from Phase 1 Question 1 (option 9: "Build a
custom genre") or via direct trigger phrases like "build a custom genre".

Custom genre files live in one of:
- `~/Documents/Ideorix-Projects/{Title}/engine-data/custom-genres/{slug}.md` (project-local)
- `~/Documents/Ideorix-Projects/.genre-library/{slug}.md` (cross-project library)

The Genre Bank Loading Protocol (see `core-pipeline.md`) checks custom
paths BEFORE the built-in bank, so custom genres with the same slug as a
built-in shadow the built-in. The builder warns and refuses slug collisions
by default.

For maintainers adding a new BUILT-IN genre to this index:
1. Copy an existing genre file as a template
2. Replace all genre-specific content
3. Reference Ideorix's `src/genreTemplates.js` for the corresponding genre's
   agent instructions (architectInstructions, writerCraftRules, etc.)
4. Add genre-specific craft techniques and revision rules
5. Update this index file
6. Test with a sample chapter generation

## Cross-Genre Inheritance System

Many genres share DNA with other genres. Rather than duplicating rules across
multiple genre files, the engine supports genre inheritance. where a genre
inherits from one or more parent genres and adds its own specialisations.

**Why this exists:** Genre hybrids (romantic-suspense, gothic-horror, dark-fantasy)
need rules from multiple genres simultaneously. Without inheritance, each hybrid
genre file must copy-paste shared rules, creating maintenance burden and
inconsistency. With inheritance, a hybrid loads its parent genres' rules
automatically and only defines its own overrides.

### Inheritance Map

Each genre's parent(s) are defined here. When loading a genre, the engine should:
1. Load ALL parent genre rules first (in order listed)
2. Load the specific genre's rules on top (overrides parents on conflict)
3. Merge AI Crutch Phrase tables (combine all parents + own. no deduplication needed)
4. On rule conflict: the MOST SPECIFIC genre wins (child > parent)

```
INHERITANCE DEFINITIONS:

# Mystery & Crime family
mystery            → [general]
cozy-mystery       → [mystery]
crime              → [mystery]
noir               → [crime]
legal-thriller     → [thriller, crime]
espionage          → [thriller]
speculative-mystery → [mystery, science-fiction]
domestic-thriller  → [thriller, drama]
psychological-thriller → [thriller]

# Fantasy family
fantasy            → [general]
epic-fantasy       → [fantasy]
dark-fantasy       → [fantasy, horror]
urban-fantasy      → [fantasy, contemporary]
cozy-fantasy       → [fantasy]
historical-fantasy → [fantasy, historical]

# Sci-Fi family
science-fiction    → [general]
cyberpunk          → [science-fiction]
space-opera        → [science-fiction]
steampunk          → [science-fiction, historical]
dystopian          → [science-fiction]
litrpg             → [fantasy, science-fiction]

# Romance family
romance            → [general]
romantic-comedy    → [romance, comedy]
romantic-suspense  → [romance, thriller]
romantic-thriller  → [romance, thriller]
paranormal-romance → [romance, paranormal]
sport-romance      → [romance, contemporary]
western-romance    → [romance, western]
gothic-romance     → [romance, gothic]
horror-romance     → [romance, horror]
historical-romance → [romance, historical]
dark-romance       → [romance]
erotica            → [romance]
romantasy          → [romance, fantasy]

# Literary family
literary           → [general]
contemporary       → [general]
upmarket           → [literary, contemporary]
womens-fiction     → [contemporary]
dark-academia      → [literary, thriller]
coming-of-age      → [contemporary]
family-saga        → [drama]
drama              → [general]
lgbtq-fiction      → [contemporary]
religious-fiction  → [literary]

# Horror family
horror             → [general]
gothic             → [horror]
gothic-horror      → [gothic, horror]
vampire            → [horror, paranormal]
zombie             → [horror, survival]
paranormal         → [general]
supernatural       → [paranormal]
occult-magic       → [paranormal, fantasy]

# Historical & Adventure
historical         → [general]
adventure          → [general]
western            → [historical, adventure]
war                → [historical]
survival           → [adventure]

# YA & Children's
middle-grade       → [general]
ya-contemporary    → [contemporary, coming-of-age]
ya-fantasy         → [fantasy, coming-of-age]

# Other
satire             → [literary, comedy]
comedy             → [general]
magical-realism    → [literary, fantasy]
cli-fi             → [science-fiction, literary]
afrofuturism       → [science-fiction]
fan-fiction         → [general]
```

### How Agents Use Inheritance

**Current behaviour (no change required):** Each genre file is self-contained
and includes all rules needed. The inheritance map above documents the
CONCEPTUAL relationships for:

1. **Genre selection guidance:** When a user's story spans multiple genres,
   the inheritance map helps identify which genre file best fits. A story
   that's "romance + thriller" should use `romantic-thriller` (which inherits
   from both) rather than loading two separate genre files.

2. **Gap detection:** If a genre file is missing rules that its parent has,
   the inheritance map identifies the gap. Maintainers can check whether
   child genres cover all parent rules.

3. **Crutch phrase accumulation:** When the Humaniser runs, it should check
   crutch phrases from BOTH the selected genre AND its parents. A
   `romantic-suspense` story should avoid romance crutch phrases AND
   thriller crutch phrases. Load the crutch phrase tables from the
   inheritance chain and merge them.

4. **New genre creation:** When creating a new genre file, start by copying
   the primary parent genre and then adding specialisations, rather than
   starting from scratch.

### Genre Mash-Up Mode (1, 2, or 3 genres)

Users can build a story from **one, two, or three** genre files at once. This
lets writers create hybrids that don't exist as curated files. "cyberpunk
western," "cozy horror," "legal thriller romantasy". by stacking the rule
sets from multiple genre files into a single active rulebook.

**How the user reaches it:** The Mash-Up option appears as a sub-step of
Question 1 (Genre) during Phase 1 setup. After picking a primary genre, the
engine asks "Want to mash this with another genre?" (1–2 more, or continue
with just the primary).

---

#### Roles

| Slot | Required? | Purpose |
|------|-----------|---------|
| **Primary** | Always | The dominant genre. Sets the default word-count tier, Story Bible template, cover style, and conflict-winning rule. |
| **Secondary** | Optional | Adds its craft rules, crutch phrases, and quality checks. Loses to Primary on conflict. |
| **Tertiary** | Optional | Same as Secondary. Loses to Primary and Secondary on conflict. |

No more than 3 slots. Beyond 3, rule sets become incoherent and the crutch-
phrase list explodes. the engine will refuse a 4th genre and ask the user
to pick a stronger Primary instead.

---

#### Pre-Flight Check: Curated Hybrid Detection

**Before accepting a mash-up, the engine MUST check if a curated hybrid
already exists**. many combinations are pre-built in the genre bank
and will always be stronger than an ad-hoc merge because their rules
have been hand-tuned for the combination.

Check the Inheritance Map above. If the user picks two genres that match
an existing hybrid's parent list, suggest it:

```
You picked Romance + Thriller. There's already a curated hybrid for this
combination: Romantic Thriller (romantic-thriller.md). It has hand-tuned
rules for how the romance and thriller arcs interact.

→ Use Romantic Thriller (recommended)
→ Continue with your ad-hoc Romance + Thriller mash-up anyway
```

Known curated hybrids (user should be offered these BEFORE ad-hoc mash-up):

| User picks… | Suggest curated hybrid |
|---|---|
| Romance + Thriller | romantic-thriller |
| Romance + Suspense/Thriller | romantic-suspense |
| Romance + Gothic | gothic-romance |
| Romance + Horror | horror-romance |
| Romance + Paranormal | paranormal-romance |
| Romance + Fantasy | romantasy |
| Romance + Comedy | romantic-comedy |
| Romance + Historical | historical-romance |
| Romance + Western | western-romance |
| Romance + Sport | sport-romance |
| Fantasy + Horror | dark-fantasy |
| Fantasy + Contemporary | urban-fantasy |
| Fantasy + Historical | historical-fantasy |
| Fantasy + Science Fiction (any) | litrpg (if progression-driven) |
| Cozy + Fantasy | cozy-fantasy |
| Cozy + Mystery | cozy-mystery |
| Mystery + Thriller | consider psychological-thriller, legal-thriller, or domestic-thriller |
| Mystery + Science Fiction | speculative-mystery |
| Science Fiction + Historical | steampunk |
| Horror + Gothic | gothic-horror |
| Horror + Survival | zombie |
| Horror + Paranormal | vampire or supernatural |
| Literary + Comedy | satire |
| Literary + Fantasy | magical-realism |
| Literary + Thriller | dark-academia |
| Science Fiction + Climate | cli-fi |
| YA + Contemporary + Coming-of-age | ya-contemporary |
| YA + Fantasy + Coming-of-age | ya-fantasy |

If no curated hybrid exists for the combination (e.g. "cozy + horror",
"western + cyberpunk", "noir + cozy fantasy"), proceed with the ad-hoc
mash-up described below.

---

#### Loading Rules

When a mash-up is active, the Genre Bank Loading Protocol (see
`core-pipeline.md`) iterates over the active genre list in order.
Primary, then Secondary, then Tertiary. and merges the following sections:

| Section | Merge Strategy |
|---------|----------------|
| Architect Instructions | Concatenate all, Primary first. Each block prefixed with `### From {genre_name}:` for traceability. |
| Writer Craft Rules | Concatenate all, Primary first. |
| Quality Check Criteria | **Union**. every criterion from every genre must pass. Conflicting thresholds: use Primary's. |
| Continuity Rules | Concatenate all, Primary first. |
| Character Rules | Concatenate all, Primary first. |
| Arc Rules | Concatenate all, Primary first. |
| Timeline Rules | Concatenate all, Primary first. |
| Genre-Specific Craft Techniques | Concatenate all, Primary first. |
| Genre-Specific Revision Rules | Concatenate all, Primary first. |
| Names & Patterns to Avoid | **Union**. every avoided name from every genre is avoided. |
| AI Crutch Phrases | **Union**. every crutch phrase from every genre is banned. If the same phrase appears in multiple genres, the strictest limit applies (lowest allowed frequency wins). |
| Metadata (word counts, icon, cover style) | Primary only. |
| Subgenre Options | Primary only. |
| Cover Design Specifications | Primary only. Secondary/tertiary styles may be offered as alternatives in the cover phase. |

#### Conflict Resolution

When two genres specify contradictory rules (e.g., horror requires escalating
dread; cozy forbids dread):

1. **Primary wins by default.** Its rule is applied.
2. **Exception. Quality Checks and Crutch Phrases are UNIONS, not overrides.**
   A mash-up must pass all of them. If the user picks two genres with
   genuinely incompatible quality checks (cozy's no-gore rule vs. horror's
   body-count expectation), the Architect surfaces the conflict during
   Phase 1 approval and asks the user to choose which rule holds. or to
   drop one of the genres.

3. **Word count target:** Primary's tier is the default. If the user
   selected a length tier in Q6 that's incompatible with Primary (e.g.,
   Novelette + Epic Fantasy Primary), the existing length-tier warning
   still applies. mash-up does not change that check.

#### Story Bible Extension

The Story Bible Extension (Section 15 of the Story Bible) uses the
**Primary** genre's template, with additional sub-sections appended for
each Secondary and Tertiary genre. For example, a mash-up of
`domestic-thriller` (Primary) + `psychological-thriller` (Secondary) +
`gothic` (Tertiary) produces:

```
Section 15: Genre-Specific Story Bible Extension
  15.1 Domestic Thriller Architecture  (from Primary)
  15.2 Psychological Thriller Layer    (from Secondary)
  15.3 Gothic Atmosphere Layer         (from Tertiary)
```

#### Outline Builder Behaviour

When the Outline Builder runs with an active mash-up, it asks the
genre-specific question set for EACH active genre (deduped), and it
runs the matching genre architecture modules for each (e.g., revelation
map for thriller, relationship arc for romance, growth ladder for
fantasy). See `outline-builder.md` for the mash-up handling.

#### Humaniser Behaviour

The Prose Humaniser loads crutch phrases from all active mash-up genres
AND from each of those genres' inheritance chains. A mash-up of
`noir` + `cozy-fantasy` loads crutch phrases from:
- noir.md, crime.md, mystery.md, general.md (noir's inheritance chain)
- cozy-fantasy.md, fantasy.md, general.md (cozy-fantasy's inheritance chain)

See `prose-humaniser.md` for details.

#### Project Storage

When a mash-up is active, `engine-data/project-config.md` records it as:

```markdown
Genre: primary-genre-id + secondary-genre-id + tertiary-genre-id
Mash-up: yes
  Primary: {display name}
  Secondary: {display name or "none"}
  Tertiary: {display name or "none"}
```

This lets the engine restore the mash-up on project return.
