---
name: lgbtq-fiction-genre
description: "Genre-specific instructions for LGBTQ+ Fiction. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
---

# LGBTQ+ Fiction. Genre Plugin

## Metadata
- **Genre ID:** lgbtq-fiction
- **Display Name:** LGBTQ+ Fiction
- **Category:** Literary & Contemporary
- **Tier:** Hybrid/Crossover
- **Target Word Count:** 4,000–4,500 per chapter
- **Min Word Count:** 3,500
- **Recommended Beat Structures:** Story Circle, Three-Act Structure, Romancing the Beat, Freytag's Pyramid

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Coming-Out Narrative | Journey of self-discovery and disclosure | Identity arc central; multiple coming-out scenes; self-acceptance pacing |
| LGBTQ+ Romance | Love story with queer protagonists | Romance structure with identity-specific obstacles; HEA/HFN expected |
| Established Identity | LGBTQ+ character in non-identity plot | Identity present through relationships and context; plot drives forward |
| Historical LGBTQ+ | Queer lives in historical settings | Era-accurate dangers, communities, and language; survival stakes |
| Queer Coming-of-Age | Youth navigating identity discovery | Age-appropriate exploration; first attractions; school/family dynamics |
| Intersectional | Multiple marginalised identities centred | Race, class, disability alongside queerness; unique compound experiences |

## Architect Instructions

### Chapter Planning Requirements

**Structure:**
- Chapter length: 3,500–4,500 words
- Pacing: Character and relationship-focused. balance identity exploration with narrative momentum
- Must open with: Character in authentic moment, relationship dynamic, or identity context
- Must close with: Emotional shift, relationship development, or self-discovery moment

**Beats Per Chapter:**
1. **Authentic character moment**. LGBTQ+ character being themselves, not defined solely by identity
2. **Relationship dynamic**. Romantic, familial, friendship, or community connection advancing
3. **Identity context**. How being LGBTQ+ shapes experience in this specific world/situation
4. **External pressure or support**. Homophobia, transphobia, acceptance, or microaggression affecting character
5. **Growth or realisation**. Self-acceptance, coming out, relationship deepening, or community finding

### Genre-Specific Requirements
- LGBTQ+ characters as protagonists with full agency. not sidekicks or tragic backstory
- Identity central but not sole defining trait. career, hobbies, flaws, dreams beyond queerness
- Joy and community alongside struggle. not only trauma narratives
- Intersectionality visible. race, class, disability, culture shape LGBTQ+ experience uniquely
- Found family importance. chosen community as significant as biological family
- Coming out narratives optional. many stories beyond that journey
- Romantic relationships given same depth and intimacy as straight romances
- Historical context accurate if period piece

### Narrative Layers
- **Layer A (External):** Plot events, social interactions, coming out moments, relationship milestones
- **Layer B (Identity):** Internal experience of queerness. self-acceptance, pride, shame, discovery
- **Layer C (Community):** Broader LGBTQ+ community, chosen family, cultural/political context

All three layers active in every chapter. Layer B carries the emotional core.

### Fractal Structure
- Novel level: Identity questioned → explored → complicated → integrated (not "fixed")
- Chapter level: External event → identity resonance → shifted understanding
- Scene level: Interaction → what it means as a queer person → accumulated self-knowledge

### Forbidden in Planning
- "Bury your gays". tragic endings solely because characters are LGBTQ+
- Stereotypes as only representation
- Fetishisation or exoticisation of LGBTQ+ relationships
- LGBTQ+ characters existing only to educate straight characters
- Conversion therapy portrayed positively
- Dead-naming trans characters or misgendering for shock value
- Gratuitous homophobia/transphobia without narrative purpose

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (relationship + community), Captivation (lived experience), Validation (identity affirmed), Revelation (self-claim).

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Voice and Tone
- **POV:** 1st person (intimate identity journey) or 3rd close (access to interiority)
- **Tense:** Past or present. present for immediacy in discovery/coming out moments
- **Voice:** Authentic to character's experience, age, culture. never stereotyped
- **Reading level:** YA to Adult

### Prose Imperatives
- Use character's correct name and pronouns consistently. no dead-naming for drama
- Show character's full life. career, hobbies, friends beyond identity struggles
- LGBTQ+ relationships described with same intimacy and detail as straight romances
- Avoid explaining LGBTQ+ basics unless character POV requires it
- Internalised prejudice shown through character thought, never endorsed by narrative
- Joy, humour, mundane happiness alongside challenges. not only suffering
- Intersectionality present. race, class, disability shape experience specifically

### Prose Masterclass Examples

**Identity Through Specific Detail:**
Show queer experience through learned behaviour and community recognition. not through telling. The scan of a room, the recognition of boots, the coded look. these are how identity is lived, not stated.

**Coming Out as Lived Experience:**
Earn the difficulty through rehearsal detail and specific moments. "Her name is Rachel" makes it personal, not categorical. The crack in the voice, the three weeks of practice. this is the craft.

**Joy Without Qualification:**
Make joy specific, physical, present-tense. The miracle is the ordinariness of it. a hand on a back, in a kitchen, on a Tuesday.

### Prose Rhythm Mapping
- Ch 1 hook: Authentic voice + identity stakes from page 1
- Prose rhythm: Varies by subgenre blend (literary, romance, thriller) BUT ALWAYS:
  - The protagonist's relationship to their identity shapes the prose texture
  - Safe spaces feel different on the page than unsafe spaces (rhythm shifts)
- Interiority around identity: Specific, not generic
  - The SPECIFIC experience of THIS character. not universal "queer experience"
  - The room scan, the code switch, the calculation before self-disclosure
- Sensory detail: The body as site of meaning
  - Physical awareness heightened in moments of visibility or vulnerability
  - Joy rendered with the same specificity as pain
- Tension: ≥4-7 depending on subgenre blend
  - Coming-out narratives: tension from concealment and revelation
  - Romance: tension from attraction and risk
  - Thriller: external danger compounded by identity vulnerability
- Paragraph rhythm: Adapts to emotional safety
  - Compressed, fragmented paragraphs in moments of threat or fear
  - Expansive, breathing paragraphs in moments of acceptance and joy

### Emotional Rhythm
- **Build:** Small moments of recognition. seeing yourself reflected, feeling less alone
- **Sustain:** Hold the tension of being seen vs. hiding. the daily negotiation of authenticity
- **Release:** Through connection, acceptance, or self-acceptance. earned, not announced
- **Recover:** Quiet moments of being fully yourself with people who see you

### Forbidden Words and Phrases
- "Lifestyle" or "preference". orientation/identity, not choice
- "Transgenders" (noun). say "transgender people"
- "Biological [sex]" for trans people. say "assigned [sex] at birth" if relevant
- "Homosexual" (clinical). gay/lesbian unless character voice requires formality
- "Suffering from" being LGBTQ+. not a disease
- Slurs without extreme narrative justification
- Dead names after character transitions (unless clearly marked flashback)

## Quality Check Criteria

### Priority Ranking
1. **Authentic representation**. Researched, non-stereotypical, dimensionally portrayed
2. **Respectful terminology**. Correct pronouns, no slurs without justification, current language
3. **Avoiding harmful tropes**. No "bury your gays," stereotypes, fetishisation, tragedy porn
4. **Intersectionality**. Race, class, disability alongside LGBTQ+ identity
5. **Hope and joy**. Struggle balanced with community, love, pride

### Genre-Specific Checks
- Pronouns consistent throughout
- Trans characters' chosen names used from introduction
- Characters dimensional. identity part of character, not sole defining trait
- Joy present. community, love, humour, mundane happiness shown
- Intersectional. unique compound experiences shown
- LGBTQ+ relationships given same depth as straight relationships
- Historical accuracy if period piece
- Coming out not required as plot

### Automatic Fails
- "Bury your gays". LGBTQ+ character dies tragically solely due to identity
- Conversion therapy portrayed positively
- Dead-naming for drama
- Stereotypes as only representation
- Fetishisation of LGBTQ+ relationships
- Misgendering. wrong pronouns for trans/nonbinary characters
- "It's just a phase". identity portrayed as temporary or curable

### Acceptable Imperfections
- Characters struggling with internalised homophobia (realistic journey)
- Not every character accepts protagonist (realistic)
- Historical fiction showing period-accurate dangers (not gratuitous)
- Bittersweet endings that still show growth and hope

## Continuity Rules

### Top 5 Continuity Priorities
1. **Name and pronoun consistency**. Chosen names and pronouns used correctly throughout
2. **Coming out status tracking**. Who knows what about character's identity, maintained precisely
3. **Identity consistency**. How character identifies remains stable unless evolution explicitly shown
4. **Relationship authenticity**. LGBTQ+ relationships given same depth as any romance
5. **Community connections**. Found family, LGBTQ+ friends, support networks maintained

### "Who Knows" Map (Critical Tracking)
- Which characters aware of protagonist's LGBTQ+ identity
- How each person learned (told, discovered, overheard)
- Character behaves differently at work (closeted) vs. with chosen family (out)
- Each coming out moment: who, when, reaction, how it changes the relationship going forward

### Critical. Never Allow
- Trans character's name/pronouns wavering (except clearly marked flashback)
- Arbitrary orientation shift without discovery process
- Coming out consequences forgotten. family/friend reactions must stay consistent
- "Who knows" map violated. character acting out in space where they're closeted
- Historical dangers ignored
- Internalised homophobia vanishing overnight without earned journey
- Microaggressions or acceptance shifting without reason

### Acceptable Inconsistencies
- Minor background character details
- Labels shifting as character discovers (thought gay, realises bi. growth, not error)

## Character Rules

### Top 5 Character Priorities
1. **Authentic identity**. Specific, not generic ("out and community-connected" not just "gay")
2. **Dimensional beyond identity**. Career, hobbies, flaws, dreams beyond being LGBTQ+
3. **Intersectionality**. Race, class, disability, culture shape experience uniquely
4. **Internal consistency**. Coming out process, self-acceptance arc realistic to psychology
5. **Relationship capacity**. How character loves shaped by identity, experience, internalised prejudice

### Character Tracking Checklist
- Who knows character's identity and how they learned
- Coming out moments and reactions. each significant and specific
- Internal acceptance level. self-love, shame, working through prejudice
- Relationship status and how openly expressed in different contexts
- Connection to LGBTQ+ community. isolated, connected, activist
- Intersectional pressures. racism, classism, ableism alongside homophobia
- Support network. allies, chosen family, safe spaces
- Dreams and goals beyond identity
- Behaviour shifts between safe and unsafe spaces (code-switching)

### Red Flags
- All LGBTQ+ characters fitting same stereotype
- Character defined solely by identity
- Bisexual/pan characters portrayed as "confused"
- Trans characters defined solely by transition
- Asexual characters portrayed as "broken"
- No joy shown. only trauma and suffering
- LGBTQ+ character exists only to educate straight characters

## Arc Rules

### Arc Types (Choose Based on Story)

**Coming Out Narrative:**
- Act I (Ch 1–10): QUESTIONING. Something feels different; self-discovery begins; internal tension builds
- MIDPOINT (Ch ~15): SELF-ACCEPTANCE. Admitting truth to self; first coming out to trusted person
- Act II (Ch 11–23): NAVIGATING IDENTITY. Multiple coming outs; consequences accumulate; found family forming
- Act III (Ch 24–30): INTEGRATION. Living authentically; identity integrated with full self; hope

**LGBTQ+ Romance:**
- Act I (Ch 1–10): MEETING. Attraction, initial barriers (closet, identity, internalised prejudice)
- MIDPOINT (Ch ~15): COMMITMENT. First major intimacy or relationship-defining moment
- Act II (Ch 11–23): DEEPENING. External pressures test bond; relationship grows through vulnerability
- Act III (Ch 24–30): RESOLUTION. Obstacles overcome together, commitment affirmed

**Established Identity Story:**
- Identity present through relationships, community, microaggressions. but plot drives forward
- LGBTQ+ character has agency in non-identity plot
- Chosen family visible, supporting main narrative

### Required Checkpoints
- By 25%: Identity context established
- By 50%: Major identity milestone
- By 75%: Maximum pressure on authenticity
- By 90%: Resolution in motion. consequences settling
- Final pages: Hope present. character living authentically, found family visible

### Genre Promise
- Authentic representation. researched, non-stereotypical
- LGBTQ+ characters as protagonists with agency
- Joy and community alongside challenges
- Hopeful or happy ending (not tragic solely due to identity)
- Intersectionality visible
- Found family and community importance

## Timeline Rules

### Top 5 Timeline Priorities
1. **Coming out pacing**. Not instant; weeks/months of fear, planning, courage-building
2. **Self-acceptance arc**. Denial → questioning → acceptance unfolds realistically over time
3. **Identity milestone tracking**. Who was told when, in what order, with what reaction
4. **Relationship pacing**. Same time to deepen as any romance
5. **Historical accuracy**. Era dictates danger level, visibility, community access, language

### Genre-Specific Temporal Rules
- Coming out not instant. weeks/months of courage-building per person
- Self-acceptance gradual. not overnight
- Multiple coming outs. each requires separate courage and timing
- Transition (if present) takes time. social, medical, legal processes span months/years
- Community finding gradual. first friend, then spaces, then chosen family over months/years

## Genre-Specific Craft Techniques

LGBTQ+ fiction is a genre whose contemporary masterclass
roster is unusually wide and structurally diverse: literary
heavyweights (Hanya Yanagihara, Garth Greenwell, Bryan
Washington, Ocean Vuong, Brandon Taylor, Alexander Chee),
genre-fluid contemporary voices (Carmen Maria Machado,
Akwaeke Emezi, Andrew Sean Greer, Saeed Jones, Andrea
Lawlor), commercial and crossover successes (Casey
McQuiston, Torrey Peters, TJ Klune, Madeline Miller,
Adib Khorram, Becky Albertalli, Kacen Callender), and
historical / period craft (Sarah Waters, Hanya
Yanagihara again, Alexander Chee's Edinburgh, Madeline
Miller's Song of Achilles). The genre is no longer
defined by the coming-out novel — it now contains
romance, literary, historical, fantasy, sci-fi, thriller,
horror, memoir-adjacent, and crossover-romance writing,
all unified by the requirement that LGBTQ+ characters
function as full protagonists rather than as
representational tokens. The most common failure modes
in this register are: **Trauma-Centred Reduction** (queer
fiction collapsed to suffering — every chapter is
homophobia, transphobia, or coming-out trauma, with no
joy, no community, no mundane queer happiness rendered
with comparable craft); **Coming-Out-as-Sole-Arc** (the
entire book is the coming out, with everything else
treated as preamble or epilogue — but the genre has
moved beyond requiring this as the only available
shape); **Token-Rep Flattening** (the queer character
whose identity is mentioned but never lived — the gay
best friend, the bisexual cousin, the trans neighbour,
identity as checkbox rather than as specifically rendered
experience); **Educator-Hostage Dynamic** (the LGBTQ+
character existing primarily to teach straight readers,
with chapters that read as identity exposition for a
non-queer audience); **Bury-Your-Gays** (tragic ending
solely because characters are LGBTQ+, the canon's worst
single trope, fatal even when the rest of the book is
strong); **Identity-Without-Specificity** ("they were
gay" or "they were trans" with no further texture about
what that specifically means for THIS character — no
community relationship, no historical positioning, no
specifically rendered way of moving through the world);
**Stereotype-as-Authenticity** (the flamboyant gay
friend, the butch lesbian, the predatory bisexual,
the trans-character-defined-only-by-transition — old
shapes mistaken for representation); and **Anachronism-
of-Acceptance** (historical LGBTQ+ fiction where
characters move through their period with 2026-era
social safety; the danger flattened, the period codes
elided, the survival craft of the era unrendered). The
techniques below — four preserved (Room Scan, Code
Switch, First Recognition, Found Family Accretion) and
three added (Specificity-of-Identity Discipline, Joy-
Equity Discipline, Intersectional Thickness System) —
are designed to ensure the genre's defining contract:
LGBTQ+ characters as fully realised protagonists with
specific lives, communities, joys, and histories, never
flattened to identity alone, never reduced to suffering,
never made hostage to a non-queer reader's education.

### The Room Scan

The learned behaviour of assessing safety in every new space:
- Who might be safe? Who might not?
- What coded signals suggest community (boots, pins, haircuts, eye contact)?
- The calculation that happens before any queer person decides how much of themselves to show
- This scan IS the queer experience rendered in prose. showing, not telling

### The Code Switch

Characters who speak and behave differently depending on who's present:
- The voice that drops an octave at work
- The pronouns that shift depending on the audience
- The way a hand is removed from a partner's when the wrong person enters the room
- The exhaustion of performing a version of yourself that isn't real

### The First Recognition

The moment of seeing yourself reflected in another person for the first time:
- A book, a film, a stranger on the bus, a friend's casual admission
- The rush of "I'm not the only one". specific, physical, overwhelming
- This moment often remembered with extraordinary vividness years later
- Write it with the weight it carries. this changed everything

### The Found Family Accretion

Chosen family doesn't arrive fully formed:
- The first friend who says "me too"
- The first safe space where performance isn't required
- The gradual building of community through accumulated trust
- The moment when "these people" becomes "my people"

### LGBTQ+ Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "finding the courage to be themselves" | Show the specific act of self-expression |
| "love is love" | Show the specific love through specific action |
| "coming out was the hardest thing they'd ever done" | Show the specific conversation |
| "the community embraced them" | Show the specific welcome |
| "they finally felt seen" | Show the specific moment of recognition |
| "fighting for the right to exist" | Show the specific fight. legal, social, personal |
| "the closet was suffocating" | Show the specific lie told and its specific toll |
| "identity was more complex than labels" | Show the specific complexity through one experience |
| "pride in who they were" | Show the specific proud moment |
| "the world wasn't ready" | Show the specific hostile encounter |
| "chosen family" | Show the specific family-building moment |
| "they wore their identity proudly" | Show the specific proud moment — the pin, the pronoun correction, the public hand-hold |
| "in the safety of their own community" | Show the specific community space and what specifically makes it safe |
| "the unique pain of being misunderstood" | Show the specific misunderstanding through one specific exchange |
| "they had always known" | Show the specific early moment of knowing through one concrete memory |
| "loving who they loved" | Cut the tautology; show the specific person they love |
| "the journey of acceptance" | Show one specific moment of acceptance (or refusal of acceptance) |
| "navigating the complexities of identity" | Show the specific complexity through one specific decision |

### The Specificity-of-Identity Discipline

The genre fails when "queer" is treated as a single
shared experience rather than as a particular
configuration in a particular life. This character's
relationship to identity is not the same as the next
character's. one is out to her sister but not her
father; one is publicly an activist; one is quietly
private; one is in love with the community; one is
alienated from it; one performs in some spaces and is
fully herself in others; one carries the language of
the era she came out in; one carries the language of
the era she came of age in. The Specificity-of-
Identity Discipline is the requirement to render THIS
character's particular queer life rather than a generic
queer experience.

```
PRINCIPLE
The character's identity must be rendered with at least
five specifics:
1. WHO KNOWS — the precise list of people who know,
   how each learned, when, with what reaction, and how
   the knowledge has shifted the relationship since
2. WHERE SHE'S OUT vs. WHERE SHE'S CLOSETED — the
   geographic / contextual map of safe and unsafe
   spaces; the code-switching protocol she has built
3. WHAT LANGUAGE SHE USES FOR HERSELF — the specific
   word she chose for her identity (and the words she
   rejected); the era that shaped her vocabulary; the
   community whose lexicon she inherited
4. WHAT HISTORY SHE CARRIES — the era she came out in,
   the friends she lost (to AIDS, to suicide, to
   estrangement, to stochastic violence), the
   movements she did or didn't join, the activists
   she does or doesn't admire
5. HOW SHE MOVES THROUGH THE WORLD — the specific
   gestures, gait, voice modulation, sartorial choices
   she has built; what is unconsidered habit and what
   is conscious craft

CALIBRATION TEST
- Could a reader describe this character's queerness
  in five sentences that would not also describe any
  other queer character in the book?
- Does the character have a SPECIFIC relationship to
  community (close / drifting / activist / alienated /
  longing / refused / etc.) — and is that relationship
  rendered, not just stated?
- Does the character carry SPECIFIC history (era,
  losses, predecessors, movements) — even if the book
  is contemporary?
- Does the language the character uses for herself
  feel chosen, not given?
If any answer is no — rebuild for specificity.

ANTI-PATTERN
- "She was a lesbian" with no further texture
- The queer character whose every interaction with
  identity is generic ("the closet was suffocating")
- The trans character who is rendered only through
  transition narrative
- The bisexual character whose bisexuality is referred
  to but never specifically lived
- The asexual character whose orientation is mentioned
  once and never returned to
- The historical queer character who has no
  predecessors, no community, no period vocabulary
```

### The Joy-Equity Discipline

The single most common failure mode in well-meaning
LGBTQ+ fiction is the gravity-well of trauma: every
chapter is homophobia, every scene is danger, every
arc is suffering and survival. The Joy-Equity
Discipline requires that joy be rendered with the same
craft attention given to struggle. mundane queer
happiness, community celebration, romantic intimacy,
casual safety, and ordinary domesticity given the same
prose weight, the same specificity, and the same
narrative space as the genre's traditional sources of
pain.

```
PRINCIPLE
For every chapter that contains a homophobic /
transphobic / closeted / threatened beat, the
manuscript must contain at least one beat — somewhere,
not necessarily in the same chapter — of:
1. SPECIFIC JOY in being queer (not "she was happy"
   but the specific Pride march, the specific kiss
   in the kitchen, the specific moment of being
   recognised by another queer person across a room)
2. SPECIFIC COMMUNITY (not "her queer friends were
   supportive" but the specific Tuesday-night dinner,
   the specific group text, the specific drag bar
   where everyone knows her name)
3. SPECIFIC INTIMACY (LGBTQ+ romantic and sexual
   intimacy rendered with the same craft as any
   straight intimacy. nothing fade-to-black that
   wouldn't fade-to-black in a heterosexual scene;
   nothing rushed that wouldn't be rushed in a
   heterosexual scene)
4. SPECIFIC ORDINARINESS (the queer character grocery
   shopping, paying bills, walking the dog, reading on
   the sofa with a partner, arguing about dinner — the
   miracle of the unmarked moment)
5. SPECIFIC HUMOUR (queer wit, in-group reference,
   community comedy — the texture of how queer people
   actually talk to each other, with each other,
   about each other)

CALIBRATION TEST
- If you removed every instance of homophobia /
  transphobia / closet pressure from the manuscript,
  would the queer characters' lives be visible at all?
- Does the manuscript contain SPECIFIC queer joy
  rendered with the same craft as queer pain?
- Is queer intimacy given the same on-page presence
  as equivalent straight intimacy would be?
- Does the queer ordinariness — Tuesday dinners,
  grocery runs, sofa evenings — appear, or has the
  whole emotional palette been narrowed to threat
  and survival?
If any answer is no — rebalance.

ANTI-PATTERN
- The trauma-only queer narrative
- The romance that fades to black where a straight
  romance would not
- The queer characters whose only joy is escaping
  pain (joy as relief, never joy as joy)
- The trans character whose only on-page experience
  is the difficulty of being trans
- The historical queer character whose entire arc is
  loss, secrecy, and grief
```

### The Intersectional Thickness System

LGBTQ+ fiction is rarely about queerness alone. it is
about queerness as it intersects with race, class,
disability, faith, region, age, family-of-origin
culture, language, immigration status, and
neurodivergence. The Intersectional Thickness System
is the requirement that intersectionality be rendered
not as flag-planting (a list of identity boxes ticked)
but as thickness of lived life. how being a Black
trans woman in Atlanta is not the same as being a
white trans woman in Portland, and how being a queer
disabled Latine person on the West Coast is not the
same as being a queer disabled white person in the
rural Midwest.

```
PRINCIPLE
For every queer character of significance, the
intersectional architecture must be rendered with at
least three of:
1. RACE / ETHNICITY shaping the specific configuration
   of queerness — community ties, family-of-origin
   complications, historical relationship to LGBTQ+
   movements, specific language and code-switching,
   specific dangers and joys
2. CLASS shaping the specific configuration — access
   to community spaces, ability to leave a hostile
   region, ability to access medical care (for trans
   characters especially), ability to be openly out
   without economic precarity
3. DISABILITY / CHRONIC ILLNESS shaping the specific
   configuration — accessibility of community spaces,
   specific intersections with the medical system
   (especially for trans characters), specific
   exhaustion that compounds across identity axes
4. FAITH / RELIGIOUS BACKGROUND shaping — relationship
   to family of origin, relationship to forgiveness
   and grace, relationship to community-of-origin,
   the specific theology the character has had to
   reconstruct or refuse
5. REGION shaping — rural / urban / suburban /
   diaspora / borderland — and the specific code-
   switching and survival craft that region requires
6. AGE / GENERATION shaping — the era the character
   came out in, the language available at that time,
   the predecessors lost (or lived through), the
   movements they joined or refused

CALIBRATION TEST
- Are at least three intersectional axes rendered
  through specific lived detail (not just mentioned)?
- Does the intersection produce SPECIFIC compound
  experience rather than additive checkbox
  representation?
- Does the character's specific community reflect
  their specific intersectional position, rather
  than a generic LGBTQ+ community?
- Are the failure modes of the surrounding world
  specific to this character's intersection (the
  specific microaggressions, the specific
  assumptions, the specific erasures)?
If any answer is no — rebuild.

ANTI-PATTERN
- Identity boxes ticked but not lived ("she was a
  Black queer disabled woman" with nothing in the
  prose beyond that sentence to render the
  intersection)
- The single-axis queer narrative (queerness rendered
  but race / class / disability invisible despite the
  character clearly being a person with those
  identities too)
- The white-default queer story where the absence of
  a race-axis is presented as universality
- Intersectionality rendered as compound suffering
  only (multiple oppressions stacked) without
  compound community, joy, or resilience
- The character whose intersectional position is
  raised but never affects how she moves through
  any specific scene
```

## Genre-Specific Revision Rules

### Six-Pass LGBTQ+ Fiction Audit (Run FIRST in editorial pipeline)

The LGBTQ+ Fiction Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Representation Pass

Verify pronouns are correct and consistent throughout.
For trans characters, the chosen name must be used from
introduction (with dead-naming permitted only inside
clearly marked flashback to a pre-transition moment,
and even then handled with care). Verify identity is
SHOWN through specific detail, not stated generically.
Verify the manuscript is free of the harmful trope set:
no bury-your-gays (no LGBTQ+ character dying solely
because they are LGBTQ+); no stereotypes-as-only-
representation (the flamboyant gay friend, the
predatory bisexual, the trans-character-as-only-
transition); no fetishisation; no conversion therapy
portrayed positively; no "it was just a phase"
ambiguity around an established identity. The
Representation Pass is the genre's lowest tolerance
pass. failures here are not craft failures, they are
ethical failures.

#### Pass 2: Dimensionality Pass

Verify each LGBTQ+ character has a life beyond their
identity. career, hobbies, family of origin (with
specifics), friendships not centred on shared queerness,
dreams unrelated to identity, flaws unrelated to
identity, expertise the world does not currently
recognise. The Token-Rep Flattening failure mode is
caught here. the character mentioned as queer but
otherwise rendered with no thickness becomes a
checkbox, which the reader feels and resents. Verify
joy is present alongside struggle (cross-reference with
Pass 6 below). Verify intersectionality is visible —
race, class, disability, faith, region, age, family-
of-origin culture all affecting how this specific queer
life is lived. Verify each LGBTQ+ character is a
protagonist or active agent in their own arc, not a
sidekick whose function is to teach a non-queer
character or to die for a non-queer character's
emotional development.

#### Pass 3: Coming-Out Integrity Pass (If Present)

For manuscripts with coming-out narrative content (this
pass is conditional — if the manuscript has no coming-
out content, skip), verify each coming-out scene is
specific and earned. The generic revelation ("I'm gay";
silence; tears; reconciliation) is the sign that the
craft has not been done. Each coming-out moment should
be specifically rendered: the rehearsal of the words,
the room, the body, the exact phrasing used (or
abandoned), the reaction that surprises (positively or
negatively), the silence that follows. Verify reactions
vary realistically between different people. the
mother's response is not the father's; the sister's is
not the best friend's; the colleague's is not the
boss's. Verify consequences are maintained and carried
forward across chapters. the family reaction in chapter
5 must still be live in chapter 25. Verify the "who
knows" map is consistent. the character does not behave
as out in a context where they have not come out, and
does not behave as closeted in a context where they
have come out, except by deliberate craft.

#### Pass 4: Relationship Equity Pass

Verify LGBTQ+ relationships are given the same depth,
intimacy, and screen time as straight relationships
would be in the same manuscript. Test by substitution:
if you imagined this same scene with a heterosexual
couple, would the prose be different? Would the
intimacy be more present? Would the kiss linger longer?
Would the bedroom scene be more fully rendered? If yes
— the LGBTQ+ relationship has been short-changed and
must be rebuilt. Verify first attraction is written
with the same craft as any first love. the specific
gestures, the specific recognition, the specific
quality of the gaze. Verify relationship obstacles are
specific (this couple's specific complications) and
not generic ("society disapproves"). The genre's
contemporary masterclass writers (Yanagihara, Greenwell,
McQuiston, Klune, Peters, Vuong) all render queer
intimacy with full craft attention. anything less is
short-changing the contract.

#### Pass 5: Terminology and Language Pass

Verify identity terms match what THIS character would
use. The vocabulary of an out-since-the-eighties man
in his sixties is not the same as the vocabulary of a
non-binary teenager in 2026. The language of a
contemporary cis lesbian is not the same as the
language of a closeted historical queer person. Verify
no clinical or outdated language ("homosexual" as
descriptor, "lifestyle", "preference", "sexual
preference", "transgenders" as noun, "biological [sex]"
for trans people) unless period-accuracy or character
voice specifically requires it (and even then, the
narration should not endorse the language). Verify no
slurs without extreme narrative justification (and
never slurs deployed as colour or shock). Verify no
dead-naming outside clearly marked flashbacks. Verify
the language characters use about themselves
(particularly trans, non-binary, asexual, intersex
characters) is the language they choose, not the
language imposed on them by the narrative voice.

#### Pass 6: Specificity-of-Identity + Joy-Equity + Intersectional-Thickness Integration

This pass is the LGBTQ+ fiction integration check — it
ties the new techniques together and verifies the genre
contract is honoured chapter by chapter.

For SPECIFICITY-OF-IDENTITY: identify what is
specifically queer about this chapter's protagonist
(beyond the stated identity label). Are the five
specifics rendered or implied somewhere in the
manuscript — who knows, where she is out vs. closeted,
what language she uses for herself, what history she
carries, how she moves through the world? If her
queerness is visible only as a label, rebuild. The
character must have a SPECIFIC relationship to identity,
not a generic one.

For JOY-EQUITY: identify the chapter's emotional
distribution. If the chapter contains homophobia /
transphobia / closet pressure / threat, has the
manuscript elsewhere rendered specific queer joy,
specific community, specific intimacy, specific
ordinariness, specific humour with comparable craft?
If the manuscript has been narrowed entirely to threat
and survival, rebalance — find moments of mundane
queer happiness and render them with the same
specificity given to the pain. The genre's contract is
not "queer suffering with hope at the end". it is
"queer life rendered fully", which includes the
suffering AND the Tuesday-night dinners, the kiss in
the kitchen, the joke that only the community gets,
the moment of being recognised across a room.

For INTERSECTIONAL-THICKNESS: identify the
intersectional axes this character lives at the
crossroads of (race, class, disability, faith, region,
age, neurodivergence, immigration status, language).
Verify at least three are rendered through specific
lived detail (not just mentioned). Verify the
intersection produces SPECIFIC compound experience —
the specific microaggressions, the specific code-
switches, the specific compound communities, the
specific compound joys — rather than additive checkbox
representation. If the chapter renders queerness but
treats race or class or disability as invisible default,
the character has been flattened to a single axis and
must be rebuilt.

## Names & Patterns to Avoid

### Forbidden Patterns
- "She was brave enough to be herself". identity is not bravery, it's existence
- "Despite being gay, he was also...". "despite" implies deficit
- The character whose only personality trait is being LGBTQ+
- Coming out as the entire plot (many stories beyond this)
- The tragic queer character who dies so straight characters can learn
- The predatory bisexual or "confused" bi character
- Trans characters who are nothing but their transition narrative
- Historical LGBTQ+ fiction where everyone is accepting (anachronistic)

### Cliché Setups to Avoid
- The makeover scene that "reveals" the character's true identity
- The instant community that appears fully formed
- The love interest who "cures" internalised homophobia with a kiss
- The coming out scene that's the same every time (generic, unspecific)
- The bully who's secretly gay (harmful unless handled with extraordinary care)
- All conflict coming from external homophobia. internal journeys matter too

### Names to Avoid
- Names that signal identity before the character can be known as a person
- Dead names revealed for shock value
- Names that code as stereotypes

## Comp Titles

LGBTQ+ fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Giovanni's Room* — James Baldwin (1956): the queer literary-fiction foundation.
- *Tipping the Velvet* — Sarah Waters (1998): historical lesbian literary fiction.
- *A Little Life* — Hanya Yanagihara (2015): contemporary queer literary epic.
- *The Song of Achilles* — Madeline Miller (2011): queer mythological literary fiction.
- *Fingersmith* — Sarah Waters (2002): queer Victorian literary benchmark.

### Contemporary (current best-in-class)

- *Detransition, Baby* — Torrey Peters (2021): trans contemporary literary fiction benchmark.
- *Real Life* — Brandon Taylor (2020): queer Black-academic literary fiction.
- *In the Dream House* — Carmen Maria Machado (2019): queer memoir-novel hybrid.
- *On Earth We're Briefly Gorgeous* — Ocean Vuong (2019): queer Vietnamese-diaspora literary.
- *Bestiary* — K-Ming Chang (2020): queer Taiwanese-American literary fiction.
- *Memorial* — Bryan Washington (2020): contemporary queer relationship literary fiction.
- *The House in the Cerulean Sea* — TJ Klune (2020): queer cozy fantasy crossover.
- *Red, White & Royal Blue* — Casey McQuiston (2019): queer commercial-literary crossover.

## Cover Design Specifications

### Visual Tone
- Warm, inviting, contemporary
- Celebrates identity through colour, light, and imagery
- Avoids both rainbow-washing and closeting
- Emotionally resonant. the feeling of being seen

### Key Visual Elements
- Characters in intimate, natural poses suggesting genuine connection
- Rainbow or pride colours used tastefully (not every cover needs a rainbow)
- Community suggested through imagery (gatherings, shared spaces)
- Warmth and light. not darkness unless specifically dark-toned story

### Typography
- Modern, clean fonts. approachable and confident
- Title prominent with character-driven imagery
- Author name visible
- Genre/identity signals subtle but present

### Colour Palette
- Primary: Warm tones. sunset colours, soft pinks, sky blues, lavenders
- Accent: Rainbow spectrum used selectively, not overwhelming
- Avoid: Exclusively dark or muted palettes (unless story tone demands it)
- High-contrast for readability

### Comp Titles (Cover Style Reference)
- *Red, White & Royal Blue* by Casey McQuiston. bright, confident, romantic
- *The House in the Cerulean Sea* by TJ Klune. warm, whimsical, hopeful
- *Detransition, Baby* by Torrey Peters. bold, literary, unapologetic
- *On Earth We're Briefly Gorgeous* by Ocean Vuong. atmospheric, poetic, intimate
