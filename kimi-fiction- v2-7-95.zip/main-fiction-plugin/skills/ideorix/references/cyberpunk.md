---
name: cyberpunk-genre
description: Genre-specific instructions for cyberpunk fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Cyberpunk. Genre Plugin

## Metadata
- id: cyberpunk
- name: Cyberpunk
- icon: 🔌
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Dan Harmon Story Circle"]

## Subgenre Options
Present during setup:
- **Classic Cyberpunk**. Corporate dystopia, hackers, street-level survival, Gibson/Sterling territory
- **Post-Cyberpunk**. Same tech, less nihilism, characters trying to build something in the cracks
- **Biopunk**. Genetic modification, organic technology, body horror, evolution as commodity
- **Nanopunk**. Nanotechnology as the primary tech, molecular manipulation, invisible infrastructure
- **Solarpunk-Adjacent**. Cyberpunk tech in a world trying to do better (tension between hope and system)
- **Noir Cyberpunk**. Detective/PI framework in a cyberpunk world, investigations through digital and physical layers

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Street-level urgency. short chapters, fast cuts, always moving
- Must open with: Action, a deal, a hack, or physical consequence of the world. never with a technology lecture

BEATS PER CHAPTER
1. Tech-Body Beat. Technology intersects with the physical body: augmentation, interface, addiction, damage, or the sensory experience of jacking in
2. Power Gradient. The vast gulf between corporate power and street-level survival is felt: economic pressure, resource scarcity, class violence
3. Information Play. Data, secrets, or access are traded, stolen, or weaponized
4. Sensory Overload. The city/world overwhelms at least one sense: neon, noise, crowds, pollution, digital overlay
5. Human Cost. Behind every piece of technology is a person paying the price

CYBERPUNK ARCHITECTURE
- "High tech, low life". advanced technology concentrated at the top, survival tech at the bottom
- The city is alive: layered, vertical, dense, NEVER clean
- Corporations are the de facto government. state power is a memory or a puppet
- The street finds its own uses for things. repurposed tech, black market modifications, jury-rigged solutions
- The internet/net/mesh is a PLACE: navigable, dangerous, with its own geography and predators
- Identity is fluid: augmentation, avatars, digital personas, body modification
- POV: First person (dominant, creates immediacy) or tight third past

TECHNOLOGY INTEGRATION
- Technology is embedded in BODIES: cybernetic eyes, neural interfaces, augmented limbs, synthetic organs
- This is not neutral. body modification has physical costs, social implications, and identity consequences
- The digital layer is always present: AR overlays, constant connectivity, data streams
- Hacking is physical: it takes effort, skill, and risk (not magic button-pressing)
- Technology fails: glitches, viruses, planned obsolescence, corporate kill-switches
- Analog is rare and valuable: unaugmented humans, physical books, off-grid spaces

THE STREET
- Cyberpunk is a STREET-LEVEL genre: the protagonist is not a CEO
- The world is experienced from the bottom: gig work, debt, survival, hustle
- The protagonist has skills (hacking, combat, fixing, smuggling) that make them valuable but expendable
- Every job is a trade: risk for reward, trust for betrayal
- The street has its own culture: music, slang, fashion, drugs, food, community

FORBIDDEN IN CYBERPUNK
- Clean, bright, Apple-aesthetic futures (cyberpunk is MESSY)
- Technology as neutral or benign (it's a tool of power and control)
- The lone hacker who brings down the system from their bedroom (too simple)
- Corporate villains who are just "evil" (they're EFFICIENT. evil is a byproduct)
- Cyberpunk aesthetics without cyberpunk politics (neon is not enough)
- The "jacking in" scene that reads like a psychedelic trip with no stakes
- Ignoring the body: if you're augmented, your body has opinions about it
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (sensory density), Captivation (worldbuilding), Revelation (system-truth uncovered).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person present tense (creates street-level immediacy) or tight third
- Voice: Clipped, sensory-overloaded, with a street-poet's eye for beauty in the ugly
- Tone: Noir-adjacent but not nihilistic. the protagonist cares about SOMETHING, even if they pretend not to
- Register: Street-level vernacular with technical fluency; the protagonist speaks code and slang equally

PROSE IMPERATIVES
- SENSORY DENSITY: cyberpunk prose packs more sensation per paragraph than any other genre
  - Pick ONE or TWO sensory hits per paragraph. Neon in a puddle is enough. The smell of frying noodles is enough. Don't stack five sensations into one sentence
- BODY AWARENESS: the protagonist's relationship with their own body is central
  - Augmented limbs have phantom pains; neural interfaces cause headaches; the meat-body ages around the chrome
- SPEED: sentences are short during action, sensory during exploration, fragmented during interface
- CONTRAST: beauty and decay coexist. a perfect holographic face advertising luxury over a gutter full of broken needles
- BRAND SPECIFICITY: the world is branded. not "a phone" but "a Kiroshi optik" or "a Mercer-Arasaka neural splice"

PROSE RHYTHM MAPPING
- Chapter 1 must establish sensory overload + grit. the world hits the reader fast and hard from sentence one
- Staccato rhythm dominates: 8-15 words per sentence is the baseline. Short. Dense. Packed with sensation. This is a genre that doesn't wait
- Sensory hits come in rapid succession: one per sentence, stacked in quick paragraphs. Neon. Smell. Sound. Data overlay. Each its own short burst
- Jargon-as-texture: brand names, slang, and tech terms embedded in short sentences create rhythm through unfamiliarity. the reader parses as they move, never pausing
- Opening paragraphs: immediate sensory assault. 3-4 short sentences layering different senses. The reader is IN the city before they've registered the plot
- Interface/hacking scenes: rhythm becomes FRAGMENTED. Incomplete sentences. Dashes. The prose mimics digital processing. fast, non-linear, overwhelming
- Body-awareness passages: slightly longer sentences (12-18 words) when the protagonist notices their augmentations. the prose slows fractionally to register physical sensation
- Dialogue: clipped. Characters don't waste words. Corporate-speak is its own rhythm: longer, smoother, euphemistic (16-20 words). Street talk: shorter, harder (6-12 words)
- Action sequences: the shortest sentences in any genre. 4-8 words. Verbs. Impact. Damage. Done. Augmented combat happens faster than thought
- Neon-and-chrome sensory moments: brief but vivid. One image per sentence, precisely rendered. The beauty of the ugly world delivered in 8-12 word flashes
- Tension baseline: ≥6 from the first line. Cyberpunk opens at speed. the protagonist is already in motion, already at risk, already running on something
- The power-gradient beat: when corporate power is felt, sentences may stretch slightly (14-20 words). the system is bigger and slower than the street, and the prose reflects that weight
- Contrast rhythms within paragraphs: 3 short sentences followed by one medium creates a breathing pattern. Pure staccato exhausts. vary the density
- Post-action crash: the only place sentences lengthen significantly (16-22 words). The comedown. The aug-cooldown. The body reasserting its needs
- Single-word sentences are genre-appropriate: "Chrome." "Flatline." "Static." Used for emphasis at paragraph breaks
- End-of-chapter rhythm: hard stop. The final sentence should hit like a kill-switch. short, definitive, and pulling the reader into the next chapter by force
- Read the entire chapter aloud at a jog's pace. if you're out of breath, it's working. If you're comfortable, it's too slow
- The goal: prose that feels like a neural interface. fast, dense, slightly overwhelming, and impossible to look away from

TECHNOLOGY PROSE
- Tech described through SENSATION, not specification:
  WRONG: "She activated her type-4 neural interface which operated at 12.8 terahertz bandwidth."
  RIGHT: "The interface kicked in and the world went crystalline. Every surface grew a data shadow. prices, owners, threat assessments flickering in the periphery of vision. Her teeth buzzed."
- Hacking is PHYSICAL: sweat, headaches, the taste of copper, fingers cramping, time pressure
- Body augmentation described through how it FEELS, not how it works
- The net/mesh has geography: levels, nodes, ice (defense programs), and black spaces where data goes to hide

DIALOGUE CRAFT
- Street slang evolves: create 5-10 setting-specific terms that feel natural
- Corporate-speak is its own language: euphemistic, precise, dehumanizing
- Fixers and dealers speak in coded offers and veiled threats
- Hackers and techs have their own shorthand
- Characters code-switch: street talk with friends, corporate polish with employers, technical precision with other specialists

ACTION CRAFT
- Cyberpunk action is SHORT and BRUTAL: not choreographed martial arts but desperate, dirty fighting
- Augmented combat: faster reflexes, but aug-glitches at the worst moment
- Hacking under fire: splitting attention between digital and physical threats
- The body has limits even with augmentation. chrome doesn't make you invincible
- Post-action: the adrenaline dump, the augmentation cooldown, the damage assessment
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

CYBERPUNK CRAFT (40% of total):
- "High tech, low life" dynamic is present and felt? (0-100)
- Technology is embodied (in bodies, in sensation) not abstract? (0-100)
- The city/world is sensorially dense and specific? (0-100)
- Power structures (corporate vs street) drive the conflict? (0-100)

STORY CRAFT (30% of total):
- Protagonist has agency within their constrained world? (0-100)
- Stakes are personal (not save-the-world generic)? (0-100)
- Information/data plays a role in the plot? (0-100)
- Pacing is urgent and propulsive? (0-100)

PROSE QUALITY (30% of total):
- Sensory density is high (reader FEELS the world)? (0-100)
- Body and augmentation are described through sensation? (0-100)
- Dialogue uses register and slang appropriately? (0-100)
- Action is physical, consequential, and brief? (0-100)

AUTOMATIC FAILS (score = 0):
- Clean, bright aesthetic without grit or consequence
- Technology lecture in narration (specs, not sensation)
- Hacking as magic (no effort, no risk, no physical consequence)
- Corporate villain with no comprehensible motivation beyond "evil"
- Cyberpunk window-dressing on a story with no class/power analysis
- No body-technology integration (augmentation mentioned but never felt)
```

## Continuity Rules

```
CYBERPUNK CONTINUITY. WHAT TO TRACK

AUGMENTATION STATE:
- What augmentations each character has, their condition, and their side effects
- Augmentation glitches: if an aug malfunctions, track the consequences
- Maintenance: augmentations need upkeep (charge, calibration, replacement parts)
- Body rejection: the human body's response to foreign hardware

DIGITAL STATE:
- Network access: who's connected, who's off-grid, who's been cut off
- Data: what information has been acquired, by whom, and what it's worth
- Digital identities: avatars, aliases, compromised accounts
- ICE (intrusion countermeasures) encountered and their characteristics

ECONOMIC STATE:
- Money/credits: track what the protagonist has and owes
- Debts: who they owe, interest rates, deadlines, consequences of default
- Gear: weapons, augmentations, vehicles, tools. track condition and ownership
- Jobs: what they've been hired to do, who hired them, payment status

CITY GEOGRAPHY:
- Specific locations: where they live, where they work, safe houses, meeting points
- Territorial control: which corp or gang controls which district
- The vertical city: levels, from sub-street to corporate towers
- Travel: how they get around (transit, bike, on foot, car)

PHYSICAL STATE:
- Injuries from combat or aug-malfunction
- Augmentation side effects: headaches, phantom pains, neural fatigue
- Substance use: stimulants, painkillers, interface drugs. track tolerance and need
- Sleep deficit: cyberpunk protagonists often don't sleep enough
```

## Character Rules

```
CYBERPUNK CHARACTER TYPES

THE PROTAGONIST:
- A specialist: hacker, fixer, street samurai, runner, tech, smuggler, investigator
- Has ONE primary skill set that makes them valuable in the underworld
- Lives at street level. not a corporate executive exploring the other side
- Has a personal reason to take the job (money, revenge, debt, loyalty, curiosity)
- Their relationship with their augmentations is complex (reliance, resentment, pride, fear)
- Moral line: what they WON'T do, and what pushes them toward it

THE FIXER:
- The intermediary between the protagonist and the job
- Knows everyone, trusted by no one
- Their value is their NETWORK. and they charge accordingly
- Has their own survival instinct that sometimes conflicts with the protagonist's needs

THE CORPORATE PRESENCE:
- Not a cartoonish villain. a SYSTEM representative
- May be a middle manager who's also a prisoner of the structure
- Or a high-level exec who's ruthlessly logical, not cruelly emotional
- The corporation as antagonist is INSTITUTIONAL, not personal

THE STREET CONTACT:
- Lives in the cracks: a bartender, a ripperdoc, a dealer, a musician
- Provides the protagonist with information, services, or community
- Their daily life illustrates the world's texture
- They have their own survival calculus

VOICE DIFFERENTIATION:
- Street characters: slang-heavy, direct, compressed
- Corporate characters: polished, euphemistic, controlled
- Tech characters: precise, jargon-natural, sometimes socially awkward
- Fixers: adaptable. they speak everyone's language
- Augmentation affects voice: characters with voice modulators, translation implants, or damaged vocal cords
```

## Arc Rules

```
CYBERPUNK STORY STRUCTURE

ACT 1: THE JOB (first 25%)
- Establish the protagonist's daily survival: their skills, their habits, their crew
- The city is established through LIVING in it (not touring it)
- A job offer arrives: too good, too dangerous, or too personal to refuse
- The client/fixer introduces the parameters. but something feels off
- The protagonist gears up: we see their augmentations, tools, and resources
- END OF ACT 1: They commit to the job (point of no return)

ACT 2A: DOWN THE RABBIT HOLE (to midpoint)
- The job goes sideways. it's not what it seemed
- Each step deeper reveals a bigger picture (corporate conspiracy, data revelation, power struggle)
- The protagonist uses their skills in increasingly dangerous situations
- Alliances form with unreliable people
- The digital and physical worlds overlap: virtual intrusion has physical consequences
- MIDPOINT: A revelation that changes the job's meaning. they're not working for who they thought, or the data means something no one expected

ACT 2B: EVERYTHING BURNS (midpoint to dark moment)
- The corporations/power structures respond to the disruption
- The protagonist's resources are stripped: safe houses compromised, allies threatened, augmentations damaged
- The personal stakes escalate: someone they care about is at risk
- Trust breaks: someone betrays them (or they betray someone)
- The body rebels: augmentation strain, injury, exhaustion
- DARK MOMENT: Captured, cornered, or stripped of their tools and allies

ACT 3: THE RUN (final 25%)
- The protagonist makes a desperate play with whatever they have left
- The climax uses BOTH physical and digital skills
- The resolution is personal: they get what they need, not what the system wanted
- Victory is small-scale: they survive, protect someone, expose a truth, escape
- The system endures. but the protagonist has changed something (even if it's just themselves)
- The street continues. There's always another job.

CYBERPUNK PACING:
- FAST. Chapters are short (2,000-2,500 words is ideal)
- Hard scene breaks between locations and timelines
- Action → aftermath → information → preparation → action
- The reader should feel slightly breathless
```

## Timeline Rules

```
CYBERPUNK TIMELINE

COMPRESSED TIMELINE:
- Most cyberpunk stories span 3-14 days
- The job has a deadline (data expires, window closes, target moves)
- Track: hours matter. A hack at 3 AM is different from one at noon.
- Night is the protagonist's natural habitat. track the day/night cycle

BODY CLOCK:
- Augmentation maintenance schedules
- Stimulant/drug use and crash cycles
- Sleep deprivation accumulating across days
- Injury and healing (often accelerated by biotech, but not instant)

DIGITAL CLOCK:
- Data has an expiry: information becomes worthless when it's old
- Network windows: security cycles, surveillance gaps, maintenance windows
- Encryption and decryption take TIME. it's not instant
- Communication delays in physical-digital hybrid operations
```

## Genre-Specific Craft Techniques

Cyberpunk is a genre with a foundational political DNA
that is constantly at risk of erosion: it began as a
critique of late-capital, corporate power, surveillance,
and the body-as-commodity, and the genre is at its
weakest when it is reduced to neon-and-chrome aesthetic
without the class-conflict, power-gradient, and
embodied-technology stakes that make it function. The
canonical comp roster — Gibson (Neuromancer, the Sprawl
trilogy, the Bridge trilogy), Bruce Sterling
(Mirrorshades, Schismatrix), Neal Stephenson (Snow
Crash, The Diamond Age), Pat Cadigan, Walter Jon
Williams (Hardwired) — established the form; the
contemporary masterclass roster — Lauren Beukes
(Moxyland, Zoo City), Hannu Rajaniemi (Quantum Thief),
Chen Qiufan (Waste Tide), Cory Doctorow (Little
Brother), Annalee Newitz (Autonomous), Malka Older
(Infomocracy), Tochi Onyebuchi (Riot Baby), Tade
Thompson, Charlie Jane Anders, Naomi Alderman, Daniel
Suarez (Daemon) — has updated the genre's pressure
points to surveillance capitalism, gig labour,
algorithmic governance, climate-collapse compounding,
and the post-2010 power configuration of platform
monopolies, sovereign-wealth states, and biotech as
capital. The most common failure modes in this register
are: **Chrome-Without-Stakes** (the cyberpunk aesthetic
— neon, rain, augmentation — present without the
political and economic pressure that makes cyberpunk
cyberpunk; the protagonist has chrome but no rent
crisis); **Dystopian-Aesthetic-as-Substance** (corporate
dystopia rendered as wallpaper rather than as material
force on the protagonist's day-to-day); **Nostalgic-
80s-Pastiche** (Gibson cosplay rather than 2026
cyberpunk sensibility — the genre frozen in its
founding decade, with cassette-futurism imagery
substituted for the current present's actual
surveillance / platform / AI / climate pressure
configuration); **Corporate-Evil-Monoculture** (the
megacorp as cardboard villain rather than as
institutional structure with internal logic,
careerists, true believers, and middle managers caught
in the same net the protagonist is); **Tech-Lecture
Substitution** (technology specs delivered as
exposition rather than rendered through sensation —
"her type-4 neural interface operated at 12.8
terahertz" rather than the buzz in the teeth, the data
shadow on the wall, the specific physical sensation of
augmentation in use); **Magic-Hacking** (hacking
rendered as button-pressing or visualization-tour
rather than as physical, time-pressured, skill-based
labour with concrete consequence — the lone teen who
brings down the corporation from a bedroom in seven
minutes flat); **Body-as-Backdrop** (augmentation
mentioned but never felt; the protagonist who has
chrome but lives in a meat-suit when narratively
convenient and a chrome-suit when narratively
convenient); and **Apolitical-Cyberpunk** (the genre's
political DNA ignored; cyberpunk as flavour rather than
as critique). The techniques below — two preserved
(Sensory Stack, Augmentation-as-Character) and three
added (Power-Gradient Rendering, Surveillance-Texture
Discipline, Subgenre-Calibration Discipline) — are
designed to keep the genre's defining tensions live:
high tech AND low life; aesthetic density AND political
substance; the body augmented AND the body still
mortal; the corporate power vast AND the street finding
its own uses.

### The Sensory Stack

Every cyberpunk scene should layer senses in rapid succession:

```
The alley smelled like frying oil and synthetic jasmine from the
vending machines. Neon from the Tycho pharmacy sign turned the
puddles green. Someone's speaker system pumped bass through the
wall hard enough to feel in his back teeth. His new Kiroshi eye
was flagging three hostiles at thirty meters, their threat
indices pulsing amber in the upper right of his vision.

Sound → Smell → Light → Touch → Digital overlay
(5 senses in 4 sentences. that's cyberpunk prose density)
```

### The Augmentation-as-Character Technique

Augmentations are not tools. they're part of the character:

- They have quirks (the cybernetic hand that grips too tight when he's stressed)
- They have history (the eye he got from a dead friend, the arm that was corporate-issue before he defected)
- They betray at the worst moment (the interface that lags during a critical hack)
- They define what the character CAN do. and therefore who they ARE

### Cyberpunk AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the neon-soaked streets" | Show ONE specific light source and what it illuminates |
| "jacked into the matrix" | Show the specific sensory experience of connection |
| "corporations controlled everything" | Show the specific control mechanism affecting this character |
| "the line between human and machine blurred" | Show the specific augmentation and its specific trade-off |
| "data streams flowed like rivers" | Show the specific data and what it means to the character |
| "the underground resistance" | Name the specific group, leader, or hideout |
| "chrome and concrete" | Pick ONE architectural detail that tells a story |
| "hackers were the new outlaws" | Show the specific hack and its specific consequence |
| "the price of augmentation" | Show the specific physical or psychological cost |
| "in the shadow of the megacorps" | Show the specific corporate action affecting this street |
| "the net was a dangerous place" | Show the specific threat encountered |
| "humanity was being left behind" | Show one person's specific struggle with obsolescence |
| "the corporate boot on the neck of the working class" | Show the specific corporate action affecting THIS character today |
| "the AI was learning" | Show the specific behaviour change through one specific encounter |
| "she felt the cold logic of the machine" | Cut "cold logic"; show the specific machine response and the specific human cost |
| "her chrome was an extension of her" | Show the specific extension through one gesture or moment of dependency |
| "the deepweb pulsed with secrets" | Show ONE specific deepweb encounter and its concrete payoff or threat |
| "another night in the city" | Cut; open with the specific scene-starting sensory detail |

### The Power-Gradient Rendering

Cyberpunk's defining pressure is the gulf between
corporate power and street-level survival, and the
genre fails when this gulf is told but not shown. The
Power-Gradient Rendering is the requirement that every
chapter register the gulf through concrete material
pressure on the protagonist's actual day. not in
narration ("the corporations controlled everything"),
not in dialogue ("the megacorps run this town"), but
in the rent calculation, the data tax, the gig
algorithm, the surveillance feed she has to scrub
every morning, the corporate building visible from
her window, the medical bill she cannot pay, the
augmentation she rents because she cannot afford to
own.

```
PRINCIPLE
Every chapter must contain at least one CONCRETE
power-gradient pressure point — a moment where the
gulf between corporate power and street survival is
felt as material force on the protagonist:
1. ECONOMIC: rent due, food cost, gig pay below cost
   of survival, medical debt, augmentation-on-credit,
   data-tax extraction, paywall on basic information
2. ALGORITHMIC: the gig app that just docked her
   rating; the credit score that just dropped because
   of an associate's politics; the predictive
   policing that just flagged her route home
3. SURVEILLANCE: the camera she had to walk around;
   the public/private negotiation in every
   conversation; the scrubbing protocol that's now a
   habit
4. SPATIAL: the corporate tower she can see but
   cannot enter; the neighbourhood being gentrified
   by a tech firm; the level she lives on vs. the
   level the boss lives on
5. INSTITUTIONAL: the contract she cannot read; the
   non-disclosure she signed for a job she never
   actually got; the fine print that turns out to
   matter

CALIBRATION TEST
- If you removed all the cyberpunk aesthetic elements
  (the neon, the chrome, the augmentations) from this
  chapter, would the reader still feel the corporate-
  versus-street gulf as material pressure on the
  protagonist?
- Does the protagonist's daily survival cost SOMETHING
  in this chapter — money, body, time, dignity, data,
  options?
- Is the gulf SHOWN through specific material pressure
  rather than told through narration or dialogue?
If any answer is no — rebuild for material specificity.

ANTI-PATTERN
- The narration that announces the dystopia ("the
  corporations had taken everything")
- The chrome-without-stakes protagonist (cool gear,
  no rent crisis, no debt, no surveillance pressure)
- The cyberpunk world as set-dressing rather than as
  active material force
- The protagonist whose problems are personal-only
  (a vendetta, a love affair, a missing friend) with
  no system pressure pressing on those problems
```

### The Surveillance-Texture Discipline

Contemporary cyberpunk operates in a surveillance
configuration that the genre's founding decade did not
fully imagine. ubiquitous facial-recognition, platform-
held location data, algorithmic advertising profiles,
predictive policing, sovereign-wealth-state monitoring,
employer telemetry, sousveillance counter-surveillance,
deep-fake disinformation, and the inversion where
private citizens hold camera-arrays and corporate
states hold the back-end. The Surveillance-Texture
Discipline requires that this layer of always-watching
be rendered as ambient texture rather than as
foregrounded plot. the cameras the character avoids
without thinking, the scrubbing protocol she runs every
morning, the public/private gear-shift in every
conversation, the way she holds her phone, the way she
covers her face when she pays cash for the rare cash
transaction.

```
PRINCIPLE
The surveillance texture must be rendered through at
least three of the following layers in any given
chapter:
1. AMBIENT — the cameras / drones / sensors visible
   in the environment, registered without comment
   because they are the wallpaper of the world
2. PROTOCOL — the specific habits the protagonist has
   built around being watched (the scrubbing, the
   masking, the fake-name purchase, the burner phone
   ritual)
3. CALCULATION — the specific moment-by-moment
   public/private negotiation (what she says aloud
   vs. what she texts; what she texts vs. what she
   only thinks; what she risks vs. what she
   refuses)
4. SLIPPAGE — the moment she forgets the surveillance
   and pays for it (the unguarded comment, the face
   shown to the wrong camera, the metadata she
   should have stripped)
5. INVERSION — the moments where the protagonist or
   her crew use the surveillance machinery in
   reverse (counter-surveilling a corp, exposing a
   bad actor, triangulating a target)

CALIBRATION TEST
- Is the surveillance state present in the chapter
  as ambient texture, not just as plot device?
- Does the protagonist behave like someone who has
  lived under surveillance for years (specific
  habits, specific instincts, specific fluency)
  rather than someone who has just discovered the
  cameras?
- Are there moments of PROTOCOL — specific learned
  behaviour — that signal long inhabitance?
- Is at least one moment of slippage or inversion
  present somewhere in the manuscript?
If any answer is no — rebuild.

ANTI-PATTERN
- Surveillance present as plot device only (the
  protagonist gets caught on camera in chapter 14,
  but for chapters 1-13 the world has no cameras)
- Surveillance announced ("we live under constant
  surveillance") rather than felt
- The protagonist who behaves like a 1985 character
  in a 2045 setting
- The world where surveillance is omnipresent but
  no character has built habits around it
```

### The Subgenre-Calibration Discipline

Cyberpunk has six subgenres listed in this file (Classic
Cyberpunk, Post-Cyberpunk, Biopunk, Nanopunk, Solarpunk-
Adjacent, Noir Cyberpunk), and each requires a different
prose register, different worldbuilding emphasis,
different stakes, and different ending shape. The
Subgenre-Calibration Discipline is the requirement that
the manuscript commit to one subgenre and render its
specific texture, rather than blending them into a
generic cyberpunk wallpaper that satisfies neither the
classical reader nor the contemporary reader.

```
PRINCIPLE
At setup, the subgenre is chosen. The manuscript must
then render that subgenre's specific texture:

CLASSIC CYBERPUNK (Gibson / Sterling / Williams):
- Tone: noir-tilted, slightly nihilist, street-survival
- Tech: cybernetic implants, neural jack, the matrix
- Stakes: corporate conspiracy, data heist, individual
  survival in the face of the system
- Ending: the system endures, the protagonist survives
  with scars

POST-CYBERPUNK (Stephenson / Doctorow / Newitz):
- Tone: less nihilist, more constructive, building in
  the cracks
- Tech: cybernetic but networked, distributed, often
  open-source-coded
- Stakes: building something that lasts; hope as
  political act
- Ending: a small win, a community formed, a system
  changed at the edge

BIOPUNK (Bear / Bacigalupi / Naam):
- Tone: body horror adjacent, evolution as commodity
- Tech: genetic modification, organic interfaces,
  designer biology
- Stakes: bodily autonomy, biotech ownership, species-
  level transformation
- Ending: the body transformed, the species changed,
  the question of what counts as human

NANOPUNK (Rajaniemi / KSR / late-Stephenson):
- Tone: more abstract, more cosmic, scale-shifting
- Tech: molecular-scale manipulation, invisible
  infrastructure, programmable matter
- Stakes: the world's substance itself contested;
  reality as software
- Ending: the world rewritten at small scale, with
  consequences only the protagonist can see

SOLARPUNK-ADJACENT (Robinson / Doctorow / Older):
- Tone: hope under pressure, post-collapse rebuilding,
  green-and-chrome
- Tech: cybernetic alongside renewable, climate-aware
- Stakes: surviving collapse, building post-collapse,
  political alternatives
- Ending: a future glimpsed, contingent, hard-won

NOIR CYBERPUNK (Beukes / Cadigan / classic-tilt):
- Tone: detective-procedural, mystery-driven,
  investigation-shaped
- Tech: cybernetic, but the investigation is the spine
- Stakes: the case, the truth, the body in the alley
- Ending: the case closed, the truth costly, the
  protagonist marked

CALIBRATION TEST
- Is the subgenre's specific texture rendered in this
  chapter, or has the manuscript drifted to generic
  cyberpunk wallpaper?
- Does the prose register match the subgenre's tone
  expectation?
- Do the stakes match the subgenre's specific
  question (survival vs. building vs. embodiment vs.
  reality vs. collapse vs. case)?
- Will the ending shape match the subgenre's
  contract?
If any answer is no — recalibrate.

ANTI-PATTERN
- Generic-cyberpunk-blend that satisfies no subgenre
- Subgenre announced at setup but not rendered in
  prose
- Mismatched ending shape (a Classic-Cyberpunk
  manuscript with a post-cyberpunk happy ending; a
  Solarpunk-Adjacent manuscript that ends in
  nihilism)
- Subgenre-tourism (sampling tropes from multiple
  subgenres without committing to any)
```

## Genre-Specific Revision Rules

### Six-Pass Cyberpunk Audit (Run FIRST in editorial pipeline)

The Cyberpunk Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Sensory Density Pass

Verify the chapter delivers high sensory density at
cyberpunk pace. At least three senses should be engaged
per scene (sight, sound, smell, touch, taste, plus the
genre's signature sixth — digital overlay / interface
sensation), and the density should be packed into short
sentences rather than spread thin across long
paragraphs. The Sensory Stack technique (one sense per
short sentence, stacked rapid-fire) is the genre's
signature; verify the chapter executes this rather
than describing the world in long expository
paragraphs. The city / world must FEEL overwhelming and
specific, not generic. neon, rain, and chrome alone are
not enough; specific neon (which sign, what it
advertises, what colour the puddles turn), specific
rain (what kind, what it smells like, what it sounds
like on the awnings), specific chrome (whose, what
make, with what scratches and field-history). If the
chapter's sensory density could appear in any cyberpunk
novel ever written, it has not been done.

#### Pass 2: Body-Tech Integration Pass

Verify augmentations are mentioned AND felt. The
Augmentation-as-Character technique requires that
augmentations have quirks, history, present-tense
sensation, and identity weight. Audit each chapter:
when does the protagonist's augmentation make itself
felt? Is there a physical sensation (the buzz, the
phantom pain, the cooldown lag, the calibration drift,
the body rejecting the foreign hardware)? Is there a
quirk (the hand that grips too hard when stressed; the
eye that flares when she's lying; the interface that
glitches in cold weather)? Is there a history (whose
chrome was this before; what it cost her; what she
gave up to get it)? Is there a present-tense identity
weight (does she feel more herself with the chrome or
less; does the chrome become her or remain a tool)? If
augmentation is mentioned but never rendered through
sensation and history, it is set-dressing and must be
rebuilt.

#### Pass 3: Class/Power Analysis Pass

Verify the gulf between corporate power and street
survival is visible and material. The Power-Gradient
Rendering technique is the spec for this pass: every
chapter must contain at least one CONCRETE power-
gradient pressure point — economic, algorithmic,
surveillance, spatial, or institutional — applied to
the protagonist's actual day. If you removed all the
cyberpunk aesthetic elements from this chapter, would
the reader still feel the corporate-versus-street gulf
as material pressure on the protagonist? If no, the
chapter has slipped into Chrome-Without-Stakes failure
mode and must be rebuilt for material specificity. The
protagonist's position in the power hierarchy should
be visible through her daily friction with the system,
not announced in narration.

#### Pass 4: Pacing Pass

Cyberpunk pacing is tight, urgent, propulsive. Verify
chapters are under 3,000 words ideally (genre target
2,000-3,500). Verify every scene advances plot or
deepens character — no scene exists purely to deliver
worldbuilding or technology specs. Verify there are no
technology lectures (the type-4-neural-interface-
operates-at-12.8-terahertz failure); when tech needs to
be communicated, it is communicated through sensation
and consequence rather than through specification.
Verify action sequences are brief (4-8 word sentences,
high verb density, immediate impact and consequence)
rather than choreographed at length. Read the chapter
aloud at a jog's pace — if you are not breathing
faster by the end, the prose has not earned the
genre's rhythm and must be tightened.

#### Pass 5: Tech-Through-Sensation + Magic-Hacking Pass

Verify all technology in the chapter is rendered
through sensation rather than through specification.
For each piece of technology mentioned, ask: what does
this FEEL like? What does it taste / smell / sound /
look like in use? What does it do to the body? What
does it cost in attention, in metabolic load, in
mental bandwidth? If the technology appears as a
black-box mechanism without sensory rendering, rebuild.
For each hacking sequence, verify the hack is PHYSICAL.
sweat, headaches, the taste of copper, fingers
cramping, the time pressure that registers in the
body, the consequence that lands when the hack
succeeds (the lock opens, the door un-locks, the
alarm doesn't fire) and a different consequence when
it fails (the trace runs, the ICE bites back, the
neural feedback drops her). The Magic-Hacking failure
mode (button-press, visualization-tour, no body, no
time, no risk) must be caught and rebuilt here. Hacking
is the genre's signature labour. it must be rendered
as labour.

#### Pass 6: Power-Gradient + Surveillance-Texture + Subgenre-Calibration Integration

This pass is the cyberpunk integration check — it ties
the new techniques together and verifies the genre's
political and structural commitments are honoured
chapter by chapter.

For POWER-GRADIENT: confirm Pass 3's spec has been met
through specific material pressure; identify the
specific moment in the chapter where the corporate-
versus-street gulf landed on the protagonist's body or
day. If absent — rebuild.

For SURVEILLANCE-TEXTURE: identify the chapter's
surveillance layer rendering. Are at least three of
the five layers (ambient / protocol / calculation /
slippage / inversion) present somewhere in the
manuscript, with the current chapter contributing to
at least one? Does the protagonist behave like
someone who has lived under surveillance for years
(specific habits, specific instincts, specific
fluency), rather than someone who has just discovered
the cameras? If the surveillance layer is absent or
treated as 1985-cyberpunk vintage rather than 2026-
cyberpunk current, rebuild for contemporary
specificity.

For SUBGENRE-CALIBRATION: identify the manuscript's
chosen subgenre (Classic / Post / Biopunk / Nanopunk /
Solarpunk-Adjacent / Noir). Verify this chapter's
prose register, worldbuilding emphasis, and stakes
match the chosen subgenre's contract. If the chapter
has drifted to generic-cyberpunk-blend, recalibrate to
the chosen subgenre's specific texture. Verify the
ending shape (whether the manuscript-level ending or
this chapter's micro-ending) matches the subgenre's
contract — Classic ends in survival-with-scars;
Post ends in small-win; Biopunk ends in transformation;
Nanopunk ends in reality-rewritten; Solarpunk-Adjacent
ends in hope-under-pressure; Noir Cyberpunk ends in
case-closed-at-cost. Mismatch is the most common late-
manuscript failure and the most expensive to fix in
revision. catch it here.

## Names & Patterns to Avoid

### Cyberpunk Character Names. NEVER USE
- Overused cyberpunk names: Nyx, Zero, Cipher, Ghost, Razor, Echo, Glitch
- Japanese names as default "cyber" aesthetic (unless the setting is specifically Japanese-influenced)
- All-caps or numeral names: Z3R0, H4CK, NOVA

### Cyberpunk Place Names. NEVER USE
- "Neon [Noun]": Neon District, Neon Alley, Neon City
- "[Tech Company] + [Tower/Block]": OmniCorp Tower, SynTech Block
- "The Grid", "The Net", "The Matrix" (too directly associated with existing IP)

### Use Instead
- Real-feeling multicultural names reflecting the city's demographics
- Corporate names that sound plausible: Tessier-Ashpool (Gibson), Arasaka, Militech. create your own with that realistic corporate DNA
- Street names and handles that feel earned, not assigned: "Switchback" (because she always finds an alternate route), "Forty" (because she's paid for forty augmentations, half on credit)

## Comp Titles

Cyberpunk's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Neuromancer* — William Gibson (1984): the cyberpunk founding text.
- *Mirrorshades* — Bruce Sterling, ed. (1986): cyberpunk anthology defining the movement.
- *Snow Crash* — Neal Stephenson (1992): post-cyberpunk satire benchmark.
- *Hardwired* — Walter Jon Williams (1986): military-cyberpunk template.

### Contemporary (current best-in-class)

- *Moxyland* — Lauren Beukes (2008): post-apartheid cyberpunk; updated genre register.
- *Little Brother* — Cory Doctorow (2008): YA-cyberpunk activism-thriller.
- *Quantum Thief* — Hannu Rajaniemi (2010): post-singularity cyberpunk benchmark.
- *Waste Tide* — Chen Qiufan (2013, 2019 translation): contemporary Chinese eco-cyberpunk.
- *Autonomous* — Annalee Newitz (2017): biotech-cyberpunk with patent-system critique.
- *Riot Baby* — Tochi Onyebuchi (2020): cyberpunk-adjacent speculative with race-and-tech architecture.
- *The Gone World* — Tom Sweterlitsch (2018): time-travel-cyberpunk hybrid.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Neon-lit cityscapes, rain-slicked streets, figures silhouetted against urban glow; the DOMINANT cyberpunk aesthetic; immediately recognizable
- **Graphic**. Bold, high-contrast design with neon accents on black; circuit-board or digital motifs; striking and modern
- **Minimalist**. A single cybernetic element (an augmented eye, a circuit pattern, a neural interface) against a dark background with neon accent; clean and effective
- **Illustrated**. Digital painting of the world's specific aesthetic: street markets, augmented characters, towering architecture; immersive and detailed

### Genre Cover Aesthetics
- **Styles:** Rain-slicked urban streets lit by neon, vertical cityscapes with extreme height contrast, lone figures with visible augmentation, digital/holographic overlay effects, the contrast between dark alleys and bright advertising, dense urban environments with visible class stratification
- **Colours:** Neon cyan/teal (the signature cyberpunk colour), hot pink and magenta (nightlife, entertainment district), toxic green (hacking, the net, code), amber and gold (street-level warmth, sodium lights), deep black with neon highlights, violet and purple (the digital realm)
- **Elements:** Neon signage (especially non-English characters), rain and wet surfaces reflecting light, cybernetic limbs and augmented eyes, circuit patterns and code, urban density (wires, pipes, signs, levels), holographic advertising, masks and visors, street-level commerce (food stalls, market stalls, clinics)
- **Typography:** Glitch effects, digital distortion, monospace or tech-inspired fonts; neon glow treatment; can include "code" elements; title should feel like a screen display or a street sign; bold and readable despite effects

### Market Positioning
Cyberpunk covers must signal "neon, grit, and high technology" instantly. The genre has a strong visual identity. lean into it while finding a specific angle. Position against Gibson, Stephenson, Doctorow, Chen Qiufan, Rajaniemi. The neon-on-dark palette is almost mandatory. At thumbnail size, the contrast between black backgrounds and bright neon elements creates immediate recognition.

### Cover Design DON'Ts
- No clean, corporate-Apple aesthetic. cyberpunk is messy, layered, and worn
- No bright daytime scenes. cyberpunk lives at night
- No generic sci-fi spaceships or planets. cyberpunk is urban and earthbound (usually)
- No cutesy or cartoonish illustration. cyberpunk is gritty and adult
- No Matrix-green-code-on-black as the primary design (too specific and dated)
- No "sexy cyborg" poses. this signals a different genre/audience
