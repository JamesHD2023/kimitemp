---
name: western-genre
description: Genre-specific instructions for western fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Western. Genre Plugin

## Metadata
- id: western
- name: Western
- icon: 🤠
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "The Hero's Journey", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Classic Western**. The lone figure in the landscape: justice, honour, and violence in a world without law; the tradition of L'Amour, McMurtry, Portis
- **Revisionist Western**. The mythology challenged: Indigenous perspectives, the cost of colonialism, women's experiences, the West as it was rather than as Hollywood told it
- **Modern/Neo-Western**. Contemporary setting, western themes: border stories, ranching communities, small-town law, the frontier spirit in a modern world
- **Weird Western**. Supernatural elements in western settings: horror on the frontier, magic in the desert, cosmic dread under open skies
- **Literary Western**. The West as literary landscape: McCarthy, Proulx, Kingsolver. the land, the people, and the hard beauty of survival
- **Western Noir**. Crime and moral ambiguity in western settings: corrupt sheriffs, desperate outlaws, frontier towns with dark secrets

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: The rhythm of the land. long stretches of journey and observation punctuated by sudden, violent action; the West demands patience and rewards it with intensity
- Must open with: The LANDSCAPE. not described from above but experienced from within; the reader should feel the sun, the wind, or the cold before they meet the character

BEATS PER CHAPTER
1. Landscape Beat. The land is present and felt: distance, weather, terrain, the physical challenge of being HERE
2. Code Beat. The moral code is tested: honour, loyalty, justice, survival. the western's central question of how to live rightly in a lawless place
3. Encounter Beat. A meeting with another person or group: friend, enemy, stranger. in the West, every encounter carries risk
4. Violence Beat. Present, threatened, or remembered; violence in westerns is not gratuitous but consequential
5. Solitude Beat. The aloneness of the protagonist: with their thoughts, their horse, the sky; the interior life of a person who speaks little

WESTERN ARCHITECTURE
- The LANDSCAPE is the first character: it is beautiful, indifferent, and lethal
- The CODE matters more than the law: what a person will and won't do defines them more than any badge or warrant
- VIOLENCE is meaningful: every act of violence has a cause, a cost, and a consequence
- SILENCE is a language: western characters say less and mean more; the unsaid dominates
- The FRONTIER is a state of mind: the edge between civilization and wilderness, law and lawlessness, the known and the unknown
- SURVIVAL is daily: heat, cold, thirst, hunger, distance. the body works for its life
- HORSES are essential: track them, know them, respect them; they're partners, not vehicles
- POV: Third person past (the dominant western voice. laconic, observational) or first person past

THE LAND
- The western landscape is NOT backdrop. it's the most powerful force in the story
- Describe it through EXPERIENCE: the protagonist walks, rides, shelters, and struggles through it
- Weather is plot: a storm can kill, a drought can starve, a river can block an escape
- Distance is drama: how far to the next town, how far behind are the pursuers, how far can a man ride before his horse fails
- The beauty is part of the danger: a stunning sunset means another cold night coming

FORBIDDEN IN WESTERNS
- Cowboys and Indians as simple heroes and villains (engage with the real history)
- Bloodless violence (if someone gets shot, it's ugly and it hurts)
- The West as playground (it was a hard place where people died of exposure, thirst, and disease)
- Talkative protagonists (western heroes are defined by what they DON'T say)
- Modern moral frameworks imposed on frontier characters (they lived by different rules)
- Ignoring Indigenous peoples, Mexican communities, Black cowboys, Chinese railroad workers. the West was diverse
- The horse as a car (horses have personalities, limits, and needs)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (action), Captivation (landscape & code), Validation (justice / honor delivered).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Third person past (laconic, observational. the classic western voice) or first person
- Voice: Spare, precise, stripped of decoration. every word carries weight because there are so few of them
- Tone: Austere beauty. the grandeur of the landscape and the hardness of the life, both respected
- Register: Simple vocabulary, short sentences, the cadence of speech in a place where words cost effort

PROSE IMPERATIVES
- ECONOMY: western prose is the leanest of any genre
  - Short sentences. Declarative. Subject-verb-object.
  - Every adjective must earn its place (most don't)
  - The landscape is described precisely but not lushly
  - One perfect detail replaces three adequate ones
- THE LAND AS PROSE: landscape description should FEEL like the land
  - Flat land = flat sentences. Mountain terrain = sentences that climb. Desert = dry, spare prose.
  - The prose rhythm matches the journey: slow travel, sudden action, quiet aftermath
- SILENCE IN PROSE: what's NOT written matters
  - Leave space between scenes: white space on the page mirrors the space of the landscape
  - Emotion is implied, not stated: a man looks at the grave and puts his hat back on. that's grief
  - The reader fills the silence with feeling
- PHYSICAL PRECISION: the western world is described through exact physical detail
  - Guns: type, calibre, condition (a Colt .45 is different from a Winchester repeater)
  - Horses: breed, temperament, condition (a tired horse moves differently)
  - Terrain: specific rock, specific grass, specific colour of sky at specific time
  - Weather: temperature, wind direction, cloud type. not "it was hot" but "the air shimmered above the flat"

DIALOGUE CRAFT
- ECONOMY: western dialogue is the shortest in any genre
- Characters say as little as possible: "Yep." "Nope." "Obliged."
- When they DO speak at length, it matters: a monologue in a western is a confession or a sermon
- Dialect without caricature: the rhythm and vocabulary of frontier speech, not parody
- The threat: a quiet statement that carries the weight of violence ("I'd think about that if I were you")
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. WESTERN

OPENING: Landscape + independence + conflict. The land comes first. sun, wind, or
cold before the character. The protagonist arrives in motion, defined by action.
Economy is everything: say less, mean more.

SENTENCES: Medium, 14-20 words. economical, declarative, frontier cadence.
Subject-verb-object backbone: "He rode. The land was flat. Nothing moved." Short
(5-10) for impact. Rare longer (22-28) only for landscape that breathes across
terrain. Rhythm matches journey: steady, patient. then sudden for violence.

VOCABULARY: Every adjective must earn its place; most don't. Physical precision: gun
types, horse breeds, terrain named exactly. One perfect detail replaces three. Anglo-
Saxon dominates. hard, plain words for hard, plain land.

DIALOGUE: Spare, understated. the shortest in any genre. "Yep." "Obliged." Silence
between lines carries meaning. A long speech is an event. The quiet threat: sentences
carrying violence without raising their voice.

TENSION FLOOR: ≥5. The landscape is a threat: distance, exposure, isolation. Conflict
present or approaching. The protagonist's code visible and about to be tested.
Every stranger is a question mark.

RHYTHM: Open with landscape (3-5 sentences, physical world experienced). Introduce
protagonist through action. A single spare dialogue exchange. Close with forward
momentum and the shadow of conflict. White space mirrors the land.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

WESTERN CRAFT (40% of total):
- The landscape is a living, active presence? (0-100)
- The moral code drives character decisions? (0-100)
- Violence is consequential (not gratuitous or bloodless)? (0-100)
- Silence and economy are used effectively? (0-100)

STORY CRAFT (30% of total):
- The protagonist's code is clear and tested? (0-100)
- Stakes are personal and felt? (0-100)
- The West is rendered honestly (not mythologised or sanitised)? (0-100)
- The ending resonates (often bittersweet)? (0-100)

PROSE QUALITY (30% of total):
- Prose is lean, precise, and economical? (0-100)
- Physical detail is exact (guns, horses, terrain, weather)? (0-100)
- Dialogue is spare and weighted? (0-100)
- Emotion is implied rather than stated? (0-100)

AUTOMATIC FAILS (score = 0):
- Cowboys-and-Indians stereotypes
- Bloodless or gratuitous violence
- Talkative, introspective protagonist who narrates feelings
- The landscape is absent or generic
- Horses treated as vehicles (not animals)
- Modern moral frameworks imposed on frontier characters
```

## Continuity Rules

```
WESTERN CONTINUITY. WHAT TO TRACK

THE LAND:
- Geography: distances between locations, terrain features, water sources
- Weather: temperature, precipitation, wind. tracked across days
- Season: affects everything (water, grass, temperature, daylight hours)
- Trail: where the protagonist has been and where they're heading

PHYSICAL STATE:
- Injuries: gunshot wounds, broken bones, exposure. they don't heal quickly on the trail
- Supplies: water, food, ammunition. finite and tracked
- Horse condition: tired, lame, thirsty, injured. the horse's state limits the rider
- Clothing: worn, damaged, weather-appropriate

FIREARMS:
- What weapons each character carries
- Ammunition count: track shots fired and rounds remaining
- Weapon condition: a dropped revolver may misfire, a wet rifle may jam
- Range and accuracy: a pistol at 50 yards is different from a rifle

SOCIAL STATE:
- Reputation: what's known about the protagonist in each town
- Alliances: who's friendly, hostile, or neutral
- Law: is there a sheriff? A marshal? A bounty? What's the legal situation?
- Debts: who owes whom (money, favours, revenge)

HORSE STATE:
- Name, breed, temperament
- Condition: rested, tired, injured, well-fed or hungry
- Shoes: when last shod, condition of hooves
- Relationship with rider: trust, nervousness, responsiveness
```

## Character Rules

```
WESTERN CHARACTER TYPES

THE PROTAGONIST:
- Defined by ACTIONS, not words: what they do reveals who they are
- Competent: they can ride, shoot, survive. these skills are EARNED, not given
- A code: personal honour, loyalty to a few, justice by their own definition
- Silent: speaks rarely, never unnecessarily; their silence is strength, not emptiness
- Wounded: something in their past drives them (but they don't talk about it)
- Alone: by choice or circumstance; self-reliance is the western's defining virtue

THE PARTNER:
- A different flavour of competence: where the protagonist is strong, the partner compensates
- They talk more than the protagonist (almost everyone does)
- Trust built through shared danger, not conversation
- They may die: the western partner is the genre's most vulnerable character

THE VILLAIN:
- As competent as the protagonist (often more so)
- Their code is DIFFERENT, not absent: they have their own logic
- They represent something the protagonist opposes: greed, cruelty, chaos, or a competing vision of justice
- Respect between adversaries: the best western villains and heroes understand each other

THE TOWN:
- The community the protagonist enters or protects
- Represents civilization: its strengths (community, law, home) and its weaknesses (fear, corruption, conformity)
- The town's decision. to fight or submit. mirrors the protagonist's own choice

VOICE DIFFERENTIATION:
- The protagonist: few words, precise, understated
- The partner: more voluble, possibly humorous, bridges the protagonist and the world
- The villain: articulate, reasonable, the most verbal character (their words are their weapons)
- Townspeople: varied, colloquial, representing the community's range
```

## Arc Rules

```
WESTERN STORY STRUCTURE

ACT 1: THE ARRIVAL (first 25%)
- The protagonist arrives: into a town, onto a trail, at a ranch. the situation is established
- The landscape is felt: the reader is placed in the physical world
- The problem is introduced: a threat, a job, a quest, a score to settle
- The protagonist's code is demonstrated through action (not explained)
- END OF ACT 1: The protagonist decides to engage (or is forced to)

ACT 2A: THE GATHERING STORM (to midpoint)
- The situation develops: allies found, enemies assessed, the lay of the land understood
- Violence threatens: skirmishes, confrontations, warnings
- The protagonist's past surfaces: what drove them here, what they're running from or toward
- The stakes become personal: it's not just a job, it's about something that matters
- MIDPOINT: First major confrontation. and it goes badly; the protagonist is outgunned, outmanoeuvred, or wounded

ACT 2B: THE RECKONING (midpoint to dark moment)
- The protagonist is diminished: injured, isolated, doubted
- The villain is ascendant: their power is visible, their threat is real
- The moral question intensifies: what is the protagonist willing to do? What's too far?
- Allies are lost or tested: betrayal, cowardice, or death
- DARK MOMENT: The protagonist is alone, wounded, and facing a choice between their code and their survival

ACT 3: THE SHOWDOWN (final 25%)
- The protagonist chooses their code (even if it means death)
- The final confrontation: direct, physical, consequential
- The violence resolves the conflict. but the cost is visible
- The aftermath: the town is safe (or changed), the protagonist survives (or doesn't)
- The departure: the protagonist rides away. the west continues, indifferent and beautiful

WESTERN PACING:
- Slow build, explosive climax: the western earns its violence through patience
- Travel scenes establish rhythm: the long ride, the campfire, the dawn
- Action scenes are BRIEF: real gunfights last seconds; draw it out and you lose authenticity
- The ending is quiet: after the noise of the climax, the final pages are silent
```

## Timeline Rules

```
WESTERN TIMELINE

JOURNEY TIMELINE:
- Distance between locations: measured in days on horseback (20-30 miles/day typical)
- Track water sources: in desert territory, this is life and death
- Seasons: winter travel is dangerous; summer heat kills

DAYLIGHT TIMELINE:
- Dawn, noon, dusk, night: each has its own western character
- Firelight vs. darkness: what can be seen, what's hidden
- The stars: navigation, time-telling, the vastness above

PHYSICAL TIMELINE:
- Gunshot wounds: without modern medicine, infection is likely; recovery takes weeks
- Starvation: affects cognition and physical ability within days
- Exposure: hypothermia, heat stroke, dehydration. the timeline of environmental death
```

## Genre-Specific Craft Techniques

Western is the genre-specific cultural register of the
American frontier, sitting adjacent to historical fiction
(period authenticity), adventure (action-driven journey),
and survival (environmental hostility) but with a distinct
contract: the form's cultural mythology, prose register,
moral framework, and landscape-character relationship are
specific to a body of literary and cinematic tradition that
the form's reader brings particular expectations to. The
cluster includes traditional western (post-Civil War through
1900-ish), revisionist western (questioning the form's
inherited assumptions), modern western (contemporary settings
that retain the form's register), space western (sci-fi
inheritance), Acid Western (literary-experimental), and
the broader "frontier fiction" range. Comp authors span the
canonical lineage (Owen Wister's *The Virginian*, Zane Grey's
*Riders of the Purple Sage*, Louis L'Amour's deep backlist,
Jack Schaefer's *Shane*, A.B. Guthrie Jr's *The Big Sky*,
Walter Van Tilburg Clark's *The Ox-Bow Incident*, Charles
Portis's *True Grit*, Larry McMurtry's *Lonesome Dove* and
*Streets of Laredo*, Cormac McCarthy's *Blood Meridian* and
the Border Trilogy, Annie Proulx's *Close Range* and
*Brokeback Mountain*) through the contemporary expansion
(Philipp Meyer's *The Son*, Patrick deWitt's *The Sisters
Brothers*, Hernan Diaz's *In the Distance*, Téa Obreht's
*Inland*, Anna North's *Outlawed*, Brandon Hobson, C
Pam Zhang's *How Much of These Hills Is Gold*, Lauren Groff's
*The Vaster Wilds*, Téa Obreht again, Jack Carr at the modern-
western edge, Craig Johnson's *Longmire* on the contemporary-
mystery cross, Peter Heller's *The Dog Stars* and *The River*
on survival cross-edge, Ron Hansen's *The Assassination of
Jesse James*, James Carlos Blake's outlaw-novels, Tomás
Rivera, Rudolfo Anaya, Ana Castillo on the Chicano-western
edge, James Welch and Louise Erdrich on the Indigenous-
western edge). The techniques below are how the form
delivers its core pleasures while avoiding the failure
modes (cinematic-cliché register that signals movie-western
rather than literary western; mythic-vagueness where
specific historical reality should operate; moral-clarity
register that the form has long since complicated; the
inherited erasures the form has been progressively reckoning
with).

### The Landscape as Emotion

The land expresses what the character won't. Western's
distinctive interior craft: protagonists in the form's
register typically operate at extreme emotional reserve,
and the landscape's specific qualities — its harshness,
its expansiveness, its silences, its weather — carry the
emotional weight the characters do not articulate. The
country IS the protagonist's interior; the prose's
attention to specific terrain detail IS the emotional
register.

```
"He rode through the afternoon and the country
got meaner. The grass thinned to nothing and the
rock came through like bone through skin. There
was no shade anywhere and wouldn't be until dark,
and dark was a long time coming."

The protagonist has just lost someone. He doesn't
think about it. The land does it for him.
```

The technique requires landscape specificity. Generic
"the desert was harsh" or "the mountains stretched to the
horizon" is the failure mode; specific terrain rendered
with precise sensory detail (the particular kind of
yucca; the specific late-afternoon light through the
specific kind of pine; the specific rock formations of
this specific region) is the technique. The form's
strongest practitioners (McCarthy, McMurtry, Proulx,
Meyer, Diaz) make the reader feel they have visited the
actual location and learned something about its specific
quality.

The technique also requires that landscape mirror or
contrast with the protagonist's interior. The character
who has just lost someone rides into landscape that mirrors
the loss; the character who has just chosen freedom rides
into landscape that opens. Generic-beautiful-vista
landscape descriptions divorced from interior register are
the failure mode; specific terrain selected to express
specific interior is the technique.

Test: pick three significant landscape passages and ask,
in each, whether the terrain rendered would be the same
terrain rendered in the same prose register if the
protagonist's interior were different. If the answer is
yes, the technique is decorative; if no, the technique is
operating.

### The Economy of Violence

Western violence is short and real. The form's distinctive
action-craft: confrontations that adventure or thriller
would extend across pages occur in the western register in
seconds, with the prose's economy mirroring the actual
brevity of real lethal violence. The cinematic-western's
extended gunfight, with multiple wounded combatants
exchanging fire across a dusty street, is the form's most-
flagged failure mode for literary western; the
fast-finished encounter with lasting consequence is the
technique.

```
NOT WESTERN:
"They drew their weapons and engaged in a fierce
gun battle that lasted several minutes, exchanging
shots back and forth across the dusty street."

WESTERN:
"They drew. The sound was one sound, not two. The
other man sat down in the street as if his legs
had quit on him. He looked at his hands. He
looked at the blood on his hands. Then he fell
over sideways and didn't move."
```

The technique requires brevity and weight. Real lethal
violence is over fast; the strongest western prose honours
this with prose that ends quickly and then sits with what
just occurred. The confrontation may be three sentences
long; the aftermath registering its weight may be three
chapters. The form's signature pacing inverts the
conventional violence rhythm: the build-up is long, the
violence is brief, the consequences extend.

The technique also requires that violence carry weight.
Bodies in western fiction don't get up to fight again;
killing has consequences that the form's reader expects
the prose to honour. The protagonist who kills routinely
without the prose registering the cumulative weight has
been written in adventure register; the protagonist who
kills rarely and where each death lives in them
afterward has been written in western register.

Test: pick three violent confrontations in the manuscript
and verify, in each, that the violence is brief, the
consequences are extended, and the cumulative weight on
the protagonist registers in subsequent chapters. If
violence resolves and dissolves without aftermath, the
economy has not been deployed.

### The Silence-as-Dialogue

What's NOT said carries the meaning. Western dialogue's
distinctive craft: the form's protagonists are not
verbose, and the form's strongest interpersonal moments
operate through silence — the sentence that ends mid-
breath; the question that gets no answer; the look that
contains the conversation that won't happen. The reader
hears both the surface dialogue and the unspoken
contradiction or refusal beneath it.

```
"You didn't have to kill him," she said.
He didn't answer. He was reloading.
"He was surrendering."
He holstered the gun and looked at her and
she saw that he had heard her and that it
changed nothing.
```

The technique requires deliberate restraint. Generic
western dialogue with characters trading laconic lines is
the failure mode (the genre's cinematic inheritance the
form has often had to reckon with); the specific moments
of silence carrying specific weight are the technique.

The technique also requires that what's unsaid be
specific. Generic "he didn't say what he was thinking" is
the failure mode; the specific kind of silence — the
silence that means refusal versus the silence that means
inability versus the silence that means agreement on a
course of action — is the technique.

Test: pick three significant dialogue exchanges in the
manuscript and ask what is not being said in each. If the
unsaid is identifiable and specific, the silence is doing
work; if exchanges have no subtext, the dialogue is
operating at information-delivery level only.

### The Period Authenticity Discipline

Western fiction (particularly traditional western) operates
in specific historical periods (post-Civil War 1865 onward;
the open-range cattle era 1866-1886; the closing of the
frontier 1890; the early modern era 1890-1920) with
specific material, social, and political realities. The
form's reader includes serious western-history readers
who detect historical imprecision immediately. The
discipline:

- **Material culture** — specific firearms (the Colt
  Single Action Army was 1873; the Winchester 1873; the
  Sharps; the Spencer; specific calibres available at
  specific dates), specific clothing, specific tools,
  specific transportation, specific food, specific
  currency, specific architecture, specific tack and
  equipment.
- **Geographic accuracy** — the specific named places
  exist where the manuscript places them; the cattle
  trails (Chisholm, Western, Goodnight-Loving, Sedalia)
  ran where they ran; the rail terminals were where they
  were at the specific dates; the towns came and went on
  specific timelines.
- **Social fabric** — the specific demographic
  composition of the West (substantially more diverse
  than cinematic western convention has rendered: Black
  cowboys at approximately 25% of the cattle workforce;
  Mexican vaqueros whose techniques the cattle industry
  inherited; Indigenous people whose displacement was
  the precondition for the form's setting; Chinese
  workers on the railways; women's specific economic and
  legal positions varying by region and date).
- **Political and economic context** — Reconstruction;
  the cattle boom and bust; the Long Drive era and its
  end; the Indian Wars and the specific treaties and
  betrayals; the railroad-building era; the homestead
  era; the mining booms; the closing of the open range.

The discipline fails in two directions. **Cinematic-
inheritance register** uses the western movie's rendered
version of the period rather than the actual historical
reality. **Anachronistic-sensibility register** retrofits
contemporary moral framework onto period characters.
Both lose authenticity; the strongest western practitioners
(McCarthy, McMurtry, Proulx, Meyer, Diaz, Hobson, Zhang)
research carefully and render specifically.

Test: pick three period-specific elements in the manuscript
(a firearm, a piece of clothing, a town, a political
context, a social interaction) and verify each against
historical sources. If the manuscript operates on cinematic-
western convention rather than historical reality, the
discipline has not been deployed.

### The Inherited-Erasure Reckoning

Western fiction has a particular cultural debt the form's
contemporary practitioners are progressively reckoning
with. The classic western canon largely erased or
distorted: Indigenous experience (rendered through settler
eyes when rendered at all); Black cowboy and frontier
experience (substantially absent from the cinematic
western); Mexican / Chicano / Latino frontier experience
(reduced to villains or background); Asian frontier
experience (largely invisible); women's frontier
experience (rendered through narrow archetypes); the
specific economic exploitation of frontier labour; the
genocidal violence underlying westward expansion.

Contemporary western practice acknowledges this inheritance
without being didactic about it. The form's strongest
contemporary practitioners (Erdrich on Indigenous
experience; James Welch's *Fools Crow*; C Pam Zhang on
Chinese frontier experience; Anna North on women's
specific frontier reality; Téa Obreht on the multi-ethnic
West; Hernan Diaz; Brandon Hobson; James Carlos Blake;
Ron Hansen) write the actual West with its actual
demographic and historical complexity, not the cinematic
West with its inherited erasures.

The technique requires that the manuscript's choices about
who appears, who has interiority, who has agency, and
whose perspective shapes the prose are deliberate. A
western set in 1875 Texas with no Mexican characters, no
Black cowboys, no Indigenous presence, and no working
women has chosen — by absence — to render the cinematic
West rather than the actual one. That choice may be
deliberate (homage; specific narrative reasons; the form
permits multiple registers), but it should be conscious,
not default.

The technique also requires sensitivity in rendering.
Where the manuscript includes characters from
historically-erased groups, those characters should have
the same depth as the protagonist — interior life,
specific cultural particulars, agency in the plot, voice
that doesn't operate at adult-imagined-stereotype level.
The strongest contemporary western treats every
significant character with full novelistic attention, not
just the white protagonist.

Test: identify the manuscript's significant characters and
audit demographic and cultural composition. If the cast
operates within cinematic-western default
(predominantly-white-male; women-as-types; non-white-
characters-as-background-or-villain), the inherited-
erasure default is operating. The fix is not tokenism —
it is the deliberate rendering of the actual West with
its actual people.

### The Modern-Western Calibration

Western has expanded across multiple temporal registers:
traditional western (set in the historical period);
modern western (contemporary setting that retains the
form's register — *No Country for Old Men*, *Hell or High
Water*, *Wind River*, much of Craig Johnson's *Longmire*
work); space western (the form's register in sci-fi
setting — *Firefly*, the broader post-*Mad Max* range);
post-apocalyptic western (the form's register applied to
collapse scenarios — *The Road*, the survival-western
cross). Each calibration retains the form's signature
elements (landscape as emotion, economy of violence,
silence-as-dialogue, period-or-setting authenticity, moral
weight of action) while applying them to different settings.

The technique is recognising what makes the manuscript a
western rather than its specific setting. The traditional
western's frontier, the modern western's small-town
contemporary, the space western's frontier-planet, the
post-apocalyptic western's collapsed-civilisation — each
operates as the form's "frontier" because each is a place
beyond complete institutional reach where individual
moral choice matters in ways that institutional
metropolitan settings would not require. The form's
reader recognises the western register across these
settings; manuscripts that lose the register while
retaining the cosmetic markers (cowboy hats, six-guns)
have produced cinematic-cosmetic-western rather than
literary western.

Test: identify the manuscript's setting and ask what
makes this setting a western frontier in the form's
sense. Is it actually beyond complete institutional
reach? Do individual moral choices matter in ways
metropolitan settings would not require? Are the form's
signature techniques (landscape, economy, silence) operating
in this setting's specific terms? If the setting is
western-flavoured but the form's deeper register is not
operating, the calibration has slipped.

### Western AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the frontier was unforgiving" | Show the specific hardship |
| "justice came from the barrel of a gun" | Show the specific confrontation |
| "the dusty trail stretched endlessly" | Show ONE specific trail detail |
| "a man with a past" | Show the specific past through its current consequence |
| "the saloon fell silent" | Show what caused the silence |
| "the law was what you made it" | Show the specific legal situation |
| "the wide-open spaces" | Show ONE specific vista through the rider's mood |
| "a showdown at high noon" | Show the specific build-up to the specific confrontation |
| "the settler's life was hard" | Show the specific daily hardship |
| "riding into the sunset" | Show the specific departure and what's left behind |
| "his hand drifted toward his gun" | Show what specifically prompted the drift and what specifically the protagonist is calculating |
| "the cowboy code demanded he act" | Cut "the cowboy code"; show the specific calculation operating in this character |
| "the West would never be the same" | Cut the meta-commentary; show what specifically has changed in this place |
| "outlaws and lawmen" | Generic; show this specific outlaw and this specific lawman with their specific particulars |
| "the wagon train pressed on" | Show ONE specific wagon-train detail (the specific family in the second wagon; the specific weather; the specific terrain) |
| "the tracks led further into the wilderness" | Show what kind of tracks (specific animal / specific number of horses / specific gait / specific freshness) and what that tells the protagonist |
| "the gold rush had changed the territory" | Show the specific change in the specific town through the protagonist's specific observation |
| "she'd come west to start over" | Show the specific reason she came and what specifically she's starting over from |

## Genre-Specific Revision Rules

Six revision passes specific to western, each with a single
question, run cover-to-cover before the next begins. Western
revision must hold the form's signature contracts: landscape
presence (the land felt in every chapter); economy (lean
prose, spare dialogue, action not statement); physical
accuracy (period-specific material culture); violence
(brief, consequential, lasting); moral code (visible,
tested, lived); period authenticity (historical specificity
beyond cinematic convention); and the inherited-erasure
reckoning that contemporary western practice has been
progressively undertaking. The passes below are ordered to
surface landscape and economy failures first (the form's
most-felt by genre readers), physical accuracy and violence
next, code and inherited-erasure audits last as integrative
final checks.

### Pass 1: Landscape Presence Check

Verify the land is described and FELT in every chapter.
Western fiction's structural pressure depends on continuous
landscape presence; chapters that lose the land have
shifted out of register. Build a landscape ledger: each
chapter's terrain rendering, with verification that the
specific place is felt rather than gestured at.

Verify the environment affects the characters' actions.
The landscape should not merely surround the action; it
should shape what's possible. The river that has to be
forded determines the route; the heat that shapes when
travel happens; the wind that affects what can be heard;
the rocky terrain that affects what the horses can manage.
If the landscape is decorative, the form's signature
landscape-as-character relationship has slipped.

Verify the landscape is specific, not generic "desert" or
"prairie". The form's reader expects to know the specific
region, the specific season, the specific quality of the
light at this hour, the specific named flora and fauna.
The strongest western prose makes the reader leave with
specific place-knowledge. Test: pick three landscape
passages and ask, in each, whether the terrain rendered
could be lifted into another western set in another
region without alteration. If yes, the landscape is
generic; if no, the technique is operating.

### Pass 2: Economy Check

Read the manuscript with sole attention to prose density.
Is the prose lean enough? Can any words be cut without
losing meaning? Western fiction's prose register favours
economy over expansion; sentences should typically be
shorter than literary fiction's average; description
should be specific rather than elaborate; the prose should
feel pared rather than full.

Verify dialogue is spare and weighted. The form's
characters speak less than literary fiction's; what they
do say carries weight. Generic chatty dialogue is the
failure mode for western register; the spare exchange
where what's not said matters more than what is is the
technique. Test: pick three significant dialogue exchanges
and verify each operates in spare, weighted register
rather than chatty register.

Verify emotion is shown through action, not stated. The
Landscape as Emotion technique requires that interior
register operate through specific exterior detail. The
protagonist who "felt sad" has been told to the reader;
the protagonist who rides into thinning grass and
darkening country has been shown. Generic emotional
vocabulary deployed in narrator voice is the failure
mode; specific landscape and action carrying the interior
weight is the technique.

The pass also catches the over-explanation failure. The
narrator who pauses to articulate what the protagonist
just felt has broken the form's economy; the strongest
western prose trusts the reader to feel the emotion the
specific detail produces, without the prose pointing at
it. Test: identify three places where the manuscript
describes a character's emotional state. Could the
description be cut, with the surrounding action / landscape
left to carry the weight? If yes, the explanation is
breaking economy.

### Pass 3: Physical Accuracy Check

Verify firearms are described accurately. Western fiction's
material-culture authenticity requires period-specific
weapon knowledge: the specific Colt or Winchester or Sharps
or Spencer model with the specific year of introduction;
the specific calibre with its specific ballistic
characteristics; the specific reload procedure for this
specific weapon; the specific maintenance the protagonist
would perform. Generic "pistol" or "rifle" is the failure
mode; specific named weapon with period-accurate detail is
the technique.

Verify horse state is tracked and realistic. Horses are
not vehicles; they tire, get sore, need rest, need water,
need feed, develop specific problems, have specific
capabilities and limits. The protagonist who rides a horse
hard for three days without rest has killed the horse;
the manuscript should know this. Track each significant
horse across the manuscript: condition, recent exertion,
feed and water access, current capability.

Verify distances and travel times are plausible. A horse
covers roughly 25-35 miles a day at sustainable pace;
hard pushing extends to 50-70 miles for a day or two
before the horse breaks down. A wagon train moves at
roughly 15 miles per day. A river crossing on horseback
takes specific time and carries specific risks. Generic
travel-time treatment is the failure mode; specific
research-backed travel logistics is the technique.

The pass extends to all material culture: clothing,
food, tools, currency, transportation, building materials,
medical practices, communication. Test: pick three period-
specific elements and verify each against historical
sources. The strongest western prose researches carefully
and renders specifically.

### Pass 4: Violence Audit

Verify violence is consequential — not gratuitous or
bloodless. Real lethal violence has weight; the form's
strongest practitioners honour that weight rather than
either sanitising violence (the bloodless gunfight) or
exploiting it (the gratuitous-detail register). The form's
register sits between: violence is real, brief, and
carries lasting consequence.

Verify injuries are realistic and persistent. The bullet
wound that heals overnight has slipped into action-
adventure register; the bullet wound that limits mobility
for weeks is the western register. The Injury Ledger
technique applies: track each injury across chapters
with specific functional consequences. Period-specific
medical care matters: the antibiotic-era wound differs
from the pre-antibiotic-era wound; the western's typical
period (pre-antibiotic) means infection is a serious
threat that the manuscript should register.

Verify violence is BRIEF. Real lethal confrontations
typically last seconds, not minutes; the cinematic-
extended-gunfight is the form's most-flagged failure mode
for literary western. The strongest western prose ends
violence quickly and then sits with the consequence.
Test: time the manuscript's significant violent
confrontations. If any extend past 30 seconds in real-
time pacing, verify the extension is doing specific work
that the form's brief-violence register would not have
delivered.

### Pass 5: Code Check

Verify the protagonist's moral code is visible. Western
fiction's signature character work: the protagonist
operates by a specific moral framework — sometimes
articulated, often not — that shapes their decisions.
This is the form's "code" tradition; the protagonist
behaves by it even when departing from it would be
easier. The code's specifics differ across the form's
range (the Wister-derived honour code; the L'Amour-
derived working-class decency; the McCarthy-derived
nihilist or near-nihilist rejection; the contemporary
revisionist code that questions inherited assumptions).

Verify the code is TESTED, not just stated. The strongest
western fiction puts the protagonist in situations where
their code costs them — where adhering means losing
something material, where compromising would yield
gain. The protagonist whose code never costs has not
been tested by the form's central work; the protagonist
whose adherence carries specific named cost demonstrates
the form's deepest character work.

Verify the character's action matches their code. The
test: when the protagonist is under pressure (violence,
loss, temptation, betrayal), do they behave in ways
consistent with the code the rest of the manuscript has
shown? If the code disappears under pressure, it has
been decorative; if the code shapes specifically what
the protagonist does and refuses to do under maximum
pressure, the technique is operating.

The pass also catches the related failure: protagonist
who has no visible code at all. Generic "good guy"
without specific moral framework is the failure mode;
specific articulable code (even if the protagonist would
never articulate it themselves) is the form's signature.

### Pass 6: Period Authenticity and Inherited-Erasure Audit

Run a final integrative pass on the manuscript's
historical and demographic representation. Two related
sub-audits:

**Period authenticity.** The Period Authenticity Discipline
technique above outlines the requirements: material
culture, geographic accuracy, social fabric, political
and economic context — all specific to the chosen period.
Audit the manuscript for cinematic-inheritance register
(the West as movies have rendered it rather than as it
was) and for anachronistic-sensibility register
(retrofitting contemporary moral framework onto period
characters). Both are failure modes; the strongest
western researches carefully and renders specifically.

**Inherited-erasure reckoning.** Western fiction's
contemporary practice acknowledges the form's history of
erasing or distorting Indigenous, Black, Mexican / Chicano /
Latino, Asian, and women's frontier experience. Audit the
manuscript's demographic and cultural composition. Does
the cast reflect the actual West's actual diversity, or
has it defaulted to cinematic-western convention
(predominantly-white-male; women as types; non-white
characters as background or villain)? Where the manuscript
includes historically-erased groups, do those characters
have the same depth, interiority, agency, and voice as
the protagonist?

The pass is not asking the manuscript to abandon western
register or to perform contemporary moral framework. It
is asking the manuscript to know what it is doing — to
make deliberate choices about what to include, what to
acknowledge, and what to render rather than defaulting to
inherited tropes the form has been progressively
reckoning with.

Test: identify three demographic / cultural choices in the
manuscript (a character included, a character excluded, a
specific group's representation, a historical event's
treatment). For each, ask whether the choice was
deliberate and whether the rendering operates with depth
or with default. If choices are default and renderings
are stereotypical, the inherited-erasure default is
operating; if choices are deliberate and renderings are
specific, the form's contemporary practice is being
honoured.

## Names & Patterns to Avoid

### Western Character Names. NEVER USE
- Movie-western caricature names: Tex, Slim, Buck, Dusty
- Names that signal role: Sheriff Justice, Doc, The Kid (unless earned within the story)
- Exclusively white Anglo names for a diverse frontier

### Western. NEVER DO
- Write the shootout as an extended action sequence (real gunfights are over in seconds)
- Ignore Indigenous peoples or reduce them to stereotypes
- Make the horse a motorcycle (horses have personality, needs, and limits)
- Have the protagonist deliver speeches about honour or justice (SHOW it)

### Use Instead
- Period-appropriate names from frontier records and census data
- Multicultural names reflecting the actual diversity of the West
- Nicknames that feel earned, not assigned

## Comp Titles

Western's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Virginian* — Owen Wister (1902): the modern western-novel foundation.
- *Riders of the Purple Sage* — Zane Grey (1912): early commercial western benchmark.
- *True Grit* — Charles Portis (1968): the literary-western masterclass.
- *Lonesome Dove* — Larry McMurtry (1985): the literary-western epic.
- *Blood Meridian* — Cormac McCarthy (1985): literary-western darkness benchmark.

### Contemporary (current best-in-class)

- *News of the World* — Paulette Jiles (2016): contemporary literary western.
- *Days Without End* — Sebastian Barry (2016): queer-Irish-immigrant literary western.
- *Inland* — Téa Obreht (2019): literary-western with magic-realism elements.
- *Outlawed* — Anna North (2021): feminist alt-history western.
- *The Sisters Brothers* — Patrick deWitt (2011): literary comic-western.
- *The Cold Millions* — Jess Walter (2020): contemporary literary western.
- *Trust Exercise* — Susan Choi (no, that's contemporary fiction; replace with) *The Last Cowboys* — John Branch (2018, NF-adjacent western).
- *That Old Country Music* — Kevin Barry (2020, stories): contemporary Irish stories with western-resonance.

## Cover Design Specifications

### Recommended Visual Styles
- **Landscape**. The vast western landscape: mesas, prairies, mountains, desert. a lone figure dwarfed by the land; the most iconic western cover composition
- **Silhouette**. A figure (on horseback or on foot) against a dramatic sky: sunset, storm, dawn; bold, simple, immediately recognisable
- **Textural**. Weathered, rugged: cracked leather, sun-bleached wood, dust and rust; the cover should feel worn and tough
- **Typographic**. Bold, rugged typography with minimal imagery: the title as brand; confident and masculine

### Genre Cover Aesthetics
- **Styles:** Vast landscapes with lone figures, horseback silhouettes against dramatic skies, frontier towns under big skies, portraits weathered by sun and wind, the meeting of civilisation and wilderness
- **Colours:** Warm earth tones: burnt sienna, ochre, desert sand, sage green; sunset oranges and reds; big-sky blues; dust and gold; the palette of the American West. warm, saturated, sun-drenched
- **Elements:** Horses, riders, hats, revolvers, leather, rope, horizon lines, cacti and scrubland, wooden structures, campfire, the road stretching to infinity
- **Typography:** Bold serif or slab-serif fonts; weathered or distressed effects; the title should feel branded into leather or carved into wood; confident, rugged, timeless

### Market Positioning
Western covers signal "vast, hard, beautiful" through landscape imagery and warm earth tones. Position against McCarthy, McMurtry, Portis, Johnson, L'Amour. The genre's visual language is one of the strongest. lean into the iconic silhouette, the big sky, the lone figure. At thumbnail size, a horseback silhouette against a sunset sky is instantly recognisable as a western.

### Cover Design DON'Ts
- No cartoonish cowboy imagery
- No cluttered compositions (the western is about SPACE)
- No modern design aesthetics (the western cover should feel timeless)
- No bright, cheerful palettes (the western palette is warm but serious)
- No stereotypical Native American imagery used decoratively
- No romance-cover aesthetics (even for westerns with romantic elements)
