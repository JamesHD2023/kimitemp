---
name: paranormal-romance-genre
description: Genre-specific instructions for paranormal romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Paranormal Romance. Genre Plugin

## Metadata
- id: paranormal-romance
- name: Paranormal Romance
- icon: 👻
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Romancing the Beat", "Horror Fear Arc", "Three-Act Structure", "Hero's Journey"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Shifter Romance | Love interest transforms between human and animal forms | The animal nature creates primal attraction and territorial dynamics; the shift itself is a source of tension |
| Fated Mates | Supernatural bond predetermines the romantic pairing | The tension lies in characters who must reconcile free will with destiny; rejection of the bond creates stakes |
| Vampire Romance | Immortal vampire love interest with mortal or vampire partner | Immortality creates the central conflict. loss, transformation, the ethics of turning |
| Witch/Warlock Romance | Magic practitioners whose powers complicate their love story | Magic systems must have rules and costs; power creates both attraction and danger |
| Angel/Demon Romance | Celestial beings in forbidden cross-faction romance | The cosmological stakes elevate the personal. their love has universal consequences |
| Ghost Romance | Romance involving a spirit or between the living and dead | The impossibility of physical contact creates exquisite romantic tension; resolution requires sacrifice |

## Architect Instructions

```
STRUCTURE

Chapter length: 3,000-5,000 words
Pacing: Romance-forward with supernatural tension. chemistry builds while paranormal stakes escalate
Must open with: Supernatural encounter, chemistry/attraction moment, paranormal threat, or hidden world revealed
Must close with: Romantic tension heightened, supernatural danger increased, mate bond deepened, or world mythology expanded

GENRE PROMISE

Romance is the spine. The supernatural is the skeleton beneath the skin. Every chapter must advance the love story AND the paranormal conflict. HEA or HFN is mandatory. the couple ends together despite supernatural obstacles.

Core elements:
- Central romance driving emotional arc: not subplot, not secondary
- Supernatural beings in contemporary/near-contemporary setting
- Hidden paranormal world existing beneath mundane reality
- Mate bonds, claiming, or fated connections common (not required)
- Pack, clan, coven, or court politics complicating romance
- Supernatural stakes threatening the couple's future

BEATS PER CHAPTER

1. Romantic Chemistry: Attraction, tension, banter, longing, intimacy. relationship must progress every chapter
2. Supernatural Element: Paranormal abilities, creature nature, hidden world mechanics shown through action
3. Paranormal Stakes: External threat from supernatural world endangering relationship or characters
4. Intimacy Progression: Emotional vulnerability deepening alongside physical attraction. trust building
5. World Mythology: Pack/clan/coven hierarchy, supernatural rules, ancient lore woven through events

STRUCTURE OPTIONS

Supernatural Discovery: Human protagonist discovers hidden world through attraction to supernatural being, drawn deeper by romance and danger
Fated Mates: Supernatural pair or supernatural/human pair recognizing destined bond, navigating resistance, acceptance, and claiming
Pack/Clan Politics: Romance complicated by supernatural hierarchy, territory disputes, or leadership challenges threatening to separate couple
Ancient Threat: Couple must unite powers against returning evil. romance forged in battle, trust built through supernatural crisis

GENRE-SPECIFIC REQUIREMENTS

- HEA or HFN absolutely required: couple committed at end despite all supernatural obstacles
- Contemporary or near-contemporary setting: our world with hidden supernatural layer
- Supernatural rules consistent: vampire feeding, shifter transformations, magic costs maintained
- Modern technology exists: smartphones, internet, cars alongside ancient supernatural powers
- Fated mates if used must include choice: destiny creates pull, characters choose to accept
- Pack/clan/coven politics concrete: hierarchy, laws, territory, succession visible
- Alpha heroes/heroines common: dominant, protective, possessive but never abusive
- Mate bonds physical: scent recognition, marking, claiming rituals with tangible effects
- Supernatural community hidden from humans: masquerade maintained or carefully managed
- Dual POV strongly encouraged: both romantic leads' perspectives
- Sexual tension escalating: supernatural senses heighten attraction, chemistry intense
- Action scenes serve romance: battles, rescues, fights deepen bond between couple

FORBIDDEN

- Supernatural without romance central: this is romance first, paranormal second
- Romance ignoring supernatural stakes: couple can't forget the world is dangerous
- Tragic ending: couple separated permanently violates genre promise
- Abuse romanticized: possessive alpha must respect consent and agency
- Inconsistent supernatural rules: vampires can't suddenly walk in sunlight without explanation
- Instalove without supernatural justification: attraction instant, love earned (unless mate bond)
- All paranormal, no contemporary grounding: modern world must be visible
- Static pack/clan politics: supernatural society must have active tensions
- Passive protagonist: hero or heroine must fight, act, choose
- Supernatural deus ex machina: magic can't solve everything conveniently
- Stereotypical characters: no default alpha male without depth or damsel without agency; both leads need specific, individual complexity beyond their supernatural nature
- Single-obstacle stories: the supernatural threat alone isn't enough; layer internal emotional wounds alongside paranormal stakes
- Relentless intensity: even in the most dangerous supernatural world, characters need moments of humor, normalcy, and unexpected warmth

OBSTACLE LAYERING (critical for paranormal romantic tension)

Paranormal romance has built-in external obstacles (supernatural threats, pack politics, hidden world dangers), but these alone won't sustain the romance. Layer INTERNAL obstacles that the supernatural context illuminates: fear of vulnerability magnified by immortal stakes, past betrayals that make trust impossible, the loneliness of centuries weighing against the hope of connection. Internal obstacles. the characters' own wounds, fears, and self-sabotage. are the engine of modern romance, even when the characters are supernatural beings. The more obstacles between the couple, the more intensely the reader yearns for their bond.

LIGHT AND SHADE

Even in a world of supernatural danger, emotional contrast is essential. After scenes of paranormal threat and life-or-death stakes, provide moments of unexpected warmth. humor between mates, the absurdity of supernatural beings dealing with modern life, a quiet moment of tenderness. After scenes of romantic closeness and safety, shatter the calm with the return of danger. This alternation amplifies both the romance and the supernatural tension. Never allow the emotional register to flatline. chart highs and lows like a pulse.

ANTI-STEREOTYPE IMPERATIVE

The great joy of paranormal romance is taking messy, flawed characters—who happen to be supernatural—and giving them love stories that feel emotionally authentic. Avoid default character types: the alpha who is possessive "just because," the human who has no qualities beyond being chosen by a supernatural being. Your protagonist should be specific and real, with individual quirks, wounds, and strengths that exist independently of their supernatural nature. Stereotypical characters flatten both the romance and the world-building.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (relationship arc), Stimulation (otherworld encounter), Captivation (worldbuilding).

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-agent.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE

POV: Dual 1st person (alternating) or dual close 3rd limited. both romantic leads' perspectives
Tense: Past (traditional romance) or present (heightened immediacy for supernatural tension)
Voice: Contemporary and accessible with supernatural undertones. modern speech patterns, ancient power beneath
Tone: Sensual, intense, dangerous. passion heightened by immortal stakes
Reading level: Adult. mature themes, supernatural violence, intimate content

PROSE IMPERATIVES

1. Contemporary Voice with Supernatural Edge
   - Modern dialogue. contractions, current speech patterns, realistic banter
   - Internal monologue natural. characters think like contemporary people with supernatural awareness
   - Supernatural elements described through sensation, not clinical explanation
   - Ancient beings speak with authority but adapt to modern language
   - Humor common. supernatural absurdity acknowledged, banter essential

2. Sensory Enhancement from Supernatural Abilities
   - Heightened senses in attraction. hearing heartbeat quicken, scenting arousal, feeling body heat
   - Predator awareness of mate. tracking movement, protective instincts, territorial responses
   - Supernatural beauty visceral. describe inhuman perfection through physical impact on POV character
   - Pain and pleasure magnified. supernatural healing, stamina, sensitivity
   - Mate bond sensations physical. pull in chest, warmth spreading, scent recognition electric

3. Alpha Heroes/Heroines
   - Dominance shown through action, not declaration
   - Protective instinct natural to supernatural nature, not controlling
   - Power balanced. strong heroines match or complement alpha heroes
   - Vulnerability beneath strength. immortal beings with ancient wounds
   - Possessiveness supernatural but tempered by respect—"mine" instinct checked by love

4. Mate Bonds and Claiming
   - Bond recognition sensory. scent, sight, supernatural knowing
   - Resistance and acceptance stages. characters struggle with fate before choosing
   - Claiming rituals species-specific. bites, marks, blood exchange, magical binding
   - Bond effects physical. separation causes pain, proximity creates calm, intimacy deepens connection
   - Mate bond language natural—avoid overusing "mate" (vary with partner, beloved, other terms)

5. Supernatural Senses in Intimacy
   - Heightened everything. taste, touch, scent amplified
   - Species-specific elements. vampire bite pleasure, shifter claiming, magic sparking
   - Stamina and endurance supernatural. recovery, intensity beyond human
   - Bond deepening through physical intimacy. magic exchanged, marks appearing
   - Consent explicit. supernatural compulsion acknowledged and navigated with agency

6. Urban Settings with Hidden World
   - Named cities and real locations. paranormal romance is grounded in recognizable places
   - Supernatural venues. hidden bars, underground fight clubs, pack compounds, coven houses
   - Modern infrastructure alongside ancient sanctuaries. penthouse lairs, converted warehouse dens
   - Technology coexisting with supernatural. security systems for vampires, encrypted shifter communications
   - Mundane life visible. jobs, groceries, traffic alongside supernatural responsibilities

7. Action Scenes with Romantic Tension
   - Fights strengthen bond. protecting each other, fighting together
   - Battle chemistry. adrenaline and attraction intertwined
   - Supernatural combat visceral. claws, fangs, magic, speed described with physical impact
   - Injuries create intimacy. healing, vulnerability, tenderness after violence
   - Power demonstrations attractive. seeing mate's strength increases desire

DIALOGUE

- Contemporary casual: supernatural beings don't speak like medieval lords (unless characterization demands it)
- Banter essential: humor and chemistry through verbal sparring
- Ancient beings: Occasional formal phrasing mixed with modern adaptation
- Pack/clan speech patterns: titles, honorifics, hierarchy in address
- Threat dialogue: Supernatural menace through calm, not shouting
- Love declarations earned: not said easily, weight of immortality behind words
- THE POWER OF THE UNSAID: What characters don't say carries enormous weight: especially supernatural beings who have had centuries to build walls. Holding back feelings gives devastating resonance to the moment they finally speak
- Each character must speak distinctly: a centuries-old vampire and a modern human have fundamentally different verbal rhythms, references, and ways of deflecting emotion
- Conversations should function as verbal sparring: advance and retreat, what's risked and what's withheld. The best romantic exchanges happen when both characters are disturbed by the depth of their connection but can't quite name it

METHOD WRITING. EMOTIONAL IMMERSION
- Identify the specific emotion you want the reader to FEEL before writing any key scene: the ache of a fated bond resisted? The thrill of supernatural power unleashed? The tenderness of an immortal being made vulnerable by love?
- If the writer isn't feeling the emotion while writing, the reader won't feel it: go back and find what's blocking the feeling
- Write through ALL senses, especially the supernatural ones: what does the mate bond feel like physically? What does a shifter scent in their mate's presence? How does magic taste when exchanged?
- Never be cynical about emotion: don't manufacture a crisis or a betrayal purely for dramatic effect. Genuine emotion earned through character investment is what creates readers who are desperate for the couple to find each other

INTIMATE SCENES. CHARACTER AND SUPERNATURAL TRUTH
- Intimate scenes must illuminate something about the characters AND their supernatural nature: not exist merely for heat
- Ask: what does this moment reveal about the power dynamic, the mate bond, the characters' emotional state? How does it advance the relationship?
- The best intimate scenes in paranormal romance contain elements of awkwardness, wonder, or emotional rawness alongside desire: a human experiencing a supernatural lover's nature for the first time, an immortal being touched for the first time in centuries
- Build physical intimacy into the emotional landscape: it should feel like a natural culmination of accumulated supernatural and emotional tension

FORBIDDEN WORDS/PHRASES

- "Orbs" for eyes: say eyes, gaze, or specific color
- "Member" or clinical anatomy: use sensual or character-appropriate language
- "Mate" every other sentence: vary terminology
- "Alpha" as personality descriptor instead of showing dominance
- Purple prose excess: "throbbing manhood," "heaving bosom" are parody territory
- Info-dumping supernatural lore: weave through action and discovery
- Modern slang that dates immediately: avoid trending phrases
- "Said" alternatives overused: "growled," "purred," "hissed" once each max per chapter
- "Suddenly" as cheap tension: build the moment instead

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- The paranormal element AND chemistry from page one: supernatural world and attraction both active
- Tension floor: 5 (danger + desire; the hidden world should feel both thrilling and alluring)
- Open with supernatural encounter or ability in motion: world-rules delivered through ACTION, not exposition
- Dialogue density: 30-40%: banter establishes chemistry; supernatural reveals come through interaction

Supernatural-sensory scenes (prose rhythm):
- Heightened sensory detail: what the paranormal character hears, scents, feels beyond human range
- Medium sentences for supernatural awareness; SHORT when the mate bond or power surges
- Interiority budget: 35-40%: the pull of the bond, the predator instinct, the centuries of loneliness
- Balance world-building with romance pacing: one supernatural rule per scene, woven through action

Action/battle scenes (prose rhythm):
- Short, kinetic sentences during supernatural combat: claws, magic, speed rendered in fragments
- Romance beats WITHIN action: protecting each other, fighting together, power demonstrated as attraction
- Post-battle vulnerability: sentences lengthen, prose softens, walls come down in the aftermath

Climax/resolution prose rhythm:
- Claiming/bonding scenes: prose intensifies: shorter sentences, visceral sensory detail, the bond made physical
- Combined power against threat: both characters' abilities rendered in urgent, interlocking rhythm
- HEA: the prose carries the weight of centuries of loneliness ending: earned, chosen, permanent

GENRE-SPECIFIC STYLE

Vampire: Cold skin against warm, predator stillness, ancient eyes in young face, blood as intimacy
Shifter: Barely contained animal, muscular heat, scent-driven attraction, possessive growling
Demon: Dangerous seduction, sulfur-sweet, power radiating, forbidden desire
Witch/Mage: Magic sparking between them, power responding to emotion, rituals as foreplay
Psychic: Shared visions, mental intimacy, emotional flooding, touch-triggered seeing
Angel: Luminous presence, otherworldly beauty, divine prohibition, fallen temptation

INTIMATE SCENES

- Supernatural elements integrated: not humans who happen to have fangs
- Species nature present: biting, marking, shifting, magic during intimacy
- Power exchange meaningful: supernatural beings sharing essence
- Emotional connection driving physical: bond deepening, not just attraction
- Heat level appropriate to story: from closed door to explicit, but always emotionally grounded
- Aftermath matters: bonding effects, mark appearance, power shifts after intimacy
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. HEA/HFN delivered. couple together at end, paranormal romance keeps romance genre promise
2. Romance central. love story drives every chapter, not supernatural plot with romance subplot
3. Supernatural rules consistent. paranormal world logic maintained for powers, vulnerabilities, hierarchy
4. Contemporary grounding. modern world visible, recognizable reality with hidden supernatural layer
5. Chemistry shown not told. attraction demonstrated through action, sensation, banter, not stated

GENRE-SPECIFIC CHECKS

HEA/HFN present. couple committed, together, supernatural obstacles overcome
Romance every chapter. relationship advances, no chapters without romantic development
Supernatural integrated. paranormal elements enhance romance, not separate from it
Contemporary setting. modern world visible through technology, urban life, current culture
Chemistry visceral—attraction shown through sensory detail, not "she was attracted to him"
Mate bond consistent. if present, bond stages tracked from recognition through claiming
Pack/clan politics active. supernatural hierarchy affecting romance, not just background decoration
Action serves romance. fights, rescues, threats deepen couple's bond
Both leads developed. dual POV or both characters fully realized with agency
Consent navigated. supernatural compulsion acknowledged, character choice preserved
Supernatural nature present in every scene. not humans who occasionally remember being paranormal
Emotional intimacy building alongside physical. bond earned through vulnerability, not just fate

AUTOMATIC FAILS

Tragic ending. couple not together, violates paranormal romance genre promise
No romance. supernatural plot dominates, romance peripheral or absent
Inconsistent supernatural. rules shift to convenience, vampires in sunlight, silver not hurting shifters
No contemporary setting. pure fantasy world is romantasy, not paranormal romance
Abuse romanticized. possessive alpha crosses into controlling or abusive without narrative awareness
No chemistry. attraction stated but never shown through sensation and interaction
Passive heroine/hero. protagonist has no agency, only reacts to supernatural events
Mate bond removes choice. fated connection eliminates character agency entirely

ACCEPTABLE IMPERFECTIONS

More romance than action chapters (or vice versa) if both substantial across story
Simplified supernatural hierarchy if consistent and logical
Some paranormal tropes (fated mates, chosen one) if well-executed with fresh specificity
Heat level varies from closed door to explicit if emotionally grounded

RED FLAGS TO INVESTIGATE

Romance stalled. chapter without relationship progress or emotional development
Supernatural info-dump. paragraphs of lore not woven through action and discovery
Generic setting. could be anywhere, no specific modern details anchoring the world
Tell not show chemistry—"she was attracted to him" instead of demonstrating through sensation
Inconsistent power levels. abilities convenient to plot, stronger or weaker as needed
Pack/coven politics absent. supernatural hierarchy ignored when it should create tension
Mate bond stage skipped. jumped from recognition to claiming without resistance and acceptance
Species traits forgotten. supernatural being acts entirely human for extended scenes
Contemporary life vanished. characters' jobs, phones, mundane obligations disappear
Claiming marks described differently. physical appearance of bond should be consistent
Ancient backstory contradicts established events from earlier chapters
Supernatural healing inconsistent. severe wounds that should take days healed in hours
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES

1. Supernatural rules: Species powers, vulnerabilities, feeding needs, transformation rules maintained
2. Mate bond progression: Recognition, resistance, acceptance, claiming stages tracked precisely
3. Pack/clan/coven hierarchy: Leadership, ranks, laws, territory boundaries consistent
4. Power levels: Character abilities established and maintained. no sudden unexplained upgrades
5. Modern world knowledge: Contemporary technology, locations, cultural references consistent

GENRE-SPECIFIC TRACKING

- Supernatural species traits: Vampire sun sensitivity, shifter moon rules, witch magic costs
- Mate bond status: What stage: unrecognized, recognized, resisted, accepted, claimed, completed
- Mate bond effects: Physical sensations, separation pain, proximity effects tracked
- Pack/coven/clan membership: Who belongs to which group, rank, role
- Hierarchy rules: How alpha determined, succession, challenges, laws
- Territory boundaries: Which supernatural group controls which area
- Ancient history: Past events affecting present politics, grudges, alliances, blood debts
- Character injuries: Supernatural healing rates, lingering wounds, silver/iron damage
- Romantic milestones: First meeting, first touch, first kiss, first intimacy, declarations, claiming
- Modern details: Character jobs, apartments, cars, phones, daily life anchors

CREATURE CONSISTENCY TRACKING

Vampire: Feeding schedule, sun vulnerability level, maker/fledgling bonds, age and power, special abilities
Shifter: Animal form, shift triggers (moon/emotion/will), pack rank, territorial instincts, silver vulnerability
Demon: Power source, summoning rules, containment, true form vs. human guise, weaknesses
Witch: Magic specialization, power source, spell costs, familiar bonds, coven position
Psychic: Ability type, trigger conditions, control level, psychic cost, shielding ability
Angel: Grace status, divine rules, fall conditions, power limitations, hierarchy rank

ACCEPTABLE INCONSISTENCIES

- Minor sensory details if core species traits maintained
- Slight variation in ancient history accounts from different characters (unreliable narrators)
- Small pack/coven protocol differences between groups

CRITICAL CONSISTENCY

- Mate bond status: once recognized, cannot be unrecognized; once claimed, permanent
- Species vulnerabilities: silver hurts shifters every time, not selectively
- Feeding requirements: vampires need blood consistently, not when convenient
- Transformation rules: moon rules, shift control maintained
- Pack/coven laws: established rules apply to all members consistently
- Hierarchy: alpha doesn't change without plot-significant challenge
- Character powers: abilities don't appear without establishment or training
- Modern anchors: character jobs, homes, phones don't disappear
- Romantic firsts: first kiss happens once, first "I love you" tracked
- Claiming marks: once placed, visible consistently, described the same way
- Ancient grudges: established enmities between groups don't vanish
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES

1. Supernatural nature: Species traits (vampire, shifter, witch, demon) consistent in every scene
2. Power levels: Abilities established and maintained. no convenient power-ups without justification
3. Mate bond response: Both characters' reactions to bond. resistance, acceptance, longing. tracked
4. Pack/clan role: Hierarchy position affects behavior, speech patterns, responsibilities
5. Modern grounding: Characters have contemporary lives. jobs, apartments, friends, technology

CHARACTER BUILDING. GROUND UP FOR PARANORMAL ROMANCE

Build each protagonist from the ground up BEFORE their supernatural nature takes over:
- For supernatural beings: What were they like before turning/awakening? What do they want beyond survival? What emotional wounds have centuries of isolation/power created? What do they carry from their mortal life?
- For human characters: What do they want from life independent of the supernatural? What are their specific quirks, fears, and strengths? What makes them compelling enough that a centuries-old being would notice them?
- Character tests: What's in their apartment/den/lair? How do they react to witnessing injustice? What do they reach for when afraid: humor, action, withdrawal, violence?
- The vast majority of this backstory won't appear on the page, but it informs every reaction, every line of dialogue, every choice in the relationship
- Messy, flawed characters. even immortal ones. are always more compelling than perfect ones. A vampire with social anxiety, a shifter who hates violence, a witch who is terrible with people. flaws create the potential for growth that romance readers crave

GENRE-SPECIFIC CHARACTER ELEMENTS

Supernatural Hero/Heroine:
- Species traits present in every scene: not human who occasionally remembers being supernatural
- Alpha presence: dominance natural, not performed
- Ancient wounds: centuries of loss, betrayal, warfare shaping current walls
- Protective instinct: mate's safety overrides everything, sometimes to conflict
- Pack/clan responsibility: leadership obligations competing with personal desires
- Control issues: supernatural power requiring constant restraint around mate
- Vulnerability masked: ancient being's loneliness, fear of loss, hidden tenderness
- Physical tells: inhuman grace, predator awareness, restrained violence

Human Discovering Hidden World:
- Shock and adaptation: disbelief, fear, wonder, acceptance as progression
- Courage despite vulnerability: human in supernatural world choosing to stay
- Knowledge gaining: learning rules, hierarchy, dangers through experience
- Power of their own: human qualities (compassion, stubbornness, ingenuity) as supernatural asset
- Fish-out-of-water humor: modern human navigating ancient supernatural politics
- Anchor to normal world: grounding supernatural partner in contemporary reality

Supernatural Pair:
- Species differences creating tension: vampire/shifter, witch/demon rivalries
- Power dynamics shifting: equals or complementary abilities
- Shared understanding of supernatural burden: no need to explain hidden world
- Pack/coven politics: relationship crossing factional lines
- Ancient history: may have known each other across centuries
- Competition and attraction intertwined: sparring as foreplay

CHARACTER ARCS MUST

- Romance arc: Attraction > resistance > vulnerability > trust > claiming > commitment
- Supernatural arc: Isolated > threatened > allied > powerful together > bonded
- Personal arc: Wounded > healing through love > choosing vulnerability > whole
- Show pack/clan loyalty tested by romance: duty vs. desire
- Demonstrate power growth through relationship: stronger together than apart
- Earn HEA through sacrifice: what each gives up to be together

TRACK FOR ROMANTIC LEAD 1

- Species traits: Feeding needs, transformation schedule, power fluctuations
- Mate bond reactions: Physical sensations, emotional responses, behavioral changes
- Pack/clan duties: Leadership obligations, political pressures, loyalty conflicts
- Emotional walls: What they hide, why, when cracks appear
- Power level: Current abilities, limitations, growth over story
- Modern life: Job, home, mundane obligations alongside supernatural
- Past relationships: Previous mates, loves, losses (especially for immortals)
- Physical state: Injuries, feeding status, shift status, exhaustion

TRACK FOR ROMANTIC LEAD 2

- Mirror all above categories for second lead
- Emotional response to lead 1: How attraction manifests, what triggers walls
- Discovery arc (if human): What they know, when they learn it, emotional processing
- Power complementarity: How abilities interact with partner's
- Independence maintained: Own goals, strengths, agency beyond romance
- Support network: Friends, family, pack members affecting romance

SUPPORTING CHARACTER FUNCTIONS

- Pack/coven members: Enforce hierarchy, create social pressure, provide found family
- Villains: Threaten couple specifically: target mate bond, challenge claim, exploit weakness
- Mentors: Explain supernatural rules, provide wisdom about bonds, guide through transition
- Rivals: Romantic competition or political enemies adding tension
- Human friends: Anchor to normal world, comic relief, loyalty across supernatural divide
- Elders/leaders: Embody tradition, enforce laws, approve or deny claiming

PARANORMAL PSYCHOLOGY

- Predator instincts and romantic love coexisting: protection vs. possession
- Immortal loneliness driving intensity of connection
- Animal nature and human emotion in conflict (shifters especially)
- Supernatural senses creating intimate awareness: hearing lies, scenting fear, feeling desire
- Pack/clan bonding overriding individual autonomy: tension between group and couple
- Ancient trauma requiring modern healing: centuries of wounds, contemporary love as salve
```

## Arc Rules

```
THREE-ACT STRUCTURE

Core arc shape:
- Supernatural encounter ignites attraction
- Chemistry deepens while paranormal danger escalates
- Mate bond recognized or romantic commitment tested
- Pack/coven politics and external threat peak together
- Couple unites against supernatural threat
- HEA/HFN with couple bonded and world stabilized

ACT I (Chapters 1-10): Supernatural Encounter and Ignition

- Ch 1: Hook: supernatural event, dangerous meeting, or hidden world glimpsed; immediate chemistry
- Ch 2-3: Both leads established: supernatural nature shown, modern life visible, attraction undeniable
- Ch 4-5: Hidden world revealed: pack/coven/clan politics, supernatural rules, hierarchy shown through action
- Ch 6-7: Romance deepening: forced proximity, banter, first vulnerable moment, tension building
- Ch 8-9: Paranormal stakes established: external threat targeting one or both leads, danger personal
- Ch 10: Mate bond recognized OR first major intimate moment AND supernatural threat clear

Purpose: Establish chemistry, reveal hidden world, introduce paranormal stakes
Ends with: Couple drawn together by attraction AND supernatural threat forcing alliance

ACT II (Chapters 11-23): Deepening Bond Under Siege

- Ch 11-13: Romance intensifying: vulnerability shared, walls cracking, intimacy building
- Ch 14: Mate bond acceptance or first claiming ritual: supernatural connection cementing
- Ch 15: MIDPOINT: major intimacy AND paranormal threat escalation (attack on pack, ancient enemy surfaces)
- Ch 16-18: Pack/coven politics peak: relationship challenged by hierarchy, duty, faction pressure
- Ch 19-20: Powers tested: couple faces supernatural threat together, discovering combined strength
- Ch 21-22: Black moment setup: betrayal from within pack/coven, or mate bond used against them
- Ch 23: BLACK MOMENT: forced separation, mate bond threatened, or one captured/endangered

Purpose: Build romance to committed love while supernatural stakes become life-threatening
Ends with: Couple torn apart by supernatural crisis. all seems lost

ACT III (Chapters 24-30): Claiming and Conquest

- Ch 24-25: Recovery and resolve: choosing each other over safety, duty, or self-preservation
- Ch 26-27: Final preparation: gathering pack/coven allies, planning supernatural confrontation
- Ch 28: Final battle: couple fighting together, powers combined, mate bond as weapon and shield
- Ch 29: Climax resolution: supernatural threat defeated, claiming completed, pack/coven accepting
- Ch 30: HEA established: couple bonded, pack/coven stable, future together certain

Purpose: Resolve supernatural conflict through couple's united strength, deliver HEA
Ends with: Couple permanently bonded, supernatural world stabilized, romance fulfilled

GENRE PROMISE

Paranormal Romance readers expect:
- HEA/HFN mandatory: couple together, committed, bonded
- Central romance: love story in every chapter, driving every decision
- Supernatural beings: vampires, shifters, witches, demons with consistent species traits
- Contemporary setting: our world with hidden supernatural layer
- Mate bonds or fated connections: common though not required
- Alpha heroes/heroines: dominant, protective, passionate
- Pack/clan/coven politics: supernatural society with hierarchy and rules
- Action and danger: supernatural threats creating urgency
- Sexual tension escalating: chemistry intense, supernatural senses heightening everything
- Claiming rituals: species-specific bonding with physical and emotional consequences
- Found family: pack/coven as chosen family alongside romantic pair

REQUIRED CHECKPOINTS

- Ch 3: Chemistry undeniable AND supernatural world rules established
- Ch 5: Hidden world politics visible: pack/coven hierarchy, territory, laws shown
- Ch 8: External paranormal threat clear AND romantic tension building
- Ch 10: Mate bond recognized OR first major intimate moment
- Ch 14: Claiming begins OR deep emotional commitment despite supernatural obstacles
- Ch 18: Pack/coven politics directly threatening relationship
- Ch 23: Black moment: couple separated or mate bond imperiled
- Ch 25: Choosing each other: commitment declared despite cost
- Ch 28: Fighting together: combined supernatural power defeating threat
- Ch 30: HEA: bonded, claimed, together, supernatural world stabilized

EMOTIONAL CONTRAST IN ARC STRUCTURE

Chart emotional highs and lows throughout the arc. After scenes of supernatural danger and high stakes, provide breathing room. moments of humor, normalcy, or quiet intimacy. After scenes of romantic warmth and mate bond deepening, shatter the calm with the return of paranormal threat. This alternation is what makes paranormal romance compulsively readable: readers relax into connection only to be jolted by danger, and brace for supernatural conflict only to find unexpected tenderness. Never allow more than two consecutive chapters at the same emotional register.

EARNED ENDINGS

The HEA must feel like the inevitable destination of THESE specific characters. The claiming/bonding should be earned through everything the couple has endured. not just fated, but CHOSEN. Seed the resolution early: if the couple defeats the threat through their combined powers, establish those capabilities in earlier chapters. The most satisfying paranormal romance endings acknowledge what the couple has sacrificed to be together while making clear why the love was worth every cost. A mate bond is the starting point, not the finish line. what the characters BUILD on that bond is the story.

THEME BENEATH THE SUPERNATURAL

Every strong paranormal romance benefits from a THEME. what the story is really about beneath the fangs and fur. Is it about the courage to trust when you've been betrayed across centuries? About choosing vulnerability when you have the power to remain invulnerable? About what it means to be truly known. and loved despite what's known? Theme transforms paranormal romance from entertaining escapism into something that resonates long after the book is closed.
```

## Timeline Rules

```
TIME SCALE

- Total story duration: Days to months (paranormal romance typically compact: intensity over duration)
- Chapter time span: Hours to days: action-oriented with intimate pauses
- Time progression: Linear with flashbacks for ancient characters' history

GENRE-SPECIFIC TEMPORAL RULES

- Contemporary pacing: Modern urgency: threats don't wait, romance burns fast
- Immortal vs. mortal time: Centuries-old beings experience weeks differently than humans
- Full moon cycles: If shifters present, 28-day cycle tracked: waxing increases restlessness
- Mate bond acceleration: Supernatural connection can justify faster emotional progression than human romance
- Pack/clan events: Full moon gatherings, seasonal rituals, challenge ceremonies on set schedules
- Supernatural healing: Faster than human but not instant: hours for minor, days for severe
- Ancient backstory: Flashbacks or memories spanning centuries for immortal characters
- Night vs. day: Vampires nocturnal, some creatures more powerful at specific times
- Modern time markers: Work schedules, rush hour, weekend vs. weekday affecting scene timing
- Transformation timing: Shifter changes tied to moon phase, emotional state, or time of day

TRACK CAREFULLY

- Moon phases: Critical for shifters: restlessness waxing, forced shift at full, weakness at new
- Days since couple met: Relationship timeline against bond progression
- Time of day: Vampire activity, shifter vulnerability, magical power fluctuations
- Mate bond stage timing: How long between recognition and acceptance, acceptance and claiming
- Supernatural event countdown: Ancient prophecy, ritual deadline, challenge date approaching
- Feeding schedules: Vampires need blood regularly: track when last fed
- Shift frequency: Shifters need to change regularly for health: track when last shifted
- Modern calendar: Work obligations, holidays, social events alongside supernatural ones
- Immortal age references: Centuries lived, historical events witnessed, era of turning
- Injury recovery: Supernatural healing timeline: minor cuts (minutes), major wounds (hours/days)

FLEXIBLE

- Exact hours unless supernatural timing requires precision (midnight ritual, dawn vulnerability)
- Minor background character schedules
- Precise travel times between familiar locations

PARANORMAL ROMANCE TIMELINE STRUCTURES

Compressed Crisis (Days):
- Supernatural threat forces couple together fast
- Mate bond accelerates emotional timeline
- Intense proximity: safehouse, on the run, siege
- Every hour deepens both romance and danger
- HEA feels earned through intensity, not duration

Building Heat (Weeks):
- Couple encounters, resists, circles each other
- Pack/coven politics complicating over weeks
- Supernatural threat escalating with romance
- Multiple encounters building to claiming
- Time for slow burn and pack dynamics

Immortal Scope (References spanning centuries):
- Present story weeks/months, backstory centuries
- Ancient being's past revealed through flashbacks
- Previous loves, wars, betrayals coloring present romance
- Human partner learning immortal's history
- Past and present timelines converging at climax
```

## Genre-Specific Craft Techniques

Paranormal romance lives at the seam of two genres that ask
opposing things of the prose. Romance asks for emotional
specificity, embodied attention, and the slow accumulation of
trust between two specific people. Paranormal asks for system
fidelity, world-build consistency, and the credibility of a
reality that diverges from ours. The integration is achieved
when the supernatural element is doing the romantic work — when
the shifter's animal form responds to her partner's grief,
when the vampire's hunger maps onto the human's longing, when
the bond manifests in the specific physical sensation neither
character had vocabulary for. The techniques below are how that
integration is sustained at scene level rather than asserted
in synopsis.

### The Supernatural as Metaphor

Paranormal abilities must reflect emotional states, not merely
exist alongside them. The telepath who cannot stop hearing the
lover's doubts is not just powered; she is exposed in a way the
reader will recognise from real intimacy. The shifter whose
animal form responds to jealousy is not just shaped; he is
revealed by the body he cannot control around the person he
cannot control himself around. The paranormal element
externalises the internal — making the invisible visible and the
subtle dramatic — and the strongest paranormal romance uses
creature traits as a lens on the emotional truth of intimacy:
vulnerability, possession, surrender, restraint, the cost of
being known. When the supernatural mirrors the psychological,
the fantasy becomes emotionally real; when the supernatural is
merely decorative (the wings that mean nothing for the romance,
the magic that only matters when the plot needs it), the genre
contract has been broken. Test: for each named ability, name
what it costs the character emotionally and how the love
interest's presence amplifies or relieves that cost. If the
ability has no romantic register, the technique has not been
deployed.

### The Mate Bond Earned

Fated connection that still requires emotional work. The bond
may be supernatural, but the relationship is human — characters
who are fated must still choose each other through
understanding, compromise, and growth. Destiny provides the
spark; the characters must tend the fire. A mate bond that does
all the emotional labour for the characters (assured intimacy
without conversation, jealousy without grounds, devotion without
known cause) robs the romance of its power: the reader has been
told they belong together rather than shown the becoming. The
bond should create opportunity, pressure, and stakes — not
substitute for them. Stage the bond's progression through
visible stations: the first recognition (which the bonded party
may misread as illness, panic, or hallucination); the resistance
(which must be earned by something the bond cannot override —
prior commitment, ethical scruple, the wound the character has
not yet named); the acceptance (which is a choice, not a
collapse); the claiming (which the genre's conventions allow as
ritual but which the prose must render as decision). The bond
that does the work is the bond that erases the romance.

### The Power Imbalance Navigation

Supernatural strength versus human vulnerability as romantic
tension. The paranormal partner must constantly calibrate their
power — the controlled touch, the restrained strength, the
breath held against the smell of blood, the deliberate
gentleness that costs something. This restraint becomes its own
form of devotion: every careful gesture is a chosen
non-violence, every protected boundary an act of love. The
less-powerful partner must bring something equally vital, or
the dynamic collapses into protection-detail romance:
emotional courage, moral clarity, the grounding force of
mortality, the specific human capacity (humour, art,
empathy, ethical insight) the paranormal partner has lost
or never had. The imbalance is not a problem to solve but a
dynamic to navigate; the genre's pleasure includes the
imbalance, and the resolution should not eliminate it but
honour both contributions. Test: in scenes where the
paranormal partner saves the mortal, can the writer name what
the mortal contributes that the paranormal partner cannot
provide for themselves? If the answer is "nothing", the
relationship is not yet a relationship.

### The Hidden World Reveal

Introducing the paranormal to the uninitiated love interest.
This reveal scene is a pivotal romantic moment — trust made
tangible — and the human partner's response defines the
relationship going forward. Fear, fascination, the sense of
betrayal at having been deceived, wonder, the particular grief
of realising the world is not what they thought: all are valid,
and the strongest reveals do not pick only one. The reveal is
not merely informational; it is an act of vulnerability from
the supernatural partner and a test of acceptance from the
human one. Stage it as a scene, not a paragraph: choose the
location (a place that matters to the relationship); choose
the form of the reveal (transformation, demonstration of
ability, presentation of the supernatural community, the
artefact that proves it); choose the witness moment (what the
human sees, in what order, with what light); and choose the
silence after, which is the actual revelatory beat. Handle the
reveal with the weight it deserves — including the cost: the
reveal cannot be undone, the human cannot un-see, and what
follows must reckon with that.

### The Immortal Stakes

What "forever" means when one partner literally lives forever.
The mortal / immortal divide creates the deepest conflict in
paranormal romance — every moment is precious and temporary
from one perspective, endless and accumulating from another.
This asymmetry must inform every romantic decision: the
immortal partner carries the weight of eventual loss (and the
weight of having survived prior loves the new beloved cannot
measure); the mortal partner carries the weight of inadequacy
against eternity, the panic that they will be the one who ages
out of the relationship, the question of whether to be turned.
Neither perspective is wrong; the tension between them is the
genre's deepest seam. The technique requires that the immortal
partner not be flattened into either eternal-comforting-presence
or eternal-tortured-loner: they must have specific prior
relationships (whose names the new beloved will hear at some
point) and specific historical experience that shapes how they
hold the present. The mortal partner must not be flattened into
either grateful recipient or eternal bargaining chip:
they must have a specific stake in their own mortality (the
parents to bury, the friends to grow old with, the body that
is theirs in a way the immortal partner's is not).

### The Worldbuilding Iceberg

Paranormal romance carries an iceberg of supernatural world-
building beneath every scene: pack hierarchies, vampire politics,
witch covens, elemental magic systems, fae court conventions,
shifter mating laws, demon contract structures. The reader needs
the surface (enough to follow the romance, feel the stakes, and
trust the world) but does not need the iceberg (the writer's
full systems document). The technique is calibration: every
scene exposes the minimum of the iceberg required, in the
sensory grammar of the POV character, embedded in actions
and reactions that also do romantic work. The vampire who needs
to feed before he can safely escort the human home does not
need to explain the politics of his clan — he needs to drink,
and the human needs to watch, and the watching is the romance.
The worldbuilding that shows up only when the plot needs it
will read as deus ex machina; the worldbuilding that shows up
in every chapter will read as homework. Test: cut a sample
chapter to half its supernatural exposition. Does the romantic
weight survive the cut? If yes, the cut exposition was iceberg-
beneath-the-water and did not need to be on the page.

### Paranormal Romance AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "their supernatural bond was undeniable" | Show the specific manifestation of the bond — the sensation, the location in the body, the involuntary response |
| "the mate bond pulled them together" | Show the specific physical sensation and what each partner does to resist or yield to it |
| "his eyes glowed with otherworldly light" | Show ONE specific visual (colour, intensity, what it does to the room) and the effect on her |
| "the beast within him stirred" | Show the specific physical transformation sign — temperature, scent, change of voice, the way he holds his hands |
| "forbidden by both their kinds" | Name the specific rule, who enforces it, and the specific consequence already paid by someone the reader has met |
| "centuries of loneliness ended when he found her" | Show his specific behaviour that reveals the loneliness — the routine he has not broken, the conversation he has not had in decades |
| "the magic between them was unlike anything" | Show the specific magical reaction to proximity — what changes, what they alone can do, what the magic costs |
| "her humanity called to his darkness" | Show the specific human quality and his specific physical or behavioural reaction to it |
| "the supernatural world was more dangerous than she knew" | Show the specific danger encountered, named, with rules the reader can track |
| "a love that transcended death" | Show the specific sacrifice or supernatural bridge — what was paid, by whom, with what consequence |
| "the transformation was painful but beautiful" | Show the specific pain (where in the body, what register); show the specific beauty (what the partner sees, what they do not look away from) |
| "their souls were intertwined" | Replace with embodied specificity: what each feels in the other's absence, what neither can do alone |
| "an ancient evil rose" | Name the specific evil, its specific history with the supernatural community, and its specific stake in this couple |
| "she was his anchor in the darkness" | Show the specific anchoring action — the touch, the word, the look that pulls him back |
| "the prophecy spoke of two becoming one" | Cut the prophecy, or stage the prophecy as text the characters dispute; received-prophecy plotting is the genre's most-flagged crutch |
| "his fangs grazed her neck" | Show what each is doing with the rest of their bodies; the moment is the surrounding stillness, not the fangs |
| "the alpha claimed his mate" | Show the claim as scene; the verb does no work without specific action and specific consent |
| "an immortal could only love once" | Earn this premise scene by scene through specific behaviour, or do not assert it; declared rules without dramatised cost are world-building debt |

### Romance Masterclass — Paranormal-Romance Calibration

The romance master file (romance.md) holds the canonical
romance frameworks: Heat Level Calibration, the 7-Element
Chemistry Scene Construction, the 6 Romance Character
Archetypes with character-build tests, Obstacle Layering
Quantitative, Light and Shade Heart-Monitor Rule, the
Differentiation Imperative, Hope-as-Resolution Calibration,
and Series Architecture. All apply directly to paranormal-
romance, calibrated below to the genre's specific
supernatural register.

**7-Element Chemistry Scene — Paranormal-Romance calibration:**

- **Element 1 (Setup):** the magical-system rules
  establish the constraint architecture; the supernatural
  identity register (vampire / werewolf / fae / witch /
  demon / angel / shifter / ghost / other) is operational.
  Establish what each lead knows, suspects, or hides about
  the supernatural world before chemistry begins.
- **Element 2 (Approach):** often through supernatural
  circumstance — mate-bond pull, magical task assignment,
  scent recognition, prophecy alignment, hunting overlap,
  ritual proximity. The proximity-pretext frequently has
  supernatural causation rather than mundane coincidence.
- **Element 3 (Banter Beat):** magical-vocabulary subtext;
  species-cultural friction (vampire-werewolf friction,
  fae-mortal friction, witch-warlock professional rivalry).
  The dialogue carries embedded magical-system reference
  that reveals character through fluency or struggle with
  the supernatural register.
- **Element 4 (Awareness Spike):** magical recognition —
  the mate-bond ignition, the scent imprint, the power
  resonance, the prophecy line spoken aloud, the curse
  recognised. The Spike's emotional pivot is rendered
  partly through magical signal (visible mark, shared
  vision, supernatural sensation) and partly through
  bodily response.
- **Element 5 (Pull-Back):** the load-bearing pull-back is
  carried by magical consequence — species barrier,
  supernatural law, mortality gap, prophecy obligation,
  council-or-court interdiction, mate-bond cost. The leads
  cannot act because the magical system, the species
  rules, or the supernatural authority holds them.
- **Element 6 (Aftermath):** the magical change carried
  forward — the mark, the bond, the scent imprint, the
  power-shift, the new visibility to other supernaturals.
  The supernatural world has registered the encounter.
- **Element 7 (Hook):** the next supernatural revelation
  or magical consequence — the council summons, the
  prophecy advancing, the new species-tension, the curse
  manifesting, the mate-bond intensifying.

**6 Character Archetypes — Paranormal-Romance calibration:**

- **The Wounded Lead** carries the supernatural identity,
  curse, lineage, or mortal-vs-immortal weight. The wound
  is structurally tied to the magical system — what they
  ARE creates the obstacle to what they want. The wound
  must be specific within the magical system (not generic
  "vampire angst" but the named transgression, the named
  ancestral debt, the named curse-condition).
- **The Opposite Lead** configurations: human-with-
  knowledge (the witch's apprentice, the demon-hunter,
  the supernatural-aware mortal), other-supernatural
  species (cross-species pairing carrying inherent
  friction), the curse-breaker (the foretold one, the
  mortal who can break the bond), or the rival-magical
  (same species, different faction).
- **The External Antagonist Force** is often the magical
  system itself — the vampire council, the fae court, the
  prophecy, the supernatural law, the species-elder
  tribunal. The antagonist may be impersonal
  (institutional) or personal (the rival-magical,
  the rejected-suitor, the dark-faction representative).
- **The Found Family** is the magical pack, coven, court,
  cabal, or supernatural community. Paranormal-romance
  benefits from strong Found Family because the
  supernatural world produces tight kinship configurations.

**Obstacle Architecture — Paranormal-Romance dominant obstacles:**

The Obstacle Layering Quantitative rules apply. For
paranormal-romance, the dominant obstacle types are:

1. **Cross-species barrier** (vampire/human, fae/mortal,
   shifter/witch, demon/angel — each pairing with its
   own friction architecture)
2. **Magical lineage / inherited curse** (the family
   bloodline, the ancient pact, the foretold doom)
3. **Supernatural authority** (vampire council, fae
   court, witches' high council, shifter-pack hierarchy)
4. **Mortality gap** (immortal lead, mortal lead — the
   genre's most poignant load-bearing obstacle)
5. **Magical secret** (the supernatural world hidden
   from mortal world; the reveal as plot pivot)

**Differentiation Imperative — Paranormal-Romance specific axes:**

- Specific magical system (named lore, named species,
  named rules, named cost-architecture for magic)
- Specific historical relationship between supernatural
  and mortal worlds (open, hidden, in-conflict,
  integrated, post-reveal)
- Specific magical consequence-architecture (what magic
  costs, what mate-bonds demand, what species-barriers
  mean for the leads)

**Ending Calibration — Paranormal-Romance patterns:**

Paranormal-romance typically delivers HEA — the magical
obstacle resolved, the species-barrier crossed, the
council placated, the mortality gap bridged or
acknowledged. HFN is common in series (each book
advances the supernatural arc; final resolution is
multi-book). The mate-bond architecture often preordains
HEA; the craft is in earning it through specific
character growth and obstacle resolution rather than
allowing the bond to do the resolution work for the
manuscript. The Hopeful ending is rare; where it appears,
it typically navigates an irresolvable mortality gap with
specific named hope for the surviving lead.

## Genre-Specific Revision Rules

Six revision passes specific to paranormal romance, each with a
single question, run cover-to-cover before the next begins.
Paranormal romance has the narrowest tolerance for system drift
of any romance sub-genre — the moment a vampire crosses a
threshold without invitation, the moment a shifter changes form
in sunlight after the writer has established that they cannot,
the moment a fae lies after the writer has established that
they cannot — the spell breaks and does not return. These
passes catch the failures specific to dual-genre integration.

### Pass 1: Paranormal Rules Consistency

Verify that the supernatural system follows its own established
rules throughout. If vampires cannot enter without invitation in
chapter two, this rule must hold in chapter twenty. If the
shifter's first transformation costs three days of recovery, the
fifth transformation cannot be casual. Build a rules ledger:
every paranormal ability, limitation, cost, threshold, exemption,
and edge case appearing anywhere in the manuscript, with the
chapter and page where each first appears. Read the manuscript
against the ledger. Flag every instance where convenience has
overridden consistency — typically the climactic chapter, where
a writer reaches for a power level the rules have not allowed.
The reader's trust in the world depends on the author's
discipline with the rules; one violation costs more reader
goodwill than ten reaffirmations earn back. Where a violation
must occur for the climax to work, rewrite the climax or
rewrite the rule earlier in the book — do not let the
violation stand.

### Pass 2: Mate Bond Logic Audit

If using fated mates, verify that the bond mechanics are
consistent and dramatised. How does the bond manifest physically
(temperature, sensation, location in the body)? What happens
when it is resisted (illness, pain, panic, hallucination)? Can
it be broken (under what cost, by what means, with what
consequence)? Can it be rejected by one partner unilaterally
(genre conventions vary; declare yours and hold to it)? These
rules must be established early — typically by the end of
chapter four — and followed rigorously through to the climax.
The bond should create tension, not eliminate it: track the
bond's progression through every stage (recognition,
resistance, acceptance, claiming) and ensure no stage is
skipped, foreshortened, or contradicted. Flag scenes where the
bond does narrative work the characters should be doing —
where attraction, trust, or commitment arrives by virtue of the
bond rather than by virtue of action and choice. The bond is
the genre's permission slip for fast intimacy; it is not a
substitute for written intimacy.

### Pass 3: Power Dynamic Balance

Chart the power relationship between the leads across the full
manuscript. The paranormal partner's advantages (speed, strength,
longevity, magic, sensory range) should be offset by emotional
vulnerabilities (the wound from a previous century, the hunger
that is also a shame, the inability to be loved without being
feared). The human or less-powerful partner must bring something
the supernatural partner cannot provide for themselves —
emotional courage, moral clarity, the grounding force of
mortality, a specific human capacity (humour, art, empathy,
ethical insight). Test scene by scene: in scenes where the
paranormal partner saves the mortal, the next scene or chapter
should contain a moment where the mortal saves the paranormal
partner — not necessarily physically, but materially. Without
this reciprocity the relationship reads as protection detail,
and the genre's romantic register collapses into care-taking.
Flag any sustained stretch (more than three chapters) where
the saving runs in only one direction.

### Pass 4: World-Building Integration Check

Verify that paranormal world-building serves the romance rather
than overwhelming it. Information about pack hierarchies,
vampire politics, fae court structure, witch covens, demonic
contracts, or magical systems should be woven into scenes that
are also doing romantic, dramatic, or character work. Read for
exposition lumps: any stretch of more than half a page where
the prose is teaching the reader about the world without
advancing scene action is a lump. Test the necessity: does this
world-building information have to be on the page now, or can
it be dramatised when it later matters? Every piece of
supernatural lore on the page should either advance the love
story or raise the stakes for the couple. Flag the lore that
fails both tests — those are the writer's notes that did not
need to be promoted to manuscript. Conversely, flag any
climactic stake that depends on world-building the reader has
not been given enough of: the rule the climax turns on must
have been established earlier in scene, not declared in the
moment.

### Pass 5: Romance-to-Paranormal Ratio

Read the manuscript tracking genre balance: which scenes are
primarily romance, which are primarily paranormal action /
politics / threat, which integrate both. The romance must be
the primary story — paranormal elements serve the love story,
not the reverse. The dual-axis test: if the romance plot were
removed (the leads were friends, family members, colleagues),
would there still be a coherent paranormal novel? If yes, the
romance is not integrated deeply enough — the supernatural plot
must turn on the relationship, not merely contain it.
Conversely, if the paranormal elements were removed (the leads
are mortal, the world is ours), would there still be a coherent
romance? If yes, the paranormal is decorative — the love story
must be shaped by the supernatural condition in ways a mortal
romance could not be. Both threads must be load-bearing; flag
chapters where one thread vanishes and the other carries alone
for more than two consecutive chapters.

### Pass 6: The Consent and Coercion Audit

Paranormal romance has a structural risk other romance sub-
genres do not face: the supernatural element can override or
mimic consent — the bite that turns, the bond that compels,
the mate who claims, the fae who promises, the demon who
contracts, the shifter whose instinct overrides reason. Run a
dedicated pass asking: where consent is compromised by the
supernatural condition, has the manuscript handled it as
genuinely consequential? The strongest paranormal romance
treats supernaturally-induced behaviour as a problem the
characters reckon with on the page, not a convenience the
plot uses and discards. Flag every scene where the
supernatural removes or pressures choice: each must be
followed (in the same scene or the next) by a moment of
mortal-time consent that ratifies or refuses what occurred. The
genre's pleasure includes its dangers; what the genre cannot
afford is to look away from those dangers when convenient.
Where the bond, the heat, the bite, the spell does the
choosing, the prose must show the characters returning later
to choose for themselves.

## Names & Patterns to Avoid

### Forbidden Patterns
- **The fated mate shortcut**. Using the mate bond to skip emotional development; "the bond made them fall in love" is not a romance, it is a spell
- **The all-powerful protector**. A paranormal love interest who solves every problem with supernatural abilities removes all stakes from the romance
- **The helpless human**. Human partners in paranormal romance must bring genuine value to the relationship beyond being the protected mortal
- **World-building as plot**. Pages of pack politics, vampire court intrigue, or magical system exposition that do not advance the romance
- **The supernatural excuse**. Using creature nature to justify controlling or possessive behaviour that would be unacceptable in a contemporary romance

### Cliché Setups to Avoid
- The alpha werewolf who growls "mine" at first scent without any earned emotional connection
- The centuries-old vampire who falls for the protagonist because she "smells different"
- The witch who does not know she has powers until a handsome supernatural explains it to her
- The mate bond that eliminates all other potential romantic interests without generating narrative tension
- The human protagonist who is inexplicably unafraid of supernatural revelation within moments of learning the truth
- The ancient evil that conveniently awakens at the exact moment the couple meets

### Naming Considerations
- Paranormal beings often have names that span eras. ancient names feel authentic for immortal characters
- Pack or clan naming conventions should be consistent within the world and reflect the group's cultural origin
- Avoid names that are unintentionally comedic for supernatural beings (Alpha Kevin, the vampire Derek)
- Human characters benefit from grounded, contemporary names that contrast with the paranormal world
- Titles and honorifics within supernatural hierarchies should be established early and used consistently

## Comp Titles

Paranormal-romance's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Dark Prince* — Christine Feehan (1999): the Carpathian series; vampire-paranormal-romance template.
- *Bitten* — Kelley Armstrong (2001): the Otherworld series; werewolf-paranormal-romance launching point.
- *Twilight* — Stephenie Meyer (2005): mass-market paranormal-romance benchmark.
- *Lover Awakened* — J.R. Ward (2006): the Black Dagger Brotherhood series; alpha-vampire register.

### Contemporary (current best-in-class)

- *A Discovery of Witches* — Deborah Harkness (2011): witch-vampire literary-paranormal-romance.
- *A Court of Thorns and Roses* — Sarah J. Maas (2015): fae-romance crossover into romantasy; commercial benchmark.
- *From Blood and Ash* — Jennifer L. Armentrout (2020): vampire-romantasy hybrid; series architecture.
- *House of Earth and Blood* — Sarah J. Maas (2020): the Crescent City series; multi-species paranormal-romance.
- *Ice Planet Barbarians* — Ruby Dixon (2015-, ongoing): alien-paranormal-romance; specific subgenre lineage.
- *Plated Prisoner* — Raven Kennedy (2021-): faerie dark-romantasy; the modern paranormal-romance-into-romantasy migration.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. Digital illustration with supernatural atmosphere and romantic chemistry. The increasingly dominant style, particularly for shifter and witch romance. Allows for depicting supernatural elements (wings, glowing eyes, magical auras) that photography cannot achieve convincingly.
- **Cinematic**. Film-still quality with dramatic supernatural lighting, otherworldly colour grading, and atmospheric depth. Works exceptionally well for vampire and demon romance where the cover needs to feel dangerous, alluring, and larger-than-life.
- **Photorealistic**. Model photography with heavy post-processing to add supernatural elements (glowing eyes, ethereal lighting, mystical overlays). Works for urban fantasy romance crossover and darker paranormal subgenres where the contemporary setting anchors the supernatural.
- **Graphic**. Bold silhouettes with supernatural details (wings, fangs, claws) against atmospheric backgrounds. Effective for series branding and stands out at thumbnail with strong iconic imagery.

### Genre Cover Aesthetics
- **Styles:** Otherworldly atmosphere with romantic tension, supernatural lighting effects (moonlight, magical glow, bioluminescence), dramatic poses suggesting power and desire, urban settings with hidden supernatural layer, nocturnal compositions, mystical symbols integrated into design
- **Colours:** Deep jewel tones. amethyst purple, sapphire blue, emerald green. with magical accent colours (silver moonlight, ethereal blue glow, golden supernatural energy). The palette should feel rich, mysterious, and slightly unearthly. Dark bases (black, midnight blue, deep purple) with luminous supernatural highlights create the genre's signature look.
- **Elements:** Supernatural creature signifiers (fangs, wings, claws, glowing eyes, wolf silhouettes), moonlight and lunar imagery, mystical symbols and runes, magical energy effects (sparks, auras, swirling power), urban skylines with supernatural overlay, forests and wild landscapes for shifter romance, blood and bite marks (tasteful), marking and claiming symbols, supernatural weaponry
- **Typography:** Display fonts with metallic or glowing effects. silver, gold, or supernatural-coloured foil. Bold, impactful lettering that can hold its own against atmospheric backgrounds. Mystical or slightly ornate fonts that signal fantasy without becoming illegible. Glow, shimmer, or embossed effects are genre-standard.

### Subgenre Variations
- **Vampire Romance:** Nocturnal palettes (deep crimson, black, silver), fang imagery, blood-red accents, gothic urban settings, pale skin contrast, predatory elegance
- **Shifter/Werewolf Romance:** Wild, natural palettes (forest green, earth tones, moonlit blue), wolf or animal silhouettes, full moon imagery, pack symbols, muscular figures, wilderness settings
- **Witch/Mage Romance:** Magical colour palettes (purple, teal, gold sparks), spell effects, botanical elements (herbs, flowers with magical properties), pentacles and mystical symbols, atmospheric libraries or apothecaries
- **Demon Romance:** Darker, more intense palettes (black, crimson, hellfire orange), horn silhouettes, smoke and flame, infernal symbols, dangerous allure, sulphurous glow
- **Fae/Fairy Romance:** Ethereal, luminous palettes (silver, moonlight blue, forest green, gold dust), wing silhouettes, nature magic, flowers and thorns, otherworldly beauty, enchanted forest settings
- **Angel/Fallen Angel Romance:** Light-and-dark contrast, feathered wing silhouettes, divine glow vs. shadow, gold and white against dark, celestial symbols, grace-and-fall visual tension

### Market Positioning
Paranormal romance readers are highly visual and subgenre-specific. the cover must immediately signal WHICH TYPE of supernatural creature is featured. A vampire romance cover that looks like shifter romance will confuse and lose the target reader. Supernatural elements must be visible at thumbnail size; the creature type should be identifiable even at the smallest display. The cover needs to balance romance and supernatural in roughly equal visual weight. too much fantasy and it looks like urban fantasy; too much romance and the paranormal hook is lost. Series branding is critical: consistent creature aesthetic, colour palette, and supernatural visual language across the series builds the dedicated readership paranormal romance depends on.

### Cover Design DON'Ts
- Cute, cozy, or lighthearted aesthetics. paranormal romance should feel intense, alluring, and slightly dangerous
- Realistic mundane settings without supernatural atmosphere. even urban scenes need otherworldly lighting or mystical elements
- Overly bright or pastel colour palettes. the colours should feel rich, deep, and supernatural
- Generic romance couple photography without paranormal signifiers. there must be something visually supernatural on the cover
- Cartoon or comic-book illustration style (unless specifically targeting a lighter paranormal comedy market). the tone should be atmospheric and intense
- Horror-forward imagery (excessive gore, body horror, jump-scare aesthetics). paranormal romance is alluring darkness, not graphic horror
- Period or historical design elements (unless specifically historical paranormal). paranormal romance is contemporary by default
- Cluttered compositions with too many supernatural elements competing for attention. pick the dominant creature signifier and make it the focal point
