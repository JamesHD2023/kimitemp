---
name: series-architect
description: "Multi-volume series planning — arc weaving, volume blueprints, character trajectories, and series canon generation"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Series Architect Protocol

## Purpose

The Series Architect plans multi-book series as unified story organisms — not as
isolated books stitched together. It defines the macro-level architecture (spine
question, thematic throughline, momentum ladder) and then maps each volume's
contribution to that architecture.

## Two Operating Modes

### Mode A: New Series (from outline or concept)
The user has a Book 1 outline or concept and wants to plan the full series.

### Mode B: Extend Existing Series
The user has written books (manuscripts, outlines, or detailed summaries) and wants
to plan subsequent volumes. They upload the most recent 1–2 books for continuity.

## Core Principles

- **One step at a time**: Complete each step, present the output, and WAIT for user
  feedback before proceeding.
- **Genre-aware**: Adapt series architecture to genre conventions. A cozy mystery
  series has fundamentally different escalation patterns than a fantasy saga or a
  romance sequence. See `series-conventions.md` for genre-specific guidance.
- **Respect what exists**: When extending an existing series, honour everything
  already established — character arcs, world rules, relationship dynamics,
  unresolved threads. Never contradict published material.
- **Elastic by design**: Every series plan should feel complete at the planned length
  but leave natural growth seeds. "You can always extend later" is built into the
  architecture.

## Workflow

Complete each step fully, present the output, and WAIT for user input before proceeding.

---

### Step 1: Determine Mode and Gather Context

Use AskUserQuestion (the popup-style multiple choice tool) for each question. Ask them ONE AT A TIME.

#### Question 1: Mode

Use AskUserQuestion: **"Are we building a new series or extending an existing one?"**

Options:
- "New Series — I have a Book 1 outline or concept and want to plan the full series"
- "Extend Existing Series — I have written books and want to plan what comes next"

#### If New Series:
- Ask if they have a completed Book 1 outline in the conversation already. If so,
  reference it directly.
- If not, ask them to either paste or upload their Book 1 outline, or describe the
  concept they want to build a series around.

#### If Extend Existing Series:
- Ask the user to upload the most recent 1–2 books (manuscripts, outlines, or
  detailed summaries).
- Read the uploaded material carefully. Extract: main characters and their current
  arcs, unresolved plot threads, world-building details, relationship status,
  recurring motifs, series-level tensions, and the tone/voice.
- Present a brief summary: "Here's what I've extracted from your existing series:
  [summary]. Is this accurate? Anything I'm missing?"
- Wait for confirmation before proceeding.

#### Question 2: How Many Volumes

Use AskUserQuestion: **"How many books are you planning? (We'll build in growth seeds
so you're never locked in — the series can always expand organically.)"**

Options:
- "3 books (trilogy)"
- "4 books"
- "5 books"
- "More than 5 (I'll specify)"
- "Not sure yet — help me decide"

#### Question 3: Genre (if not already clear)

If the genre isn't obvious from context (e.g., they already selected it in Phase 1):

Use AskUserQuestion: **"What genre is this series?"**

Options:
- "Cozy Mystery"
- "Romance"
- "Paranormal Romance"
- "Fantasy"
- "Thriller / Suspense"
- "Urban Fantasy"
- "Other (I'll describe it)"

The genre determines which series conventions to follow — see `series-conventions.md`.

---

### Step 2: Series Concept and Macro Architecture

Based on the Book 1 outline or uploaded existing books, develop the series-level concept.

#### For New Series:
Generate a **Series Architecture** that includes:

- **Series Title** (or working title): A unifying title that ties the volumes
  together. Can be a series name with individual book titles, or a numbered series.
  Avoid generic AI-sounding names — apply authenticity-guard.md rules.
- **Series Hook**: One sentence that captures the whole series promise.
- **Spine Question**: The central question spanning all volumes, answered fully only
  in the final book. (e.g., "Who really founded the town and why did they bury the
  truth?" or "Can two people who've built their lives around independence learn to
  need each other?")
- **Thematic Throughline**: The deeper thematic thread running through every volume
  (belonging, justice, second chances, found family, redemption, etc.)
- **Momentum Ladder**: How stakes, tension, and complexity build from volume to
  volume. Each book should feel larger in scope or deeper in emotional resonance
  than the last. Define the specific escalation per volume.

#### For Extend Existing Series:
Extract and confirm:
- What spine questions remain open?
- What character arcs are unfinished?
- What threads were planted but not yet resolved?
- What's the natural next escalation on the momentum ladder?

Then propose the **Series Forward Plan**: where the series goes from here, including
new questions to raise, new complications, and how existing threads resolve.

**Present and wait for feedback.**

---

### Step 3: Volume Blueprints

Generate a blueprint for each planned volume. Each blueprint includes:

- **Volume Number and Working Title**
- **One-Line Hook** (the "back of book" elevator pitch)
- **Central Conflict** (what drives this particular volume)
- **Spine Connection** (how this volume advances the series spine question)
- **Character Spotlight** (which characters get the most development)
- **New Elements** (new characters, settings, complications, revelations introduced)
- **Threads Resolved** (what questions from this or previous volumes are answered)
- **Threads Opened** (new threads planted for future volumes)
- **Growth Seed** (if the series extends beyond the planned length, where does this
  volume leave room for expansion?)

#### Genre-Specific Blueprint Elements:

**For Cozy Mystery Series:**
- Each volume needs its own standalone case (fully resolved by the end)
- A series-spanning mystery or tension that builds across volumes
- Community evolution (new characters, new businesses, seasonal changes)
- The investigator's growing reputation and capabilities
- If paranormal: magical world-building that deepens each volume
- If romance: clear romantic progression milestones per volume

**For Romance Series:**
- Each volume features a different couple (interconnected standalones) OR the same
  couple at different stages
- Shared world/community/circle that ties volumes together
- Each volume is a complete romance arc (HEA or HFN)
- Supporting characters from one volume become leads in later volumes
- The community/world evolves and grows

**For Other Genres:**
- Adapt based on genre conventions (see `series-conventions.md`)

**Present all blueprints and ask: "Do these volume concepts work? Want to adjust any?"**

---

### Step 4: Character Trajectory Map

Map how key characters evolve across the entire series.

For each major recurring character, create a series-level trajectory:

```
Character: [Name]
Role: [Protagonist / Love Interest / Ally / Antagonist / etc.]

Volume 1: [Where they start — emotional state, goals, relationships]
Volume 2: [How they've changed — what events from Volume 1 affect them]
Volume 3: [Further development — growth, setbacks, new dynamics]
Volume 4: [Approaching resolution — arcs converging]
Volume 5: [Resolution — where they end up]
```

(Adjust number of volumes to match the planned series length.)

### Key dimensions to track per character:
- **Emotional trajectory** (how they grow/change internally)
- **Relationship trajectory** (how their connections to other characters shift)
- **Competence trajectory** (how they become better at what they do — especially
  for mystery investigators or action protagonists)
- **Secrets & revelations** (what the reader learns about them over time)

For romance subplots, map the romantic progression specifically:
- Volume 1: Meeting / attraction / tension
- Volume 2: Growing closer / obstacles
- Volume 3: Major turning point
- Volume 4: Deepening commitment / crisis
- Volume 5: Full resolution / HEA

**Present the character trajectory map and ask for feedback.**

---

### Step 5: Series Canon and Arc Weave Matrix

Create a series-level continuity document that tracks everything across volumes.

#### Timeline
- How much time passes between volumes (days, weeks, months, seasons?)
- Seasonal setting for each volume (if applicable — cozy mysteries especially
  benefit from seasonal variety)
- Key dates and events that anchor the timeline

#### World Canon
- Setting details that carry across volumes (town layout, key locations, businesses)
- Rules of the world (especially important for paranormal/fantasy — what abilities
  can and can't do)
- Community dynamics (alliances, rivalries, social networks)

#### Arc Weave Matrix
A table tracking every open thread across the series:

| Thread | Planted In | Develops In | Resolves In | Notes |
|--------|-----------|-------------|-------------|-------|
| Who was behind the original incident? | Vol 1 | Vols 2–4 | Vol 5 | Spine thread |
| Protagonist's estranged family | Vol 1 | Vol 3 | Vol 4 | Character thread |
| The sealed room in the old building | Vol 2 | Vol 3 | Vol 4 | World thread |

#### Growth Seeds
Note specific places where the series could naturally extend:
- "If we add Volume 6, this thread from Volume 4 could become its own storyline"
- "This supporting character introduced in Volume 3 could carry their own volume"
- "This world-building element has untapped potential for 2–3 more volumes"

**Present the series canon and arc weave matrix, then ask for feedback.**

---

### Step 6: High-Level Volume Outlines

For each volume beyond Book 1 (or beyond existing books if extending), create a
high-level outline:

- **Three-Act Summary** (1–2 paragraphs per act)
- **Key Plot Beats** (8–12 major beats per volume)
- **Character Moments** (the must-have emotional scenes)
- **Hook for Next Volume** (what makes the reader reach for the next book)
- **Spine Advancement** (specific progress on the series spine question)

For mystery/thriller series, each volume outline also needs:
- The standalone case (victim, perpetrator, method, motive — in brief)
- How the standalone case connects to or complicates the series-level arc
- Misdirection strategy for this volume
- Clue planting that serves both the standalone AND series arcs

**This step is the most extensive. Present one volume at a time and ask for feedback
before moving to the next.**

---

### Step 7: Series Positioning and Sell-Through Blueprint

Generate series-level marketing material:

- **Series Positioning Brief** (200–300 words): What would go on a series page or
  box set description. Sells the WORLD and the PROMISE, not just Volume 1.
- **Market Anchors**: 2–3 published series that share DNA with this one ("For fans
  of [X] meets [Y]")
- **Series Selling Points**: 3–5 bullet points for why a reader should commit to
  this series
- **Sell-Through Blueprint**: How to structure pricing and release to maximise
  series read-through (e.g., Volume 1 at introductory price or permafree, rest at
  full price; rapid release schedule; box set timing)

**Present and ask for feedback.**

---

### Step 8: Final Delivery — Series Bible

Compile everything into a single Series Bible document:

1. Series Concept and Macro Architecture
2. Volume Blueprints
3. Character Trajectory Map
4. Series Canon (including Arc Weave Matrix)
5. High-Level Outlines for each volume
6. Series Positioning and Sell-Through Blueprint

Save as: `Ideorix-Projects/[Series Title]/series-data/series-bible.md`
Also save a user-facing summary as: `Ideorix-Projects/[Series Title]/series-data/series-plan.docx`

### Series Folder Structure (MANDATORY)

When a project is identified as a series (Phase 1 Q7: "Book 1" or
"Book 2-5"), the Series Architect creates a MASTER SERIES FOLDER
with individual book folders nested inside:

```
Ideorix-Projects/[Series Title]/
├── series-data/                     ← Series-level planning (shared across all books)
│   ├── series-bible.md              ← Cross-volume canon + arc weave matrix
│   ├── series-guns.md               ← Long-range Chekhov's Guns (cross-volume)
│   └── series-plan.docx             ← User-facing series summary
├── [Book 1 Title]/                  ← Individual book folder (full standard structure)
│   ├── engine-data/
│   │   ├── story-bible.md
│   │   ├── chapters/
│   │   ├── reports/
│   │   └── ... (all standard per-book files)
│   ├── manuscript/
│   └── marketing/
├── [Book 2 Title]/
│   ├── engine-data/
│   ├── manuscript/
│   └── marketing/
└── [Book 3 Title]/                  ← Created when the user starts Book 3
    ├── engine-data/
    ├── manuscript/
    └── marketing/
```

**Rules:**
- Series-level files live in `series-data/`, NOT in any individual
  book's `engine-data/`. The series bible is the cross-volume reference;
  each book's story bible is the per-volume reference.
- Individual book folders are created AS NEEDED — when the user starts
  Book 1, only `[Book 1 Title]/` is created alongside `series-data/`.
  Book 2 and 3 folders are created when the user begins those volumes.
- The `series-data/` folder uses a DIFFERENT name from `engine-data/`
  deliberately — this prevents confusion between series-level and
  book-level state files. A folder named `engine-data/` always belongs
  to a specific book; `series-data/` always belongs to the series.
- Each book folder has the FULL standard structure (engine-data/,
  manuscript/, marketing/) identical to a standalone project.

**Path pattern for series books:**
`Ideorix-Projects/[Series Title]/[Book Title]/engine-data/chapters/ch01.md`

Compare standalone:
`Ideorix-Projects/[Book Title]/engine-data/chapters/ch01.md`

The only difference is the intermediate `[Series Title]/` directory.
All per-book paths (chapters, reports, summaries, etc.) remain the
same relative to the book folder root.

**After delivery, remind the user**: "You can always come back to extend this series —
just upload the latest book or outline and we'll plan the next phase. The growth seeds
are already built in."

---

## Integration with Core Pipeline

When the Series Architect completes, it feeds into the standard Ideorix pipeline:

1. **Series Bible** is saved to `series-data/series-bible.md`
2. User selects which volume to write first (usually Volume 1)
3. The core pipeline's Phase 1 (Setup) inherits:
   - Genre from series planning
   - Series position (auto-set to correct volume number)
   - Spine question and thematic throughline → injected into Story Bible
   - Volume blueprint → used as the outline source (Question 9)
   - Character trajectories → inform character creation with arc endpoints
4. Phase 2 (Story Bible) includes a **Series Continuity** section
   (see world-canon.md for the series extension)
5. Verification agents gain access to the Arc Weave Matrix for
   cross-volume continuity checking

## Names & Patterns Rules

ALL generated series content must follow `authenticity-guard.md` rules.
No AI-default names, places, or patterns. Use real-world naming conventions.

## Number & Time Diversity

Actively avoid defaulting to 7 for ages, quantities, chapter counts, volume counts,
or dates. Distribute numbers across all ending digits. This is an anti-AI-bias
measure — LLMs disproportionately favour the number 7.
