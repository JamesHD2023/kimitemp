---
name: womens-fiction-genre
description: Genre-specific instructions for women's fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Women's Fiction. Genre Plugin

## Metadata
- id: womens-fiction
- name: Women's Fiction
- icon: 💪
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Seven-Point Story Structure", "Dan Harmon Story Circle"]

## Subgenre Options
Present during setup:
- **Self-Discovery**. A woman finding (or refinding) herself: identity, independence, purpose. the journey FROM who she was TO who she becomes
- **Friendship-Centred**. The bonds between women as the central story: the complexity, loyalty, jealousy, and endurance of female friendships
- **Family Drama**. The family system: mothers and daughters, sisters, generations. the ties that bind and the ones that need cutting
- **Starting Over**. Reinvention: after divorce, loss, career change, or crisis. building a new life from the rubble of the old one
- **Multi-Generational**. Women across generations: how their stories echo, diverge, and illuminate each other
- **Book Club Fiction**. Accessible, emotionally engaging, discussion-worthy: stories designed to be shared and talked about

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Emotional rhythm. the story breathes with the protagonist's inner life; moments of crisis alternate with reflection, connection, and growth
- Must open with: The protagonist at a crossroads or in a situation that's about to change. the reader should feel both the weight of her current life and the promise of what it might become

BEATS PER CHAPTER
1. Identity Beat. Who is she right now? Her self-perception, her role, how others see her vs. how she sees herself
2. Relationship Beat. A bond is tested, deepened, broken, or discovered; women's fiction is a literature of connection
3. Pressure Beat. Something pushes against her: expectation, obligation, betrayal, loss, the demands of others
4. Agency Beat. She makes a choice, takes an action, or refuses to; the protagonist must ACT, not just endure
5. Growth Beat. She learns something, shifts a perspective, gains a skill, or takes a step toward who she's becoming

WOMEN'S FICTION ARCHITECTURE
- The PROTAGONIST'S JOURNEY is the plot: her emotional, psychological, and practical transformation
- RELATIONSHIPS are the landscape: every significant relationship is a thread in the story's fabric
- The INTERIOR LIFE is central: thoughts, feelings, memories, fears, hopes. the reader lives inside her consciousness
- AGENCY is essential: the protagonist makes choices, takes risks, and drives her own story. she is not a victim of circumstance
- COMMUNITY matters: the women around her (friends, mothers, daughters, sisters, colleagues) form a network that supports, challenges, and complicates her journey
- RESILIENCE is the through-line: women's fiction celebrates the strength required to survive, adapt, and grow
- POV: First person (intimate, confessional) or third person close (allows slight distance and broader perspective)

THE EMOTIONAL LANDSCAPE
- Women's fiction takes emotional experience SERIOUSLY: feelings are not decorative, they're the substance
- Complex emotions: the simultaneous love and resentment toward a mother; the pride and envy between friends; the relief and guilt after leaving a marriage
- Emotional intelligence: the protagonist's ability to read others (and herself) grows across the narrative
- The body carries emotion: tension in the shoulders, the knot in the stomach, tears that arrive at inconvenient moments

FORBIDDEN IN WOMEN'S FICTION
- The passive protagonist who waits to be rescued (by a man, by fate, by someone else's decision)
- Defining the protagonist entirely through her relationships (she must have desires BEYOND others)
- Men as the sole source of conflict or salvation
- Emotional simplicity: this character should feel COMPLEX emotions, not just "happy" or "sad"
- The makeover-montage transformation: real change is gradual, painful, and non-linear
- Condescension toward "women's concerns" (domestic life, relationships, self-care. these are not trivial)
- Romance as the endpoint: romance can be PART of the story, but the arc is about HER, not the couple
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (primary), Captivation, Revelation through the protagonist's transformation.

VOICE & TONE
- POV: First person (dominant. intimate, confessional) or close third
- Voice: Warm, intelligent, often wry. the voice of a woman who's aware of the absurdity of her situation even as she's living through it
- Tone: Emotionally resonant without being saccharine; honest about difficulty without being bleak
- Register: Accessible, conversational, real. the reader should feel like she's talking to a smart friend

PROSE IMPERATIVES
- EMOTIONAL PRECISION: the exact feeling, not the approximate one
  - Not "she was worried" but "she had the specific worry of a woman who has said 'I'm fine' so many times that no one asks anymore"
  - Compound emotions: feeling two things at once is the norm, not the exception
  - The body as emotional register: where does she feel it? The chest? The throat? The hands?
- RELATIONSHIP PROSE: rendering the space between people
  - The history of a relationship in a single gesture: the way her mother touches her hair, the way her friend raises one eyebrow
  - What's not said: the loaded silence, the subject change, the too-bright laugh
  - The shift: the moment a relationship changes, rendered with precision
- DOMESTIC DETAIL AS MEANING: the home is not backdrop, it's text
  - What she cooks tells you who she is; what she wears to the meeting tells you what she's feeling
  - The state of the house mirrors the state of the life: the sink full of dishes, the garden left untended
  - These details are not decoration. they're the story's language
- HUMOUR: women's fiction uses humour as a survival tool
  - Self-deprecating wit that reveals intelligence
  - The absurdity of trying to be everything to everyone
  - Dark humour when things are genuinely difficult
  - Humour that builds intimacy between the narrator and reader

PROSE RHYTHM MAPPING
- Ch 1 hook: Emotional stakes that are immediately personal and specific
- Prose rhythm: Warm, intimate, grounded in domestic/relational detail
- Sentence length: 14-22 words average
  - Conversational flow. accessible without being simple
  - Shorter sentences during emotional intensity; longer during reflection
- Interiority: High. 60-80 words per beat, always advancing the emotional arc
  - Compound emotions rendered precisely (feeling two things at once is the norm)
  - The body as emotional register: where does she feel it?
- Dialogue: Natural, often multi-layered
  - What's said vs. what's meant. the gap IS the drama
  - 30-40% by word count; more during key relationship scenes
- Tension: ≥4 for Ch 1
- Paragraph rhythm: Medium paragraphs (3-5 sentences) with warmth
  - Single-line paragraphs for emotional clarity or humour
  - Longer paragraphs for reflection and self-reckoning

DIALOGUE CRAFT
- Women talking to women: the specific register of female friendship (supportive, challenging, funny, occasionally brutal)
- Women talking to men: the unspoken negotiations of gender, power, and expectation
- The conversation she REHEARSES vs. the one she actually has
- Text messages and phone calls as relationship barometers
- The group conversation: the dynamics of women in a room together (who leads, who deflects, who says the uncomfortable thing)
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

CHARACTER JOURNEY (40% of total):
- The protagonist is specific, complex, and actively driving her story? (0-100)
- Her internal journey (identity, self-perception, growth) is the central arc? (0-100)
- She has agency and makes choices (not just reacting)? (0-100)
- Her transformation is gradual, earned, and non-linear? (0-100)

RELATIONSHIP CRAFT (30% of total):
- Relationships are rendered with complexity and specificity? (0-100)
- Female friendships/bonds are central and multi-dimensional? (0-100)
- The space between people (subtext, history, tension) is palpable? (0-100)
- Supporting characters have their own lives and motivations? (0-100)

PROSE QUALITY (30% of total):
- Emotional precision (exact feelings, not approximate)? (0-100)
- Voice is warm, intelligent, and distinctive? (0-100)
- Domestic/daily details carry meaning? (0-100)
- Humour is present and serves the story? (0-100)

AUTOMATIC FAILS (score = 0):
- Passive protagonist who waits to be saved
- All emotional depth comes from romance (the arc must be HER arc)
- Emotional simplicity (characters feel one thing at a time)
- Domestic life treated as trivial or backdrop
- The "makeover transformation" (overnight change that doesn't feel earned)
- Condescending tone toward the protagonist's concerns
```

## Continuity Rules

```
WOMEN'S FICTION CONTINUITY. WHAT TO TRACK

IDENTITY STATE:
- Who the protagonist thinks she is at each chapter (her self-image evolves)
- The roles she occupies: mother, daughter, friend, professional, partner. and how she feels about each
- Her confidence level: track the rises and falls
- Her goals: what she wants, what she's pursuing, and how these shift

RELATIONSHIP STATE:
- Every significant relationship: current status, recent interactions, unresolved issues
- The friendship network: who she calls first, who she avoids, who she's reconnecting with
- Family dynamics: ongoing tensions, recent developments, unhealed wounds
- Romantic relationship (if present): its trajectory, conflicts, and emotional temperature

PRACTICAL STATE:
- Living situation: housing, finances, employment. the practical scaffolding of her life
- Health: physical, mental, emotional. including how she's taking care of (or neglecting) herself
- Daily routine: what her days look like, and how this changes across the manuscript
- Self-care: what she does for herself (or doesn't). yoga, wine, therapy, running, baking at midnight

EMOTIONAL ARC:
- Her dominant emotional state per chapter
- Unprocessed events: things that happened but haven't been dealt with
- Breakthroughs: moments of clarity, however small
- Setbacks: moments where old patterns reassert themselves
- The reader should be able to trace a line from her emotional state in chapter 1 to her state in the final chapter

GROWTH MARKERS:
- Specific moments where she does something she couldn't have done in chapter 1
- Skills learned (practical and emotional)
- Boundaries set (especially new ones)
- Relationships renegotiated (speaking up, stepping back, reaching out)
```

## Character Rules

```
WOMEN'S FICTION CHARACTER TYPES

THE PROTAGONIST:
- A specific woman at a specific moment: her age, her life stage, her circumstances matter
- She has a rich inner life: thoughts, feelings, memories, fears, dreams that the reader shares
- She is COMPETENT: good at something, knowledgeable about something, valued for something
- She is FLAWED: avoidant, controlling, self-sacrificing, angry, afraid. in recognisable, sympathetic ways
- Her growth is the story: she becomes more herself, not a different person
- She makes choices: even when the choice is "I'm going to stop doing this"

THE BEST FRIEND:
- Not just a sounding board. has her own life, problems, and perspective
- Challenges the protagonist: says the hard things, offers the uncomfortable truth
- Their friendship has HISTORY: shorthand, shared memories, known territories
- She may have her own arc (smaller, but present)

THE MOTHER FIGURE:
- May be the protagonist's actual mother, a mother-in-law, or an older mentor
- The relationship is COMPLEX: love and frustration, gratitude and resentment
- She represents the previous generation's choices (and their consequences)
- Understanding her is part of the protagonist's growth

THE ROMANTIC INTEREST (if present):
- A fully developed person, not a prize to be won
- Challenges the protagonist in ways that contribute to her growth
- Has his/her own life, flaws, and journey
- The romance supports the protagonist's arc. it doesn't replace it

THE ANTAGONIST:
- Often a person who represents what the protagonist fears becoming (or was)
- May be a system rather than a person (workplace culture, social expectation, family dynamics)
- If a person: their motivations are understandable, even sympathetic
- They push the protagonist toward the change she's avoiding

VOICE DIFFERENTIATION:
- The protagonist: self-aware, sometimes self-critical, warm, wry
- The best friend: more blunt, possibly funnier, says what the protagonist won't
- The mother figure: speaks from a different era's assumptions and experience
- The romantic interest: a different communication style that the protagonist must learn to read
```

## Arc Rules

```
WOMEN'S FICTION STORY STRUCTURE

ACT 1: THE LIFE SHE HAS (first 25%)
- The protagonist's current life in full detail: what works, what doesn't, what she's accepted, what she's ignoring
- Her relationships: the web of connections that define her daily experience
- The roles she plays: and the gap between who she IS and who she presents
- The catalyst: an event that makes the status quo unsustainable (divorce papers, a death, a revelation, a crisis, a chance encounter)
- END OF ACT 1: She can't go back to the way things were

ACT 2A: THE ATTEMPT (to midpoint)
- She tries to change: makes moves, takes risks, reaches out
- Some attempts work; others backfire spectacularly
- Friendships are tested: her changes affect others, not always positively
- Old patterns reassert: she falls back into familiar roles and behaviours
- New possibilities open: skills, people, experiences that suggest who she could become
- MIDPOINT: A moment of genuine breakthrough. followed immediately by a complication that shows how much further she has to go

ACT 2B: THE UNRAVELLING (midpoint to dark moment)
- The deeper issues surface: it's not just the marriage, the job, or the friendship. it's what they represented
- Relationships reach crisis: the conversations that have been avoided can no longer be delayed
- Her self-image cracks: she sees herself clearly, including the parts she'd rather not
- External pressures compound: practical, financial, social
- DARK MOMENT: She faces the core truth. about herself, her mother, her marriage, her fear. and it's harder than she imagined

ACT 3: THE LIFE SHE CHOOSES (final 25%)
- She makes a CHOICE that reflects genuine growth (not just different circumstances)
- The difficult conversation: with her mother, her friend, her partner, HERSELF
- Relationships are renegotiated: some heal, some end, some transform
- She is recognisably the same person. but she has expanded, deepened, and chosen herself
- The ending is earned: the reader feels both the cost and the value of the change
- She is not "fixed". she is MORE HERSELF

WOMEN'S FICTION PACING:
- Emotional pacing: scenes expand during significant emotional moments, compress during transitions
- Conversation scenes can be the longest: the dynamics between women deserve space
- The pace accelerates through Act 3: decisions come faster as clarity increases
- The final chapter is often quiet: a moment of peace, perspective, or gentle humour after the storm
```

## Timeline Rules

```
WOMEN'S FICTION TIMELINE

LIFE-STAGE TIMELINE:
- Women's fiction is often tied to life transitions: turning 40, empty nest, divorce, retirement, new motherhood
- The transition period typically spans weeks to months
- Track the practical milestones: moving out, starting a job, first date, first day alone

RELATIONSHIP TIMELINE:
- When significant conversations happened
- Anniversary dates, birthdays, and milestone moments
- How long since the protagonist spoke to estranged people
- The history of key relationships (when they met, when things changed)

SELF-CARE TIMELINE:
- Track the protagonist's self-care arc: when she starts running, when she stops drinking, when she starts therapy
- These practical changes mirror the emotional arc
- Setbacks in self-care mirror emotional setbacks

SEASONAL RHYTHM:
- Women's fiction often follows seasonal progression
- The season mirrors the emotional arc (winter isolation → spring renewal is classic but effective)
- Holidays and cultural events as story beats (Christmas alone, the first birthday after)
```

## Genre-Specific Craft Techniques

Women's fiction is a genre with a distinct dual obligation:
deliver emotional resonance and reader pleasure on the
commercial side, while taking female interiority,
female agency, and female relational life seriously
enough that the genre is not condescended to. The comp
field is wide and structurally diverse — Liane Moriarty
(Big Little Lies, Apples Never Fall), Elin Hilderbrand
(beach / Nantucket setting craft), Taylor Jenkins Reid
(Daisy Jones, Carrie Soto, Malibu Rising), Sally
Hepworth (The Mother-in-Law, The Good Sister), Kristin
Hannah (The Nightingale, The Four Winds), Jojo Moyes (Me
Before You, The Giver of Stars), Jodi Picoult, Marian
Keyes, Anne Tyler, Curtis Sittenfeld, Jennifer Weiner,
Susan Wiggs, Robyn Carr, Beth O'Leary, Helen Fielding,
Rebecca Wells (Ya-Ya Sisterhood). Each of these writers
keeps the genre's two halves in tension. emotional
accessibility and craft seriousness, recognisable life-
stage situations and fully-rendered specific women,
forward-driving plot and unrushed relational depth. The
most common failure modes in this register are: **Passive-
Heroine Trap** (the protagonist who waits for events to
happen rather than driving them — she receives the
divorce papers, she receives the diagnosis, she receives
the affair confession, but never makes a choice of her
own that the reader can name); **Romance-as-Resolution**
(using romantic union as the proxy for personal
transformation — "she got the man" as the arc, the new
relationship presented as evidence of growth rather than
the growth itself); **Best-Friend-as-Sounding-Board**
(the secondary woman who exists only to listen and
validate, who has no off-page life, no current crisis of
her own, no perspective the protagonist hasn't already
articulated); **Mother-as-Antagonist Reduction**
(collapsing the mother-daughter relationship to villain
versus victim instead of rendering complex love — the
mother who is cruel, period; rather than the mother who
loved imperfectly, in an imperfect time, with the tools
she had); **Domestic-as-Decorative** (kitchen scenes,
clothing choices, garden details rendered as backdrop
rather than as meaning — what she cooks should tell the
reader who she is, not just where the scene is set);
**Strength-as-Performance** (the "strong woman" who is
strong in slogans rather than in specific demonstrated
choices — "she was a survivor" rather than the specific
moment of survival, the specific refusal, the specific
boundary held); **Generic-Empowerment-Pap** (vague
feminist-coded language without specific consequence —
"she was learning to take up space", "she was finding
her voice", "she was reclaiming her power" as filler
phrases that signal theme without delivering it); and
**Conflict-Avoidance Reduction** (the difficult
conversation deferred forever; the boundary that's
stated but never tested; the mother who is never
actually confronted, the friend who is never actually
told the hard thing). The techniques below — three
preserved (Mirror Moment, Friendship Shorthand, Inherited
Pattern) and three added (Specific-Strength Discipline,
Domestic-as-Text System, Female-Network Architecture) —
are designed to keep the genre's dual obligation live:
emotional accessibility AND seriousness of craft;
recognisable situations AND specifically-rendered women.

### The Mirror Moment

A scene where the protagonist sees herself clearly. not in a literal mirror, but through someone else's eyes:

```
Her daughter said, "You always do this. You say you're
fine and then you make that face and everyone has to
pretend they believe you."

She opened her mouth to say she was fine.

She closed it.
```

### The Friendship Shorthand

Long friendships have their own language:

```
Kate texted: WINE?
She texted back: THERAPY WINE OR CELEBRATION WINE?
Kate: IS THERE A THIRD OPTION
She: THAT BAD?
Kate: BRING THE GOOD GLASSES

Twelve texts. An entire emotional conversation. Years
of friendship in a text exchange.
```

### The Inherited Pattern

The protagonist recognises her mother's behaviour in herself:

```
She heard herself say "It's fine, don't worry about me"
and felt a cold flash of recognition. It was her mother's
voice. Not the tone or the accent, but the STRATEGY. the
decades-old family tradition of performing selflessness
while keeping a running tally of sacrifices nobody asked for.
```

### Women's Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "she was finding herself" | Show the specific discovery through action |
| "juggling career and family" | Show the specific dropped ball |
| "she'd lost herself in the marriage" | Show the specific thing she gave up and how she notices its absence |
| "it was time to put herself first" | Show the specific selfish act and its consequences |
| "sisterhood was powerful" | Show the specific act of female support |
| "she was stronger than she knew" | Show the specific strength demonstrated in crisis |
| "the journey of self-discovery" | Show ONE specific discovery moment |
| "reclaiming her identity" | Show the specific identity marker she retrieves |
| "she realised she deserved more" | Show the specific "more" and the specific "less" she's been accepting |
| "motherhood changed everything" | Show the specific thing that changed |
| "she found her voice" | Show the specific thing she finally says |
| "the bonds of friendship" | Show the specific shared act |
| "she was learning to take up space" | Show the specific space she takes — in a meeting, at a table, in a conversation |
| "the weight of generations" | Show the specific generational pattern through one inherited gesture or phrase |
| "she would no longer apologise for existing" | Show the specific apology she stops making, mid-sentence |
| "the unspoken expectations" | Show the specific expectation through one specific look or comment |
| "she had been everything for everyone" | Show the specific everything — the school run, the dinner, the calling-the-plumber |
| "she was rediscovering her authentic self" | Cut "authentic self"; show one specific old preference she returns to (a band, a book, a route home) |

### The Specific-Strength Discipline

Women's fiction earns its strength claims through
specific demonstrated choice, never through narrated
assertion. The genre fails when the protagonist is told
to be strong by the narration (or by the supporting
cast) without the reader being shown the specific
moment where strength looks like a particular refusal,
a particular boundary, a particular act that the
chapter-1 version of her could not have performed.

```
PRINCIPLE
Strength is not asserted. Strength is shown through:
- A specific REFUSAL she makes (not "she said no" — the
  exact words, the exact context, the exact thing she
  refuses)
- A specific BOUNDARY she holds when tested (not
  "she stood her ground" — the test, the temptation
  to fold, the held line)
- A specific TRUTH she speaks aloud that she has been
  swallowing for chapters (not "she finally spoke up"
  — the actual sentence, said to the actual person)
- A specific RISK she takes that she could not have
  taken in chapter 1 (not "she was finally ready" —
  the leap itself, with all its ambivalence)

CALIBRATION TEST
For every claim of strength in the narration or
dialogue, ask:
- Is the strength SHOWN in this chapter or an earlier
  chapter, or only ASSERTED?
- Is the strength SPECIFIC (a particular act) or
  GENERIC ("she was strong")?
- Did the chapter-1 version of her have this capacity,
  or has the protagonist genuinely changed?
- Could a reader name the moment where this strength
  was earned?
If any answer is no — rewrite for specificity.

ANTI-PATTERNS
- "She had become a survivor" without the moment of
  survival
- "She found her voice" without the specific sentence
- "She was finally putting herself first" without the
  specific selfish act and its specific cost
- Strength delivered as slogan ("girls support girls",
  "she was unstoppable", "she had taken back her
  power") rather than as observed behaviour
- Strength conferred by a man's recognition (a male
  character telling her she's strong is not the same
  as the reader seeing her be strong)
```

### The Domestic-as-Text System

Women's fiction inherits a long tradition of treating
the domestic as the site where character is rendered.
Done well, this is one of the genre's defining
strengths — the kitchen, the wardrobe, the garden, the
school run, the holiday meal preparation are all text,
not backdrop. Done badly, domestic detail becomes
decorative: lipstick mentioned for atmosphere, dinner
prepared for setting, garden tended because women in
this genre tend gardens. The discipline is to make
every domestic detail a load-bearing piece of
characterisation or plot.

```
PRINCIPLE
The domestic detail must do at least one of:
- Reveal CHARACTER (what she cooks, wears, drives,
  cleans, cares about — and how those choices change
  across the manuscript)
- Reveal RELATIONSHIP (who is welcome in the kitchen,
  whose name is on the chore chart, whose photo is
  framed and whose is buried in a drawer)
- Reveal STATUS or HISTORY (the heirloom dish, the
  inherited recipe, the carpet she's had since
  university, the phone she refuses to upgrade)
- Reveal CHANGE (the dishes left in the sink for the
  first time; the meal she always made and now
  refuses to; the wedding ring removed and where it
  goes)

WORKED EXAMPLE
Weak (decorative):
"She put on her favourite earrings and went to meet
her sister at the café."

Strong (textual):
"She put on the earrings her mother had given her at
her divorce — the only divorce gift she had received,
and the only thing of her mother's she still wore —
and went to meet the sister who had not, in fifteen
years, asked her once how she was."

The earrings are now character (her relationship to
her mother, her divorce), relationship (her sister,
the family pattern), and history (fifteen years of
unasked questions). All in one sentence. That's the
discipline.

THE KITCHEN AS BAROMETER
The state of the kitchen across the manuscript should
mirror the state of the protagonist's life.
Crucially: the kitchen does not need narrating
("the dishes piled up because she was overwhelmed").
The reader builds the meaning. Sink full → sink half-
full → sink empty → sink full of new flowers in a
glass jar. The arc is rendered in the sink.

ANTI-PATTERNS
- Domestic detail mentioned but never returned to (a
  prop in one scene, gone in the next)
- Domestic detail used purely for atmosphere ("the
  smell of baking filled the warm kitchen")
- Domestic detail that contradicts character without
  acknowledgement (she's a chaotic mess in chapter 3
  but her kitchen is gleaming in chapter 4)
- Domestic detail that flattens women's lives into
  cliché (every woman bakes; every woman gardens;
  every woman has "her" coffee mug)
```

### The Female-Network Architecture

Women's fiction is, more than any other genre, a
literature of female community. The protagonist exists
inside a network of women — friends, sisters, mothers,
daughters, colleagues, neighbours, strangers in
waiting rooms — and the architecture of that network
is one of the genre's primary craft surfaces. The
common failure is to render the network as a single
best friend (the sounding board), a difficult mother
(the antagonist), and a generic background of "the
girls" (filler). The discipline is to build a network
where each woman is real.

```
PRINCIPLE
The female network architecture requires:
1. AT LEAST 3 SIGNIFICANT WOMEN beyond the protagonist
   — each rendered with her own life, agency, and
   active off-page concerns
2. EACH significant woman has a CRISIS OR DESIRE OF
   HER OWN that is visible in the manuscript
   (referenced, briefly entered, or briefly resolved)
   — not a full subplot, but enough that the reader
   knows her life continues when she leaves the page
3. AT LEAST ONE MOMENT per major arc beat where a
   woman in the network challenges the protagonist
   rather than supports her — the friend who says the
   uncomfortable thing, the sister who refuses to
   collude in the family lie, the colleague who calls
   out the avoidance
4. AT LEAST ONE MOMENT per major arc beat where the
   protagonist supports another woman — women's
   fiction is reciprocal; the protagonist who only
   receives support is incomplete
5. THE NETWORK SHIFTS across the manuscript — friends
   who were close drift, friends who were peripheral
   become central, the mother who was distant
   approaches, the daughter who was a child becomes
   a peer

CALIBRATION TEST
- Does each named woman in the manuscript have a life
  the reader can imagine continuing when she leaves
  the page?
- Does at least one supporting woman challenge the
  protagonist meaningfully (not just "you should call
  your mother")?
- Does the protagonist support someone, not just
  receive support?
- Does the network look DIFFERENT at the end than it
  did at the start?
If any answer is no — rebuild.

ANTI-PATTERNS
- The Best-Friend-as-Sounding-Board (one woman whose
  only function is to listen)
- The Wallpaper Sisterhood (a cluster of women named
  but never individuated — "and her three friends")
- The Antagonist-Mother who has no inner life of her
  own beyond opposing the protagonist
- The Static Network (the same configuration of
  relationships from chapter 1 to chapter 30)
- The Female-Solidarity Slogan (women supporting each
  other invoked in the abstract rather than shown
  in specific reciprocal acts)
```

## Genre-Specific Revision Rules

### Six-Pass Women's Fiction Audit (Run FIRST in editorial pipeline)

The Women's Fiction Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Agency Pass

The protagonist must make at least one active choice in
every chapter — even when the choice is "I am going to
stop doing this" or "I am not going to apologise this
time" or "I will go even though I am afraid". The
Passive-Heroine Trap is the single most common failure
mode in women's fiction, and it is rarely visible to
the writer because it disguises itself as realism
("she was overwhelmed; she didn't know what to do;
she let the days pass"). Realism is not the absence of
agency; realism is agency exercised under constraint.
Audit each chapter: identify the choice the protagonist
makes. If the only choice is "she didn't say
anything", that is sometimes a valid choice — but it
must be a CONSCIOUS not-saying, with the reader inside
her decision, not a default she falls into. When things
happen TO her (the call, the diagnosis, the affair
revelation), the response must contain at least one
active element — even if the active element is to sit
on the kitchen floor and order a pizza, that pizza is a
choice she makes rather than a thing that happens.

#### Pass 2: Relationship Depth Pass

At least one relationship must be advanced, complicated,
or deepened in each chapter. The relationship can be
with a friend, a mother, a daughter, a sister, a
colleague, a neighbour, the protagonist's romantic
partner, or with the protagonist herself (her
relationship to her own past, her body, her name).
Female relationships in particular must be rendered
with the same craft attention given to romantic
relationships. the friendship between two women in
their forties deserves as much specificity as the
courtship of a marriage plot. Audit the subtext: what
is not said? What is the gap between what she texts and
what she means? What does the friend's silence on a
particular subject reveal? If a relationship in the
chapter is rendered only on its surface (literal
dialogue, no subtext, no history pressing under the
words), it has not been earned.

#### Pass 3: Emotional Complexity Pass

The protagonist must feel at least TWO emotions
simultaneously at some point in each chapter, and the
prose must render the simultaneity rather than collapse
it. The compound emotion is the genre's signature: the
mother whose grief at her daughter's leaving home is
laced with a relief she will not admit; the friend
whose congratulations on a promotion are genuine AND
contain a thread of envy that surprises her; the
divorcée whose first night alone is sad AND
luxurious. Audit each emotional moment: is the feeling
GENERIC ("she was sad", "she was angry") or SPECIFIC
("she had the particular anger of a woman who has been
told to calm down by men who did not, themselves, seem
calm")? Is the body involved — where does she feel it?
The chest, the throat, the small of the back, the
hands? If a chapter contains only flat single-affect
emotion, rebuild for compound emotion and bodily
specificity.

#### Pass 4: Growth Pass

There must be at least one moment per chapter that
moves the protagonist's arc forward — even by a
millimetre. Growth in women's fiction is non-linear
(setbacks are required; full reversals are common
and earn their reversal in a later chapter), but
direction must be discernible across the manuscript.
The Specific-Strength Discipline applies here: identify
the moment of growth and ask whether the chapter-1
version of her could have done this. If yes — the
moment is not growth, it is competence. If no — the
moment is the chapter's growth marker. Setbacks must
be present too. a chapter where she is purely thriving
is suspicious; a chapter where she fully regresses
must be followed by a chapter that re-establishes
direction. Track the cumulative arc: the protagonist
in the final chapter must be recognisably the same
person but visibly more herself.

#### Pass 5: Voice Pass

The narrative voice must be warm, intelligent, and
distinctive — the voice of a specific woman, not a
generic women's-fiction narrator. Audit each chapter
for vocabulary range, syntactic patterns, and
characteristic devices (does she use parenthetical
asides? Does she punctuate observation with self-
deprecating wit? Does she favour short sharp sentences
when angry, longer ones when reflective?). Humour
must be present in some form — even in the darkest
chapters, the protagonist's wry awareness of absurdity
is one of the genre's primary intimacies with the
reader. If a chapter reads as if it could have been
narrated by any of the manuscript's women, the voice
has flattened. If a chapter contains no moment of
warmth, intelligence, or humour, it has lost the
narrator.

#### Pass 6: Specific-Strength + Domestic-Text + Female-Network Integration

This pass is the women's-fiction integration check —
it ties the new techniques together and verifies the
chapter serves the genre's dual obligation of
emotional accessibility and craft seriousness.

For SPECIFIC-STRENGTH: identify any moment of asserted
strength in the chapter (in narration, in dialogue, in
the protagonist's own self-talk). For each, verify the
strength is SHOWN through specific demonstrated choice,
not narrated as slogan. If the chapter contains
"she was a survivor", "she found her voice", "she was
finally putting herself first", or any equivalent
generic-empowerment phrase, rewrite to render the
specific moment of survival, the specific sentence
finally spoken, the specific selfish act and its
specific cost.

For DOMESTIC-TEXT: identify the chapter's domestic
details (kitchen, clothing, garden, car, phone, home,
school run, meal preparation, holiday rituals). For
each, verify the detail is doing at least one of:
revealing character, revealing relationship, revealing
status or history, revealing change. If a domestic
detail is purely decorative ("the smell of baking
filled the kitchen"; "she put on her favourite
earrings"), either rebuild it for textual weight or
cut it. The kitchen, in particular, should function as
a barometer across the manuscript — track what state
it is in this chapter and whether the state mirrors
the protagonist's interior arc.

For FEMALE-NETWORK: identify the women named in the
chapter beyond the protagonist. For each, verify she
has a life the reader can imagine continuing when she
leaves the page (not necessarily entered, but
referenced or felt). Verify at least one supporting
woman challenges the protagonist meaningfully in the
manuscript's overall arc (the chapter under audit may
not contain the challenge, but the manuscript must).
Verify the protagonist supports another woman
somewhere in the manuscript. Verify the network
configuration shifts across the manuscript: who is
close in chapter 1 versus chapter 30, who has entered,
who has left. If the female network is static, flat,
or organised around a single sounding-board friend,
rebuild for genuine plurality. The genre is the
literature of female community. that community must
be a real community, not a backdrop.

## Names & Patterns to Avoid

### Women's Fiction Character Names. NEVER USE
- Names that signal "strong woman": Athena, Valerie (valour), Victoria
- Cutesy names that undermine the character: Buffy, Bunny, Trixie
- Names that date badly or signal a specific demographic too narrowly

### Women's Fiction. NEVER DO
- Open with the protagonist looking in a mirror and describing herself
- Have the best friend exist only to give advice
- Solve the protagonist's problems with a man's arrival
- Treat domestic work as either noble sacrifice or oppressive drudgery (it's BOTH, and more)
- End with a wedding, pregnancy, or relationship as the "reward" for personal growth

### Use Instead
- Names appropriate to the character's age, background, and cultural context
- Names that feel chosen by her parents, not by an author trying to signal something

## Comp Titles

Women's-fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Joy Luck Club* — Amy Tan (1989): mother-daughter women's-fiction benchmark.
- *Divine Secrets of the Ya-Ya Sisterhood* — Rebecca Wells (1996): female-friendship women's-fiction benchmark.
- *The Bridges of Madison County* — Robert James Waller (1992): commercial women's-fiction crossover.
- *Where the Heart Is* — Billie Letts (1995): women's-fiction commercial-literary template.

### Contemporary (current best-in-class)

- *Big Little Lies* — Liane Moriarty (2014): contemporary women's-fiction-thriller crossover benchmark.
- *Apples Never Fall* — Liane Moriarty (2021): contemporary family women's-fiction.
- *The Last Thing He Told Me* — Laura Dave (2021): contemporary women's-fiction-thriller.
- *Lessons in Chemistry* — Bonnie Garmus (2022): historical-feminist women's-fiction.
- *Carrie Soto Is Back* — Taylor Jenkins Reid (2022): women's-fiction with sport architecture.
- *The Mother-in-Law* — Sally Hepworth (2019): contemporary domestic women's-fiction-thriller.
- *Beach Read* — Emily Henry (2020): contemporary women's-fiction-romance crossover.
- *The Family Upstairs* — Lisa Jewell (2019): contemporary domestic women's-fiction-suspense.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrative**. Contemporary illustration: a woman, a scene, a moment rendered in a modern, appealing style; warm and inviting
- **Photographic**. A figure (from behind, in motion, in a meaningful setting) that suggests the emotional world; aspirational but real
- **Typographic**. Bold, beautiful title with minimal imagery; a single colour or textural element; clean and confident
- **Graphic**. Bold colours, clean design, a single striking image or object; the cover as visual statement

### Genre Cover Aesthetics
- **Styles:** Women in motion or contemplation (not posed), domestic spaces rendered beautiful (kitchens, gardens, windows), natural settings (beaches, forests, fields), objects that suggest story (a letter, a suitcase, a key, a pair of shoes), single figures in evocative settings
- **Colours:** Warm, inviting palettes: coral, sage, dusty rose, amber, soft teal, cream; bold single colours for high-concept; pastels for lighter tones; rich jewel tones for dramatic stories; colours that feel both feminine and strong
- **Elements:** Women depicted with strength and warmth (not fragility), domestic objects elevated to significance, natural beauty, book club-friendly aesthetics, modern illustration styles, hand-lettering for warmth
- **Typography:** Approachable serif or script fonts for warmth; bold sans-serif for strength; the title should be large and inviting; author name prominent; the typography should feel like an invitation

### Market Positioning
Women's fiction covers must signal "this is YOUR story". recognisable, emotionally resonant, and beautifully presented. Position against Picoult, Hilderbrand, Ng, Reid, Shipstead. Book club appeal is important: the cover should look good face-out on a table. At thumbnail size, warm colours and clear typography create immediate emotional appeal. The cover should suggest depth without intimidating: accessible AND meaningful.

### Cover Design DON'Ts
- No "chick lit" pastel triviality (the genre has evolved beyond stilettos and shopping bags)
- No headless women in sundresses (the body-without-identity trope)
- No infantilising design (cupcakes, sparkles, hearts)
- No dark, grim aesthetics (women's fiction is ultimately hopeful)
- No generic beach/sunset imagery (unless the execution is exceptional)
- No designs that look like romance novels (no embracing couples, no shirtless men)
