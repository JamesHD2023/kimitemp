---
name: format-markdown
description: "Clean Markdown export template"
user-invocable: false
---
<!-- (c) 2025 Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->
# Markdown Export Template

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.md`

This Markdown export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. Use `-export.md` if you need to disambiguate from the chapter source files. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Overview

Export the manuscript as clean Markdown with heading hierarchy, scene breaks, and
formatting preserved. For authors who work in Obsidian, Scrivener import, or
version-controlled writing workflows.

## Markdown Structure

```markdown
# Book Title

*by Author Name*

---

## Chapter 1: The Discovery

First paragraph of the chapter with no special formatting needed.

Second paragraph continues the narrative flow. **Bold text** and *italic text*
are preserved using standard Markdown syntax.

---

"Dialogue paragraphs start naturally," she said.

---

## Chapter 2: The Revelation

...
```

## Formatting Conventions

| Element | Markdown Syntax |
|---------|----------------|
| Book title | `# Book Title` (H1) |
| Author byline | `*by Author Name*` (italic, after H1) |
| Chapter headings | `## Chapter N: Title` (H2) |
| Scene breaks | `---` (horizontal rule, blank line before and after) |
| Body paragraphs | Plain text, separated by blank lines |
| Bold text | `**bold**` |
| Italic text | `*italic*` |
| Em-dash | `—` (Unicode em-dash, not `--`) |
| Dialogue | Standard quotation marks, no special formatting |

## File Specifications

- **Encoding:** UTF-8
- **Line endings:** LF (Unix-style)
- **File extension:** `.md`
- **Paragraph separation:** Double newline (blank line between paragraphs)
- **No trailing whitespace** on any line

## Node.js Generation Template

```javascript
function createMarkdown(title, author, chapters) {
  const lines = [];

  // Title block
  lines.push(`# ${title}`);
  lines.push('');
  lines.push(`*by ${author}*`);
  lines.push('');
  lines.push('---');
  lines.push('');

  // Chapters
  chapters.forEach((chapter, index) => {
    // Chapter heading
    lines.push(`## Chapter ${index + 1}: ${chapter.title}`);
    lines.push('');

    // Chapter content
    const paragraphs = chapter.content.split('\n\n');

    paragraphs.forEach(para => {
      const trimmed = para.trim();
      if (!trimmed) return;

      // Scene break — normalize to ---
      if (trimmed === '* * *' || trimmed === '---') {
        lines.push('---');
        lines.push('');
        return;
      }

      // Regular paragraph — preserve inline formatting
      lines.push(trimmed);
      lines.push('');
    });
  });

  // Clean up: remove trailing blank lines, ensure final newline
  let output = lines.join('\n').replace(/\n{3,}/g, '\n\n').trimEnd();
  output += '\n';

  return Buffer.from(output, 'utf-8');
}
```

## Content Parsing Notes

1. Preserve all Markdown-native formatting (`**bold**`, `*italic*`)
2. Convert scene breaks (any format) to `---`
3. Ensure blank lines between all paragraphs
4. Preserve em-dashes, curly quotes, and special Unicode characters
5. No HTML tags — pure Markdown only
6. Strip any DOCX-specific formatting that doesn't translate

## Import Compatibility

### Obsidian
- Drop the `.md` file into any vault folder
- Chapter headings appear in the outline panel
- Scene breaks render as horizontal rules
- Links and tags can be added by the author after import

### Scrivener
- File → Import → Files → select the `.md` file
- Scrivener converts Markdown headings to document structure
- Each H2 chapter heading becomes a separate document in the Binder
- Use "Split by heading" for automatic chapter splitting

### VS Code / Git Workflows
- Standard Markdown renders in any editor preview
- Clean diffs for version control — each paragraph is a single line
- Compatible with Pandoc for further conversion to any format

### Ulysses
- Drag and drop `.md` file into Ulysses library
- Formatting preserved via Ulysses' Markdown XL support

## Delivery Notes

When delivering a Markdown file, include:
- Total word count
- Note that this format is ideal for further editing and conversion
- Mention Pandoc compatibility for converting to other formats if needed
