---
name: writers-companion
description: "Protocol for generating the Writer's Companion document — a comprehensive creative brief for human writers in Story Bible Only mode"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Writer's Companion Protocol

## Purpose

Generate a single, comprehensive .docx document that gives a human writer
everything they need to write their novel without guessing. The Writer's
Companion is the primary deliverable of Story Bible Only mode — it compiles
the Story Bible, entity database, outline, beat structure, trope plan,
Chekhov's Guns, genre craft notes, and transportive setting into a
human-friendly reference document.

Think of it as the brief a ghostwriter would receive: complete, specific,
and structured for someone who needs to write the book from scratch.

## When It Runs

- During Phase 2.5, ONLY when `project_mode` is `story_bible_only`
- After Phase 2 (Story Bible Generation) is fully complete
- All source documents (story-bible.md, entities.md, outline.md, etc.)
  must exist before this protocol runs

## Source Documents

The Writer's Companion draws from these engine-data files:

| Source | Used For |
|--------|----------|
| `story-bible.md` | World, characters, themes, timeline, canon |
| `entities.md` | Structured character/location reference |
| `outline.md` | Chapter-by-chapter plan |
| `beat-structure.md` | Structural beat map (if selected) |
| `trope-plan.md` | Trope delivery schedule (if tropes selected) |
| `chekhovs-guns.md` | Plant/payoff tracking (if guns selected) |
| `market-pulse.md` | Comp titles and positioning (if generated) |
| `style-guide.md` | Voice/style guidance (if built from uploads) |
| Genre bank file | Genre conventions, craft rules, pitfalls |
| `transportive-settings.md` | Setting sensory palette (if selected) |

## Document Structure

Generate the Writer's Companion as a single .docx file with clear sections,
headers, and formatting. The tone should be direct, practical, and
encouraging — like notes from an experienced editor to a writer they trust.

---

### PART 1: YOUR STORY AT A GLANCE

A one-page overview the writer can pin above their desk.

**Include:**
- **Title** (working title)
- **Genre** and any subgenre
- **Premise** — 2-3 sentences (from Story Bible Section 1)
- **Hook** — The single-sentence pitch (from outline)
- **Positioning statement** — Back-cover pitch (from outline)
- **Word count target** — Total words, chapter count, words per chapter
- **Timeline** — When the story starts, when it ends, total timespan
- **Season** — The season(s) the story spans
- **POV** — Type, tense, voice characteristics
- **Tone** — Overall tone with genre-specific notes
- **Thematic question** — What the story is really asking (from Story Bible Section 2)
- **Genre promise** — What readers of this genre expect and must receive

**Format:** Clean, scannable. No dense paragraphs. A writer should be able
to glance at this page and remember what they're writing.

---

### PART 2: YOUR CHARACTERS

Written as prose profiles, not database fields. Each character should feel
like someone the writer already knows.

**For the PROTAGONIST:**
- Full name and any nicknames
- Age and physical description (the 2-3 details that matter, not a police report)
- Who they are in the world (occupation, social position, daily life)
- **Surface personality** — how others see them
- **Underneath** — who they really are under pressure
- **Internal conflict** — the tension between two competing needs (frame as "X vs Y")
- **What they want** — the conscious goal driving them
- **What they need** — the deeper truth the story forces them toward
- **Core flaw** — the specific behavior that creates problems
- **How they talk** — speech patterns, vocabulary, sentence length, tics, humour.
  Include 2-3 example lines of dialogue showing their voice
- **Arc summary** — Where they start → what changes them → where they end.
  Written as a narrative sentence, not bullet points
- **Key relationships** — How they relate to every major character, with the
  emotional dynamic (not just "friends" — what's the tension, the loyalty, the history?)

**For EACH MAJOR CHARACTER:**
- Same depth as protagonist, scaled slightly shorter
- Emphasis on how they differ from the protagonist in voice and behavior
- Their role in the story (what breaks if you remove them?)
- Their relationship to the protagonist (the dynamic, not just the label)

**For MINOR CHARACTERS:**
- Name, role, 2-3 defining traits
- One sentence on why they exist in the story
- How they sound different from everyone else (one speech habit)

**RELATIONSHIP MAP:**
- A clear summary of who connects to whom and how
- Note which relationships change during the story (and when)

**CHARACTER VOICE GUIDE:**
A quick-reference table the writer can consult while writing dialogue:

```
| Character | Speech Style | Vocabulary | Tics/Habits | Example Line |
|-----------|-------------|------------|-------------|--------------|
| {name}    | {short/long sentences, formal/casual} | {register} | {specific habit} | "{example}" |
```

---

### PART 3: YOUR WORLD

Everything the writer needs to make the world feel real on the page.

**Setting Overview:**
- Where and when the story takes place
- The feel of the world (from transportive setting, if selected)
- What makes this setting distinctive

**Key Locations:**
For each major location:
- Name and function
- Physical description (what a character would notice walking in)
- Atmosphere and mood
- Who frequents this place
- Why it matters to the story

**Sensory Palette:**
The specific sensory details the writer should reach for in this world:
- **Smells** — 5-8 specific smells associated with this world
- **Sounds** — 5-8 ambient sounds and character sounds
- **Textures** — What characters touch and feel
- **Light** — How light behaves in this world (quality, time of day, seasonal)
- **Temperature** — The physical feeling of being in this place
- **Taste** — Food, drink, the taste of air or weather

> **Note to writer:** You don't need ALL of these in every scene. Pick ONE
> dominant sense per scene and commit to it. The list gives you options — not
> obligations.

**Timeline and Calendar:**
- Story start date and end date
- Season(s) the story spans
- Months that may appear in the narrative
- Key dates and events (with their position in the story)
- Day-by-day or week-by-week chronology if the story is tightly timed

**Canon Rules:**
Things the writer must not contradict — world rules, physical constraints,
established facts. Listed clearly so the writer can check against them.

**Worldbuilding Categories:**
Include ONLY the categories generated in the Story Bible (genre-dependent):
- Culture & daily life details to weave into prose
- Magic/technology systems (rules, costs, limitations)
- Social structures, politics, factions
- History and lore that affects the present
- Any other generated worldbuilding categories

---

### PART 4: YOUR PLOT

The chapter-by-chapter roadmap. This is the spine of the Writer's Companion.

**Story Structure Overview:**
- Act breakdown with chapter ranges
- Key turning points (inciting incident, midpoint, climax, resolution)
- How tension/pressure should escalate across the manuscript
- Subplot integration points

**CHAPTER-BY-CHAPTER OUTLINE:**

For EACH chapter, present a self-contained briefing the writer can read
before sitting down to write that chapter:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  CHAPTER {N}: {Title}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  WHAT HAPPENS:
  {3-5 sentence summary of events}

  WHY IT MATTERS:
  {What this chapter accomplishes in the larger story — why the reader
  needs this chapter}

  EMOTIONAL ARC:
  Opens: {mood/feeling}  →  Closes: {mood/feeling}

  CHARACTERS PRESENT: {list}

  STORY BEAT: {which structural beat this chapter serves}
  {One sentence on how this beat works in the chapter}

  STAKES ESCALATION:
  {What is at risk now that wasn't before? How have stakes risen
  since the previous chapter?}

  TROPE WORK: {which tropes advance this chapter, if any}
  {Setup / escalation / payoff note}

  CHEKHOV'S GUNS: {any guns planted or paid off this chapter}

  KEY SCENES:
  - Scene 1: {what happens, where, emotional register}
  - Scene 2: {what happens, where, emotional register}
  - Scene 3: {what happens, where, emotional register}

  CHAPTER ENDING:
  {How this chapter should close — what question or tension pulls
  the reader into the next chapter}

  PACING GUIDANCE:
  Tension: {1-10}  |  Pacing Energy: {1-10}
  {Brief note on prose rhythm — fast/slow, dialogue-heavy/reflective}

  WORD TARGET: ~{words} words
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**BEAT STRUCTURE MAP** (if beat structure selected):
Visual overview showing which beat falls where across the manuscript.
Present as a simple table:

```
| Beat | Target Chapter | Description |
|------|---------------|-------------|
| {beat_name} | Ch {N} | {what this beat accomplishes} |
```

**TROPE DELIVERY SCHEDULE** (if tropes selected):
For each selected trope:
- What it is and how it manifests in this story
- Setup chapters (where it's introduced)
- Escalation chapters (where it deepens)
- Payoff chapters (where it resolves)
- How it interacts with other selected tropes

**CHEKHOV'S GUN TRACKING** (if guns selected):
For each gun:
- What it is (the element)
- Plant chapter — how to introduce it naturally (it should feel incidental)
- Payoff chapter — how it becomes significant
- Callback note — how to echo the original introduction when it pays off

**SUBPLOT MAP:**
For each subplot:
- What it is and which characters carry it
- Where it appears (chapter list)
- How it connects to the main plot
- When and how it resolves

---

### PART 5: GENRE CRAFT NOTES

Practical writing advice specific to this genre. Drawn from the genre bank
file, translated into direct guidance for the writer.

**Genre Conventions — What Readers Expect:**
- The genre promise (what must be delivered)
- Key conventions the writer should honour
- Reader expectations for pacing, tone, and resolution

**Common Pitfalls to Avoid:**
- Genre-specific mistakes (from the genre bank's avoidance rules)
- Pacing traps (where this genre tends to sag)
- Character pitfalls (archetypes that feel stale)

**Pacing Guidance:**
- How this genre handles pacing across acts
- Where to push tempo and where to breathe
- The relationship between genre pacing and emotional impact

**Dialogue Tips:**
- Genre-specific dialogue conventions
- How characters in this genre tend to speak
- What to avoid in dialogue for this genre

**Prose Style Notes:**
- Genre-appropriate prose register
- Sentence rhythm guidance
- Description density expectations

**Names & Patterns to Avoid:**
- Genre-specific naming pitfalls
- Clichéd patterns for this genre
- AI-default patterns to watch for (even in human writing, some
  patterns feel generic — this list helps the writer avoid them)

---

### PART 6: WHEN YOU'RE DONE

Clear instructions for bringing the manuscript back to Ideorix.

**How to Return Your Manuscript:**

```
When you've finished writing, open Ideorix and say any of:

  "Edit my {Title}"
  "I've finished {Title}"
  "Review my manuscript for {Title}"

Then paste or upload your completed manuscript (plain text, Markdown,
.txt, or text pasted from Word or Google Docs).

What happens next:
1. The engine reconnects to your Story Bible and character database
2. It validates your manuscript against the established canon
3. It asks you about any creative changes you made (characters you
   changed, plot points you moved, details you invented)
4. It reconciles the Story Bible to match YOUR decisions
5. It builds a Voice Profile from YOUR writing style
6. It runs the full editorial pipeline:
   • Proofreader — grammar, spelling, punctuation
   • Copy Editor — sentence-level clarity, word choice, rhythm
   • Developmental Editor — structure, pacing, arcs, plot holes
   • Line Editor — deep prose polish, cliché detection
   • Alpha Reader — first-impression feedback
   • Beta Reader — genre-expert assessment
7. You receive an editorial report and revised manuscript

The editing is MORE accurate than a cold edit because the engine
already knows your story — characters, timeline, canon, genre
conventions — from the Story Bible it built with you.
```

**Other Tools Available:**
- **Cover Designer** — "Design my cover" (uses your Story Bible for context)
- **Marketing Expert** — "Marketing for {Title}" (blurbs, Amazon copy, social)
- **Manuscript Clinic** — "Manuscript clinic for {Title}" (deep diagnostic)
- **Video Trailer Designer** — "Create a trailer for {Title}"

**Tips for Writing from This Brief:**
- Use the chapter outline as a roadmap, not a prison. If you discover
  something better while writing, follow it. When you bring the manuscript
  back, the engine will reconcile your creative departures with the original plan.
- Refer to the Character Voice Guide before writing dialogue for each character.
  Read their example lines aloud to get their rhythm in your ear.
- Pick ONE sensory detail per scene from the Sensory Palette. Don't catalogue.
- Check the Timeline periodically — temporal continuity is the easiest
  thing to break and the hardest to fix in revision.
- The beat structure shows you where your story should hit emotional peaks.
  Trust it for pacing, but deliver the beats in your own way.

---

## Formatting Rules

- Generate as a properly formatted .docx with:
  - Clear heading hierarchy (Part → Section → Subsection)
  - Page breaks between Parts
  - Clean tables where tables are used
  - Readable fonts and spacing (this is a working document, not a manuscript)
- Save to: `Ideorix-Projects/[Title]/manuscript/writers-companion.docx`
- Use `format-docx.md` for .docx generation protocol

## Tone Guidelines

The Writer's Companion should feel like:
- Notes from an experienced editor who respects the writer
- Direct and practical — no fluff, no motivation, no "you've got this!"
- Confident in its structural choices but clear that the writer can deviate
- Warm but professional — like a colleague, not a teacher

**Never:**
- Patronise the writer
- Use exclamation marks excessively
- Include meta-commentary about AI or the engine
- Add motivational quotes or generic writing advice
- Include anything the writer doesn't need to write the book

## Quality Checklist

Before delivering the Writer's Companion, verify:

- [ ] Every character in entities.md appears in Part 2
- [ ] Every location in entities.md appears in Part 3
- [ ] Every chapter in the outline appears in Part 4
- [ ] Beat structure (if selected) is mapped in Part 4
- [ ] Trope plan (if selected) is integrated into Part 4
- [ ] Chekhov's Guns (if selected) are tracked in Part 4
- [ ] Genre craft notes draw from the actual genre bank file, not generic advice
- [ ] Timeline is internally consistent
- [ ] Return instructions reference the correct project title
- [ ] The document is self-contained — a writer could work from this
  document alone without accessing any engine-data files
