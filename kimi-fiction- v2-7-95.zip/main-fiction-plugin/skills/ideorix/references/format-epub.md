---
name: format-epub
description: "EPUB 3 e-book generation template"
user-invocable: false
---
<!-- (c) 2025 Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->
# EPUB 3 Generation Template

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.epub`

This EPUB 3 export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Overview

Generate standard EPUB 3 e-books with proper chapter navigation, metadata, and
formatting that renders correctly on Kindle, Kobo, Apple Books, and Nook.

**Universal Standard (EPUB 3.3/3.2):** EPUB is the most widely supported
vendor-independent format. It is the required standard for nearly all major
retailers, offering reflowable text that adapts to different screen sizes and
orientations. This is the format to use for wide distribution.

EPUB is a ZIP archive containing XHTML content files, a navigation document,
and package metadata. This template produces spec-compliant EPUB 3 files.

## EPUB Structure

```
manuscript.epub (ZIP archive)
├── mimetype                          # Must be first file, uncompressed
├── META-INF/
│   └── container.xml                 # Points to content.opf
├── OEBPS/
│   ├── content.opf                   # Package document (metadata + manifest + spine)
│   ├── toc.xhtml                     # Navigation document (table of contents)
│   ├── style.css                     # Stylesheet
│   ├── title.xhtml                   # Title page
│   ├── chapter-01.xhtml              # Chapter 1
│   ├── chapter-02.xhtml              # Chapter 2
│   └── ...                           # Remaining chapters
```

## Metadata Requirements

The content.opf must include:
- **dc:title** — Book title
- **dc:creator** — Author name
- **dc:language** — Language code (default: `en`)
- **dc:identifier** — Unique identifier (generate a UUID)
- **dc:date** — Publication date (or current date)
- **dc:description** — Book description/blurb
- **dc:subject** — Genre/category
- **meta property="dcterms:modified"** — Last modified timestamp

## Stylesheet (style.css)

```css
@charset "UTF-8";

body {
  font-family: Georgia, "Times New Roman", serif;
  font-size: 1em;
  line-height: 1.6;
  margin: 1em;
  text-align: justify;
}

h1 {
  font-size: 1.8em;
  text-align: center;
  margin-top: 3em;
  margin-bottom: 1.5em;
  font-weight: bold;
  page-break-before: always;
}

p {
  margin: 0;
  text-indent: 1.5em;
}

p.first, p.after-break {
  text-indent: 0;
}

p.scene-break {
  text-indent: 0;
  text-align: center;
  margin: 1.5em 0;
}

.title-page {
  text-align: center;
  margin-top: 30%;
}

.title-page h1 {
  font-size: 2.2em;
  margin-bottom: 0.5em;
  page-break-before: auto;
}

.title-page .author {
  font-size: 1.4em;
  margin-top: 2em;
}
```

## Node.js Generation Template

```javascript
const JSZip = require('jszip');
const { v4: uuidv4 } = require('uuid');

async function createEpub(title, author, chapters, metadata = {}) {
  const zip = new JSZip();
  const bookId = uuidv4();
  const now = new Date().toISOString().split('.')[0] + 'Z';
  const description = metadata.description || '';
  const language = metadata.language || 'en';
  const genre = metadata.genre || 'Fiction';

  // mimetype — must be first, uncompressed
  zip.file('mimetype', 'application/epub+zip', { compression: 'STORE' });

  // META-INF/container.xml
  zip.file('META-INF/container.xml', `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>`);

  // Stylesheet
  zip.file('OEBPS/style.css', getStylesheet());

  // Title page
  zip.file('OEBPS/title.xhtml', createTitlePage(title, author));

  // Chapter files
  chapters.forEach((chapter, index) => {
    const num = String(index + 1).padStart(2, '0');
    zip.file(`OEBPS/chapter-${num}.xhtml`,
      createChapterXhtml(chapter, index));
  });

  // Navigation document (toc.xhtml)
  zip.file('OEBPS/toc.xhtml', createNavDocument(title, chapters));

  // Package document (content.opf)
  zip.file('OEBPS/content.opf', createPackageDocument({
    bookId, title, author, language, description, genre, now, chapters
  }));

  return zip.generateAsync({ type: 'nodebuffer', mimeType: 'application/epub+zip' });
}

function getStylesheet() {
  return `@charset "UTF-8";
body { font-family: Georgia, "Times New Roman", serif; font-size: 1em;
       line-height: 1.6; margin: 1em; text-align: justify; }
h1 { font-size: 1.8em; text-align: center; margin-top: 3em;
     margin-bottom: 1.5em; font-weight: bold; page-break-before: always; }
p { margin: 0; text-indent: 1.5em; }
p.first, p.after-break { text-indent: 0; }
p.scene-break { text-indent: 0; text-align: center; margin: 1.5em 0; }
.title-page { text-align: center; margin-top: 30%; }
.title-page h1 { font-size: 2.2em; margin-bottom: 0.5em; page-break-before: auto; }
.title-page .author { font-size: 1.4em; margin-top: 2em; }`;
}

function escapeXml(text) {
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;')
             .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function createTitlePage(title, author) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><title>${escapeXml(title)}</title>
<link rel="stylesheet" type="text/css" href="style.css"/></head>
<body>
<div class="title-page">
  <h1>${escapeXml(title)}</h1>
  <p class="author">${escapeXml(author)}</p>
</div>
</body></html>`;
}

function createChapterXhtml(chapter, index) {
  const heading = escapeXml(`Chapter ${index + 1}: ${chapter.title}`);
  const bodyHtml = convertContentToXhtml(chapter.content);

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><title>${heading}</title>
<link rel="stylesheet" type="text/css" href="style.css"/></head>
<body>
<h1>${heading}</h1>
${bodyHtml}
</body></html>`;
}

function convertContentToXhtml(content) {
  const paragraphs = content.split('\n\n');
  let isFirst = true;
  const lines = [];

  for (const para of paragraphs) {
    const trimmed = para.trim();
    if (!trimmed) continue;

    if (trimmed === '* * *' || trimmed === '---') {
      lines.push('<p class="scene-break">* * *</p>');
      isFirst = true;
      continue;
    }

    const cssClass = isFirst ? ' class="first"' : '';
    const html = convertInlineFormatting(escapeXml(trimmed));
    lines.push(`<p${cssClass}>${html}</p>`);
    isFirst = false;
  }

  return lines.join('\n');
}

function convertInlineFormatting(text) {
  // Bold
  text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  // Italic
  text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');
  return text;
}

function createNavDocument(title, chapters) {
  const items = chapters.map((ch, i) => {
    const num = String(i + 1).padStart(2, '0');
    return `    <li><a href="chapter-${num}.xhtml">${escapeXml(`Chapter ${i + 1}: ${ch.title}`)}</a></li>`;
  }).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><title>Table of Contents</title></head>
<body>
<nav epub:type="toc" id="toc">
  <h1>Table of Contents</h1>
  <ol>
${items}
  </ol>
</nav>
</body></html>`;
}

function createPackageDocument({ bookId, title, author, language, description,
                                  genre, now, chapters }) {
  const manifestItems = [
    '<item id="style" href="style.css" media-type="text/css"/>',
    '<item id="nav" href="toc.xhtml" media-type="application/xhtml+xml" properties="nav"/>',
    '<item id="title-page" href="title.xhtml" media-type="application/xhtml+xml"/>'
  ];
  const spineItems = ['<itemref idref="title-page"/>'];

  chapters.forEach((_, i) => {
    const num = String(i + 1).padStart(2, '0');
    manifestItems.push(
      `<item id="chapter-${num}" href="chapter-${num}.xhtml" media-type="application/xhtml+xml"/>`
    );
    spineItems.push(`<itemref idref="chapter-${num}"/>`);
  });

  return `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
  <dc:identifier id="bookid">urn:uuid:${bookId}</dc:identifier>
  <dc:title>${escapeXml(title)}</dc:title>
  <dc:creator>${escapeXml(author)}</dc:creator>
  <dc:language>${language}</dc:language>
  <dc:description>${escapeXml(description)}</dc:description>
  <dc:subject>${escapeXml(genre)}</dc:subject>
  <meta property="dcterms:modified">${now}</meta>
</metadata>
<manifest>
  ${manifestItems.join('\n  ')}
</manifest>
<spine>
  ${spineItems.join('\n  ')}
</spine>
</package>`;
}
```

## Content Parsing Notes

1. All text must be valid XHTML — escape `&`, `<`, `>`, `"`
2. Split on double newlines for paragraph breaks
3. Convert scene breaks to `<p class="scene-break">* * *</p>`
4. First paragraph after heading or scene break gets class `first` (no indent)
5. Convert `**bold**` to `<strong>`, `*italic*` to `<em>`
6. Preserve em-dashes (—), curly quotes, and special characters
7. Each chapter is a separate XHTML file for proper navigation

## Retailer Compatibility Notes

- **Kindle (KDP):** Upload EPUB directly — Amazon converts to KF8 automatically
- **Kobo Writing Life:** Accepts EPUB 3 directly
- **Apple Books (iTunes Connect):** Accepts EPUB 3 directly
- **Nook Press:** Accepts EPUB directly
- **Google Play Books:** Accepts EPUB directly
- **Draft2Digital / Smashwords:** Accept EPUB for wide distribution
