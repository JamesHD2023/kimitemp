---
name: space-opera-genre
description: Genre-specific instructions for space opera fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Space Opera. Genre Plugin

## Metadata
- id: space-opera
- name: Space Opera
- icon: ✨
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Hero's Journey", "Seven-Point Story Structure", "Dan Harmon Story Circle"]

## Subgenre Options
Present during setup:
- **Classic Space Opera**. Grand adventure across star systems, diverse crews, galaxy-spanning stakes
- **Space Western**. Frontier justice, lawless regions, small-crew survival on the edges of civilization
- **Political Space Opera**. Interstellar diplomacy, empire-level politics, palace intrigue among the stars
- **Pirate/Smuggler**. Outlaw crews, heists, underworld dealings, evading authority across systems
- **Generation Ship**. Closed society traveling between stars, internal politics, generational change
- **New Space Opera**. Literary ambition, complex morality, post-singularity or post-scarcity settings

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Cinematic. big action set pieces alternating with character drama and political intrigue
- Must open with: Action, crisis, arrival, or confrontation. never with a captain's log or star chart description

BEATS PER CHAPTER
1. Scale Beat. At least one moment that reminds the reader how BIG this universe is (a planet from orbit, a fleet, a distance measured in light-years, a civilization's span)
2. Crew Dynamic. The relationships between characters advance: loyalty tested, bonds formed, friction explored
3. Plot Advancement. The central mission/conflict progresses through action, discovery, or political manoeuvring
4. World Texture. A specific detail that makes this universe feel lived-in (alien food, ship maintenance, cultural customs, economic realities)
5. Stakes Escalation. The consequences of failure become clearer or larger

SPACE OPERA ARCHITECTURE
- The CREW is the story's emotional core. the ship (or station, or fleet) is their home
- Multiple species/cultures interacting creates the story's texture and conflict
- Scale is VAST but experienced through intimate character moments
- Politics operates at multiple levels: crew, ship, fleet, nation, species, galaxy
- FTL travel exists (or equivalent). don't let the physics slow down the drama
- Trade, economy, and resources drive politics as much as military power

CREW AND SHIP DYNAMICS
- The crew is a found family with complementary skills and conflicting personalities
- Ship/station hierarchy creates power dynamics and obligations
- Close quarters create intimacy, friction, and loyalty
- The ship itself has personality (quirks, history, damage, modifications)
- Crew disagreements about tactics, morality, and priorities DRIVE the plot

MULTI-SPECIES WORLD
- Each alien species is GENUINELY different: biology, psychology, values, communication
- Cultural misunderstanding is a source of both comedy and conflict
- No species is a monolith. individuals within each species vary
- Humans are not the default "normal". they're one species among many with their own peculiarities
- Biological differences create practical challenges (atmosphere, gravity, food, communication speed)

SPACE OPERA SCALE
- Distances are measured in light-years, not miles
- Civilizations span multiple star systems
- History stretches back millennia
- But EVERY scene is experienced at human scale. through one character's eyes, one ship's bridge, one planet's surface
- The galaxy is background; the people are foreground

FORBIDDEN IN SPACE OPERA
- Star Trek/Star Wars direct copies (create your OWN universe)
- Aliens that are just "humans but blue" (genuinely different psychology)
- Space battles that work like naval battles or aerial dogfights without acknowledging 3D space
- A universe where humans are always central and most important
- Technology exposition replacing story
- FTL travel treated as boring or routine (it's miraculous. the characters may be blasé, but the prose should carry the wonder occasionally)
- Monoculture planets (one planet = one biome = one culture is lazy)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (galactic worldbuilding), Anticipation (mission stakes), Stimulation at action set-pieces.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Third close past tense (rotating for ensemble) or first person (for single-protagonist stories)
- Voice: Cinematic and character-driven. big scope but personal lens
- Tone: Adventurous with emotional depth; space opera allows MORE humor and warmth than hard sci-fi
- Register: Varies by character: a pilot speaks differently from a diplomat who speaks differently from an alien linguist

PROSE IMPERATIVES
- SCALE is conveyed through CONTRAST: the vastness of space vs the smallness of a person standing at a viewport
- Ship interiors should feel as real as a home. Pick ONE domestic detail per scene. a character knows which corridor runs warm, or which bulkhead hums
- Alien worlds described through ARRIVAL: the single thing the character notices first. Different gravity, wrong-coloured sky, or air that tastes metallic. One detail, not three
- Space itself is not empty. it's filled with radiation, debris, beauty, and danger
- Battle scenes are PHYSICAL even in space. Pick the dominant sensation: G-forces pinning a pilot to the seat, or hull groaning under stress. One at a time

PROSE RHYTHM MAPPING
- Chapter 1 must establish scale + intimacy. the galaxy is vast, and we experience it through one person's heartbeat
- Long sentences for grandeur: when conveying scope (a fleet emerging from FTL, a planet seen from orbit, the span of a civilization), let sentences stretch to 22-30 words with layered imagery and subordinate clauses
- Short sentences for combat: when weapons fire and hulls breach, compress to 6-14 words. Immediate. Physical. One sensation per sentence
- The CONTRAST between these rhythms IS the genre: the seesaw between galactic scale and human intimacy should be felt in sentence length, not just content
- Opening paragraphs: establish the dual rhythm immediately. a long sentence of scope followed by a short sentence of human reaction. The reader feels both the vastness and the person within it
- Crew dialogue: quick, overlapping, professional. Short sentences (8-14 words) with the natural shorthand of people who work together under pressure
- Ship-as-home moments (mess hall, corridor walks): medium rhythm (16-22 words), warm and domestic. the prose relaxes to signal safety
- Political/diplomatic scenes: medium-long sentences (18-24 words), measured and deliberate, reflecting the careful language of negotiation
- Alien encounters: the rhythm should feel slightly wrong. unusual sentence lengths, unexpected pauses, cadences that don't quite match human speech patterns
- Scale moments (the reader feels the VASTNESS): one genuinely long sentence (25-35 words) that forces the reader to hold their breath, followed by a short one that releases it
- Tension baseline: ≥5 from the first page. Space opera tension comes from both personal stakes and galactic consequences. the prose should carry both
- Ensemble rhythm: each crew member's dialogue/POV has a slightly different rhythm signature. the pilot speaks in quick bursts, the diplomat in balanced clauses, the engineer in practical fragments
- Damage and aftermath: sentences lengthen after combat (18-24 words) as the crew assesses, grieves, and repairs. The prose slows to let loss register
- End-of-chapter rhythm: varies by chapter type. action chapters end sharp and short; character chapters end with one resonant long sentence; plot chapters end with a medium sentence carrying a revelation
- Read fleet-scale passages aloud grandly. they should feel cinematic. Read combat passages at a clip. they should feel urgent
- Adventure and wonder moments: slightly longer sentences with a lighter rhythm. the prose should feel like discovery, not observation
- Paragraph variety: mix long immersive paragraphs (scale) with short punchy ones (action) and medium domestic ones (crew) within each chapter
- The goal: prose that makes the reader feel simultaneously small (one person in an infinite universe) and immense (that one person's choices matter to everything)

CREW DIALOGUE
- Each crew member has a distinct voice. test by covering names; can you tell who's speaking?
- Professional shorthand: crews develop their own language ("hard burn", "go dark", nicknames for maneuvers)
- Banter under pressure is a space opera tradition and should feel earned (not forced)
- Cross-species communication has quirks: one species is too literal, another speaks in metaphor
- Command dialogue has rhythm: order, acknowledgment, status, action

ALIEN WORLD CRAFT
- Each new planet/station/ship is an opportunity for wonder OR unease
- Describe through the POV character's COMPARISON to what they know:
  "The gravity was lighter here. not enough for her stomach to float, but enough that her boots didn't sound right."
- Atmospheric detail: what does this world SMELL like? SOUND like? How does the air FEEL?
- Culture through DAILY LIFE: what people eat, how they greet, what they consider rude or sacred
- No tourist-guide descriptions. the reader discovers the world through the character's NEEDS (finding food, navigating customs, avoiding trouble)

BATTLE CRAFT (SPACE COMBAT)
- Space is 3D: threats come from above, below, and every angle
- Battles are fought by CREWS, not individuals (coordination, communication, competing priorities)
- Technology defines tactics: weapon ranges, shield capabilities, sensor limitations
- The bridge experience: information overload, rapid decisions, trusting your team
- Personal consequences: fear, injury, loss, adrenaline
- Aftermath: damage assessment, casualties, the quiet after the noise
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

SPACE OPERA CRAFT (35% of total):
- Scale conveyed through intimate character experience? (0-100)
- Crew dynamics feel authentic and drive the story? (0-100)
- Alien species are genuinely different (not humans in costume)? (0-100)
- The universe feels vast, lived-in, and consistent? (0-100)

STORY CRAFT (35% of total):
- Plot advances through character decisions (not just events)? (0-100)
- Multiple plotlines weave together effectively? (0-100)
- Action set pieces are clear, physical, and consequential? (0-100)
- Pacing balances action, character, and world? (0-100)

PROSE QUALITY (30% of total):
- Ship and space environments are sensorially vivid? (0-100)
- Dialogue is differentiated by character and species? (0-100)
- Wonder moments land (the reader feels the scale)? (0-100)
- Sensory detail quality (0-100)

AUTOMATIC FAILS (score = 0):
- Technology exposition replacing character drama
- Aliens that are culturally/psychologically identical to humans
- Space battles with no physical consequences (no damage, no fear, no casualties)
- Monoculture planets (one biome, one government, one people)
- No crew dynamics (characters who don't interact meaningfully)
- Direct clone of existing IP (Star Trek bridge, Star Wars cantina, etc.)
```

## Continuity Rules

```
SPACE OPERA CONTINUITY. WHAT TO TRACK

SHIP/FLEET STATE:
- Damage: hull breaches, system failures, and repairs (damage persists)
- Resources: fuel, ammunition, food, spare parts. track consumption
- Crew roster: who's aboard, who's been lost, who's been picked up
- Modifications: upgrades, jury-rigged fixes, borrowed tech
- Ship capabilities: what it can do, what it can't (consistent chapter to chapter)

INTERSTELLAR GEOGRAPHY:
- Star systems, planets, stations. named and located consistently
- Travel times between locations (FTL speed must be consistent)
- Who controls what territory
- Trade routes, borders, contested zones

POLITICAL STATE:
- Interstellar factions: who's at war, who's allied, who's neutral
- Power balance: military, economic, technological advantages
- Diplomatic status: treaties, tensions, negotiations in progress
- Intelligence: what each faction knows about the others

SPECIES AND CULTURE:
- Each species' biology: atmosphere requirements, gravity preferences, lifespans
- Cultural norms: greeting customs, taboos, communication styles
- Individual characters' relationship to their culture (conforming, rebelling, exiled)
- Cross-species relationships and their complications

CREW STATE:
- Personal relationships: who's close, who's in conflict, who's newly aboard
- Individual character arcs: what are they struggling with, what have they learned
- Injuries and trauma: physical and psychological, persisting across chapters
- Loyalty dynamics: who's questioning command, who's unwavering, who's hiding something
```

## Character Rules

```
SPACE OPERA CHARACTER ENSEMBLE

THE CAPTAIN/LEADER:
- Bears the weight of command: their decisions get people killed or save them
- Not always right. the best space opera captains are wrong sometimes
- Earns loyalty through competence AND care (not just charisma)
- Has a personal code that the story tests
- Their relationship with the crew IS the emotional spine of the story

THE CREW (found family ensemble):
- PILOT: Instinctive, physical relationship with the ship; the one who gets them out of trouble
- ENGINEER: Keeps everything running; knows the ship's secrets; often the pragmatic voice
- MEDIC/SCIENTIST: Technical expertise; sees the ethical implications others miss
- WEAPONS/SECURITY: The fighter; comfortable with violence but not without conscience
- COMMS/DIPLOMAT: The bridge between cultures; navigates social situations; reads people
- Roles can be combined or modified, but the FUNCTIONS should be represented

THE ALIEN CREW MEMBER(S):
- At least one non-human character in the core crew
- Their alienness is SPECIFIC: different sensory experience, different emotional responses, different values
- They are not the "wise outsider" commenting on humanity. they have their own problems
- Cultural friction with human crew members creates both comedy and genuine conflict

THE ANTAGONIST:
- Often represents a political/ideological position, not just personal villainy
- Has resources (fleets, planets, intelligence networks) that dwarf the protagonists
- Comprehensible motivation: expansion, security, ideology, revenge, survival
- May not be evil. they may be wrong, or right for the wrong reasons

VOICE DIFFERENTIATION:
- Professional role shapes vocabulary (pilots talk about vectors, diplomats talk about precedent)
- Species shapes perception and expression
- Rank shapes how characters address each other
- Under pressure, characters reveal their core: who swears, who goes calm, who cracks jokes
```

## Arc Rules

```
SPACE OPERA STORY STRUCTURE

ACT 1: ASSEMBLING THE CREW / THE MISSION (first 25%)
- Establish the crew and their dynamics (either existing crew or coming together)
- The ship/base/station is established as HOME
- The mission or inciting crisis is introduced
- Each crew member's role and personality established through ACTION
- The political landscape is sketched through character experience
- At least one early action/escape sequence to establish the story's pace
- END OF ACT 1: The crew is committed to the mission (willingly or not)

ACT 2A: INTO THE UNKNOWN (to midpoint)
- The mission progresses through alien worlds, space encounters, and political complications
- Crew bonds are tested: trust is built, rivalries emerge, secrets are revealed
- Scale expands: the galaxy is BIGGER than they thought, the threat is DEEPER
- Alliance-building: gaining unexpected allies, making uncomfortable deals
- At least two major set pieces (space battle, alien world encounter, heist, diplomatic crisis)
- MIDPOINT: A major revelation that changes the nature of the mission

ACT 2B: THE PRICE (midpoint to dark moment)
- The mission becomes personal: the stakes are no longer abstract
- Crew members are at risk: injury, capture, betrayal, death
- The enemy responds with overwhelming force or cunning
- Internal conflict: the crew disagrees about how to proceed
- Resources run low: fuel, time, allies, options
- DARK MOMENT: The crew suffers a devastating loss. military, personal, or both

ACT 3: THE FINAL RUN (final 25%)
- The crew regroups with what they have left
- The plan for the climax uses everything established: technology, alliances, character skills, knowledge gained
- The final confrontation combines personal and galactic stakes
- Crew members' individual arcs resolve in the context of the group
- Sacrifice: someone pays a real price for victory
- Resolution: the galaxy is changed; the crew endures but is different
- The adventure continues (or the crew's chapter closes). space opera loves an open horizon

ENSEMBLE PACING:
- Rotate focus across crew members. don't let one character dominate for more than 2-3 consecutive chapters
- Each crew member should have at least one "spotlight" chapter where they're central
- Crew scenes (mess hall, bridge, downtime) serve as emotional glue between action set pieces
- Personal subplots advance alongside the main mission
```

## Timeline Rules

```
SPACE OPERA TIMELINE

FTL TRAVEL:
- Establish the speed/nature of FTL and maintain consistency
- Travel times between key locations: always the same unless something changes (blockade, damage, new route)
- What happens during FTL transit: can people communicate? Is there subjective time? Side effects?

MISSION CLOCK:
- Most space opera has a ticking clock: a deadline, a pursuit, a dwindling resource
- Track the mission's progress as a percentage
- If multiple threads: are they synchronised or diverging in time?

SHIP'S TIME:
- Day/night cycles may be artificial on a ship. but they matter for crew rhythms
- Track: meals, watches/shifts, sleep cycles
- Time zones across planets and stations

GALACTIC TIMELINE:
- Wars, treaties, and political events have dates that matter
- News travels at FTL speed (or doesn't). information delay affects politics
- Historical events referenced by characters must be chronologically consistent
```

## Genre-Specific Craft Techniques

Space opera is a genre that demands two opposing crafts
held simultaneously: the GALACTIC SCALE that gives the
genre its sweep (empires, fleets, alien civilisations,
millennium-spanning conflicts) and the PERSONAL INTIMACY
that gives the reader someone to care about (the crew,
the bond, the specific scene that registers as human).
The canonical roster — Iain M. Banks (the Culture
novels: Consider Phlebas, Use of Weapons, Look to
Windward, Surface Detail, Excession), Lois McMaster
Bujold (the Vorkosigan saga), C.J. Cherryh (the Alliance-
Union and Foreigner sequences), Ursula K. Le Guin (the
Hainish cycle: The Left Hand of Darkness, The
Dispossessed), Frank Herbert (Dune), Dan Simmons (the
Hyperion Cantos), Vernor Vinge (A Fire Upon the Deep, A
Deepness in the Sky), Alastair Reynolds (Revelation
Space, House of Suns), Peter F. Hamilton (Pandora's Star,
the Commonwealth saga), Ann Leckie (the Imperial Radch
trilogy), Becky Chambers (the Wayfarers series), James
S.A. Corey (the Expanse) — established the form; the
contemporary masterclass roster — Arkady Martine (A
Memory Called Empire, A Desolation Called Peace), Yoon
Ha Lee (Ninefox Gambit, the Machineries of Empire),
Kameron Hurley (the Worldbreaker saga, the Light Brigade),
Aliette de Bodard (the Xuya Universe), Tamsyn Muir (the
Locked Tomb sequence, with strong space-opera elements),
Tochi Onyebuchi (Goliath, War Girls), Suyi Davies Okungbowa
(the Nameless Republic), Rebecca Roanhorse (Black Sun-
adjacent space-leaning work), Megan E. O'Keefe, Drew
Williams, Adrian Tchaikovsky (Children of Time), Hannu
Rajaniemi (the Quantum Thief), Jamie Sawyer, Cixin Liu
(the Three-Body Problem trilogy) — has expanded the
genre's range to post-colonial, queer, post-imperial,
non-Western, and structurally experimental registers
that the canonical roster historically underweighted.
The most common failure modes in this register are:
**Scale-Without-Intimacy** (galactic conflict rendered
without the crew, the ship, the bond that makes the
scale matter; the fleet battle that has no one specific
the reader cares about); **Worldbuilding-as-Exposition**
(the galactic context delivered through narrator-as-
historian or character-as-tour-guide rather than woven
into lived experience); **Empire-Wallpaper** (the
imperial / federation / alliance frame presented as
backdrop rather than as material force on character
choice); **Alien-as-Costume** (alien characters who are
humans-with-different-features rather than genuinely
alien in perception, values, biology); **Tech-Without-
Cost** (FTL, energy weapons, shields, AI deployed as
narrative convenience without consistent cost or
limitation); **Star-Wars-Pastiche** (the manuscript that
echoes existing IP without earning its own
worldbuilding distinction); **Monoculture-Species** (the
alien species rendered as having a single culture, a
single language, a single set of values across an
entire civilisation); **Galactic-Scope Without
Geopolitical-Specificity** (the empire that is the
empire, with no specific named factions, no specific
named worlds, no specific named conflicts within it);
**Crew-as-Stock-Cast** (the crew filled with type-cast
roles — the captain, the pilot, the mechanic, the
medic — without specific named characterisation); and
**Combat-as-Choreography** (space combat rendered as
elegant ballet rather than as the physics-constrained,
information-poor, panic-inducing reality the genre's
best writers render). The techniques below — two
preserved (Scale/Intimacy Seesaw, Crew Scene) and
three added (Specific Polity Architecture, Alien-as-
Genuinely-Alien Discipline, Tech-Cost Calibration) —
are designed to keep the genre's defining commitments
live: galactic scale grounded in specific intimacy,
empires rendered with internal political texture, and
aliens that are genuinely other.

### The Scale/Intimacy Seesaw

Space opera's signature technique: alternate between GALACTIC SCALE and PERSONAL INTIMACY.

**In practice:**
- A chapter that opens with a fleet battle ends with two characters sharing a quiet drink in the damaged mess hall
- A chapter about interstellar politics zooms into one diplomat's trembling hand as they sign the treaty
- A vast alien landscape is experienced through one character's first breath of alien air

**Rule:** Every chapter that goes BIG must come back SMALL. Every chapter that goes small must reference something BIG.

### The Crew Scene

Space opera's secret weapon: the crew just BEING together.

**Types of crew scenes:**
| Scene | Purpose | Emotional Effect |
|-------|---------|-----------------|
| **Mess Hall** | Characters eating together, arguing, laughing | Found family, normalcy amid chaos |
| **Bridge Watch** | Quiet monitoring during transit | Trust, competence, shared purpose |
| **Repair Session** | Characters fixing the ship together | Teamwork, problem-solving, banter |
| **Shore Leave** | Crew exploring a new port together | Characters outside their roles, vulnerability |
| **Medical Bay** | Aftermath of injury, caretaking | Intimacy, fear, loyalty |

**Rule:** At least one crew scene per 3 chapters. These are NOT downtime. they're where the reader falls in love with the ensemble.

### Space Opera AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the vastness of space" | Show the specific view from the specific viewport |
| "an empire spanning galaxies" | Show the specific political structure through one interaction |
| "the captain's burden" | Show the specific decision and its crew-level consequence |
| "alien species beyond imagination" | Show the specific alien through one distinctive behaviour |
| "the fleet assembled" | Show the specific ships through one crew member's perspective |
| "a distress signal from the void" | Show the specific signal content and crew reaction |
| "the space battle raged" | Show the specific manoeuvre from one person's station |
| "hyperspace was a blur of light" | Show the specific physical sensation |
| "diplomatic relations between species were fragile" | Show the specific insult or misunderstanding |
| "the weapon could destroy worlds" | Show the specific destructive capability through demonstration |
| "uncharted territory" | Show the specific anomaly on the specific scan |
| "the bridge crew exchanged glances" | Show the specific reaction from ONE crew member |
| "the empire's grip tightened" | Show the specific imperial action affecting one named character or place |
| "ancient ruins on a forgotten world" | Show the specific ruins (named civilisation, named architectural detail, named period) |
| "a galaxy at war" | Show the specific war (named factions, named theatre, named cause) |
| "the AI calculated" | Show the specific calculation or decision rendered through AI's specific personality / interface |
| "they emerged from hyperspace" | Show the specific re-entry sensation, specific arrival, specific destination |
| "the alien spoke in a way that sounded like..." | Show the specific alien linguistic / non-linguistic communication mode |
| "the captain bore the weight of command" | Show the specific decision and its specific cost on the specific captain |

### The Specific Polity Architecture

Space opera's defining setting is the polity (empire,
federation, alliance, hegemony, republic, network,
collective). The Empire-Wallpaper failure mode collapses
when this polity is treated as backdrop rather than as
the manuscript's primary structural force. The Specific
Polity Architecture is the discipline that renders the
polity with internal political texture — specific named
factions, specific named worlds, specific named conflicts
within it.

```
PRINCIPLE
The manuscript's polity must be rendered through at least
four of the following six axes:
1. NAMED INTERNAL FACTIONS — the polity is not
   monolithic; specific named factions disagree with
   each other (the imperial bureaucracy vs the
   military, the founding worlds vs the rim, the
   reformist faction vs the conservatives, the
   pre-AI traditionalists vs the post-AI integrationists)
2. NAMED MEMBER WORLDS — specific named worlds with
   specific cultures, biospheres, economies, histories;
   not "the empire's worlds" but Trantor and Anacreon,
   not "the federation's planets" but Earth, Vulcan,
   Andoria — each rendered with internal complexity
3. NAMED HISTORICAL CONFLICTS — the polity's history
   includes specific wars, treaties, schisms,
   reformations, displacements; the present manuscript
   sits inside that history rather than at its zero
   point
4. NAMED ECONOMIC ARCHITECTURE — the polity moves
   resources, taxes, trade goods, credits, slaves,
   citizens, information; the specific economic
   logic of THIS polity differs from generic-empire
5. NAMED INSTITUTIONAL CULTURE — the bureaucracy, the
   military hierarchy, the priesthood, the academy,
   the corporate sector; how this polity's
   institutions actually operate
6. NAMED OUTSIDE OTHERS — what the polity defines
   itself against (rival polities, unaligned worlds,
   alien civilisations, internal exiles); polities
   are constituted partly by their others

CALIBRATION TEST
- Could the polity be replaced with another generic
  space-opera polity without the manuscript losing
  anything specific? If yes, the polity is wallpaper.
- Are at least four of the six axes rendered through
  specific named detail?
- Does the polity's specific texture shape character
  choices in the manuscript, or is it backdrop?
If any answer is no — rebuild for polity specificity.

ANTI-PATTERN
- "The empire" as singular monolithic entity
- "The federation" without internal political
  texture
- Worlds named but not differentiated
- Galactic history compressed to "the long war" or
  "the great peace"
- Economic architecture absent (how the polity
  actually moves resources)
```

### The Alien-as-Genuinely-Alien Discipline

The Alien-as-Costume failure mode produces alien
characters who are humans with different surface
features. The Monoculture-Species failure mode
compounds this by rendering alien species as
homogeneous across entire civilisations. The Alien-as-
Genuinely-Alien Discipline is the requirement that
alien species be rendered with biology, perception,
values, language, and internal cultural diversity that
makes them recognisable as other.

```
PRINCIPLE
For each significant alien species in the manuscript,
the rendering must satisfy at least four of the
following six criteria:
1. BIOLOGY-SHAPED — the species' biology shapes their
   experience (atmosphere requirements, gravity
   tolerance, lifespan, reproduction architecture,
   sensory modalities) and the manuscript renders
   these specifically
2. PERCEPTION-DIFFERENT — what the species perceives
   that humans don't, or perceives differently;
   echolocation, infrared vision, pheromonal signal,
   gravitational sense, time-perception variance
3. VALUE-STRUCTURE-DIFFERENT — what they consider
   important is genuinely different from human
   default (collective vs individual self, time-
   horizons, kinship architecture, ethical primary)
4. LANGUAGE-OR-COMMUNICATION-DIFFERENT — communication
   modes that humans cannot fully access (chemical
   signal, gestalt-mind, song, dance, formal-
   protocol-bound speech); the gap between human
   and alien communication renders specifically
5. INTERNAL DIVERSITY — the species is not
   monocultural; specific named factions, regions,
   classes, or generations disagree about what it
   means to be of this species
6. HISTORICAL POSITION — the species has specific
   relationship to galactic history; specific
   conflicts, specific alliances, specific
   internal periods that map to but differ from
   human history

CALIBRATION TEST
- Could the alien species be removed from the
  manuscript and replaced with humans-from-another-
  culture without losing anything? If yes, the
  alien is costume.
- Are at least four of the six axes rendered through
  specific named detail?
- Does the alien species exhibit internal diversity
  rather than monoculture?
- Does the manuscript render the gap between human
  and alien perception/values rather than skating
  over it?
If any answer is no — rebuild for alien-otherness.

ANTI-PATTERN
- The aliens who are humans with pointed ears /
  scaly skin / tentacles
- The species that has one culture, one language,
  one set of values across an entire civilisation
- The "warrior race" / "mercantile race" / "wise
  ancient race" stock species
- The alien language that maps neatly to human
  syntax with different vocabulary
- The alien ethics that are recognisable human
  ethics with cosmetic adjustment
```

### The Tech-Cost Calibration

Space opera's technology — FTL, energy weapons,
shields, AI, terraforming, longevity medicine, mind
upload — provides the genre's signature toys but
threatens the manuscript's tension if deployed without
cost. The Tech-Without-Cost failure mode produces
narrative-convenience technology that resolves
problems without requiring character work. The Tech-
Cost Calibration is the discipline that ensures every
significant technology in the manuscript carries
specific named costs.

```
PRINCIPLE
For every significant technology in the manuscript,
the manuscript must specify at least three of the
following four cost categories:
1. ENERGY / RESOURCE — what the technology requires
   to operate (specific named fuel, specific named
   computational load, specific named scarce
   material); resources can run out
2. TIME / DURATION — the technology takes specific
   time to operate (FTL takes hours / days /
   weeks; shields recharge over specific time;
   medical treatment takes specific time)
3. SIDE-EFFECT / DAMAGE — the technology produces
   specific named damage to the user, the system,
   or the surroundings (FTL produces fatigue or
   sickness; weapons heat the firing platform; AI
   degrades specific subsystems)
4. INFORMATION-POOR — the technology produces
   information gaps; FTL travel produces
   communication delays; sensors have specific
   range and resolution limits; even AI has
   specific blind spots

CALIBRATION TEST
- For every technology deployed in the chapter, can
  the reader name its specific cost?
- Are technologies that resolve problems doing so
  with specific cost, or are they functioning as
  narrative convenience?
- Do scarce resources actually deplete across the
  manuscript?
- Does information-poverty actually generate
  tension (limited sensors, comms delay, fog of
  war in space)?
If any answer is no — rebuild for tech-cost.

ANTI-PATTERN
- The shield that holds against any attack the
  plot requires
- The FTL that takes the time the plot requires
- The AI that produces the answer the plot requires
- The med-bay that heals the wound the plot requires
- Sensors that detect everything when the plot
  requires
- Communications that work when the plot requires
  and fail when the plot requires
```

## Genre-Specific Revision Rules

### Six-Pass Space Opera Audit (Run FIRST in editorial pipeline)

The Space Opera Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Scale Pass

Verify the reader feels the vastness of space at least
once per chapter, and that galactic scope is grounded
in personal experience. The Scale-Without-Intimacy
failure mode is caught here. for every scale moment
(fleet battle, planetary view, FTL transit, treaty
signing, war declaration), is the moment grounded
through specific character experience? Is the reader
seeing the scale through someone's specific eyes? Are
distances and travel times consistent across the
manuscript? The Scale/Intimacy Seesaw is the genre's
load-bearing rhythm; chapters that go big without
coming back small, or that go small without registering
the big, lose the genre's signature texture.

#### Pass 2: Crew Dynamic Pass

Verify all core crew members are active or meaningfully
absent in each chapter. The Crew-as-Stock-Cast failure
mode is caught here. is each crew member rendered as
specific named character with specific arc, voice, and
agenda — or are they filling type-cast roles (the
captain, the pilot, the mechanic, the medic) without
specific characterisation? Do crew interactions advance
relationships rather than serve as filler? Is banter
earned through specific shared history rather than
generic-snappy-comeback? Does crew disagreement drive
plot? Are at least one crew scene per three chapters
present (mess hall, bridge watch, repair session,
shore leave, medical bay)?

#### Pass 3: Species Authenticity Pass

Verify alien characters are genuinely alien in
perception, values, biology, language, and internal
diversity. The Alien-as-Costume and Monoculture-Species
failure modes are caught here. for each significant
alien species, are at least four of the six Alien-as-
Genuinely-Alien criteria (biology-shaped / perception-
different / value-structure-different / language-
different / internal-diversity / historical-position)
rendered through specific detail? Is the species
rendered with internal cultural diversity rather than
as monoculture? Are the gaps between human and alien
perception / values / communication rendered rather
than skated over?

#### Pass 4: Technology Consistency Pass

Verify ship capabilities, FTL rules, weapons, shields,
and AI behaviour are consistent chapter to chapter. The
Tech-Cost Calibration provides the spec — every
significant technology must specify at least three of
the four cost categories (energy / time / side-effect /
information-poor). Audit each chapter: damage persists
chapter to chapter? Resources deplete? Information-
poverty actually generates tension? The Tech-Without-
Cost failure mode is caught here. if the manuscript's
technology resolves problems without specific cost,
rebuild.

#### Pass 5: Action Set Piece Pass

Verify space battles, ground combat, and other action
set pieces are 3D, crew-coordinated, and consequential.
The Combat-as-Choreography failure mode is the genre's
common lapse. is the combat rendered through one
character's specific moment-by-moment limited
information rather than as omniscient elegant ballet?
Are physical consequences felt (G-forces, damage,
casualties, decompression, life-support stress)? Do
tactics reflect established technology rather than
defaulting to generic-action? Is aftermath included
(damage, loss, emotional processing) rather than the
manuscript cutting from victory to next chapter?

#### Pass 6: Specific-Polity + Alien-Otherness + Tech-Cost Integration

This pass is the space opera integration check — it
ties the new techniques together and verifies the
manuscript honours the genre's defining commitments at
the manuscript level.

For SPECIFIC-POLITY: confirm the polity is rendered
with internal political texture across at least four of
the six axes (named factions / named worlds / named
historical conflicts / named economic architecture /
named institutional culture / named outside others).
The Empire-Wallpaper failure mode is caught here. if
the polity is monolithic and undifferentiated, rebuild
for political specificity.

For ALIEN-OTHERNESS: confirm Pass 3's spec at the
manuscript level. across the manuscript, do alien
species exhibit internal diversity, biological
specificity, value-structure difference, and historical
positioning?

For TECH-COST: confirm Pass 4's spec at the manuscript
level. is the manuscript's technology consistently
costed across the manuscript? Do resources actually
deplete? Does information-poverty actually generate
tension? The Star-Wars-Pastiche failure mode is also
caught here. if the manuscript's technology echoes
existing IP without earning its own worldbuilding
distinction, rebuild for original tech architecture.

## Names & Patterns to Avoid

### Space Opera Character Names. NEVER USE
- Star Wars/Trek echoes: anything that sounds like it belongs in existing IP
- Generic "spacer" names: Zyx, Kron, Vex, Jett, Axel, Blaze
- All human crew from one nationality (the future is diverse)
- Alien names that are unpronounceable strings of consonants

### Space Opera Place Names. NEVER USE
- "[Greek Myth] + [Designation]": Prometheus Station, Artemis Colony, Olympus Port
- "[English Word] + Prime/Major/Alpha": Terra Prime, Centauri Alpha, Haven Major
- Single-word mystical names: Elysium, Arcadia, Serenity, Destiny

### Space Opera Tropes. AVOID or SUBVERT
- The Han Solo knockoff (charming rogue, heart of gold)
- The bridge as the only interesting room on the ship
- Aliens who all speak perfect English without explanation
- The planet that's one biome (desert planet, ice planet, jungle planet)
- The evil empire vs plucky rebels (this is Star Wars; write your own political landscape)
- Faster-than-light without consequences or complications

### Use Instead
- Ship names with history: named after events, people, or concepts meaningful to the crew's culture
- Crew names from the logical demographic of the setting's history (Earth diaspora = many cultures)
- Alien names that follow their own phonological rules (not random. consistent within a species)
- Places named by settlers for practical reasons: "Drywell", "The Reach", "Port Kalina" (after a founder)

## Comp Titles

Space-opera's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Dune* — Frank Herbert (1965): epic-SF empire and ecology benchmark.
- *Consider Phlebas* — Iain M. Banks (1987): the Culture novels; literary-space-opera.
- *Hyperion* — Dan Simmons (1989): structurally ambitious space-opera; multi-POV frame.
- *The Vorkosigan saga* — Lois McMaster Bujold (1986-): character-driven space-opera benchmark.

### Contemporary (current best-in-class)

- *Leviathan Wakes* — James S.A. Corey (2011): the Expanse series; modern space-opera benchmark.
- *Ancillary Justice* — Ann Leckie (2013): pronoun-experimental military-space-opera.
- *The Long Way to a Small, Angry Planet* — Becky Chambers (2014): cozy literary space-opera.
- *Ninefox Gambit* — Yoon Ha Lee (2016): mathematical-warfare space-opera.
- *A Memory Called Empire* — Arkady Martine (2019): linguistic-imperial space-opera.
- *Children of Time* — Adrian Tchaikovsky (2015): post-human space-opera with uplifted-spider perspective.
- *Goliath* — Tochi Onyebuchi (2022): post-Earth Black-future space-opera.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. The DOMINANT style: dramatic space vistas with ships, planets, or stations; movie-poster composition; sense of scale and adventure; this is what readers expect
- **Illustrated**. Rich, painted scenes of ships, alien worlds, or space battles; especially good for classic and military space opera; detailed and immersive
- **Minimalist**. A single ship silhouette against a starfield, or a planet in vast negative space; powerful for literary space opera; clean and striking
- **Graphic**. Bold, design-forward with strong colour blocking and geometric elements; modern and eye-catching; good for new space opera

### Genre Cover Aesthetics
- **Styles:** Ships against vast starscapes, planetary vistas seen from orbit or approach, dramatic lighting from stars and nebulae, sense of scale (tiny ship against enormous backdrop), dynamic composition suggesting movement and adventure, atmospheric depth with multiple planes (foreground ship, midground planet, background stars)
- **Colours:** Deep space blue-black (the foundation), bright engine glow (blue, white, orange), nebula colours (purple, pink, gold clouds), planetary tones (rust red for Mars-types, blue-white for ice worlds, deep green for garden worlds), the contrast between the cold of space and the warmth of human light (viewports, engine trails, station lights)
- **Elements:** Spaceships (the MOST iconic space opera cover element), planets and moons, space stations and orbital structures, starfields and nebulae, fleet formations, alien worlds and structures, the curve of a planet's horizon, engine trails and light effects
- **Typography:** Bold, confident fonts. often sans-serif with a technological feel; title must convey SCALE (large, impactful); metallic or gradient effects common; series branding prominent; author name sized according to market recognition; the typography should feel like a movie title

### Market Positioning
Space opera covers must convey ADVENTURE, SCALE, and WONDER. The cover should make the reader feel they're about to embark on something vast and thrilling. Position against Chambers, Scalzi, Leckie, Banks, Reynolds, Corey. Ships and space dominate the genre's visual language. a well-rendered ship against a dramatic backdrop is the safest bet for the genre. At thumbnail size, the contrast between dark space and bright elements (ships, stars, engine glow) creates maximum impact.

### Cover Design DON'Ts
- No empty starfields without focal elements. space alone is not a cover
- No cluttered multi-ship battle scenes that become illegible at thumbnail
- No retro pulp aesthetics (unless deliberately retro)
- No fantasy elements (swords, magic, dragons) unless the story blends genres
- No photorealistic human faces floating in space (the "floating head" curse)
- No overly technical/schematic designs that read as non-fiction
- No dark, oppressive imagery. space opera is adventurous, not bleak
