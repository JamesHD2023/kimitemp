---
name: marketing-expert
description: "AI-powered marketing copy generation — blurbs, Amazon descriptions, social media packs, query letters, audience analysis, keywords, and more"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Marketing Expert — Engine Skill

## Purpose

The Marketing Expert generates professional, market-competitive marketing
materials for books. It produces 10 distinct material types spanning retail copy,
social media, PR, traditional publishing, and discoverability optimisation.

Every output is:
- **Market-researched** — informed by live web search and genre benchmarks
- **Genre-adapted** — uses the visual language, hooks, and conventions readers expect
- **Tone-configurable** — professional, conversational, urgent, mysterious, emotional, or witty
- **Copy-ready** — formatted for direct use on the target platform

## When to Use

Activate when:
- The user asks for marketing copy, blurbs, descriptions, or promotional materials
- The manuscript is complete or near-complete and moving toward publishing
- The user needs query letters, elevator pitches, or audience analysis
- The user is working in the Publishing Studio / Marketing Expert interface

---

## Material Types

### Retail Copy

| ID | Name | Description | Output Fields |
|----|------|-------------|---------------|
| `amazon-description` | Amazon Description | Semantic-search-optimised description with a mobile-fold three-punch hook | headline, mobileHook, description (HTML), keywords[], characterCount, marketAnalysis |
| `back-cover-blurb` | Back Cover Blurb | 150–200 word back cover text with tagline | blurb, tagline, wordCount |
| `keywords-categories` | Keywords & Categories | Amazon SEO keywords, BISAC categories, browse categories, long-tail keywords | amazonKeywords[7], bisacCategories[], amazonCategories[], seoKeywords[], longTailKeywords[], negativeKeywords[], searchTips |

### Pitching & Traditional Publishing

| ID | Name | Description | Output Fields |
|----|------|-------------|---------------|
| `elevator-pitch` | Elevator Pitch | Multi-format pitch: logline (25 words), 30-second (75 words), paragraph (150 words), X-meets-Y | logline, thirtySecondPitch, paragraphPitch, comparisonPitch |
| `query-letter` | Query Letter | Industry-standard query for literary agents | salutation, hook, pitch, compTitles, bio, closing, wordCount |
| `comparison-titles` | Comparison Titles | Strategic "X meets Y" positioning with market context | marketPositioning, similarBooks[], xMeetsY[], similarAuthors[], comparableSeries[], crossMedia[] |

### Digital Marketing

| ID | Name | Description | Output Fields |
|----|------|-------------|---------------|
| `social-media-pack` | Social Media Pack | Platform-specific posts for Twitter/X (3 variations), Instagram, Facebook, TikTok (script + overlays), LinkedIn | twitter[], instagram, facebook, tiktok{hook, script, textOverlays[]}, linkedin, hashtags[] |
| `email-newsletter` | Email Newsletter | Subscriber announcement with multiple subject lines | subjectLine, alternativeSubjects[], previewText, body, callToAction, psLine |
| `press-release` | Press Release | Media-ready announcement with pull quotes | headline, subheadline, body, pullQuotes[], bookDetails |

### Strategy & Analysis

| ID | Name | Description | Output Fields |
|----|------|-------------|---------------|
| `target-audience` | Target Audience Analysis | Detailed reader personas, demographics, psychographics, where to find them | primaryPersona, secondaryAudiences[], demographics, psychographics, whereToFind[], marketingAngles[] |

---

## Tone Options

| ID | Name | Best For |
|----|------|----------|
| `professional` | Professional | Query letters, press releases, Amazon descriptions |
| `conversational` | Conversational | Email newsletters, social media, blog posts |
| `urgent` | Urgent/Exciting | Thriller/action marketing, launch announcements |
| `mysterious` | Mysterious | Mystery/thriller/horror blurbs and descriptions |
| `emotional` | Emotional | Romance, literary fiction, memoir marketing |
| `witty` | Witty | Comedy, cozy genres, social media |

---

## Generation Pipeline

### Phase 1: Market Research

Load `market-scout.md` and run Market Scout with context: **"marketing"**.

The marketing context adapter emphasises reader expectations (must-haves for copy),
comp titles (for positioning), price point guidance, and keywords/phrases that
resonate with readers. It also surfaces emotional triggers and value propositions
that convert browsers to buyers.

See `market-scout.md` for the full protocol, report format, and fallback behaviour.

### Phase 2: Context Assembly

Gather all inputs for the prompt:

```
Required:
- Book title, genre, project type
- Story Bible (truncated to 3,000 chars)
- Key themes
- Main characters (truncated to 2,000 chars)
- Word count and chapter count
- Selected tone
- Selected material type

Optional:
- Author name (from author profile)
- Author bio (short bio preferred)
- Series name and order
- Custom notes from user
- Live market research data
- Static market benchmarks
```

### Phase 3: Prompt Construction

Every prompt includes a **Market Intelligence** preamble that forces market-aware copy:

1. **Bestseller Positioning** — what marketing angles and copy styles drive sales?
2. **Competitor Analysis** — what makes top-selling descriptions/blurbs effective?
3. **Reader Psychology** — what emotional triggers and value propositions work?
4. **Avoidance List** — what approaches are overused or ineffective?

The preamble is followed by book information, story overview, themes, characters,
selected tone, and any custom notes.

### Phase 4: Generation & Parsing

The AI returns structured JSON matching the material type's output schema.
Parse the response, store as a `marketingMaterial` entry on the project.

---

## Material-Specific Generation Guidance

### Amazon Description

The mobile see-more fold is the primary constraint. On the Amazon app — where most browsing happens — only the first ~150 characters are visible before "see more". Write in two movements:

**Movement 1 — the 150-character hook (above the fold).** The first ~150 characters MUST work standalone. The proven structure is the **three-punch opener**: three short fragments delivering, in order, conflict / stakes / emotion. Example: "A strange town. A missing girl. A dog who knows." Fragments, not sentences. Concrete nouns. No "In a world where...", no throat-clearing.

**Movement 2 — the full description (below the fold).** After the hook: protagonist + world, conflict expanded, rising stakes, emotional hooks, call to action. Under 4,000 characters total. HTML: `<b>`, `<i>`, `<br>`.

**Semantic discoverability — front-load concepts, do not keyword-stuff.** Amazon discovery has shifted from keyword matching (A9) to semantic search via Cosmo (semantic relevance) and Rufus (shopping assistant). Readers search in natural language — "a mystery with a dog in it". Two consequences: (1) the concrete elements a reader would search for must be present and EARLY — Cosmo weighs early content, the mobile fold shows only early content, both point to front-loading; (2) natural-language prose beats keyword strings — "a retired detective returns to the farm where her sister vanished" outperforms a comma-separated list.

Include a `marketAnalysis` block with competitor insights, semantic positioning strategy, and mobile-fold rationale.

### Back Cover Blurb

Structure:
1. Immediate hook
2. Introduce protagonist and world
3. Present central conflict and stakes
4. Build tension and intrigue
5. End with a compelling question or hook

Target: 150–200 words. Also generate a one-line tagline.

### Elevator Pitch

Four formats in one generation:
- **Logline**: 25 words maximum. One sentence. Hooks instantly.
- **30-second pitch**: 75 words. Conversational. For in-person pitching.
- **Paragraph pitch**: 150 words. For written submissions and about pages.
- **Comparison pitch**: "X meets Y" format. Use titles readers recognise.

### Social Media Pack

Platform-specific formatting:
- **Twitter/X**: 3 variations, 280 chars each, with hashtags
- **Instagram**: Engaging caption with emoji, call to action, 20–30 hashtags
- **Facebook**: Longer conversational format
- **TikTok**: 15–30 second video concept with hook (first 3 seconds), full script, text overlays
- **LinkedIn**: Professional angle for author branding

### Press Release

Follow standard press release format:
1. Attention-grabbing headline
2. Subheadline
3. Dateline and lead paragraph (who, what, when, where, why)
4. Book details and synopsis
5. Author bio section
6. Availability information
7. Contact information placeholder
8. Boilerplate/about section
9. 2 pull quotes suitable for media use

### Email Newsletter

Structure for maximum open rate and engagement:
1. Compelling subject line + 2 alternatives for A/B testing
2. Preview text (the snippet shown before opening)
3. Personal, warm greeting
4. The exciting announcement
5. Exclusive insider details (makes subscribers feel special)
6. Clear call to action
7. P.S. line with a bonus hook (P.S. lines have high read rates)

### Query Letter

Follow industry standards precisely:
1. Hook opening line (the "why this book" sentence)
2. Story pitch (250 words max — like back cover but for agents)
3. Comparison titles (positioned naturally)
4. Author bio/credentials with `[PLACEHOLDER]` markers for personalisation
5. Professional closing

### Comparison Titles

Focus on COMMERCIAL viability:
- 5 similar books (prioritise recent bestsellers from past 2–3 years)
- 3 "X meets Y" combinations (use titles readers recognise)
- Similar authors (currently popular in this space)
- Comparable series (especially successful ongoing series)
- Cross-media comparisons (films, TV, streaming with similar appeal)

Each comp includes a `salesContext` field explaining why it's strategically valuable.

### Target Audience Analysis

Build a complete reader profile:
- **Primary persona**: Detailed profile with name, age, interests, reading habits, buying behaviour
- **Secondary audiences**: 2–3 additional segments
- **Demographics**: Age range, gender split, education, location
- **Psychographics**: Values, motivations, pain points
- **Where to find them**: Specific platforms, communities, subreddits, BookTok tags
- **Marketing angles**: What messaging will resonate with each segment

### Keywords & Categories

Amazon SEO optimisation:
- **7 Amazon keyword phrases** (max 50 chars each):
  - 2 broad genre keywords
  - 2 trope/theme keywords
  - 2 specific niche keywords
  - 1 comp-based keyword
- **3 BISAC categories** (code + name)
- **5 Amazon browse categories**
- **SEO keywords** for author website
- **Long-tail keywords** for advertising
- **Negative keywords** to exclude from ad targeting
- **Search optimisation tips**

---

## Publishing Resource Links

The Marketing Expert surfaces relevant platform links based on material type:

| Category | Platforms |
|----------|-----------|
| Retail | Amazon KDP, Draft2Digital, IngramSpark |
| Social | Canva, Later, Buffer |
| Email | Mailchimp, ConvertKit, BookFunnel |
| Research | Publisher Rocket, Goodreads Author Dashboard |
| PR | HARO, Reedsy |
| Traditional | QueryTracker, Publishers Marketplace |

Resource categories are mapped to material types:
- `amazon-description` → retail, research
- `social-media-pack` → social, research
- `query-letter` → traditional, research
- `email-newsletter` → email, research
- `keywords-categories` → retail, research

---

## Quality Criteria

### Copy Quality
- Hooks in the first sentence — every material type
- No spoilers in reader-facing copy
- Genre-appropriate language and tone
- Strategic keyword integration (not keyword stuffing)
- Platform-specific formatting and length constraints met
- Call to action present where appropriate

### Market Competitiveness
- Copy researched against current bestseller marketing
- Avoids clichéd or overused phrasing for the genre
- Comparison titles are recent, recognisable, and strategically chosen
- Keywords reflect current search trends, not generic terms

### Professional Standards
- Query letters follow industry format precisely
- Press releases follow AP style conventions
- Amazon descriptions stay within character limits
- BISAC categories use correct codes

---

## Output Storage

**File output:** `Ideorix-Projects/[Title]/marketing/marketing-brief.docx`

Materials are also stored on the project object:

```json
{
  "id": "timestamp",
  "type": "amazon-description",
  "typeName": "Amazon Description",
  "tone": "professional",
  "data": { /* material-type-specific JSON */ },
  "customNotes": "user's additional instructions",
  "genre": "domestic-thriller",
  "bookTitle": "The Last House",
  "createdAt": "ISO date",
  "status": "draft"
}
```

Multiple materials of the same type can coexist (e.g., different tones).
Users can copy individual fields, regenerate, or delete materials.

---

## Relationship to Other Engine Files

| Engine File | Relationship |
|-------------|-------------|
| `cover-designer.md` | Cover concepts inform marketing visual language |
| `publishing-formats.md` | Amazon description and keywords feed directly into KDP metadata |
| `core-pipeline.md` | Marketing generation happens AFTER manuscript is complete |
| `world-canon.md` | Story Bible provides the source material for all copy |
| `outline-builder.md` | Market Pulse Research data can inform marketing positioning |

The Marketing Expert is a **post-manuscript tool** — it consumes the Story Bible
and manuscript content to create marketing materials that accurately represent
the finished work.
