---
name: religious-fiction-genre
description: Genre-specific instructions for religious fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Religious Fiction. Genre Plugin

## Metadata
- id: religious-fiction
- name: Religious Fiction
- icon: ✝️
- category: Literary & Contemporary
- tier: Core
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Story Circle", "Three-Act Structure", "Memoir 3-Act Emotional Arc"]

## Subgenre Options
Present during setup:

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| **Inspirational Christian** | Faith-affirming stories within an evangelical or mainline Protestant tradition; hope and redemption central | Clean content guidelines, conversion arcs common, church community prominent |
| **Catholic Literary** | Fiction rooted in the Catholic intellectual tradition. sacramental imagination, guilt, grace, the weight of doctrine | Liturgical rhythm, sacramental imagery, theological density higher, Flannery O'Connor territory |
| **Interfaith / Comparative** | Characters from different faith traditions colliding, conversing, or coexisting; the drama of religious difference | Multiple theologies in dialogue, cultural friction, no single tradition privileged |
| **Spiritual Quest** | Seekers, doubters, and wanderers pursuing meaning outside. or on the margins of. organised religion | Less denominational specificity, mystical elements possible, questions valued over answers |
| **Historical Religious** | Faith set against a specific historical period. Reformation, Crusades, early Church, missionary era | Period-accurate theology and practice, historical research demands, cultural distance navigated |
| **Amish / Plain Community** | Stories set within Amish, Mennonite, or similar plain communities; the tension between tradition and modernity | Specific community rules (Ordnung), Rumspringa narratives, separation from "English" world |

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Contemplative with purpose. balance spiritual reflection with narrative momentum
- Must open with: Faith challenge, moral dilemma, spiritual moment, or community context
- Must close with: Spiritual insight, prayer, moral choice, or deepened faith question

BEATS PER CHAPTER
1. Faith in Action: Character living/questioning beliefs, prayer, worship, scripture reading
2. Moral/Ethical Dilemma: Decision requiring faith principles, testing beliefs
3. Community Context: Religious community, fellowship, accountability, belonging
4. Spiritual Growth: Doubt wrestled with, faith deepened, understanding expanded
5. Providence or Purpose: Divine guidance, answered prayer, or questioning God's plan

GENRE-SPECIFIC REQUIREMENTS
- Faith central to story. not just backdrop but drives character choices and plot
- Religious practices authentic. worship, prayer, scripture reading portrayed accurately
- Theology present but accessible. spiritual truth through story, not sermons
- Moral framework clear. good/evil often defined, though characters may struggle
- Community matters. church, temple, fellowship group significant
- Scripture or sacred texts integrated. quoted naturally, applied to situations
- Prayer scenes genuine. not perfunctory, showing real communication with divine
- Conversion or spiritual growth. characters deepen faith, come to faith, or struggle honestly
- Redemption themes. grace, forgiveness, second chances central
- Suffering addressed. theodicy explored, "why do bad things happen" wrestled with
- Hope essential. even in darkness, faith provides hope or path forward

STORY TURNS (every 4-6 pages)
Every 4-6 pages must contain a turn. a moment that shifts the spiritual or narrative direction:
- Scripture passage that cuts both ways. comforts AND convicts
- Prayer that receives an unexpected answer. or a disturbing silence
- Community member who embodies the opposite of what they preach
- Moral choice where faith principles conflict with compassion or survival
- Doubt surfacing at the worst possible moment. during a crisis that demands certainty
- Act of grace from an unexpected source. the non-believer who shows more love than the congregation
Turns in religious fiction work best when they complicate faith rather than simplify it. The reader should feel the protagonist's struggle, not just witness it.

NARRATIVE LAYERS (A/B/C stories)
- A-story: Protagonist's faith journey. doubt, crisis, growth, transformation
- B-story: Key human relationship testing faith principles. marriage, friendship, parent/child
- C-story: Community dimension. congregation politics, moral controversy, collective faith tested
These layers should collide: the personal crisis (A) is sharpened by the relationship test (B) and reflected in the community's response (C). The best religious fiction shows faith as lived experience, not isolated meditation.

FRACTAL STRUCTURE
The faith journey repeats at every scale:
- Scene level: Certainty → challenge → wrestling → new understanding
- Chapter level: Comfort → crisis → prayer/seeking → provisional peace
- Act level: Established faith → shattering doubt → dark night of the soul → transformed belief
Even small scenes should mirror the macro arc. A character struggling to forgive a small slight in chapter 3 should preview the devastating forgiveness demanded in the climax.

THEOLOGICAL ARCHITECTURE
- Every chapter should engage at least one genuine theological question through story
- Theology is dramatised, not explained: the doctrine of grace is shown when a character extends undeserved mercy, not when a pastor defines it
- Allow competing interpretations: two faithful characters may read the same scripture differently. this is realism, not relativism
- The sacred and the mundane coexist: a character praying over a kitchen sink is more powerful than a character praying in a cathedral, because it reveals faith woven into ordinary life
- Build towards a spiritual climax that earns its weight. the reader should feel the cost of belief

FORBIDDEN
- Preaching. spiritual truth through story and character, not author lectures
- Straw man skeptics. atheist/agnostic characters as cartoons to defeat
- Easy answers. real faith struggles shown, not Band-Aid solutions
- All non-believers villains. complexity in both believers and non-believers
- Prosperity gospel. faith as transaction for earthly rewards
- Ignoring doubt. authentic faith includes questioning and wrestling
- Cultural Christianity. treating faith as tribal identity vs. living belief
- Syncretism without awareness. mixing incompatible theologies carelessly
- Demonising other faiths. respect while maintaining own tradition
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (faith-formed world), Affection (community & calling), Revelation (insight / grace).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: 1st person (intimate faith journey) or 3rd limited (access to spiritual interiority)
- Tense: Past (reflective) or present (immediacy of spiritual crisis)
- Voice: Reverent but accessible, honest about doubt, hopeful without being naive
- Reading level: Accessible to faith community. assumes some theological literacy

PROSE IMPERATIVES
- Scripture integration natural. quotes woven into narrative, applied to situations
- Prayer authentic. genuine conversation with God, not performance
- Spiritual language balanced. theological terms used but explained through context
- Show faith through action. character's beliefs visible in choices, not just stated
- Doubt honestly portrayed. wrestling with God shown respectfully
- Community dialogue realistic. how believers actually talk to each other
- Moral struggles genuine. temptation and sin portrayed seriously but not gratuitously
- Divine presence subtle. providence through circumstances, not typically overt miracles
- Conversion or growth gradual. faith journeys take time, not instant
- Hope persistent. even in suffering, light visible

PROSE RHYTHM MAPPING
- Ch 1 hook: Faith question + human stakes. the spiritual and the personal entwined
- Prose rhythm: Measured, sometimes rhythmic (echoing liturgical cadence when appropriate)
  - The prose should breathe like a prayer: sustained attention punctuated by silence
- Sentence length: Medium (15-22 words)
  - Longer sentences for contemplative moments and theological wrestling
  - Shorter sentences for spiritual clarity or crisis
- Sensory detail: Sacramental. light through stained glass, incense, the weight of ritual objects
  - The physical world as vessel for the sacred
  - Domestic detail as incarnational: the kitchen prayer, the bedside psalm
- Interiority: Deep, wrestling, honest
  - The internal conversation with God rendered as genuine thought
  - Doubt and faith coexisting in the same paragraph
- Tension: ≥4 for Ch 1
- Paragraph rhythm: Measured paragraphs (3-6 sentences)
  - Silence given space. white space on the page mirrors spiritual waiting
  - Prayer passages formatted distinctly (italics or separate paragraphs)

GENRE-SPECIFIC STYLE
- Prayer formatted distinctly. italics, separate paragraphs, or clear attribution
- Scripture quoted accurately. use actual translation (NIV, ESV, KJV, etc.) consistently
- Worship scenes specific. hymns named, liturgy described, denominational practices accurate
- Theological discussions accessible. complex ideas through conversation and experience
- Sermon snippets realistic. pastor's voice distinct, message clear but not full sermon
- Faith community language. how congregation actually speaks to each other
- Inner spiritual voice. character's relationship with God shown through thought
- Redemption arc language. grace, forgiveness, transformation terminology accurate

FORBIDDEN WORDS/PHRASES
- "Christianese" overload. excessive insider jargon alienating even to believers
- Trite phrases. "Let go and let God," "God never gives you more than you can handle" (often untrue)
- Manipulative language. emotional manipulation vs. genuine spiritual appeal
- Preachy tone. "dear reader, you should..." direct address breaking story
- Perfect Christians. characters without genuine struggle or sin
- Demonising language. harsh condemnation without compassion
- Prosperity gospel phrases. "name it claim it," faith as transaction
- "God told me". overuse cheapens divine communication
- Cartoon villains. "evil atheist" or "corrupt clergy" without depth

SCRIPTURE INTEGRATION
- Quote accurately. verify translation and context
- Apply thoughtfully. characters wrestle with meaning, don't just proof-text
- Context matters. misquoting or misapplying scripture avoided
- Multiple perspectives. different characters may interpret differently
- Memorisation natural. long-time believers know verses, new believers learn
- Devotional reading. quiet time scenes with Bible study portrayed realistically
- Preaching context. pastor explaining text in sermon with interpretation

PRAYER CRAFT
Private prayer:
- Intimate conversation. honest, vulnerable, sometimes angry
- Not performance. raw communication with God
- Various forms. praise, petition, confession, thanksgiving, lament
- Silence included. listening, waiting, meditation

Corporate prayer:
- Denominational style. liturgical, spontaneous, contemplative as appropriate
- Community needs. praying for others, corporate confession
- Led prayer. pastor or leader's voice distinct

Answered/unanswered:
- Ambiguity sometimes. providence subtle, not always clear
- "No" or "wait" as answers. not always immediate yes
- Faith despite silence. believing when prayers seem unanswered

THEOLOGICAL DEPTH
- Show through story. parable-like, truth through narrative
- Character discussion. theological debate in natural conversation
- Tested by experience. beliefs challenged by life circumstances
- Growth through struggle. understanding deepens through wrestling
- Nuance present. theological complexity honoured, not oversimplified
- Denominational differences. acknowledged respectfully if relevant

PROSE EXAMPLES

**Good Example (prayer as genuine conversation):**
"Margaret knelt by the hospital bed, too exhausted for eloquence. 'I don't know what to pray anymore,' she admitted to the ceiling tiles. 'You know what I want. You know I'm angry You haven't given it. So I'm just going to sit here. If You have something to say, I'm listening.'
The machines beeped their steady rhythm. No voice from heaven. But somewhere in the waiting, her grip on the guardrail loosened."

Why it works: Shows honest faith. anger, confusion, perseverance. without resolving easily. Prayer is authentic conversation, not performance. Growth is subtle (the loosened grip), not a dramatic revelation.

**Avoid This:**
"'Lord, I know You never give me more than I can handle, and I trust Your perfect plan!' Margaret smiled peacefully despite her dying husband, filled with unexplainable joy."

Problems: Trite phrases, unrealistic emotional response, faith as magic solution, no wrestling or authentic humanity.

**Good Example (scripture woven naturally):**
"Pastor James leaned forward. 'David writes, "I would have despaired unless I had believed I would see the goodness of the Lord in the land of the living." That's Psalm 27:13. Notice he says "would have." Past tense. He wrote that after the despair, looking back. Sometimes you don't see the goodness until the tunnel ends.'
'What if the tunnel doesn't end?' Tom asked.
'Then you write your own psalm. David did too. Ever read 22?'"

Why it works: Scripture quoted accurately with citation, applied through conversation, leaves room for doubt, pastor voice distinct, theological depth through dialogue.

**Good Example (faith in action):**
"She almost walked past. the smell alone could stop traffic, and her new shoes would be ruined. But something made her turn back. The man huddled in the doorway wasn't asking for anything; that's what got her. He'd stopped expecting.
'Cold night,' she said, crouching down to his level.
He flinched, then met her eyes. 'You don't have to. '
'I know.' She handed him the sandwich she'd bought for her lunch. 'But I remember being hungry.'"

Why it works: Shows faith through action without preaching, character's internal conflict present, respects the recipient's dignity, doesn't resolve into triumphant conversion. just a moment of grace.
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Faith authenticity. religious practices, beliefs, scripture accurate to stated tradition
2. Spiritual honesty. doubt, struggle, sin portrayed realistically, not easy answers
3. Avoiding preachiness. truth through story and character, not author sermons
4. Theological coherence. beliefs consistent with stated tradition, no careless syncretism
5. Character complexity. believers flawed, non-believers not villains, moral nuance throughout

SCORING RUBRIC (0-100 per dimension)

SPIRITUAL AUTHENTICITY (35% of total):
- Religious practices accurate to stated denomination/tradition? (0-100)
- Scripture quoted correctly, applied in context? (0-100)
- Prayer scenes genuine and varied (not formulaic)? (0-100)
- Theology sound and consistent with stated tradition? (0-100)

NARRATIVE CRAFT (35% of total):
- Faith drives plot through character choices, not authorial manipulation? (0-100)
- Doubt and struggle portrayed with honesty and complexity? (0-100)
- Story earns its emotional moments (no sentimentality shortcuts)? (0-100)
- Community dynamics realistic (both supportive and failing)? (0-100)

CHARACTER & THEME (30% of total):
- Believers are flawed, non-believers are complex? (0-100)
- Spiritual growth is gradual and earned? (0-100)
- Redemption themes emerge from story, not imposed? (0-100)
- Hope present without being naive or facile? (0-100)

GENRE-SPECIFIC CHECKS

Scripture accuracy. verses quoted correctly from actual translation, applied in context
Denominational authenticity. practices match stated tradition (Catholic, Protestant, etc.)
Prayer genuine. conversation with God, not performance for reader
Worship realistic. church services, liturgy, music appropriate to setting and tradition
Theology sound. core doctrines accurate to stated religious teaching
Growth gradual. spiritual transformation over time, not instant conversion or sanctification
Doubt respected. wrestling with God portrayed authentically and without easy dismissal
Community real. church or temple dynamics genuine, showing both support and failure
Moral complexity. good people struggle, sin has consequences, grace present
Hope maintained. even in suffering, faith provides endurance or honest questioning

AUTOMATIC FAILS

Preaching to reader. author breaking story to deliver sermon or moral lecture
Straw man skeptics. atheists or agnostics as cartoon villains to defeat
Prosperity gospel. faith as transaction for health, wealth, or earthly rewards
Scripture misquoted. verses wrong or cherry-picked out of context to serve plot
Easy answers. complex suffering resolved with trite phrase or platitude
Perfect Christians. characters without genuine sin struggle or doubt
Denominational confusion. Catholic practices in Protestant church without reason
Syncretism. mixing incompatible theologies carelessly without narrative awareness
Demonising other faiths. disrespectful portrayal without attempting understanding
Magic Christianity. faith as superstition or good luck charm rather than living belief

ACCEPTABLE IMPERFECTIONS

Simplified theological explanations if core truth preserved
Minor worship practice variations within denominational flexibility
Miracle or providence ambiguity. some readers see natural, others divine
Continued questions at end. not all doubts resolved if spiritually honest

RED FLAGS TO INVESTIGATE

Author's voice intruding over character's voice during spiritual moments
Scripture used as proof-text rather than wrestled with in context
Faith crisis resolved too quickly. doubt that took chapters to build dismissed in a page
Prayer scenes formulaic. same pattern repeated without variation or emotional depth
Non-believing characters existing only to be converted or defeated
Community presented as uniformly supportive. real congregations have politics and failures
Spiritual growth without setbacks. sanctification is not linear progress
Theological discussion that reads as textbook rather than lived experience
Trite phrases replacing genuine spiritual insight ("everything happens for a reason")
Sin struggles mentioned then dropped. ongoing temptation vanishing without resolution
Character's faith unchanged by major suffering or loss. crisis should deepen or test belief
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Faith journey consistency: Character's spiritual state progression logical. growth or struggle tracks
2. Denominational accuracy: If specific tradition, practices and beliefs stay consistent to that tradition
3. Scripture usage: Verses quoted accurately from same translation throughout
4. Community relationships: Church/temple/mosque fellowship connections maintained
5. Theological coherence: Character's beliefs don't contradict arbitrarily. evolution shown

GENRE-SPECIFIC TRACKING
- Scripture verses: Which passages quoted, from what translation (NIV, ESV, KJV, etc.)
- Faith state: Character's belief, doubt, growth, crisis at each stage
- Prayer life: How/when character prays, answered/unanswered prayers
- Church community: Who belongs, roles, relationships, support network
- Denominational details: Worship style, theology, practices specific to tradition
- Conversion or growth moments: Key spiritual turning points
- Moral struggles: Ongoing temptations, sins struggled with, victories
- Mentors/disciples: Who's teaching/learning faith from whom

ACCEPTABLE INCONSISTENCIES
- Minor worship practice variations if within denominational flexibility
- Different prayer styles in different circumstances (urgent vs. contemplative)
- Evolving understanding of theology if growth shown

CRITICAL CONSISTENCY
- Scripture translation same throughout. don't switch KJV to NIV arbitrarily
- Denominational practices. Catholic characters go to Mass, not "church service"
- Theological beliefs. character's core doctrine doesn't shift without reason
- Prayer patterns. how character typically prays maintained
- Community membership. who's in fellowship, roles in community
- Faith crisis depth. doubt level tracks believably
- Sin struggles. ongoing temptations don't vanish overnight
- Spiritual gifts. if charismatic tradition, gifts consistent
- Conversion story. testimony details stay same when retold

NARRATIVE LAYER TRACKING
- A-story (Faith journey): Current spiritual state. growing, doubting, seeking, transformed? What triggered the last shift?
- B-story (Relationships): Status of key human connection being tested. marriage, friendship, mentor/mentee
- C-story (Community): Church/congregation dynamics. who's supportive, who's judgmental, what controversy is simmering
- Track where storylines have intersected. when did the personal crisis affect the relationship? When did community judgement deepen the doubt?
- Flag when any storyline has stalled for 2+ chapters

STORY TURN LOG
- Track last significant turn per storyline per chapter
- Ensure turns escalate. early doubts are intellectual, later ones are existential
- Flag chapters where faith is neither tested nor deepened (spiritual static = lost reader engagement)
- Turns should build on theology. each challenge should engage deeper doctrine, not repeat surface-level doubt
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Faith authenticity: Character's beliefs and practices genuine to their stage of spiritual journey
2. Struggle reality: Doubt, temptation, sin portrayed honestly. not perfect Christians
3. Growth trajectory: Spiritual progression logical. crisis to deeper faith, or honest wrestling
4. Community integration: How character relates to faith community consistent with beliefs
5. Moral complexity: Good people with flaws, questionable choices made with good intentions

GENRE-SPECIFIC CHARACTER ELEMENTS
- Spiritual state: New believer, mature Christian, backslider, seeker, skeptic. clear and evolving
- Prayer life: How/when/why character prays. intimate with God or struggling to connect
- Scripture engagement: Bible reading patterns, favourite verses, how applies to life
- Church involvement: Active, peripheral, searching, or resistant to community
- Testimony: Conversion or faith story. how came to belief or deepened
- Spiritual gifts: If charismatic tradition, specific gifts (teaching, mercy, prophecy, etc.)
- Sin struggles: Specific temptations. pride, lust, greed, anger, fear addressed honestly
- Doubt areas: What questions about God, suffering, theology character wrestles with

MEMORABLE CHARACTERS
Create believers (and doubters) who are larger than life yet grounded by contradiction:
- The pastor with thundering conviction who privately drowns in doubt every night
- The atheist scientist whose kindness and moral clarity shames the congregation
- The quiet grandmother whose faith is iron. but whose past holds a secret that would shatter the church
- The zealous youth leader whose passion masks deep personal brokenness
- Every significant character should embody one trait that contradicts their spiritual archetype
- The most compelling religious fiction characters are those whose faith and flaws are inseparable. the doubt is what makes the faith real, the sin is what makes the grace necessary
- Avoid flat saints and flat sinners. complexity is where spiritual truth lives

CHARACTER ARCS MUST
- Show faith tested. crisis that challenges belief
- Demonstrate growth through struggle. not easy sanctification
- Face moral choices requiring faith principles. tested by circumstances
- Wrestle authentically. doubt portrayed respectfully, not quickly dismissed
- Build community. isolation to belonging, or community betrayal to new fellowship
- Apply faith practically. belief affecting daily choices, relationships, work
- Earn transformation. spiritual change through experience, prayer, community, not magic

TRACK
- Spiritual state at story start vs. end. how faith changed
- Prayer patterns. frequency, style, content evolution
- Scripture verses meaningful to character. favourites, struggles with
- Church community relationships. who mentors, who fellow travellers, conflicts
- Specific sins struggled with. don't just say "temptation," name it
- Doubts and theological questions wrestled with
- Answered and unanswered prayers. what asked, what received
- Conversion or significant faith moments. testimony details
```

## Arc Rules

```
ACT I (Chapters 1-10): Established Faith or Spiritual State
- Ch 1: Character's spiritual state established. believer, seeker, skeptic
- Ch 2-3: Faith context. church community, prayer life, beliefs shown in action
- Ch 4-5: Life circumstances. family, work, relationships that will be tested
- Ch 6-8: Inciting incident. crisis begins (death, betrayal, moral temptation, doubt)
- Ch 9-10: Faith inadequate. current spiritual state can't handle crisis
- Purpose: Show character's spiritual condition, introduce faith challenge or crisis
- Ends with: Crisis that tests faith. doubt triggered, moral failure, suffering begins

MIDPOINT (Chapter 15): Spiritual Turning Point
- Moment of surrender, conversion, or deepest doubt. path forward shifts
- Answered prayer, conversion moment, or dark night of soul
- Tonal shift: From questioning to seeking, or from faith to doubt and back

ACT II (Chapters 11-23): Wrestling and Growth
- Ch 11-14: Seeking answers. prayer, scripture study, counsel from mentors
- Ch 15: MIDPOINT. spiritual breakthrough or deepest crisis
- Ch 16-18: Testing. applying new understanding, facing temptation, choosing faith
- Ch 19-21: Community support or betrayal. church response to struggle
- Ch 22-23: Climax of struggle. must choose faith or walk away, obey or rebel
- Purpose: Character struggles spiritually, seeks answers, tests faith, experiences community
- Ends with: Breaking point. faith nearly lost or surrender begins

ACT III (Chapters 24-30): Transformation and Resolution
- Ch 24-25: Final test. greatest moral choice or faith decision
- Ch 26-28: Choosing faith. despite cost, uncertainty, or continued questions
- Ch 29: Resolution. crisis resolves, character's faith proven or converted
- Ch 30: New normal. transformed character, deeper faith, hope for journey ahead
- Purpose: Faith tested at highest level, character transformed, new spiritual equilibrium
- Ends with: Deepened faith, conversion completed, or honest continued wrestling with hope

GENRE PROMISE
- Faith central: not backdrop but driving force
- Spiritual authenticity: real prayer, scripture, worship
- Moral clarity: generally clear good/evil, though struggle is real
- Community importance: church/temple/mosque fellowship matters
- Redemption possible: grace, forgiveness, second chances
- Hope present: even in suffering, faith provides light
- Growth shown: character spiritually different by end
- Theological depth: spiritual truth through story
- Honest doubt: faith includes wrestling, questions
- Providence: God working, even when not obvious

REQUIRED CHECKPOINTS
- Ch 3: Character's spiritual state and faith practices clear
- Ch 8: Crisis begins that tests faith. suffering, doubt, temptation
- Ch 10: Current faith inadequate. needs to grow or deepen
- Ch 15: Spiritual turning point. conversion, surrender, or crisis peak
- Ch 20: Faith tested practically. must choose based on beliefs
- Ch 23: Breaking point. faith nearly lost or finally embraced
- Ch 28: Final choice. faith vs. self, obedience vs. rebellion
- Ch 30: Transformation evident. faith deeper, conversion complete, hope restored
```

## Timeline Rules

```
TIME SCALE
- Total story duration: Weeks to years (spiritual journeys take time)
- Chapter time span: Days to weeks. balance events with reflection time
- Time progression: Linear with flashbacks to testimony/conversion if relevant

GENRE-SPECIFIC TEMPORAL RULES
- Faith growth gradual. conversion or deepening over weeks/months, not instant
- Church calendar relevant. Advent, Lent, Easter, Christmas structure Christian stories
- Prayer time realistic. daily devotions, weekly services, annual retreats
- Crisis to resolution. spiritual struggles don't resolve overnight
- Discipleship takes time. mentoring relationship develops over months
- Doubt season. wrestling with God may span weeks or months
- Answered prayer timing. some immediate, some wait years, some "no"
- Habit formation. spiritual disciplines build over weeks of practice

TRACK CAREFULLY
- Church calendar season. Advent, Lent, Ordinary Time if Christian
- Days since conversion or crisis. track spiritual journey from specific point
- Weekly worship attendance. Sunday services, Sabbath, Friday prayers
- Daily prayer times. morning devotions, meal prayers, bedtime
- Small group meetings. weekly Bible study, accountability group
- Scripture reading progress. if character reading through Bible or specific book
- Time wrestling with specific doubt or temptation
- Seasons of life. spiritual state often tied to life circumstances

PACING RHYTHM
- Story turns every 4-6 pages. no section should coast on spiritual atmosphere without a shift
- Alternate scene types: prayer/reflection followed by action/confrontation; community warmth followed by private doubt
- After a spiritual breakthrough, ground the reader in mundane reality. the bills that still need paying, the relationship that's still broken
- Build urgency through converging pressures: the faith crisis deepens as the life crisis demands action
- Allow silence. not every chapter needs a dramatic revelation. Sometimes faith grows in the quiet between storms. But even quiet chapters need a small turn: a verse that unsettles, a memory that surfaces, a question that won't sleep.

FLEXIBLE
- Exact times of daily prayers unless ritual tradition requires precision
- Minor background character spiritual journeys
- Precise dates unless tied to church calendar
```

## Genre-Specific Craft Techniques

Religious fiction at the level of John Bunyan, Graham Greene,
Shūsaku Endō, Marilynne Robinson, Michel Faber, Ron Hansen,
Fredrik Backman, and Maggie O'Farrell does not earn its
spiritual weight by adopting a reverent register and quoting
scripture: it earns weight through specific tradition,
embodied theology, and the refusal to resolve doubt cheaply.
The genre is uniquely vulnerable to a cluster of failure
modes that AI-generated drafts hit with depressing
consistency: **Didactic Preaching** (the narrative stops and
the author lectures the reader through a thin character
mask); **Religion-as-Decoration** (sacred vocabulary applied
as set-dressing without specific tradition, denomination, or
doctrinal architecture underneath); **Crisis-of-Faith
Reduction** (a season of doubt sketched in a paragraph and
resolved by a verse, when authentic faith crisis takes
chapters to build and never resolves cleanly); **Saintly
Protagonist** (a believer without genuine sin, doubt, or
weakness, against whom no real grace can land because nothing
needs forgiving); **Anti-Religious Caricature** (atheists,
agnostics, or other-tradition characters as cartoon villains
to be defeated rather than people whose objections are
respected); **Uncritical Hagiography** (the inverse failure —
the faith community shown as uniformly virtuous, with
gossip / hypocrisy / institutional failure invisible);
**Historical-Period Religious Inauthenticity** (a Reformation
or medieval setting with twenty-first-century Protestant
sensibilities pasted in, ignoring the actual theology and
practice of the period); **Universal-Spiritual Without
Specific Tradition** (vaguely "spiritual" content that
refuses to commit to a denominational or theological
position, producing a bland ecumenicism that satisfies
neither faith nor literary readers); **Conversion-Arc Cliché**
(the skeptic-becomes-believer arc executed in a single
chapter through a single dramatic event); **Suffering-Equals-
Virtue Collapse** (theodicy collapsed into "everything
happens for a reason" — the trite phrase that passes for
theology in lazy religious fiction); and **Contemporary-
Religious-Fiction Cultural Alienation** (writing as if the
faith community exists in a pre-modern bubble untouched by
secular culture, social media, denominational decline,
political fracture, or the actual pressures that twenty-
first-century believers navigate). The five canonical
techniques below — Incarnational Detail, Doubled Scripture,
Congregational Mirror, Honest Lament, Grace Ambush — defeat
these failure modes through specificity, embodiment, and
honesty. The three deepening techniques after them
(Specific-Tradition Discipline, Doubt-and-Faith
Architecture, Theological-Embodiment Discipline) extend the
defence into structural disciplines the manuscript must
sustain across the full arc.

### The Incarnational Detail

Religious fiction earns its spiritual weight through physical, embodied moments. not abstractions. The sacred is revealed through the material:

```
ABSTRACT (fails):
"She felt God's presence and was filled with peace."

INCARNATIONAL (works):
"She pressed her forehead against the cold wood of the
pew. The varnish smelled like her grandmother's church.
lemon oil and candle wax and something older. Her knees
ached. Her mind wouldn't settle. But her hands, folded
without thinking, had found the shape of every prayer
she'd ever been taught, and that was enough."

The body prays before the mind agrees.
God shows up in lemon oil, not abstractions.
```

### The Doubled Scripture

A single Bible passage read twice. at different points in the story, by a character in different spiritual states. reveals how faith transforms understanding:

```
Chapter 3 (comfort):
Pastor reads Psalm 23 at the Sunday service.
Sarah hears "The Lord is my shepherd" and feels safe.
It confirms what she already believes.

Chapter 19 (crisis):
Sarah's son is missing. She opens her Bible to Psalm 23
by habit. "Though I walk through the valley of the
shadow of death". she stops. She's never been in the
valley before. The words are the same. She is not.

Same text. Different reader. The scripture hasn't changed;
the character has. This is how religious fiction dramatises
theology without explaining it.
```

### The Congregational Mirror

Use the faith community as a chorus that reflects, distorts, and challenges the protagonist's spiritual state. The congregation is not scenery. it is a dramatic instrument:

```
When the protagonist doubts, the congregation's certainty
becomes oppressive. When the protagonist breaks through,
the congregation's petty disputes become newly bearable.
The same Wednesday night prayer meeting feels like
sanctuary in chapter 5 and suffocation in chapter 14.

The community reveals the protagonist to herself.
The small-group leader who says "I'll pray for you" can
be the most comforting or the most infuriating line in
the book, depending on when it lands.
```

### The Honest Lament

Religious fiction's most powerful register is the lament. the tradition of arguing with God that runs from Job through the Psalms. Most writers avoid it (too uncomfortable). The best writers lean into it:

```
NOT lament (too tidy):
"Why, God?" she whispered, then remembered Romans 8:28
and felt better.

GENUINE lament:
"Where were You?" She wasn't whispering. She was sitting
in her car in the church car park, engine off, windows up,
and she was not whispering. "Where were You when he was
dying? I asked. I begged. I fasted. I did everything
the books say. Everything the pastor says. And You —"
She hit the steering wheel. Her palm stung.
"You could have. That's what I can't get past. Not that
You didn't. That You could have."

Lament is not loss of faith. It is faith's most
demanding expression. the refusal to pretend.
```

### The Grace Ambush

The most powerful moments of grace in religious fiction arrive uninvited and from unexpected directions. Grace that the character earns is not grace. it is reward. Grace that arrives through the "wrong" person, at the wrong time, in the wrong form is theologically accurate and narratively devastating:

```
The estranged brother who hasn't spoken to her in six
years shows up at the hospital. He doesn't apologise.
He doesn't explain. He sits in the plastic chair beside
her and says, "I brought coffee. It's terrible." And
she understands, in that moment, more about the nature
of unmerited love than she learned in twenty years of
Sunday school.

Grace is most visible when it arrives through cracked
vessels. The imperfect messenger makes the message real.
```

### Specific-Tradition Discipline

The single most common failure mode in religious fiction is
"generically spiritual" prose — writing that gestures at the
sacred without committing to a specific denomination,
theology, or practice. Authentic religious fiction locks down
the tradition early and lets every detail emanate from that
specific commitment. The discipline applies whether the
manuscript sits inside a tradition (Catholic literary fiction,
Inspirational Christian, Amish), straddles two (interfaith
dialogue), or operates on the margins (spiritual quest):

```
1. NAMED TRADITION (lock down at outline stage)
   - Not "Christian" — Roman Catholic (post-Vatican II);
     Anglican (low-church evangelical or high-church
     Anglo-Catholic); Southern Baptist (SBC, post-2000
     conservative resurgence); PCA Presbyterian; charismatic
     non-denominational; Greek Orthodox; Old Order Amish.
   - Not "spiritual" — Quaker meeting; secular humanist
     wrestling with religious upbringing; Reform Jewish; UU
     congregant; ex-Mormon. The label sets the playing field.
   - Period and geography matter: 1950s Irish Catholic is
     not 2020s American Catholic, and an SBC church in
     Birmingham AL is not an SBC church in Seattle WA.

2. VOCABULARY CONSISTENCY
   - Catholic characters go to Mass, not "service." They
     genuflect; they cross themselves with holy water; they
     speak of the Eucharist (not Communion in the
     Protestant sense); they pray the Rosary; they go to
     Confession (not "talk to the pastor").
   - Protestant characters go to "service" or "worship,"
     not Mass. They take Communion or the Lord's Supper.
     Their prayer language differs by tradition (charismatic
     "Father, we just thank You" vs. Anglican collect form).
   - Jewish characters do not "pray to God" in the
     Christian-prayer cadence; they daven, they say a
     bracha, they sit shiva. Get the verbs right.

3. DOCTRINAL CONSISTENCY
   - Theological positions stay inside the tradition's
     actual range. A PCA Presbyterian character does not
     casually affirm purgatory; a Catholic character does
     not preach sola scriptura; a Quaker does not lead a
     liturgical procession.
   - When characters disagree across traditions, render the
     disagreement specifically (this is one of the genre's
     richest dramatic resources — see The Power and the
     Glory's Whisky Priest vs. the lieutenant).
   - If your character holds a heterodox position within
     their stated tradition, name it: it is a story
     element, not an oversight.

4. RESEARCH DEPTH
   - Liturgical calendar accurate (Catholic Lent ≠ Eastern
     Orthodox Lent — different start dates, different
     fasting rules).
   - Scripture quotation from the translation that tradition
     actually uses (Catholics cite NABRE or Douay-Rheims,
     not NIV; KJV-Only Baptists cite KJV exclusively;
     Reformed evangelicals often cite ESV).
   - Hymns and worship music from the actual repertoire
     (Catholic Mass parts ≠ contemporary worship songs ≠
     Sacred Harp shape-note ≠ African-American gospel
     tradition). Name the songs.
   - Clergy titles correct (Father / Pastor / Reverend /
     Minister / Rabbi / Imam — and note that Anglican
     priests are Father, but PCA pastors are Pastor or
     Reverend, never Father).

5. CULTURAL-RESPECT POSITIONING
   - When writing a tradition you do not personally
     practise, the discipline is research-led humility.
     Read what insiders write; consult sensitivity readers
     from inside the tradition; verify liturgical detail
     against actual rubrics.
   - The story's point of view need not be uncritical, but
     the tradition's beliefs must be understood from inside
     before they are critiqued from outside (Greene was a
     Catholic critic of the Catholic Church; Robinson is a
     Calvinist defender of Calvinism — both write from
     informed positions).
```

The Specific-Tradition Discipline is what separates
*Mariette in Ecstasy* (Hansen knows the post-Vatican II
contemplative-order setting cold) from generic
"convent fiction." The reader feels the tradition's weight
even when they do not share it.

### Doubt-and-Faith Architecture

Authentic religious fiction never collapses doubt into a
narrative obstacle to be overcome. Doubt is faith's
interlocutor, present from the first chapter to the last,
shifting in form and intensity but never disappearing.
The Doubt-and-Faith Architecture is the structural
discipline that ensures doubt and faith are both
characterised, both honoured, and neither defeated:

```
1. DOUBT IS CHARACTERISED, NOT DECORATIVE
   - The character's doubts are specific and intellectually
     honest: not "she doubted God" but "she could not
     reconcile a loving God with the random pediatric
     cancer ward where she worked night shifts."
   - Each doubt has a history: when did this question first
     surface? What event sharpened it? What previous
     answers have failed? Doubt has biography, like faith.
   - Multiple doubts at multiple registers: intellectual
     (theodicy, biblical reliability, miracle), moral (the
     church's complicity in harm), existential (meaning,
     mortality, the felt absence of God).

2. FAITH IS CHARACTERISED, NOT ASSUMED
   - Believers' faith is rendered with the same specificity
     as doubt: not "she believed in God" but "she believed
     in the God who shows up in the kitchen, who is more
     interested in how you treat the cashier than how you
     vote, who she could not have explained to her seminary
     professors but who was unmistakably present in the
     way her grandmother said grace over Sunday dinner."
   - Faith has texture, history, sources. Why this
     particular shape of belief? Whose faith was inherited?
     What practices sustain it? What experiences confirm it?

3. DOUBT AND FAITH COEXIST, NOT ALTERNATE
   - The strongest religious fiction shows characters who
     simultaneously believe and doubt — Greene's Whisky
     Priest, Endō's Rodrigues, Robinson's John Ames in his
     darkest moments. The "either / or" framing is
     simplistic and unliterary.
   - In a single paragraph, a character can pray
     genuinely AND not be sure anyone hears. This is not
     a contradiction; it is faith's actual condition.
   - The narrative does not punish doubt or reward
     certainty; both are character states, equally
     respected.

4. DOUBT-AND-FAITH ARCS PROGRESS NON-LINEARLY
   - The Act III "transformation" is rarely doubt
     overcome. More often it is doubt integrated — the
     character lives with the question, has stopped
     needing it answered, has found a way of being
     faithful that includes uncertainty.
   - "Dark night of the soul" passages (St. John of the
     Cross's term) are not failure states; they are
     traditional mystical territory. The novel can take
     this seriously.
   - Honest endings: doubt may deepen alongside faith;
     a character may end the manuscript more believing
     AND more uncertain than at the start. This is not a
     contradiction; it is the reader's experience.

5. NON-BELIEVING CHARACTERS ARE FULLY HUMAN
   - Atheists, agnostics, and characters of other faiths
     are not narrative obstacles or conversion targets.
     Their objections are intellectually serious and
     respected by the narrative voice.
   - The "atheist defeated by simple faith" trope is
     forbidden. Real atheists hold their position for
     reasons that survived prior contact with belief.
   - Characters of other faiths are rendered with the
     same Specific-Tradition Discipline as the
     protagonist's tradition: Hindu characters have
     specific doctrinal commitments, not generic
     spirituality.
```

The Doubt-and-Faith Architecture is the structural
guarantee against the Saintly Protagonist failure mode
and the Crisis-of-Faith Reduction. Doubt that is
specific, biographical, and unresolved is what makes
faith — when it appears — narratively credible.

### Theological-Embodiment Discipline

Theology in religious fiction must be dramatised, not
explained. The Theological-Embodiment Discipline is the
operational test that converts every potentially abstract
spiritual claim into a specific embodied scene. It is the
single most powerful defence against Didactic Preaching
and Religion-as-Decoration:

```
1. EVERY DOCTRINE BECOMES A SCENE
   - "Grace" is not a noun the narrator can deploy; it is
     a specific moment in which a specific character
     receives a specific undeserved kindness from a
     specific person at a specific time, and the receiving
     character's specific response renders the doctrine
     concrete.
   - "Forgiveness" is not "she forgave him"; it is "she
     made the call. He picked up. She said the
     sentence she had been rehearsing for eight months
     and meant a different sentence than the one she
     had rehearsed."
   - "Repentance" is not internal monologue; it is the
     specific changed behaviour that registers in another
     character's perception.

2. EVERY PRAYER HAS SPECIFIC CONTENT AND SPECIFIC RESULT
   - No "she prayed" without rendering at least one
     sentence of the prayer. Prayers without content are
     decoration.
   - Every prayer's effect on the praying character is
     rendered: the slight relaxation, the surfacing
     memory, the new resolve, the deeper anguish, the
     unchanged condition. Prayer that has no
     consequence even on the praying character is
     theatrical.
   - "Answered" prayers come through specific
     mechanisms (the friend who calls, the unexpected
     opportunity, the changed circumstance); the
     attribution to God is the character's interpretive
     choice, never the narrator's flat claim.

3. EVERY SCRIPTURE HAS SPECIFIC LOCAL FUNCTION
   - When a verse is quoted, it does specific work in
     the immediate scene: comfort, conviction,
     argument, ironic counterpoint, memory trigger,
     character self-disclosure.
   - The character has a specific relationship with the
     verse: when did they learn it? Whose voice do they
     hear it in? Has its meaning shifted for them?
   - Avoid proof-texting (the verse deployed to settle
     an argument the narrator wants settled). Verses in
     literary religious fiction unsettle as often as
     they comfort.

4. EVERY WORSHIP MOMENT HAS SPECIFIC PHYSICAL
   PARTICULARITY
   - Mass / service / meeting renders: the specific
     hymn (named), the specific liturgical text (cited
     by source), the specific sensory detail (the smell
     of incense / the cold of the wooden pew / the
     particular timbre of this congregation's voice on
     "How Great Thou Art"), the specific
     congregational dynamic (who's not here / who's
     watching whom / what is being said in the row
     behind).
   - The protagonist's specific internal experience of
     the worship moment: present, distracted,
     skeptical, transported, conflicted, bored. Generic
     reverence is not characterisation.

5. EVERY MORAL CHOICE HAS SPECIFIC THEOLOGICAL FREIGHT
   - When a character makes a choice rooted in faith,
     the theological commitment is specific: not "she
     did the right thing" but "she remembered the line
     about the least of these and did the thing she had
     been refusing to do."
   - The cost is rendered: faith-rooted choices in good
     religious fiction cost the character something
     specific (relationship, money, comfort,
     reputation), and the manuscript shows the cost.
   - Choices made AGAINST faith principles are
     similarly specific: the character knows what
     tradition would require and does the other thing,
     and the manuscript honours the weight of that
     deviation.
```

The Theological-Embodiment Discipline is the operational
form of "show, don't tell" applied to religious content.
When applied across the full manuscript, it produces
prose in which a non-believing reader can engage
theologically without being lectured, and a believing
reader feels their tradition rendered with the
specificity it actually has.

### Religious Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "faith was tested" | Show the specific test |
| "a divine presence filled the room" | Show the specific experience through the character's senses |
| "the power of prayer" | Show the specific prayer and its specific consequence |
| "a crisis of faith" | Show the specific event that triggers doubt |
| "God works in mysterious ways" | Show the specific mysterious event |
| "the spiritual journey" | Show ONE specific step on the journey |
| "redemption was possible" | Show the specific act of redemption |
| "the sacred and the profane" | Show the specific collision |
| "a calling that could not be ignored" | Show the specific call and specific sacrifice it demands |
| "the light of faith" | Show the specific comforting or guiding moment |
| "she felt at peace" | Show the specific physical change: the shoulders dropping, the breath that finally came |
| "his heart was heavy" | Show the specific weight: the inability to eat, the staring at a ceiling, the hand that won't lift the phone |
| "a moment of clarity" | Show the specific seen thing — the window, the line of scripture, the person's face — that produced the seeing |
| "everything happens for a reason" | Cut entirely. If a character speaks it, show another character bristling. The phrase is the failure |
| "God's plan was unfolding" | Show the specific event without the narrator-frame editorial; let the reader read providence (or not) |
| "her soul was restless" | Show the specific behaviour: the 3am Bible-app scrolling, the avoidance of the small group, the dreams |
| "he felt called" | Show the specific intrusion: the sentence that wouldn't go away, the conversation that kept being repeated, the closed door that opened |
| "their faith was unshakeable" | Show the specific test the faith has already survived; if untested, it isn't unshakeable, it's untried |

## Genre-Specific Revision Rules

### Six-Pass Religious Fiction Audit (Run FIRST in editorial pipeline)

The Religious Fiction Audit runs every chapter through six
named passes. Run them in order — each builds on the last.

#### Pass 1: Scripture & Theology

The Scripture & Theology pass is the first defence against
Religion-as-Decoration and the proof-texting failure mode.
Read every quoted verse against the stated translation —
NIV in NIV chapters, ESV in ESV chapters, NABRE in
Catholic chapters, KJV where the tradition demands it —
and verify wording is accurate, citation is correct, and
context is honoured. Scripture must do specific local
work in the scene rather than settle an argument the
author wants settled; the verse must be earned by the
character's relationship with it, not deployed by the
narrator to deliver a lesson. Theological claims must
remain consistent with the stated denomination and
tradition: a PCA Presbyterian character does not preach
purgatory, a Catholic character does not affirm sola
scriptura, a Quaker does not lead a liturgical procession.
Any doctrine presented as universal that is actually
denominational gets flagged for revision — heterodox
positions inside a tradition are story elements that must
be named, not narrator-level oversights. The pass
concludes by confirming the manuscript has at least one
character who reads the same verse differently from the
protagonist; absence of theological dialogue across
faithful positions is itself a failure mode.

#### Pass 2: Preachiness Detector

The Preachiness Detector is the most ruthless pass, and
the one most religious fiction manuscripts most need.
Read each spiritual moment with a specific question: is
the author's voice intruding over the character's? Any
passage where the narrative stops and a lesson begins
gets cut or dramatised — the test is whether you can
delete the explanation and still feel the spiritual
weight through the scene's specific details. Every
spiritual insight must arrive through experience, never
through exposition: the doctrine of grace is not stated,
it is shown when a character extends undeserved mercy
without commentary; the doctrine of providence is not
labelled, it is rendered when the character later
notices the unlikely chain that brought them here.
Apply the non-believing-reader test: could a thoughtful
agnostic respect the passage as literature, or would
they feel lectured at? If the latter, the passage is
not yet earning its place. The Preachiness Detector
catches the Didactic Preaching failure mode at the
sentence level.

#### Pass 3: Prayer & Worship Authenticity

The Prayer & Worship Authenticity pass tests the
tradition's specificity at the level of practice. Are
prayer scenes varied in form across the manuscript —
praise, petition, confession, lament, silence,
intercession, contemplation — or are they all the same
rhythm? A protagonist who only ever petitions is
characterologically thin; faithful prayer life
includes registers the manuscript must render. Does
worship feel specific to the stated tradition or
generically "churchy"? A Catholic Mass renders the
specific liturgical motion (the standing, the kneeling,
the responses, the Eucharistic prayer); a charismatic
worship service renders the specific sound (the
extended worship sets, the spontaneous prayer, the
"Father, we just thank You" cadence); an Anglican
Evensong renders the specific text (Cranmer's collects,
the Magnificat, the cadenced Book of Common Prayer
phrasing). Hymns, liturgical texts, and practices must
be named and accurate. The pass closes by confirming
the protagonist's prayer life evolves across the
manuscript — the prayer life of Chapter 1 cannot be
identical to the prayer life of Chapter 30, or the
spiritual journey is not reaching the page.

#### Pass 4: Doubt & Struggle Integrity

The Doubt & Struggle Integrity pass enforces the Doubt-
and-Faith Architecture against the Crisis-of-Faith
Reduction failure mode. Every faith crisis must be
earned — built over chapters, not sprung in a single
paragraph — and the resolution must be proportional to
the crisis: a season of doubt that took ten chapters to
deepen cannot be resolved by a verse and a sunrise.
Doubts must be intellectually honest: would a real
skeptic actually raise this question, or is the doubt
a strawman the narrative is preparing to defeat?
Authentic doubt has biography (when did this question
first surface, what event sharpened it, what previous
answers have failed) and stays specific (theodicy,
biblical reliability, miracle, ecclesial complicity,
felt absence). Non-believing characters must have
genuine, respected reasons for their position; the
"atheist defeated by simple faith" trope is forbidden.
The pass also verifies the inverse: faithful
characters' faith is rendered with the same specificity
as doubt — texture, history, sources, sustaining
practices — so that neither side is decorative.

#### Pass 5: Community & Relationship Realism

The Community & Relationship Realism pass is the
defence against Uncritical Hagiography and generic
"fellowship." The faith community must contain both
saints and hypocrites — and the manuscript must let
the hypocrites be hypocrites without authorial
comment, trusting the reader to register the gap
between profession and practice. Congregational
politics, gossip, theological dispute, denominational
fracture, and institutional failure must be shown
alongside the support and warmth the community also
provides. Relationships within the church must feel
specific: not "the small group prayed for her" but
the named members with named burdens whose
intercession has texture. The community's response to
the protagonist's crisis must be believable —
including the moments where the response is
inadequate, judgemental, or actively harmful. A
manuscript in which the church is uniformly warm,
wise, and supportive has not yet rendered a real
congregation; the pass forces specificity by asking
which named character in the community actively makes
the protagonist's situation worse.

#### Pass 6: Specific-Tradition + Doubt-and-Faith + Theological-Embodiment Integration

The integration pass is where the three structural
disciplines from the Genre-Specific Craft Techniques
section get verified at the manuscript level. Apply the
Specific-Tradition Discipline checklist: is the named
tradition locked down (denomination, period, geography);
is the vocabulary consistent (Mass vs. service vs.
meeting, Father vs. Pastor vs. Reverend, Eucharist vs.
Communion, daven vs. pray); is the doctrinal range
inside the tradition's actual envelope; is research
depth visible (correct liturgical calendar, correct
scripture translation, correct hymn repertoire, correct
clergy titles); is the cultural-respect positioning
informed-from-inside? Apply the Doubt-and-Faith
Architecture: is doubt characterised with the same
specificity as faith; do they coexist in the same
character rather than alternate; is the arc non-linear
(integration rather than overcoming); are non-believing
characters fully human? Apply the Theological-
Embodiment Discipline: does every doctrine become a
specific scene; does every prayer have content and
result; does every scripture have local function; does
every worship moment have physical particularity;
does every moral choice have specific theological
freight? The integration pass is the final guarantee
against Religion-as-Decoration, the Saintly
Protagonist, the Conversion-Arc Cliché, and the
Suffering-Equals-Virtue Collapse — the failure modes
that distinguish AI-grade religious fiction from the
real thing.

## Names & Patterns to Avoid

### Religious Fiction Character Names. NEVER USE
- Overtly allegorical names: Grace, Faith, Hope, Mercy, Christian, Pilgrim
- Names that telegraph spiritual state: Angel, Trinity, Eden, Revelation
- "Stained glass" names that feel chosen for symbolism rather than given by parents
- Biblical names used heavy-handedly when the character parallels that figure (a betrayer named Judas, a leader named Moses)

### Religious Fiction. NEVER DO
- Open with a character waking up and reading their Bible (the most overused opening in the genre)
- End with a neat conversion that resolves all narrative problems
- Include a "testimony scene" where a character recounts their entire faith journey in unbroken monologue
- Kill a character solely to teach the protagonist a spiritual lesson (theodicy as plot device)
- Have the skeptic character convert after a single dramatic event
- Resolve a marriage crisis by having both partners pray and instantly reconcile
- Use a child's innocent faith to shame adult doubt (sentimentality masquerading as theology)

### Use Instead
- Names appropriate to the character's cultural background, denomination, era, and family
- Names that feel given by parents. not selected by an author with a theological agenda
- Biblical names are fine when they feel natural to the family (many real families use them). just don't lean on the parallel
- The name should disappear into the character: after two chapters, the reader should think of the person, not the symbol

### Cliché Setups to Avoid
- The pastor who loses faith after a personal tragedy (unless executed with genuine originality)
- The rebellious preacher's kid who returns to faith
- The atheist professor defeated by a freshman's simple belief
- The dying relative whose faith inspires everyone
- The miraculous healing that proves God's existence to the doubter

## Comp Titles

Religious-fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Pilgrim's Progress* — John Bunyan (1678): the foundational Christian allegorical-fiction.
- *The Power and the Glory* — Graham Greene (1940): Catholic literary-religious benchmark.
- *Silence* — Shūsaku Endō (1966): Japanese-Catholic literary-religious masterpiece.
- *Gilead* — Marilynne Robinson (2004): contemporary literary-religious benchmark.

### Contemporary (current best-in-class)

- *Lila* — Marilynne Robinson (2014): the Gilead series; literary-religious continuation.
- *Jack* — Marilynne Robinson (2020): same series; demonstrates literary-religious series architecture.
- *The Book of Strange New Things* — Michel Faber (2014): SF-religious-fiction crossover.
- *Mariette in Ecstasy* — Ron Hansen (1991): Catholic mystical literary-religious.
- *Brother West* — Cornel West (2009, NF) / similar contemporary religious-literary nonfiction.
- *Beartown* — Fredrik Backman (2016, religious-adjacent): contemporary literary-religious-adjacent.
- *Hamnet* — Maggie O'Farrell (2020, religious-historical): contemporary literary-religious-historical.

## Cover Design Specifications

### Recommended Visual Styles
- **Luminous Realism**. Warm, light-filled photography or illustration; golden hour tones; imagery suggesting hope, transcendence, and quiet beauty without being saccharine
- **Symbolic Minimalism**. A single resonant object (a candle, an open door, a path through trees, a pair of hands) against a clean background; the symbol invites contemplation
- **Literary Devotional**. Typography-forward design with subtle sacred geometry or watercolour textures; signals literary quality within the faith market
- **Landscape as Theology**. Natural landscapes (fields, mountains, rivers, light through clouds) that evoke the sacred without depicting it literally; creation pointing beyond itself

### Genre Cover Aesthetics
- **Styles:** Warm and inviting without being saccharine; photographic or painterly rather than graphic; light as a recurring motif (dawn, candles, windows); nature imagery suggesting providence; restrained elegance that bridges the faith and literary markets
- **Colours:** Warm gold, soft amber, deep burgundy, cream, sage green, sky blue, ivory; earth tones grounded with light; avoid neon or garish palettes; avoid funeral black as dominant colour; the palette should feel like morning light in a quiet room
- **Elements:** Paths, doorways, light sources, natural landscapes, architectural details (arches, stained glass. used sparingly), open books, simple objects with symbolic weight, hands (in prayer, reaching, holding); avoid crosses and religious iconography on the cover unless the tradition specifically calls for it (the Amish bonnet is an exception)
- **Typography:** Warm serif fonts (Garamond, Caslon, Baskerville families); elegant but approachable; title prominent with generous spacing; author name in complementary weight; avoid ornate script fonts that signal romance rather than literary faith fiction

### Market Positioning
Religious fiction covers must navigate two markets: the faith community (who want assurance of values alignment) and the literary market (who want assurance of quality). The best covers signal both. Position against Marilynne Robinson, Tosca Lee, Francine Rivers, Ron Hansen, Graham Greene, Shusaku Endo. Avoid imagery that looks like a church bulletin or a greeting card. The cover should invite a reader of any faith (or none) to pick up the book. the spiritual content reveals itself through the reading, not the packaging. At thumbnail size, warmth and light are more effective than detail.

### Cover Design DON'Ts
- No literal religious iconography as the dominant element (crosses, rosaries, Bibles on the cover)
- No stock photography of people praying with hands clasped and eyes closed
- No heavenly light beams or clouds parting
- No church steeples silhouetted against sunsets
- No doves, angels, or lambs
- No cursive "inspirational" fonts
- No imagery that would look at home on a greeting card or church programme
