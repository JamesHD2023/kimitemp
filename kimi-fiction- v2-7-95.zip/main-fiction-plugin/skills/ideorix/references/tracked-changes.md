---
name: tracked-changes
description: "Tracked-changes DOCX emission protocol. Defines the canonical three-phase flow (DOCX-Read → Mark-Changes → DOCX-Write) with mandatory integrity verification (paragraph count, word count, byte count, SHA256 fingerprint) so user manuscripts cannot lose content silently during editorial passes that produce tracked-changes deliverables. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.3"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Tracked-Changes DOCX Emission Protocol (MANDATORY for any flow that produces a tracked-changes manuscript)

## Purpose

Define the canonical protocol for producing a **tracked-changes
DOCX** from a user-supplied source manuscript — preserving the
user's source content with byte-level fidelity while marking
suggested edits as Word-compatible tracked changes (insertions,
deletions, formatting changes).

This protocol exists because of a documented production failure
mode: in operational use, the engine ran an editorial pass over
a user's existing manuscript with the instruction to track
changes rather than apply them. The output DOCX silently dropped
2-3 sentences in at least two places — clean prose passages that
the editorial agents had no reason to flag, with mid-sentence
cutoffs at page boundaries, only caught because the user was
reading the output line-by-line against the original. The
agent's edit-pass had improvised the tracked-changes flow
without a documented protocol. There were:

- No paragraph-count verification post-emission
- No word-count integrity check
- No byte-count integrity check
- No diff-against-source deliverable
- No file-write hygiene gate on the DOCX write
- No HARD GATE blocking emission with content loss

This protocol closes that gap structurally. Every tracked-changes
DOCX flow MUST follow the three-phase pattern below, with
mandatory integrity verification at each phase boundary.

## When this protocol fires

This protocol is invoked whenever a flow produces a
**tracked-changes DOCX deliverable**. Specifically:

- **`edit-and-revise.md`** — when the user requests editorial
  feedback as tracked-changes ("track changes rather than
  apply them", "give me a tracked-changes version", "I want
  to review changes before accepting", etc.)
- **`editorial-suite.md` Stage 8** (Apply Top Fixes /
  Surgical Fixes) — when invoked in tracked-changes mode rather
  than apply-inline mode
- **`manuscript-clinic.md`** — when the clinic produces
  redline-style annotations on the manuscript
- **`batch-editor.md`** — if the batch editor's output is
  delivered as tracked changes (typically inline-applied, but
  if a user asks for tracked output, this protocol governs)
- **Any other flow** where the agent needs to produce a DOCX
  showing changes against a source DOCX

If the agent finds itself about to produce a tracked-changes
DOCX outside of this protocol, the agent MUST stop and load
this spec before proceeding.

## File Location Discipline (MANDATORY — HARD GATE)

**Output files:**

- **Tracked-changes DOCX** →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-tracked-changes.docx`
  (the deliverable the user opens in Word's Review tab to
  step through accept/reject)
- **Integrity report** →
  `~/Documents/Ideorix-Projects/[Title]/engine-data/reports/tracked-changes-integrity-{YYYY-MM-DD}.md`
  (paragraph count source vs output, word count source vs
  output, byte-fingerprint of preserved content, list of
  changes by chapter / paragraph)
- **Source-canonical archive** →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-source-archive.docx`
  (a byte-identical copy of the user's source DOCX,
  preserved unchanged for diff-against-source verification
  at any later time)

These outputs MUST be written to the canonical project's
subfolders. NOT to the parent `~/Documents/Ideorix-Projects/`
folder, the agent's working directory, or any sandbox /
temporary path. See `core-pipeline.md` § File Location
Discipline.

**HARD GATE — BLOCKING.** All three deliverables (tracked-
changes DOCX, integrity report, source archive) MUST be
present in the canonical paths before the flow reports
success.

## The Three-Phase Protocol

### Phase A: DOCX-Read with Integrity Capture (MANDATORY)

Before any editorial work begins on the user's manuscript,
capture a complete fingerprint of the source DOCX. This
fingerprint is the reference against which the output DOCX is
verified at Phase C.

**Steps:**

1. **Archive the source DOCX byte-identically.** Copy the
   user-supplied DOCX to
   `manuscript/{Title}-source-archive.docx` using `cp` (NOT
   python-docx round-trip — that may not be byte-stable).
   Verify byte-identity:

   ```bash
   sha256sum {user_path} {project_path}/manuscript/{Title}-source-archive.docx
   ```

   Both SHA256s MUST match. If not, the archive write
   failed; STOP and re-archive.

2. **Capture source fingerprint** in a Phase A summary
   structure:

   ```
   source_path: {user-supplied DOCX path}
   source_archive: manuscript/{Title}-source-archive.docx
   source_sha256: {sha256 of source DOCX}
   source_byte_count: {byte count of source DOCX}
   source_paragraph_count: {paragraph count via python-docx
                            Document.paragraphs}
   source_word_count: {sum of words across all paragraphs}
   source_run_count: {sum of runs across all paragraphs}
   source_page_estimate: {approximate page count if reliably
                          computable}
   chapter_boundaries: [list of paragraph indices where
                        chapter headings start]
   ```

3. **Per-paragraph fingerprint** — for each paragraph in the
   source DOCX, capture:
   - Paragraph index (1-based, in document order)
   - Paragraph text (full text content)
   - Paragraph SHA256 (of the text content)
   - Paragraph word count
   - Paragraph style name (Heading 1, Body Text, etc.)
   - Whether the paragraph spans a page boundary
     (paragraph contains `<w:br type="page"/>` or rendered
     across pages)

   Store this as `engine-data/tracked-changes-source-paragraphs.md`
   with one row per paragraph. This is the canonical
   reference Phase C verifies against.

4. **Page-boundary hazard scan** — flag any paragraphs that:
   - Span a page boundary (run before page break + run after
     page break in the same paragraph)
   - End mid-sentence (sentence likely continues in the next
     paragraph due to formatting issues)
   - Have unusual run structure (many runs in one paragraph,
     suggesting complex formatting)

   These are HIGH-RISK paragraphs for silent truncation.
   Phase C will give them additional verification scrutiny.

**Phase A HARD GATE:** Cannot proceed to Phase B until:
- Source archive byte-matches user-supplied DOCX (sha256
  identical)
- Source fingerprint structure is complete and written to
  engine-data
- Per-paragraph fingerprint file exists with one row per
  paragraph

### Phase B: Mark Changes (MANDATORY — operates on intermediate, not on source)

Editorial agents operate on an **intermediate Markdown
representation** of the manuscript, NOT on the source DOCX
directly. This separation ensures the source DOCX is never
modified — only read at Phase A and verified at Phase C.

**Steps:**

1. **Convert source DOCX to chapter-level Markdown** at
   `engine-data/chapters/ch{NN}.md` per the canonical
   project layout. Use the chapter boundaries captured at
   Phase A. Preserve paragraph-level structure 1:1 — every
   source paragraph becomes one MD paragraph. The
   conversion MUST be lossless: round-tripping MD → DOCX
   and back must produce paragraph-count parity.

2. **Per-chapter integrity check after conversion.** For
   each chapter MD file:

   ```bash
   bash scripts/word-count-check.sh {project}/engine-data/chapters/ch{NN}.md
   ```

   Compare paragraph count and word count against the
   source DOCX's chapter range (from Phase A's chapter
   boundaries). Mismatch is BLOCKING — the conversion has
   lost content; STOP and investigate.

3. **Run editorial agents** on the MD intermediates per
   the standard editorial pipeline (`editorial-suite.md`).
   The agents identify suggested changes but do NOT apply
   them inline. Instead, each suggested change is recorded
   as a structured change record:

   ```
   change_id: TC-001
   chapter: 12
   paragraph: 47 (1-based, document-order)
   change_type: insertion | deletion | replacement | format
   span_start: {character offset within paragraph}
   span_end: {character offset within paragraph}
   original_text: "..."
   suggested_text: "..."
   rationale: "{which editorial agent flagged this and why}"
   stage: {Stage N of editorial-suite.md}
   ```

   Stored in `engine-data/tracked-changes-suggestions.md`.

4. **File-write hygiene during Phase B.** Every Edit /
   Write operation on the chapter MD files MUST follow
   `core-pipeline.md` § Chained-Edit Truncation Safeguard:
   - Cap individual Edit replacements at ~2 KB
   - Run `scripts/word-count-check.sh` after every chapter
     file edit
   - Verify on-disk integrity via Bash before declaring
     the per-chapter pass complete

**Phase B HARD GATE:** Cannot proceed to Phase C until:
- Every chapter MD file has matching paragraph count and
  word count against its source-DOCX paragraph range
- The suggestions file exists with all change records
  structured per the schema above
- No chapter MD file is truncated mid-token (no file ends
  in mid-word, mid-sentence, mid-paragraph; the
  word-count-check tail-byte verification confirms this)

### Phase C: DOCX-Write with Integrity Verification (MANDATORY)

Generate the tracked-changes DOCX from the source-archive
DOCX (NOT from the chapter MD files). This is critical: the
DOCX-write phase preserves the source's paragraph structure,
runs, formatting, and page-boundary handling exactly — and
applies the change records from Phase B as Word-compatible
tracked-change markup.

**Steps:**

1. **Open the source archive DOCX** as the base document.
   This guarantees paragraph fidelity — every source
   paragraph is preserved at its original index because we
   never round-trip through MD for the OUTPUT writing.

2. **Apply tracked-change markup per change record.** For
   each entry in `engine-data/tracked-changes-suggestions.md`:
   - Locate the target paragraph by index
   - Locate the target span within the paragraph (character
     offset)
   - Apply the appropriate Word XML markup:
     - Insertion: `<w:ins w:author="Ideorix" w:date="...">`
     - Deletion: `<w:del w:author="Ideorix" w:date="...">`
     - Replacement: deletion + insertion at same offset
     - Format change: `<w:rPrChange>`
   - Preserve all surrounding text, runs, and formatting
     exactly

3. **Write the tracked-changes DOCX** to
   `manuscript/{Title}-tracked-changes.docx` using
   python-docx Document.save() OR direct XML manipulation
   with file copy. Verify the write completed:

   ```bash
   ls -la {project}/manuscript/{Title}-tracked-changes.docx
   ```

4. **Phase C HARD INTEGRITY VERIFICATION (BLOCKING):**

   Open both the source archive DOCX and the output
   tracked-changes DOCX. Compute the following comparisons:

   **a. Paragraph count parity.**
   `paragraph_count(output) == paragraph_count(source)`.
   The output may have more change-tracking spans, but the
   number of paragraphs MUST equal the source. Mismatch =
   paragraph loss. BLOCKING.

   **b. Per-paragraph base-text preservation.** For each
   paragraph index in source, the output's paragraph
   "base text" (text excluding deletion-marked spans, plus
   text outside insertion-marked spans) MUST match the
   source paragraph text byte-for-byte (modulo whitespace
   normalisation if explicitly specified). Compute by:
   - Strip `<w:ins>` and `<w:del>` content from output
     paragraph
   - SHA256 the resulting text
   - Compare against source paragraph SHA256 from Phase A
   - Any mismatch = silent content modification.
     BLOCKING.

   **c. Word count delta sanity.**
   `word_count(output_base) == word_count(source)`. The
   output base-text word count (with insertions excluded
   and deletions included as if not deleted) MUST equal
   source word count exactly. BLOCKING if not.

   **d. High-risk paragraph spot-check.** For every
   paragraph flagged at Phase A as page-boundary-spanning
   or sentence-continuation-risk, verify byte-for-byte
   that the source content survives in the output. Mid-
   sentence cutoffs at page boundaries are the documented
   failure signature; this check is the explicit guard
   against it.

5. **Write the integrity report.** Emit
   `engine-data/reports/tracked-changes-integrity-{YYYY-MM-DD}.md`
   with:

   ```
   # Tracked-Changes Integrity Report — {Title} — {Date}

   ## Source
   - Source path: {original}
   - Source archive: manuscript/{Title}-source-archive.docx
   - Source SHA256: {sha256}
   - Source paragraph count: {N}
   - Source word count: {W}

   ## Output
   - Output path: manuscript/{Title}-tracked-changes.docx
   - Output paragraph count: {N}     ← MUST equal source
   - Output base-text word count: {W} ← MUST equal source
   - Output base-text per-paragraph SHA256 match: {N}/{N}
                                       ← MUST equal source

   ## Changes Applied
   - Total change records: {C}
     - Insertions: {Ci}
     - Deletions: {Cd}
     - Replacements: {Cr}
     - Format changes: {Cf}

   ## High-Risk Paragraphs (page-boundary / sentence-continuation)
   - Total flagged at Phase A: {H}
   - All preserved byte-for-byte in output: YES / NO
     ← MUST be YES

   ## Verdict
   READY FOR DELIVERY / NOT-READY ({reason})
   ```

**Phase C HARD GATE:** The flow MUST NOT report success
until:
- Output paragraph count == source paragraph count
- All source paragraphs are preserved byte-for-byte
  (after stripping change-tracking markup) in the output
- Output base-text word count == source word count
- All high-risk paragraphs flagged at Phase A are
  byte-preserved in output
- Integrity report has been written to engine-data and
  shows verdict "READY FOR DELIVERY"

If ANY of these fails, the verdict is NOT-READY and the
flow MUST surface the specific failure to the user
(paragraph index missing / word count mismatch / SHA256
mismatch on paragraph X) rather than silently shipping a
truncated manuscript.

## Typographic Fidelity (MANDATORY — applies across all three phases)

**Word DOCX files use typographic curly quotes by default**
(U+2018 `'` and U+2019 `'` for single quotes; U+201C `"`
and U+201D `"` for double quotes; en-dashes U+2013 `–`
and em-dashes U+2014 `—`; horizontal ellipsis U+2026 `…`).
When the agent reads source text, these characters are
preserved as their Unicode code points but may render
visually as their ASCII counterparts (`'`, `"`, `-`, `--`,
`...`) in many editors and renderers — making them easy to
mishandle silently.

This is a documented operational failure mode: an editorial
agent reads source text containing `don't` (curly U+2019),
constructs an Edit with `old_string: "don't"` using ASCII
U+0027, and the Edit fails to find the target because the
bytes differ. Or the agent records the suggested text with
straight quotes when the source uses curly, producing
inconsistent typography in the output DOCX. Or the agent
escapes around the quote issue and corrupts the actual
content.

**The fidelity rule binds across all three phases:**

### Phase A — Source typographic capture

When capturing per-paragraph fingerprints (Phase A step 3),
record the source text **byte-faithfully**. Curly quotes,
en-dashes, em-dashes, ellipses, non-breaking spaces, and
any other Unicode-typographic characters MUST be preserved
in the captured paragraph text exactly as they appear in
the source DOCX. The SHA256 fingerprint is computed over
the byte-faithful text — any deviation from source bytes
causes the Phase C integrity check to fail.

The Phase A fingerprint capture also records a typographic
profile per chapter: count of curly-vs-straight single
quotes, count of curly-vs-straight double quotes, count of
en-dashes vs em-dashes vs ASCII hyphens, ellipsis style
(U+2026 vs three-dots `...`). This profile is the reference
Phase C verifies against.

### Phase B — Change records preserve source typography

When editorial agents generate change records:

1. **`original_text` is byte-faithful to source.** The
   change record's `original_text` field MUST contain the
   exact source bytes, including curly quotes / en-dashes /
   smart ellipses. Do NOT mentally normalize to ASCII when
   recording the change.

2. **`suggested_text` matches source's typographic style.**
   If the source paragraph uses curly quotes, the suggested
   replacement uses curly quotes. If the source uses em-
   dashes for parenthetical asides, the suggested
   replacement uses em-dashes. The change record preserves
   the manuscript's existing typographic identity rather
   than introducing inconsistency.

3. **No silent normalization.** If the user has explicitly
   requested quote-style normalization (e.g., "convert all
   straight quotes to curly throughout"), that is a
   separate operation logged as its own change-type record,
   not an implicit side effect of editorial fixes. The
   default is preserve-as-is.

4. **Edit-tool exact-match discipline.** When the agent
   uses the Edit tool on a chapter MD intermediate, the
   `old_string` MUST be copied byte-faithfully from a Read
   tool output of the same file. Do not retype from
   visual memory; the curly-vs-straight distinction is
   invisible in many renderers but Edit fails on byte
   mismatch. If Edit fails to find the target on a passage
   that should obviously exist, suspect typographic
   mismatch and Read the file again to verify the actual
   bytes.

### Phase C — Typographic consistency verification

The Phase C integrity verification adds two typographic
checks alongside the paragraph-count and SHA256 checks:

**e. Typographic-profile preservation.** Compare the
output DOCX's per-chapter typographic profile against the
source's Phase A profile:
- Curly-quote count parity (output ≥ source after
  accounting for insertions; output ≤ source after
  accounting for deletions)
- Em-dash / en-dash / ASCII-hyphen counts within
  expected delta
- Ellipsis-style consistency (no source-uses-U+2026 →
  output-uses-`...` regression)

A typographic-profile drift flags as a NOT-READY blocker.
The integrity report names the specific drift (e.g.,
"Chapter 7: source has 23 curly apostrophes, output has
18 — 5 dropped or replaced with straight"). The user
sees the specific failure rather than discovering it
later by reading line-by-line.

**f. Insertion typography matches surrounding context.**
For each insertion in the change records, verify the
inserted text's typographic style matches the surrounding
paragraph (curly-quotes inserted into curly-quote prose;
straight-quotes inserted into straight-quote prose if
source is straight). Drift flags as NOT-READY.

**g. Typography Sweep on output DOCX (MANDATORY).**
After Phase C writes the output DOCX, run
`scripts/typography-sweep.sh` against the output file. The
sweep enforces uniformity for the full document: any ASCII
apostrophe, ASCII double quote, double-hyphen, or three-
dot ellipsis in narrative prose flags as a typographic
artifact. If the source profile is curly-target (default)
and the output contains ASCII artifacts, the sweep exits
1 and the integrity check FAILS — the user is shown the
artifact list with line numbers before the DOCX is
released. See `typography-sweep.md` for the full spec.

```sh
bash scripts/typography-sweep.sh {project}/manuscript/{Title}-tracked.docx
```

## Anti-patterns this protocol prevents

The protocol's three-phase + integrity-verification design
is structured around the documented failure modes:

1. **Silent paragraph drop at page boundaries** — the
   classic "2-3 sentences missing, mid-sentence cutoff at
   bottom of page" failure. Phase C-d's high-risk
   paragraph spot-check catches this explicitly. Phase C-a
   (paragraph count parity) catches it as a count
   mismatch.

2. **Mid-token truncation during chapter-MD intermediate
   editing** — the chained-Edit truncation failure mode
   (see `core-pipeline.md` § Chained-Edit Truncation
   Safeguard). Phase B integrates the existing safeguard
   per chapter file. Phase C verifies the MD didn't lose
   content vs source.

3. **DOCX round-trip parsing artifacts** — Phase A's
   byte-identical archive (via `cp`, NOT round-trip)
   ensures the source is never corrupted by parser bugs
   in python-docx or any DOCX-handling library. Phase C
   writes from the archive, preserving source structure.

4. **Format / run / paragraph-style loss** — Phase C
   writes from the source archive rather than rebuilding
   from MD, so paragraph styles, run formatting, page
   layouts, headers/footers, footnotes, and other DOCX
   features are preserved by inheritance from the source.

5. **Defer-to-user verification** — the integrity report
   is a deliverable, not an aspiration. The flow's
   success verdict requires the integrity check to pass;
   the user receives the report alongside the DOCX so they
   know the engine has structurally verified content
   preservation, rather than being told "looks good, you
   should spot-check."

6. **Typographic mismatch on quotes / dashes / ellipses** —
   the documented Mitch-curly-quote failure mode. Source
   DOCX uses U+2019 curly apostrophe; agent reads it as
   "looks like an apostrophe" and constructs Edit calls
   with U+0027 ASCII straight apostrophe; Edit silently
   fails to find the target OR succeeds with corrupted
   content. The Typographic Fidelity rules at all three
   phases catch this: byte-faithful capture at Phase A,
   byte-faithful change records at Phase B, profile
   verification at Phase C.

## Implementation notes

- DOCX parsing/writing should use a documented stable
  library (python-docx, docx2txt for read-only, or direct
  ZIP+XML manipulation). Whichever is chosen, the SAME
  library MUST be used for Phase A read and Phase C write
  to ensure consistency.
- The source archive at Phase A is bit-perfect (`cp`),
  not parsed-and-rewritten. This guarantees Phase C can
  always start from a clean known-good source even if
  the parsing library has limitations.
- python-docx does not natively support Word's tracked-
  change XML elements (`<w:ins>`, `<w:del>`, etc.). The
  agent will need to manipulate the underlying XML
  directly (via lxml or python-docx's element access) to
  emit valid Word-compatible tracked changes.
- The integrity check at Phase C SHOULD be implemented
  as a callable subroutine so it can be invoked
  separately for spot-checking after the fact (e.g., if
  the user reports a possible drop, re-run the integrity
  check against the archived source).

## See also

- `core-pipeline.md` § Chained-Edit Truncation Safeguard
  — the upstream file-write hygiene protocol that Phase B
  integrates
- `core-pipeline.md` § File Location Discipline — the
  canonical project folder structure these outputs land in
- `editorial-suite.md` Stage 8 — the editorial-suite stage
  that invokes this protocol when in tracked-changes mode
- `edit-and-revise.md` — the entry point spec that routes
  to tracked-changes when the user asks for it
- `verification-discipline.md` — the parallel discipline
  for verification (this protocol is the parallel for
  source-content preservation)

## Mirroring

This file is in the cross-engine mirror set (see
`scripts/spec-lint.sh` Check 7). When editing this file,
edit one engine's copy, `cp` to the other, `diff -q` both
to verify byte-identity, then run `scripts/spec-lint.sh`
to confirm Check 7 passes.
