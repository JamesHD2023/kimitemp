---
name: magical-realism-genre
description: Genre-specific instructions for magical realism fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Magical Realism. Genre Plugin

## Metadata
- id: magical-realism
- name: Magical Realism
- icon: ✨
- category: Fiction
- minWords: 3500
- targetWords: "4,000-4,500"
- recommendedBeatStructures: ["Freytag's Pyramid", "Story Circle", "Three-Act Structure"]

## Subgenre Options
Present during setup:
- **Latin American Magical Realism**. The foundational tradition: García Márquez, Allende, Borges; magic woven into the fabric of post-colonial life, history, and community; the genre's deepest roots
- **African/Diaspora Magical Realism**. Magic in the African and diaspora experience: Ben Okri, Toni Morrison; ancestral memory, spirits, the supernatural as resistance to historical violence
- **Asian Magical Realism**. East and South Asian traditions: Murakami, Rushdie, Tan; cultural mythology, ancestral connection, the impossible made domestic
- **European Magical Realism**. Kafka, Saramago, Bulgakov; bureaucratic absurdity, philosophical impossibility, magic as metaphor for the human condition
- **Contemporary Global Magical Realism**. Modern, multicultural settings: magic in immigrant experience, diaspora identity, the collision of cultural worlds
- **Southern Gothic Magical Realism**. American South: ghosts, the land's memory, the weight of history made literal; where magical realism meets Gothic tradition

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,500-4,500 words
- Pacing: Measured, dreamlike. magic unfolds naturally without urgency to explain; the rhythm of life with the impossible woven in
- Must open with: Grounded reality with a hint of impossibility, or a magical element presented as utterly mundane. "It rained fish that Tuesday"

BEATS PER CHAPTER
1. Realistic Grounding. Specific, detailed real-world setting: culture, place, daily life vivid and particular; the reader must smell the food and hear the language
2. Magical Intrusion. An impossible element appears, treated as ordinary by characters; no fanfare, no explanation, no wonder
3. Blurred Boundary. Uncertainty whether the event is magical, metaphorical, or psychological; the ambiguity IS the genre
4. Cultural/Historical Resonance. Magic connects to identity, history, colonialism, tradition; the impossible carries the weight of the real
5. Acceptance Without Explanation. Characters react to magic practically, never questioning the impossibility; magic is weather

★ NON-NEGOTIABLE GENRE RULES ★

ZERO CHARACTER AMAZEMENT AT MAGIC:
- Characters must NEVER show surprise, wonder, curiosity, or investigation of magical events
- Magic is treated like weather. acknowledged, worked around, never marvelled at
- "She noted the flying children and returned to her sewing" = CORRECT
- "He stepped around the ghost to reach the kitchen" = CORRECT
- "She stared in wonder as..." = FORBIDDEN
- "How is this possible?" = FORBIDDEN

MANDATORY CULTURAL SPECIFICITY:
- Generic settings are automatic failures
- Every chapter needs: named town/neighbourhood, culturally specific food/rituals/language, historical context tied to that exact place
- "A small village" or "a coastal town" = REWRITE REQUIRED
- "The fishing village of São Tomé" or "the market at Calle Bolívar" = CORRECT

MANDATORY TIME FLUIDITY:
- Past and present MUST bleed together
- Grandmother's memory interrupting present scene, tense shifting mid-paragraph, dead conversing with living in present tense, future shadowing backward
- A chapter staying entirely in a single timeline = GENRE VIOLATION
- At least 2 temporal blendings per chapter required

NARRATIVE LAYERS (all three present in every chapter):
- Layer A (Mundane reality): daily life, cultural routines, family dynamics, historical events
- Layer B (Magical reality): impossible events accepted as ordinary, prophecy, ghosts, transformation
- Layer C (Symbolic/political): colonialism, oppression, cultural memory, generational trauma

FRACTAL STRUCTURE:
- Novel level: reality established → magic intrudes → boundaries blur → ambiguity deepened → transformed understanding
- Chapter level: grounded moment → impossible event (treated as normal) → meaning accumulates
- Scene level: specific detail → magical detail (same tone, same weight) → both equally true

FORBIDDEN IN MAGICAL REALISM
- Explaining magic (no "how it works" or origin stories)
- Characters shocked by magic (treated as they would weather or hunger)
- Fantasy world-building (this is OUR world with magical intrusions)
- Urban fantasy tropes (no hidden magical society, chosen one, or magic rules)
- Whimsical or cute magic (tone serious even when events impossible)
- Pure allegory (magic both literal AND symbolic, not just metaphor)
- Western fantasy conventions (this isn't Tolkien with a different setting)
- Generic settings (specificity is the genre's foundation)
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (the strangeness is part of the engine), Captivation, Affection, Revelation at thematic core.

VOICE & TONE
- POV: Third person limited or omniscient (distance allows matter-of-fact magic) or first person (intimate acceptance)
- Tense: Past (traditional, allows mythic distance) with mandatory present-tense intrusions for temporal fluidity
- Voice: Matter-of-fact about impossibility, lyrical but grounded, culturally specific; the voice never draws attention to the magic
- Register: Adult literary. sophisticated blending of real and magical; the prose treats both with equal seriousness

PROSE IMPERATIVES
- MAGIC AS MUNDANE: describe the impossible with the same verbs as the ordinary
  - "She flew" not "she impossibly rose" or "she seemed to fly"
  - The sensory details of magic: what it smells, sounds, weighs, tastes like. specific and grounded
  - No hedging: state magic as fact, never as simile or seeming
  - Magic described as casually as weather: "It rained fish that Tuesday". same tone as "It rained heavily that Tuesday"
- CULTURAL SPECIFICITY IN LANGUAGE: the world is rendered through its own idioms
  - Concrete cultural markers: "arepas" not "bread," "the Orinoco" not "the river," "Día de los Muertos" not "the holiday"
  - Local idioms, expressions, and speech patterns embedded naturally
  - Food prepared and eaten specifically: named dishes, particular ingredients, regional preparations
  - Architecture, dress, music, worship. all culturally exact
- TIME FLUIDITY IN PROSE: the temporal is always shifting
  - Past tense shifts to present for emotional intensity. mid-paragraph, mid-sentence
  - Grandmother's story becomes granddaughter's seamlessly: no transition, no section break
  - Historical events bleed into the current moment: the war of 1952 is happening NOW in the grandmother's telling
  - Dead relatives converse in present tense: they are here, they never left
- THE EMOTIONAL RHYTHM: build → sustain → release → recover
  - Build: accumulate ordinary details until the magical feels inevitable
  - Sustain: hold magic and reality in the same breath. no transition, no contrast, just coexistence
  - Release: through image or event that is simultaneously real and impossible
  - Recover: return to mundane detail that now carries new weight

PROSE MASTERCLASS EXAMPLES:
- Magic as reported fact: "She ascended at twilight, as her mother had. The neighbors closed their shutters. not from fear, but because the light she gave off was hard on the eyes, and the telenovela was starting."
- Time fluidity: "She stirred the pot as her grandmother had in 1943, the war years when sugar was scarce, and now Eliza stirred the same pot with the same wooden spoon that had outlived them both, and the ghost of Uncle Marcus sat in his corner chair and said the soup needed salt."
- Cultural grounding: "He wept emeralds until morning, and by Tuesday the jeweler on Calle Bolívar had appraised them at forty thousand pesos, enough to repair the roof the hurricane of '52 had damaged."

DIALOGUE CRAFT
- Characters discuss magic practically: "Your grandmother is in the garden" (the grandmother has been dead for twenty years. no one comments on this)
- Gossip carries the magical: the neighbourhood discusses impossible events the same way they discuss scandals
- Generational voices: grandmother's speech carries the rhythm of an older world; the child's voice is modern; both accept magic equally
- The dead speak: dialogue with ghosts is conversational, not dramatic. they have opinions, complaints, recipes

FORBIDDEN WORDS/PHRASES
- "Impossibly," "magically," "miraculously". do not flag magic as extraordinary
- "Stared in wonder," "couldn't believe," "gasped at," "marvelled at," "eyes widened"
- "How is this possible," "tried to understand," "sought an explanation"
- "As if" or "seemed to" before magical events. magic IS, it doesn't "seem"
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. MAGICAL REALISM

OPENING: The magical treated as ordinary. no fanfare. A culturally specific world
with the impossible already woven in. The reader cannot identify the moment prose
"becomes" magical. it simply IS. Magic has always been here.

SENTENCES: Medium-long flowing, 18-28 words average. Accretive rhythm: building,
layering, accumulating the way memory does. Longer (30-40) for generational passages.
Shorter (8-14) for grounding: food, weather, tasks. Magical events in the SAME
rhythm as mundane. no shift in register, energy, or tempo.

VOCABULARY: Culturally specific. "arepas" not "bread," "the Orinoco" not "the
river." Magic described with physical verbs: "She flew" (never "seemed to fly").
NO hedging: no "as if," no "impossibly." Sensory detail for the magical: what it
smells, weighs, tastes like. ZERO amazement words: no "gasped," "stared in wonder."

TENSION FLOOR: ≥4. Tension from human relationships and family secrets. not from
magic itself. The past pressing on the present: generational wounds, unresolved
history. Magic carries practical consequences. Ambiguity IS tension. Political/
historical undertow: colonialism, displacement, cultural loss.

RHYTHM: Open with a culturally specific moment (place named, practice rendered).
Layer magic within the SAME sentence. no separate introduction. Time already fluid:
present bleeding into memory. Dialogue with the dead is domestic conversation. Close
with an image simultaneously real and impossible. prose makes no distinction.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

MAGICAL REALISM CRAFT (40% of total):
- Zero character amazement at magic (treated as mundane throughout)? (0-100)
- Cultural specificity present (named places, foods, customs, history)? (0-100)
- Time fluidity operating (past/present bleed, multiple timelines woven)? (0-100)
- Ambiguity maintained (magic both literal and symbolic, never fully explained)? (0-100)

STORY CRAFT (30% of total):
- All three narrative layers present (mundane, magical, symbolic/political)? (0-100)
- Magic carries thematic weight (not decorative but meaningful)? (0-100)
- Generational scope visible (history, memory, inheritance)? (0-100)
- Characters human and specific despite magical elements? (0-100)

PROSE QUALITY (30% of total):
- Magic described with same verbs and tone as ordinary events? (0-100)
- Cultural markers concrete and specific (named foods, places, customs)? (0-100)
- Temporal shifts executed within prose (not section breaks)? (0-100)
- Lyrical but grounded (beauty without losing physical reality)? (0-100)

AUTOMATIC FAILS (score = 0):
- Characters express wonder, surprise, or investigation at magic
- Generic settings ("a village," "a coastal town" without specificity)
- Chapter stays in single timeline without temporal blending
- Magic explained (origin stories, rules, systems)
- Fantasy/urban fantasy tropes (chosen ones, magical societies, magic systems)
- Pure allegory (magic only metaphorical, never literal)
- Hedging language ("seemed to fly," "as if she were floating")
- Whimsical or cute tone (magical realism is serious, even when impossible)
```

## Continuity Rules

```
MAGICAL REALISM CONTINUITY. WHAT TO TRACK

MAGICAL STATE:
- What magical events have occurred and their practical consequences
- How characters adapted to magical intrusions (always practically, never with wonder)
- The dead: which deceased characters are present, where they appear, what they want
- Prophecies: what's been foretold and what's been fulfilled (treated as practical information)
- Transformations: who or what has changed and whether the change persists

CULTURAL STATE:
- Setting specifics: the named town, its geography, its industries, its social hierarchy
- Cultural calendar: festivals, seasons, religious observances, market days
- Food and daily life: what's being prepared, eaten, celebrated. tracked for consistency
- Historical events referenced: dates, names, consequences. must remain consistent
- Language and idiom: regional expressions, family sayings, cultural references

TEMPORAL STATE:
- Which timelines have been visited: present, specific past periods, ancestral memory
- The dead's timeline: when they died, what they knew, what they want from the living
- Generational connections: which grandmother's story connects to which grandchild's experience
- Historical accuracy: dates and events referenced must be consistent across temporal shifts

FAMILY STATE:
- The family tree: who's alive, who's dead, who's present despite being dead
- Generational patterns: gifts, curses, habits, recipes, objects passed down
- Family mythology: the stories told about the family vs. what actually happened
- Objects: significant items tracked across generations (the wooden spoon, the house, the recipe)

THE AMBIGUITY BALANCE:
- Which events are clearly magical, which are ambiguous, which might be psychological
- The balance should be maintained: never fully explained, never fully dismissed
- Reader's certainty level: should fluctuate, never settle
```

## Character Rules

```
MAGICAL REALISM CHARACTER TYPES

THE MATRIARCH/PATRIARCH:
- The keeper of memory: they carry the family's stories, which are also the culture's stories
- Their relationship with the dead is the most established: grandmothers who chat with their own grandmothers
- They accept magic most completely: it's been part of their world longest
- Their stories contain both truth and myth. and in magical realism, these are the same thing
- They represent continuity: the thread from the past to the present

THE INHERITOR:
- A younger character who receives the family's magical legacy: a gift, a curse, a sensitivity
- They may resist, accept, or simply live with their inheritance
- Their relationship to the magic reflects their relationship to their culture: embrace, conflict, or negotiation
- They're the bridge between the old world and the new

THE PRACTICAL PRAGMATIST:
- A character who accepts magic with complete matter-of-factness
- They work around the impossible: "The roof leaks and the ghost needs feeding. which do we fix first?"
- They represent the genre's core attitude: magic is real, life continues, dinner must be made
- Their pragmatism IS the genre's voice

THE GHOST:
- Not a horror element but a family member: dead but present, opinionated, sometimes helpful
- They have the concerns of the living: the soup needs salt, the grandchild should marry, the roof needs repair
- Their presence is NEVER scary. it's domestic, comfortable, ordinary
- They carry information from the past that the living need

THE OUTSIDER:
- Someone from outside the culture or family who encounters the magic
- They may be the only character who notices the impossibility (but even they adjust quickly)
- Their perspective creates brief contrast. then they, too, accept
- They represent the reader's journey: from disbelief to acceptance

VOICE DIFFERENTIATION:
- The matriarch: rhythmic, story-telling, mixing timelines naturally, the cadence of oral tradition
- The inheritor: modern but carrying echoes of the ancestral voice
- The pragmatist: direct, practical, unimpressed by the miraculous
- The ghost: speaks in their era's language, may confuse past and present (because for them, it's the same)
```

## Arc Rules

```
MAGICAL REALISM STORY STRUCTURE

ACT 1: THE WORLD AS IT IS (first 25%)
- The setting rendered with cultural specificity: this place, this family, this particular daily life
- Magic is ALREADY present: it doesn't arrive. it's been here all along
- The family and community established: who lives, who has died, who refuses to leave despite being dead
- The inciting incident: a change that disrupts the balance. a death, a return, a birth, a political upheaval
- END OF ACT 1: The disruption has activated the magical dimension. the past begins insisting on the present

ACT 2A: THE BLURRING (to midpoint)
- Magic intensifies: more impossible events, treated with the same mundanity
- The past becomes more present: generational stories demand to be heard, the dead become more insistent
- Cultural history surfaces: the specific historical events (colonialism, revolution, displacement) that created this present
- The ambiguity deepens: the reader is less certain what's real and what's magical (and the characters don't distinguish)
- MIDPOINT: A magical event with profound practical consequences. the impossible changes something real; or a historical truth is revealed through magical means

ACT 2B: THE CONVERGENCE (midpoint to dark moment)
- Past and present are barely distinguishable: temporal fluidity at its most intense
- The family's mythology confronts its reality: the stories they tell vs. what actually happened
- Magic becomes both more prevalent and more ambiguous: is the grandmother really here, or is this grief made visible?
- The cultural/political layer demands attention: the historical wound that won't heal because it hasn't been acknowledged
- DARK MOMENT: The magic reveals a truth that changes the family's understanding of itself. the comfortable mythology is shattered

ACT 3: THE TRANSFORMED UNDERSTANDING (final 25%)
- The family/community integrates the truth: not resolution but acceptance
- The dead and the living reach an understanding (or the dead are released, or they choose to stay)
- The cultural wound is acknowledged if not healed: magical realism doesn't offer neat resolution
- Magic continues: the world has not become ordinary; it was always extraordinary; the characters simply see it more clearly
- The ending: the world goes on, enchanted and real simultaneously; life continues with the impossible woven in

MAGICAL REALISM PACING:
- Measured and flowing: the pace matches the culture's rhythm (not Western thriller pacing)
- Scenes breathe: descriptions are rich, conversations meander, daily life is given its full weight
- The pace doesn't so much accelerate as DEEPEN: each chapter adds layers rather than speed
- The climax is often quiet: a conversation, a realisation, a letting go. not an explosion
```

## Timeline Rules

```
MAGICAL REALISM TIMELINE

TEMPORAL FLUIDITY:
- Time is NOT linear: past, present, and future coexist in every chapter
- The dead don't observe temporal boundaries: they appear in the present, reference the past, sometimes know the future
- Generational time: the grandmother's experience IS the granddaughter's, separated by decades but connected by blood, place, and magic
- Historical time: specific historical events (dates, names, consequences) must be accurate when referenced

CULTURAL CALENDAR:
- Festivals, saints' days, harvest times, market days create rhythm
- Seasonal changes tied to specific cultural practices
- Religious and secular observances mark the passage of time
- Family occasions: births, deaths, marriages, returns. the personal calendar

THE DEAD'S TIMELINE:
- When they died and what they knew at death
- Their relationship to time: they may experience all times simultaneously
- What draws them to the present: an anniversary, a descendant in need, a wrong to be righted
- Whether they're fading, strengthening, or constant
```

## Genre-Specific Craft Techniques

Magical realism is the literary-speculative register that
treats the impossible as ordinary, distinguishing itself from
fantasy (which builds magical systems with internal logic
the reader engages with) and literary fiction (which
typically operates in realist register without magical
elements) by holding magical events alongside realistic ones
without distinguishing them in tone, texture, or character
response. The form's classical home is in Latin American
literary tradition (the term *realismo mágico* itself comes
from this body of work), but contemporary practice extends
across diaspora and global literatures, with the form often
carrying specific political weight tied to its specific
cultural and historical contexts. The cluster includes
Latin American magical realism (the foundational tradition),
diasporic magical realism, African magical realism, Asian
magical realism (sometimes overlapping with literary
mythopoeic registers), Indigenous magical realism, the
literary-fabulist register that operates in adjacent space.
Comp authors span the canonical lineage (Gabriel García
Márquez's *One Hundred Years of Solitude* and *Love in the
Time of Cholera*, Isabel Allende's *The House of the
Spirits*, Julio Cortázar, Jorge Luis Borges on the adjacent
fabulist register, Carlos Fuentes, Laura Esquivel's *Like
Water for Chocolate*, Toni Morrison's *Beloved* and *Song of
Solomon*, Salman Rushdie's *Midnight's Children*, Angela
Carter's adjacent magical-fabulist work) through the
contemporary expansion (Karen Russell's *Swamplandia* and
*Orange World*, Carmen Maria Machado's *Her Body and Other
Parties*, Helen Oyeyemi's *Mr Fox* and *White Is for
Witching*, Jesmyn Ward's *Sing, Unburied, Sing*, Yaa Gyasi's
*Homegoing*, Ben Okri's *The Famished Road*, Akwaeke Emezi's
*Freshwater*, Tayari Jones, Téa Obreht's *The Tiger's Wife*,
Imbolo Mbue, Marlon James, Ocean Vuong, Rivers Solomon,
Tomi Adeyemi at the YA crossover edge, Silvia Moreno-Garcia,
Isabel Cañas, Erin Morgenstern's *The Night Circus* on the
literary-fantasy edge, Karen Joy Fowler, Kelly Link, George
Saunders at the literary-fabulist register). The techniques
below are how the form delivers its core pleasures while
avoiding the failure modes (fantasy-with-realist-aesthetic
that builds magical systems despite the form's specific
refusal to do so; magical-element-as-decoration where the
impossible appears once and is forgotten; cultural-tourism
register where Western writers borrow Latin American or
diasporic conventions without specific cultural grounding;
amazement-rupture where any character at any point treats
the magical as remarkable, breaking the form's signature
contract).

### The Matter-of-Fact Miracle

The impossible presented with domestic normalcy:

```
"The baby was born with wings. Small ones,
like a finch's, folded neatly against her
shoulder blades. The midwife, who had seen
stranger things in forty years of practice,
wrapped her in the yellow blanket her
grandmother had crocheted and said she would
need to make the sleepholes wider. She
charged the usual fee."

The miracle is real. The response is practical.
The genre lives in the gap between the two.
```

### The Generational Echo

The past and present are the same story:

```
"Abuela was seventeen when the soldiers came,
and she hid in the mango tree for three days,
and now Rosa is seventeen and hiding from
something she cannot name, cannot see, but
feels in her bones the way Abuela felt the
soldiers' boots on the road. the tremor that
travels through the earth and the blood and
the years and arrives in a girl's hands as
a trembling she calls anxiety but is really
memory, is really the tree, is really 1952
happening again as it has never stopped
happening in this family."

One sentence. Three timelines. One truth.
The generational echo IS the genre.
```

### The Practical Ghost

The dead treated as household members:

```
"'The soup needs salt,' said Uncle Marcos,
who had been dead for eleven years but
still preferred the corner chair and still
had opinions about cooking. Elena added
salt. She added more when he raised an
eyebrow. She did not find this unusual.
Marcos had always been particular about
soup, alive or otherwise."

The dead are not frightening. They're
family. They have preferences. They
criticise the cooking.
```

### Magical Realism AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "magic existed in the everyday" | Show the specific magical moment in the specific mundane setting |
| "the boundary between real and magical dissolved" | Show the specific dissolution |
| "the magical was treated as ordinary" | Show the specific matter-of-fact magical detail |
| "the world was more than it appeared" | Show the specific hidden layer |
| "reality bent" | Show the specific bending. time, space, physics |
| "the ordinary became extraordinary" | Show the specific transformation |
| "magic was woven into the fabric of life" | Show ONE specific magical daily practice |
| "the impossible happened. and nobody remarked on it" | Show the specific impossible event and specific casual reaction |
| "a heightened reality" | Show the specific heightened detail |
| "the metaphor became literal" | Show the specific literalisation |
| "she felt the spirits of her ancestors" | Cut the gestural; show the specific ancestor doing the specific thing in the specific moment |
| "the village had its own magic" | Cut "had its own magic"; show the specific local practice the village considers ordinary |
| "the old woman knew things she shouldn't" | Show ONE specific thing she knows and how the family relates to her knowing it |
| "stories took on lives of their own" | Show ONE specific story doing ONE specific thing in scene |
| "the dreams felt real" | Cut hedging; show the specific dream and its specific consequence with no quotes around "real" |
| "ancestors watched over them" | Show ONE specific ancestor doing ONE specific thing for ONE specific descendant in this specific scene |
| "the magic of the place" | Cut; show ONE specific feature the local community treats as ordinary |
| "she had a gift" | Name the specific gift through the specific scene where it operates |

### The Refused Explanation

Magical realism's signature structural discipline: the form
specifically refuses the magical-system explanations that
fantasy requires. The strongest magical realism never
explains where the magic comes from, what its rules are,
who can do it and who cannot, what its costs and
limitations are. The refused explanation IS the form. The
moment the manuscript begins to systematise — establishing
that "the women in our family can do this because" or "the
ghost only appears when" — the form has slipped into
fantasy register and lost its distinctive contract.

The technique requires sustained refusal. Generic "she
inherited the gift from her grandmother" provides exactly
the kind of magical-system explanation the form excludes.
Specific behavioural rendering without explanation is the
technique: the protagonist does the thing; the family
treats it as familiar; the prose neither asks nor answers
how. The reader's certainty about what is real and what is
not is intentionally destabilised; the form's signature
emotional register is the productive uncertainty the
refused explanation produces.

The technique extends to cause-and-effect. Fantasy operates
on causal logic: this magical event happened because this
condition was met. Magical realism operates on
juxtaposition: this magical event happened, and this
mundane event happened, and the relationship between them
is for the reader to feel rather than for the prose to
articulate. Generic "she was so sad that the rain came" is
the failure mode (prose articulating cause); specific
"she sat by the window and the rain started and her aunt
brought tea" is the technique (prose juxtaposing without
explaining).

Test: identify the manuscript's magical events and ask, in
each, whether the manuscript at any point explains how, why,
or by what mechanism. If explanations exist, the discipline
has slipped; if events are rendered without origin stories
or systems, the form is operating.

### The Cultural Specificity Imperative

Magical realism is unusually culturally rooted. The form's
classic register emerges from specific Latin American
literary, political, and cultural traditions; contemporary
practice extends across diaspora and global literatures,
but always with specific cultural grounding rather than as
generic literary register. The form's most-flagged
contemporary craft failure is cultural-tourism magical
realism — Western writers borrowing the conventions
without the specific cultural and political contexts that
gave the form its weight.

The technique requires specific cultural grounding:

- **Specific named place** — not "the village" or "the town"
  but the specific named location with its specific
  geography, specific history, specific relationship to
  larger political and economic forces. The village in
  *One Hundred Years of Solitude* is Macondo; the
  manuscript's village should be similarly named and
  specifically rendered.
- **Specific cultural texture** — named foods, named
  festivals, named historical events the community
  remembers, specific religious or spiritual practices,
  specific kinship structures, specific class formations.
  Generic "exotic Latin American village" treatment is the
  failure mode; specific Colombian or Mexican or
  Argentinian or specifically diasporic-Cuban or
  specifically Nigerian-Igbo cultural rendering is the
  technique.
- **Specific historical context** — magical realism is
  often deeply political. The civil wars and dictatorships
  of Latin American history shape the form's classic
  register; the specific colonial and postcolonial reality
  of the writer's diaspora context shapes contemporary
  practice; the specific historical violence the
  manuscript is reckoning with should be on the page.
- **Specific linguistic texture** — the prose should
  register specific cultural vocabulary, idiom, rhythm.
  This need not require untranslated Spanish or other
  source-language terms (though it can), but the prose's
  English should bear the specific cultural inflection
  that distinguishes the manuscript from generic literary
  English.

The technique fails when magical realism is treated as a
neutral literary mode that any writer can deploy without
specific cultural grounding. The form's strongest
contemporary practitioners (Allende, Morrison, Rushdie,
Karen Russell on her specifically-Florida register, Helen
Oyeyemi on her specifically-British-Nigerian register,
Jesmyn Ward on her specifically-Mississippi register, Ben
Okri on his specifically-Nigerian register, Marlon James
on his specifically-Jamaican register) ground the form in
specific cultural and political reality.

Test: identify the manuscript's cultural setting and audit
the rendering for specificity. Is the place named and
specific? Are cultural markers concrete? Is historical
context specific? Does the prose carry specific cultural
inflection? If renderings are generic, the cultural
grounding has not been deployed.

### The Three-Layer Coexistence

Magical realism's signature structural complexity: the form
holds three registers simultaneously. The mundane (daily
life, cultural routines, ordinary human events); the
magical (impossible events treated as ordinary); and the
symbolic-or-political (the historical, social, or
metaphorical weight the magical events carry). The
strongest magical realism makes all three operate at once
without one overwhelming the others.

The discipline requires:

- **Layer A — Mundane reality** — the daily texture of
  ordinary life: cooking, working, family dynamics,
  weather, illness, age, marriage, money. This layer
  grounds the form; without it, the magical floats and
  the symbolic becomes allegory.
- **Layer B — Magical reality** — the impossible treated
  as ordinary: the dead at the dinner table, the baby
  with wings, the village where it has rained for four
  years. This layer is the form's distinctive register;
  without it, the manuscript is literary fiction.
- **Layer C — Symbolic/political reality** — the
  historical, social, metaphorical weight the magical
  carries. The dead at the dinner table are also the
  community's dead from the political violence; the baby
  with wings is also the family's specific exceptional
  child whose specificity the larger society cannot
  accommodate; the four-year rain is also the long
  weight of accumulated suffering. Without this layer,
  the magic is decoration; with it, the magic carries
  meaning.

The technique requires that all three layers be present in
significant scenes, not separated into different chapters
or different registers. The form's most-flagged failure
mode is the manuscript that alternates between mundane
chapters, magical chapters, and political chapters
without the three operating simultaneously. The strongest
magical realism makes a single sentence carry all three
registers.

Test: pick three significant scenes and verify each contains
all three layers operating at once. If scenes are separated
by register, the coexistence has not been deployed.

## Genre-Specific Revision Rules

Six revision passes specific to magical realism, each with a
focused question, run cover-to-cover before the next begins.
Magical realism revision must hold the form's signature
contracts: zero amazement (the matter-of-fact register
sustained); cultural specificity (specific cultural
grounding rather than generic literary register); time
fluidity (the form's distinctive temporal blending); three-
layer coexistence (mundane / magical / symbolic-political);
ambiguity (magic both literal and symbolic, with reader
certainty intentionally unstable); and the refused-
explanation discipline that distinguishes the form from
fantasy. The passes below are ordered to surface amazement
and cultural-specificity failures first (the form's most-
felt by genre readers), time-fluidity and three-layer
audits next, ambiguity and refused-explanation last as
integrative final checks.

### Pass 1: Zero Amazement Check

Verify NO character expresses surprise, wonder, or
investigation at magical events. The form's signature
structural contract is that the magical is treated as
ordinary by ALL characters, not just the protagonist. The
moment any character — main, secondary, walk-on — registers
amazement at the magical, the form's contract has been
broken. Scan the manuscript for amazement-words: stared,
gasped, marvelled, wondered, asked how, couldn't believe,
was astonished, was amazed, in awe, in wonder.

Verify forbidden phrases are absent. Generic literary-
fiction reactions to the impossible — "stared in wonder",
"how is this possible", "she could hardly believe her eyes"
— are the form's specific exclusion. The strongest magical
realism never deploys these phrases; characters absorb
magical events the way they absorb weather.

Verify magic is treated with the same vocabulary and tone as
mundane events. Test sentence-level: pick three sentences
that contain magical content and three that contain mundane
content. Do they operate in the same prose register? If
the magical sentences shift to elevated, awe-struck, or
hedged register, the matter-of-fact contract has slipped.

Verify hedging language is absent. "Seemed to", "as if",
"almost", "looked like", "appeared to" — these are the
form's specific failure mode at the sentence level. Magical
realism asserts; it does not hedge. The dead are at the
table; they don't "seem to be" at the table. The baby has
wings; they don't "appear to be" wings. Test: search the
manuscript for these hedging phrases in proximity to magical
content and verify each is intentional rather than default.

### Pass 2: Cultural Specificity Check

Verify the setting is named and specific. Magical realism
is deeply place-rooted; generic "village" or "town" is the
failure mode. The setting should be named (Macondo, the
specific Colombian town, the specific Mexican border city,
the specific neighbourhood in Lagos) and specifically
rendered with its specific geography, history, and place
in larger political and economic forces.

Verify cultural markers are concrete. Named foods, named
festivals, named historical events, specific religious or
spiritual practices, specific kinship structures. The Cultural
Specificity Imperative technique provides the framework. Generic
"the village had its traditions" is the failure mode; specific
named tradition with specific operational detail is the
technique.

Verify the language is culturally grounded. The prose should
carry specific cultural inflection — idioms, expressions,
regional speech rhythms, occasional source-language
vocabulary where appropriate (Spanish in Latin American
register, Yoruba in West African register, etc.). Generic
literary English without cultural inflection is the failure
mode for magical realism specifically; the form expects
its English to bear the specific cultural mark.

Verify historical context is specific and accurate. Magical
realism is often deeply political — the civil wars and
dictatorships of Latin American history; the specific
colonial and postcolonial realities of diaspora contexts;
the specific historical violence the manuscript is
reckoning with. Generic "the country was torn by
violence" is the failure mode; specific named historical
period with specific named events and specific operational
reality is the technique.

### Pass 3: Time Fluidity Check

Verify the chapter includes at least 2 temporal blendings.
Magical realism's distinctive temporal craft: past, present,
and sometimes future operate as if simultaneous, with the
prose moving between them without conventional breaks. A
chapter that maintains a single conventional timeline has
operated in adjacent register; a chapter that blends times
operates in the form.

Verify the chapter is not confined to a single timeline.
The form's signature structural pressure is that ancestors,
descendants, and present characters often operate in the
same prose, with the boundaries between their times
intentionally permeable. The strongest magical realism
makes the past not just remembered but present — the
grandmother's day in 1952 and the granddaughter's day in
2024 happening as the same day in the same prose.

Verify tense shifts occur naturally within prose, not just
at section breaks. The form's prose can shift from past to
present tense within a sentence, with the shift reproducing
the temporal blending the form depicts. Generic "she
remembered the day" followed by past-tense recollection is
literary fiction's register; "she sat by the window and her
grandmother is sitting in the chair beside her, the chair
that has been empty for forty years, and they are talking
about the rain" is the form's register.

Verify the dead converse in present tense where appropriate.
The Practical Ghost technique requires that ancestors be
treated as present rather than as memories. The grandmother
who died in 1962 doesn't "would have said" or "always
used to say"; she "says". The form's prose grants the dead
present-tense agency in scenes they participate in.

### Pass 4: Three-Layer Check

Verify all three layers are present and coexisting. The
Three-Layer Coexistence technique requires that significant
scenes operate in mundane, magical, AND symbolic-political
registers simultaneously. Audit the manuscript and identify
each layer in significant scenes.

- **Layer A (Mundane reality)** — daily life, cultural
  routines, ordinary human events. Cooking, working, family
  dynamics, weather, illness, age, marriage, money.
- **Layer B (Magical reality)** — impossible events treated
  as ordinary. The dead at the table, the baby with wings,
  the village where it has rained for four years.
- **Layer C (Symbolic-political reality)** — the historical,
  social, metaphorical weight the magical carries. The dead
  are also the community's dead from political violence; the
  baby's wings are also the family's exceptionality the
  society cannot accommodate; the four-year rain is also the
  accumulated suffering.

Verify all three layers coexist without one overwhelming the
others. The form's failure mode is the manuscript that tilts
to one layer at the others' expense — pure-mundane
chapters where the magic disappears, pure-magical chapters
where the political weight evaporates, pure-political
chapters where the daily texture vanishes. The strongest
magical realism holds all three within a single paragraph,
sometimes within a single sentence.

Test: pick three significant scenes and identify each
layer's specific operation in each. If any layer is absent
from any scene, the coexistence has not been deployed
across the manuscript; if all three operate in all
scenes, the form's signature structural craft is operating.

### Pass 5: Ambiguity Check

Verify magic is both literal and symbolic, not pure
allegory. Magical realism's distinctive interpretive
register: the magical events are real within the world of
the book AND carry symbolic weight beyond their literal
occurrence. Pure allegory (where the magical means only
its symbolic meaning, with the literal level evacuated)
slips toward fable; pure literal-magic (where the magical
operates only as event without symbolic weight) slips
toward fantasy. The form's signature register holds both.

Verify the reader's certainty level is appropriately
unstable. The form's deepest interpretive pleasure is the
reader's productive uncertainty about what is real, what
is metaphor, what is unreliable narration, what is cultural
specificity. Manuscripts that resolve this uncertainty
(by signalling clearly which events are literal and which
are metaphorical) have lost the form's signature ambiguity.

Verify there is NO explanation for the magic. The Refused
Explanation technique requires that the manuscript never
articulate magical-system rules. No origin stories, no
mechanisms, no who-can-do-what taxonomies. Generic
"she inherited the gift" provides exactly the kind of
magical-system explanation the form excludes. Specific
behavioural rendering without explanation is the technique.
Test: search the manuscript for explanations of magical
events. Where explanations exist, verify each is
intentional (the protagonist offering a partial
explanation that the prose then complicates) rather than
authorial (the narrator articulating how the magic works).

### Pass 6: Cultural Specificity + Refused-Explanation Integration Audit

Run a final integrative pass on the manuscript's cultural
grounding and structural discipline. Two related sub-audits:

**Cultural specificity verification.** Magical realism's
contemporary craft expects deep cultural grounding. Audit
the manuscript: is the cultural setting specifically and
accurately rendered? Are cultural markers, historical
contexts, linguistic textures, religious and spiritual
practices, kinship structures all specific to the chosen
cultural context rather than generic literary atmospheres?
Cultural-tourism magical realism — Western writers
borrowing Latin American conventions without specific
cultural grounding — is the form's most-flagged
contemporary craft failure.

The pass also checks for the related failure mode:
manuscript writers who attempt magical realism in cultural
contexts they don't have specific connection to. The form
permits — and is enriched by — diverse practitioners
working in varied cultural contexts, but the specific
cultural grounding must be earned. Generic "exotic
location" treatment is unacceptable; specific researched
or lived cultural reality is the form's signature.

**Refused-explanation discipline.** The form's structural
contract requires the sustained refusal to systematise the
magic. Audit the manuscript for explanation-creep — the
moments where the prose has begun to explain how the magic
works, where it comes from, what its rules are. Each
instance is a slippage toward fantasy register. The
strongest magical realism maintains the refusal across
hundreds of pages, with the magic operating as
unquestionable feature of the world rather than as system
the reader engages with analytically.

The pass also checks for the related failure mode: magical
events that appear once and are forgotten. The form's
strongest practice integrates magical content throughout
the manuscript rather than concentrating it in a few set-
pieces. Generic "magical-realism flavoured" treatment where
the magic operates only at chapter openings or climactic
moments is the failure mode; sustained matter-of-fact
magical presence across the manuscript is the technique.

Test: at three points spaced across the manuscript, can
the writer identify the magical content operating in
those chapters? If magical content concentrates in a few
chapters and disappears elsewhere, the form's sustained
register has not been deployed; if magical content
operates as continuous matter-of-fact presence across the
book, the form's signature integration is operating.

## Names & Patterns to Avoid

### Magical Realism Character Names. NEVER USE
- Generic Anglo names in culturally specific settings (respect the culture's naming traditions)
- Symbolic names that telegraph the magic (Esperanza can work, Magia cannot)
- Fantasy names (this is not a fantasy world. these are real cultures)

### Magical Realism. NEVER DO
- Explain the magic (origin stories, rules, systems, causes)
- Let characters express wonder at the impossible (it's weather, not a miracle)
- Use generic settings ("a village in South America". which village? which country? which region?)
- Write pure allegory (magic must be literally true AND symbolically meaningful)
- Apply Western fantasy tropes (chosen ones, magical societies, quest narratives)
- Write whimsy (magical realism is serious; the impossible has weight)
- Stay in a single timeline (temporal fluidity is mandatory)

### Use Instead
- Names authentic to the specific culture and region depicted
- Names that carry family history (named after grandmothers, saints, historical figures)
- Nicknames that reveal community relationships and affection

## Comp Titles

Magical-realism's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *One Hundred Years of Solitude* — Gabriel García Márquez (1967): the genre-defining text.
- *Like Water for Chocolate* — Laura Esquivel (1989): culinary magical-realism benchmark.
- *Beloved* — Toni Morrison (1987): post-slavery literary magical-realism.
- *The House of the Spirits* — Isabel Allende (1982): generational magical-realism epic.
- *Midnight's Children* — Salman Rushdie (1981): post-colonial magical-realism.

### Contemporary (current best-in-class)

- *Exit West* — Mohsin Hamid (2017): refugee magical-realism with door-portals.
- *Things We Lost in the Fire* — Mariana Enríquez (2016, English 2017): Argentine literary magical-realism stories.
- *Daughters of the Lost Coven* — various 2020s magical-realism: Latin American literary-revival.
- *The Bear and the Nightingale* — Katherine Arden (2017): folkloric Russian magical-realism.
- *The House in the Cerulean Sea* — TJ Klune (2020): cozy-magical-realism crossover.
- *Mexican Gothic* — Silvia Moreno-Garcia (2020): magical-realism-gothic hybrid.
- *Piranesi* — Susanna Clarke (2020): literary magical-realism with constrained-world.
- *White Teeth* — Zadie Smith (2000): magical-realism-adjacent literary benchmark.

## Cover Design Specifications

### Recommended Visual Styles
- **Lush/Botanical**. Rich natural imagery with impossible elements: flowers that shouldn't exist, animals where they shouldn't be, the natural world made magical through abundance and beauty
- **Photographic/Surreal**. Realistic photography with one impossible element: a normal scene with something slightly, beautifully wrong; the visual equivalent of the genre's core technique
- **Illustrated**. Rich, detailed illustration influenced by the story's culture: muralism, folk art, textile patterns; the visual traditions of the specific culture rendered bookishly
- **Typographic/Textural**. Beautiful typography with cultural motifs; the title nestled in organic or cultural patterns; the design should feel woven, not assembled

### Genre Cover Aesthetics
- **Styles:** Lush, rich, slightly surreal; realistic with one impossible element; influenced by the specific culture's visual traditions; painted or illustrative rather than photographic; botanical abundance; the collision of the domestic and the magical
- **Colours:** Rich, warm, saturated: tropical greens, deep reds, golden yellows, earth tones with one impossible colour; the palette should feel alive and specific to the story's region. not generic "exotic" but THIS place's light and colour
- **Elements:** Butterflies, birds, flowers in abundance; domestic objects made magical (a chair that floats, a pot that overflows with stars); cultural artefacts; generational images (old photographs, family trees, ancestral portraits); the collision of the everyday and the extraordinary
- **Typography:** Elegant, often with flourishes; may incorporate elements from the culture's visual traditions; the title should feel like it belongs in the world of the story; gold or metallic effects suggest the magical layer beneath the real

### Market Positioning
Magical realism covers must signal "lyrical, culturally rich, and quietly impossible" through lush, slightly surreal design. Position against García Márquez, Allende, Murakami, Morrison, Okri. The cover should be beautiful enough to stare at and strange enough to pull the eye. At thumbnail size, rich colour and organic imagery create a visual identity distinct from both literary fiction and fantasy.

### Cover Design DON'Ts
- No fantasy imagery (dragons, swords, castles. this is not fantasy)
- No "exoticising" designs (the cover should respect the culture, not commodify it)
- No dark or horror-adjacent imagery (magical realism's magic is domestic, not threatening)
- No minimalist/stark designs (the genre is lush; the cover should be too)
- No generic imagery (specificity in the cover reflects specificity in the text)
- No designs that could be mistaken for literary fiction (the magical element should be visible)
