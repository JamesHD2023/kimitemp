---
name: beat-structures
description: "28 beat structure templates with genre-to-beat mapping"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Beat Structure Protocol

## Purpose

Beat structures provide a narrative skeleton for the manuscript. They define the key
story moments (beats) and where they should fall in the story (as a percentage of
total length). The Architect uses beats to plan chapters; the Arc Analyst verifies
beat delivery.

## When It Runs

During Phase 1 (Interactive Setup), after genre and length tier are selected.

## Beat Selection Protocol

### Step 1: Load Beat Library

Read `genres/beat-library.md` to access the full library of beat structures
and genre-to-beat mappings.

### Step 2: Recommend Structures

Based on the user's selected genre and length tier, present recommended structures:

```
GENRE-TO-BEAT RECOMMENDATIONS:
1. Look up the genre in the GENRE-TO-BEAT MAPPING section of beat-library.md
2. Present RECOMMENDED structures first (these are the best fit for the genre)
3. Present SECONDARY structures as alternatives
4. Always offer "No beat structure" as an option (freeform writing)

For NOVELLAS: Use the NOVELLA-SPECIFIC genre mappings (shorter, tighter structures)
For NOVELS: Use the STANDARD genre mappings
```

### Step 3: Present to User

Use AskUserQuestion to offer the beat structure choice:

```
Based on your genre [{genre}] and length [{tier}], these beat structures
are recommended:

RECOMMENDED:
- [Structure Name] — [description] ([N] beats)
- [Structure Name] — [description] ([N] beats)

ALTERNATIVES:
- [Structure Name] — [description] ([N] beats)

OTHER OPTIONS:
- No beat structure (freeform — the Architect plans freely)
- Custom (describe your preferred structure)
```

### Step 4: Store Selection

Record the selected beat structure ID in the workspace:
- Save to `Ideorix-Projects/[Title]/engine-data/beat-structure.md`
- Include the full beat list with percentages
- This file is referenced by Architect and Arc Analyst for every chapter

## Beat-to-Chapter Mapping Formula

```
Story Percentage = ((chapterNumber - 1) / (totalChapters - 1)) × 100

Example (30-chapter novel, Save the Cat):
- Chapter 1  →  0%  → "Opening Image"
- Chapter 2  →  3%  → "Theme Stated" (5%)
- Chapter 4  → 10%  → "Setup" / "Catalyst" (10%)
- Chapter 7  → 21%  → "Debate" (20%)
- Chapter 8  → 24%  → "Break into Two" (25%)
- Chapter 10 → 31%  → "B Story" (30%)
- Chapter 11 → 34%  → "Fun and Games" (35%)
- Chapter 15 → 48%  → "Midpoint" (50%)
- Chapter 18 → 59%  → "Bad Guys Close In" (60%)
- Chapter 23 → 76%  → "All Is Lost" (75%)
- Chapter 24 → 79%  → "Dark Night of the Soul" (80%)
- Chapter 27 → 90%  → "Finale" (90%)
- Chapter 30 → 100% → "Final Image" (100%)
```

### Finding the Current Beat

For any chapter, find the beat whose percentage is closest to (but not exceeding)
the chapter's story percentage. The NEXT beat is the one the chapter should be
building toward.

```
Given: Chapter 18 of 30 → Story% = 58.6%

Beats nearby:
- "Midpoint" at 50% ← CURRENT (already passed)
- "Bad Guys Close In" at 60% ← APPROACHING (within 10%)

The Architect should plan Chapter 18 to DELIVER the "Bad Guys Close In" beat
or build directly toward it.
```

### Tolerance Rules

- A beat is considered DELIVERED if the chapter's story percentage is within
  ±5% of the beat's target percentage
- A beat is APPROACHING if the chapter is within 10% BEFORE the beat's percentage
- A beat is OVERDUE if the story percentage has passed the beat's target by >10%
  and it hasn't been delivered in any chapter

## How Agents Use Beats

### Architect Agent

The Architect receives:
```
BEAT STRUCTURE: {structure_name}
CURRENT CHAPTER: {N} of {total} (Story Position: {X}%)

CURRENT BEAT: "{beat_name}" — {beat_description}
  Target: {beat_percentage}% | Status: [approaching / delivering / delivered]

NEXT BEAT: "{next_beat_name}" — {next_description}
  Target: {next_percentage}%

INSTRUCTION: This chapter MUST clearly serve the "{beat_name}" beat.
Plan scenes that advance the story to this structural moment.
If the beat is already delivered, build toward the NEXT beat.
```

The Architect includes in the chapter brief:
- Which beat this chapter serves
- How each scene contributes to the beat
- What structural purpose the chapter fulfils in the larger arc

### Writer Agent

The Writer receives a simplified version:
```
STORY BEAT: This chapter serves the "{beat_name}" beat.
Beat purpose: {beat_description}

Write the chapter so that the reader FEELS this structural moment.
The beat should emerge through character action and story events,
not through explicit signaling or meta-commentary.
```

### Arc Analyst (Verification)

After each chapter, the Arc Analyst checks:
```
BEAT DELIVERY CHECK:
- Expected beat: "{beat_name}" at {beat_percentage}%
- Chapter story position: {X}%
- Was the beat delivered? [yes / partial / no]
- If partial: What's missing?
- If no: Is the beat overdue? Should it be delivered in the next chapter?

PACING ANALYSIS:
- Is the story running ahead of the beat structure? (compressing too fast)
- Is the story running behind? (stretching or stalling)
- Pacing status: [on-track / ahead / behind]
- Severity: [minor / moderate / severe]
```

### Arc Analyst Output Schema Addition

The Arc Analyst's existing `beatDelivery` field should track:
```
beatDelivery: {
  [beatName]: "delivered" | "partial" | "missed" | "upcoming"
}
beatPacing: "on-track" | "ahead" | "behind"
beatPacingSeverity: "minor" | "moderate" | "severe"
```

## Edge Cases

### No Beat Structure Selected

If the user chooses "No beat structure":
- The Architect plans chapters freely using genre conventions
- The Arc Analyst evaluates general pacing without beat targets
- The `beatDelivery` section of reports is omitted

### Custom Beat Structure

If the user describes a custom structure:
- Parse their description into `{ name, description, percentage }` beats
- Save to `Ideorix-Projects/[Title]/engine-data/beat-structure.md` in the same format
- All agents use it identically to a library structure

### Multiple Beats at Same Percentage

Some structures have multiple beats at the same percentage (e.g., Save the Cat
has "Dark Night of the Soul" and "Break into Three" both at 80%). In these cases:
- The Architect should address BOTH beats in the same chapter or adjacent chapters
- The Arc Analyst checks for both and reports on each separately

### Beat Structure and Genre Arc Rules

Beat structures COMPLEMENT genre-specific arc rules (from genre bank files).
They do NOT replace them.

```
PRIORITY ORDER:
1. Genre arc rules (act structure, genre-specific requirements)
2. Beat structure (narrative skeleton — WHERE things happen)
3. Architect's creative planning (HOW things happen)

When beat structure conflicts with genre arc rules, GENRE WINS.
Example: If the genre says "midpoint must be a psychological revelation"
and the beat says "Midpoint = a major victory," the Architect should deliver
a psychological revelation that ALSO functions as a structural midpoint.
```

## File Output

Save beat structure selection to: `Ideorix-Projects/[Title]/engine-data/beat-structure.md`

Format:
```markdown
# Beat Structure: {Structure Name}

Selected for: {Book Title}
Genre: {genre}
Length: {tier} ({total_chapters} chapters)

## Beats

| # | Beat | Description | Target % | Target Chapter |
|---|------|-------------|----------|----------------|
| 1 | Opening Image | ... | 0% | Ch. 1 |
| 2 | Theme Stated | ... | 5% | Ch. 2 |
| ... | ... | ... | ... | ... |

## Beat Delivery Log

Updated after each chapter:

| Beat | Target Ch. | Delivered Ch. | Status |
|------|-----------|---------------|--------|
| Opening Image | 1 | 1 | ✓ Delivered |
| Theme Stated | 2 | 2 | ✓ Delivered |
| ... | ... | ... | ... |
```
