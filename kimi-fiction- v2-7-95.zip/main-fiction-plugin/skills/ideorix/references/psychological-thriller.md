---
name: psychological-thriller-genre
description: Genre-specific instructions for psychological thriller fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Psychological Thriller. Genre Plugin

## Metadata
- id: psychological-thriller
- name: Psychological Thriller
- icon: 🧠
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Seven-Point Story Structure", "The Story Circle"]

## Subgenre Options
Present during setup:
- **Unreliable Narrator**. The protagonist's perception is fractured or deceptive. The reader pieces together what's real from contradictory accounts, memory gaps, and slowly revealed truths (Gillian Flynn, Paula Hawkins)
- **Gaslighting / Coercive Control**. A manipulator systematically destabilises the protagonist's grip on reality. The reader watches the trap close while the protagonist struggles to name what's happening (B.A. Paris, Freida McFadden)
- **Obsession**. A character fixates on another person, object, or goal to the point of self-destruction. The line between devotion and pathology blurs (Patricia Highsmith, Caroline Kepnes)
- **Locked Setting**. Isolation amplifies paranoia. A house, island, hotel, institution, or remote location becomes a pressure cooker with no escape (Ruth Ware, Agatha Christie's And Then There Were None)
- **Identity / Amnesia**. The protagonist doesn't know who they are, what they've done, or what's been done to them. Memory is the mystery (S.J. Watson, A.J. Finn)
- **Dual/Multiple POV**. Competing perspectives on the same events. Each narrator's version contradicts the others. The reader must determine whose reality is closest to the truth (Tana French, Lisa Jewell)

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: SLOW BURN with periodic spikes. tension accumulates through atmosphere,
  internal doubt, and small wrongnesses rather than action sequences
- Must end with: A perception shift. something the protagonist believed is undermined,
  a detail that doesn't fit, a question that keeps the reader turning pages
- Must open with: The protagonist in their subjective reality. show their worldview
  BEFORE you start cracking it

BEATS PER CHAPTER
1. Perception Beat. The protagonist observes, interprets, or remembers something
   (this is the lens through which the reader experiences the world)
2. Dissonance Beat. Something doesn't match: a contradictory detail, a gap in memory,
   a reaction from another character that doesn't fit the protagonist's narrative
3. Rationalisation Beat. The protagonist explains away the dissonance
   (early chapters: successfully; later chapters: with visible strain)
4. Emotional Cost Beat. The uncertainty takes a toll: anxiety, paranoia, self-doubt,
   isolation, physical symptoms of stress
5. Escalation Beat. The chapter ends with the dissonance slightly wider than it started.
   the cracks are growing

UNRELIABLE NARRATOR ARCHITECTURE (CRITICAL)
- Layer 1 (Chapters 1-3): Establish the narrator's worldview as trustworthy.
  The reader bonds with this perspective. The prose is confident, the observations specific,
  the voice sympathetic. Plant the FIRST hairline crack. one detail that a careful reader
  might notice doesn't quite add up.
- Layer 2 (Chapters 4-8): Introduce competing information. Other characters react in ways
  that don't match the narrator's version. Small inconsistencies accumulate. The narrator
  explains them away. The reader begins to have doubts but isn't sure.
- Layer 3 (Chapters 9-14): The cracks widen. The narrator's rationalisations become
  visibly strained. A major piece of contradictory evidence surfaces. The reader now
  actively questions the narrator's version. But which parts are wrong?
- Layer 4 (Chapters 15-end): Revelation cascade. The true picture emerges. not all at once
  but in stages. Each revelation reframes earlier events. The reader re-evaluates everything.
  The final revelation should feel both shocking AND inevitable.

INFORMATION MANAGEMENT FOR PSYCHOLOGICAL THRILLERS
- The reader should always know SLIGHTLY more than the protagonist thinks they know.
  but less than they think they know. This creates the delicious unease of recognising
  manipulation that the character can't yet see.
- Plant clues in EVERY chapter. Some are real, some are red herrings, some are true
  but misinterpreted. The reader collects them and builds their own theory.
- At least 3 planted clues must pay off in the final revelation.
- The twist must be FAIR. upon rereading, every clue was visible. No information
  withheld from a first-person narrator who would obviously know it.
  (Exception: repressed memories, but these must be flagged by gaps/inconsistencies.)
- False conclusions are powerful: the protagonist AND the reader build the wrong picture
  from real clues. The reframe isn't "you were lied to". it's "you interpreted correctly
  but from incomplete data."

ATMOSPHERE AS ARCHITECTURE
- Setting reflects psychological state (pathetic fallacy used deliberately, not accidentally)
- Domestic spaces become threatening: the house that felt safe now feels like a cage
- Routine activities become loaded with dread (cooking, driving, checking the mail)
- Time of day matters: 3 AM thoughts, the golden hour when everything looks fine,
  the Sunday evening dread
- Silence is as important as dialogue. what is NOT said carries enormous weight

DUAL TIMELINE STRUCTURE (if using past/present)
- Present chapters: First person, immediate, uncertain
- Past chapters: Can use different tense or POV to signal the shift
- The past and present converge at the climax. the reader finally sees how
  "what happened then" created "what's happening now"
- Each past chapter should recontextualise the present chapter that precedes it
- The gap between the two timelines narrows as the book progresses

FORBIDDEN IN PSYCHOLOGICAL THRILLER
- Jump scares or horror-movie shocks (this is dread, not fear)
- Physical action as a substitute for psychological tension
- The protagonist suddenly becoming a detective who solves everything rationally
- A twist that relies on withheld information the narrator would obviously know
- Mental illness used as a plot device without psychological accuracy or empathy
- "It was all in their head" as the entire resolution (some must be real)
- The antagonist explaining their manipulation in a monologue
- Gaslighting portrayed as romantic or flattering ("he's so protective")
- Amnesia without physiological or psychological justification
- The protagonist having no agency. they must CHOOSE, even if they choose wrong
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (mounting dread), Captivation (interior unreliability), Revelation (perception shift).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person present tense (primary) OR first person past tense
  OR close third past tense. First person is strongly preferred. the reader
  must be INSIDE this mind, sharing its distortions.
- Voice: Intimate, observant, slightly anxious. The prose has a confessional quality.
  the narrator is trying to make sense of things by telling you about them.
  They notice too much or too little. Their attention is selective in revealing ways.
- Tone: Unsettled. Even calm moments carry an undertow of wrongness. The reader
  should feel that something is off before they can articulate what.
- Sentence structure: Varies with emotional state. Controlled and articulate when
  the narrator feels safe. Fragmented, repetitive, or spiralling when distressed.
- Reader relationship: Co-conspirator. The reader is pulled into the narrator's
  worldview, complicit in their interpretations, then forced to question everything.

DIALECT CONSISTENCY (IMPORTANT)
- Establish the dialect in the Story Bible (British English, American English, etc.)
- Maintain 100% consistency throughout. a single "fall" in a British novel is jarring
- Common British/American traps to watch:
  - autumn / fall
  - colour / color
  - pavement / sidewalk
  - boot (of car) / trunk
  - torch / flashlight
  - flat / apartment
  - "have got" / "gotten"
  - mobile / cell phone
  - post / mail
  - therapist / counsellor (usage conventions differ)
  - tablets / pills (British tends toward "tablets")
  - GP / doctor (British uses "GP" for primary care)
- If British English: NEVER use "fall" for autumn, "gotten", "apartment" for "flat",
  or "cell phone" for "mobile"
- Psychological thrillers often feature therapy, medication, and healthcare. ensure
  medical/therapeutic terminology matches the setting's dialect
- The Prose Craft Improver should scan for dialect inconsistencies during its pass

PROSE IMPERATIVES
- INTERIORITY IS EVERYTHING: The reader lives inside the protagonist's perceptions.
  Describe the WORLD through the CHARACTER'S emotional filter, not objectively.
  A happy character sees a "sunny kitchen." A paranoid character sees "light that
  exposed every surface, leaving nowhere to hide."
- SENSORY DETAIL SERVES PSYCHOLOGY: Physical sensations ground psychological states.
  Anxiety is a tightness in the chest, a metallic taste. Dissociation is sounds
  becoming distant, textures going numb. Don't name the emotion. render its
  physical signature.
- OBSESSIVE FOCUS: The narrator fixates on specific details and returns to them.
  This is characterisation AND foreshadowing. What they notice repeatedly matters.
  What they avoid noticing matters more.
- RATIONALISATION AS PROSE RHYTHM: After every disturbing observation, the narrator
  explains it away. These rationalisations should sound increasingly hollow as the
  book progresses. "There must be a reason." "I'm probably imagining things."
  "It doesn't mean anything."
- MEMORY AS UNRELIABLE TEXTURE: When the narrator remembers past events, the
  memories should feel slightly different each time they're recalled. A detail
  changes, an emphasis shifts, a new element surfaces. This is how real memory works
  AND how the reader learns the narrator's version is unstable.

UNRELIABLE NARRATOR PROSE TECHNIQUES
- The Confident Lie: State something as fact that later proves false. Use specific
  detail to make it convincing. "The door was locked. I'd checked it twice before bed."
  (Later: was it? Did they?)
- The Telling Omission: The narrator skips over a period of time, changes subject
  abruptly, or says "I don't remember exactly." These gaps ARE the story.
- The Over-Explanation: When the narrator spends three sentences justifying something
  that shouldn't need justification, the reader's suspicion is triggered.
- The Contradictory Detail: In Chapter 3, the narrator describes the vase on the shelf.
  In Chapter 9, they mention the shelf has always been empty. Don't flag it.
  Let the reader catch it.
- The Emotional Mismatch: The narrator describes something horrifying in a calm,
  flat tone. or something mundane with disproportionate fear. The reader feels
  the wrongness before they understand it.
- The Retroactive Edit: "That was the night everything changed. No. that's not right.
  Everything had already changed. I just hadn't noticed."

DIALOGUE FOR PSYCHOLOGICAL THRILLER
- Subtext is EVERYTHING. Characters almost never say what they mean.
- Power dynamics visible in dialogue structure: who asks questions, who deflects,
  who changes the subject, who controls the topic
- Gaslighting in dialogue: "You always do this." "That never happened." "Are you sure
  you're remembering that right?" "I'm worried about you.". These phrases should chill
  the reader because they recognise the pattern.
- Silence and non-response as dialogue: What the other character DOESN'T say is often
  more revealing than what they do.
- The protagonist's dialogue should reveal their current state: confident early,
  questioning middle, either assertive or broken by the end.
- Overheard conversations and half-caught phrases create paranoia without confirmation.

CHAPTER 1 PAGE-TURNER RHYTHM (psychological thriller adaptation)

Psychological thrillers are atmosphere-driven. but Chapter 1 still
must hook. The hook is WRONGNESS. Something is off about the narrator,
the situation, or the world, and the reader must feel it before they
can name it.

- Prose rhythm: medium-long sentences (15-25 words) that create a
  hypnotic, immersive quality. punctuated by SHORT sentences (5-8
  words) that land like a flinch. The short sentence IS the crack.
  "The door was open. I always lock the door."
- The FIRST hairline crack must land within 500 words of the chapter
  opening. not at the end. The reader should feel unease from the
  FIRST PAGE, not from the last paragraph.
- Interiority: this genre's strength, but in Ch 1 it must serve
  UNEASE, not setup. The narrator's thoughts should contain at least
  one rationalisation that the reader recognises as hollow.
- Sensory detail: weighted toward PSYCHOLOGICAL texture (how things
  FEEL to the narrator, not how they objectively look). One detail
  that recurs. the narrator notices it, explains it away, but the
  reader files it.
- Dialogue: at least one exchange where the reader can see a crack
  the narrator can't (or won't). The gap between what's said and
  what's true is the page-turner.
- Tension slider: ≥7 for Ch 1. The tension is psychological, not
  physical. but it must be FELT from page 1, not page 15.
- Therapist/friend conversations can serve as reality-testing scenes where the protagonist
  tries to articulate what's wrong and fails. or succeeds and isn't believed.

PACING FOR PSYCHOLOGICAL THRILLER
- NOT action-based pacing. Tension comes from UNCERTAINTY, not events.
- The "drip" technique: small wrongnesses accumulate. A moved object. A contradicted memory.
  A look between two people that the narrator can't interpret. Each one is individually
  dismissible. Together they build a pattern the reader sees before the narrator.
- Acceleration pattern: Early chapters: one dissonant detail per chapter.
  Middle chapters: two or three per chapter. Final act: rapid cascade, dissonance
  in every scene.
- Breather scenes MUST still carry unease. A "nice" dinner where the reader knows
  something the protagonist doesn't. A quiet morning where the protagonist notices
  something but chooses not to pursue it.
- The longest gap between tension should never exceed 2 pages.

MANAGING READER TRUST
- Phase 1 (Bond): Reader trusts the narrator completely. Earn this with specific,
  relatable, sympathetic details. Make the reader LIKE being in this head.
- Phase 2 (Doubt): Reader begins to notice inconsistencies. Don't confirm their
  doubts yet. Let uncertainty build.
- Phase 3 (Split): Reader holds two competing theories. The narrator's version
  and an alternative. Both seem possible.
- Phase 4 (Revelation): The truth emerges. If done well, the reader feels both
  "I should have seen it" and "I never could have guessed."
- CRITICAL: Never let the reader feel cheated. The clues were there. The twist
  was fair. The emotional truth was real even if the factual truth was different.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

PSYCHOLOGICAL TENSION (40% of total):
- Atmosphere and dread: Does every chapter carry an undertow of unease? (0-100)
- Unreliability management: Is the narrator's unreliability handled with craft,
  not cheap tricks? (0-100)
- Dissonance accumulation: Do small wrongnesses build to an intolerable weight? (0-100)
- Reader uncertainty: Does the reader hold multiple competing theories? (0-100)
- Internal logic: Do the protagonist's perceptions and reactions feel psychologically
  authentic, even when distorted? (0-100)

TWIST & REVELATION CRAFT (30% of total):
- Clue planting: Are clues seeded early and visibly (on reread)? (0-100)
- Fair play: Does the twist arise from information available to the reader? (0-100)
- Reframe power: Does the revelation fundamentally change how earlier events read? (0-100)
- Escalation: Do reveals build in magnitude toward the climax? (0-100)
- Emotional truth: Is the twist emotionally devastating, not just intellectually clever? (0-100)

CHARACTER & VOICE (30% of total):
- Interiority depth: Is the reader fully immersed in the protagonist's mind? (0-100)
- Voice consistency: Does the narrator's voice feel like one person across chapters? (0-100)
- Manipulation craft: Is the antagonist's manipulation psychologically plausible? (0-100)
- Character agency: Does the protagonist make choices, even bad ones? (0-100)
- Psychological accuracy: Are mental states, trauma responses, and relationship
  dynamics rendered with accuracy and nuance? (0-100)

AUTOMATIC FAILS (score = 0):
- CHEATING TWIST: Revelation depends on information withheld from a first-person
  narrator who would obviously possess it
- NO CLUES PLANTED: The twist has no setup. it arrives from nowhere
- MENTAL ILLNESS AS GIMMICK: Psychological conditions used purely as plot devices
  without authentic portrayal
- PASSIVE PROTAGONIST: Narrator observes and reacts but never makes choices
- ATMOSPHERE COLLAPSE: More than two consecutive chapters without psychological tension
- GRATUITOUS MANIPULATION: Gaslighting or abuse depicted without emotional weight
  or consequence (treated as entertainment)
- DEUS EX THERAPIST: A professional character explains the entire psychological
  dynamic in a single exposition scene
- IDENTITY WHIPLASH: The narrator's unreliability is so extreme that the reader
  gives up trying to track what's real
- MISOGYNISTIC FRAMING: Female protagonist's distress played for titillation rather
  than empathy; "crazy woman" tropes reinforced rather than interrogated
```

## Continuity Rules

```
PSYCHOLOGICAL THRILLER CONTINUITY. WHAT TO TRACK

NARRATOR'S STATED REALITY (CRITICAL):
- What has the narrator told the reader as fact?
- Which of these "facts" will later be contradicted or recontextualised?
- Track contradictions deliberately: if the narrator says the door was blue in Ch.3,
  and green in Ch.11, is that intentional unreliability or an author error?
- Maintain a "true timeline" separate from the narrator's timeline. know what
  ACTUALLY happened even if the narrator doesn't
- Track what the narrator claims to remember vs. claims not to remember

EMOTIONAL STATE CONTINUITY:
- Current anxiety level (baseline → elevated → crisis → dissociation)
- Sleep quality and quantity (insomnia builds, nightmares evolve)
- Appetite and physical self-care (declining under stress)
- Coping mechanisms (what do they do when afraid? Drink? Clean? Run? Freeze?)
- Relationship to medication, therapy, or other support systems
- Physical symptoms of psychological distress (headaches, nausea, trembling, numbness)
- What triggers flashbacks or panic? (Must be consistent once established)

MANIPULATION TIMELINE:
- What has the antagonist done to the protagonist, and when?
- Track the escalation: early manipulation is subtle, later manipulation is overt
- What does the protagonist currently believe about the antagonist's intentions?
- What evidence does the protagonist have that something is wrong?
- What evidence has the antagonist destroyed, hidden, or explained away?
- Which other characters have witnessed manipulative behaviour?
- Track the antagonist's cover story. it must remain internally consistent

RELATIONSHIP DYNAMICS MAP:
- Who does the protagonist trust? (This list should shrink across the manuscript)
- Who is genuinely trustworthy vs. apparently trustworthy?
- Who has the protagonist confided in? What did they share?
- Who is allied with the antagonist (knowingly or unknowingly)?
- Which relationships have been damaged by the protagonist's increasing paranoia?
- Track isolation: how many people can the protagonist turn to? (Should decrease)

MEMORY AND PERCEPTION STATE:
- Which memories has the narrator shared? Do they change on re-telling?
- Where are the gaps? (The narrator says "I don't remember". what are they not remembering?)
- What objects, details, or sensory triggers prompt memory intrusions?
- How reliable is the narrator's sense of time? (Are they losing hours? Confusing days?)
- Track medication, alcohol, or substance use that might affect perception

CLUE AND RED HERRING TRACKER:
- Plant list: Every clue seeded, which chapter, how visible
- Payoff list: When each clue is activated or explained
- Red herring list: Which misleading clues are planted and when they're debunked
- "Reread" moments: Scenes that read completely differently after the twist
- Ensure every planted clue has a payoff, every red herring has a debunking

SETTING CONTINUITY:
- The house/apartment/institution layout (must be consistent. readers map spaces)
- Which rooms, objects, and spaces have psychological associations?
- What has been moved, changed, or gone missing? (Track for gaslighting plots)
- Locked rooms, hidden spaces, or areas the protagonist avoids. why?
- Weather and season tracking (atmosphere depends on environmental accuracy)
- Neighbourhood and surrounding area (who might see or hear things?)

OTHER CHARACTER KNOWLEDGE STATE:
- What does each character know about the protagonist's situation?
- What has each character witnessed?
- Who is lying and what do they know?
- Track what the reader knows about each character vs. what the protagonist knows
```

## Character Rules

```
PSYCHOLOGICAL THRILLER CHARACTER ARCHETYPES

THE UNRELIABLE PROTAGONIST:
- Sympathetic despite distortions. the reader cares about them even when questioning them
- Has a specific vulnerability the antagonist exploits (grief, guilt, trauma, illness, isolation)
- Their unreliability has a CAUSE. it's not random, it's psychological (trauma, medication,
  manipulation, denial, substance use, mental health condition)
- Their perception is internally consistent. they believe their version completely
- They have moments of lucidity where they almost see the truth, then retreat from it
- Their competence exists in a specific domain (their job, their art, their intellect)
  even as their personal reality crumbles
- They make choices. even trapped characters choose how to respond to their situation
- Their arc is toward truth, even if the truth is devastating

PATTERNS OF UNRELIABILITY:
Type A. The Self-Deceiver (Gone Girl's Nick, Girl on the Train's Rachel):
- Knows more than they're telling the reader (and possibly themselves)
- Hides shameful actions behind rationalisations and euphemisms
- The reader gradually realises the narrator's version omits crucial self-knowledge
- Craft: Let the narrator's blind spots speak louder than their words

Type B. The Gaslit Protagonist (Behind Closed Doors, The Woman in the Window):
- Genuinely doesn't know what's real because someone is deliberately distorting reality
- Their self-doubt is a weapon being used against them
- The reader recognises the manipulation before the protagonist does
- Craft: Show the protagonist's reality being eroded in real time

Type C. The Fractured Mind (Before I Go to Sleep, The Silent Patient):
- Memory, identity, or perception is physiologically compromised
- They're working with incomplete or corrupted information
- The gaps in their knowledge ARE the mystery
- Craft: The reader pieces together what the narrator cannot

THE PSYCHOLOGICAL ANTAGONIST:
- Intelligent, patient, and strategic. manipulation is a long game, not impulsive
- Has a psychologically plausible motivation (control, jealousy, self-protection,
  ideological certainty, narcissistic injury)
- Maintains a convincing public persona. other characters like or respect them
- Their manipulation toolkit is specific and consistent:
  - Isolation (cutting the protagonist off from support)
  - Reality distortion (denying events, reframing memories)
  - Emotional leverage (love-bombing then withdrawing, creating dependency)
  - Information control (what the protagonist is allowed to know)
- They have their own vulnerability. something they're protecting, hiding, or compensating for
- They escalate when threatened. when the protagonist gets close to the truth,
  the antagonist's methods become more extreme
- They are NEVER revealed as simply "evil". their psychology is as layered as the protagonist's
- Their reveal should prompt the reader to re-evaluate their charm as sinister

THE CONFIDANT / REALITY CHECK:
- One character who sees clearly (friend, therapist, colleague, neighbour)
- Their function: gives the protagonist (and reader) a reality anchor
- They may be believed or dismissed by the protagonist
- They can be neutralised by the antagonist (discredited, alienated, silenced)
- If they disappear or turn, the protagonist is truly alone. maximum vulnerability
- DANGER: This character must NOT become a mouthpiece for exposition. Show their
  concern through behaviour, not speeches.

THE AMBIGUOUS ALLY:
- A character whose allegiance is genuinely uncertain for most of the book
- Could be helping or could be part of the problem
- Their ambiguity should be maintained until the final act
- The reader should be able to argue either interpretation at the midpoint
- When their true nature is revealed, both readings of their earlier behaviour make sense

THE WITNESS:
- A character who saw or knows something but can't or won't tell
- Could be a child, a person with their own secrets, or someone compromised
- Their partial information creates dramatic irony (reader suspects, protagonist doesn't)
- Their silence has a psychologically plausible reason (fear, loyalty, denial, complicity)

ANTAGONIST PRESENCE BALANCE (Writer-Level Enforcement):
In psychological thrillers, the antagonist's presence is often disguised as something
benign. Track BOTH their surface behaviour and their manipulation:
- SURFACE PRESENCE: Scenes where the antagonist appears as their public persona
  (charming, supportive, reasonable)
- MANIPULATION PRESENCE: Scenes where the antagonist's manipulation is active
  (gaslighting, isolating, reality-distorting, love-bombing)
- AFTERMATH PRESENCE: Scenes where the protagonist is dealing with the EFFECTS
  of manipulation (self-doubt, confusion, checking their own memory)
- Per-chapter minimum: At least ONE of the three presence types
- CRITICAL BALANCE: The ratio of surface-to-manipulation presence should shift
  across the manuscript:
  Act 1: ~80% surface / ~20% manipulation (the mask is mostly on)
  Act 2A: ~50% surface / ~50% manipulation (cracks appearing)
  Act 2B: ~30% surface / ~70% manipulation (the mask slipping)
  Act 3: ~10% surface / ~90% manipulation (full reveal)
- The antagonist must NOT disappear from the narrative for >1 chapter.
  Even in chapters focused on the protagonist's investigation, the antagonist's
  influence should be felt through aftermath presence.
- The Character Tracker will flag chapters where antagonist presence is absent
  or where the surface/manipulation ratio doesn't match the expected act progression.

VOICE DIFFERENTIATION:
- Protagonist: Rich interiority, observant, increasingly fragmented under stress
- Antagonist: Controlled, warm on the surface, precise in manipulation.
  their words chosen to manage others' perceptions
- Confidant: Direct, grounded, shorter sentences. a counterpoint to the protagonist's spiralling
- Each character's dialogue reveals their power position and agenda
- The same event described by different characters should feel materially different

VOICE DIFFERENTIATION. QUANTITATIVE CHECK:
For each PAIR of major characters, identify at least 3 distinguishing dialogue features.
If any two characters share >2 features, one must be revised before proceeding.

Psychological thrillers risk the antagonist and protagonist mirroring each other's
voice too closely (especially in gaslighting plots where the antagonist echoes
the protagonist's language). Ensure different:
- Sentence construction (protagonist: increasingly fragmented; antagonist: consistently controlled)
- Emotional register (protagonist: reactive, questioning; antagonist: reassuring, deflecting)
- Power dynamics in dialogue (who asks questions, who provides answers, who redirects)
- Self-reference patterns (protagonist: uncertain "I think", "maybe"; antagonist:
  declarative "I know", "obviously", "you always")
- What they leave unsaid (protagonist omits from confusion; antagonist omits strategically)

The Character Tracker verification agent will flag voice convergence between
any two major characters. If flagged, the Writer must differentiate before proceeding.
```

## Arc Rules

```
PSYCHOLOGICAL THRILLER STORY STRUCTURE

ACT 1: THE ESTABLISHED REALITY (Chapters 1-5 for novella, 1-8 for novel)
- Chapter 1: Establish the protagonist's world, voice, and subjective reality.
  The reader enters their mind and trusts it. Plant the FIRST microscopic crack.
- Chapters 2-3: Deepen the protagonist's situation. Introduce key relationships.
  Show the world as the protagonist sees it. believable, specific, sympathetic.
- Inciting dissonance: Something happens that doesn't fit. A small thing.
  A forgotten conversation. A moved object. A strange reaction from someone trusted.
- The protagonist rationalises it. "I must have forgotten." "They were probably joking."
- Establish the protagonist's vulnerability (what makes them susceptible to doubt)
- Establish the antagonist's charm (what makes them trusted)
- Plant at least 3 clues for the final revelation. invisible on first read, obvious on reread
- End of Act 1: The protagonist has a nagging feeling that something is wrong
  but cannot articulate what. Their world is intact but hairline-cracked.

ACT 2A: GROWING DISSONANCE (Chapters 6-10 for novella, 9-16 for novel)
- The cracks multiply. Each chapter introduces a new piece of dissonant information.
- The protagonist investigates. but tentatively, afraid of what they'll find
- Other characters provide conflicting accounts of events
- The antagonist (if present) offers reasonable explanations that sound right
  but feel wrong
- The protagonist's support network begins to erode (friends alienated,
  therapist doubted, family unavailable)
- Physical symptoms of stress intensify
- The reader now holds two theories: the narrator's version, and an alternative
- A false trail leads the protagonist (and reader) toward a wrong conclusion
- Midpoint: A MAJOR piece of evidence surfaces that cannot be rationalised away.
  The protagonist's world cracks open. They can no longer pretend everything is fine.

MIDPOINT CRISIS:
- This is NOT an action set piece. It's a psychological breaking point.
- The protagonist confronts the dissonance directly for the first time
- They may confront the antagonist. who defuses the confrontation skillfully
- OR they discover physical evidence that contradicts their entire narrative
- OR they learn that other people's experience of events is radically different from theirs
- The protagonist must make a CHOICE: pursue the truth or retreat into the comfortable lie
- They choose to pursue. and this choice has immediate consequences

ACT 2B: UNRAVELLING (Chapters 11-16 for novella, 17-24 for novel)
- The protagonist actively seeks the truth. but the truth fights back
- Each revelation reframes earlier events (the reader starts re-evaluating previous chapters)
- The antagonist escalates in response to the protagonist's investigation
- The protagonist's credibility is attacked (the antagonist undermines their sanity,
  their memory, their reliability to others)
- Allies are lost, compromised, or revealed as complicit
- The protagonist reaches their lowest point: isolated, doubting their own mind,
  with evidence pointing in multiple directions
- The false conclusion from Act 2A is debunked. but what replaces it is worse
- A secondary revelation: Something the protagonist has been hiding from themselves
  (and possibly from the reader) is forced to the surface
- End of Act 2B: The protagonist has enough pieces to see the true picture.
  but the cost of seeing it is enormous

ACT 3: TRUTH AND CONSEQUENCE (Chapters 17-20 for novella, 25-32 for novel)
- The final revelation arrives. not as a single twist but as a cascade.
  Each piece clicks into place. The reader re-evaluates EVERYTHING.
- The confrontation with the antagonist (or with the truth) is psychological,
  not physical. Words, not weapons. Understanding, not combat.
  (Physical confrontation is acceptable if it emerges organically, but the
  REAL climax is the moment of seeing clearly.)
- The protagonist must ACT on the truth. confront, escape, expose, or accept
- The cost is real: relationships destroyed, self-image shattered, safety lost
- The resolution should feel INEVITABLE. every clue led here
- The emotional truth may differ from the factual truth (the relationship was
  real even if the person was lying; the protagonist's love was genuine even
  if it was manipulated)

THE CLIMAX SEQUENCE. THE CASCADE OF SEEING:
The psychological thriller climax is a REVELATION, not an action. Structure
it as a cascade across 3-4 chapters:

Chapter N-3 (THE LAST PIECE):
- The protagonist finds the final piece of evidence that they can no longer
  explain away. This is not the biggest piece. it's the one that makes all
  the other pieces form a picture.
- Show the moment of cognitive shift: everything they've been told, every
  "reasonable explanation," every memory they doubted. reinterpreted in
  an instant. Write this as a physical experience (nausea, vertigo, the
  room tilting, sounds becoming distant).
- The protagonist re-reads earlier events in their mind. Give the reader
  at least 3 specific callbacks to scenes from Acts 1-2 that now look
  completely different.

Chapter N-2 (THE CONFRONTATION OF TRUTH):
- The protagonist confronts the antagonist. or the truth about themselves.
- This scene is DIALOGUE-HEAVY and psychologically intense.
- The antagonist may deny, may confess, may try to reframe the truth one
  final time. Their response reveals which type they are:
  - The Manipulator doubles down: "You're confused. You're ill. No one will believe you."
  - The Narcissist pivots to victimhood: "After everything I've done for you."
  - The Self-Deceiver reveals they believe their own version: "I was protecting you."
- The protagonist's clarity is the weapon. For the first time, they see
  the antagonist WITHOUT the filter of self-doubt.
- Show the power dynamic flip: the protagonist speaks with certainty;
  the antagonist's control fractures.

Chapter N-1 (THE COST OF KNOWING):
- Immediate aftermath of the confrontation. The truth is out. but now what?
- The protagonist must deal with the wreckage: relationships built on the lie,
  decisions made while deceived, time lost, self-trust damaged.
- Other characters learn the truth. Their reactions vary: some believed all
  along, some are devastated, some are complicit and afraid.
- The protagonist makes a decision about what to DO with the truth
  (expose, protect, leave, stay, forgive, prosecute).

Chapter N (THE NEW EYES):
- The protagonist in their new reality. The prose style should be noticeably
  different from Chapter 1. clearer, more direct, less defensive.
- A specific sensory detail that appeared in Chapter 1 appears again.
  but the protagonist sees it differently now.
- Not a happy ending, but a CLEAR one. The protagonist sees truly,
  even if what they see is painful.

RESOLUTION:
- Brief. 1-2 chapters maximum
- Show the protagonist in their new reality. changed, scarred, but seeing clearly
- The world looks different now. The prose reflects this: clearer, more direct,
  less defensive
- Not necessarily happy. Psychological thrillers earn ambiguous or bittersweet endings.
- The protagonist has agency they didn't have at the start. even if the cost was high
- If the narrator was unreliable: a final passage that demonstrates they now see
  themselves clearly. Or: a final hint that their unreliability continues (darker ending).
- Avoid neat resolution of all threads. some psychological damage is permanent

TENSION ARC:
- Starts with unease (something is slightly off)
- Builds through accumulation (more things don't add up)
- Spikes at the midpoint (the comfortable lie breaks)
- Sustained high through Act 2B (every chapter reveals something disturbing)
- Peak at the final revelation (the full truth is worse than any partial version)
- Resolution: a different kind of tension. the weight of knowing
```

## Timeline Rules

```
PSYCHOLOGICAL THRILLER TIMELINE TRACKING

SUBJECTIVE VS OBJECTIVE TIME (CRITICAL):
- Track what time/date the NARRATOR believes it is
- Track what time/date it ACTUALLY is (if different. amnesia, blackouts, manipulation)
- Note any time gaps the narrator glosses over ("The next few days are a blur")
- Track when the narrator's timeline contradicts external evidence
  (receipts, phone records, other character accounts)
- If the antagonist is manipulating the protagonist's sense of time, track how

LINEAR NARRATIVE TIMELINE:
- Day-by-day tracking of present-timeline events
- Duration of the main narrative (psychological thrillers typically span days to weeks,
  rarely months)
- What happens on which day. the protagonist's routine, disruptions, investigations
- When does the protagonist sleep? (Insomnia is common and affects perception)
- When does the protagonist eat? (Anxiety suppresses appetite. track this)
- Track medication schedules if relevant (missed doses affect reliability)

DUAL TIMELINE MANAGEMENT (if using past/present):
- PAST TIMELINE: What happened and when, in chronological order
- PRESENT TIMELINE: What's happening now, how it connects to the past
- CONVERGENCE POINT: The moment where past and present collide
  (typically late Act 2 or early Act 3)
- Track which past events have been revealed in which present chapters
- Ensure past revelations arrive in an order that maximises dramatic impact
  (not simply chronological)
- The gap between the two timelines should narrow: early chapters might be
  years apart; by the climax, past and present are almost touching

NON-LINEAR NARRATIVE RULES:
- If memories are presented out of order, track the reading order separately
  from the chronological order
- Each memory/flashback must serve a present-tense purpose (reveals context,
  provides a clue, reframes a present event)
- Never use flashback as padding. every excursion into the past must change
  how the reader understands the present
- Flag which memories are reliable and which are distorted
- Track when the same memory is recalled differently (intentional contradiction)

MEDICATION AND SUBSTANCE TRACKING:
- What is the protagonist taking? Dosage? Schedule?
- When are doses missed or changed?
- Side effects that affect perception (drowsiness, confusion, memory gaps,
  emotional blunting)
- If the antagonist is tampering with medication, track what they've done and when
- Alcohol consumption: when, how much, and its effect on the narrator's reliability
  in the following scenes

COMMUNICATION AUDIT:
- Texts, calls, emails, messages: who contacted whom, when, what was said
- Deleted messages: if messages are deleted (by narrator or antagonist), track this
- Social media activity: timestamps, posts, messages that become evidence
- Which communications are verified (seen by others) vs. claimed by the narrator?
- Voicemails and their timestamps. useful for establishing what actually happened

SEASONAL AND ENVIRONMENTAL:
- Weather must be consistent within the timeline
- Seasonal details (daylight hours, temperature) must match the stated month
- If the narrative spans a holiday period, track relevant dates
- Changes to the domestic environment (redecorating, moving furniture). track dates
  and who made changes (especially important in gaslighting plots)

PSYCHOLOGICAL DETERIORATION TIMELINE:
- Map the protagonist's mental state chapter by chapter
- Sleep quality: declining across the narrative (occasional insomnia → chronic → crisis)
- Social functioning: withdrawing, cancelling plans, calling in sick
- Physical symptoms: tracking when headaches, nausea, trembling, etc. first appear
  and how they intensify
- The deterioration should be gradual and consistent. no sudden jumps
  without triggering events
```

## Genre-Specific Craft Techniques

Psychological thriller at the level of Patricia Highsmith,
Thomas Harris, Stephen King, Caroline Kepnes, Gillian
Flynn, Paula Hawkins, B.A. Paris, Greer Hendricks, Sarah
Pekkanen, Alex Michaelides, Colleen Hoover, Tana French,
Lisa Jewell, Ruth Ware, Agatha Christie, S.J. Watson, A.J.
Finn, Freida McFadden, and Rebecca Makkai earns its
genre-defining unease through unreliable-narrator
discipline, fair-play clue architecture, and psychological
authenticity. The form is uniquely vulnerable to a cluster
of failure modes that AI-generated drafts hit with
predictable frequency: **Cheating Twist** (revelation
depends on information withheld from a first-person
narrator who would obviously possess it — the genre's
single most-flagged structural failure); **No-Clues-Planted
Twist** (the reveal arrives from nowhere with no prior
seeding the reader can locate on reread); **Mental-Illness-
as-Gimmick** (psychological conditions deployed purely as
plot devices without authentic portrayal, often falling
into outdated split-personality or "crazy woman" tropes);
**Passive-Protagonist Drift** (the narrator observes and
reacts but never makes choices across the manuscript);
**Atmosphere Collapse** (more than two consecutive chapters
without psychological tension, the slow burn dropping into
inert exposition); **Gratuitous Manipulation** (gaslighting
or abuse depicted without emotional weight or consequence,
treated as entertainment); **Deus Ex Therapist** (a
professional character explains the entire psychological
dynamic in a single exposition scene that voids the genre's
slow-revelation contract); **Identity Whiplash** (the
narrator's unreliability is so extreme that the reader
gives up trying to track what's real, breaking the form's
reader-bond contract); **Misogynistic Framing** (female
protagonist's distress played for titillation rather than
empathy, "crazy woman" tropes reinforced rather than
interrogated); **Dream-Hallucination Resolution** ("it was
all in their head" as the entire resolution, voiding the
form's reality-anchor contract — at least some of the
dread must have been real); and **Manipulation-as-Romance**
(gaslighting portrayed as romantic or flattering, "he's so
protective," collapsing the ethical frame the genre
requires). The thirteen canonical techniques below — five
unreliable-narrator techniques (Confidence Anchor, Shifting
Memory, Tell-Tale Syntax, Objective Intrusion, Trusted
Secondary Source) plus four twist-construction rules (Fair
Play Doctrine, Emotional Reframe, Double-Bottom Twist,
Retroactive Reframe) plus four atmospheric-pressure
techniques (Domestic Uncanny, Social Performance, Ambient
Threat, Normalcy Trap) — are how the form defends against
these failure modes through specificity, fair play, and
psychological honesty.

### The Unreliable Narrator Toolkit

**Technique 1: The Confidence Anchor**
Establish the narrator's reliability through hyperspecific, verifiable details early on. When the narrator later proves unreliable about important things, the reader is more disoriented because they trusted the specificity. "The kitchen clock read 7:42. The toast was burning. I could smell it from the hallway. The dog was scratching at the back door." This level of detail says "trust me, I notice everything." Which makes the later gaps more powerful.

**Technique 2: The Shifting Memory**
When a narrator recalls a key event more than once, change a small detail. Not flagged, not commented on. The reader catches it. or catches it on reread. This is the gentlest form of unreliability, and the most unsettling.
- First recall (Ch.3): "He was wearing his blue jacket."
- Second recall (Ch.12): "He was wearing his grey jacket. no, blue. It was blue."
- The hesitation is the tell. The narrator is editing in real time.

**Technique 3: The Tell-Tale Syntax**
The narrator's sentence structure changes when they're lying or avoiding:
- Truthful passages: Concrete sensory detail, specific actions, grounded in the body
- Evasive passages: Abstract language, passive voice, vague time references
  ("At some point," "Eventually," "I must have")
- Lying passages: Overspecific justification, defensive tone, pre-emptive objection
  ("It wasn't like that," "Anyone would have done the same")

**Technique 4: The Objective Intrusion**
Introduce objective evidence that contradicts the narrator's account: a photograph, a dated receipt, a text message, another character's clear memory. Don't have the narrator acknowledge the contradiction directly. Let the reader sit with it.

**Technique 5: The Trusted Secondary Source**
A character the reader trusts (established as honest, grounded, consistent) gives a different account of events. The reader must choose: the narrator they've bonded with, or this credible witness? Ideally, both seem right. The truth is a third option.

### Twist Construction Rules

**The Fair Play Doctrine:**
- Every twist must be supported by at least 3 planted clues
- Clues must be VISIBLE on reread. not hidden in throwaway lines or deliberately obscured
- The best clues are in plain sight but misinterpreted (the reader assigns them to the wrong theory)
- Test: If a reader rereads Chapter 1 after finishing, they should gasp at what they missed

**The Emotional Reframe Rule:**
A twist that changes only the FACTS is a puzzle. A twist that changes the EMOTIONAL MEANING of what came before is art. The reader should feel the protagonist's pain, betrayal, or revelation viscerally. not just intellectually rearrange the plot pieces.

**The Double-Bottom Twist:**
The best psychological thrillers have two layers of revelation:
1. The surface twist (who did it / what really happened / who is lying)
2. The deeper truth (what it means about the protagonist / what it reveals about the relationship / the irreversible cost)
Layer 2 lands harder than Layer 1.

**The Retroactive Reframe:**
After the twist, specific earlier scenes should replay in the reader's mind with completely different emotional valence:
- The "loving" gesture was actually controlling
- The "memory lapse" was actually evidence of drugging
- The "helpful" character was actually surveillance
Map at least 5 scenes that transform after the revelation.

### Atmospheric Pressure Techniques

**The Domestic Uncanny:**
Make familiar spaces strange. The protagonist's own home becomes alien through small changes: a smell that shouldn't be there, a drawer in a different position, a window found open that was definitely closed. The horror is in the ordinary.

**The Social Performance:**
Scenes where the protagonist must appear normal while internally disintegrating. Dinner parties, work meetings, school runs. performed competence masking psychological crisis. The gap between the public face and the private reality IS the tension.

**The Ambient Threat:**
Not every chapter needs a plot event. Some chapters derive their tension entirely from atmosphere: the protagonist alone in the house, aware that something is wrong but unable to name it. Sound, light, temperature, the quality of silence. these are your instruments.

**The Normalcy Trap:**
Occasional chapters where everything seems genuinely fine. The antagonist is charming. The protagonist doubts their suspicions. The reader, who has more information, feels dread precisely BECAUSE the protagonist is relaxing their guard.

### Psychological Thriller AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "her mind was playing tricks on her" | Show the specific perceptual distortion |
| "the line between reality and fantasy blurred" | Show the specific moment of confusion |
| "paranoia crept in like a fog" | Show the specific behaviour paranoia causes |
| "was she losing her mind?" | Show the specific evidence that makes her doubt |
| "the gaslighting was subtle but effective" | Show the specific manipulation technique |
| "she couldn't trust her own memory" | Show the specific contradictory evidence |
| "the mask slipped" | Show the specific micro-expression or out-of-character moment |
| "nothing was as it seemed" | Show the specific reveal |
| "the walls of her reality were crumbling" | Show the specific discovery |
| "a twisted game of cat and mouse" | Show the specific move in the game |
| "the truth was more terrifying than the lie" | Show BOTH the truth and the lie specifically |
| "her world shattered" | Show the specific piece of information and physical reaction |
| "she felt herself disappearing" | Show the specific dissociative texture — the hands that don't feel like hers, the voice from the other room that turns out to be her own |
| "something deep inside her knew" | Render the specific intuition with its specific source: the smell, the half-glimpsed object, the contradiction she half-registered three days ago |
| "she was being watched" | Show the specific tell — the parked car, the curtain that moved, the username with no posts and a recent visit timestamp |
| "the past kept resurfacing" | Show the specific intrusion: the song in the supermarket, the smell of his cologne, the particular angle of light that triggered it |
| "she didn't recognise herself anymore" | Show the specific moment of self-strangeness — the photo she doesn't remember posing for, the sentence in her own handwriting she can't recall writing |
| "a sense of dread filled her" | Show the specific physical signature — the cold at the base of the skull, the inability to swallow, the impulse to check the lock again |

## Genre-Specific Revision Rules

### Six-Pass Psychological Thriller Audit (Run FIRST in editorial pipeline)

The Psychological Thriller Audit runs every chapter through
six named passes. Run them in order — each builds on the
last.

#### Pass 1: Narrator Integrity + Voice Consistency

The Narrator Integrity and Voice Consistency pass tests
the form's foundational unreliable-narrator contract. For
Narrator Consistency, verify the narrator's unreliability
is INTENTIONAL and tracked (not accidental authorial
error); that the level of reliability matches the planned
progression (more reliable early → less reliable middle →
either restored or fully collapsed by end); that
contradictions are deliberate and documented in the
continuity tracker; and that the narrator's voice remains
recognisably the same person even as reliability shifts.
For Voice Consistency, read ONLY the narrator's internal
monologue passages in sequence and verify it sounds like
one person across 300 pages. Track the narrator's
vocabulary, sentence rhythm, and verbal tics — these
should be consistent, or their change should reflect
psychological state in a way that traces a specific
deterioration arc. Verify the narrator's emotional
register matches their stated situation, or that any
mismatches are intentional unreliability rather than
authorial oversight. Confirm the narrator's observations
are filtered through their character (a painter notices
colour, a musician notices sound, a nurse notices physical
symptoms) — generic observation is the failure mode that
voids interiority.

#### Pass 2: Clue Architecture + Twist Fairness

The Clue Architecture and Twist Fairness pass enforces the
form's Fair Play Doctrine against the Cheating Twist and
No-Clues-Planted failure modes. List every planted clue
and its location across the manuscript; verify each clue
is visible but not highlighted (not too subtle, not too
obvious); confirm every clue has a payoff and every red
herring has a debunking. Apply the careful-reader test:
could a careful reader solve the mystery early? The ideal
answer is "almost, but not quite." For Twist Fairness,
reread Chapter 1 after knowing the twist and verify it
still works — every clue should be visible on reread, no
information withheld from a first-person narrator who
would obviously possess it. Confirm at least 3 chapters
where the clue was available (Fair Play Doctrine
requires minimum 3 planted clues per twist). The reading-
group test: would a reading group be split on "I saw it
coming" vs. "I never guessed"? Both reactions should be
possible — that is the sweet spot. The decisive test:
does the twist change the EMOTIONAL reading of earlier
chapters, not just the factual one? A twist that changes
only facts is a puzzle; a twist that changes emotional
meaning is the genre's masterclass-level achievement. Map
at least 5 specific scenes that transform after the
revelation.

#### Pass 3: Manipulation Plausibility

The Manipulation Plausibility pass enforces the form's
antagonist-psychological-coherence contract. Verify the
antagonist's manipulation is psychologically plausible
(matching documented patterns rather than movie-thriller
convention); that the manipulation escalates at a
believable pace (no sudden jumps from charm to violence
without intermediate steps); that other characters'
failure to notice the manipulation is explained by
specific narrative mechanisms (isolation imposed by the
antagonist, the antagonist's social charm, cultural
norms that read controlling behaviour as devotion); and
that the protagonist's failure to act is explained by
genuine psychological barriers (trauma bonding,
financial entanglement, fear of disbelief, gaslighting
residue) rather than authorial-convenience stupidity.
The manipulation toolkit must be specific and consistent:
isolation, reality distortion, emotional leverage, and
information control deployed with named techniques the
reader can track. The antagonist must escalate when
threatened — when the protagonist gets closer to the
truth, the antagonist's methods become more extreme,
never simply repeat. The pass also confirms the
antagonist's vulnerability — what they are protecting,
hiding, or compensating for — because flat-evil antagonists
fail the form's psychological-coherence contract.

#### Pass 4: Atmosphere & Dread

The Atmosphere & Dread pass enforces the form's slow-burn-
with-mounting-unease contract. Verify every chapter
carries at least a baseline of unease — no chapter drops
to neutral, even in apparent breathers. Map each chapter's
tension level (1-10): the line should trend upward with
strategic dips (never below 3 after Act 1, with the
longest gap between tension never exceeding 2 pages).
Verify "quiet" chapters are still unsettling — if not,
ambient details must be added (the smell that shouldn't
be there, the half-caught conversation, the moved object).
Verify the setting reflects and amplifies the
psychological state through pathetic fallacy used
deliberately rather than accidentally. Confirm the four
atmospheric-pressure techniques are deployed: Domestic
Uncanny (familiar spaces made strange through small
changes), Social Performance (scenes where the
protagonist must appear normal while internally
disintegrating), Ambient Threat (chapters that derive
tension entirely from atmosphere — sound, light,
temperature, the quality of silence), and Normalcy Trap
(occasional chapters where everything seems genuinely
fine, which the reader experiences as dread because they
hold more information than the protagonist). The
Atmosphere Collapse failure mode is the form's most
common killer; this pass is the defence against it.

#### Pass 5: Psychological Accuracy

The Psychological Accuracy pass is the form's defence
against the Mental-Illness-as-Gimmick and Misogynistic-
Framing failure modes. Verify mental health
representation is accurate and nuanced — if specific
conditions are named (PTSD, dissociation, BPD, OCD,
PPD), consult DSM-5 criteria and clinical-literature
sources, not movie portrayals. Verify trauma responses
are depicted realistically: PTSD intrusions, dissociation,
hypervigilance, hyperarousal, emotional numbing, and the
specific behavioural signatures of complex trauma must
match the actual lived experience documented in
clinical and survivor literature, not the dramatised
versions thrillers often default to. Verify the
antagonist's manipulation patterns match documented
coercive control, gaslighting, and narcissistic-abuse
patterns specifically; generic "emotional abuse" is the
failure mode. If the protagonist begins to heal, the
recovery process must be realistic — non-linear,
incomplete, hard-won, with setbacks and fragile gains.
The no-glorification rule applies absolutely:
manipulation must be shown as harmful, never as
glamorous, romantic, or flattering. The reader must
understand the manipulation is wrong even if the
protagonist cannot yet see it. The pass also verifies
the absence of the form's most damaging clichés:
amnesia without physiological or psychological
justification, split personality as twist, "it was all
in their head" as resolution, the dead character who
turns out to be alive without structural necessity.

#### Pass 6: Reader Trust Phase Integration

The Reader Trust Phase Integration pass verifies the
manuscript's deployment of the form's signature reader-
relationship architecture across all four phases. Phase 1
(Bond): verify the early chapters earn the reader's trust
in the narrator through specific, relatable, sympathetic
detail — the reader must LIKE being in this head before
the trust can be productively undermined. Phase 2 (Doubt):
verify the middle chapters introduce inconsistencies the
reader notices before the narrator does, without
confirming the reader's doubts (uncertainty must build,
not resolve). Phase 3 (Split): verify there is a
sustained passage where the reader holds two competing
theories — the narrator's version and a credible
alternative — both genuinely possible. Phase 4
(Revelation): verify the truth emerges as a cascade
rather than a single twist, with each piece clicking
into place such that the reader feels both "I should have
seen it" and "I never could have guessed." The decisive
integration test: never let the reader feel cheated. The
clues were there, the twist was fair, the emotional truth
was real even when the factual truth was different. The
pass closes by verifying the resolution honours the
form's contract on aftermath — endings may be ambiguous
or bittersweet (the genre earns these), some psychological
damage must be permanent, and if the narrator was
unreliable, the closing passage should either demonstrate
they now see themselves clearly or hint that their
unreliability continues for a darker register. Neat
resolution of all threads is a failure mode; honest
incompleteness is the form's contract.

## Names & Patterns to Avoid

### Psychological Thriller Character Names. NEVER USE
- Protagonist names: Any name that signals "victim" through softness or innocence
  (avoid naming her Lily, Daisy, or Angel unless interrogating the trope)
- Antagonist names: Names that telegraph menace (Damien, Drake, Malachi, Raven)
- The therapist: Dr. [Germanic surname] (avoid the cliché)
- Avoid giving every female protagonist a traditionally "pretty" name : 
  diversify across backgrounds and name styles

### Psychological Thriller Plot Patterns. AVOID
- "The woman no one believes" without examining WHY she isn't believed
  (misogyny, institutional failure, the antagonist's social capital. name the system)
- Amnesia as the sole plot device without physiological or psychological cause
- The protagonist discovers she's actually the villain. unless the entire book
  is structured to support this (it's extremely hard to do well)
- The antagonist is simply "a psychopath". this is not a motivation, it's a label.
  Give them a real psychological profile.
- "It was all a dream / hallucination / delusion" as the twist. some of it must be real
- The protagonist's instincts are right about everything from the start. then there's
  no mystery, just other characters not listening
- The dead character who turns out to be alive (overused; if using, it must be
  structurally essential, not a cheap shock)
- Split personality as a twist (outdated, clinically inaccurate, offensive to
  people with DID)
- The boyfriend/husband did it because he's "controlling". develop a REAL psychology
  beyond "bad man is bad"

### Psychological Thriller Title Patterns. AVOID
- "The [Woman/Girl/Wife] in/on/at the [Location]" (done to death)
- "Behind [Object/Location]" (Behind Closed Doors was great; the copies are tired)
- "The [Adjective] [Female Relative]" (The Perfect Wife, The Silent Patient : 
  these worked but the format is exhausted)
- Single-word abstract nouns (Trust, Gone, Dark, Lost). too generic

### Use Instead
- Names that feel real and specific to the character's background, age, and region
- Antagonists who are charming, successful, and psychologically specific
- Twists that emerge from CHARACTER rather than plot machinery
- Endings that acknowledge the complexity of psychological damage and recovery
- Multiple sources of unreliability (not just one gimmick)
- Cultural and socioeconomic specificity that grounds the psychological dynamics
  in real-world power structures

## Comp Titles

Psychological-thriller's comp-title set supports
manuscript positioning: market category placement,
cover-design conversation, reader-expectation
calibration, similar-author discovery, and editorial /
agent submission framing.

### Canonical (foundational reference points)

- *The Talented Mr. Ripley* — Patricia Highsmith (1955): obsessive-impostor psychological-thriller archetype.
- *Strangers on a Train* — Patricia Highsmith (1950): the murder-pact psychological-thriller template.
- *The Silence of the Lambs* — Thomas Harris (1988): psychological-thriller-procedural hybrid.
- *Misery* — Stephen King (1987): captor-victim psychological-thriller benchmark.

### Contemporary (current best-in-class)

- *Gone Girl* — Gillian Flynn (2012): the modern psychological-thriller benchmark; reframed the category.
- *The Girl on the Train* — Paula Hawkins (2015): unreliable-narrator psychological-thriller; mass-market success.
- *Behind Closed Doors* — B.A. Paris (2016): contemporary domestic-psychological-thriller.
- *The Wife Between Us* — Greer Hendricks & Sarah Pekkanen (2018): twist-led psychological-thriller.
- *The Silent Patient* — Alex Michaelides (2019): therapist-protagonist psychological-thriller.
- *Verity* — Colleen Hoover (2018): psychological-thriller with manuscript-as-evidence; viral commercial success.
- *I Have Some Questions for You* — Rebecca Makkai (2023): literary psychological-thriller with podcast frame.

## Cover Design Specifications

### Recommended Visual Styles
- **Abstract**. Distorted, fragmented, or manipulated imagery that reflects fractured perception. Double exposures, kaleidoscopic effects, warped reflections. The cover should feel like the mind playing tricks. perfect for unreliable narrator and identity subgenres.
- **Minimalist**. A single unsettling image on a stark background: a cracked mirror, a pill, a key, a blurred face. Maximum psychological impact through visual restraint. The emptiness around the object IS the tension.
- **Typographic**. Large-scale typography as the primary design element, often with subtle visual tricks embedded in the letterforms (a letter reversed, a word obscured, a crack running through the title). The text itself becomes the puzzle.
- **Photorealistic**. Heavily processed photography with psychological distortion: faces half in shadow, double exposures overlaying two identities, out-of-focus figures, reflections that don't match their source. The uncanny valley of familiar faces made strange.

### Genre Cover Aesthetics
- **Styles:** Fragmented and distorted, double-exposure layering, mirror/reflection imagery, unsettling symmetry, faces partially obscured or multiplied, clinical minimalism, the uncanny ordinary
- **Colours:** Cold palettes dominate. icy blues, washed-out greys, clinical whites, deep blacks with blue undertones. Accent colours are muted: bruised purple, drained teal, sickly amber. Warmth is used only to create unease (a warm light in a cold composition feels wrong). Avoid saturated, vivid colours. this genre lives in desaturation.
- **Elements:** Fragmented or split faces, mirrors and reflections (especially distorted), silhouettes with missing or doubled features, pill bottles, glass surfaces, windows, staircases, empty corridors, out-of-focus figures in backgrounds, eyes (watching, obscured, multiplied), handwriting and diary pages
- **Typography:** Clean, modern typefaces. often with a visual disruption (a letter displaced, a word fading, a crack through the title). Sans-serif for clinical precision or elegant serif for literary psychological thrillers. The type treatment should subtly signal that something is off. Avoid decorative or horror-style fonts.

### Subgenre Variations
- **Unreliable Narrator**. Distorted faces, double exposures, text that appears to shift or fragment. The cover should make the viewer question what they're seeing. Layered imagery where two realities coexist.
- **Gaslighting / Coercive Control**. Domestic spaces made strange, figures that are present but indistinct, light sources that feel artificial or interrogative. Muted, drained palettes suggesting a world where colour has been stolen.
- **Obsession**. Close-up imagery (an eye, a mouth, hands), voyeuristic framing, surveillance-style photography. The cover should feel uncomfortably intimate. the viewer is too close.
- **Locked Setting**. The building itself as the central image (the house, the hotel, the island), rendered with architectural precision but unsettling emptiness. Isolation made visual.
- **Identity / Amnesia**. Blank or obscured faces, mirrors showing different reflections, fragmented portraits, missing puzzle pieces. The cover should embody the question "who am I?"

### Market Positioning
Psychological thriller covers must signal INTELLIGENCE and UNEASE at thumbnail size. The genre's readers are looking for mind games, not action. covers should feel cerebral, not visceral. Clean compositions with high contrast between dark backgrounds and pale focal elements perform best on Amazon. The title must be legible at small sizes but can incorporate subtle visual tricks that reward closer inspection. Position between the Gillian Flynn end (bold, typographic, high-concept) and the Tana French end (atmospheric, literary, restrained). Avoid anything that looks like horror (too dark, too gory), romance (too soft, too warm), or action thriller (too loud, too busy). The psychological thriller cover promises the reader a puzzle, not a ride.

### Cover Design DON'Ts
- Do NOT use explosions, guns, car chases, or overt violence. psychological thrillers are about what happens INSIDE the mind, not outside
- Do NOT use horror imagery (dripping blood, screaming faces, gothic fonts). this genre is unsettling, not frightening
- Do NOT use bright, warm colours. psychological thrillers are cold and clinical by convention
- Do NOT use overly complex compositions. the best psych thriller covers have one focal element and negative space
- Do NOT use generic "woman from behind" stock photography. this trope is critically exhausted and signals low production value
- Do NOT use literal depictions of plot events (a character being pushed, a specific crime scene). the cover should suggest mood, not narrate story
- Do NOT use playful or whimsical design elements. nothing about a psychological thriller cover should feel light or fun
- Do NOT use heavily gendered design (all-pink, cursive scripts, floral elements). psychological thrillers have a cross-gender readership and covers should reflect that
