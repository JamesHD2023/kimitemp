---
name: gothic-romance-genre
description: Genre-specific instructions for Gothic Romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Gothic Romance. Genre Plugin

## Metadata
- id: gothic-romance
- name: Gothic Romance
- icon: 🏚️
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Romancing the Beat", "Three-Act Structure", "Freytag's Pyramid", "Hero's Journey", "Horror Fear Arc"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| **Classic Gothic Romance** | The Brontë/du Maurier tradition. isolated estates, brooding heroes, imperilled heroines, and mysteries woven through crumbling architecture. Atmosphere is paramount; the supernatural may be suggested but never confirmed. | Slow-burn pacing, literary prose register, ambiguous supernatural, heavy emphasis on setting as emotional mirror. The romance resolves through truth-telling rather than action. |
| **Southern Gothic Romance** | Decaying plantation houses, humid landscapes, family secrets rotting beneath polite surfaces. Combines gothic dread with the social complexities of the American South. race, class, religion, and inherited guilt. | Warmer, more oppressive atmosphere (heat rather than cold). Social critique layered beneath the romance. Family as the source of gothic horror. Dialect and voice carry significant weight. |
| **Modern Gothic** | Contemporary settings reimagined through a gothic lens. isolated country houses, remote coastal properties, crumbling urban mansions. The protagonist is a modern woman confronting old darkness. | Present-day language and sensibility. Technology exists but fails or is absent (no mobile signal, power cuts). Psychological tension often replaces supernatural ambiguity. Faster pacing than classic gothic. |
| **Haunted House Romance** | The estate itself is the primary antagonist and catalyst. The house's history drives the mystery; the romance develops as the protagonists investigate together. Supernatural elements are typically more overt. | Architecture and spatial discovery dominate the plot. Dual timeline common (past inhabitants, present lovers). The house must be resolved. healed, escaped, or accepted. alongside the romance. |
| **Byronic Hero Romance** | Centres the complex, morally ambiguous love interest as the primary source of both attraction and danger. The protagonist must decide whether the Byronic figure can be trusted. and whether love can survive their darkness. | Character-driven rather than setting-driven. The love interest's psychology is the mystery. Higher emotional intensity. Risk of romanticising harmful behaviour must be handled with care and nuance. |
| **Gothic Mystery Romance** | Whodunit structure wrapped in gothic atmosphere. A crime or disappearance drives the plot; the romance develops between investigators or between suspect and sleuth. Clue-planting and fair-play mystery rules apply. | Tighter plotting required. Mystery must be solvable by the reader. Romance complicated by suspicion. the love interest may be the prime suspect. Resolution demands both romantic and mystery satisfaction. |

## Architect Instructions

```
STRUCTURE

Chapter length: 3,000-4,000 words
Pacing: Slow-burn atmosphere with emotional tension building gradually
Must open with: Atmospheric hook, arrival at mysterious location, or encounter with brooding presence
Must close with: Romantic tension deepened, gothic mystery advanced, or ominous revelation

GENRE PROMISE

Intertwine longing, dread, beauty, and danger. The emotional core is a romance wrapped in shadows, secrets, and emotional vulnerability.

Core elements:
- Atmosphere heavier than plot
- Emotion intensified by danger and mystery
- Setting as a living entity (estate, ruined chapel, stormy cliffs)
- Love and fear feeding each other
- Mystery that reveals emotional truth

STRUCTURE OPTIONS

The Arrival: Protagonist enters mysterious estate, brooding love interest, secrets surface, emotional revelation pairs with gothic mystery resolution
The Haunting of the Heart: Romance deepens through uncanny encounters, apparitions reflect emotional wounds, supernatural literal or metaphorical
Forbidden Love in the Shadows: Emotional closeness = increasing danger, love interest may be protector or threat. or alternating

BEATS PER CHAPTER

1. Atmospheric Mood: Weather, architecture, silence, shadows reflecting emotional states
2. Romantic Tension: Longing restrained by fear or mystery, alluring + dangerous + vulnerable love interest
3. Gothic Element: Secret, symbol, omen, locked room, or mysterious past
4. Emotional Vulnerability: Fear, longing, or wound exposed
5. Mystery Advancement: New clue, revelation, or deepening of central enigma

GENRE-SPECIFIC REQUIREMENTS

- Setting must feel alive: estate, manor, ruins as character with history
- Romance must smolder: restrained desire, danger heightening attraction
- Emotional wounds drive plot: trauma, secrets, guilt, forbidden desire
- Supernatural may be real, false, or metaphorical: always tied to emotion
- Gothic duality throughout: beauty/decay, love/fear, light/shadow
- Secrets and omens in every chapter: locked rooms, mysterious pasts, whispers

OBSTACLE LAYERING (critical for romantic tension)

Gothic romance demands MULTIPLE simultaneous obstacles. never rely on a single barrier. Layer internal obstacles (fear of vulnerability, past wounds, self-sabotage) with external ones (the gothic setting itself, societal expectations, the mystery threatening safety). Each new obstacle should make the reader yearn MORE for the couple to connect. The more effective the obstacles, the more the reader aches for every stolen moment of tenderness in the shadows.

LIGHT AND SHADE

Never write one-note darkness. After a scene of deep gothic dread, follow with unexpected warmth. a moment of humor, tenderness, or beauty. After a scene of romantic closeness, shatter it with an ominous revelation. This contrast amplifies both the terror and the longing. Think of adjacent scenes as emotional opposites that intensify each other. the party next door to the funeral.

FORBIDDEN

- Over-explanation of supernatural
- Romance without stakes or danger
- Flat settings without atmospheric detail
- Removing gothic tension too early
- Action thriller pacing: gothic romance is slow-burn
- Stereotypical heroes/heroines: no default brooding lord + trembling maiden without complexity
- Single-obstacle stories: one barrier is not enough to sustain gothic romantic tension
- Relentless darkness without emotional variation: dread without relief exhausts rather than terrifies
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (forbidden bond), Captivation (atmosphere & place), Anticipation (dread + longing twin engines).

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-agent.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE

POV: 1st person or close 3rd. deep interiority essential for gothic romance
Tense: Past (traditional gothic) or present (heightened immediacy)
Voice: Lush, atmospheric, introspective. emotional intensity through setting and sensory detail
Tone: Brooding, melancholic, romantically charged. beauty tinged with dread

PROSE IMPERATIVES

1. Setting Is a Character
   - Weather, silence, architecture, shadows
   - Reflect emotional states
   - Estate/location should feel alive with history

2. Sensory Mood Rules Everything
   - Describe with lush detail, but with purpose
   - Texture, temperature, light, sound
   - Gothic atmosphere through concrete sensory detail

3. Romantic Tension Must Smolder
   - Longing restrained by fear or mystery
   - Love interest: alluring + dangerous + vulnerable
   - Desire expressed through restraint

4. Emotional Wounds Drive the Plot
   - Trauma, secrets, guilt, forbidden desire
   - Past wounds echo through present action

5. Slow-Burn Pacing
   - Gradual reveals
   - Quiet dread > jump scares
   - Tension accumulated through atmosphere

6. Secrets & Omens
   - Locked rooms, mysterious pasts, strange symbols
   - Whispers, letters, dreams
   - Each chapter contains mystery element

7. Gothic Duality
   - Beauty + decay
   - Love + fear
   - Light + shadow

8. Supernatural Ambiguity
   - May be real, false, or metaphorical
   - Always tied to emotional truth

9. Language Should Be Evocative
   - Lyrical, moody, lush prose
   - Sensory richness without purple excess

10. Endings Should Be Haunting
    - Bittersweet romance acceptable
    - Emotional catharsis through truth
    - Lingering beauty even in resolution

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- Atmospheric dread AND romantic intrigue from the opening paragraph
- Tension floor: 6 (the reader must feel both unease and fascination immediately)
- Open with arrival, approach, or first encounter: the setting looming, the love interest glimpsed or felt
- Dialogue density: 20-25%: atmosphere dominates Ch 1; the house speaks louder than people

Gothic atmosphere scenes (prose rhythm):
- Long, layered sentences building menace: clause upon clause accumulating dread like fog
- Sensory detail lush and purposeful: temperature, sound, light quality, the weight of silence
- Paragraphs breathe slowly; the reader should feel time stretching in the gothic space
- Interiority budget: 45%: the protagonist's perception of the setting IS the horror

Romantic-encounter scenes (prose rhythm):
- SHORT sentences when the love interest appears or speaks: electric, immediate, cutting through atmosphere
- The contrast with gothic prose IS the effect: long atmospheric buildup punctuated by sharp romantic awareness
- Dual rhythm: gothic (long, layered, sensory) vs. romance (short, charged, direct): alternate within scenes

Climax/resolution prose rhythm:
- Gothic crisis: sentences fragment as truth surfaces: short, breathless, revelation stripped of ornament
- Romantic resolution: prose settles into something warmer but never loses its gothic edge
- Final beat: haunting, beautiful, lingering: the prose should echo after the last line

DIALOGUE. THE POWER OF THE UNSAID

- Subtext-heavy: characters rarely say what they mean until climactic moments
- Period-appropriate if historical setting
- Love interest's dialogue should be enigmatic, alluring
- Emotional truths revealed through what's NOT said
- Holding back dialogue gives enormous resonance to the moment characters finally express themselves
- Conversations should be a push-pull game: exploration and retreat, flirtation masked as antagonism
- Each character must speak distinctly: the protagonist's voice should never be confused with the love interest's, even without dialogue tags
- The most powerful romantic exchanges happen when both characters are disturbed by what they feel but cannot name it directly
- Restraint in dialogue IS the foreplay: when characters finally say what they mean, the reader should feel the release of chapters of accumulated tension

METHOD WRITING. EMOTIONAL IMMERSION

- The writer must FEEL the gothic atmosphere and romantic longing while crafting each scene
- Write through the senses: what does the protagonist smell in that decaying library? What does the love interest's voice do to their pulse? What is the exact temperature of accidental contact?
- If a scene of emotional revelation doesn't move the writer, it won't move the reader: go back and find what's blocking the emotion
- Identify the specific feeling you want the reader to experience BEFORE writing the scene. dread? longing? devastating tenderness?. then build every sensory detail toward that feeling
- Never be cynical about emotion: don't kill a character or deliver a revelation purely for shock. Genuine emotion, earned through character investment, is what makes readers weep

INTIMATE SCENES (if present)

- Gothic romance intimacy should illuminate character and relationship, not merely titillate
- Sex scenes must serve a narrative purpose: marking a pivot in the relationship, revealing vulnerability, or deepening the central conflict
- Write through sensory detail: the specific textures, temperatures, and sounds of the gothic space around the lovers
- Awkwardness and imperfection make intimacy more authentic than choreographed perfection
- Build physical intimacy into the emotional landscape: what the characters feel about each other matters more than what their bodies do
- The gothic setting should remain present even in intimate moments: shadows in the peripheral vision, the creak of ancient floorboards, candlelight flickering

PSYCHOGEOGRAPHY: THE ESTATE'S HIDDEN AUTOBIOGRAPHY
The gothic romance estate is not merely a setting. it is accumulated history made architectural, and its past should generate the plot:

**The estate as palimpsest. layer upon layer of purpose:**
  "The east wing had been a chapel before Lord Ashworth's grandfather converted it to a gallery. She could still see the tracery in the windows, the niche where a saint once stood, now empty, filled with shadow. The gallery's paintings hung on walls that had heard centuries of prayer. She wondered if the walls remembered. She was beginning to think they did."
  Every room in a gothic romance conceals an earlier purpose. and that purpose shapes the present mystery.

**Techniques for psychogeographic depth in gothic romance:**
- The protagonist's exploration of the estate IS the romantic plot: each room reveals a secret about the love interest, each passage conceals a chapter of family history
- Hidden architectural features as romantic revelation: a walled-up door, a sealed room, a garden path that leads somewhere unexpected: each discovery brings the protagonist closer to the truth AND to the enigmatic figure at the story's heart
- The grounds as emotional map: the overgrown garden represents what was neglected, the locked chapel represents what was forbidden, the tower represents what was hidden
- Local legends attached to the estate carry encoded family secrets: "They say the Lady of the Rose Window still walks..." is both atmosphere and clue
- Seasonal change on the estate mirrors the relationship's arc: autumn arrival (mystery, uncertainty), winter deepening (isolation, intimacy, fear), spring revelation (truth, transformation)
- The estate's history should eventually illuminate the love interest's wounds: why they are who they are is inseparable from where they live and what happened within these walls
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Atmospheric immersion. gothic setting vivid and alive, weather reflecting emotional states, sensory details lush but purposeful
2. Romantic tension. longing smouldering beneath the surface, desire restrained by fear or mystery, love interest alluring, dangerous, and vulnerable
3. Gothic duality maintained. beauty and decay, love and fear, safety and danger coexisting in every scene
4. Emotional depth. protagonist's feelings shown through action and detail, wounds driving the plot, vulnerability earned
5. Mystery progression. central enigma advanced each chapter, clues planted fairly, tension sustained without frustration

GENRE-SPECIFIC CHECKS

Setting as emotional mirror: Weather, architecture, and landscape reflect and amplify character feeling. storms during conflict, oppressive stillness during dread
Gothic imagery present: Omens, secrets, symbols, locked doors, portraits, candlelight, shadows. the visual language of gothic romance sustained
Slow-burn pacing: Atmosphere builds without dragging. romantic and gothic beats balanced within each chapter
Love interest complexity: Brooding but not one-note. vulnerability visible beneath danger, past wounds shaping present behaviour
Supernatural restraint: If supernatural present, it serves emotional truth rather than spectacle. mystery preserved
Sensory richness: Readers can feel the cold stone, smell the old wood, hear the creak of floorboards. gothic immersion through physical detail
Dual genre satisfaction: Both genuinely romantic AND genuinely gothic. neither genre merely decorative
HEA/HFN trajectory: Romance arc progressing toward satisfying resolution despite gothic obstacles

AUTOMATIC FAILS

Flat, generic setting: Estate or manor without atmospheric specificity. could be any old house anywhere
Modern thriller pacing: Action and revelation speed that breaks the gothic slow-burn mood
Love interest without vulnerability: Brooding hero who is purely dark and dangerous with no tenderness or wounds shown
Romance without stakes: Attraction present but no genuine danger, fear, or mystery threatening the relationship
Over-explained supernatural: Mystery and ambiguity destroyed by rational explanation or detailed paranormal rules
Protagonist passive: Heroine who only reacts and never investigates, challenges, or chooses. gothic romance requires agency within constraint
Gothic elements as decoration: Omens and symbols present but carrying no weight or consequence

ACCEPTABLE IMPERFECTIONS

Dense atmospheric prose. gothic romance demands richer language than contemporary genres
Slow pacing if every scene deepens mood, mystery, or romantic tension
Ambiguity about supernatural elements. gothic romance thrives on uncertainty
Love interest remaining mysterious for extended stretches if tension maintained
Period-influenced language or slightly formal register. genre expectation, not a flaw

RED FLAGS TO INVESTIGATE

Atmosphere concentrated in chapter openings then forgotten. gothic mood must be sustained throughout
Romance and mystery operating on separate tracks. never intersecting within scenes
Love interest's behaviour inconsistent. dangerous in one scene, tender in the next without earned transition
Gothic imagery repetitive. same symbols recycled without development or deepening
No sense of the house or estate as a presence. setting passive rather than active force in the story
Protagonist's emotional wounds mentioned but not dramatised. told about past trauma without seeing its present effects
Clues or omens planted but never paid off. gothic romance requires symbolic cohesion
Intimate moments lacking gothic atmosphere. the setting should remain present even during tenderness
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES

Setting details: Manor layout, weather patterns, recurring symbols, gothic imagery
Love interest behavior: Brooding but consistent, wounds and triggers tracked
Mystery progression: What is known vs unknown, clues planted and revealed
Protagonist emotional arc: Fear → longing → truth → resolution
Symbolic objects: Keys, letters, portraits, locked rooms, heirlooms

GENRE-SPECIFIC TRACKING

- Gothic imagery must remain consistent (symbols, omens, recurring images)
- Estate/setting geography: rooms, passages, grounds, secret spaces
- Weather patterns and their emotional significance
- Love interest's past: wounds, secrets, tragic history
- Supernatural elements: if present, rules must be consistent
- Romantic progression: from fear/attraction to vulnerability/trust

ACCEPTABLE FLEXIBILITY

- Exact timeline if mood and pacing maintained
- Minor setting details if core gothic imagery consistent
- Background character specifics if not plot-critical

CRITICAL CONSISTENCY

- Omens must remain meaningful: pay off planted symbols
- Love interest's emotional wounds: consistent triggers, consistent healing
- Mystery elements: clues must lead to truth, no contradictions
- Gothic atmosphere: don't break mood with anachronistic elements
- Characters must walk a true line: cannot suddenly act out of character for plot convenience
- What characters have SAID and NOT SAID to each other tracked precisely: the unsaid accumulates power
- Obstacle progression: obstacles introduced must be resolved meaningfully, not vanish when convenient
- Emotional highs and lows must alternate: track chapter-by-chapter emotional register to ensure contrast and variation
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Emotional authenticity: Fear and desire coexist, neither fully dominant. internal tension constant
2. Gothic archetypes honored: Byronic love interest, vulnerable protagonist, mysterious supporting cast
3. Wound consistency: Past traumas inform present behavior and slowly reveal through story
4. Atmosphere sensitivity: Characters respond to setting, weather, and supernatural with appropriate intensity
5. Slow-burn romance: Attraction builds through proximity and danger, not instant declaration

CHARACTER BUILDING. GROUND UP

Build every significant character from the ground up BEFORE they appear on the page. Ask foundational questions:
- What do they want out of life? What is stopping them?
- What is their relationship with their family? Where did they grow up?
- What do they carry with them (literally and emotionally)?
- Set character tests: How would they react to witnessing cruelty? To an act of unexpected kindness? To being caught in a lie?
- The vast majority of this backstory will never appear on the page, but it informs every reaction, every line of dialogue, every choice

ANTI-STEREOTYPE IMPERATIVE

Avoid default gothic archetypes without depth. No brooding lord who is dark "just because." No trembling maiden whose only quality is sensitivity. The great joy of gothic romance is taking flawed, unconventional people who shouldn't be together, who get things wrong, but whom readers believe in and root for. Your protagonist can be prickly, difficult, funny, or fierce. Your love interest can be gentle, awkward, or wounded in ways that manifest as kindness rather than cruelty. Stereotypes get in the way—complexity draws readers in.

GENRE-SPECIFIC CHARACTER ELEMENTS
- Protagonist vulnerability: Introspective, emotionally open, wounded past or longing for connection: but never passive or helpless
- Heightened sensitivity: Protagonist attuned to atmosphere, omens, and the uncanny
- Courage through fear: Pursues truth despite terror, drawn to mystery
- Capacity for deep feeling: Romantic intensity matching gothic emotional register
- Love interest complexity: Alluring, dangerous, wounded: but with specific, earned reasons for their darkness, not generic brooding
- Guarded heart: Love interest's tenderness glimpsed through cracks in armor: these moments must be EARNED, not arbitrary
- Tragic history: Past events explaining love interest's darkness and isolation: built through the ground-up character process
- Secrets driving behavior: What love interest hides shapes actions until revealed
- Gothic supporting cast: Housekeeper, groundskeeper, mentor, rival, spectral presence: each with distinct voice and function
- Setting as character: House/castle has personality, moods, and possibly will
- Messy and flawed characters are always more compelling than perfect ones: flaws create growth potential, and growth is what romance readers crave

CHARACTER ARCS MUST
- Protagonist arc: Fear → attraction → vulnerability → truth → love or loss
- Love interest arc: Guarded → glimpses of heart → wound revealed → choice to trust or retreat
- Relationship arc: Danger → longing → intimacy → crisis → binding or breaking
- Mystery arc: Curiosity → investigation → revelation → reckoning
- Show transformation through accumulated emotional experiences, not single epiphany

TRACK FOR PROTAGONIST
- Emotional state chapter by chapter: fear, desire, confusion, resolve
- Growing attraction to love interest: specific moments, physical responses
- Fear vs. desire balance: which dominates when, why shifts occur
- Discovery of truths about love interest and setting: what's learned, impact
- Physical isolation and its psychological effects
- Response to supernatural or uncanny elements

TRACK FOR LOVE INTEREST
- Consistency of brooding behavior: what triggers withdrawal, what prompts tenderness
- Gradual revelation of wounds: what's shown when, in what context
- Moments of vulnerability: earned, not arbitrary, tied to emotional stakes
- Protective vs. threatening balance: when each emerges, why
- How history explains present behavior
- Genuine feeling beneath the mystery

SUPPORTING CHARACTER FUNCTIONS
- Intensify mood and mystery: cryptic warnings, ominous silences
- Hold pieces of truth: reveal at appropriate pacing
- Can be allies, obstacles, or both: loyalty unclear
- Mirror or contrast protagonist's situation
- Connect present to gothic past

GOTHIC PSYCHOLOGY
- Fear and desire intertwined: danger heightens attraction
- Isolation intensifies emotion: no escape, no distraction
- Past intrudes on present: ghosts literal or emotional
- Beauty in darkness: attraction to the forbidden, the wounded, the dangerous
- Vulnerability as strength: emotional openness enables connection and healing

THEME BENEATH THE GOTHIC SURFACE

Every gothic romance should have a THEME. what the book is really about beneath the mystery and the longing. Theme adds a dimension that lingers after the story ends. Common gothic romance themes: the cost of secrets, the prison of isolation, healing through truth, the courage to trust after betrayal, the way the past haunts the present until confronted. Pin the theme above the story and let it inform every chapter. When a reader finishes the book, it is often the theme that stays with them long after the plot details fade.
```

## Arc Rules

```
THREE-ACT STRUCTURE

Core arc shape:
- Atmospheric arrival
- Growing attraction through fear
- Gothic mystery deepening
- Emotional wounds revealed
- Crisis point
- Truth unearthed
- Romantic resolution (haunting, bittersweet, or tender)

ACT I (Chapters 1-8): Haunting World Established
- Atmospheric hook
- Arrival at gothic setting
- First encounter with love interest
- First omen or uncanny moment
- Emotional isolation of protagonist
- Growing attraction despite fear

Purpose: Establish gothic atmosphere, introduce romantic tension, plant mystery seeds

ACT II (Chapters 9-22): Deepening Shadows
- Secrets revealed slowly
- Romantic tension intensifies
- Gothic encounters escalate
- Revelation of love interest's wound
- Supernatural element develops
- Trust and fear in tension

Purpose: Build romantic and gothic stakes simultaneously, reveal emotional truths

ACT III (Chapters 23-30): Truth and Resolution
- Gothic crisis (storm, apparition, locked room revelation)
- Emotional breaking point
- Truth revealed
- Final choice: unite or part
- Romantic resolution
- Gothic aftermath: lingering emotion

Purpose: Resolve mystery, fulfill romantic promise, leave haunting impression

REQUIRED CHECKPOINTS

- Chapter 3: Gothic atmosphere fully established, love interest introduced
- Chapter 8: First significant romantic moment, mystery deepens
- Chapter 15: Love interest's wound glimpsed, emotional stakes raised
- Chapter 22: Major gothic revelation, romantic crisis
- Chapter 28: Truth unearthed, emotional climax
- Chapter 30: Resolution: haunting, bittersweet, or tender

ARC THEMES

- Love through fear
- Beauty in sorrow
- Healing through revelation
- Emotional illumination through darkness

EMOTIONAL HIGHS AND LOWS. THE CONTRAST PRINCIPLE

Chart the emotional arc visually. Know when each character is at their highest and lowest points. After a scene of romantic warmth and closeness, drop in an ominous revelation. After a scene of pure gothic dread, allow a moment of unexpected tenderness or dark humor. This principle of emotional contrast is what separates compelling gothic romance from monotonous gloom. The reader should never be able to predict whether the next scene will break their heart or make it soar. and each emotional extreme should amplify the one that follows.

EARNED ENDINGS

The ending must be TRUE to the characters built throughout the story. A gothic romance ending doesn't have to be conventionally happy—but it must have emotional truth and, ideally, hope. If a character has been established as decisive and clear-minded, they cannot suddenly waver at the end to serve the plot. If the story has been building toward a bittersweet resolution, don't swerve to sunshine because it seems easier. The ending that is most authentic to your characters is always the right one, even if it surprises you. Seed plot twists early so they feel earned when revealed—the reader should think "I didn't see that coming, but of course."
```

## Timeline Rules

```
TIME SCALE
- Total story duration: Weeks to months (gothic romance needs time for atmosphere and slow-burn tension)
- Chapter time span: Days to weeks: time moves with emotional intensity, compressed during gothic events
- Time progression: Atmospheric pacing: slow during romantic tension, accelerating during reveals and crisis

GENRE-SPECIFIC TEMPORAL RULES
- Weather and season progress consistently: storms don't appear from nowhere
- Gothic events cluster at night, during storms, at liminal times (dusk, midnight, dawn)
- Romantic tension builds over multiple encounters: slow-burn is essential
- Mystery reveals paced deliberately: not too fast (loses dread), not too slow (loses reader)
- Isolation creates timelessness: days blend in remote manor or castle
- Letters and messages take realistic time to arrive (if period setting)
- Seasons mirror emotional arc: autumn decay, winter desolation, spring rebirth
- Full moons, storms, and anniversaries as temporal markers
- Past events intrude through flashback, dream, or revelation
- Supernatural doesn't follow normal time: ghosts tied to specific hours, curses to dates

TRACK CAREFULLY
- Time between romantic encounters: anticipation requires spacing
- Progression of gothic mystery reveals: what's known when, building dread
- Seasonal/weather changes and their emotional symbolism
- Night vs. day scenes and their different tones and dangers
- Duration of protagonist's isolation in gothic setting
- Time since traumatic past events (for love interest's wounds)
- Storm patterns: don't have constant storms, make them matter
- Anniversaries of deaths, tragedies, or supernatural events
- How long protagonist has known love interest vs. intensity of feeling

FLEXIBLE
- Exact dates unless anniversary or supernatural timing matters
- Precise duration of individual gothic encounters
- Background character schedules

ATMOSPHERIC TIME
- Time feels different in gothic spaces: hours stretch, nights are endless
- Storms should have realistic duration (hours, not days) unless supernatural
- Candlelight and firelight create different temporal feel than daylight
- Seasons affect available light, weather, and emotional atmosphere
- Gothic time is subjective: terror stretches moments, desire accelerates hours
```

## Genre-Specific Craft Techniques

Gothic romance lives or dies on the integration of its two
genres. A romance set in a gothic house is not gothic romance.
A gothic novel that happens to have a love interest is not
gothic romance. The form requires that the gothic apparatus
(the house, the secret, the wounded other, the uncanny) is
itself the romantic apparatus. Each of the techniques below is
how that integration is achieved at the level of the line, the
scene, and the chapter.

### The House as Character

The estate, mansion, parsonage, or dwelling must function as a
sentient participant in the romance, not as backdrop. Rooms feel
different depending on who occupies them; corridors seem longer
at night; the house responds to the emotional state of its
inhabitants — doors stick when secrets are kept, windows clear
when truth is spoken, the air in a particular room becomes
heavier when the wrong person enters. This is not literal magic
(unless the subgenre is gothic-paranormal); it is the heroine's
heightened perception rendered as the building's behaviour. The
craft test: can the reader picture three specific rooms by the
end of chapter five, and does each carry distinct emotional
weight? If the house could be swapped for any other large old
building without altering the romance, the technique has not
been deployed.

### The Secret in the Walls

Architectural revelation must double as romantic revelation. The
sealed wing, the locked turret, the bricked-up door, the cellar
the housekeeper warns against — each parallel to a sealed
chamber in the love interest's emotional history. When the
heroine breaches a physical threshold, an emotional threshold
must move with it. The progression should be staged: discovery
of the first hidden space corresponds to the first crack in the
hero's reserve; the deepest hidden space (often the centre of
the house — the chapel, the master bedroom, the family vault)
corresponds to the deepest confession. Spaces revealed to the
heroine should not be revealed to the reader before her; the
gothic-romance reader's pleasure is the synchronised
unsealing of building and beloved.

### The Atmospheric Seduction

Weather, decay, isolation, and the surrounding landscape are
not scenery — they are seduction. Storms that strand characters
together; fog that disorients and creates dependence; the moor,
the cliff, the sea-cave, the maze, the icebound pass; the heath
in autumn; the orchard gone to ruin — the environment conspires
to create intimacy and to test it. The technique requires
specificity: not "a stormy night" but the particular sound of
hail on a leaded window, the particular smell of a fire that
will not draw because the chimney is choked with rooks' nests.
The atmospheric seduction is also a tension generator: the more
seductive the landscape becomes, the more the reader senses the
landscape might also be the trap.

### The Byronic Peel

Gradual revelation of the dark love interest's wounded interior,
paced as seduction rather than as exposition. Each layer removed
should cost the character something visible — a flinch, a
silence, a sudden departure, a confession followed by retreat.
The progression from brooding mystery to vulnerable confession
moves through stations: the first loss of composure (witnessed,
not narrated); the first half-truth (the reader sees what the
heroine cannot); the first deliberate confidence (offered, then
recanted); the full disclosure (which is also a request). Too
fast destroys the gothic atmosphere; too slow frustrates the
romance contract. The peel test: can the reader name what the
hero is hiding by the midpoint, and does the actual revelation
go further than the reader had guessed?

### The Domestic Uncanny

Making the familiar home strange and the strange home familiar.
The protagonist should feel simultaneously drawn to and repelled
by the domestic space — the bedroom that feels like sanctuary
by day and menacing by night; the dressing-room mirror that
reflects something the heroine did not put in it; the seat at
the dinner table that is always laid for one more guest. The
uncanny operates at the intersection of safety and threat:
gothic romance achieves it by making the romance itself the
source of the uncanny (this man I am beginning to love is also
a man who terrifies me, and both registers are real
simultaneously). The technique fails if the uncanny is
quarantined to "creepy scenes" — it must shadow the romantic
scenes too.

### The Inheritance Plot

The gothic-romance heroine arrives as governess, ward,
companion, distant relation, or inheritor — almost never as the
property's established mistress. Her status as outsider-with-
claim drives the structural tension: she has standing to ask
questions but no authority to compel answers. The inheritance
itself (estate, fortune, title, child to be raised, cursed
bequest, family secret she did not know she carried) is the
engine of plot and stakes. Even contemporary gothic-romances
preserve this structure — the heroine returns to the family
home after a death, takes a position in a stranger's house,
inherits something she did not seek. The romance and the
inheritance must converge: by the climax, the choice of love
and the disposition of the inheritance are the same choice.

### Gothic Romance AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the house held dark secrets" | Show ONE specific architectural detail that suggests history — the painted-over door, the wallpaper that does not match the room |
| "a brooding hero with a mysterious past" | Show the specific behaviour that suggests the past — the way he avoids one corridor, the name he flinches at |
| "the atmosphere was thick with dread and desire" | Show ONE sensory detail that carries both registers in the same line |
| "shadows danced on the walls" | Show the specific light source and what the shadows reveal — candle flame, moonlight through diamond panes, firelight across a portrait |
| "she was drawn to the danger he represented" | Show the specific dangerous behaviour and her precise physical reaction |
| "the moors stretched endlessly" | Show ONE specific landscape detail that creates isolation — the absence of a road, the distance to the next light |
| "a love that bordered on obsession" | Show the specific obsessive behaviour — what he watches, what she returns to, what neither can stop noticing |
| "the house seemed to breathe" | Show the specific structural sound: settling timber, wind in a flue, water in old pipes — and who hears it |
| "secrets whispered through the corridors" | Show the specific overheard fragment in the specific corridor, and what the heroine does next |
| "beauty and terror intertwined" | Show the specific beautiful-terrible image — the white peacock dead in the snow, the chandelier above a stained floor |
| "the Gothic heroine trembled" | Show what makes her tremble through physical detail — cold, recognition, the touch she did not invite |
| "their eyes met across the room" | Show what each was doing before they looked, and what the look interrupts |
| "an ancient evil stirred" | Name the specific evil and stage its specific manifestation in this scene |
| "she felt watched" | Show the specific sign — moved object, candle that should not still be lit, footstep where there should be silence |
| "his touch was both gentle and possessive" | Pick one register and show it; the line between them is what the reader is here to feel |
| "the past refused to stay buried" | Show the specific document, portrait, letter, or relic that surfaces, and who finds it |
| "a forbidden attraction" | Name the specific prohibition (rank, marriage, vow, family enmity, supernatural condition) and show the moment of breach |
| "the storm raged outside" | Show ONE concrete weather detail and its effect on the room (cold from the window, shutters that will not hold, candles guttering) |

### Romance Masterclass — Gothic-Romance Calibration

The romance master file (romance.md) holds the canonical
romance frameworks: Heat Level Calibration, the 7-Element
Chemistry Scene Construction, the 6 Romance Character
Archetypes with character-build tests, Obstacle Layering
Quantitative, Light and Shade Heart-Monitor Rule, the
Differentiation Imperative, Hope-as-Resolution Calibration,
and Series Architecture. All apply directly to gothic-
romance, but the calibration below renders each framework
in the genre's specific atmospheric and structural register.

**7-Element Chemistry Scene — Gothic-Romance calibration:**

- **Element 1 (Setup):** the house, estate, or institution
  is the third character in the scene. Establish the
  building's mood, weather, hour, and current state of
  decay before the leads come into proximity. The Setup
  must register the gothic atmosphere as material weight
  on both leads' choices.
- **Element 2 (Approach):** often through architectural
  exploration (a forbidden corridor, the locked east wing,
  the cellar after dark, the ruined chapel). The proximity-
  pretext is typically the building itself drawing them
  together.
- **Element 3 (Banter Beat):** wit edged with danger;
  secrets traded as currency rather than currency
  exchanged for wit. The dialogue carries period or modern-
  gothic register and must operate on at least two layers
  (surface social exchange + buried-knowledge subtext).
- **Element 4 (Awareness Spike):** typically arrives
  during architectural revelation (the painted-over door
  rediscovered), supernatural threat (the cold spot, the
  voice in the wall), or shared peril (the storm, the
  intruder, the missing servant). The Spike's emotional
  pivot is rendered through the building's response as
  much as the leads' bodies.
- **Element 5 (Pull-Back):** the load-bearing pull-back is
  carried by the gothic obstacle — the secret of the
  house, the inheritance, the dead first wife or lover,
  the family curse, the period social constraint that
  prohibits action. The leads cannot act because the
  building, the past, or the secret holds them.
- **Element 6 (Aftermath):** the protagonist's
  relationship with the house has shifted; she sees it
  differently after the encounter. Render the Aftermath
  through how the building feels to her now compared to
  before.
- **Element 7 (Hook):** the next architectural or
  historical revelation (a portrait noticed, a letter
  found, a room newly accessible). The Hook in gothic-
  romance is typically the building offering the next
  piece of its history.

**6 Character Archetypes — Gothic-Romance calibration:**

- **The Wounded Lead** is typically the heroine: an
  outsider arriving at the gothic location with hidden
  vulnerability, frequently with claim to inheritance, an
  unanswered question about her own past, or a profession
  that brings her into the house (governess, secretary,
  archivist, restorer, distant relation). Her wound
  predates the gothic encounter and the house pressures
  it.
- **The Opposite Lead** is the byronic figure: keeper of
  the house's secret, tortured by inherited burden, often
  the heir or current resident. His wound is buried in
  the architecture; the house's secret IS his secret. His
  departure from the byronic-stereotype must be specific
  in at least three character-rooted ways (per the
  romance.md archetype departure rule).
- **The Antagonistic Ex / Rival** is often historical
  rather than living — the dead first wife, the
  ancestor's mistress, the family secret made flesh in
  portrait or letter. The living rival, when present,
  carries the building's social pressure (the
  housekeeper, the neighbour, the cousin with claim).
- **The Found Family** is typically restricted in
  gothic-romance: the protagonist is structurally
  isolated. Where it appears, it is small (a single
  ally, a former servant, a sympathetic neighbour) and
  frequently distant (correspondence, intermittent
  visits).

**Obstacle Architecture — Gothic-Romance dominant obstacles:**

The Obstacle Layering Quantitative rules apply (Act 1: 2
obstacles by Ch 5; Act 2: 3 active by midpoint; Act 3:
all addressed by climax). For gothic-romance, the
dominant obstacle types are:

1. **The gothic secret** (inheritance dispute, family
   curse, haunting, buried crime, hidden lineage)
2. **Period or institutional social constraint** (often
   historical setting; even modern-gothic carries the
   weight of inheritance law and family pressure)
3. **Architectural threat** (the house itself dangerous —
   structural decay, supernatural presence, the locked
   room that contains something, the cellar)
4. **The byronic lead's tortured past** (the load-bearing
   internal obstacle — what he cannot say, what he cannot
   forgive himself for, what he believes makes him
   unworthy)

**Differentiation Imperative — Gothic-Romance specific axes:**

- Specific historical period and architectural specificity
  (named house, named region, named year)
- Specific gothic-threat register (psychological vs
  supernatural vs criminal vs ancestral-curse)
- Specific inheritance configuration (who claims, what
  the claim costs, what the resolution requires)

**Ending Calibration — Gothic-Romance patterns:**

Gothic-romance typically delivers HEA — the gothic
resolved (the secret revealed, the inheritance settled,
the threat removed, the byronic lead's wound healed
enough for partnership). HFN is possible when the
broader gothic context remains active across a series.
The Hopeful ending is rare in gothic-romance — the genre
expects conventional resolution within the gothic frame.
Where the genre permits it, the manuscript must signal
from the early chapters that conventional union is not
on the table.

## Genre-Specific Revision Rules

Six revision passes specific to gothic romance, run after the
standard structural / line / continuity passes. Each pass has a
single question; each pass is run cover-to-cover before the next
begins. Mixed passes ("read for atmosphere AND character") miss
both. The gothic-romance reader notices any of these failures
within the first three chapters.

### Pass 1: Atmosphere Consistency Audit

Read the manuscript for atmospheric continuity, scene by scene,
asking only: does the gothic register sustain, and does it vary
enough not to become monotonous? Map the atmospheric weight of
each scene on a 1–5 scale (1 = ordinary daylight social moment;
5 = full uncanny pressure). The contour should resemble a tide,
not a flat-line: lighter moments must exist as contrast, not as
relief from a register the writer has lost confidence in. Verify
that weather, lighting, architectural detail, and the heroine's
embodied perception reinforce rather than contradict the
emotional register of each scene. Flag chapters that drop below
2 for more than ten consecutive pages (atmosphere has lapsed)
and chapters that hold at 5 for the same span (atmosphere has
become ambient noise the reader stops hearing).

### Pass 2: Gothic-to-Romance Balance

Map the ratio of gothic apparatus (house, secret, threat,
uncanny) to romantic development (attraction, bond, conflict,
commitment) across every chapter. Neither register should
overwhelm the other for more than two consecutive chapters; both
should be present in nearly every chapter. The gothic setting
must serve the romance — every uncanny event should also be a
romantic event (revealing something about the lovers, advancing
or threatening their bond). The romance must be shaped by the
gothic context — every romantic beat should also be a gothic
beat (occurring in a charged space, witnessed by a watchful
house, edged with the awareness that not everything is safe).
Chapters that read as pure-gothic-with-nominal-love-interest, or
pure-romance-with-decorative-old-house, are the failure mode
this pass exists to catch.

### Pass 3: Secret Revelation Pacing

Build a chronological table of every secret in the book — what
it is, who knows it, when the heroine learns of its existence,
when she learns its content, when the reader learns its content.
Verify escalation: the first secrets revealed should be the
smaller (or seemingly smaller) ones; the devastating
revelations cluster in the third quarter. Verify no secret is
revealed and immediately forgotten; each revelation should
permanently alter the romantic dynamic and ripple forward into
later chapters. Verify the climactic secret is genuinely
climactic — large enough to threaten the relationship, specific
enough to demand a precise resolution. Flag any secret revealed
without consequence, any secret the heroine learns but does not
react to, any secret that the reader figures out before the
heroine has plausible reason to.

### Pass 4: Byronic Hero Depth Check

Review the love interest's characterisation in isolation: read
only his scenes (and scenes in which he is discussed). Is the
brooding persona supported by genuine psychological depth, or
does it collapse into performance — silence as substitute for
character, scowl as substitute for grief? List his motivations
beyond the central wound. Does he have appetites, opinions, ways
of being kind that are particular to him and not interchangeable
with any other gothic hero? Ensure the vulnerability we are
asked to find compelling has been earned through specific
actions and specific moments of self-betrayal, not through
authorial assertion. Test: can the reader, by the midpoint,
write three sentences about him that no other gothic-romance
hero would say? If not, the character is still archetype, not
person.

### Pass 5: Setting-as-Character Verification

Read every scene for setting presence. The house, estate, or
dominant gothic space should be referenced or felt in every
chapter — through sound, scent, temperature, sightline, pressure
on the heroine's mood, or her active engagement with it. Check
that the physical environment evolves alongside the relationship:
the same room should feel different in chapter twenty-five than
it did in chapter five, and the difference should be earned by
what has happened between. Check that the heroine has handled,
walked, sat, slept, and changed in the space — that she occupies
it bodily, not as an observer. Flag any chapter where the setting
could be deleted and the scene would still make sense; that scene
is not yet in this book.

### Pass 6: The Heroine's Agency Audit

Gothic romance has an inherited problem: the genre's earlier
conventions sometimes positioned the heroine as object of rescue,
witness to the hero's interior, or vessel for the reader's
identification without independent action. Modern gothic romance
must give her agency without abandoning the form's pleasures.
Read every chapter asking: what does the heroine choose, do, or
risk in this scene that advances the plot? She should be the
investigator (not merely the observer); she should make decisions
that surprise the hero (not merely react to his); she should have
desires and limits she enforces (not merely a capacity to be
moved). Flag chapters where the heroine is moved through the
plot rather than moving it. The gothic-romance reader will accept
peril, isolation, and the dark hero's centrality — but only if
the heroine remains the protagonist of her own decisions.

## Names & Patterns to Avoid

### Forbidden Patterns
- **The purely decorative setting**. If the gothic architecture could be replaced with a modern flat without changing the story, the gothic element is cosmetic
- **The passive heroine**. Gothic romance protagonists must investigate, explore, and challenge, not merely react to mysterious circumstances
- **Mystery without resolution**. Every gothic secret must be satisfactorily explained by the end; lingering mysteries frustrate romance readers
- **The villain love interest without redemption arc**. Gothic heroes can be dark, but the romance requires demonstrated change or at minimum unwavering devotion

### Cliché Setups to Avoid
- The governess who falls for the brooding master (unless substantially reinvented)
- The wife in the attic (unless the Bertha Mason archetype is interrogated rather than recycled)
- The storm that conveniently traps the leads together (unless the contrivance is acknowledged)
- The portrait of the dead first wife who looks exactly like the heroine

### Naming Considerations
- Gothic names should feel weighty and historical. avoid contemporary casual names
- Estate names should evoke atmosphere (Thornfield, Manderley, Wuthering Heights set the standard)
- Avoid unintentionally comedic gothic names (Lord Darkmore, Miss Shadowgrave)
- Surnames drawn from landscape features suit the genre well. Blackwood, Ashworth, Ravenscar, Thornbury
- First names should carry weight without feeling contrived. Eleanor over Ellie, Catherine over Cat, Julian over Jules
- Servant and supporting character names should reflect their era and station without descending into caricature

## Comp Titles

Gothic-romance's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Jane Eyre* — Charlotte Brontë (1847): the gothic-romance archetype; the heroine, the byronic master, the secret in the house.
- *Wuthering Heights* — Emily Brontë (1847): obsessive love rendered through gothic atmosphere; the moors as third character.
- *Jamaica Inn* — Daphne du Maurier (1936): atmospheric gothic with Cornish-coastal specificity.
- *Rebecca* — Daphne du Maurier (1938): the second-wife gothic; Manderley as the genre's archetypal house.
- *My Cousin Rachel* — Daphne du Maurier (1951): the unreliable-narrator gothic-romance.

### Contemporary (current best-in-class)

- *Mexican Gothic* — Silvia Moreno-Garcia (2020): post-colonial gothic-romance; mid-century Mexican setting; body-horror integration.
- *Plain Bad Heroines* — Emily M. Danforth (2020): queer gothic-romance with dual timeline; meta-gothic literary register.
- *Velvet Was the Night* — Silvia Moreno-Garcia (2021): noir-gothic romance hybrid; 1970s Mexico City.
- *The Death of Jane Lawrence* — Caitlin Starling (2021): magical-realist gothic with arranged-marriage frame.
- *House of Hunger* — Alexis Henderson (2022): vampire-coded gothic with class-friction architecture.
- *The Daughter of Doctor Moreau* — Silvia Moreno-Garcia (2022): science-gothic with colonial Mexico setting.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. Painterly, atmospheric illustrations with rich texture and period detail. The strongest style for gothic romance; evokes the literary tradition and allows for the moody, layered compositions the genre demands.
- **Vintage**. Aged, antique aesthetic with distressed textures, sepia tones, and period-appropriate design elements. Signals the historical and classic literary roots of the genre. Particularly effective for Bronte/du Maurier-adjacent stories.
- **Cinematic**. Film-still quality with dramatic lighting, fog, and architectural grandeur. Works for gothic romance with supernatural or thriller elements where atmosphere is paramount.
- **Abstract**. Symbolic, mood-driven compositions using colour, texture, and suggestive shapes rather than literal depiction. Effective for literary gothic romance or crossover titles.

### Genre Cover Aesthetics
- **Styles:** Atmospheric and brooding compositions, fog and mist effects, candlelit or moonlit scenes, silhouetted figures against imposing architecture, painterly textures, Pre-Raphaelite influence, layered depth with foreground and background mystery
- **Colours:** Deep jewel tones. burgundy, midnight blue, aged gold, forest green, plum. Warm amber and candlelight glow against dark backgrounds. Parchment cream and ivory for text or accent elements. The palette should feel rich, aged, and atmospheric. like old velvet and firelight.
- **Elements:** Castles, manors, and crumbling estates; moors and windswept landscapes; ravens and crows; candelabras and candlelight; fog and mist; locked doors and iron keys; portraits and mirrors; climbing roses and ivy; graveyards and crypts; stormy skies; women in flowing gowns; silhouetted figures in windows
- **Typography:** Ornate serif fonts with period character. Garamond, Caslon, or Didot-style letterforms. Decorative flourishes, swashes, and drop caps. Gold foil or embossed effects on dark backgrounds. The typography should feel hand-set and literary, evoking an earlier era of bookmaking.

### Subgenre Variations
- **Classic Gothic (Bronte/du Maurier style):** Silhouetted woman approaching manor house, windswept moors, single candle in dark window, restrained and literary composition
- **Southern Gothic Romance:** Spanish moss, plantation houses (depicted critically), swampland, warm humid palettes, weathered textures
- **Victorian Gothic:** Ornate period detail, gaslit streets, fog-shrouded London or countryside, corseted silhouettes, seance imagery
- **Supernatural Gothic:** Ghostly figures, spectral light, mirrors with wrong reflections, more overt paranormal visual cues while maintaining atmospheric restraint
- **Modern Gothic:** Contemporary settings with gothic atmosphere. old houses, isolated locations, moody photography with vintage colour grading

### Market Positioning
Gothic romance occupies a niche but passionate readership that values literary quality and atmospheric depth. Covers must signal both ROMANCE and GOTHIC simultaneously. neither element should dominate visually. The cover should evoke a feeling of beautiful unease: alluring and unsettling in equal measure. At thumbnail size, the architectural or landscape element should be immediately recognisable, and the mood should be unmistakably atmospheric. Gothic romance readers are often literary fiction crossover readers; the cover should feel elevated and artful, not mass-market. Series branding should maintain consistent atmospheric quality and colour palette.

### Cover Design DON'Ts
- Modern settings or contemporary imagery. gothic romance demands period or timeless atmospheric aesthetics
- Bright, saturated, or cheerful colour palettes. the mood must be brooding and atmospheric
- Minimalist design with clean lines and white space. gothic romance requires visual richness and layered depth
- Photorealistic couple photography. this signals contemporary romance; gothic romance covers should be more atmospheric than literal
- Comic or cartoon illustration styles. breaks the serious, literary tone entirely
- Sans-serif or modern typography. gothic romance typography must feel period-appropriate and ornate
- Cluttered compositions without focal point. atmospheric complexity needs compositional discipline
- Horror-forward imagery (gore, explicit monsters, jump-scare aesthetics). gothic romance is about beautiful dread, not graphic horror
