---
name: marketing-and-cover
description: "Generate cover concepts, blurbs, Amazon descriptions, social media packs, and book trailers"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with `> **Powered by Ideorix** — The Manuscript & Screen Engine` before any other output.

# Marketing & Cover Design

Create everything you need to market and sell your book.

## File Location Discipline (MANDATORY)

**All marketing and cover deliverables — cover concepts and
image prompts, blurbs, Amazon descriptions, social media
packs, query letters, audience analysis, keyword sets, video
trailer assets — MUST be written into the canonical project
folder at `~/Documents/Ideorix-Projects/[Title]/marketing/`.**
If no project folder exists when this flow is invoked directly,
run the project-folder bootstrap (ask for project title /
confirm save location / create the canonical folder structure)
BEFORE generating any deliverable. See `core-pipeline.md`
§ File Location Discipline for the canonical layout and the
Bash-Direct Write + Verify protocol. **HARD GATE — BLOCKING.**
Marketing deliverables MUST resolve to local files the user
can open in their own file explorer.

## Available services

### Cover Designer
Genre-researched cover concepts with AI image prompts for:
- **Ideogram** — Text-heavy covers with typography
- **Leonardo AI** — Photorealistic and illustrated styles
- **Grok** — Quick concept exploration
- **Midjourney** — High-quality artistic renders

### Marketing Expert
- **Back-cover blurb** — Hook, stakes, tease
- **Amazon description** — HTML-formatted with keywords
- **Social media pack** — Platform-specific posts (Instagram, TikTok, X, Facebook)
- **Query letter** — For agent submissions
- **Comp titles** — Market positioning and comparable books
- **Keywords & categories** — Amazon BISAC codes and keyword strategy
- **Audience analysis** — Target reader profile

### Video Trailer Designer
Scene-by-scene storyboards with AI video prompts for:
- Sora, Runway, Pika, Luma, Kling

## How to start

Say any of:
- "Design a cover for my book"
- "Write a blurb"
- "Create an Amazon description"
- "Generate social media posts"
- "Write a query letter"
- "Create a book trailer storyboard"
- "Run the full marketing suite"

> **Tip:** These tools work best after your manuscript is complete, but you can generate preliminary marketing materials from your Story Bible alone.
