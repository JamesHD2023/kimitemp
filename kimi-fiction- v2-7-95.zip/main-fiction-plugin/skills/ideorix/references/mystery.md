---
name: mystery-genre
description: Genre-specific instructions for mystery fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Mystery. Genre Plugin

## Metadata
- id: mystery
- name: Mystery
- icon: 🔍
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Save the Cat"]

## Subgenre Options
Present during setup:
- **Classic Whodunit**. The traditional mystery: a crime, a detective, a suspect pool, red herrings, and a revelation; Agatha Christie territory
- **Police Procedural**. The investigation through official channels: forensics, interviews, jurisdictions, paperwork; the system as both tool and obstacle
- **Amateur Sleuth**. A non-professional investigator: curiosity, personal connection, and outsider perspective; the accidental detective
- **Hard-Boiled**. Tough, cynical, street-smart: the detective who operates in moral grey areas; Chandler, Hammett, Mosley territory
- **Locked Room/Impossible Crime**. The puzzle box: a crime that CAN'T have happened the way it appears; the intellectual mystery at its purest
- **Inverted Mystery**. The reader knows who did it; the question is how the detective figures it out; Columbo structure

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Investigation rhythm. each chapter ends with either a new clue or a new question; the reader should feel the net tightening
- Must open with: The crime (or its discovery). the body, the theft, the disappearance; establish the mystery in the first chapter

BEATS PER CHAPTER
1. Clue Beat. A piece of evidence is found, examined, or reinterpreted; the investigation advances
2. Interview/Interrogation Beat. The detective talks to a suspect or witness; information is given AND withheld
3. Red Herring Beat. A false lead that seems promising; the reader and detective pursue it
4. Deduction Beat. The detective (and reader) connect pieces: a pattern emerges, a contradiction surfaces
5. Complication Beat. The investigation is blocked, redirected, or complicated: new evidence, another crime, a suspect's death

MYSTERY ARCHITECTURE
- The PUZZLE is sacred: there must be a genuine, solvable mystery with a satisfying solution
- FAIR PLAY: every clue the detective uses in the solution must be available to the reader (even if they didn't notice it)
- The SUSPECT POOL: 4-6 suspects, each with means, motive, and opportunity; each plausible as the culprit
- RED HERRINGS: false clues that misdirect WITHOUT cheating; they must have a logical explanation
- The DETECTIVE drives the investigation through intelligence, observation, and persistence
- The SOLUTION must be surprising yet inevitable: "Of COURSE it was them". but the reader didn't see it coming
- CLUE PLACEMENT is an art: clues hidden in plain sight, disguised by context, or overlooked due to misdirection
- POV: First person (detective narrates. classic) or third person close (allows wider view)

THE CLUE ARCHITECTURE
- Plant clues EARLY: the most important clue should appear in the first third
- Disguise clues through context: the vital detail buried in a description, a conversation, a list
- The RULE OF THREE: each major clue should be noticed, dismissed, and then re-examined
- Physical clues (objects, forensics), testimonial clues (what people say), and behavioral clues (how people act)
- Every clue should point in at least two directions: toward the truth AND toward a red herring

THE SUSPECT POOL
- Each suspect has a SECRET (not all secrets are about the murder)
- Each suspect has a MOTIVE (real or apparent)
- Each suspect has an ALIBI (some solid, some weak, some false)
- The guilty party should be someone the reader considered and dismissed
- Suspects should be differentiated by personality, speech pattern, and relationship to the victim

FORBIDDEN IN MYSTERY
- The solution depends on information withheld from the reader (unfair play)
- The culprit is someone introduced in the last chapter
- "The detective just KNEW" (intuition without evidence is not detection)
- Twin siblings, disguises, or secret passages (unless the genre is explicitly classic/tongue-in-cheek)
- The detective is never wrong or confused (they should pursue false leads too)
- Forensic magic (instant DNA results, technology that doesn't exist)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (primary engine — the central question), Validation at the solution, Revelation at the climax.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the mystery cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  mystery cues below apply directly.VOICE & TONE
- POV: First person (detective or Watson-figure. the classic mystery voice) or third person close
- Voice: Observant, analytical, sometimes wry; the detective notices what others miss
- Tone: Investigative curiosity with appropriate gravity for the crime
- Register: Varies by subgenre. conversational for amateur sleuth, professional for procedural, hard-edged for noir

PROSE IMPERATIVES
- OBSERVATION PROSE: the detective's eye sees MORE
  - What others miss: the cigarette brand, the shoe size, the hesitation before answering
  - Description serves detection: every detail could be a clue (or a red herring)
  - The reader should be able to re-read and find the clues they missed
- INTERVIEW PROSE: conversations as investigation
  - What the suspect says vs. how they say it (confidence, nervousness, rehearsed quality)
  - The detective's questions: strategic, seemingly casual, circling the truth
  - Body language: fidgeting, eye contact, posture changes. all potential evidence
- DEDUCTION PROSE: the intellectual machinery in motion
  - Show the detective's thinking: connection, elimination, re-examination
  - "If X is true, then Y is impossible. But Y happened. Therefore X is false."
  - The reader should be able to follow the logic (even if they reach different conclusions)
- TENSION THROUGH KNOWLEDGE: the mystery's tension comes from what's known and unknown
  - Each revelation should raise a new question
  - The reader should feel "I'm getting closer" and "But what about...?" simultaneously

PROSE RHYTHM MAPPING (CRITICAL. the puzzle in the prose)

Mystery prose is clean, precise, and observational. The reader should
feel an intelligent mind at work. noticing, connecting, questioning.
The prose itself is a fair-play instrument: the sentence containing a
clue should feel slightly different from its neighbours.

Chapter 1 prose rhythm:
- Sentence average: 14-22 words. Clean and precise, never florid.
  Observation sentences can run longer; deduction sentences run shorter.
- Clue-delivery rhythm: the sentence that contains a real clue should
  be slightly shorter, slightly more specific than surrounding prose.
  Attentive readers will notice the shift in register. the detail that
  is TOO precise amid general description. This is fair-play signalling
  through rhythm, not through bold font.
- Dialogue density: 35-40% by word count. Dialogue in mystery serves
  two functions simultaneously. misdirection and revelation. Every
  interview contains both truths and deflections. The reader must parse
  which is which.
- Observation prose: the detective's eye lingers on details that MATTER
 . but the prose weight is equal across all details. The vital clue
  sits beside the irrelevant detail with identical narrative conviction.
- Interiority: permitted in analytical beats (the detective connects
  dots, eliminates possibilities, forms hypotheses). These passages
  should feel like watching a mind work. logical, sequential, testable.
- Tension floor: ≥5. The puzzle IS the tension. Every chapter should
  end with the reader knowing more and understanding less.

DIALOGUE CRAFT
- Interview dialogue: the detective steers, the suspect reveals (or conceals)
- Each suspect sounds different: vocabulary, sentence length, confidence level, what they volunteer vs. what they withhold
- The detective's questions: some probing, some casual, some deliberately misleading
- The "gotcha" moment: when a suspect's lie is revealed through their own words
- Witness dialogue: partial, contradictory, emotionally filtered (people remember differently)
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

MYSTERY CRAFT (40% of total):
- The puzzle is fair (clues available to the reader)? (0-100)
- Clues are effectively disguised (hidden in plain sight)? (0-100)
- Red herrings are logical (not cheats)? (0-100)
- The solution is surprising yet inevitable? (0-100)

STORY CRAFT (30% of total):
- The suspect pool is well-differentiated and each is plausible? (0-100)
- The detective drives the investigation through intelligence? (0-100)
- Stakes escalate (the case becomes more dangerous/urgent)? (0-100)
- The reveal is dramatically satisfying? (0-100)

PROSE QUALITY (30% of total):
- Observation prose rewards re-reading (clues visible in hindsight)? (0-100)
- Interview scenes are strategic and revealing? (0-100)
- Deduction is shown through clear logical process? (0-100)
- Each chapter ends with a hook (clue or question)? (0-100)

AUTOMATIC FAILS (score = 0):
- The solution requires information withheld from the reader
- The culprit appears only in the final chapters
- The detective solves the case through intuition alone
- Red herrings that have no logical explanation
- Forensic technology that doesn't exist (or works impossibly fast)
- The guilty party's motive is inadequate for the crime
```

## Continuity Rules

```
MYSTERY CONTINUITY. WHAT TO TRACK

CLUE STATE:
- Every clue: what it is, when found, who found it, what it seems to indicate
- Clue connections: which clues have been linked, which remain isolated
- Physical evidence chain: where each piece of evidence is (preserved, lost, contaminated)
- Clues the detective has and clues the reader has (should be the same. fair play)

SUSPECT STATE:
- Each suspect's alibi: when given, how verified, any contradictions
- Each suspect's motive: as understood at each point (may shift)
- Each suspect's secret: revealed or hidden at each point
- Interview history: when the detective spoke to each suspect, what was said

TIMELINE OF THE CRIME:
- The victim's last known movements
- Where each suspect was at the time of the crime
- The sequence of events on the night/day in question
- Forensic timeline: when the crime occurred (as narrowed by evidence)

INVESTIGATION TIMELINE:
- Day-by-day progress of the investigation
- When key clues were discovered
- When theories were formed and abandoned
- External pressures: deadlines, media, institutional pressure

DETECTIVE STATE:
- Current theory: what the detective thinks happened (changes over time)
- What they know vs. what they suspect vs. what they've eliminated
- Personal state: the case's effect on their life, mood, and relationships
- Mistakes: false trails pursued and what they cost
```

## Character Rules

```
MYSTERY CHARACTER TYPES

THE DETECTIVE:
- Intellectually superior in OBSERVATION, not in general knowledge
- Has a method: systematic, intuitive, forensic, social. their approach is distinctive
- Flawed: the thing that makes them a great detective may make them a difficult person
- Persistent: they don't give up when the case gets difficult
- Fair: they follow the evidence, not their preferences

THE VICTIM:
- Not just a body. a person with a life, relationships, and secrets
- The investigation reveals WHO they were (which is often different from how they appeared)
- Their character should have a bearing on the solution (who they were explains why they died)
- The victim's secrets are often the key to the mystery

THE SUSPECTS:
- 4-6 suspects, each distinct in personality, relationship to victim, and potential motive
- Each has a secret: NOT all secrets relate to the murder
- Their behavior under investigation reveals character
- The guilty party should be fair-play: present from early on, with clues pointing to them
- The most sympathetic suspect is often the most suspicious

THE WITNESS:
- Unreliable by nature: memory is imperfect, perception is filtered, people lie
- What they saw vs. what they THINK they saw vs. what they SAY they saw. three different things
- Their testimony contains both truth and distortion

VOICE DIFFERENTIATION:
- The detective: precise, observant, sometimes detached
- Each suspect: distinct speech patterns, vocabulary, confidence levels
- The truth-teller: direct, consistent, sometimes irrelevant (they tell the truth but don't know what matters)
- The liar: rehearsed, deflecting, providing too much or too little detail
```

## Arc Rules

```
MYSTERY STORY STRUCTURE

ACT 1: THE CRIME (first 25%)
- The crime is discovered (or committed in the reader's view)
- The detective is engaged: officially assigned, hired, or personally drawn in
- The scene is examined: physical evidence collected, first observations made
- The suspect pool is established: who had access, motive, opportunity
- Initial interviews: first impressions of key suspects
- END OF ACT 1: The detective has a working theory (which is WRONG, or at least incomplete)

ACT 2A: THE INVESTIGATION (to midpoint)
- Systematic investigation: interviews, evidence analysis, background research
- Red herrings are pursued: plausible leads that don't pan out
- The suspect pool narrows (some cleared) and expands (new connections discovered)
- Clues accumulate: some pointing to the truth, some misdirecting
- The victim's hidden life emerges: they were not who they seemed
- MIDPOINT: A major twist. a second crime, a key alibi crumbles, or a crucial clue reframes everything

ACT 2B: THE COMPLICATION (midpoint to dark moment)
- The case becomes more dangerous or urgent
- The detective's theory is challenged or destroyed
- Suspects become uncooperative, scared, or actively hostile
- Previously reliable evidence is questioned
- The detective must reassess everything they think they know
- DARK MOMENT: The case seems unsolvable. or worse, the detective suspects the wrong person

ACT 3: THE SOLUTION (final 25%)
- The crucial insight: the detective re-examines a clue and sees what they missed
- The pieces fall into place: a cascade of connections
- The confrontation: the detective faces the guilty party with the evidence
- The revelation: the full story. how and why. explained with all clues referenced
- The resolution: justice (or its absence) and the aftermath
- The reader re-evaluates: the solution should make them want to re-read, finding all the clues they missed

MYSTERY PACING:
- Every chapter ends with a question or revelation
- The pace accelerates through Act 2 as clues come faster
- The confrontation/reveal in Act 3 is the longest sustained tension
- After the reveal, a brief wind-down: the aftermath, the consequences
```

## Timeline Rules

```
MYSTERY TIMELINE

CRIME TIMELINE:
- Precisely timed: when the crime occurred (to the minute if possible)
- The victim's movements before the crime
- Each suspect's movements before and after
- The discovery: when and by whom

INVESTIGATION TIMELINE:
- Day-by-day: the pace of the investigation
- When each clue was found and by whom
- When each interview occurred
- When theories changed and why

ALIBI TIMELINE:
- Each suspect's claimed location at the time of the crime
- Verification status: confirmed, unconfirmed, disproven
- The window of opportunity for each suspect
```

## Genre-Specific Craft Techniques

Mystery is the foundational genre of the puzzle-fiction
catalogue and the parent of an extensive sub-genre cluster
(cozy mystery, police procedural, hardboiled, domestic
thriller, legal thriller, historical mystery, locked-room,
inverted mystery, amateur sleuth, espionage / spy mystery).
Its readers — from the Golden Age tradition (Christie, Sayers,
Allingham, Carr, Marsh, Tey) through the contemporary
expansion (Ann Cleeves, Tana French, Louise Penny, Jane
Casey, Elly Griffiths, Anthony Horowitz, Richard Osman,
Belinda Bauer, Jane Harper, Adrian McKinty, Liz Moore,
Kate Atkinson) — bring strict expectations of fair-play
puzzle construction, suspect equality, clue placement,
revelation timing, and the form's distinctive contract that
the reader could have solved the case if they had been
paying close enough attention. The techniques below are how
the form sustains the puzzle contract while delivering
character work, setting, and atmosphere across registers
that range from cozy to noir-adjacent. The genre's failure
modes are specific: clues that appear only at the reveal
(violating fair play); the killer marked by differential
narrative treatment (telegraphing the solution); resolutions
that depend on coincidence or detective intuition rather
than evidence; suspects who exist only to fill out the
suspect list without their own narrative weight.

### The Hidden-in-Plain-Sight Technique

The most important clue should be visible but unnoticed. The
genre's signature pleasure: the reader returning to chapter
three after the chapter-twenty-two reveal and finding that
the clue was always there, perfectly placed, available to
anyone who had been paying close enough attention. The
technique converts the writer's omniscient knowledge of
which detail matters into the reader's eventual recognition
that they could have solved the case.

```
Chapter 3: "The drawing room was immaculate: fresh
flowers in the vase, the piano lid open as if someone
had just been playing, and Mrs. Henderson's reading
glasses on the side table beside a half-finished
cup of tea."

Chapter 15 (the reveal): "The reading glasses. Mrs.
Henderson was long-sighted. she used them for reading
only. But the letter on the desk was typed. Why would
she need her reading glasses to read a typed letter?
Unless she wasn't reading the letter. She was reading
something much smaller. The inscription on the watch."

The clue was there in Chapter 3. The reader didn't
notice because it was disguised as scene-setting.
```

The technique requires the equal-weight inventory: the clue
must be presented with the same prose weight, syntactic
emphasis, and narratorial attention as the surrounding
non-clue details. The strongest mystery practitioners run
multiple hidden-in-plain-sight clues simultaneously — the
inscription, the changed timing of a witness's lunch, the
unfamiliar perfume, the locked drawer that the housekeeper
remembers being unlocked the day before — with different
clues paying off across the investigation's progression.

Test: return to each chapter where a clue was planted, after
finishing the manuscript, and verify the clue is present in
the text. Was it disguised enough that the average reader
would miss it on first reading, but specific enough that a
careful reader on rereading could identify it as the clue?
If the clue cannot be located in the text where it was
supposed to be planted, the writer has cheated; if the clue
is present but flagged so heavily that average first-readers
would see it, the disguise has failed.

### The Interview Triangle

Every interview has three layers, and the strongest mystery
prose works all three simultaneously — surface speech,
embodied behaviour, and the silence around what isn't said.
The detective who attends only to what suspects say is a
weak detective; the detective who reads all three layers is
operating within the form's craft.

1. **What the suspect says** (the surface — may be true or
   false; the suspect may believe what they're saying or
   may be lying with full knowledge; the writer's interest
   is what they choose to put on record)
2. **How they say it** (behaviour — nervous, rehearsed,
   aggressive, too calm, the answer that arrives before
   the question finished, the answer that takes too long
   to arrive, the smile that doesn't reach the eyes, the
   hand that tightens on the chair arm)
3. **What they DON'T say** (the gap — what topic they
   avoid, the question they redirect, the name they don't
   mention, the alibi they offer for a time the detective
   didn't ask about)

The technique requires that interviews be staged as scenes,
not summarised. The detective who walks out of three
interviews knowing only what each suspect said has done
half the work; the detective whose investigative interior
has been tracking embodied behaviour and conversational
gaps across each interview is operating within the form. The
prose's job is to render all three layers without pointing
at any of them — the reader sees what the detective sees,
draws their own conclusions, and at the reveal recognises
what the detective registered all along.

Test: pick three significant interviews and verify each
operates on all three layers. If interviews function as
information-delivery only, the form's signature interview
craft has not been deployed.

### The Revision Guarantee

After the solution is written, verify: could a careful
reader, re-reading with knowledge of the solution, find
every clue planted in the text? If any clue the detective
uses in the solution is missing from the text, plant it.
This is the genre's central fair-play discipline, codified
by Knox's Decalogue (1929), the Detection Club rules, and
maintained as the contemporary genre standard.

The discipline has three components:

- **Every clue used in the solution must be on the page**
  before the solution. The detective who reveals at the
  climax that the killer left a thread of fabric at the
  scene must have shown that thread on the page when the
  scene was investigated. The reader should be able to
  point at the chapter where each clue was first planted.
- **Every clue must be findable**, in the sense that an
  attentive reader on rereading could identify it as
  significant. Clues hidden behind authorial misdirection
  are fair; clues placed in passages the reader had no
  reason to attend to are not.
- **Every clue must connect to the solution**, in the sense
  that its presence must be explicable in retrospect. A
  reader who returns to a flagged clue and cannot reconstruct
  why it mattered has been cheated.

The genre's strongest practitioners run the verify-on-
rereading test as part of their final revision pass: the
manuscript is read with the solution in mind, every step
of the detective's reasoning traced back to its specific
chapter-page origin, and any missing or under-supported step
fixed before publication. Test: write a paragraph
summarising the detective's reasoning in the climactic
reveal. For each fact the reasoning depends on, locate
the chapter and page where the fact was first established.
If any fact has no source, the fair-play contract has
been broken.

### The Suspect Equality Discipline

Every named suspect must be a person, not a fixture. The
genre's most-flagged character craft failure is the suspect
list populated with placeholders — the gardener with no
interior life, the cousin who exists only to be questioned
once, the housekeeper whose only function is to discover
the body. Each suspect must have: a particular relationship
to the victim, a particular motive (which they may or may
not have acted upon), a particular alibi (which may or may
not hold), an interior life that exists independent of the
investigation, and at least one memorable particularity
that the reader can grasp.

The discipline also requires equal narrative treatment of
suspects. The killer cannot receive differential prose
attention — extra description, "something off about them"
authorial flagging, more page time than other suspects, more
careful interior observation by the detective. The reader's
ability to genuinely consider any suspect as the killer is
what makes the reveal land; if the killer has been marked
across the manuscript by narrative attention they shouldn't
have, the careful reader will see them coming.

The technique extends to red-herring suspects. The most-
suspected character (the one with motive, opportunity, and
suspicious behaviour) must have a genuine reason for that
suspicious behaviour that, when revealed, satisfies the
reader as plausible. The red-herring suspect whose behaviour
turns out to have been arbitrary misdirection by the writer
is the failure mode; the red-herring suspect whose behaviour
makes complete sense once you understand what they were
actually doing (the affair they were hiding, the addiction
they were concealing, the financial scheme unrelated to the
murder) is the technique.

Test: at the climax, write a one-sentence summary of each
suspect's life independent of the murder. Each summary
should describe a recognisable human being with concerns,
relationships, and stakes that would exist if the murder
had not occurred. If any suspect cannot be summarised in
this way, the suspect equality discipline has not been
observed.

### The Detective's Method

Mystery's distinctive character work is the detective's
method — the specific way this particular investigator
reads cases, gathers evidence, conducts interviews, and
arrives at conclusions. The genre's signature characters
are remembered for their methods (Holmes's deductive
chains, Poirot's psychology of the criminal, Marple's
pattern-matching from village experience, Bosch's
patience and procedural depth, Penny's emotional intelligence,
Atkinson's Brodie's empathy with the lost) and the manuscript
must give the detective a recognisable, consistent method
that operates across the investigation.

The method must be specific (not "she was very observant"
but "she paid particular attention to people's hands —
because hands lied less often than faces"), demonstrable
(visible in scenes where the detective is investigating,
not just asserted by the narrator), and limited (every
detective's method has blind spots; the case that exposes
the limit is often the case that becomes the book). The
detective who is competent at everything is a less
interesting detective than the one whose method is
exceptional in one register and weak in another.

The method also operates as the engine of the climactic
reveal: the detective solves the case using their specific
method, and the reader recognises the solution as
characteristic of this detective rather than as generic
puzzle resolution. Test: at the reveal, can the writer
trace each step of the detective's reasoning back to the
detective's established method? If the solution arrives by
generic logic rather than by this detective's particular
way of thinking, the character work has been delivered
flat.

### The Reveal Choreography

The mystery's climactic reveal is the genre's most-staged
scene, and the form has developed conventions the
manuscript can use deliberately or against. The traditional
parlour-room reveal (Christie, Carr) gathers all suspects
in one location and the detective explains the solution
working through each suspect's possibility before arriving
at the truth. The procedural reveal (Connelly, French)
unfolds across the investigation's final chapters, with
the detective's understanding firming up gradually rather
than all at once. The dual-reveal (Tana French's *In the
Woods*, Catriona Ward's *Sundial*) delivers a primary
solution and then either subverts it, reveals a deeper
truth, or leaves an ambiguity the reader must navigate.

The choreography requires:

- **The detective's reasoning is traceable.** The reader
  follows each step rather than receiving the solution as
  authorial pronouncement.
- **Every previously-planted clue is referenced.** The
  hidden-in-plain-sight planting pays off here, with the
  detective recalling specific chapter-three details and
  showing how they fit.
- **The killer's reaction confirms rather than explains.**
  The killer who delivers a confessional monologue
  explaining motive, method, and means is the genre's
  most-tired convention; the killer whose reaction (the
  flinch, the silence, the unexpected grace) confirms the
  detective's deduction is the technique.
- **The remaining suspects are accounted for.** The
  innocent suspects' suspicious behaviour gets explained;
  the reader leaves understanding why each red herring
  was suspicious and why each was innocent.
- **The aftermath registers.** The climactic reveal is not
  the last beat; the genre permits — and is often
  strengthened by — the post-reveal beat that registers
  what the truth costs (the survivor's grief, the
  detective's complicated relationship to the resolution,
  the secondary characters' lives forever altered).

Test: read the climactic chapter and identify each of the
five components. If any is missing or rushed, the reveal
choreography has not been completed.

### Mystery AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "something felt off about [suspect]" | Name the specific detail |
| "the pieces were starting to fall into place" | Show the specific connection the detective makes |
| "a clue that could change everything" | Name the clue and show why it matters |
| "the detective's instincts told her" | What specific observation triggers the instinct? |
| "nothing is what it seems" | Show the specific deception |
| "the truth was more complicated than anyone imagined" | Show the specific complication |
| "a web of lies and deceit" | Name the specific lies |
| "the plot thickened" | Delete. Show the complication directly |
| "all the evidence pointed to" | Show the specific evidence trail |
| "she knew she was getting closer to the truth" | Show the specific progress. what new fact? |
| "a dark secret" | Name the secret |
| "the killer's motive became clear" | Show the specific realisation |
| "the suspect had something to hide" | Name what is hidden, even if the detective doesn't yet know its content |
| "the alibi held / the alibi crumbled" | Show the specific moment the alibi was confirmed or contradicted |
| "the case had taken a strange turn" | Show what specifically changed and why it surprises the detective |
| "the inspector arrived to take charge" | Name the specific operational decision the inspector makes that the protagonist had been about to make differently |
| "the body had been there for some time" | Show the specific signs (state, smell, lividity, room temperature, what insects had arrived) |
| "she pieced together the truth" | Show the specific connection that completes the picture |

## Genre-Specific Revision Rules

Six revision passes specific to mystery, each with a single
question, run cover-to-cover before the next begins. Mystery
revision must hold the genre's signature fair-play discipline
(the puzzle the reader could solve), suspect equality (every
suspect a person), red-herring quality (misdirection that
makes sense in retrospect), chapter-hook rhythm (the
investigation always advancing), reasoning consistency (the
detective's logic traceable), and the reveal choreography
(the climactic explanation that satisfies). The passes
below are ordered to surface the puzzle-integrity failures
first (the genre's most-policed standard), suspect-and-clue
craft failures next, and reveal-and-pacing audits last when
the rest of the book is sound enough to hold the climactic
test.

### Pass 1: Fair Play Check

Verify the manuscript's puzzle-fairness contract is intact.
Every clue the detective uses in the solution must be planted
in the text before the solution. Build a clue ledger: every
fact, observation, and inference that contributes to the
detective's final reasoning, with the chapter and page where
each first appears in the text. Read the manuscript against
the ledger. Verify clues are disguised but findable on
re-reading: the average first-time reader should miss them
in the moment; the careful re-reader should be able to point
at the chapter where each clue was planted.

Verify no crucial information has been withheld from the
reader. The genre's contract requires that the reader have
access to everything the detective has — interview transcripts,
crime-scene observations, forensic results (where applicable),
witness statements. Where the detective notices something
specifically (the unusual perfume, the shoe inconsistency, the
photograph that should have been on the desk), the noticing
must be on the page in the chapter where it occurred, even
if the detective's interpretation comes later. The "the
detective realised" formulation that delivers a fact never
shown in scene is the failure mode; the noticing rendered in
scene at the time, with the interpretation following later,
is the technique.

Where the manuscript employs first-person POV (the genre's
classic configuration), Knox's no-secrets rule applies: the
narrator-detective cannot have known the solution from a
mid-book point but withheld it from the narration. If the
narrator knows the solution at chapter twenty but the reader
doesn't see it until chapter thirty, the reader has been
cheated. The fix is to revise either the narrator's
knowledge (they don't know yet) or the disclosure timing
(they tell us when they figure it out).

### Pass 2: Suspect Pool Check

Read each suspect's appearances in isolation. Are suspects
differentiated by voice, personality, relationship to the
victim, motive shape, alibi quality, and behavioural
signature? The mystery reader tracks suspects by name across
the book, and indistinguishable suspects (two grandsons of
the same age, two business partners with similar
preoccupations, two romantic interests with overlapping
backgrounds) are the genre's classic tracking failure. Each
suspect needs a memorable particular — the specific habit,
the specific verbal tic, the specific physical feature, the
specific hobby — that allows the reader to keep them
distinct.

Verify each suspect remains plausible at the chapter's
current point in the investigation. A suspect ruled out in
chapter eight should not be re-suspected in chapter twelve
without specific new evidence; a suspect cleared by alibi
in chapter ten should not be the killer revealed in chapter
twenty-five without the alibi being credibly broken on the
page. The plausibility curve operates per suspect and across
the suspect pool: the reader's evolving estimate of who is
guilty should follow from the evidence the manuscript
provides, with all suspects (including the eventual killer)
maintaining their plausibility through the right portion of
the book.

Verify the guilty party is present and active in the
investigation. The killer who appears in chapter two,
disappears for fifteen chapters, and reappears at the
reveal has not been a credible suspect; the reader has
forgotten about them. The killer must be visible to the
reader across the investigation — interviewed, observed,
reported on, present at significant scenes — even when (or
especially when) the reader doesn't suspect them.

### Pass 3: Red Herring Check

Audit every red herring in the manuscript. Are false leads
logical (not arbitrary misdirection)? The strongest red
herrings are the suspect's genuine secrets that turn out
not to be the murder — the affair, the financial fraud, the
addiction, the past indiscretion that the suspect was
hiding for reasons unrelated to the case. The reader's
investigation of the red-herring suspect uncovers a real
secret that simply isn't the relevant one. Generic
misdirection (the suspect who behaves suspiciously for no
reason that survives the reveal) is the failure mode.

Verify each red herring has an innocent explanation that
the reader will accept as plausible. The reveal must
include the red-herring's resolution — why they were
behaving suspiciously, what they were actually hiding, why
that turns out not to matter for the murder. Resolutions
that read as authorial-fiat ("they were just nervous"; "it
was a coincidence") undermine the misdirection retroactively;
resolutions that are themselves substantive (the secret
revealed is itself dramatic, even if not murder-related)
strengthen the book.

Verify the balance is right. The mystery should have enough
red herrings to genuinely mislead the careful reader (the
attentive reader should suspect three or four different
suspects across the book before arriving at the truth) but
not so many that the reader gives up trying to track. The
genre's traditional standard is three to five viable
suspects with the killer among them; some sub-genres operate
with smaller (locked-room) or larger (epic ensemble mystery)
pools, but the calibration must be deliberate and held.

### Pass 4: Hook and Pacing Check

Read each chapter's ending. Does it end with a question, a
revelation, or a complication that drives the reader to
continue? The mystery is the genre most dependent on chapter-
end hooks — the form is structurally a sequence of
revelations and complications, and chapters that fizzle out
mid-investigation lose readers. Verify the investigation
advances in every chapter: a new clue discovered, a new
suspect emerged, a new theory considered or discarded, a
new connection drawn. Chapters that exist primarily as
character development, atmospheric scene, or relationship
work are permissible (and often valuable) but must still
carry investigative momentum at chapter close — the
detective who has been in the pub for half a chapter
discussing the case with the bartender exits the pub with
something they didn't have when they arrived.

Check the pacing curve across the manuscript. Mystery
readers expect rhythm: the discovery (chapter one or two),
the suspect-pool establishment (early chapters), the false
trail (mid-book), the breakthrough (three-quarters mark or
later), the reveal (final chapters). Books that linger in
suspect-pool chapters too long lose momentum; books that
rush through breakthrough material to reach the reveal
shortchange the genre's signature pleasure. Test: chart
the pacing markers across the manuscript and verify the
investigation's structural beats are placed where the
genre's reader expects them.

### Pass 5: Reasoning Consistency Check

Verify the detective's reasoning is sound at each step.
Build a reasoning ledger: every deduction the detective
makes, with the evidence the deduction is based on. Read
the manuscript against the ledger. Are deductions based on
available evidence the detective actually has at that
point? The detective who knows in chapter ten that the
fingerprint is the killer's, when the fingerprint is not
sent to the lab until chapter twelve, has been moved
forward in time by the writer.

Verify the timeline of the crime is consistent with all
known facts. Build a crime timeline: when each event in the
murder occurred, who was where at each moment, what each
character was doing. Cross-reference with the manuscript:
do all the alibis hold against the timeline as the reader
will eventually understand it? Does the killer have time to
be where they need to be to commit the crime, given their
established movements? The genre's classic failure is the
killer who, by the reveal's timeline, was demonstrably
elsewhere when the murder occurred; the second-most-classic
is the timeline that requires impossible travel speeds, two
characters being in different places at the same time, or
witnessed alibis that were not actually witnessed by anyone
who could report them.

Test the reasoning by writing out the detective's solution
in numbered steps. Each step must trace to a specific piece
of evidence the detective has by that point in the book. If
any step requires evidence the detective shouldn't have or a
deduction the evidence doesn't support, the reasoning has
broken and the manuscript needs revision.

### Pass 6: The Reveal Choreography Audit

Read the climactic reveal sequence as a continuous block.
Verify the five components of strong reveal choreography:

- **Traceable reasoning** — the detective's logic is visible
  step by step, not delivered as authorial pronouncement
- **Previously-planted clues referenced** — the chapter-three
  clue is recalled at the reveal with chapter-three
  specificity; the reader registers that the clue was always
  there
- **Killer's reaction confirms rather than explains** — the
  killer-monologue-explaining-everything is the genre's
  most-tired convention; the killer whose flinch, silence,
  or unexpected gesture confirms the deduction is the
  technique
- **Innocent suspects accounted for** — the red-herring
  resolutions are delivered, not skipped; the reader leaves
  understanding why each suspect was suspicious and why
  each was innocent
- **Aftermath registered** — the climactic reveal is not
  the last beat; the post-reveal pages give weight to
  what the resolution costs (grief, complication, the
  difficult truth that justice has been delivered but the
  loss is not undone)

Verify the reveal earns its moment. The genre's reader has
been working alongside the detective for 200+ pages; the
reveal must reward that investment with a solution that is
elegant (the moving parts fit together cleanly), surprising
(the reader did not see it but, on reflection, recognises
it as the only possible solution), and satisfying (the
case's emotional weight is resolved, even if not always
happily). Test: write a one-paragraph summary of the
reveal as you understand it. Does the summary read as
inevitable in retrospect, or does it read as one possible
solution among several? Mystery's deepest pleasure is the
solution that, once delivered, was always the only
possible answer; if the solution feels arbitrary, the
mystery has not earned its climactic beat.

## Names & Patterns to Avoid

### Mystery Character Names. NEVER USE
- Names that signal guilt or innocence: Mr. Guiltworth, Vera Innocent
- Names too similar to each other (readers track suspects by name. help them)
- Famous detective names: Holmes, Poirot, Marple (too associated)

### Mystery. NEVER DO
- Introduce the killer in the final quarter of the book
- Resolve the mystery through a deathbed confession by someone other than the detective
- Use identical twins, unknown siblings, or secret identities as the solution
- Have the detective withhold information from the reader (unfair play)
- Make the solution dependent on specialised knowledge the reader couldn't have

### Use Instead
- Distinctive, memorable names that help the reader track the suspect pool
- Names appropriate to the setting's time and culture

## Comp Titles

Mystery's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Murder of Roger Ackroyd* — Agatha Christie (1926): the genre's structural masterclass on unreliable narration.
- *The Big Sleep* — Raymond Chandler (1939): hardboiled-PI mystery template.
- *The Maltese Falcon* — Dashiell Hammett (1930): the PI-procedural archetype.
- *In Cold Blood* — Truman Capote (1966): true-crime-adjacent mystery; literary-mystery crossover lineage.

### Contemporary (current best-in-class)

- *Mystic River* — Dennis Lehane (2001): literary-mystery; character-driven mystery architecture.
- *The Cuckoo's Calling* — Robert Galbraith / J.K. Rowling (2013): the Cormoran Strike series; modern PI-mystery benchmark.
- *Big Little Lies* — Liane Moriarty (2014): mystery-with-women's-fiction crossover.
- *The Thursday Murder Club* — Richard Osman (2020): cozy-mystery-adjacent contemporary; commercial benchmark.
- *Magpie Murders* — Anthony Horowitz (2016): meta-mystery with novel-within-novel structure.
- *The Word Is Murder* — Anthony Horowitz (2017): meta-mystery with author-as-character.
- *Bluebird, Bluebird* — Attica Locke (2017): contemporary mystery with race-and-place specificity.

## Cover Design Specifications

### Recommended Visual Styles
- **Object-Focused**. A single significant object: the murder weapon, a key piece of evidence, something that suggests the puzzle
- **Atmospheric**. Moody, shadowy compositions: a doorway, a figure, a scene that suggests crime and investigation
- **Graphic**. Clean, bold design with a puzzle or mystery motif: silhouettes, keyholes, magnifying glasses. the visual language of detection
- **Typographic**. Bold, confident typography with minimal imagery; the title IS the hook

### Genre Cover Aesthetics
- **Styles:** Crime scenes suggested but not shown, objects that imply a story (a bloodstain, a broken glass, a letter), shadowy figures, detective silhouettes, the duality of public face and hidden truth, noir lighting effects
- **Colours:** Dark, sophisticated palettes: navy, black, deep red, burgundy; gold or white accents; the colour palette should suggest midnight, candlelight, and secrets
- **Elements:** Keys, magnifying glasses, fingerprints, blood spots, handwritten notes, photographs, maps, clocks (time as evidence), shadows, keyholes, evidence bags
- **Typography:** Bold, confident, often serif; the title should feel like a case file heading; gold or red accents; the author name as a brand (mystery readers follow authors)

### Market Positioning
Mystery covers must signal "puzzle, detection, and secrets" through atmospheric design and the visual language of crime. Position against Christie, Tana French, Atkinson, Hawkins, Ware. The cover should promise both intellectual engagement and emotional stakes. At thumbnail size, dark palettes with one striking object or colour accent create immediate genre recognition.

### Cover Design DON'Ts
- No explicit violence or gore (mystery is about the puzzle, not the carnage)
- No cartoonish magnifying glasses or detective hats (too literal)
- No busy compositions that distract from the central image
- No bright, cheerful palettes (mystery is atmospheric and dark)
- No romance imagery (even for mysteries with romantic elements)
- No spoilery imagery (don't put the murder weapon on the cover if it's a twist)
