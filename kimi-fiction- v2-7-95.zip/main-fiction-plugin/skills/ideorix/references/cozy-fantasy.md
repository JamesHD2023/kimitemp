---
name: cozy-fantasy-genre
description: "Genre-specific instructions for Cozy Fantasy. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
---

# Cozy Fantasy. Genre Plugin

## Metadata
- **Genre ID:** cozy-fantasy
- **Display Name:** Cozy Fantasy
- **Category:** Fantasy & Sci-Fi
- **Tier:** Hybrid/Crossover
- **Target Word Count:** 2,500–4,000 per chapter
- **Min Word Count:** 2,500
- **Recommended Beat Structures:** Cozy Mystery Beat Sheet, Worldbuilding Beats, Three-Act Structure, Story Circle

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Cottage Core Fantasy | Pastoral magic, garden witches, rural enchantment | Nature-centred magic; seasonal rhythm; self-sufficiency themes |
| Small Business Fantasy | Running a shop, bakery, or tavern in a magical world | Business-as-plot; customer relationships; livelihood stakes (not lethal) |
| Retired Adventurer | Former hero finding peace, community, quiet purpose | Backstory tension; choosing peace over glory; mentoring next generation |
| Magical Slice of Life | Daily life in a world where magic is ordinary | Magic-as-mundane; community over conflict; wonder in routine |
| Cozy Romance Fantasy | Gentle love story in a whimsical fantasy setting | Romance arc primary; low-stakes external conflict; enchanted meet-cutes |
| Healing/Recovery Fantasy | Character healing from trauma in a gentle magical world | Recovery pacing; safe space as setting; magic aiding (not replacing) growth |

## Architect Instructions

### Chapter Planning Requirements

**Structure:**
- Chapter length: 2,500–4,000 words
- Pacing: Leisurely and immersive. character moments, sensory richness, community scenes, gentle discovery
- Must open with: Sensory grounding (weather, food, shop atmosphere), character routine, community interaction, or quiet magical moment
- Must close with: Emotional warmth, small victory, deepened connection, gentle question, or cozy resolution. NEVER with dread, mortal peril, or dark cliffhangers

**Beats Per Chapter:**
1. **Community moment**. Interaction with neighbours, customers, friends, or found family that reveals or deepens relationships
2. **Magical wonder**. A moment of gentle magic. something whimsical, beautiful, or quietly impossible that evokes awe rather than fear
3. **Personal growth**. Protagonist takes a small but meaningful step. vulnerability, trust, forgiveness, or self-acceptance
4. **Sensory grounding**. Rich, specific detail: food being prepared, weather shifting, shop atmosphere, garden growth, texture of cloth or wood
5. **Warmth or humour**. A moment of genuine comfort, gentle comedy, or shared joy that rewards the reader for being here

### Genre-Specific Requirements
- Low stakes. no world-ending threats, no mortal peril, no grimdark violence
- Found family. community as central theme; belonging earned through kindness, not battle
- Sensory warmth. food, weather, atmosphere, texture, scent described with loving specificity
- Whimsical magic. magic that delights rather than destroys; enchanted teapots, talking cats, self-watering gardens
- Personal stakes. the challenge is emotional: opening up, forgiving, trusting, finding purpose
- Gentle conflict. misunderstandings, personal fears, community tensions, business challenges. not villains
- Optimistic resolution. every chapter moves toward warmth; the world is fundamentally good
- Comfort as craft. readers choose this genre to feel safe; honour that contract
- Diverse, inclusive community. varied backgrounds and identities treated as unremarkable
- Healing is gradual. characters carry wounds but the world helps them heal, slowly, honestly

### Narrative Layers
- **Layer A (Community/Daily Life):** Running the shop, tending the garden, attending the festival, welcoming the stranger
- **Layer B (Personal Growth/Healing):** Learning to trust, forgiving the past, accepting help, discovering self-worth
- **Layer C (Gentle Magic/Wonder):** The world's enchantment deepening, magic revealing itself in new ways, wonder as reward

All three layers active in every chapter. Layer B carries the emotional core. the real story is always internal.

### Fractal Structure
- Novel level: Stranger arrives → community slowly embraces → personal walls fall → belonging earned → home found
- Chapter level: Routine grounding → small disruption → connection deepened → warmth restored
- Scene level: Sensory detail → character interaction → emotional shift (always toward warmth)

### Forbidden in Planning
- Dark lords, apocalyptic threats, or existential danger
- Violence as solution. no combat sequences, no battles, no weapons
- Chapter endings on dread, despair, or mortal peril
- Trauma used for shock value. wounds are treated with care
- Cynicism or nihilism. the world is fundamentally good
- Magic as weapon. magic serves community, creativity, and wonder
- Isolated protagonist. community is always present, even if character resists at first
- Romantic love as sole source of happiness. found family equally valid
- Grimdark aesthetics. no blood, no torture, no cruelty lingered upon
- Resolution through force. problems solved through connection, creativity, kindness

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (warm world & gentle magic), Affection (community), Validation (low-stakes wins).

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Voice and Tone
- **POV:** 1st person (intimate, confessional) or 3rd close (warm access to interiority)
- **Tense:** Past (reflective, storytelling quality) or present (for immersive wonder moments)
- **Voice:** Warm, gentle, observant, occasionally wry. never cynical, never cruel
- **Reading level:** All ages welcome. accessible language, emotional complexity

### Prose Imperatives
- Sensory richness. food, weather, texture, scent described with loving specificity
- Magic as wonder. enchantment evokes delight, not fear; awe, not power
- Community as character. the town/village/neighbourhood has personality, rhythms, moods
- Gentle humour. wit that includes rather than mocks; warmth in comedy
- Food as love language. meals prepared, shared, offered as connection
- Weather as mood. seasons, storms, sunshine reflecting emotional landscape
- Interior richness. character's thoughts warm, complex, yearning for belonging
- Pacing that breathes. scenes allowed to linger; no rushing toward action
- Dialogue that reveals. conversations carry emotional weight without melodrama
- Objects with history. the chipped mug, the inherited recipe, the door that sticks

PROSE RHYTHM MAPPING
- Chapter 1 must establish warmth + wonder. the reader should feel held by the prose from the first paragraph
- Medium sentences (14-20 words) form the backbone: gentle, unhurried, with room to breathe. this is the genre's resting heartbeat
- The rhythm is GENTLE. no sharp accelerations, no brutal compressions. Even moments of mild tension stay within a comfortable range
- Opening paragraphs: a warm, enveloping rhythm. Sentences flow into each other like a comfortable conversation. The reader should exhale and settle in
- Sensory-detail sentences may stretch slightly longer (18-24 words) when the prose lingers on a beloved detail. the smell of baking bread, the weight of a handmade mug, sunlight through a dusty window
- Dialogue rhythm: natural and warm. Medium-length exchanges with gentle pauses between. No one is rushed. No one is afraid
- Moments of emotional vulnerability: sentences may shorten slightly (10-14 words) as the character's guard drops. simplicity conveys sincerity
- Wonder moments (magical elements): the rhythm lifts. slightly longer sentences with softer vowel sounds, creating a sense of gentle surprise
- Comfort-detail density should be HIGH: the prose rhythm allows space to notice and appreciate small beautiful things. Never rush past them
- Humor beats: slightly shorter sentences with a conversational lilt. The punchline lands gently, like a friend's quiet joke
- Low stakes feel SAFE: the rhythm never tightens into urgency or dread. Even when gentle conflict appears, the prose maintains its warm tempo
- Tension baseline: ≥3 (genre-appropriate). Tension in cozy fantasy is curiosity, mild worry, or emotional vulnerability. never fear or dread
- Paragraph length: medium. Neither too short (which creates urgency) nor too long (which creates density). Each paragraph is a comfortable breath
- Avoid staccato rhythms. rapid-fire short sentences feel wrong in cozy fantasy. Even quick moments maintain a leisurely flow
- Transitions between scenes: gentle. A sentence about weather, a sensory bridge, a small domestic action easing the reader from one moment to the next
- End-of-chapter rhythm: warm resolution or gentle curiosity. The final sentences should feel like pulling a blanket up. satisfied, safe, perhaps wondering what tomorrow brings
- The paragraph should read like a cup of tea tastes. warm, familiar, comforting, with just enough variety to stay interesting
- The goal: prose that feels like home. unhurried, specific, warm, and welcoming. The reader should never feel pushed or pulled, only invited

### Prose Masterclass Examples

**Sensory Grounding. The Opening Anchor:**
Ground the reader in physical sensation before anything else. The cozy fantasy reader wants to feel the world wrap around them like a blanket. Start with what the character touches, smells, tastes. not what they think or fear.

The smell of bread already rising. The particular quality of morning light through a window that needs cleaning. The cat that has claimed the warm spot on the counter. These details ARE the story. not preamble to it.

**Magical Wonder. The Quiet Impossible:**
Magic in cozy fantasy should stop the reader with beauty, not spectacle. A teacup that refills itself with exactly the tea you needed. A garden where the flowers hum. A bookshop where the right book always finds you. The wonder is in the precision of the magic's kindness, not its power.

Write magic the way you'd write a perfect sunset. not by explaining the physics but by capturing the feeling of witnessing something that shouldn't be possible but is.

**Found Family Moment. The Casual Inclusion:**
The most powerful found-family moments are not dramatic declarations of love. They're casual inclusions: setting an extra place at the table without being asked. Knowing how someone takes their tea. The neighbour who brings soup when you're sick and doesn't make a fuss about it.

Write these moments as if they're unremarkable. Their power comes from the accumulation. the reader gradually realises this character has been adopted by a community without anyone signing papers.

**Gentle Conflict. The Misunderstanding That Matters:**
Cozy fantasy conflict comes from miscommunication, personal fear, and the difficulty of vulnerability. not villainy. The baker who won't share her recipe because it's the last thing her grandmother gave her. The newcomer who won't unpack because unpacking means staying means risking another loss.

The stakes are entirely emotional but must feel as real to the reader as any sword fight. This requires specificity. the particular fear, the specific memory, the exact moment trust becomes possible.

**Comfort Rhythm. The Return to Safety:**
After any moment of tension (however gentle), return the reader to safety quickly. The disruption is temporary. The warmth is permanent. This rhythm. safe, gentle challenge, safer. is the genre's heartbeat.

### Emotional Rhythm
- **Build:** Sensory grounding, community warmth, routine established as comfortable
- **Sustain:** Personal challenge introduced gently. a fear, a memory, a risk of connection
- **Release:** Through connection. a conversation, a shared meal, a gift given, a truth spoken
- **Recover:** Return to warmth, expanded. the world is slightly better, the circle slightly wider

### Forbidden Words and Phrases
- "Battle," "war," "enemy," "fight". unless clearly metaphorical and gentle
- "Dark lord," "evil," "villain". no antagonists of this type
- "Blood," "gore," "wound". unless referring to a scraped knee
- "Destroyed," "devastated," "ruined". too violent for the tone
- Clinical or cold descriptions of magic. magic is warm, surprising, personal
- "Despite everything" or "against all odds". stakes should never feel that dire
- Cynical interior monologue. character may be guarded but never cruel in thought

## Quality Check Criteria

### Priority Ranking
1. **Comfort tone maintained**. Reader feels safe throughout; no tonal betrayals into grimdark or horror
2. **Sensory richness**. World is tangible through food, weather, texture, scent, sound in every chapter
3. **Community warmth**. Found family dynamics present, deepening, and central to the story
4. **Magic as wonder**. Enchantment evokes delight, not fear; whimsical, not weaponised
5. **Emotional authenticity**. Personal growth feels earned, not rushed; vulnerability rewarded, not punished

### Genre-Specific Checks
- Warmth present in every chapter. no chapter leaves the reader anxious or distressed
- Stakes appropriately low. personal and community challenges, not existential threats
- Magic whimsical and kind. enchantment serves community, beauty, connection
- Food described with care. at least one meaningful food moment every few chapters
- Community deepening. relationships developing naturally, inclusively
- Personal growth visible. character moving toward openness, trust, belonging
- Sensory grounding. weather, texture, scent, light present in every chapter
- Chapter endings warm. never cliffhangers of dread or mortal peril
- Pacing unhurried. scenes given room to breathe, no rushing

### Automatic Fails
- Grimdark tone intrusion. violence, cruelty, despair dominating any chapter
- World-ending stakes. apocalyptic threats, dark lords, existential danger
- Hopeless or cynical ending. the world must end warmer than it began
- Magic as weapon. combat magic, destructive enchantment, power fantasy
- Community destroyed. the found family must survive and strengthen
- Trauma exploited. character wounds used for shock value rather than treated with care
- Chapter ending on dread. reader must never feel unsafe at a chapter break

### Acceptable Imperfections
- Moments of genuine sadness (grief, loneliness) if held with care and resolved toward warmth
- Gentle melancholy as undercurrent. the retired adventurer's old wounds, the newcomer's loss
- Not every problem solved in one chapter. some healing takes time
- Minor tensions between community members if resolved through communication

## Continuity Rules

### Top 5 Continuity Priorities
1. **Community character roster**. Who lives where, relationships, names, roles, quirks maintained
2. **Magic system consistency**. How enchantment works in this world, its limits, its personality
3. **Business/livelihood tracking**. Shop inventory, customer relationships, seasonal challenges
4. **Seasonal and weather continuity**. Time of year, weather patterns, festival calendar
5. **Personal growth trajectory**. Character's emotional arc building consistently, no regression without cause

### Magic System Consistency
Even whimsical magic needs rules:
- What magic can and can't do. limits create story
- How magic manifests. visual, sensory, emotional. consistent style
- Who can use magic. everyone, some, only specific beings
- Cost of magic. not painful but perhaps tiring, requiring focus, seasonal
- Magic's personality. does it have moods? Preferences? Humour?

### Community Character Tracking
For each community member:
- Name, role, personality, quirks
- Relationship to protagonist
- Where they live/work
- How they take their tea/coffee (this matters in cozy fantasy)
- What they contribute to community
- Running jokes, shared history, private kindnesses

### Seasonal/Weather Tracking
- Current season and its effects on daily life, business, magic
- Festival calendar. community celebrations, seasonal rituals
- Weather patterns affecting mood, activity, magic
- Garden/nature cycles. what's blooming, harvesting, dormant

### Business/Livelihood Tracking
If protagonist runs a shop, bakery, tavern, etc.:
- Inventory and supplies
- Regular customers and their orders
- Seasonal challenges (winter slow period, festival rush)
- Financial health. not stressed but present as backdrop
- Staff or helpers and their roles

### Critical. Never Allow
- Community member forgotten between chapters
- Magic working differently without explanation
- Season jumping without transition
- Character personality shifting without growth shown
- Previously established relationships contradicted
- Business details inconsistent (menu items, shop layout)

### Acceptable Inconsistencies
- Minor background character detail variations
- Weather specifics if general seasonal tone maintained
- Exact shop inventory if not plot-relevant

## Character Rules

### Top 5 Character Priorities
1. **Warmth capacity**. Every character capable of kindness, even if guarded at first
2. **Specific quirks**. Characters defined by habits, preferences, small delights. not just role
3. **Growth toward openness**. Arc moves from guarded to trusting, isolated to connected
4. **Community role**. How they contribute, what they offer, how they're needed
5. **Vulnerability shown**. Strength in this genre means being brave enough to be soft

### Character Types

**The Newcomer Finding Home:**
- Arriving from elsewhere. running from or toward something
- Guarded at first. slow to trust, carrying invisible wounds
- Community's warmth slowly breaks down walls
- Arc: From passing through to putting down roots, from alone to belonging
- Key moment: The first time they call this place "home" without thinking

**The Retired Adventurer:**
- Former hero choosing peace. scars visible and invisible
- Running a quiet business, tending a garden, raising bees
- Occasionally tempted by old life but choosing this one
- Arc: From hiding from the past to integrating it, from survivor to caretaker
- Key moment: Choosing to stay when adventure calls again

**The Community Pillar:**
- Always been here, knows everyone, holds the place together
- Appears perfectly content but carrying a private longing or loss
- Depth revealed gradually. they need the community as much as it needs them
- Arc: From giving to others to accepting help, from performing strength to showing vulnerability
- Key moment: Letting someone else carry the burden for a day

**The Gentle Eccentric:**
- The talking cat's companion, the mushroom witch, the wizard who forgot he was a wizard
- Provides comic relief but also surprising wisdom
- Knows more than they let on; kindness disguised as oddity
- Arc: From tolerated to treasured, from eccentric to essential
- Key moment: The time their particular weirdness saves the day

**The Healing Heart:**
- Carrying real grief, real trauma. but gently, carefully
- The world is helping them heal, one small kindness at a time
- Recovery isn't linear. setbacks handled with care, not drama
- Arc: From fragile to whole, from afraid to open, from surviving to living
- Key moment: The first laugh that doesn't hurt

### Relationship Dynamics

**Found Family Accretion:**
- Not instant. trust built through accumulated small moments
- The extra plate at dinner, the check-in after a storm, the shared recipe
- Conflict resolved through conversation, not avoidance
- Love expressed through action more than declaration

**Gentle Romance:**
- Slow-burn, tender, often involving shared activity (cooking, gardening, running a shop)
- First touch significant. holding hands, a brush of fingers
- Vulnerability as intimacy. sharing a fear, a memory, a hope
- No love triangles or dramatic jealousy. romance is safe here

**Mentor/Mentee:**
- Elder community member guiding newcomer
- Knowledge shared through doing, not lecturing
- Mutual learning. the mentor grows too
- Respect for the learner's pace. no rushing

### Red Flags
- Characters who are purely antagonistic. everyone has redeeming qualities
- Protagonist who never opens up. the arc must move toward connection
- Romance that overwhelms community. found family is equally important
- Trauma dumped without care. wounds revealed gradually, held gently
- Characters defined solely by their role. quirks, preferences, interior life required
- Wise elder who's perfect. all characters should have blind spots, needs

## Arc Rules

### Arc Types (Choose Based on Story)

**The Newcomer's Welcome:**
- Act I (Ch 1–10): ARRIVAL. Newcomer arrives, guarded; community curious, welcoming, slightly overwhelming; protagonist resists belonging
- MIDPOINT (Ch ~15): ROOTS FORMING. First genuine connection that protagonist didn't plan for; choosing to stay a little longer
- Act II (Ch 11–23): BELONGING. Community challenges faced together; protagonist's walls crumbling; past hinted at, slowly revealed
- Act III (Ch 24–30): HOME. Protagonist accepts belonging; community enriched by their presence; warmth earned

**The Healing Journey:**
- Act I (Ch 1–10): REFUGE. Character arrives carrying wounds; gentle world begins to soothe
- MIDPOINT (Ch ~15): TRUST. First real vulnerability; accepting help; setback possible but handled with care
- Act II (Ch 11–23): RECOVERY. Gradual opening; new purpose discovered; community support deepening
- Act III (Ch 24–30): WHOLENESS. Not fixed but integrated; character thriving, contributing, connected

**The Business Builder:**
- Act I (Ch 1–10): OPENING. Setting up shop/garden/tavern; meeting community; learning local ways
- MIDPOINT (Ch ~15): CHALLENGE. Business or personal setback; community rallies (or protagonist must ask for help)
- Act II (Ch 11–23): FLOURISHING. Business growing, community deepening, personal growth through work
- Act III (Ch 24–30): ESTABLISHED. Business thriving, protagonist woven into community fabric

### Required Checkpoints
- By 25%: Protagonist has begun connecting with at least two community members; world's magic glimpsed
- By 50%: Genuine vulnerability shown; first moment of real belonging; magic deepening
- By 75%: Personal challenge faced with community support; protagonist's past/fear addressed
- By 90%: Resolution in motion. all threads drawing toward warmth
- Final pages: Protagonist is home; community is stronger; wonder is present; warmth radiates

### Genre Promise
Cozy Fantasy readers expect:
- Safety. the world is fundamentally good; they will not be ambushed by horror or tragedy
- Warmth. genuine emotional comfort; belonging, kindness, connection
- Wonder. magic that delights; a world that surprises with beauty
- Found family. community that welcomes, includes, and holds
- Sensory pleasure. food, weather, atmosphere described with loving detail
- Gentle conflict. challenges that matter emotionally without threatening lives
- Optimistic resolution. the world ends better than it began
- Pacing that comforts. no rushing; permission to linger in beautiful moments

## Timeline Rules

### Top 5 Timeline Priorities
1. **Seasonal rhythm**. Time of year shapes daily life, business, magic, community activities
2. **Gentle pacing**. Weeks and months pass without urgency; no countdown clocks
3. **Festival and celebration tracking**. Community events marking time, deepening bonds
4. **Growth visible over time**. Gardens planted in chapter three bloom in chapter twenty
5. **Routine as comfort**. Daily rhythms established and returned to; change is gradual

### Genre-Specific Temporal Rules
- No urgent deadlines. if deadlines exist, they're gentle (festival preparation, seasonal planting)
- Seasons pass. spring planting, summer growth, autumn harvest, winter gathering
- Time between chapters can be days or weeks. nothing wrong with "a quiet week passed"
- Morning, afternoon, evening rhythm. daily life has structure and comfort
- Growth shown over time. relationships deepen gradually, gardens mature, businesses establish
- Weather transitions. no sudden season jumps; show the shift
- Festivals anchor the calendar. community celebrations mark significant moments

### Seasonal Structure
- **Spring:** New beginnings, planting, newcomers arriving, fresh energy
- **Summer:** Growth, abundance, festivals, community gathering, long evenings
- **Autumn:** Harvest, preparation, reflection, change, golden light
- **Winter:** Gathering in, cozy interiors, fireside community, rest and renewal

## Genre-Specific Craft Techniques

Cozy fantasy is a relatively young genre that emerged
from a specific craft principle: the structural commitment
to comfort, community, and small-stakes warmth in a world
that contains magic. The genre's contract with the reader
is that the manuscript will hold them — no shock-violence,
no grimdark moral compromise, no existential threat — and
that magic in this register operates as gift rather than
as threat. The genre's masterclass roster — Travis
Baldree (Legends & Lattes, Bookshops & Bonedust), Becky
Chambers (the Monk and Robot novellas: A Psalm for the
Wild-Built, A Prayer for the Crown-Shy; the Wayfarers
series in its cozy register), T. Kingfisher (the Saint of
Steel series, A House With Good Bones, A Wizard's Guide
to Defensive Baking), Sangu Mandanna (The Very Secret
Society of Irregular Witches), TJ Klune (The House in the
Cerulean Sea, Under the Whispering Door, In the Lives of
Puppets), Heather Fawcett (Emily Wilde's Encyclopaedia of
Faeries), Olivia Atwater (the Regency Faerie Tales), Ryka
Aoki (Light from Uncommon Stars), Helene Wecker's
adjacent-cozy work, Genoveva Dimova, Iona Datt Sharma,
Suzanne Walker, the broader cottagecore-adjacent
publishing wave — has established the form and continues
to expand its range. The most common failure modes in
this register are: **Tonal-Betrayal** (the manuscript
that begins cozy and drifts into grimdark, horror, or
despair; readers who chose the genre for comfort feel
betrayed); **Stakes-Inflation** (the introduction of
existential threat, world-ending magic, or apocalyptic
peril; the genre's contract is small-stakes); **Magic-
as-Threat** (magic deployed as menace rather than as
gift; the genre's register is whimsy, not danger);
**Conflict-Through-Violence** (problems resolved by
combat or destruction rather than through connection,
communication, and kindness); **Cardboard-Cosy** (the
manuscript that delivers cozy aesthetic — the bakery,
the bookshop, the village — without rendering the
specific texture that makes cozy work); **Sensory-
Thinness** (cozy fantasy lives in sensory detail; the
manuscript that skips the food, the weather, the
texture of the magical objects loses the genre's
foundational craft); **Insta-Found-Family** (chosen
family declared rather than built through accumulated
small moments); **Diversity-as-Token** (representation
present without specific named character work; the
queer character / disabled character / older character
appearing without being individually rendered);
**Pacing-Drift** (cozy fantasy can mistake "slow" for
"static"; the genre demands forward motion even at
gentle pace); and **Theme-Lecture** (the manuscript
announcing its themes of community, kindness,
acceptance rather than letting them emerge from
specific scenes). The techniques below — five preserved
(Sensory Anchor, Small Stakes Engine, Found Family
Accretion, Whimsical Magic Moment, Comfort Rhythm) and
three added (Genre-Promise Discipline, Specific-
Community Architecture, Forward-Motion-at-Gentle-Pace
Calibration) — are designed to keep the genre's
defining commitments live: comfort honoured without
collapse into static, magic as gift, community built
through specific accumulated detail.

### The Sensory Anchor

Ground every scene in physical sensation before emotion or action. The cozy fantasy reader comes for the texture of the world. Begin scenes with ONE specific physical detail the character experiences. not a sensory inventory, but the single thing they notice first. A character pulling bread from the oven feels the heat on their wrists. That's enough. The reader builds the rest.

Key principle: Sensory detail IS emotional content in cozy fantasy. The scent of cinnamon in a bakery isn't setting decoration. it's the feeling of safety made tangible. A character who notices the first snowflake is a character who has slowed down enough to be present. Write the physical world as if it loves the characters.

### The Small Stakes Engine

Create genuine tension and reader investment from personal, community, and livelihood challenges. never existential threats. The bakery's oven is broken before the festival. The newcomer's past might follow them here. The garden won't grow. The neighbour's feelings were hurt and they're not coming to dinner.

Key principle: Stakes feel proportional to the world. In a cozy fantasy, a failed sourdough starter can carry the emotional weight of a fantasy battle. if you've shown us how much it means. The reader must understand WHY this small thing matters so much. Connect every stake to belonging, identity, or love.

### The Found Family Accretion

Build chosen family through accumulated small moments rather than dramatic declarations. Set an extra place at the table. Remember how someone takes their tea. Bring soup when they're sick without being asked. Defend them quietly when they're not in the room.

Key principle: Found family is built in the margins. The most powerful moments are casual. the point where helping each other becomes automatic, where "your" problems become "our" problems, where the character looks around and realises they're home without having decided to stay.

### The Whimsical Magic Moment

Create wonder without threat. Magic in cozy fantasy should feel like a gift. delightful, unexpected, precisely kind. A teacup that always stays the right temperature. A doorbell that chimes in the visitor's favourite song. Books that rearrange themselves by mood rather than alphabet.

Key principle: The best cozy magic is specific and personal. Generic "glowing things" don't create wonder. Magic that knows your favourite flower, that hums the lullaby your grandmother sang, that makes your coffee exactly right on the morning you needed it most. that's the wonder this genre promises.

### The Comfort Rhythm

Pace the narrative so that any moment of tension (however gentle) is followed by a return to warmth. This rhythm. safe, gentle disruption, safer-than-before. is the genre's heartbeat. Readers must trust that the story will hold them.

Key principle: Every chapter should leave the reader warmer than it found them. This doesn't mean nothing difficult happens. it means difficulty is held with care and resolved toward connection. The disruption exists to make the restoration sweeter. Think of it as breathing: the exhale of tension makes the inhale of comfort deeper.

### Cozy Fantasy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "magic made everything better" | Show the specific magical solution and its charming limitation |
| "the enchanted [object] glowed warmly" | Show what the object actually DOES |
| "a cozy cottage filled with wonder" | Pick ONE specific wonderful detail |
| "the friendly dragon purred contentedly" | Show the dragon's specific personality through action |
| "magic sparkled in the sunlight" | Show the specific visual effect |
| "the village was peaceful and magical" | Show one person doing one magical thing in daily life |
| "she discovered her powers were special" | Show the specific power and its specific quirk |
| "the magical community welcomed her" | Show the specific act of welcome |
| "a gentle adventure awaited" | Show the specific inciting event |
| "the potion bubbled cheerfully" | Show the specific smell, colour, or effect |
| "everything about the place felt like home" | Show ONE detail that triggers that feeling |
| "warmth filled the room" | Show the specific source of warmth (the lit hearth, the cup of tea, the late afternoon sun through the leaded window) |
| "the bakery smelled of magic" | Show the specific scent (named bread, named spice, named magical signature with specific texture) |
| "kindness saved the day" | Show the specific act of kindness and its specific consequence |
| "the gentle pace of village life" | Show ONE specific routine the protagonist now participates in |
| "the cat looked wise" | Cut anthropomorphism; show the specific feline behaviour the protagonist interprets as wise |
| "they knew they were home" | Show the specific moment that produces the recognition |
| "everyone gathered for tea" | Name everyone, name the tea, name what's specifically said |

### The Genre-Promise Discipline

The Tonal-Betrayal and Stakes-Inflation failure modes are
the genre's deepest failures because they violate the
specific contract the cover, blurb, and tags promise the
reader. The Genre-Promise Discipline is the requirement
that the manuscript honour the cozy contract from page
one to ending without drift, betrayal, or apologetic-
darkness.

```
PRINCIPLE
The manuscript must honour the cozy genre-promise across
at least five of the following six axes:
1. NO EXISTENTIAL THREATS — the world is not ending,
   the kingdom is not falling, the apocalypse is not
   coming; stakes remain personal, community-level,
   and recoverable
2. NO ON-PAGE GRAPHIC VIOLENCE — physical conflict, if
   it appears, is rendered with restraint; the genre
   permits some peril (the chase, the magical
   misadventure, the threat to the bakery) but not
   gore, torture, or onscreen death of beloved
   characters without strong genre-permitted reason
3. NO PERMANENT TRAGIC LOSSES — beloved community
   members do not die of disease the manuscript
   refuses to cure; the genre permits grief
   (especially of past losses, named ancestors,
   moved-away friends) but not relentless
   present-tense bereavement
4. NO MORAL-COMPLEXITY-WITHOUT-RESOLUTION — the genre
   permits characters who are difficult, prickly, or
   wounded but resolves their arcs toward connection;
   moral grey that remains grey at the ending betrays
   the contract
5. NO MAGIC-AS-MENACE — magic in cozy fantasy operates
   as gift, surprise, or specific helpful weirdness;
   threats may come from misuse or misunderstanding
   but magic itself is not the menace
6. NO BLEAK ENDINGS — the ending must leave the reader
   warmer than the opening; even bittersweet endings
   resolve toward connection, hope, and continued
   community

CALIBRATION TEST
- Read the manuscript's opening, middle, and ending
  side by side. Is the genre register consistent?
- Does the manuscript drift into other genre registers
  (horror, grimdark, dystopian) at any point?
- Are at least five of the six promise axes honoured?
- Would a reader who chose the cozy genre for comfort
  feel safe throughout?
If any answer is no — rebuild for promise integrity.

ANTI-PATTERN
- The cozy fantasy that opens warm, drifts dark in
  Act 2, and tries to reclaim cozy in Act 3
- Beloved character death rendered for emotional
  punch
- The "but actually the world is ending" reveal
  that escalates stakes inappropriately
- Unrendered cruelty (the village under tyrannical
  rule whose suffering the manuscript treats as
  context rather than as cozy-genre violation)
- The bittersweet ending that lands on bitter rather
  than sweet
```

### The Specific-Community Architecture

The Cardboard-Cosy and Insta-Found-Family failure modes
produce manuscripts that gesture at community without
specifically rendering it. The Specific-Community
Architecture is the requirement that the cozy fantasy
village, town, found-family, or bookshop community be
populated with specifically named, individually rendered,
distinctly voiced characters who collectively constitute
the community the protagonist belongs to.

```
PRINCIPLE
The manuscript's community must satisfy at least four of
the following five criteria:
1. NAMED ROSTER — the community is populated by
   specifically named characters (at least 6-8 named
   community members beyond the protagonist's
   immediate inner circle); not "the villagers"
   but Mrs Halloran, the smith Tobias, the
   apothecary Greer, the widow Mathilda, the twins
   Nev and Lis, the schoolmaster's husband Carrick
2. INDIVIDUAL RENDERING — each named member has at
   least one specific quirk, habit, opinion,
   skill, history, or texture that makes them
   recognisable across appearances
3. INTERPERSONAL HISTORY — the community has its own
   history; specific past events, specific
   relationships, specific tensions and
   reconciliations, specific seasonal traditions
4. EVOLVING DYNAMICS — the community's relationships
   shift across the manuscript; trust grows, old
   wounds heal, new conflicts emerge and resolve;
   the community is not static
5. PROTAGONIST INTEGRATION — the protagonist's
   relationship to the community evolves
   specifically — moments of welcome, moments of
   misunderstanding, moments of being chosen,
   moments of choosing back; the found-family
   accretion is rendered through specific scenes
   rather than declared

CALIBRATION TEST
- Could the community's named characters be
  reduced to "the villagers" without the
  manuscript losing specificity?
- Are at least 6-8 named community members
  individually rendered?
- Does the community feel populated with people
  the reader can imagine continuing to live their
  lives when off-page?
- Is the protagonist's integration shown through
  accumulated specific moments rather than
  declared?
If any answer is no — rebuild for community
specificity.

ANTI-PATTERN
- "The villagers welcomed her" without specific
  named welcomers
- The community-as-homogeneous-warmth without
  individual distinguishing
- The found-family declared in chapter 2 and
  treated as fact in chapter 12 without rendered
  development
- The named character who appears in one scene
  and is forgotten
- Diversity as roster-checking rather than as
  individual character work
```

### The Forward-Motion-at-Gentle-Pace Calibration

The Pacing-Drift failure mode in cozy fantasy mistakes
"slow" for "static". Cozy pace is gentle but moving —
each chapter must deliver progression without sacrificing
the genre's signature warmth. The Forward-Motion-at-
Gentle-Pace Calibration is the discipline that prevents
warmth from becoming inertia.

```
PRINCIPLE
Every chapter must deliver at least three of the
following five forward-motion elements while maintaining
gentle pace:
1. NEW SMALL DEVELOPMENT — the protagonist learns
   something specific (a new community member, a new
   piece of magical lore, a new recipe, a new piece
   of local history, a new dimension of an existing
   character)
2. SENSORY ACCUMULATION — the manuscript's specific
   sensory texture deepens; new specific foods,
   new specific seasonal markers, new specific
   magical specifics
3. RELATIONSHIP DEEPENING — at least one
   relationship advances in specific small way;
   trust grows, history surfaces, casual care
   becomes deliberate care
4. SMALL-STAKE PROGRESSION — the chapter's gentle
   conflict (the broken oven, the unfinished
   project, the misunderstanding) advances toward
   resolution or sharpens
5. INTERNAL ARC PROGRESSION — the protagonist's
   internal journey moves at least one step
   forward (recognising belonging, releasing past
   pattern, accepting community-membership,
   committing to staying)

CALIBRATION TEST
- Read each chapter in isolation: did three of five
  forward-motion elements occur?
- Read consecutive chapters: is there discernible
  movement in development, sensory texture,
  relationships, stakes, and internal arc?
- If you skipped this chapter, would the manuscript
  notice? If no, the chapter has not done its
  forward-motion work and must be rebuilt or cut.
- Does the gentle pace feel like craft (chosen,
  controlled) or like authorial drift (events not
  happening because the writer is not pushing the
  manuscript forward)?
If any answer is no — restructure for gentle-but-
forward motion.

ANTI-PATTERN
- The chapter where the protagonist makes tea, eats
  a scone, reads a book, and goes to bed without
  any forward motion
- Sensory texture that repeats (the same
  description of the bakery's morning bread three
  times in three chapters)
- The community where nothing actually develops
  across the manuscript
- The cozy chapter that exists to maintain warmth
  without contributing to the manuscript's overall
  arc
- The "nothing happens but it's nice" pacing that
  cannot sustain a full novel
```

## Genre-Specific Revision Rules

### Six-Pass Cozy Fantasy Audit (Run FIRST in editorial pipeline)

The Cozy Fantasy Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Comfort Tone Pass

Verify every chapter maintains the cozy contract — no
tonal betrayals into horror, grimdark, or despair. Do
chapter endings leave the reader warm, curious, or
satisfied rather than anxious or dread-filled? Is the
overall emotional trajectory toward warmth, connection,
and hope? Would a reader who chose the genre for
comfort feel safe throughout? The Tonal-Betrayal failure
mode is caught here. any chapter that drifts into a
register the reader did not sign up for must be
rebuilt or recalibrated.

#### Pass 2: Stakes Calibration Pass

Verify stakes are personal and community-level rather
than existential. Do the challenges feel meaningful
without feeling threatening? Is conflict resolved
through connection, communication, and kindness rather
than violence? Are consequences proportional —
failure means disappointment, not death? The Stakes-
Inflation failure mode is caught here. cozy fantasy
permits stakes that the protagonist genuinely cares
about (the bakery, the festival, the friend's hurt
feelings, the missing recipe) but not stakes that
exceed the genre's contract.

#### Pass 3: Sensory Richness Pass

Verify every chapter is grounded in physical sensation.
Are food moments present and rendered with care? Does
weather or season contribute to mood and atmosphere?
Can the reader feel the world, not just see it? The
Sensory-Thinness failure mode is caught here. cozy
fantasy lives in sensory detail; the manuscript that
skips the texture of magical objects, the specific
smell of the bakery, the feel of the late autumn
afternoon, the taste of the seasonal preserve loses
the genre's foundational craft.

#### Pass 4: Community Warmth Pass

Verify community relationships are deepening across
the manuscript. Is the found-family dynamic earning
its warmth through accumulated small moments? Does
every significant community member have specific
quirks, depth, and personality? Is diversity present
and treated as unremarkable? The Insta-Found-Family
and Diversity-as-Token failure modes are caught here.
the Specific-Community Architecture provides the spec
— at least 6-8 named community members individually
rendered, with interpersonal history, evolving
dynamics, and specifically rendered protagonist
integration.

#### Pass 5: Magic Whimsy Pass

Verify magic evokes wonder rather than fear. Is
enchantment specific, personal, and kind rather than
generic glowing effects? Are magical rules consistent
while remaining delightful? Does magic serve
community, beauty, and connection rather than combat
or destruction? The Magic-as-Threat failure mode is
caught here. cozy fantasy magic operates as gift; the
specific enchantment that knows the protagonist's
favourite flower, that hums their grandmother's
lullaby, that makes the coffee exactly right.

#### Pass 6: Genre-Promise + Specific-Community + Forward-Motion-at-Gentle-Pace Integration

This pass is the cozy fantasy integration check — it
ties the new techniques together and verifies the
manuscript honours the genre's defining commitments at
the manuscript level.

For GENRE-PROMISE: confirm the manuscript honours all
six promise axes (no existential threats / no on-page
graphic violence / no permanent tragic losses / no
moral-complexity-without-resolution / no magic-as-
menace / no bleak endings). Read opening, middle, and
ending side-by-side to verify register consistency.

For SPECIFIC-COMMUNITY: confirm Pass 4's spec at the
manuscript level. Are at least 6-8 named community
members individually rendered? Does the community feel
populated with people who continue to live when off-
page?

For FORWARD-MOTION: confirm each chapter delivers at
least three of the five forward-motion elements (new
small development / sensory accumulation / relationship
deepening / small-stake progression / internal arc
progression). The Pacing-Drift failure mode is caught
here. if chapters maintain warmth without forward
motion, the manuscript has confused "cozy" with
"static" and must be rebuilt for gentle-but-moving
pace.

## Names & Patterns to Avoid

### Forbidden Patterns
- The dark threat on the horizon that the cozy world must face
- The protagonist who "fixes" the community with outsider knowledge
- Love interest as the only reason to stay. community must be equally compelling
- Magic explained through rigid, gamified systems. keep it whimsical
- Community that's perfect from page one. they should have quirks, tensions, flaws
- Protagonist who's immediately beloved. trust must be earned on both sides
- Resolution through dramatic confrontation. cozy fantasy resolves through conversation and connection

### Cliche Setups to Avoid
- The bakery/bookshop that's magically perfect from day one
- Instant mastery of magic. learning should be charming and slow
- The single mean character who exists only to create conflict
- Talking animals who are just sassy humans. give them genuine animal behaviour alongside magic
- "I'm not staying" repeated endlessly before they stay. show the pull, not just the resistance
- A festival in every chapter. festivals should be special, not routine
- Perfect weather always. let it rain, let it be cold, and find the coziness in imperfection

### Naming Considerations
- Names should feel warm, approachable, slightly whimsical
- Fantasy names that are pronounceable and memorable
- Shop/business names that evoke personality and warmth
- Place names that suggest belonging. villages, lanes, gardens
- Avoid harsh, aggressive, or intimidating names for any character or place

## Comp Titles

Cozy-fantasy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Howl's Moving Castle* — Diana Wynne Jones (1986): proto-cozy-fantasy template.
- *The House in the Cerulean Sea* — TJ Klune (2020): modern cozy-fantasy benchmark; queer-found-family.
- *The Long Way to a Small, Angry Planet* — Becky Chambers (2014): cozy SF-adjacent crossover.

### Contemporary (current best-in-class)

- *Legends & Lattes* — Travis Baldree (2022): the genre-naming text; orc-runs-coffeeshop.
- *Bookshops & Bonedust* — Travis Baldree (2023): same world; demonstrates cozy-fantasy series architecture.
- *A Psalm for the Wild-Built* — Becky Chambers (2021): the Monk and Robot novellas; cozy SF-cozy-fantasy hybrid.
- *A Prayer for the Crown-Shy* — Becky Chambers (2022): same series.
- *The Very Secret Society of Irregular Witches* — Sangu Mandanna (2022): cozy-fantasy benchmark.
- *Emily Wilde's Encyclopaedia of Faeries* — Heather Fawcett (2023): academic-fae cozy-fantasy.
- *A Wizard's Guide to Defensive Baking* — T. Kingfisher (2020): cozy-with-stakes fantasy.
- *Under the Whispering Door* — TJ Klune (2021): cozy afterlife fantasy.

## Cover Design Specifications

### Visual Tone
- Warm, whimsical, inviting
- Illustrated or painterly style preferred
- Cottage-core aesthetic. gardens, shops, cozy interiors
- Magical elements visible but gentle. glowing windows, floating books, enchanted plants

### Key Visual Elements
- Charming buildings. cottages, shops, taverns with personality
- Gardens and nature. flowers, vines, trees, animals
- Warm light. fireplaces, lanterns, sunset glow, candlelight
- Magical touches. subtle enchantment visible (sparkles, unusual colours, floating objects)
- Food and drink. steaming mugs, fresh bread, window displays
- Animals. cats, dragons (tiny), familiars adding warmth

### Typography
- Handwritten or serif fonts. warm, approachable, slightly whimsical
- Title in a cozy, readable font. nothing harsh or angular
- Author name visible but integrated into design
- Tagline if used should evoke feeling: "A novel of tea, magic, and belonging"

### Colour Palette
- Primary: Warm tones. amber, honey, sage green, dusty rose, warm brown
- Accent: Soft magical colours. lavender, periwinkle, soft gold
- Atmosphere: Golden hour light, firelight warmth
- Avoid: Dark, desaturated, or cold palettes
- High warmth, medium saturation. nothing garish

### Comp Titles (Cover Style Reference)
- *The House in the Cerulean Sea* by TJ Klune. warm, whimsical, found family
- *Legends & Lattes* by Travis Baldree. cozy business, gentle fantasy, inviting
- *A Wizard's Guide to Defensive Baking* by T. Kingfisher. charming, practical magic
- *The Very Secret Society of Irregular Witches* by Sangu Mandanna. community, warmth, gentle magic
