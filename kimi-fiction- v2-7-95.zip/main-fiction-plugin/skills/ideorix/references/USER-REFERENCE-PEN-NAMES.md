# Pen Name & Voice Studio — User Reference

## Quick Start

Say **"Create a pen name"** or **"Pen Name Studio"** at any time.
Say **"Build a voice"** or **"Voice Builder"** to create an author voice profile.

During project setup, Question 12 offers pen name selection and Question 8 offers voice profile selection.

## What It Does

Creates genre-appropriate pen names with professional author bios, and builds reusable
author voice profiles that control how your manuscripts sound. Pen names and voices
persist across all your projects — and can be linked together so selecting a pen name
automatically loads its voice.

## The Process

1. **You provide:** Genre, gender preference, cultural background, vibe, any initial preferences
2. **Engine generates:** 5 name candidates tailored to your genre
3. **You select:** Pick one, mix-and-match, request more, or provide your own
4. **You choose:** Bio preferences — backstory approach (fictional/real/vague), brand voice, any exclusions
5. **Engine generates:** 3 bio variants (short, medium, long) based on your preferences
6. **You review:** Read all 3 bios, then approve, edit, regenerate, or write your own
7. **Engine saves:** Profile stored locally for reuse

## Bio Lengths

| Length | Words | Best For |
|--------|-------|----------|
| Short | 50-75 | Amazon author page, back-of-book |
| Medium | 100-150 | Author website, press kit |
| Long | 200-300 | Query letters, speaking engagements |

## Genre Name Styles

| Genre | Style | Example Feel |
|-------|-------|-------------|
| Romance | Warm, melodic, soft consonants | Evelyn Hart |
| Thriller | Sharp, authoritative, punchy | Cole Ashford |
| Literary | Understated, classic, timeless | Eleanor Marsh |
| Fantasy | Distinctive, memorable | Rowan Kestrel |
| Horror | Dark, atmospheric, weight | Silas Crane |
| Cozy Mystery | Friendly, trustworthy | Harriet Bloom |

## Where Pen Names Are Used

When a pen name is assigned to a project, it's automatically applied to:
- DOCX manuscript metadata (author field)
- KDP metadata document
- Marketing materials (blurbs, Amazon descriptions)
- Cover concept (author name treatment)
- Query letters

## Storage Location

```
~/Documents/Ideorix-Projects/
└── .pen-names/
    ├── index.md              ← Master list (includes voice status)
    └── profiles/
        ├── elena-blackwood.md
        ├── jack-reeve.md
        └── voices/
            ├── elena-blackwood-voice.md   ← Full voice profile
            ├── jack-reeve-voice.md
            └── standalone-voice-01.md     ← Voice without pen name
```

## Standalone Studio Options

### Pen Name Studio
1. Create a new pen name
2. View my pen names
3. Edit a pen name
4. Delete a pen name
5. Generate new bios for existing name
6. Back to main menu

### Voice Builder
1. Build a new voice (guided conversation + test drive)
2. Build from my writing (extract from a sample)
3. Hybrid build (guided + calibration against your prose)
4. View my voices
5. Edit a voice
6. Test-drive a voice (generate a sample passage)
7. Link voice to pen name
8. Back to main menu

## Voice Profiles

A voice profile captures how you write — sentence rhythm, vocabulary, dialogue style,
pacing, and more. It's the fingerprint that makes your thriller sound different from
every other thriller on the shelf.

### Three Ways to Build a Voice

| Method | Best For | Time |
|--------|----------|------|
| **Guided Build** | Creating a new voice from scratch | 5-10 min |
| **Extract from Writing** | Capturing a voice you already have | 2-5 min |
| **Hybrid** | Most accurate result — guided + calibrated | 10-15 min |

### Writer Profile

Every voice starts with a Writer Profile — your age bracket, experience level, and
reading background. This shapes the voice defaults: a 25-year-old debut writer gets
different starting points from a 55-year-old career novelist. You adjust anything
that doesn't fit.

### Test Drive

Before saving, the engine generates a 300-word sample passage in your voice. You
read it, react, and iterate until it sounds right. You never save a voice you
haven't heard.

### Linking Voices to Pen Names

Each pen name can have one linked voice. When you select that pen name for a project,
its voice loads automatically as your Style Guide. Different pen names, different
voices — write romance as Elena Blackwood and thrillers as Jack Reeve, each with
their own distinct sound.

## Setup Integration

### Question 12 (Pen Name)

| Option | What Happens |
|--------|-------------|
| Select existing | Browse saved pen names, pick one |
| Create new | Full generation protocol (5 candidates + bios) |
| Use my real name | No pen name assigned |
| Decide later | Skip now, assign before export |

### Question 8 (Style Guide)

| Option | What Happens |
|--------|-------------|
| Use saved voice profile | Select from your voice library |
| Use pen name's voice | Auto-suggested if your pen name has a linked voice |
| Upload manuscripts | Engine extracts voice from your writing |
| Describe your style | Free-text description |
| Use genre defaults | Standard voice for the selected genre |
