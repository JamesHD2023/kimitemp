---
name: format-smf
description: "Standard Manuscript Format (SMF) generation template"
user-invocable: false
---
<!-- (c) 2025 Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->
# Standard Manuscript Format (SMF) Generation Template

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-smf.docx`

This Standard Manuscript Format export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Overview

Generate manuscripts in Standard Manuscript Format — the traditional submission format
for literary agents and publishers who specify it. Double-spaced, Courier 12pt,
approximately 250 words per page, with proper headers throughout. Based on the
William Shunn manuscript format guidelines.

## SMF vs Standard DOCX

| Feature | Standard DOCX | SMF |
|---------|--------------|-----|
| Font | Times New Roman 12pt | **Courier New 12pt** (monospaced) |
| Spacing | 1.5 line spacing | **Double-spaced** (exact 24pt) |
| Words per page | ~300-350 | **~250** (industry standard) |
| Title page | Minimal | **Full contact info + word count** |
| Headers | Book/chapter title | **Author / Title / Page #** |
| First line indent | 0.5" | **0.5"** |
| Scene breaks | `* * *` | **#** (single hash, centered) |
| Chapter starts | Page break | **Page break, ~1/3 down page** |

## Title Page Layout (Page 1)

```
[Top left corner — single-spaced]
Author Legal Name
Street Address
City, State ZIP
Phone Number
Email Address

[Top right corner]
~XX,000 words

[Centered, ~1/3 down the page]
BOOK TITLE
by
Author Name (or pen name)

[Bottom of page, centered, optional]
Agent Name / Agency (if represented)
```

## Manuscript Specifications

- **Page size:** US Letter (8.5" x 11")
- **Margins:** 1 inch all sides
- **Body font:** Courier New, 12pt (monospaced)
- **Chapter headings:** Courier New, 12pt, ALL CAPS, centered
- **Line spacing:** Double-spaced (exactly 24pt line spacing)
- **Paragraph spacing:** 0pt
- **First line indent:** 0.5 inch (every paragraph except first after heading)
- **Scene breaks:** `#` centered on its own line (not `* * *`)
- **Chapter starts:** New page, heading positioned ~1/3 down
- **Header:** `Surname / TITLE / Page#` — right-aligned, on every page except title page
- **Word count:** Rounded to nearest thousand on title page
- **End mark:** `# # #` or `THE END` centered after final paragraph

## Node.js Generation Template

```javascript
const { Document, Packer, Paragraph, TextRun, AlignmentType,
        Header, PageNumber, PageBreak, TabStopType, TabStopPosition } = require('docx');

function createSmfManuscript(title, author, chapters, contactInfo = {}) {
  const surname = author.split(' ').pop().toUpperCase();
  const shortTitle = title.toUpperCase().split(' ').slice(0, 3).join(' ');
  const totalWords = chapters.reduce((sum, ch) =>
    sum + ch.content.split(/\s+/).length, 0);
  const roundedWords = `${Math.round(totalWords / 1000)},000`;

  // Running header for all pages except title
  const runningHeader = new Header({
    children: [new Paragraph({
      alignment: AlignmentType.RIGHT,
      children: [
        new TextRun({ text: `${surname} / ${shortTitle} / `, font: 'Courier New', size: 24 }),
        new TextRun({ children: [PageNumber.CURRENT], font: 'Courier New', size: 24 })
      ]
    })]
  });

  const doc = new Document({
    sections: [
      // Title page — no header
      {
        properties: {
          page: {
            size: { width: 12240, height: 15840 },
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
          }
        },
        children: [
          // Contact info — top left
          ...createContactBlock(author, contactInfo),
          // Word count — requires tab stop to right-align
          new Paragraph({
            alignment: AlignmentType.RIGHT,
            children: [new TextRun({
              text: `~${roundedWords} words`,
              font: 'Courier New', size: 24
            })]
          }),
          // Title block — centered, ~1/3 down
          new Paragraph({ spacing: { before: 4800 } }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({
              text: title.toUpperCase(),
              font: 'Courier New', size: 24
            })]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 400 },
            children: [new TextRun({ text: 'by', font: 'Courier New', size: 24 })]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 400 },
            children: [new TextRun({ text: author, font: 'Courier New', size: 24 })]
          })
        ]
      },
      // Chapter sections — with running header
      ...chapters.map((chapter, index) => ({
        properties: {
          page: {
            size: { width: 12240, height: 15840 },
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
            pageNumbers: { start: index === 0 ? 1 : undefined }
          }
        },
        headers: { default: runningHeader },
        children: [
          // Drop — ~1/3 down page
          new Paragraph({ spacing: { before: 4800 } }),
          // Chapter heading — ALL CAPS, centered
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 480 },
            children: [new TextRun({
              text: `CHAPTER ${numberToWord(index + 1).toUpperCase()}`,
              font: 'Courier New', size: 24
            })]
          }),
          // Subtitle if chapter has a title
          ...(chapter.title ? [new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 480 },
            children: [new TextRun({
              text: chapter.title, font: 'Courier New', size: 24
            })]
          })] : []),
          // Chapter body
          ...parseSmfParagraphs(chapter.content),
          // End mark after final chapter
          ...(index === chapters.length - 1 ? [
            new Paragraph({ spacing: { before: 480 } }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [new TextRun({
                text: '# # #', font: 'Courier New', size: 24
              })]
            })
          ] : [])
        ]
      }))
    ]
  });

  return Packer.toBuffer(doc);
}

function createContactBlock(author, info) {
  const lines = [
    author,
    info.address || '[Address]',
    info.cityStateZip || '[City, State ZIP]',
    info.phone || '[Phone]',
    info.email || '[Email]'
  ];

  return lines.map(line => new Paragraph({
    spacing: { line: 240 },  // Single-spaced for contact block
    children: [new TextRun({ text: line, font: 'Courier New', size: 24 })]
  }));
}

function parseSmfParagraphs(content) {
  const blocks = content.split('\n\n');
  let isFirstAfterBreak = true;

  return blocks.filter(b => b.trim()).map(block => {
    const trimmed = block.trim();

    // Scene break — # centered (SMF standard)
    if (trimmed === '* * *' || trimmed === '---' || trimmed === '#') {
      isFirstAfterBreak = true;
      return new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 480, after: 480, line: 480 },
        children: [new TextRun({ text: '#', font: 'Courier New', size: 24 })]
      });
    }

    // Regular paragraph — double-spaced
    const indent = isFirstAfterBreak ? {} : { firstLine: 720 };
    isFirstAfterBreak = false;

    return new Paragraph({
      spacing: { line: 480 },  // Double-spaced (480 twips = 24pt)
      indent,
      children: parseSmfInline(trimmed)
    });
  });
}

function parseSmfInline(text) {
  // In SMF, italic is indicated by underline (traditional convention)
  // Bold is rarely used in manuscripts
  const runs = [];
  const regex = /\*\*(.+?)\*\*|\*(.+?)\*/g;
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      runs.push(new TextRun({
        text: text.slice(lastIndex, match.index),
        font: 'Courier New', size: 24
      }));
    }
    if (match[1]) {
      // Bold — keep as bold (rare in manuscripts)
      runs.push(new TextRun({
        text: match[1], bold: true, font: 'Courier New', size: 24
      }));
    } else if (match[2]) {
      // Italic → underline (SMF convention: underline indicates italic to typesetter)
      runs.push(new TextRun({
        text: match[2], underline: {}, font: 'Courier New', size: 24
      }));
    }
    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    runs.push(new TextRun({
      text: text.slice(lastIndex), font: 'Courier New', size: 24
    }));
  }

  return runs;
}

function numberToWord(n) {
  const words = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven',
    'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen',
    'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty',
    'twenty-one', 'twenty-two', 'twenty-three', 'twenty-four', 'twenty-five',
    'twenty-six', 'twenty-seven', 'twenty-eight', 'twenty-nine', 'thirty',
    'thirty-one', 'thirty-two', 'thirty-three', 'thirty-four', 'thirty-five',
    'thirty-six', 'thirty-seven', 'thirty-eight', 'thirty-nine', 'forty',
    'forty-one', 'forty-two', 'forty-three', 'forty-four', 'forty-five',
    'forty-six', 'forty-seven', 'forty-eight', 'forty-nine', 'fifty'];
  return n <= 50 ? words[n] : String(n);
}
```

## Content Parsing Notes

1. Font must be **Courier New 12pt** throughout (monospaced is mandatory)
2. **Double-spacing** everywhere (480 twips = 24pt line height)
3. Scene breaks use **`#`** (single hash, centered) — not `* * *`
4. Italic text is rendered as **underline** (traditional SMF convention —
   underline signals the typesetter to set the text in italic)
5. Chapter headings are **ALL CAPS** and centered
6. Title page includes full contact information and rounded word count
7. Running header on every page: `SURNAME / TITLE / page#`
8. End mark `# # #` centered after the final paragraph of the manuscript
9. First paragraph after heading or scene break: no indent
10. All other paragraphs: 0.5" first-line indent

## Agent/Publisher Submission Notes

When delivering an SMF file, include these notes for the user:
- This format follows William Shunn's Standard Manuscript Format guidelines
- Widely accepted by literary agents and traditional publishers
- Fill in contact information on the title page before submitting
- If an agent specifies different formatting, their requirements take priority
- Some agents now accept Times New Roman — check submission guidelines
- Word count on title page is rounded to the nearest thousand (industry convention)
