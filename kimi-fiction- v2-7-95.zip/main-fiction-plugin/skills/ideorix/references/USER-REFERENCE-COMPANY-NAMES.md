# Company & Business Name Generator — User Reference

## Quick Start

Say **"Name a business"** or **"Generate company names"** at any time.

During Story Bible generation (Phase 2A), the generator runs automatically for every business, shop, pub, restaurant, corporation, and organisation in the story world.

## What It Does

Generates fictional business names that are:
- **Era-accurate** — naming conventions matched to the founding period
- **Regionally authentic** — UK pubs, French ateliers, Japanese KK, Italian fratelli, etc.
- **Business-type appropriate** — law firms vs startups vs pubs vs criminal fronts
- **Real-world verified** — no collision with actual companies

## The Process

1. **Engine defines** business type, founding era, region, industry, scale, owner background
2. **Generator researches** era-appropriate conventions, regional patterns, type conventions
3. **Generator checks** all candidates against real-world companies (5-step collision protocol)
4. **Engine presents** 5 name candidates with full justification
5. **You select** a name (or mix-and-match, request more, or provide your own)
6. **Name locked** into Story Bible and entity database

## Three Research Layers

### Layer 1: Era-Appropriate
| Era | Naming Style | Examples |
|-----|-------------|----------|
| Pre-1900 | Owner's surname + trade | "Whitfield & Sons", "The Crown Inn" |
| 1900-1940 | Surname or trade + location | "Brennan's Hardware", "Pacific Electric" |
| 1940-1970 | Geographic + industry, compounds | "Midwest Manufacturing" |
| 1970-1990 | Acronyms, abstract names | "CompuServe", "Goldman Sachs" |
| 1990-2010 | Portmanteaus, playful, .com culture | "PayPal", "BlackBerry" |
| 2010-present | Single abstract words, short, global | "Stripe", "Notion", "Figma" |

### Layer 2: Regional Authenticity
| Region | Key Conventions |
|--------|----------------|
| UK | Pub formulas, "& Sons"/"& Co.", Ltd/PLC |
| US | Owner or street names, LLC/Inc/Corp |
| France | "Maison", "Chez", "Atelier" + surname, SARL/SA |
| Germany | Compound descriptive names, GmbH |
| Japan | Founder surname or aspirational kanji, KK (株式会社) |
| Italy | "Fratelli" (Brothers), saint references, SpA/Srl |
| Latin America | "Hermanos", SA/SRL, geographic references |
| India | Family dynasty names, "& Sons"/"& Brothers", Pvt Ltd |

### Layer 3: Business Type
| Type | Naming Pattern |
|------|---------------|
| Pubs/Bars | Heraldic symbols, landmarks, traditional formulas |
| Restaurants | Owner's name, cuisine type, location |
| Shops | Owner surname + trade |
| Law Firms | Partner surnames — never cute |
| Corporations | Geographic + industry, abstract coined words |
| Startups | Short, punchy, single word or portmanteau |
| Criminal Fronts | Deliberately bland and forgettable |
| Newspapers | [City/Region] + [Times/Herald/Post/Gazette] |

## Real-World Collision Check

Every candidate is verified through 5 checks:

1. **Exact match** — Would a reader Google this and find a real company?
2. **Industry match** — Similar name in the same industry?
3. **Famous brand** — Evokes a well-known brand?
4. **Phonetic similarity** — Sounds like a real company in an audiobook?
5. **Lawsuit plausibility** — Could a real company claim confusion?

Candidates that fail ANY check are rejected before you see them.

## Business Name Differentiation

The engine automatically ensures:
- No two businesses share a first word
- No business name starts with the same letter as a main character's surname
- No business names that rhyme or alliterate with character names
- Business names contrast in length and feel
- Criminal front names are deliberately forgettable

## AI Patterns — Automatically Blocked

These patterns are rejected at generation time:

| Pattern | Examples |
|---------|----------|
| [Abstract] + [Tech] | Nexus Technologies, Apex Systems |
| [Adjective] + [Animal] | The Gilded Fox, The Crimson Owl |
| [Whimsy] & [Whimsy] | Whiskers & Wands, Petals & Prose |
| The Cozy [Noun] | The Cozy Corner, The Cozy Cup |
| [Greek/Latin] + [Corp] | Helix Corp, Omni Industries |

## Each Candidate Includes

```
1. BUSINESS NAME
   Naming logic:     Why this name (owner/location/trade/abstract)
   Era accuracy:     Why this style fits the founding period
   Regional fit:     Why it works in this setting
   Type fit:         Why it matches the business type
   Tone match:       How it serves the story
   Real-world check: Confirmed no collision
   Cast check:       No collision with character names
```

## When It Runs

| Context | Trigger | Mode |
|---------|---------|------|
| Story Bible (Phase 2A) | Automatic | All businesses named before writing begins |
| New business mid-manuscript | Architect flags in brief | Before Writer executes |
| On demand | "Name a business" | Interactive, any time |
