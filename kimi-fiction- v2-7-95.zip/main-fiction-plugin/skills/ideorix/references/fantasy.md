---
name: fantasy-genre
description: Genre-specific instructions for general fantasy fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Fantasy. Genre Plugin

## Metadata
- id: fantasy
- name: Fantasy
- icon: 🏰
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Three-Act Structure", "Hero's Journey", "Save the Cat", "Dan Harmon Story Circle"]

## Subgenre Options
Present during setup:
- **Adventure Fantasy**. Quest-driven, exploration-focused, wonder and discovery
- **Coming-of-Age Fantasy**. Young protagonist discovering power, identity, and the wider world
- **Portal Fantasy**. Character from our world enters a fantasy realm (the fish-out-of-water engine)
- **Cozy Fantasy**. Low stakes, warm community, gentle magic; the world is safe even if imperfect
- **Comedy Fantasy**. Humour-forward, genre-aware, playful subversion of tropes
- **Romantic Fantasy**. Strong romance thread woven through a fantasy adventure (lighter than romantasy)

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Balanced. action/adventure sequences balanced with discovery, character growth, and wonder
- Must open with: Character in motion, a discovery, or a disruption. never with a map description or creation myth

BEATS PER CHAPTER
1. Wonder Beat. At least one moment of genuine wonder, discovery, or magic that makes the reader feel the world is bigger and stranger than expected
2. Character Growth. The protagonist learns something, fails at something, or makes a choice that reveals or changes them
3. Conflict Progression. The central conflict advances through obstacles, revelations, or complications
4. World Experience. The reader discovers something about the world through the character LIVING in it
5. Connection Beat. A relationship deepens, fractures, or forms (friendship, mentorship, rivalry, romance)

FANTASY ARCHITECTURE
- POV: 1-3 characters depending on length tier
  - Novella: 1 POV (tight focus)
  - Standard: 1-2 POVs
  - Epic: 2-3 POVs
- The world should inspire WONDER. the reader should want to visit
- Magic enhances the world. it creates possibility, beauty, and danger in equal measure
- The story's heart is the protagonist's GROWTH, not just the plot's resolution
- Friendship and found family are legitimate story engines (not just romance)

MAGIC SYSTEM REQUIREMENTS
- Establish how magic works before it solves problems
- Magic has limits and costs (but the costs can be lighter than in dark fantasy)
- The magic system should create interesting PROBLEMS, not just interesting solutions
- Magic should feel connected to the world's culture, history, and ecology
- Avoid "magic as technology". magic should retain some mystery and wonder
- Soft magic is perfectly valid: not everything needs hard rules, but LIMITS must be demonstrated

WORLD-BUILDING DELIVERY
- Wonder through character experience: the reader discovers the world as the character does
- NO infodumps. world-building through observation, interaction, and consequence
- New locations should make the reader pause and imagine
- The world has history that shows in its present: old ruins, cultural traditions, geographical scars
- Invented terms: max 3 per chapter, always contextually clear
- Food, clothing, music, and architecture reveal culture more than exposition

FORBIDDEN IN GENERAL FANTASY
- Geography lectures or creation myth prologues
- Magic that works perfectly without rules or consequences
- "Tell the reader about the world" narration (SHOW through character experience)
- One-dimensional evil (even the villain of an adventure fantasy has a reason)
- The hero who wins through raw power rather than cleverness, sacrifice, or growth
- Modern language or anachronisms (no "okay", "guys", "whatever")
- "Chosen one" prophecy as a substitute for character agency
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation through worldbuilding, Anticipation through quest structure, Affection with the cast, Revelation at thematic core.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the fantasy cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  fantasy cues below apply directly.VOICE & TONE
- POV: Third close past tense (standard) or first person (for portal/coming-of-age)
- Voice: Engaging and immersive. the voice should make the reader feel they are IN the world, seeing it fresh
- Tone: Adventurous with emotional depth. lighter than dark fantasy but not frivolous
- Register: Elevated but accessible. no "thee/thou", but also not modern casual

PROSE IMPERATIVES
- WONDER is the core emotional tool: describe things that inspire awe, curiosity, or delight
- Every new location should engage at least 3 senses (not just sight)
- Magic should be BEAUTIFUL or TERRIFYING (or both). never boring or clinical
- Action sequences are clear and kinetic. the reader should feel the movement
- Quiet moments between adventures carry emotional weight. campfire conversations, shared meals, the view from a mountain pass
- Nature is alive and specific: not "they walked through the forest" but specific trees, specific sounds, specific light

PROSE RHYTHM MAPPING
- Chapter 1 must establish world-immersion + character stakes through rhythmic variation
- Medium-long sentences (18-25 words) for world-texture: descriptions of magic, landscape, culture, and wonder moments that let the reader sink into the world
- Shorter sentences (12-16 words) for action beats and dialogue: combat, quick exchanges, moments of surprise or decision
- World-building arrives through LIVED EXPERIENCE, not exposition. the rhythm slows when the character encounters something wondrous, quickens when stakes press
- Opening paragraphs: establish a medium-flowing rhythm that signals "this is a world worth inhabiting". not rushed, not languorous
- Wonder moments demand longer, more musical sentences. give the reader time to picture the impossible
- Dialogue scenes: tighten the rhythm. Characters speak in shorter bursts; narration between lines stays lean
- Action sequences: sentences compress. Verbs dominate. Fragments are permitted. The reader's pulse should match the character's
- Transitions between wonder and action should be FELT in the sentence length shift. not abrupt, but noticeable
- Internal thought: medium rhythm, slightly shorter than world-description, slightly longer than action
- The paragraph itself has rhythm: vary sentence lengths within each paragraph (long-short-medium, or short-short-long) to avoid monotony
- Avoid stacking sentences of identical length. three 20-word sentences in a row creates a drone
- Tension baseline: ≥5 from the first page. Even quiet world-building scenes carry an undercurrent of stakes or mystery
- The first chapter's rhythm should feel like walking into a new world with eyes wide. measured but alert
- Dialogue tags and action beats between speech keep the rhythm from flattening during conversation
- End-of-chapter rhythm: sentences should tighten toward the chapter's final beat, creating a pull into the next chapter
- Read paragraphs aloud. if the rhythm doesn't vary, rewrite until it breathes
- The goal: prose that moves like a river. sometimes wide and slow (wonder), sometimes narrow and fast (danger), always flowing forward

SENSORY CRAFT FOR FANTASY
- Fantasy demands MORE sensory detail than contemporary fiction because the reader can't draw on personal experience
- Touch, smell, sound, taste, light are all available. but use ONE per beat, not all five in a paragraph. The cave is cold underfoot OR it smells of wet limestone. Not both at once. Let each detail land before moving to the next
- Prioritise non-visual senses: smell, touch, and taste make unfamiliar worlds feel real faster than visual description

DIALOGUE CRAFT
- Speech patterns reflect culture and education (but never become illegible dialect writing)
- Humor is genre-appropriate: wordplay, situational comedy, character-based wit
- Exposition through DISAGREEMENT: two characters with different knowledge argue about how something works
- Formality varies by setting: court speech vs tavern speech vs battlefield speech
- Foreign languages/terms used sparingly and contextually (never a full sentence the reader can't parse)

WONDER CRAFT
- The "tourist moment": when a character (and reader) encounters something genuinely new, give it SPACE
- Describe magical and fantastical elements as if the POV character is really seeing them for the first time:
  WRONG: "The magical forest was beautiful and enchanted."
  RIGHT: "The trees grew sideways here, trunks curving like frozen rivers, their bark phosphorescent blue in the dusk. She put her hand on one and felt it hum. a vibration deep enough to feel in her ribs."
- Vary the wonder: sometimes beautiful, sometimes eerie, sometimes frightening, sometimes amusing
- Wonder fades over time for characters who live in the world. show what THEY take for granted that the reader finds amazing
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

FANTASY CRAFT (35% of total):
- Wonder: does the world inspire awe, curiosity, or delight? (0-100)
- Magic system is interesting, limited, and consistent? (0-100)
- World delivered through experience, not exposition? (0-100)
- Growth: does the protagonist change meaningfully? (0-100)

STORY CRAFT (35% of total):
- Plot advances with clear cause-and-effect? (0-100)
- Conflict escalates appropriately? (0-100)
- Relationships feel authentic and serve the story? (0-100)
- Pacing balances action, discovery, and character? (0-100)

PROSE QUALITY (30% of total):
- Sensory detail creates immersion? (0-100)
- Dialogue is differentiated and natural? (0-100)
- Action scenes are clear and kinetic? (0-100)
- Wonder moments land (the reader pauses to imagine)? (0-100)

AUTOMATIC FAILS (score = 0):
- Exposition dump longer than 2 paragraphs
- Magic solves the central problem without established rules
- Geography/cosmology lecture in narration
- Modern language or anachronisms in dialogue
- One-dimensional villain with no comprehensible motivation
- Protagonist wins through power rather than growth, cleverness, or sacrifice
```

## Continuity Rules

```
FANTASY CONTINUITY. WHAT TO TRACK

MAGIC SYSTEM:
- What magic can do, what it costs, and what it can't do
- Each character's magical capabilities and limitations
- Magical objects: location, capabilities, who possesses them
- If new magic is learned, how it was learned and what it cost
- Consistency: same spell, same rules, same cost, every time

WORLD GEOGRAPHY:
- Travel times between locations (consistent throughout)
- Terrain and climate: mountains, forests, deserts, seas. persistent and consistent
- Cities and settlements: once described, details remain constant
- If a location is destroyed or changed, it stays changed

CHARACTER GROWTH ARC:
- What the protagonist believed at each story point
- What they learned and when
- Skills acquired: what they can do now that they couldn't before
- Relationships: who trusts whom, who owes whom, who's been hurt by whom

CULTURAL CONSISTENCY:
- Each culture's customs, values, food, clothing, architecture
- How cultures interact: trade, diplomacy, conflict, misunderstanding
- Religious or magical traditions: consistent rituals, beliefs, taboos
- Social hierarchy: who defers to whom and why

TIMELINE:
- Days of travel between locations
- How long since key events (the battle, the spell, the meeting)
- Seasonal changes across the story
- Character ages if the story spans significant time
```

## Character Rules

```
FANTASY CHARACTER TYPES

THE PROTAGONIST:
- Has a CLEAR personal desire that conflicts with the story's demands
- Starts with a limited view of the world that expands across the story
- Growth is the engine: the person at the end is different from the person at the start
- Skills that reflect their background (a baker's child notices food details, not sword techniques)
- A FLAW that creates genuine problems (not just endearing quirks)
- Agency: they make choices that drive the plot, not just react to events

THE COMPANION(S):
- Each companion brings a different SKILL, PERSPECTIVE, and PERSONALITY
- Companions disagree with each other and with the protagonist. this is productive
- No companion exists just to be helpful. they have their own goals and problems
- The group dynamic shifts across the story as trust builds and tensions arise
- Found family is built through SHARED experience and EARNED trust

THE MENTOR (if present):
- Flawed. they've made mistakes, and those mistakes inform their teaching
- Does NOT have all the answers
- May have their own agenda that doesn't perfectly align with the protagonist's
- Can be wrong. Can fail. Can die.
- Teaches through experience and failure, not lectures

THE ANTAGONIST:
- Has comprehensible motivation (power, fear, grief, ideology, survival)
- Poses a genuine threat that the protagonist cannot simply overpower
- Has strengths and competencies. they are dangerous for specific reasons
- The resolution requires understanding what drives them, not just defeating them

VOICE DIFFERENTIATION:
- Every companion should be identifiable by dialogue alone
- Cultural background shapes speech patterns
- Education level affects vocabulary
- Characters under stress reveal their true personality
- Humor styles differ: one is witty, another is sarcastic, another is deadpan
```

## Arc Rules

```
FANTASY STORY STRUCTURE

ACT 1: THE KNOWN WORLD (first 25%)
- Establish the protagonist in their ordinary life. what they want, what they lack
- The world is introduced through daily life, not exposition
- The inciting incident disrupts their ordinary world (discovery, crisis, call)
- The protagonist resists or hesitates before committing (this is human)
- Companions introduced naturally through the story's demands
- The first taste of the wider world / deeper magic
- END OF ACT 1: The protagonist crosses a threshold. the ordinary world is behind them

ACT 2A: THE NEW WORLD (to midpoint)
- Discovery phase: the protagonist (and reader) explore the wider world
- Skills tested and found wanting. early failures drive learning
- Alliances form through shared adversity
- The scope of the threat becomes clearer
- Wonder moments: the world should be WORTH exploring
- MIDPOINT: A revelation that changes the protagonist's understanding of the conflict

ACT 2B: THE NARROWING PATH (midpoint to dark moment)
- Stakes become personal. it's no longer about the quest, it's about the people
- The protagonist's flaw creates a major setback
- Alliances are tested by pressure and disagreement
- The antagonist's plan advances. the clock is ticking
- Loss: something or someone important is lost
- DARK MOMENT: The protagonist faces their deepest fear or greatest failure

ACT 3: THE TRANSFORMATION (final 25%)
- The protagonist uses EVERYTHING they've learned (skills, relationships, self-knowledge)
- The resolution requires growth: who they've become, not just what they can do
- The climax uses established magic, world-rules, and character dynamics
- Sacrifice is real. victory costs something
- The world after: changed but continuing. The protagonist's place in it has shifted.
- Wonder survives: even after the climax, the world retains its magic

GROWTH ARC TRACKING:
- Chapter 1: Who is the protagonist? What do they believe? What do they want?
- Midpoint: How have their beliefs been challenged? What have they learned?
- Dark moment: What must they give up or face to continue?
- Climax: How does their growth ENABLE the resolution?
- End: Who have they become? What do they believe now?
```

## Timeline Rules

```
FANTASY TIMELINE

TRAVEL AND DISTANCE:
- Establish journey times early and maintain them
- On foot: ~15-20 miles/day (rough terrain less)
- Horseback: ~30-40 miles/day
- Ship: depends on wind, current, type of vessel. establish and be consistent
- Magical travel: if it exists, define its limits and costs

SEASONAL PROGRESSION:
- Track seasons if the story spans months
- Seasonal effects on travel, food, moods, and environment
- Harvest, planting, festivals. communities mark time differently
- Weather affects plot: winter closes mountain passes, storms delay ships

STORY CLOCK:
- How much time passes between each chapter?
- If multiple POVs: are they in the same timeframe?
- Key deadlines: is there a solstice ritual, a coronation, a seasonal event driving the timeline?

LEARNING TIMELINE:
- Magical skills take time to develop. no mastery overnight
- Physical training needs duration. a month of sword practice, not a montage
- Relationships deepen over time, not over a single conversation
```

## Genre-Specific Craft Techniques

Fantasy is the foundational genre of the imaginative-fiction
catalogue and the parent of an extensive sub-genre cluster
(epic, dark, urban, cozy, historical, paranormal, romantasy,
magical realism, sword-and-sorcery, gaslamp, weird, grimdark).
Its readers — from the Tolkien tradition through Le Guin,
Robin Hobb, Steven Erikson, Joe Abercrombie, N.K. Jemisin's
Broken Earth and Inheritance trilogies, Brandon Sanderson's
Cosmere, Patrick Rothfuss, Robert Jackson Bennett, R.F. Kuang,
Tasha Suri, Tamsyn Muir, Samantha Shannon, Andrea Stewart,
Olivie Blake, Rebecca Roanhorse, V.E. Schwab — bring
sophisticated expectations: that the world feel inhabited
rather than constructed, that the magic operate by rules the
reader can engage with, that the prose's wonder-register be
genuine rather than performed, and that the imaginative
investment the form requires be repaid with substantive
narrative work. The techniques below are how the form delivers
its core pleasures while avoiding the failure modes (info-
dump worldbuilding, Tolkien-cosplay default settings, magic
that solves problems by authorial fiat, characters who exist
only to navigate a tour of the writer's worldbuilding notes).

### The Wonder Engine

Fantasy's unique emotional tool is WONDER — the feeling that
the world is bigger, stranger, and more magical than the
reader expected. Every 2-3 chapters should deliver at least
one genuine wonder moment. The technique is the genre's
signature emotional register, and its absence is what
distinguishes literary fiction with magical elements from
fantasy proper. Wonder is not the same as awe, surprise, or
spectacle — it is the specific recognition that the world
contains more than the reader had imagined possible, and that
the writer's imagination has met the reader's with something
worth the journey.

**Wonder Categories (rotate across the manuscript):**

| Type | Effect | Example |
|------|--------|---------|
| **Scale** | The world is VAST | Seeing a city carved into a mountainside for the first time |
| **Beauty** | The world is BEAUTIFUL | A forest where the trees sing in harmony at dawn |
| **Strangeness** | The world is ALIEN | A market where memories are traded in glass vials |
| **Power** | Magic is AWE-INSPIRING | Watching a mage call lightning. and seeing the cost on their body |
| **History** | The world has DEPTH | Walking through ruins that dwarf the current civilization |
| **Connection** | Magic is INTIMATE | A spell that lets you feel what another person feels, just for a moment |

**Rule:** Wonder moments need SPACE — at least one full
paragraph of sensory detail. Don't rush past them. The genre's
most-flagged failure is the wonder moment compressed into a
sentence to keep the plot moving; the reader has come for
this, and the prose must register that. The technique
requires deliberate rotation: a manuscript that delivers four
Scale moments and nothing else has narrowed its wonder
register to a single note. Test: chart the wonder moments in
the manuscript and verify that across the book the categories
are mixed, with no single category dominating.

### The Discovery Protocol

Fantasy readers want to figure out the world alongside the
character. Structure information delivery as DISCOVERY rather
than as exposition. The protocol distinguishes worldbuilding
that earns its presence (the reader works for what they
learn, and is rewarded for the work) from worldbuilding that
is announced (the narrator hands the reader information that
should have been earned through scene).

1. **Encounter** — The character meets something new (a
   custom, a creature, a spell, a location, a political
   dynamic, a religious practice, a piece of architecture)
2. **Confusion** — They don't fully understand it (the reader
   doesn't either; this is the moment the reader becomes
   genuinely curious)
3. **Partial Understanding** — Context clues provide most of
   the picture (the protagonist works it out partially, the
   reader keeps pace)
4. **Full Understanding** — Later events clarify what was
   observed (sometimes chapters later; the protocol pays off
   when the reader recognises that an early-book observation
   has now become legible)

This protocol applies to magic rules, cultural customs,
political dynamics, religious frameworks, and historical
context alike. Test: pick three pieces of significant
worldbuilding the manuscript delivers and verify each one
followed the protocol rather than arriving as exposition. If
the reader was told instead of shown, the worldbuilding has
not been earned.

### The Magic System Discipline

Fantasy's magic systems range from soft (atmospheric, felt-
rather-than-explained, operating by mood and metaphor) to hard
(strictly rule-governed, explicable, with consistent costs and
limits) — see Sanderson's Three Laws of Magic for the
canonical hard-magic framework. The technique is not picking
the right end of the spectrum but committing to the chosen
position and holding it with discipline. The reader who picks
up a soft-magic book (Tolkien, Le Guin's Earthsea, Susanna
Clarke's *Jonathan Strange & Mr Norrell* in its felt-magic
register, recent atmospheric fantasy by R.F. Kuang's *Babel*
and Olivie Blake) is settling into a register where magic
operates by mystery and consequence; the reader who picks up
a hard-magic book (Sanderson, Will Wight's Cradle, the
Cosmere broadly) is engaging with a system whose rules they
will track and whose use will operate within stated limits.

Soft magic's discipline: consistent atmospheric register;
costs felt rather than enumerated; magic should not solve
problems the rest of the narrative could not solve;
revelations of capability scaled so that the reader's
investment in the system is rewarded by depth, not by
mechanism.

Hard magic's discipline: rules established before being used;
costs consistent throughout; no new capabilities without
setup; the climactic problem solved by the rules the reader
has been learning, not by an exception the writer invents at
the climactic moment.

The genre permits — and is strengthened by — hybrid systems
that operate harder in some registers (combat, conflict
resolution) and softer in others (atmosphere, emotional
truth). What it does not permit is drift: the soft-magic book
that suddenly deploys hard-magic mechanics at the climax has
broken its contract; the hard-magic book that waves through a
mechanism at the climax has done the same. Test: identify the
manuscript's magic-system tier and read three magical events
from spaced points in the book. Are they operating on
consistent principles? If not, the discipline has slipped.

### The Worldbuilding Iceberg

Fantasy carries a worldbuilding iceberg beneath every scene:
political structures, religious frameworks, economic systems,
linguistic groups, historical periods, geographic
specificities, racial / species relations, magical
institutions, climate and seasonal patterns, technological
levels per region, trade networks, family / clan / dynastic
configurations. The reader needs the surface (enough to
follow the plot, feel the stakes, trust the world); the
reader does not need the iceberg (the writer's full
encyclopaedia of worldbuilding notes). The technique is
calibration — every scene exposes the minimum of the iceberg
required for the scene's purpose, in the sensory grammar of
the POV character, embedded in actions and reactions that
also do narrative work.

The danger sign is the worldbuilding paragraph the writer
cannot bear to cut because they spent so much time
researching or inventing it. The strongest fantasy
practitioners (Le Guin, Hobb, Jemisin, Erikson at his best)
embed worldbuilding so thoroughly into character experience
that the reader absorbs the world without ever feeling
they were taught it. The weaker register is the
worldbuilding-as-tour, where chapters are organised by
location-introduction and the protagonist serves primarily
to walk the reader through the writer's invented setting.

Test: cut a sample chapter to half its worldbuilding
exposition. Does the chapter's plot, character work, and
emotional weight survive the cut? If yes, the cut exposition
was iceberg-beneath-the-water and didn't need to be on the
page. If no, the worldbuilding was load-bearing and stays.

### The Quest Structure Discipline

Fantasy's most-published structural template is the quest —
the protagonist (alone or in a fellowship) leaves an ordinary
world, undertakes a journey toward a specific objective,
encounters trials and growth across the journey, faces a
climactic confrontation, and returns (or doesn't, or returns
changed). The structure inherits from Campbell's monomyth and
its fantasy refinements through Tolkien, Eddings, Jordan, and
their successors. The discipline is to use the structure
intentionally — knowing when to deploy its conventions, when
to subvert them, and when to abandon them for a different
structural template (court intrigue; siege; portal-fantasy;
character-driven sojourn; multi-POV epic).

The contemporary genre permits — and increasingly rewards —
quest deviation: the quest that fails and forces a different
question; the quest whose objective turns out to be wrong;
the quest that the protagonist abandons for better reasons;
the quest that resolves through declined power rather than
seized power. The technique requires that whichever
structural template the manuscript chooses, that template be
recognisable to the reader as a deliberate choice, and the
beats of the chosen template must be earned in scene rather
than gestured at by genre convention.

Test: identify the manuscript's structural template and trace
its beats across the book. Are the beats present, in order,
earned by character work? If the structure is "quest with
chosen one and dark lord" and the beats arrive on schedule
without earning, the manuscript has reached for genre
convention rather than committed to its own version of the
form.

### The Voice and Register Calibration

Fantasy operates across a spectrum of registers (high-formal
through middle-vernacular through demotic-contemporary) and
the manuscript must commit to a specific register and hold
it. The high-formal register (Tolkien, Hobb in *Assassin's
Apprentice*, Jemisin's *Broken Earth* opening, contemporary
literary fantasy) carries the resonance of myth and legend;
the middle-vernacular (Sanderson, Sullivan's Riyria, most
commercial epic fantasy) operates in clear contemporary prose
that doesn't telegraph period; the demotic-contemporary
(Pratchett at his sharpest, contemporary urban fantasy,
modern romantasy) uses contemporary voice deliberately and
permits anachronism for effect.

The discipline is consistency. A manuscript that opens in
high-formal register and swerves to demotic by chapter
twenty has lost its voice; a manuscript that operates
demotic throughout but reaches for elevated register at
climactic moments without preparation has produced
unintentional pastiche. The strongest fantasy
practitioners hold their register through 600+ pages —
Hobb's first-person voice across Fitz's nine novels;
Jemisin's second-person voice across the Broken Earth
trilogy; Sanderson's clear-prose voice across the Cosmere.

Where the manuscript employs multiple POV characters with
different registers (the dwarven warrior whose chapters use
clipped declaratives; the elven scholar whose chapters
operate in elevated diction; the human protagonist whose
register sits between them), each POV's register must be
distinct, recognisable, and consistent across that POV's
chapters. Test: read three chapters from spaced points in
the manuscript and identify each chapter's register. If the
chapters disagree where they shouldn't, calibration has
slipped.

### Fantasy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "magic crackled in the air" | Show the specific magical effect |
| "ancient power stirred within" | Show the physical sensation and what triggers it |
| "destiny called to [character]" | Show the specific event that compels action |
| "the prophecy foretold" | Show the specific words or vision |
| "darkness was spreading across the land" | Show the specific consequence in a specific place |
| "the chosen one" | Show why THIS character, through action not label |
| "power beyond imagination" | Show the specific power and its specific limits |
| "the balance between light and dark" | Show the specific conflict through affected people |
| "the sword sang as it was drawn" | One metallic detail, not personification |
| "an evil that had slumbered for centuries" | Show the specific threat and its specific history |
| "the ancient texts revealed" | Show the specific passage and who reads it |
| "the world hung in the balance" | Show the specific stakes for specific people |
| "his eyes glowed with magical power" | Show ONE specific visual change and its effect on the witness |
| "ancient runes covered the door" | Show ONE specific rune and what it suggests to the character who reads or fails to read it |
| "in a world where magic existed" | Cut; show the magic operating in the opening scene |
| "the dark lord's armies marched" | Show the specific army through one named soldier or one specific company |
| "the elven kingdom lay beyond" | Cut "elven kingdom"; show one specific feature of the landscape that distinguishes it |
| "spoken in the old tongue" | Show the specific word or phrase, even if untranslated, and the listener's specific reaction |

## Genre-Specific Revision Rules

Six revision passes specific to fantasy, each with a single
question, run cover-to-cover before the next begins. Fantasy
revision must hold a wide set of disciplines simultaneously:
the wonder register that distinguishes the form from
literary fiction with magical elements; the worldbuilding
discipline that prevents exposition collapse; the magic-
system consistency that the genre's reader unforgivingly
audits; the character growth that distinguishes fantasy from
travelogue; the voice register that holds the prose's
chosen tier; and the structural discipline that keeps the
form's quest, court, or epic template recognisable. The
passes below are ordered to surface the most-felt failures
first (wonder absence, exposition lumps, magic
inconsistency), narrative-craft failures next (growth, voice),
and the structural-template audit last when the rest of the
book is sound.

### Pass 1: Wonder Check

Read the manuscript with sole attention to its wonder beats.
Does every 2-3 chapter span include a genuine wonder moment?
Mark each wonder moment in the margin with its category
(Scale / Beauty / Strangeness / Power / History / Connection)
and chart the distribution across the book. Are wonder
moments varied across categories, or has the manuscript
narrowed to one or two registers? A book that delivers
wonder only through Scale (vast cities, immense mountain
ranges, armies stretching to the horizon) has missed five-
sixths of the genre's emotional range; a book that delivers
wonder only through Power (impressive magical displays,
catastrophic spell effects) has reached for spectacle without
the form's deeper registers.

Verify wonder moments are given enough space. The genre's
most-flagged failure mode is the wonder moment compressed
into a sentence to keep the plot moving; the reader has come
for this, and the prose must register that. Each wonder
moment deserves at least a full paragraph of sensory detail
through the POV character's specific response. Test: does
the world feel like somewhere the reader wants to explore?
At the close of a sample chapter, the reader should feel
that the world contains more than has been shown — that
beyond the corner of the scene is more world worth visiting.
If the world feels merely surveyed, the wonder engine has
not been deployed.

### Pass 2: Exposition Audit

Flag every passage of three or more consecutive sentences of
pure worldbuilding information. The fantasy reader's
tolerance for exposition is finite — typically about half a
page in concentrated form before attention fragments. Every
piece of worldbuilding must arrive through character
experience: the protagonist encountering, navigating,
struggling with, or being changed by the world rather than
having it explained to them. The Discovery Protocol from
the GCRF should be operating throughout.

Scan specifically for:
- "As you know" dialogue (one character explaining to
  another what both already know, for the reader's benefit)
- Narrator explaining history, culture, or magic directly to
  the reader without grounding the explanation in scene
- Encyclopedia paragraphs (the prose's voice shifting into
  encyclopedia register to deliver information the writer
  wanted on the page)
- POV-character interior monologue used as exposition vehicle
  (the protagonist suddenly recalling, in the middle of a
  fight, the entire history of the magical war for the
  reader's benefit)

The fix for exposition lumps is integration — convert the
information into something the protagonist is doing,
deciding, or fearing — not summary cuts that leave the
reader under-informed. Where exposition genuinely cannot be
dramatised (the political backstory the climax depends on),
distribute it across multiple scenes as overheard fragments,
remembered detail, or specific conversations rather than
delivered in one block.

### Pass 3: Magic Consistency Audit

Build a magic-rules ledger: every named ability, limitation,
cost, threshold, exemption, and edge case appearing anywhere
in the manuscript, with the chapter and page where each
first appears. Read the manuscript against the ledger. Verify
rules are established before they're used to solve problems
— the deus-ex-magic of the climactic ability nobody mentioned
before chapter twenty-eight is the genre's most-flagged
craft failure. Verify costs are consistent throughout: the
spell that exhausted the protagonist for three days in
chapter five cannot be casually cast in chapter twenty-five
without explanation of how the protagonist's capacity has
changed.

Check that no new capabilities appear without setup. Where
the climax requires a capability not previously demonstrated,
either the capability must be foreshadowed (the protagonist
has reasons to suspect they could do this; the magical
tradition includes this; an ally has hinted at the
possibility) or the introduction of the capability must be
the climactic surprise the prose has been preparing. The
climax must use magic within established rules; the genre's
contract with its reader includes the promise that the rules
the reader has been learning will be the rules that solve
the climactic problem.

Verify also the magic system's tier (soft / hybrid / hard) is
held throughout. Drift between tiers is the most-detected
calibration failure; the soft-magic book that suddenly
deploys hard mechanics or vice versa has broken the contract
the opening chapters established.

### Pass 4: Growth Tracking

Verify the protagonist has demonstrably changed by the end of
the manuscript. Read three protagonist scenes spaced across
the book — opening chapters, midpoint, climactic chapters —
and ask whether the protagonist of the climax could have
made the decisions the climax requires when the book began.
If the answer is yes, the growth arc has not landed; the
protagonist has been moved through plot rather than changed
by it.

Check that growth is earned through experience, not revelation.
The protagonist who grows because they discover their secret
heritage / true identity / hidden bloodline has been served
plot rather than character; the protagonist who grows because
they learned, struggled, failed, and chose differently is
operating within the form. Skills acquired must reflect the
journey's challenges — the protagonist cannot be a master
swordsman at the climax having only sparred with their tutor
in the opening chapters.

The resolution depends on who the character has become, not
just what they can do. The form's deepest pleasure is the
recognition that the protagonist of chapter one could not
have solved the problem of chapter thirty, and the
intervening chapters made the difference visible. Test:
write a one-paragraph character description for the
protagonist as they appear in chapter one and a one-
paragraph description as they appear at the climax. Are the
two descriptions of the same person at different points, or
of different people? Both should be the same person, but
recognisably changed by what occurred.

### Pass 5: Dialogue and Voice Register

Read all dialogue aloud, ideally with a second reader.
Verify no modern language or anachronisms have crept into the
period-or-secondary-world register the manuscript has
established. Check cultural speech patterns are maintained
across each character's appearances — the elven scholar's
diction stays consistent across the book; the dwarven
warrior's idiom doesn't drift into the human protagonist's
voice mid-conversation. Verify characters sound distinct
from each other through vocabulary, sentence rhythm, idiom,
topical concern. Verify formality is appropriate to setting
— the queen's court doesn't operate at coffee-shop register;
the tavern doesn't operate at throne-room register.

Check for the silent-anachronism categories that fantasy is
particularly susceptible to:
- Modern psychological vocabulary (anxiety, depression,
  trauma as named diagnoses; therapeutic language)
- Modern political concepts (democracy, civil rights,
  nationality as administrative category) when the setting
  predates them
- Modern social concepts (the nuclear family as default;
  individual rights; the autonomous self) where the setting
  operates by different social configurations
- Modern technology metaphors ("recharging", "downloading",
  "processing") that postdate the setting
- Pop-culture-quote register (the quippy modern banter that
  signals contemporary screenwriter influence) where the
  manuscript's surface signals a different voice

Test: pick three dialogue exchanges spaced across the book
and ask, in each, whether the period or secondary-world
register holds. Where the writer has reached for clarity by
deploying modern phrasing, the genre's voice contract has
slipped.

### Pass 6: Structural Template Audit

Identify the manuscript's structural template — quest, court
intrigue, siege, portal-fantasy, character-driven sojourn,
multi-POV epic, magical-school, found-family adventure — and
trace its beats across the book. Are the beats present, in
order, earned by character work? Where the manuscript employs
the quest template, the structure's beats (call, refusal,
threshold crossing, mentor encounter, allies and enemies,
trials, abyss, transformation, return) should be present and
earned. Where the manuscript subverts a beat (the protagonist
who refuses the call permanently and the book follows what
they do instead; the mentor who turns out to be wrong; the
abyss that the protagonist doesn't survive in the conventional
sense), the subversion must be deliberate and committed to.

The pass also checks for structural drift — the manuscript
that opens as quest, drifts into court intrigue mid-book,
and resolves as character-driven sojourn has often lost the
structural template the opening promised, and the reader's
experience of the book is of three partial books rather than
one whole. Where the manuscript deliberately combines
structures (the quest that interrupts a court-intrigue
segment; the siege that the protagonist arrives at after
the quest), the combination must read as choice rather than
drift.

Test: write a one-sentence summary of the manuscript's
structural shape. Does the sentence describe a recognisable
fantasy structure? If the answer is "things happen across
many chapters", the structural template has not been
committed to.

## Names & Patterns to Avoid

### Fantasy Character Names. NEVER USE
- AI-default fantasy names: Elara, Lyra, Thorne, Ash, Rowan, Sage, Kael
- "-wyn/-ael" suffixes: Bronwyn, Elowyn, Azrael, Nathanael
- Nature-word names: Storm, River, Blaze, Frost, Rain (as character names)
- Apostrophe names: K'val, Dra'el, Tor'an
- Names that sound like medication: Alarax, Zeridol, Valindra

### Fantasy Place Names. NEVER USE
- "[Nature] + [Settlement]": Willowbrook, Maplewood, Silverstream
- "[Mystical] + [Feature]": Moonvale, Starfall, Dreamhaven
- "[Color] + [Terrain]": Greenfield, Blackwater, Goldspire

### Fantasy Tropes. AVOID or SUBVERT
- Orphan discovers they're secretly royal
- Prophecy that removes character agency
- Magic school with a sorting/houses system
- Dark Lord in a dark tower
- Elves = wise, dwarves = gruff, orcs = evil
- The "it's not a quest" quest (hero denying the obvious)

### Use Instead
- Culturally grounded names: pick a real-world linguistic root for each culture
- Place names that reflect geography, history, or function: Bridgeford, Saltmarsh, High Cairn, Kettering
- Names that sound like they belong to PEOPLE: Maren, Tobin, Dalla, Piet, Essa, Hakan

## Comp Titles

Fantasy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Lord of the Rings* — J.R.R. Tolkien (1954-55): the modern fantasy archetype.
- *A Wizard of Earthsea* — Ursula K. Le Guin (1968): the literary fantasy benchmark.
- *Mistborn* — Brandon Sanderson (2006): the modern hard-magic-system fantasy.
- *The Name of the Wind* — Patrick Rothfuss (2007): contemporary literary-fantasy benchmark.

### Contemporary (current best-in-class)

- *The Fifth Season* — N.K. Jemisin (2015): the Broken Earth trilogy; literary-fantasy benchmark.
- *Spinning Silver* — Naomi Novik (2018): folkloric-fantasy benchmark.
- *Piranesi* — Susanna Clarke (2020): literary-fantasy with constrained-world architecture.
- *The City We Became* — N.K. Jemisin (2020): urban-fantasy-political crossover.
- *The Empire of Gold* — S.A. Chakraborty (2020): the Daevabad trilogy; non-Western epic fantasy.
- *Babel* — R.F. Kuang (2022): dark-academia-fantasy with anti-colonial polemic.
- *Black Sun* — Rebecca Roanhorse (2020): Indigenous-rooted epic fantasy.
- *The Stardust Thief* — Chelsea Abdullah (2022): Arabic-folkloric epic fantasy.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. The most versatile style for general fantasy; warm, detailed illustrations that invite the reader into the world; can range from painterly to graphic depending on tone
- **Cinematic**. Dramatic landscape or character shot with atmospheric lighting; works well for adventure and quest fantasy; signals epic scope without the grim weight of dark fantasy
- **Minimalist**. A single iconic element (a sword, a crown, a magical symbol, a key) against a coloured background; clean and modern; increasingly popular for fantasy that wants to signal "literary quality"
- **Graphic**. Bold, stylized design with strong colour blocking; excellent for younger-skewing fantasy or comedic fantasy; eye-catching and distinctive

### Genre Cover Aesthetics
- **Styles:** Sweeping landscapes that invite exploration, magical effects that suggest wonder rather than threat, characters in journey/discovery poses, warm lighting mixed with magical atmosphere, detailed world-building visible in the cover art, sense of adventure and possibility
- **Colours:** Rich jewel tones (sapphire blue, emerald green, amethyst purple), warm gold and honey amber (magic, discovery, warmth), sunset and dawn colours (journey, transformation), forest greens and earth tones (nature, groundedness), the palette should feel rich and inviting, not dark or threatening
- **Elements:** Landscapes that suggest a wider world (paths disappearing into distance, mountains on the horizon), magical effects (glowing objects, luminous environments, enchanted creatures), journey imagery (roads, ships, horses, maps), key objects from the story, forests, mountains, seas, and skies that feel vast and explorable
- **Typography:** Elegant but readable fonts; often decorative serifs with fantasy character; title integrated with or positioned over the landscape; metallic effects (gold, bronze) common; author name clear but secondary; series branding consistent; the typography should feel like it belongs in this world

### Market Positioning
General fantasy covers should signal "wonder, adventure, and a world worth entering." The cover is a doorway. it should make the reader want to step through. Position against current market (Kuang, Shannon, Novik, Bardugo, Chakraborty). Warm, inviting covers outperform dark and threatening for general fantasy. At thumbnail size, a clear landscape with magical elements and large readable typography works best.

### Cover Design DON'Ts
- No overly dark or grim imagery. general fantasy should feel inviting, not threatening
- No generic "figure with sword" without atmosphere or context
- No cluttered composition with too many elements competing for attention
- No dated 1980s fantasy art style (literal scene depiction with multiple characters)
- No photorealistic human figures in fantasy settings (it creates an uncanny valley)
- No tiny, illegible typography. the title should be one of the largest elements
- No sci-fi elements (spaceships, futuristic technology) unless the story explicitly blends genres
