---
name: adventure-genre
description: Genre-specific instructions for action adventure fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Action Adventure. Genre Plugin

## Metadata
- id: adventure
- name: Action Adventure
- icon: ⚔️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "The Hero's Journey", "Save the Cat", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Treasure Hunt**. The quest for something hidden: artifacts, treasure, lost cities; maps, clues, rivals, and the race to get there first
- **Survival Adventure**. The protagonist vs. nature or hostile environment: shipwreck, wilderness, extreme terrain; the body and mind pushed to breaking
- **Exploration/Expedition**. The journey into the unknown: uncharted territory, first contact, discovery; wonder and danger in equal measure
- **Military/Tactical**. Combat-driven adventure: missions, operations, warfare; the tactical and the human under fire
- **Heist/Caper**. The plan, the team, the execution, the complication; intelligence and skill against security and opposition
- **Pulp Adventure**. High-octane, globe-trotting, larger-than-life: the Indiana Jones tradition; adventure as pure entertainment

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: RELENTLESS. action adventure is the fastest genre; chapters are short, scenes are tight, momentum never stops
- Must open with: ACTION or IMMEDIATE STAKES. the protagonist in motion, in danger, or making a decision under pressure

BEATS PER CHAPTER
1. Action Beat. Physical action: running, fighting, climbing, escaping, pursuing; the body in motion
2. Stakes Beat. What's at risk is clear and felt: life, the mission, the treasure, someone they care about
3. Complication Beat. The plan changes: a new obstacle, a betrayal, a discovery that shifts the situation
4. Skill Beat. The protagonist uses their competence: tactical thinking, physical ability, knowledge, improvisation
5. Momentum Beat. The chapter ends with forward thrust: a cliffhanger, a new direction, a ticking clock

ACTION ADVENTURE ARCHITECTURE
- MOMENTUM is sacred: the story must feel like it's ALWAYS MOVING
- The PROTAGONIST is competent: they're good at what they do (fighting, thinking, surviving)
- The WORLD is the arena: jungles, deserts, oceans, mountains, cities. the setting is an active force
- STAKES are clear and escalating: life and death, the fate of the mission, the clock ticking
- The PLAN is essential: there's always a plan, and it always goes wrong, and the protagonist improvises
- PHYSICAL INTELLIGENCE: the protagonist thinks with their body. instinct, reaction, spatial awareness
- SPECTACLE with character: action scenes should be visually stunning AND reveal character
- POV: Third person past (classic adventure voice, allows scope) or first person present (maximum immediacy)

ACTION SCENE PRINCIPLES
- Every action scene has a GOAL (not just "fighting")
- The environment is a weapon: use the terrain, the weather, the objects at hand
- Action has PHASES: the situation, the plan, the execution, the complication, the improvisation
- Physical consequences: injuries accumulate, exhaustion matters, the body has limits
- The reader must be able to FOLLOW the action: spatial clarity is essential
- Short sentences for speed; longer ones for tactical thinking or sensory detail

FORBIDDEN IN ACTION ADVENTURE
- Invincible protagonists who never get hurt or tired
- Action without consequences (unlimited ammunition, no injuries, instant recovery)
- Stopping the story for exposition, backstory, or lengthy reflection
- Generic settings (the jungle, the desert) without specific, sensory detail
- Villains who explain their plans instead of executing them
- Technology or physical feats that break the story's established reality
- Romance scenes that kill the momentum (integrate romantic tension into action)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (primary — action set-pieces), Anticipation (peril escalation), Captivation (setting & set-piece geography).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Third person past (the classic, allows wide-angle action) or first person present (maximum adrenaline)
- Voice: Lean, precise, kinetic. every word earns its place; the prose is a vehicle for velocity
- Tone: Thrilling with moments of humour, wonder, or emotion between the action beats
- Register: Accessible and direct; action adventure prose is CLEAN. no purple passages, no obscure vocabulary

PROSE IMPERATIVES
- KINETIC PROSE: the sentence structure mirrors the action
  - Short sentences for speed: "He ran. The wall was close. He jumped."
  - Longer sentences for tension: "He counted the guards, mapped the exits, calculated the distance to the fence, and knew. with the certainty that comes from doing this too many times. that the margin was three seconds."
  - Fragments for impact: "The explosion. Then silence. Then dust."
- SPATIAL CLARITY: the reader must always know WHERE things are
  - Establish the space before the action starts
  - Track character positions: who's where, what's between them
  - Use compass, clock, or relative directions: "to his left," "twenty feet above," "behind the wall"
- PHYSICALITY: action is experienced through the body
  - Pick the ONE sensation that dominates the moment: if the character just landed hard, it's the jar in the knees, not a full sensory inventory
  - Fatigue: muscles screaming, lungs burning, hands shaking
  - Pain: specific, located, affecting function ("his right arm was useless below the elbow")
- ENVIRONMENT AS CHARACTER: the setting fights back
  - Heat, cold, altitude, water, darkness. each environment has its own dangers
  - The terrain is tactical: high ground, cover, chokepoints, escape routes
  - Weather as opponent: storm, fog, rain, darkness

DIALOGUE CRAFT
- Brief, functional, CHARACTER-REVEALING under pressure
- Banter under fire: shows character and relieves tension
- Radio/comms dialogue: clipped, professional, urgent
- The villain's dialogue: confident, intelligent, occasionally philosophical
- Pre-mission briefings: convey information economically
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. ACTION ADVENTURE

OPENING: Action + stakes from page 1. The protagonist in motion, in danger, or
deciding under pressure. No slow setup, no backstory before the body moves.

SENTENCES: Short kinetic sentences in action: 8-15 words. Fragments for impact:
"The wall. The drop. Three seconds." Medium (16-22) during planning and discovery.
Vary within paragraphs: short-short-short-medium creates acceleration then breath.

VOCABULARY: Clean, precise, physical. verbs carry the weight (ran, dropped, swung).
No purple prose. Technical accuracy where relevant. One-syllable words at action
peaks; multi-syllable for tactical thinking. Spatial language essential: distances,
directions, positions always clear.

TENSION FLOOR: ≥7. Immediate physical danger or time pressure from the opening
line. Stakes visible on page 1: life, mission, someone they protect. The clock is
always running. No safety. failure must feel possible and imminent.

RHYTHM: Open mid-action or the instant before it ignites. Establish spatial clarity
in 2-3 sentences, then accelerate. Alternate action bursts (3-5 short) with
consequence/assessment (1-2 medium). Show protagonist's competence AND vulnerability
in the same sequence. End on forward thrust: new threat, cliffhanger, ticking clock.
Dialogue clipped, functional, character-revealing under pressure.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

ACTION CRAFT (40% of total):
- Action scenes are clear, kinetic, and spatially coherent? (0-100)
- Physical consequences are real (injuries, exhaustion, limitations)? (0-100)
- The environment is an active participant in action scenes? (0-100)
- Momentum is maintained throughout (no dead spots)? (0-100)

STORY CRAFT (30% of total):
- Stakes are clear, escalating, and genuinely felt? (0-100)
- The protagonist is competent AND vulnerable? (0-100)
- The plan/mission drives the plot with effective complications? (0-100)
- Supporting characters contribute meaningfully? (0-100)

PROSE QUALITY (30% of total):
- Prose is lean, precise, and kinetic? (0-100)
- Spatial clarity is maintained during action? (0-100)
- Physical experience is visceral (the reader feels the action)? (0-100)
- Dialogue is sharp and economical? (0-100)

AUTOMATIC FAILS (score = 0):
- Invincible protagonist (never hurt, never tired)
- Action without spatial clarity (the reader can't follow what's happening)
- Momentum-killing exposition or reflection mid-action
- Generic settings with no sensory specificity
- The villain explains the plan instead of executing it
- Action scenes with no clear goal or stakes
```

## Continuity Rules

```
ACTION ADVENTURE CONTINUITY. WHAT TO TRACK

PHYSICAL STATE:
- Injuries: location, severity, and impact on function. injuries ACCUMULATE
- Fatigue: how long since rest, food, water
- Equipment: what they have, what's been lost, damaged, or used up
- Ammunition/resources: track consumption precisely
- Physical condition: cuts, bruises, broken bones don't heal between chapters

TACTICAL STATE:
- The current plan: what's the objective, what's the route, what's the timeline
- Known obstacles: guards, terrain, weather, opposition
- Intelligence: what the protagonist knows about the enemy/environment
- Comms: who's in contact with whom, what technology they have
- Backup plans: what happens when Plan A fails

GEOGRAPHICAL STATE:
- Current location: precise positioning
- Distance to objectives: how far, how long, by what route
- Terrain: what the environment looks like and how it affects movement
- Time zones and daylight: when the sun sets matters for operations

OPPOSITION STATE:
- The antagonist's resources, position, and knowledge
- How many enemies, their capabilities, their equipment
- What the opposition knows about the protagonist
- Their strategy: reactive or proactive?

MISSION STATE:
- Objective: what they're trying to do and why
- Progress: what's been accomplished, what remains
- Timeline: any deadlines or ticking clocks
- Complications: what's gone wrong and how it affects the plan
```

## Character Rules

```
ACTION ADVENTURE CHARACTER TYPES

THE PROTAGONIST:
- COMPETENT: exceptionally good at a specific skill set (combat, survival, tactics, engineering)
- VULNERABLE: competence doesn't mean invincible; they have limits and they get hurt
- A CODE: they have principles, even in chaos (what they won't do is as important as what they will)
- RESOURCEFUL: when the plan fails, they improvise with what's available
- PHYSICAL: described through action and capability, not introspection
- A PAST: their skill came from somewhere; their experience shaped them

THE PARTNER/TEAM:
- Complementary skills: the team covers the protagonist's blind spots
- Trust is earned: through shared danger and demonstrated competence
- Tension within the team creates drama BETWEEN action scenes
- Each team member has a specialty that becomes critical at some point

THE VILLAIN:
- COMPETENT: the villain must be as capable as the protagonist (or more)
- MOTIVATED: they want something specific and their plan to get it is intelligent
- RESOURCEFUL: they have advantages the protagonist doesn't (money, manpower, information)
- DANGEROUS: the reader should believe they could win
- A FOIL: they mirror the protagonist in some way

VOICE DIFFERENTIATION:
- The protagonist: direct, precise, economy of language under pressure
- The partner: contrasting style (the analyst vs. the soldier, the cautious vs. the reckless)
- The villain: articulate, controlled, occasionally charming
- Under fire: everyone's dialogue becomes shorter, more urgent, more fragmented
```

## Arc Rules

```
ACTION ADVENTURE STORY STRUCTURE

ACT 1: THE MISSION (first 25%)
- Open with action: the protagonist in their element, demonstrating competence
- Establish the mission/quest: what's the objective, what's at stake, what's the timeline
- Assemble the team (if applicable): who they are and what they bring
- The first complication: the mission won't be as simple as briefed
- END OF ACT 1: The protagonist is committed and in motion

ACT 2A: ESCALATION (to midpoint)
- The mission progresses with increasing difficulty
- Each obstacle requires different skills: combat, stealth, intelligence, endurance
- The environment becomes more hostile: deeper into the jungle, higher on the mountain, closer to the enemy
- The opposition becomes aware and responsive
- MIDPOINT: A major setback. betrayal, ambush, discovery, environmental catastrophe. that changes the entire approach

ACT 2B: SURVIVAL (midpoint to dark moment)
- Resources depleted: ammunition, food, allies, escape routes
- The protagonist is pushed to their physical limits
- The true scope of the opposition is revealed
- Personal stakes escalate: it's not just the mission, it's survival
- DARK MOMENT: Captured, cornered, injured, and out of options

ACT 3: THE FINAL PUSH (final 25%)
- The protagonist improvises with whatever they have left
- The climactic action sequence: the biggest, most dangerous, most consequential
- The environment plays a role in the resolution
- The villain is confronted directly
- The resolution is physical AND personal
- Aftermath: the cost counted, the mission assessed, the survivor standing

ACTION ADVENTURE PACING:
- EVERY chapter ends with a hook (cliffhanger, new threat, time pressure)
- Action → brief recovery → action (the recovery scenes get shorter as the story progresses)
- The climax is SUSTAINED: not one scene but a sequence of connected action
- The final chapter provides the brief exhale the reader needs
```

## Timeline Rules

```
ACTION ADVENTURE TIMELINE

COMPRESSED TIMELINE:
- Most action adventures span hours to days (not weeks or months)
- The shorter the timeline, the more intense the experience
- Ticking clocks are essential: "We have 48 hours before..."
- Track time precisely: when missions go wrong, minutes matter

OPERATIONAL TIMELINE:
- Mission phases: infiltration, execution, exfiltration (or equivalent)
- Travel time between locations: realistic for the mode of transport
- Day/night cycle: darkness is tactical (advantage or disadvantage)
- Communication windows: when contact is possible

PHYSICAL TIMELINE:
- Fatigue accumulates: track hours since rest
- Injuries degrade over time (not just when they happen)
- Dehydration and hunger affect performance
- Adrenaline: peaks and crashes
```

## Genre-Specific Craft Techniques

Adventure is the action-driven plot register, sitting adjacent
to thriller (which centres a specific threat) and quest-
fantasy (which centres a goal in a magical world) but with a
distinct contract: the protagonist's journey through varied
locations, encounters, and physical challenges is the form's
spine, with action sequences rendered for tactical clarity
and consequence rather than for adrenaline alone. The cluster
includes treasure-hunt adventure, survival adventure, military
adventure, exploration / expedition adventure, archaeological
adventure (Indiana Jones lineage), heist adventure, espionage-
adjacent adventure (where the action register dominates over
the thriller's tension register), and the broader plot-driven-
travel range. Comp authors span the canonical lineage (Robert
Louis Stevenson's *Treasure Island* and *Kidnapped*, Rider
Haggard, John Buchan's *The Thirty-Nine Steps*, Hammond Innes,
Alistair MacLean, Wilbur Smith, Bernard Cornwell, Patrick
O'Brian, Clive Cussler) through contemporary expansion
(Lee Child, Jack Reacher's procedural-adventure register,
James Rollins, Steve Berry, Brad Thor, Vince Flynn, Daniel
Silva at the spy-thriller-cross edge, Mark Greaney, Andy
McNab, Chris Ryan, Iris Johansen on the chase-adventure
register, Brad Taylor, Jack Carr at the contemporary military-
adventure end, Tom Clancy's procedural-adventure inheritance,
Frederick Forsyth, Robert Ludlum, Daniel Suarez at the techno-
adventure cross, Hugh Howey at the survival-cross, Andy
Weir's *The Martian* on the science-adventure end). The
techniques below are how the form delivers its core pleasures
while avoiding the failure modes (action without spatial
clarity; consequence-free violence; competence-porn that
voids stakes; chase-and-set-piece that doesn't accumulate
into structural meaning).

### The Action Clarity Framework

Every action sequence needs spatial setup. Adventure's
distinctive craft requirement: the reader must be able to
visualise where the protagonist is, what's around them, and
what the geometry of the action permits. Action that the
reader cannot diagram has failed; action that the reader can
follow as a sequence of spatial moves with consequences is
the form's signature.

```
BEFORE THE ACTION:
"The compound was a rectangle, fifty meters by thirty.
Guard tower on the northeast corner. Two-man patrol on
the south wall, ten-minute cycle. The generator was
behind the main building. If he could reach it, the
lights go dark."

DURING THE ACTION:
Position → Action → Consequence
"He was three meters from the wall (position) when the
searchlight swung his way (action). He dropped flat,
face in the dirt, and felt the beam pass over him like
something physical (consequence)."
```

The technique requires deliberate spatial scaffolding before
the action begins. The reader needs to know the terrain, the
players' positions, the relevant landmarks, and the constraints
the geometry imposes. During the action, every beat operates
in the position-action-consequence triangle: where the
character was, what they did, what followed from doing it.
Generic "the fight was chaotic" or "everything happened so
fast" is the failure mode; the writer who gestures at action
without staging it has skipped the form's central work.

The technique also requires that distances and times be
plausible. The protagonist who covers fifty metres in three
seconds while carrying a wounded comrade has done the
impossible; the protagonist who covers fifty metres in
fifteen seconds with the wounded comrade dropped twice along
the way has done the survivable. Test: pick three significant
action scenes in the manuscript and ask whether you could
draw a diagram of the action from the prose. If you cannot,
spatial clarity has not been deployed.

### The Injury Ledger

Injuries accumulate and matter. The form's distinctive
realism craft: physical damage sustained in chapter three
must continue affecting the protagonist in chapter twenty,
not vanish at chapter break. The genre's failure mode is the
adrenaline-amnesia register where injuries serve narrative
intensity in their moment but disappear before the next set-
piece; the technique is the running ledger where bullet
wounds limit mobility, exhaustion accumulates across days,
infections develop on schedules, and the protagonist's
specific body history shapes what they can and cannot do at
each subsequent point.

```
Chapter 3: "The bullet grazed his left shoulder. It
stung. He could still use the arm."

Chapter 7: "The shoulder was stiff now, seeping
through the field dressing. He compensated with
his right, but his accuracy was off by inches."

Chapter 11: "He couldn't lift the left arm above
his chest. The fever was starting. He had maybe
six hours before infection made the decisions for him."
```

The technique extends beyond gunshot wounds to all
accumulated physical state: the dehydration progressing across
days; the sleep deprivation compounding; the calorie deficit
building; the cold injury creeping; the broken finger that
won't bend correctly anymore; the persistent cough from the
smoke inhalation. The strongest adventure prose tracks
multiple physical states simultaneously, with the protagonist's
operational capacity at each moment a function of the
accumulated state rather than starting fresh each scene.

The technique also requires that the protagonist's body
register the cost on the page. Generic "he was tired" is the
failure mode; the specific quality of the exhaustion (the
hands no longer responding cleanly to the fine-motor task;
the vision narrowing at the edges; the way decisions are now
slow because the brain is rationing) is the technique. Test:
build an injury ledger for the manuscript's protagonist —
every injury, every resource depletion, every accumulating
physical condition, with the chapter where each appears.
Verify each persists in subsequent chapters in ways the
prose registers; if any vanishes without resolution, the
ledger has slipped.

### The Improvisation Moment

The best action scenes feature creative problem-solving.
Adventure's character-craft signature: the protagonist's
intelligence and resourcefulness IS the form's primary
demonstration of competence, more so than raw physical
capability. The character who shoots their way out has
demonstrated marksmanship; the character who improvises a
distraction from a fire extinguisher and a metal chair has
demonstrated the form's signature register.

```
NOT ADVENTURE:
"He pulled out his gun and shot the lock."

ADVENTURE:
"The lock was industrial. No picking it, no shooting
it. He looked at the room: a fire extinguisher, a
metal chair, and twenty feet of electrical cable.
He thought about it for exactly three seconds.
'I have an extremely bad idea,' he said."
```

The technique requires that the available resources be on the
page before the protagonist invents the solution. The reader
should be able to look back and identify the elements the
protagonist combined; nothing should arrive from off-page.
Generic "he found a way" is the failure mode; specific
inventory plus specific combination is the technique.

The technique also requires that improvisations have their
own consequences. The fire-extinguisher-and-electrical-cable
solution probably doesn't work as cleanly as planned; the
backup plan has costs; the success leaves the protagonist
out of fire extinguishers for the next encounter. The form's
strongest adventure prose threads improvisation costs across
the manuscript, with each clever solution depleting something
the protagonist will later need.

Test: pick three improvisation moments in the manuscript and
verify, in each, that the available materials were established
on the page before the solution emerged AND that the
solution's costs / consequences carried forward. If solutions
arrive with no setup or have no consequences, the
improvisation register is operating decoratively.

### The Pacing Rhythm

Adventure has a specific pacing requirement different from
both thriller (which sustains tension across the book through
threat) and quest-fantasy (which paces through magical
revelation). The adventure's pacing is action-rest-action-
rest, with the rest moments doing specific work — character
development, planning, recovery, accumulation of stakes,
deepening of relationships — rather than functioning as
filler between set-pieces.

The discipline:

- **Set-pieces** — the form's signature action sequences,
  spaced across the manuscript with deliberate intervals.
  Typical adventure novel: 4-6 major set-pieces in a
  300-page book, with 1-2 minor encounters between each.
- **Recovery beats** — the chapter or scene after a set-
  piece where the protagonist tends injuries, processes
  what occurred, and the reader breathes. These are not
  filler; they are where character work concentrates and
  where stakes recalibrate for the next set-piece.
- **Planning interludes** — chapters where the protagonist
  reviews intelligence, plots routes, considers options,
  prepares equipment. The form's reader rewards this
  register; rushing past planning to reach the next set-
  piece short-changes the form's signature competence-on-
  display pleasure.
- **Travel sequences** — for adventure that includes
  literal journey, the travel itself is content, not
  transition. The terrain, the conditions, the small
  encounters along the way, the deepening of relationships
  during shared travel — all carry the form's weight.

The technique fails when pacing collapses to set-piece-after-
set-piece without recovery (the reader exhausts; tension
loses its purchase) OR when recovery / planning beats run
too long without forward movement (the form's reader
disengages waiting for the next action). Test: chart the
manuscript's set-pieces and the intervals between them.
Does the rhythm calibrate to genre expectation, with rest
beats doing visible work?

### The Stakes Escalation Architecture

Adventure's structural requirement: stakes must escalate
across the manuscript. The protagonist who started chasing a
lost map is, by the climax, stopping a global catastrophe;
the protagonist who started a personal mission has, by the
final chapters, become responsible for outcomes far beyond
the personal. The form's signature thrust is the widening
gyre — what began as a small problem reveals itself as part
of a larger problem reveals itself as part of the largest
problem.

The architecture requires:

- **Local-to-global progression** — early stakes are
  personal / local; mid-book stakes are regional /
  organisational; climax stakes are existential / global.
  The progression must be earned by what the protagonist
  discovers, not asserted by sudden expansion.
- **Each escalation tier specifically motivated** — the
  protagonist learns a fact that recontextualises what
  they've been doing; the antagonist's plan is revealed at
  a larger scale than first appeared; the protagonist's
  personal stakes turn out to be tied to broader stakes.
- **The protagonist's competence escalates alongside** — the
  same protagonist who could handle the local problem can
  now handle the global problem, but only after the
  intermediate stages forced the necessary growth. Sudden
  competence-jumps to match sudden stakes-jumps are the
  failure mode.
- **The opposition escalates** — the antagonist, the
  threat, the difficulty must scale with the stakes. The
  small-time crook of chapter four cannot be the global-
  scale antagonist of chapter twenty-five without an
  intermediate ladder showing how the protagonist's reach
  expanded.

The architecture's failure modes: stakes-stagnation (the
local problem stays local through the book; the climax is
just a bigger version of the inciting incident) and stakes-
explosion (the personal problem suddenly becomes global at
the climax without intermediate development). Both lose the
form's signature widening-gyre pleasure. Test: chart the
stakes at three points in the manuscript (early / middle /
climax) and verify the escalation feels earned at each
transition.

### The Setting as Character

Adventure's signature relationship to place: the locations
the protagonist moves through are not background but are
participants in the action. The Amazon basin shapes what's
possible; the Sahara shapes what's possible differently; the
Arctic shapes what's possible differently again. The form's
strongest practitioners (Cussler on oceans; O'Brian on the
sailing world; Cornwell on specific historical battlefields;
James Rollins on caves and subterranean structures) make the
setting itself the source of plot pressure rather than mere
backdrop for action.

The technique requires:

- **Specific terrain** — not "the desert" but the specific
  Sonoran-versus-Saharan-versus-Atacama desert with their
  specific challenges. The reader should leave the book
  having learned something about the actual place.
- **Setting-specific challenges** — what kills you in this
  place is not what kills you in another. Heatstroke in the
  desert; hypothermia in the Arctic; altitude sickness in
  the mountains; piranha and bot-fly in the Amazon. The
  manuscript should know the specific ways the place can
  end the protagonist.
- **Setting-specific solutions** — what saves you in this
  place uses what the place provides. The protagonist who
  survives the desert because they understand the desert
  has demonstrated the form's signature competence; the
  protagonist who survives because of generic skills they
  could have used anywhere has not been tested by the
  setting.
- **Setting changes across the book** — multi-location
  adventure (the form's commercial mainstream) requires
  that each location be specifically rendered with its own
  challenges and possibilities. Generic "exotic location"
  treatment is the failure mode.

Test: pick three locations in the manuscript and ask, in
each, what the protagonist would face here that they would
not face elsewhere. If the setting could be swapped for
another exotic location without altering the action, the
setting-as-character treatment has not been deployed.

### Adventure AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the adventure of a lifetime" | Show the specific inciting event |
| "danger lurked around every corner" | Show the specific danger |
| "the journey tested their limits" | Show the specific physical or mental test |
| "a treasure beyond imagination" | Show the specific treasure and specific motivation |
| "the map revealed" | Show the specific map detail and what it means |
| "uncharted territory" | Show the specific unknown encountered |
| "the team worked together" | Show the specific collaboration on a specific problem |
| "survival instincts kicked in" | Show the specific survival action |
| "the landscape was breathtaking" | Show ONE specific landscape feature |
| "a discovery that changed everything" | Show the specific discovery |
| "his training kicked in" | Show the specific trained behaviour — the door cleared, the weapon checked, the sightlines mapped |
| "the chase was on" | Show the specific pursuit through specific terrain with specific stakes |
| "they made it just in time" | Show how close the timing was through specific concrete detail (the door closing as he passed; the explosion shaking dust down on him) |
| "the explosion rocked the building" | Show the specific consequences (the ringing ears; the walls cracked specifically there; what the protagonist now cannot do) |
| "he was running on adrenaline" | Show the specific physical signs (the hyper-clarity, the inability to feel the wound until later, the shaking that comes after) |
| "the weight of the mission" | Show the specific operational difficulty in this specific moment |
| "victory was within reach" | Cut; show what specifically remains between protagonist and goal |
| "the world hung in the balance" | Show the specific stakes for specific people |

## Genre-Specific Revision Rules

Six revision passes specific to adventure, each with a single
question, run cover-to-cover before the next begins. Adventure
revision must hold the form's signature contracts: momentum
(forward drive maintained); spatial clarity (action that the
reader can diagram); physical consequence (injuries, fatigue,
resources tracked); stakes escalation (the widening gyre);
competence + vulnerability balance (skilled but not
invincible); and setting-as-character (locations doing
plot work). The passes below are ordered to surface
momentum and clarity failures first (the most-felt by
adventure readers), physical consequence and stakes next,
and competence-balance + setting audits last.

### Pass 1: Momentum Check

Read the manuscript with sole attention to forward drive.
Does each chapter have momentum from first line to last?
Adventure's reader expects continuous propulsion; chapters
that stall lose readers. Verify each chapter ends with a
hook — a cliffhanger, a new question, a new threat, an
unexpected complication, a discovery that recontextualises
what came before. Generic chapter endings (the protagonist
goes to sleep; the day ends quietly; the conversation
trails off) are the failure mode for adventure even when
they would succeed in adjacent forms.

Audit for dead spots. Where in the manuscript does momentum
stall? Common dead-spot locations: the chapter after a
major set-piece (recovery beats can become inert if not
designed); the planning interlude (which can balloon
beyond what the reader will tolerate); the travel sequence
that runs too long without small encounters; the
protagonist's interior reflection (which can drift into
adjacent-form register).

Test: read the manuscript and identify any chapter where
you, as a reader, would consider putting the book down. At
those points, momentum has slipped. The fix is not always
adding action — sometimes it's tightening the existing
non-action material so the reader stays engaged through the
quieter beats. The strongest adventure prose makes recovery
and planning chapters propulsive in their own register.

### Pass 2: Spatial Clarity Check

Read every action sequence with diagrammatic specificity.
Can the reader visualise where characters are during the
action? Build the spatial map for three significant action
sequences: where the protagonist starts; what's around
them; where the antagonists are; what the relevant
landmarks, distances, and obstacles are. If the prose
doesn't establish this geometry before the action begins,
the action will be hard for the reader to follow.

Verify positions, distances, and directions are clear
during the action. The position-action-consequence triangle
operates per beat: the reader should know, in each beat,
where the character was, what they did, and what followed.
Generic "the fight was chaotic" or "everything happened so
fast" is the failure mode; the specific beat-by-beat
spatial rendering with consequences is the technique.

Test: pick three significant action scenes and try to draw
a basic map of the action from the prose alone. If you
cannot reconstruct positions and movements from the writer's
text, spatial clarity has not been deployed. The fix is
typically backward: adding setup before the action so the
geometry is established when the reader needs it, and
revising the action itself to keep position-action-
consequence visible at each beat.

### Pass 3: Physical Consequence Check

Build the manuscript's injury / resource ledger. Every
injury sustained, every resource depleted, every
accumulated physical condition — bullet wounds, exhaustion,
dehydration, hunger, sleep deprivation, cold injury,
psychological strain — with the chapter where each first
appears. Read the manuscript against the ledger.

Verify injuries from previous chapters are still affecting
the protagonist. The shoulder shot in chapter three should
still limit mobility in chapter twelve, with infection
either developing on schedule or the protagonist taking
specific actions (antibiotic supplies; a particular
medical resource accessed) that the manuscript registers.
Generic "his shoulder hurt" is decorative; specific
mobility-limit operating across the chapters is the
technique.

Verify resources are being tracked: ammunition, food,
water, fuel, equipment, time. The protagonist who has 17
rounds in chapter four cannot have 23 rounds in chapter
five without explicit acquisition. Generic "he checked his
ammo" is the failure mode; specific count tracked across
chapters is the technique. The strongest adventure prose
makes the depleting resource into its own tension engine —
the reader knows the protagonist has three rounds left and
feels each shot's weight.

Verify fatigue is accumulating realistically. The
protagonist who has been awake 36 hours, walked 40 miles,
been in a fight, taken minor injuries, and missed two
meals cannot operate at full effectiveness; the prose
should register the cost in specific behavioural and
cognitive terms (slowed decision-making, fine-motor
mistakes, narrowed perception, increased irritability). If
fatigue is mentioned but doesn't change behaviour, the
ledger has not been deployed.

### Pass 4: Stakes Escalation Check

Map the stakes across the manuscript. What is at risk in
each chapter? Build a stakes ledger: the immediate stakes
(what the protagonist could lose right now) and the
larger stakes (what the world / region / organisation /
specific named people stand to lose). Verify the local-to-
global progression operates: early-book stakes are personal
or local; mid-book stakes have widened; climactic stakes
are at their largest scale.

Verify stakes are higher in each act than in the prior. The
form's structural pressure depends on the widening gyre.
Stakes-stagnation (the climax is just a bigger version of
the inciting incident) is the failure mode; staked-
explosion (the local problem suddenly becomes global at
the climax without intermediate development) is the
opposite failure mode. Both lose the form's signature
escalation pleasure.

Verify the reader believes the protagonist could fail. The
adventure reader's investment depends on genuine uncertainty
about outcomes. Generic-action-hero protagonists who never
seem genuinely at risk lose the form's tension; the
strongest adventure prose maintains specific reasons the
protagonist could lose at each point — capability gaps,
opposition strength, accumulated injury, inadequate
resources, time pressure. Test: at three significant beats,
can the writer name the specific way the protagonist could
fail? If the failure modes are vague, the stakes are
operating at narrative-only level.

### Pass 5: Competence + Vulnerability Balance Check

Verify the protagonist demonstrates skill — specific,
on-the-page competence that the reader registers. The
form's pleasure includes watching expertise in action:
the specific tactical decision, the specific tradecraft,
the specific knowledge applied to the specific problem.
Generic "he was good at his job" is the failure mode;
specific demonstrated competence is the technique.

Verify the protagonist also faces genuine difficulty or
danger. Competence without vulnerability is competence-porn
and voids stakes. The protagonist who handles every
challenge effortlessly has not been challenged; the
protagonist who encounters specific situations beyond
their established capability — and either fails, improvises,
or barely succeeds — is the form's signature register.

Verify the balance is right — not invincible, not
incompetent. Adventure permits a wider competence range
than literary fiction (the form's heroes are typically
above-average in the relevant skills) but the competence
must come with specific limits. The protagonist who is
expert at their primary domain but shaky at adjacent
domains, who has specific weaknesses and blind spots, who
faces situations that genuinely test the limits of their
ability, is the form's actual hero. Test: identify three
moments where the protagonist's competence is tested. Does
the test push their actual capability, or does it confirm
what they could already do? Tests that confirm without
pushing are competence-porn; tests that push toward the
edges of capability — where the outcome is uncertain even
to the protagonist — are the form's signature.

### Pass 6: Setting-as-Character Audit

Run a final pass on the manuscript's setting work. Does
each location operate as a participant in the action
rather than as backdrop? The Setting-as-Character technique
requires that the place specifically shape what's possible:
specific terrain creating specific challenges; specific
climate / weather / season constraining options; specific
local material culture providing specific resources; specific
human / political / cultural context that the protagonist
must navigate.

Audit each significant location in the manuscript:

- What does this place threaten the protagonist with that
  another place would not? (Heatstroke in the desert,
  hypothermia in the Arctic, altitude in the mountains,
  parasites in the Amazon, surveillance in the city.)
- What does this place offer that another place would
  not? (Specific resources, specific allies, specific
  knowledge available here.)
- What does the protagonist have to know about this place
  to survive in it, and does the prose render that
  knowledge?
- What changes across this specific location during the
  manuscript? (Weather shifts, season changes, political
  situation evolves.)

Generic "exotic location" treatment that could be swapped
for any other exotic location is the failure mode; specific
place-rooted material that could not be moved without
losing meaning is the technique. The strongest adventure
prose makes the reader feel they have visited the actual
location and learned something specific about it.

Test: pick three locations in the manuscript and write one
paragraph for each describing what the protagonist faces
there that they would not face elsewhere. If paragraphs are
generic, setting work has not been deployed; if paragraphs
identify specific challenges only this place offers, the
technique is operating.

## Names & Patterns to Avoid

### Action Adventure Character Names. NEVER USE
- Generic action hero names: Jack Stone, Max Steel, Blade
- Pun names or names that describe the character: Hunter Chase, Gunner, Archer (unless the story is pulpy enough to earn it)

### Action Adventure. NEVER DO
- Start with a dream sequence or peaceful scene that goes on for pages before the action
- Give the protagonist unlimited resources or perfect information
- Have action scenes where the protagonist is never in genuine danger
- Stop the action for extended flashback or reflection

### Use Instead
- Names that feel real and grounded
- Military/professional naming conventions if appropriate (callsigns, surnames in professional context)

## Comp Titles

Adventure's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Treasure Island* — Robert Louis Stevenson (1883): the modern adventure-novel archetype.
- *King Solomon's Mines* — H. Rider Haggard (1885): exploration-adventure foundation.
- *Heart of Darkness* — Joseph Conrad (1899): literary-adventure with imperial-critique.
- *The Lost World* — Arthur Conan Doyle (1912): scientific-adventure template.
- *Indiana Jones / Raiders of the Lost Ark* (1981, film): mass-market adventure benchmark.

### Contemporary (current best-in-class)

- *The River* — Peter Heller (2019): contemporary literary survival-adventure.
- *State of Wonder* — Ann Patchett (2011): literary expedition-adventure.
- *In the Heart of the Sea* — Nathaniel Philbrick (2000, NF-adventure-adjacent): the Essex-whale narrative; modern adventure benchmark.
- *The Lost City of Z* — David Grann (2009, NF): contemporary exploration-adventure benchmark.
- *Where the Crawdads Sing* — Delia Owens (2018): literary survival-adventure.
- *The Bear* — Andrew Krivak (2020): post-apocalyptic literary adventure.
- *The Reformatory* — Tananarive Due (2023): adventure-horror lineage.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Wide-angle, dramatic compositions: a figure against a vast landscape, explosive action frozen in motion, the scale of the adventure made visible
- **Graphic**. Bold, high-contrast design with a single striking action element: a weapon, a map, a silhouette in motion
- **Illustrative**. Dynamic illustration with energy and movement: the cover should feel like it's IN MOTION
- **Textural**. Rugged, tactile: the cover feels like the adventure (cracked earth, rough metal, aged paper)

### Genre Cover Aesthetics
- **Styles:** Dramatic landscapes (mountains, jungles, deserts, oceans), action silhouettes, maps and navigation imagery, military/tactical elements, exploration scenes, figures in motion against overwhelming environments
- **Colours:** Bold, high-contrast: deep blues and oranges (adventure classic), earth tones for survival stories, military greens and greys, treasure-hunt golds, ocean blues; nothing soft or muted. adventure colours are STRONG
- **Elements:** Landscapes that dwarf figures, weapons and equipment, maps and compasses, vehicles (boats, planes, jeeps), dramatic weather, architectural ruins, explosions and fire
- **Typography:** Bold, sans-serif, masculine: the title should feel like a mission briefing or a movie poster; large, readable, confident; sometimes distressed or textured to match the setting

### Market Positioning
Action adventure covers must signal "thrilling, physical, and epic in scope" through dramatic imagery and bold design. Position against Cussler, Rollins, Child, Preston & Child. The cover should promise SPECTACLE and PACE. At thumbnail size, a dramatic silhouette or landscape with bold typography creates immediate excitement. This is the one genre where the cover can be unsubtle. impact over elegance.

### Cover Design DON'Ts
- No quiet, contemplative imagery (this is ACTION)
- No muted, desaturated colour palettes
- No delicate typography that whispers
- No static compositions. the cover should feel like it's moving
- No generic stock photography
- No romance-focused imagery (even if there's a romantic subplot)
