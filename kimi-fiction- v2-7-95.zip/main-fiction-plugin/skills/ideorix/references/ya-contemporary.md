---
name: ya-contemporary-genre
description: Genre-specific instructions for YA contemporary fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# YA Contemporary. Genre Plugin

## Metadata
- id: ya-contemporary
- name: YA Contemporary
- icon: 🎓
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Save the Cat", "Story Circle", "Three-Act Structure", "Romancing the Beat"]

## Subgenre Options
Present during setup:
- **Realistic YA**. Grounded in the real world: school, family, identity, first love; the honest truth of being a teenager; John Green, Angie Thomas territory
- **YA Romance**. First love as the engine: the intensity, the discovery, the heartbreak; romantic relationships as a lens for self-discovery
- **Issue-Driven YA**. A specific issue at the centre: mental health, racism, sexuality, grief, addiction; the issue explored through character, not lecture
- **YA Comedy/Dramedy**. Humour and heart: the absurdity of teenage life rendered with wit; funny on the surface, emotionally honest underneath
- **Verse Novel**. Narrative poetry: the story told through poems; compression, white space, emotional intensity; Sarah Crossan, Elizabeth Acevedo territory
- **YA Thriller/Mystery**. Suspense with teen protagonists: the missing friend, the school secret, the online threat; danger filtered through adolescent perspective

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Brisk and engaging. teen readers, contemporary attention spans; each chapter should end with a hook that makes putting the book down feel wrong
- Must open with: The protagonist's voice. immediate, authentic, in the middle of something that matters to them; the reader should hear a PERSON, not a narrator

BEATS PER CHAPTER
1. Voice Beat. The protagonist's authentic teen voice is heard: their observations, humour, fears, the way they see their world
2. Coming-of-Age Beat. Identity formation, self-discovery, a moment where the protagonist learns something about who they are (or who they're not)
3. Relationship Beat. Friends, romance, family. the connections that define teenage life tested, deepened, or complicated
4. Stakes Beat. Something matters intensely: social standing, a grade, a relationship, a secret, an injustice. stakes are personal and felt
5. Emotional Truth Beat. An honest emotional moment that respects the reader's intelligence; feelings are heightened but never trivialised

YA CONTEMPORARY ARCHITECTURE
- VOICE is everything: the protagonist's voice must be authentic, distinctive, and compelling from the first line; if the voice isn't right, nothing else matters
- TEEN EXPERIENCE is the lens: everything is filtered through what it feels like to be this age. the intensity, the uncertainty, the firsts
- IDENTITY FORMATION drives the story: the protagonist is becoming who they are; the plot should test and reveal that becoming
- FIRST EXPERIENCES carry enormous weight: first love, first loss, first choice, first betrayal. these are not small; they are the most important things that have ever happened
- ADULTS EXIST but teens drive the story: parents, teachers, coaches are present and matter, but the protagonist must have agency and solve their own problems
- HOPE is essential: even dark YA needs hope; not happily ever after, but HOPEFULLY ever after. the sense that things can change, the future is open
- SOCIAL WORLD is character: school hierarchy, friend groups, social media, the cafeteria. these environments shape the story
- POV: First person present (maximum immediacy and teen urgency) or close third

THEME AS STICK OF ROCK
- Theme runs through the story like words in a stick of rock. present on every cross-section, visible in every chapter
- Keep it short: "true love cannot be denied," "daring to be different," "where there's life, there's hope"
- The protagonist should be tested on exactly the theme: if it's about courage, they must face fear; if it's about identity, they must choose who to be
- ONE theme, two at most; more dilutes the story

OBSTACLE LAYERING
- The engine of YA drama: MULTIPLE obstacles layered simultaneously
- Internal obstacles: self-doubt, fear, identity crisis, broken heart, coping mechanisms that hold them back
- External obstacles: family, friends, school dynamics, bullies, authority figures, the person they love
- Environmental obstacles: poverty, illness, racism, societal structures, systems stacked against them
- Things should get WORSE before they get better. in story arc AND emotional journey

FORBIDDEN IN YA CONTEMPORARY
- Adults solving the teen's problems (teens must have agency)
- Condescending tone (respect teen readers, don't talk down)
- Dated slang (contemporary but not trying too hard; avoid what dates quickly)
- Preachy messaging (explore issues, don't lecture)
- Parents absent without reason (adults exist; balance independence with reality)
- Explicit sexual content (fade to black; YA is not adult romance)
- Hopeless endings (YA needs hope, possibility, even if bittersweet)
- Teen stereotypes without depth (jock, nerd, popular girl are starting points, not destinations)
- Writing down to teens (they are the most honest, discerning audience)
- Shying away from difficult subjects (if it's something a teen goes through, it's legitimate to write about)
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (primary — voice is everything for YA), Captivation, Revelation at coming-of-age moments.

VOICE & TONE
- POV: First person present (most common. intimate teen voice with maximum immediacy) or close third limited
- Tense: Present (urgency) or past (traditional); present tense dominates contemporary YA
- Voice: Contemporary teen. authentic, emotionally honest, not trying too hard; the protagonist sounds like a real person, not a character
- Register: Accessible but not simplistic. intelligent teens deserve intelligent prose

PROSE IMPERATIVES
- TEEN VOICE AUTHENTICITY: the single most important craft element
  - Contemporary language, emotional truth, age-appropriate concerns
  - The protagonist reacts in THEIR way, not the author's way
  - Code-switching: how the character speaks differently with friends, parents, teachers, crushes
  - Sarcasm and humour as defence mechanism. the joke that masks the hurt
  - ✓ "I wasn't going to cry. Not here. Not in front of Chelsea and her perfect hair and her perfect life."
  - ✗ "I reflected upon my emotional state and decided crying would be inadvisable in this social context."
- EMOTIONAL INTENSITY: everything matters at this age
  - First love: consuming, world-ending if it fails, the only thing that matters
  - Friendship betrayal: devastating, trust broken, worst pain imaginable
  - Social humiliation: death; can't show face; life over
  - Parent disappointment: crushing, expectations heavy, identity conflict
  - Teen feelings NEVER minimised. they are experiencing these things for the FIRST TIME
- SHOW DON'T TELL. THE WORD-WALK TECHNIQUE:
  - Don't tell us a character is sad. show it: shoulders drooping, head bowed, how they move through the world
  - Take an emotion for a walk: if sadness was a musical instrument, what would it be? If anger was a car, what kind?
  - "I'm screechy violins today" gives instant emotional image
  - Use sparingly for maximum impact. fresh, surprising ways to convey emotion without stating it
- SENSORY IMMERSION: all five senses, not just sight
  - What do they hear, taste, smell, touch?
  - Put yourself through what your characters experience
  - Specificity makes writing come alive

DIALOGUE CRAFT
- THREE FUNCTIONS, ALWAYS: every piece of dialogue must reveal character, give information, or move the story forward (best dialogue does all three)
- SUBTEXT: it's not just what characters SAY but what they DON'T say. the loaded silence, the joke that masks hurt, the argument about something trivial that's really about something devastating
- CODE-SWITCHING: characters speak differently with different people. friends vs. parents vs. teachers vs. crushes
- SLANG CRAFT: "cool" endures; "groovy" is a period piece; if using contemporary slang, be sparing. enough to set context, not so much readers stumble
- RAPID RHYTHM: teens talk fast, interrupt, leave sentences unfinished, text mid-conversation. dialogue should feel alive and messy

BALANCE ACTION AND REFLECTION
- Stories that are crash-bang-wallop all the time are exhausting
- Too much introspection bores readers to sleep
- Find the balance: for key action moments, slow down and take the reader through it beat by beat
- Slowing down makes it more subjective, more emotional, more invested
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. YA CONTEMPORARY

OPENING: Authentic teen voice from sentence 1. The voice IS the hook. distinctive,
immediate, emotionally honest. Drop the reader mid-thought, mid-feeling. They should
know who this person is within five sentences.

SENTENCES: Short-medium, 10-18 words average. Short (4-10) for emotional punch and
comic timing. Fragments for authenticity: "Great. Just great." Medium for interiority.
Rhythm feels like a teen THINKING: quick, associative, emotionally charged.

VOCABULARY: Contemporary teen voice. natural, never trying too hard. Emotionally
precise. Code-switching visible from the start. Sarcasm and humour as defence
mechanisms. Cultural markers grounding in NOW (but avoid what dates in 18 months).

DIALOGUE DENSITY: 45%+. High dialogue from page 1. Real teens: interruptions,
incomplete sentences, deflections. Subtext from the start. Different voices
immediately. Interiority emotionally honest. gap between mask and truth from page 1.

TENSION FLOOR: ≥4. Emotional stakes from the opening: something at risk, something
hurts. Social and identity tension simultaneously. The reader feels the protagonist's
emotional weather immediately. No minimising teen feelings.

RHYTHM: Open mid-thought, distinctive, engaging. Establish social world quickly.
Dialogue within page 1. Layer internal commentary against external action. Close on
an emotional hook. a feeling or complication that demands more.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

YA CRAFT (40% of total):
- Teen voice authentic (sounds like a real person, not a character)? (0-100)
- Coming-of-age arc earned (protagonist changes through experience)? (0-100)
- Emotional intensity respected (teen feelings never trivialised)? (0-100)
- Agency present (the teen drives the story, not adults)? (0-100)

STORY CRAFT (30% of total):
- Theme consistent (present in every chapter like a stick of rock)? (0-100)
- Obstacles layered (internal + external + environmental)? (0-100)
- Relationships complex (friends, family, romance. nuanced)? (0-100)
- Hope present (even in dark moments, the future feels possible)? (0-100)

PROSE QUALITY (30% of total):
- Voice distinctive (would the reader recognise this character from voice alone)? (0-100)
- Dialogue authentic (code-switching, subtext, rapid rhythm)? (0-100)
- Show don't tell (emotion through behaviour, not statement)? (0-100)
- Sensory immersion (all five senses, not just sight)? (0-100)

AUTOMATIC FAILS (score = 0):
- Adults solving the teen's problems
- Condescending or preachy tone
- Teen stereotypes without depth (jock, nerd, popular girl as types not people)
- Explicit sexual content (YA requires fade to black)
- Hopeless ending with no sense of possibility
- Dated or forced slang that breaks authenticity
- The protagonist's voice sounds like an adult pretending to be a teen
- Writing that talks down to teen readers
```

## Continuity Rules

```
YA CONTEMPORARY CONTINUITY. WHAT TO TRACK

SOCIAL STATE:
- Friend group dynamics: who's in, who's out, who's drifting, who's fighting at each point
- Romantic relationships: status, public knowledge, who knows what
- Social hierarchy position: where the protagonist stands in the school ecosystem
- Social media: what's been posted, what's been seen, what's gone viral (if relevant)
- Reputation: what people think about the protagonist (and how accurate it is)

SCHOOL STATE:
- Academic standing: grades, assignments due, tests approaching
- Extracurriculars: commitments, competitions, rehearsals, practice schedules
- Teacher relationships: who's supportive, who's difficult, who's involved in the story
- School calendar: when events happen (prom, homecoming, exams, breaks)

FAMILY STATE:
- Parent relationship: trust level, conflict status, rules and restrictions
- Sibling dynamics: rivalry, support, shared secrets
- Family situation: divorce proceedings, financial stress, illness, secrets
- Home atmosphere: tense, supportive, chaotic, absent. and how it changes

EMOTIONAL STATE:
- The protagonist's internal weather: what they're feeling and why at each point
- Coping mechanisms: what they do when stressed (healthy and unhealthy)
- Self-knowledge: what they understand about themselves vs. what they don't yet
- Growth markers: moments of insight that accumulate toward the arc's resolution

IDENTITY STATE:
- Who the protagonist thinks they are at each point (shifting)
- Who they're trying to be (and whether it's authentic)
- What they want vs. what they need (the gap narrows across the story)
- The mask: what they show the world vs. who they actually are

TECHNOLOGY STATE:
- Phone/text conversations: who said what, when, who screenshot what
- Social media posts and their consequences
- Online vs. offline behaviour differences
- Digital evidence of events (photos, messages, posts)
```

## Character Rules

```
YA CONTEMPORARY CHARACTER TYPES

THE PROTAGONIST:
- 14-18 years old, in the process of becoming who they are
- Voice must be DISTINCTIVE: the reader should recognise them from a single paragraph
- Contradictory: shy AND brave, funny AND heartbroken, confident AND terrified. the contradictions are the character
- Their strengths are tested: whatever they're good at should be challenged by the plot
- Their weaknesses drive mistakes: whatever they struggle with should cause real consequences
- Agency: they make choices, face consequences, and grow. not passive, not perfect
- The ANTI-STEREOTYPE IMPERATIVE: no cookie-cutter jocks, nerds, or mean girls without depth; use the contradictory adjective technique. two positive traits, one negative, then dig deeper

THE BEST FRIEND:
- Not a sidekick. a fully realised person with their own life, problems, and desires
- The friendship should be tested: loyalty under pressure, secrets that strain, growth that pulls apart
- Their loss or betrayal is the story's emotional weapon
- They may see the protagonist more clearly than the protagonist sees themselves

THE LOVE INTEREST:
- Not a prize to be won. a person with their own arc and complexity
- The attraction should be specific: not just "attractive" but what specifically draws the protagonist
- Conflict comes from who they are, not manufactured misunderstandings
- First love intensity: the all-consuming, can't-think-about-anything-else quality

THE FAMILY:
- Parents exist and matter: they're not absent unless that absence IS the story
- Parent-teen dynamics are nuanced: wanting independence while still needing support
- Family conflict is felt deeply: disappointment, expectation, the weight of "because I said so"
- Siblings: rivalry AND loyalty, the person who knows you longest

THE ANTAGONIST:
- May be a person, a system, or an internal struggle. or all three
- If a person: not a cartoon bully but someone whose behaviour has a reason
- If a system: school rules, social hierarchy, family expectations, societal prejudice
- The antagonist should embody the protagonist's worst fear about themselves

VOICE DIFFERENTIATION:
- The protagonist: distinctive, immediate, emotionally honest, with specific speech patterns
- Best friend: a different rhythm, vocabulary, energy. the contrast makes both real
- Parents: the language of adult concern (protective, controlling, loving, clueless. sometimes all at once)
- Love interest: the way the protagonist's voice CHANGES around them (breathless, performative, honest)
- Authority figures: the language of institutional power (teachers, coaches, counsellors)
```

## Arc Rules

```
YA CONTEMPORARY STORY STRUCTURE

ACT 1: THE WORLD BEFORE (first 25%)
- The protagonist's ordinary life: who they are, who they pretend to be, what they want
- The social world established: friends, family, school. the ecosystem they navigate daily
- The inciting incident: something changes. a new person, a revelation, a loss, an opportunity
- The first choice: the protagonist decides to engage with the change (even if reluctantly)
- END OF ACT 1: The protagonist is committed to a path that will test everything they think they know about themselves

ACT 2A: THE ESCALATION (to midpoint)
- New relationships deepen: friendships tested, romance intensifies, family dynamics shift
- The stakes become personal: what started as an event becomes an identity question
- Obstacles layer: internal doubts, external pressures, environmental constraints pile up simultaneously
- The protagonist makes mistakes: they're a teenager. good intentions, poor execution
- MIDPOINT: A revelation that changes everything. a secret exposed, a betrayal discovered, a truth about themselves they can't ignore; the story pivots from "what's happening" to "who am I"

ACT 2B: THE CRISIS (midpoint to dark moment)
- Relationships fracture: the friendship that seemed unbreakable is breaking, the romance is complicated, family trust is tested
- The protagonist's mask cracks: who they've been pretending to be vs. who they actually are comes into painful focus
- Consequences compound: earlier mistakes return, the easy option disappears
- The theme is challenged directly: if the story is about courage, this is where courage fails; if it's about identity, this is where identity shatters
- DARK MOMENT: The protagonist faces their worst fear. isolation, exposure, loss. and has to decide who they really are

ACT 3: THE BECOMING (final 25%)
- The protagonist chooses authenticity: they stop pretending and face the truth about themselves
- The climactic confrontation: not always physical. often a conversation, a choice, a declaration
- Relationships are rebuilt, transformed, or honestly mourned
- The theme resolves: the stick of rock breaks and the words are visible
- HOPEFULLY EVER AFTER: the ending doesn't need to be perfect. it needs to be honest; the future is open, the protagonist is more themselves than they've ever been, and things can get better

YA CONTEMPORARY PACING:
- Fast chapters, each ending with a hook. teen readers need momentum
- Alternate between high-energy scenes and quieter emotional beats
- The pace accelerates through Act 2 as obstacles pile up
- The climax is emotional, not necessarily action-driven
- The resolution is brief but satisfying: a scene, not a chapter. trust the reader to fill in the rest
```

## Timeline Rules

```
YA CONTEMPORARY TIMELINE

SCHOOL CALENDAR:
- Track the academic year: term start, exam periods, holidays, breaks
- School events: prom, homecoming, sports seasons, performances, college application deadlines
- Daily rhythm: classes, lunch, after-school activities, evenings, weekends
- The school calendar creates natural deadlines and gathering points

RELATIONSHIP TIMELINE:
- Friendship dynamics: when alliances shifted, when secrets were shared, when betrayals happened
- Romance: when they met, first conversation, first date, first kiss, first fight. each milestone specific
- Family: when tensions escalated, when conversations happened, when truths were revealed
- Social media timeline: what was posted when, what was seen, what went viral

EMOTIONAL TIMELINE:
- The protagonist's emotional arc tracks against external events
- Peak intensity moments: first love, betrayal, the dark moment. their timing matters
- Recovery: emotions don't reset chapter to chapter; grief and hurt accumulate
- Growth: insight builds slowly, not in sudden epiphanies (except the climactic one)

SEASONAL/TEMPORAL:
- Time of year affects mood, activities, and pressure (exam stress, summer freedom, winter isolation)
- Duration: typically one school year, one semester, or one significant period
- Weekdays vs. weekends: different social possibilities, different parent oversight
```

## Genre-Specific Craft Techniques

YA contemporary is the present-day register of young adult
fiction, distinct from adult contemporary in voice, audience,
emotional intensity, and the form's specific contract with
its primary teen reader. The cluster includes contemporary
romance YA, friendship and identity novels, mental health
fiction, social-issue YA, and the broader young-protagonist
present-day range. Comp authors span the canonical
contemporary YA (Stephen Chbosky's *Perks of Being a
Wallflower*, John Green's *The Fault in Our Stars* and
*Looking for Alaska*, Sarah Dessen, Rainbow Rowell's
*Eleanor & Park* and *Fangirl*, Jandy Nelson's *I'll Give
You the Sun*, Jenny Han's *To All the Boys I've Loved
Before*) through the contemporary expansion (Angie Thomas's
*The Hate U Give* and *On the Come Up*, Elizabeth Acevedo's
*The Poet X* and *Clap When You Land*, Tomi Adeyemi, Nicola
Yoon, Becky Albertalli, Adam Silvera, Casey McQuiston's
*Red, White & Royal Blue*, Akwaeke Emezi's *Pet*, Mariko
Tamaki, Alice Oseman's *Heartstopper* / *Loveless*, Erin
Morgenstern, Holly Bourne, Patrice Caldwell, Renée Watson,
Ibi Zoboi, Zoraida Córdova, Aisha Saeed, Tahereh Mafi). The
techniques below are how the form delivers its core
pleasures while avoiding the failure modes (adult voice
ventriloquising teen protagonist; first experiences
flattened to plot beats; technology gestured at rather than
inhabited; "issue novel" treatment where character serves
theme; performative authenticity that adult writers think
teens recognise but teens spot immediately).

### The First-Time Lens

Everything experienced for the first time carries enormous
weight. YA's signature emotional register: the first kiss,
the first heartbreak, the first time saying I love you, the
first betrayal of trust, the first independent decision, the
first encounter with adult cruelty. Each must be rendered as
the world-altering event it actually is for the protagonist
— not as a plot beat the writer is checking off, but as the
event that transforms what the protagonist understands about
how the world works.

```
NOT YA:
"They kissed. It was nice."

YA:
"He leaned in and I forgot how breathing worked.
Just. forgot. Like my lungs got a software update
in the middle of running and now nothing was
compatible. His mouth was warm and tasted like
the mango smoothie we'd split and I thought: this
is it. This is the thing everyone writes songs
about. And I understood all the songs. Every single
one. All at once."

The first kiss isn't a plot point. It's a
world-altering event. Write it that way.
```

The technique requires that the prose match the protagonist's
actual interior intensity. Adult writers' instinct toward
restraint and irony is the failure mode for YA — teen
readers want emotional commitment, not adult arch detachment.
The strongest YA contemporary writers commit fully to the
protagonist's experience even when the adult writer would,
in their own register, find the teen's reaction excessive.
The reaction is excessive; that excess IS the form's truth.

Test: pick three first-experience moments in the manuscript
and ask, in each, whether the prose commits to the
protagonist's interior intensity or hedges with adult
distance. If the prose deflects to dry observation when
emotion would commit, the form's signature register has
been compromised.

### The Code-Switch Reveal

How the protagonist speaks differently reveals who they are.
YA's signature voice-craft: the teen protagonist speaks
multiple registers across their day — to friends, to
parents, to teachers / counsellors, to crushes / love
interests, to siblings, in-group online vs out-group online,
in their own interior. Each register is true; the differences
between them are the character.

```
With friends: "Dude, she literally just WALKED
past me. Like I wasn't even there. I'm dead.
I'm actually dead."

With Mom: "School was fine. Yeah. No, nothing
happened. Can I go to Priya's?"

With the counsellor: "I don't know. I guess
sometimes I feel like... I don't know.
Never mind."

With the love interest: "I don't actually
like horror movies. I just said that because
you said that. I've been lying to you for
three weeks. About movies. Sorry."

The same character. Four different voices.
Each one true.
```

The technique requires that each register be specific.
Generic teen-with-friends register, generic teen-with-parent
register, generic teen-with-crush register are the failure
mode; the specific register THIS protagonist deploys with
THESE specific people in THIS specific era is the technique.
Code-switching also operates intra-register: the teen who
speaks differently to their best friend than to their just-a-
friend; the teen who has different versions of themselves
for different friend groups; the teen whose Instagram register
differs from their group-chat register differs from their
private journal.

Test: pick three significant dialogue exchanges between the
protagonist and different characters. Without attribution,
can the reader identify which exchange the protagonist is
having with which character based on register alone? If
not, the code-switching has not been deployed.

### The Social Media Beat

Technology as emotional amplifier. Social media is not
setting in YA contemporary — it is emotional architecture
that the form must inhabit rather than describe. The
specific platform-mediated experience (the like-count
watching, the seen-not-replied check, the story-screenshot,
the deliberate non-following, the anxious refresh) is the
contemporary teen's emotional terrain, and YA contemporary
that fails to inhabit this terrain reads as set in 2005
with phones added.

```
"I watched the likes climb. 47. 62. 89. Each
one a tiny electric jolt of I exist, I matter,
someone sees me. At 112 I screenshot it.

Then I saw Jake had liked Mira's photo. The one
at the beach. The one in the bikini. I put my
phone face down on the bed and stared at the
ceiling and wished I lived in a world where
knowing everything about everyone all the time
didn't make me feel like I knew nothing about
anything."

Social media isn't setting. It's emotional
architecture. Track its effects.
```

The technique requires platform-specific specificity. Generic
"she scrolled" / "he checked his phone" is the failure mode;
specific platforms (Instagram vs TikTok vs BeReal vs Discord
vs the group chat) operating in specific ways with specific
emotional consequences is the technique. The technique also
requires the digital register to be genuine — the writer
must understand actual teen platform behaviour rather than
adult-imagined teen platform behaviour. Adult writers
imagining "the kids today" without research produce the
form's most-cringed-at falsity.

Test: at three significant social-media moments in the
manuscript, ask whether the rendering captures specific
contemporary platform behaviour or operates at adult-
imagined-generic-teen-online level. If the latter, the
technique needs research; if the former, the form's
distinctive digital register is operating.

### The Authentic Voice Discipline

YA contemporary's most-flagged failure is the adult voice
ventriloquising the teen protagonist. Adult writers
unconsciously deploy adult vocabulary, adult cultural
references, adult emotional frameworks, adult sentence
structures, adult retrospective wisdom. Teen readers detect
this immediately and lose investment for the rest of the
book. The technique is sustained voice-craft across hundreds
of pages.

The discipline operates on multiple axes:

- **Vocabulary** — every word the narrator uses must be a
  word a teen would actually use. Not "she felt a sense of
  dissonance" but "it felt weird"; not "he was experiencing
  cognitive overload" but "his brain was full"; not "the
  social hierarchy" but "everyone knew where they stood".
  Adult vocabulary deployed unconsciously is the most
  common failure mode.
- **Cultural reference** — references the protagonist would
  actually have. The contemporary teen's cultural reference
  set is specific to their age, region, and subculture; not
  what an adult writer thinks teens reference, but what
  this specific teen would actually know. The wrong
  reference at the wrong level breaks the spell.
- **Emotional vocabulary** — the protagonist's emotional
  framework. Contemporary teens have absorbed therapeutic
  vocabulary in ways earlier generations didn't, but the
  specific teen's specific exposure must be rendered. The
  teen who casually deploys "boundaries", "triggers",
  "trauma response" without context has been ventriloquised;
  the teen who absorbed these terms from a specific source
  (therapy, social media, a friend, a class) and uses them
  in specific ways has been characterised.
- **Sentence structure** — teen prose, particularly first-
  person, has a different rhythm than adult literary prose.
  Sentences fragment more; commas substitute for full stops;
  asides interrupt the through-line. Adult prose with
  occasional contractions is not teen voice.

Test: read three first-person passages in the manuscript and
ask, for each word, whether THIS specific teen at THIS
specific age in THIS specific context would actually use it.
If any passage requires the writer to explain that "she's a
literary teen" to justify the vocabulary, the voice has
been adult-ventriloquised; if every word feels available to
the actual character, the discipline is operating.

### The Mental Health Authenticity

Contemporary YA carries an evolved relationship to mental-
health representation that the form's strongest practitioners
handle with specific care. The protagonist with anxiety,
depression, OCD, eating disorder, ADHD, trauma response,
grief, suicidal ideation, self-harm history, addiction
history — each of these is now common in YA contemporary,
and each requires specific rendering that distinguishes
authentic mental health writing from issue-novel
representation.

The technique requires:

- **Specificity over diagnosis** — the protagonist's
  experience is rendered through specific behaviour,
  thought, and sensation, not through diagnostic label.
  "She had anxiety" is the failure mode; "she sat in the
  car for forty minutes before going into the party
  because the going-in had become a bigger thing than the
  party" is the technique.
- **Lived texture** — what the experience actually feels
  like from inside, including its inconsistencies and its
  specific cognitive patterns. Generic "she felt anxious"
  loses the particular shape of THIS protagonist's anxiety.
- **Treatment / management visible without preachiness** —
  if the protagonist is in therapy, on medication, using
  specific coping strategies, the prose can render these
  without becoming a treatment manual. The form's strongest
  examples (Jasmine Warga, John Green's *Turtles All the
  Way Down*, Adam Silvera, Holly Bourne) show treatment as
  part of life, not as plot or instruction.
- **Refusal of recovery narrative** — many YA mental-health
  novels have moved past the recovery-arc structure (where
  the protagonist begins ill and ends well). Contemporary
  practice often acknowledges that mental-health conditions
  are managed rather than cured, that recovery is non-
  linear, that the protagonist may end the book still in
  the territory the book has been navigating.
- **Resource awareness** — many YA contemporary novels
  conclude with a resource note (crisis hotlines, support
  organisations) where the topic warrants. The form's
  current standard treats this as ethical practice, not
  extra-textual decoration.

Test: pick three significant mental-health moments in the
manuscript and ask, in each, whether the rendering operates
at specific-lived-experience level or at diagnostic-label
level. If diagnostic, the technique needs revision; if
specifically rendered, the form's contract is operating.

### The Adult-as-Imperfect-Ally Discipline

YA contemporary's relationship to adult characters: adults
must be present, must be complex, must be imperfect, but
must not solve the protagonist's problems. The form's
structural truth is that the teen must navigate their own
difficulties with the adults available being some
combination of helpful, unhelpful, and absent. The strongest
contemporary YA writes adults as full characters whose own
interior lives the protagonist partially perceives (the
parent who is also tired and afraid; the teacher who is also
having their own difficult year; the counsellor who is
genuinely competent and limited at the same time).

The discipline avoids two failure modes:

- **Cardboard adults** — the parent who exists only to
  disapprove or only to approve; the teacher who is generic
  authority-figure; the counsellor who is generic helper.
  Each of these is character abandonment.
- **Adult-saviour structure** — the adult who arrives and
  solves the protagonist's problem. The form's plot pressure
  comes from teen autonomy; adults fixing things robs the
  protagonist of the genre's central work.

The discipline also operates on the teen's perception of
adults: the form's signature emotional moment is the teen's
realisation that the adult they thought knew everything is
also figuring it out, also afraid, also limited. This
realisation is part of the protagonist's coming-of-age
arc and should be rendered as the difficult gain it is —
neither the teen's smug recognition that adults are
incompetent nor the teen's collapse into adults-knew-better.

Test: at three significant interactions between the
protagonist and adult characters, ask whether the adult is
rendered as a full person with their own interior, or as
plot device. If the adult exists only to advance / block
the protagonist's plot, the discipline has not been
deployed.

### YA Contemporary AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "high school was a battlefield" | Show the specific social conflict |
| "she didn't fit the mould" | Show the specific mould and specific deviation |
| "the pressure to be perfect" | Show the specific perfectionist behaviour and its crack |
| "social media was destroying their generation" | Show the specific social media moment and its effect |
| "first love was overwhelming" | Show the specific overwhelm through behaviour |
| "finding their identity" | Show the specific identity moment |
| "the adults were clueless" | Show the specific adult failure |
| "mental health was a silent epidemic" | Show the specific symptom through action, not label |
| "they were all dealing with something" | Show ONE person's specific something |
| "the world expected too much" | Show the specific expectation |
| "authenticity was rare" | Show the specific authentic moment |
| "she wasn't like the other girls" | Cut; this phrase has aged into self-parody. Show what specifically distinguishes her |
| "the cool kids" / "the popular kids" | Generic high-school taxonomy; show the specific social configuration of THIS school |
| "her best friend was her ride or die" | Show the specific loyalty test or specific shared experience |
| "she had her squad" | Cut "squad" as generic; name the specific friends with their specific dynamics |
| "the weight of senior year" | Show the specific senior-year pressure (college applications / scholarships / specific deadlines) operating in this character |
| "she just wanted to be heard" | Show what specifically she has been trying to say and to whom |
| "the world was watching" | Show ONE specific perceived watcher and the specific anxiety it produces |

## Genre-Specific Revision Rules

Six revision passes specific to YA contemporary, each with a
single question, run cover-to-cover before the next begins.
YA revision must hold the form's signature contracts: voice
authenticity (the protagonist sounds like a real teen);
teen agency (the protagonist drives the story); emotional
honesty (teen feelings respected, not minimised or mocked);
social world authenticity (relationships and environments
specific and lived); hope discipline (even in dark moments,
the form's contract for survivability and possibility); and
the technology / mental-health / adult-as-imperfect-ally
specificities that distinguish contemporary YA from earlier
generations of the form. The passes below are ordered to
surface voice and agency failures first (the form's most-
felt by primary readers), emotional honesty and social
world next, and hope-and-period-specific audits last.

### Pass 1: Voice Authenticity Check

Read the protagonist's first-person passages aloud. Does the
voice sound like a real teen (not an adult pretending)? The
form's most-flagged failure is the adult voice
ventriloquising the teen. Check vocabulary specifically:
words the protagonist would actually use vs words the adult
writer reached for unconsciously. Check sentence rhythm —
teen prose tends toward fragments, asides, comma-driven
rhythm rather than measured literary sentences. Check
cultural reference — references the protagonist would
actually have at this age in this region in this era.

Verify the voice is distinctive — would a reader recognise
this character from voice alone? Build a voice profile:
what specific vocabulary, what specific verbal tics, what
specific patterns of observation and self-correction make
this protagonist's voice theirs and not generic-YA-voice.
Generic teen voice is the failure mode; specific
distinctive teen voice is the technique.

Verify code-switching is present — the protagonist speaks
differently with friends than with parents than with
counsellors than with crushes. Each register should be
recognisable as belonging to the same character but
operating in different mode. Verify slang is contemporary
but not forced. Slang is a particular trap: too much and
the writing reads as adult-imagined-teen-voice; too little
and the prose reads as generic-literary; the right level is
the slang the actual character would actually use, deployed
with the specific frequency they would deploy it.

Test: read three first-person passages without attribution.
Could this voice belong to any other YA contemporary
protagonist, or is it specifically THIS character? If
generic, voice has not been built.

### Pass 2: Teen Agency Check

Verify the teen is driving the story rather than adults
solving their problems. Audit each significant plot beat:
who initiated, who chose, who acted, who paid. The form's
plot pressure must come from teen choices and teen
consequences; adults intervening to fix things robs the
form of its central work.

Verify the protagonist makes active choices, even bad ones.
Coming-of-age YA permits — and is often deepened by — the
protagonist who makes specifically bad choices, then has to
live with what those choices produced. Passive
protagonists who things merely happen to are the failure
mode; protagonists whose choices (good and bad) drive
their arc are the technique.

Verify consequences are felt by the protagonist, not
shielded by adults. The form's contract: the protagonist
is responsible for what they have done. Adults can support
through aftermath; they cannot make the consequences go
away. Verify the protagonist's growth is visible — shown
through specific behaviour change, not asserted by
narrator. The protagonist who is "stronger now" without
the prose showing the specific new behaviour has been
served growth as plot beat.

Test: at three significant plot beats, ask who acted and
who paid. If adults consistently appear in either column
when teens should be there, the agency contract has been
broken.

### Pass 3: Emotional Honesty Check

Verify teen feelings are respected, not minimised or
mocked. The form's most-flagged adult-writer failure is the
condescending register that treats teen emotional intensity
as overreaction or melodrama. Teen first-time emotion IS
intense — that's not melodrama; that's the form's truth.
The strongest YA contemporary commits fully to the
intensity rather than ironising it.

Verify emotion is shown through behaviour, not stated. The
protagonist whose interior says "she felt overwhelmed"
without the specific behavioural rendering is being told to
the reader; the protagonist whose hands shake on the door
handle, whose voice does the thing it does when it's about
to break, whose specific physical state registers the
overwhelm has been shown.

Verify emotional intensity is appropriate to first
experiences. First kiss, first heartbreak, first parent's
death, first betrayal of trust — each carries adult-novel-
unjustifiable intensity in the YA register because the
protagonist genuinely has no comparison. Adult writers
inclined toward restraint should remember: the teen reader
needs commitment, not adult arch detachment.

Verify dark subjects are handled honestly — not preachy or
sanitised. Modern YA tackles trauma, sexual assault, mental
illness, addiction, racism, homophobia, ableism, abuse,
death, grief. Each subject requires specific rendering that
respects the reader's intelligence and the seriousness of
the material. Preachy prose lectures the reader; sanitised
prose softens the reality; the strongest contemporary YA
holds neither register.

Test: pick three emotionally significant moments and ask,
in each, whether the prose commits to the protagonist's
interior intensity, shows rather than states the emotion,
and respects the reader's intelligence. If any moment
hedges, lectures, or sanitises, the form's emotional
honesty has slipped.

### Pass 4: Social World Check

Verify relationships are complex — friends, family, romance,
all rendered with nuance rather than archetype. The
protagonist's best friend should not be the supportive-
sidekick type; the parent should not be the disapproving-
authority type; the love interest should not be the
romantic-prize type. Each must be a full character with
their own interior, motivations, and arc.

Verify the school / social environment is active, not just
backdrop. The cafeteria, the corridor, the specific class,
the particular teacher, the specific friend group's
configuration — these should be felt as inhabited and
specific rather than gestured at as generic high-school
scenery. The strongest contemporary YA writes school as a
specific institution with specific dynamics rather than
generic-high-school.

Verify characters are three-dimensional with no
stereotypes lacking depth. The popular girl who turns out
to be more complex than her social position; the bully who
has reasons that don't excuse but explain; the parent
whose disapproval comes from specific fears the protagonist
slowly perceives. Stereotype-without-depth is the form's
most-criticised contemporary failure — readers and reviewers
specifically flag flat antagonist treatment.

Verify the love interest is a person, not a prize.
Contemporary YA romance has evolved past the love-interest-
as-trophy model; the love interest must have their own arc,
own goals, own interiority that the protagonist gradually
perceives. The relationship must be a relationship, not a
reward for the protagonist's growth.

### Pass 5: Hope Check

Verify even in dark moments there is a sense that things
can change. YA contemporary has a structural ethical
commitment: the form addresses readers in formative years
encountering hard material often for the first time, and
the form's contract requires that the reader close the
book with somewhere to stand. This is not the same as
happy ending; many of the form's strongest books end in
loss, change, or the new equilibrium that follows what
cannot be undone. Hope is more specific: the protagonist
arrives at the ending with agency, perspective, and a
future they can imagine themselves into.

Verify the protagonist has agency in their own future.
Endings where the protagonist's future is determined
entirely by external forces (the parent's decision, the
adult intervention, the deus-ex-machina rescue) lose the
form's hope register. Endings where the protagonist
chooses, even if the choices are constrained, restore it.

Verify the ending is honest AND hopeful, even if
bittersweet. The form permits — and is often deepened by —
endings that don't tie up tidily. The friend group that
disperses but the protagonist who has learned to make
friends elsewhere. The first love that ends but the
protagonist who knows now they can love. The family
trauma that doesn't resolve but the protagonist who has
found a way to live with it. The honesty is in not
pretending these are full resolutions; the hope is in the
protagonist's continued capacity to keep going.

Test: read the manuscript's ending and ask whether it
honours both registers. If the ending is gentler than the
journey has earned, the hope is unearned; if the ending is
bleaker than the journey has earned, the hope register has
been abandoned.

### Pass 6: Period-Specific Authenticity Audit

Run a final pass on the manuscript's contemporary specificity
— the dimensions where YA contemporary either inhabits its
moment or reads as set elsewhere. Three sub-audits:

**Technology authenticity.** Does the manuscript inhabit
contemporary platform behaviour rather than adult-imagined-
teen-online? Specific platforms operating with specific
behavioural texture (the like-anxiety; the seen-not-replied;
the deliberate non-following; the BeReal-time scramble; the
group-chat dynamics that no adult fully understands)
distinguishes contemporary-aware YA from contemporary-
flavoured YA. Generic "she scrolled her phone" without
platform specificity is the failure mode.

**Mental-health representation.** Where the manuscript
addresses mental-health material, does it operate at
specific-lived-experience level rather than diagnostic-
label level? Does it avoid issue-novel preachy register
while honouring the seriousness of the material? Does it
acknowledge the contemporary standard that mental-health
conditions are managed rather than cured, that recovery is
non-linear, that the protagonist may end the book still
in the territory the book has been navigating?

**Adult character treatment.** Are adults rendered as full
characters with their own interior lives that the
protagonist partially perceives? Does the manuscript avoid
both cardboard-adult failure (parents / teachers /
counsellors as plot devices) and adult-saviour structure
(the adult who arrives to solve the problem)? Does the
protagonist's evolving perception of adults track as part
of their coming-of-age arc?

Test: pick one moment in the manuscript exemplifying each
sub-audit and verify each operates at contemporary-
authentic level. If any sub-audit falls into its failure
mode, the period-specific authenticity needs revision in
that domain.

## Names & Patterns to Avoid

### YA Character Names. NEVER USE
- Adult-sounding names: Bartholomew, Gertrude, Reginald (unless deliberately)
- Names that signal role: Faith (the religious character), Crystal (the popular girl)
- All characters sharing similar names (teen readers need to track a social world)

### YA Contemporary. NEVER DO
- Let adults solve the teen's problems (agency is non-negotiable)
- Talk down to readers (teens are the most discerning audience)
- Use dated slang (if in doubt, leave it out)
- Preach about issues (explore through character, not lecture)
- Write stereotypes without depth (every "type" must also be a person)
- Skip the difficult subjects (if teens experience it, it's legitimate to write about)
- Make the love interest a one-dimensional prize
- Write explicit sexual content (fade to black; this is YA, not adult romance)

### Use Instead
- Names that reflect the setting's cultural diversity
- Names that feel contemporary and specific to the character's background
- Nicknames that reveal friendship dynamics and social positioning

## Comp Titles

YA-contemporary's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Outsiders* — S.E. Hinton (1967): the modern YA-contemporary foundation.
- *The Catcher in the Rye* — J.D. Salinger (1951): the YA-adjacent coming-of-age classic.
- *Speak* — Laurie Halse Anderson (1999): YA-contemporary with trauma-recovery frame.
- *The Perks of Being a Wallflower* — Stephen Chbosky (1999): epistolary YA-contemporary benchmark.

### Contemporary (current best-in-class)

- *The Hate U Give* — Angie Thomas (2017): contemporary YA-political benchmark.
- *Long Way Down* — Jason Reynolds (2017): YA-novel-in-verse contemporary.
- *Eleanor & Park* — Rainbow Rowell (2013): YA-contemporary romance benchmark.
- *I'll Give You the Sun* — Jandy Nelson (2014): literary YA-contemporary.
- *Dear Evan Hansen* — Val Emmich et al (2018): YA contemporary mental-health benchmark.
- *The Astonishing Color of After* — Emily X.R. Pan (2018): YA-contemporary with Taiwanese-American grief.
- *Felix Ever After* — Kacen Callender (2020): YA-contemporary trans-protagonist.
- *Aristotle and Dante Discover the Secrets of the Universe* — Benjamin Alire Sáenz (2012): queer Latine YA-contemporary.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. Bold, stylised illustrations: character-driven imagery, graphic novel influence, bright or striking colours; the visual language of contemporary YA
- **Typographic**. The title dominates: bold, modern fonts, creative layout; minimal imagery; the design is as distinctive as the voice
- **Photographic**. Intimate, contemporary photography: a figure, a detail, a moment; authentic rather than glossy; the visual equivalent of the first-person voice
- **Graphic**. Bold graphic elements: patterns, symbols, silhouettes against colour blocks; eye-catching at thumbnail, distinctive on a shelf

### Genre Cover Aesthetics
- **Styles:** Illustrated characters (diverse, contemporary), bold typography, bright colour blocks, graphic patterns, contemporary photography with artistic treatment, social media-influenced design, the visual language of teen culture
- **Colours:** Bold, contemporary palettes: bright pinks, yellows, teals, corals alongside deep blues and blacks; colour choices that feel current and eye-catching; the palette should feel like a curated Instagram aesthetic
- **Elements:** Diverse characters, contemporary settings (schools, cities, bedrooms), technology (phones, screens, headphones), friendship symbols, cultural markers that signal contemporary teen life, illustrated flora/fauna as decorative frames
- **Typography:** Bold, modern, often the dominant design element; hand-lettered or custom fonts; creative placement (angled, wrapped, oversized); the typography should feel as distinctive as the protagonist's voice

### Market Positioning
YA Contemporary covers must signal "authentic, diverse, and emotionally honest" through bold design and contemporary aesthetics. Position against Green, Thomas, Acevedo, Albertalli, Silvera. The cover should look like something a teen would proudly carry and post. At thumbnail size, bold colour and distinctive typography create immediate shelf impact.

### Cover Design DON'Ts
- No designs that look like adult literary fiction (different audience, different visual language)
- No dark, moody palettes (unless the content specifically demands it)
- No stock photography that feels generic or staged
- No designs without diversity in character representation
- No dated visual elements (keep the aesthetic current)
- No cluttered compositions (bold and clean wins for YA)
