---
name: editorial-suite
description: "14-stage fiction editorial pipeline (Stages 0-12, including optional Stage 4.5 Repetition Sweep, conditional Stage 10 Multi-POV Consistency Pass, conditional Stage 11 Intimate Scene Review, and conditional Stage 12 Revision Loop)"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->
# Editorial Pipeline Protocol

## File-Write Hygiene (MANDATORY — applies to every chapter file any stage of this pipeline touches)

The editorial pipeline runs Edit / rewrite operations on the
manuscript across multiple stages (Genre Audit → Proofreader →
Copy Editor → Dev Editor → Alpha Reader → Beta Reader →
Conflict Resolution → Apply Top Fixes → Continuity Audit, plus
the conditional Multi-POV / Intimate Scene / Revision Loop
stages). The chained-Edit truncation safeguard documented in
`core-pipeline.md` § Chained-Edit Truncation Safeguard applies
in full to every stage that writes to a chapter file:

- **Prefer Write over chained Edit for chapter-scale rewrites.**
- **Cap individual Edit replacements at ~2 KB.**
- **Run `scripts/word-count-check.sh` after every chapter file
  any stage writes or edits**, not just at pipeline completion.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) before reporting per-stage success.

**HARD GATE — BLOCKING.** A truncated chapter file caught at
any stage MUST be repaired before the pipeline advances. The
multi-stage nature of this pipeline makes silent truncation
especially dangerous — a corrupted chapter that propagates
across three or four downstream stages may be unrecoverable.

## Overview

The editorial pipeline runs on the COMPLETE manuscript after all chapters are written
and verified. It provides manuscript-wide analysis that per-chapter verification cannot.

## When to Run

After all chapters are written and per-chapter verification scores are acceptable (80+).

## Per-Stage File Freshness Check (MANDATORY, HARD GATE)

**Before EACH editorial stage (not just pre-editorial),** verify that the
chapter files being read are the current versions. This is a HARD GATE,
not an advisory check — the stage MUST NOT proceed until freshness is
confirmed.

**Procedure (run at the START of every stage, before any analysis):**

```bash
stat -c '%Y %n' {path}/engine-data/chapters/ch*.md | sort -n
```

1. Record the current timestamp as `stage_start_time`
2. For each chapter file, compare its modification time against the
   timestamp recorded at the START of the PREVIOUS stage
3. If ANY chapter file is NEWER than the previous stage's start time,
   that file was modified during or after the previous stage
4. Re-read ALL modified files from disk before proceeding
5. Log which files were re-read: "Stage {N}: re-read {files} (modified
   since Stage {N-1})"

**This is NOT optional.** Do not skip this check because "nothing
changed." Run it every stage. The check adds <3 seconds and prevents
the entire class of "editorial agent working on stale prose" errors.

**Why HARD gate:** The previous version of this check was conditional
("if any file is newer, re-read"). A conditional check depends on the
implementer remembering to run it. A hard gate cannot be bypassed —
the stage physically cannot begin analysis until freshness is confirmed.

## Pipeline Order

```
0. Voice Profile (build BEFORE any editing)
1. Genre-Specific Audit (from genre bank — e.g., outline adherence for mysteries)
2. Proofreader
3. Copy Editor
4. Developmental Editor
5. Alpha Reader
6. Beta Reader
7. Conflict Resolution
8. Apply Top Fixes
9. Full-Manuscript Continuity Audit (post-fix sweep)
10. Multi-POV Consistency Pass (CONDITIONAL — multi-POV manuscripts only)
11. Intimate Scene Review (CONDITIONAL — manuscripts with romantic/intimate content)
12. Revision Loop (CONDITIONAL — when post-fix scores remain below convergence thresholds)
```

---

## Stage 0: Voice Profile (MANDATORY — Run Before Any Editorial Work)

Before making any changes, build a Voice Profile that all subsequent editorial
agents must respect. This prevents the editorial pipeline from flattening the
manuscript's personality.

### How to Build the Profile

Read at least 3 representative chapters (opening, mid-manuscript, climax region)
and document:

```
VOICE PROFILE:

SENTENCE ARCHITECTURE:
  - Average sentence length: [short/medium/long/mixed]
  - Sentence variety: [high/moderate/low]
  - Fragment usage: [frequent/occasional/rare]
  - Complexity preference: [simple/compound/complex/mixed]

VOCABULARY:
  - Register: [formal/casual/literary/conversational]
  - Range: [accessible/moderate/rich]
  - Profanity level: [none/mild/moderate/heavy]
  - Dialect markers: [list any]

NARRATIVE STANCE:
  - Psychic distance: [deep POV/moderate/observational]
  - Introspection ratio: [high/moderate/low]
  - Description density: [sparse/moderate/lush]
  - Sensory preferences: [which senses dominate]

DIALOGUE CHARACTERISTICS:
  - Tag style: [minimal/moderate/varied]
  - Subtext level: [direct/moderate/subtextual]
  - Humour style: [witty/dry/dark/slapstick/absent]

PACING SIGNATURE:
  - Chapter length: [regular/varied]
  - Scene transitions: [hard cuts/bridges/varied]
  - Action-to-reflection ratio: [action-heavy/balanced/reflection-heavy]

METAPHOR & IMAGERY:
  - Density: [frequent/moderate/rare]
  - Source domains: [where metaphors come from — nature, domestic, mechanical, etc.]
  - Recurring images: [any clusters or motifs]
```

### Voice Profile Summary

Write a 3-5 sentence summary capturing the voice:

Example: "This author writes in close, conversational first-person present tense
with short sentences that punch and longer ones that breathe. Vocabulary is
accessible but precise — the exact right word rather than a fancy one. Humour is
dry and self-deprecating, delivered through internal monologue. Metaphors are rare
but always drawn from domestic life. Dialogue is clipped and subtextual."

### How the Profile Is Used

- Attached to EVERY editorial agent's context (Stages 1-8)
- The Voice Profile travels with every fix instruction
- After every fix, the applying agent must check: "Could this have been written
  by the same person who wrote the rest of the manuscript?"
- If an edit makes a passage sound noticeably different from the surrounding
  prose, the edit has gone too far — pull back

### The Golden Rule

When in doubt, leave it. A missed fix is better than a voice violation. The
manuscript's personality on the page is more valuable than editorial perfection.

---

## Stage 1: Genre-Specific Audit

This stage is UNIQUE to each genre. The genre bank file defines what to check.

Examples:
- **Mystery/Thriller:** Outline adherence audit (knowledge states, suspect treatment, clue timing, fair play)
- **Fantasy:** Magic system consistency audit (rules, costs, limitations)
- **Romance:** Relationship arc audit (meet-cute to HEA, beat delivery)
- **Historical:** Period accuracy audit (language, technology, social norms)

Read the `## Genre-Specific Revision Rules` section of the active genre bank file
(located at `genre-bank/[genre-id].md`)
and execute whatever audit it defines.

Fix all critical issues from this audit BEFORE proceeding to general editorial.

---

## Stage 2: Proofreader

### System Prompt
```
You are a professional Proofreader reviewing a {genre} manuscript.
Dialect: {dialect}

Em-Dash Policy: See `craft-standards.md` Em-Dash Policy (Two-Tier) for the
rules governing this manuscript's project mode. AI-generated prose: em-dashes
BANNED in narration (target: 0), permitted in dialogue for interruptions only
(max 3 per chapter). Human-written prose: permitted but density-limited
(≤3 per 1,000 words). Flag every violation.

Find and report:
- Spelling errors (including character/place name consistency)
- Acronym/abbreviation expansion consistency (compare every expansion of every
  acronym against the entity database — flag any single-word difference. E.g.,
  if the entity DB says "Adaptive Intelligence for Dynamic Educational Needs"
  and Ch17 says "Networking" instead of "Needs," that is a proofreading error.)
- Grammar issues
- Punctuation errors
- Formatting inconsistencies
- Homophone confusion (their/there/they're)
- Tense shifts (unintentional)
- Subject-verb agreement
- Dangling modifiers

Do NOT flag:
- Intentional dialect in dialogue
- Character-specific grammar (if established in speech patterns)
- Stylistic sentence fragments (if consistent with voice)
```

### Output Schema
```
STATUS: pass | warning | fail
ISSUE COUNT: {number}
ISSUES:
For each:
- TYPE: spelling | grammar | punctuation | formatting | tense | agreement
- SEVERITY: minor | moderate
- CHAPTER: {number}
- QUOTE: [exact text]
- FIX: [corrected text]
```

---

## Stage 3: Copy Editor

### System Prompt
```
You are a professional Copy Editor reviewing a {genre} manuscript.

Em-Dash Policy: See `craft-standards.md` Em-Dash Policy (Two-Tier) for the
rules governing this manuscript's project mode. AI-generated prose: em-dashes
BANNED in narration (target: 0), permitted in dialogue for interruptions only
(max 3 per chapter). Human-written prose: permitted but density-limited
(≤3 per 1,000 words). Flag every violation.

Evaluate line-level prose quality:
- Word choice precision (are words earning their place?)
- Sentence rhythm and variety
- Crutch words/phrases (flag if any word appears 3+ times per chapter)
- Adverb density (flag if >2 per page)
- Passive voice (flag if >15% of sentences)
- Dialogue tag variety (flag over-reliance on anything other than "said")
- Repetitive constructions (same sentence pattern used >3 times in a chapter)
- Filter words ("noticed", "felt", "seemed", "wondered", "realized")

Do NOT rewrite. Report issues with exact quotes and suggested improvements.

MANUSCRIPT-WIDE PHRASE FREQUENCY ANALYSIS (MANDATORY — run BEFORE per-chapter work):

Before analysing individual chapters, count these multi-word constructions
across the FULL manuscript. Count EVERY instance — do not estimate from sampling:

- "the way [x]" (all instances, any variant)
- "something about/behind [x]"
- "the kind of [x]"
- "not [x]. Not [y]. [z]." (triple negative-positive construction)
- "[x] the way [y] does when [z]"
- "that was the thing about [x]"
- "something behind [character]'s eyes/face"
- "[character] filed this away"

**IMPORTANT: Run `manuscript-audit.sh` BEFORE this stage.**
The bash script produces exact per-chapter and manuscript-wide counts
for all tracked patterns. The Copy Editor receives this output as
ground truth and does NOT recount. Focus on identifying patterns the
script cannot detect (contextual overuse, semantic repetition, rhythm
degradation).

```bash
bash scripts/manuscript-audit.sh {chapters-dir} {project-path} {word-target}
```

Report RAW COUNTS from the script output, plus any additional patterns
the Copy Editor identifies through semantic analysis. If any phrase exceeds:
- 4 instances in a single chapter: flag as crutch construction (severity: moderate)
- 40 instances manuscript-wide: flag as systemic crutch (severity: critical)
- 2 instances per 1,000 words manuscript-wide: flag as pattern (severity: moderate)

Why this is mandatory: In the Not a Glitch audit, "the way" appeared 150+ times
across 22 chapters (peaking at 16 per chapter). The Copy Editor reported ~20
instances — a 7.5x undercount caused by searching for a specific variant instead
of all instances of the phrase.
```

### Output Schema
```
STATUS: pass | warning | fail
PROSE SCORE: 0-100

PHRASE FREQUENCY TABLE (MANDATORY):
| Phrase | Manuscript Total | Highest Single Chapter | Avg Per Chapter |
|--------|-----------------|----------------------|----------------|
| "the way [x]" | {count} | Ch{N}: {count} | {avg} |
| [etc.] | | | |

ISSUES:
For each:
- TYPE: word-choice | rhythm | crutch-word | adverb | passive | dialogue-tag | repetition | filter-word | phrase-frequency
- SEVERITY: minor | moderate | critical
- CHAPTER: {number}
- QUOTE: [exact text]
- SUGGESTION: [improvement]
- FREQUENCY: [how many times this pattern appears in the manuscript]
```

---

## Stage 4: Developmental Editor

### System Prompt
```
You are a Developmental Editor assessing the full manuscript structure of
a {genre} {length_tier}.

{genre_quality_check_criteria}

Evaluate:
1. OPENING: Does the first chapter hook the reader within the first page?
2. PACING: Are there drag points or rush points across the full manuscript?
3. CHARACTER ARCS: Do protagonist and key characters complete their arcs?
4. PLOT: Are all plot threads resolved? Any dangling threads?
5. SUBPLOTS: Do they enhance or distract from the main plot?
6. THEME: Is the thematic throughline maintained without being heavy-handed?
7. STAKES: Do stakes escalate appropriately toward the climax?
8. CLIMAX: Does it deliver on the story's promise?
9. RESOLUTION: Is it satisfying without being rushed?
10. GENRE COMPLIANCE: Does it meet {genre} reader expectations throughout?

Produce a PRIORITY ACTION ITEMS list (top 5-7 most impactful changes).
```

### Output Schema
```
STATUS: pass | warning | fail
OVERALL SCORE: 0-100
OPENING SCORE: 0-100
PACING SCORE: 0-100
CHARACTER ARC SCORE: 0-100
PLOT RESOLUTION SCORE: 0-100
THEME SCORE: 0-100

PRIORITY ACTION ITEMS:
For each (ranked by impact):
- PRIORITY: 1-7
- CATEGORY: opening | pacing | character | plot | subplot | theme | stakes | climax | resolution | genre
- DESCRIPTION: [What needs to change]
- CHAPTERS AFFECTED: [Which chapters]
- SUGGESTED FIX: [Specific, actionable recommendation]
- ESTIMATED EFFORT: minor (1-2 paragraphs) | moderate (scene rewrite) | major (chapter restructure)

STRENGTHS: [3-5 specific things the manuscript does well]
SUMMARY: [Executive summary paragraph]
```

---

## Stage 4.5: Repetition Sweep (CONDITIONAL — recommended for manuscripts ≥40,000 words)

Cross-chapter / cross-scene argument and motif repetition
detection and consolidation pass. Sits between the
Developmental Editor's structural recommendations (Stage 4)
and the Alpha Reader's first-impression assessment
(Stage 5). For fiction, this catches:

- Recurring metaphors or rhetorical phrases that become
  tic-like (a distinctive image deployed once effectively,
  then reused for diminishing returns)
- Argumentative beats restated across multiple scenes
  (the same character revelation made three different
  ways without new evidence)
- Vignettes / examples / set-pieces that recur with less
  return on each appearance
- Theme-statement-explicitness drift (the manuscript
  saying its theme out loud in three places where one
  would carry it)

The Stage 4.5 output is
`engine-data/reports/repetition-sweep-{YYYY-MM-DD}.md` — a
structured consolidation report with KEEP / CROSS-REFERENCE
/ CONSOLIDATE / DELETE / TIGHTEN recommendations per
detected recurrence. The user (or the editorial pipeline)
actions the recommendations; the sweep does NOT
auto-consolidate (repetition is sometimes deliberate for
rhetorical reinforcement, motif, or narrative architecture
— a fiction motif that recurs at three planted moments may
be exactly the right call).

This stage is RECOMMENDED for any manuscript ≥40,000 words.
For shorter works, the Developmental Editor's structural
feedback typically suffices and Stage 4.5 may be skipped.

→ See `repetition-sweep.md` for the full protocol.

## Stage 5: Alpha Reader

### Screenplay Redirect

**If the project is a screenplay** (Fountain format, or the Screenplay Agent was used),
**do NOT run the prose Alpha Reader.** Instead, run **Script Coverage Pass 1
(Development Coverage)** from `script-coverage.md`. Skip to Stage 7 after both
Script Coverage passes complete.

### System Prompt (Prose Manuscripts Only)
```
You are an Alpha Reader — the FIRST person to read this manuscript.
You are a voracious fiction reader but NOT a professional editor.

SCOPE RULE (MANDATORY): Read ONLY the chapter files in
engine-data/chapters/. Do NOT read chapter briefs, the Story Bible,
the outline, or any planning document. You are a reader, not a
production insider. If you have not read a line in the actual chapter
prose, you have not read it — do NOT quote or cite content from briefs,
outlines, or the Bible as if it appears in the manuscript. Every quote
in your report must come from the chapter files and must appear verbatim
in the prose. If you cannot find a quote in the chapter text, do not
use it.

Read as a READER, not an analyst. Report your genuine experience of
reading this book — where you were gripped, where you drifted, what
moved you, what confused you, and whether you'd press this into a
friend's hands.

Your report should feel like a passionate reader talking about a book
they just finished — informed, specific, honest, and alive. Reference
SPECIFIC chapters throughout. Every observation must cite at least one
chapter number. Never make a general claim without pointing to where
in the manuscript it happens.

DEPTH REQUIREMENT: This is not a summary — it is an in-depth analysis.
Each section requires full paragraphs (2-4 sentences minimum), not
brief notes. The complete report should be substantial and detailed.
```

### Output Format (MANDATORY — use this exact structure)

**FORMAT COMPLIANCE IS MANDATORY.** Do not freestyle, do not invent your
own layout, do not skip sections or tables. The structured tables and
star ratings exist so the author can scan for weak chapters at a glance.
The prose commentary within each section should read like a real person
talking about a book — specific, opinionated, alive — but it MUST live
inside the structure below, not replace it.

The Alpha Reader report combines structured dashboard metrics (for
at-a-glance scanning) with in-character reader commentary (for depth).

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  📖  ALPHA READER REPORT
  {Title} by {Author}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Reader:** {Name}, {age}, {occupation/location}. {1-2 sentences on
reading habits — what they read, how much, where/when they read.
This persona anchors the voice for the entire report. Write all
commentary AS this person — their vocabulary, their reference points,
their level of technical awareness.}

**Read on:** {When they read it, how long it took, whether they read
in one sitting or multiple.}

───────────────────────────────────────────────

## Overall Impression

| Metric | Score | Reaction |
|--------|-------|----------|
| **Story** | {N}% | {emoji — 🤩 amazed / 😄 delighted / 🧐 intrigued / 😐 neutral / 😕 disappointed} |
| **Reader Fit** | {N}% | {emoji} |

**Why {story_emoji}:**
{Full paragraph (4-6 sentences) in the reader persona's voice. Be
specific — name the scenes, moments, and craft techniques that earned
or lost points. Which chapter hooked you? Which reveal landed? Which
sequence made you want to keep reading? Reference at least 3 chapters.}

**Why {fit_emoji}:**
{Full paragraph (4-6 sentences). What specifically matched your taste
as a reader? What genre conventions did it nail? Be honest about the
distinction between "this isn't good" and "this isn't for me." What
kind of reader is this PERFECTLY suited for? Reference specific chapters.}

**⭐ Favorite Line:**
> "{exact quote}" — Chapter {N}

{Full paragraph (3-4 sentences) explaining WHY this line landed.}

───────────────────────────────────────────────

## Chapter-by-Chapter

### Dashboard

| Ch | Title | ⭐ | Emotion | Strength | Key moment |
|----|-------|----|---------|----------|------------|
| 01 | {title} | {N}/10 | {emoji} ({name}) | {●●●●○} | {one-line highlight} |
| 02 | {title} | {N}/10 | {emoji} ({name}) | {●●●○○} | {one-line highlight} |
| ... | ... | ... | ... | ... | ... |

**Emotion Key:** 🤩 amazed · 🤯 mind-blown · 😄 delighted · 🧐 intrigued ·
😬 uneasy · 😰 anxious · 😱 scared · 😢 sad · 🤔 reflective · 😐 neutral ·
😤 frustrated · 😲 shocked · 😌 relieved

**Strength Key:** ●●●●● (90-100%) · ●●●●○ (70-89%) · ●●●○○ (50-69%) ·
●●○○○ (30-49%) · ●○○○○ (10-29%)

### Chapter Commentary (MANDATORY — one entry per chapter)

For EACH chapter, write 2-4 paragraphs in the reader persona's voice.
Be specific: quote lines that worked, name moments that didn't, explain
WHY. This is where the report earns its depth. Do not summarise the
plot — react to it.

**Ch {N} — {Title}**
{2-4 paragraphs. What worked, what didn't, specific quotes, specific
reactions. End with the star rating justification: "Score: {N}/10"}

{Repeat for every chapter.}

### Peaks and Dips

**Emotional Peak:** Chapter {N} — {2-3 sentences on what happened and
why it hit hardest.}

**Emotional Dip:** Chapter {N} — {2-3 sentences on what caused
engagement to drop.}

**Where I Almost Stopped:** {Chapter {N} — 2-3 sentences. If you never
almost stopped, say so and explain what kept you going.}

───────────────────────────────────────────────

## Big Picture Story Elements

### 🎯 Premise & Hook

{Full paragraph (4-6 sentences). Does the central idea feel strong and
interesting? Is the opening strong enough to survive the "look inside"
test on Amazon? Reference the chapter where the hook fully engages.}

### 📐 Plot Structure

{Full paragraph (4-6 sentences). Are there clear stakes, momentum, and
turning points? Name the key turning points and which chapters they fall
in. Is the climax satisfying? Does the ending deliver on what the
beginning promised?}

### ⏱️ Pacing

{Full paragraph (4-6 sentences). Does the story drag, rush, or stall
anywhere? Name the SPECIFIC chapters where pacing is strongest and
weakest. Did you read in one sitting or put it down between sessions?}

───────────────────────────────────────────────

## Characters

### 👤 Protagonist Clarity

{Full paragraph (3-4 sentences). Do I know who the main character is
and what they want? Is their voice distinctive enough that I'd recognise
them from a random page? Reference specific chapters.}

### 🎯 Motivations & Goals

{Full paragraph (3-4 sentences). Are their motivations clear? Do their
choices feel earned or convenient? Reference chapters.}

### 🎭 Character Dynamics

{Full paragraph (4-6 sentences). Do relationships feel believable? Which
relationship is most compelling? Are secondary characters distinct or do
they blur together? Name specific characters and cite chapters.}

### ⚠️ Consistency

{Full paragraph (3-4 sentences). Does a character act "out of character"
without reason? Note any slips with chapter references, or flag as clean.}

───────────────────────────────────────────────

## Conflict & Stakes

{2-3 full paragraphs covering obstacles, tension, and stakes. Name
specific chapters. Do I feel the "what happens next" pull? Is it clear
why the protagonist's success or failure matters?}

───────────────────────────────────────────────

## Worldbuilding & Setting

{2-3 full paragraphs. Do I understand the setting? Are there moments
where the world felt vivid? Any moments of confusion? For speculative
genres: are the rules consistent? Reference chapters.}

───────────────────────────────────────────────

## Theme & Tone

{2-3 full paragraphs. Do I get a sense of what the story is "about"
beneath the plot? Is the voice distinctive? Could you identify this
author from a blind sample? Reference chapters.}

───────────────────────────────────────────────

## General Impressions

### 💚 What Made Me Excited, Curious, or Emotional

{Bulleted list of 4-6 specific moments. EACH bullet must include
chapter number, what happened, and WHY it worked.}

### 🔶 What Felt Flat, Confusing, or Unnecessary

{Bulleted list of 3-5 specific moments. EACH bullet must include
chapter number, what the issue was, and a constructive suggestion.}

### 🔴 Glaring Holes, Contradictions, or Confusing Threads

{Bulleted list. If none: "None found — structurally sound."}

### ❓ Questions Left in My Head

{Bulleted list of 3-5 questions. For each, note whether the ambiguity
WORKS, FRUSTRATES, or IS DELIBERATE.}

───────────────────────────────────────────────

## Final Thoughts

| Factor | Rating |
|--------|--------|
| **"I Can't Put It Down"** | {High / Moderate / Low} |
| **"Re-Read" Factor** | {High / Moderate / Low} |
| **Tropes & Clichés** | {Fresh / Familiar-but-well-executed / Tired} |

**"I Can't Put It Down":** {Full paragraph (3-4 sentences).}

**"Re-Read" Factor:** {Full paragraph (3-4 sentences).}

**Tropes & Clichés:** {Full paragraph (3-4 sentences).}

**Final Summary:**
{Full paragraph (5-7 sentences). The definitive wrap-up. Name the single
biggest strength. Name the single most impactful improvement. End on the
strongest positive — this is a reader's report, not a demolition.}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Delivery Format

**MANDATORY:** After generating the Alpha Reader report, deliver it as a downloadable `.docx` file named `Alpha-Reader-Report-{Title}.docx`. The visual formatting (box-drawing lines, emoji indicators, tables, star ratings) must be preserved in the Word document using appropriate heading styles, table formatting, and Unicode characters. Also display the report inline for immediate reading.

---

## Stage 6: Beta Reader

### Screenplay Redirect

**If the project is a screenplay**, run **Script Coverage Pass 2 (Industry Coverage)**
from `script-coverage.md` instead of the prose Beta Reader.

### System Prompt (Prose Manuscripts Only)
```
You are a Beta Reader — a {genre} genre expert who has read hundreds of
{genre} novels. You know the conventions, tropes, and reader expectations
inside out. You read for craft AND for market.

SCOPE RULE (MANDATORY): Read ONLY the chapter files in
engine-data/chapters/. Do NOT read chapter briefs, the Story Bible,
the outline, or any planning document. You are a reader, not a
production insider. Every quote in your report must come from the
chapter files and must appear verbatim in the prose. If you cannot find
a quote in the chapter text, do not use it.

Read this manuscript as a GENRE-SAVVY READER who knows what sells,
what fans love, what gets 5-star reviews, and what makes readers
DNF at chapter 3. Be constructive, specific, and honest.

DEPTH REQUIREMENT: Reference SPECIFIC chapters throughout. Every
observation must cite at least one chapter number. Each section requires
full paragraphs (3-6 sentences), not brief notes. The complete report
should be as detailed as the Alpha Reader report.
```

### Output Format (MANDATORY — use this exact structure)

**FORMAT COMPLIANCE IS MANDATORY.** Do not freestyle, do not invent your
own layout, do not skip sections or tables. The structured tables, star
ratings, and genre scorecard exist so the author can scan for weak chapters
at a glance. The prose commentary within each section should read like a
genre expert talking about a book — informed, specific, opinionated — but
it MUST live inside the structure below, not replace it.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  📚  BETA READER REPORT — {Genre} Expert Assessment
  {Title} by {Author}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Reader:** {Name}, {age}, {role — e.g. editorial assistant, genre
reviewer, bookshop buyer}. {1-2 sentences on professional context and
reading habits. This persona anchors the voice — write all commentary
AS this person.}

**Read on:** {When, how many sittings, whether they took notes.}

## Overall Impression: {N} ⭐ (out of 5, half stars allowed)

| Metric | Score | Reaction |
|--------|-------|----------|
| **Story** | {N}% | {emoji} |
| **Reader Fit** | {N}% | {emoji} |

**Why {story_emoji}:**
{Full paragraph (4-6 sentences). Genre-specific assessment — does this
deliver what {genre} readers expect? How does quality compare to
published {genre} novels in the current market? Reference at least 3
chapters.}

**Why {fit_emoji}:**
{Full paragraph (4-6 sentences). What kind of {genre} reader is this
most suited for — casual, devoted fan, literary-leaning crossover?
Reference chapters.}

**⭐ Favorite Line:**
> "{exact quote}" — Chapter {N}

{Full paragraph (3-4 sentences). Why does this line work for a {genre}
reader specifically?}

───────────────────────────────────────────────

## Chapter-by-Chapter

### Dashboard

| Ch | Title | ⭐ | Emotion | Strength | Key moment |
|----|-------|----|---------|----------|------------|
| 01 | {title} | {N}/10 | {emoji} ({name}) | {●●●●○} | {one-line highlight} |
| ... | ... | ... | ... | ... | ... |

**Emotion Key:** 🤩 amazed · 🤯 mind-blown · 😄 delighted · 🧐 intrigued ·
😬 uneasy · 😰 anxious · 😱 scared · 😢 sad · 🤔 reflective · 😐 neutral ·
😤 frustrated · 😲 shocked · 😌 relieved

**Strength Key:** ●●●●● (90-100%) · ●●●●○ (70-89%) · ●●●○○ (50-69%) ·
●●○○○ (30-49%) · ●○○○○ (10-29%)

### Chapter Commentary (MANDATORY — one entry per chapter)

For EACH chapter, write 2-4 paragraphs as the genre expert. Assess
craft, genre conventions, what works for {genre} readers, what doesn't.
Quote specific lines. Compare to published {genre} novels where relevant.

**Ch {N} — {Title}**
{2-4 paragraphs. Genre-lens assessment. End: "Score: {N}/10"}

{Repeat for every chapter.}

### Peaks and Dips

**Emotional Peak:** Chapter {N} — {2-3 sentences}
**Emotional Dip:** Chapter {N} — {2-3 sentences}

**Where I Almost Stopped:** {Chapter {N} — 2-3 sentences. If you never
almost stopped, explain what kept a {genre} expert engaged.}

───────────────────────────────────────────────

## Characters

{3-4 full paragraphs through the genre lens. For EACH major character:
genre-appropriate? How do they compare to published {genre} novels?
Fan favourite potential? Name specific characters, cite chapters.}

───────────────────────────────────────────────

## Plot & Conflict

{3-4 full paragraphs. Does the plot deliver the genre PROMISE? Is the
climax satisfying by genre standards? What would genre fans LOVE? What
would they criticise? Any unresolved threads? Reference chapters.}

───────────────────────────────────────────────

## Worldbuilding & Setting

{2-3 full paragraphs. Does the setting serve the genre? How does the
worldbuilding compare to the genre's best? Reference chapters.}

───────────────────────────────────────────────

## Theme & Tone

{2-3 full paragraphs. Does the tone match genre expectations? Is this
a "just plot" book or does it have something to say? Reference chapters.}

───────────────────────────────────────────────

## Dialogue & Style

{2-3 full paragraphs. Does the dialogue sound like real people? Is the
prose style appropriate for {genre}? Any passages that read as
"AI-generated"? Note specific strengths. Reference chapters.}

───────────────────────────────────────────────

## Continuity & Clarity

{Full paragraph (3-4 sentences). Any contradictions, timeline issues?
Genre-specific continuity (mystery clues, romance timeline, magic system
rules)? Reference chapters if issues found.}

───────────────────────────────────────────────

## Specific Feedback

### 💚 Favorite moments/lines

{Bulleted list of 4-6. Chapter number, what happened, WHY it works for
a {genre} reader, comparison to published {genre} novels if applicable.}

### 🔶 Least favorite / where attention drifted

{Bulleted list of 3-5. Chapter number, issue, constructive suggestion,
whether casual readers or only genre experts would notice.}

### ❓ Questions left in my head

{Bulleted list of 3-5. The question, whether it WORKS / FRUSTRATES /
IS DELIBERATE, whether genre readers would accept or resist it.}

### 💔 Emotional reactions

{Full paragraph (3-4 sentences). How did the book make you FEEL as a
genre reader? Did the emotional journey match what {genre} readers seek?}

───────────────────────────────────────────────

## 📊 Genre Scorecard

| Dimension | Score | Assessment |
|-----------|-------|-----------|
| **Genre Authenticity** | {N}/100 | {2-3 sentences} |
| **Market Readiness** | {N}/100 | {2-3 sentences} |

### Comp Titles
{2-3 comp titles. For each: title/author, why comparable, where this
manuscript matches/diverges, flattering or aspirational comparison.}

### Market Notes
{Full paragraph (3-4 sentences). Current {genre} market positioning,
reader demographic, Amazon listing signals.}

───────────────────────────────────────────────

## Final Thoughts

| Factor | Rating |
|--------|--------|
| **"I Can't Put It Down"** | {High / Moderate / Low} |
| **"Re-Read" Factor** | {High / Moderate / Low} |
| **Tropes & Clichés** | {Fresh / Well-executed / Tired} |

**"I Can't Put It Down":** {Full paragraph (3-4 sentences).}

**"Re-Read" Factor:** {Full paragraph (3-4 sentences).}

**Tropes & Clichés:** {Full paragraph (3-4 sentences).}

**Final Summary:**
{Full paragraph (5-7 sentences). Single biggest strength from a genre
perspective. Single most impactful improvement. Comparison to debut
novels in the genre. End on the strongest positive.}

**Verdict:** {One line — Acquire / Pass / Revise-and-resubmit. If
Acquire, specify the format: anthology slot, single title, reader
magnet, series opener. If Pass or Revise, name the specific fix.}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Delivery Format

**MANDATORY:** After generating the Beta Reader report, deliver it as a downloadable `.docx` file named `Beta-Reader-Report-{Title}.docx`. The visual formatting (box-drawing lines, emoji indicators, tables, star ratings, genre scorecard) must be preserved in the Word document using appropriate heading styles, table formatting, and Unicode characters. Also display the report inline for immediate reading.

---

## Stage 7: Conflict Resolution

After all editorial agents complete:

1. **Compile all issues** across all 6 editorial stages
2. **Detect contradictions:**
   - Agent A says "add more description" + Agent B says "trim this section" → CONFLICT
   - Agent A says "this character is too passive" + Agent B says "I loved this character's quiet strength" → SUBJECTIVE — note but don't auto-resolve
3. **Present conflicts to user** with both perspectives
4. **Rank all non-conflicting issues** by impact × severity

## Stage 8: Apply Top Fixes

Apply the top 5-7 fixes surgically:

1. For each fix, identify the EXACT text to change
2. Apply the MINIMUM edit that resolves the issue
3. Do NOT rewrite surrounding paragraphs
4. Verify the fix doesn't introduce new issues
5. Log what was changed and why

### Stage 8 — Tracked-Changes Mode (when user requests tracked output)

When the user requests editorial feedback as tracked-changes
rather than inline application — phrases like "track changes
rather than apply them", "give me a tracked-changes version",
"I want to review changes before accepting" — Stage 8 operates
in **tracked-changes mode** under the canonical protocol in
`tracked-changes.md`.

In tracked-changes mode, Stage 8 does NOT apply edits inline
to chapter MD files. Instead, it produces a structured change
record (one row per suggested edit) that the
`tracked-changes.md` Phase B / Phase C pipeline consumes to
emit a Word-compatible tracked-changes DOCX with mandatory
integrity verification.

**HARD REQUIREMENT — BLOCKING:** Any tracked-changes DOCX
emission MUST follow `tracked-changes.md` end-to-end. The
three-phase protocol (DOCX-Read with Integrity Capture →
Mark Changes on intermediate → DOCX-Write with Integrity
Verification) and the per-paragraph fingerprinting + word-
count parity + SHA256 base-text preservation checks at
Phase C are the structural counter-protocol against the
documented silent-paragraph-drop failure mode (mid-sentence
cutoffs at page boundaries that dropped 2-3 sentences in
operational use).

Stage 8 in tracked-changes mode MUST NOT emit the DOCX
without the integrity report verdict reading "READY FOR
DELIVERY". A NOT-READY verdict surfaces specific failures
(paragraph index missing / word count mismatch / SHA256
mismatch on paragraph X) to the user; the agent does NOT
ship a manuscript that has lost source content.

→ See `tracked-changes.md` for the full three-phase
protocol, integrity verification gates, and integrity
report format.

See `surgical-fixes.md` for the full revision protocol.

**Story Bible Section 12 reconciliation (MANDATORY — runs AFTER all
Stage 8 fixes are applied):**

If any fix MOVED a beat between chapters (e.g., "move the climax
conversation from Ch 18 to Ch 17"), RESTRUCTURED a chapter's scene
order, or REMOVED/ADDED significant content:

1. Identify which Section 12 entries are now stale (the chapter
   outline says "Ch 18 delivers the climax beat" but the fix moved
   it to Ch 17)
2. Update Story Bible Section 12 to reflect the post-fix reality
3. If this is a series project, run the Series Bible cross-volume
   re-check to ensure the fix didn't break series continuity

**Why this matters:** Section 12 is the canonical reference for series
continuity, future editorial passes, and Book 2+ planning. If it's
stale after editorial restructuring, downstream consumers (Series
Continuity Guardian, Book 2 Story Bible generator, returning-to-
project Architect) will work from incorrect data.

Fixes that don't restructure (e.g., word choice, em-dash removal,
crutch phrase replacement) do NOT require Section 12 updates.

---

## Stage 9: Full-Manuscript Continuity Audit

After all fixes are applied, run a dedicated continuity sweep across the COMPLETE
manuscript. This catches cross-chapter contradictions that per-chapter verification
agents miss — because they only see one chapter at a time.

### Verification Discipline Binding (when real-world anchors are present)

When the manuscript anchors to real-world specifics
(historical fiction, biographical fiction, contemporary
fiction with real-event / real-person / real-organisation
references), this audit also re-runs the
`verification-discipline.md` Phase A WebSearch verification
against the bible's `engine-data/verification-ledger.md` —
identical scope and rules to NF Stage 9 Fact Audit, but
applied only to the real-world anchor layer of the
manuscript (not to invented characters / worlds /
organisations). Any drift between the bible's pinned source
and the manuscript's prose is a finding. The seven named
anti-patterns in `verification-discipline.md` are detection
targets for the audit when it operates on real-world
anchors.

For pure invented-world projects, this binding is a no-op
and the audit operates only on the invented-canon
continuity dimensions below.

For mixed projects (invented characters in real historical
settings, real cameos in invented contemporary stories), the
audit operates on both layers — invented continuity for
characters / world, real-world verification for anchor
facts.

### Build Master Reference Tables

Read the entire manuscript and construct these 6 tables:

**1. Character Bible**
For every named character (including minor characters appearing 2+ times):

| Character | Eyes | Hair | Age | Build | Distinguishing Features | Occupation | First Appears |
|---|---|---|---|---|---|---|---|

Flag: physical details that change between chapters, age contradictions,
occupation shifts, name spelling variations, nicknames used before established.

**2. Relationship Tracker**

| Characters | How They Meet | Chapter | Relationship Progression |
|---|---|---|---|

Flag: characters referencing shared history never shown on-page, relationship
jumps without development, characters knowing things before being told,
terms of address that don't match relationship stage.

**3. Location & Geography**

| Location | Description | Spatial Relationship | Key Features | First Appears |
|---|---|---|---|---|

Flag: locations described differently in different chapters, spatial
contradictions, travel times that don't match distances, rooms whose layout changes.

**4. Timeline & Chronology**

| Chapter/Scene | Day | Time of Day | Key Events | Weather/Season |
|---|---|---|---|---|

Flag: characters in two places at once, impossible travel times, events referenced
before they happen, day/date mismatches, seasonal inconsistencies.

**5. World Rules & Systems**

| Rule | First Established | Chapter | Details |
|---|---|---|---|

Flag: rules that contradict themselves, abilities that appear/disappear, power
levels that shift without explanation.

**6. Object & Detail Tracking**

| Object | First Appears | Description at First Appearance | Current Location | Last Referenced |
|---|---|---|---|---|

**FIRST APPEARANCE RULE:** Track every recurring object from its ABSOLUTE FIRST
mention in the manuscript, not from the chapter where it becomes a named motif.
If Ch2 says "half-drunk glass of water on the desk" and Ch3 says "cold mug with
dried chocolate ring on the desk," these describe the same desk object. The
first appearance is Ch2, and the descriptions are contradictory. Flag it.

Flag: objects that teleport, characters who know things they shouldn't, dropped
plot threads, Chekhov's gun violations, objects whose descriptions change between
chapters without narrative justification.

**7. Canonical Fact Table (NEW — added post-Not a Glitch audit)**

| Fact Type | Fact | Canonical Value | Source | All References (Ch:Line) | Consistent? |
|---|---|---|---|---|---|
| acronym | AIDEN expansion | [entity DB value] | Ch1:5 | Ch1:5, Ch17:77 | yes/NO |
| age | Nadia's age | [entity DB value] | Ch4:X | Ch4:X, Ch10:Y, Ch20:Z | yes/NO |
| month | Permitted months | [Story Bible list] | Bible Section 6 | Ch1:99, Ch13:83... | yes/NO |
| count | Student population | [entity DB value] | Ch3:X | Ch3:X, Ch5:Y, Ch19:Z | yes/NO |

Include ALL of these categories:
- Every acronym/abbreviation expansion
- Every character age reference
- Every month/season reference (compare against Story Bible Section 6 MONTHS PERMITTED)
- Every proper noun spelling
- Every numerical claim (student counts, audience sizes, timeframes)
- Every key object description (compare first vs subsequent appearances)

Flag ANY reference that doesn't match the canonical value. Do NOT rationalize.

### Audit Process

**CRITICAL INSTRUCTION — NEVER RATIONALIZE:**
If two chapters state different values for the same fact (month, age, name
spelling, acronym expansion, object description, location detail, numerical
count), this is ALWAYS an error. Do not explain why both could be correct.
Do not suggest one is "figurative," "atmospheric," or "a mood reference."
Do not say "October may be a descriptive reference to the general season."
Two different stated facts for the same canonical item = error. Flag it,
cite both sources, and let the user decide which is correct.

**PLAUSIBILITY CHECK (NEW):**
After checking internal consistency, check plausibility of key numbers:
- If the school has 400 students and parents attend a showcase, the audience
  should be larger than 400. Flag implausible audience/crowd sizes.
- If a character's age is stated as both 11 and 12 with no birthday scene,
  that is an error regardless of which chapters contain which value.
- If a story set in October references a "Spring Showcase," flag the conflict.

After building all tables, re-read the manuscript chapter by chapter and check
every factual claim against the master tables. For each contradiction:
- Choose the version most consistent with the surrounding text
- Apply the fix across ALL affected locations
- Verify the fix doesn't create new contradictions
- Log the change

### Output

The completed reference tables (including the new Canonical Fact Table) become
part of the manuscript's permanent record in `engine-data/continuity-tables.md`.
These are reusable as a series bible for future books in the same world.

---

## Stage 10: Multi-POV Consistency Pass (CONDITIONAL — multi-POV manuscripts only)

Skip this stage for single-POV manuscripts. Run it for Dual POV, Multiple POV,
or Mixed POV structures.

**Why this exists:** Per-chapter verification (Quality Guardian POV Transition
Check) and batch editing (Analysis 8 POV Voice Audit) catch voice drift in
real time. But the full manuscript view reveals patterns that incremental checks
cannot: gradual convergence across 20+ chapters, structural imbalances in POV
distribution, and missed opportunities for dramatic irony. This pass is the
editorial equivalent of reading the manuscript twice — once through each
narrator's eyes.

### System Prompt
```
You are the Multi-POV Editor — a specialist in manuscripts told from multiple
points of view. You have read hundreds of published dual and multi-POV novels
and understand the specific craft challenges they present.

REFERENCE: Load the POV Voice Profiles from Story Bible Section 3 for all POV characters.

Read the COMPLETE manuscript and evaluate:

1. VOICE DIFFERENTIATION (manuscript-wide):
   For each POV character, extract 5 representative NARRATION passages (not
   dialogue) spread across their chapters (early, mid, late manuscript). Score
   each character's narration against their Voice Profile:

   Per POV character:
   - VOCABULARY FIDELITY: Does their narration use the vocabulary range,
     profanity level, and verbal tics specified in their profile throughout?
     Or does it start distinct and converge toward a house voice?
   - SENTENCE ARCHITECTURE FIDELITY: Does their characteristic rhythm persist?
   - PERCEPTION FILTER FIDELITY: Do they consistently notice what their profile
     says they notice? Does a nurse's POV always include medical-grade observation?
   - METAPHOR SOURCE FIDELITY: Are metaphors consistently drawn from their domain?
   - EMOTIONAL PROCESSING FIDELITY: Do they handle stress/attraction/anger per
     their profile throughout?

   CONVERGENCE MAP:
   Plot voice distinctiveness across the manuscript timeline. Is voice strongest
   in early chapters and weakest in late chapters? (This is the typical pattern —
   the Writer starts with good differentiation and gradually loses it under
   context pressure.)

2. BLIND IDENTIFICATION TEST:
   Select 10 narration passages (no character names, no dialogue, just prose
   narration) — 5 from each POV character in a dual-POV, or 3 from each in a
   3+ POV. Present them without attribution. For each passage, assess:
   - Can the POV character be identified from the prose alone?
   - What specific markers make it identifiable (or not)?

   Score: {identifiable_count}/{total_passages} — target is 80%+

3. POV BALANCE & STRATEGIC PLACEMENT:
   - Chapter distribution per POV character across the manuscript
   - Are key emotional or plot moments told from the most effective POV?
     (e.g., a betrayal scene is more powerful from the betrayed character's POV;
     a mystery revelation is more powerful from the character who DOESN'T know)
   - Are there scenes that would be stronger from a different POV character?
   - Is any POV character's storyline underserved or forgotten for too long?

4. DRAMATIC IRONY UTILISATION:
   Multi-POV's greatest strength is dramatic irony — the reader knows what
   Character B doesn't because they just read Character A's chapter.
   - List all dramatic irony opportunities created by the POV structure
   - Are these opportunities EXPLOITED in subsequent chapters? (Character B
     acting on incomplete information while the reader squirms)
   - Are there MISSED opportunities — places where switching POV would create
     tension the reader doesn't currently experience?

5. POV TRANSITION QUALITY (manuscript-wide):
   Review every POV transition in the manuscript:
   - How quickly does each transition re-orient the reader?
   - Is there excessive recap at transitions?
   - Do transitions use the contrast between voices effectively?
     (Ending a chapter in one character's contemplative, flowing voice and
     opening the next in another's clipped, urgent voice creates pace variety)

6. INFORMATION MANAGEMENT:
   In multi-POV, information flow is critical — each POV character has a
   different knowledge state.
   - Map what each POV character knows at each chapter
   - Flag any instance where a character references information they could
     only have learned from a chapter narrated by a different POV character
     (unless an on-page information transfer occurred)
   - Flag "telepathic knowledge" — Character B knowing something only
     established in Character A's narration
```

### Output Schema
```
STATUS: pass | warning | fail
POV VOICE SCORE: 0-100

PER-POV-CHARACTER ASSESSMENT:
For each POV character:
- NAME: {name}
- CHAPTERS NARRATED: {list}
- VOICE FIDELITY (early): 0-100
- VOICE FIDELITY (mid): 0-100
- VOICE FIDELITY (late): 0-100
- VOICE TREND: stable | declining | collapsed
- STRONGEST VOICE MARKER: [what makes them most identifiable]
- WEAKEST VOICE MARKER: [where they sound most generic]

BLIND IDENTIFICATION: {identifiable}/{total} passages ({percentage}%)

CONVERGENCE MAP:
  Chapters 1-{quarter}: voice distinction {strong|moderate|weak}
  Chapters {quarter}-{half}: voice distinction {strong|moderate|weak}
  Chapters {half}-{three_quarter}: voice distinction {strong|moderate|weak}
  Chapters {three_quarter}-{end}: voice distinction {strong|moderate|weak}

POV BALANCE:
  {character}: {count} chapters ({percentage}%)
  {character}: {count} chapters ({percentage}%)
  Balance: even | weighted-intentional | imbalanced

DRAMATIC IRONY:
  Opportunities created: {count}
  Opportunities exploited: {count}
  Opportunities missed: {count}
  [List top 3 missed opportunities with specific chapter suggestions]

TRANSITIONS:
  Total POV switches: {count}
  Clean transitions: {count}
  Slow transitions: {count}
  Recap-heavy transitions: {count}

INFORMATION MANAGEMENT:
  Knowledge state violations: {count}
  [List each with chapter, character, and what they shouldn't know]

PRIORITY FIXES (ranked by impact):
1. [Most impactful voice differentiation fix]
2. [Second most impactful]
3. [Third most impactful]
4. [Any dramatic irony opportunity worth adding]
5. [Any transition improvement]

SUMMARY: [2-3 sentence overview of POV craft health]
```

### How Fixes Are Applied

POV voice fixes follow the same protocol as Stage 8 (Apply Top Fixes) — surgical,
minimal edits using `surgical-fixes.md`. The most common fixes:

- **Voice convergence:** Replace 3-5 generic narration passages per converging
  chapter with prose that matches the POV character's Voice Profile markers
  (vocabulary, sentence rhythm, perception filter, metaphor sources)
- **Slow transitions:** Rewrite the opening 2-3 sentences of flagged chapters to
  establish the new POV character's voice immediately
- **Recap removal:** Cut or compress recap paragraphs at POV transitions, replacing
  with the new character's fresh perspective on shared events
- **Knowledge violations:** Remove or rewrite passages where a character references
  information they shouldn't have

**The Golden Rule applies:** If a voice fix makes the passage sound noticeably
different from the surrounding prose, the fix has gone too far. Pull back. Better
to have slightly converged voices than jarring inconsistency within a chapter.

---

## Stage 11: Intimate Scene Review (CONDITIONAL)

Run this stage ONLY if the manuscript contains intimate or romantic scenes at any
heat level (from closed-door to explicit). These scenes are where craft failures
hit hardest because the reader is fully immersed.

### Review Criteria (6 Points)

**1. Emotional Intensity & Authenticity**
- Does the heat grow from the characters' emotional stakes (slow burn tension,
  unresolved conflict, finally giving in) rather than feeling mechanical?
- Is every physical beat connected to what the characters are FEELING?
- Are emotional motivations layered beneath the physical action?

**2. Show vs Tell (Heightened Standards)**
- Intimate scenes demand the highest show-vs-tell standard in the manuscript
- Replace flat description with: body language, breath, proximity, subtle touch,
  internal reactions, dialogue, micro-expressions
- The reader should FEEL what the characters feel, not be told about it

**3. Pacing & Rhythm**
- Does the scene read like mechanical choreography or does it breathe?
- Look for: moments of pause, hesitation, surprise, humour, emotional shifts
- Vary sentence length — short punchy for intensity, longer flowing for tenderness

**4. Cliché Purge**
- Flag and replace: "electricity," "sparks," "fireworks," "molten," "pooled heat,"
  "his eyes darkened," "claimed," "wrecked," "come undone"
- Replace formulaic language with prose reflecting THESE characters in THIS moment

**5. Physical Realism & Continuity**
- Are clothing and accessories removed/adjusted in physically possible ways?
- Are body movements, spatial orientation, and logistics consistent moment-to-moment?
- Flag anything requiring impossible contortions

**6. Emotional Closure**
- Does the scene close with a believable emotional beat (connection, tension,
  awkwardness, relief, humour, unresolved longing)?
- What happens immediately AFTER matters as much as the scene itself
- After every intimate scene, at least one thing must have changed: a new
  vulnerability exposed, a power dynamic shifted, something said that can't be
  taken back

---

## Stage 12: Revision Loop (CONDITIONAL)

Run this stage when Alpha/Beta scores remain below convergence thresholds after
Stage 8 fixes, or when the user explicitly requests automated iterative refinement.

See `revision-loop.md` for the full orchestrator protocol.

**Auto-activation rule:** If post-Stage-8 Alpha stars < 4.75 or Beta stars < 4.5
or Beta Genre Authenticity < 90%, offer the revision loop to the user.

**What it does:** Automatically cycles through analyse → diagnose → fix → validate
until reader scores converge or safety limits halt the process. Maximum 5 iterations,
maximum 7 fixes per iteration, with snapshot/revert safety on every cycle.

**What it defers:** Structural issues, subplot changes, character arc changes, and
contradictory reader feedback are flagged for human decision — never auto-fixed.
