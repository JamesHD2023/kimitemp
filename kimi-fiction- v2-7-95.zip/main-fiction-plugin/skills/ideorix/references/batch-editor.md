---
name: batch-editor
description: "5-chapter batch deep edit protocol — cross-chapter quality analysis and line-level fixes"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->
# Batch Editor Protocol

## File-Write Hygiene (MANDATORY — applies to every chapter file this protocol touches)

This protocol performs cross-chapter Edit / rewrite operations
on chapter files in 5-chapter blocks. The chained-Edit
truncation safeguard documented in `core-pipeline.md` § Chained-
Edit Truncation Safeguard applies in full and is binding here:

- **Prefer Write over chained Edit for chapter-scale rewrites.**
  When the change touches more than half a chapter file, write
  the whole revised chapter once via the bash-heredoc + mv
  pattern rather than accumulating sequential Edit patches.
- **Cap individual Edit replacements at ~2 KB.** Split larger
  rewrites into multiple smaller Edits.
- **Run `scripts/word-count-check.sh` after every chapter file
  this protocol writes or edits**, not just at the end of the
  batch. Truncation caught after one Edit is recoverable;
  truncation that propagates through multiple editorial stages
  may not be.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) before reporting batch success — the
  Edit/Write tool's success return does not confirm on-disk
  integrity, and the Read tool can return cached content that
  masks corruption.

**HARD GATE — BLOCKING.** A truncated chapter file caught at
this stage MUST be repaired (clean Write of the full intended
content, post-write integrity verification) before the batch
report is delivered. This protocol has historically been the
site of silent truncation events; this section is the explicit
counter-protocol.

## Overview

The Batch Editor runs a deep editorial pass on every 5-chapter block of the
manuscript. It catches cross-chapter problems that per-chapter verification
cannot detect: accumulating AI-isms, pacing drift, voice flattening, and
quality degradation.

This is the engine's primary defence against the "Act 3 collapse" — the
consistent pattern where output quality degrades in the second half of a
manuscript due to context pressure and accumulated shortcuts.

## When to Run

**Automatically after every 5th chapter completes its full pipeline cycle.**

The batch editor runs after chapters: 5, 10, 15, 20, 25, 30, 35, 40.
For novellas (16 chapters): after chapters 5, 10, 15, and a final pass on
chapter 16 (partial batch of 1-4 chapters).

The batch editor is NOT optional. It is a mandatory pipeline step, like
per-chapter verification. Do NOT skip it. Do NOT defer it. Do NOT ask
the user if they want to run it.

**Sequence:**
```
Ch 1 → verify → Ch 2 → verify → Ch 3 → verify → Ch 4 → verify → Ch 5 → verify
→ BATCH EDIT (Ch 1-5) → Ch 6 → verify → ... → Ch 10 → verify
→ BATCH EDIT (Ch 6-10) → ...
```

## What It Does

The batch editor performs 7 analyses across the batch (8 for multi-POV
manuscripts), then applies surgical fixes to the weakest chapter. Total time:
comparable to writing one chapter.
The break from prose generation is intentional — it gives the engine editorial
distance from the text it just produced.

---

## Analysis 1: Cross-Chapter AI-ism Audit

Per-chapter AI-ism checks catch individual violations. This audit catches
**accumulation** — patterns that are acceptable once but become a tell when
repeated across 5 chapters.

### System Prompt
```
You are the AI-ism Auditor — scanning {batch_size} consecutive chapters for
accumulated AI-generated prose patterns.

Read all {batch_size} chapters in this batch and count:

ZERO TOLERANCE PATTERNS (should be 0 across the batch):
- "A sense of [emotion]"
- "There was something about [person/place]"
- "Little did [they] know" / "Unbeknownst to [them]"
- "The air was thick with [abstraction]"
- "[They] couldn't help but [verb]"
- "And in that moment, [they] understood..."
- "In that moment"
- "The silence was deafening"
- "Eyes that held [abstraction]"
- "The weight of [abstraction] settled on [their] shoulders"

FREQUENCY-LIMITED PATTERNS (max per BATCH, not per chapter):
- "Something about [person/place]": max 1 per batch
- "The weight of [abstraction]": max 0 per batch (1 per manuscript)
- "Found herself [verb]ing": max 1 per batch
- "The kind of [X] that [Y]": max 1 per batch
- "As though": max 4 per batch
- "It was as if [elaborate simile]": max 1 per batch
- "[Character] filed this away": max 1 per batch
- "Couldn't quite [verb]": max 1 per batch
- "Not for the first time": max 1 per batch

STRUCTURAL PATTERNS (cross-chapter only):
- Triple-beat lists ("the X, the Y, the Z"): max 2 per batch
- Identical chapter opening types: flag if >2 of 5 use the same technique
- Identical chapter ending types: flag if >2 of 5 use the same technique
- Em-dashes: flag ANY occurrence (em-dashes are banned; target is 0 per manuscript)
- "Morning" in chapter openings: flag if >1 in batch
- Same character processing tic repeated: flag if any phrase appears 2+ times
```

### Required Output
```
AI-ISM AUDIT — Batch {N} (Chapters {start}-{end})

ZERO TOLERANCE VIOLATIONS: {count}
  [list each with chapter, quote, and location]

FREQUENCY VIOLATIONS: {count}
  [list each pattern with batch total vs limit]

STRUCTURAL VIOLATIONS: {count}
  [list each with specific chapters and examples]

EM-DASH DENSITY: {rate}/1,000 words — {OK|WARNING|CRITICAL}

BATCH HEALTH: clean | minor-drift | significant-drift | critical
FIXES REQUIRED: [list specific replacements needed]
```

---

## Analysis 2: Pacing Trajectory

Plot the tension and pacing energy across the 5-chapter batch. Detect
flatlines, declining curves, and monotonous patterns that per-chapter
checks miss because they only see one chapter at a time.

### System Prompt
```
You are the Pacing Analyst — evaluating momentum across a 5-chapter batch.

PRIMARY DATA SOURCE: Read the tension tracker file at
`engine-data/tension-tracker.md` — this contains both planned and actual
slider values for every chapter, maintained by the Architect and Arc Analyst.
Use this as the authoritative source rather than reconstructing from
individual brief and verification files.

Read the narrative pacing sliders from the tension tracker. Compare planned vs delivered.

SLIDER TRAJECTORY:
For each of the 6 sliders (Tension, Dread, Emotional Intimacy, Relationship
Tension, Pacing Energy, Humor), plot the values across the batch:

  Ch{start}: T:{} D:{} EI:{} RT:{} PE:{} H:{}
  Ch{start+1}: T:{} D:{} EI:{} RT:{} PE:{} H:{}
  ...

CHECK:
1. FLATLINES — Any slider with the same value (±1) for 3+ consecutive chapters?
   Flag: "Monotonous {slider} — reader will disengage"
2. DECLINING CURVES — Any slider trending downward across the full batch?
   Flag: "{slider} declining — investigate if intentional or drift"
3. ENERGY FLOOR — Did any chapter deliver PE ≤ 3 without a compensating
   high slider (EI ≥ 7 or RT ≥ 7)? Flag: "Dead chapter — no engagement driver"
4. VARIETY — Do all 5 chapters have similar slider profiles? (all within ±2
   of each other on every slider) Flag: "Emotional monotone — batch lacks texture"
5. TRAJECTORY vs STORY POSITION — Is the overall energy appropriate for where
   this batch falls in the manuscript? (Act 1 = building, Act 2 = sustained,
   Act 3 = escalating)
```

### Required Output
```
PACING TRAJECTORY — Batch {N}

SLIDER MAP:
  [table of all sliders across all chapters]

FLATLINES: {count} — [details]
DECLINING CURVES: {count} — [details]
DEAD CHAPTERS: {count} — [details]
VARIETY CHECK: varied | monotonous
STORY POSITION ALIGNMENT: appropriate | under-energised | over-energised

RECOMMENDATION: [specific pacing adjustments if needed]
```

---

## Analysis 3: Prose Craft Trend

Compare prose quality metrics across the batch to detect degradation.
The most common failure mode: early chapters have varied sentence lengths,
rich sensory detail, and distinctive voice. Late chapters converge toward
flat, uniform prose. This analysis catches that convergence.

### System Prompt
```
You are the Prose Craft Analyst — measuring prose quality trends across a
5-chapter batch of {genre} fiction.

For EACH chapter in the batch, measure:

1. SENTENCE LENGTH DISTRIBUTION:
   - Short (1-5 words): {%}
   - Medium (6-15 words): {%}
   - Long (16-25 words): {%}
   - Very long (25+ words): {%}
   Flag if distribution narrows across the batch (variety decreasing)

2. DIALOGUE-TO-NARRATION RATIO:
   - Estimate % of chapter that is dialogue vs narration
   - Flag if ratio is identical (±5%) across 3+ chapters

3. OPENING AND ENDING VARIETY:
   - List each chapter's opening technique and ending technique
   - Flag any repetition within the batch

4. SENSORY DETAIL DENSITY:
   - Count distinct sensory details per chapter (smell, touch, taste, sound, specific visual)
   - Flag if density drops across the batch (detail fatigue)

5. CHARACTER VOICE DISTINCTION:
   - For each character who speaks in 2+ chapters of the batch:
     Could their dialogue be identified without attribution?
   - Flag if voices are converging (sounding more alike)

6. CRAFT COMMANDMENT TREND:
   - For each of the 7 Craft Commandments, is execution improving,
     stable, or declining across the batch?
   - Flag any commandment that has declined for 2+ consecutive chapters
```

### Required Output
```
PROSE CRAFT TREND — Batch {N}

SENTENCE VARIETY: [trend direction] — {details}
DIALOGUE RATIO: [varied | converging] — {details}
OPENING/ENDING VARIETY: [varied | repetitive] — {details}
SENSORY DENSITY: [stable | declining] — {per-chapter counts}
VOICE DISTINCTION: [strong | weakening] — {details}
COMMANDMENT TRENDS: [table of 7 commandments × direction]

WEAKEST CHAPTER IN BATCH: Chapter {N} — Reason: {specific weakness}
OVERALL CRAFT HEALTH: strong | stable | declining | critical
```

---

## Analysis 4: Character Consistency Audit

Check character voice and behaviour consistency across the batch. Per-chapter
verification checks against the story bible. This checks against the character's
own voice in earlier chapters of the batch — detecting drift that happens
gradually rather than as a single contradiction.

### System Prompt
```
You are the Character Consistency Auditor — checking character stability across
a 5-chapter batch.

For each recurring character (appears in 2+ chapters of the batch):

1. VOICE CHECK — Extract 3 representative dialogue lines from each chapter.
   Are they consistent in: vocabulary level, sentence length, verbal tics,
   topic preferences, conflict response style?

2. BEHAVIOUR CHECK — Does the character's emotional register match their arc
   position? A character who was frightened in Chapter {N} shouldn't be casual
   in Chapter {N+1} without an on-page reason.

3. KNOWLEDGE CHECK — Does each character only reference information they have
   learned on-page? Cross-reference with chapter summaries.

4. RELATIONSHIP DYNAMICS — Are the power dynamics between characters consistent
   and evolving appropriately?
```

### Required Output
```
CHARACTER CONSISTENCY — Batch {N}

For each recurring character:
- NAME: {name}
- CHAPTERS PRESENT: {list}
- VOICE STABILITY: consistent | minor-drift | significant-drift
- BEHAVIOUR CONSISTENCY: consistent | unexplained-shift | arc-appropriate-shift
- KNOWLEDGE VIOLATIONS: {count}
- NOTES: {specific issues if any}

OVERALL: consistent | minor-issues | revision-needed
```

---

## Analysis 5: Word Count Trend

Detect systematic under-delivery before it compounds into a short manuscript.

### System Prompt
```
Analyse word count delivery across the batch:

BATCH WORD COUNT:
  Ch {start}: {actual}/{target} ({%})
  Ch {start+1}: {actual}/{target} ({%})
  ...
  Batch average: {%}

TREND: Is the average rising, stable, or falling across the batch?

MANUSCRIPT RUNNING AVERAGE: {%} (all chapters to date)

If batch average < 95%: FLAG — "Batch {N} is running short. The next batch
  Architect briefs should increase dramatization depth and add scene content."

If any individual chapter < 90%: FLAG — "Chapter {N} is a hard miss at {%}.
  Consider surgical expansion before proceeding."

If trend is declining: FLAG — "Word counts are trending downward. This
  typically indicates the Writer is compressing briefs. The next batch's
  Architect must provide more detailed dramatization notes."
```

---

## Analysis 6: Factual Consistency Sweep (NEW — added post-Not a Glitch audit)

Catch factual contradictions that per-chapter verification misses because
agents compare against summaries rather than raw text, and because some
errors only become visible across a multi-chapter span.

**Why this exists:** In Not a Glitch, the story opened in "late October" (Ch1-8)
but shifted to "March" (Ch13, 17, 21) without transition. Nadia was called both
"eleven" and "twelve" — including both values in the same chapter (Ch20). The
AIDEN acronym expanded to "Needs" in Ch1 and "Networking" in Ch17. A "glass of
water" in Ch2 became a "mug of hot chocolate" in Ch3+. None of these were caught
by per-chapter verification, batch editors 1-5, or the editorial suite.

### System Prompt
```
You are the Factual Consistency Auditor — scanning {batch_size} consecutive
chapters for contradictory facts. You reference the entity database and
Story Bible Section 6 as ground truth.

SAME-CHAPTER CHECK:
For each chapter in the batch, search for any factual claim (age, name,
number, date, month, acronym expansion, object description) that appears
with TWO DIFFERENT VALUES within the same chapter.
Example: "She was eleven years old" AND "I'm twelve" in the same chapter
for the same character is always CRITICAL.

CROSS-CHAPTER CHECK:
Compare these canonical facts across all chapters in the batch:
- Character ages (compare against entity database)
- Acronym/abbreviation expansions (compare character-by-character against
  entity database)
- Month/season references (compare against Story Bible MONTHS PERMITTED list)
- School/location names and descriptions
- Recurring object descriptions (compare first appearance against all later
  appearances — a "glass of water" becoming a "mug of hot chocolate" is a
  contradiction even if the object isn't named)
- Numerical claims (student counts, audience sizes, countdown numbers)

CROSS-BATCH CHECK (cumulative):
If this is batch 2+, also compare against facts established in prior batches.
The entity database and Story Bible are the ultimate ground truth.

NEVER RATIONALIZE. Two different values for the same fact is an error. Period.
```

### Required Output
```
FACTUAL CONSISTENCY — Batch {N} (Chapters {start}-{end})

SAME-CHAPTER CONTRADICTIONS: {count}
  For each:
  - CHAPTER: {N}
  - FACT: [what is being stated]
  - VALUE 1: [exact quote] at line {X}
  - VALUE 2: [exact quote] at line {Y}
  - SEVERITY: CRITICAL

CROSS-CHAPTER CONTRADICTIONS: {count}
  For each:
  - FACT: [what is being stated]
  - CANONICAL VALUE: [from entity DB or Story Bible]
  - DEVIATION: [exact quote from chapter]
  - CHAPTER: {N}, line {X}
  - SEVERITY: critical | moderate

ENTITY DATABASE DEVIATIONS: {count}
  For each:
  - FIELD: [which entity field]
  - DB VALUE: [canonical]
  - CHAPTER VALUE: [what the chapter says]
  - CHAPTER: {N}, line {X}

STATUS: clean | issues-found | critical
```

---

## Analysis 8: POV Voice Differentiation Audit (CONDITIONAL — multi-POV manuscripts only)

Skip this analysis if the manuscript uses a single POV character. Run it for
Dual POV, Multiple POV, or Mixed POV structures.

**Why this exists:** In multi-POV manuscripts, narrative voice converges over
time. Early chapters may have distinct voices for each POV character, but by
mid-manuscript the Writer defaults to a single "house voice" regardless of
whose head we're in. This audit catches that convergence before it compounds.

### System Prompt
```
You are the POV Voice Differentiation Auditor — checking whether each POV
character's narration remains distinctly their own across a {batch_size}-chapter
batch of a multi-POV {genre} manuscript.

REFERENCE: Load the POV Voice Profiles from Story Bible Section 3 for each POV
character who narrates in this batch.

For each POV character who narrates 1+ chapters in this batch:

1. VOICE PROFILE COMPLIANCE:
   Extract 3 representative NARRATION passages (not dialogue — the narrating
   voice between dialogue lines) from each of their chapters. Compare against
   their Voice Profile:
   - VOCABULARY: Does the narration use this character's vocabulary range,
     profanity level, and verbal tics? Or has it drifted toward generic prose?
   - SENTENCE ARCHITECTURE: Does the sentence rhythm match the profile?
     (Short/punchy character writing in long flowing sentences = drift)
   - PERCEPTION FILTER: Does this character notice what their profile says they
     notice first? (A nurse POV should flag medical details; if they're noticing
     architecture instead, the voice has drifted)
   - METAPHOR SOURCES: Are metaphors drawn from this character's domain? Or are
     all POV characters using the same metaphor family?
   - EMOTIONAL PROCESSING: Does this character handle tension/attraction/anger
     the way their profile specifies?

2. CROSS-POV CONVERGENCE TEST:
   Take one narration passage from each POV character in this batch. Strip the
   character name and chapter number. Could a reader identify which character is
   narrating from the prose alone?
   - YES for all characters → PASS
   - YES for some, NO for others → FLAG which characters are converging
   - NO for most → CRITICAL: voices have collapsed into a single narrator

3. POV CHAPTER BALANCE:
   Count how many chapters each POV character has narrated across the manuscript
   to date. Flag if:
   - Any POV character has >60% of total chapters (unless the story structure
     intentionally weights one POV — check the outline)
   - Any POV character has had 0 chapters in the last 5 (reader may forget
     their voice and storyline)
   - The rotation pattern has become predictable (strict A-B-A-B when the
     outline specified organic rotation)

4. POV TRANSITION QUALITY (cross-chapter):
   For each chapter that switches POV from the previous chapter:
   - Does the opening paragraph establish the new POV character's voice within
     the first 2-3 sentences?
   - Is there unnecessary recap of the previous POV's events?
   - Does the new POV character have a distinct sensory or emotional entry point?
```

### Required Output
```
POV VOICE AUDIT — Batch {N} (Chapters {start}-{end})

POV CHARACTERS IN BATCH: {list with chapter counts}

VOICE PROFILE COMPLIANCE:
For each POV character:
- NAME: {name}
- CHAPTERS NARRATED (batch): {list}
- CHAPTERS NARRATED (manuscript total): {count}/{total_chapters}
- VOCABULARY MATCH: aligned | drifting | collapsed
- SENTENCE RHYTHM MATCH: aligned | drifting | collapsed
- PERCEPTION FILTER MATCH: aligned | drifting | collapsed
- METAPHOR SOURCE MATCH: aligned | drifting | collapsed
- OVERALL VOICE FIDELITY: 0-100

CONVERGENCE TEST:
- IDENTIFIABLE BY PROSE ALONE: {yes_count}/{total_pov_characters}
- CONVERGING PAIRS: {list any POV characters whose voices are becoming similar}
- CONVERGENCE SEVERITY: distinct | minor-drift | significant-convergence | collapsed

POV BALANCE:
- DISTRIBUTION: {character: count, character: count, ...}
- BALANCE STATUS: balanced | weighted-but-intentional | imbalanced
- GAP FLAG: {any POV character absent too long}

POV TRANSITIONS:
- TRANSITIONS IN BATCH: {count}
- CLEAN TRANSITIONS: {count}
- WEAK TRANSITIONS: {count} — [list chapters with recap or slow re-orientation]

OVERALL POV HEALTH: strong | stable | drifting | critical
FIXES REQUIRED: [specific voice corrections needed]
```

---

## Analysis 7: Batch Health Report

Synthesise all analyses (1-6, plus Analysis 8 if multi-POV) into a single
health report that is saved to disk and displayed to the user.

### Required Output (saved AND displayed)
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  BATCH {N} DEEP EDIT — Chapters {start}-{end}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  AI-ism Health:    {clean|minor-drift|significant-drift|critical}
  Pacing Health:    {strong|stable|declining|critical}
  Craft Health:     {strong|stable|declining|critical}
  Character Health: {consistent|minor-issues|revision-needed}
  Factual Health:   {clean|issues-found|critical}
  POV Health:       {strong|stable|drifting|critical|n/a (single POV)}
  Word Count:       {batch_avg}% of target ({trend})

  Weakest Chapter:  Chapter {N} — {reason}
  Fixes Applied:    {count} surgical fixes

  Batch Score:      {composite}/100

  Manuscript Progress: {chapters_done}/{total} chapters
  Running Score:       {avg_score}/100
  Running Words:       {word_avg}% of target

  Next batch: Chapters {next_start}-{next_end}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**SCORE CEILING:** A batch score of 100/100 is not permitted. No batch of prose
is flawless. If the composite calculation returns 100, cap it at 99 and add an
advisory note: "Perfect score capped — verify scrutiny depth."

Save to: `engine-data/reports/batch-{N}-edit.md`

---

## Fix Protocol

After the 7 analyses complete:

1. **Identify the weakest chapter** in the batch (lowest craft health + most issues)
2. **Apply surgical line-level fixes** to that chapter using `surgical-fixes.md`:
   - Fix all AI-ism violations found in Analysis 1
   - Remove all em-dashes (they are banned; replace with commas, periods, colons, etc.)
   - If voice is drifting, revise 3-5 dialogue lines to restore character voice
   - If sensory density is declining, add 2-3 specific sensory details
   - If POV voice convergence detected (Analysis 8), revise 3-5 narration passages
     in converging chapters to restore the POV character's distinctive voice markers
     per their Voice Profile
3. **Apply AI-ism fixes across all chapters** — zero-tolerance violations must be
   fixed in every chapter, not just the weakest
4. **Save revised chapters** to disk and verify with Read tool
5. **Update the pipeline checkpoint** with batch edit status
6. **Re-run mechanical verification on every revised chapter** — after
   saving revised chapters, run `scripts/ideorix-audit.sh` on each chapter
   the batch touched. Any FAIL (em-dashes, forbidden words, formatting
   caps) must be fixed before the batch is marked complete. Rationale: a
   batch edit rewrites prose and re-introduces em-dashes; the per-chapter
   checks do not auto-re-run after a batch edit; this catches batch-
   introduced violations including Bash-heredoc edits the Write/Edit hook
   doesn't see.

### What NOT to Do
- Do NOT rewrite entire chapters — fixes are surgical
- Do NOT change plot, character decisions, or story events
- Do NOT add new scenes or remove existing ones
- Do NOT fix problems in chapters outside this batch
- Do NOT spend more than ~15 minutes on fixes — this is a tuning pass, not a rewrite

---

## Feeding Forward

After the batch edit completes, the results feed into the NEXT batch's
generation via TWO channels, each with different durability:

### Channel A — Running Banlist (permanent, Writer-facing opening constraints)

Patterns detected by the Batch Editor are written into
`engine-data/running-banlist.md` under the same protocol the Humaniser
uses (see `prose-humaniser.md` "Running Banlist"). This is the ONLY
channel that is guaranteed to land at the top of future Writer prompts
as opening hard constraints.

1. **AI-ism patterns found** → Write to the Running Banlist with promotion
   trigger "batch editor feed-forward". If the pattern appeared in 2+
   chapters within the batch, promote DIRECTLY to HARD CONSTRAINTS
   (skipping WATCHLIST — the Batch Editor sees 5 chapters of data at
   once, so consecutive-chapter detection is immediate). If the pattern
   appeared in exactly 1 chapter of the batch, add to WATCHLIST.
   Use the Writer-facing "Rule" field to state the zero-tolerance rule
   verbatim as the next chapter's Writer will read it.

2. **Per-chapter surgical-fix recurrence** → If the same pattern needed
   surgical fixes in 2+ chapters of the batch (the failure mode that
   motivated this system), it is PROMOTED to HARD CONSTRAINTS with a
   "recurring fix burden — {N} chapters" note in the Rule field. This
   is the production-failure signal — if the user had to apply the same
   surgical pattern twice, the Writer is not learning from feed-forward
   and the pattern needs to become an opening hard constraint on the
   next chapter.

3. **Batch-wide breach of existing HARD CONSTRAINTS** → If a pattern
   already in HARD CONSTRAINTS appeared in the batch, log it as a breach
   (see `prose-humaniser.md` Breach Reporting). Breach logs prefix the
   pattern's Rule field with "⚠ REPEATED BREACH — {N} breaches".

### Channel B — Batch-level corrections (advisory, one-batch lifespan)

Corrections that don't fit the pattern-ban shape (pacing, structural,
per-character voice) feed forward as advisory notes for the NEXT batch
only. These do NOT land in the running banlist because they are not
zero-tolerance rules — they are batch-specific corrections.

1. **Pacing issues** → If flatlines or declining energy were detected,
   flag in the next Architect brief: "Previous batch had {issue}. This
   chapter must {correction}."

2. **Craft decline** → If sentence variety narrowed or sensory density
   dropped, add to the Writer prompt for the next batch: "Sentence length
   distribution has narrowed. Actively vary: include at least 3 sentences
   over 20 words and 5 sentences under 5 words per scene."

3. **Word count trend** → If batch average < 95%, the next batch's
   Architect briefs must include expanded dramatization notes with
   coverage validation ≥ 90%.

4. **POV voice drift** (multi-POV only) → If convergence was detected,
   add to the Writer prompt for the next batch: "POV voice audit detected
   convergence between {characters}. For {character}'s chapters,
   emphasise: {specific markers from their voice profile}. The narration
   must pass the blind identification test."

### Why two channels

Channel A is permanent and dominates the next chapter's Writer prompt
opening — used for patterns the Writer must NEVER produce again (zero
tolerance). Channel B is advisory and lives one batch — used for
corrections that are relative to batch conditions (pacing, voice
convergence, word count trend) and don't make sense as standing rules.

**Production rule:** if a surgical pattern needs to be fixed in 2+
consecutive chapters, it is NOT a Channel B advisory — it is a Channel A
hard constraint. The recurring fix burden IS the promotion signal. See
`prose-humaniser.md` Promotion Protocol for the full rules.

This feed-forward loop is the mechanism that prevents quality degradation
from compounding. Each batch edit produces specific, actionable
corrections that shape the next batch's generation — and the recurring
patterns land at the TOP of the next Writer prompt as opening hard
constraints, not buried in advisory notes.

---

## Partial Batch Handling

For manuscripts where chapter count isn't divisible by 5 (e.g., 16 chapters):
- Run on chapters 1-5, 6-10, 11-15 normally
- Run a final partial batch on chapter 16 (or chapters 16-18, etc.)
- The partial batch still runs all 6 analyses but calibrates frequency limits
  proportionally (e.g., a 1-chapter "batch" has 1/5 the frequency limits)

For the FINAL batch (partial or full): also run a manuscript-wide tension
trajectory check (see `quality-gate.md` — Cross-Chapter Tension Tracking)
to ensure the overall arc is sound before proceeding to Phase 5 (Editorial).
