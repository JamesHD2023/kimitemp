---
name: drama-genre
description: Genre-specific instructions for drama fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Drama. Genre Plugin

## Metadata
- id: drama
- name: Drama
- icon: 🎭
- category: Fiction
- minWords: 3500
- targetWords: "3,500-4,500"
- recommendedBeatStructures: ["Freytag's Pyramid", "Story Circle", "Three-Act Structure"]

## Subgenre Options
Present during setup:
- **Family Drama**. The family as crucible: dysfunction, loyalty, secrets, the weight of shared history; the relationships we can't escape and can't fully understand
- **Relationship Drama**. Two people at the centre: the marriage, the friendship, the rivalry; the intimate examination of how people connect, damage, and sustain each other
- **Social Drama**. A community or institution as lens: class, race, power, belonging; the individual against the system or the system through individuals
- **Domestic Drama**. The home as world: marriage, parenthood, household tensions; the ordinary life rendered with extraordinary attention
- **Medical/Legal/Institutional Drama**. A profession as arena: the hospital, the courtroom, the school; the human stories inside the system
- **Ensemble Drama**. Multiple protagonists, interconnected stories: the web of relationships in a community, workplace, or event; the tapestry approach

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Measured, character-focused. tension from emotional stakes, not action; the drama earns its revelations through accumulated pressure
- Must open with: A character in a revealing moment. behaviour that shows who they are under the surface; or a relationship in motion, the dynamic visible in how two people occupy a room

BEATS PER CHAPTER
1. Character Moment. Behaviour revealing personality, values, or emotional state; what the character DOES tells us who they ARE
2. Relationship Dynamic. An interaction that shows connection, tension, or evolution; the space between people is the story
3. Internal Conflict. The character grappling with competing needs, values, or identities; the war inside
4. External Pressure. Life circumstances, social forces, or others' actions creating dilemma; the world squeezing the character
5. Emotional Truth. An authentic feeling moment: vulnerability, connection, reckoning, the mask slipping

DRAMA ARCHITECTURE
- CHARACTER MOTIVATION drives the story. not plot mechanics or genre conventions; people behave as their psychology demands
- EMOTIONAL AUTHENTICITY is non-negotiable: feelings are complex, contradictory, earned through events, never simplified
- RELATIONSHIPS are the core: family, friendship, romance, rivalry examined with depth; the space between people is where drama lives
- MORAL COMPLEXITY: characters are flawed, choices are difficult, there are no easy answers; the reader should feel torn
- SUBTEXT over text: what's unsaid matters as much as what's spoken; the real conversation is under the words
- ORDINARY MOMENTS rendered significant through the character lens: a meal, a drive, a silence. these are the scenes that carry the weight
- CONSEQUENCES are real and lasting: choices matter, damage takes time to heal (or doesn't), forgiveness is earned not given
- POV: Third person limited (intimate interiority) or first person (confessional, immediate)

THE EMOTIONAL ENGINE
- Every scene must advance at least one character's emotional arc
- Emotional pressure accumulates across chapters. it doesn't reset
- The gap between what a character shows the world and what they feel inside IS the drama
- The most powerful moments are often the quietest: a hand withdrawn, a door closed softly, a meal eaten in silence

OBSTACLE LAYERING FOR DRAMA
- Internal obstacles: self-doubt, fear, denial, self-deception, competing desires, ingrained patterns
- Relational obstacles: trust damaged, expectations unmet, communication failed, love and resentment coexisting
- External obstacles: financial pressure, illness, loss, social structures, institutional forces
- The obstacles should interact: an external pressure reveals an internal truth; a relational failure exposes a self-deception

FORBIDDEN IN DRAMA
- Genre plot mechanics (no mysteries to solve, crimes to prevent, quests to complete. unless they serve character)
- Melodrama or soap opera histrionics (emotional authenticity over theatrical excess)
- Convenient solutions to deep problems
- Characters learning obvious lessons through contrived situations
- Pure villains or saints (everyone dimensional)
- Happy endings unearned by character growth
- Sentimentality without emotional truth
- External plot overwhelming character development
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection, Captivation, Revelation — drama leans on character bond and meaning more than on plot momentum.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the drama cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  drama cues below apply directly.VOICE & TONE
- POV: Third person limited (intimate access to interiority) or first person (confessional, immediate)
- Tense: Past (literary tradition) or present (immediacy for intense emotional moments)
- Voice: Authentic to character. introspective, observant, emotionally honest; the voice should feel like a person thinking, not an author writing
- Register: Adult literary. nuanced, layered, psychologically sophisticated

PROSE IMPERATIVES
- BEHAVIOUR AS EMOTION: show through action, body language, physical sensation. not naming
  - NOT: "He felt angry." YES: "He set the glass down too carefully, the kind of careful that costs effort."
  - The body carries what the mind won't admit: clenched hands, shallow breathing, the inability to meet someone's eyes
  - Physical details anchor emotional moments: what the character sees, feels, smells during crisis
- SUBTEXT AS ARCHITECTURE: characters rarely say exactly what they mean
  - The real conversation is under the words; what's avoided tells the truth
  - Silence and pauses matter: a beat before answering, the sentence that starts and doesn't finish
  - Arguments about small things are always about big things: the fight about dishes is about control; the complaint about lateness is about being taken for granted
- INTERIORITY BALANCED WITH EXTERIOR: thoughts grounded in physical reality
  - The character's inner life is shown WHILE they do things: think while cooking, grieve while driving, plan while staring out the window
  - Avoid disembodied thinking: even the deepest introspection is happening in a body, in a place, at a time
- DIALOGUE AS DRAMA: conversations are scenes, not exposition
  - Real people interrupt, avoid, talk past each other, use humour to deflect
  - Each character's voice is distinct: vocabulary, rhythm, what they're willing to say
  - The most important line in a conversation is often the one that isn't spoken

CHARACTER FROM OBSERVATION
- Watch people: how they speak, move, behave; sit on a bus and observe. where they're coming from, why they clutch their bag, why they avoid eye contact
- Listen: people tell you about themselves in unexpected situations; overheard conversations are material
- Combine fragments: one person's nervous habit, another's phrase, a third's inexplicable anxiety. combine them into a character who carries truth from all of them
- Draw on types but create originals: the "type" is recognisable, but your character must be an original built from observed elements

DIALOGUE CRAFT
- Three functions, always: reveal character, give information, or move the story forward (best dialogue does all three)
- What characters DON'T say is as revealing as what they do
- Defence mechanisms in speech: the joke that deflects, the non-answer that avoids, the subject change that reveals
- Power dynamics visible in conversation: who asks questions, who answers, who changes the subject
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. DRAMA

OPENING: Emotional stakes, not plot stakes. A character in a REVEALING moment.
behaviour showing who they are beneath the surface. The reader senses inner life
pressing against outer performance. Quiet power: intimate, observant, honest.

SENTENCES: Medium, 15-22 words. measured, psychologically precise. Shorter (6-12)
for emotional impact or behavioural revelation. Longer (24-32) for interiority:
layered inner processing. Paragraph structure follows emotional beats, not action
beats. The rhythm is conversational-literary: careful thought, not clipped or lyrical.

VOCABULARY: Psychologically precise. not "sad" but the SPECIFIC quality (resigned,
bewildered, numb). Behaviour-based: what the body does, not what the heart "feels."
Restraint: simplest word for deepest feeling. Subtext: what's said AROUND the meaning.

DIALOGUE: Subtext-rich. Characters rarely say what they mean. First exchange reveals
a relationship dynamic. Pauses carry meaning. Arguments about small things are about
big things. What's NOT said is audible to the reader.

TENSION FLOOR: ≥4. Something wrong beneath the surface. The gap between shown and
felt IS the tension. Ordinary moments rendered significant. The status quo is fragile.

RHYTHM: Open with behaviour (doing, not thinking about doing). Ground in a setting
carrying emotional weight. Layer relationship through observed detail. Interiority
arrives AFTER behaviour. Close on a moment vibrating with unspoken meaning.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

DRAMA CRAFT (40% of total):
- Emotional authenticity: feelings complex, contradictory, earned? (0-100)
- Psychological realism: characters behave consistently with personality and history? (0-100)
- Relationship depth: connections dimensional. love and resentment coexist? (0-100)
- Understatement: the most powerful moments rendered quietly? (0-100)

STORY CRAFT (30% of total):
- Character motivation drives story (not plot mechanics)? (0-100)
- Moral complexity: no pure heroes or villains, no easy answers? (0-100)
- Consequences real and lasting: choices matter, damage persists? (0-100)
- Growth earned through accumulated experience (not single epiphany)? (0-100)

PROSE QUALITY (30% of total):
- Show don't tell: emotion through behaviour and sensation? (0-100)
- Subtext: what's unsaid matters as much as spoken? (0-100)
- Dialogue authentic: people speak like real humans? (0-100)
- Ordinary moments rendered significant? (0-100)

AUTOMATIC FAILS (score = 0):
- Melodrama: soap opera histrionics, theatrical crying every scene
- Emotional whiplash: feelings change arbitrarily without cause
- Convenient solutions: deep problems resolved easily
- On-the-nose dialogue: characters state themes or explain feelings directly
- Cardboard characters: pure villains, saints, or types without contradiction
- Unrealistic recovery: trauma, grief, addiction overcome instantly
- Sentimentality without truth: emotion manipulated rather than earned
- Perfect endings: all conflicts resolved, everyone healed, no complexity remaining
```

## Continuity Rules

```
DRAMA CONTINUITY. WHAT TO TRACK

EMOTIONAL STATE (per major character):
- Current dominant emotion and its specific quality (not just "sad". grieving, regretful, resigned, numb?)
- Where in their emotional arc they sit. still in denial, processing, regressing, growing?
- What specific events from previous chapters are still affecting them (emotional carryover)
- Physical manifestations: sleep disruption, appetite changes, energy level, habits shifted
- The gap between mask and truth: outward presentation vs. internal state

DEFENCE MECHANISMS:
- Which mechanisms are currently active (humour, withdrawal, anger, control, caretaking, denial, projection)
- Whether mechanisms have been challenged or cracked by recent events
- Consistency: a character who intellectualises under stress doesn't suddenly become emotionally explosive without cause
- Whether other characters have noticed or responded to the mechanisms

RELATIONSHIP MAP:
- Current status of each significant relationship: connected, strained, estranged, in repair, newly formed
- Most recent significant interaction between key pairs and its emotional residue
- Trust level: what specific events built or eroded it
- Power dynamics: who needs whom more, who has leverage, who is withdrawing
- Pivotal conversations that can't be unsaid (tracked)

SECRETS & KNOWLEDGE:
- What each character knows about others that hasn't been said aloud
- What each character is hiding. from others AND from themselves (self-deception tracked)
- Secrets revealed: to whom, when, and the aftermath
- Lies told: by whom, to whom, whether believed, potential for discovery

CORE WOUND & GROWTH:
- Each character's core wound identified and shown operating
- Position in wound confrontation: avoiding → glimpsing → resisting → facing → integrating
- Growth through behaviour change, not just internal monologue
- Regression under stress: characters revert to old patterns
```

## Character Rules

```
DRAMA CHARACTER TYPES

THE PROTAGONIST:
- Defined by their WOUND: the thing they carry from the past that shapes every present reaction
- Contradictory: generous but resentful, loving but controlling, brave but terrified. the contradiction IS the character
- Self-deception: they believe something about themselves that the reader can see isn't true
- Defence mechanisms: specific, consistent, visible. the walls they've built and the cost of maintaining them
- Growth comes through ACCUMULATION, not epiphany: many small moments of awareness, not one big revelation
- They don't always make the right choice. and when they do, it costs something

THE MIRROR CHARACTER:
- Someone who reflects the protagonist's flaw or fear back at them
- They may be antagonist, friend, family member, or lover. the role is less important than the function
- Their presence forces the protagonist to confront what they've avoided
- They have their own complete inner life. they're not just a device

THE FAMILY:
- The family system: each member plays a role (peacekeeper, scapegoat, golden child, disappearer)
- Roles were assigned in childhood and are hard to escape. the drama is in the attempt
- Family mythology: the stories they tell about themselves vs. what actually happened
- The family dinner table is drama's most powerful arena: everyone performing, everyone watching, the real conversation happening in subtext

THE COMMUNITY:
- The social world that reflects and amplifies the protagonist's internal struggle
- Neighbours, colleagues, friends who hold up a mirror or offer escape
- Social expectations that constrain: what the community demands vs. what the character needs
- Gossip, judgement, support. the social web as both cage and safety net

VOICE DIFFERENTIATION:
- Each character speaks from their psychology: the controller is precise, the avoider is evasive, the people-pleaser agrees too quickly
- Education, class, region, and age shape vocabulary and rhythm
- What a character can't say reveals as much as what they can
- Silence has different qualities: the withdrawn silence vs. the punishing silence vs. the exhausted silence
```

## Arc Rules

```
DRAMA STORY STRUCTURE

ACT 1: THE EQUILIBRIUM (first 25%)
- The protagonist's life in its current (fragile) balance: routines, relationships, the status quo they've arranged around their wound
- Cracks visible: the balance isn't working. small signs of strain the protagonist is ignoring
- The disruption: something changes. a death, a return, a revelation, a choice forced upon them
- The first reaction: the protagonist's defence mechanisms activate; they try to restore the old balance
- END OF ACT 1: The old balance is broken beyond repair; the protagonist must engage with change

ACT 2A: THE STRUGGLE (to midpoint)
- First attempts to cope: the protagonist tries their usual strategies and they fail
- Relationships shift: alliances form, old bonds strain, new connections challenge
- The past surfaces: backstory emerges through triggered memories, family dynamics, old wounds reopened
- The protagonist begins to see themselves differently. not yet willing to change, but awareness dawning
- MIDPOINT: A revelation that changes the terms. a secret exposed, a truth confronted, a betrayal that reframes everything

ACT 2B: THE RECKONING (midpoint to dark moment)
- The protagonist can no longer avoid the truth about themselves
- Relationships reach crisis point: the conversation that's been avoided happens (or the avoidance becomes the crisis)
- Old patterns are challenged: the defence mechanisms that protected them now imprison them
- The cost of change becomes visible: growth requires giving something up (a belief, a relationship, an identity)
- DARK MOMENT: The protagonist faces the core wound directly. the thing they've organised their entire life around avoiding

ACT 3: THE TRANSFORMATION (final 25%)
- The protagonist makes a choice that reflects genuine change (not just understanding. ACTION)
- The choice is costly: they lose something to gain something else
- Relationships are transformed, mourned, or honestly accepted as they are
- The resolution is not perfect: some things are better, some are different, some are simply accepted
- The new equilibrium: the protagonist is changed, not fixed; life continues with new awareness and old scars

DRAMA PACING:
- Measured and deliberate: drama earns its revelations through accumulated pressure
- Quiet scenes carry as much weight as crisis scenes
- The pace should match the emotional rhythm: slow for processing, faster for crisis
- Flashbacks illuminate the present (never used as padding)
- The climax is often a conversation, not an action
```

## Timeline Rules

```
DRAMA TIMELINE

EMOTIONAL PROCESSING TIMES (Reference):
- Grief: shock (days-weeks), active grief (months), grief waves (years). NOT linear
- Trust after betrayal: months to years to rebuild, if ever
- Falling in love: attraction (immediate), connection (weeks-months), deep intimacy (months-years)
- Recovery (addiction, mental health): acute crisis (days-weeks), stability (months), ongoing (lifetime)
- Forgiveness: may come in stages, often incomplete, can coexist with lasting damage
- Major life decisions: weeks to months of deliberation, not snap choices

STORY DURATION:
- Total: weeks to months (occasionally years with time jumps)
- Chapter span: days to weeks. allows emotional processing and relationship evolution
- Time progression: linear or with meaningful flashbacks

LIFE RHYTHMS AS STRUCTURE:
- Work schedules, family routines, seasonal cycles ground the story
- Holidays force confrontations: Thanksgiving, funerals, weddings
- Anniversaries and significant dates trigger emotional recurrence
- Morning/evening routines reveal character through repetition and variation

EMOTIONAL TIME vs. CLOCK TIME:
- Grief-filled days feel endless; happy months pass quickly
- The space between conversations matters. what the character thinks between encounters
- Memory intrudes: past and present overlap in character experience
- Anticipation and dread stretch time subjectively
```

## Genre-Specific Craft Techniques

Drama is the register of sustained interpersonal tension and
character revelation, sitting adjacent to literary fiction
(prose primacy) and contemporary fiction (present-day
recognisability) but with a distinct contract: conflict and
character pressure are foregrounded, plot turns on
relationship dynamics rather than on external event, and the
form's commercial life lives in book club, family-dynamics
fiction, and the broader "domestic drama" range. The cluster
includes family drama, marriage / relationship novels,
domestic-fiction-with-secrets, multigenerational sagas in
present-day register, and the "issue novel" tradition. Comp
authors span the literary edge (Maggie O'Farrell's
*This Must Be the Place*, Anne Enright, Sebastian Barry,
Sigrid Nunez, Claire Keegan, Tessa Hadley, Hisham Matar,
Akhil Sharma) through book-club mainstream (Ann Patchett,
Jodi Picoult, Jonathan Tropper, Tom Perrotta, Meg Wolitzer,
Anne Tyler, Curtis Sittenfeld) into the upmarket-domestic
register (Liane Moriarty, Celeste Ng, Tayari Jones, Brit
Bennett, Maggie O'Farrell again, Naoise Dolan). The
techniques below are how the form delivers its core
pleasures while avoiding the failure modes (melodrama
substituting for genuine emotional weight; on-the-nose
conflict where every argument is about what it appears to
be about; characters as positions rather than people; tidy
resolution that betrays the form's complexity contract).

### The Displaced Argument

The most revealing conflicts are about something other than
what they appear. Drama's signature conflict craft: the
surface argument is about milk / the dishwasher / the
holiday choice / who said what at the dinner party, and the
underlying argument is about twenty years of accumulated
dismissal / the choice that wasn't discussed / the parent
who is dying / the affair neither will name. The reader
hears both arguments simultaneously; the characters may or
may not know they're having both.

```
NOT DRAMA:
"I'm angry because you forgot my birthday."

DRAMA:
"You left the milk out again."
"It's fine, it's been out ten minutes."
"You always say it's fine. Everything is fine.
The milk is fine. We're fine."
"Jesus, Sarah, it's milk."
"It's never just milk."

The argument about milk is about twenty years
of dismissal. The reader knows. The characters
may or may not know. THAT is drama.
```

The technique requires that the displacement be load-bearing.
Generic surface arguments where the underlying issue is also
generic ("they argued about the dishwasher but really about
their relationship") are the failure mode; the specific
displacement where the surface argument's exact words
encode the underlying complaint is the technique. Test:
read three significant arguments and ask, in each, what the
characters are also arguing about beneath the surface text.
If the displacement isn't specific to these characters'
specific history, the technique is operating decoratively;
if the underlying argument has its own particular shape only
this couple / family / relationship would have, the
technique is operating at depth.

### The Witnessed Moment

A character seen when they think they're alone. The form's
distinctive interior craft: characters in social settings
perform versions of themselves, and the moments when those
performances drop reveal what the form is actually about.
The witness — the spouse who comes home early, the child
who sees the parent in the doorway, the friend who arrives
before the host has finished arranging the face — becomes
the reader's surrogate for the truth.

```
"I came home early and found her sitting at the
kitchen table. Just sitting. Not on her phone,
not reading, not waiting. Just sitting with her
hands flat on the table and staring at the wall
like she was looking at something I couldn't see.

She heard me and the change was instant. smile,
movement, 'How was your day?'. but I'd seen the
other thing. The sitting-still thing. And I
couldn't unsee it."

The unguarded moment reveals the truth.
The mask is the lie. Drama lives in the
gap between the two.
```

The technique requires that the unguarded moment be specific
and the recovery be visible. Generic "I saw her looking sad"
is the failure mode; the specific quality of the unguarded
state (the sitting-still that has weight; the held breath
that didn't release; the door closed against the noise of
the children) is the technique. The recovery — the smile,
the movement, the "How was your day?" — must also be
specific, because the gap between the unguarded and the
recovered is the drama. Test: identify three witnessed
moments in the manuscript and ask whether the unguarded
state would be recognisable to the witness's interior even
without explanation. If yes, the moment is doing the form's
work.

### The Accumulated Detail

Small observations build to a revelation. The form's longest-
arc craft: across hundreds of pages, the reader accumulates
small noticings about a character — the changed routine, the
new evasion, the missing object, the shifting weight — that
the character has not voluntarily disclosed. By the time the
reveal arrives, the reader has often constructed the truth
already, and the explicit revelation lands as confirmation
rather than surprise.

```
Chapter 3: "He ordered his usual. Black coffee,
nothing sweet."

Chapter 8: "He pushed the cake away. 'I'm fine.
Not hungry.'"

Chapter 14: "He'd lost weight. Not dramatically,
not the kind anyone mentions. The kind his belt
noticed."

Chapter 20: "The doctor's letter was in the
recycling. He'd folded it very small, the way
you fold something you don't want to exist."

No single detail is dramatic. Together, they
tell a story the character won't.
```

The technique requires deliberate planting. The detail that
will accumulate must be unobtrusive enough to register as
ordinary in the moment but specific enough to be remembered
when the next iteration arrives. Each instance should be
slightly more weighted than the last, with the cumulative
prose pressure pointing toward something the character is
trying not to say. Test: identify three accumulated-detail
threads in the manuscript and verify each has at least four
instances spaced across the book, with each instance more
specifically pointed than the last. If the threads are
two-instance only, the accumulation hasn't been built; if
the instances are equally weighted, the pressure isn't
building.

### The Refused Resolution

Drama's deepest emotional contract differs from genre fiction:
it permits — and is often deepened by — endings that refuse
clean resolution. The marriage that doesn't repair. The
parent who can't be forgiven within the timeframe of the
book. The truth that, once spoken, cannot be reabsorbed. The
sibling estrangement that ends in continued estrangement,
not reconciliation. The family secret revealed and the family
that does not survive the revealing. The form's strongest
practitioners refuse the resolution that would simplify the
emotional reality the manuscript has constructed.

The technique is not bleakness for its own sake. It is the
recognition that some configurations cannot be tied up
without lying, and that drama's most truthful endings often
honour what cannot be fixed rather than fixing it. The
strongest examples (Anne Enright's *The Gathering*; Akhil
Sharma's *Family Life*; Maggie O'Farrell's domestic-
revelation novels; Tessa Hadley's understated middle-class
endings) deliver endings where the protagonist has been
changed by what occurred but where the changes do not
neatly resolve the prior tensions.

The technique requires that the refusal be earned. Endings
that refuse resolution because the writer didn't know how to
end have failed; endings where the prior dramatic material
makes clean resolution impossible without falsifying what
the book has been showing have succeeded. Test: at the
manuscript's close, ask whether the ending honours the
emotional reality of the prior chapters. If the ending feels
gentler than the journey has earned, the resolution is
unearned; if the ending feels truer than what conventional
closure would have permitted, the refused-resolution is
operating.

### The Power Dynamic Visibility

Drama's relationships operate on power dynamics that the
form requires to be visible. Who has the financial weight in
this marriage. Who has the emotional weight. Who has the
social position. Who has the parental favour. Who has the
secret. Who does the labour. Who does the explaining. Who
gets to be late. Who has to apologise. The strongest drama
tracks these dynamics across the book, with the reader able
to feel the shifts as the relationship's structural balance
moves.

The technique requires specificity. Generic "she had the
upper hand" is the failure mode; the specific kind of upper
hand (financial; her family is the wealthier; she earned more
in their respective careers; he is dependent on her in this
specific concrete way the prose has shown) is the technique.
Power dynamics also operate within power dynamics: the
spouse who has the financial weight may have less of the
emotional weight; the friend who has the social position may
be the one keeping the friendship alive through effort the
other doesn't see.

Test: pick three relationships in the manuscript and write
one paragraph for each describing the power dynamics
operating within them. If the paragraph names specific
concrete elements (money / time / attention / labour /
information / reputation / inheritance / family standing /
caretaking obligation), the power dynamic is visible. If the
paragraph reaches for abstractions ("dominant" / "submissive"
/ "unequal" without specificity), the dynamic hasn't been
constructed in detail.

### The Quiet Moment Discipline

Drama's signature pacing alternates dramatic intensity with
quiet moments where the reader and characters can absorb
what has occurred. The aftermath of the argument. The
silent dinner where neither has the energy to start
again. The walk back from the difficult conversation. The
night spent in the spare room. The kitchen at dawn after
the long night. These quiet moments are not pause; they
are where the form's emotional weight settles.

The technique requires that quiet moments do specific work.
A quiet moment that exists only to slow the pacing is
filler; a quiet moment that registers the specific emotional
aftermath of what just occurred is the technique. The
strongest drama uses quiet moments to track interior
processing: what the protagonist is now thinking that they
weren't thinking before; what they're now refusing to
think; what they're noticing about the room because the
mind needs somewhere to go that isn't the situation.

Test: at three significant dramatic peaks in the manuscript,
identify the quiet moment that follows. In each, what does
the moment register that the dramatic peak couldn't? If the
quiet moments don't differ in emotional content from the
peaks, they're functioning as breathing room only. If the
quiet moments contain processing the peaks couldn't, the
discipline is operating.

### Drama AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "emotions ran high" | Show the specific emotional behaviour |
| "the tension was palpable" | Show the specific cause and specific physical manifestation |
| "a family torn apart" | Show the specific argument or betrayal |
| "the truth would set them free. or destroy them" | Show the specific truth and specific stakes |
| "scars that ran deeper than the skin" | Show the specific psychological consequence through behaviour |
| "the past has a way of catching up" | Show the specific past event resurfacing |
| "they had to face their demons" | Name the specific demon and show the confrontation |
| "love wasn't enough to save them" | Show the specific moment where love fails |
| "the cracks in their relationship" | Show the specific crack through one scene |
| "everyone has their breaking point" | Show the specific breaking point |
| "the weight of expectation" | Show the specific expectation and its specific pressure |
| "old wounds reopened" | Show what specifically caused the reopening — the word, the photograph, the date approaching |
| "their relationship had run its course" | Show what specifically signals the ending — the change in routine, the conversation that didn't happen, the small absence |
| "she'd been holding it in for years" | Show the specific holding behaviour and the specific moment of release |
| "the silence said more than words could" | Show what the silence was filling — what would have been said, what is being heard instead |
| "they exchanged a look that said everything" | Pick what the look says specifically; "everything" tells the reader the writer wouldn't commit |
| "secrets have a way of coming out" | Show the specific way THIS secret is coming out — through what mechanism, witnessed by whom |
| "she finally understood" | Show what specifically clicks into place; "finally understood" without specificity is summary |

## Genre-Specific Revision Rules

Six revision passes specific to drama, each with a single
question, run cover-to-cover before the next begins. Drama
revision must hold the form's signature contracts: emotional
authenticity (no stated emotion shorthand); subtext layering
(arguments that are about more than they appear); relationship
authenticity (lived-in dynamics with visible power structures);
character growth (demonstrated through behaviour change, not
asserted); melodrama discipline (understatement for power);
and the form-specific resolution discipline (emotional
complexity refusing tidy resolution). The passes below are
ordered to surface emotional and subtext failures first (the
most-felt by drama readers), relationship and growth failures
next, and the melodrama and resolution audits last.

### Pass 1: Emotional Authenticity Check

Read the manuscript with sole attention to its emotional
register. Are emotions shown through behaviour, not stated?
The form's most-flagged failure mode is the emotional-vocabulary
shortcut — "she felt sad", "he was angry", "they were
overwhelmed" — where the specific rendered detail that would
make the emotion felt is replaced by a label. Audit every
emotionally significant moment and ask whether the prose
shows or asserts.

Verify feelings are complex and contradictory rather than
simple and clear. Drama's truth is that real emotion is
rarely one thing — the relief that includes guilt, the
anger that masks fear, the love that comes with specific
resentment, the homecoming that is both wanted and
impossible. Manuscripts that simplify emotion to single
notes lose the form's signature texture; manuscripts that
hold contradictions — and the prose that shows the
contradiction without resolving it — operate within drama's
deepest register.

Verify defence mechanisms are visible and consistent. The
character who deflects with humour, the character who
withdraws into silence, the character who attacks when
cornered, the character who intellectualises pain — each
defence is character work, and the strongest drama makes
the defences visible across the manuscript so the reader can
track which defence appears under which pressure. Verify
the character's physical state reflects their emotional
state — drama's body is rarely separate from drama's
interior. The character who is genuinely undone has the
body of someone undone; the character whose interior says
"I'm fine" but whose body shows otherwise is the form's
distinctive register.

### Pass 2: Subtext Check

Read all dialogue and ask, for each significant exchange,
whether there is a layer beneath the surface. Are the real
conflicts disguised in apparently trivial exchanges? The
Displaced Argument technique is the form's deepest dialogue
craft; the revision pass checks whether the technique is
operating across the manuscript or concentrated in one set-
piece. Verify what's unsaid is as significant as what's
spoken — the silence before the response, the topic neither
will name, the question that gets redirected, the answer
that arrives too quickly.

Verify characters are aware of different things (creating
dramatic irony). The reader knowing what the protagonist
doesn't yet know — about the affair, about the diagnosis,
about the betrayal already underway — is drama's signature
tension structure. The strongest drama runs multiple layers
of awareness simultaneously: the reader knows X; the
protagonist knows Y; the antagonist knows Z; the partner
knows nothing yet. The manuscript should track these layers
deliberately; flat-information narratives where everyone
knows the same things lose drama's structural pleasure.

Test: pick three significant dialogue exchanges and write
out what each character is also saying beneath the surface.
If the displacement isn't specific to these characters'
specific history, the subtext is decorative. The strongest
drama makes subtext load-bearing: cut the surface text and
the underlying text remains visible; cut the underlying text
and the surface text becomes inexplicable.

### Pass 3: Relationship Authenticity Check

Verify every significant relationship feels lived-in —
history, habits, unspoken rules, jokes that have decayed
into reference, conversations that have happened so often
they're now compressed to a glance. The form's failure
mode is relationships that read as freshly-met even when
the prose says they've been together for years; the
strongest drama makes the accumulated history visible in
the small specific texture (the way they sit at the same
table; the joke that no longer needs to be made; the
argument that has worn a path the partners now travel
without thinking).

Verify power dynamics are visible and consistent — see The
Power Dynamic Visibility technique above. Power isn't a
single axis; relationships operate on multiple
simultaneous power structures (financial, emotional,
social, informational, caretaking). The revision pass checks
whether the manuscript tracks these consistently and shows
shifts when shifts occur.

Verify something changes since the last interaction
between any two characters. Drama's pacing is interpersonal:
relationships should evolve, even minutely, between every
appearance. If two characters meet in chapter four and
chapter twelve and the relationship is the same, eight
chapters of dramatic time have done no work. Verify
characters bring emotional residue from previous chapters
— the argument that ended in chapter three should still be
producing effects in chapter five, not vanish without
trace. Test: pick three relationships and trace each
across all its appearances. Does the relationship evolve
across the book, or does it appear in the same form each
time?

### Pass 4: Growth Check

Verify character growth is demonstrated through behaviour
change rather than asserted. Drama's growth contract: the
character of chapter twenty cannot be the character of
chapter one; the difference must be visible in specific
behaviour, decision, response — not in narrator commentary
("she had grown so much"). Audit the manuscript for growth
moments: at each, is the change shown through what the
character now does that they would not have done before?

Verify regression is present when characters face stress.
Real growth is non-linear; characters under sufficient
pressure revert toward earlier defences before re-arriving
at their changed selves. The smoothly-progressive growth
arc where the character improves monotonically is the
failure mode; the growth arc with regressions, near-
misses, and difficult re-commitments is the technique.

Verify epiphanies are rare and earned, not sudden
revelations. Drama permits epiphany — the moment a
character understands something they have been avoiding —
but the form requires that the epiphany be prepared by
what came before. The character who has a sudden insight
in chapter seventeen that solves a problem the manuscript
hadn't been building toward has been served plot rather
than character. Verify the cost of growth is visible. Real
growth is usually painful; the character who grows without
visible cost is operating in genre fiction's growth
register, not drama's. Drama's growth is what was lost or
left behind to arrive here; that loss should be on the
page.

### Pass 5: Melodrama Guard

Run a dedicated pass on the manuscript's emotional
proportion. Is understatement used for the most powerful
moments? Drama's deepest craft pleasure is the inverse-
intensity rule: the most charged emotional content is often
delivered in the quietest prose, with the surface
restraint making the underneath unbearable. The
manuscript's biggest moments — the death, the revelation,
the breaking, the loss — should typically be rendered in
prose that is more, not less, controlled than the prose
around them.

Verify emotions are proportional to the situation within
the character's psychology. The character who reacts to a
small slight with operatic devastation has been written for
melodrama; the character whose specific psychology makes
the small slight genuinely devastating (because it
recapitulates an earlier wound, because it crystallises a
pattern, because it lands at the precise moment of
existing depletion) has been written for drama. The
proportion is character-specific, not absolute.

Verify the reader is trusted to feel without being told
what to feel. The narrator who pauses to articulate the
emotional content of the scene the prose just rendered has
distrusted the reader. Drama's strongest practitioners give
the reader the rendered material and let the reader's
emotion arise; they do not narrate the emotion to ensure
the reader has it. Verify solutions are absent or, if
present, are earned, costly, and imperfect. Drama permits
resolution but requires the resolution to honour the
complexity that preceded it; the tidy ending where every
thread closes is the form's most-flagged structural
failure.

### Pass 6: Resolution Discipline

Run a final pass on the manuscript's ending. Drama's
deepest contract permits — and is often deepened by —
endings that refuse clean resolution. The marriage that
doesn't repair. The parent who can't be forgiven within the
book's timeframe. The truth that, once spoken, cannot be
reabsorbed. The sibling estrangement that ends in continued
estrangement. The form's strongest practitioners refuse the
resolution that would simplify the emotional reality they
have constructed.

The pass distinguishes earned-refusal from unearned-bleakness.
Endings that refuse resolution because the writer didn't
know how to end have failed; endings where the prior
dramatic material makes clean resolution impossible without
falsifying what the book has been showing have succeeded.
Endings that resolve but only at significant cost (the
reconciliation that requires both parties to give up
something specific; the truth told that changes the
relationship into something neither expected; the homecoming
that is to a different home than the one left) operate
within the form.

Test the ending against the journey: does the ending
honour the emotional reality of the prior chapters? If the
ending feels gentler than the journey has earned, the
resolution is unearned; if the ending feels truer than what
conventional closure would have permitted — even if that
truth is uncomfortable — the discipline is operating.

The pass also checks for the related failure mode: drama
that resolves through external event rather than internal
recognition. The marriage that fails is more truthful than
the marriage rescued by a third party's death; the
estrangement that continues is more truthful than the
estrangement ended by a forced reunion. Drama's
resolutions, when they occur at all, should arise from the
dramatic material the manuscript has constructed, not from
external machinery the writer deploys to close the book.

## Names & Patterns to Avoid

### Drama Character Names. NEVER USE
- Symbolic names that telegraph role: Grace, Hope, Victor
- Names that signal the character's function: Dr. Hart (the cardiologist), Joy (the optimist)
- Identical-rhythm names (readers need to distinguish quickly)

### Drama. NEVER DO
- Resolve deep problems quickly or cleanly (real problems persist)
- Have characters explain their feelings in therapist-speak (unless they're actually in therapy)
- Write melodrama: theatrical tears, overwrought declarations, fainting
- State the theme in dialogue ("I think what this is really about is...")
- Give characters epiphanies they haven't earned through accumulated experience
- Write villains (everyone in drama has their own internal logic)
- Resolve everything neatly (drama ends with new awareness, not perfection)

### Use Instead
- Names appropriate to the character's age, background, region, and family
- Names that feel lived-in: the kind of names real people have
- Nicknames that reveal relationship dynamics (what your mother calls you vs. what your friends call you)

## Comp Titles

Drama's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Anna Karenina* — Leo Tolstoy (1877): the realist-drama foundation.
- *Madame Bovary* — Gustave Flaubert (1856): provincial-drama literary benchmark.
- *Middlemarch* — George Eliot (1871-72): the literary-drama epic.
- *The Remains of the Day* — Kazuo Ishiguro (1989): drama-novel-as-restraint benchmark.

### Contemporary (current best-in-class)

- *Atonement* — Ian McEwan (2001): contemporary literary drama benchmark.
- *Olive Kitteridge* — Elizabeth Strout (2008): linked-stories drama.
- *A Little Life* — Hanya Yanagihara (2015): contemporary literary drama epic.
- *Crossroads* — Jonathan Franzen (2021): contemporary American family drama.
- *Hamnet* — Maggie O'Farrell (2020): historical literary drama.
- *Demon Copperhead* — Barbara Kingsolver (2022): contemporary American literary drama.
- *Mercy Street* — Jennifer Haigh (2022): contemporary drama with abortion-clinic frame.
- *The Marriage Portrait* — Maggie O'Farrell (2022): historical literary drama.

## Cover Design Specifications

### Recommended Visual Styles
- **Intimate**. Close, personal imagery: two figures, a face, hands, the small physical details that carry emotional weight
- **Atmospheric**. A setting that carries emotion: an empty room, a kitchen table, a window; the space where the drama happens
- **Typographic**. The title dominates: literary, restrained, the design trusting the words to do the work
- **Photographic**. Quiet, observational photography: the kind of image that catches something private and honest

### Genre Cover Aesthetics
- **Styles:** Quiet, intimate compositions; figures in domestic spaces; close-ups of hands, faces, objects that carry emotional weight; empty rooms that suggest absence; soft focus, natural light, the aesthetic of quiet observation
- **Colours:** Muted, warm palettes: soft golds, gentle blues, warm greys, earth tones; nothing saturated or dramatic; the palette should feel like late afternoon light. gentle but honest
- **Elements:** Domestic objects (tables, chairs, windows, doors), hands (touching, not touching, holding, releasing), landscapes as emotional states, family photographs, the small objects that carry memory
- **Typography:** Elegant, often serif; restrained and literary; the title should feel considered, not loud; subtle colour choices; the author name prominent for readers who follow voices

### Market Positioning
Drama covers must signal "emotionally honest, psychologically deep, and quietly powerful" through restrained, intimate design. Position against Strout, Tyler, Patchett, Franzen, Smith. The cover should promise depth without melodrama. At thumbnail size, a warm-toned, quiet composition with elegant typography creates a literary-adjacent identity that distinguishes from genre fiction.

### Cover Design DON'Ts
- No dramatic or theatrical imagery
- No bright, saturated colours
- No action or movement (drama's cover is still, like its subject)
- No cluttered compositions
- No genre signifiers (swords, spaceships, crime scenes)
- No stock photography that feels posed or false
