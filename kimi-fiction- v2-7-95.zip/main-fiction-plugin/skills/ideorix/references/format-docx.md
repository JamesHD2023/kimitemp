---
name: format-docx
description: "DOCX manuscript generation template"
user-invocable: false
---
<!-- (c) 2025 James Harvey Media / Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# DOCX Generation Template

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.docx`

This DOCX export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Routing — Novel vs. Screenplay (READ FIRST)

This file ships **two** DOCX layouts. Pick the right one before generating.

| Source content | Use this layout | Why |
|---|---|---|
| Novel manuscript (prose chapters, scene breaks `* * *`, no Fountain syntax) | **Novel DOCX** (the main body of this file) | Industry manuscript format: Times New Roman 12pt, double/1.5 spacing, first-line indent, page break per chapter |
| Screenplay (Fountain source, scene headings `INT./EXT.`, character cues, action paragraphs) | **Screenplay DOCX** (see "Screenplay DOCX Layout" section below) | Industry-standard spec script format: Courier 12pt, US Letter, screenplay margins, character-cue indentation. Output should match what Final Draft / Highland export as DOCX. |

**Detection:** if the source text contains scene headings matching
`^(INT\.|EXT\.|INT\./EXT\.|I/E\.)` followed by a slugline pattern, OR
the source filename ends in `.fountain`, route to the Screenplay DOCX
layout. Otherwise use the Novel DOCX layout below.

If a project contains both, generate two separate DOCX files — one
per format.

---

## Novel DOCX — Overview

Generate .docx manuscript files using the `docx` npm package.
This template produces publisher-ready formatting.

## Manuscript Specifications

- **Page size:** US Letter (8.5" x 11")
- **Margins:** 1 inch all sides
- **Body font:** Times New Roman, 12pt
- **Chapter headings:** Times New Roman, 16pt, bold, centered
- **Line spacing:** 1.5
- **Paragraph spacing:** 6pt after each paragraph
- **First line indent:** 0.5 inch (except first paragraph after heading)
- **Page breaks:** Between every chapter
- **Header:** Book title (even pages) / Chapter title (odd pages) — from chapter 2 onward
- **Footer:** Page number, centered

## File Size Expectations

- **Short Story (~8,000 words):** 15-25 KB
- **Novelette (~12,500 words):** 22-35 KB
- **Novella (~40,000 words):** 65-100 KB
- **Standard Novel (~75,000 words):** 110-170 KB
- **Epic Novel (~120,000 words):** 170-250 KB

## Title Page Structure

```
[3 blank lines]

[Book Title — 24pt, bold, centered]

[1 blank line]

[Subtitle — 14pt, italic, centered] (if applicable)

[2 blank lines]

[Author Name — 16pt, centered]

[Page break]
```

## Chapter Structure

```
[Page break before each chapter]

[Chapter heading — 16pt, bold, centered]
[e.g., "Chapter 1: The Discovery"]

[1 blank line]

[Chapter body — 12pt, 1.5 spacing]
[First paragraph: no indent]
[Subsequent paragraphs: 0.5" first line indent]
```

## Scene Break Formatting

Within a chapter, scene breaks are indicated by:
```
[blank line]
* * *
[blank line]
```

Centered, with three asterisks separated by spaces.

## Node.js Generation Template

```javascript
const { Document, Packer, Paragraph, TextRun, AlignmentType,
        PageBreak, Header, Footer, PageNumber } = require('docx');

function createManuscript(title, author, chapters) {
  const doc = new Document({
    sections: [
      // Title page
      {
        properties: { page: { size: { width: 12240, height: 15840 },
                              margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
        children: [
          new Paragraph({ spacing: { before: 3600 } }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: title, bold: true, size: 48, font: 'Times New Roman' })]
          }),
          new Paragraph({ spacing: { before: 400 } }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: author, size: 32, font: 'Times New Roman' })]
          }),
        ]
      },
      // Chapter sections
      ...chapters.map((chapter, index) => ({
        properties: {
          page: { size: { width: 12240, height: 15840 },
                  margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } }
        },
        children: [
          // Chapter heading
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 },
            children: [new TextRun({
              text: `Chapter ${index + 1}: ${chapter.title}`,
              bold: true, size: 32, font: 'Times New Roman'
            })]
          }),
          // Chapter content paragraphs
          ...chapter.paragraphs.map((para, pIndex) => new Paragraph({
            spacing: { after: 200, line: 360 },
            indent: pIndex === 0 ? {} : { firstLine: 720 },
            children: [new TextRun({ text: para, size: 24, font: 'Times New Roman' })]
          }))
        ]
      }))
    ]
  });

  return Packer.toBuffer(doc);
}
```

## Content Parsing

Before generating the .docx, parse chapter markdown into paragraphs:

1. Split on double newlines for paragraph breaks
2. Convert scene breaks (`* * *` or `---`) into centered separator paragraphs
3. Handle dialogue paragraphs (start with `"`) — no first-line indent
4. Strip any markdown formatting (`**bold**` → bold TextRun, `*italic*` → italic TextRun)
5. Preserve em-dashes (—), curly quotes, and special characters

## CRITICAL: Paragraph Formatting Requirements

**Regardless of how the .docx is generated** (Node.js docx package, Pandoc,
Python python-docx, or direct XML), every body paragraph MUST have these
properties applied explicitly — do NOT rely on named styles resolving correctly:

**Body paragraphs (all paragraphs after the first in each chapter/scene):**
- First line indent: 0.5 inch (720 twips / 360 EMUs / `ind firstLine="720"`)
- Spacing after: 6pt (120 twentieth-points / `spacing after="120"`)
- Line spacing: 1.5 (360 twentieth-points / `spacing line="360"`)
- Font: Times New Roman, 12pt

**First paragraph after heading or scene break:**
- NO first line indent
- Spacing after: 6pt (same as body)
- Line spacing: 1.5 (same as body)

**Chapter headings:**
- Centered, bold, 16pt
- Spacing after: 20pt (400 twentieth-points)
- Page break before (except chapter 1 which follows the title page)

**If using Pandoc:** You MUST either:
1. Provide a reference.docx with BodyText and FirstParagraph styles properly
   defined (indent + spacing), OR
2. Apply spacing and indent as direct formatting on every paragraph rather
   than relying on style names

**If using Python python-docx:** Apply `paragraph_format.first_line_indent`
and `paragraph_format.space_after` directly on each paragraph object.

**Test:** Open the generated .docx in Word or LibreOffice. If all paragraphs
are flush-left with no indent and no spacing, the formatting was not applied.
This is the most common DOCX generation failure — fix it before delivery.

---

## Screenplay DOCX Layout

Generate industry-standard screenplay DOCX from Fountain source. The
output must be indistinguishable from a Final Draft / Highland / Fade In
export — that's the bar; anything less reads as amateur.

### Page geometry (MANDATORY)

- **Page size:** US Letter (8.5" × 11") — 12240 × 15840 twips
- **Top margin:** 1.0" (1440 twips)
- **Bottom margin:** 0.5"–1.0" (720–1440 twips)
- **Left margin:** 1.5" (2160 twips)
- **Right margin:** 1.0" (1440 twips)

### Font (MANDATORY)

- **Font:** Courier or Courier Prime, 12pt (24 half-points). Monospace.
- **Single weight:** Plain. No bold sluglines (industry has moved
  away from underlined or bold sluglines).
- **Color:** Black only.

### Element layout (MANDATORY)

| Element | Indent (left) | Right indent | Alignment | Notes |
|---|---|---|---|---|
| Scene Heading | 0 (relative to page margin) | 0 | Left | UPPERCASE |
| Action | 0 | 0 | Left | Single-spaced within paragraph; blank line between paragraphs |
| Character Cue | 2.2" (3168 twips) | 0 | Left | UPPERCASE; on its own line; blank line above |
| Parenthetical | 1.6" (2304 twips) | 1.4" (2016 twips) | Left | Lowercase; in parens; immediately above the dialogue |
| Dialogue | 1.0" (1440 twips) | 1.5" (2160 twips) | Left | Single-spaced |
| Transition | 0 | 0 | Right | UPPERCASE; ends with `:` |
| Page Number | top right | — | Right | `N.` (with period); first page omitted |

The indent values above are **relative to the page text area** (which
already has the 1.5" left page margin), so a Character Cue at 2.2"
indent appears 1.5" + 2.2" = 3.7" from the page edge — matching the
PDF layout in `format-pdf.md`.

### Title Page

First section, separate from the body. No page number. Layout:

- ~3.5" of vertical space at the top
- Centered TITLE (12pt Courier, uppercase)
- Blank line
- Centered credit line (`Written by` etc.)
- Blank line
- Centered author name
- (Optional) blank line + centered Source line (italic if Source present)
- Push down with vertical space
- Bottom-left contact block (author, email, phone)
- (Optional) bottom-right `Draft date`

Title page is one section with its own properties (no page number);
body starts on the second section with page numbers from page 2.

### Special elements

- **MORE / CONT'D at page break:** when a dialogue block must split
  across a page break, append `(MORE)` at the bottom of the page and
  `CHARACTER (CONT'D)` at the top of the next page.
- **Scene numbers:** **omit** in spec scripts.
- **Dual dialogue:** render as a 2-column table at the dual dialogue
  widths above. Both columns left-aligned within their column.
- **MONTAGE / INTERCUT / INSERT / SUPER:** rendered as scene headings.

### Node.js generation (using docx package)

```javascript
const { Document, Packer, Paragraph, TextRun, AlignmentType,
        PageBreak, Header, Footer, PageNumber, TabStopType,
        TabStopPosition, convertInchesToTwip, LevelFormat } = require('docx');

// All values in twips (1 inch = 1440 twips)
const SCRPLAY = {
  pageWidth: 12240, pageHeight: 15840,
  marginTop: 1440, marginBottom: 1440,
  marginLeft: 2160, marginRight: 1440,
  font: 'Courier Prime',     // fallback: 'Courier New' or 'Courier'
  fontSize: 24,               // 12pt = 24 half-points

  indents: {
    sceneHeading: 0,
    action: 0,
    character: 3168,           // 2.2"
    parenthetical: 2304,       // 1.6"
    dialogue: 1440,            // 1.0"
  },
  rightIndents: {
    parenthetical: 2016,       // 1.4"
    dialogue: 2160,            // 1.5"
  }
};

function createScreenplayDocx(title, fountainScenes) {
  const sections = [
    titlePageSection(fountainScenes.titlePage),
    bodySection(fountainScenes.scenes)
  ];
  const doc = new Document({ sections });
  return Packer.toBuffer(doc);
}

function bodySection(scenes) {
  const children = [];
  scenes.forEach(scene => {
    children.push(...renderScene(scene));
  });
  return {
    properties: {
      page: {
        size: { width: SCRPLAY.pageWidth, height: SCRPLAY.pageHeight },
        margin: {
          top: SCRPLAY.marginTop, bottom: SCRPLAY.marginBottom,
          left: SCRPLAY.marginLeft, right: SCRPLAY.marginRight
        },
        pageNumbers: { start: 2 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [
            new TextRun({ children: [PageNumber.CURRENT], font: SCRPLAY.font, size: SCRPLAY.fontSize }),
            new TextRun({ text: '.', font: SCRPLAY.font, size: SCRPLAY.fontSize })
          ]
        })]
      })
    },
    children
  };
}

function renderScene(scene) {
  const out = [];
  // Scene heading
  out.push(new Paragraph({
    indent: { left: SCRPLAY.indents.sceneHeading },
    spacing: { before: 240, after: 240 },
    children: [new TextRun({
      text: scene.heading.toUpperCase(),
      font: SCRPLAY.font, size: SCRPLAY.fontSize
    })]
  }));

  scene.elements.forEach(el => {
    switch (el.type) {
      case 'action':
        out.push(new Paragraph({
          indent: { left: SCRPLAY.indents.action },
          spacing: { after: 240 },
          children: [new TextRun({ text: el.text, font: SCRPLAY.font, size: SCRPLAY.fontSize })]
        }));
        break;
      case 'character':
        out.push(new Paragraph({
          indent: { left: SCRPLAY.indents.character },
          spacing: { before: 240 },
          children: [new TextRun({
            text: el.name.toUpperCase() + (el.extension || ''),
            font: SCRPLAY.font, size: SCRPLAY.fontSize
          })]
        }));
        break;
      case 'parenthetical':
        out.push(new Paragraph({
          indent: { left: SCRPLAY.indents.parenthetical, right: SCRPLAY.rightIndents.parenthetical },
          children: [new TextRun({ text: '(' + el.text + ')', font: SCRPLAY.font, size: SCRPLAY.fontSize })]
        }));
        break;
      case 'dialogue':
        out.push(new Paragraph({
          indent: { left: SCRPLAY.indents.dialogue, right: SCRPLAY.rightIndents.dialogue },
          spacing: { after: 240 },
          children: [new TextRun({ text: el.text, font: SCRPLAY.font, size: SCRPLAY.fontSize })]
        }));
        break;
      case 'transition':
        out.push(new Paragraph({
          alignment: AlignmentType.RIGHT,
          spacing: { before: 240, after: 240 },
          children: [new TextRun({
            text: el.text.toUpperCase() + ':',
            font: SCRPLAY.font, size: SCRPLAY.fontSize
          })]
        }));
        break;
    }
  });
  return out;
}
```

### Critical: paragraph properties on every element

DO NOT rely on Word style names. Apply font, size, indent, and
spacing as direct formatting on every paragraph. The most common DOCX
screenplay generation failure is a file that opens in Word with
proportional font and novel formatting because the engine relied on
named styles.

### Verification (do before delivery)

- Open in Word or LibreOffice and confirm:
  - All paragraphs in monospace Courier (or Courier Prime), 12pt
  - Sluglines flush at the page text area's left edge (1.5" from page edge total)
  - Character cues at +2.2" indent (3.7" from page edge)
  - Dialogue at +1.0" indent (2.5" from page edge), with right indent so total dialogue width is 3.5"
  - Page numbers top-right with format `N.`
  - First body page is `2.`; title page has no number

### When the source is not Fountain

Route through `screenplay-importer.md` to convert DOCX/FDX/PDF to
normalised scene list, then regenerate using the layout above. Do NOT
attempt to "fix up" a malformed screenplay DOCX in place — re-derive
from the canonical scene structure.
