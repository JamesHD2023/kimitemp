---
name: thriller-genre
description: Genre-specific instructions for action/thriller fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# Thriller. Genre Plugin

## Metadata
- id: thriller
- name: Action Thriller
- icon: 💥
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "The Hero's Journey", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Action**. High-octane physical conflict, ex-military or law enforcement protagonist, global stakes (Lee Child, Vince Flynn)
- **Conspiracy**. Institutional corruption, layered secrets, protagonist uncovers truth against powerful opposition (Dan Brown, David Baldacci)
- **Techno**. Technology-driven threats, cyber warfare, surveillance, weapons systems (Tom Clancy, Daniel Suarez)
- **Political**. Government intrigue, assassination plots, geopolitical maneuvering (Brad Thor, Kyle Mills)
- **Psychological**. Cat-and-mouse, manipulation, unreliable perspectives, mind games (Thomas Harris, Gillian Flynn)
- **Survival**. Protagonist isolated in hostile environment, must outlast threat (wilderness, disaster, siege)

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: FAST. short chapters, relentless forward momentum, no dead weight
- Must end with: A hook. question raised, threat escalated, revelation dropped, or cliffhanger
- Must open with: Action in progress, immediate tension, or consequence of previous chapter's hook

BEATS PER CHAPTER
1. Orientation Beat. Where are we, what just happened, what's at stake RIGHT NOW (under 200 words)
2. Escalation Beat. New information, new threat, or new complication that raises the stakes
3. Action/Decision Beat. Protagonist acts, fights, investigates, or makes a critical choice under pressure
4. Consequence Beat. The action has a cost (physical, emotional, tactical, or informational)
5. Hook Beat. Chapter ends on forward momentum: cliffhanger, revelation, ticking clock advancement

TICKING CLOCK ARCHITECTURE (CRITICAL)
- Establish a concrete deadline by the end of Act 1 (bomb detonation, hostage execution, election day, launch window)
- The clock must be SPECIFIC. "48 hours," "before the summit on Friday," not vague "running out of time"
- Remind the reader of the clock every 3-4 chapters minimum
- The deadline can shift (accelerate or reveal a second clock) but NEVER quietly disappear
- At the midpoint, the remaining time should feel insufficient for the task
- In Act 3, the clock compresses. chapters cover shorter and shorter time spans

THRILLER ARCHITECTURE
- Inciting threat established by end of Chapter 1. the reader knows something dangerous is in motion
- Protagonist drawn in by Chapter 2-3 (through duty, personal connection, or being targeted)
- Antagonist demonstrated as competent and dangerous by Chapter 3-4 (NOT just described. shown)
- Minimum 3 major set pieces spaced across the manuscript:
  - Act 1 set piece: Establishes the physical rules of this world (first confrontation, narrow escape)
  - Midpoint set piece: The biggest "oh no" moment. stakes become undeniably personal
  - Climax set piece: Maximum jeopardy, all resources depleted, protagonist must improvise
- Information reveals layered progressively:
  - Layer 1 (Act 1): Surface threat. what it LOOKS like is happening
  - Layer 2 (Midpoint): Deeper truth. the real scope of the conspiracy/threat
  - Layer 3 (Act 3 turn): Final revelation. who is truly behind it and why
- Each layer should recontextualize earlier events without invalidating them

MULTI-POV STRUCTURE (if using antagonist chapters)
- Antagonist POV chapters: shorter (1,500-2,500 words), used sparingly (every 4-5 chapters max)
- Antagonist chapters reveal CAPABILITY and DETERMINATION, not full plans
- Show the antagonist solving problems competently. they are a professional too
- The reader should know MORE than the protagonist but NOT everything
- Never reveal the full plan in antagonist chapters. maintain dramatic irony, not spoilers
- Alternate structure: Protagonist chapter → Supporting character → Antagonist (never back-to-back antagonist)

STAKES ESCALATION LADDER (MUST FOLLOW THIS PROGRESSION)
1. Professional stakes. mission, assignment, reputation
2. Personal stakes. someone the protagonist cares about is threatened
3. Physical stakes. protagonist's body is damaged, resources depleted
4. Moral stakes. protagonist must compromise principles or make impossible choice
5. Existential stakes. survival of many, institutional collapse, irreversible consequences
Each rung reached by roughly: 20%, 35%, 50%, 70%, 85% of manuscript

CHAPTER ENDING REQUIREMENTS
- Every chapter ends with a HOOK. the reader must need to turn the page
- Acceptable hooks: Mid-action break, revelation that reframes everything, new threat introduced,
  ally compromised, countdown milestone reached, protagonist makes a dangerous choice
- Rotate hook types. do NOT use the same technique in consecutive chapters
- NEVER use: "Little did he know," vague foreboding, recap of what just happened,
  the protagonist going to sleep (unless they're ambushed mid-sleep)
- BEST PRACTICE: End mid-scene, not between scenes. cut at the moment of maximum tension

FORBIDDEN IN THRILLER
- Extended domestic scenes without tension (brief respite yes, cozy chapters no)
- Protagonist monologuing about their feelings for more than one paragraph
- Antagonist explaining their plan in full before the climax (no Bond villain speeches)
- Technology that doesn't exist (keep tech grounded in current capability or near-future plausible)
- Coincidences that save the protagonist (coincidences that CREATE problems are fine)
- Action scenes where the protagonist wins easily (every victory must cost something)
- Passive protagonist waiting for things to happen (they drive the plot, even when reacting)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (primary), Stimulation at set-pieces, Validation at each set-piece resolution.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the thriller cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  thriller cues below apply directly.

VOICE & TONE
- POV: Third person close past tense (primary) OR first person past tense
- Voice: Direct, muscular, precise. no wasted words
- Tone: Urgent, grounded, intelligent. the reader trusts this narrator knows what they're describing
- Sentence structure: Short during action, medium during investigation, longer only during rare breather moments
- Reader relationship: Riding shotgun with a competent professional under pressure

DIALECT CONSISTENCY (IMPORTANT)
- Establish the dialect in the Story Bible (British English, American English, etc.)
- Maintain 100% consistency throughout. a single "fall" in a British novel is jarring
- Common British/American traps to watch:
  - autumn / fall
  - colour / color
  - pavement / sidewalk
  - boot (of car) / trunk
  - torch / flashlight
  - flat / apartment
  - "have got" / "gotten"
  - mobile / cell phone
  - post / mail
  - magazine / clip (firearms. "clip" is technically wrong for most modern firearms;
    use "magazine" unless the character is deliberately colloquial)
  - boot / trunk (vehicles)
  - bonnet / hood (vehicles)
- If British English: NEVER use "fall" for autumn, "gotten", "apartment" for "flat",
  or "cell phone" for "mobile"
- If American English: NEVER use "boot" for trunk, "bonnet" for hood, "torch" for
  flashlight, or "mobile" for cell phone
- The Prose Craft Improver should scan for dialect inconsistencies during its pass

PROSE IMPERATIVES
- SHOW competence through specific detail (he didn't "check the gun". he press-checked the Glock's chamber)
- Sensory details serve tension. Pick the ONE detail that ratchets the moment: cordite, OR boots on concrete, OR cold sweat. Not all three
- Technical accuracy matters. readers WILL notice wrong gun calibers, impossible geography, bad tradecraft
- Pare prose to the bone during action. no similes, no metaphors, no literary flourishes mid-fight
- Breather scenes earn their length by revealing character or planting information for later
- Environment is always tactically relevant (exits, cover, sight lines, crowd density)

ACTION SCENE CONSTRUCTION (CRITICAL)
- SPATIAL AWARENESS: Establish the physical space BEFORE the action begins (layout, distances, obstacles)
- CHOREOGRAPHY: Every move must be physically possible from the last established position
- CONSEQUENCE: Every action has a physical cost. bruises accumulate, ammunition depletes, fatigue builds
- CLARITY: The reader must always know: where the protagonist is, where the threat is, what's between them
- TEMPO: Action paragraphs are SHORT (2-4 sentences). One action per paragraph. Cut the fat.
- SENSORY GROUNDING: In combat, reduce to animal senses. sight, sound, pain, adrenaline
- NO SUPERHUMAN FEATS: Protagonist is skilled but human. they miss shots, get winded, make mistakes
- STAKES IN EVERY FIGHT: Something must be at risk beyond survival (information, an ally, time on the clock)
- END ACTION SCENES WITH COST: Injury, lost asset, revealed position, spent resources, emotional toll

THE BREATHER CYCLE (PACING ARCHITECTURE)
- Pattern: Action/Tension → Brief Breather → Escalation → Higher Action/Tension
- Breathers last 1-2 pages maximum, not full chapters
- During breathers: Protagonist takes stock, treats injuries, processes information, contacts allies
- Breathers ALWAYS contain a seed of the next escalation (new information, a phone call, a news report)
- Never more than 2 consecutive low-tension chapters. if investigation requires it, lace with threat reminders
- The breather-to-action ratio tightens as the book progresses (Act 1: 40/60, Act 2: 25/75, Act 3: 10/90)

PAGE-TURNER PROSE RHYTHM (CRITICAL. translates pacing into execution)

The difference between a structurally correct thriller and a page-turner
is PROSE RHYTHM. how the sentences feel, not just what they say.

Chapter 1 prose rhythm (applies to ALL thriller subgenres):
- Sentence average: 8-15 words during threat/action beats; 15-20
  during setup. NO sentences over 30 words in Ch 1.
- Paragraphs: 2-4 sentences max. No flowing 8-sentence paragraphs.
- Dialogue density: one exchange every 100-150 words of prose. Ch 1
  should be 40-50% dialogue by word count.
- Interiority: max 50 words per internal beat. The reader needs
  momentum, not reflection. The character ACTS, then THINKS briefly,
  then ACTS again.
- Sensory detail: 70% threat-relevant (sounds of danger, physical
  tension, tactical awareness); 30% setting. No atmospheric
  scene-painting in Ch 1.
- Metaphor/simile: max 1 per 500 words. Pare to the bone.

Act 1 prose rhythm (Ch 1 through ~25%):
- Sentence average: 10-18 words. Shorter in escalation scenes.
- Paragraphs: 3-5 sentences.
- Dialogue: 30-40% by word count.
- Interiority: max 75 words per beat.
- The prose should feel like LEANING FORWARD in a chair.

Act 2-3 prose rhythm:
- Sentence variety widens (some long analytical sentences in
  investigation beats, short punchy sentences in action).
- Breather scenes: sentences lengthen, paragraphs lengthen, but
  ALWAYS seed the next threat within 200 words.
- Climax: return to Ch 1 rhythm. short, fast, stripped.

VERIFICATION: The Quality Guardian should flag any thriller chapter
where the average sentence length exceeds 20 words during scenes
marked Tension ≥6 in the brief. Long sentences in high-tension
scenes = the prose isn't matching the pacing.

DIALOGUE FOR THRILLER
- Short exchanges under pressure. people don't speechify when bullets fly
- Subtext over text. professionals communicate in shorthand, implication, and omission
- Interrogation scenes: Power shifts moment by moment (who controls the conversation?)
- Phone/comms dialogue: Terse, professional, interrupted by events
- Antagonist dialogue: Controlled, precise, reveals intelligence without monologuing
- Distinguish military/intelligence jargon from civilian speech (but don't overload with acronyms)
- Exposition through conflict: Information revealed during arguments, negotiations, or standoffs. NOT info dumps

PROTAGONIST TYPES (adapt craft accordingly)
Type A. Extraordinary Person (Jack Reacher, Jason Bourne):
- Competence is established early and never in doubt. the question is HOW they'll win, not IF
- Internal conflict comes from moral choices, not ability
- Prose reflects confidence: decisive verbs, minimal hesitation, tactical awareness
- The vulnerability is emotional or institutional, not physical

Type B. Ordinary Person in Extraordinary Situation (the journalist, the doctor, the teacher):
- Competence builds. early chapters show them out of their depth, later chapters show adaptation
- Internal monologue reflects genuine fear and improvisation
- Prose reflects growing confidence: hesitant early, decisive late
- The vulnerability is real and physical. they genuinely might not survive

INFORMATION MANAGEMENT (CONSPIRACY/PURSUIT THRILLERS)
- Reveal information in LAYERS. surface truth → partial truth → deeper truth → full picture
- Each revelation should make the protagonist (and reader) re-evaluate earlier events
- Plant the seeds of later revelations early. when the twist lands, the reader recalls the setup
- Use the "one step forward, two steps back" pattern: every answer generates two new questions
- The protagonist should be WRONG about something important at the midpoint
- Never withhold information the POV character clearly possesses (that's cheating, not suspense)
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

TENSION & PACING (40% of total):
- Forward momentum: Does every chapter advance the plot? (0-100)
- Ticking clock presence: Is urgency maintained throughout? (0-100)
- Chapter hooks: Does every chapter end with a reason to keep reading? (0-100)
- Breather ratio: Are quiet moments brief, purposeful, and seeded with threat? (0-100)
- Stakes escalation: Do stakes climb progressively across the manuscript? (0-100)

ACTION CRAFT (30% of total):
- Spatial clarity: Can the reader map the action in their mind? (0-100)
- Physical plausibility: Are fight outcomes realistic for the characters? (0-100)
- Consequence accumulation: Do injuries/losses persist and affect later scenes? (0-100)
- Set piece quality: Are major action sequences varied and inventive? (0-100)

PLOT & CHARACTER (30% of total):
- Antagonist competence: Is the villain genuinely threatening and capable? (0-100)
- Protagonist agency: Does the protagonist drive the plot through decisions? (0-100)
- Information layering: Are reveals properly paced and earned? (0-100)
- Technical accuracy: Are weapons, tactics, locations, and procedures plausible? (0-100)

AUTOMATIC FAILS (score = 0):
- Dead chapter: Any chapter that does not advance plot, raise stakes, or reveal information
- Deus ex machina: Protagonist saved by coincidence, cavalry arriving unearned, or sudden new ability
- Bond villain monologue: Antagonist explains full plan while protagonist is captured
- Invincible protagonist: Hero sustains no consequences from action sequences
- PACING COLLAPSE: More than two consecutive chapters without tension escalation
- CLOCK ABANDONMENT: Ticking clock established then forgotten or quietly removed
- STAKES REGRESSION: Stakes decrease without narrative justification (the threat diminishes for no reason)
- COMPETENCE FAILURE: Antagonist makes stupid mistakes to let protagonist win
- Technical howlers: Weapons, vehicles, geography, or procedures so wrong they break immersion
```

## Continuity Rules

```
THRILLER CONTINUITY. WHAT TO TRACK

PHYSICAL STATE OF PROTAGONIST (CRITICAL):
- Current injuries: What hurts, what's bandaged, what limits mobility?
- Exhaustion level: When did they last sleep? Last eat? How long have they been running?
- Equipment: What weapons do they have? How much ammunition? What gear was lost?
- Appearance: Are they recognizable? Blood-stained? Disguised?
- Vehicle/transport: What are they driving? Fuel level? Damage sustained?

TICKING CLOCK STATE:
- Current deadline: How much time remains?
- Last time the reader was reminded of the clock
- Any changes to the deadline (accelerated, revealed to be earlier than thought)
- What must happen before the deadline

ANTAGONIST CAPABILITY TRACKING:
- What resources does the antagonist have? (people, money, weapons, authority, technology)
- What has the protagonist cost them so far? (lost operatives, blown cover, compromised plans)
- What does the antagonist know about the protagonist's position, identity, and plans?
- What has the protagonist learned about the antagonist's operation?

INFORMATION STATE (CRITICAL FOR CONSPIRACY PLOTS):
- What does the protagonist KNOW vs SUSPECT vs BELIEVE INCORRECTLY?
- What has been revealed to the reader but NOT to the protagonist (dramatic irony)?
- Which allies have which pieces of the puzzle?
- What evidence has been obtained, and where is it now?
- Has any critical information been compromised (antagonist knows what protagonist knows)?

GEOGRAPHIC/TACTICAL CONTINUITY:
- Current location of all major players
- Distance and travel time between key locations
- Security state of safe houses, meeting points, and hideouts
- Which locations have been compromised (can't go back)
- Communication channels: Which phones/emails/contacts are burned?

ALLY/ASSET STATUS:
- Which allies are alive, injured, compromised, or out of contact?
- Which allies have been revealed as untrustworthy?
- What resources can the protagonist still call on?
- Who is watching whom? Who has gone dark?

WEAPON AND TECHNOLOGY TRACKING:
- Specific firearms: model, caliber, capacity, rounds remaining
- Communication devices: which are secure, which are compromised
- Vehicles: make, model, condition, fuel, GPS tracking status
- Any special equipment: when obtained, when used, when lost
```

## Character Rules

```
THRILLER CHARACTER ARCHETYPES

THE PROTAGONIST:
- Competent in a specific domain (combat, intelligence, investigation, survival)
- Has a code or principles that create internal conflict when circumstances demand compromise
- Physically capable but NOT invulnerable. skill comes from training, experience, and determination
- Has a personal wound or loss that drives them beyond professional duty
- Makes decisions under pressure that reveal character. the choices define who they are
- Resourceful. uses environment, improvises, adapts when plans fail
- NEVER passive. even when reacting to events, they choose HOW to react

Extraordinary Protagonist (Reacher/Bourne type):
- Competence is a given. tension comes from impossible odds and moral complexity
- Underestimated by antagonists. this is a strength
- Solitary by choice or circumstance. trust issues are earned, not melodramatic
- Physical description through action, not mirror scenes

Ordinary Protagonist (civilian thrust into danger):
- Initial incompetence is realistic. they make beginner mistakes
- Growth is visible chapter by chapter. they learn from every encounter
- Fear is present and acknowledged. courage is acting DESPITE fear
- They bring a non-combat skill that proves unexpectedly useful (journalism, medicine, engineering)

THE ANTAGONIST:
- Must be COMPETENT. the most dangerous thing about them is their intelligence and capability
- Has resources, planning, and motivation that make them genuinely formidable
- Their plan would WORK if the protagonist didn't intervene
- Motivation is understandable within their worldview (not "evil for evil's sake")
- Professional in their domain. they don't make stupid mistakes, they get outmaneuvered
- If they have subordinates, the subordinates are also competent (no bumbling henchmen)
- Reveal their depth progressively. first encounter: surface threat; midpoint: true scope; climax: full picture
- They ADAPT to the protagonist's interference. escalating countermeasures, not repeating failed approaches

THE HANDLER/MENTOR:
- Provides resources, intelligence, and context. may have hidden agenda
- Can be compromised or revealed as unreliable at a critical moment
- Speaks in shorthand with the protagonist. their relationship predates the story
- If betrayal is planned, their earlier support must be GENUINE (not performative from Chapter 1)

THE ALLY:
- Has their own competence and role (tech support, local contact, specialist)
- Not just a sounding board. contributes meaningfully to the mission
- Can be lost (killed, captured, compromised) to raise stakes. this loss must COST the protagonist
- If romantic interest, the relationship develops under pressure, not in quiet domestic scenes

THE SECONDARY ANTAGONIST:
- Operative, enforcer, or rival with personal motivation to stop the protagonist
- More visible than the mastermind. the face of the threat in action sequences
- May have their own agenda that diverges from the primary antagonist
- Their defeat should be hard-won and occur before the climax, clearing the path to the final confrontation

ANTAGONIST PRESENCE BALANCE (Writer-Level Enforcement):
The antagonist (or their influence) must maintain consistent narrative pressure.
Quantitative tracking per chapter:
- DIRECT PRESENCE: Scenes where the antagonist appears on-page
- INDIRECT PRESENCE: Scenes where the antagonist's actions, plans, or consequences
  are felt (surveillance, orders being carried out, aftermath of their decisions)
- Per-chapter minimum: At least ONE of direct or indirect presence
- No more than 2 consecutive chapters without DIRECT antagonist presence
  (indirect-only runs risk the reader forgetting the threat's human face)
- If MULTIPLE antagonist-tier threats exist (mastermind + enforcer + rival faction),
  track each separately. The primary antagonist must not disappear for >3 chapters.
- The antagonist's screen time should ESCALATE across acts:
  Act 1: ~15-20% of chapter content involves the antagonist
  Act 2: ~25-35% of chapter content involves the antagonist
  Act 3: ~40-50% of chapter content involves the antagonist
- The Character Tracker will flag chapters where antagonist presence drops below
  threshold. The Writer must add indirect presence beats before proceeding.

VOICE DIFFERENTIATION REQUIREMENTS:
- Protagonist: Direct, precise, tactical awareness in internal monologue
- Antagonist: Controlled, strategic, reveals intelligence through word choice
- Military/Intelligence characters: Jargon-comfortable, clipped, mission-focused
- Civilian characters: Longer sentences, more emotional expression, ask more questions
- Every named character identifiable by dialogue alone. vocabulary, rhythm, concerns

VOICE DIFFERENTIATION. QUANTITATIVE CHECK:
For each PAIR of major characters, identify at least 3 distinguishing dialogue features.
If any two characters share >2 features, one must be revised before proceeding.

Thrillers are especially prone to "competent male voice convergence" where multiple
operatives/agents/military characters sound identical. Ensure different:
- Sentence length patterns (one terse, one mid-range, one verbose under pressure)
- Vocabulary domain (one military, one technical, one street-smart, one academic)
- Response to pressure (one gets colder, one gets louder, one gets precise, one deflects)
- Information style (one gives too much, one gives too little, one lies fluently)
- Physical tells during dialogue (one paces, one goes still, one fidgets with objects)

The Character Tracker verification agent will flag voice convergence between
any two major characters. If flagged, the Writer must differentiate before proceeding.
```

## Arc Rules

```
THRILLER STORY STRUCTURE

ACT 1: SETUP AND IGNITION (Chapters 1-4 for novella, 1-8 for novel)
- Chapter 1: Establish protagonist competence + normalcy; introduce the inciting threat
- Protagonist drawn into the conflict by end of Chapter 2-3
- Ticking clock established by end of Act 1
- Antagonist demonstrated (not just described) as dangerous by Chapter 3-4
- First set piece: Initial confrontation or narrow escape
- First major information reveal: The surface-level understanding of the threat
- Plant at least 2 details that will pay off in Act 3
- Stakes reach Rung 1-2 (professional → personal)

ACT 2A: PURSUIT AND INVESTIGATION (Chapters 5-10 for novella, 9-18 for novel)
- Protagonist is proactive. hunting, investigating, pursuing
- Each chapter reveals new information while raising new questions
- Allies recruited and relationships tested
- Antagonist's reach demonstrated. they're closer than the protagonist thinks
- Resources begin to deplete (safe houses compromised, allies lost, equipment damaged)
- Stakes reach Rung 3 (physical. the protagonist is hurt, exhausted, running low)
- Build toward midpoint reversal

MIDPOINT REVERSAL (center of manuscript):
- A major revelation that changes the nature of the threat
- What the protagonist thought was happening is only the SURFACE
- The real scope is bigger, more personal, or more urgent than imagined
- The ticking clock accelerates or a second clock is revealed
- The protagonist must reassess everything. some earlier "facts" were wrong
- This is the second set piece: maximum "oh no" moment

ACT 2B: ESCALATION AND COST (Chapters 11-16 for novella, 19-26 for novel)
- The protagonist is now HUNTED as well as hunting (dual pressure)
- Allies compromised, lost, or revealed as unreliable
- The protagonist must make morally difficult choices
- False victory: A win that turns out to be exactly what the antagonist wanted
- Dark night of the soul: Protagonist at lowest point. resources gone, allies lost, clock running out
- Stakes reach Rung 4 (moral. protagonist must cross a line or make an impossible choice)
- The final piece of information falls into place. protagonist now knows the full truth

ACT 3: CONVERGENCE AND CLIMAX (Chapters 17-20 for novella, 27-32 for novel)
- Protagonist commits to a plan with no safety net. this is the final play
- Chapters cover shorter time spans (hours, then minutes). compression creates urgency
- Secondary antagonist defeated in a preliminary confrontation
- Climax set piece: Maximum jeopardy, improvisation required, clock at zero
- The protagonist wins through competence + sacrifice. NOT luck or coincidence
- The victory has a COST. something is permanently lost (ally, innocence, belief, physical ability)
- Stakes reach Rung 5 (existential. the consequences of failure affect many)

THE CLIMAX SEQUENCE. STRUCTURED SET PIECE:
The thriller climax is a 3-4 chapter sequence with escalating compression:

Chapter N-3 (THE PREPARATION):
- Protagonist formulates the final plan, knowing it's the only shot
- Resources assembled. what's left, what's improvised, what's borrowed
- The reader sees the plan but knows it won't survive contact with the enemy
- Emotional beat: the protagonist says goodbye (implicitly or explicitly) to
  someone they care about. Stakes made personal in the same breath as tactical.

Chapter N-2 (THE APPROACH):
- Plan in motion. Everything goes right. at first. The pieces fall into place.
- Then the FIRST COMPLICATION: something the protagonist didn't account for.
  A guard rotation changed. A door is locked. An ally doesn't show.
- Improvisation begins. The protagonist adapts. competence under pressure.
- Time compression: chapters should cover hours, then minutes.

Chapter N-1 (THE CONFRONTATION):
- Face-to-face with the antagonist (directly or operationally)
- The plan is in tatters. the protagonist is operating on instinct and skill
- The antagonist demonstrates their full capability. this is their strongest moment
- The protagonist's specific competence (established in Act 1) is the deciding factor
- The clock hits zero. The decision point arrives. The protagonist acts.

Chapter N (THE COST):
- Immediate aftermath. The threat is neutralised. but at what price?
- Show the physical and emotional damage (don't skip to "everything's fine")
- The protagonist surveys what they've won and what they've lost
- This chapter is QUIET after the preceding intensity. the silence is the point

RESOLUTION (final chapter or epilogue):
- Brief. 1 chapter maximum
- Immediate aftermath: What was the cost? Who survived?
- The protagonist is changed. the wound from before the story is different now
- A new normal is established (not a return to the old normal)
- If series: A thread left unresolved (new threat hinted, old enemy survived, larger conspiracy)
- If standalone: Closure with weight. the protagonist carries what happened

TENSION ARC:
- Starts high (in media res or immediate threat), dips briefly for character establishment
- Builds steadily through Act 1 (each chapter higher than the last)
- Midpoint spike (major revelation/reversal)
- Act 2B: Sustained high tension with brief tactical breathers
- Act 3: Relentless escalation. no breathers, no pauses, maximum compression
- Resolution: Sharp drop to new baseline (not the old baseline. things have changed)
```

## Timeline Rules

```
THRILLER TIMELINE TRACKING

TICKING CLOCK MANAGEMENT (CRITICAL):
- What is the deadline? Express in specific terms (date, time, event)
- Current time relative to deadline at the start of each chapter
- How much time each chapter covers (hours? minutes? a day?)
- When was the reader last reminded of the countdown?
- Has the deadline shifted? Why? When was this revealed?
- Are there secondary deadlines (ally's surgery window, evidence being destroyed, witness fleeing)?

TIME COMPRESSION IN ACT 3:
- Act 1 chapters may cover days
- Act 2 chapters typically cover hours to a day
- Act 3 chapters must cover hours, then minutes
- Track the compression. if Chapter 1 covers three days and Chapter 25 covers thirty minutes, the pacing is correct
- NEVER let Act 3 chapters cover MORE time than Act 2 chapters (that's decompression, the opposite of what you want)

TRAVEL AND GEOGRAPHY:
- If the protagonist drives from New York to DC, that's 4+ hours. account for it
- Flights: Include realistic travel time, layovers, security
- Chase sequences: Map the route, track distances, time elapsed
- International travel: Passport, customs, time zone changes
- DO NOT teleport characters. every location change needs plausible transit time

COMMUNICATION TIMELINE:
- When was the last check-in with allies/handler?
- How long has the protagonist been out of contact?
- If a character says "I'll call you in two hours," track that
- Time zones matter for international plots. 3 PM in London is 10 AM in DC

EXHAUSTION AND HUMAN LIMITS:
- When did the protagonist last sleep? (After 24 hours without sleep, cognitive function degrades)
- When did they last eat? (Low blood sugar affects decision-making. use this)
- How long since their last injury? (Adrenaline wears off; pain catches up)
- How many days has the main action spanned? (Realistic thriller timeline: 3-14 days typically)

ANTAGONIST TIMELINE (parallel tracking):
- What is the antagonist doing while the protagonist acts?
- Their plan has its own timeline. track milestones
- When do they learn of the protagonist's interference? How do they adjust?
- Their resources also deplete (but they often have more to start with)

DAYLIGHT AND DARKNESS:
- Track sunrise/sunset for each location on each day
- Night operations have different rules than daytime
- If a chapter starts at sunset, it shouldn't be noon two pages later
- Use darkness and light tactically. they affect visibility, civilian presence, and options
```

## Genre-Specific Craft Techniques

Thriller is the threat-driven plot register, sitting adjacent
to mystery (puzzle-driven), suspense-romance (relationship-
under-threat), and action-adventure (action-driven journey)
but with a distinct contract: a specific danger (organisation,
individual, conspiracy, ticking clock, hidden truth)
generates sustained tension that the protagonist must
navigate through competence, deduction, and forced moral
choice. The cluster includes political thriller, espionage /
spy thriller, legal thriller (covered separately as
sibling), domestic thriller (covered separately), techno-
thriller, conspiracy thriller, psychological thriller (covered
separately), military thriller, and the broader threat-driven
range. Comp authors span the canonical lineage (John le Carré,
Frederick Forsyth, Robert Ludlum, Tom Clancy, Patricia
Highsmith, Graham Greene, Eric Ambler, Charles McCarry, Alan
Furst on the historical-thriller register) through contemporary
expansion (Lee Child, Mick Herron's *Slough House* series,
Daniel Silva, David Baldacci, James Patterson, Robert Crais,
John Grisham at the legal edge, Don Winslow, Olen Steinhauer,
Joseph Kanon, Charles Cumming, Jason Matthews, Mark Mills,
Daniel Suarez at the techno edge, Alex Berenson, Jack Carr,
Brad Thor, Kyle Mills, Mark Greaney, Vince Flynn / Kyle
Mills's Mitch Rapp series, Joe Finder, Karin Slaughter, Tana
French at the literary-thriller cross, Steph Cha, Megan
Abbott, Lou Berney, Liz Moore, Attica Locke, Walter Mosley,
Olivie Blake at the literary-cross). The form is uniquely
vulnerable to a cluster of failure modes that AI-generated
drafts hit with predictable frequency: **Action-Without-
Stakes** (set pieces deployed for spectacle with nothing
specific at risk beyond generic survival); **Competence-Porn
That Voids Tension** (the protagonist's victory is so
preordained that the question of whether they will succeed
never enters the reader's mind); **Conspiracy-Bigger-Than-
The-Book** (a sprawling conspiracy whose final revelation
can never satisfy the build-up because no specific outcome
matches the size of the implied stakes); **Bond-Villain
Monologue** (the antagonist explains their full plan to a
captured protagonist before the climax, voiding dramatic
irony); **Deus-Ex-Machina Rescue** (the cavalry arrives
unearned, the protagonist gains a sudden new ability, or
coincidence resolves what should have cost the protagonist);
**Tradecraft-by-Movie** (operational detail sourced from
other thrillers and films rather than from the actual
specifics of the depicted service / period / jurisdiction —
the failure mode that loses the genre's professional reader
fastest); **Pacing Collapse** (more than two consecutive
chapters without tension escalation, the manuscript drifting
into investigation or reflection without the form's
forward-momentum contract); **Clock Abandonment** (a ticking
clock established in Act 1 that quietly disappears from the
narrative without the reader being told what happened to
it); **Stakes Regression** (the threat diminishes between
chapters without narrative justification, breaking the
escalation ladder); **Antagonist-Made-Stupid** (villains
whose decisions only make sense because the writer needed
them for the plot, not because a competent operator with
the antagonist's information would actually choose them);
and **Forced-Choice Simulation** (generic "the protagonist
had to make a hard choice" without specific competing goods
with specific identifiable costs that persist). The four
canonical techniques (Set Piece Construction, Information
Architecture, Antagonist Mirror, Cliffhanger Rotation) plus
the two cluster-completing techniques (Forced Choice
Architecture, Tradecraft Discipline) are how the form
defends against these failure modes through specificity,
moral cost, and procedural authenticity.

### Set Piece Construction (CRITICAL FOR THRILLERS)

A set piece is a major action sequence that serves as a structural pillar of the thriller.
Every set piece must be PLANNED, not improvised during writing.

**The 7 Elements of a Thriller Set Piece:**

**Element 1: The Arena**
Establish the physical space before action begins. The reader needs a mental map.
- What are the dimensions? (warehouse floor, city block, moving train)
- What are the exits? (the protagonist should know. or discover they're blocked)
- What can be used as cover, weapon, or obstacle?
- What are the environmental hazards? (height, water, fire, crowd, traffic)
- What makes THIS arena different from the last set piece?

**Element 2: The Stakes Beyond Survival**
The protagonist isn't just trying to not die. Something else is at risk.
- Information that must be obtained or protected
- An ally who needs extraction
- A device that must be disabled
- A deadline that's about to expire
- A witness who will be killed if the protagonist fails

**Element 3: The Constraint**
Something limits the protagonist's options and forces creative problem-solving.
- Injured from a previous encounter
- Unarmed or low on ammunition
- Must not be seen (stealth requirement)
- Civilians in the crossfire
- Operating on no sleep or with compromised intelligence

**Element 4: The Escalation**
The situation gets worse DURING the set piece, not just before it.
- Reinforcements arrive for the antagonist
- A new threat emerges mid-fight
- The environment changes (fire starts, bridge collapses, crowd panics)
- An ally is hit or compromised
- The ticking clock advances to a critical threshold

**Element 5: The Turn**
The protagonist adapts. uses environment, improvises, exploits a weakness.
- This is the moment of protagonist COMPETENCE. the reason readers love this character
- The turn should use something established earlier (in this scene or a previous chapter)
- It should be clever but physically plausible
- It costs something. the turn works, but not cleanly

**Element 6: The Resolution**
The immediate action resolves, but not everything is clean.
- Protagonist survives but is diminished (injured, lost equipment, burned a safe house)
- New information obtained (at a price)
- The antagonist's plan is disrupted but not stopped
- A new problem is created by the resolution

**Element 7: The Transition**
The set piece connects to the next story beat.
- What did the protagonist learn?
- What did the encounter cost?
- How does this change the plan?
- What must happen next? (This feeds the chapter hook)

### Information Architecture for Conspiracy Thrillers

Managing what the reader knows vs. what the protagonist knows is the core craft of conspiracy thrillers.

**The Three Knowledge States:**
1. **Reader knows, protagonist doesn't** (dramatic irony. creates dread)
2. **Protagonist knows, reader discovers with them** (shared discovery. creates partnership)
3. **Neither knows yet** (mystery. creates curiosity)

**Rules for managing reveals:**
- Each major reveal should shift at least one piece of information between states
- Never let the reader get TOO far ahead of the protagonist (more than one major secret)
- The protagonist should figure out at least 60% of the truth through their own deduction
- Save the biggest "I should have seen it" moment for the Act 2/Act 3 transition
- False conclusions are powerful. the protagonist assembles the wrong picture from real clues

### The Antagonist Mirror Technique

The best thriller antagonists mirror the protagonist in some way.
- Same skill set, different moral code
- Same goal (safety, justice, order), different methods
- Same wound or loss, different response to it
- Their first direct confrontation should feel like looking in a dark mirror
- The protagonist wins not by being stronger, but by being willing to sacrifice what the antagonist won't

### Cliffhanger Rotation System

Rotate chapter endings to avoid repetition:

| Type | Example | Max Frequency |
|------|---------|---------------|
| Mid-Action Cut | "He pulled the trigger—" then cut to next chapter/POV | Every 5 chapters |
| Revelation Hook | Protagonist discovers something that changes everything | Every 3 chapters |
| Threat Escalation | A new danger is introduced or an existing one worsens | Every 3 chapters |
| Clock Milestone | The countdown reaches a critical threshold | Every 4 chapters |
| Ally Compromise | A trusted person is captured, revealed as traitor, or killed | Once per act |
| Decision Point | Protagonist faces an impossible choice. chapter ends before they choose | Every 4 chapters |
| Location Shift | A cut to the antagonist or secondary character in a dangerous position | Every 4 chapters |

**Rule:** Never use the same cliffhanger type in consecutive chapters. Track usage to ensure variety.

### The Forced Choice Architecture

Thriller's signature moral pressure: the protagonist must
make decisions where every available option costs something
real. The genre's deepest emotional weight comes not from
the question of whether the protagonist will succeed but
from the question of what they will sacrifice — and what
the sacrifice will mean — to succeed. The strongest
thrillers stage forced-choice moments at structural
intervals across the book, with each choice's cost
accumulating into the protagonist's specific moral weight
by the climax.

The architecture requires:

- **Specific competing goods** — the choice is not between
  good and bad but between two goods (or two bads): save
  the family member or stop the bombing; protect the asset
  or keep the cover; tell the truth and lose the
  prosecution or stay silent and let the larger conspiracy
  continue. Each option has identifiable defenders.
- **Information asymmetry** — the protagonist often must
  choose with incomplete information. They know enough to
  understand both options have weight, not enough to know
  which is right. The reader shares this asymmetry; the
  decision lands as genuinely uncertain.
- **Specific costs accumulating** — what the protagonist
  chose in chapter eight constrains what they can choose
  in chapter sixteen. The forced choice is not reset
  between scenes; it persists, shapes future choices, and
  builds toward the climactic decision that uses everything
  the prior choices accumulated.
- **The unchosen path remembered** — the strongest thriller
  protagonists carry awareness of what they didn't choose.
  The asset they didn't protect; the colleague they
  sacrificed; the truth they didn't speak. The
  protagonist's interior register carries the unchosen
  paths, and the prose registers their weight.
- **The climactic choice that uses everything** — the
  thriller's structural peak is typically a forced choice
  the protagonist could not have made at the start. The
  climactic choice's specific shape — what it costs, what
  it protects, what it will mean to live with — should
  draw on the prior choices' accumulated weight.

The architecture fails when forced choices are simulated
rather than genuine. Generic "the protagonist had to make
a hard choice" without specific competing goods is the
failure mode; specific named alternatives with specific
identifiable costs is the technique. The form's strongest
practitioners (le Carré is the canonical example; Mick
Herron's *Slough House* sequence; Joseph Kanon's literary-
historical thrillers; Don Winslow's *Power of the Dog*
trilogy) make moral cost visible across hundreds of pages,
with the protagonist's specific accumulated weight by the
climax inseparable from the form's emotional payoff.

Test: identify the forced-choice moments in the manuscript
and verify each presents specific competing goods with
specific costs that persist into subsequent chapters. If
choices are reset between scenes or if costs are generic,
the architecture has not been deployed.

### The Tradecraft Discipline

Thriller fiction's procedural authenticity requirement.
Spy / military / law-enforcement / legal / political
thriller readers include practitioners and serious
followers of the relevant fields; tradecraft mistakes
break the spell faster than character or plot mistakes
because they signal the writer doesn't know the world
they're writing about. The discipline:

- **Operational accuracy** — how intelligence services
  actually work (compartmentalisation; legend-building;
  tradecraft tools and techniques; surveillance detection;
  asset handling protocols; communications security; the
  specific procedures of the specific service the
  manuscript depicts). Generic spy-movie tradecraft is the
  failure mode; specific researched protocols are the
  technique.
- **Equipment specificity** — weapons, communications,
  surveillance equipment, vehicles, breaching tools, body
  armour, medical kit, all rendered with period-and-
  context-specific accuracy. The professional reader
  notices when the wrong magazine capacity is given, when
  a discontinued radio model appears, when a specific
  piece of kit is described in a way that reveals the
  writer's research limit.
- **Communications protocols** — how operatives actually
  communicate (voice / text / dead drop / brush pass /
  signal sites / specific operational language) and the
  specific failure modes of each. Generic "he called his
  handler" is the failure mode; specific channel selection
  with specific operational reasoning is the technique.
- **Hierarchy and chain of command** — who reports to
  whom; what authority each rank carries; what
  authorisation is required for what action; what
  paperwork follows what kind of operation. Generic
  "agency" treatment without specific organisational
  reality is the failure mode.
- **Legal frameworks** — for thrillers involving law
  enforcement or legal matters, the specific applicable
  law, the specific procedural requirements, the specific
  jurisdiction's specific rules. The legal thriller's
  reader includes lawyers; the political thriller's
  reader includes Hill staffers and Beltway-adjacent
  professionals.
- **Geographic and temporal accuracy** — the specific city,
  the specific embassy district, the specific border
  crossing, the specific period's political context. The
  Cold War-era thriller and the post-9/11 thriller and the
  contemporary-China thriller operate in different
  professional realities; conflating them loses the
  reader.

The discipline requires research. The strongest thriller
practitioners (Le Carré drew on his SIS service; Forsyth on
his journalism background; Tom Clancy researched
exhaustively; Daniel Silva on Mossad consultation; Jason
Matthews on his CIA career; Mick Herron on close attention
to British intelligence-community texture) ground their
fiction in specific researched reality. The form's failure
mode is the writer who imagines tradecraft from movie
exposure rather than researching the actual specifics.

Test: identify the manuscript's tradecraft moments and
verify each operates with specific researched detail rather
than with generic spy-thriller convention. If tradecraft
moments could be lifted from any other thriller without
revision, the discipline has not been deployed; if they
operate with specific period-and-service-and-jurisdiction
detail, the form's professional contract is being honoured.

### Thriller AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "time was running out" | Show the specific countdown |
| "the hunter became the hunted" | Show the specific role reversal moment |
| "a race against time" | Show the specific clock and specific deadline |
| "the stakes couldn't be higher" | Name the specific stakes |
| "everything was connected" | Show the specific connection |
| "the conspiracy went deeper than anyone imagined" | Show the specific new layer |
| "they were one step ahead" | Show the specific tactical advantage |
| "a deadly game of cat and mouse" | Show the specific pursuit |
| "the truth would shock everyone" | Show the specific truth |
| "a web of intrigue" | Show the specific intrigue through one interaction |
| "the body count was rising" | Show the specific victim and why they matter |
| "his training kicked in" | Show the specific trained behaviour — door cleared, weapon checked, sightlines mapped |
| "the operation had gone sideways" | Show what specifically went wrong and what the protagonist now must improvise |
| "no one was who they seemed" | Show one specific revelation about one specific character; "no one" without specificity is summary |
| "he had a bad feeling" | Show what specifically alerted him — the parked car, the missed check-in, the tail that didn't break off |
| "the safe house wasn't safe anymore" | Show the specific breach indicator and the precise sequence of decisions that follow |
| "the asset was burned" | Show what specifically compromised the asset — the photograph; the intercept; the betrayer's action |
| "they were running out of time" | Show the specific clock and what specifically happens when it expires |

## Genre-Specific Revision Rules

### Six-Pass Thriller Audit (Run FIRST in editorial pipeline)

The Thriller Audit runs every chapter through six named
passes. Run them in order — each builds on the last.
Thriller revision must hold the form's signature contracts:
pacing (forward momentum maintained); competence and
plausibility (protagonist earns victories); action
authenticity (scenes the reader can diagram); information
control (reader's knowledge calibrated against
protagonist's); antagonist coherence (the opposition makes
sense from inside its own plan); and tradecraft authenticity
(procedural specificity the genre's professional reader
expects).

#### Pass 1: Pacing

The Pacing pass is the first defence against Pacing Collapse
and Clock Abandonment. Read every chapter against the
forward-momentum contract: does this chapter advance the
plot in at least one concrete way, could it be removed
without the reader losing anything (if yes, cut or merge),
does it end at a higher tension level than it began, and is
there a clear reason for the reader to turn to the next
chapter? Apply the breather-ratio verification by mapping
each chapter as ACTION, TENSION, INVESTIGATION, or
BREATHER — never more than one BREATHER in a row, Act 3
must contain ZERO full breather chapters, and total
breather content must come in under 15% of manuscript.
Verify the ticking clock: it must be first established by
the end of Act 1, no more than 4 chapters may pass without
a clock reference, the clock must compress in Act 3, and
the deadline must never be quietly abandoned (this is an
automatic fail). Verify set piece distribution: major
action sequences spaced at roughly 25%, 50%, and 85%
through the manuscript, each set piece using a different
arena, escalating in scope and stakes, with lasting
consequences. Close the pass with the hook rotation check:
list every chapter-ending hook and its type, flag
consecutive same-type hooks, and verify Act 3 hooks land
stronger than Act 1 hooks.

#### Pass 2: Competence and Plausibility

The Competence and Plausibility pass enforces the form's
earned-victory contract. Verify protagonist competence: the
hero earns every victory through skill, preparation, or
sacrifice — not luck, not coincidence, not sudden
unexplained ability. Verify antagonist competence: the
villain makes intelligent decisions based on the information
they actually have, not on what would be convenient for the
protagonist's path. Verify physical plausibility: injuries,
distances, ammunition counts, and fatigue levels are
tracked across chapters with continuity that holds. Verify
technical accuracy: weapons, vehicles, communications, and
procedures pass basic accuracy checks against the genre's
practitioner-aware reader. Verify the no-deus-ex-machina
contract: every rescue, escape, and victory must be
traceable to an earlier setup the reader can locate in the
manuscript. Verify stakes maintained: stakes go only UP
across the arc (with brief tactical retreats permitted, but
no unexplained regression). Verify consequence persistence:
an injury in Chapter 5 must still affect the protagonist in
Chapter 15, and equipment lost in Act 1 must remain lost
through Act 3 unless deliberately reacquired on-page.

#### Pass 3: Action Scene

The Action Scene pass tests every action sequence against
the form's diagrammable-clarity contract. For each action
scene, verify that the arena is established before fighting
starts (the reader holds a spatial layout in mind);
choreography tracks (no character teleports across the
room or through walls; every move is physically possible
from the last established position); ammunition and weapon
continuity holds (if the protagonist fired 15 rounds from a
15-round magazine, they are empty — and the manuscript
shows the reload or the running-dry); physical cost is
rendered (the protagonist is hurt, tired, or depleted after
the fight, and that depletion carries forward); duration is
plausible (a hand-to-hand fight lasting 10 minutes is
unrealistic; 60-90 seconds is typical, and gunfights compress
even tighter); civilian presence is accounted for (if the
fight is in public, bystanders react — running, screaming,
filming, freezing); and the outcome advances the plot
(every action scene must resolve something or reveal
something, never sit as set-piece spectacle without
narrative consequence).

#### Pass 4: Information Reveal

The Information Reveal pass enforces the form's information-
control contract for conspiracy and pursuit plots. Map every
major piece of information across the manuscript: when it
was planted, when it was revealed, to whom (protagonist /
reader / both / neither). Verify the reader has enough
information to follow the logic but not enough to get
significantly ahead of the protagonist (more than one major
secret ahead and dramatic irony tips into reader frustration).
Check that the protagonist's deductions are shown rather
than told — the reader watches the protagonist assemble
the picture, including the false-positive turns and the
moments of genuine insight. Confirm that no critical
information appears for the first time in the climax —
every climactic reveal must be traceable to seeds planted
earlier in the manuscript. Verify that false conclusions
are debunked BEFORE the final act, not held until the last
minute (the protagonist must be wrong about something
important by the midpoint and right enough by Act 3 to
drive the climax through their own deduction). The pass
also confirms the form's no-cheating rule: the manuscript
never withholds information the POV character clearly
possesses.

#### Pass 5: Antagonist Coherence

Build the antagonist's plan ledger. Every step the antagonist
takes from before the book begins through the climax: their
goal, their available resources, their assessment of the
protagonist, their decision points, their adaptive responses
when the protagonist disrupts their plan. Read the manuscript
against the ledger and ask: does the antagonist's plan make
sense from inside the antagonist's own information state?

Verify the antagonist makes intelligent decisions based on
their available information. The genre's most-flagged
antagonist failure: villains whose decisions only make sense
because the writer needed them to make those decisions for
the plot to work. The strongest thriller antagonists operate
by their own coherent logic; their plan is what a competent
adversary would actually do given their goals and resources.

Verify the antagonist's responses to the protagonist's
disruptions are plausible. When the protagonist disrupts the
plan in chapter twelve, the antagonist's chapter-thirteen
adaptation should be what a competent operator would
actually do — not what makes the protagonist's job easier
or what produces the next set-piece the writer wanted.

Verify the antagonist has a believable goal. Generic "world
domination" or "revenge" without specific concrete what-they-
want is the failure mode; specific goals with specific
desired outcomes the reader can name is the technique. The
antagonist should be able to articulate, in their own
terms, what they are trying to achieve and why their plan
is the right way to achieve it.

Test: write a one-paragraph antagonist plan from inside the
antagonist's perspective. Does the plan make sense as
something a competent person with the antagonist's
resources and worldview would attempt? If yes, antagonist
coherence is operating. If the plan only makes sense as
plot necessity, the audit has flagged a structural issue.

The pass also checks for the related failure mode:
antagonist who is opaque to the reader. Thriller readers
expect to understand the antagonist's plan by the climax
(even if not in real-time). If the climactic confrontation
arrives without the reader being able to articulate what
the antagonist was trying to do and why, the information-
control audit (Pass 4) and antagonist-coherence audit (this
pass) should both have caught the issue earlier.

#### Pass 6: Tradecraft Authenticity

For thrillers involving intelligence services, military
operations, law enforcement, legal proceedings, political
processes, or other professional domains, run a dedicated
tradecraft pass. The genre's professional reader detects
tradecraft mistakes immediately and loses confidence in
the rest of the book. The pass:

- **Operational protocols** — verify that the manuscript's
  depicted operations follow the actual procedures of the
  service / agency / organisation depicted. Compartmentalisation,
  legend-building, surveillance detection, asset handling,
  communications security — each should operate as it
  actually operates, not as movie conventions.
- **Equipment specificity** — every weapon, every piece of
  surveillance equipment, every vehicle, every piece of
  kit should be accurate to the period and service. The
  professional reader notices when equipment is anachronistic,
  miscalibrated, or fictional in a way that breaks the
  spell.
- **Communications discipline** — every operational
  conversation should reflect the service's actual
  communications protocols. Generic "he called his handler
  on a secure line" is the failure mode; specific channel
  selection with specific operational reasoning is the
  technique.
- **Hierarchy and authorisation** — verify that operations
  in the manuscript would actually be authorised at the
  level depicted. Legal authorities, departmental
  approvals, oversight requirements — generic depictions
  of "the director okayed it" miss the actual layered
  authorisation real operations require.
- **Geographic and political accuracy** — verify the
  manuscript's depicted locations exist where it places
  them; that the political context is accurate to the
  period; that the specific embassies / safe houses /
  border crossings / specific institutional landmarks are
  real or plausibly fictionalised.
- **Legal accuracy** — for thrillers with legal or
  procedural elements, verify that depicted legal
  frameworks match real applicable law. Search-and-seizure
  rules, evidentiary requirements, procedural timelines,
  jurisdictional limits — the legal-thriller reader
  includes lawyers who detect generic-legal-thriller
  treatment immediately.

The pass requires research. Where research has been
incomplete, the manuscript should either acknowledge the
limit (the operational fictionalisation declared as
deliberate, the procedural compression noted) or revise
toward accuracy. The strongest thriller practitioners
engage in extensive consultation with practitioners of the
domains they write about; the form's failure mode is the
writer who relied on movies and other thrillers as their
research base.

Test: pick three significant tradecraft moments in the
manuscript and verify each against actual practitioner
sources where possible. If tradecraft moments could be
lifted from any other thriller without revision, the
audit has flagged a research gap; if they operate with
specific period-and-service-specific particulars, the
form's professional contract is being honoured.

## Names & Patterns to Avoid

### Thriller-Specific Character Names. NEVER USE
- Protagonist names: Jack Stone, Max Steel, Blaze, Hunter, Gunner, Hawk, Wolf
- Antagonist names: Viktor (any spelling), Dimitri, Hans, any name that "sounds villainous" by ethnicity
- Handler names: Control, The Director, The Old Man (unless deliberately homaging Le Carre)
- Female character names: exclusively soft/pretty names for the only woman in the cast (diversify)

### Thriller-Specific Organization Names. NEVER USE
- "The Shadow [Noun]" (The Shadow Council, The Shadow Protocol)
- "Project [Greek Letter]" (Project Omega, Project Alpha)
- "Operation [Dramatic Adjective]" (Operation Darkfall, Operation Endgame)
- "[Color] [Noun]" for covert ops (Black Horizon, Red Cipher, Dark Aegis)

### Thriller-Specific Plot Patterns. AVOID
- The protagonist is framed for a crime they didn't commit (overused opener unless subverted)
- The female character exists only to be kidnapped/threatened as motivation (fridging)
- The traitor is the person who was "too helpful" from the start
- The protagonist goes rogue and accomplishes more alone than entire agencies
- The antagonist's plan requires the protagonist to do exactly what they did (too-clever plotting)
- The countdown stops at 0:01 (find a more inventive resolution)
- Opening with the protagonist waking up / looking in a mirror / on an airplane

### Use Instead
- Real names from census data appropriate to character background (Michael, Sarah, James, Daniel, David, Priya, Catherine, Laura)
- Organizations with bureaucratic real-world names (National Infrastructure Security Division, Joint Threat Assessment Group)
- Operations named after mundane things (Operation GARDEN FENCE, Operation BLUE LAMP. real ops have boring names)
- Diverse cast with names matching actual demographic backgrounds of their professions
- Plot twists that feel inevitable in hindsight, not "gotcha" surprises
- Countdowns that resolve through protagonist action at any point. not always at the last second

## Comp Titles

Thriller's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Day of the Jackal* — Frederick Forsyth (1971): the procedural-thriller template; tradecraft specificity benchmark.
- *The Silence of the Lambs* — Thomas Harris (1988): psychological-thriller-procedural hybrid; defined modern serial-killer thriller.
- *The Bourne Identity* — Robert Ludlum (1980): action-thriller / spy-adjacent benchmark.
- *Mystic River* — Dennis Lehane (2001): literary-thriller crossover; character-driven thriller architecture.

### Contemporary (current best-in-class)

- *Gone Girl* — Gillian Flynn (2012): the modern marriage-thriller benchmark; reframed the category's voice.
- *The Girl on the Train* — Paula Hawkins (2015): unreliable-narrator thriller; mass-market success.
- *I Am Pilgrim* — Terry Hayes (2013): contemporary international-thriller.
- *The Reckoning* — John Grisham (2018): legal-thriller-adjacent benchmark.
- *The Last Thing He Told Me* — Laura Dave (2021): contemporary domestic-thriller.
- *Tomorrow, and Tomorrow, and Tomorrow* — Gabrielle Zevin (2022, thriller-adjacent): demonstrates literary-thriller crossover.
- *The Plot* — Jean Hanff Korelitz (2021): writer-protagonist literary-thriller.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. The dominant style for action and conspiracy thrillers. Wide-angle compositions, dramatic lighting, and film-poster energy that promises spectacle and pace.
- **Photorealistic**. High-impact photographic imagery (city skylines, lone figures, weapons, vehicles) with heavy post-processing. Signals grounded, modern storytelling.
- **Typographic**. Bold, oversized title treatment dominating the cover. Works for established authors or when the title itself is the hook. Minimal imagery lets the typography do the heavy lifting.
- **Minimalist**. A single striking object or symbol (a bullet, a clock face, crosshairs) on a dark field. Effective for cerebral conspiracy thrillers where the threat is invisible.

### Genre Cover Aesthetics
- **Styles:** Dark and moody, high contrast, cinematic widescreen compositions, urban noir, silhouette-driven imagery
- **Colours:** Deep blacks, blood reds, steel greys, electric blues, burnt orange accents. palette should feel nocturnal and urgent. Avoid warm, inviting tones.
- **Elements:** Shadowy figures in motion, city skylines at night, crosshairs or targeting imagery, ticking clocks, lone silhouettes against dramatic backdrops, rain-slicked streets, surveillance imagery
- **Typography:** Bold sans-serif for action thrillers (Impact, Bebas Neue, condensed gothics). Condensed or compressed typefaces signal urgency. Title should dominate. often larger than the author name unless the author is the brand. Metallic, embossed, or textured effects common for premium feel.

### Subgenre Variations
- **Action Thriller**. Maximum visual impact. Silhouetted figures, explosions, weapons, vehicles. Cinematic lighting. Red and black dominate. The cover should feel like a movie poster.
- **Conspiracy Thriller**. More restrained. Typographic-heavy or single-symbol covers. Government buildings, redacted documents, shadowy corridors. Blues, greys, and blacks. The cover should whisper danger, not shout it.
- **Techno Thriller**. Circuit board textures, digital glitch effects, surveillance aesthetics, code fragments. Neon accents (cyan, green) against black. The cover signals technology-as-threat.
- **Survival Thriller**. Isolated landscapes, harsh environments (mountains, ocean, forest, desert). A lone figure dwarfed by nature. Desaturated palettes with a single accent colour. The cover signals vulnerability and scale.
- **Political Thriller**. Capitol buildings, flags, presidential seals, formal interiors. Dark, muted palettes with gold or red accents. The cover signals power and institutional menace.

### Market Positioning
Thriller covers must signal PACE and DANGER within the first second of a thumbnail view. On Amazon, the title must be legible at small sizes. condensed bold type in high-contrast colours against dark backgrounds. The best-performing thriller covers use 2-3 colours maximum and a single focal point. Readers scanning the thriller category expect dark covers with sharp typography; anything bright, playful, or illustrative will be scrolled past. Position between the Lee Child / Jack Carr end (bold, cinematic, photorealistic) and the Daniel Silva / John le Carre end (typographic, restrained, sophisticated) based on subgenre.

### Cover Design DON'Ts
- Do NOT use romance-coded colours (pinks, soft purples, pastels). they signal the wrong genre entirely
- Do NOT use whimsical, handwritten, or script fonts. they undermine urgency and authority
- Do NOT use busy illustrated styles (watercolour, cartoon, hand-drawn). thrillers demand photographic or cinematic realism
- Do NOT place too many visual elements on the cover. one focal point is stronger than five competing images
- Do NOT use stock photography that looks generic or low-resolution. thriller readers are visually sophisticated
- Do NOT use bright white backgrounds. thriller covers are dark by convention and expectation
- Do NOT use dated design trends (lens flares, heavy drop shadows, 3D chrome text). they age a cover instantly
- Do NOT make the author name larger than the title unless the author is a household name. for debut and midlist authors, the title sells the book
