---
name: sales-log-format
description: "Schema for the optional per-project sales-log.md file. Manual-entry markdown table; ebook / KU / print / audio + ad spend; multi-currency (USD / GBP / EUR). Read by Catalog Overview when present, ignored when absent."
version: "2.3.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*


# Sales Log Format

This is the schema for `sales-log.md` — an optional file users
maintain at the top level of a project folder
(`~/Documents/Ideorix-Projects/{Title}/sales-log.md`). When
present, Catalog Overview parses it and reports last-month net
margin, format mix, trend, and surfaces six sales-derived
opportunity flags. When absent, Catalog Overview reports
`(no log)` and moves on with no nagging — sales tracking is
opt-in.

## Why the format is fixed

Two consumers read this file:

1. **Catalog Overview's parser** (this engine).
2. **Kimi in any session with file access** to the project
   folder — Cowork, Kimi Desktop, Kimi Code, kimi.ai with
   project access. The user can say "Add August sales for The
   Clean Label: …" and Kimi reads, appends a properly-formatted
   row, and saves. Works in v2.3.0 from day one.

Both need to agree on the table shape. Locking the format here is
the v2.3.0 contract.

## Canonical example

```markdown
# Sales Log — {Title}

primary_currency: USD

| Month   | Curr | Ebook            | KU                | Print          | Audio           | Ad Spend  | Notes               |
|---------|------|------------------|-------------------|----------------|-----------------|-----------|---------------------|
| 2026-08 | USD  | 47u / $145.78    | 12.4k / $54.56    | 8u / $71.92    | 12u / $87.40    | $112.40   | AMS + BookBub run   |
| 2026-08 | GBP  | 12u / £35.40     | 3.1k / £8.20      | 2u / £15.60    |                 |           | UK marketplace      |
| 2026-09 | USD  | 31u / $96.10     | 9.8k / $43.12     | 5u / $44.95    | 10u / $72.10    | $48.20    | AMS only            |
```

## Schema

**Eight columns, in this order:**

| # | Column | Format | Required |
|---|---|---|---|
| 1 | `Month` | `YYYY-MM` | yes |
| 2 | `Curr` | 3-letter ISO code (USD / GBP / EUR) | yes |
| 3 | `Ebook` | `Nu / amount` (e.g. `47u / $145.78`) or empty | empty cell allowed |
| 4 | `KU` | `pages / amount` (e.g. `12.4k / $54.56`) or empty | empty cell allowed |
| 5 | `Print` | `Nu / amount` or empty | empty cell allowed |
| 6 | `Audio` | `Nu / amount` or empty | empty cell allowed |
| 7 | `Ad Spend` | `amount` only (e.g. `$112.40`) or empty | empty cell allowed |
| 8 | `Notes` | free text | empty cell allowed |

## Rules

- **One row per month per currency.** Multi-marketplace authors
  split by region into separate rows — USD for Amazon.com, GBP
  for Amazon.co.uk, EUR for Amazon.de, and so on. No conversion
  is required. Each currency stays in its own row.

- **`Nu` (units)** for Ebook / Print / Audio: integer count
  followed by `u` (e.g. `47u`, `8u`).

- **`pages / amount`** for KU: thousands shorthand `k` is
  optional but conventional for large page counts
  (`12.4k` ≡ 12 400; `3.1k` ≡ 3 100). Plain integers also
  accepted (`12400`).

- **Amounts** carry a currency symbol matching the row's `Curr`
  column (`$` for USD, `£` for GBP, `€` for EUR). Decimal point,
  not comma. Two decimal places conventional but not required.

- **Ad Spend** is the row's currency only — no unit count.
  Optional. Empty cell when no ads ran that month. Captures
  paid-promotion cost (Amazon Ads, BookBub, Facebook Ads, etc.)
  so the dashboard can show **net margin** (gross − ad spend),
  not just gross revenue.

- **`primary_currency:` header line** is informational only.
  Documents which currency the user thinks of as primary; the
  per-row `Curr` column is what the parser actually reads. If
  multiple projects under the same pen name declare different
  primary currencies, Catalog Overview never reconciles them —
  per-pen-name aggregation lists each currency on its own line.

- **Notes column** is captured verbatim. Useful for promo
  context ("BookBub Day 12-15"), KU enrolment changes,
  one-off events. Surfaced in full when the user asks "explain
  this month."

- **Empty cells allowed** anywhere a format had no activity that
  month. Empty Ad Spend means "no ads ran" — distinct from `$0`
  (which would be a zero-cost campaign, vanishingly rare).

## Parser tolerance

The Catalog Overview parser is **fragile-but-tolerant**. Catalog
Overview never crashes on a malformed sales log; it reports what
it could read and flags what it couldn't.

| Issue | Behaviour |
|---|---|
| Wrong number of columns on a row | Skip row, log `(parse error in row N)`, continue |
| Unrecognised currency code | Skip row, log warning, continue |
| Malformed cell (non-numeric `Nu` or amount) | Skip cell (treat as empty), continue |
| `Nu / amount` shape but with extra spaces | Tolerated — whitespace inside cells is normalised |
| `KU` cell uses plain integer instead of `k` shorthand | Tolerated |
| File present but no data rows yet (header only) | Reported as `(no data yet)` — distinct from `(no log)` |
| File missing | Reported as `(no log)` — never an error, never blocks anything |

## Adding rows

The recommended path is **ask Kimi in any session with file
access**:

> "Add August sales to The Clean Label: 47 ebook units, $145.78.
> KU 12,400 pages, $54.56. 8 print at $71.92. 12 audio at $87.40.
> Ad spend $112.40. Note: AMS + BookBub run."

Kimi reads the existing file, appends a properly-formatted row,
and saves. Works in any Kimi session (Cowork, Kimi Desktop,
Kimi Code, kimi.ai with project access).

The fallback is **edit the file directly** in any text editor
(Notepad, TextEdit, VS Code, Obsidian, etc.). Add a row. Save.
Roughly 5 seconds at month-end.

A formal triggered entry workflow ("log September sales for The
Clean Label" → guided prompt) is pending platform integration
(KDP / ACX / ad-platform CSV ingestion is the natural source for
structured entry; until that lands, the v2.3.0 contract is the
file format, not a structured entry flow).

## Boundaries (out of scope)

- **No CSV import / parsing.** Manual entry only.
- **No KDP / ACX / ad-platform API integration.** No automated
  data ingestion of any kind.
- **No currency conversion.** Per-pen-name aggregation lists
  each currency on its own line — pending platform integration
  if multi-currency users surface the need.
- **Not a tax / accounting document.** Captures last-month
  snapshot data (units, gross, ad spend, notes) — not the
  fields a tax filing needs (transaction dates, jurisdictions,
  expenses, capital gains). Tax-grade export is a separate
  future feature.
