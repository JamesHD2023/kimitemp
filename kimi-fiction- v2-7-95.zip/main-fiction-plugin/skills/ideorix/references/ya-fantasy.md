---
name: ya-fantasy-genre
description: Genre-specific instructions for YA fantasy fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
---

# YA Fantasy. Genre Plugin

## Metadata
- id: ya-fantasy
- name: YA Fantasy
- icon: ⚔️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["The Hero's Journey", "Save the Cat", "Three-Act Structure", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **High Fantasy YA**. Fully secondary world: kingdoms, magic systems, prophecies; the teenager who discovers they're destined for something enormous; Garth Nix, Tamora Pierce territory
- **Urban Fantasy YA**. Magic in the modern world: the hidden magical society, the doorway to another realm, supernatural elements in a contemporary teen's life
- **Portal Fantasy YA**. A teen crosses into another world: the wardrobe, the portal, the glitch; fish-out-of-water meets coming-of-age in a magical setting
- **Dystopian/Fantasy Hybrid**. A fantastical world with dystopian elements: magical oppression, caste systems based on power, the teen who rebels; Hunger Games meets magic
- **Fairy Tale Retelling**. Classic tales reimagined through a YA lens: subverted expectations, diverse perspectives, the old stories made new and relevant
- **Romantasy YA**. Fantasy with romance at the centre: the forbidden love, the rival-to-lover, the bond between characters across magical divides; fantasy world, YA-appropriate romance

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Brisk with moments of wonder. the discovery of magic should thrill; the action should breathe; the emotional beats need space but the plot needs momentum
- Must open with: The protagonist's voice in their world. establishing WHO they are before WHAT they can do; the magic comes second, the person comes first

BEATS PER CHAPTER
1. Identity Beat. The protagonist discovers something about who they are: a power, a heritage, a truth; identity formation is the engine of both YA and fantasy
2. World-Discovery Beat. Something about the magical world is revealed: a rule, a place, a history; the reader learns alongside the protagonist
3. Power Beat. The protagonist's abilities are tested, expanded, or fail; magic has a cost and a learning curve
4. Alliance Beat. Relationships are formed, tested, or betrayed: the team, the mentor, the rival, the love interest; who can be trusted in a world of deception
5. Stakes Beat. The personal and the epic converge: what the protagonist wants for themselves vs. what the world needs from them

YA FANTASY ARCHITECTURE
- The PROTAGONIST comes first, the magic comes second: the reader must care about the person before they care about the powers
- IDENTITY IS THE QUEST: the external quest (defeat the villain, save the kingdom, master the power) mirrors the internal quest (who am I? what do I stand for? who do I choose to be?)
- MAGIC HAS RULES AND COST: the magic system must be internally consistent; power must come at a price; the solution cannot be "more magic"
- The CHOSEN ONE problem: if the protagonist is chosen, the story must address WHY it matters that it's THIS person, not just anyone with the prophecy; agency must override destiny
- FOUND FAMILY is the genre's emotional core: the team, the group, the unlikely alliance; teenagers forming bonds outside their biological family
- MENTORS are complicated: the wise guide may have their own agenda, be wrong, or need to be surpassed; the protagonist must ultimately make their own choices
- The VILLAIN represents something the protagonist fears becoming: power corrupts, righteousness hardens, grief destroys; the antagonist should be a warning
- POV: First person present (YA immediacy) or tight third past (allows scope for world-building)

WORLD-BUILDING FOR YA
- ECONOMY of exposition: reveal the world through experience, not lecture; the protagonist discovers it, the reader discovers it with them
- WONDER must be preserved: even in dark fantasy, there should be moments where magic is awe-inspiring; don't let world-building become mundane
- RULES before exceptions: establish what magic can and can't do before breaking those rules
- The world should REFLECT the theme: if the story is about freedom, the world should contain oppression; if about identity, the world should force choices about who to be
- TEEN PERSPECTIVE on the world: a teenager sees differently. they question authority, challenge traditions, notice the unfairness adults have accepted

THE POWER CURVE
- Powers DEVELOP over the story: the protagonist doesn't start fully capable
- Each new ability comes with a cost or complication
- Mastery requires practice, failure, and often sacrifice
- The climactic use of power should require everything the protagonist has learned AND who they've become
- Power without wisdom is dangerous. the protagonist must learn this

FORBIDDEN IN YA FANTASY
- The protagonist is special just because (they must EARN their role through character, not just prophecy)
- World-building dumps that stop the story (reveal through experience, not textbook)
- Magic without cost or consequence (power must have a price)
- Adults solving everything while the teen watches (agency is non-negotiable)
- Stereotypical fantasy without subversion (the tropes must be earned or challenged)
- Hopeless endings (YA fantasy needs hope. the world can be saved, the person can grow)
- One-dimensional evil (the villain should have a point, even if their methods are wrong)
- Sexual content beyond YA norms (romance yes, explicit content no)
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation through worldbuilding, Affection with the cast, Anticipation through quest structure, Revelation.

VOICE & TONE
- POV: First person present (YA immediacy combined with fantasy discovery) or tight third past
- Voice: The protagonist's authentic teen voice. even in a fantasy world, they think and feel like a teenager; wonder, snark, fear, intensity all present
- Tone: Epic but intimate. the fate of the world matters, but so does the protagonist's first kiss, their fight with their best friend, their fear of becoming their parent
- Register: Accessible but not simplistic; the language of the fantasy world flavours the voice without overwhelming it

PROSE IMPERATIVES
- WONDER WRITING: magic must feel magical
  - The first experience of magic: rendered with full sensory detail, awe intact
  - Familiar-but-different: the world should feel real enough to inhabit and strange enough to thrill
  - The beauty of the world is a reason to save it. describe what's worth fighting for
  - Wonder diminishes naturally (the protagonist gets used to magic) but should return at key moments
- TEEN VOICE IN A FANTASY SETTING: the voice must stay authentic
  - A teenager in a fantasy world still thinks like a teenager: they're scared, excited, awkward, funny
  - Modern teen sensibility is fine even in secondary worlds. the voice is for the reader, not the setting
  - The protagonist QUESTIONS the world: Why do we do this? Who decided? That's not fair.
  - Emotional truth takes precedence over world-building accuracy
- ACTION WRITING: fantasy action that serves character
  - Fight scenes are character scenes. how someone fights reveals who they are
  - The body in action: fear, adrenaline, pain, exhaustion. physical reality even in magical combat
  - Powers in combat: show the cost (fatigue, pain, moral weight) not just the spectacle
  - Brevity: real fights are fast and chaotic; extended choreography loses tension
- WORLD THROUGH CHARACTER: exposition that doesn't feel like exposition
  - The protagonist's reactions to the world are more important than the world itself
  - Show what's normal (the character doesn't notice it) and what's new (they do)
  - Cultural details through behaviour, not description: how people greet, eat, worship, argue

DIALOGUE CRAFT
- Fantasy world dialogue that doesn't feel stilted: avoid "thee" and "thou" unless the setting demands it
- Each character's speech reflects their position in the world: royal, common, magical, outsider
- The protagonist's voice should stand out from the fantasy-world characters. they think differently
- Banter between team members creates chemistry and reveals character dynamics
- The villain's voice: persuasive, reasonable, offering something the protagonist actually wants
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. YA FANTASY

OPENING: Identity + world + stakes woven together. Teen voice comes FIRST. who
they are before what they can do. Contemporary sensibility overlaid on fantasy world.
The reader must care about the PERSON before they care about the POWERS.

SENTENCES: Medium, 14-20 words average. Short (6-12) for emotional impact and
action. Longer (22-28) for wonder-moments and world-revelation. YA-immediate rhythm,
not the measured pace of adult fantasy. Interiority is identity-focused: "Who am I?"
beats woven into action and description.

VOCABULARY: Accessible but not simplistic. Fantasy terms introduced through
experience, never glossary. Protagonist's internal voice stays modern-teen even in
secondary worlds. Sensory wonder: magic FELT in the body (heat, pressure, colour).
World-specific terms layered gradually. one or two per page max in chapter 1.

TENSION FLOOR: ≥5. Identity tension: the protagonist doesn't fit or is about to
discover something. The world contains visible injustice the teen notices. Personal
AND larger stakes seeded. Magic's cost or danger hinted. A question the protagonist
cannot ignore about themselves, their heritage, or their world.

RHYTHM: Open in protagonist's teen-authentic voice. Ground through one sensory
experience (not a world-building paragraph). Establish what they WANT. Introduce
fantasy through lived experience. Layer identity-conflict. Close with a hook merging
personal and epic. Dialogue differentiates protagonist from fantasy-world voices.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

YA FANTASY CRAFT (40% of total):
- Magic system internally consistent with clear rules and costs? (0-100)
- Identity quest mirrors external quest (who they ARE determines what they DO)? (0-100)
- Teen voice authentic even in fantasy setting? (0-100)
- Wonder preserved (magic feels magical, world worth saving)? (0-100)

STORY CRAFT (30% of total):
- Found family earns its bonds through shared experience? (0-100)
- The villain represents a genuine threat AND a comprehensible philosophy? (0-100)
- Stakes are both personal (the protagonist's identity) AND epic (the world's fate)? (0-100)
- Hope present even in the darkest moments? (0-100)

PROSE QUALITY (30% of total):
- World-building delivered through experience, not exposition? (0-100)
- Action scenes reveal character (not just choreography)? (0-100)
- Emotional intensity appropriate (teen feelings respected)? (0-100)
- Dialogue natural and differentiated (not stilted fantasy-speak)? (0-100)

AUTOMATIC FAILS (score = 0):
- The protagonist is special only because of prophecy (no earned character growth)
- Magic without cost or consequence
- World-building dumps that stop the narrative
- Adults solving problems while the teen watches
- Hopeless ending without agency or hope
- One-dimensional evil without comprehensible motivation
- Explicit sexual content beyond YA norms
- The voice sounds like an adult author, not a teen protagonist
```

## Continuity Rules

```
YA FANTASY CONTINUITY. WHAT TO TRACK

MAGIC SYSTEM STATE:
- Rules: what magic can and cannot do (must remain consistent)
- The protagonist's current ability level (develops across the story)
- Cost/price: what magic takes from the user (fatigue, pain, years, memory. tracked)
- Limitations: what the protagonist CAN'T do yet (or ever)
- Artefacts/tools: what magical objects exist, who has them, what they do

POWER PROGRESSION:
- What the protagonist could do at each chapter
- When new abilities were discovered or mastered
- Failures: when magic failed and why (should be consistent with rules)
- The ultimate ability: foreshadowed before used in climax

WORLD STATE:
- Political landscape: who rules, who rebels, what alliances exist
- Geography: where the protagonist has been, distances, travel times
- Cultural details: customs mentioned (must be consistent when referenced again)
- History: what's been revealed about the world's past (must not contradict)
- The threat: what the antagonist has accomplished, what they're planning, their timeline

ALLIANCE STATE:
- Team composition: who's in the group, when they joined, why
- Trust levels: who trusts whom, who has secrets, what's been revealed
- Abilities: each team member's skills and limitations
- Romantic dynamics: who's drawn to whom, how it's progressing
- Betrayals: who has betrayed the group (or will), planted seeds

IDENTITY STATE:
- Who the protagonist thinks they are at each point
- What they've learned about their heritage/power/destiny
- The gap between who they are and who the world needs them to be
- Key choices that defined their character (tracked as identity markers)
- The mentor's role: what they've taught, what they've withheld

PROPHECY/DESTINY STATE (if applicable):
- What's been foretold and how much has been fulfilled
- The protagonist's attitude toward their destiny (resistance, acceptance, subversion)
- How destiny and agency interact (does the prophecy allow choice?)
```

## Character Rules

```
YA FANTASY CHARACTER TYPES

THE PROTAGONIST:
- A teenager first, a hero second: their teen concerns (identity, belonging, first love) matter as much as the quest
- The CHOSEN ONE dilemma: if chosen, they should struggle with the burden; they didn't ask for this; they want to be normal
- Power with a learning curve: they're not instantly competent; failure is essential to growth
- Moral complexity: they will face choices between personal desire and greater good. and sometimes choose wrong
- The identity quest: who they become matters more than what they achieve

THE FOUND FAMILY:
- 3-5 companions with complementary abilities and personalities
- Each brings something the protagonist lacks: skill, knowledge, perspective, emotional support
- Internal conflicts: the group doesn't always agree; tensions reflect real friendship dynamics
- Loyalty tested: one member may betray, leave, or sacrifice; the bonds are real because they can break
- The friendships should feel teen-authentic: banter, inside jokes, fierce protectiveness, petty arguments

THE MENTOR:
- Initially helpful, eventually surpassed or complicated
- May have their own agenda that doesn't perfectly align with the protagonist's needs
- Their greatest gift: not knowledge but the confidence that the protagonist can succeed without them
- The mentor's absence or failure is often the turning point. the protagonist must stand alone

THE VILLAIN:
- Represents what the protagonist could become if they made different choices
- Has a philosophy, not just a plan: their vision of the world is wrong but UNDERSTANDABLE
- Was once like the protagonist (or believes they were): the mirror image
- Their weakness should be the opposite of the protagonist's strength: if the protagonist's power is connection, the villain's weakness is isolation

THE LOVE INTEREST:
- A person with their own abilities, arc, and agency. not a reward for heroism
- The romance complicates the quest: loyalty, distraction, vulnerability, strength
- Chemistry shown through specific moments, not declared
- The relationship should test and reveal the protagonist's character

VOICE DIFFERENTIATION:
- Protagonist: teen voice. immediate, emotional, questioning, growing
- Found family: each with distinct speech patterns, humour, and concerns
- Mentor: measured, sometimes cryptic, occasionally wrong. the voice of experience that isn't always right
- Villain: persuasive, reasonable, offering what the protagonist genuinely wants
- Love interest: the person who sees the protagonist most clearly
```

## Arc Rules

```
YA FANTASY STORY STRUCTURE

ACT 1: THE ORDINARY WORLD AND THE CALL (first 25%)
- The protagonist in their before-life: who they are, what they lack, what they don't yet know about themselves
- The inciting incident: discovery of magic, the summons, the revelation of heritage, the world breaking in
- Initial resistance: the protagonist doesn't want this; they want to be normal (or they leap in and quickly learn it's harder than expected)
- The mentor appears: guidance, the first lessons, the beginning of the power curve
- END OF ACT 1: The protagonist crosses the threshold. they're in the magical world (literally or metaphorically) and can't go back

ACT 2A: THE EDUCATION (to midpoint)
- Power develops: training, failure, small victories, the cost becoming clear
- Found family forms: the team comes together, each member earned through shared experience
- The world reveals itself: politics, history, the shape of the threat, the rules of magic
- Romance begins: attraction, tension, the complication of feelings during a quest
- MIDPOINT: A major revelation. about the protagonist's identity, the villain's plan, or the true nature of the quest; what they thought they were fighting for is not the full picture

ACT 2B: THE CRUCIBLE (midpoint to dark moment)
- The team is tested: betrayal, loss, failure, the discovery that the villain is closer than they thought
- The protagonist's powers are not enough: they need something beyond strength. wisdom, sacrifice, connection
- The mentor fails or is absent: the protagonist must make their own choices
- Personal desires conflict with the mission: love vs. duty, safety vs. courage, self vs. others
- DARK MOMENT: The worst loss. a companion, a battle, a piece of themselves; the protagonist doubts everything; the villain seems unbeatable

ACT 3: THE BECOMING (final 25%)
- The protagonist chooses who they are: identity resolved through action, not declaration
- The final confrontation uses everything they've learned. power AND character
- The villain is defeated not by superior force but by the quality the protagonist embodies (love, sacrifice, connection, hope)
- Relationships resolve: the found family's bonds confirmed, the romance clarified, the mentor's legacy honoured
- HOPEFULLY EVER AFTER: the world is saved (or changed), the protagonist is transformed, and the future is open with possibility

YA FANTASY PACING:
- ACT 1: brisk. establish character fast, get to the magic
- ACT 2A: varies. world-building scenes can slow, but action and relationship scenes maintain momentum
- ACT 2B: accelerating. the threats compound, the pace picks up
- ACT 3: fast and intense. the climax should be breathless, the resolution earned but brief
```

## Timeline Rules

```
YA FANTASY TIMELINE

QUEST TIMELINE:
- Duration: typically weeks to months (rarely years in single books)
- Travel time: consistent with the world's geography (if it took three days to get there, it takes three days to get back)
- Deadlines: the villain's plan has a timeline; the eclipse, the coronation, the ritual. create urgency

POWER TIMELINE:
- Track the protagonist's ability development chapter by chapter
- Training takes time: mastery is not instant
- Exhaustion and recovery: after major magical effort, recovery time must be consistent
- The power curve should match the story arc (peak ability at climax)

WORLD TIMELINE:
- Historical events referenced must remain consistent
- Seasonal changes: if the quest spans months, seasons shift
- Political events: wars, alliances, betrayals happen on their own timeline
- The villain's progress: they're not waiting. their plan advances while the protagonist trains

RELATIONSHIP TIMELINE:
- Trust builds over shared experience (not instant)
- Romance develops through specific moments (not declarations)
- Betrayal seeds must be planted before the betrayal occurs
- Found family bonds strengthen through crisis (track the bonding moments)
```

## Genre-Specific Craft Techniques

YA fantasy is the cluster bridge between fantasy (its
worldbuilding parent) and YA contemporary (its voice and
audience parent). The form retains fantasy's craft
disciplines (wonder engine, magic-system rigour, worldbuilding
calibration) while inheriting YA's voice authenticity, teen
agency, and emotional commitment. The cluster includes high-
fantasy YA, urban-fantasy YA, romantasy at the YA edge,
fairytale-retellings, magical-school subgenre, portal-fantasy
YA, and the broader speculative-coming-of-age range. Comp
authors span the canonical lineage (J.K. Rowling, Tamora
Pierce, Garth Nix, Diana Wynne Jones, Philip Pullman,
Ursula K. Le Guin's *Earthsea*, Megan Whalen Turner's
*Queen's Thief* series) through the contemporary expansion
(Leigh Bardugo's *Six of Crows* and *Shadow and Bone*, V.E.
Schwab's *Shades of Magic*, Sabaa Tahir, Marie Lu, Marissa
Meyer, Holly Black, Renée Ahdieh, Tomi Adeyemi's *Children
of Blood and Bone*, Roshani Chokshi, Tracy Deonn's *Legendborn*,
Tracy Wolff, Adrienne Young, Olivie Blake at the upper-YA
edge, Akwaeke Emezi's *Pet*, Amélie Wen Zhao, Joan He, Kalynn
Bayron, Rebecca Roanhorse for younger readers, Brigid Kemmerer,
Stephanie Garber's *Caraval*, Chloe Gong's *These Violent
Delights*, Holly Jackson at the genre-cross edge, Erin Bowman,
Emily Skrutskie, Alexandra Bracken). The techniques below are
how the form delivers its dual contract — the fantasy reader's
expectations of the speculative work AND the YA reader's
expectations of voice and agency — without compromising
either. Failure modes: adult-fantasy ventriloquising teen
protagonist; teen voice gestured at while adult-fantasy
prose register dominates; magic system rigorous in worldbuild
but inconsistent in scene; teen agency claimed but adults
solving problems beneath the surface.

### The Wonder-Identity Fusion

The moment of magical discovery is also a moment of self-
discovery. YA fantasy's signature emotional craft: the
protagonist's encounter with the magical world is
inseparable from their encounter with who they are. The
power isn't a thing they acquire and use; it is the
external manifestation of an internal truth they have been
carrying without knowing it.

```
"The fire came from my hands. MY hands. The same
hands that couldn't catch a ball in PE, that shook
when Kira Okafor looked at me, that my mother
used to hold while we crossed the street.

Now they were burning.

And the thing I couldn't admit to anyone, the
thing that made me a terrible person probably,
was this: I wasn't scared. I was relieved. Because
I'd always known something was wrong with me.
Turns out, something was right."

The magic IS the identity discovery. The power
IS the coming-of-age. They're the same story.
```

The technique requires that the magical and the developmental
align in scene. The protagonist who is becoming themselves AND
becoming a magical being must do both at once, with each
beat of the magical arc also moving the identity arc. The
form's failure mode is the protagonist whose magical journey
and identity journey run in parallel without intersecting
(the magical training in the fantasy world; the identity work
in their relationships at home; never the twain shall meet).
The strongest YA fantasy fuses them: the magic surfaces what
the protagonist has been suppressing about themselves; the
identity question becomes urgent precisely because the magic
has put it on the table.

Test: pick three significant magical moments in the
manuscript and ask, in each, whether the moment also moves
the identity arc. If the magic merely demonstrates capability
without revealing or forcing recognition about who the
protagonist is becoming, the fusion has not been deployed.

### The Cost Made Personal

Magic's price shown through character impact rather than
mechanical bookkeeping. YA fantasy inherits adult-fantasy's
hard-magic discipline (rules and costs) but renders the
costs as character truths the reader feels rather than as
stat-screen accounting. The spell that exhausts the
protagonist's mana is uninteresting; the spell that costs
the protagonist a specific memory of someone they loved is
the form's signature register.

```
NOT YA FANTASY:
"The spell drained her magical energy."

YA FANTASY:
"I pushed the fire outward and felt something
leave. Not energy. that's what the textbooks
said. Memory. The first spell cost me Tuesday
mornings with Grandma. I didn't notice until I
tried to remember and found only static where
the kitchen used to be, where she used to be,
where the eggs and the radio and her laugh used
to be.

They tell you magic has a price. They don't
tell you it picks what you can't afford to lose."

The cost is PERSONAL. Not HP. Not mana.
Something the character and reader feel.
```

The technique requires that costs accumulate. A magical
system where each spell extracts a specific personal price
makes the protagonist's choice to use magic increasingly
weighted across the manuscript. Generic "magic is hard"
without specific cumulative cost is the failure mode; the
specific accumulating losses — memories / sleep / capacity to
feel certain emotions / relationships / years of life / hair
turning white / specific senses dulled — that the reader
tracks across the manuscript is the technique. The
protagonist who has paid five specific costs by the climax
must use the climactic magic differently than they used the
first.

Test: identify the magical costs in the manuscript and trace
them across the protagonist's arc. Do the costs accumulate
in ways the reader feels? If each spell-cost is reset
between chapters, the cost-as-character-impact discipline
hasn't been deployed; if costs persist and shape later
choices, the technique is operating.

### The Question-Authority Voice

The teen who doesn't accept the fantasy world's rules. YA
fantasy's signature character work: the protagonist looks at
the fantasy world's centuries of accumulated convention,
hierarchy, prophecy, and tradition, and asks the questions
adults in that world stopped asking generations ago. The
challenge to the world's premises IS the form's coming-of-
age engine.

```
"'It has always been this way,' the Elder said.

'Okay but WHY has it always been this way? Like,
did someone decide? Was there a vote? Because
this seems like something someone decided and
everyone else just... went along with?'

The Elder's face did the thing adults' faces
do when a teenager asks a question they've
never bothered to ask themselves."

YA fantasy protagonists don't accept "because
tradition." They ask the questions adults
stopped asking. That's their superpower.
```

The technique requires that the questions be specific and
load-bearing. Generic "she questioned the system" is the
failure mode; the specific question asked at the specific
moment about the specific tradition that turns out to be
indefensible is the technique. The strongest YA fantasy uses
the question-authority voice to drive the plot: the
protagonist's question doesn't merely register protest, it
forces the world to defend itself, and the defence's
inadequacy is what produces the rebellion / reform / break-
from-tradition that becomes the book's plot.

The technique extends to the protagonist's relationship with
the fantasy genre's own conventions. The strongest YA
fantasy is self-aware about Chosen One narratives, about
prophecy, about magical-school structure — the protagonist's
question can be directed at the genre's defaults as well as
at the world's traditions. Holly Black's protagonists do
this; Leigh Bardugo's do this; Tracy Deonn's *Legendborn*
does this with Arthurian convention.

Test: identify the questions the protagonist asks of
authority in the manuscript. Are the questions specific to
THIS world's specific traditions? Do the answers / non-
answers drive plot? If questions are decorative, the voice is
operating at register level only; if questions force the
world to respond, the technique is doing structural work.

### The YA Fantasy Voice Authenticity

YA fantasy must hold both fantasy's prose register
(speculative authority, world-building specificity, magical
event rendered with the appropriate atmospheric weight) and
YA's voice authenticity (teen protagonist sounds like a
teen). The form's most-flagged failure: adult-fantasy prose
register applied to a teen protagonist whose interior
therefore reads as adult-narrator-pretending-to-be-teen.

The discipline operates on multiple axes:

- **Vocabulary** — every word the teen narrator uses must be
  available to this specific teen at this specific age. The
  fantasy setting permits some elevated diction the
  contemporary YA register would not (the protagonist who is
  in a magical academy can plausibly use words their
  contemporary-suburb counterpart wouldn't), but the
  vocabulary must remain teen-accessible. Adult-fantasy's
  Latinate vocabulary is the failure mode.
- **Sentence rhythm** — even in fantasy register, teen prose
  fragments more, asides more, rhythm-shifts more than adult
  fantasy. The teen narrator's voice should retain the
  contemporary-YA-voice's energy even when describing magical
  events.
- **Cultural reference** — the teen protagonist references
  what they would actually know. Even in secondary-world
  fantasy, the protagonist's interior comparisons (this
  feels like / sounds like / reminds me of) come from their
  experience, which is teen. The protagonist who compares
  the magical chamber to Renaissance architecture has been
  ventriloquised.
- **Emotional register** — teen emotional intensity (see The
  First-Time Lens from ya-contemporary) operates in YA
  fantasy too. The first kiss, the first betrayal, the
  first death witnessed should be rendered with full teen
  intensity, not adult-fantasy's distanced register.

Test: pick three first-person passages where the protagonist
encounters magical or fantastical material. Is the prose
register YA voice rendering fantasy material, or fantasy
prose with teen vocabulary sprinkled in? The first is the
form; the second is the failure mode.

### The Found Family Construction

YA fantasy's signature relational structure is the found
family — the chosen group that forms across the manuscript,
typically taking the protagonist's primary emotional weight
from biological family (which is often absent, complicated,
or compromised) to chosen companions. The found family
operates differently from the standard fantasy fellowship:
it carries the protagonist's identity work, not merely their
quest mechanics.

The construction requires:

- **Distinctive companions** — each member of the found
  family has their own voice, history, motivations, and arc
  independent of the protagonist. The strongest YA fantasy
  found-families (*Six of Crows*, *Shadow and Bone*,
  *Throne of Glass*, *Children of Blood and Bone*) make
  every team member a person the reader cares about
  separately.
- **Developing dynamics** — the relationships between
  companions evolve across the manuscript. The team that
  formed in chapter five is not the same team in chapter
  twenty-five; specific bonds have deepened, specific
  conflicts have surfaced, specific configurations have
  shifted.
- **Tested bonds** — the found family must be tested by
  what occurs. The genre's strongest examples include
  betrayals, deaths, departures, returns, and the slow
  accumulation of shared experience that makes the chosen
  family feel earned rather than declared.
- **Unequal stakes** — different companions risk different
  things, want different things, can lose different things.
  Found-family treatment that flattens the team into shared-
  stake undifferentiated unity is the failure mode; the
  strongest found families are made of distinct individuals
  whose competing interests the protagonist must navigate.

Test: pick three found-family members and write one
paragraph for each describing their goals, fears, and
specific relationship to the protagonist. If paragraphs blur
or sound interchangeable, the team has been built at chorus
level; if paragraphs reveal distinct people with distinct
arcs, the construction is operating.

### The Magical Coming-of-Age Discipline

YA fantasy operates within both forms simultaneously: it must
deliver fantasy's core pleasures (worldbuilding,
adventure, magical revelation, the sustained imaginative
work of inhabiting another world) AND coming-of-age's core
pleasures (protagonist becoming, voice evolving across the
arc, first experiences rendered with intensity, the
accumulation of small developmental shifts). The discipline
is integration — neither register may dominate at the
other's expense.

Failure modes:

- **Fantasy-priority drift** — the manuscript becomes a YA-
  voiced fantasy adventure where the protagonist's coming-
  of-age is gestured at through plot beats but never
  rendered as the form's actual through-line.
- **Coming-of-age priority drift** — the manuscript
  becomes a contemporary-coming-of-age in fantasy costume
  where the magical material is decorative and the form's
  speculative pleasures are abandoned.
- **Alternation register** — the manuscript switches between
  fantasy adventure chapters and quiet coming-of-age
  chapters without integrating the two; the reader feels
  they're reading two different books.

The integration succeeds when the protagonist's magical
arc and identity arc move together — the magic surfaces
what they have been carrying; the identity recognition
unlocks a magical capability; the cost of magical use IS the
cost of becoming oneself. Test: pick three significant
chapters and ask, in each, whether the chapter does both
fantasy and coming-of-age work, or only one. If most
chapters tilt to one register, integration has slipped.

### YA Fantasy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the Chosen One discovered their power" | Show the specific power through its first manifestation |
| "the training montage" | Show ONE specific training failure or breakthrough |
| "a world she never knew existed" | Show her specific reaction to one specific detail |
| "the mentor was mysterious" | Show the specific enigmatic behaviour |
| "the love triangle" | Show the specific moment of divided attention |
| "she was special" | Show the specific ability and its specific limitation |
| "the evil empire" | Show the specific oppressive act on a specific person |
| "the prophecy said" | Show the specific words and the character's reaction |
| "her magic was unique" | Show the specific uniqueness through one demonstration |
| "the academy was more than it seemed" | Show the specific hidden truth |
| "rebellion stirred" | Show the specific rebellious act by a specific character |
| "the kingdom would never be the same" | Show what specifically has changed and who has noticed |
| "the ancient prophecy was about her" | Cut the meta-summary; show the prophecy's specific words and her specific recognition |
| "she was destined for greatness" | Cut "destined"; show what she does that constitutes greatness in this world |
| "the magic responded to her bloodline" | Show the specific bloodline manifestation through specific moment |
| "her companions were her family now" | Show the specific moment that crystallised the found-family bond |
| "the dark lord rose" | Cut "dark lord" as cliché; name the specific antagonist with specific recent action |
| "the realm was at war" | Show the specific war through one specific casualty or one specific village affected |

## Genre-Specific Revision Rules

Six revision passes specific to YA fantasy, each with a single
question, run cover-to-cover before the next begins. YA
fantasy revision must hold the form's dual contract: fantasy's
craft disciplines (magic-system consistency, worldbuilding
integration, wonder-engine operation) AND YA's craft
disciplines (voice authenticity, teen agency, emotional
honesty, hope register). The passes below are ordered to
surface the integration failures first (the form's distinctive
craft challenge), magic and voice failures next, found-family
and wonder audits last.

### Pass 1: Identity-Quest Alignment Check

Verify the external quest advances the internal identity
question. The Wonder-Identity Fusion technique is the form's
deepest craft; the revision pass checks whether the technique
is operating across the manuscript or concentrated in a few
set-pieces. At each significant magical or quest beat, ask:
what does this beat reveal about who the protagonist is
becoming? If the magical event happens AND the protagonist
learns something new about themselves, the technique is
operating; if the magical event is a plot beat alone, the
fusion has slipped.

Verify the protagonist is becoming someone, not just doing
things. The form's signature failure mode is the action-
heavy YA fantasy where the protagonist completes a magical
quest without character development — the protagonist of
chapter thirty is identical to the protagonist of chapter
one, just with more powers. The form's contract requires
that the protagonist arrive at the climax having become
someone different from who they started as; the difference
must be visible in specific behaviour change.

Verify magical developments are tied to character growth.
The protagonist who acquires a new ability should also
acquire something character-true alongside it (a new
understanding, a new commitment, a new fear, a new
willingness). The strongest YA fantasy makes the magical
acquisition AND the character recognition the same
chapter's beat.

Test: pick three chapters spaced across the manuscript and,
in each, identify what the protagonist learned about
themselves AND what they learned magically. If only one
column populates per chapter, the alignment has not been
deployed.

### Pass 2: Magic System Consistency Check

Verify the rules established earlier still apply. Build a
magic-rules ledger: every named ability, limitation, cost,
threshold, exemption, and edge case appearing anywhere in
the manuscript, with the chapter and page where each first
appears. Read the manuscript against the ledger. The fantasy
reader's tolerance for system inconsistency is unforgiving;
one violation costs more goodwill than ten reaffirmations
earn back.

Verify the cost of magic is consistent and tracked. The Cost
Made Personal technique requires that costs accumulate
across the manuscript. The protagonist who paid a memory in
chapter four still doesn't have that memory in chapter
twenty; the protagonist who paid five years of life by
chapter ten still has those years missing at the climax.
Inconsistent cost-tracking is the failure mode.

Verify limitations are respected — no sudden power jumps
without earning. The genre's most-flagged structural
failure is the climactic ability that nobody mentioned
before chapter twenty-eight; the climax must use magic
within established rules. Where the climax requires a
capability not previously demonstrated, either the
capability must be foreshadowed (the protagonist has
reasons to suspect they could do this) or its introduction
must be the climactic surprise the prose has been
preparing.

Verify the protagonist's ability level is consistent with
their training. The protagonist who has trained for one
chapter cannot operate at master level in chapter ten; the
gradient of competence acquisition must match the
training the manuscript has shown. Skill-jumps without
intermediate development are the failure mode.

### Pass 3: Teen Voice Check

Read the protagonist's first-person passages aloud. Does the
protagonist still sound like a teenager (not an adult
narrator)? The form's most-flagged failure: adult-fantasy
prose register applied to teen protagonist whose interior
therefore reads as adult-narrator-pretending-to-be-teen.
Check vocabulary: every word should be available to this
specific teen at this specific age in this specific fantasy
world. Adult-fantasy's Latinate vocabulary is the failure
mode; teen voice rendering fantasy material is the
technique.

Verify emotional responses are age-appropriate — intense,
immediate, sometimes disproportionate. Teen emotion in YA
fantasy operates at the same intensity as YA contemporary;
the magical setting doesn't permit emotional restraint the
form would not otherwise allow. First magical encounters,
first kisses, first deaths witnessed must register at full
teen intensity even when the prose is also doing fantasy
worldbuild work.

Verify the protagonist questions authority and challenges
the fantasy world's assumptions. The Question-Authority
Voice technique is the form's signature character work;
revision pass checks whether the protagonist's challenges
are specific (THIS world's specific traditions) and load-
bearing (the questions force the world to respond). If the
protagonist accepts the world's premises uncritically, the
form's coming-of-age engine has not started.

Test: read three first-person passages where the protagonist
encounters magical material. Is the prose register YA voice
rendering fantasy material, or fantasy prose with teen
vocabulary sprinkled in? The first is the form's discipline.

### Pass 4: Found Family Check

Verify team dynamics are developing rather than static.
Build a found-family ledger: each companion's appearance
chapters, their relationship arc with the protagonist and
with other team members, the specific bonds and conflicts
across the book. The relationships should evolve — pairings
that started awkward should have shifted by chapter twenty;
trust levels should match accumulated shared experience.

Verify each companion has a distinct voice and role.
Generic supportive-team-member companions are the failure
mode; companions with their own voices, backstories,
motivations, and arcs are the technique. Build a one-
paragraph profile for each significant companion; if
paragraphs blur, the team has been built at chorus level.

Verify bonds are being tested rather than declared. The
prose that asserts "they trusted each other completely"
without showing the specific trust test is the failure
mode; the prose that stages specific moments where trust
must be chosen — and is, sometimes uncertainly — is the
technique. The strongest YA fantasy includes betrayals
(intentional and inadvertent), deaths, departures, returns
across the team's arc.

Verify the group's trust level is consistent with their
shared experience. A team that has just met in chapter four
shouldn't operate as long-bonded family in chapter five;
trust accumulates across pages, and the manuscript should
track the accumulation visibly.

### Pass 5: Wonder Preservation Check

Verify there are still moments of awe even in familiar
magical settings. Fantasy's wonder-engine technique applies
in YA fantasy: the world should retain its capacity to
surprise the protagonist (and reader) across the manuscript,
not be exhausted by the first three chapters' worth of
worldbuild. Where the protagonist has become acclimated to
the magical world, the manuscript should introduce new
elements that re-trigger wonder.

Verify the world is shown as worth saving — beauty alongside
danger. The YA fantasy reader's investment in the
protagonist's quest depends on caring about the world the
quest is for. Generic threatened-world treatment is the
failure mode; specific beautiful detail (the river that
runs phosphorescent at midsummer; the bakery in the lower
city that opens at four AM; the singing trees of the
specific grove) makes the threat matter.

Verify the reader is discovering alongside the protagonist.
The form's signature pacing pleasure is the synchronised
unsealing of the world: the protagonist learns something
new about the magic system / the politics / the history /
the threat, and the reader learns it at the same moment.
Over-explained worldbuilding (the reader knows everything
by chapter five) is the failure mode; controlled revelation
across the book is the technique.

### Pass 6: Dual-Contract Integration Audit

Run a final pass on the manuscript's integration of fantasy
and YA registers. Does the manuscript deliver fantasy's core
pleasures (worldbuilding, magical revelation, adventure,
sustained imaginative work) AND YA's core pleasures (voice
authenticity, teen agency, emotional honesty, coming-of-age
arc)? The form's three failure modes:

- **Fantasy-priority drift** — the manuscript becomes a YA-
  voiced fantasy adventure where the protagonist's coming-
  of-age is gestured at through plot beats but never
  rendered as the form's actual through-line. Symptom: the
  protagonist's interior is thin; magical event chapters
  outweigh interior-development chapters by 5:1.
- **Coming-of-age priority drift** — the manuscript becomes
  a contemporary-coming-of-age in fantasy costume where the
  magical material is decorative and the form's speculative
  pleasures are abandoned. Symptom: the magical world's
  specific texture is generic; magical events could be
  removed without altering the protagonist's identity arc.
- **Alternation register** — the manuscript switches between
  fantasy adventure chapters and quiet coming-of-age
  chapters without integrating the two. Symptom: chapters
  feel like two different books; readers preferring one
  register skim chapters in the other.

Verify the integration succeeds: the protagonist's magical
arc and identity arc move together. Each chapter does
fantasy work AND coming-of-age work; magical events surface
identity questions; identity recognitions unlock magical
capabilities; the cost of magical use IS the cost of
becoming oneself.

Test: pick three significant chapters and ask, in each,
whether the chapter does both fantasy and YA work
simultaneously. If most chapters tilt heavily to one
register, integration has slipped and the manuscript needs
revision toward the dual contract the form requires.

## Names & Patterns to Avoid

### YA Fantasy Character Names. NEVER USE
- Unpronounceable names (teen readers need to say these aloud in their heads)
- Names too similar to each other (the group needs distinct names)
- Generic fantasy names: Elara, Thorne, Raven (unless the setting earns them)
- Names from well-known YA series: Katniss, Tris, Percy (too associated)

### YA Fantasy. NEVER DO
- Make the protagonist special only because prophecy says so (character must earn it)
- Dump world-building in exposition blocks (reveal through experience)
- Write magic without cost or consequence (free power is boring)
- Let adults solve the problem while teens watch (agency is sacred)
- Write a hopeless ending (YA fantasy needs hope, even hard-won)
- Make the villain one-dimensional (their philosophy should make uncomfortable sense)
- Use the love interest as motivation or reward only (they need their own agency)

### Use Instead
- Names that are distinctive, pronounceable, and culturally appropriate to the world
- Names that sound right in the protagonist's mouth (they'll say these names constantly)
- Nicknames that reveal relationship dynamics within the group

## Comp Titles

YA-fantasy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Harry Potter and the Philosopher's Stone* — J.K. Rowling (1997): the modern YA-fantasy phenomenon.
- *Sabriel* — Garth Nix (1995): the Old Kingdom series; literary YA-fantasy benchmark.
- *Throne of Glass* — Sarah J. Maas (2012): the modern YA-fantasy series benchmark.
- *Graceling* — Kristin Cashore (2008): YA-fantasy with strong heroine-protagonist.

### Contemporary (current best-in-class)

- *Six of Crows* — Leigh Bardugo (2015): the Grishaverse; ensemble YA-fantasy benchmark.
- *Children of Blood and Bone* — Tomi Adeyemi (2018): West-African-inspired YA-fantasy.
- *The Cruel Prince* — Holly Black (2018): YA fae-romance-fantasy.
- *Daughter of Smoke and Bone* — Laini Taylor (2011): literary-YA-fantasy benchmark.
- *Sorcery of Thorns* — Margaret Rogerson (2019): YA-fantasy with magical-library setting.
- *Spinning Silver* — Naomi Novik (2018): adult/YA-fantasy crossover.
- *Legendborn* — Tracy Deonn (2020): contemporary Black-Arthurian YA-fantasy.

## Cover Design Specifications

### Recommended Visual Styles
- **Character-Centred**. The protagonist in their world: a figure with visible power, distinctive clothing, the fantasy world behind them; the reader should see who they'll become
- **Symbolic**. A single powerful symbol: a crown, a flame, a weapon, a creature; the image that captures the story's essence
- **Illustrated**. Bold, stylised illustration: the visual language of contemporary YA fantasy; often featuring the protagonist in an action or power pose
- **Atmospheric**. The fantasy world itself: a magical landscape, a castle, a forest, a city; the world as invitation

### Genre Cover Aesthetics
- **Styles:** Illustrated characters in fantasy settings, magical elements (fire, ice, shadow, light), bold silhouettes against dramatic skies, detailed fantasy world landscapes, character portraits with magical effects, weapons and armour rendered beautifully
- **Colours:** Rich, saturated palettes: deep blues, purples, golds, reds, teal; metallic effects (gold foil, silver embossing popular in YA fantasy); the palette should feel both magical and contemporary
- **Elements:** Crowns, swords, magical effects (glowing hands, floating objects), fantastical creatures, maps as background elements, cloaks and armour, celestial imagery (moons, stars, constellations), thrones and towers
- **Typography:** Bold, often with fantasy-influenced flourishes but remaining readable; metallic effects; the title should feel like an incantation or a declaration; series branding prominent

### Market Positioning
YA Fantasy covers must signal "epic, magical, and personal" through character-driven imagery with fantasy elements. Position against Bardugo, Maas, Aveyard, Tahir, Zhao. The cover should promise both world-shattering stakes and intimate character journey. At thumbnail size, a striking figure with magical elements and bold typography creates instant series recognition.

### Cover Design DON'Ts
- No designs that look like adult epic fantasy (YA has its own visual language)
- No busy compositions that obscure the central figure or symbol
- No dull or muted palettes (YA fantasy is visually bold)
- No generic fantasy imagery without character specificity
- No covers that could be mistaken for middle grade (maintain YA sophistication)
- No designs without diversity consideration in character representation
