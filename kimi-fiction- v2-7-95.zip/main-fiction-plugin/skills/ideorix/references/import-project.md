---
name: import-project
description: "Import an existing project from another writing tool (Novelcrafter supported; more sources coming)"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

**Display rule:** Always begin your response with `> **Powered by Ideorix** — The Manuscript & Screen Engine` before any other output.

# Import Project

Bring your existing work from another writing tool into Ideorix. The importer
parses your manuscript, characters, locations, objects, and world-building,
then lands it in a working Ideorix project ready for the full editorial
pipeline.

## Architect Mode is set automatically (v2.7.1+)

**Imported material is user-supplied canon by definition.**
Every importer (Novelcrafter, Plottr, Scrivener, Screenplay)
writes `architect_mode: true` to
`engine-data/project-config.md` as part of the import
completion step. This propagates the same Architect Mode
discipline that the BYO-canon entry point provides:

- The Architect agent treats imported characters / world /
  outline as immutable — no flattening to easier-to-write
  versions, no psychology projection, no silent
  reinterpretation
- The Writer agent treats imported voice / character voice /
  pre-existing prose as authoritative — voice guide doesn't
  drift toward genre-conventional defaults; sample passages
  calibrate without anchoring as plot tentpoles
- The Quality Guardian flags canon drift in any chapter that
  silently rewrites the imported user material

Importers also mirror the original imported data into
`source-canon/<source>-import/` (read-only canon, the engine
reads but never writes back) so the Outline Builder Step 0
filesystem trigger fires uniformly across BYO-canon and
import paths.

The user does NOT need to invoke Architect mode explicitly
when importing — it is set unconditionally by the import
flow because every import is, by definition, a transfer of
user-supplied creative work that the engine should serve
rather than originate. See `byo-canon.md` for the equivalent
flow when starting from raw material rather than from a tool
export.

→ See `blueprint-agent.md` § Architect Mode Binding for the
Architect-agent contract.
→ See `prose-agent.md` § Architect Mode Binding for the
Writer-agent contract.
→ See `quality-gate.md` § Architect Mode Binding for the
Quality Guardian contract.
→ See `outline-builder.md` § Step 0 for the canon-absorption
protocol that runs on imported material.

## What it does

| Task | What happens |
|------|-------------|
| **Manuscript import** | Parses your full book into Ideorix chapter files, preserves acts and scene breaks |
| **Codex import** | Converts characters, locations, objects, and subplots into an Ideorix Story Bible |
| **Alias preservation** | Your character aliases flow through to the Continuity Guardian and Prose Humaniser so mention tracking keeps working |
| **Workflow cleanup** | Drops scratch notes, AI chat logs, and draft outlines — only canonical content comes across |
| **Reduced setup** | Skips setup questions that don't apply (you already have an outline); only asks for what Ideorix needs (genre, voice, length tier) |
| **Choose your next step** | Hand off to Continue Writing, Writers Studio, Edit & Revise, or Manuscript Clinic |

## Supported sources

| Source | Status | Notes |
|--------|--------|-------|
| **Novelcrafter** | ✓ Supported | Full export zip (manuscript + codex) |
| **Plottr** | ✓ Supported | Word export (.docx) — outline-only, builds full Story Bible |
| **Scrivener** | ✓ Supported | `.scriv` bundle (zipped) — full prose + binder + characters/places/notes |
| Campfire | Planned | |
| World Anvil | Planned | |

More sources are added as users ask for them. If you use a tool that isn't
listed, export your work as markdown and ask — most tools that export
markdown can be imported with minor tweaks to the parser.

## How to start

Say any of:
- "Import from Novelcrafter"
- "Import my Novelcrafter project"
- "Bring my Novelcrafter work across"
- "I'm moving from Novelcrafter"
- "Import project"
- "Import my existing work"

## How to prepare your Novelcrafter export

Before running the importer:

1. Open your project in Novelcrafter
2. Click **Export** at the bottom of the left sidebar
3. Choose **Markdown** as the format
4. **Important:** tick **"Include codex"** — without this, only your manuscript
   will come across (no characters, locations, or world-building)
5. Tick the other defaults (chapters, scenes, scene summaries)
6. Export and save the resulting zip

Then place the zip in `~/Documents/Ideorix-Projects/imports/` (the importer
will find it automatically) or have the full file path ready.

## What gets imported

From a Novelcrafter export, the importer brings across:

- **Manuscript prose** — every chapter, every scene, every `* * *` break preserved
- **Characters** — name, aliases, tags, full description
- **Locations** — name, aliases, tags, full description
- **Objects** — name, aliases, tags, full description
- **Subplots** — name and full description
- **World-building** — triaged from Novelcrafter's "other" folder (the importer
  filters out chapter drafts, AI style guides, and workflow notes automatically)
- **Book metadata** — title and author (pulled from your manuscript header)

## What is NOT imported

- **Scene beats** — Ideorix works at chapter level; sub-scene beats are not carried
- **Novelcrafter chat history** — AI conversation logs are workflow only
- **Snippets** — scratch notes aren't part of the canonical project
- **codex.html** — Novelcrafter includes a rendered HTML view; Ideorix doesn't need it
- **Thumbnails** — not used by Ideorix
- **Mention tracker data** — Ideorix regenerates this itself from the alias list

## What Ideorix will ask you after import

Novelcrafter doesn't record certain things Ideorix needs for its agent
pipeline. After the import completes, you'll be asked for:

1. **Genre** — controls which genre plugin loads (craft rules, tropes, quality checks)
2. **Dialect** — US or GB English
3. **POV** — inferred from the first chapter, confirmed by you
4. **Length tier** — inferred from word count, confirmed by you
5. **Voice** — attach an existing voice profile, or build one now, or skip
6. **Pen name** — attach an existing pen name, create one, or skip

Everything else (tropes, beat structure, Chekhov's guns, transportive setting)
can be derived from your existing content or set later.

## What you get back

A fully populated Ideorix project workspace:

```
~/Documents/Ideorix-Projects/{Your Title}/
├── project-config.md              Project metadata + setup answers
├── manuscript/imported/           Your chapters, one file each
├── engine-data/
│   ├── story-bible.md             Characters, locations, objects, world
│   ├── entities/                  Same data, split by type
│   └── summaries/                 Chapter summaries from your export
├── marketing/
└── imports/novelcrafter-export/   Original unpacked export (for reference)
```

From there you choose your next step: continue writing with the AI pipeline,
run the editorial suite, run targeted fixes, or get a scored clinic analysis.

> Protocol: `novelcrafter-importer.md`
