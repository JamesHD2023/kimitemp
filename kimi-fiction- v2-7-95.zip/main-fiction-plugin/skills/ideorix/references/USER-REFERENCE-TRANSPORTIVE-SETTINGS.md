# Transportive Settings — User Reference

## Quick Start

During project setup, **Question 13** asks you to choose a transportive setting. Genre-recommended options are starred at the top of the list.

## What It Does

Gives your manuscript an atmospheric DNA — a curated sensory palette (smells, sounds, textures, light) injected into every chapter by the Architect and Writer agents.

## The 13 Setting Archetypes

| # | Setting | Core Atmosphere | Comp Mood |
|---|---------|----------------|-----------|
| 1 | **Fog-Wrapped Coastal Town** | Isolation, secrets, salt air | Broadchurch, The Shipping News |
| 2 | **Neon-Lit Metropolis** | Urban energy, anonymity | Blade Runner, Severance |
| 3 | **Sun-Baked Rural Heartland** | Wide horizons, slow time | Where the Crawdads Sing, Fargo |
| 4 | **Snow-Bound Isolation** | Claustrophobia, survival | The Shining, Station Eleven |
| 5 | **Tropical Paradise (Dark Underbelly)** | Lush beauty masking danger | The Beach, White Lotus |
| 6 | **Ancient City Layers** | History underfoot | The Shadow of the Wind |
| 7 | **Industrial Decline** | Rust belt, resilience | Nomadland, The Wire |
| 8 | **Enchanted Wilderness** | Deep forest, nature as character | Uprooted, The Overstory |
| 9 | **High Society Estate** | Wealth, secrets, surfaces | Downton Abbey, Rebecca |
| 10 | **War-Torn Landscape** | Destruction, survival | All the Light We Cannot See |
| 11 | **Suburban Uncanny** | Surface normality, rot underneath | Big Little Lies, Get Out |
| 12 | **Underground / Subterranean** | Hidden world, descent | Piranesi, Metro 2033 |
| 13 | **Custom** | You describe it, engine builds the profile | — |

## Genre-Recommended Defaults

| Genre | Primary | Secondary |
|-------|---------|-----------|
| Romance | High Society Estate | Ancient City Layers, Tropical Paradise |
| Thriller | Neon-Lit Metropolis | Industrial Decline, Snow-Bound Isolation |
| Cozy Mystery | Fog-Wrapped Coastal Town | Sun-Baked Rural Heartland |
| Horror / Gothic | Enchanted Wilderness | Snow-Bound Isolation, Underground |
| Literary | Ancient City Layers | Industrial Decline, Fog-Wrapped Coastal Town |
| Fantasy | Enchanted Wilderness | Ancient City Layers |
| Sci-Fi | Neon-Lit Metropolis | Snow-Bound Isolation |
| Historical | Ancient City Layers | High Society Estate, War-Torn Landscape |
| Domestic Thriller | Suburban Uncanny | High Society Estate |
| Dark Romance | High Society Estate | Snow-Bound Isolation |

## What Each Archetype Contains

Every setting archetype provides:

- **Sensory Palette** — Specific smells, sounds, textures, light (4 senses, 3-5 entries each)
- **Weather Patterns** — Characteristic weather and how it affects mood
- **Architecture** — Built environment details, landmarks, spatial feel
- **Social Dynamics** — How people interact, hierarchies, tensions
- **Time Feel** — How time moves (fast, slow, cyclical, stalled)
- **Comp Mood** — Reference titles that capture the atmosphere

## How It Affects Your Manuscript

### The Architect uses your setting to:
- Fill the Worldbuilding Brief with setting-specific sensory details
- Follow established weather patterns instead of random weather
- Match architecture to the setting's built environment
- Shape social dynamics between characters
- Calibrate pacing to the setting's time feel

### The Writer uses your setting to:
- Draw at least 2 sensory details from the palette per scene
- Ground readers in the setting within the first 3 paragraphs
- Treat the setting as a character with moods and reactions
- Match prose rhythm to the setting's time feel
- Use the setting's specific vocabulary (not generic alternatives)

## Setup Options (Question 13)

| Option | What Happens |
|--------|-------------|
| Select a recommended setting | Full sensory profile loaded, injected into all agents |
| Select from full list | Same as above, any of the 13 archetypes |
| Custom | You describe the atmosphere; engine generates a full profile |
| Use genre default | Engine auto-selects the primary recommendation |

## Custom Settings

If you select Custom:
1. Describe the atmosphere in 2-3 sentences
2. Provide 3-5 sensory details you associate with this world
3. Give a mood or comparable title reference
4. Engine generates a complete archetype profile
5. You approve before it's applied
