---
name: transportive-settings
description: "Transportive setting atmosphere selection and prose injection"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Transportive Settings

## Overview

A transportive setting goes beyond "where the story takes place" — it defines the
atmospheric DNA of the manuscript. It shapes how the world FEELS on every page:
the light, the weather, the soundscape, the textures, the rhythms of daily life.

Selected during Phase 1 setup (Question 13) and injected into the Architect and
Writer agent prompts alongside genre rules.

## Setting Archetypes

### 1. Fog-Wrapped Coastal Town
**Atmosphere:** Isolation, buried secrets, salt-crusted beauty, erosion as metaphor
**Sensory Palette:**
- Smell: Brine, wet rope, fish markets, damp wool, wood smoke
- Sound: Foghorns, gull cries, waves on shingle, wind through gaps in window frames
- Touch: Salt-sticky skin, cold handrails, gritty sand in shoes, damp everything
- Light: Diffused grey, sudden breaks of watery sun, lighthouse sweeps at night
**Weather Patterns:** Fog banks rolling in, horizontal rain, brief golden-hour breaks, storms that strand
**Architecture:** Peeling paint, harbour walls, narrow lanes, cliffside paths, boats in dry dock
**Social Dynamics:** Everyone knows everyone, newcomers are watched, old grudges, seasonal economy
**Time Feel:** Slow — tidal rhythms, waiting for weather to clear, long winters
**Comp Mood:** Broadchurch, The Shipping News, Piranesi, The Outrun

### 2. Neon-Lit Metropolis
**Atmosphere:** Urban energy, anonymity in crowds, surveillance, possibility and danger
**Sensory Palette:**
- Smell: Street food, exhaust, rain on hot asphalt, perfume in elevators, subway air
- Sound: Traffic hum, distant sirens, bar music bleeding through walls, multilingual chatter
- Touch: Smooth phone screens, crowded train pressure, rooftop wind, air conditioning chill
- Light: Neon reflections in puddles, LED billboards, blue-white fluorescent offices, amber streetlights
**Weather Patterns:** Rain transforms the city (reflections), heat creates shimmer, cold makes breath visible
**Architecture:** Glass towers, narrow alleys, underground bars, rooftop gardens, 24-hour convenience stores
**Social Dynamics:** Anonymity, fleeting connections, class contrasts (penthouses above homeless encampments), digital and physical worlds overlapping
**Time Feel:** Fast — always-on, no closing time, seasons barely noticed indoors
**Comp Mood:** Blade Runner, Bonfire of the Vanities, Severance, Tokyo Drifter

### 3. Sun-Baked Rural Heartland
**Atmosphere:** Wide horizons, deep roots, slow time, harvest pressure, community bonds
**Sensory Palette:**
- Smell: Fresh-cut hay, dust, diesel from farm equipment, pie cooling on a sill, storm ozone
- Sound: Cicadas, screen doors, distant thunder, gravel under tyres, wind through corn
- Touch: Sun-warmed wood, cracked earth, sweat, cold well water, callused hands
- Light: Relentless summer sun, long golden evenings, purple storm fronts, star-drenched nights
**Weather Patterns:** Drought anxiety, thunderstorms as events, harvest season urgency, first frost
**Architecture:** Farmhouses with wraparound porches, grain silos, one-street towns, churches as landmarks, roadside diners
**Social Dynamics:** Generational land ties, town gossip, outsider suspicion, church community, county fair rituals
**Time Feel:** Seasonal — life follows planting and harvest, Sunday rhythms, dusk-to-dawn
**Comp Mood:** Where the Crawdads Sing, Fargo, Killers of the Flower Moon, Olive Kitteridge

### 4. Snow-Bound Isolation
**Atmosphere:** Claustrophobia, survival, terrible beauty, silence, cabin fever
**Sensory Palette:**
- Smell: Wood smoke, frozen air, wet wool drying by a fire, pine resin, kerosene
- Sound: Silence so deep it hums, snow crunching, ice cracking, wind howling, fire popping
- Touch: Numb fingers, burning cold, heavy blankets, hot drinks in cold hands, ice underfoot
- Light: Blue-white snow glare, short days, orange firelight, aurora glow, perpetual twilight
**Weather Patterns:** Blizzards that trap, whiteouts, ice storms, brief thaws that refreeze, avalanche threat
**Architecture:** Isolated cabins, snowbound lodges, ice-locked research stations, villages cut off from roads
**Social Dynamics:** Forced proximity, dwindling supplies, cabin fever, roles that shift when help can't arrive, secrets that surface in confinement
**Time Feel:** Compressed — days feel endless, nights feel longer, time loses meaning
**Comp Mood:** The Shining, Station Eleven, The Terror, Smilla's Sense of Snow

### 5. Tropical Paradise (Dark Underbelly)
**Atmosphere:** Lush beauty masking danger, colonial echoes, decay beneath the surface
**Sensory Palette:**
- Smell: Frangipani, overripe fruit, salt water, mould, incense, coconut oil
- Sound: Rain on broad leaves, insects at dusk, distant music, gecko clicks, ocean roar
- Touch: Humidity on skin, sand between toes, mosquito bites, sun-heated stone, warm rain
- Light: Intense tropical sun, green-filtered jungle light, vivid sunsets, bioluminescent water
**Weather Patterns:** Monsoon season, sudden downpours, oppressive humidity, perfect mornings that turn threatening
**Architecture:** Colonial villas, beach shacks, overgrown ruins, coral walls, palm-thatched roofs
**Social Dynamics:** Tourist/local divide, expat communities, colonial history undercurrents, surface hospitality hiding resentment
**Time Feel:** Liquid — days blur, routines dissolve, urgency fades then spikes
**Comp Mood:** The Beach, White Lotus, Wide Sargasso Sea, The Poisonwood Bible

### 6. Ancient City Layers
**Atmosphere:** History underfoot, narrow streets, hidden spaces, past and present coexisting
**Sensory Palette:**
- Smell: Old stone, espresso, incense from churches, river damp, bread baking, candle wax
- Sound: Church bells, echoing footsteps, fountain splash, café chatter, vespa engines
- Touch: Worn stone steps, iron railings, cool church interiors, cobblestones underfoot
- Light: Golden stone in afternoon sun, candlelit interiors, streetlamp pools, light through stained glass
**Weather Patterns:** Mediterranean warmth, winter rain on stone, spring blossom, summer heat that empties streets at midday
**Architecture:** Layered history — Roman foundations, medieval walls, Renaissance facades, modern graffiti. Catacombs, hidden courtyards, rooftop terraces
**Social Dynamics:** Old families, neighbourhood territories, tourist economy, artisan traditions, bureaucratic labyrinths
**Time Feel:** Layered — the present is thin over centuries of past, ghosts are metaphorical or literal
**Comp Mood:** The Shadow of the Wind, My Brilliant Friend, The Historian, A Room with a View

### 7. Industrial Decline
**Atmosphere:** Rust belt beauty, abandoned spaces, resilience, class tension, rebirth potential
**Sensory Palette:**
- Smell: Rust, river water, fried food, diesel, wet concrete, chemical tang
- Sound: Train whistles, dripping water in empty buildings, distant highway, bar jukebox
- Touch: Cold metal, broken glass, graffiti-textured walls, steering wheel vibration
- Light: Overcast grey, sodium-orange streetlights, neon bar signs, furnace glow, sunset through smokestacks
**Weather Patterns:** Grey drizzle, industrial haze, bitter winters, humid summers, weather as oppression
**Architecture:** Shuttered factories, brownstone terraces, strip malls, highway overpasses, dive bars, union halls
**Social Dynamics:** Unemployment, community solidarity, opioid crisis, old vs young (leave or stay), ethnic neighbourhoods, mill-town identity
**Time Feel:** Stalled — the past was better, the present is stuck, the future is uncertain
**Comp Mood:** Nomadland, Hillbilly Elegy, The Wire, Beloved

### 8. Enchanted Wilderness
**Atmosphere:** Deep forest, nature as character, magical realism, ancient presence
**Sensory Palette:**
- Smell: Damp earth, moss, mushrooms, wildflowers, pine sap, approaching rain
- Sound: Bird calls, wind in canopy, stream over stones, branch snaps, silence that listens
- Touch: Bark textures, cold stream water, muddy trails, dew on skin, thorns
- Light: Dappled forest light, green-filtered, sudden clearings of brightness, moonlight through branches, bioluminescence
**Weather Patterns:** Mist in valleys, sudden rain under clear sky, seasonal transformations, frost patterns, storms that feel intentional
**Architecture:** Forest clearings, hidden cottages, ancient trees as landmarks, cave systems, stone circles, paths that shift
**Social Dynamics:** Solitude, communion with nature, village-edge communities, old knowledge, respect/fear of the wild
**Time Feel:** Cyclical — seasons as story structure, dawn-to-dusk rhythms, time that bends in the deep woods
**Comp Mood:** Uprooted, The Bear and the Nightingale, Piranesi, The Overstory

### 9. High Society Estate
**Atmosphere:** Wealth, secrets, staff hierarchies, manicured surfaces hiding rot
**Sensory Palette:**
- Smell: Cut flowers, beeswax polish, expensive perfume, old books, cigar smoke, kitchen aromas from below stairs
- Sound: Clock ticks, crystal clinking, hushed conversations, heels on marble, servants' bells, gravel crunch of arriving cars
- Touch: Silk, leather, cold marble, heavy silver, starched linen, the weight of jewellery
- Light: Chandelier warmth, candlelight, morning sun through tall windows, portrait gallery shadows, moonlight on formal gardens
**Weather Patterns:** Observed from inside — rain on windows, snow on grounds, perfect garden-party weather, storms that strand guests
**Architecture:** Grand houses, formal gardens, libraries, wine cellars, servants' quarters, gate lodges, family chapels
**Social Dynamics:** Inheritance tension, upstairs/downstairs divide, dinner-party politics, family secrets, performative perfection, the cost of maintaining appearances
**Time Feel:** Preserved — the house resists change, traditions anchor the calendar, generations layer
**Comp Mood:** Downton Abbey, The Goldfinch, Rebecca, Brideshead Revisited

### 10. War-Torn Landscape
**Atmosphere:** Destruction, displacement, unexpected beauty in ruins, survival and solidarity
**Sensory Palette:**
- Smell: Smoke, cordite, plaster dust, field hospitals, bread baking in a bomb shelter, rain on rubble
- Sound: Distant artillery, all-clear sirens, children playing in ruins, radio static, sudden silence
- Touch: Rubble underfoot, bandage linen, cold weapons, someone's hand in the dark, dust in everything
- Light: Searchlight sweeps, fire glow, blackout darkness, dawn after a raid, sun through a shattered roof
**Weather Patterns:** Weather is tactical — fog provides cover, rain fills trenches, winter threatens survival, spring mockingly beautiful
**Architecture:** Bombed buildings, makeshift shelters, bunkers, field hospitals, ruins reclaimed, the remaining intact building as sanctuary
**Social Dynamics:** Strangers bonded by circumstance, moral compromises, black markets, resistance networks, letters never sent, love under pressure
**Time Feel:** Urgent — every day could be the last, future is abstract, past is nostalgia, present is survival
**Comp Mood:** All the Light We Cannot See, The Tattooist of Auschwitz, Atonement, The Nightingale

### 11. Suburban Uncanny
**Atmosphere:** Surface normality, something wrong underneath, conformity as pressure, secrets behind curtains
**Sensory Palette:**
- Smell: Fresh-cut grass, laundry detergent, barbecue smoke, new car interiors, chlorine from pools
- Sound: Sprinklers, lawnmowers, garage doors, neighbourhood dogs, laughter from a party you're not invited to
- Touch: Manicured lawn edges, vinyl siding, smooth kitchen counters, the sticky leather of a minivan
- Light: Porch lights, blue TV glow through windows, identical streetlights, sunrise jogging routes
**Weather Patterns:** Perfect weather that feels oppressive, sudden storms that disrupt the routine, seasons marked by HOA-approved decorations
**Architecture:** Identical houses, cul-de-sacs, strip malls, school parking lots, community pools, the one house that doesn't conform
**Social Dynamics:** Keeping up appearances, neighbourhood surveillance (Nextdoor, curtain-twitching), school-gate hierarchies, book clubs as power structures
**Time Feel:** Repetitive — every day is the same until it isn't
**Comp Mood:** Big Little Lies, Desperate Housewives, Get Out, Revolutionary Road

### 12. Underground / Subterranean
**Atmosphere:** Hidden world, descent as metaphor, claustrophobia, discovery, what lurks below
**Sensory Palette:**
- Smell: Damp stone, mineral water, stale air, rust, earth, things growing without light
- Sound: Dripping water, echoes, distant rumbles, own heartbeat, the sound of space
- Touch: Wet rock, cold metal, crawl-space tightness, sudden openings, temperature drops
- Light: Headlamp beams, bioluminescence, absolute darkness, fire reflections on water, light from above
**Weather Patterns:** No weather — but water levels rise, air pressure changes, tremors
**Architecture:** Tunnels, caverns, bunkers, subway systems, mines, catacombs, hidden rooms, underground rivers
**Social Dynamics:** Isolation or hidden communities, guide/follower dynamics, what people become in the dark, trust without sight
**Time Feel:** Lost — no daylight cycle, time measured by hunger and fatigue
**Comp Mood:** The Descent, Metro 2033, Piranesi, Journey to the Centre of the Earth

### 13. Custom Setting
**User defines their own setting atmosphere.**

When the user selects Custom:
1. Ask them to describe the setting's core atmosphere in 2-3 sentences
2. Ask for 3-5 sensory details they associate with this world
3. Ask for a mood or comp title reference
4. Generate a full setting archetype profile following the format above
5. Present for approval before proceeding

## Genre-Recommended Defaults

When presenting Q13 during setup, highlight the genre's recommended settings:

| Genre Family | Primary Recommendation | Secondary Options |
|---|---|---|
| Romance | High Society Estate, Ancient City Layers | Sun-Baked Rural Heartland, Tropical Paradise |
| Thriller | Neon-Lit Metropolis, Suburban Uncanny | Industrial Decline, Snow-Bound Isolation |
| Cozy Mystery | Fog-Wrapped Coastal Town, Sun-Baked Rural Heartland | Ancient City Layers, Enchanted Wilderness |
| Horror / Gothic | Enchanted Wilderness, Snow-Bound Isolation | Fog-Wrapped Coastal Town, Underground |
| Literary Fiction | Ancient City Layers, Industrial Decline | Fog-Wrapped Coastal Town, Suburban Uncanny |
| Fantasy | Enchanted Wilderness, Ancient City Layers | Snow-Bound Isolation, Underground |
| Sci-Fi | Neon-Lit Metropolis, Snow-Bound Isolation | Underground, War-Torn Landscape |
| Historical | Ancient City Layers, High Society Estate | War-Torn Landscape, Fog-Wrapped Coastal Town |
| Crime / Noir | Neon-Lit Metropolis, Industrial Decline | Fog-Wrapped Coastal Town, Suburban Uncanny |
| Adventure | Tropical Paradise, Enchanted Wilderness | Snow-Bound Isolation, War-Torn Landscape |
| Domestic Thriller | Suburban Uncanny, High Society Estate | Neon-Lit Metropolis, Fog-Wrapped Coastal Town |
| Dark Romance | High Society Estate, Snow-Bound Isolation | Neon-Lit Metropolis, Enchanted Wilderness |
| Western | Sun-Baked Rural Heartland | Industrial Decline, Snow-Bound Isolation |
| YA | Suburban Uncanny, Enchanted Wilderness | Neon-Lit Metropolis, Ancient City Layers |

## How Settings Are Injected into Agents

### Architect Integration

The selected setting's full profile is injected into the Architect's system prompt:

```
TRANSPORTIVE SETTING: {setting_name}

{full sensory palette, weather patterns, architecture, social dynamics, time feel}

SETTING INTEGRATION RULES:
1. Every chapter brief's WORLDBUILDING BRIEF section must draw from this setting's
   sensory palette — use the specific smells, sounds, textures, and light qualities
   listed above, not generic alternatives
2. Weather patterns should follow the setting's established patterns, not random weather
3. Architecture details in scene locations should reflect the setting's built environment
4. Social dynamics from the setting should influence character interactions
5. The setting's "time feel" should shape chapter pacing — a Snow-Bound Isolation
   story moves differently from a Neon-Lit Metropolis story
6. SETTING AS MOOD in every scene brief must reference the transportive setting's
   atmosphere and show how the physical environment mirrors or contrasts the
   emotional tone of the scene
```

### Writer Integration

The setting's sensory palette is injected into the Writer's system prompt:

```
TRANSPORTIVE SETTING — PROSE GUIDE: {setting_name}

SENSORY VOCABULARY:
{smell, sound, touch, light entries from the setting profile}

ATMOSPHERE RULES:
1. Use at least 2 sensory details from the setting's palette per scene
2. Ground the reader in the setting within the first 3 paragraphs of every chapter
3. The setting should feel like a CHARACTER — it has moods, it reacts, it shapes events
4. Vary which senses you lead with — don't default to visual every scene
5. Weather and light are not decoration — they mirror or ironically contrast the
   emotional beats (the Architect's SETTING AS MOOD note tells you which)
6. Use the setting's specific vocabulary: if the setting says "brine" don't write
   "ocean smell"; if it says "neon reflections in puddles" don't write "city lights"
7. The setting's TIME FEEL should influence prose rhythm: Snow-Bound Isolation gets
   longer, more contemplative sentences; Neon-Lit Metropolis gets shorter, punchier prose
```

## Blending Settings

If the user wants to combine elements from multiple settings (Option B from design):

1. Let the user select a **primary setting** (dominant atmosphere)
2. Let the user select **1-2 accent settings** (secondary flavour)
3. Generate a blended profile that takes the primary's structure and weaves in
   specific sensory/social elements from the accents
4. Present the blended profile for approval

Example: "Fog-Wrapped Coastal Town" (primary) + "High Society Estate" (accent)
= Gothic seaside manor — salt air meets beeswax polish, harbour fog meets chandelier light,
  fishing community below the cliff, the great house above

## Anti-Patterns

- Do NOT use setting vocabulary as decoration — every sensory detail should serve mood or character
- Do NOT override genre conventions with setting — the setting enriches, not replaces
- Do NOT repeat the same 3 sensory details in every chapter — rotate through the full palette
- Do NOT ignore the setting's social dynamics — they shape character interaction
- Do NOT use setting details that contradict the Story Bible's established world
- Do NOT let the setting overwhelm the plot — it is atmosphere, not the story itself
