---
name: speculative-mystery-genre
description: "Genre-specific instructions for Speculative Mystery. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
---

# Speculative Mystery. Genre Plugin

## Metadata
- **Genre ID:** speculative-mystery
- **Display Name:** Speculative Mystery
- **Category:** Mystery & Crime
- **Tier:** Hybrid/Crossover
- **Target Word Count:** 3,000–5,000 per chapter
- **Min Word Count:** 3,000
- **Recommended Beat Structures:** Cozy Mystery Beat Sheet, Worldbuilding Beats, Three-Act Structure, Seven-Point Structure

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Fantasy Noir | Detective in a magical city, hardboiled with enchantment | Noir voice + magical underworld; corruption involves both mundane and arcane power |
| Sci-Fi Procedural | Crime-solving in a future setting, forensics adapted to technology | Future tech changes evidence, alibis, and motive; procedural rigour in speculative context |
| Magical Locked Room | Impossible crime that's only impossible without understanding the magic | Fair-play clues embedded in magical rules; solution requires world-knowledge |
| Time Travel Mystery | Crime across timelines, evidence in multiple eras | Temporal logic as clue structure; paradoxes as red herrings; causality as the puzzle |
| Alternate History Whodunit | Mystery in a world where history diverged | Changed history creates changed motives, power structures, and investigative tools |
| Techno-Thriller Mystery | Near-future crime involving emergent technology | Technology as both murder weapon and investigative tool; ethical implications central |

## Architect Instructions

### Chapter Planning Requirements

**Structure:**
- Chapter length: 3,000–5,000 words
- Pacing: Dual-engine. mystery investigation and speculative world discovery advance in tandem
- Must open with: Crime scene detail, world-rule demonstration, investigation step, or speculative anomaly
- Must close with: Clue recontextualised by world rules, investigation pivoting on speculative logic, or suspect interaction revealing world-specific information

**Beats Per Chapter:**
1. **Clue discovery**. Physical, magical, or technological evidence found and examined through the lens of the world's rules
2. **World rule reveal**. A law of physics, magic, or technology that changes what is possible. delivered through investigation, not lecture
3. **Investigation step**. Interrogation, deduction, forensic analysis, or surveillance adapted to the speculative setting
4. **Suspect interaction**. Character encountered whose motive, alibi, or capability is shaped by the world's unique rules
5. **Recontextualisation**. Previously known information shifts meaning when a new world rule is understood

### Genre-Specific Requirements
- Fair-play mystery. the reader CAN solve it, but only by understanding the world's rules
- Dual-engine pacing. every chapter advances both the mystery AND the world-building
- World rules as evidence. speculative elements fundamentally change what constitutes a clue, an alibi, or a motive
- Speculative elements serve investigation. every fantastical element either creates, complicates, or solves the crime
- No decorative world-building. if a magical/technological rule doesn't affect the mystery, cut it
- Red herrings from misunderstood rules. false leads arise from incomplete world knowledge
- Investigation adapted to setting. forensics, interrogation, and deduction modified by the world's possibilities
- Detective competence. investigator must be believable in this specific world's context
- Solution impossible without world. the crime could NOT have been committed (or solved) in our world
- Multiple suspects with world-specific motives. each suspect's motive shaped by the setting's unique possibilities

### Narrative Layers
- **Layer A (Investigation/Clues):** Crime scene, evidence, interrogation, deduction, forensics, red herrings, revelation
- **Layer B (World-Building/Rule Discovery):** How the speculative setting works, what's possible, what changes everything
- **Layer C (Detective's Personal Arc):** How the investigator is shaped by this world, what the case costs them personally

All three layers active in every chapter. Layers A and B are structurally intertwined. world rules ARE clues, and clues reveal world rules.

### Fractal Structure
- Novel level: Crime discovered → world rules learned → investigation adapts → truth revealed through world logic → resolution changes both mystery and world understanding
- Chapter level: Evidence examined → world rule illuminates → investigation pivots → new suspect/direction
- Scene level: Observation → "but in this world, that means..." → deduction

### Forbidden in Planning
- Deus ex machina solutions. no world rules introduced only at the climax to solve the crime
- Decorative world-building. every speculative element must serve the mystery
- Investigation ignoring world rules. detective can't investigate as if in our world
- Unsolvable mystery. reader must be able to reach the solution with available clues + world rules
- World rules that break fair play. no rules that make the crime literally impossible to deduce
- Info-dump world-building. rules revealed through investigation, not lecture
- Magic/tech as hand-wave. "a wizard did it" is not a solution
- Solution that works in any setting. if you remove the speculative elements and the mystery still works, the hybrid has failed

### World Rule Registry
Track every speculative rule that affects the mystery:
- **Rule stated:** What was established, in which chapter
- **Evidence affected:** How this rule changes what's possible as evidence
- **Alibis affected:** How this rule creates or destroys alibis
- **Motives affected:** How this rule creates unique motives
- **Red herrings:** How misunderstanding this rule creates false leads
- **Solution dependency:** Whether the final solution requires knowing this rule

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (genre-bent worldbuilding), Anticipation (puzzle), Revelation at solve.

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Voice and Tone
- **POV:** 1st person (detective's voice, unreliable knowledge of world) or 3rd close (access to deductive process)
- **Tense:** Past (investigative account) or present (immediate discovery)
- **Voice:** Observant, analytical, curious. the detective's mind working on two levels (crime + world)
- **Reading level:** Adult. complexity of both mystery logic and speculative world demands attention

### Prose Imperatives
- Crime scenes described through speculative lens. what's different here than in our world?
- World rules delivered through action and investigation, not exposition
- Detective's deductive process visible. show the thinking, the wrong turns, the recontextualisation
- Interrogation adapted to setting. questions a detective in this world would ask
- Clues embedded in world detail. the reader who's paying attention to the world-building gets the clues
- Technical accuracy. whether magic system or future tech, internal logic must hold
- Dual exposition. every piece of world-building also advances the mystery, and vice versa
- Atmosphere specific to setting. a magical city's rain is different from a space station's hum
- Fair-play signalling. clues must be visible on the page, not hidden in prose tricks

PROSE RHYTHM MAPPING (CRITICAL. world-rule + puzzle in every sentence)

Speculative mystery prose carries a double burden: it must advance the
investigation AND build the world simultaneously. The rhythm reflects
this dual engine. every descriptive detail teaches the reader how the
world works while planting or obscuring a clue.

Chapter 1 prose rhythm:
- Sentence average: 16-24 words. Complex enough to carry world detail,
  clean enough to maintain investigative momentum. The prose must never
  feel like it is pausing to explain the world. world-building is
  woven INTO investigation, not bolted onto it.
- Clue-delivery through world-mechanics: clues are embedded in the
  speculative rules themselves. The sentence describing a magical
  residue IS a clue. The paragraph about teleportation limits IS
  evidence. The prose makes no distinction between world-building and
  evidence-planting. the reader who tracks both solves the case.
- Dialogue density: 30-40% by word count. Interrogation adapted to
  setting. questions a detective in THIS world would ask. "When did
  you last use your teleportation permit?" World rules revealed
  through conversation, never through lecture.
- Recontextualisation rhythm: at least once per chapter, a previously
  established detail shifts meaning when a new world-rule is
  understood. The prose should create a "click". the reader feels
  information rearrange. Write these moments with clarity and
  precision; they are the genre's signature satisfaction.
- Tension floor: ≥5. The puzzle IS the tension. both the crime puzzle
  and the world puzzle. The reader should feel that understanding the
  world is the key to understanding the crime, and vice versa.

### Prose Masterclass Examples

**Crime Scene Through Speculative Lens:**
Show the detective examining evidence that only exists because of the world's unique rules. The absence of a teleportation signature. The residue of a spell that shouldn't be possible. The data log that shows the victim in two places simultaneously. The reader learns the world AND the mystery from the same paragraph.

The key is double-duty prose: every descriptive detail simultaneously builds the world and plants (or obscures) a clue. The detective examining a magical crime scene doesn't just see blood. they see the absence of a ward that should have prevented violence in this building. That's world-building AND evidence.

**The World-Rule Deduction:**
Show the moment when a new understanding of the world's rules transforms the meaning of existing evidence. This is the genre's signature move. the detective realises that because telepathy can't penetrate iron, the suspect's iron-walled office isn't paranoia but privacy for planning murder.

Write these moments with the click of a lock opening. Everything the reader already knew rearranges. The clue was visible all along. they just didn't understand the world well enough to read it.

**Interrogation Adapted to Setting:**
Questions a detective in this world would ask that a detective in ours wouldn't. "When did you last use your teleportation permit?" "Can anyone verify your astral whereabouts between three and four?" "The victim's familiar identified you by scent. care to explain?"

The interrogation reveals character, motive, world rule, and evidence simultaneously. Every question should be impossible in our world but perfectly natural in this one.

**The Speculative Red Herring:**
Mislead through misunderstood world rules. The detective (and reader) believes a suspect has an alibi because they think teleportation is instantaneous. but later learns it takes seven seconds, which is enough time. The red herring is built from world logic, not authorial sleight-of-hand.

Key principle: Fair-play red herrings come from the reader's incomplete understanding of the world, not from the author withholding information. Every piece of misdirection should be solvable in retrospect.

**Dual-Engine Prose:**
Every paragraph that advances the mystery should also build the world, and vice versa. Don't alternate between "mystery chapter" and "world-building chapter". interweave them in every scene.

The detective interviewing a suspect in a floating market isn't just conducting an interrogation. they're showing the reader how commerce works in anti-gravity, which will matter when they need to explain how the body was moved.

### Emotional Rhythm
- **Build:** Crime discovered, world glimpsed. curiosity on two fronts
- **Sustain:** Clues accumulate, world deepens. the puzzle grows more complex
- **Release:** Recontextualisation. a world rule clicks and evidence transforms
- **Recover:** New equilibrium, but with more questions. the next layer of both mystery and world

### Forbidden Words and Phrases
- "As you know" or "As I've explained". don't lecture about established world rules
- "In this world" as exposition. show through action, investigation, experience
- "It was magic" or "technology did it". specificity required, always
- "Impossible" without speculative qualification. what's impossible depends on the rules
- Jargon without context. technical terms must be graspable through use
- Our-world metaphors that break immersion. adapt comparisons to the speculative setting

## Quality Check Criteria

### Priority Ranking
1. **Fair-play solvability**. Reader can reach the solution using clues + world rules presented in the text
2. **World-rule consistency**. Speculative rules don't contradict themselves or change for convenience
3. **Dual-engine integration**. Mystery and world-building advance together, never separately
4. **Speculative elements essential**. Remove the fantastical elements and the mystery breaks
5. **Clue visibility**. Evidence and world rules are on the page, not hidden or withheld unfairly

### Genre-Specific Checks
- Every world rule that affects the solution is established before the climax
- Clues are embedded in world-building, not separated from it
- Red herrings arise from misunderstood world rules, not authorial withholding
- Investigation methods adapted to the speculative setting. not our-world forensics in a costume
- Detective's competence believable within the world's context
- Multiple suspects with world-specific motives that couldn't exist in our world
- Solution requires understanding both the crime AND the world
- World-building never pauses the investigation. always delivered in service of it
- Atmosphere specific to the speculative setting, not generic

### Automatic Fails
- Unsolvable mystery. solution depends on information not available to the reader
- Deus ex machina. world rule introduced at climax to solve the crime
- Decorative speculation. remove the fantastical elements and the mystery still works
- World rules changing for convenience. rules broken to make the plot work
- Info-dump world-building. pages of exposition disconnected from investigation
- "A wizard did it". vague magical explanation substituting for actual deduction
- Fair play violated. clues withheld, misleading narration, key evidence invisible to reader
- Investigation unchanged by setting. detective solves crime using only our-world logic

### Acceptable Imperfections
- Minor world details inconsistent if core mystery-relevant rules are airtight
- Some world-building that enriches atmosphere without directly affecting the crime
- Detective's personal arc receiving less attention than mystery + world integration
- Slightly uneven pacing between mystery and world-building chapters if both advance

## Continuity Rules

### Top 5 Continuity Priorities
1. **World rule registry**. Every speculative rule tracked, consistent, never contradicted
2. **Clue chain integrity**. Evidence introduced, recontextualised, and resolved without gaps
3. **Suspect alibi tracking**. With speculative complications (teleportation, time magic, shapeshifting)
4. **Evidence log**. Physical, magical, and technological evidence catalogued with chain of custody
5. **Investigation timeline**. When each clue was found, each suspect interviewed, each deduction made

### World Rule Registry
For every speculative rule:
- **Rule:** What it is, precisely
- **Chapter introduced:** When the reader first encounters it
- **How demonstrated:** Through action, investigation, or character experience (never pure exposition)
- **Evidence impact:** What this rule makes possible or impossible as evidence
- **Alibi impact:** How this rule affects suspect alibis
- **Motive impact:** What unique motives this rule creates
- **Solution role:** Whether the final solution depends on this rule

### Clue Chain Tracking
For every significant clue:
- **First appearance:** When and how the clue enters the narrative
- **Initial interpretation:** What the detective (and reader) first think it means
- **Recontextualisation:** When and how its meaning changes based on new world knowledge
- **Final role:** How it contributes to the solution
- **Fair-play check:** Could the reader have reached this interpretation?

### Suspect Tracking
For each suspect:
- **Name and role:** Position in the speculative world
- **Motive:** Why they might have committed the crime. shaped by world rules
- **Means:** How they could have done it. using world-specific capabilities
- **Opportunity:** Their alibi or lack thereof. complicated by speculative possibilities
- **World-specific capability:** What they can do that's unique to this setting
- **Red herring potential:** How misunderstanding a world rule might falsely implicate them
- **Elimination:** How and when they're cleared (or not)

### Evidence Log
For each piece of evidence:
- Physical/magical/technological. what type
- Where found, when, by whom
- What it initially suggests
- How its meaning shifts with world knowledge
- Chain of custody. who's handled it, could it be tampered with?

### Critical. Never Allow
- World rule contradicted between chapters
- Clue introduced after the reader needs it to solve the mystery
- Suspect's speculative capabilities changing without explanation
- Evidence disappearing without narrative justification
- Detective using investigation methods that shouldn't work in this world
- Fair play violated. reader misled by narration rather than world complexity
- World rules introduced only at the climax

### Acceptable Inconsistencies
- Minor atmospheric world details that don't affect the mystery
- Slight variations in how minor characters describe world rules (unreliable narrator effect)
- Background world elements that enrich setting without mystery implications

## Character Rules

### Top 5 Character Priorities
1. **World-native intelligence**. Detective thinks in this world's terms, not ours
2. **Speculative competence**. Investigator understands (or learns) the world's rules as investigative tools
3. **Motivated by both mystery and world**. Personal stake in both the crime and the setting
4. **Adaptable deduction**. Willing to abandon our-world assumptions when the evidence demands it
5. **Fallible worldview**. Detective's understanding of the world can be wrong, creating misdirection

### Character Types

**The Native Expert:**
- Born in this world, deep knowledge of its rules
- Blind spots from familiarity. assumes things the reader doesn't know
- Advantage: Deep world knowledge for investigation
- Vulnerability: Can't see what an outsider would notice
- Arc: The case reveals something about their world they never questioned

**The Outsider Investigator:**
- New to this world. learning rules as they investigate
- Reader surrogate. discovers world alongside the audience
- Advantage: Fresh perspective, questions assumptions natives don't
- Vulnerability: Misunderstands world rules, creates false leads
- Arc: Mastery of the world parallels solving the case

**The Magic-User Detective:**
- Possesses speculative abilities that aid investigation
- Powers have limits that create investigative challenges
- Advantage: Can perceive evidence others can't
- Vulnerability: Over-reliance on abilities creates blind spots
- Arc: The case requires them to go beyond their powers

**The Tech-Savvy Investigator:**
- Expert in the setting's technology, uses it forensically
- Technology as extension of deductive method
- Advantage: Can analyse evidence at levels others can't
- Vulnerability: Technology can be hacked, spoofed, manipulated
- Arc: Discovers the limits of technology. some truths require human intuition

### Relationship Dynamics

**Detective and World:**
- The investigator's relationship with the speculative setting IS a character dynamic
- How comfortable they are, what they fear, what they don't understand
- The world itself can be hostile, indifferent, or an ally to investigation

**Detective and Suspects:**
- Power dynamics shaped by speculative world. a telepathic suspect, a time-travelling witness
- Interrogation complicated by world-specific capabilities
- Trust difficult when the world allows deception on levels ours doesn't

### Red Flags
- Detective who ignores world rules when investigating
- Suspects with no speculative dimension to their character
- Sidekick who exists only to receive exposition
- World-building that doesn't serve the mystery in any way
- Detective who solves the case through our-world logic alone
- Romantic subplot that pauses the investigation entirely
- Villain whose motive would work in any setting

## Arc Rules

### Arc Types (Choose Based on Story)

**The World-Revealing Investigation:**
- Act I (Ch 1–10): CRIME AND WORLD. Murder discovered; investigation begins; world rules glimpsed through crime scene
- MIDPOINT (Ch ~15): RECONTEXTUALISATION. A world rule transforms the meaning of all previous evidence; investigation pivots
- Act II (Ch 11–23): DEEPENING. More suspects, more world rules, more complexity; detective's understanding of both crime and world growing
- Act III (Ch 24–30): SOLUTION. Crime solved through mastery of world rules; world itself understood differently

**The Dual Discovery:**
- Act I (Ch 1–10): TWO MYSTERIES. The crime AND the world are puzzles to solve simultaneously
- MIDPOINT (Ch ~15): CONVERGENCE. Realisation that understanding the world IS solving the crime
- Act II (Ch 11–23): INTEGRATION. Investigation and world discovery become inseparable
- Act III (Ch 24–30): UNIFIED SOLUTION. Crime and world-puzzle solved in a single revelation

### Required Checkpoints
- By Ch 3: Crime established AND first world rule demonstrated through investigation
- By Ch 8: At least three world rules introduced, each affecting the evidence differently
- By Ch 12: Major recontextualisation. evidence means something different now
- By Ch 15: All world rules needed for the solution are on the page (even if not yet understood)
- By Ch 20: Red herrings from misunderstood world rules are being cleared
- By Ch 25: Detective closing in. world mastery enabling deduction
- By Ch 28: Solution achieved through speculative logic + evidence
- Final chapter: Both mystery and world-understanding resolved

### Genre Promise
Speculative Mystery readers expect:
- Fair-play puzzle. solvable if you track the clues AND the world rules
- A world that matters. speculative elements essential to the crime, not decorative
- Intellectual satisfaction. the "click" of understanding both the mystery and the world simultaneously
- Adapted investigation. forensics, interrogation, and deduction reimagined for the setting
- World-specific impossibility. a crime that could only happen here
- Red herrings from world complexity. misdirection through misunderstood rules, not authorial cheating
- Resolution that rewards attention. readers who tracked both clues and world rules can solve it

## Timeline Rules

### Top 5 Timeline Priorities
1. **Investigation pacing**. Clue discovery rate maintains momentum while allowing world-building
2. **World-rule reveal pacing**. New rules introduced steadily, not front-loaded or back-loaded
3. **All rules before climax**. Every world rule needed for the solution established by 60% mark
4. **Recontextualisation timing**. Major evidence shifts spaced for maximum impact
5. **Suspect interview sequence**. Order of interviews reveals information strategically

### Genre-Specific Temporal Rules
- Investigation drives timeline. time passes according to investigative steps, not world events
- World-rule reveals paced like clues. steady drip, not flood
- Recontextualisations spaced. each shift given room to breathe and recalibrate
- Suspect interviews ordered strategically. each revealing world information needed for the next
- Deadline pressure optional. some speculative mysteries benefit from time pressure, others from thorough investigation
- Flashback/flash-forward used carefully. only if the speculative setting justifies (time travel, prophesy, memory magic)

### Investigation Pacing Guide
- Chapters 1–5: Crime + first 2–3 world rules + initial suspects
- Chapters 6–10: Deepening investigation + world rules complicating evidence + red herrings emerging
- Chapters 11–15: Major recontextualisation + new suspects or cleared suspects + world mastery growing
- Chapters 16–20: Narrowing suspects + world rules fully understood + detective closing in
- Chapters 21–25: Final complications + last red herring cleared + solution within reach
- Chapters 26–30: Solution achieved + world-understanding transformed + resolution

## Genre-Specific Craft Techniques

Speculative mystery is a hybrid genre that demands two
crafts simultaneously: the mystery's fair-play
investigative rigor (clues planted, deductions earned,
the reader given enough to solve the case) AND the
speculative element's worldbuilding integrity (rules
consistent, world textured, the speculation specific
and load-bearing). The genre's craft challenge is that
either engine, run alone, produces a deficient
manuscript: pure mystery in a fantasy setting that
ignores the magic loses the speculative reader; pure
worldbuilding with a token investigation loses the
mystery reader. The masterclass roster — Isaac Asimov
(the R. Daneel Olivaw novels: Caves of Steel, The
Naked Sun, The Robots of Dawn), Jasper Fforde (the
Thursday Next series, the Nursery Crime sequence,
Shades of Grey), China Miéville (The City & The
City), Charles Stross (the Laundry Files in mystery
register), Ben Aaronovitch (the Rivers of London
series), Dirk Gently (Douglas Adams), Randall Garrett
(the Lord Darcy stories), Genevieve Cogman (the
Invisible Library), Aliette de Bodard (the Xuya Tea
Master mysteries), Tade Thompson (the Wormwood
trilogy in mystery register), P. Djèlí Clark (the
Dead Djinn Universe novellas) — established the form;
the contemporary masterclass roster — Stuart Turton
(The 7½ Deaths of Evelyn Hardcastle, The Last Murder
at the End of the World), Mur Lafferty (Six Wakes), V.
E. Schwab's mystery-leaning work, Naomi Novik (Spinning
Silver in mystery-register), Catriona Ward, Sarah
Gailey (Magic for Liars), N.K. Jemisin's mystery-
adjacent work, Olivie Blake, Kate Mascarenhas (The
Psychology of Time Travel) — has expanded the genre's
range to include time-travel-mystery, magical-school-
mystery, post-apocalyptic-mystery, and structurally
experimental hybrids. The most common failure modes in
this register are: **Decorative-Speculation** (the
manuscript could be transplanted to a contemporary
realist setting without losing the mystery; the
speculation is wallpaper rather than load-bearing);
**Mystery-Without-Fair-Play** (the solution depends on
information the reader was not given, or on world
rules introduced in the climax); **World-Rules-Drift**
(the speculative rules shift to suit the plot;
teleportation takes seven seconds when the plot needs
it to and zero when the plot needs it not to);
**Single-Engine Stalling** (chapters that advance only
mystery without advancing world, or only world without
advancing mystery); **Solution-Outside-Rules** (the
detective solves the case through means the
established world does not support); **Speculation-as-
Convenience** (magic, technology, or speculative
ability deployed to remove evidence, create alibis, or
confuse evidence in ways the world's prior rules did
not allow); **Genre-Identity Confusion** (the
manuscript that does not commit to mystery's pacing or
to speculative's worldbuilding, ending up as neither);
**Anachronistic-Investigation** (the investigative
techniques drawn from contemporary procedural without
adjustment for the speculative world's specific
investigative resources); **Reader-Information Hoarding**
(the writer withholds world rules necessary for
solution, preventing fair play); and **Reveal-Without-
Resonance** (the solution reveal that explains the
mystery but does not produce the genre's signature
"of course" recognition). The techniques below — five
preserved (Dual-Engine Chapter, World-Rule Clue,
Speculative Red Herring, Integration Test, Fair-Play
Speculative Audit) and three added (World-Rules
Lockdown, Detection-Tools-of-the-World Architecture,
Solution-Resonance Discipline) — are designed to keep
the genre's defining hybrid commitments live: world
rules consistent and disclosed, detection methods
appropriate to the world, solutions that resonate as
inevitable in retrospect.

### The Dual-Engine Chapter

Advance both mystery and world-building in every single chapter. never dedicate chapters purely to one or the other. The investigation IS the vehicle for world discovery, and world discovery IS the vehicle for investigation.

Key principle: Every interrogation should reveal a world rule. Every world rule should recontextualise evidence. Every crime scene detail should teach the reader something about how this world works. If you find yourself writing a "world-building chapter" that doesn't advance the mystery, you've stalled one engine.

### The World-Rule Clue

Plant clues that only function as clues if the reader understands a speculative rule. The iron residue on the victim's hands means nothing unless you know that iron blocks telepathy. The seven-second gap in the teleportation log means nothing unless you know teleportation takes seven seconds, not zero.

Key principle: These clues should be visible on the page but invisible in meaning until the relevant world rule is understood. The reader who's tracking both the mystery AND the world should be able to solve the case. The reader who's only tracking one will be surprised.

### The Speculative Red Herring

Mislead through misunderstood world rules. the fairest kind of misdirection. The detective (and reader) believes Suspect A has an alibi because they misunderstand how a speculative rule works. When the correct understanding arrives, the alibi crumbles (or a different suspect's alibi strengthens).

Key principle: Every red herring should be solvable in retrospect. When the reader looks back, they should see that the misdirection came from their own incomplete world knowledge, not from the author hiding information. This is the genre's ethical contract. deception through complexity, not concealment.

### The Integration Test

Apply this test to every speculative element in the manuscript: "If I removed this fantastical element, would the mystery still work?" If yes, the element is decorative and should be cut or made essential. If no, the integration is working.

Key principle: The ideal speculative mystery is one where every world rule serves the crime. The magic system isn't background. it's the murder weapon, the alibi, the motive, and the solution. The more deeply integrated the speculation and the mystery, the more satisfying the "click" of resolution.

### The Fair-Play Speculative Audit

After drafting, verify that every element of the solution is available to the reader through presented clues + established world rules. Track the chain: "The reader knows X (world rule) from chapter 3. The reader sees Y (evidence) in chapter 8. Therefore, the reader CAN deduce Z."

Key principle: Map every logical step of the solution back to a specific page where the information appears. If any link in the chain is missing. if any world rule or piece of evidence needed for the solution isn't on the page. fix it before publication. Fair play is not optional in this genre.

### Speculative Mystery AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the technology revealed a disturbing truth" | Name the tech and the truth |
| "in a world where nothing is certain" | Show the specific uncertainty |
| "the algorithm knew more than it should" | Show the specific data point |
| "reality itself was the crime scene" | Show the specific anomaly |
| "the boundaries between worlds grew thin" | Show the specific manifestation |
| "a mystery that defied the laws of physics" | Show the specific impossibility |
| "the evidence existed in multiple realities" | Show the specific contradictory evidence |
| "truth was relative in this world" | Show the specific truth-distortion mechanic |
| "she questioned the nature of reality" | Show the specific observation that triggers doubt |
| "the impossible had become possible" | Show the specific impossible event |
| "the rules of magic were complicated" | Cut "complicated"; render the specific rule with specific named limit |
| "she examined the crime scene" | Show the specific examination through the specific speculative-world investigative method |
| "the witness's testimony was unreliable" | Show what specifically about the speculative-world makes their testimony unreliable |
| "the truth was stranger than fiction" | Cut cliché; show ONE specific strange fact and its specific deductive payload |
| "a paradox at the heart of the case" | Show the specific paradox and the specific rule that makes it a paradox |
| "his alibi seemed solid" | Show the specific alibi and the specific world-rule that makes it solid (or apparently solid) |
| "the impossible murder" | Cut announcement; render the specific impossibility through specific named contradictions |

### The World-Rules Lockdown

The World-Rules Drift failure mode is speculative
mystery's most fatal: the moment a rule shifts to suit
the plot, the genre's fair-play contract collapses.
The World-Rules Lockdown is the discipline of
establishing rules early, rendering them through
specific scenes, and refusing to adjust them
mid-manuscript even when convenient.

```
PRINCIPLE
The manuscript's speculative rule-set must satisfy at
least four of the following five lockdown criteria:
1. EARLY ESTABLISHMENT — the rules required for the
   solution are established before chapter 50% of
   the manuscript; the reader is given full
   information to deduce
2. SPECIFIC DEMONSTRATION — each rule is rendered
   through a specific scene that shows it in
   operation, not merely declared in narration; the
   reader sees the rule work
3. CONSISTENT APPLICATION — the rule operates the
   same way every time it appears; if the rule
   has limits, those limits are shown to apply
   universally
4. TESTED EDGE-CASES — the manuscript renders at
   least one edge-case where the rule's limits
   matter; the rule is shown to bend or break
   under specific conditions, but the bending /
   breaking follows internal logic
5. NO MID-MANUSCRIPT REVISION — once a rule is
   established, it is not silently revised; if a
   rule must be amended for plot reasons, the
   manuscript renders the revision as in-world
   discovery rather than retroactive change

CALIBRATION TEST
- Across the manuscript, do the speculative rules
  remain consistent? Could a reader chart the rule-
  set on a single page and have it apply
  throughout?
- Are the rules required for the solution
  established before the climax?
- Do edge-cases follow internal logic rather than
  authorial convenience?
- Does the manuscript hold the rules even when
  inconvenient?
If any answer is no — rebuild for rule-lockdown.

ANTI-PATTERN
- The rule established in chapter 3 that quietly
  changes operation in chapter 27
- The exception that appears specifically when the
  plot requires it
- The mid-manuscript "actually, the rule works
  this way" reveal that wasn't seeded
- The convenient new rule introduced near the
  climax to enable the solution
```

### The Detection-Tools-of-the-World Architecture

The Anachronistic-Investigation failure mode imports
contemporary procedural techniques (DNA testing,
digital forensics, surveillance capture) without
adjusting for the speculative world's specific
investigative resources. The Detection-Tools-of-the-
World Architecture is the requirement that
investigation methods be drawn from and constrained
by the manuscript's specific speculative setting.

```
PRINCIPLE
The manuscript must render investigation through at
least four of the following five world-specific
considerations:
1. AVAILABLE MAGICAL / TECHNOLOGICAL TOOLS — what
   investigation tools the world specifically
   provides (specific named magical detection,
   specific named technological scanning, specific
   named species-ability that the detective can
   call on)
2. UNAVAILABLE TOOLS — what the world specifically
   does NOT provide; the absence of conventional
   forensic tools, the absence of ubiquitous
   surveillance, the absence of contemporary
   procedural assumptions
3. WHO HAS AUTHORITY TO INVESTIGATE — the
   institutional architecture of detection in this
   world; named investigative bodies, named
   jurisdictional rules, named authority limits
4. EVIDENCE TYPES NOVEL TO THE WORLD — speculative
   evidence categories the contemporary procedural
   does not encounter (magical residue, time-
   stamped reality, dream-evidence, divinatory
   testimony, AI-perception logs)
5. INVESTIGATIVE CULTURE — the specific way this
   world's detectives operate (rituals, partner
   conventions, deduction methods, presentation
   formats); the cultural texture of the
   detective's profession in THIS world

CALIBRATION TEST
- Could the investigation be transplanted to
  contemporary procedural without adjustment? If
  yes, the world has not been integrated.
- Are at least four of the five world-specific
  considerations operative?
- Does the detective have access to specific tools
  the contemporary detective does not, AND face
  specific limits the contemporary detective does
  not?
- Is the investigative institutional architecture
  rendered through specific named bodies and rules?
If any answer is no — rebuild for world-specific
investigation.

ANTI-PATTERN
- The detective who deploys CSI techniques in a
  medieval fantasy setting
- The investigation that ignores available
  magical or technological tools the world
  provides
- The institutional vacuum (no named
  investigative authority, no jurisdictional
  rules)
- Magical or technological evidence whose
  handling protocols are not specified
- The detective culture that is contemporary-
  procedural with cosmetic adjustment
```

### The Solution-Resonance Discipline

The Reveal-Without-Resonance failure mode produces
solutions that explain the mystery but do not produce
the genre's signature recognition. The Solution-
Resonance Discipline is the requirement that the
solution feel both surprising and inevitable in
retrospect — the moment of "of course" that depends
on the world's rules and the planted clues converging
exactly.

```
PRINCIPLE
The solution must satisfy at least four of the
following five resonance criteria:
1. RULES-DEPENDENT — the solution requires the
   reader to understand the world's rules; the
   detective could not have solved it without the
   speculative knowledge
2. CLUES-COMPLETE — every step of the solution is
   traceable to a clue planted somewhere in the
   manuscript; the reader could have solved it
3. CHARACTER-CONGRUENT — the perpetrator's identity
   and motive are consistent with their prior
   characterisation; the reveal does not require
   the reader to learn new psychological
   information about the perpetrator at the
   reveal
4. WORLD-APPROPRIATE STAKES — the solution's
   consequences flow from the world's specific
   institutional and social architecture; the
   reveal is consequential within this world
5. EMOTIONAL WEIGHT — the solution carries
   emotional weight beyond intellectual
   satisfaction; the reader feels something about
   what was uncovered, not merely thinks "ah, of
   course"

CALIBRATION TEST
- Does the solution depend on understanding the
  speculative world's rules?
- Could a careful reader have solved it from the
  page?
- Is the perpetrator's reveal character-consistent
  rather than character-revealing?
- Does the solution carry consequence and emotional
  weight?
If any answer is no — rebuild for solution
resonance.

ANTI-PATTERN
- The solution that could work in any setting
  (the speculation is decorative)
- The solution that requires information the
  reader was not given (fair-play violation)
- The perpetrator whose identity surprises by
  contradicting prior characterisation rather
  than by completing it
- The reveal that satisfies intellectually but
  carries no emotional weight
- The solution whose consequences do not flow
  from the world's specific institutional
  architecture
```

## Genre-Specific Revision Rules

### Six-Pass Speculative Mystery Audit (Run FIRST in editorial pipeline)

The Speculative Mystery Audit runs every chapter through
six named passes. Run them in order — each builds on
the last.

#### Pass 1: Fair-Play Solvability Pass

Verify a careful reader can solve the mystery using
only information present in the text. Is every world
rule needed for the solution established before the
climax? Are clues visible (even if their meaning is
not immediately clear)? Are red herrings fair —
arising from misunderstood rules rather than withheld
information? The Mystery-Without-Fair-Play and
Reader-Information Hoarding failure modes are caught
here. the genre's ethical contract is that deception
operates through complexity (the reader has the
information but has not yet integrated it) rather
than through concealment.

#### Pass 2: World Rule Consistency Pass

Verify every speculative rule works the same way every
time it appears. Are there convenient exceptions that
serve the plot? Is the rule set complete with no gaps
that allow solutions outside the established logic? Do
characters behave consistently with the world's rules?
The World-Rules Drift failure mode is caught here. the
World-Rules Lockdown discipline provides the spec —
early establishment / specific demonstration /
consistent application / tested edge-cases / no mid-
manuscript revision.

#### Pass 3: Dual-Engine Balance Pass

Verify every chapter advances both the mystery and the
world-building. Are there purely world-building chapters
that stall the investigation? Are there purely mystery
chapters that ignore the speculative setting? Is the
ratio balanced across the novel? The Single-Engine
Stalling failure mode is caught here. the Dual-Engine
Chapter is the genre's structural commitment, and any
chapter that fires only one engine has lost the
manuscript's hybrid texture.

#### Pass 4: Clue Integration Pass

Verify every clue is embedded in world-building rather
than isolated. Do clues gain new meaning when world
rules are better understood? Is the evidence chain
complete from crime scene to solution? Are planted
clues distinguishable from background detail on re-
read? The World-Rule Clue technique provides the spec
— clues that only function as clues if the reader
understands a speculative rule. The genre's signature
craft pleasure is the moment when a previously-
innocent detail becomes the key.

#### Pass 5: Speculative Element Necessity Pass

Apply the Integration Test to every speculative
element: if removed, does the mystery break? The
Decorative-Speculation failure mode is caught here.
if any element is decorative, either make it essential
or remove it. Does the solution require understanding
the speculative world? Could this mystery be set in
our world without changes? (If yes, the hybrid has
failed.) The Detection-Tools-of-the-World Architecture
provides additional spec — investigation methods drawn
from and constrained by the manuscript's specific
speculative setting.

#### Pass 6: World-Rules-Lockdown + Detection-Tools + Solution-Resonance Integration

This pass is the speculative mystery integration check
— it ties the new techniques together and verifies the
manuscript honours the genre's defining hybrid
commitments at the manuscript level.

For WORLD-RULES-LOCKDOWN: confirm Pass 2's spec at the
manuscript level. Could a reader chart the rule-set
on a single page and have it apply throughout? Are
edge-cases internally logical rather than convenient?
Has any rule been silently revised mid-manuscript?

For DETECTION-TOOLS: confirm investigation methods
are world-specific rather than imported procedural.
Are at least four of the five world-specific
considerations (available tools / unavailable tools /
authority architecture / novel evidence types /
investigative culture) operative? The Anachronistic-
Investigation failure mode is caught here.

For SOLUTION-RESONANCE: at the ending level, audit
whether the solution satisfies at least four of the
five resonance criteria (rules-dependent / clues-
complete / character-congruent / world-appropriate
stakes / emotional weight). The Reveal-Without-
Resonance failure mode produces solutions that
explain the mystery but do not produce the genre's
signature recognition. if the solution lands flat,
the manuscript's resolution craft must be rebuilt to
produce the "of course" inevitability the genre
demands.

## Names & Patterns to Avoid

### Forbidden Patterns
- The mystery that works without the speculative elements. decoration is not integration
- "A wizard did it". vague magical explanation substituting for actual deduction
- World rules introduced only when needed to solve the crime
- The detective who investigates exactly as they would in our world
- Speculative elements as obstacle course rather than investigative tools
- The reveal that depends on information the reader never had
- The sidekick who asks "how does that work?" so the detective can info-dump
- Magic/tech that conveniently doesn't work when the plot needs it to fail

### Cliche Setups to Avoid
- The "chosen one" detective who can see things no one else can (unless the limits create real challenges)
- The case that's actually about a prophecy (mystery, not quest narrative)
- The evil corporation/cabal that's behind everything (make it personal)
- The climactic magic battle instead of a climactic deduction
- The "it was the least likely person" without world-logic supporting it
- The world where everyone has magic except the detective (unless that IS the puzzle)

### Naming Considerations
- World-appropriate names. matching the speculative setting's culture and history
- Detective's name should suggest competence and world-belonging
- Suspects' names distinct from each other. many names to track in a mystery
- Avoid names too similar to famous fictional detectives (Holmes, Poirot, Marple, etc.)
- Speculative terminology should be intuitive or quickly contextualised
- Avoid jargon overload. maximum 3–4 world-specific terms introduced per chapter

## Comp Titles

Speculative-mystery's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Caves of Steel* — Isaac Asimov (1954): the SF-mystery template; the R. Daneel Olivaw novels.
- *Lord Darcy* (stories) — Randall Garrett (1964-1979): magical-procedural mystery foundation.
- *Dirk Gently's Holistic Detective Agency* — Douglas Adams (1987): comic-speculative-mystery.

### Contemporary (current best-in-class)

- *The City & The City* — China Miéville (2009): the genre-defining literary-speculative-mystery.
- *The Eyre Affair* — Jasper Fforde (2001): the Thursday Next series; meta-speculative-mystery.
- *Six Wakes* — Mur Lafferty (2017): closed-circle SF-mystery on a generation ship.
- *The 7½ Deaths of Evelyn Hardcastle* — Stuart Turton (2018): time-loop speculative-mystery; modern category benchmark.
- *Magic for Liars* — Sarah Gailey (2019): magical-school speculative-mystery.
- *The Last Murder at the End of the World* — Stuart Turton (2024): post-apocalyptic speculative-mystery.
- *Rivers of London* — Ben Aaronovitch (2011): the Peter Grant series; urban-fantasy-procedural mystery.

## Cover Design Specifications

### Visual Tone
- Atmospheric, mysterious, intellectually intriguing
- Blending genre aesthetics. mystery noir + speculative wonder
- Dual visual language. crime elements (magnifying glass, evidence) + speculative elements (magic, tech)
- Sophisticated. this is a thinking reader's genre

### Key Visual Elements
- Crime scene rendered in speculative setting (magical evidence markers, holographic outlines)
- Detective silhouette against impossible architecture or alien sky
- Dual imagery. something familiar (evidence, investigation) shown through an unfamiliar lens
- Atmospheric lighting. neon in rain, magical glow through fog, starlight through a crime scene window
- World details visible but mysterious. inviting the reader to puzzle over them

### Typography
- Clean, sharp fonts. intellectual precision
- Title prominent. often two-word or three-word titles work well for this genre
- Genre signalling through font treatment. slightly otherworldly while clearly mystery
- Author name visible, especially if series

### Colour Palette
- Primary: Deep, atmospheric tones. midnight blue, amber, violet
- Accent: Speculative element colour. magical glow, tech neon, otherworldly luminescence
- Contrast: Sharp highlights against dark backgrounds. the visual equivalent of a clue catching light
- Avoid: Generic mystery dark palettes. the speculative element must be visible in the colour choice

### Comp Titles (Cover Style Reference)
- *The City & The City* by China Mieville. atmospheric, intellectually challenging, noir
- *The 7½ Deaths of Evelyn Hardcastle* by Stuart Turton. puzzle-box, elegant, mysterious
- *A Memory Called Empire* by Arkady Martine. sophisticated, speculative, atmospheric
- *The Yiddish Policemen's Union* by Michael Chabon. alternate history, noir, literary
