---
name: heat-calibration
description: "Universal prose calibration for the Setup Q4 / per-chapter Spice 0-5 pipeline. Engine-agnostic, genre-agnostic. Loaded into the Writer prompt's {heat_level_calibration} slot whenever heat level applies (romance genres, or any genre with a romance subplot)."
version: "2.3.2"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# Heat Level Calibration (Universal)

This is the universal prose calibration for the Setup Q4 / per-
chapter Spice 0-5 pipeline. It applies to **any genre** where heat
level is captured at setup — i.e. all romance genres AND any non-
romance genre with `romance_subplot: yes` selected at Q3.

The block is loaded into the Writer prompt's
`{heat_level_calibration}` slot (see `prose-agent.md`, "Heat Level
Calibration Slot"). The Writer reads it BEFORE the genre file's
craft rules, and INSTRUCTION HIERARCHY rule 4 ("HEAT CALIBRATION")
gives it priority over default chemistry-demonstration cues from
the genre file.

## Why this is genre-agnostic

Heat level is a property of the project, not the genre. A thriller
with a romance subplot at Spice:0, a fantasy with a slow-burn arc
at Spice:1, and a contemporary romance at Spice:0 all face the
same calibration problem: the model's default chemistry vocabulary
leans steamy, and at low heat that vocabulary collapses to
Hallmark/KU cliches. The substitute prose imperatives — interior
architecture, non-body sensory channels, character-rooted
specificity — work identically across genres.

Genre files may add genre-specific overlays (e.g. how a thriller's
romance subplot interacts with the suspense pacing) but the core
calibration lives here.

---

## Read this first; it overrides defaults

Heat level is set at Setup Q4 and rated per chapter (Spice 0-5) by
the Architect. Every chemistry / intimacy / banter cue in the
genre file applies DIFFERENTLY at each heat level. The Writer must
calibrate to the chapter's rated Spice level before applying any
other prose rule from the genre file. Default genre cues lean
steamy — without this calibration, low-heat books drift into
Hallmark/KU cliche territory because the chemistry-demonstration
playbook has been emptied out without a substitute being supplied.

═══ Sweet/Clean (Spice 0-1) ═══

What the chapter contains: Attraction, awareness, longing,
emotional intimacy, banter, vulnerability, possibly hand-holding /
embraces / closed-door kisses by Act 2-3. NO physical intimacy
beyond that. Tension comes from emotional risk, not bodily desire.

What the prose leans into instead of physical heat:

- **Interior architecture.** Spice:0 chemistry lives in interiority
  more than body. Use 80-120 words of internal beat per chemistry
  moment (higher than the 60-80 default). What does she NOTICE
  about him she didn't notice last week? What does he keep almost
  saying and pull back from? The reader is in the gap between
  acknowledgement and admission.
- **Banter that earns its sparkle without sexual subtext.** No
  "verbal foreplay". Sweet-clean banter is wit, shared reference,
  surprised laughter, the relief of being understood. He makes her
  laugh in a way her colleagues can't. She catches a joke he didn't
  finish. Banter advances character knowledge, not heat.
- **Sensory channels other than the body.** Weather, food, music,
  work, place. The smell of his grandmother's house. The way he
  rolls up his sleeves to fix her sink. Coffee gone cold on the
  table because they're still talking. These carry the chemistry
  load that scent-of-skin / racing-heart cues carry at higher
  heat.
- **Slow burn architecture.** First-touch moments matter more —
  one accidental brush of fingers in Ch 6 carries the weight a
  steamy book wouldn't ask of it. Treat each escalation
  (eye contact held a beat too long, hand offered, embrace, first
  kiss) as a load-bearing structural beat, not a passing moment.
- **Stakes outside the bedroom.** Family, community, faith,
  vocation, place, principle, secret. Sweet-clean romance leans
  on what makes the relationship costly to have, not on what
  makes it physically intense. Period romance, faith-based,
  small-town, second-chance with grown children, single-parent —
  the externals carry weight.
- **Sentence rhythm.** The "shortens when attraction spikes" rule
  still applies, but the spike at Spice:0 is a glance, a held
  breath while she waits for his answer, a phone vibrating at the
  wrong moment. The shortening accents non-bodily revelation.

What to AVOID (these are the cliche fallbacks the model defaults to
when it can't reach for sensual cues):

- "Her heart skipped a beat" / "skipped a beat"
- "She felt her cheeks flush" / "her cheeks bloomed pink" /
  "a blush crept up her neck"
- "Their eyes locked" / "their gazes met and held"
- "An electric jolt" / "a jolt of electricity"
- "Time seemed to slow" / "time stood still"
- "Warmth spread through her chest"
- "She bit her lip" (as a chemistry tell)
- "He raked his hand through his hair"
- "Their fingers brushed (accidentally)"
- "A shiver ran down her spine"
- "His gaze pinned her in place"
- "She held her breath"
- "Butterflies in her stomach"

These phrases are not banned outright — used once, sparingly, in
the right moment, any of them can land. Used as the default
chemistry vocabulary they read as robotic and Hallmark-derivative.
If you find yourself reaching for one, ask: what would THIS
character, in THIS specific moment, actually notice? Replace the
generic tell with a specific one rooted in this character's
history and this scene's stakes.

═══ Mild Spice (Spice 2) ═══

What the chapter contains: Everything Sweet/Clean does, plus
on-page kissing, deliberate touch, fade-to-black for anything
beyond that. Tension carries a bodily charge but the camera turns
away at the bedroom door.

What the prose calibration adjusts:

- Body cues now in play (warmth, awareness of physical presence,
  the consequence of accidental contact) but they ride alongside
  the interior architecture, never replacing it.
- The "almost moments" become longer and more architectural —
  the held kiss interrupted by a phone, the moment in the
  doorway when neither steps back. These are the load-bearing
  beats Mild Spice trades on.
- Fade-to-black should be earned: the buildup is on-page, the
  consummation is implied, the after-shot (next morning,
  emotional residue) is on-page again.

═══ Open Door (Spice 3-5) ═══

What the chapter contains: On-page intimacy with detail
proportional to rated level. The genre file's intimate-scenes
guidance (where present — see e.g. `romance.md` "INTIMATE SCENES")
applies.

What the prose calibration retains from the lower levels:

- Interior architecture still does the heaviest lifting. Sex
  scenes that are all body and no interior read as choreography.
- Banter still earns its sparkle from character, not just heat.
  Sexual subtext is layered ON TOP of wit, not replacing it.
- The "almost moments" before consummation still matter. A book
  that hits Spice:4 in Ch 5 and stays there has spent its
  ammunition; reserve the peak for narrative payoff.

═══ Calibration self-check before submitting a chapter ═══

Before the Writer hands a chapter back, run this self-check:

1. What is this chapter's rated Spice level (from the brief)?
2. Did any chemistry beat use a body-cue that requires a higher
   Spice level than this chapter is rated for?
3. Did any scene avoid showing chemistry at all because the
   default sensual cues weren't available, instead falling back
   to "heart skipped a beat"-class cliches?
4. Is the sensory load carried by non-body channels appropriate
   to this Spice level?
5. Is the interior beat length scaled correctly (80-120 words at
   Spice:0-1, dropping toward 60-80 as Spice rises and body cues
   take more of the load)?

If any answer is wrong, the prose is mis-calibrated. Revise.

---

## Cliche blocklist

Used by `forbidden-words-scan.sh` (when extended to take Spice
input) and surfaced to the Writer in the prompt slot.

### High-spice cliches (apply at ALL heat levels)

- "His manhood": use actual anatomical terms or sensual description
- Purple prose: "throbbing member", "turgid peaks", overly flowery
- "She released the breath she didn't realize she was holding":
  overused breath cliche
- "Chemistry" stated: show it, don't name it
- Instant love: "love at first sight" without showing attraction
  to love progression
- "Perfect" repeatedly: flaws make characters real
- Clinical detachment: if writing intimacy, embrace sensuality

### Sweet/Clean cliches (especially flag at Spice 0-1; once-each discipline at Spice 2+)

- "Her heart skipped a beat" / "skipped a beat"
- "She felt her cheeks flush" / "her cheeks bloomed pink" / "a
  blush crept up her neck"
- "Their eyes locked" / "their gazes met and held"
- "An electric jolt" / "a jolt of electricity ran through her"
- "Time seemed to slow" / "time stood still"
- "Warmth spread through her chest"
- "She bit her lip" (as a chemistry tell — fine as a stress tell)
- "He raked his hand through his hair"
- "Their fingers brushed accidentally" / "his hand brushed hers"
- "A shiver ran down her spine"
- "His gaze pinned her in place" / "his gaze pinned her"
- "She held her breath" (as a chemistry beat)
- "Butterflies in her stomach" / "butterflies took flight"

Each of the sweet-romance cliches above can land if used once in
the right moment. The failure mode is using them as default
chemistry vocabulary when no specific, character-rooted cue
presents itself. If reaching for one, stop and ask: what would
THIS character in THIS specific moment actually notice?

---

## Worked example: Sweet/Clean chemistry done well

The two paragraphs below are the same scene beat — first kiss
moment, Spice:0, small-town second-chance romance. Read both
and notice what changes.

CLICHE-DRIVEN (the Hallmark/KU default the model reaches for
when no calibration is supplied):

  Maya's heart skipped a beat as Tom leaned closer. Their eyes
  locked, and time seemed to slow. A jolt of electricity ran
  through her when his fingers brushed hers. She felt her cheeks
  flush, butterflies taking flight in her stomach. He raked a
  hand through his hair and held her gaze, and she held her
  breath. Warmth spread through her chest. This was the moment
  she had been waiting for.

What's wrong: every chemistry tell is a stock phrase. None of it
is rooted in Maya, Tom, this town, this history, this Tuesday.
Replace any character name and any setting and the paragraph
still works — which is the diagnostic. It's robotic because it's
made of parts that fit any couple.

CALIBRATED (Spice:0 with interior architecture, non-body sensory
channels, character-rooted specificity):

  He'd left her on this porch in 2014 with the light bill
  unpaid and a promise he hadn't kept, and now he was standing
  one boot-step closer than he had any right to. Maya could smell
  the lemon polish her aunt had made her use on the railing that
  morning. The cicadas were loud enough that whatever he said
  next, she might mishear it on purpose. Eleven years of replies
  she'd rehearsed in the car between the diner and the house —
  none of them survived the way he was looking at her, like he'd
  been planning to apologise the whole drive over and forgotten
  the sentence on the steps. He didn't reach for her. That was
  the thing that undid her. The other Tom would have. This one
  was waiting to be told.

What works:

- Interior beat is ~110 words (Spice:0 target). Eleven years of
  rehearsed replies, the way the model of him she carries
  doesn't match the man on the steps. Chemistry lives in that
  gap.
- Sensory channels are non-body: lemon polish (the aunt's
  routine, her place in this house), cicadas (small-town, late
  summer, she might mishear on purpose), boot-step (specific
  proximity without naming touch).
- The chemistry tell is what he DOESN'T do: doesn't reach for
  her. Used as Spice:0's load-bearing beat where a higher-heat
  scene would have first contact.
- Character-rooted: he's the Tom who left her with the light
  bill unpaid in 2014 — every other detail in the paragraph
  is shaped by that history. Replace Tom or the town and the
  paragraph collapses.
- The accumulated pressure of held-back declaration ("plenty
  of replies she'd rehearsed in the car... none of them
  survived") is doing the work that "her heart skipped a beat"
  is reaching for in the cliche version.

Notice what's NOT in the calibrated version: no body-cue
chemistry vocabulary at all (no flush, no jolt, no skipped
heart, no held breath). The scene carries weight without any
of the stock vocabulary because the specifics are doing the
load-bearing. That's the calibration target.

---

## Where this block is loaded

`prose-agent.md`'s `{heat_level_calibration}` slot pulls from
this file by default for any project where heat applies. Genre
files may layer genre-specific overlays on top (a thriller's
romance-subplot pacing, a historical's period-appropriate
restraint, a fantasy's worldbuilding-mediated chemistry) — but
the core calibration is universal and lives here.

When this file is updated, the change applies everywhere
heat-calibrated prose is generated, regardless of genre. No
parallel updates required to per-genre files.
