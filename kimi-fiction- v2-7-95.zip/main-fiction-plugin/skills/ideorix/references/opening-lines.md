---
name: opening-lines
description: "Universal four-pattern framework for crafting opening lines that maximize reader engagement. Engine-agnostic, genre-agnostic, conditional load (fires on chapter and book opens). Provides pattern definitions, templates, evaluation checklist, and revision guidance."
version: "2.3.4"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*


# Opening Lines (Universal — Conditional Load)

This file is loaded into the Writer prompt's
`{opening_line_diagnostic}` slot **conditionally** — only when
the scene being generated is a chapter opening or a book
opening. Most scenes do not trigger it. This keeps the
universal-craft load lean for the majority of generation calls
while ensuring opening moments — which carry outsized weight —
get specific framework guidance.

## Why opening lines are different

The opening line of a book is the only line that does not follow
another line. It carries an outsized burden: it sets tone,
voice, pace, and an implicit promise of what's to come. The
reader has just decided to open the book. The first line either
delivers them to the second line or loses them.

Chapter openings carry similar (if smaller) weight. The reader
has just turned the page from a chapter ending — the chapter
ending pulled them forward; the chapter opening must reward that
forward motion.

Both share a single craft requirement: **be intriguing without
begging for attention.** The strongest opening lines do their
work subtly. They don't announce themselves. They hold out a
slight indication of what's to come, then trust the reader to
decide.

## The four patterns

Effective opening lines tend to deploy one (or more) of four
psychological-engagement patterns. The patterns are not
mutually exclusive; the strongest openings often combine two.

### Pattern 1 — Emotional Contradiction

**Structure:** A statement that establishes an emotional
expectation and immediately subverts or complicates it.

**Effect:** Triggers a prediction-error response. The reader's
brain seeks resolution and reads on to find it.

**When to use:** When you want instant unease or mystery; when
the story turns on something hidden beneath the surface of
ordinary life.

**Templates:**

- "I always believed X — until the day Y happened."
- "Everyone said it was safe here, except for me."
- "[Positive statement]. [Subtle contradiction or
  complication]."

**Evaluation signals:**

- Presence of contrasting emotional cues
- Positive or neutral statement followed by unease or conflict
- A "however" or "until" or "except" implicit or explicit

### Pattern 2 — Intimate Universal

**Structure:** A personal, specific expression of a feeling or
moment that reflects a broadly relatable human experience.

**Effect:** Activates empathetic mirroring. The reader
recognises themselves in the line and bonds with the narrator
or POV.

**When to use:** When you want deep relatability; when the
story is character-driven; when emotional resonance matters
more than plot momentum at the open.

**Templates:**

- "We all remember our first X, but mine began with Y."
- "It's strange how something ordinary can change everything."
- "[Universal human experience], framed as personal
  confession."

**Evaluation signals:**

- Universally relatable premise
- Framed as a personal experience or confession
- The "I" or "we" of the opening invites the reader into the
  speaker's perspective

### Pattern 3 — Temporal Disruption

**Structure:** A sentence that introduces deliberate
uncertainty or layering of time references (past, present,
future).

**Effect:** Engages the reader's orientation processing and
curiosity by destabilising the timeline. The reader works to
locate themselves in time.

**When to use:** When you want a dreamy, reflective, or
suspense tone; when the story plays with chronology;
retrospective narration; foreshadowing of consequence.

**Templates:**

- "I didn't know it then, but that was the day everything
  ended."
- "Last night, I dreamed of the place I haven't visited yet."
- "[Future-perspective comment about a past event]."

**Evaluation signals:**

- Mixed verb tenses (past + future, past perfect + simple
  past, present + retrospective)
- References to multiple timeframes
- Retrospective or prophetic framing

### Pattern 4 — False Certainty

**Structure:** A confidently delivered statement about a
concept or event that, upon reflection, contains inherent
ambiguity or contradiction.

**Effect:** Exploits the curiosity gap by pairing an
authoritative tone with uncertain meaning. The reader wants
to fill in the missing information.

**When to use:** When you want intrigue or irony; when the
story turns on an unreliable narrator or a hidden twist;
when the opening line itself can carry symbolic weight.

**Templates:**

- "It began the day I died."
- "Everyone agrees what happened was inevitable — though no
  one knows why."
- "[Definitive declarative statement] [about something
  ambiguous or impossible]."

**Evaluation signals:**

- Declarative tone
- Embedded ambiguity
- Implied but unresolved contradiction

## Evaluation checklist

When generating or evaluating an opening line, check:

1. **Emotional Tension** — Does the sentence create a
   contradiction or unresolved feeling?
2. **Personal Relevance** — Does it tap into universal
   emotions or experiences?
3. **Temporal Complexity** — Does it shift or destabilise
   time in an intriguing way?
4. **Curiosity Generation** — Does it make a definitive
   claim that raises a question?

A strong opening line activates **at least two of the four
criteria.** A line activating only one is functional. A line
activating none is flat and should be revised.

## Combination patterns

The strongest opening lines often combine two patterns:

- **Pattern 1 + Pattern 4** — Emotional contradiction
  delivered with false certainty: "I always believed I would
  die first. I was wrong about almost everything."
- **Pattern 2 + Pattern 3** — Intimate universal with
  temporal disruption: "We all think we'll know when it ends.
  I should have. I didn't."
- **Pattern 1 + Pattern 3** — Emotional contradiction with
  temporal disruption: "I had been happy that morning. By
  the time the sun set, I had forgotten what the word meant."

Combinations are stronger than single-pattern lines because
they engage multiple psychological-response mechanisms in
parallel.

## Anti-patterns to avoid

These opening-line forms typically fail to engage:

- **Weather as scene-setter without complication** — "It was
  a bright cold day in April" works only because of what
  follows ("and the clocks were striking thirteen"). On its
  own it is flat.
- **Generic action without context** — "She ran." Who? Why?
  From what? Without immediate context, generic action
  fails to engage.
- **Wholesale exposition** — "Sarah Henderson had grown up
  in a small town in southern Oregon, where..." Backstory
  belongs later, not in the opening line.
- **Mirror-narration of physical features** — "She looked
  in the mirror at her chestnut hair and narrow blue eyes."
  Nobody narrates their own features standing at a mirror.
- **Dream openings** — "She woke up." Dreams as openings
  are nearly always discardable; they don't commit to the
  story's reality.
- **Begging for attention** — Lines that announce their own
  importance ("This is the story of...") rather than letting
  the reader discover it.

## Application by scene type

### Book opening (the first line of the manuscript)

Carries the most weight. Should activate at least two of the
four pattern criteria. Should be revised aggressively —
spending an hour on the opening line is justified.

The book opening also implicitly announces the project's
DNA: tone, voice, pace, the kind of story this will be.
Listen to what the opening line is telling you. If it
suggests a different story than the one you intended,
investigate before committing.

### Chapter opening (the first line of a chapter past Chapter 1)

Carries less weight than the book opening but still
significant. Should reward the reader who turned the page
from the previous chapter ending. Should NOT be
ostentatious — chapter openings work best when they propel
the reader into the chapter without making them stop and
admire the writing.

In medias res (mid-action) chapter openings work especially
well after a high-tension chapter ending. After a quiet
chapter ending, an opening that introduces a new question
or new threat re-engages forward motion.

### Scene opening within a chapter

Less critical than book or chapter openings. The four
patterns can still apply but a simpler functional open is
also acceptable. The constraint relaxes within a chapter
because the reader is already inside the chapter's
momentum.

## Per-scene self-check

Before submitting any opening (book, chapter, or scene):

1. Which pattern(s) does this opening line use?
2. Does it activate at least 2 of the 4 evaluation criteria
   (Emotional Tension / Personal Relevance / Temporal
   Complexity / Curiosity Generation)?
3. Is there an anti-pattern present that should be removed?
4. Does the opening match the project's tone and voice, or
   does it feel like a graft from a different style?
5. Would the reader turn the page from this line alone?

If 1 or 2 fails, revise. If 3 fails, cut the anti-pattern.
If 4 fails, the line is mismatched to the project. If 5
fails, the line is doing its first job poorly.

## Where this block is loaded

The `{opening_line_diagnostic}` slot in `prose-agent.md`
(fiction) and `content-writer.md` (non-fiction) pulls from this
file **conditionally** — only when the Architect's brief
indicates the scene being generated is a chapter or book
opening. The slot is filled with a one-line "not applicable"
stub when the scene is mid-chapter.

This conditional loading keeps the universal-craft prompt
content lean for the majority of scene generations while
ensuring opening moments — which carry outsized weight — get
the framework treatment.

When this file is updated, the change applies everywhere
opening lines are generated, regardless of genre. No parallel
updates to per-genre files required.
