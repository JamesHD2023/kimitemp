---
name: ideorix
description: "Ideorix — AI-powered manuscript generation engine. Say 'Write a book' to begin."
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *The Ideorix writing, editing, and publishing system is © 2025 James Harvey Media. All rights reserved.*


# Ideorix Engine — Core Skill

## Branding and Licence Display

Branding and licence verification are handled by SKILL.md on session
start. Do not duplicate them here. See SKILL.md "Branding Display Rule"
and "Licence Header" sections — SKILL.md is authoritative for all
user-visible session-start display.

## Genre Bank Location

> **Path:** `genres/`
>
> Genre files are organised by category under `genres/`:
> `genres/mystery-crime/`, `genres/romance/`, `genres/fantasy-scifi/`,
> `genres/literary-contemporary/`, `genres/horror-gothic/`, `genres/historical-adventure/`,
> `genres/ya-childrens/`, `genres/other/`.
> The genre index is at `genres/_index.md` and beat library at `genres/beat-library.md`.

## Mandatory Triggers

Activate this skill when the user mentions ANY of:
- "I want to write a book" (no genre specified — proceed to genre selection)
- "write a book"
- "write a [genre] novel/novella/short story/manuscript/book"
- "manuscript engine"
- "generate a [genre] manuscript"
- "write my [genre]"
- "[genre] author plugin"
- "write a short story"
- "test an idea" / "try out a concept"
- Any request to write a complete fiction manuscript or short story

If NO genre is specified, go straight to Question 1 (genre selection).
If a genre IS specified, confirm it and skip to Question 2.

## What This Produces

**Full Pipeline mode (default):**
1. **Complete manuscript** (.docx) — 5,000-120,000 words depending on length tier
2. **KDP metadata document** (.docx) — Amazon publishing info, keywords, cover prompt
3. **Story Bible** — Canonical reference document with all story elements
4. **Entity database** — Structured characters, locations, objects, canon rules
5. **Quality reports** — Scored verification and editorial reports per chapter

**Story Bible Only mode:**
1. **Writer's Companion** (.docx) — Complete creative brief for a human writer (see `writers-companion.md`)
2. **Story Bible** — Canonical reference document with all story elements
3. **Entity database** — Structured characters, locations, objects, canon rules
4. **Chapter outline** — Detailed per-chapter plan with beats, tropes, and emotional arcs
5. **Genre craft notes** — Key conventions, pitfalls, and pacing guidance
6. **Return instructions** — How to bring the finished manuscript back for editing

## Cross-Cutting Bindings (engine-wide)

This pipeline binds nine cross-cutting protocols. Every spec
in the engine MUST conform to these where applicable. The
canonical catalog is `silent-failure-audit.md`.

1. **Architect Mode** — when source canon is present (`byo-canon.md`)
2. **Verification Discipline** — when real-world anchors are present (`verification-discipline.md`)
3. **File-Write Hygiene** — every critical-path file write (this section + Sub-agent dispatch forbidden + Chained-Edit Truncation Safeguard + File-Freshness Post-Write Discipline)
4. **Edit-Tool Typographic Fidelity** — every Edit on user manuscripts (this file § Edit-Tool Typographic Fidelity)
5. **Read-Verification** — every Read of user-supplied source files (`read-verification.md`)
6. **Web-Content Verification** — every WebFetch / WebSearch (`web-content-verification.md`)
7. **Sub-agent Output Verification** — every evidence-bearing sub-agent dispatch (`subagent-output-verification.md`)
8. **Bash-Output Verification** — every Bash command whose output routes a decision (`bash-output-verification.md`)
9. **User Prompt Disambiguation** — every user question whose answer routes a decision (`ask-user-disambiguation.md`)

The discipline that catches new instances before they ship is
documented in CLAUDE.md § Silent-Failure Audit Discipline and
enforced by `scripts/spec-lint.sh` Check 10.

## File Operation Policy — Bash-Direct Write + Verify

**ALWAYS USE BASH FOR CRITICAL-PATH FILE WRITES.**

The bash-direct write protocol below is MANDATORY for all critical-path
files. Kimi's filesystem is reliable, but the bash protocol provides
verifiable, byte-count-confirmed persistence that tool-based writes
cannot guarantee. Root-level files (pipeline-checkpoint.md, market-pulse.md)
also benefit from bash verification.

**MANDATORY WRITE PROTOCOL — ALL critical-path files:**

Do NOT use the write tool or edit tool for any critical-path file.
Instead, use the bash side-file + mv-swap pattern:

```bash
# 1. Write content to a TEMPORARY file (new file — always works)
cat > /tmp/ideorix-write-{filename} << 'IDEORIX_EOF'
{file content here}
IDEORIX_EOF

# 2. Move the temporary file to the target path (replaces inode)
mv /tmp/ideorix-write-{filename} {target-path}/{filename}

# 3. Force filesystem sync (guarantees persistence to disk)
sync

# 4. Verify existence
ls -la {target-path}/{filename}

# 5. Verify byte count (catches zero-byte ghosts and truncation)
stat -c %s {target-path}/{filename}
wc -w {target-path}/{filename}
```

**Why this works:** Creating a new file via bash succeeds reliably.
The `mv` command replaces the file's identity (inode) at the target
path, bypassing any caching layer that might interfere with in-place writes. This pattern was proven working during Book 1's chapter recovery
(Ch 10, Ch 12, Ch 13 all restored successfully via this method).

**Why the write tool fails:** The write tool writes through a file-
system layer that caches the old file identity. For new files in
root-level directories, it works. For existing files or files in
subdirectories (engine-data/chapters/, engine-data/reports/, etc.),
the write reports success but the bytes don't reach the user's disk.
The read tool then shows a cached view that doesn't match reality.

**For chapter files, ALSO run the integrity check after mv:**

```bash
wc -w {path}/engine-data/chapters/ch{NN}.md && \
tail -n 5 {path}/engine-data/chapters/ch{NN}.md | grep -v '^\s*$' | tail -1 && \
grep -cP '\x00' {path}/engine-data/chapters/ch{NN}.md
```

This verifies: (1) word count is plausible (≥90% of brief target),
(2) last line ends with terminal punctuation (not mid-word), (3) no
null bytes. If any check fails, the write produced a truncated or
corrupt file. STOP — do NOT mark the checkpoint column as Yes.

**Chained-Edit Truncation Safeguard (read this carefully):**

The edit tool can truncate mid-word when the replacement text is
large (typically >2 KB per call) or when the file is large
(>15 KB) and the orchestrator is making multiple sequential Edit
calls on the same file. The signature is unambiguous: the file
ends in mid-word, mid-sentence, or mid-token (`workin`, `operating ou`,
`Iron-House-adjacen`). The orchestrator's Bash + Write verification
output reports success even though the file is corrupt.

This is a tool-layer behaviour at the file-edit infrastructure
level. It is not specific to any genre, project, or user prompt.
It is reproducible across sessions and not solved by restarting.

**Mitigations (apply in this order):**

1. **Prefer Write over chained Edit for chapter-scale rewrites.**
   When you are extending or revising a chapter and the change
   touches more than half the file, write the whole revised
   chapter once via the bash-heredoc + mv pattern rather than
   accumulating sequential Edit patches. A single Write rarely
   truncates; chained Edits on >15 KB files truncate frequently.

2. **Cap individual Edit replacements at ~2 KB.** If you must use
   Edit (because you're patching a known section of a large
   file), keep each Edit's `new_string` under approximately 2 KB.
   Split a 6 KB section rewrite into three 2 KB Edits rather than
   one 6 KB Edit.

3. **Run the integrity check after EVERY chapter-file Edit, not
   just at the end of the pipeline.** The chapter-file integrity
   check (`scripts/word-count-check.sh`) is mandatory at the major
   pipeline stages (post-Writer, post-Humaniser, post-fix). It is
   ALSO mandatory after any interactive / out-of-pipeline Edit
   that touches a chapter file. Truncation caught after one Edit
   is recoverable; truncation that propagates through five
   editorial stages may not be.

4. **For chained-Edit work that cannot be avoided, run the spot
   check between Edits:**
   ```bash
   tail -c 200 {path}/engine-data/chapters/ch{NN}.md
   ```
   If the last 200 characters end mid-word, the most recent Edit
   truncated. Discard, re-stage, and use Write or smaller Edits.

5. **Never declare a chapter complete on the basis of the Edit
   tool's success return.** The edit tool reports success even
   when the on-disk file is truncated. Verification is integrity
   check + word count, not tool-call return status.

The same safeguard applies to other large pipeline files
(entity-canon.md when the canon grows past ~10 KB; pipeline-
checkpoint.md once the chapter table is long; running-banlist.md
in the late stages of a long manuscript). When any
critical-path file is being edited and the file is over ~10 KB,
prefer Write over chained Edit and run the integrity check after
each modification.

**ALL verification reads use bash, not the read tool.** The read tool
may show a cached view that doesn't match disk. Use `cat`, `head`,
`tail`, `wc`, `grep` via bash for any verification check. The Read
tool is acceptable only for loading content into the prompt (Story
Bible, entity canon, summaries for the Architect) — never for
confirming a write succeeded.

**Critical-path files (bash-direct write + verify REQUIRED):**
`entity-canon.md`, `pipeline-checkpoint.md`, `running-banlist.md`,
`model-health.md`, `chapter-briefs/ch{NN}-brief.md`, `chapters/ch{NN}.md`,
`reports/ch{NN}-humaniser-notes.md`, `reports/ch{NN}-verification.md`,
`reports/ch{NN}-canon-validation.md`, `summaries/ch{NN}-summary.md`,
`revisions/ch{NN}-v{N}.md`

**Run log (MANDATORY — observability):**

After every critical-path Write + Bash `ls` verification (whether
successful or failed), append one line to `engine-data/run.log`:

```
{iso8601} | {phase} | {step} | {agent} | {verdict} | {artifact_path}
```

Example:
```
2026-04-22T19:35:12Z | Phase3 | step7 | writer | OK | engine-data/chapters/ch01.md
2026-04-22T19:36:08Z | Phase3 | step18 | checkpoint | OK | engine-data/pipeline-checkpoint.md
2026-04-22T19:38:44Z | Phase3 | step5a | oc-agent | FAIL | engine-data/reports/ch02-outline-conformance.md
```

Use bash-append:
```bash
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) | $PHASE | $STEP | $AGENT | $VERDICT | $PATH" >> {project_root}/{title}/engine-data/run.log
```

The run log is for debugging silent failures. When the user reports
"chapter X never appeared," the run log shows whether the Write was
attempted, whether `ls` saw the file, and what step it happened at.

**If bash ls shows "No such file" after mv:** The write failed. STOP.
Re-run the bash-direct write. Do NOT mark the checkpoint column as
Yes. Do NOT proceed to the next pipeline step. The file must be
confirmed on disk before the pipeline advances.

**Pipeline checkpoint** is the source of truth for "did step X
complete". Checkpoint columns are only set to Yes AFTER the Bash ls
check passes. Read the checkpoint once per chapter; don't re-read
individual files.

### Edit-Tool Typographic Fidelity (MANDATORY for any Edit on user manuscripts)

**Word DOCX files use typographic curly characters by default**:
U+2018 `'` and U+2019 `'` (single quotes); U+201C `"` and U+201D
`"` (double quotes); U+2013 `–` and U+2014 `—` (en/em-dashes);
U+2026 `…` (ellipsis). When Read returns a chapter file converted
from DOCX, these Unicode characters are preserved as their actual
code points — even though many editors and renderers display them
visually identical to their ASCII counterparts (`'`, `"`, `-`,
`--`, `...`).

The edit tool matches `old_string` byte-for-byte. If the source
file has `don't` (curly U+2019) and the agent constructs an Edit
with `old_string: "don't"` using ASCII U+0027, the Edit fails to
find the target. The change either silently drops, or — worse —
the agent retries with shell-escaping or string-escaping that
introduces new artifacts (`’`, `\'`, `'`) into the file
content.

This is a documented operational failure mode: it surfaced when a
user ran a tracked-changes editorial pass and reported that some
suggested changes had not been applied to their manuscript despite
the agent reporting success.

**Rules for any Edit on a user manuscript chapter file:**

1. **Read before Edit, every time.** Before constructing any
   Edit `old_string`, run Read on the same file to see the exact
   byte representation of the target passage. Copy bytes from
   the Read output into `old_string` — do NOT retype from visual
   memory.

2. **Preserve typographic style in `new_string`.** If the
   surrounding text uses curly quotes, the replacement uses
   curly quotes. If the source uses em-dashes, the replacement
   uses em-dashes. The agent MUST NOT silently normalize curly →
   straight (or vice versa) as a side effect of editorial fixes.

3. **If Edit fails to find an obviously-present target, suspect
   typographic mismatch.** Re-Read the file and inspect the bytes
   of the target passage. Common culprits:
   - Single quote: `'` (U+0027 ASCII) vs `'` (U+2019 curly)
   - Double quote: `"` (U+0022 ASCII) vs `"` `"` (U+201C/U+201D curly)
   - Apostrophe in contractions (don't / can't / it's): nearly
     always U+2019 in DOCX-sourced text
   - Dash: `-` (U+002D ASCII hyphen-minus) vs `–` (U+2013 en-dash)
     vs `—` (U+2014 em-dash)
   - Ellipsis: `...` (three ASCII dots) vs `…` (U+2026 single
     character)
   - Non-breaking space: ` ` (U+0020 normal) vs ` ` (U+00A0
     non-breaking) — particularly common in French-language
     prose and in date / number formatting

4. **For tracked-changes flows specifically**, the Typographic
   Fidelity binding in `tracked-changes.md` extends this rule to
   the change-record pipeline: byte-faithful capture at Phase A,
   byte-faithful change records at Phase B, profile verification
   at Phase C.

**This rule does NOT prohibit normalization** — if the user has
explicitly requested quote / dash / ellipsis normalization (e.g.,
"convert all straight quotes to curly throughout the manuscript"
or as part of a Heritage Text modernization pass), the engine
performs the requested operation as a deliberate, logged change.
The rule prohibits SILENT normalization as a side effect of
something else.

### File-Freshness Post-Write Discipline (v2.7.8 extension)

File-Write Hygiene verifies on-disk integrity AT WRITE TIME
(byte count, line count, word count, terminal-character check).
The discipline catches truncation and write tool failures the
moment they happen.

**Extension:** when a spec READS a file the engine wrote
earlier in the same session, the engine MUST verify the file
hasn't been modified externally (by the user, by a parallel
process, or by another agent) since the last engine write.
Without this check, an in-context value (e.g. a Story Bible
held in the agent's working memory) can diverge from the
on-disk version after the user edits the file mid-flow, and
subsequent writes overwrite the user's edits silently.

**Per-read discipline:**

1. The engine maintains a per-session ledger of files it has
   written, recording (file path, mtime at write, sha256 at
   write).
2. Before re-reading any of those files in the same session,
   run `stat -c %Y {path}` and compare to the recorded
   mtime. If different, the file was modified externally.
3. If modified externally, the engine MUST re-Read the file
   in full (do NOT trust in-context cached version) AND
   surface to the user before any subsequent write:

```
NOTICE — {file_path} was modified after I wrote it earlier in
this session.
  Engine-write mtime: {recorded_mtime}
  Current mtime:      {actual_mtime}

I'll re-read the file to capture your changes before
proceeding. If you'd rather I overwrite your changes with the
engine's working version, tell me explicitly.
```

4. Re-Read invokes Read-Verification (per-format threshold) to
   ensure the freshly-read content is real (not empty due to
   user mid-edit save).

**Flows where this discipline is critical:**

- Phase 5 editorial stages (already wired with per-stage file
  freshness check; this is the foundation of that pattern,
  generalized)
- Continue Writing / Continue Researching (re-loads existing
  project's prior chapter files; user may have hand-edited
  between sessions or even mid-session)
- Edit & Revise (returning user; user may have edited
  manuscript files since last engine touch)
- BYO-canon (user may add files to source-canon/ mid-flow)
- Tracked-Changes Phase A → C (source DOCX might be modified
  between Phase A capture and Phase C write)

**Anti-pattern this prevents:** engine writes Story Bible at
T=0; user manually edits bible at T=5; engine writes a chapter
brief at T=10 against its T=0 in-memory version; brief
contradicts the user's T=5 edits. The user catches it only
when reviewing the brief or a subsequent chapter.

### Sub-agent dispatch forbidden for file-writing steps

Sub-agents run in isolated contexts. Their write tool calls may not
propagate to the user's filesystem, causing silent persistence
failures. The sub-agent will narrate success ("I have saved the
chapter to..."), but the parent conversation sees no file on disk.

**The following pipeline steps MUST run in the parent conversation —
sub-agent dispatch is FORBIDDEN:**

- Step 5a: OC Agent's Write of the brief + audit footer
- Step 7: Writer's Write of the initial chapter draft
- Step 10: Prose Humaniser's Write of the cleaned chapter + notes
- Step 11: Prose Craft Improver's Write (when run)
- Step 12: Verification's Write of the consolidated 6-agent report
- Step 13: Chapter summary Write
- Step 13b: Character-state snapshot Write
- Step 14: Pre-save revision snapshot Write
- Step 18: Pipeline checkpoint update Write
- Phase 2D: Entity canon Write
- Phase 2E: Pipeline checkpoint + running banlist starter Writes

Sub-agents MAY be used for pure reasoning (text analysis, conformance
checks on in-memory content) but NOT for any step that ends in a
Write to disk. If a sub-agent returns claiming to have written files,
the parent conversation MUST re-do the Writes in the parent context
using the bash-direct protocol and verify with Bash `ls -la`.

## Graceful Degradation for Pre-Hardening Projects

This policy covers three project states:

- **New project** (starting fresh) → **MODERN MODE — all new features active**
- **Existing project with modern schema** (pipeline-checkpoint.md present with
  the new columns) → **MODERN MODE — all new features active**
- **Existing project with legacy schema** (chapters on disk, no
  pipeline-checkpoint.md, or progress-dashboard.md instead) → **LEGACY
  MODE — only after explicit user confirmation**

### The rule

1. **DEFAULT to MODERN MODE.** Every project is modern unless clearly proven
   otherwise. Missing state files on a new project are NOT evidence of
   legacy — they're an instruction to INITIALIZE.

2. **Only engage LEGACY MODE when ALL THREE of these are true:**
   - `engine-data/pipeline-checkpoint.md` is missing OR has the old schema
     (no `OC Report` / `OC Verdict` / `Banlist Loaded` / `Canon Loaded` /
     `Canon Check` columns)
   - Actual chapter files exist under `engine-data/chapters/` (i.e., this
     is a resumed project, not a new one)
   - The user explicitly confirms by prompting the user: *"This project was
     started under an older Ideorix version. Continue in legacy-compatibility
     mode (no mid-run migration) or run the migration tool to upgrade it to
     the modern schema?"*

   Without ALL THREE, default to MODERN MODE and initialize missing files.

3. **Never silently degrade a new project to legacy.** Missing
   `entity-canon.md` on a project with zero chapters means "not created yet"
   — run Phase 2D to create it. It does NOT mean "legacy project."

### Decision tree (authoritative)

```
IF engine-data/chapters/ directory exists AND contains ch{NN}.md files:
    # Project has existing chapters — could be resumed modern or legacy
    IF engine-data/pipeline-checkpoint.md exists:
        IF checkpoint has the new columns (OC Report, OC Verdict, etc.):
            mode = MODERN
        ELSE:
            # Old schema checkpoint
            ASK user: "Upgrade schema to modern, or continue legacy?"
            mode = user choice
    ELSE:
        # Chapters but no checkpoint — legacy project
        ASK user: "This looks like a pre-hardening project. Continue in
                  legacy mode, or run migration to modernize?"
        mode = user choice
ELSE:
    # No chapters — new project
    mode = MODERN
    # Initialize all new-schema files during Phase 2
```

### MODERN MODE requirements (what the pipeline MUST do)

In MODERN MODE, the pipeline MUST produce and maintain these files:

| File | Created at | Contents |
|---|---|---|
| `engine-data/pipeline-checkpoint.md` | Phase 2E (before the Approval Gate) | New-schema checkpoint with all columns, schema header, header-row-only tables (see Pipeline Checkpoint section) |
| `engine-data/entity-canon.md` | Phase 2D (after Entity Extraction) | Flat name lookup generated from Story Bible characters/locations/objects |
| `engine-data/running-banlist.md` | Phase 2E (before the Approval Gate) | Empty starter with HARD CONSTRAINTS / WATCHLIST / RETIRED sections, header tables with no rows |
| `engine-data/reports/ch{NN}-outline-conformance.md` | Step 5a of each chapter | OC Agent audit (or embedded as IDEORIX:AUDIT footer in brief file) |
| `engine-data/reports/ch{NN}-humaniser-notes.md` | Post-Humaniser step 10 of each chapter | Humaniser detection report + change summary (see `prose-humaniser.md` Output section) |
| `engine-data/reports/ch{NN}-verification.md` | Step 12 of each chapter | Consolidated 6-agent verification report |
| `engine-data/reports/ch{NN}-canon-validation.md` | Step 18 of each chapter (post-checkpoint) | Canon Validator report — content claims vs Bible aggregate tables |

**If any of these files is missing DURING a run on a new or modern project,
STOP and create it rather than degrading to legacy mode.**

### LEGACY MODE requirements (only after explicit user confirmation)

In LEGACY MODE, skip the new-feature steps:
1. Skip Phase 2D (Entity Canon Lockfile generation)
2. Skip Running Banlist initialization
3. Skip step 5a (OC Agent) during chapter generation
4. Skip Canon Compliance Check in Continuity Guardian / Source Guardian
5. Skip Writer Pre-Load steps 6a A (banlist) and 6a B (canon) — use empty placeholders
6. Preserve the project's existing dashboard schema (`progress-dashboard.md`
   stays; don't start a competing `pipeline-checkpoint.md`)

The File Operation Policy (Trust the write tool) still applies regardless
of mode. Legacy mode is a compatibility layer for old projects, not a
feature-limited tier for new ones.

## Writing Style Directive

Write **"Section N"** in full, not `Section N`. Applies to all generated output.

## File Location Discipline (MANDATORY)

Every file the pipeline produces has ONE canonical location. Inventing
new locations, subfolders, or intermediate artefacts is a protocol
violation. Users lose trust and waste tokens when the engine-data root
fills with unrecognised files.

### Canonical directory structure

**Standalone project:**

```
Ideorix-Projects/[Title]/
├── manuscript/              ← User-facing final deliverables (.docx, .epub, etc.)
├── marketing/               ← Cover concepts, blurbs, social-media assets
└── engine-data/             ← Internal engine state
    ├── story-bible.md
    ├── entities.md
    ├── entity-canon.md
    ├── chekhovs-guns.md
    ├── trope-plan.md
    ├── pipeline-checkpoint.md
    ├── running-banlist.md
    ├── humaniser-tracker.md
    ├── model-health.md         ← Model behaviour telemetry (see Model Health Monitor)
    ├── market-pulse.md
    ├── outline.md
    ├── project-config.md
    ├── project-mode.md        (Story Bible Only projects only)
    ├── tension-tracker.md     ← Pacing slider history (plan vs actual)
    ├── beat-structure.md      ← Selected beat structure + delivery log
    ├── style-guide.md         ← Style guide (if built from uploads)
    ├── character-states/      ← Per-chapter character emotional/knowledge state
    │   └── ch{NN}-state.md
    ├── chapters/              ← Final chapter prose, ONE file per chapter
    │   └── ch{NN}.md
    ├── chapter-briefs/        ← Architect briefs (with IDEORIX:AUDIT footer)
    │   └── ch{NN}-brief.md
    ├── summaries/             ← 3-5 sentence continuity summaries
    │   └── ch{NN}-summary.md
    ├── reports/               ← All per-chapter verification + humaniser reports
    │   ├── ch{NN}-outline-conformance.md     (FAIL overflow only — rare)
    │   ├── ch{NN}-humaniser-notes.md
    │   ├── ch{NN}-verification.md
    │   ├── ch{NN}-preview-report.md          (on-demand only)
    │   ├── ch{NN}-oc-detail.md                (FAIL overflow only)
    │   ├── batch-{N}-edit.md
    │   ├── batch-{N}-health-report.md
    │   └── batch-{N}-preview-report.md
    └── revisions/             ← Automatic pre-save snapshots
        └── ch{NN}-v{N}.md
```

**Series project (see `series-architect.md` for full spec):**

```
Ideorix-Projects/[Series Title]/
├── series-data/                     ← Series-level (shared across all books)
│   ├── series-bible.md
│   ├── series-guns.md
│   └── series-plan.docx
├── [Book 1 Title]/                  ← Full standard per-book structure
│   ├── engine-data/
│   │   ├── story-bible.md
│   │   ├── chapters/
│   │   └── ... (all standard files)
│   ├── manuscript/
│   └── marketing/
├── [Book 2 Title]/                  ← Created when user starts Book 2
│   ├── engine-data/
│   ├── manuscript/
│   └── marketing/
└── ...
```

`series-data/` is DISTINCT from `engine-data/` — series-level files
live in `series-data/`, book-level files live in each book's
`engine-data/`. A folder named `engine-data/` always belongs to a
specific book; `series-data/` always belongs to the series. Book
folders are created as-needed, not pre-populated.

### File rules

**ONLY write files to paths shown in the directory tree above.** Do not
invent new filenames or locations. Intermediate work (concept seeds,
character drafts, outline fragments) stays in memory — only canonical
output files get written to disk.

- Chapter filenames: exactly `ch{NN}.md` (two digits, no title/stage suffix).
  **NEVER append `-draft`, `-final`, `-humanised`, `-v2`, or any other
  suffix.** The filename is always `ch01.md`, `ch02.md`, etc. A chapter
  file named `ch01-draft.md` is a hard error — rename it to `ch01.md`
  immediately. Users look for `ch01.md`; a `-draft` suffix hides the file.
- One chapter file per chapter: Writer writes → Humaniser overwrites at same path
- **Chapter prose goes to `engine-data/chapters/ch{NN}.md` — NEVER to
  `manuscript/` or `manuscript/chapters/`.** The `manuscript/` folder is
  for user-facing deliverables (`.docx` files) generated at Phase 6
  Delivery. Raw chapter `.md` files are engine-internal and belong under
  `engine-data/chapters/`. If `engine-data/chapters/` does not exist when
  the Writer runs, create it. Do NOT write chapter prose to `manuscript/`,
  `manuscript/chapters/`, or the `engine-data/` root.
- Reports go under `reports/`, never at engine-data root
- Checkpoint columns: use the exact header names shown below (see Pipeline Checkpoint). Do not rename columns.

**Before every Write:** confirm the path matches the directory tree.
If it doesn't, correct the path — don't invent a new location.

## Core Architecture

This engine uses a **multi-agent pipeline** mirroring production manuscript generation:

```
Full Pipeline:       Setup → Story Bible → [Architect → Writer → Verification] × N chapters → Editorial → Delivery
Story Bible Only:    Setup → Story Bible → Writer's Companion → Delivery → [User writes] → Return → Editorial
```

### Agent Roster

**Generation Agents:**
- Architect — Plans chapter structure (brief-as-contract)
- Writer — Executes brief into prose
- Prose Humaniser — Strips AI-generated patterns from Writer output (post-Writer)
- Prose Craft Improver — Two-step line editing: analyse → apply surgical fixes (uses `surgical-fixes.md` + `line-editor.md`, optional)

**Verification Agents (run after each chapter):**
- Continuity Guardian — Character/information consistency
- Quality Guardian — Prose quality + genre fit scoring
- Timeline Keeper — Temporal logic + event sequencing
- Character Tracker — Behavior consistency + voice differentiation
- Arc Analyst — Structure + beat delivery + tension progression
- Dialogue Guardian — Voice differentiation, subtext, reveal vs explain, interruption patterns
- Canon Validator — Checkpoint-to-Bible content claim validation (runs at step 4b pre-brief AND step 18 post-chapter; see `canon-validator.md`)
- Series Continuity Guardian — Cross-volume consistency (multi-volume projects only; see `quality-gate.md`)

**Editorial Agents (run on full manuscript):**
- Proofreader — Grammar, spelling, style
- Copy Editor — Line-level prose quality
- Dev Editor — Structural assessment
- Alpha Reader — First-impression experience
- Beta Reader — Genre-savvy assessment

**Support Protocols (referenced during generation):**
- Authenticity Guard — Universal AI name/pattern avoidance (see `authenticity-guard.md`)
- Surgical Fixes — Two-step revision protocol (see `surgical-fixes.md`)
- Revision Loop — Automated iterative refinement: reader diagnostics → surgical fixes → re-validation → repeat until convergence (see `revision-loop.md`)

**Utility Skills (on demand):**
- Heritage Text Refiner — Modernizes public domain source texts: archaic spelling updates, OCR repair, Chicago style formatting (see `heritage-text-refiner.md`)

**Post-Manuscript Publishing Studio (on demand):**
- Cover Designer — Market-researched cover concepts with AI image prompts (see `cover-designer.md`)
- Marketing Expert — Blurbs, Amazon descriptions, social media packs, query letters, audience analysis, keywords (see `marketing-expert.md`)
- Video Trailer Designer — Scene-by-scene trailer storyboards with AI video prompts for Sora, Runway, Pika, Luma, Kling (see `video-trailer-designer.md`)

### Instruction Hierarchy (NEVER violate this order)

```
1. CONTINUITY (highest) — Never contradict established facts
2. KNOWLEDGE STATE — Characters only know what they've learned on-page
3. AUTHOR DIRECTIVES — User's explicit instructions and style guide
4. GENRE RULES — Genre-specific conventions from genre bank
5. CRAFT STANDARDS — Universal prose quality rules (lowest)
```

When rules conflict, higher-numbered rules yield to lower-numbered rules.

## Complete Workflow

### PHASE 0: SERIES ARCHITECTURE (Optional — if multi-volume)

Before individual book setup, determine if this is a series project.

**Trigger:** When the user mentions writing a series, planning multiple books,
or selects "Book 1" or "Book 2-5" in Question 7, offer the Series Architect.

**How it works:**
1. Read `series-architect.md` for the full 8-step series planning protocol
2. Read `series-conventions.md` for genre-specific series rules
3. Complete the Series Architect workflow (Steps 1–8)
4. **Create the master series folder structure:**
   ```
   Ideorix-Projects/[Series Title]/
   ├── series-data/                ← Series-level (shared across all books)
   │   ├── series-bible.md
   │   ├── series-guns.md          (if long-range guns exist)
   │   └── series-plan.docx
   └── [Book 1 Title]/             ← First volume (created when user starts it)
       ├── engine-data/
       ├── manuscript/
       └── marketing/
   ```
   Save the Series Bible to `Ideorix-Projects/[Series Title]/series-data/series-bible.md`
5. When complete, the user selects which volume to write first
6. Create that volume's book folder inside the series master folder
7. Phase 1 inherits: genre, series position, spine question, thematic throughline,
   volume blueprint (as outline source), and character trajectories

**Individual book folders are created AS NEEDED** — only the volume
the user is currently writing gets its folder. Book 2 and 3 folders
are created when the user begins those volumes. This avoids empty
placeholder folders cluttering the series folder.

**Path pattern for series books:**
`Ideorix-Projects/[Series Title]/[Book Title]/engine-data/...`

All per-book pipeline paths (chapters/, reports/, summaries/, etc.)
work identically to standalone — just with the extra `[Series Title]/`
parent directory. See `series-architect.md` for the full folder spec.

**If the user says "standalone" or skips series planning:** Proceed
directly to Phase 1. The project folder is created at
`Ideorix-Projects/[Book Title]/` (no series parent).

**If extending an existing series:** The Series Architect's Mode B
reads uploaded books, extracts continuity, and plans forward volumes
before handing off to Phase 1. The existing series master folder is
reused.

---

### PHASE 1: INTERACTIVE SETUP

### PHASE 1 COMPLIANCE RULES (READ BEFORE PROCEEDING — MANDATORY)

Phase 1 consists of EXACTLY 14 questions, defined below (Q1 through Q14). You MUST:

1. Ask these exact questions in this exact order (Q1 → Q2 → Q3 → ... → Q14)
2. Prompt the user for each one — not free-text messages that can be ignored
3. NOT invent, add, merge, reorder, or substitute any questions
4. NOT ask character, plot, concept, antagonist, or theme questions during setup
   (those belong ONLY in the Outline Builder, triggered by Q9)
5. NOT treat Phase 1 as a creative brainstorming session — it is a structured
   configuration phase that collects 14 specific parameters
6. Complete ALL 14 questions before ANY generation begins (Story Bible, chapters, etc.)
7. NOT skip a question because the genre "doesn't need it" — every question has a
   valid default answer (e.g., Q2: "American English", Q3: "No", Q4: "N/A", Q5: "Skip tropes", Q12: "Decide later", Q13: genre default, Q14: "Full Pipeline")

**Questions you must NEVER ask in Phase 1** (they belong elsewhere):
- "What's your concept/idea?" → Outline Builder (triggered by Q9)
- "Tell me about your protagonist" → Outline Builder (triggered by Q9)
- "Who is the antagonist?" → Outline Builder (triggered by Q9)
- "What's the tone?" → Derived from genre file + style guide, not a setup question
- "What are your themes?" → Derived from trope selection + genre, not a setup question
- "Anything else?" / "Any other preferences?" → Not a pipeline question. Q14 is
  specifically Project Mode, not a catch-all

---

### PHASE 1 CONTINUATION-BOOK CROSS-CHECK (MANDATORY, BLOCKING, HARD GATE — Book N where N > 1)

**THIS IS A HARD GATE — NOT A SUGGESTION:**

When setting up a continuation book (Book 2, 3, etc. in an existing series),
Phase 1 answers MUST be validated against the Series Architecture BEFORE the
Setup Completion table is shown to the user. This prevents synthesis drift
— the same class of error that caused the Canon Validator incident, now
applied to the setup phase.

- You MAY NOT display the Phase 1 Summary table until the cross-check
  has actually run and every field carries a source citation.
- You MAY NOT present Phase 1 answers to the user without citations.
- You MAY NOT proceed to Phase 2 until synthesis items are approved.
- "The answers look correct, I'll skip the formal check" is a PROTOCOL
  VIOLATION regardless of how clean the answers appear. Run the check.
  Every continuation book. Every time.
- Skipping this step is the SINGLE most common way that series drift
  enters the Story Bible — a Phase 1 answer that was synthesised rather
  than extracted becomes canonical, and every downstream agent treats it
  as architecture.

**Trigger:** This section applies when Q7 = "Book 2-5 (continuation)" AND
`series-data/series-architecture.md` (or `series-data/series-bible.md`)
exists from a prior Phase 0 run.

**Execution procedure (follow in order):**

1. After all 14 Phase 1 questions are answered but BEFORE the Summary
   table is assembled, read `series-data/series-architecture.md` (or
   `series-data/series-bible.md`) in full.
2. For EACH of the 14 Phase 1 answers, search the architecture for a
   matching specification for this book number.
3. Classify each answer as one of:
   - `[locked — architecture Section N line N]` — architecture specifies this
     value exactly; the Phase 1 answer must match verbatim
   - `[carry-forward from Book N-1 — architecture Section N]` — unresolved
     element from the prior book; non-negotiable inclusion
   - `[new — synthesis from Section N, needs user approval]` — architecture
     is silent; this answer was inferred from adjacent material
   - `[standalone — no architecture constraint]` — this field has no
     series-level specification (e.g., pen name, style guide)
4. If ANY answer is classified `[locked]` but doesn't match the
   architecture value: STOP. Correct the answer to match before
   proceeding.
5. Assemble the Summary table WITH the SOURCE column (see below).
6. Only THEN display the table to the user.

**Rules:**

1. **Extraction is mandatory where architecture speaks.** For every Phase 1
   answer, check whether the Series Architecture specifies a value for this
   book. If it does, the Phase 1 answer MUST match the architecture. Present
   the answer with a source citation:
   `[locked — architecture Section N line N]`

2. **Synthesis requires labelling.** Where the architecture is silent or
   adjacent (e.g., tropes not specified per-book, terminology lock characters
   not explicitly listed), synthesis from nearby material is permitted but
   MUST be labelled:
   `[new — synthesis from Section N, needs user approval]`
   The user sees exactly which answers are locked by architecture and which
   are proposed inferences.

3. **Category merges are forbidden.** If the architecture separates concepts
   into distinct categories (e.g., Chekhov's Guns, Real Clues, and Red
   Herrings as three separate lists per book), Phase 1 MUST NOT collapse
   them into a single field. Each architectural category stays separate.
   Q11 (Chekhov's Guns) presents the architecture's per-book gun list
   as the locked baseline; new guns proposed by the engine are labelled
   `[new — synthesis]`.

4. **Carry-forward items are non-negotiable.** The architecture specifies
   carry-forward elements per book (unresolved guns, active arc weave
   threads, character trajectory positions). These are automatically
   included — they are not optional Phase 1 choices. Present them as:
   `[carry-forward from Book N-1 — architecture Section N]`

5. **Cross-check before display.** Before the Phase 1 Summary table is
   shown to the user, run a mechanical diff: for every field in the table,
   confirm either (a) a source citation exists, or (b) the field is
   labelled as synthesis. Any answer without a citation or label is a
   potential drift — STOP and add the citation before presenting.

**Phase 1 Summary table for continuation books:**

The standard table gains a SOURCE column:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SETUP COMPLETE — Phase 1 Summary (Book {N})
  ARCHITECTURE CROSS-CHECK: {PASS / N items need approval}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Q1  Genre:            {genre}                [locked — arch Section 2]
  Q2  Dialect:          {dialect}              [locked — arch Section 1]
  Q3  Romance subplot:  {yes/no}               [locked — arch Section 9]
  Q5  Tropes:           {count}                [new — synthesis Section 8]
  Q7  Series position:  Book {N}               [locked — arch Section 1]
  Q11 Chekhov's Guns:   {count}                [locked — arch Section 10]
       Carry-forward:   {list}                 [carry-forward — arch Section 10]
       New this book:   {list}                 [new — synthesis Section 10]
  ...

  Locked items: {N}
  Carry-forward items: {N}
  Synthesis items (need approval): {N}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**If the cross-check finds synthesis items:** Prompt the user to
present each synthesis item for explicit approval. The user must approve,
reject, or modify each one. Unapproved synthesis items CANNOT enter the
Story Bible. Do NOT use a text message that can be ignored — use the
interactive tool so the pipeline physically cannot proceed without a
response for each synthesis item.

---

Ask these questions ONE AT A TIME by prompting the user. Wait for each response.

**Question 1: Genre**
Read `genres/_index.md` to show available genres.

**Pre-step — Detect user custom genres:**
Before showing the category list, check for user-authored custom genres in
these two locations:

1. **Project-local:** `~/Documents/Ideorix-Projects/{current_project_title}/engine-data/custom-genres/*.md` (if a project context exists)
2. **Persistent library:** `~/Documents/Ideorix-Projects/.genre-library/*.md`

For each custom genre file found, read the `display_name` from its metadata
frontmatter. If any exist, add a "Your custom genres" section at the top of
the category list, showing each custom genre as selectable by its display
name. A custom genre selected here becomes the Primary genre directly and
skips to Step 3 (mash-up offer).

**Step 1 — Show categories:**
Present the top-level categories as a numbered list:
1. Mystery & Crime
2. Romance
3. Fantasy & Sci-Fi
4. Literary & Contemporary
5. Horror & Gothic
6. Historical & Adventure
7. YA & Children's
8. Describe your idea — tell me what you want to write and I'll find the best genre match
9. Build a custom genre — design your own from scratch or inherit from existing genres

**If the user selects option 9 (Build a custom genre):**
Run the Custom Genre Builder agent. See `genre-builder.md` for the full
protocol. When the builder completes, it returns a saved custom genre file
and offers to register it as the Primary. If the user accepts, the custom
genre becomes the Primary and Question 1 continues at Step 3 (mash-up offer).
If the user declines, return to Step 1 (category list) so they can pick a
different genre.

**If the user selects option 8 (describe your idea):**
Ask the user to describe their book concept in their own words — a sentence, a paragraph,
a vibe, a comparable title, or anything that captures what they want to write.

Then:
1. Read `genres/_index.md` to scan all available genres and their descriptions
2. Identify the 2-3 best-matching genres based on the user's description
3. For each match, explain WHY it fits and show key features from the genre file
4. Present the matches as options and let the user choose
5. If none of the matches feel right, offer to browse all categories manually

Example flow:
```
User: "I want to write about a mum who discovers the food industry is poisoning
her kid and takes on a pharmaceutical company"

Engine: Based on your concept, here are the best genre matches:

1. Domestic Thriller — Everyday danger in domestic settings. Investigation through
   household discovery, corporate antagonists as systemic threat, slow-burn tension
   through ordinary life turned sinister. (Best match)

2. Thriller — Broader thriller conventions with investigation, institutional
   antagonists, and escalating stakes. Less domestic texture, more pace.

3. Legal Thriller — If the story focuses on the legal/regulatory battle against
   the company. Courtroom and procedural elements.

Which feels closest to what you have in mind?
```

This option exists because showing only category headings can make users think
those are the only choices. "Describe your idea" invites users who don't think
in genre terms to participate naturally.

**Step 2 — Show genres within the selected category:**
After the user picks a category, show ONLY genres with status "Ready" from `_index.md`.
Mark any "Planned" genres as "(Coming Soon)" so the user knows they exist but can't
select them yet.

Example for Romance:
```
Available Romance genres:
  1. Contemporary Romance
  2. Historical Romance
  3. Dark Romance
  4. Gothic Romance
  5. Horror Romance
  6. Romantic Comedy
  7. Romantic Suspense
  8. Romantic Thriller
  9. Sport Romance
  10. Western Romance
  11. Paranormal Romance
```

**If the user picks a "Planned" genre:** Explain it's not available yet, suggest the
closest Ready alternative, and offer to proceed with that or pick a different genre.

**If the user already specified a genre in their initial request** (e.g., "write a
cozy mystery"): Confirm the genre and skip to **Step 3 (Mash-Up offer)**.

**Step 3 — Offer a genre mash-up (optional):**

After the primary genre is confirmed, ask the user whether they want to
mash it up with another genre:

```
Your Primary genre: {genre display name}

Want to mash this with another genre? You can blend up to 3 genres total —
we'll stack their rules, craft techniques, crutch-phrase bans, and quality
checks into one active rulebook, with {genre display name} as the dominant
influence.

Examples:
  • Cozy Mystery + Fantasy → cosy whodunit with magical elements
  • Domestic Thriller + Gothic → modern domestic dread with haunted atmosphere
  • Cyberpunk + Western → neon frontier outlaw story
  • Literary + Horror → slow-burn literary dread

Options:
  1. No thanks — just {primary} (recommended for first-time users)
  2. Add ONE more genre (create a 2-genre mash-up)
  3. Add TWO more genres (create a 3-genre mash-up)
```

Prompt the user to present these three options.

**If the user picks option 1:** Single-genre mode. Skip to Question 2.

**If the user picks option 2 or 3:** Run the **Mash-Up Sub-Flow** below, then skip to Question 2.

---

**Mash-Up Sub-Flow (activates when the user selects 2 or 3 genres):**

**Step M1 — Pick the Secondary genre:**

Show the same category list as Step 1, except exclude the Primary's category
heading from the default (it can still be chosen — the user might want two
genres from the same family, e.g. thriller + crime). Also offer the same
"Describe your idea" helper as Step 1.

Once the user picks a Secondary genre, validate it:

1. **Refuse if Secondary == Primary.** Ask for a different choice.

2. **Curated Hybrid Check:** Look up the Inheritance Map in `_index.md`.
   If a curated hybrid exists whose parent list matches the user's
   Primary + Secondary combination, STOP and present it as an
   alternative:

   ```
   You picked {Primary} + {Secondary}. There's already a curated hybrid
   for this combination: {Hybrid Name} ({hybrid-file}.md). Its rules
   have been hand-tuned for how {Primary} and {Secondary} interact —
   it will produce stronger prose than an ad-hoc mash-up.

   Options:
     1. Use {Hybrid Name} instead (recommended)
     2. Continue with ad-hoc {Primary} + {Secondary} mash-up anyway
   ```

   Prompt the user. If the user picks option 1, switch the Primary
   to the curated hybrid, clear the mash-up state, and skip to Question 2.

3. **If no curated hybrid matches:** Accept the Secondary and continue.

**Step M2 — Pick the Tertiary genre (only if user chose "Add TWO more"):**

Show the category list again. Same rules as Step M1 — refuse duplicates
(Tertiary cannot equal Primary or Secondary). Curated hybrid detection:
if {Primary, Secondary, Tertiary} collectively match a curated hybrid's
parents, offer it.

**Step M3 — Confirm the mash-up and check for obvious conflicts:**

Display the final active genre list:

```
Active genre stack for this project:

  Primary:    {Primary display name}
  Secondary:  {Secondary display name}
  Tertiary:   {Tertiary display name or "—"}

Primary wins on rule conflicts. Quality checks and crutch-phrase bans
from all genres apply. Word count defaults come from {Primary}.
```

Run a quick conflict scan by reading the `## Quality Check Criteria`
and `## Genre-Specific Revision Rules` sections of each loaded genre
file. Look for obvious contradictions:

- A genre that REQUIRES gore/violence paired with a genre that FORBIDS it
- A genre that REQUIRES romantic resolution paired with a genre that
  REQUIRES bleak ending
- A genre that REQUIRES fast pacing (thriller) paired with a genre that
  REQUIRES slow, atmospheric pacing (literary, gothic)
- A genre that REQUIRES third-person limited paired with a genre that
  REQUIRES first-person

If any contradictions are found, present them to the user:

```
⚠ Conflict detected between {Genre A} and {Genre B}:

  {Genre A}: {specific rule}
  {Genre B}: {conflicting specific rule}

Primary ({Primary}) wins by default, so {Primary's rule} will apply.
But this may dilute {the losing genre}'s reader expectations.

Options:
  1. Continue — Primary's rule wins, I accept the trade-off
  2. Swap Primary — make {losing genre} the new Primary instead
  3. Drop {losing genre} from the mash-up
```

Resolve all conflicts before proceeding. Write the final mash-up
state to `engine-data/project-config.md`:

```markdown
Genre: {primary-id} + {secondary-id}[ + {tertiary-id}]
Mash-up: yes
  Primary: {Primary display name}
  Secondary: {Secondary display name}
  Tertiary: {Tertiary display name or "none"}
```

Then proceed to Question 2.

**Question 2: English Dialect** *(MANDATORY — "American English" is the default)*
- American English (US spelling, vocabulary, and conventions)
- British English (UK spelling, vocabulary, and conventions)

> This locks the dialect for the entire project. Every downstream agent — Writer,
> Proofreader, Copy Editor, Line Editor, Batch Editor, Prose Humaniser — enforces
> this dialect consistently. The Proofreader will flag dialect violations (e.g.,
> "fall" in a British English manuscript, "boot" for car trunk in an American
> English manuscript). Character dialogue may use any dialect for authenticity,
> but all narration must match the selected dialect.
>
> **Canadian/Australian writers:** Select the closest parent dialect (American or
> British respectively) and note specific preferences in your Style Guide (Q8).
>
> **Genre-aware suggestion:** After the user selects a genre, suggest the most
> common dialect for that genre's primary market. For example, if the genre is
> Cozy Mystery and the setting is likely British, suggest British English. If the
> user already specified a setting or locale in their initial request (e.g., "a
> thriller set in New York"), suggest the matching dialect. The user always has
> the final choice.

**Question 3: Romance Subplot?** *(MANDATORY — do not skip)*
- Yes (slow-burn romance woven through plot)
- No (pure genre focus)

> This question is mandatory even for genres that seem incompatible with romance.
> "No" is a valid answer. The engine needs the explicit selection to configure later phases.

**Question 4: Heat Level** *(MANDATORY if Q3=yes OR genre is romance; skip ONLY if Q3=no AND genre is non-romance)*
- Sweet/Clean (no explicit content)
- Mild Spice (some sensuality, closed door)
- Open Door (explicit scenes — if genre supports it)

**Question 5: Trope Selection** *(MANDATORY — see `trope-library.md` for full reference)*

> Do NOT substitute this with plot, character, or theme questions. Trope selection
> happens HERE. "Skip tropes" is a valid answer. Do NOT ask about concept, protagonist,
> or antagonist — those belong in the Outline Builder (Q9).

This step shapes the thematic DNA of the story. Tropes are loaded from `trope-library.md`.

**Step 1 — Offer a starting approach:**
- Pick a Starter Bundle (pre-built trope combos for common subgenres)
- Browse by category (explore all 10 trope categories)
- Skip tropes (freeform — no trope constraints)

**Step 2 — If Starter Bundle selected:**
Filter bundles to show only those relevant to the selected genre and heat level.
Present matching bundles with their trope lists. User picks one.
Then offer: "Want to customise this bundle? You can add or remove tropes."

**Step 3 — If Browse by Category (or customising a bundle):**
Show the 10 trope categories one at a time:
1. Relationship Dynamics
2. Character Archetypes
3. Situations & Settings
4. Emotional & Thematic
5. Fantasy & Paranormal (only if genre is fantasy/paranormal/sci-fi)
6. Spice & Intimacy (filter by heat level — hide `dark` tropes unless heat = dark)
7. Historical & Period (only if genre is historical)
8. Thriller & Suspense (only if genre is thriller/suspense)
9. Sci-Fi & Futuristic (only if genre is sci-fi)
10. Multi-Partner (only if heat level = steamy+ or above)

For each relevant category, show tropes as a selectable list. User picks from each.

**Step 4 — Pairing suggestions:**
After selection, check `pairs` data. If the user selected a trope that pairs well with
an unselected trope, suggest it: "You picked Enemies to Lovers — this pairs great with
Forced Proximity and Only One Bed. Want to add either?"

**Step 5 — Confirm final trope list:**
Display selected tropes (3–7 recommended). Confirm before proceeding.

**Trope filtering rules:**
- Hide tropes tagged with genres that don't match the selected genre (unless tagged `all`)
- Hide `steamy+` tropes if heat level is Sweet/Clean or Mild Spice
- Hide `dark` tropes unless heat level explicitly supports dark content
- Always show `all` genre / `all` heat tropes

**Question 6: Length Tier**

Present all five options by prompting the user in ascending length order. Include the
recommendation reasoning for the Novella option as its description so the user can
make an informed choice:

1. **Short Story (~8,000 words, 5 chapters, ~1,600 words/chapter)**
   - Perfect for testing an idea before committing to a full novel. Write a
     self-contained story that explores your concept, characters, and genre — then
     decide if you want to expand it. The engine runs the full quality pipeline
     (verification agents, humaniser, craft standards) even on short stories, so you
     get a polished, publication-ready piece regardless of whether you expand later.
2. **Novelette (~12,500 words, 9 chapters, ~1,400 words/chapter)**
   - A middle ground between a short story and a novella — long enough to build
     real characters and a complete arc, short enough to finish in a few sittings.
     Ideal for genre magazines, anthologies, Kindle Vella, serialised fiction, and
     readers who prefer shorter reads. **Genre fit note:** Novelettes work best
     for cozy mystery, romance, literary, horror, noir, and contemporary genres.
     They are NOT well-suited to epic fantasy, space opera, historical epic, family
     saga, or any genre that needs extensive worldbuilding or a large cast — those
     need novella length or longer to breathe properly. If you're writing one of
     those genres, pick Novella or higher.
3. **Novella (~40,000 words, 16 chapters, ~2,500 words/chapter) (Recommended)**
   - Best balance of depth and completion time — long enough for full character arcs,
     subplots, and satisfying resolutions, but short enough to maintain consistent
     quality across the entire manuscript. Novellas also have strong market demand
     in digital-first publishing (Kindle, Kobo) where readers want complete, polished
     stories they can finish in a few sittings. If this is your first Ideorix project,
     start here — you'll see the engine's full capability without the commitment of
     a 75K+ word marathon.
4. **Standard Novel (~75,000 words, 30 chapters, ~2,500 words/chapter)**
5. **Epic Novel (~120,000 words, 40 chapters, ~3,000 words/chapter)**

> **Short Story mode:** When the user selects Short Story, the engine runs the full
> pipeline (Story Bible, Architect, Writer, Verification, Editorial) but scaled for
> 5 chapters. The Story Bible is lighter (core characters, single setting, one plot
> thread). Beat structures are simplified to a 5-act micro-structure: Hook (Ch 1),
> Escalation (Ch 2), Midpoint Turn (Ch 3), Crisis (Ch 4), Resolution (Ch 5). Tropes
> are limited to 1-3. Chekhov's Guns are limited to 0-1. The Outline Builder produces
> a 5-chapter outline. Series Position (Question 7) is skipped — short stories are
> always standalone.
>
> **Short Story Expansion Prompt:** After the Short Story's editorial pipeline
> (Phase 5) completes, calculate the manuscript's average verification score across
> all 5 chapters. If the average score is **≥85**, present the following expansion
> offer by prompting the user:
>
> ---
> **Your short story scored {avg_score}/100 — that's strong enough to build on.**
>
> Your concept, characters, and world held up well under the engine's quality checks.
> Stories that score this high often have the foundation for something longer. Would
> you like to expand this into a full manuscript?
>
> Options:
> 1. **Expand to Novelette (~12,500 words)** — The smallest expansion. The engine
>    adds 4 chapters to your 5 and lightly extends the existing ones, keeping the
>    tight focus of your short story while giving it a fuller arc. Best for cozy
>    mystery, romance, literary, horror, noir, and contemporary — not suited to
>    epic fantasy or any genre needing heavy worldbuilding.
> 2. **Expand to Novella (~40,000 words)** — Use this short story as the seed.
>    The engine will extend your Story Bible, build a full outline around your
>    existing chapters, and generate the remaining chapters.
> 3. **Expand to Standard Novel (~75,000 words)** — Same as above, but with more
>    room for subplots, deeper character development, and a fuller world.
> 4. **Expand to Epic Novel (~120,000 words)** — Go big. Your concept supports it.
> 5. **Keep as Short Story** — Deliver the finished short story as-is.
> ---
>
> If the user chooses to expand:
> - Retain the existing Story Bible, entities, and chapter summaries as the foundation
> - Re-run Phase 1 Questions 4 (tropes), 9 (beat structure), and 10 (Chekhov's Guns)
>   with the expanded tier's limits (the short story limits were restrictive)
> - Run the Outline Builder to extend the existing 5-chapter outline into a full
>   outline for the chosen length tier, using the short story chapters as the opening
> - The existing 5 chapters become the first 5 chapters of the expanded manuscript
>   (the engine may revise them during the editorial pass to fit the longer arc)
> - Resume normal pipeline from Chapter 6 onward
>
> If the average score is **<85**, skip the expansion prompt and proceed directly
> to delivery. The user can always manually request expansion later.

**Question 7: Series Position** *(skipped if Short Story was selected)*
- Standalone
- Book 1 (series starter) → If Phase 0 was NOT already run, offer the Series Architect now
- Book 2-5 (continuation) → If Phase 0 was NOT already run, offer the Series Architect now
- Not sure yet (write as potential standalone with series hooks)

> **Series Architect integration:** If the user selects Book 1 or Book 2-5 and hasn't
> already completed Phase 0, ask: "Would you like to plan the full series architecture
> first? This maps out all volumes, character trajectories, and the series spine before
> we dive into this book." If yes, run Phase 0 (see `series-architect.md`). If no,
> continue with standard setup.

**Question 8: Style Guide** *(MANDATORY — "Use genre defaults" is a valid answer)*
- Upload previous manuscripts for voice matching
- Describe your preferred style
- Use genre defaults

If manuscripts uploaded, build Style Guide capturing:
Voice & Tone, Dialogue Patterns, Pacing Style, Description Style,
POV Handling, Chapter Structure, Comfort/Tension Balance.

**Question 9: Outline Source** *(MANDATORY — this is where character/plot/concept work begins)*
- I have an outline (user provides) → see User Outline Pacing Audit below
- Generate one for me (AI creates a full outline from genre conventions) → Triggers the Outline Builder
- Guided outline build (interactive step-by-step — you make choices at each stage) → Triggers the Outline Builder
- Help me develop a concept (start from a vague idea and brainstorm together) → Triggers the Outline Builder

> **CRITICAL:** The Outline Builder (triggered by this question) is the ONLY place
> where concept, protagonist, antagonist, and plot questions are asked. Do NOT ask
> these questions earlier in the setup phase. If you have already asked them before
> reaching Q9, you have violated the pipeline — go back and follow the correct order.

> **HARD GATE — BLOCKING — applies BEFORE Q9 advances when source material is present:**
>
> If ANY of the following conditions is true, **Outline Builder Step 0 (Source
> Material Absorption) MUST run FIRST** — before Q9 advances, before any concept /
> protagonist / antagonist / plot work begins, before any outline scaffolding is
> proposed:
>
> 1. A `source-canon/` subfolder exists in the project folder
>    (`~/Documents/Ideorix-Projects/[Title]/source-canon/`)
> 2. The user has uploaded or pasted worldbuilding documents in this conversation
> 3. The user has uploaded or pasted character profiles or character sheets
> 4. The user has provided a voice guide or sample scenes
> 5. The user has an existing outline, synopsis, or plot summary
> 6. The user has mentioned "I have notes", "I've already built the world", "use
>    my worldbuilding", "I have my characters", "bring my own canon", or any
>    equivalent phrasing
> 7. The user invoked the BYO-canon entry point (see `byo-canon.md`)
>
> **DETECTION IS MECHANICAL, NOT DISCRETIONARY.** Run the following Bash check
> before advancing Q9:
>
> ```bash
> ls -la ~/Documents/Ideorix-Projects/{Title}/source-canon/ 2>/dev/null
> ```
>
> If the folder exists with files, OR if the conversation contains user-supplied
> source material (uploaded files, pasted profiles, referenced documents), Step 0
> is structurally required. The agent MUST NOT advance Q9 until Step 0 has been
> loaded from `outline-builder.md`, executed in full, and produced a confirmed
> canon-constraints checklist. The Q9 selections "Generate / Guided / Help
> develop" THEN apply on top of the locked constraints — they do not bypass
> Step 0.
>
> **After Step 0 completes and user confirms constraints, the Source Canon
> Grounding Gate MUST run before any outline generation begins.** See
> `source-canon-grounding.md` for the full protocol. The orchestrator produces
> `engine-data/reports/source-canon-grounding.yaml` containing sha256 hashes and
> verbatim samples from each source file. The deterministic gate verifies that
> the orchestrator is grounded in current file content, not stale memory. If the
> gate fails, the orchestrator must re-read all source files and regenerate the
> artifact before proceeding.
>
> **This gate exists because of a documented production failure mode:** agents
> drafted before absorbing user canon, leaned on sample scenes as plot
> tentpoles, flattened user-defined characters to easier-to-write versions,
> projected unstated psychology onto user-defined characters, summarised
> threats instead of dramatising, and produced "greatest hits albums of canon
> moments with summary connecting them" outlines that the user could not use.
> Step 0 makes those failures structurally impossible — but ONLY if it
> actually fires. This HARD GATE makes firing mandatory. The Source Canon
> Grounding Gate ensures the orchestrator is actually using the file content
> when generating, not stale memory from an earlier read.

> **Outline Builder:** If the user selects "Generate one for me," "Guided outline build,"
> or "Help me develop a concept," load `outline-builder.md` and run the full Outline
> Builder protocol. **If the user has uploaded or provided any source material**
> (per the HARD GATE above), **Step 0 (Source Material Absorption) runs FIRST** —
> the engine reads every file in full, extracts canon constraints, presents them
> for user confirmation, and locks them as hard rails before any outline generation
> begins. This prevents the engine from skimming or ignoring user-provided
> material. See `outline-builder.md` Step 0 for the full protocol and
> `byo-canon.md` for the dedicated entry point.
> This is a multi-step interactive process (source absorption, market pulse research,
> concept seeds, character design, world-building, genre architecture, and detailed
> chapter outline). The Outline Builder handles Steps 0–13 of the outline process.
> - **"Generate one for me"** — Present complete outputs at each step; user approves or tweaks.
> - **"Guided outline build"** — Present choices and options at each step; user picks and the engine builds from their selections.
> - **"Help me develop a concept"** — Start with open-ended brainstorming; collaborate to shape the concept before building the outline.
> When the Outline Builder completes, resume Phase 1 with Question 10 (Beat Structure).

**User Outline Pacing Audit (when user selects "I have an outline"):**

If the user provides their own outline AND the genre is
thriller/suspense/domestic-thriller/psychological-thriller/espionage/
legal-thriller, run a quick tension audit before accepting it:

1. Does Chapter 1 establish a visible threat or wrongness by its end?
2. Does the outline show escalation across Act 1 (not flat setup)?
3. Is there a ticking clock, deadline, or escalating pressure mechanism?
4. Are there more than 2 consecutive low-tension chapters anywhere?

If any check fails, flag it to the user with a specific suggestion:
*"Your outline establishes the protagonist's world in Ch 1-2 but
doesn't introduce a threat until Ch 3. Thriller readers expect to be
hooked by page 3. Suggest: move the inciting threat into Ch 1 and
use Ch 2 for the first escalation. Approve as-is or revise?"*

Do NOT silently accept a low-tension outline for a thriller genre.
The user chose thriller — the outline must deliver thriller pacing.
If the user approves despite the warning, proceed but log the
override so the Architect knows to compensate.

**Question 10: Beat Structure** (see `beat-structures.md` for full protocol)
Read `genres/beat-library.md` and present genre-recommended beat structures:
- [Recommended structures for the selected genre] (show 2-3 options with beat counts)
- [Secondary/alternative structures] (show 1-2 options)
- No beat structure (freeform — the Architect plans freely)
- Custom (user describes their preferred structure)

If a beat structure is selected, save it to `Ideorix-Projects/[Title]/engine-data/beat-structure.md`
with the full beat list mapped to target chapters.

**Question 11: Chekhov's Guns** (see `chekhovs-guns.md` for full protocol)
Present ALL FOUR options as individually selectable choices — do not omit, merge, or
group any of them:
1. None — No planted-and-paid-off elements (simpler narrative)
2. One (1) — A single significant planted element
3. A Few (3) — Three planted elements across the narrative
4. Several (5) — Five planted elements for a richly layered story

**Question 12: Pen Name** *(MANDATORY — "Decide later" is a valid answer)*

See `pen-name-generator.md` for the full protocol.

Check if `~/Documents/Ideorix-Projects/.pen-names/index.md` exists.

**If existing pen names are found:**
1. Select an existing pen name (show the saved list)
2. Create a new pen name (run the pen name generation protocol)
3. Use my real name (skip pen name assignment)
4. Decide later (skip for now — can assign before export)

**If no existing pen names are found:**
1. Create a pen name (run the pen name generation protocol)
2. Use my real name (skip pen name assignment)
3. Decide later (skip for now — can assign before export)

When a pen name is selected or created, record it in the project metadata. The pen
name will be used in all generated marketing materials, KDP metadata, and DOCX author
fields. The pen name profile's usage history is updated automatically.

**Question 13: Transportive Setting** *(MANDATORY — genre default is a valid answer)*

See `transportive-settings.md` for the full protocol and all setting archetypes.

Present the genre-recommended settings first (from the genre-recommendations table in
`transportive-settings.md`), then the full list:

```
Recommended for {genre}:
  ★ {primary recommendation} — {one-line description}
  ☆ {secondary option 1} — {one-line description}
  ☆ {secondary option 2} — {one-line description}

All settings:
  1.  Fog-Wrapped Coastal Town — Isolation, secrets, salt air, crumbling cliffs
  2.  Neon-Lit Metropolis — Urban energy, anonymity, nightlife, surveillance
  3.  Sun-Baked Rural Heartland — Wide horizons, community, slow time, harvest cycles
  4.  Snow-Bound Isolation — Claustrophobia, survival, beauty, silence
  5.  Tropical Paradise (Dark Underbelly) — Lush beauty masking danger, colonial echoes
  6.  Ancient City Layers — History underfoot, narrow streets, hidden spaces
  7.  Industrial Decline — Rust belt, abandoned spaces, resilience, class tension
  8.  Enchanted Wilderness — Deep forest, magical realism, nature as character
  9.  High Society Estate — Wealth, secrets, staff hierarchies, manicured surfaces
  10. War-Torn Landscape — Destruction, displacement, unexpected beauty, survival
  11. Suburban Uncanny — Surface normality, something wrong underneath
  12. Underground / Subterranean — Hidden world, descent as metaphor, claustrophobia
  13. Custom — Describe your own setting atmosphere

  Or: Use genre default (engine selects the primary recommendation automatically)
```

When the user selects a setting, load the full setting archetype from
`transportive-settings.md` and record it in the project metadata. The setting's
sensory palette and atmosphere rules will be injected into Architect and Writer
agent prompts for the entire manuscript.

**Question 14: Project Mode** *(MANDATORY — "Full Pipeline" is the default)*

This question determines how the project runs after the Story Bible is generated.

Present by prompting the user:

```
How would you like to work on this book?

1. Full Pipeline — Chapter by Chapter (Recommended for first project)
   Ideorix writes the manuscript — you approve each chapter brief and
   prose draft, with full verification and editorial passes. The engine
   pauses for your approval at every step.

2. Full Pipeline — Supervised Autopilot
   The engine runs automatically through the full pipeline without
   pausing for approval at each chapter. It ONLY stops when:
   • A verification score falls below 80
   • A word count hard miss occurs
   • A CRITICAL violation is detected (frame leaks, narration em dashes)
   • Every 5th chapter (batch edit checkpoint)
   You review output at these natural breakpoints instead of every chapter.
   Best for experienced users who trust the pipeline.

3. Story Bible Only — I'll write it myself
   Ideorix builds the complete creative skeleton: Story Bible, character
   profiles, chapter outline, beat structure, trope plan, and genre craft
   notes. You receive a comprehensive Writer's Companion document — a
   professional brief you can follow to write the book yourself, in your
   own voice, at your own pace.

   When you've finished writing, bring your manuscript back to this
   project. Ideorix will validate it against your Story Bible, reconcile
   any creative changes you made, and run the full editorial pipeline
   (proofreader, copy editor, dev editor, line editor, alpha reader,
   beta reader) — with the advantage of already knowing your story
   intimately.
```

> **Why this question exists:** Many writers want professional-quality story
> architecture but want the prose to be entirely their own. Story Bible Only
> mode gives them the structural thinking of the full pipeline — genre-aware
> outlining, beat mapping, character design, market research — without the
> AI writing a single word of their novel. The return flow then provides
> editorial services that are more accurate than a cold edit because the
> engine already has the Story Bible, entity database, and timeline.

Record the selection in project metadata as `project_mode: full_pipeline`,
`project_mode: supervised_autopilot`, or `project_mode: story_bible_only`.

### SUPERVISED AUTOPILOT BEHAVIOUR

When `project_mode: supervised_autopilot` is selected:

**Runs automatically (no pause for approval):**
- Architect generates chapter brief → proceeds directly to Writer
- Writer generates prose → proceeds to Humaniser
- Humaniser → proceeds to verification
- Verification passes (all scores ≥80) → updates checkpoint → proceeds to next chapter

**Pauses for user review (BLOCKING):**
- Any verification agent scores below 80
- Word count hard miss (below 90% of internal target)
- Any CRITICAL violation (fictional-frame leaks, em dashes in narration)
- Every 5th chapter batch edit → present Batch Health Report

**Context refresh at every batch edit checkpoint (ALL modes):**
Re-read SKILL.md, craft-standards.md, and forbidden-words.md from disk
to reload rules that may have been compressed out of context.

**Restart recommendation at every batch edit (ALL modes):**
Display a tip suggesting the user restart Kimi for optimal
performance on the next batch. Progress is saved to disk.

### SETUP COMPLETION GATE (MANDATORY — BLOCKING)

Before proceeding to Phase 2, output the following checklist to the conversation.
Every item must show a value and ✓. If ANY question was skipped, go back and ask it.
The pipeline CANNOT proceed to Phase 2 with incomplete setup data.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  SETUP COMPLETE — Phase 1 Summary
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Q1  Genre:            {genre_name}                    ✓
  Q2  Dialect:          {American English / British English} ✓
  Q3  Romance subplot:  {yes/no}                        ✓
  Q4  Heat level:       {level or N/A}                  ✓
  Q5  Tropes:           {count selected or 0}           ✓
  Q6  Length:            {tier + word count}             ✓
  Q7  Series position:  {standalone/book N}             ✓
  Q8  Style guide:      {source or defaults}            ✓
  Q9  Outline:          {source type}                   ✓
  Q10 Beat structure:   {name or freeform}              ✓
  Q11 Chekhov's Guns:   {count: 0/1/3/5}               ✓
  Q12 Pen name:         {name or real name or later}    ✓
  Q13 Setting:          {setting name or genre default} ✓
  Q14 Project mode:     {Full Pipeline / Story Bible Only} ✓

  All 14 questions answered: YES / NO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**If "All 14 questions answered" is NO:** STOP. Identify which questions were missed
and go back to ask them. Do NOT proceed to Phase 2.

**If YES and mode is Full Pipeline:** Display "Proceeding to Phase 2: Story Bible Generation" and continue.

**If YES and mode is Story Bible Only:** Display "Proceeding to Phase 2: Story Bible Generation → Writer's Companion" and continue.

---

### PHASE 2: STORY BIBLE GENERATION

**VERIFICATION DISCIPLINE BINDING (MANDATORY for projects
that anchor to real-world facts):**

Phase 2 builds the Story Bible. When the project's genre /
setting / premise anchors to real-world specifics
(historical fiction, biographical fiction, contemporary
fiction with real-event references, period crime / war /
espionage / political thriller projects, named-real-person
cameos, real-organisation references, real-location
geography), the verification discipline in
`verification-discipline.md` applies to those anchor
facts. The same three-class labeling (VERIFIED /
SPECULATIVE / REJECTED) and Phase A WebSearch verification
runs on every committed real-world specific in the bible:
historical events, real persons named in the manuscript,
real institutions, real legislation, real dates, real
places. The discipline does NOT apply to invented
characters, invented organisations, or invented worlds —
those are the author's prerogative. It applies to the
real-world anchor layer that historical and contemporary
fiction commits to.

Output: `engine-data/verification-ledger.md` with a row
per real-world anchor specific. Stage 9 (Full-Manuscript
Continuity Audit) re-verifies at audit time.

For pure invented-world projects (epic fantasy, secondary-
world science fiction, fully-invented contemporary
settings), the verification discipline is a no-op — the
ledger is empty by design. The discipline is therefore
context-aware rather than universal in fiction.

**SOURCE CANON GROUNDING BINDING (MANDATORY for BYO-canon projects):**

If this project has `source-canon/` files (worldbuilding, character
profiles, voice guides, sample scenes — see `byo-canon.md`), the
Source Canon Grounding Gate MUST run BEFORE Story Bible generation
begins. See `source-canon-grounding.md` for the full protocol.

The orchestrator produces `engine-data/reports/source-canon-grounding.yaml`
containing per-file sha256 hashes and verbatim samples. The
deterministic gate verifies: sha256 matches current files, samples are
actual substrings, minimum counts met. If the gate fails, the
orchestrator must re-read all source-canon files and regenerate the
artifact before proceeding.

This prevents the documented failure mode where the orchestrator
reads canon files early in a session, retains vague surface knowledge,
and then generates Story Bible content from stale memory rather than
from the actual current file content. The gate is opt-in controlled
via `source_canon_grounding` in `project-config.md`:
- `enabled` — gate runs (default for new BYO-canon projects)
- `disabled` — gate skips
- `legacy` — gate skips, diagnostic: "pre-v2.8.0 project, opt-out honored"

Non-BYO-canon projects (no source-canon files) are unaffected. The gate
skips by default when no source-canon files exist.

**SERIES PROJECTS — PER-BOOK STORY BIBLE IS MANDATORY:**

If this project is part of a series (Phase 0 completed, Series Bible
exists in `series-data/series-bible.md`), Phase 2 STILL runs in full
for each individual book. The Series Bible and the per-book Story Bible
are DIFFERENT documents that serve different purposes:

- **Series Bible** (Phase 0, `series-data/series-bible.md`): Cross-
  volume architecture — spine question, character trajectories across
  books, arc weave matrix, long-range Chekhov's Guns, thematic
  throughline. Shared across all books in the series.

- **Per-book Story Bible** (Phase 2, `engine-data/story-bible.md`):
  THIS BOOK's detailed canon — characters as they appear in THIS
  volume (with book-specific detail: exact backstory revealed this
  book, current emotional state, relationship states at this book's
  start), locations in detail (room plans, geography), props and
  clue schedules, chapter-by-chapter timeline with specific dates,
  voice profile narrowed to this book's POV characters, cross-book
  seeds planted in this volume.

The Series Bible is the WHY (where the series is going). The per-book
Story Bible is the WHAT (exactly what happens in this specific book,
at what level of detail the Architect and Writer need to execute it).

**You CANNOT skip Phase 2 because Phase 0 already ran.** The engine
jumping from Series Bible → outline → chapter briefs is a protocol
violation. A volume blueprint from Phase 0 is a 1-2 page summary;
a Story Bible is a 30-80 page detailed canon with character profiles,
location descriptions, props, timeline, voice samples, and clue
schedules. They are not interchangeable.

**The per-book Story Bible INHERITS from the Series Bible:**
- Series-level character arcs → expanded into this-book character detail
- Series-level world rules → expanded into this-book location specifics
- Series-level themes → narrowed to this-book thematic focus
- Cross-book seeds → tracked in this-book's plant/payoff schedule
- Series voice conventions → narrowed to this-book's POV voice profile

Phase 2 runs its full protocol (2A Foundation → 2B Plot → 2C Entity
Extraction → 2D Entity Canon → 2E Pipeline State) with the Series
Bible loaded as additional context. The per-book Story Bible is then
the canonical reference for all downstream agents (Architect, Writer,
Verification) — not the Series Bible directly.

#### SCREENPLAY ADAPTATION BRANCH — SHORT-CIRCUITS PHASE 1 AND PART OF PHASE 2

If the user entered via **Screenplay → Novel** (see `screenplay-import.md`)
and `project-config.md` contains `source: screenplay`, most of Phase 1
and Phase 2 are handled by the screenplay importer instead of the
normal pipeline:

1. The importer routes to the correct parser based on file extension
   (`.fountain`, `.fdx`, `.docx`, or `.pdf`). PDFs run a text-layer
   probe first; scanned PDFs are rejected with a clean re-export
   message (see `screenplay-importer.md` PDF parser section).
2. The importer parses the screenplay and produces a normalised
   scene list, character roster, and location bank regardless of
   input format.
3. The importer seeds the Story Bible (Sections 1, 4, 7, 12, 14) from
   the parsed data.
4. The importer generates `engine-data/entity-canon.md` automatically
   from the character and location rosters.
5. The importer preserves the full parsed data at
   `engine-data/screenplay-source.md` and the scene-to-chapter mapping
   at `engine-data/scene-to-chapter-map.md`.
6. The importer asks a reduced Phase 1 question set:
   - **Length tier** (Short Story / Novelette / Novella / Standard
     Novel / Epic Novel) with calculated expansion ratios and
     out-of-range warnings per tier
   - **POV mode** (Single / Dual / Multi) and POV character selection
     from the ranked character roster
   - **POV assignment mode** for Dual/Multi (alternating / scene-driven
     / user-assigned)
   - Genre (best-guess + user confirm), dialect, voice profile(s),
     pen name, dialogue handling policy
7. The user reviews the seeded Story Bible at a user-review gate,
   fills in any gaps the screenplay didn't cover (tone, themes, voice
   contrast per POV character for multi-POV, etc.).
8. The pipeline hands off to Phase 3 (Chapter Generation) with the
   mode flag `adaptation_mode: screenplay_adaptation` and all the
   additional config fields (length_tier, pov_type, pov_characters,
   pov_assignment_mode, dialogue_handling, expansion_ratio,
   expansion_mode). See `screenplay-importer.md` Hand-off section.

**Market Scout still runs** — it's not skipped, because positioning
matters even for adaptations. Market Scout runs after the Story Bible
review, before Phase 3 begins. The report informs tropes, voice, and
market-positioning decisions in a way that doesn't override the
screenplay's locked plot.

**Phase 3 adaptation mode:** The Architect and Writer load
`screenplay-expansion.md` and apply its expansion-aware rules
throughout chapter generation. The Outline Conformance Agent treats
the screenplay scenes mapped to the current chapter as the canonical
outline. Every plot beat is locked to the source; the Writer expands
interiority, sensory environment, dialogue craft, and subtext within
that lock.

**Phase 4, 5, 6 run normally.** No adaptation-specific modifications
for verification, editorial, or delivery — once the chapters are
written, they're just chapters.

#### MARKET SCOUT — MANDATORY PRE-PHASE 2 STEP

**Before generating the Story Bible, ALWAYS run Market Scout** — regardless of
how the outline was sourced (user-provided, AI-generated, or guided build).

If the Outline Builder already ran Market Scout during Step 2, skip this step
(the report already exists at `engine-data/market-pulse.md`).

If Market Scout has NOT yet run (i.e., the user provided their own outline at Q9,
or chose "basic story outline", or pasted an outline), run it NOW:

1. Load `market-scout.md` (or `market-scout-protocol.md`)
2. Run Market Scout with context: **"setup"** and the selected genre
3. Save the report to `engine-data/market-pulse.md`
4. Present the key findings (trending tropes, reader expectations, market gaps)
   to the user before Story Bible generation begins
5. The Market Scout report feeds into the Story Bible to ensure the manuscript
   is positioned competitively from the start

**Why this is mandatory:** Market Scout provides the competitive landscape that
shapes trope integration, reader expectation alignment, and strategic positioning
in the Story Bible. Without it, the manuscript is built blind to market conditions.
In testing, choosing "basic story outline" bypassed Market Scout entirely, producing
a Story Bible with no market awareness. This step ensures every project — regardless
of outline source — benefits from live market intelligence.

See `world-canon.md` for the complete 3-phase protocol.

During Phase 2B (Plot & Story Elements):
- **Trope integration:** Embed selected tropes as thematic pillars in the Story Bible.
  For each selected trope, define: how it manifests in the plot, key delivery beats
  (setup → escalation → payoff), and which characters carry it.
- **Trope plan extraction:** After trope integration, generate a standalone
  `trope-plan.md` file containing:
  - Each selected trope with its delivery schedule (which chapters set up,
    escalate, and pay off each trope)
  - Trope interaction map (how tropes reinforce or create tension with each other)
  - Per-chapter trope targets (which tropes each chapter should advance)
  This file is consumed by the Architect in Phase 3 when planning each chapter.
- **Chekhov's Guns:** If selected, generate the specified number of guns with
  introduction and payoff chapters (see `chekhovs-guns.md`).
- Save guns to `Ideorix-Projects/[Title]/engine-data/chekhovs-guns.md`
- Save trope plan to `Ideorix-Projects/[Title]/engine-data/trope-plan.md`

Output: `Ideorix-Projects/[Title]/engine-data/story-bible.md` + `Ideorix-Projects/[Title]/engine-data/entities.md`
+ `Ideorix-Projects/[Title]/engine-data/chekhovs-guns.md` (if guns selected)
+ `Ideorix-Projects/[Title]/engine-data/trope-plan.md` (if tropes selected)

#### PHASE 2D: ENTITY CANON LOCKFILE (MANDATORY, BLOCKING)

After Phase 2C (Entity Extraction) completes and BEFORE the Story Bible
Approval Gate, generate the Entity Canon Lockfile. This step is
**mandatory for every new project**. It is not optional, not conditional
on mode, and not skippable. Skipping it breaks the Writer's pre-load
(step 6a Step B), the Continuity Guardian's Canon Compliance Check
(step 12), and produces the "Canon Loaded = No" / "Canon Check = blocked"
failure mode observed in testing.

**Execution:**

1. Load `world-canon.md` and run the Phase 2D — Entity Canon Lockfile
   protocol in full. The protocol specifies the file format, the population
   rules for Characters / Locations / Objects / Organisations, and the
   canonical-name rules.
2. Build the entity canon rows from the Story Bible (characters), the
   Entities database (locations, objects, organisations), and any
   additional canon rules collected during Phase 1.
3. Write the completed lockfile to:
   `Ideorix-Projects/[Title]/engine-data/entity-canon.md`
4. **Verify the write with Bash ls (MANDATORY):**
   ```bash
   ls -la {project-path}/engine-data/entity-canon.md
   ```
   If ls returns "No such file or directory", the write tool was not
   invoked. STOP. Re-run the Write in the parent conversation (not a
   sub-agent) and re-verify with Bash ls. Do NOT proceed to step 5 until
   Bash ls confirms the file on disk.
5. Update the pipeline checkpoint's Canon-Loaded-ready state so Chapter 1
   can pass the pre-flight check.

**You MAY NOT proceed to the Story Bible Approval Gate (and the user
MAY NOT be asked to approve the Bible) until entity-canon.md has been
successfully written.** Present the Entity Canon Lockfile to the user
alongside the Story Bible at the Approval Gate so the user reviews the
canonical names, aliases, and short forms in a single pass.

Output: `Ideorix-Projects/[Title]/engine-data/entity-canon.md`

#### PHASE 2E: PIPELINE STATE INITIALIZATION (MANDATORY, BLOCKING)

After Phase 2D (Entity Canon Lockfile) completes and BEFORE the Story Bible
Approval Gate, initialize the two infrastructure files that every modern-mode
chapter requires. This step is **mandatory for every new project**. It is not
optional, not conditional on mode, and not skippable. Skipping it means the
first chapter cycle has no source-of-truth checkpoint to write to and no
banlist file for the Writer Pre-Load step 6a Step A to read.

**Execution:**

1. **Create the Pipeline Checkpoint file** at
   `Ideorix-Projects/[Title]/engine-data/pipeline-checkpoint.md` using the
   full v2-schema template (see "Pipeline Checkpoint" section below).
   Populate with:
   - Schema header: `<!-- schema: ideorix-checkpoint v2 -->`
   - Pipeline Status: Phase = Phase 2 complete, Current chapter = 0, Mode =
     per-chapter verification
   - Chapter Progress table: column headers only, no data rows yet
   - Word Count Tracker: column headers only
   - Batch Edit Status: column headers only
   - Number-7 Bias Tracker: initial zero state
   - Flags: empty
   - Next Action: "Awaiting Story Bible Approval Gate; then write Chapter 1"

2. **Create the Running Banlist starter file** at
   `Ideorix-Projects/[Title]/engine-data/running-banlist.md`. This is a
   one-time initialization — the Humaniser updates it after every chapter
   (see `prose-humaniser.md` step 5 of the post-chapter banlist update
   protocol). The starter must contain:
   - A short preface explaining what the file is
   - `## HARD CONSTRAINTS` — empty list (no patterns promoted yet; starter
     header only)
   - `## WATCHLIST` — empty list
   - `## RETIRED` — empty list

3. **Verify both writes with Bash ls (MANDATORY):**
   ```bash
   ls -la {project-path}/engine-data/pipeline-checkpoint.md
   ls -la {project-path}/engine-data/running-banlist.md
   ```
   If either Bash ls returns "No such file or directory", the write tool
   was not invoked for that file. STOP. Re-run the Write in the parent
   conversation (not a sub-agent) and re-verify. Do NOT proceed to step 4
   until Bash ls confirms BOTH files on disk.

4. **Forbidden root-file scan (MANDATORY):**
   ```bash
   ls {project-path}/engine-data/
   ```
   Inspect the output for any of the following FORBIDDEN filenames
   (see File Location Discipline above for the full list):
   - `antagonist.md`, `protagonist.md`, `supporting-cast.md`
   - `world-setting.md`, `genre-architecture.md`
   - `concept-seeds.md`, `hook-positioning.md`
   - `chapter-outline.md`, `ending.md`, `tension-tracker.md`
   - Any `ch{NN}-*.md` file at engine-data root (must live under
     `chapters/` or `reports/`)

   If any forbidden file is found, STOP and alert the user. Do NOT
   silently delete — the user decides whether the content should be
   consolidated into the canonical file (usually `outline.md`) or
   removed. Forbidden root files mean the Outline Builder or a
   downstream agent ignored File Location Discipline; surface it
   rather than hide it.

5. Update the in-memory pipeline state so the Story Bible Approval Gate (and
   subsequently Phase 3) can reference both files.

**You MAY NOT proceed to the Story Bible Approval Gate until both files
have been successfully written.**

**Running Banlist starter format:**

```markdown
# Running Banlist — {Title}
<!-- Updated by the Prose Humaniser after every chapter. Read by the
     Content Writer pre-load (step 6a Step A). -->
Last updated: Phase 2 (starter — no chapters written yet)

This file records Writer-Humaniser feedback across the manuscript.
Patterns that recur in two or more chapters are promoted to HARD
CONSTRAINTS, which become opening-prompt hard bans for the Writer.
Patterns in WATCHLIST are advisory. Patterns in RETIRED were once
HARD but have been clean for 5 consecutive chapters.

## HARD CONSTRAINTS

(No entries yet — patterns will be promoted from the Humaniser's
chapter reports starting at Chapter 2.)

| Pattern | First flagged | Chapters where flagged | Promotion trigger |
|---------|---------------|-----------------------|-------------------|

## WATCHLIST

(No entries yet.)

| Pattern | First flagged | Chapters where flagged | Promoted if |
|---------|---------------|-----------------------|-------------|

## RETIRED

(No entries yet.)

| Pattern | First flagged | Last flagged | Clean chapters since |
|---------|---------------|--------------|---------------------|
```

Output: `Ideorix-Projects/[Title]/engine-data/pipeline-checkpoint.md` + `Ideorix-Projects/[Title]/engine-data/running-banlist.md`

#### PHASE 2F: STORY BIBLE CONFORMANCE CHECK (MANDATORY, BLOCKING)

After Phase 2E and BEFORE the Story Bible Approval Gate, run the
traceability pass defined in `world-canon.md` Phase 2 Content
Discipline. This is the Phase 2 equivalent of the OC Agent — it
catches contradictions and unauthorized inventions before the user
sees the Story Bible.

**Execution:**

1. **Run the traceability pass** on the draft Story Bible. Classify
   every element as CITATION / EXPANSION / INVENTION / CONTRADICTION
   per the rules in `world-canon.md`.

2. **For series projects** (where `series-data/series-bible.md`
   exists): additionally check every Story Bible element against
   the Series Bible's character trajectories, Arc Weave Matrix,
   cross-book seed inventory, and long-range Chekhov's Guns. A
   Book 1 Story Bible that references Book 2+ content is a
   CONTRADICTION.

3. **If any CONTRADICTIONS are found:** STOP. Do NOT proceed to the
   Approval Gate. List every contradiction with its source conflict
   (e.g., "Penvose referenced in Book 1 Section 4 — Series
   Architecture Section 10 assigns Penvose to Book 2 Ch 12"). Fix all
   contradictions before re-running the check.

4. **If INVENTIONS are found:** Ensure every invention uses a
   [PLACEHOLDER] tag (not a silently assigned name). If any
   invention was named without a placeholder, convert it to a
   placeholder before presenting.

5. **Produce the traceability summary** at the top of the Story
   Bible presentation:
   ```
   TRACEABILITY SUMMARY:
     Citations (from architecture): {N} elements
     Expansions (in-book only): {N} elements
     Inventions (cross-book, [PLACEHOLDER]): {N} — REQUIRE YOUR APPROVAL
     Contradictions found: {N}
   ```

6. **Only then proceed to the Story Bible Approval Gate.**

#### STORY BIBLE APPROVAL GATE (MANDATORY, BLOCKING)

After Phase 2F (Conformance Check) completes:

1. **Display the COMPLETE Story Bible** to the user as formatted text in the
   conversation. This includes: Core Concept, Themes, POV & Narrative Style,
   ALL Characters (with full bios and personality sliders for major characters),
   Locations & World, Timeline, Plot Structure, Chapter Outline summary,
   Trope Integration, and Chekhov's Guns.
2. **Display the Entity Database** — show the extracted characters, locations,
   and canon rules so the user can verify accuracy.
3. **Prompt the user** with options:
   - "Approve Story Bible — proceed to chapter generation"
   - "Request changes" (specify what to modify)
   - "Add details" (user wants to supplement the Bible)
4. **Do NOT proceed to Phase 3 (or Phase 2.5) until the user approves.**

### PHASE 2.5: STORY BIBLE ONLY DELIVERY (Conditional — Story Bible Only mode)

**When to run:** ONLY when `project_mode` is `story_bible_only`. If mode is
`full_pipeline`, skip this phase entirely and proceed to Phase 3.

**What happens:** Generate the Writer's Companion document and deliver the
complete creative package. The pipeline then STOPS — no chapter generation,
no verification, no editorial. The user writes the book themselves.

**Steps:**

1. **Generate Writer's Companion** — Load `writers-companion.md` and run the
   full Writer's Companion generation protocol. This compiles the Story Bible,
   entity database, outline, beat structure, trope plan, Chekhov's Guns, genre
   craft notes, and transportive setting into a single, human-friendly .docx
   document designed for a writer working in Word, Scrivener, or Google Docs.

2. **Save project metadata** — Write a `project-mode.md` file to engine-data:
   ```markdown
   # Project Mode: Story Bible Only
   Created: {date}
   Genre: {genre}
   Length tier: {tier}
   Status: Awaiting manuscript

   ## Return Instructions
   When the writer completes their manuscript, they should:
   1. Return to this project ("edit my [Title]" or "I've finished [Title]")
   2. Paste or upload their completed manuscript
   3. The engine will validate against the Story Bible, reconcile changes,
      and run the full editorial pipeline
   ```

3. **Deliver to user** — Present the delivery summary:
   ```
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     YOUR STORY BIBLE IS COMPLETE
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

     Project: {Title}
     Genre:   {genre}
     Length:  {tier} (~{word_count} words, {chapter_count} chapters)

     Delivered:
     ✓ Writer's Companion (.docx) — your complete creative brief
     ✓ Story Bible — world, characters, timeline, canon rules
     ✓ Entity Database — structured character/location reference
     ✓ Chapter Outline — per-chapter plan with beats and arcs
     ✓ Beat Structure — structural beat map
     ✓ Trope Plan — setup/escalation/payoff schedule (if selected)
     ✓ Chekhov's Guns — plant/payoff tracking (if selected)
     ✓ Market Pulse Report — comp titles and positioning (if generated)

     Saved to: ~/Documents/Ideorix-Projects/{Title}/

   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

     WHAT HAPPENS NEXT

     Write your book using the Writer's Companion as your guide.
     Take as long as you need — your project data is saved.

     When you've finished writing, come back and say:

       "Edit my {Title}"
       "I've finished {Title}"
       "Review my manuscript for {Title}"

     The engine will:
     1. Reconnect to your Story Bible and character database
     2. Validate your manuscript against the established canon
     3. Ask you about any creative changes you made
     4. Run the full editorial pipeline — with the advantage of
        already knowing your story intimately

     You can also use these tools at any time:
     • "Design my cover" — Cover Designer (uses your Story Bible)
     • "Marketing for {Title}" — Marketing materials
     • "Manuscript clinic" — Deep diagnostic analysis
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   ```

4. **STOP.** The pipeline is complete for Story Bible Only mode. Do NOT
   proceed to Phase 3. The next interaction with this project will be the
   return flow (see "Returning to a Story Bible Only Project" below).

**Output:**
- `Ideorix-Projects/[Title]/manuscript/writers-companion.docx`
- `Ideorix-Projects/[Title]/engine-data/project-mode.md`
- All Phase 2 outputs (story-bible.md, entities.md, outline.md, etc.)

---

### PHASE 3: CHAPTER GENERATION

See `blueprint-agent.md` and `prose-agent.md` for agent protocols.
See `beat-structures.md` for beat integration, `chekhovs-guns.md` for gun tracking,
and `trope-library.md` for trope delivery guidance.

For EACH chapter (written sequentially, never out of order):

0. **Context Scoping (MANDATORY, runs before any agent)** — Read the chapter
   outline entry and identify which characters, locations, and objects appear.
   Load ONLY those entity profiles from `entities.md` for this chapter's
   Architect, Writer, and Verification agents. Also scope chapter summaries:
   last 3 in full, earlier chapters as one-line precis only. This reduces
   context by 30-60% on novels with large casts and improves agent focus.
   **Exception:** For Chapter 1 and the final chapter, load full entities.
   See `blueprint-agent.md` and `prose-agent.md` for scoping rules.

   **Disk re-read rule (MANDATORY — context compression defence):**
   At the start of EVERY chapter's generation cycle, re-read ALL source
   files from disk. Do NOT rely on in-memory state from earlier chapters.
   Kimi's context management may compress or evict earlier token blocks
   during long sessions, making in-memory copies of files stale.

   Files that MUST be re-read from disk at the start of each chapter:
   - `engine-data/pipeline-checkpoint.md` (already required by pre-flight)
   - `engine-data/story-bible.md` (Section 12 entry for this chapter)
   - `engine-data/entity-canon.md` (loaded at step 6a)
   - `engine-data/running-banlist.md` (loaded at step 6a)
   - `engine-data/summaries/ch{NN-1}-summary.md` (last 3 summaries)
   - `engine-data/character-states/ch{NN-1}-state.md` (most recent
     character-state snapshot — emotional state, knowledge, secrets)

   Never assume "I already loaded the Bible earlier in this session."
   The checkpoint file is the ONLY persistent cross-chapter state — all
   other files must be re-read from disk at each chapter boundary.
1. **Read genre bank file** for genre-specific architect/writer instructions
2. **Calculate beat target** — if a beat structure is selected, determine which beat
   this chapter should serve (see `beat-structures.md` for the mapping formula)
3. **Check Chekhov's Guns** — if guns are active, determine if this chapter plants
   or pays off a gun (see `chekhovs-guns.md` for integration protocol)
4. **Check trope plan** — if tropes are active, consult `trope-plan.md` to determine
   which tropes this chapter should advance, setup, or pay off
4b. **Canon Validator — pre-brief audit (MANDATORY, BLOCKING)** — Before the
   Architect runs, the Canon Validator (see `canon-validator.md`) performs a
   scoped check: it reads all checkpoint content claims that implicate
   Chapter N and cross-checks them against the Story Bible's aggregate truth
   tables and Section 12 entry for Chapter N.

   **Why this runs here:** The Architect reads the checkpoint to understand
   prior-chapter state. If the checkpoint contains a stale or invented
   content claim ("Ch N must fire event X"), the Architect will design a
   brief around it. Catching the stale claim BEFORE the Architect reads it
   is cheaper than catching it after the brief is written.

   **Execution procedure:**
   1. Read `engine-data/pipeline-checkpoint.md` — extract the Flags section
      and any content claims referencing Chapter N or later chapters
   2. For each content claim found, apply the Canon Validator's 5-step
      validation procedure (see `canon-validator.md`)
   3. Apply the Aggregate Precedence Rule (see `world-canon.md`): check
      aggregate truth tables FIRST. If a table answers the question, use
      that answer — do not search prose-embedded claims
   4. If all claims PASS: proceed to step 5 (Architect)
   5. If any claim is WARN: surface to the user with the Architect brief
      at step 6. The Architect may proceed but the user sees the warning
   6. If any claim is FAIL: STOP. The failing claim must be corrected in
      the checkpoint before the Architect runs. Present the Canon
      Validator's report to the user and wait for resolution

   **This step adds ~30 seconds per chapter.** It is the engine's primary
   defence against stale checkpoint claims propagating into briefs.

5. **Architect** generates chapter brief (scenes, beats, emotional arcs, goals)
   — Receives beat target, gun instructions, and trope delivery targets for this chapter
   — Plans scenes that service active tropes naturally (not forced)
5a. **Outline Conformance check (MANDATORY, BLOCKING, HARD GATE)** — Run the Outline
   Conformance Agent (see `outline-conformance.md`) against the draft brief
   BEFORE presenting it to the user. This agent is the engine's ONLY brief-time
   verifier — all others run after prose is written. It performs 6 checks:
   Chapter Goal Match, Required Beat Delivery, No Silent Drops, No Unauthorised
   Additions, Zoom-Out Sustainability, and Chekhov Gun Room. Output: PASS / WARN
   / FAIL, written to `engine-data/reports/ch{NN}-outline-conformance.md`.

   **THIS IS A HARD GATE — NOT A SUGGESTION:**
   - Skipping this step is the SINGLE most common way that cumulative outline
   - You MAY NOT present the brief to the user at step 6 until the Outline
     Conformance Agent has actually run, written its report via the Write
     tool, and updated the pipeline-checkpoint's `OC Report` field to "Yes".
   - You MAY NOT "narrate" the conformance check and proceed. The agent
     must actually run, and the write tool must actually be invoked to
     persist the report. The checkpoint field is the proof the step
     completed. (See File Operation Policy above — trust the Write
     tool and the checkpoint; don't Read the report back.)
   - "The brief looks fine to me, Section 12 seems aligned, I'll skip the
     formal check this time" is a PROTOCOL VIOLATION regardless of how
     obviously clean the brief appears. Run the agent. Every brief. Every time.

   **Execution procedure (follow in order):**
   1. Load Section 12 (Chapter Outline) for Chapter N from the Story Bible
   2. Load Section 14 (Chekhov Gun schedule) for the gun-room check
   3. Load `engine-data/beat-delivery-log.md` (if it exists) for the
      sustainability check
   4. Receive the draft brief content from step 5 (in-memory from the
      Architect — do NOT Read from a file, the brief hasn't been written
      yet)
   5. Run the 6 checks as specified in `outline-conformance.md`
   6. **Produce the audit footer** in this format:
      ```
      <!-- IDEORIX:AUDIT:BEGIN v1 -->

      ## Outline Conformance Audit
      Verdict: {PASS | WARN | FAIL}
      Ran at: Chapter {N} brief-generation time
      Agent: Outline Conformance Agent (6 checks)

      Check A (Chapter Goal Match):       {pass/warn/fail} — {one-phrase reason if not pass}
      Check B (Required Beat Delivery):   {pass/warn/fail} — {...}
      Check C (No Silent Drops):          {pass/warn/fail} — {...}
      Check D (No Unauthorised Additions):{pass/warn/fail} — {...}
      Check E (Zoom-Out Sustainability):  {pass/warn/fail} — {...}
      Check F (Chekhov Gun Room):         {pass/warn/fail} — {...}

      {drift detail list, one line per drift item, max 50 items}

      {recommendations, max 10 lines}

      <!-- IDEORIX:AUDIT:END -->
      ```
   7. **Check audit length.** Count the lines between the BEGIN and END
      markers (inclusive of the markers themselves).
      - **If audit ≤ 100 lines:** append the full audit block to the
        brief content in memory.
      - **If audit > 100 lines (typically FAIL with many drift items):**
        - Write the full audit to `engine-data/reports/ch{NN}-oc-detail.md`
          as an overflow file (single write tool call).
        - Append a SUMMARY audit block to the brief instead: verdict +
          top 3 drift items + a "Full detail: engine-data/reports/
          ch{NN}-oc-detail.md" pointer line. The summary block is still
          wrapped in `<!-- IDEORIX:AUDIT:BEGIN v1 -->` /
          `<!-- IDEORIX:AUDIT:END -->` markers for consistency.
      - The 100-line cap exists to prevent the brief file from being
        dominated by an oversized audit footer. Overflow is rare —
        clean PASS and WARN audits fit within 30-50 lines; the cap
        triggers only on FAIL cases with extensive drift.
   8. **Write the combined brief + audit footer** to
      `engine-data/chapter-briefs/ch{NN}-brief.md` via the write tool.
      This is a single write tool call containing brief content + audit
      footer. Trust the write tool — if it returns without error, the
      file is on disk. If Write errored, STOP and re-run the agent. Do
      NOT Read the file back (see File Operation Policy above).
   9. Update `engine-data/pipeline-checkpoint.md` — set Chapter N's
      "OC Report" field to "Yes" and record the verdict (PASS / WARN /
      FAIL) in the "OC Verdict" column. The checkpoint is the
      cross-chapter status ledger and the Progress Dashboard's OC
      Verdict line reads from here.
   10. Only then proceed to step 6 (User Review Gate).

   **Consolidation note (v1):** Prior to this version, the OC Agent
   wrote its report as a separate file `engine-data/reports/ch{NN}-
   outline-conformance.md`. As of v1 of the `IDEORIX:AUDIT` footer, the
   audit is consolidated into the brief file to reduce per-chapter
   file count and Kimi's Sources panel clutter. The
   separate OC report file is no longer produced in the common case
   — only as an overflow file for FAIL cases exceeding the 100-line
   cap. The Progress Dashboard's Outline Conformance line reads the
   verdict from the pipeline-checkpoint (same as before); nothing
   downstream depends on the standalone OC report file.

   **Attach the conformance verdict to the brief before the User Review
   Gate (step 6).** The brief file now contains the audit footer
   inline. The user review (step 6) displays the brief content (without
   the audit footer) in conversation, then displays the audit verdict
   summary below, then prompt the user. If the conformance verdict is
   FAIL, step 6 is expanded with extra options (see step 6 below).
6. **User review (MANDATORY, BLOCKING, NEVER SKIP)** — Present the complete brief
   AND the Outline Conformance Report to the user by prompting them.
   Do NOT proceed to the Writer until the user confirms.
   This gate was skipped in every test run. It MUST NOT be skipped.

   **Autopilot override (when `project_mode: supervised_autopilot`):**
   Read `engine-data/project-config.md` for `project_mode`. If set to
   `supervised_autopilot`, SKIP the interactive brief-review prompt when
   the Outline Conformance verdict is PASS or WARN. Display the brief
   summary (title, beat, target word count) and the OC verdict inline,
   append "[AUTO-APPROVE] Brief for Chapter {N} — OC: {verdict} —
   proceeding to Writer", and continue directly to step 7.
   If OC verdict is FAIL, the autopilot YIELDS: display the full brief
   and audit, explain the failure, and prompt the user with standard
   options (Revise brief, Override and write, etc.).

   **Display logic for step 6:** Load the brief file content. Strip
   any content between `<!-- IDEORIX:AUDIT:BEGIN v1 -->` and
   `<!-- IDEORIX:AUDIT:END -->` markers (inclusive). Display the
   stripped brief content to the user in conversation. Then display
   the audit summary (verdict + top 3 findings if WARN/FAIL, or
   just the verdict if PASS) as a separate block. Then use
   prompt the user for approval.

   **Pre-gate check (MANDATORY, HARD GATE, runs BEFORE prompting the user):**
   Before you may present the brief to the user, confirm that step 5a
   completed. This is a fail-closed gate — any uncertainty MUST block
   presentation of the brief.

   **Check procedure:**
   1. Read `engine-data/pipeline-checkpoint.md` ONCE (no re-reads).
   2. Locate the Chapter Progress table — the table whose header row
      begins `| Ch |`.
   3. Confirm the header row contains `OC Report` and `OC Verdict` as
      exact column names. If the checkpoint has been written with a
      different column schema (e.g., "Architect brief" instead of
      "Brief", or no OC Report column at all), that is a Phase 2E
      schema violation — STOP. Re-run Phase 2E with the canonical
      v2-schema column headers. See File Location Discipline above
      (Checkpoint schema invention — FORBIDDEN).
   4. Locate the row for the current chapter N.
      - If no row exists, step 5a was skipped. STOP. Return to step 5a,
        run the Outline Conformance Agent, and let it create the row
        with OC Report populated.
      - If the row exists but `OC Report` is not "Yes" OR `OC Verdict`
        is blank, step 5a ran incompletely (e.g., did not Write the
        audit footer into the brief or did not update the checkpoint).
        STOP. Re-run step 5a in full.
   5. Only when BOTH `OC Report = Yes` AND `OC Verdict ∈ {PASS, WARN,
      FAIL}` may you proceed to display the brief.

   There is no "this brief looks clean, we can skip OC this time"
   override. The OC Agent is a blocking upstream dependency of step 6,
   not an optional audit. (Do NOT Read the OC report file itself as an
   existence check — trust the checkpoint. See File Operation Policy
   above.)

   **Implementation:** Prompt the user with options:
   - If conformance verdict is **PASS** or **WARN**: "Approve brief", "Edit
     brief", "Add notes for the Writer"
   - If conformance verdict is **FAIL**: "Keep brief as-is — update Story Bible
     Section 12 to reflect the drift", "Revise brief to match Section 12",
     "Abort this chapter and regenerate from Section 12 alone"
   Do NOT use a text message that can be ignored — use
   the interactive tool so the pipeline physically cannot proceed without a response.
   **If the user picks "Keep brief as-is" on a FAIL:** Apply the user's reasoning
   as a Section 12 update (the drift becomes the new plan) and log the decision
   to `engine-data/outline-conformance-log.md`. The updated Section 12 becomes
   the baseline for all subsequent conformance checks.
6a. **Writer Pre-Load (MANDATORY, BLOCKING)** — Before the Writer generates
   any prose for this chapter, the pipeline MUST pre-load TWO files into
   the Writer prompt: (A) the Running Banlist as OPENING HARD CONSTRAINTS
   (see `prose-agent.md` "Running Banlist" section) and (B) the Entity
   Canon Lockfile as ENTITY CANON (see `world-canon.md` Phase 2D and
   `prose-agent.md` ENTITY CANON block).

   **Brief freshness check (MANDATORY — runs BEFORE any pre-load):**
   Before loading the banlist or canon, verify the brief file is current:

   ```bash
   stat -c '%Y' {path}/engine-data/chapter-briefs/ch{NN}-brief.md
   ```

   Compare the brief's modification timestamp against the time the user
   approved the brief at step 6. If the brief file is OLDER than the
   approval (i.e., the file was not updated after approval), it is stale
   — a different brief may have been generated since. STOP and alert
   the user: "Brief file for Ch {N} was last modified at {timestamp},
   but approval was granted at {approval_time}. Verify this is the
   correct brief before proceeding."

   Also run the file-integrity check on the brief:
   ```bash
   wc -w {path}/engine-data/chapter-briefs/ch{NN}-brief.md && tail -n 3 {path}/engine-data/chapter-briefs/ch{NN}-brief.md
   ```
   If the brief is <100 words or ends mid-sentence, it is truncated.
   STOP — do not proceed to the Writer with a damaged brief.

   **Execution procedure:**

   **Step A — Running Banlist pre-load:**
   1. Read `engine-data/running-banlist.md` with the read tool
   2. **Banlist freshness check:** If this is Chapter 3 or later, verify
      the banlist was updated after the previous chapter's Humaniser ran.
      Check the file's modification timestamp:
      ```bash
      stat -c '%Y' {path}/engine-data/running-banlist.md
      ```
      If the banlist is older than the previous chapter's Humaniser
      completion (i.e., the Humaniser's banlist write failed silently),
      flag: "Banlist may be stale — last modified before Ch {N-1}
      Humaniser. Verify the Humaniser updated it." Proceed with the
      loaded banlist but surface the warning to the user.
   3. Extract the HARD CONSTRAINTS section verbatim (not WATCHLIST, not
      RETIRED, not BREACH LOG)
   4. **Banlist format validation:** Verify the extracted HARD CONSTRAINTS
      section is well-formed before injection:
      - Contains at least the section header (`## HARD CONSTRAINTS`)
      - Each constraint entry follows the expected format (pattern
        description + chapter where it was promoted)
      - No truncated entries (each entry ends with a complete sentence)
      If the section is malformed or truncated, flag: "Banlist HARD
      CONSTRAINTS section appears malformed. Verify the Humaniser's
      last update completed successfully." Proceed with the loaded
      constraints but surface the warning.
   5. Inject it into the Writer's User Prompt Template at the
      `{opening_hard_constraints}` slot — which is the FIRST block of the
      prompt, before STORY BIBLE EXCERPT
   6. If the file does not exist (Chapters 1 and 2 of a new manuscript),
      use the single-line placeholder: "No recurring patterns promoted yet
      — universal forbidden-words.md rules still apply."

   **Step B — Entity Canon pre-load:**
   1. Read `engine-data/entity-canon.md` with the read tool
   2. Extract the Characters, Locations, and Objects tables verbatim (all
      three — do NOT truncate to "just characters")
   3. **Check the NEW ENTITIES PENDING APPROVAL section.** If the current
      chapter's brief introduced a new entity and it has NOT been approved
      by the user, STOP. The brief should have surfaced the pending entity
      at the User Review Gate (step 6) for approval. Return to step 6 and
      get approval before proceeding.
   4. Inject the approved canon tables into the Writer's User Prompt Template
      at the `{entity_canon}` slot — which sits just below the OPENING
      HARD CONSTRAINTS block, above STORY BIBLE EXCERPT
   5. If `entity-canon.md` does not exist, the Story Bible phase did not
      produce it. STOP and re-generate the canon before proceeding —
      the Writer MAY NOT run without an entity canon.
      **Branch by project source:**
      - If `project-config.md` shows `source: screenplay`, the entity
        canon is owned by the screenplay importer. Re-run the Entity
        Canon Lockfile generation step from
        `screenplay-importer.md` against the already-parsed data in
        `engine-data/screenplay-source.md`.
      - Otherwise (normal Write-a-Book project), re-run the World
        Canon's Phase 2D Entity Canon Lockfile protocol
        (`world-canon.md`).

   **Story Bible change detection (MANDATORY — runs AFTER banlist and
   canon pre-load, BEFORE Writer prompt assembly):**

   Check whether the Story Bible was modified since the Architect
   generated the brief for this chapter:

   ```bash
   stat -c '%Y' {path}/engine-data/story-bible.md
   ```

   Compare the Bible's modification timestamp against the brief file's
   timestamp. If the Bible is NEWER than the brief, the user (or an
   agent) modified the Bible after the Architect read it. The Writer
   is about to execute a brief built on stale Bible data.

   - If the Bible change was a Section 12 update for THIS chapter
     (e.g., the user approved a FAIL brief and updated Section 12):
     this is expected. Proceed — the brief already reflects the change.
   - If the Bible change affects OTHER sections (character profiles,
     locations, canon rules, entity names): flag to the user:
     "Story Bible was modified since Ch {N}'s brief was generated.
     Changes may affect this chapter. Re-run the Architect, or approve
     the current brief with the understanding that it was built on
     the pre-change Bible."

   This check prevents the "user corrects Bible mid-chapter, Writer
   still uses old cached version" scenario. It adds <2 seconds.

   **Series Bible cross-volume re-check (CONDITIONAL — series projects
   only, runs when Story Bible change is detected):**

   If (a) this is a series project (`series-data/series-bible.md`
   exists) AND (b) the Story Bible was modified since the brief was
   generated, additionally check the modified Bible against the Series
   Bible:

   1. Read the Series Bible's character trajectories for this volume
   2. Read the modified Story Bible's Section 12 entries for upcoming
      chapters
   3. Verify that character arc assignments in the modified Section 12
      still align with the Series Bible's trajectory map for this
      volume
   4. Verify that no arc weave thread was silently dropped or
      contradicted by the modification

   If a contradiction is found: flag to the user — "Story Bible
   modification conflicts with Series Bible: {detail}. Resolve before
   proceeding." This re-check only runs when a change is detected,
   not every chapter — it adds ~5 seconds when triggered.

   **Checkpoint update:**
   6. Update `engine-data/pipeline-checkpoint.md` — set Chapter N's
      "Banlist Loaded" field to "Yes" AND "Canon Loaded" field to "Yes"

   **Why this step exists (production failure):** In a real manuscript run,
   Ch12 and Ch13 both needed the same surgical fixes: em dashes in narration,
   "the way [pronoun]" overuse, "the kind of" despite ban. The Humaniser had
   flagged the patterns. The Batch Editor's feed-forward "notes" had
   mentioned them. But the Writer never internalised them because
   feed-forward notes are advisory — they do not dominate attention the way
   opening hard constraints do. The fix burden recurred chapter after
   chapter. This step moves recurring patterns out of advisory feed-forward
   and into the Writer prompt's opening block where attention is strongest.

   **Second production failure (entity canon):** Same manuscript had the
   father's canonical name set to "Matthew" in the Story Bible but the
   Ch10 prose established "Mark" in dialogue. The drift carried through
   Ch10-Ch11 before the user caught it manually. The mother's name also
   drifted from "Catherine" to "Caroline" across Ch9-Ch11. The Continuity
   Guardian's proper-noun check existed but missed the drift because the
   character descriptions were in Bible paragraph form rather than a
   structured flat lookup. Step B (Entity Canon pre-load) prevents this
   by putting a flat, authoritative name table at the top of every Writer
   prompt. The Writer physically cannot invent new names when the
   canonical ones are sitting at the top of its attention window — and
   when paired with the Continuity Guardian's mechanical Canon Compliance
   Check (see `quality-gate.md`), any drift that somehow slips through is
   caught at verification time against the same flat table.

   **Banlist Loaded is a HARD GATE.** The Writer MAY NOT run (step 7)
   until this step has completed and the checkpoint's `Banlist Loaded`
   field is "Yes" for the current chapter. Skipping this step is the
   single most common way running-fix-burden patterns recur across
   chapters.

7. **Writer** executes brief into prose
   — Applies the Running Banlist HARD CONSTRAINTS loaded at step 6a
     (zero tolerance, non-negotiable, zero per chapter)
   — Applies the 7 Craft Commandments (see `craft-standards.md`)
   — Applies universal name/pattern avoidance (see `authenticity-guard.md`)
   — Receives gun plant/payoff instructions if applicable
   — Delivers trope moments through character behaviour, not narrator announcement
7a. **User reviews prose (MANDATORY, BLOCKING)** — Present the COMPLETE chapter
   prose to the user as conversation output (not a file read). Prompt the user
   with options:
   - **"Approve — continue to verification"** — Accept the chapter and proceed to
     post-processing and verification agents.
   - **"Request revisions"** — Provide specific feedback for the Writer to address.
   - **"Rewrite from brief"** — Discard this draft and regenerate from the chapter brief.
   - **"Run chapter quality report"** — Before deciding, run all 6 verification agents
     on the current draft and present a comprehensive quality report (scores, issues,
     strengths, weaknesses) so the user can make an informed approve/revise decision.
     After the report is displayed, re-present the approval options (minus this one)
     so the user can act on what they've learned. If this is the final chapter of a
     5-chapter batch (chapter number divisible by 5, or the last chapter of the
     manuscript), automatically expand this into a **full batch editorial review**:
     run the Batch Editor (see `batch-editor.md`) across all chapters in the current
     batch and present a Batch Health Report covering cross-chapter continuity,
     pacing, voice drift, AI-ism accumulation, and overall arc progression — in
     addition to the single-chapter scores.
   The user must see and approve the prose before any post-processing runs. This is
   the prose equivalent of the brief review gate at step 6.

   **Autopilot override (when `project_mode: supervised_autopilot`):**
   Read `engine-data/project-config.md` for `project_mode`. If set to
   `supervised_autopilot`, SKIP the interactive prose-approval prompt.
   Display a compact prose summary (first line + word count + any
   visible placeholder count) and append "[AUTO-APPROVE] Prose for
   Chapter {N} — {words} words — proceeding to verification".
   Proceed directly to step 8 (prose quality check) and step 9
   (word count enforcement). The full prose IS still displayed so the
   user can scroll back and review, but the engine does not wait for
   a response before continuing.
8. **Prose quality check** — verify no placeholders, no brackets, no meta-text
9. **Word count enforcement (MANDATORY, BLOCKING)** — Count the chapter's words and
   compare to target. This check is NOT optional. Report the actual vs target count
   explicitly. Do NOT proceed until word count is met.

   **Pass band:** 90-110% of the published target = PASS. Proceed.
   **Soft miss:** 80-89% = retry. Expand thin scenes per the Architect's
   dramatisation notes. Maximum 2 retries.
   **Hard miss:** below 80% after 2 retries = escalate to Architect for
   brief expansion (see `prose-agent.md` Severe Miss protocol). The
   expanded brief MUST go through OC Agent + User Review Gate before
   the Writer re-runs.
   **Over target:** 111-115% = trim. Above 115% = structural issue,
   escalate to Architect.

   If the Writer cannot reach 90% after 2 retries, prompt the user:
   "Chapter {N} is at {actual}% of target after 2 retries. Options:
   (A) Accept as-is, (B) Expand brief and re-write, (C) Adjust target."

9a. **Pre-Humaniser Mechanical Audit (MANDATORY — feeds Model Health Monitor)**
   Before the Humaniser runs, run the full mechanical audit suite on
   the Writer's first-draft output. This captures violation counts
   BEFORE any fixing — the raw signal of model constraint-compliance.

   **Run the master orchestrator:**
   ```bash
   bash scripts/ideorix-audit.sh \
     {path}/engine-data/chapters/ch{NN}.md \
     {project-path} \
     {word-target}
   ```

   This runs all 7 per-chapter modules in sequence:
   1. Forbidden words scan (full 1,212-entry list)
   2. Formatting check (em-dashes, ellipses, exclamation marks)
   3. Pattern counter (31 AI-ism patterns with exact counts)
   4. Placeholder scan (brackets, TBD, frame leaks)
   5. Word count check (vs target + file integrity)
   6. Entity canon verification (proper noun drift)
   7. Number-7 bias check

   **Then run the violation dashboard to produce the health row:**
   ```bash
   bash scripts/violation-dashboard.sh \
     {path}/engine-data/chapters/ch{NN}.md \
     {project-path} \
     {word-target} \
     {model-id}
   ```

   The dashboard outputs a structured table and a model-health.md row.
   Append the row to `engine-data/model-health.md` using bash-direct
   write (side-file + mv pattern).

   **The script output is GROUND TRUTH for mechanical counts.** Model
   agents at step 12 MUST NOT recount these — they receive the script
   output as input and focus on creative/semantic judgement only.

   **Model Health Monitor tier from script output:**
   - PASS: proceed to Humaniser normally
   - WATCH: proceed, but surface the elevated metrics in the
     Progress Dashboard under "Model Health"
   - STOP: hard gate — present a prompt to the user with options:
     continue / switch model / pause session

   # "which was" count (cap ≤2)
   WHICH_WAS=$(grep -ciE 'which (was|were)' "$DRAFT")

   # Forbidden-word hits (zero tolerance)
   FORBIDDEN_HITS={count of forbidden-words.md matches}
   ```

   Record these in the chapter's humaniser-notes file and in
   `engine-data/model-health.md` (see Model Health Monitor below).

   **Do NOT alert the user yet.** The Humaniser will fix most of these.
   The purpose here is telemetry only — capturing the pre-fix state so
   the Model Health Monitor can detect behavioural drift across chapters.

10. **Prose Humaniser (MANDATORY)** — Strip AI-ism patterns from Writer output
   (see `prose-humaniser.md`). Runs BEFORE verification agents. Do NOT skip this step.

   **Post-Humaniser content validation (MANDATORY — runs AFTER Humaniser
   overwrites `chapters/ch{NN}.md`, BEFORE step 11 or step 12):**

   The Humaniser overwrites the Writer's chapter file in-place. This
   validation confirms the overwrite didn't corrupt, truncate, or
   semantically damage the chapter.

   1. **Word count delta check:** Compare the Humaniser's output word
      count against the Writer's original (from the pre-Humaniser
      snapshot at step 14). If the delta exceeds ±5%, the Humaniser
      removed or added more content than pattern replacement warrants.
      Flag: "Humaniser changed word count by {delta}% — expected ≤5%.
      Verify the overwrite didn't delete content."

   2. **Entity-canon spot-check:** Grep the Humanised chapter for every
      Canonical Name in `entity-canon.md`. If a name that appeared in
      the Writer's draft is MISSING from the Humanised version, a
      replacement operation may have accidentally deleted a character
      reference. Flag: "Character '{name}' present in Writer draft but
      absent from Humanised output."

   3. **Plot-anchor check:** Read the chapter brief's scene breakdown.
      For each scene's key action or dialogue line, grep the Humanised
      chapter for a signature phrase (character name + verb, or a
      distinctive dialogue fragment). If a scene's signature is absent,
      the Humaniser may have removed plot-critical content. Flag:
      "Scene {N} signature not found in Humanised output."

   4. **Terminal integrity:** Same check as step 18 — last non-empty
      line ends with terminal punctuation, no null bytes. (Belt-and-
      braces catch for Humaniser-introduced truncation.)

   If any check flags a HIGH-severity issue (entity missing, scene
   signature absent, >5% word count delta), STOP. Restore from the
   pre-Humaniser snapshot and re-run, or surface to the user.

11. **Prose Craft Improver** — [Optional] two-step line editing: analyse prose against
   `craft-standards.md`, then apply surgical fixes (see `surgical-fixes.md` + `line-editor.md`).
   Use when higher prose quality is desired. Runs after Humaniser, before verification.
12. **Verification agents (MANDATORY, BLOCKING, HARD GATE)** — Run ALL 6
   verification agents on THIS chapter (see `quality-gate.md`): Continuity
   Guardian, Quality Guardian, Timeline Keeper, Character Tracker, Arc Analyst,
   Dialogue Guardian.

   **THIS IS A HARD GATE — NOT A SUGGESTION:**
   - The verification suite is NOT the same as the post-writing checks (steps 8-9).
   - Steps 8-9 are mechanical QA (word count, placeholders, em-dashes).
   - Step 12 is the 6-AGENT EDITORIAL VERIFICATION SUITE with structured reports,
     scores, continuity cross-checks, and issue tracking.
   - Completing steps 8-9 does NOT satisfy step 12. They are separate processes.
   - You MUST run all 6 agents AND save the report file AND display the progress
     dashboard BEFORE you may proceed to step 13 or the next chapter.

   **AGENT NAMES AND SCORING — EXACT SPECIFICATION (DO NOT SUBSTITUTE):**

   The 5 verification agents are defined in `quality-gate.md`. Their names,
   roles, and scoring are LOCKED. Do NOT rename them, replace them with
   invented agents, merge them, or substitute PASS/FAIL verdicts for scores.

   | Agent | Role | Score Range |
   |---|---|---|
   | **Continuity Guardian** | Character/information consistency vs Bible, entity DB, prior chapters | 0–100 |
   | **Quality Guardian** | Prose quality, 7 Craft Commandments, genre fit, AI-ism density | 0–100 |
   | **Timeline Keeper** | Temporal logic, event sequencing, time-of-day consistency | 0–100 |
   | **Character Tracker** | Behaviour consistency, voice differentiation, knowledge-state | 0–100 |
   | **Arc Analyst** | Structure, beat delivery, tension progression, pacing slider accuracy | 0–100 |
   | **Dialogue Guardian** | Voice differentiation, subtext, reveal vs explain, interruption patterns | 0–100 |

   **Scoring is NUMERIC (0–100), not PASS/FAIL.** Each agent produces a
   score from 0 to 100 using the calibration anchors in `quality-gate.md`.
   PASS/FAIL is NOT an acceptable substitute — a "PASS" hides whether the
   score was 82 or 98, which are very different quality levels.

   **V-Score formula (MANDATORY — use this exact calculation):**
   ```
   Standard (6 agents):  V-Score = Continuity×0.20 + Quality×0.15 + Timeline×0.15 + Character×0.20 + Arc×0.15 + Dialogue×0.15
   Series (7 agents):    V-Score = Continuity×0.15 + Quality×0.15 + Timeline×0.10 + Character×0.15 + Arc×0.10 + Dialogue×0.15 + Series×0.20
   ```

   **The V-Score is the WEIGHTED AVERAGE of 6 numeric scores.** It is NOT
   a count of PASS verdicts. A V-Score of 100 means all 6 agents scored
   100/100 — which should be exceptionally rare.

   **Progress Dashboard verification section MUST show BOTH layers:**

   ```
   MECHANICAL AUDIT (bash scripts — exact counts, no approximation)
   | Check                    | Result | Cap   | Status |
   |--------------------------|--------|-------|--------|
   | Forbidden words          |  {N}   | 0     | {P/F}  |
   | Narration em-dashes      |  {N}   | 0     | {P/F}  |
   | Dialogue em-dashes       |  {N}   | ≤3    | {P/F}  |
   | "the way [pronoun]"      |  {N}   | ≤6    | {P/F}  |
   | "the kind/sort of"       |  {N}   | ≤3ms  | {P/F}  |
   | "the particular"         |  {N}   | 0     | {P/F}  |
   | "which was/were"         |  {N}   | ≤2    | {P/F}  |
   | Frame leaks              |  {N}   | 0     | {P/F}  |
   | Placeholders             |  {N}   | 0     | {P/F}  |
   | Word count               |  {N}   | {tgt} | {P/F}  |
   | Entity canon drift       |  {N}   | 0     | {P/F}  |
   | Number-7 bias            |  {N}%  | ≤25%  | {P/F}  |
   Mechanical audit: PASS / FAIL ({N} violations)

   CREATIVE VERIFICATION (6-agent suite — semantic judgement)
   | Agent               | Score |
   |---------------------|-------|
   | Continuity Guardian |  {N}  |
   | Quality Guardian    |  {N}  |
   | Timeline Keeper     |  {N}  |
   | Character Tracker   |  {N}  |
   | Arc Analyst         |  {N}  |
   | Dialogue Guardian   |  {N}  |
   V-Score: {weighted average} / 100

   MODEL HEALTH: {PASS / WATCH / STOP} (from violation-dashboard.sh)
   ```

   Do NOT invent new agent names. Do NOT add agents that are not in this
   list (the Prose Humaniser is NOT a verification agent — it runs at
   step 10, not step 12). Do NOT replace the table with prose summaries
   or PASS/FAIL verdicts. The dashboard must show the 6 exact names,
   6 numeric scores, and the weighted V-Score.

   **MECHANICAL COUNTS ARE ALREADY DONE — DO NOT RECOUNT.**

   The mechanical audit scripts ran at step 9a (pre-Humaniser) and
   again post-Humaniser. Their output is the ground truth for:
   - Forbidden word count
   - Em-dash count (narration vs dialogue)
   - Pattern frequency ("the way", "the kind of", "the particular", etc.)
   - Placeholder/frame leak detection
   - Word count vs target
   - Entity canon compliance
   - Number-7 bias

   **Verification agents MUST NOT recount these.** Instead:

   1. Read the step 9a audit output (available in conversation or in
      `engine-data/reports/ch{NN}-mechanical-audit.md` if persisted)
   2. Accept the mechanical counts as given facts
   3. Focus EXCLUSIVELY on creative/semantic judgement:
      - Continuity Guardian: logical consistency, knowledge-state violations,
        cross-chapter contradictions (NOT name counting — scripts did that)
      - Quality Guardian: 7 Craft Commandments assessment, prose rhythm,
        show-vs-tell, voice quality (NOT forbidden word scanning)
      - Timeline Keeper: temporal logic, event plausibility, travel-time
        credibility (NOT month/season name extraction — scripts did that)
      - Character Tracker: behaviour credibility, voice differentiation,
        arc progression, motivation (NOT name-count balancing)
      - Arc Analyst: beat delivery, tension trajectory, escalation
        sufficiency, pacing judgement (NOT slider arithmetic)

   4. Each agent's score (0–100) reflects ONLY creative/semantic quality
      — not mechanical compliance. A chapter with 0 mechanical violations
      but flat, lifeless prose should still score low on Quality Guardian.

   The Progress Dashboard includes BOTH the mechanical audit results
   AND the 6-agent creative scores — two independent assessments.

   **FILE GATE:** The verification report MUST be written to disk at:
   `engine-data/reports/ch{NN}-verification.md`
   Then confirmed via read tool. If this file does not exist, the chapter is
   NOT verified, regardless of what was displayed in conversation.

   **WHAT HAPPENS IF YOU SKIP THIS STEP:**
   - Errors compound across chapters (proven in testing — Feb/March timestamp
     contradiction, character count errors, repeated chapter endings)
   - The user loses confidence in the engine
   - Fixes become exponentially more expensive the longer they're deferred
   - This step exists because skipping it has caused real damage in production use

   Fix any critical issues BEFORE proceeding. This runs per-chapter, not in
   batches — do NOT defer verification to run on multiple chapters at once.
13. **Chapter summary (MANDATORY, BLOCKING)** — generate 3-5 sentence
   summary for continuity — Include trope delivery notes (which tropes
   were advanced this chapter).

   Write summary to: `engine-data/summaries/ch{NN}-summary.md` via
   the write tool.

   **Bash ls verification (MANDATORY):**
   ```bash
   ls -la {project-path}/engine-data/summaries/ch{NN}-summary.md
   ```
   If ls returns "No such file or directory", the write tool was not
   invoked. STOP. Re-run the summary Write in the parent conversation
   (not a sub-agent) and re-verify. Do NOT mark the checkpoint Summary
   column Yes until Bash ls confirms the file on disk.

   **Summary-vs-chapter verification (MANDATORY — runs AFTER summary
   Write, BEFORE marking Summary as Yes):**

   The summary feeds directly into the next chapter's Architect as
   continuity context. A summary that doesn't match the actual chapter
   silently corrupts the next brief. After writing the summary, verify:

   1. **Characters present:** Every character named in the summary must
      appear in the chapter prose. Grep the chapter file for each name.
      If a name appears in the summary but not the chapter, the summary
      is hallucinating characters — STOP and regenerate.
   2. **Key events:** The summary's event claims must correspond to
      actual scenes in the chapter. If the summary describes an event
      that doesn't happen in the prose, it was sourced from the brief
      (plan), not the chapter (reality) — STOP and regenerate.
   3. **Emotional state:** The summary's closing emotional state must
      match the chapter's actual ending, not the brief's planned ending.
      Read the last 10 lines of the chapter and compare.

   If any check fails, regenerate the summary from the chapter file
   (not from the brief or from memory). The summary must reflect what
   was WRITTEN, not what was PLANNED.

13b. **Character-state snapshot (MANDATORY)** — After the summary, write a
   structured character-state record to
   `engine-data/character-states/ch{NN}-state.md`.

   For each POV or major character who appeared in this chapter:

   ```
   CHARACTER: {name}
   EMOTIONAL STATE AT CHAPTER END: {specific — not "upset" but
     "ashamed of lying to Nell, guilty about the cup, determined
     to tell Helen tomorrow"}
   BELIEF STATE: {what they believe is true at this point, per
     their arc — "believes Helen is hiding something about the
     locket" / "trusts Pol completely"}
   RELATIONSHIP DELTAS: {who they trust more/less than before —
     "+trust Pol (he was honest about the chain)" /
     "-trust Vanessa (she didn't ask where it was found)"}
   KNOWLEDGE STATE: {what they NOW know that they didn't before
     — "knows the chain is wrong-period" / "knows Vanessa
     recognised the locket"}
   SECRETS HELD: {what they know but haven't shared — "hasn't
     told Helen about the soil" / "hasn't told Pol about
     Vanessa's face"}
   ```

   **Why this matters:** Without this, each chapter's Architect treats
   characters as a fresh draw from the Story Bible. If Ch 5 ends with
   Marlo ashamed and isolated, but Ch 6's Architect only reads the
   Bible (which says "Marlo: observant, quiet, files things"), Ch 6
   opens without the emotional weight of Ch 5's ending. Emotional-arc
   drift across long books is the subtlest character failure.

   **The next chapter's Architect MUST read the most recent character-
   state snapshot** as brief input alongside the Bible, the summary,
   and the beat sheet. It is loaded during Context Scoping (step 0).

   Write using bash-direct protocol. Verify with ls + stat.

14. **Snapshot (MANDATORY, BLOCKING)** — Before the Humaniser overwrites
   `chapters/ch{NN}.md`, copy the current Writer-draft content of that
   file to:
   `engine-data/revisions/{YYYY-MM-DDTHH-MM}_{stage}/ch{NN}.md`
   where `{stage}` is the process about to run (e.g. `pre-generation`,
   `pre-humaniser`, `pre-batch-edit`). If the chapter file does not yet
   exist (first generation), skip this step for that chapter. This
   creates an immutable rollback point — NEVER modify files inside
   `revisions/`. The snapshot folder is created once per process
   invocation, not per chapter.

   **Bash ls verification (MANDATORY):**
   ```bash
   ls -la {project-path}/engine-data/revisions/{snapshot-folder}/ch{NN}.md
   ```
   If ls returns "No such file or directory" AND the source chapter
   file existed (i.e., this isn't the first-generation skip case),
   the write tool was not invoked. STOP. Re-run the snapshot Write in
   the parent conversation and re-verify.
15. **Save** brief, chapter, and summary to workspace
16. **Post-save file verification (MANDATORY, BLOCKING)** — see File Verification Gate below
17. **Update tracking (MANDATORY — SYNCED FROM SHIPPED PROSE, NOT FROM THE BRIEF)** —
   update beat delivery log, Chekhov's Gun status, trope progress, and any
   open-questions or mystery-thread trackers.

   **CRITICAL RULE: All state trackers must be updated from what the Writer
   ACTUALLY SHIPPED in the chapter file, not from what the Architect's brief
   SAID the chapter would deliver.**

   The brief is a plan. The chapter file is the reality. If they disagree
   (because the Writer drifted from the brief, or the Humaniser restructured
   a scene, or verification surfaced a fix that changed the beat ordering),
   the tracker must reflect reality. Updating trackers from the brief
   silently desyncs state from the manuscript.

   **Per-tracker sync procedure:**
   - **Beat delivery log** (`engine-data/beat-delivery-log.md`) — read the
     shipped chapter file. For each beat Section 12 lists for this chapter,
     confirm it is actually present in the prose (not just referenced in the
     brief). Mark the beat as delivered ONLY if the prose delivers it.
   - **Chekhov's gun tracker** (`engine-data/chekhovs-guns.md`) — read the
     shipped chapter file. For each active gun, check whether the prose
     planted it (new gun entering the manuscript), paid it off (gun fires),
     or referenced it (awareness callback). Update the tracker from what's
     in the prose, not from what the brief scheduled.
   - **Open questions / mystery thread log** (`engine-data/open-questions.md`
     or equivalent) — read the shipped chapter file. Close any question the
     prose answered. Open any question the prose raised. Do NOT update this
     log from the brief.
   - **Trope delivery log** (`engine-data/trope-plan.md`) — same rule: mark
     a trope "delivered" only if the prose actually delivers it.

     **Trope at-risk early warning (MANDATORY — runs at step 17 for
     every chapter from the midpoint onwards):**

     After updating trope-plan.md, check for tropes that are behind
     schedule:

     ```
     FOR each trope in trope-plan.md:
       IF trope has a scheduled payoff chapter AND
          current_chapter >= (payoff_chapter - 2) AND
          trope status is NOT "escalated" or "paid off":
            FLAG: "Trope '{trope_name}' is scheduled to pay off in
            Ch {payoff_chapter} but has not escalated yet. {remaining}
            chapters remain. Risk of silent non-delivery."
     ```

     Surface flagged tropes in the Progress Dashboard under a "Tropes
     at Risk" section. This gives the Architect 2 chapters of lead
     time to course-correct before a trope falls off the calendar.
     The flag is advisory (WARN), not blocking — trope delivery is
     thematic and the Architect may have valid reasons to delay. But
     the warning must be visible.
   - **Beats-remaining ledger** (`engine-data/beats-remaining.md`) — derived
     from the beat delivery log. Must be regenerated from the shipped
     chapter, not the brief.

   **If a brief-vs-shipped mismatch is detected** (the brief said a beat
   would land, the prose doesn't have it): log the mismatch in
   `engine-data/brief-vs-shipped-log.md` and surface it at the end-of-chapter
   outline health check (step 17a below). This catches Writer drift, not
   just Architect drift.
17a. **Outline health check (MANDATORY — cumulative drift ledger)** — Display
   a zoom-out summary to the user before moving to the next chapter. This is
   the view that was missing when drift accumulated across Ch9-Ch12 in
   production testing.

   **Display format:**

   ```
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     CH{NN} COMPLETE — OUTLINE HEALTH CHECK

     Chapters remaining:  {total - N}
     Section 12 beats not yet delivered:  {count from beats-remaining ledger}
     Delivery rate needed:  {beats/chapter needed to finish}
     Typical capacity:  {typical beats per chapter for this length tier}
     Status:  {✓ SUSTAINABLE | ⚠ TIGHT | ⚠ DRIFT WARNING}

     Chekhov guns:
       Originally planned (Section 14):  {count}
       Currently planted:  {count}  {± mid-book additions}
       Fired so far:  {count}
       Unfired with <3 chapters to fire:  {list or "none"}

     Planned beats still undelivered:
       - {beat 1}
       - {beat 2}
       ...

     Brief-vs-shipped mismatches this chapter:  {count}
       {if > 0: list the specific mismatches with chapter reference}

     Conformance decisions to date:
       - PASS: {count}
       - WARN: {count}
       - FAIL accepted (Story Bible updated):  {count}
       - FAIL rejected (brief revised):  {count}

     Recommendation: {one of}
       ✓ On track — proceed to Ch{N+1}
       ⚠ Tight — consider compressing remaining beats
       ⚠ Drift detected — review Section 12 before Ch{N+1}
       ⛔ Major drift — recommend full outline review with user
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   ```

   **Typical capacity lookup (from project-config.md length tier):**

   | Length Tier | Typical Beats/Chapter |
   |---|---|
   | Short Story | 3 |
   | Novelette | 3 |
   | Novella | 4 |
   | Standard Novel | 4 |
   | Epic Novel | 5 |

   Read the length tier from `engine-data/project-config.md`. If it's
   missing, default to 4 and log the fallback. This is the same table the
   Outline Conformance Agent uses for Check E — see
   `outline-conformance.md` for the derivation (~1.5 beats per 1,000
   words of chapter length, observed from Section 12 entries across
   Ideorix genre files).

   **Status logic:**
   - `✓ SUSTAINABLE` when `delivery_rate_needed ≤ typical_capacity`
   - `⚠ TIGHT` when `delivery_rate_needed` is 1.0× to 1.5× typical
   - `⚠ DRIFT WARNING` when `delivery_rate_needed` is 1.5× to 2× typical
   - `⛔ MAJOR DRIFT` when `delivery_rate_needed` > 2× typical

   **This is a display-only step — it does not block progression** (the
   blocking gate is the brief-time Outline Conformance check at step 5a).
   Its purpose is to make cumulative drift visible to the user at every
   chapter boundary, so they can intervene before drift becomes unrecoverable.

   Drift is usually invisible chapter-by-chapter because each new chapter
   is a coherent continuation of the previous one. The health check zooms
   out to "remaining beats vs remaining chapters" — the only view that
   catches slow-accumulating drift.
18. **Update pipeline checkpoint (MANDATORY, BLOCKING, HARD GATE)** —
    Append or update the row for Chapter {N} in
    `engine-data/pipeline-checkpoint.md` with every column populated from
    the completed cycle: `Brief`, `OC Report`, `OC Verdict`, `Banlist
    Loaded`, `Canon Loaded`, `Written`, `Saved`, `Verified (disk)`,
    `Humanised`, `V-Score`, `Canon Check`, `Canon Valid`, `Report Saved`,
    `Summary`. Also update the Word Count Tracker row, the Number-7 Bias
    Tracker running counts, and the Next Action line.

    **Canon Validator gate (runs AFTER checkpoint row is populated,
    BEFORE Progress Dashboard):**
    After writing the checkpoint row, run the Canon Validator (see
    `canon-validator.md`) against the FULL checkpoint — not just Chapter
    N's row, but all content claims in the Flags section and any
    forward-looking claims in earlier rows. This is the post-chapter
    trigger point.

    - If Canon Validator returns PASS: set `Canon Valid` to `Yes` for
      Chapter N and proceed to the Progress Dashboard.
    - If Canon Validator returns WARN: set `Canon Valid` to `warn` for
      Chapter N. Surface warnings in the Progress Dashboard. The next
      chapter may proceed, but 3+ accumulated warns across the
      manuscript trigger a mandatory citation audit at the next batch
      edit boundary.
    - If Canon Validator returns FAIL: set `Canon Valid` to `FAIL` for
      Chapter N. STOP. Correct the failing claims before displaying
      the Progress Dashboard or starting the next chapter. Present the
      Canon Validator report to the user.

    **This step is not optional and not a suggestion:**
    - You MAY NOT display the Progress Dashboard or move to the next
      chapter until the checkpoint row for Chapter {N} has been written
      via the write tool AND Bash ls has confirmed the file on disk.
    - You MAY NOT "narrate" the checkpoint update and proceed. If step 18
      was skipped, Chapter {N+1}'s pre-flight check has no source of truth,
      the OC Report / Banlist Loaded / Canon Loaded gates all read `No`,
      and step 5a / step 6a / step 12 will all fire protocol-violation
      errors when they try to confirm prior-chapter completion.
    - If `engine-data/pipeline-checkpoint.md` does not exist at this point,
      the Phase 2E step was skipped during Phase 2. STOP and run Phase 2E
      (Pipeline State Initialization) before anything else. Do NOT try to
      create a partial checkpoint ad-hoc from chapter state — the v2
      schema must be initialized as a unit.

    **Column-by-column Bash ls verification before marking Yes:**

    Each `Yes` in the checkpoint row must be backed by a prior Bash ls
    that confirmed the corresponding file on disk. The columns and their
    verification paths:

    | Column | Bash ls target |
    |---|---|
    | `Brief: Yes` | `ls -la {path}/engine-data/chapter-briefs/ch{NN}-brief.md` |
    | `OC Report: Yes` | (audit footer embedded in brief — verified by Brief column) |
    | `Written: Yes` | `ls -la {path}/engine-data/chapters/ch{NN}.md` |
    | `Humanised: Yes` | `ls -la {path}/engine-data/chapters/ch{NN}.md` (post-Humaniser overwrite) |
    | `Report Saved: Yes` | `ls -la {path}/engine-data/reports/ch{NN}-verification.md` |
    | `Summary: Yes` | `ls -la {path}/engine-data/summaries/ch{NN}-summary.md` |

    **File-integrity check (MANDATORY — runs AFTER Humaniser, BEFORE
    marking Written/Humanised as Yes):**

    After the Humaniser overwrites `chapters/ch{NN}.md`, run this check
    BEFORE setting the Written or Humanised columns to Yes. This catches
    truncation at the point of creation, not six editorial stages later.

    ```bash
    # 1. Word count vs brief target
    wc -w {path}/engine-data/chapters/ch{NN}.md

    # 2. Terminal punctuation — last non-empty line
    tail -n 5 {path}/engine-data/chapters/ch{NN}.md | grep -v '^\s*$' | tail -1

    # 3. Null byte check
    grep -cP '\x00' {path}/engine-data/chapters/ch{NN}.md
    ```

    **Check 1 — Word count vs target:**
    Compare the actual word count against the brief's target. If actual
    is <90% of target, the chapter is potentially truncated. STOP. Do
    NOT mark Written or Humanised as Yes. Alert the user:
    "Chapter {N} is {actual} words — {percentage}% of the {target}-word
    target. Possible truncation. Verify the chapter ending before
    proceeding."

    **Check 2 — Terminal punctuation:**
    The last non-empty line of the chapter MUST end with terminal
    punctuation: `.` `?` `!` `"` `'` `)` or `—` (dialogue interruption).
    If the last line ends mid-word or with no punctuation, the file is
    truncated. STOP. Do NOT mark Written or Humanised as Yes.

    **Check 3 — Null bytes:**
    If `grep -cP '\x00'` returns >0, the file contains null bytes.
    STOP. Clean the file (strip nulls) and re-verify.

    **If any check fails:** The chapter is BLOCKED. The checkpoint row
    stays incomplete. The Writer or Humaniser must re-run, or the user
    must approve the file manually. Do NOT proceed to the next chapter
    or to editorial with a truncated file on disk.

    Any column whose Bash ls has NOT been run and passed MUST be marked
    `No` (or `-` pending). Do NOT mark `Yes` based on narration, in-memory
    state, or the write tool's return status alone. The pattern is:
    Write → Bash ls → checkpoint Yes. Skip any of those and the column
    stays No.

    After the checkpoint update Write, verify the checkpoint itself:
    ```bash
    ls -la {project-path}/engine-data/pipeline-checkpoint.md
    ```
    (The file already existed from Phase 2E; this is verifying the
    just-written update. A missing file here means the Phase 2E
    checkpoint was deleted or the update Write targeted a different
    path. STOP.)

    The Progress Dashboard (displayed as the next user-facing output
    after this step) reads its values from the row just written — the
    checkpoint is the single source of truth for cross-chapter state.

    **Batch Edit Gate (MANDATORY, BLOCKING — checked at step 18):**

    Before displaying the Progress Dashboard, check whether this chapter
    triggers a batch edit:

    ```
    IF chapter_number % 5 == 0 OR chapter_number == total_chapters:
        batch_edit_required = TRUE
    ELSE:
        batch_edit_required = FALSE
    ```

    **If batch_edit_required is TRUE:**
    - Do NOT display the Progress Dashboard yet.
    - Do NOT present the chapter approval gate.
    - STOP and run step 19 (Batch Deep Edit) FIRST.
    - After the batch edit completes and the Batch Health Report is
      written to `engine-data/reports/batch-{N}-edit.md` (verified
      with Bash ls), update the pipeline-checkpoint with
      `Batch Edit: Yes` for the current batch.
    - ONLY THEN display the Progress Dashboard (which now includes
      the batch-edit results) and present the approval gate.

    **If batch_edit_required is FALSE:** Proceed directly to the
    Progress Dashboard and approval gate. No batch edit needed.

    **Model Health Monitor (MANDATORY — runs BEFORE Progress Dashboard):**

    Read the pre-Humaniser violation counts captured at step 9a and
    aggregate them into `engine-data/model-health.md`. Then check
    against the two-tier thresholds:

    **Tier 1 — WATCH (log + display in dashboard, no stop):**
    - Narration em-dashes in first draft: 3–5
    - "the way" pattern in first draft: 1–2 over cap
    - Forbidden-word hits in first draft: 1–2
    - Writer needed 1 retry to pass word-count check
    - V-Score exactly 100 for THIS chapter (single occurrence)
    - First-draft word count 85–89% of target

    WATCH items surface in the Progress Dashboard under a
    "Model Health" section: "ELEVATED — {metric}: {value}. Watch for
    trend." Do NOT stop the pipeline.

    **Tier 2 — STOP (hard gate, BLOCKING):**

    Any ONE of the following triggers a hard stop:

    - Narration em-dashes in first draft: 6 or more
    - Frame leaks present: ANY occurrence of "Book N", "the reader",
      "the previous chapter", or meta-narrator breaks (zero occurrences
      in 10 prior books — a single occurrence is a reliable signal)
    - Agent name substitution: verification report uses any name NOT
      in the canonical 5 (Continuity Guardian, Quality Guardian,
      Timeline Keeper, Character Tracker, Arc Analyst)
    - V-Score exactly 100 for 2+ consecutive chapters (scoring
      calibration failure — no real manuscript produces this)
    - Writer retry count: 3 or more on any single chapter
    - Write-verify mismatch: bash ls returned "No such file" after
      a write tool call reported success (1+ per session)
    - First-draft violation total (sum of all zero-tolerance categories):
      10 or more

    **On STOP trigger:** Prompt the user with options:
    - **"Continue with current model — acknowledge the risk"** —
      proceed, log the acknowledgement
    - **"Switch model (Opus 4.6 / Sonnet 4.6) and re-run this chapter"** —
      rollback to the pre-Humaniser snapshot, surface instruction to
      user to change model in Kimi, then re-run step 7
    - **"Pause session — report to Moonshot AI"** — stop all further
      work, print the model-health.md summary for the user to copy
      into a bug report

    **This STOP trigger is NOT overridden by `supervised_autopilot`.**
    Even in autopilot mode, a Tier 2 STOP halts the engine and
    requires explicit user acknowledgment before proceeding.

    Do NOT proceed past this gate without a user response. The model-
    health.md file persists across sessions so patterns visible only
    across multiple chapters (e.g., rising V-Score inflation) are
    detectable on session resume.

    **Why this gate exists:** In April 2026, Opus 4.7 produced drafts
    with 9 narration em-dashes, 7 frame leaks, 482-word shortfalls,
    and fabricated V-Scores of 100/100 — none of which occurred in the
    prior 10 books on earlier model snapshots. The mechanical fix
    pipeline was overwhelmed by the constraint-shedding rate. This
    monitor surfaces model regressions BEFORE they compound across a
    manuscript.

19. **Batch deep edit (every 5th chapter, MANDATORY, BLOCKING)** —
   If this chapter number is divisible by 5 (or is the final chapter),
   run the Batch Editor (see `batch-editor.md`). This is a MANDATORY
   deep editorial pass across the last 5 chapters that catches
   cross-chapter drift, accumulating AI-isms, pacing flatlines, and
   prose quality degradation.

   **This step is not optional and not a suggestion:**
   - The Batch Edit Gate at step 18 blocks the Progress Dashboard
     until this step completes. The engine cannot skip it.
   - Do NOT say "Would you like me to run the batch edit?" or "I can
     run a batch review if you'd like." Just run it. The batch edit
     is as mandatory as the Humaniser or verification agents.
   - The batch edit MUST complete before the next chapter begins.
   - It produces a Batch Health Report saved to
     `engine-data/reports/batch-{N}-edit.md` — verified with Bash ls
     before the checkpoint is updated.

   **Batch Edit Output:**
   1. Write the Batch Health Report to
      `engine-data/reports/batch-{N}-edit.md` via the write tool.
   2. Bash ls verification:
      ```bash
      ls -la {project-path}/engine-data/reports/batch-{N}-edit.md
      ```
      If missing, STOP and re-run.
   3. Apply any surgical fixes the batch edit identifies (prose
      corrections go back to `chapters/ch{NN}.md` for each affected
      chapter — Write + Bash ls each).

      **Post-fix verification (MANDATORY — runs AFTER each surgical
      fix is applied):**
      After writing each fixed chapter file back to disk:
      a. **File-integrity check:** Run the standard chapter integrity
         check (wc + tail + grep null) on the modified file. If the
         fix introduced truncation or corruption, STOP and restore
         from the pre-batch-edit snapshot.
      b. **Fix-applied check:** Grep the modified chapter for the
         specific pattern the fix targeted. If the pattern is still
         present, the fix was not applied — re-apply or flag.
      c. **Collateral damage check:** Compare word count of the fixed
         file against the pre-fix version. If delta exceeds ±2%
         (surgical fixes should be minimal), flag: "Batch fix to
         Ch {N} changed word count by {delta}% — verify no
         collateral content was removed."
      Only mark the fix as applied after all three checks pass.

   4. Update the pipeline-checkpoint: `Batch Edit: Yes` for this batch.
   5. Display the Batch Health Report inline in the conversation.
   6. THEN proceed to the Progress Dashboard and approval gate.

#### File Save Gate (MANDATORY, BLOCKING)

Each chapter produces three persisted files — the chapter prose, the
chapter brief, and the chapter summary. Validation happens BEFORE the
write tool is called, not after. Trust the write tool for persistence
(see File Operation Policy above).

```
PRE-WRITE CONTENT CHECKS (run against in-memory content BEFORE saving):

1. Chapter prose (target: engine-data/chapters/ch{NN}.md)
   - Content is non-empty
   - Content starts with "# Chapter {N}:" heading
   - Word count matches expected output (±5%)

2. Chapter brief (target: engine-data/chapter-briefs/ch{NN}-brief.md)
   - Content is non-empty

3. Chapter summary (target: engine-data/summaries/ch{NN}-summary.md)
   - Content is non-empty
   - Contains 3-5 sentences of factual summary

IF ANY CONTENT CHECK FAILS:
- Do NOT call the write tool for that file
- Fix the content in memory and re-check
- If the fix fails: STOP and alert the user in plain language
  ("Chapter 6 prose is missing the chapter heading — regenerating.")

POST-WRITE STATUS CHECK (NOT a Read-back):

After each write tool call, check the write tool's own return status.
- If Write returned without error: the file is on disk. Proceed.
- If Write returned an error: STOP and alert the user in plain language.

NEVER:
- Narrate a save without using the write tool to execute it
- Read the file back "to confirm it exists" (see File Operation Policy)
- Display raw file paths or filenames in user-facing output
```

**SILENT OPERATION:** The File Save Gate is an internal engine check.
Do NOT display raw file paths, filenames, or "Files updated" lists to
the user. The user does not need to see `engine-data/chapters/ch06.md`
or similar paths — these are internal implementation details. The
ONLY user-facing output after a chapter completes is the **Progress
Dashboard** (see below). If all files save successfully, proceed
silently to the next pipeline step. If a save fails, alert the user
in plain language (e.g., "Chapter 6 didn't save correctly — retrying
now.") without exposing file paths.

#### Pipeline Checkpoint

Maintain a persistent checkpoint file that tracks pipeline progress. This file
is the source of truth for what has actually been completed — it survives session
interruption and context compression.

Write to: `Ideorix-Projects/[Title]/engine-data/pipeline-checkpoint.md`

**Update this file after EVERY chapter completes its full cycle** (write → save →
verify → verification agents → score). This is not optional.

```markdown
# Pipeline Checkpoint — {Title}
<!-- schema: ideorix-checkpoint v3 (post-hardening + canon-validator: adds Canon Valid column; see canon-validator.md) -->
Last updated: Chapter {N} — {timestamp}

## Pipeline Status
Phase: {current_phase}
Current chapter: {N} of {total}
Mode: per-chapter verification | batch verification

## Chapter Progress
| Ch | Brief | OC Report | OC Location | OC Verdict | Banlist Loaded | Canon Loaded | Written | Saved | Verified (disk) | Humanised | V-Score | Canon Check | Canon Valid | Report Saved | Summary |
|----|-------|-----------|-------------|------------|----------------|--------------|---------|-------|-----------------|-----------|---------|-------------|-------------|--------------|---------|
| 1  | Yes   | Yes       | inline      | PASS       | n/a (first ch) | Yes          | Yes     | Yes   | Yes             | Yes       | 94      | clean       | Yes         | Yes          | Yes     |
| 2  | Yes   | Yes       | inline      | WARN       | n/a (first ch) | Yes          | Yes     | Yes   | Yes             | Yes       | 88      | clean       | Yes         | Yes          | Yes     |
| 3  | Yes   | Yes       | inline      | PASS       | Yes            | Yes          | No      | -     | -               | -         | -       | -           | -           | -            | -       |

**OC Report column rules:** The OC Report column MUST be "Yes" before the
brief for that chapter is presented to the user at step 6. A row that shows
Brief=Yes but OC Report=No indicates step 5a was skipped — this is a
protocol violation; stop and run the Outline Conformance Agent before doing
anything else with that chapter. The OC Verdict column records the brief-time
verdict (PASS / WARN / FAIL) and feeds the post-chapter Progress Dashboard's
"Outline Conformance" line.

- **OC Location**: `inline` if the OC audit fit in the brief footer;
  `separate` if the FAIL detail was written to
  `engine-data/reports/ch{NN}-oc-detail.md` due to overflow. Pre-Flight
  reconciliation uses this field to know which file to verify on disk.

**Banlist Loaded column rules:** The Banlist Loaded column MUST be "Yes"
before the Writer generates any prose for that chapter (step 7). A row that
shows OC Verdict populated but Banlist Loaded=No indicates step 6a was
skipped — this is a protocol violation; stop and run the Writer Pre-Load
before proceeding. Chapters 1 and 2 use "n/a (first ch)" because the
banlist has no promoted entries yet (patterns need 2+ chapters to be
promoted). From Chapter 3 onwards, Banlist Loaded must be "Yes" before
the Writer runs.

**Canon Loaded column rules:** The Canon Loaded column MUST be "Yes" before
the Writer generates any prose for that chapter (step 7, Step B of the
pre-load). Unlike Banlist Loaded, Canon Loaded applies from Chapter 1
onwards — the Entity Canon exists from Phase 2 (Story Bible generation)
and every chapter needs it. A row with Canon Loaded=No means step 6a Step B
was skipped or engine-data/entity-canon.md is missing. STOP and run the
World Canon's Phase 2D protocol if the file doesn't exist, or re-run the
pre-load if it does.

**Canon Check column rules:** The Canon Check column records the output of
the Continuity Guardian's Canon Compliance Check (see `quality-gate.md`)
for that chapter. Values:
- `clean` — every proper noun in the chapter matched an entry in
  entity-canon.md
- `{N} drift` — {N} name-shaped tokens in the chapter did NOT match the
  canon; Continuity Guardian flagged each one. The user reviews the
  drifted names and either adds them as aliases of existing entities,
  declares them new entities (pending approval), or requests a prose
  rewrite to fix the drift
- `blocked` — the Continuity Guardian could not run the check because
  entity-canon.md was missing or unreadable
Canon Check is populated AFTER verification (step 12) and flows into the
post-chapter Progress Dashboard's "Canon Drift" line.

**Canon Valid column rules:** The Canon Valid column records the output of
the Canon Validator agent (see `canon-validator.md`) for that chapter.
Values:
- `Yes` — all content claims in the checkpoint passed validation against
  the Story Bible's aggregate truth tables and Section 12
- `warn` — no FAIL claims, but 1+ claims are uncited, sourced from working
  notes, or inference-based. The user sees warnings in the Progress
  Dashboard. 3+ accumulated warns trigger a mandatory citation audit at the
  next batch edit boundary
- `FAIL` — 1+ content claim contradicts an aggregate table or Section 12.
  The checkpoint update is BLOCKED until the failing claims are corrected
Canon Valid is populated at step 18 (post-chapter, after the checkpoint row
is written) by the Canon Validator agent. It is also checked at step 4b
(pre-brief) for claims implicating the upcoming chapter.

## Word Count Tracker
| Ch | Target | Actual | % | Status |
|----|--------|--------|---|--------|
| 1  | 2500   | 2380   | 95% | OK |
| 2  | 2500   | 2210   | 88% | Soft miss |
Running average: {avg}% of target

## Batch Edit Status
| Batch | Chapters | Status | Score | Weakest Ch | Fixes Applied |
|-------|----------|--------|-------|------------|---------------|
| 1     | 1-5      | Done   | 87    | Ch 3       | 4             |
| 2     | 6-10     | Due    | -     | -          | -             |

## Number-7 Bias Tracker (Manuscript-Wide)
Total numbers in manuscript: {count}
Numbers ending in 7: {count} ({percentage}%)
Status: {OK if ≤15% | WARNING if 15-25% | CRITICAL if >25%}
Manuscript-wide threshold: ≤15% of all numbers should end in digit 7.
If approaching limit, prioritise replacing 7-ending numbers in next chapter.

## Flags
- {any patterns approaching limits — including number-7 bias}
- {any persistent shortfalls}
- {batch editor feed-forward notes for next batch}

## Next Action
{what should happen next — e.g., "Write Chapter 3 using brief at ch03-brief.md"}
```

**Recovery protocol:** When returning to a project or starting a new session,
read the pipeline checkpoint FIRST. It tells you exactly where to resume.

#### Model Health Monitor File

Write to: `Ideorix-Projects/[Title]/engine-data/model-health.md`

This file accumulates per-chapter telemetry on model behaviour. It is
updated at step 18 (after pre-Humaniser violation capture) and read at
step 18 for threshold checking. Persists across sessions so trend
patterns are visible on resume.

```markdown
# Model Health Monitor — {Title}
<!-- schema: ideorix-model-health v1 -->
Last updated: Chapter {N} — {timestamp}
Model at last update: {model ID from Kimi, e.g. kimi-k2-0711-longcontext}

## Per-Chapter First-Draft Telemetry

Captured at step 9a BEFORE the Humaniser runs. These are raw model
outputs — violation counts against zero-tolerance rules.

| Ch | Model | Narr em-dash | Frame leaks | "the way" | "which was" | Forbidden hits | Writer retries | Word-count % | V-Score |
|----|-------|--------------|-------------|-----------|-------------|----------------|----------------|--------------|---------|
| 1  | opus-4-6 | 0 | 0 | 2 | 0 | 0 | 0 | 98% | 92 |
| 2  | opus-4-6 | 1 | 0 | 4 | 1 | 0 | 0 | 101% | 89 |

## Threshold Status

- WATCH triggers: {count, with details}
- STOP triggers: {count, with details}
- Last acknowledgement: {timestamp + user choice, if any}

## Trend Flags

- {Any 3-chapter rising trend in violations}
- {Any agent name substitutions logged}
- {Any write-verify mismatches this session}
- {Any model changes mid-project}

## Session Change Log

- {timestamp} — Model changed from {X} to {Y} (user-initiated)
- {timestamp} — STOP gate triggered on Ch {N}: {reason}
- {timestamp} — User chose: {continue / switch / pause}
```

**Interpretation:**

- Normal manuscript: most chapters show 0–2 narration em-dashes, 0 frame
  leaks, "the way" under cap, 0 forbidden hits, 0 retries, word count
  90–110% of target, V-Score 85–96 range.
- Model health concern: any frame leaks, multiple narration em-dashes,
  V-Score clustering at 100, or rising violation trend across chapters.
- Use this file as evidence when reporting model regressions to
  Moonshot AI — it provides per-chapter data with exact counts and
  model IDs.

**Pre-flight check (MANDATORY before starting any new chapter):**
Before running the Architect for Chapter N+1, perform this check.
The check reads `pipeline-checkpoint.md` ONCE and trusts its recorded
field values. Do NOT Read individual report files to verify existence
(see File Operation Policy above — the checkpoint is the
authoritative cross-chapter status ledger).

1. Read `engine-data/pipeline-checkpoint.md` — this is the only Read
   required for pre-flight.
2. For the MOST RECENT chapter (N), confirm ALL of these are "Yes":
   - Brief: Yes
   - OC Report: Yes
   - Banlist Loaded: Yes (or "n/a (first ch)" for Chapters 1-2)
   - Canon Loaded: Yes
   - Written: Yes
   - Saved: Yes
   - Verified (disk): Yes
   - Humanised: Yes
   - Report Saved: Yes
   - Summary: Yes
3. Confirm V-Score is populated (not "-" or blank)
4. Confirm OC Verdict is populated (PASS / WARN / FAIL — not "-" or blank)
5. Confirm Canon Check is populated (clean / {N} drift — not "-" or blank).
   If Canon Check shows drift that the user has not resolved, STOP and
   surface the unresolved drift to the user before starting Chapter N+1.
6. Confirm Canon Valid is populated (Yes / warn / FAIL — not "-" or blank).
   If Canon Valid is "FAIL", the checkpoint contains content claims that
   contradict the Story Bible's aggregate tables. STOP — resolve the
   failing claims before starting Chapter N+1. If Canon Valid is "warn",
   note the warning count; if 3+ warns have accumulated across the
   manuscript, flag for mandatory citation audit at next batch boundary.

**Pre-Flight file reconciliation (MANDATORY — runs BEFORE trusting
checkpoint fields):**

The checkpoint may lie. If a write was dropped after the checkpoint
was updated, or if a Kimi restart occurred between write and
sync, a field says "Yes" but the file is gone. Before trusting the
checkpoint, verify the actual files:

For each checkpoint field marked "Yes" on the previous chapter (N):

```bash
# Brief
ls -la {path}/engine-data/chapter-briefs/ch{NN}-brief.md && \
stat -c %s {path}/engine-data/chapter-briefs/ch{NN}-brief.md

# Chapter
ls -la {path}/engine-data/chapters/ch{NN}.md && \
stat -c %s {path}/engine-data/chapters/ch{NN}.md

# Verification report
ls -la {path}/engine-data/reports/ch{NN}-verification.md && \
stat -c %s {path}/engine-data/reports/ch{NN}-verification.md

# Summary
ls -la {path}/engine-data/summaries/ch{NN}-summary.md && \
stat -c %s {path}/engine-data/summaries/ch{NN}-summary.md
```

If ANY file is missing or zero-bytes:
1. Flip the corresponding checkpoint field back to "No"
2. Log a reconciliation event to `engine-data/run.log`
3. Alert the user: "Pre-flight reconciliation: {file} is missing from
   disk despite checkpoint marking it complete. Re-running {step}."
4. Re-run the failed step before allowing Chapter N+1 to start

Pre-Flight Check passes ONLY when every field is "Yes" AND every
referenced file passes existence + non-zero-byte checks.

The checkpoint's fields were set by each pipeline step as it completed.
However, a write may have been dropped after the checkpoint was
updated. The reconciliation step above catches this. Trust the
checkpoint. If any field is missing or blank, that's a signal the
corresponding step did not complete — investigate the missing step,
don't Read individual files to "verify" them.

**If ANY field is "No", "-", or blank:** STOP. Do not start Chapter N+1.
Complete the missing step for Chapter N first. Alert the user:
"Chapter {N} has incomplete pipeline steps: {list missing}. Completing
these before starting Chapter {N+1}."

**If the checkpoint file doesn't exist:** STOP. The pipeline state is unknown.
Alert the user and reconstruct by scanning existing files in engine-data/.

This pre-flight check catches sessions where verification was skipped due to
context loss, session restart, or pipeline violation. It is the engine's
primary defence against compounding errors.

### PHASE 4: VERIFICATION (runs automatically after each chapter)

See `quality-gate.md` for the 6 agent protocols (7 for series projects).

**DEFAULT BEHAVIOUR — Per-chapter verification:**
After EVERY chapter is written (and humanised), automatically run all 6 verification
agents before proceeding to the next chapter. Do NOT wait for the user to request this.
This is the standard pipeline — it prevents error accumulation across the manuscript.

- All 6 agents analyse the chapter (7 if series project — see below)
- Each returns structured report with scores and issues
- Cross-agent analysis flags contradictions
- Issues above severity threshold → fix before next chapter
- Only proceed to the next chapter when the chapter scores ≥80 or user approves exceptions

**Series Projects — 6th Verification Agent:**
If `engine-data/series-bible.md` exists (project is part of a planned series),
ALSO run Agent 6: Series Continuity Guardian on every chapter. This agent
validates cross-volume consistency: spine question advancement, character
trajectory alignment, arc weave thread status, long-range gun tracking, and
series canon violations. See `quality-gate.md` Agent 6 for the full protocol.

When the 6th agent is active, the weighted scoring formula changes:
```
Standard (6 agents):  Continuity×0.20 + Quality×0.15 + Timeline×0.15 + Character×0.20 + Arc×0.15 + Dialogue×0.15
Series (7 agents):    Continuity×0.15 + Quality×0.15 + Timeline×0.10 + Character×0.15 + Arc×0.10 + Dialogue×0.15 + Series×0.20
```

The progress dashboard must include the Series score when the 6th agent is active.

**Verification Report Gate (MANDATORY, BLOCKING):**
After all 6 (or 7) agents complete and the cross-agent score is calculated:

1. Save the consolidated report to `engine-data/reports/ch{NN}-verification.md`
   using the write tool. The Write MUST run in the parent conversation —
   sub-agent dispatch is forbidden for file-writing steps (see File
   Operation Policy).
2. **Bash ls verification (MANDATORY):**
   ```bash
   ls -la {project-path}/engine-data/reports/ch{NN}-verification.md
   ```
   If ls returns "No such file or directory", the write tool was not
   invoked. STOP. Re-run the Write in the parent conversation and
   re-verify. Do NOT mark the checkpoint `Report Saved` column Yes
   until Bash ls confirms the file on disk.
3. If score < 80: STOP — apply fixes before proceeding to next chapter.
4. If the write tool returned an error OR Bash ls fails after a retry:
   STOP and alert the user in plain language ("Chapter {N} verification
   report failed to save — the 6-agent findings are in conversation
   only; please copy them before proceeding.").
5. Update the pipeline checkpoint with the score and "Report Saved: Yes"
   only after Bash ls has confirmed the file on disk.
   The checkpoint is the cross-chapter status ledger.
5. **Display to the user in this order (post-chapter presentation
   protocol):**
   a. **Progress Dashboard** first (see Progress Dashboard below).
   b. **6-agent verification summary** — a compact view showing each
      agent's verdict + top findings. Full report is in the file;
      summary is for user review.
   c. **Chapter approval gate** — prompt the user with options:
      "Approve — move to Chapter {N+1}", "Request revisions", "Read
      chapter in full".

      **Autopilot override (when `project_mode: supervised_autopilot`):**
      Read `engine-data/project-config.md` for `project_mode`. If set to
      `supervised_autopilot`, SKIP the interactive approval prompt when
      ALL of the following hold:
      - Weighted V-Score ≥ 80
      - No CRITICAL issues in any agent report
      - Word count ≥ 90% of target (no hard miss)
      - Model Health Monitor is at WATCH tier or below (no Tier 2 STOP)
      - Canon Validator shows PASS (no canon drift blocking)

      If all conditions pass: display the dashboard, append a line
      "[AUTO-APPROVE] Chapter {N} — V-Score {score}/100 — proceeding to Chapter {N+1}"
      to the conversation, update the checkpoint, and proceed directly
      to the next chapter's Architect brief WITHOUT waiting for user input.

      If ANY blocking condition is met (score < 80, CRITICAL issues,
      hard word-count miss, Tier 2 STOP, Canon FAIL): the autopilot
      YIELDS. Present the full dashboard, explain which condition
      triggered the stop, and prompt the user with the standard
      approval-gate options. The user must explicitly approve before
      the engine continues.
   d. **Do NOT auto-display the full chapter prose after the dashboard.**
      The user has already seen the prose during the Humaniser's
      in-conversation display. Auto-re-displaying 1,500-3,000 words of
      prose after the dashboard wastes the user's scroll time and
      obscures the verification summary. If the user picks "Read
      chapter in full" at the approval gate, THEN display the prose
      on-demand.

   **Post-chapter presentation format (summary block):**

   ```
   6-Agent Verification Summary — Chapter {N}

   Continuity Guardian   : {PASS/WARN/FAIL} — {one-line finding}
   Quality Guardian      : {PASS/WARN/FAIL} — {one-line finding}
   Timeline Keeper       : {PASS/WARN/FAIL} — {one-line finding}
   Character Tracker     : {PASS/WARN/FAIL} — {one-line finding}
   Arc Analyst           : {PASS/WARN/FAIL} — {one-line finding}

   Overall score: {N}/100
   Full report: engine-data/reports/ch{NN}-verification.md
   ```

   Then present the approval gate. The full chapter prose is NOT
   auto-displayed — user requests it explicitly via "Read chapter in
   full".

#### Progress Dashboard (MANDATORY — display after EVERY chapter)

After each chapter completes its full pipeline cycle, display this dashboard
to the user. This is NOT optional. It MUST appear in the conversation output
after every single chapter, including late chapters when context is compressed.

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Chapter {N} of {total}: "{chapter_title}"  ✓ COMPLETE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Score: {weighted_score}/100
  ┌──────────────────────────────────────┐
  │ Continuity:  {score}  │ Quality:   {score}  │
  │ Timeline:    {score}  │ Character: {score}  │
  │ Arc:         {score}  │                     │
  └──────────────────────────────────────┘
  Words: {actual}/{target} ({percentage}%)
  Issues: {critical} critical · {moderate} moderate · {minor} minor
  Beat: "{beat_name}" — {delivered|partial|missed}
  Guns: {status summary}
  Outline Conformance: {verdict} (brief-time, pre-Writer)
  Canon Drift: {clean | {N} drift | blocked} (Continuity Guardian)

  Progress: [{filled_bar}{empty_bar}] {N}/{total} chapters
  Running avg score: {avg}  |  Running avg words: {word_avg}%
  {batch_status — e.g., "Batch 1 of 6 — deep edit due after Ch 5"}

  Next: Chapter {N+1}: "{next_title}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Enforcement rules:**
- This dashboard MUST be output as text in the conversation — not just saved to a file
- If context is compressed and prior dashboards are lost, the current dashboard
  still MUST appear. Read the pipeline checkpoint to reconstruct running averages.
- The dashboard is the user's primary signal that the engine is working correctly.
  Skipping it — even once — erodes user confidence. This was the single biggest
  usability failure in testing: progress output disappeared in the second half
  of the manuscript.
- **MINIMUM DISPLAY REQUIREMENT:** The progress dashboard is the user's ONLY
  evidence that verification ran. If the user does not see a formatted dashboard
  with all 6 agent scores, word count, issue counts, and the progress bar, the
  verification step has FAILED regardless of what happened internally. A dashboard
  that omits scores or shows partial data is also a failure. Display the complete
  dashboard every time.
- The batch status line shows which batch the chapter belongs to and when the
  next deep edit is due (see `batch-editor.md`).
- The **Outline Conformance** line is read from the pipeline-checkpoint's
  `OC Verdict` column for the current chapter (populated at step 5a by
  the Outline Conformance Agent — see step 5a execution procedure).
  This line is **informational only** — it does NOT contribute to the
  weighted Score. Its purpose is traceability: the user can see at a
  glance that the brief-time check ran and what it found, alongside
  the chapter's post-writing scores. Format:
    - `PASS` — brief conformed cleanly
    - `WARN — {N} soft issues` — brief shipped with flagged issues
    - `FAIL — user override (Story Bible updated)` — user kept the brief
       and Section 12 was updated
    - `FAIL — user override (brief kept as-is)` — user explicitly kept a
       non-conforming brief without updating Section 12
    - `FAIL — brief revised` — the original brief was revised and re-ran
       conformance before writing (shows the final verdict)
    - `n/a (pre-Outline-Conformance chapter)` — chapter was produced before
       the Outline Conformance Agent existed
  The checkpoint already has the verdict; the dashboard reads it from
  there. Do NOT Read the OC report file itself for this purpose (see
  File Operation Policy above — we trust the checkpoint). Do NOT re-run
  the conformance agent at post-chapter time — it runs at brief-time only.

**OPT-IN ALTERNATIVE — Batch mode:**
Only if the user explicitly requests batch verification (e.g., "skip checks and write
all chapters first"), run verification on the full manuscript after all chapters are
complete. This is faster but continuity errors may compound. The user must opt in —
batch mode is NEVER the default.

#### Chapter Quality Report (on-demand from Step 7a)

When the user selects **"Run chapter quality report"** at the prose approval gate,
execute the following protocol BEFORE the user makes their approve/revise decision:

**Single-chapter report (default):**

1. Run all 5 verification agents on the current chapter draft:
   - Continuity Guardian — contradictions with Story Bible, prior chapters, character knowledge
   - Quality Guardian — prose quality against 7 Craft Commandments, genre fit, AI-ism density
   - Timeline Keeper — temporal logic, event sequencing, time-of-day consistency
   - Character Tracker — behaviour consistency, voice differentiation, motivation alignment
   - Arc Analyst — beat delivery, tension curve, structural pacing
2. Compile a consolidated report with:
   - Overall weighted score (0–100)
   - Individual agent scores
   - Top 3 strengths (what's working well)
   - All issues ranked by severity (critical → moderate → minor)
   - Specific quotes and line references for each issue
   - Recommended fixes (actionable, not vague)
3. Display the report inline in the conversation (not just saved to file)
4. Save the report to `engine-data/reports/ch{NN}-preview-report.md`
5. Re-present the approval gate with options: "Approve — continue to verification",
   "Request revisions", "Rewrite from brief"

**Full batch editorial review (at 5-chapter boundaries):**

If the current chapter is the last in a 5-chapter batch (chapter number divisible by 5)
or is the final chapter of the manuscript, the quality report automatically expands to
include a full batch editorial review:

1. Run the single-chapter report as above
2. Run the Batch Editor (see `batch-editor.md`) across all chapters in the current batch
3. Present a **Batch Health Report** covering:
   - Cross-chapter continuity drift (are facts shifting between chapters?)
   - Pacing analysis (are chapters accelerating/decelerating appropriately?)
   - Voice consistency (is the narrative voice steady or wandering?)
   - AI-ism accumulation (are banned patterns creeping back in across the batch?)
   - Arc progression (are story beats landing on schedule?)
   - Character arc tracking (are character arcs advancing as planned?)
   - Weakest chapter in the batch (with specific improvement recommendations)
   - Batch-level score (0–100) alongside individual chapter scores
4. Display both reports (chapter + batch) inline in the conversation
5. Save the batch report to `engine-data/reports/batch-{N}-health-report.md`
6. Re-present the approval gate with options: "Approve — continue to next batch",
   "Request revisions to this chapter", "Rewrite from brief"

### PHASE 5: EDITORIAL PIPELINE

See `editorial-suite.md` for full editorial protocols.

**Pre-editorial file-integrity gate (MANDATORY, BLOCKING — runs BEFORE
Stage 0):**

Before any editorial agent touches the manuscript, verify every chapter
file on disk is complete. This gate catches truncations that survived
the per-chapter check at step 18 (e.g., files corrupted between chapter
completion and editorial start, or legacy chapters written before the
step 18 integrity check existed).

For EACH chapter file in `engine-data/chapters/`:

```bash
# 1. Word count
wc -w {path}/engine-data/chapters/ch{NN}.md

# 2. Last non-empty line
tail -n 5 {path}/engine-data/chapters/ch{NN}.md | grep -v '^\s*$' | tail -1

# 3. Null bytes
grep -cP '\x00' {path}/engine-data/chapters/ch{NN}.md
```

| Check | PASS | FAIL |
|---|---|---|
| Word count | ≥90% of brief target for that chapter | <90% of target → potential truncation |
| Terminal punctuation | Last line ends with `. ? ! " ' ) —` | Mid-word cutoff or no punctuation |
| Null bytes | 0 matches | >0 matches → file corruption |

**If ANY chapter fails ANY check:** STOP. Do NOT proceed to Stage 0.
List all failing chapters with their specific failures. The user must
approve recovery (re-run Writer, restore from snapshot, or manually
verify) before editorial begins.

**Report format:**
```
PRE-EDITORIAL INTEGRITY CHECK
Chapters scanned: {N}
Passed: {N}
Failed: {N}

{For each failure:}
  Ch {NN}: FAIL — {reason} (actual: {value}, expected: {value})
```

Run on complete manuscript (ALL 12 stages — see `editorial-suite.md` for full protocols):

**Voice & Genre Foundation:**
0. Voice Profile — build forensic voice profile BEFORE any editing begins
1. Genre-Specific Audit (from genre bank — e.g., outline adherence for mysteries)

**Mechanical Editing:**
2. Proofreader pass
3. Copy Editor pass

**Structural Assessment:**
4. Dev Editor assessment
5. Alpha Reader experience
6. Beta Reader assessment
7. Conflict resolution (surface contradictions between agents)

**Surgical Fixes & Audit:**
8. Apply top fixes surgically (checked against Voice Profile)
9. Full-Manuscript Continuity Audit (master reference tables)

**Conditional Stages (run based on manuscript characteristics):**
10. Intimate Scene Review — CONDITIONAL: runs if manuscript heat level > 0 or
    contains romantic/intimate content at any level. Checks emotional authenticity,
    show-vs-tell at heightened standards, pacing/rhythm, cliché purge, physical
    realism, and emotional closure. See `editorial-suite.md` Stage 11.
11. Multi-POV Pass — CONDITIONAL: runs if manuscript has multiple POV characters.
    Checks voice distinction, timeline consistency, information boundaries.
12. Revision Loop — CONDITIONAL: runs if Alpha stars < 4.75 or Beta stars < 4.5
    or Genre Authenticity < 90%. Automated iterative refinement until convergence.

**Final Gate:**
13. Publication Readiness Assessment — final review confirming manuscript meets
    professional publishing standards before delivery.

### Handoff Protocol — Standard Sequence for Completed Manuscripts

This is the required sequence before any manuscript is considered
done — run it after the final chapter and before PHASE 6 Delivery:

7.1 **Chapter-by-chapter targeted pass** — fix all known bible errors
 (character facts, timeline dates, canonical counts, named
 quantities). Work chapter by chapter; this pass is surgical and
 fast.

7.2 **Canonical-fact sweep** — run regex searches across all chapter
 files for every canonical fact in the Story Bible (years, ages,
 dates, counts, names, rates). This catches survivors the targeted
 pass missed. Use `grep -ra` to handle non-standard file encodings.
 This is a canonical-fact sweep, NOT an em-dash / forbidden-word
 mechanical cleanup.

7.3 **Full editorial pipeline — run EVERY stage** — run the complete
 pipeline (PHASE 5, `editorial-suite.md`) end-to-end to confirm
 cohesion after the targeted fixes and catch anything the chapter
 pass and grep sweep both missed. The pipeline reads the whole
 manuscript; the chapter pass reads in isolation — they catch
 different classes of error.

 A Step 7.3 section that contains only em-dash and forbidden-word
 fixes has NOT run the editorial pipeline.

 Enumerate every stage with a verdict (PASS / WARN / FAIL / SKIPPED):

 | Stage | Name | Verdict |
 |-------|------|---------|
 | 0 | Voice Profile | |
 | 1 | Genre-Specific Audit | |
 | 2 | Proofreader | |
 | 3 | Copy Editor | |
 | 4 | Developmental Editor | |
 | 4.5 | Repetition Sweep | |
 | 5 | Alpha Reader | |
 | 6 | Beta Reader | |
 | 7 | Conflict Resolution | |
 | 8 | Apply Top Fixes | |
 | 9 | Full-Manuscript Continuity Audit | |
 | 10 | Multi-POV Consistency Pass | |
 | 11 | Intimate Scene Review | |
 | 12 | Revision Loop | |

7.4 **Apply advisory fixes** — review the pipeline report's advisory
 items and apply any that improve the manuscript. These are
 non-blocking but should be actioned before handoff.

**Handoff checklist + gate (MANDATORY):**

The orchestrator MUST produce `engine-data/reports/handoff-checklist.md`
recording all four steps. The Step 7.3 section MUST enumerate every
editorial stage with a verdict. The checklist ends with a single
status line — `HANDOFF STATUS: COMPLETE` or `HANDOFF STATUS:
BLOCKED`. Then run: `bash scripts/handoff-gate.sh "{project-root}"`.
The gate fails-closed if the checklist is missing, if Step 7.3
enumerates fewer than 14 editorial stages, if any FAIL is
unresolved, or if the status line is not COMPLETE.

**Audit FAILs are blocking (not advisory):**

Any per-chapter audit FAIL surfaced during the protocol — word
count below 90% of target, forbidden-words, integrity, etc. — is a
BLOCKING decision item, not an advisory. Resolution is binary: fix
the chapter, OR record an explicit waiver in the handoff checklist
with a stated reason. Do NOT silently downgrade an audit FAIL to
"advisory". The gate checks every FAIL carries a RESOLVED/WAIVED
resolution.

This sequence is mandatory for multi-book series and strongly
recommended for standalone novels.

**Scope (MANDATORY — whole-volume operation):**

The Handoff Protocol operates on a COMPLETE volume — every chapter
of the manuscript, run after the final chapter. Steps 2 and 3 are
whole-manuscript by definition: the grep sweep spans every chapter
file, and the editorial pipeline reads the entire manuscript
(Developmental Editor, Alpha Reader, Beta Reader, and the
cross-manuscript consistency stages cannot operate on a single
chapter).

If the protocol is invoked on a partial scope — a single chapter or
a subset of chapters — the engine MUST refuse rather than degrade.
Respond:

> "The Handoff Protocol runs on a complete volume, after the final
> chapter. You've scoped it to a partial selection. Either run it on
> the full volume, or — for a one-off chapter check — ask for a
> standard per-chapter audit outside the protocol (the chapter audit
> plus whichever editorial agents you want)."

Do NOT silently degrade steps 2–4 to single-chapter substitutes, and
do NOT relabel a per-chapter mechanical pass as the editorial
pipeline. A partial-scope run presented as a completed Handoff
Protocol is a success-claim / success-fact divergence — the exact
failure shape documented in the Silent-Failure Audit below.

### PHASE 6: DELIVERY

See `format-docx.md` and `publishing-formats.md`.

1. Generate .docx manuscript with proper formatting
2. Generate KDP metadata .docx
3. Save all outputs to workspace folder
4. Present final summary with:
   - Word count and chapter count
   - Average quality scores across all chapters
   - Editorial highlights
   - Any remaining issues flagged but not fixed
5. **Cover Design Notification** — After presenting the final summary, notify the user:

   ```
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   YOUR MANUSCRIPT IS COMPLETE!

   Ready to design your book cover?

   The Cover Designer can create market-researched, genre-accurate
   cover concepts with prompts for Ideogram, Leonardo.ai, Grok Aurora,
   and Midjourney — plus print-ready specifications.

   To start: Say "design my cover" or "create a cover concept"

   What it produces:
   - Full visual concept with colour palette and typography
   - AI image prompts for 4 platforms (copy-paste ready)
   - Print specifications (trim size, spine width, bleed)
   - Back cover and wraparound designs
   - 2 alternative concept directions

   You can also do this later — your manuscript data is saved.
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   ```

### PHASE 7: PUBLISHING STUDIO (Optional — On Demand)

This phase is triggered by user request, NOT automatically after delivery.
All Publishing Studio tools consume the Story Bible and manuscript data.

#### Cover Designer (`cover-designer.md`)

1. **Market research** — Live web search for current bestseller cover trends
2. **Context assembly** — Book info, Story Bible, genre aesthetics from genre bank
3. **Concept generation** — Full cover concept with:
   - Visual concept, composition, and colour palette
   - Typography recommendations
   - AI image prompts for 4 platforms (Ideogram, Leonardo, Grok Aurora, Midjourney)
   - Front cover, back cover, and wraparound variants
   - Print specifications calculated from manuscript word count

#### Marketing Expert (`marketing-expert.md`)

1. **Market research** — Live web search for current marketing copy trends
2. **Material generation** — 10 material types:
   - Retail: Amazon description, back cover blurb, keywords & categories
   - Pitching: Elevator pitch, query letter, comparison titles
   - Digital: Social media pack (Twitter, Instagram, Facebook, TikTok, LinkedIn), email newsletter, press release
   - Strategy: Target audience analysis
3. **Tone selection** — Professional, conversational, urgent, mysterious, emotional, or witty
4. Save materials to `Ideorix-Projects/[Title]/marketing/marketing-brief.docx`

#### Video Trailer Designer (`video-trailer-designer.md`)

1. **Market research** — Live web search for current book trailer trends
2. **Storyboard generation** — Scene-by-scene trailer with:
   - 3–9 scenes (30s / 60s / 90s duration options)
   - Per-scene AI video prompts for 5 platforms (Sora, Runway, Pika, Luma, Kling)
   - 8 visual styles (cinematic, atmospheric, character-focused, etc.)
   - Post-production guidance: text overlays, music, transitions, export settings
4. **User review** — Present concept, allow iteration on style/direction
5. Save storyboard to `Ideorix-Projects/[Title]/marketing/trailer-storyboard.docx`

**Genre integration:** The genre bank file's `## Cover Design Specifications` section
provides genre-specific aesthetics, colour palettes, visual motifs, and subgenre
variations that feed into the cover concept.

## Skill Loading Protocol

Skills are loaded in tiers to keep the context window lean. Only Tier 1 skills
are always active. Tier 2 skills are read on-demand at the pipeline phase that needs them.

### Tier 1 — Always Active (auto-loaded with this skill)
| Skill | File | Purpose |
|-------|------|---------|
| Core Pipeline | `core-pipeline.md` | This file — orchestrates everything |
| Craft Standards | `craft-standards.md` | Universal prose rules (7 Commandments) |
| Forbidden Words | `forbidden-words.md` | ~1,170 AI-telltale words/phrases |
| Authenticity Guard | `authenticity-guard.md` | Name/pattern avoidance |

### Tier 2 — Load On Demand
Read these files ONLY when their pipeline phase is reached:

| Phase | Skill to Load | File |
|-------|--------------|------|
| Phase 0 (Series) | Series Architect | `series-architect.md` |
| Phase 0 (Series) | Series Conventions | `series-conventions.md` |
| Phase 1 (Setup Q9) | Market Scout | `market-scout.md` |
| Phase 1 (Setup Q9) | Outline Builder | `outline-builder.md` |
| Phase 2 (Pre-Bible) | Market Scout (if not already run) | `market-scout.md` |
| Phase 2 (Story Bible) | Character Name Generator | `character-name-generator.md` |
| Phase 2 (Story Bible) | Company Name Generator | `company-name-generator.md` |
| Phase 1 (Setup Q5) | Trope Library | `trope-library.md` |
| Phase 1 (Setup Q10) | Beat Structures | `beat-structures.md` |
| Phase 1 (Setup Q11) | Chekhov's Guns | `chekhovs-guns.md` |
| Phase 2 (Story Bible) | World Canon | `world-canon.md` |
| Phase 2.5 (Story Bible Only) | Writer's Companion | `writers-companion.md` |
| Phase 3 (Generation) | Architect Protocol | `blueprint-agent.md` |
| Phase 3 (Brief-time) | Outline Conformance Agent | `outline-conformance.md` |
| Phase 3 (Generation) | Writer Protocol | `prose-agent.md` |
| Phase 3 (Post-Write) | Prose Humaniser | `prose-humaniser.md` |
| Phase 3 (Revision) | Surgical Fixes | `surgical-fixes.md` |
| Phase 3 (Every 5th ch) | Batch Editor | `batch-editor.md` |
| Phase 4 (Verification) | Quality Gate | `quality-gate.md` |
| Phase 5 (Editorial) | Editorial Suite | `editorial-suite.md` |
| Phase 5 (Editorial, optional supplement to Copy Editor) | Line Editor | `line-editor.md` |
| Phase 6 (Delivery) | DOCX Format | `format-docx.md` |
| Phase 6 (Delivery) | Publishing Formats | `publishing-formats.md` |
| Phase 7 (Cover) | Market Scout | `market-scout.md` |
| Phase 7 (Cover) | Cover Designer | `cover-designer.md` |
| Phase 7 (Marketing) | Market Scout | `market-scout.md` |
| Phase 7 (Marketing) | Marketing Expert | `marketing-expert.md` |
| Phase 7 (Trailer) | Market Scout | `market-scout.md` |
| Phase 7 (Trailer) | Video Trailer Designer | `video-trailer-designer.md` |
| On Request | Story Analysis | `story-analysis.md` |

> **Rule:** When a phase begins, read its Tier 2 skill file(s) from `/app/.user/skills/ideorix/references/`.
> Do NOT pre-load all skills at once — this wastes context on protocols not yet needed.

## Genre Bank Loading Protocol

**Custom genre precedence (checked FIRST for every genre slot, single or mash-up):**

Before reading a genre from the built-in bank, check for user-authored
custom genres at these locations in order:

1. **Project-local custom-genres:** `~/Documents/Ideorix-Projects/{Title}/engine-data/custom-genres/{slug}.md`
2. **Persistent library:** `~/Documents/Ideorix-Projects/.genre-library/{slug}.md`
3. **Built-in bank:** `genres/{category}/{slug}.md` (the fallback)

The first match wins. A custom genre with the same slug as a built-in
SHADOWS the built-in (the builder warns against this — see
`genre-builder.md`). Custom genre files have the same section structure
as built-in files, so the rest of the protocol is unchanged — they're
loaded and merged identically.

If a custom genre file was produced by the Custom Genre Builder, it
may contain a `parents: [slug1, slug2, ...]` frontmatter field. The
loader uses this list to locate the parent genre files (from the
built-in bank) for inheritance-chain crutch phrase loading during
Humaniser runs.

**Single-genre mode (no mash-up active):**

1. Read `genres/_index.md` to find the genre file
2. Read the full genre file from its category folder (e.g., `genres/mystery-crime/cozy-mystery.md`) — OR from a custom path if the custom precedence check above matched
3. Extract each section and hold in context:
   - `## Architect Instructions` → inject into Architect system prompt
   - `## Writer Craft Rules` → inject into Writer system prompt
   - `## Quality Check Criteria` → inject into Quality Guardian
   - `## Continuity Rules` → inject into Continuity Guardian
   - `## Character Rules` → inject into Character Tracker
   - `## Arc Rules` → inject into Arc Analyst
   - `## Timeline Rules` → inject into Timeline Keeper
   - `## Genre-Specific Craft Techniques` → inject into Writer + editorial
   - `## Genre-Specific Revision Rules` → inject into editorial pipeline
   - `## Names & Patterns to Avoid` → supplement universal avoidance list
   - `## Metadata` (icon, category, word targets) → genre categorisation and length defaults
   - `## Subgenre Options` → present to user during Phase 1 for subgenre selection
   - `## Cover Design Specifications` → inject into Cover Designer prompt (Phase 7)

**Mash-up mode (2 or 3 genres active):**

When `project-config.md` shows `Mash-up: yes`, the loader iterates over the
active genre list (Primary → Secondary → Tertiary) and merges sections as
follows BEFORE injecting into agent prompts. This produces a single merged
rulebook that downstream agents treat identically to a single-genre load.

**Merge strategy by section:**

| Section | How it merges |
|---------|---------------|
| `## Architect Instructions` | Concatenate in Primary → Secondary → Tertiary order. Prefix each block with `### From {Genre Display Name}:` so the Architect can attribute conflicting instructions. |
| `## Writer Craft Rules` | Concatenate in the same order with attribution headers. |
| `## Quality Check Criteria` | **Union.** Every criterion from every genre must pass. If two genres specify different numerical thresholds for the same check, use Primary's. |
| `## Continuity Rules` | Concatenate in Primary → Secondary → Tertiary order. |
| `## Character Rules` | Concatenate in the same order. |
| `## Arc Rules` | Concatenate in the same order. If two genres specify different act structures, Primary wins and the other genres' arc rules become "overlay beats" that must still fire inside Primary's act structure. |
| `## Timeline Rules` | Concatenate in the same order. |
| `## Genre-Specific Craft Techniques` | Concatenate in the same order. |
| `## Genre-Specific Revision Rules` | Concatenate in the same order. |
| `## Names & Patterns to Avoid` | **Union.** Every avoided name from every genre is avoided. |
| `## AI Crutch Phrases (ELIMINATE ALL)` | **Union.** Every crutch phrase from every genre is banned. If the same phrase appears in multiple genre tables with different allowed-frequency limits, the STRICTEST (lowest) limit wins. |
| `## Metadata` (word counts, icon, category, cover style) | **Primary only.** Secondary and Tertiary metadata is ignored for defaults. |
| `## Subgenre Options` | **Primary only.** |
| `## Cover Design Specifications` | **Primary only** at default. Secondary/Tertiary cover styles may be surfaced as alternative cover concepts during Phase 7. |

**Inheritance chain loading (applies to every slot):**

Each genre in the active stack also pulls rules from its own inheritance
chain as documented in `_index.md`. For example, a mash-up of
`noir` (Primary) + `cozy-fantasy` (Secondary) loads:

1. **Primary chain:** noir → crime → mystery → general
2. **Secondary chain:** cozy-fantasy → fantasy → general

All files in both chains contribute to the merged `AI Crutch Phrases`
union. `general` appears in both chains — de-duplicate by file, not by
rule. Rules within the same file are loaded once regardless of how many
stack slots reference it.

**Placeholder substitution for agent system prompts:**

Downstream agents (Architect, Writer, Quality Guardian, etc.) use
placeholders like `{genre}`, `{genre_name}`, `{genre_architect_instructions}`
in their system prompt templates. In mash-up mode:

- `{genre}` and `{genre_name}` → a compound string, e.g.
  `"Cozy Mystery + Fantasy (primary + secondary)"` or
  `"Domestic Thriller / Psychological Thriller / Gothic (primary + secondary + tertiary)"`
- `{genre_architect_instructions}` → the concatenated merged block
- `{genre_writer_craft_rules}` → the concatenated merged block
- `{genre_quality_check_criteria}` → the unioned criteria
- `{genre_specific_craft_techniques}` → the concatenated merged block
- `{genre_specific_automatic_fails}` → the unioned automatic fails
- `{genre_continuity_rules}` → the concatenated merged block
- `{genre_timeline_rules}` → the concatenated merged block
- `{genre_character_rules}` → the concatenated merged block

**Attribution headers in merged blocks:**

When concatenating, always include attribution headers so the agent can
reason about which rule came from which genre. Example merged Architect
Instructions block for a Cozy Mystery + Fantasy mash-up:

```markdown
### From Cozy Mystery (Primary):
{full text of cozy-mystery.md's Architect Instructions section}

### From Fantasy (Secondary):
{full text of fantasy.md's Architect Instructions section}
```

This lets the Architect cite "Cozy Mystery requires a small-community
amateur sleuth" and "Fantasy requires a clearly defined magic system" as
two independent rules that both need to be honoured in the brief.

## File Management

All output goes to: `{project_root}/[Book Title]/`

The project folder is split into two areas:
- **`manuscript/`** — User-facing files in .docx format (editable in Word/Google Docs)
- **`engine-data/`** — Internal engine files used by the engine for continuity and return visits

### Path Resolution (MANDATORY — runs once per project at Phase 1)

**Never pass `~` through to Write/Bash operations.** `~` expansion behaviour
varies between shells and operating systems. Before creating any project
files:

1. Resolve the home directory via bash:
   ```bash
   HOME_ABS=$(echo $HOME)   # Linux/macOS
   # Windows Kimi: echo $USERPROFILE if $HOME is empty
   ```
2. Construct the full project path:
   `{HOME_ABS}/Documents/Ideorix-Projects/{sanitised_title}/`
3. Store the resolved absolute path in `project-config.md` as
   `project_root:` — all subsequent phases READ project_root from
   project-config.md, never re-expand `~`.

### Project Title Sanitisation (MANDATORY)

Before using the user's title as a folder name:

1. Strip any `..` (prevents path traversal)
2. Replace any `/` or `\` with `-`
3. Strip leading/trailing whitespace
4. Trim to 100 characters maximum
5. If empty after sanitisation, fall back to `Untitled Project`

Store the sanitised version as `sanitised_title:` in project-config.md
(used for folder/file names). Store the user's ORIGINAL title as
`display_title:` (used in all user-facing output — headers, dashboards,
KDP metadata). Sanitisation preserves usability without altering the
user's chosen title in display contexts.

> **IMPORTANT — Local-First Storage:**
> The Cowork workspace is **ephemeral** — files are lost if the skill is deleted or
> reinstalled. All project files MUST be saved to the user's **local filesystem**,
> which persists across sessions and skill updates.
>
> At the START of every session, ask the user where they want projects saved.
> Default: `~/Documents/Ideorix-Projects/`. Other good options:
> - `~/Desktop/Ideorix-Projects/` (easy access)
> - A folder inside Google Drive Desktop sync path (automatic cloud backup)
>
> **Why local?** The desktop app has full filesystem access. Saving locally means
> the user keeps their Story Bible, chapters, and engine-data even if the skill
> is updated, reinstalled, or the workspace is cleared. Files are also available
> offline and can be opened in any editor.

## Cowork Space Monitor (MANDATORY — runs at session start)

**Why this exists:** The Cowork workspace is a ~10 GB ephemeral filesystem.
Users who save projects to Cowork instead of local storage accumulate
snapshots, briefs, reports, and imports until they hit the cap and the
engine starts failing silently. This monitor catches the problem before
the first chapter is generated.

**At the START of every session** (after the licence header, before the
Front Gate menu), check Cowork's free space:

```bash
df -h /home/user 2>/dev/null | awk 'NR==2 {print $4}'
```

**Trigger logic:**

| Free Space | Action |
|---|---|
| > 2 GB | Silent — proceed normally |
| 500 MB – 2 GB | Display soft warning at session start (one-line note) |
| < 500 MB | Display HARD warning + diagnostic with biggest space consumers |
| < 100 MB | BLOCK new project creation entirely until space is freed |

**Soft warning template (500 MB – 2 GB):**

```
⚠ Cowork workspace: {free} free of 9.7 GB. Consider migrating projects
  to your local filesystem (~/Documents/Ideorix-Projects/) — Cowork is
  ephemeral and will lose all files on workspace reset.
```

**Hard warning template (< 500 MB):**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ⚠ COWORK WORKSPACE NEARLY FULL — {free} free of 9.7 GB

  Your projects are saved in the ephemeral Cowork workspace, which has
  a hard cap. When it fills up, the engine will start failing silently
  on snapshots, briefs, and reports. Worse, Cowork can be reset at any
  time, taking all your project files with it.

  Top space consumers:
{list_top_consumers}

  Recommended actions:
    1. Move active projects to ~/Documents/Ideorix-Projects/ (local disk)
    2. Delete old engine-data/revisions/ folders for finished projects
    3. Delete old engine-data/imports/ folders for completed imports

  Run "/space" for full diagnostic and migration guidance.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Diagnostic — top space consumers:**

```bash
du -sh ~/Ideorix-Projects/*/engine-data/revisions 2>/dev/null | sort -h | tail -3
du -sh ~/Ideorix-Projects/*/engine-data/imports 2>/dev/null | sort -h | tail -3
du -sh ~/Ideorix-Projects/* 2>/dev/null | sort -h | tail -3
```

These three queries identify the largest revisions folders, the largest
import caches, and the largest project folders overall. Display the top 3
of each in the warning so the user knows exactly what to clean up.

**Block threshold (< 100 MB):**

If free space is below 100 MB, refuse to start a NEW project. Display:

```
⛔ Cowork workspace nearly exhausted — {free} free.

The engine cannot safely start a new project at this space level.
Snapshots, chapter files, and reports will fail to write.

Required actions before continuing:
  1. Move existing projects to ~/Documents/Ideorix-Projects/ (local disk)
  2. Or delete old projects from Cowork to free space
  3. Or work on an existing project that's already in your local filesystem

The engine will resume normal operation once Cowork has at least 500 MB free.
```

The user can still work on local-filesystem projects in this state — only
NEW project creation in Cowork is blocked.

## Cowork Project Setup Hard-Block (MANDATORY — Start New Project)

**When the user runs Start New Project, after they specify the save path:**

Resolve the path to absolute. If it resolves to a Cowork-only path
(typically `/home/user/...` without `/mnt/` or `/Users/` or similar
local-filesystem markers), STOP and present this prompt to the user:

```
⚠ The path you specified — {path} — is in the Cowork workspace.

Cowork is ephemeral. Your project will be lost if:
  - The workspace is reset
  - You reinstall the Ideorix skill
  - Cowork hits its 9.7 GB storage cap

For project work that you care about, save to your local filesystem:
  - Mac:     ~/Documents/Ideorix-Projects/
  - Windows: C:\Users\{name}\Documents\Ideorix-Projects\
  - Or:      a folder inside Google Drive / Dropbox / OneDrive sync

Options:
  1. Use the recommended local path (~/Documents/Ideorix-Projects/)
  2. Specify a different path
  3. Continue with Cowork anyway (I understand the risks — for testing/throwaway only)
```

**If the user picks option 3**, log the choice to `engine-data/project-config.md`
with a `cowork_acknowledged: true` flag and proceed. Do NOT prompt again
for the same project — the user has explicitly accepted the risk.

**If the user picks option 1**, set the path to `~/Documents/Ideorix-Projects/`
and continue with project creation.

**If the user picks option 2**, re-prompt for the path and re-run the
Cowork detection. Loop until they choose a non-Cowork path or explicitly
accept Cowork.

This hard-block exists because soft warnings have not been sufficient —
users still default to Cowork without realising the implications, and the
cost of losing a project mid-write is high. The block adds 30 seconds to
project setup and prevents hours of lost work.

```
Ideorix-Projects/
└── [Book Title]/
    │
    ├── manuscript/                      # USER-FACING — editable files
    │   ├── [Book Title].docx            # Final manuscript (Full Pipeline)
    │   ├── [Book Title] - KDP Info.docx # Amazon metadata (Full Pipeline)
    │   ├── writers-companion.docx       # Writer's Companion (Story Bible Only)
    │   ├── outline.docx                 # User-facing outline
    │   └── chapters/
    │       ├── chapter-01.docx          # Individual chapters (for editing)
    │       ├── chapter-02.docx
    │       └── ...
    │
    ├── marketing/                       # USER-FACING — cover & marketing assets
    │   ├── cover-concept.docx           # Cover design concept (if requested)
    │   ├── marketing-brief.docx         # Marketing materials (if requested)
    │   └── trailer-storyboard.docx      # Video trailer storyboard (if requested)
    │
    └── engine-data/                     # ENGINE USE ONLY — do not edit manually
        ├── project-mode.md              # Project mode + status (Full Pipeline / Story Bible Only)
        ├── series-bible.md              # Series Bible (Phase 0 — if multi-volume)
        ├── story-bible.md               # Story Bible (Phases 2A + 2B)
        ├── entities.md                  # Extracted entities (Phase 2C)
        ├── outline.md                   # Detailed chapter outline (Outline Builder)
        ├── market-pulse.md              # Market Pulse Research report (Outline Builder)
        ├── trope-plan.md                # Selected tropes + delivery plan
        ├── style-guide.md               # Style guide (if built from uploads)
        ├── beat-structure.md            # Selected beat structure + delivery log
        ├── chekhovs-guns.md             # Chekhov's Gun tracking
        ├── humaniser-tracker.md         # AI-ism frequency tracker
        ├── tension-tracker.md          # Pacing slider history (plan vs actual)
        ├── chapter-briefs/
        │   ├── ch01-brief.md
        │   ├── ch02-brief.md
        │   └── ...
        ├── chapters/                    # Raw chapter text (md for engine use)
        │   ├── ch01.md
        │   ├── ch02.md
        │   └── ...
        ├── summaries/
        │   ├── ch01-summary.md
        │   ├── ch02-summary.md
        │   └── ...
        └── reports/
            ├── ch01-verification.md
            ├── ch01-editorial.md
            ├── manuscript-editorial.md
            └── ...
```

### Returning to a Project

When a user says "continue writing [title]" or "design my cover" or returns to an existing project:
1. Check `Ideorix-Projects/` for matching project folders
2. **Check `engine-data/project-mode.md`** — if it exists and says "Story Bible Only",
   follow the **Story Bible Only Return Flow** below instead of the standard flow
3. Read `engine-data/series-bible.md` (if it exists) to restore series context
4. Read `engine-data/story-bible.md` to restore full story context
5. Read `engine-data/entities.md` — build an **entity index** (names, ages,
   acronym expansions only) for lightweight lookup. Full profiles are loaded
   per-chapter via Context Scoping (see Phase 3, step 0)
6. Read the latest `engine-data/summaries/` files for continuity — on project
   return, load all summaries to re-establish context. During chapter generation,
   Context Scoping limits summaries to last 3 full + one-line precis for earlier.
7. Resume from where the user left off — the engine-data folder has everything needed

### Returning to a Story Bible Only Project

When a user returns with a completed manuscript for a Story Bible Only project
(detected via `engine-data/project-mode.md`), run this protocol:

**Trigger phrases:** "Edit my [Title]", "I've finished [Title]", "Review my
manuscript for [Title]", "I've written [Title]", or any return to a project
that has `project_mode: story_bible_only` and `status: Awaiting manuscript`.

**Step 1: Project Recognition**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  WELCOME BACK — Story Bible Project: {Title}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  I have your complete Story Bible, character database, chapter outline,
  and all planning documents for "{Title}".

  Ready to review your manuscript. Please paste or upload your completed
  text (plain text, Markdown, .txt, or text pasted from Word/Google Docs).
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Prompt the user to receive the manuscript. The user may paste text, upload
a file, or provide a file path.

**Step 2: Story Bible Validation**

After receiving the manuscript, run a structured comparison against the existing
Story Bible, entity database, and timeline. Check for:

- **Character consistency:** Names, ages, physical descriptions, relationships,
  occupations — compare every character fact in the manuscript against `entities.md`
- **Timeline consistency:** Does the manuscript's chronology align with the Story
  Bible's timeline? Season, months, day sequencing, event ordering
- **Location consistency:** Do locations match their Story Bible descriptions?
  Any new locations introduced?
- **Canon rule compliance:** Does the manuscript honour the world rules
  established in the Story Bible?
- **Plot alignment:** How closely does the manuscript follow the chapter outline?
  Which chapters diverged, and how?
- **Beat delivery:** Were the planned story beats delivered? Any missed or moved?
- **Trope delivery:** Were selected tropes set up, escalated, and paid off?
- **Chekhov's Guns:** Were planted elements paid off?

Generate a **Story Bible Validation Report** with three categories:

```
VALIDATION REPORT — {Title}

ALIGNED (matches Story Bible):
  ✓ [list of elements that match]

CREATIVE DEPARTURES (writer chose differently — needs reconciliation):
  ~ [list of intentional differences with Story Bible reference]

POTENTIAL CONTINUITY ISSUES (may be errors):
  ✗ [list of contradictions that may be unintentional]
```

**Step 3: Canon Reconciliation (INTERACTIVE)**

Present the Creative Departures and Potential Continuity Issues to the user
by prompting the user. For each departure:

"Your Story Bible says {X}, but your manuscript says {Y}. Which is correct?"

Options:
- "My manuscript is correct — update the Story Bible"
- "The Story Bible is correct — flag this for editing"
- "Both are intentional — the character/world changed during the story"

Update the Story Bible and entities to reflect the writer's decisions. The
reconciled Story Bible becomes the new source of truth for editorial agents.

**Step 4: Voice Profile Generation**

Build a Voice Profile from the writer's manuscript (see `editorial-suite.md`
Stage 0). This captures the writer's actual prose style — sentence architecture,
vocabulary, narrative stance, dialogue characteristics, pacing signature,
metaphor and imagery patterns. All subsequent editing preserves this voice.

> **Why this matters for Story Bible Only projects:** The voice profile is built
> from the WRITER'S prose, not AI-generated text. Every editorial suggestion
> will respect the writer's natural style. This is fundamentally different from
> editing AI-generated text — the editorial agents protect voice rather than
> stripping AI patterns.

**Step 5: Editorial Pipeline**

Run the full editorial pipeline (Phase 5) on the reconciled manuscript:
1. Genre-Specific Audit (from genre bank)
2. Proofreader
3. Copy Editor
4. Developmental Editor
5. Alpha Reader
6. Beta Reader
7. Conflict Resolution
8. Apply Top Fixes (surgical — preserving writer's voice)
9. Full-Manuscript Continuity Audit (using the reconciled Story Bible)

> **Note:** The Prose Humaniser is NOT run on Story Bible Only manuscripts.
> The writer's prose is human by definition — the Humaniser only applies to
> AI-generated text. Similarly, the line editor's "AI Paragraph Architecture
> Detection" is skipped. All other line editor checks (passive voice, adverbs,
> clichés, redundancy) still apply if selected.

**Step 6: Delivery**

Generate the editorial report and revised manuscript. Update `project-mode.md`:
```markdown
Status: Editorial complete
Editorial date: {date}
```

Present the delivery summary with editorial scores, key findings, and the
revised manuscript. Offer the Publishing Studio tools (Cover Designer,
Marketing Expert, Video Trailer Designer).

**Step 7: Optional — Manuscript Clinic**

After editorial delivery, offer the Manuscript Clinic for deeper diagnostic:

"Would you like a full Manuscript Clinic consultation? This provides a 6-axis
diagnostic (Structure, Character, Dialogue, Voice, Market Viability, Genre Fit)
with scores and actionable recommendations. It's especially useful for Story
Bible projects because it can compare your execution against the original plan
and identify where your creative choices strengthened or weakened the story."

### Starting the Next Volume in a Series

When a user says "write the next book" or "start Volume 2":
1. Read `engine-data/series-bible.md` for series architecture
2. Load the Arc Weave Matrix to see which threads carry forward
3. Load the Character Trajectory Map for where characters should be at this point
4. Load the Volume Blueprint for this specific volume
5. Run Phase 1 (Setup) with inherited series context — genre, spine question,
   thematic throughline, and volume blueprint are pre-loaded

## Critical Rules

1. **NEVER skip the Architect** — Every chapter gets a brief before writing
2. **NEVER write out of order** — Chapters must be sequential for continuity
3. **ALWAYS generate chapter summaries** — These are the continuity backbone
4. **ALWAYS check verification scores** — Below 80 = fix before proceeding
5. **NEVER do holistic rewrites** — All revisions are surgical (analyse → fix)
6. **ALWAYS use the instruction hierarchy** — Continuity trumps everything
7. **ALWAYS read the genre bank file** — Never generate from generic knowledge
8. **SAVE incrementally** — Write each chapter to disk as it's completed
9. **HONOUR the beat structure** — If selected, every chapter serves its target beat
10. **TRACK Chekhov's Guns** — Every planted gun must pay off; update status per chapter
11. **APPLY the 7 Craft Commandments** — Every chapter evaluated against all 7
12. **DELIVER selected tropes** — Every trope must have setup, escalation, and payoff across the manuscript
13. **COMPLETE each chapter's full pipeline before starting the next** — Steps 1-17
   must ALL finish for Chapter N before Step 1 begins for Chapter N+1. Never batch
   verification, humaniser, or summaries across multiple chapters.
14. **DO NOT ask permission to continue the pipeline** — Once the user approves the
   setup (Phase 1), each chapter brief (Step 6), and each chapter's prose (Step 7a),
   execute all remaining steps without asking "Shall I continue?" or "How would you
   like me to handle X?" The pipeline is defined — just run it. The ONLY mandatory
   user gates are: brief approval (Step 6) and prose approval (Step 7a).
15. **RUN the batch editor every 5 chapters** — After chapters 5, 10, 15, 20, 25, 30
   (and the final chapter), run the full batch deep edit. This is not optional.
   The batch edit is the engine's primary defence against quality degradation.
16. **ALWAYS show the progress dashboard** — After every chapter completes its pipeline
   cycle, display the progress dashboard to the user. This was the single biggest
   usability failure in testing. Never skip it, even under context pressure.
17. **ALWAYS prompt the user for brief review** — The user MUST approve each
   chapter brief before writing begins. Prompt the user, not plain text output.
   This gate was skipped in every test run. The interactive tool makes skipping
   structurally impossible.
18. **ALWAYS offer Short Story expansion when score ≥85** — After a Short Story
   completes Phase 5 with an average verification score of 85 or higher, present
   the expansion prompt by prompting the user. This is not optional — high-scoring
   short stories represent validated concepts worth offering to expand.
19. **ALWAYS display the Story Bible to the user** — After Phase 2 completes, the
   full Story Bible MUST be presented in the conversation as formatted text. Do NOT
   silently save it to a file and move on. The user must see and approve the Story
   Bible before chapter generation begins. Prompt the user with options:
   "Approve Story Bible", "Request changes", "Add details". This is a BLOCKING gate.
20. **ALWAYS display verification reports inline** — Every verification report
   (per-chapter and batch) MUST be displayed in the conversation as formatted text
   with all 6 agent scores, issue counts, and the progress dashboard. Do NOT save
   reports to files without also showing them to the user. Do NOT summarise or
   abbreviate reports. Do NOT offer to "show the report if you'd like" — always
   show it. The user's inability to see quality data was the root cause of
   undetected degradation in testing.
21. **NEVER offer the 5-chapter batch edit as optional** — The batch deep edit at
   every 5th chapter (and the final chapter) is a MANDATORY pipeline step, not a
   suggestion. Do NOT say "Would you like me to run the batch edit?" or "I can
   run a batch review if you'd like." Just run it. The batch edit is as mandatory
   as the Humaniser or verification agents — it is part of the pipeline, not an
   add-on. Display the Batch Health Report inline in the conversation.
22. **ALWAYS run Market Scout** — Market Scout MUST run for every project, regardless
   of outline source. If the Outline Builder ran it, it's done. If the user provided
   their own outline, run Market Scout before Phase 2. Do NOT skip it because the
   user "already has an outline." Market intelligence informs the Story Bible,
   trope integration, and strategic positioning — not just the outline.
