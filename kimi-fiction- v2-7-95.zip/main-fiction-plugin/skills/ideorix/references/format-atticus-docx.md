---
name: format-atticus-docx
description: "Atticus-compatible DOCX generation template"
user-invocable: false
---
<!-- (c) 2025 Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->
# Atticus-Compatible DOCX Generation Template

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-atticus.docx`

This Atticus-compatible DOCX export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. Use the `-atticus` suffix to distinguish from the standard DOCX export. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Overview

Generate .docx files optimised for import into Atticus — the popular book formatting
tool. Atticus applies its own templates for fonts, margins, and layout, so this format
strips away publisher-style headers/footers and uses clean heading styles that Atticus
recognises automatically.

## Key Differences from Standard DOCX

| Feature | Standard DOCX | Atticus DOCX |
|---------|--------------|--------------|
| Chapter headings | Custom 16pt bold centered | **Heading 1** style (Atticus auto-detects) |
| Scene breaks | Centered `* * *` | Centered `* * *` (Atticus auto-detects) |
| Headers/footers | Book title / chapter title / page numbers | **None** (Atticus handles these) |
| First-line indent | 0.5" except first paragraph | **None** (Atticus handles indentation) |
| Line spacing | 1.5 | Single (Atticus re-applies spacing) |
| Page breaks | Between chapters | Between chapters (preserved) |
| Font | Times New Roman 12pt | Default font (Atticus overrides) |

## Manuscript Specifications

- **Page size:** US Letter (8.5" x 11")
- **Margins:** 1 inch all sides
- **Body font:** Times New Roman, 12pt (Atticus will override)
- **Chapter headings:** Heading 1 style — Atticus uses this to detect chapter boundaries
- **Line spacing:** Single (Atticus applies its own spacing)
- **Paragraph spacing:** None (Atticus applies its own)
- **First line indent:** None (Atticus handles indentation)
- **Page breaks:** Between every chapter (preserved by Atticus)
- **Headers/footers:** None — Atticus generates its own
- **Scene breaks:** `* * *` centered — Atticus auto-detects these

## Title Page Structure

```
[Book Title — Heading 1 style]

[blank line]

[Author Name — normal paragraph, centered]

[Page break]
```

Keep the title page minimal. Atticus has its own title page templates the author
will choose during formatting.

## Chapter Structure

```
[Page break before each chapter]

[Chapter heading — Heading 1 style]
[e.g., "Chapter 1: The Discovery"]

[Chapter body — normal paragraphs]
[No first-line indent — Atticus handles this]
[Scene breaks as centered * * *]
```

## Node.js Generation Template

```javascript
const { Document, Packer, Paragraph, TextRun, AlignmentType,
        HeadingLevel, PageBreak } = require('docx');

function createAtticusManuscript(title, author, chapters) {
  const doc = new Document({
    styles: {
      paragraphStyles: [
        {
          id: 'Normal',
          name: 'Normal',
          run: { size: 24, font: 'Times New Roman' },
          paragraph: { spacing: { line: 240 } }
        }
      ]
    },
    sections: [
      // Title page — minimal, Atticus overrides
      {
        properties: {
          page: {
            size: { width: 12240, height: 15840 },
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
          }
        },
        children: [
          new Paragraph({
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER,
            spacing: { before: 3600 },
            children: [new TextRun({ text: title, bold: true })]
          }),
          new Paragraph({ spacing: { before: 400 } }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: author, size: 24, font: 'Times New Roman' })]
          })
        ]
      },
      // Chapter sections
      ...chapters.map((chapter, index) => ({
        properties: {
          page: {
            size: { width: 12240, height: 15840 },
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
          }
        },
        children: [
          // Chapter heading — Heading 1 for Atticus detection
          new Paragraph({
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 },
            children: [new TextRun({
              text: `Chapter ${index + 1}: ${chapter.title}`
            })]
          }),
          // Chapter content — no indentation, Atticus handles it
          ...parseParagraphsForAtticus(chapter.content)
        ]
      }))
    ]
  });

  return Packer.toBuffer(doc);
}

function parseParagraphsForAtticus(content) {
  const blocks = content.split('\n\n');
  return blocks.map(block => {
    const trimmed = block.trim();

    // Scene break
    if (trimmed === '* * *' || trimmed === '---') {
      return new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 200, after: 200 },
        children: [new TextRun({ text: '* * *', size: 24, font: 'Times New Roman' })]
      });
    }

    // Normal paragraph — no indent (Atticus handles it)
    return new Paragraph({
      spacing: { line: 240 },
      children: parseInlineFormatting(trimmed)
    });
  });
}

function parseInlineFormatting(text) {
  const runs = [];
  const regex = /\*\*(.+?)\*\*|\*(.+?)\*/g;
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      runs.push(new TextRun({
        text: text.slice(lastIndex, match.index),
        size: 24, font: 'Times New Roman'
      }));
    }
    if (match[1]) {
      runs.push(new TextRun({
        text: match[1], bold: true, size: 24, font: 'Times New Roman'
      }));
    } else if (match[2]) {
      runs.push(new TextRun({
        text: match[2], italics: true, size: 24, font: 'Times New Roman'
      }));
    }
    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    runs.push(new TextRun({
      text: text.slice(lastIndex), size: 24, font: 'Times New Roman'
    }));
  }

  return runs;
}
```

## Content Parsing Notes

1. Split on double newlines for paragraph breaks
2. Convert scene breaks (`* * *` or `---`) to centered `* * *` (Atticus standard)
3. **Do not** apply first-line indentation — Atticus handles this
4. **Do not** add headers or footers — Atticus handles this
5. Strip markdown formatting into bold/italic TextRuns
6. Preserve em-dashes (—), curly quotes, and special characters
7. Chapter headings **must** use Heading 1 style — this is how Atticus detects chapters

## Atticus Import Tips (Include in Delivery Notes)

When delivering an Atticus-compatible file, include these notes for the user:
- Open Atticus → New Project → Import DOCX
- Atticus will auto-detect chapters from Heading 1 styles
- Scene breaks (`* * *`) will be converted to Atticus scene separators
- Choose your formatting template in Atticus after import
- Review chapter detection — verify all chapters were found
