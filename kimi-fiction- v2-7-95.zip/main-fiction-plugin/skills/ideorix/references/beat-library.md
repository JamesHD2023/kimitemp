---
name: beat-library
description: "28 beat structure templates and genre-to-beat mappings"
user-invocable: false
---

# Beat Structure Library

> Reference data file. read on demand by the engine when beat selection is needed.
> Contains all 28 beat structure templates and genre-to-beat mappings.
> Source: `src/beatsLibrary.js` and `src/genreToBeats.js` from Ideorix.

## How to Use This File

1. During Phase 1 Setup, read this file when the user reaches beat structure selection
2. Look up the user's genre in the GENRE-TO-BEAT MAPPING section
3. Present the recommended structures with their beat lists
4. Save the selected structure to the workspace

## Beat Structure Format

Each structure has:
- **ID**. Unique identifier
- **Name**. Display name
- **Description**. What the structure is good for
- **Beats**. Ordered list of story moments with target percentages

---

## STANDARD FICTION STRUCTURES (22)

### 1. Save the Cat

**ID:** `save-the-cat`
**Best for:** Commercial fiction, genre fiction, accessible stories
**Description:** A 15-beat commercial storytelling framework that balances character arc and plot.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Opening Image | A snapshot of the hero's life before the story begins | 0 |
| 2 | Theme Stated | Another character hints at the story's core truth | 5 |
| 3 | Setup | Meet key characters, see the hero's world, glimpse flaws and stakes | 10 |
| 4 | Catalyst | An event disrupts the hero's status quo and forces a choice | 10 |
| 5 | Debate | The hero resists change, weighs options, hesitates | 20 |
| 6 | Break into Two | The hero chooses to step into a new world or approach | 25 |
| 7 | B Story | A supporting subplot that reflects or challenges the main theme | 30 |
| 8 | Fun and Games | The promise of the premise: core situations and genre delights | 35 |
| 9 | Midpoint | A major victory or defeat that changes the game and raises stakes | 50 |
| 10 | Bad Guys Close In | Internal and external pressures intensify | 60 |
| 11 | All Is Lost | The apparent worst moment where the hero seems to fail | 75 |
| 12 | Dark Night of the Soul | The hero reflects, grieves, and struggles with the loss | 80 |
| 13 | Break into Three | A new idea combines lessons from A and B stories | 80 |
| 14 | Finale | The hero executes a new plan and resolves core stakes | 90 |
| 15 | Final Image | A contrasting image showing how the hero and world have changed | 100 |

---

### 2. Hero's Journey

**ID:** `heros-journey`
**Best for:** Epic fantasy, adventure, transformative character arcs
**Description:** A mythic pattern of departure, initiation, and return.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Ordinary World | The hero's normal life before the adventure | 0 |
| 2 | Call to Adventure | Something disrupts the ordinary world | 5 |
| 3 | Refusal of the Call | The hero hesitates or declines | 10 |
| 4 | Meeting the Mentor | A guide provides wisdom, training, or tools | 15 |
| 5 | Crossing the Threshold | The hero leaves the ordinary world | 20 |
| 6 | Tests, Allies, Enemies | Challenges, alliances, and opposition | 30 |
| 7 | Approach to Inmost Cave | The hero nears the central ordeal | 45 |
| 8 | Ordeal | A major crisis or confrontation | 50 |
| 9 | Reward | The hero gains knowledge, an item, or new power | 60 |
| 10 | The Road Back | The journey home, often under pursuit | 70 |
| 11 | Resurrection | A final climactic test where the hero is reborn | 85 |
| 12 | Return with the Elixir | The hero brings back something that transforms the world | 100 |

---

### 3. Story Circle (Dan Harmon)

**ID:** `story-circle`
**Best for:** Character-driven fiction, YA, TV-paced narratives
**Description:** An 8-step character-centered structure focusing on desire, change, and return.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | You (Comfort Zone) | Meet the character in their ordinary situation | 0 |
| 2 | Need (Desire) | What the character wants or what's missing | 12 |
| 3 | Go (Crossing) | Enter an unfamiliar situation or challenge | 25 |
| 4 | Search | Adapt, experiment, and struggle | 37 |
| 5 | Find | Get what they thought they wanted | 50 |
| 6 | Take (Price) | Consequences hit. there's a cost | 62 |
| 7 | Return | Return to a familiar world, changed | 75 |
| 8 | Change | Clear evidence of transformation | 100 |

---

### 4. Three-Act Structure

**ID:** `three-act`
**Best for:** Universal. works for nearly all narrative forms
**Description:** Classic division into Setup, Confrontation, and Resolution.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Act I: Setup | Introduce characters, world, and central problem | 0 |
| 2 | Inciting Incident | An event kicks off the main conflict | 10 |
| 3 | First Plot Point | Major turning point into Act II | 25 |
| 4 | Act II: Rising Action | Complications, subplots, escalating stakes | 25 |
| 5 | Midpoint | Central reversal or revelation | 50 |
| 6 | Second Plot Point | Crisis that sets up the climax | 75 |
| 7 | Act III: Climax | Decisive confrontation resolving the conflict | 85 |
| 8 | Resolution | Loose ends tied, new normal established | 100 |

---

### 5. Freytag's Pyramid

**ID:** `freytag`
**Best for:** Literary fiction, drama, character-driven stories
**Description:** Dramatic arc tracing the rise and fall of tension.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Setup (Exposition) | Establish world, characters, and situation | 0 |
| 2 | Inciting Incident | An event disrupts the status quo | 10 |
| 3 | Rising Action: Complications | Obstacles multiply, stakes clarify | 25 |
| 4 | Rising Action: Intensification | Harder choices, converging conflicts | 40 |
| 5 | Climax (Turning Point) | Greatest tension, defining choice | 55 |
| 6 | Falling Action | Consequences ripple, tension decreases | 75 |
| 7 | Resolution | New situation, transformation demonstrated | 100 |

---

### 6. Seven-Point Structure

**ID:** `seven-point`
**Best for:** Fantasy, sci-fi, strong-plot novels
**Description:** Plot-focused framework built around seven key turning points.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Hook | The protagonist before change | 0 |
| 2 | First Plot Turn | Main conflict introduced | 25 |
| 3 | First Pinch Point | Antagonistic pressure reminds us of stakes | 37 |
| 4 | Midpoint | Protagonist moves from reacting to acting | 50 |
| 5 | Second Pinch Point | Antagonistic forces assert urgency | 62 |
| 6 | Second Plot Turn | Revelation or decision enabling the climax | 75 |
| 7 | Resolution | Protagonist's transformation revealed | 100 |

---

### 7. Romancing the Beat

**ID:** `romancing-the-beat`
**Best for:** Romance, romantic subplots
**Description:** Romance-specific beat sheet focusing on emotional progression and HEA/HFN.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Set-Up (Before) | Each lead's life before the romance | 0 |
| 2 | Meet Cute | The leads meet or re-meet | 10 |
| 3 | No Way (Refusal) | Why this romance can't or shouldn't happen | 20 |
| 4 | Adhesion | Circumstances force continued interaction | 30 |
| 5 | Deepening Attraction | Growing closer, revealing vulnerabilities | 40 |
| 6 | Midpoint: Commitment Shift | Emotional commitment beyond admission | 50 |
| 7 | Push-Pull | Tension between intimacy and fear | 60 |
| 8 | All Is Lost (Breakup) | Major rift tears them apart | 75 |
| 9 | Grovel / Realization | One or both realize their mistakes | 85 |
| 10 | Grand Gesture | Bold act proving love and vulnerability | 90 |
| 11 | HEA / HFN | Satisfying, emotionally earned ending | 100 |

---

### 8. Thriller 12-Beat

**ID:** `thriller-12-beat`
**Best for:** Crime, suspense, espionage, action thrillers
**Description:** High-tension structure emphasizing escalating stakes and reveals.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Opening Crime / Threat | The crime or danger that drives the story | 0 |
| 2 | Investigator Hook | Protagonist introduced with personal stakes | 8 |
| 3 | Initial Investigation | First clues and encounters | 15 |
| 4 | First Major Obstacle | Setback showing antagonist's seriousness | 25 |
| 5 | Rising Threat | More victims or fallout; threat expands | 35 |
| 6 | Midpoint Revelation | Twist changing the investigation's direction | 50 |
| 7 | False Lead / Betrayal | Promising lead fails or ally betrays | 60 |
| 8 | Personal Stakes Spike | Threat targets protagonist or loved ones | 70 |
| 9 | All Is Lost | Case seems unsolvable or villain appears to win | 80 |
| 10 | Revelation of True Pattern | New insight clarifies motives or plan | 85 |
| 11 | Final Confrontation | High-stakes showdown | 95 |
| 12 | Aftermath / Justice | Consequences and resolution | 100 |

---

### 9. Horror Fear Arc

**ID:** `horror-fear-arc`
**Best for:** Horror, gothic, supernatural fiction
**Description:** Structure centered on escalating dread and confrontation with the monstrous.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Normal World | Grounded setting before horror intrudes | 0 |
| 2 | First Unease | Minor oddities hint something is wrong | 10 |
| 3 | First Confirmed Threat | Clear incident proving the threat is real | 20 |
| 4 | Denial / Rationalization | Characters downplay the threat | 30 |
| 5 | Rising Terrors | More intense encounters | 45 |
| 6 | Isolation | Help and escape routes cut off | 55 |
| 7 | Rules of the Horror | Characters learn how the threat operates | 60 |
| 8 | All Is Lost / Body Count Peak | Severe loss, survival seems impossible | 75 |
| 9 | Final Confrontation | Survivors face the source of horror | 90 |
| 10 | Aftermath / Lingering Dread | Return to "normal" with scars. or horror persists | 100 |

---

### 10. Cozy Mystery Beat Sheet

**ID:** `cozy-mystery`
**Best for:** Cozy mysteries, amateur sleuth stories
**Description:** Light, character-focused mystery rooted in community and puzzle.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Community Setup | Introduce sleuth, setting, quirky dynamics | 0 |
| 2 | Inciting Crime | Murder or crime shocks the cozy environment | 10 |
| 3 | Initial Suspects | Sleuth identifies people with motives and secrets | 20 |
| 4 | First Clues | Evidence gathered through observation and eavesdropping | 30 |
| 5 | Red Herrings | False leads keep the reader guessing | 40 |
| 6 | Midpoint Revelation | A new clue changes the direction of suspicion | 50 |
| 7 | Community Complications | Tensions rise, relationships strain | 60 |
| 8 | Narrowing Suspects | Several suspects cleared, focus sharpens | 70 |
| 9 | Danger to Sleuth | Sleuth threatened by getting too close | 80 |
| 10 | Reveal & Confrontation | Sleuth reveals the culprit | 90 |
| 11 | Restoring Harmony | Community returns to balance | 100 |

---

### 11. Middle Grade 7-Beat Arc

**ID:** `mg-4-beat`
**Best for:** Middle grade fiction (ages 8-12)
**Description:** Clear, engaging structure balancing adventure with emotional growth.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Ordinary World & Problem | Protagonist in everyday life, central problem | 0 |
| 2 | Call to Action & Helper | Challenge accepted, mentor or friend appears | 15 |
| 3 | First Try & Failure | Initial attempt meets obstacle or setback | 30 |
| 4 | Midpoint Discovery | Key clue, skill, or truth shifts approach | 50 |
| 5 | Rising Stakes & Setback | Pressure mounts, allies tested | 65 |
| 6 | Climax & Brave Choice | Protagonist faces the challenge head-on | 85 |
| 7 | New Normal | Growth shown through changed behavior | 100 |

---

### 12. Worldbuilding Arc

**ID:** `worldbuilding-arc`
**Best for:** Fantasy, sci-fi, any world-heavy fiction
**Description:** Structure balancing world revelation with character progression.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Familiar Ground | Protagonist in known surroundings, world introduced through routine | 0 |
| 2 | First Glimpse | A hint of the wider world, a rule broken, a mystery glimpsed | 10 |
| 3 | Immersion | Protagonist enters the wider world; reader learns key rules | 20 |
| 4 | Culture Shock | Protagonist confronts an unfamiliar rule, custom, or power | 35 |
| 5 | Midpoint: World Cracks | A system, belief, or power is revealed as flawed or threatened | 50 |
| 6 | Deeper Truth | The world's hidden history, cost, or contradiction is exposed | 65 |
| 7 | World in Crisis | The system breaks down or the threat reaches its peak | 80 |
| 8 | New World Order | The world is changed (saved, reformed, or lost). protagonist shaped by it | 100 |

---

### 13. Epic Fantasy Arc

**ID:** `epic-fantasy-arc`
**Best for:** Epic/high fantasy, multi-POV sagas
**Description:** Large-scale structure for quests, wars, and destiny narratives.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Prophecy / World at Peace | The world before the storm; hints of ancient forces | 0 |
| 2 | The Chosen One / Call | Protagonist learns of their role or burden | 8 |
| 3 | Assembly of the Party | Allies gathered, each with unique skills and flaws | 18 |
| 4 | First Quest / Journey | The party sets out; world expanded through travel | 28 |
| 5 | Trial by Fire | A major battle, loss, or revelation tests the party | 40 |
| 6 | Midpoint: The True Enemy | The real threat is revealed (not who they expected) | 50 |
| 7 | Fragmentation | The party splits, trust fractures, alliances shift | 62 |
| 8 | The Dark Lord's Triumph | The enemy gains the upper hand; hope seems lost | 75 |
| 9 | The Final Battle | Climactic confrontation where everything is at stake | 88 |
| 10 | The New Age | The world reshaped; the protagonist's sacrifice honored | 100 |

---

### 14. Memoir Three-Act

**ID:** `memoir-3-act`
**Best for:** Memoir-style fiction, autobiographical narratives
**Description:** Structure adapted for personal narrative arcs.

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | The Before | Life as it was. the world the author inhabited | 0 |
| 2 | The Inciting Change | The event that disrupted everything | 12 |
| 3 | Struggling with Change | Resistance, denial, early attempts to cope | 25 |
| 4 | Turning Point | A moment of clarity or commitment to a new path | 45 |
| 5 | The Hard Work | Sustained effort, setbacks, small victories | 60 |
| 6 | Crisis of Faith | Doubting the journey, temptation to return to old ways | 75 |
| 7 | Resolution & Reflection | The transformation crystallized, lessons distilled | 100 |

---

## NOVELLA-SPECIFIC STRUCTURES (6)

### N1. Novella Romance

**ID:** `novella-romance`
**Best for:** Romance novellas (20K-40K words)

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Meet & Spark | Instant connection or friction between leads | 0 |
| 2 | Forced Proximity | Circumstances keep them together | 15 |
| 3 | Walls Down | Vulnerability revealed, emotional intimacy deepens | 35 |
| 4 | Midpoint Heat | Physical or emotional turning point | 50 |
| 5 | The Lie / Misunderstanding | A rift driven by fear, secrets, or miscommunication | 70 |
| 6 | Grand Gesture & HEA | Reconciliation, declaration, satisfying ending | 90 |

---

### N2. Novella Thriller

**ID:** `novella-thriller`
**Best for:** Thriller/suspense novellas

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Cold Open | Immediate danger or crime that hooks the reader | 0 |
| 2 | The Chase Begins | Protagonist drawn in, stakes personal | 15 |
| 3 | Escalation | Threats multiply, allies prove unreliable | 35 |
| 4 | Midpoint Twist | Everything the protagonist believed is wrong | 50 |
| 5 | Cornered | Resources gone, enemy closing in, time running out | 70 |
| 6 | Final Confrontation & Fallout | Climactic showdown and consequences | 90 |

---

### N3. Novella Mystery

**ID:** `novella-mystery`
**Best for:** Mystery novellas

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Crime & Community | The crime disrupts a close-knit world | 0 |
| 2 | Suspects & Clues | Initial investigation, multiple possible suspects | 15 |
| 3 | Red Herring | A convincing false lead | 35 |
| 4 | Midpoint: New Evidence | A discovery reframes the case | 50 |
| 5 | Danger Closes In | The sleuth becomes a target | 70 |
| 6 | Reveal & Resolution | The culprit exposed, community restored | 90 |

---

### N4. Novella Horror

**ID:** `novella-horror`
**Best for:** Horror novellas

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Uneasy Normal | Something slightly wrong in an ordinary setting | 0 |
| 2 | First Encounter | Undeniable proof the threat is real | 15 |
| 3 | Escalating Dread | Each chapter worse than the last | 35 |
| 4 | Isolation | Help is gone, escape blocked | 50 |
| 5 | The Rules | How the horror works. and one possible weakness | 70 |
| 6 | Confrontation & Aftermath | Face the horror; survive (or don't) | 90 |

---

### N5. Novella Literary

**ID:** `novella-literary`
**Best for:** Literary fiction novellas

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | The Situation | A character in a specific, pressured situation | 0 |
| 2 | Complication | Something changes that demands response | 15 |
| 3 | Deepening | The emotional and practical complexity increases | 35 |
| 4 | Crisis | A moment that forces the most difficult choice | 60 |
| 5 | Consequence | Living with what was chosen | 80 |
| 6 | Resonance | The final image that encapsulates the transformation | 100 |

---

### N6. Novella Speculative

**ID:** `novella-speculative`
**Best for:** Sci-fi and fantasy novellas

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | The World & Its Rules | Establish the speculative element and its cost | 0 |
| 2 | The Disruption | Something breaks the world's equilibrium | 15 |
| 3 | Exploration & Cost | The protagonist engages with the speculative element; price revealed | 35 |
| 4 | Midpoint: Deeper Truth | The world's hidden nature or history exposed | 50 |
| 5 | Crisis of the World | The system/magic/technology fails or threatens everything | 70 |
| 6 | New Equilibrium | The world is changed; protagonist transformed by it | 90 |

---

### N7. Novella Concentrated

**ID:** `novella-concentrated`
**Best for:** Any genre novella. tightest possible structure

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Hook & Setup | Protagonist, world, and problem in one chapter | 0 |
| 2 | Complications | Things get worse, stakes rise | 25 |
| 3 | Midpoint Shift | A revelation or reversal changes everything | 50 |
| 4 | Dark Moment | All seems lost | 75 |
| 5 | Resolution | Climax and aftermath | 100 |

---

### N8. Novella KISS

**ID:** `novella-kiss`
**Best for:** Simplest possible novella structure

| # | Beat | Description | % |
|---|------|-------------|---|
| 1 | Beginning | Character + problem | 0 |
| 2 | Middle | Complications + escalation | 33 |
| 3 | Climax | The decisive moment | 66 |
| 4 | End | Resolution and new normal | 100 |

---

## GENRE-TO-BEAT MAPPING

### Standard Fiction (Novels)

| Genre | Recommended | Secondary |
|-------|-------------|-----------|
| Action Adventure | save-the-cat, heros-journey, seven-point | thriller-12-beat, three-act |
| Afrofuturism | seven-point, worldbuilding-arc | story-circle, heros-journey |
| Children's Books | mg-4-beat | freytag, three-act, story-circle |
| Climate Fiction | freytag, seven-point | three-act, worldbuilding-arc |
| Comedy Fiction | save-the-cat, story-circle | three-act, freytag |
| Coming of Age | story-circle, save-the-cat | freytag, three-act |
| Contemporary Fiction | three-act, story-circle | freytag |
| Contemporary Romance | romancing-the-beat | story-circle, three-act, save-the-cat |
| Cozy Mystery | cozy-mystery | three-act, seven-point, save-the-cat |
| Crime Fiction | thriller-12-beat | three-act, seven-point |
| Cyberpunk | heros-journey, seven-point | worldbuilding-arc, three-act |
| Dark Academia | freytag, three-act | story-circle, heros-journey |
| Dark Fantasy | heros-journey, epic-fantasy-arc | horror-fear-arc, seven-point |
| Domestic Thriller | thriller-12-beat | save-the-cat, seven-point, three-act |
| Drama | freytag, story-circle | three-act |
| Dystopian | seven-point, heros-journey | freytag, worldbuilding-arc |
| Epic Fantasy | epic-fantasy-arc, heros-journey | seven-point, worldbuilding-arc |
| Erotica | romancing-the-beat | story-circle, three-act |
| Espionage | thriller-12-beat | save-the-cat, three-act, seven-point |
| Family Saga | freytag, story-circle | memoir-3-act, three-act |
| Fan Fiction | three-act, save-the-cat | story-circle |
| Fantasy | heros-journey, epic-fantasy-arc | seven-point, worldbuilding-arc, save-the-cat |
| General Fiction | three-act, story-circle | freytag |
| Gothic | freytag, horror-fear-arc | three-act, seven-point |
| Gothic Romance | romancing-the-beat, three-act | freytag, heros-journey |
| Historical Fiction | freytag, three-act | seven-point, memoir-3-act |
| Horror | horror-fear-arc | save-the-cat, three-act, seven-point |
| Legal Thriller | thriller-12-beat | seven-point, three-act |
| LGBTQ+ Fiction | story-circle | three-act, romancing-the-beat, freytag |
| Literary Fiction | freytag, story-circle | three-act |
| LitRPG | epic-fantasy-arc, story-circle | save-the-cat, worldbuilding-arc |
| Magical Realism | freytag, story-circle | three-act |
| Middle Grade | mg-4-beat | three-act, freytag, story-circle |
| Mystery | cozy-mystery, thriller-12-beat | seven-point, three-act |
| Noir | thriller-12-beat, freytag | three-act, seven-point |
| Occult & Magic | heros-journey, horror-fear-arc | worldbuilding-arc, seven-point |
| Paranormal | horror-fear-arc, story-circle | seven-point, three-act |
| Psychological Thriller | thriller-12-beat, story-circle | seven-point, three-act |
| Religious Fiction | story-circle | three-act, memoir-3-act |
| Romance | romancing-the-beat | story-circle, three-act, save-the-cat |
| Romantasy | romancing-the-beat, heros-journey | epic-fantasy-arc, worldbuilding-arc |
| Romantic Comedy | romancing-the-beat, save-the-cat | story-circle, three-act |
| Satire | save-the-cat, freytag | story-circle, three-act |
| Science Fiction | seven-point, worldbuilding-arc | save-the-cat, heros-journey, three-act |
| Space Opera | epic-fantasy-arc, heros-journey | worldbuilding-arc, seven-point |
| Steampunk | heros-journey, worldbuilding-arc | seven-point, three-act |
| Supernatural | horror-fear-arc, story-circle | seven-point, three-act |
| Survival Fiction | seven-point, heros-journey | three-act, thriller-12-beat |
| Thriller | thriller-12-beat, seven-point | save-the-cat, three-act |
| Upmarket Fiction | story-circle, freytag | three-act |
| Urban Fantasy | heros-journey, worldbuilding-arc | story-circle, save-the-cat |
| Vampire Fiction | horror-fear-arc | romancing-the-beat, save-the-cat, three-act |
| War Fiction | heros-journey, three-act | seven-point, freytag |
| Western | heros-journey, three-act | freytag, seven-point |
| Women's Fiction | story-circle, memoir-3-act | three-act, romancing-the-beat |
| YA Contemporary | save-the-cat, story-circle | three-act, freytag |
| YA Fantasy | heros-journey, save-the-cat | story-circle, epic-fantasy-arc |
| Young Adult | save-the-cat, story-circle | three-act, romancing-the-beat |
| Zombie Fiction | horror-fear-arc | thriller-12-beat, seven-point, three-act |

### Hybrid Genres

| Genre | Recommended | Secondary |
|-------|-------------|-----------|
| Horror Romance | horror-fear-arc, romancing-the-beat | three-act, save-the-cat |
| Historical Romance | romancing-the-beat, three-act | freytag, memoir-3-act |
| Paranormal Romance | romancing-the-beat, horror-fear-arc | three-act, save-the-cat, worldbuilding-arc |
| Romantic Suspense | romancing-the-beat, thriller-12-beat | three-act, save-the-cat |
| Dark Romance | romancing-the-beat, three-act | horror-fear-arc, seven-point |
| Romantic Thriller | thriller-12-beat, romancing-the-beat | three-act, save-the-cat, seven-point |
| Cozy Fantasy | cozy-mystery, worldbuilding-arc | three-act, story-circle |
| Gothic Horror | horror-fear-arc, freytag | three-act, seven-point |
| Speculative Mystery | cozy-mystery, worldbuilding-arc | three-act, seven-point |
| Historical Fantasy | epic-fantasy-arc, heros-journey | three-act, worldbuilding-arc |
| Sport Romance | romancing-the-beat, save-the-cat | three-act, seven-point |
| Western Romance | romancing-the-beat, save-the-cat | three-act, seven-point |

### Novella-Specific Mappings

| Genre | Recommended | Secondary |
|-------|-------------|-----------|
| Romance / Rom-Com / Erotica | novella-romance | novella-concentrated, novella-kiss |
| Historical / Paranormal / Dark Romance | novella-romance | novella-literary, novella-concentrated |
| Gothic / Horror Romance | novella-romance, novella-horror | novella-literary, novella-concentrated |
| Domestic / Espionage / Psych Thriller | novella-thriller | novella-concentrated, novella-kiss |
| Action Adventure / Crime / Military | novella-thriller | novella-concentrated, novella-kiss |
| Horror / Vampire / Zombie / Gothic | novella-horror | novella-concentrated, novella-kiss |
| Mystery / Cozy Mystery / Speculative Mystery | novella-mystery | novella-thriller, novella-concentrated |
| Fantasy / Sci-Fi / Cyberpunk / Dystopian | novella-speculative | novella-concentrated, novella-kiss |
| Literary / General / Upmarket / Drama | novella-literary | novella-kiss, novella-concentrated |
| Young Adult | novella-concentrated | novella-romance, novella-kiss |
| Middle Grade / Children's | novella-kiss | novella-concentrated |
| Default (genre not listed) | novella-concentrated | novella-kiss, novella-literary |
