---
name: format-rtf
description: "Rich Text Format (RTF) generation template"
user-invocable: false
---
<!-- (c) 2025 Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->
# RTF Generation Template

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.rtf`

This RTF export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Overview

Generate Rich Text Format files for universal compatibility. RTF opens in any word
processor on any operating system — Word, LibreOffice, TextEdit, WordPad, Google Docs
(via upload), and Pages. Use this when maximum compatibility matters.

## Manuscript Specifications

- **Page size:** US Letter (8.5" x 11")
- **Margins:** 1 inch all sides
- **Body font:** Times New Roman, 12pt
- **Chapter headings:** Times New Roman, 16pt, bold, centered
- **Line spacing:** Double-spaced (480 twips)
- **Paragraph spacing:** 0pt (double spacing handles vertical rhythm)
- **First line indent:** 0.5 inch (except first paragraph after heading)
- **Page breaks:** Between every chapter
- **Encoding:** UTF-8 with RTF Unicode escapes for special characters

## RTF Document Structure

```
{\rtf1\ansi\deff0
{\fonttbl{\f0 Times New Roman;}}
{\colortbl;\red0\green0\blue0;}
\paperw12240\paperh15840
\margl1440\margr1440\margt1440\margb1440
\widowctrl\ftnbj

[Title page content]
\page

[Chapter 1 content]
\page

[Chapter 2 content]
...
}
```

## Node.js Generation Template

```javascript
function createRtf(title, author, chapters) {
  const lines = [];

  // RTF header
  lines.push('{\\rtf1\\ansi\\ansicpg1252\\deff0');
  lines.push('{\\fonttbl{\\f0\\froman Times New Roman;}}');
  lines.push('{\\colortbl;\\red0\\green0\\blue0;}');
  lines.push('\\paperw12240\\paperh15840');
  lines.push('\\margl1440\\margr1440\\margt1440\\margb1440');
  lines.push('\\widowctrl\\ftnbj');
  lines.push('');

  // Title page
  lines.push('\\pard\\qc\\sb3600');
  lines.push(`{\\f0\\fs48\\b ${escapeRtf(title)}}`);
  lines.push('\\par\\sb400');
  lines.push(`{\\f0\\fs32 ${escapeRtf(author)}}`);
  lines.push('\\par');
  lines.push('\\page');

  // Chapters
  chapters.forEach((chapter, index) => {
    // Chapter heading
    lines.push('\\pard\\qc\\sb400\\sa400');
    lines.push(`{\\f0\\fs32\\b ${escapeRtf(`Chapter ${index + 1}: ${chapter.title}`)}}`);
    lines.push('\\par');

    // Chapter content
    const paragraphs = chapter.content.split('\n\n');
    let isFirstAfterBreak = true;

    paragraphs.forEach(para => {
      const trimmed = para.trim();
      if (!trimmed) return;

      // Scene break
      if (trimmed === '* * *' || trimmed === '---') {
        lines.push('\\pard\\qc\\sb200\\sa200');
        lines.push('{\\f0\\fs24 * * *}');
        lines.push('\\par');
        isFirstAfterBreak = true;
        return;
      }

      // Regular paragraph
      const indent = isFirstAfterBreak ? '\\fi0' : '\\fi720';
      lines.push(`\\pard\\ql${indent}\\sl480\\slmult1`);

      // Parse inline formatting
      const rtfContent = convertInlineToRtf(trimmed);
      lines.push(`{\\f0\\fs24 ${rtfContent}}`);
      lines.push('\\par');

      isFirstAfterBreak = false;
    });

    // Page break between chapters (not after last)
    if (index < chapters.length - 1) {
      lines.push('\\page');
    }
  });

  // Close document
  lines.push('}');

  return Buffer.from(lines.join('\n'), 'ascii');
}

function escapeRtf(text) {
  let result = '';
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    const char = text[i];

    if (char === '\\') result += '\\\\';
    else if (char === '{') result += '\\{';
    else if (char === '}') result += '\\}';
    else if (code === 0x2014) result += '\\emdash ';     // em-dash —
    else if (code === 0x2013) result += '\\endash ';     // en-dash –
    else if (code === 0x2018) result += '\\lquote ';     // left single quote '
    else if (code === 0x2019) result += '\\rquote ';     // right single quote '
    else if (code === 0x201C) result += '\\ldblquote ';  // left double quote "
    else if (code === 0x201D) result += '\\rdblquote ';  // right double quote "
    else if (code === 0x2026) result += '\\u8230 ...';   // ellipsis …
    else if (code > 127) result += `\\u${code} ?`;       // Unicode escape
    else result += char;
  }
  return result;
}

function convertInlineToRtf(text) {
  // Process bold and italic markers
  let result = escapeRtf(text);

  // Bold: **text** → {\b text}
  result = result.replace(/\\\*\\\*(.+?)\\\*\\\*/g, '{\\b $1}');

  // Italic: *text* → {\i text}
  result = result.replace(/\\\*(.+?)\\\*/g, '{\\i $1}');

  return result;
}
```

## Content Parsing Notes

1. All special characters must use RTF escape sequences
2. Unicode characters above 127 use `\uN ?` syntax (N = decimal code point)
3. Curly quotes, em-dashes, and ellipses get dedicated RTF control words
4. Split on double newlines for paragraph breaks
5. Convert scene breaks to centered `* * *`
6. First paragraph after heading or scene break: no indent (`\fi0`)
7. Subsequent paragraphs: 0.5" indent (`\fi720` — 720 twips = 0.5")
8. Bold: `**text**` → `{\b text}`
9. Italic: `*text*` → `{\i text}`

## Compatibility Notes

RTF 1.x is supported by:
- **Windows:** Word, WordPad, LibreOffice
- **macOS:** TextEdit, Pages, Word, LibreOffice
- **Linux:** LibreOffice, AbiWord
- **Web:** Google Docs (upload), Zoho Writer
- **Mobile:** Most document viewer apps

## Delivery Notes

When delivering an RTF file, include:
- Note that RTF is a universal format readable on any platform
- Formatting will appear correctly in any RTF-compatible word processor
- For submission portals that accept RTF, this file is ready to upload
