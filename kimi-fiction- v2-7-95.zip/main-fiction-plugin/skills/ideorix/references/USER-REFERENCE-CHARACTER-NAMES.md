# Character Name Generator — User Reference

## Quick Start

Say **"Name a character"** or **"Generate character names"** at any time.

During Story Bible generation (Phase 2A), the generator runs automatically for every character.

## What It Does

Generates historically accurate, culturally appropriate character names based on:
- **When** they were born (era-appropriate naming trends)
- **Where** they're from (geographic region and naming conventions)
- **What culture** shaped their naming (specific cultural traditions)

## The Process

1. **Engine defines** character role, age, background, region, cultural context
2. **Generator researches** era-appropriate names, regional conventions, class markers
3. **Engine presents** 5 name candidates with full justification
4. **You select** a name (or mix-and-match, request more, or provide your own)
5. **Name locked** into Story Bible and entity database

## Three Research Layers

### Layer 1: Era-Appropriate
A character born in 1952 gets a 1952 name, not a 2015 name. Naming trends mapped by decade across cultures.

### Layer 2: Regional Authenticity
| Region | Key Conventions |
|--------|----------------|
| East Asia | Family name first, generational names |
| South Asia | Varies by religion and region |
| West Africa | Day-names, praise-names, Islamic influence |
| Latin America | Two surnames (father's + mother's) |
| Eastern Europe | Patronymics, diminutives |
| Western Europe | Country-specific rules |

### Layer 3: Social Class
| Class | Naming Pattern |
|-------|---------------|
| Upper | Longer, traditional, formal, multiple given names |
| Middle | Aspirational, trend-following |
| Working | Shorter, practical, nicknames as legal names |
| Nobility | Dynastic, numbered, title conventions |

## Cast Differentiation

The engine automatically ensures:
- No two characters share a first initial (unless cast > 10)
- No same syllable count + stress pattern combinations
- No rhyming or near-rhyming surnames
- Protagonist and antagonist names contrast phonetically
- Names look distinct on the page

## Fantasy & Sci-Fi Worlds

For secondary worlds, the engine:
- Establishes sound palettes per culture/faction
- Ensures all names from one culture sound cohesive
- Different factions have audibly different naming
- All names pass the readability test (pronounceable on first read)
- POV character names pass the "coffee shop test" (barista-spellable)

## Each Candidate Includes

```
1. FULL NAME
   Given name origin:  Language, meaning, era of popularity
   Surname origin:     Etymology, regional origin
   Era accuracy:       Why it fits the birth year
   Cultural accuracy:  Why it fits the region/culture
   Class fit:          Why it matches social position
   Pronunciation:      Phonetic guide (if non-obvious)
   Nickname options:   2-3 natural shortenings
   Cast check:         Differentiation confirmed
```

## When It Runs

| Context | Trigger | Mode |
|---------|---------|------|
| Story Bible (Phase 2A) | Automatic | All characters named before writing begins |
| New character mid-manuscript | Architect flags in brief | Before Writer executes |
| On demand | "Name a character" | Interactive, any time |
