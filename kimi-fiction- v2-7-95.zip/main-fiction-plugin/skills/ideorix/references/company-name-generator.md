---
name: company-name-generator
description: "Era-accurate, region-specific fictional company and business name generator with real-world collision avoidance"
user-invocable: false
---
<!-- (c) 2025 James Harvey Media / Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->

# Company & Business Name Generator

## Overview

Generates fictional company, business, shop, organisation, and institution names
that are historically accurate, regionally authentic, and verified against
real-world entities. Integrated into Story Bible generation (Phase 2A) and
available on demand during chapter writing.

**Why this exists:** AI-generated business names cluster around predictable
patterns ("Nexus Technologies", "Horizon Dynamics", "Apex Solutions",
"The Gilded Fox", "Whiskers & Wands") that experienced readers spot instantly.
Worse, randomly generated names frequently collide with real companies, creating
legal risk and breaking reader immersion. This generator solves both problems.

## When It Runs

- **Automatically:** During Phase 2A (Story Bible Foundation) when the world
  and setting are being built — any named business, company, organisation, or
  institution in the Story Bible must go through this generator
- **On demand:** When the user says "name a business", "generate company names",
  "I need a shop name", or when a new business/organisation is introduced
  mid-manuscript

## Name Generation Protocol

### Step 1: Gather Business Context

For each business requiring a name, collect or derive these parameters:

```
BUSINESS NAME BRIEF:
  Type:            {shop / restaurant / pub / corporation / startup / law firm /
                    hospital / school / church / factory / newspaper / agency /
                    charity / criminal front / fictional brand / other}
  Founded:         {year or approximate era — e.g., 1923, "Victorian era",
                    "early 2000s", "far future"}
  Region:          {geographic location — e.g., "Brooklyn", "rural Devon",
                    "1920s Chicago", "Lagos", "Neo-Tokyo"}
  Culture:         {cultural context — e.g., "Italian-American community",
                    "post-industrial English", "Edo-period Japanese"}
  Industry:        {what the business does — e.g., "hardware store",
                    "biotech startup", "family bakery", "organised crime front"}
  Scale:           {sole trader / small family business / local chain / regional /
                    national / multinational / global conglomerate}
  Owner Background: {if known — owner's name, ethnicity, class, personality.
                     Many small businesses are named after their owners.}
  Tone:            {serious / warm / prestigious / gritty / whimsical / sinister /
                    corporate / homely — matches the story's treatment}
  Story Genre:     {from project setup — affects naming feel}
  Existing Names:  {businesses already named — for differentiation}
```

### Step 2: Historical and Regional Name Research

Apply these research layers in order:

**Layer 1 — Era-Appropriate Business Naming Conventions**

Business naming follows distinct historical patterns:

| Era | Naming Conventions | Examples |
|-----|-------------------|----------|
| Pre-1900 | Owner's surname, trade description, location reference. Rarely abstract. | "Whitfield & Sons", "The Crown Inn", "Hargreaves Iron Works" |
| 1900-1940 | Surname-based or trade + location. Early acronyms for large firms. Some patriotic/aspirational names. | "Brennan's Hardware", "Pacific Electric", "Imperial Chemical Industries" |
| 1940-1970 | Post-war corporate naming. Geographic + industry. Compound words. First "coined" names for large corporations. | "Midwest Manufacturing", "Consolidated Foods", "Unilever" |
| 1970-1990 | Acronyms peak. Abstract names emerge. "Tech" and "Systems" suffixes. Founder surnames for professional firms. | "TRW", "Atari", "CompuServe", "Goldman Sachs" |
| 1990-2010 | Internet era: lowercase, missing vowels, portmanteaus, ".com" culture. Playful names for startups. Established firms keep traditional names. | "Flickr", "Napster", "BlackBerry", "PayPal" |
| 2010-present | Single abstract words, Latin/Greek roots, nature words, AI-friendly. Short, global-sounding. | "Palantir", "Stripe", "Notion", "Figma" |
| Future | Extrapolate: single-syllable, alphanumeric, neo-classical, or ironically old-fashioned | "Vex", "Nth", "Callisto", "Old Earth Provisions" |

**These are English-language baselines.** Every culture has its own business
naming traditions. The engine must research the SPECIFIC culture's conventions.

**Layer 2 — Regional Business Naming Traditions**

| Region | Naming Conventions |
|--------|-------------------|
| **UK** | Pub names follow specific patterns (The [Noun] & [Noun], The [Adjective] [Animal]). High street shops often owner-surname based. Ltd/PLC suffixes. "& Sons", "& Co." for established firms. Regional chains reference counties/cities. |
| **US** | Main Street businesses named after owners or streets. Corporations: geographic + industry or abstract coined names. Regional variations (Southern: more formal; NYC: more direct; California: more creative). LLC/Inc/Corp suffixes. |
| **France** | Artisan businesses: "Maison [Surname]", "Atelier [Surname]". Cafés/restaurants: "Le/La [Noun]", "Chez [Name]". SARL/SA suffixes. |
| **Germany** | "GmbH" suffix. Compound descriptive names. Technical precision in naming. Surname + trade pattern. |
| **Japan** | Company name + 株式会社 (KK). Often founder's surname or aspirational kanji combinations. Western-style names for international-facing brands. |
| **China** | Auspicious characters (prosperity, harmony, fortune). Colour symbolism. Often founder's surname + trade. Many now have both Chinese and English names. |
| **Italy** | "Fratelli [Surname]" (Brothers). Religious saint references for old businesses. Family name prominence. SpA/Srl suffixes. |
| **Latin America** | "Hermanos [Surname]". SA/SRL suffixes. Geographic references. Catholic saint names for older establishments. |
| **Middle East** | "Al-[Name]" pattern. Family/tribal name prominence. Islamic finance terms for banks. Trading house traditions. |
| **India** | Family dynasty names. "& Sons", "& Brothers" patterns. Regional language naming. Pvt Ltd suffix. Aspirational English names for tech firms. |
| **Africa** | Varies hugely by region. West Africa: family names, aspirational words. East Africa: Swahili + English blends. South Africa: Afrikaans/English/Zulu naming. |

**Layer 3 — Business Type Naming Patterns**

Real businesses follow type-specific naming conventions:

```
NAMING PATTERNS BY BUSINESS TYPE:

  Pubs/Bars:       Named after historical events, heraldic symbols, local
                   landmarks, or traditional pub name formulas.
                   UK: "The Red Lion", "The King's Arms", "The Railway"
                   US: "O'Malley's", "The Rusty Nail", "Paddy's"

  Restaurants:     Owner's name, cuisine type, location, or atmosphere.
                   "Brennan's", "Canton Kitchen", "The Mill House"

  Shops:           Owner surname + trade. "Fletcher's Butchers",
                   "Cartwright & Sons Hardware", "Main Street Books"

  Law Firms:       Founding partner surnames. "Harmon, Steele & Associates",
                   "Whitaker LLP". Never cute or whimsical.

  Corporations:    Geographic + industry, abstract coined word, or
                   founder surname. "Northern Consolidated",
                   "Vanderberg Industries", "Prism Corp"

  Startups:        Short, punchy, often a single word or portmanteau.
                   May reference function obliquely. "Conduit", "Relay"

  Criminal fronts: Deliberately bland or respectable-sounding.
                   "Eastside Import & Export", "Premier Waste Management",
                   "Goodman Consulting Group"

  Newspapers:      [City/Region] + [Times/Herald/Post/Tribune/Gazette/Star].
                   "The Millbrook Herald", "Prairie County Star"

  Schools:         Named after founders, saints, or location.
                   "St. Benedict's", "Ashford Academy", "Lincoln High"

  Hospitals:       Named after benefactors, saints, or location.
                   "St. Mary's", "Hargrove Memorial", "County General"
```

### Step 3: Generate Candidates

Produce **5 name candidates** for each business, with:

```
1. [BUSINESS NAME]
   Naming logic:     {why this name — owner-based, location-based,
                      trade-based, or abstract, and why that choice
                      fits the era and region}
   Era accuracy:     {why this naming style fits the founding period}
   Regional fit:     {why this name works in this geographic/cultural setting}
   Type fit:         {why this naming convention matches the business type}
   Tone match:       {how the name serves the story's treatment of this business}
   Real-world check: {CONFIRMED: no major real-world company with this name
                      in the same industry. See Step 4.}
   Cast check:       {no collision with character names or other business names}
```

### Step 4: Real-World Collision Check

**This is the critical differentiator from character naming.**

For EACH candidate name, perform these checks:

```
REAL-WORLD COLLISION PROTOCOL:

1. EXACT MATCH CHECK
   - Would a reader Google this name and find a real company?
   - Is this the name of a well-known brand in ANY industry?
   - Could this be confused with a Fortune 500 / FTSE 100 company?
   → If YES to any: REJECT the candidate. Do not present it.

2. INDUSTRY MATCH CHECK
   - Is there a real company with a similar name in the SAME industry?
   - Even if not identical, would a reader think you meant the real company?
   → If YES: REJECT the candidate.

3. FAMOUS BRAND CHECK
   - Does this name evoke a well-known brand even if not identical?
   - Would it read as a thinly veiled reference or parody?
     (e.g., "Amazonia" for a tech company, "Mapple" for a phone maker)
   → If YES: REJECT unless deliberate satire approved by user.

4. PHONETIC SIMILARITY CHECK
   - Does the name SOUND like a real company when read aloud?
   - Could it be mistaken for a real brand in an audiobook?
   → If YES: REJECT the candidate.

5. LAWSUIT PLAUSIBILITY CHECK
   - If a real company with a similar name exists, could they
     plausibly claim the fictional use causes confusion or damages
     their brand?
   → If YES: REJECT the candidate. Err on the side of caution.
```

**The Obscurity Principle:** Prefer names that are plausible but *unmemorable*
to search engines. A hardware store called "Garfield's" is fine — it's too
generic to collide meaningfully. A tech startup called "Nexora" is risky —
readers will assume it's a real company and Google it.

**When a collision is unavoidable** (e.g., common naming patterns in a specific
industry), add a distinguishing element: a location prefix, a founder's name,
or a date ("Established 1923"). This makes the fictional name specific enough
to avoid confusion.

### Step 5: Differentiation Check

Before presenting candidates, verify against existing story names:

```
BUSINESS NAME DIFFERENTIATION RULES:
  1. No two businesses share a first word (unless one is a chain/subsidiary)
  2. No business name starts with the same letter as a main character's surname
     (avoids confusion in dialogue: "I'm going to Morrison's" — the person or the shop?)
  3. No business names that rhyme or alliterate with character names
  4. Business names should CONTRAST with each other in length and feel —
     if one business is "Hargrove & Sons", don't name another "Whitfield & Sons"
  5. For criminal fronts: the name must be boring enough to be forgettable
     (that's the point — readers should feel the blandness)
```

### Step 6: User Selection

Present candidates via AskUserQuestion:
- Select one of the 5
- Mix and match elements (e.g., surname from #1, structure from #3)
- Request 5 more candidates with adjusted parameters
- Provide their own name (engine validates it for era accuracy and runs the
  real-world collision check, flagging any issues but respecting the user's choice)

## Constructed Business Names Protocol (Fantasy / Sci-Fi / Secondary Worlds)

When the story is set in a secondary world:

### Linguistic Consistency with World-Building

1. **Match the culture's naming conventions** established for character names:
   - If a culture uses hard consonants for character names, its businesses should
     use similar phonetics
   - Businesses in trading cultures might have compound names; militant cultures
     might use single commanding words

2. **Business type reflects world-building:**
   - Medieval: guilds, workshops, inns named by their sign ("The Hammer and Tongs")
   - Futuristic: corporate naming trends extrapolated, possibly alphanumeric
   - Magical: may reference magical function or materials

3. **Readability test** — same as for character names. If the reader can't
   pronounce it, they'll skip over it, and you've lost a world-building opportunity.

## Integration with Story Bible (Phase 2A)

During Phase 2A world-building, the company name generator runs automatically
for any business, company, organisation, or institution that appears in the
story world:

1. The Story Architect defines each business's role in the plot, its type,
   founding era, and location
2. From the story's timeline and setting, derive the regional and cultural context
3. Run the name generation protocol for each named business
4. Run the real-world collision check on all candidates
5. Present all business names together for user approval before proceeding
6. Save approved names to the Story Bible and entity database

**System prompt injection for Phase 2A:**
```
BUSINESS/COMPANY NAMING: For every business, company, shop, organisation,
institution, or brand that appears in the story world, DO NOT assign a name
directly. Instead, define the business's type, founding era, region, industry,
scale, and narrative role. The Company Name Generator will produce era-accurate,
regionally authentic name candidates — each verified against real-world companies
— for the user to select. Assign placeholder labels (e.g., "PROTAGONIST'S
WORKPLACE", "THE LOCAL PUB", "THE ANTAGONIST'S CORPORATION") until names
are confirmed.
```

## On-Demand Usage (Mid-Manuscript)

When a new business appears during chapter generation:

1. The Architect flags the new business in the chapter brief
2. Before the Writer executes, run the name generator for the new business
3. User approves the name
4. Name is added to the entity database
5. Writer receives the confirmed name in its prompt

Trigger phrases:
- "Name a business"
- "Generate company names"
- "I need a shop/pub/restaurant name"
- "What would a [era] [region] [type] business be called?"

## Anti-Patterns

### AI Business Name Patterns — NEVER USE

These are the business-name equivalents of "Marcus Chen" — instant AI tells:

```
BANNED PATTERNS:
  - [Abstract Noun] + [Tech Suffix]:  "Nexus Technologies", "Apex Systems",
    "Pinnacle Solutions", "Zenith Dynamics", "Vanguard Analytics"
  - [Adjective] + [Animal]:           "The Gilded Fox", "The Silver Stag",
    "The Crimson Owl", "The Jade Serpent"
  - [Whimsy] & [Whimsy]:              "Whiskers & Wands", "Petals & Prose",
    "Brambles & Brew", "Quill & Compass"
  - The Cozy [Noun]:                  "The Cozy Corner", "The Cozy Cup",
    "The Cozy Nook", "The Cozy Hearth"
  - The Enchanted [Noun]:             "The Enchanted Garden", "The Enchanted Page"
  - [Colour] + [Gemstone/Metal]:      "Crimson Sapphire", "Obsidian & Gold"
  - [Greek/Latin Root] + [Corp]:      "Helix Corp", "Omni Industries",
    "Proteus Global", "Aether Dynamics"
  - The [Adjective] [Craft Noun]:     "The Rustic Spoon", "The Gilded Quill",
    "The Velvet Curtain", "The Polished Stone"
```

### Other Anti-Patterns

- Do NOT give every pub a "charming" or "atmospheric" name — real pubs are
  often boringly named ("The Railway", "The Red Lion", "The Crown")
- Do NOT make corporate names sound sinister just because the company is evil
  in the plot — real evil corporations have boring names
- Do NOT use names that telegraph the business's plot role (a money laundering
  front shouldn't be called "Shadowbank Trading")
- Do NOT default to English naming conventions for businesses in non-English-speaking settings
- Do NOT use names from the genre file's "Names to Avoid" section
- Do NOT use names from `forbidden-words.md` or `authenticity-guard.md`
- Do NOT give every small business a "quirky" or "artisanal" name — most real
  small businesses have straightforward names
- Do NOT name businesses after the street they're on AND the thing they sell
  (e.g., "High Street Hardware on High Street") — this reads as lazy worldbuilding
