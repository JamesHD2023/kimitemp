---
name: plottr-importer
description: Import a Plottr Word export (.docx) into Ideorix — converts beats, characters, places, and storylines into a complete Story Bible
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the technical protocol document. The user-facing skill lives in `plottr-import.md` (same folder) — that's where the trigger phrases and branding rule live. This file is loaded by reference during import execution.


> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*

# Plottr Importer

## Purpose

Convert a Plottr **Word export** (`.docx`) into a working Ideorix project
with a complete Story Bible — characters, places, subplots, timeline, beat
structure, and chapter outline — ready to feed straight into chapter
generation. Unlike the Novelcrafter Importer (which imports manuscript
prose), Plottr imports an OUTLINE: there are no chapters yet, only the
structural blueprint. The handoff is to Phase 2C (Story Bible review),
not Phase 3 (chapter generation).

This is a **one-way import.** Once complete, the Ideorix project becomes
the authoritative working copy.

## When to Use

Trigger phrases:
- "Import from Plottr"
- "Import my Plottr project"
- "Bring my Plottr outline across"
- "Plottr import"
- "I have a Plottr project" / "I'm moving from Plottr"
- "I planned my book in Plottr"

## Prerequisites

The user must provide a **Plottr Word export (`.docx`)**, produced by:

1. In Plottr, open the project to import
2. File → Export → **Word document**
3. Tick the defaults (Outline, Characters, Places, Notes)
4. Save the resulting `.docx`

The user is asked to place the file in
`~/Documents/Ideorix-Projects/imports/` (the importer finds it
automatically) or have the full file path ready.

**Why Word export and not `.pltr` JSON?** The `.docx` format is stable
across Plottr versions and subscription tiers, human-readable, and uses
predictable markers (`Begin Summary` / `End Summary`, `Description` /
`Category` / `Notes` field sequences) that make parsing unambiguous. The
`.pltr` JSON schema has changed across major Plottr releases — building
against `.docx` is more robust.

---

## Input Format Reference

A Plottr Word export contains three top-level sections in this order:

### 1. Outline section
- Begins with the standalone heading `Outline`
- Beats grouped under day headers (e.g. `Saturday`, `Sunday`, `Monday`)
- Each beat has the structure:
  ```
  {Beat Title} ({Storyline})
  Begin Summary
  {optional summary text — may be empty}
  End Summary
  ```
- Storylines tagged in parentheses: `Main Plot`, plus user-defined subplots
  (e.g. `Teens`, `Killer`) and template tracks (e.g. `Act 1: Ordinary World`,
  `Act 2: Reactive`, `Act 3: Proactive`, `Act 4: Confrontation`)
- Day headers represent chronological grouping in Plottr's timeline view
- The same day name may appear multiple times for multi-week stories

### 2. Characters section
- Begins with the standalone heading `Characters`
- Each character is a block of paragraphs:
  ```
  {Full Name}
  (blank)
  Description
  {short bio}
  Category
  {Main | Supporting | Book One | etc.}
  Notes
  {optional notes}
  Nickname
  {comma-separated aliases, may include parenthetical context}
  Age
  {age}
  Gender
  Race
  Eye Color
  Hair Color
  Skin Color
  Height
  Weight
  Religion
  City of Birth
  Education
  Job Title
  Bad Habits
  Good Habits
  Life Goals
  Fears
  ```
- Not all fields are populated for every character — handle missing fields gracefully
- Custom user-defined fields may also appear with `{Field Name}` / `{value}` pairs

### 3. Places section
- Begins with the standalone heading `Places`
- Same format as Characters: `{Name}` / `Description` / `Category` / `Notes`
- May be empty (the heading appears even if no places are defined)

---

## Template Beat Detection

Some beats include Plottr's built-in template instructions, identifiable by:
- A storyline tag matching `Act {N}: {phase}` (e.g. `Act 1: Ordinary World`)
- A `--- Add Your Details Above this Line ---` marker inside the summary
- Template content below the marker (instructional text from Plottr's beat sheet templates)

When parsing:
- The text ABOVE the `--- Add Your Details Above this Line ---` marker is
  the user's actual content for that beat
- The text BELOW the marker is template instructional content — STRIP IT
- If the entire summary is template content (no user content above the marker),
  treat the beat as a structural placeholder, not a real beat

**Detected template tracks** become Story Bible Section 13 (Beat Structure)
content. The detected template name (Save the Cat, Hero's Journey, etc.) is
inferred from the storyline tag pattern.

---

## Processing Pipeline

Run these steps in order. Do not parallelise.

### Step 1: Locate the export

Look for a `.docx` file in `~/Documents/Ideorix-Projects/imports/`. If
multiple are found, ask the user which one. If none, ask the user to
provide the full path.

### Step 2: Unpack the .docx

**Read-Verification HARD GATE applies (see `read-verification.md`).**
Before unpacking, verify the Plottr `.docx` Read returned content
above the threshold (≥ 100 chars). DOCX Read failures (locked files,
oversized files, corrupted exports) return success metadata with
empty extracted text — proceeding to ZIP-extraction would produce a
blank document.xml and an empty Story Bible. If the Read failed,
BLOCK and surface the failed read to the user with the three
resolution options (paste / skip / re-upload) before any parse
logic runs.

The `.docx` is a ZIP archive. Extract to a temp directory.

```
{temp_dir}/
├── [Content_Types].xml
├── _rels/
├── docProps/
└── word/
    ├── document.xml      ← the main content
    ├── media/             ← embedded character images (ignore — not used)
    └── ...
```

### Step 3: Parse document.xml

The body is a single line of XML. Extract paragraph text by walking all
`<w:p>` elements and concatenating their `<w:t>` children. Preserve order
and preserve blank paragraphs (they're structural separators between beats
and characters).

### Step 4: Validate top-level structure

Verify the document contains:
- An `Outline` heading (mandatory)
- A `Characters` heading (mandatory)
- A `Places` heading (optional but expected)

If any mandatory heading is missing, surface an error and ask the user to
re-export from Plottr with the standard sections enabled.

### Step 5: Parse the Outline section

Walk paragraphs from `Outline` until `Characters`. Track state:

- **Day header detected** when a paragraph matches `Saturday|Sunday|Monday|Tuesday|Wednesday|Thursday|Friday` (optionally with `AM`/`PM` suffix). Start a new day group.
- **Beat title detected** when a paragraph matches `^(.+?) \(([^)]+)\)$`. Extract title and storyline tag.
- **Beat content** is everything between `Begin Summary` and `End Summary`.
- **Strip template content** if `--- Add Your Details Above this Line ---` is present.

Build an internal beat ledger:

```
beats = [
  {day: "Saturday", title: "Chapter One", storyline: "Main Plot", summary: "..."},
  {day: "Saturday", title: "Rick Opens", storyline: "Teens", summary: ""},
  ...
]
```

### Step 6: Parse the Characters section

Walk paragraphs from `Characters` until `Places` (or end). Each character
starts with a non-empty title line followed by a blank then `Description`.

For each character, walk forward collecting alternating field-name /
field-value pairs until the next blank-then-name pattern. Store as a record:

```
character = {
  name: "Aileen Diedre Brannigan",
  description: "Divorced mother of one...",
  category: "Main",
  nicknames: ["Leena", "AB", "Granny Branny", "Lila", "Alibi", "Dee-Dee"],
  fields: {age: 51, gender: "Female", ...}
}
```

**Nickname parsing:** Split on commas, but PRESERVE parenthetical context.
Examples:
- `"Leena, AB, Granny Branny (jovial, from kids)"` →
  `["Leena", "AB", "Granny Branny (jovial, from kids)"]`
- `"Lila, Alibi (former husband, hates it now), Dee-Dee (mother, hates it)"` →
  `["Lila", "Alibi (former husband, hates it now)", "Dee-Dee (mother, hates it)"]`

The parenthetical context is critical for the Continuity Guardian and
Prose Humaniser — it tells them who calls the character what.

### Step 7: Parse the Places section

Same algorithm as Characters but with `Description` / `Category` / `Notes`
plus any custom user-defined fields. Often empty — handle gracefully.

### Step 8: Preview and confirm

Display a summary to the user:

```
Plottr import preview:
  Title:        {detected from filename or first paragraph}
  Total beats:  {count}
    Main Plot:  {count}
    Subplots:   {list of storyline names with counts}
    Templates:  {list of detected beat structure templates}
  Characters:   {count}
  Places:       {count}
  Days in timeline: {count} ({first day} → {last day})

Proceed with import? (yes / cancel)
```

### Step 9: Build the Story Bible

Construct a complete Story Bible with these sections populated from
parsed data:

| Story Bible Section | Source |
|---|---|
| Section 1 (Title, Genre, etc.) | Title from filename; rest asked at reduced setup |
| Section 2 (Characters) | Each parsed character → bio block with name + aliases (from Nickname) + description + traits derived from fields |
| Section 5 (Locations) | Each parsed place |
| Section 7 (Subplots) | Non-Main-Plot storylines (Teens, Killer, etc.) — each becomes a subplot track with the beats from that storyline as the subplot arc |
| Section 11 (Timeline) | Day headers in order, with beats grouped by day |
| Section 12 (Chapter Outline) | Main Plot beats in order, with a heuristic for chapter grouping (see Step 10) |
| Section 13 (Beat Structure) | Template tracks (Act 1 / Act 2A / etc.) — populated as the project's selected beat structure |
| Section 14 (Chekhov's Guns) | Empty — Plottr doesn't track Chekhov guns; user adds during reduced setup |

### Step 10: Chapter grouping heuristic

Plottr beats don't map 1:1 to chapters — they're scenes/moments. Group
consecutive Main Plot beats into chapters using this rule:

```
target_beats_per_chapter = lookup(length_tier_typical_beats_per_chapter)
  Short Story / Novelette: 3
  Novella / Standard Novel: 4
  Epic Novel: 5
```

The user picks the length tier during reduced setup. Then group:
- Take the Main Plot beats in order
- Slot the first N beats into Chapter 1
- Slot the next N into Chapter 2
- Continue until exhausted

If subplot beats (Teens, Killer, etc.) interleave with Main Plot beats by
day-grouping, weave them into the same chapters by their day proximity:
"Saturday Main Plot beats + Saturday subplot beats → Chapters in the
Saturday sequence."

Surface the proposed chapter grouping to the user:

```
Proposed chapter outline (you can adjust before approving):
  Ch 1 (Saturday): {beat 1}, {beat 2}, {beat 3}
  Ch 2 (Saturday): {beat 4}, {beat 5}, {beat 6}
  Ch 3 (Sunday):   {beat 7}, {beat 8}, {beat 9}
  ...
```

### Step 11: Reduced Phase 1 setup

Plottr doesn't record certain things Ideorix needs. Ask only these:

| Question | Why it's needed |
|---|---|
| Genre | Plottr doesn't have a genre field; controls genre plugin loading |
| Dialect | US or GB English; Plottr is dialect-agnostic |
| Length tier | Plottr is length-agnostic; needed for chapter grouping heuristic |
| POV preference | Plottr doesn't track POV at the beat level |
| Voice profile | Optional — attach existing or skip |
| Pen name | Optional — attach existing or skip |
| Romance subplot? Heat level? Tropes? | Standard Phase 1 questions, asked normally |

Skip these questions (Plottr already provides the answer):
- Outline source (Plottr is the outline)
- Beat structure (template tracks already detected)
- Chekhov's guns (asked separately during Story Bible review)

### Step 12: Build the workspace

Create the standard Ideorix project structure at the user-confirmed path:

```
~/Documents/Ideorix-Projects/{Title}/
├── project-config.md
├── manuscript/
│   └── (empty — chapters generated later)
├── marketing/
└── engine-data/
    ├── story-bible.md          ← built from parsed Plottr data
    ├── entities/
    │   ├── characters.md
    │   └── places.md
    ├── outline.md              ← Section 12 chapter outline
    ├── beat-structure.md       ← Section 13 template tracks
    ├── trope-plan.md           ← user-confirmed tropes
    └── imports/
        └── plottr-export/      ← original .docx for reference (optional)
```

### Step 12b: Post-Import Lockfile Generation (MANDATORY)

After the Story Bible is assembled, generate MODERN MODE infrastructure:

1. **Entity Canon Lockfile** — Generate `entity-canon.md` from the
   imported characters, locations, and objects. Verify with Bash ls.
2. **Pipeline Checkpoint** — Generate `pipeline-checkpoint.md` (v2
   schema, header rows only — no chapters written yet for a Plottr
   outline-only import). Verify with Bash ls.
3. **Running Banlist** — Generate empty `running-banlist.md` starter.
   Verify with Bash ls.
4. **Forbidden root-file scan** — Bash ls `engine-data/` and confirm
   no forbidden files present.

5. **Architect Mode flag (MANDATORY — v2.7.1+).** Imported
   material is user-supplied canon by definition; the import
   flow MUST set Architect mode so downstream agents
   (Architect, Writer, Quality Guardian) treat the imported
   content as authoritative rather than as raw material to
   reinterpret. Write the following to
   `engine-data/project-config.md`:

   ```markdown
   architect_mode: true
   architect_mode_set_at: {ISO 8601 timestamp}
   architect_mode_source: plottr-import
   import_source: plottr
   ```

   Verify the write with Bash ls; read back to confirm.
   Every downstream agent reads `architect_mode` and applies
   its Architect Mode Binding (see `blueprint-agent.md` §
   Architect Mode Binding, `prose-agent.md` § Architect Mode
   Binding, `quality-gate.md` § Architect Mode Binding).

6. **Source-canon mirror (MANDATORY — v2.7.1+).** Copy the
   imported user material into `source-canon/plottr-import/`
   so the Step 0 filesystem trigger fires uniformly across
   BYO-canon and import paths. The mirror is read-only canon
   — the engine reads from it but never writes back. The
   engine-data/ files are the WORKING copy; source-canon/
   preserves the original imported state for reference.

**The imported Story Bible is the user's canon.** Downstream
agents execute the user's characters, not improve them. The
Architect mode flag set in Step 5 above MAKES THIS
STRUCTURALLY ENFORCED rather than convention-only. See
`blueprint-agent.md` § Architect Mode Binding,
`outline-builder.md` § Anti-Rewriting Rule.

### Step 13: Hand off to Story Bible review

Present the assembled Story Bible to the user for review (Phase 2C in
the standard `core-pipeline.md` flow). The user approves the Story Bible
exactly as if it had been auto-generated by the engine.

Once approved, the project is ready to enter Phase 3 (Chapter Generation).
The Outline Conformance Agent will check every chapter brief against
Section 12 — which is now populated from the user's Plottr outline.

---

## Anti-Patterns

1. **Do NOT discard storyline tags.** Subplots are first-class story
   structure, not metadata. They map to Story Bible Section 7.
2. **Do NOT auto-merge similar character names.** "Aileen" and "Aileen
   Diedre Brannigan" might both appear in beats — preserve both, the
   alias matching is the Continuity Guardian's job.
3. **Do NOT strip parenthetical context from nicknames.** "Granny Branny
   (jovial, from kids)" tells the engine WHO calls her that. Critical
   for dialogue authenticity.
4. **Do NOT include Plottr template content in beat summaries.** Strip
   everything below `--- Add Your Details Above this Line ---`.
5. **Do NOT fabricate chapter numbers when Plottr has none.** Use the
   chapter grouping heuristic from Step 10. Surface the result for user
   approval before locking it in.

## Error Handling

| Error | Response |
|---|---|
| File not found | Ask user for full path |
| File is not a valid `.docx` | Surface error, ask for re-export |
| `Outline` heading missing | Surface error, ask user to re-export with outline enabled |
| `Characters` heading missing | Surface error, ask user to re-export with characters enabled |
| Empty beat summaries throughout | Warn user — outline has no content, only structure |
| Unrecognised storyline tags | Treat as user-defined subplot (Section 7) |
| Character with no Description field | Warn but continue — use empty description |
| Slug collision with existing project | Append suffix (`-2`, `-3`, etc.) |

## Future Expansion

v2 will add:
- Custom field detection (Plottr supports user-defined character/place fields)
- Tag and category extraction
- Multi-book project support (Plottr can store series — currently we import one book at a time)
- `.pltr` JSON support as an alternative to `.docx`
