---
name: pen-name
description: "Create and manage author pen names with genre-appropriate bios"
user-invocable: false
---
<!-- (c) 2025 James Harvey Media / Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine

# Pen Name Studio

Create, manage, and select author pen names. Each pen name comes with a genre-tailored
professional bio in three lengths (short, medium, long) and persona notes for consistent
author branding across all your projects.

## What You Can Do

1. **Create a new pen name** — Genre-informed name generation with 5 candidates,
   plus professional author bios in three lengths
2. **View my pen names** — Browse all saved pen names with their bios and usage history
3. **Edit a pen name** — Update name, bios, persona notes, or genre affinity
4. **Delete a pen name** — Remove a pen name profile (with confirmation)
5. **Generate new bios** — Create fresh bio variants for an existing pen name
6. **Back to main menu**

## How It Works

The engine generates pen names that are genre-appropriate — romance names sound different
from thriller names. Names are checked for shelf positioning, pronounceability, and
uniqueness within your existing pen name collection.

Each pen name includes:
- **Short bio** (50-75 words) — for Amazon author pages and back-of-book
- **Medium bio** (100-150 words) — for author websites and press kits
- **Long bio** (200-300 words) — for query letters and speaking engagements
- **Persona notes** — voice, social media tone, author photo style guidance
- **Voice profile** (optional) — a linked writing voice that loads automatically as your Style Guide

Pen names are saved to your local Ideorix Projects folder and persist across all projects.
You can select a pen name during project setup or assign one before export. When a pen name
has a linked voice profile, selecting it automatically sets your writing voice.

→ Protocol: `pen-name-generator.md`
