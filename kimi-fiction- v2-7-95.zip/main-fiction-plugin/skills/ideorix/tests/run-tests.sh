#!/bin/bash
# ============================================================
# Ideorix Test Harness — Mechanical Audit Regression Tests
# ============================================================
# Run all tests: bash tests/run-tests.sh
# Run single test: bash tests/run-tests.sh <module-name>
# ============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
TESTDIR=$(mktemp -d)
trap 'rm -rf "$TESTDIR"' EXIT

PASS=0
FAIL=0

run_test() {
    local name="$1"
    local script="$2"
    local input="$3"
    local expected_exit="${4:-0}"
    local check_errors="${5:-yes}"
    shift 5 || true
    local extra_args="$@"

    echo "--- TEST: $name ---"
    local output_file="$TESTDIR/${name// /_}.out"
    local exit_code=0

    if bash "$PLUGIN_ROOT/scripts/$script" "$input" $extra_args > "$output_file" 2>&1; then
        exit_code=0
    else
        exit_code=$?
    fi

    local has_shell_errors=0
    if grep -q 'integer expression expected\|command not found\|No such file' "$output_file" 2>/dev/null; then
        has_shell_errors=1
    fi

    local status="PASS"
    local reasons=""

    if [ "$exit_code" -ne "$expected_exit" ]; then
        status="FAIL"
        reasons="exit $exit_code (expected $expected_exit)"
    fi

    if [ "$check_errors" = "yes" ] && [ "$has_shell_errors" -eq 1 ]; then
        status="FAIL"
        if [ -n "$reasons" ]; then reasons="$reasons; "; fi
        reasons="${reasons}shell errors detected"
    fi

    if [ "$status" = "PASS" ]; then
        echo "  PASS"
        PASS=$((PASS + 1))
    else
        echo "  FAIL — $reasons"
        echo "  Output:"
        sed 's/^/    /' "$output_file"
        FAIL=$((FAIL + 1))
    fi
}

echo "=== IDEORIX MECHANICAL AUDIT TESTS ==="
echo ""

# --- number-7-bias: zero digit-sevens (the fixed bug) ---
cat > "$TESTDIR/zero-seven.md" <<'EOF'
# Chapter Zero

She looked at the map. The year was 1840.

The boy was eleven.

It was 3:45 in the afternoon.
EOF

run_test "number-7-bias: zero digit-sevens" \
    "number-7-bias.sh" \
    "$TESTDIR/zero-seven.md" \
    "0" \
    "yes"

# --- number-7-bias: chapter with sevens (FAIL content) ---
cat > "$TESTDIR/with-seven.md" <<'EOF'
# Chapter Seven

She counted seven stones. The year was 1847.

Seven birds flew overhead. It was 3:45.
EOF

run_test "number-7-bias: with digit-sevens" \
    "number-7-bias.sh" \
    "$TESTDIR/with-seven.md" \
    "1" \
    "yes"

# --- word-count-check: normal chapter (PASS) ---
cat > "$TESTDIR/wordcount.md" <<'EOF'
# Chapter One

She looked at the map. He walked to the door. The sun was setting over the hills. Birds sang in the trees. A cool breeze moved through the open window. She sat down at the desk and began to write. The pen moved across the page. Words formed slowly, carefully. Each sentence carried weight. The story needed to be told. Time passed. Shadows lengthened. Evening approached.
EOF

run_test "word-count-check: normal chapter" \
    "word-count-check.sh" \
    "$TESTDIR/wordcount.md" \
    "0" \
    "yes" \
    "30"

# --- typography-sweep: ASCII quotes (FAIL content) ---
cat > "$TESTDIR/ascii-quotes.md" <<'EOF'
# Chapter

"Hello," she said. The boy could not help but smile.
EOF

run_test "typography-sweep: ASCII quotes detected" \
    "typography-sweep.sh" \
    "$TESTDIR/ascii-quotes.md" \
    "1" \
    "yes"

# --- typography-sweep: clean curly quotes (PASS) ---
# Use printf with literal curly quotes to avoid heredoc normalization
printf '# Chapter\n\n\u201cHello,\u201d she said. The boy could not help but smile.\n' > "$TESTDIR/curly-quotes.md"
run_test "typography-sweep: curly quotes PASS" \
    "typography-sweep.sh" \
    "$TESTDIR/curly-quotes.md" \
    "0" \
    "yes"

# --- placeholder-scan: no placeholders (PASS) ---
cat > "$TESTDIR/clean.md" <<'EOF'
# Chapter

She looked at the map. The year was 1840.
EOF

run_test "placeholder-scan: clean chapter" \
    "placeholder-scan.sh" \
    "$TESTDIR/clean.md" \
    "0" \
    "yes"

# --- placeholder-scan: with placeholders (FAIL content) ---
cat > "$TESTDIR/dirty.md" <<'EOF'
# Chapter

She looked at the [MAP]. There was a TBD here.

{insert description} and a NOTE TO EDITOR.
EOF

run_test "placeholder-scan: placeholders detected" \
    "placeholder-scan.sh" \
    "$TESTDIR/dirty.md" \
    "1" \
    "yes"

# --- read-verification: txt file (PASS) ---
echo "This is a test document with enough content." > "$TESTDIR/test.txt"
run_test "read-verification: txt file" \
    "read-verification.sh" \
    "$TESTDIR/test.txt" \
    "0" \
    "yes" \
    "txt"

# --- formatting-check: normal dialogue (PASS) ---
cat > "$TESTDIR/dialogue.md" <<'EOF'
# Chapter

She looked at him. "We need to go," she said.

He nodded. "I know."
EOF

run_test "formatting-check: dialogue separation" \
    "formatting-check.sh" \
    "$TESTDIR/dialogue.md" \
    "0" \
    "yes"

# --- temporal-verify: permitted month (PASS) ---
cat > "$TESTDIR/summer.md" <<'EOF'
# Chapter

It was a hot July afternoon. The summer sun beat down.
EOF

run_test "temporal-verify: permitted month" \
    "temporal-verify.sh" \
    "$TESTDIR/summer.md" \
    "0" \
    "yes" \
    "July" "summer"

# --- temporal-verify: forbidden month (FAIL content) ---
cat > "$TESTDIR/winter.md" <<'EOF'
# Chapter

It was a cold December morning. The winter snow fell.
EOF

run_test "temporal-verify: forbidden month" \
    "temporal-verify.sh" \
    "$TESTDIR/winter.md" \
    "1" \
    "yes" \
    "July" "summer"

# --- pattern-counter: zero-tolerance pattern (FAIL content) ---
cat > "$TESTDIR/patterns.md" <<'EOF'
# Chapter

She had a sense of dread. She could not help but look.
EOF

run_test "pattern-counter: AI patterns" \
    "pattern-counter.sh" \
    "$TESTDIR/patterns.md" \
    "1" \
    "yes"

# --- forbidden-words-scan: clean chapter (PASS) ---
cat > "$TESTDIR/fwclean.md" <<'EOF'
# Chapter

She walked to the door. The cat sat on the mat.
EOF

run_test "forbidden-words: clean chapter" \
    "forbidden-words-scan.sh" \
    "$TESTDIR/fwclean.md" \
    "0" \
    "yes" \
    "$PLUGIN_ROOT/references/forbidden-words.md"

# --- pre-flight-gate: missing bible (FAIL gate) ---
mkdir -p "$TESTDIR/bad-project/engine-data"
echo "test" > "$TESTDIR/bad-project/engine-data/project-config.md"
run_test "pre-flight-gate: missing bible FAIL" \
    "pre-flight-gate.sh" \
    "$TESTDIR/bad-project" \
    "1" \
    "yes" \
    "1"

# --- batch-edit-gate: chapter 3 (PASS) ---
mkdir -p "$TESTDIR/good-project/engine-data"
echo "test" > "$TESTDIR/good-project/engine-data/pipeline-checkpoint.md"
run_test "batch-edit-gate: chapter 3 PASS" \
    "batch-edit-gate.sh" \
    "$TESTDIR/good-project" \
    "0" \
    "yes" \
    "3"

# --- config-validator: valid project (WARN, not FAIL) ---
mkdir -p "$TESTDIR/valid-project/engine-data"
echo "test" > "$TESTDIR/valid-project/engine-data/pipeline-checkpoint.md"
run_test "config-validator: minimal project WARN" \
    "config-validator.sh" \
    "$TESTDIR/valid-project" \
    "0" \
    "yes"

# --- config-validator: missing project (FAIL) ---
run_test "config-validator: missing project FAIL" \
    "config-validator.sh" \
    "$TESTDIR/nonexistent" \
    "1" \
    "yes"

# --- entity-canon-verify: no drift (PASS) ---
cat > "$TESTDIR/canon.md" <<'EOF'
# Canon

| Name | Type |
|------|------|
| Finn | protagonist |
| Oxford | place |
EOF
cat > "$TESTDIR/ch-canon.md" <<'EOF'
# Chapter

Finn walked through Oxford.
EOF
run_test "entity-canon-verify: no drift PASS" \
    "entity-canon-verify.sh" \
    "$TESTDIR/ch-canon.md" \
    "0" \
    "yes" \
    "$TESTDIR/canon.md"

# --- anaphora-detect: clean chapter (PASS) ---
cat > "$TESTDIR/no-anaphora.md" <<'EOF'
# Chapter

The sun rose over the hills. Birds began to sing in the trees.

A cool breeze moved through the open window. She sat down at the desk.

He walked to the door and paused. The clock struck midnight.
EOF
run_test "anaphora-detect: clean chapter PASS" \
    "anaphora-detect.sh" \
    "$TESTDIR/no-anaphora.md" \
    "0" \
    "yes"

# --- anaphora-detect: anaphora abuse (FAIL content) ---
cat > "$TESTDIR/anaphora-abuse.md" <<'EOF'
# Chapter

She looked at the door. She looked at the window. She looked at the clock.

The rain fell. The rain fell harder. The rain fell all night.
EOF
run_test "anaphora-detect: anaphora abuse detected" \
    "anaphora-detect.sh" \
    "$TESTDIR/anaphora-abuse.md" \
    "1" \
    "yes"

# --- waiver-check: active waiver (PASS) ---
mkdir -p "$TESTDIR/waiver-project/references"
mkdir -p "$TESTDIR/waiver-project/chapters"
cat > "$TESTDIR/waiver-project/references/waivers.md" <<'EOF'
| Chapter | Module | Reason | Expires |
|---------|--------|--------|---------|
| waived-chapter.md | number-7-bias | Chapter literally about The Seven Stones | never |
EOF
touch "$TESTDIR/waiver-project/chapters/waived-chapter.md"
run_test "waiver-check: active waiver" \
    "waiver-check.sh" \
    "$TESTDIR/waiver-project/chapters/waived-chapter.md" \
    "0" \
    "yes" \
    "number-7-bias" "$TESTDIR/waiver-project"

# --- waiver-check: no waiver (FAIL — no waiver found) ---
run_test "waiver-check: no waiver" \
    "waiver-check.sh" \
    "$TESTDIR/waiver-project/chapters/waived-chapter.md" \
    "1" \
    "yes" \
    "typography-sweep" "$TESTDIR/waiver-project"

# --- plugin-lint: run on actual plugin (PASS — dead refs resolved) ---
run_test "plugin-lint: actual plugin" \
    "plugin-lint.sh" \
    "" \
    "0" \
    "yes"

# --- batch-edit-gate: no checkpoint (PASS) ---
mkdir -p "$TESTDIR/beg-no-checkpoint/engine-data"
run_test "batch-edit-gate: no checkpoint PASS" \
    "batch-edit-gate.sh" \
    "$TESTDIR/beg-no-checkpoint" \
    "0" \
    "yes" \
    "3"

# --- batch-edit-gate: non-batch chapter (PASS) ---
mkdir -p "$TESTDIR/beg-nonbatch/engine-data"
echo "test" > "$TESTDIR/beg-nonbatch/engine-data/pipeline-checkpoint.md"
run_test "batch-edit-gate: non-batch chapter PASS" \
    "batch-edit-gate.sh" \
    "$TESTDIR/beg-nonbatch" \
    "0" \
    "yes" \
    "3"

# --- batch-edit-gate: batch without completion (FAIL) ---
mkdir -p "$TESTDIR/beg-batch-nocmpl/engine-data"
echo "test" > "$TESTDIR/beg-batch-nocmpl/engine-data/pipeline-checkpoint.md"
run_test "batch-edit-gate: batch without completion FAIL" \
    "batch-edit-gate.sh" \
    "$TESTDIR/beg-batch-nocmpl" \
    "1" \
    "yes" \
    "5"

# --- batch-edit-gate: batch with completion (PASS) ---
mkdir -p "$TESTDIR/beg-batch-cmpl/engine-data"
echo "Batch Edit 5: complete" > "$TESTDIR/beg-batch-cmpl/engine-data/pipeline-checkpoint.md"
run_test "batch-edit-gate: batch with completion PASS" \
    "batch-edit-gate.sh" \
    "$TESTDIR/beg-batch-cmpl" \
    "0" \
    "yes" \
    "5"

# --- batch-edit-gate: final chapter without completion (FAIL) ---
mkdir -p "$TESTDIR/beg-final-nocmpl/engine-data"
echo "test" > "$TESTDIR/beg-final-nocmpl/engine-data/pipeline-checkpoint.md"
run_test "batch-edit-gate: final chapter without completion FAIL" \
    "batch-edit-gate.sh" \
    "$TESTDIR/beg-final-nocmpl" \
    "1" \
    "yes" \
    "5" "5"

# ============================================================
# v2.7.92 markdown-to-docx-render.sh tests
# ============================================================
DOCX_RENDER="$PLUGIN_ROOT/scripts/markdown-to-docx-render.sh"

# --- markdown-to-docx-render: missing arg (FAIL) ---
set +e
bash "$DOCX_RENDER" > /dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 1 ]; then
    echo "  PASS"
    PASS=$((PASS + 1))
else
    echo "  FAIL — exit $EXIT (expected 1)"
    FAIL=$((FAIL + 1))
fi

# --- markdown-to-docx-render: nonexistent project (FAIL) ---
set +e
bash "$DOCX_RENDER" "/nonexistent/project/path" > /dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 1 ]; then
    echo "  PASS"
    PASS=$((PASS + 1))
else
    echo "  FAIL — exit $EXIT (expected 1)"
    FAIL=$((FAIL + 1))
fi

# --- markdown-to-docx-render: missing chapters dir (FAIL) ---
RENDER_TMP=$(mktemp -d)
mkdir -p "$RENDER_TMP/engine-data"
set +e
bash "$DOCX_RENDER" "$RENDER_TMP" > /dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 2 ]; then
    echo "  PASS"
    PASS=$((PASS + 1))
else
    echo "  FAIL — exit $EXIT (expected 2)"
    FAIL=$((FAIL + 1))
fi

# --- markdown-to-docx-render: empty chapters dir (FAIL) ---
mkdir "$RENDER_TMP/engine-data/chapters"
set +e
bash "$DOCX_RENDER" "$RENDER_TMP" > /dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 2 ]; then
    echo "  PASS"
    PASS=$((PASS + 1))
else
    echo "  FAIL — exit $EXIT (expected 2)"
    FAIL=$((FAIL + 1))
fi

RENDER_BASENAME=$(basename "$RENDER_TMP")
EXPECTED_DOCX="$RENDER_TMP/manuscript/${RENDER_BASENAME}.docx"

cat > "$RENDER_TMP/engine-data/chapters/ch01.md" <<'CHAPTER_EOF'
---
chapter: 1
---

# Chapter 1: The SL*18

The Marantz **SL*18** released in 1979. A literal asterisk in a
model number — the input that broke v2.7.x ad-hoc renderers — must
render without infinite-looping. *Italics work*. **Bold works**.

* * *

Em-dashes — like this one — should also pass through.
CHAPTER_EOF

if command -v pandoc > /dev/null 2>&1; then
    set +e
    bash "$DOCX_RENDER" "$RENDER_TMP" > /dev/null 2>&1
    EXIT=$?
    set -e
    if [ "$EXIT" -eq 0 ] && [ -f "$EXPECTED_DOCX" ]; then
        echo "  PASS — end-to-end render produces valid DOCX at manuscript/{Title}.docx"
        PASS=$((PASS + 1))
    else
        echo "  FAIL — end-to-end render failed (exit $EXIT, expected $EXPECTED_DOCX)"
        FAIL=$((FAIL + 1))
    fi

    if [ -f "$EXPECTED_DOCX" ] && \
       unzip -p "$EXPECTED_DOCX" word/document.xml 2>/dev/null | \
       grep -q "SL\*18"; then
        echo "  PASS — literal asterisk 'SL*18' preserved in output"
        PASS=$((PASS + 1))
    else
        echo "  FAIL — literal asterisk not preserved"
        FAIL=$((FAIL + 1))
    fi

    # v2.7.92 regression: default path must NOT write to engine-data/manuscript.docx
    if [ ! -f "$RENDER_TMP/engine-data/manuscript.docx" ]; then
        echo "  PASS — regression: no stale DOCX at engine-data/manuscript.docx"
        PASS=$((PASS + 1))
    else
        echo "  FAIL — regression: DOCX leaked to engine-data/manuscript.docx"
        FAIL=$((FAIL + 1))
    fi
else
    set +e
    OUTPUT=$(bash "$DOCX_RENDER" "$RENDER_TMP" 2>&1)
    EXIT=$?
    set -e
    if [ "$EXIT" -eq 3 ] && echo "$OUTPUT" | grep -q "pandoc not installed"; then
        echo "  PASS — missing pandoc exits 3 with install hint"
        PASS=$((PASS + 1))
    else
        echo "  FAIL — missing pandoc behaviour wrong (exit $EXIT)"
        FAIL=$((FAIL + 1))
    fi
    echo "  SKIP — end-to-end + literal-asterisk-preservation + engine-data-regression (pandoc not present)"
fi

rm -rf "$RENDER_TMP"

echo ""
echo "=== TEST SUMMARY ==="
echo "Passed: $PASS"
echo "Failed: $FAIL"

if [ "$FAIL" -gt 0 ]; then
    exit 1
else
    exit 0
fi
