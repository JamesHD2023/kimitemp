#!/bin/bash
# ============================================================
# Test: Source Canon Grounding Gate
# ============================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
TESTDIR=$(mktemp -d)
trap 'rm -rf "$TESTDIR"' EXIT

echo "=== SOURCE CANON GROUNDING GATE TESTS ==="
echo ""

# --- TEST 1: Happy path (all verifications pass) ---
mkdir -p "$TESTDIR/project/engine-data/reports"
mkdir -p "$TESTDIR/project/source-canon/worldbuilding"

# Create a source file
cat > "$TESTDIR/project/source-canon/worldbuilding/geography.md" <<'EOF'
# Geography of Lower Marston

Lower Marston sits in a fold of the Cotswold hills, where the River Windrush
runs shallow and clear over limestone gravel. The village has existed since
the Domesday Book, though the name has changed twice in nine hundred years.

The parish boundary follows the river on three sides, marked by ancient
hawthorn hedgerows that were planted when the land was enclosed in 1767.
On the fourth side, the boundary is a dry stone wall that runs along the
ridge of Marston Hill, where the wind moves through the beech trees with
a sound like water.

The common land occupies the flat ground between the river and the railway
embankment. It was never enclosed because the railway company bought the
cutting rights in 1847 and left the top as rough pasture. The grass there
grows coarse and tufted, full of sorrel and yellow rattle in summer.
EOF

# Compute sha256
SHA=$(sha256sum "$TESTDIR/project/source-canon/worldbuilding/geography.md" | awk '{print $1}')

# Create artifact with valid samples
python3 - "$TESTDIR" "$SHA" <<'PYEOF'
import sys, os

testdir = sys.argv[1]
sha = sys.argv[2]

artifact = f"""# Source Canon Grounding Artifact
# Generated: 2026-05-17T12:00:00Z
# For step: Outline Builder Step 10
# Project: Test Project

project: Test Project
step: Outline Builder Step 10
generated_at: 2026-05-17T12:00:00Z

files:
  - path: source-canon/worldbuilding/geography.md
    sha256: {sha}
    sample_count: 3
    samples:
      - "Lower Marston sits in a fold of the Cotswold hills, where the River Windrush"
      - "The parish boundary follows the river on three sides, marked by ancient"
      - "The common land occupies the flat ground between the river and the railway"
    key_facts:
      - "Lower Marston is in the Cotswolds"
      - "River Windrush runs through the village"
      - "Common land exists between river and railway"

min_samples_per_file: 3
min_files_with_samples: 1
required_total_samples: 3
"""

with open(f"{testdir}/project/engine-data/reports/source-canon-grounding.yaml", 'w') as f:
    f.write(artifact)
PYEOF

echo "--- TEST 1: Happy path (all verifications pass) ---"
if bash "$PLUGIN_ROOT/scripts/source-canon-grounding-gate.sh" "$TESTDIR/project" > "$TESTDIR/test1.out" 2>&1; then
    echo "  PASS"
    grep "STATUS: PASS" "$TESTDIR/test1.out" > /dev/null && echo "  Verdict: PASS confirmed"
else
    echo "  FAIL — exit code $?"
    cat "$TESTDIR/test1.out"
fi
echo ""

# --- TEST 2: SHA256 mismatch (file changed since artifact) ---
echo "--- TEST 2: SHA256 mismatch (stale memory simulation) ---"
# Modify the file after artifact generation
echo "New content added later" >> "$TESTDIR/project/source-canon/worldbuilding/geography.md"

if bash "$PLUGIN_ROOT/scripts/source-canon-grounding-gate.sh" "$TESTDIR/project" > "$TESTDIR/test2.out" 2>&1; then
    echo "  FAIL — should have exited 1"
    cat "$TESTDIR/test2.out"
else
    exit_code=$?
    if [ "$exit_code" -eq 1 ]; then
        echo "  PASS — exit 1 (FAIL) as expected"
        grep "SHA256 mismatch" "$TESTDIR/test2.out" > /dev/null && echo "  SHA256 mismatch detected"
    else
        echo "  FAIL — wrong exit code: $exit_code"
        cat "$TESTDIR/test2.out"
    fi
fi

# Restore file for next test
head -n -1 "$TESTDIR/project/source-canon/worldbuilding/geography.md" > "$TESTDIR/project/source-canon/worldbuilding/geography.md.tmp"
mv "$TESTDIR/project/source-canon/worldbuilding/geography.md.tmp" "$TESTDIR/project/source-canon/worldbuilding/geography.md"
echo ""

# --- TEST 3: Fabricated sample (not in file) ---
echo "--- TEST 3: Fabricated sample (not in file) ---"
python3 - "$TESTDIR" "$SHA" <<'PYEOF'
import sys, os

testdir = sys.argv[1]
sha = sys.argv[2]

artifact = f"""# Source Canon Grounding Artifact
project: Test Project
step: Outline Builder Step 10
generated_at: 2026-05-17T12:00:00Z

files:
  - path: source-canon/worldbuilding/geography.md
    sha256: {sha}
    sample_count: 3
    samples:
      - "Lower Marston sits in a fold of the Cotswold hills, where the River Windrush"
      - "This sentence does not exist in the file at all and is fabricated"
      - "The common land occupies the flat ground between the river and the railway"
    key_facts:
      - "Lower Marston is in the Cotswolds"

min_samples_per_file: 3
min_files_with_samples: 1
required_total_samples: 3
"""

with open(f"{testdir}/project/engine-data/reports/source-canon-grounding.yaml", 'w') as f:
    f.write(artifact)
PYEOF

if bash "$PLUGIN_ROOT/scripts/source-canon-grounding-gate.sh" "$TESTDIR/project" > "$TESTDIR/test3.out" 2>&1; then
    echo "  FAIL — should have exited 1"
    cat "$TESTDIR/test3.out"
else
    exit_code=$?
    if [ "$exit_code" -eq 1 ]; then
        echo "  PASS — exit 1 (FAIL) as expected"
        grep "NOT FOUND" "$TESTDIR/test3.out" > /dev/null && echo "  Fabricated sample detected"
    else
        echo "  FAIL — wrong exit code: $exit_code"
        cat "$TESTDIR/test3.out"
    fi
fi
echo ""

# --- TEST 4: Missing artifact ---
echo "--- TEST 4: Missing artifact ---"
rm -f "$TESTDIR/project/engine-data/reports/source-canon-grounding.yaml"

if bash "$PLUGIN_ROOT/scripts/source-canon-grounding-gate.sh" "$TESTDIR/project" > "$TESTDIR/test4.out" 2>&1; then
    echo "  FAIL — should have exited 2"
    cat "$TESTDIR/test4.out"
else
    exit_code=$?
    if [ "$exit_code" -eq 2 ]; then
        echo "  PASS — exit 2 (NO ARTIFACT) as expected"
    else
        echo "  FAIL — wrong exit code: $exit_code"
        cat "$TESTDIR/test4.out"
    fi
fi
echo ""

# --- TEST 5: Disabled in config ---
echo "--- TEST 5: Disabled in config ---"
echo "source_canon_grounding: disabled" > "$TESTDIR/project/project-config.md"

set +e
bash "$PLUGIN_ROOT/scripts/source-canon-grounding-gate.sh" "$TESTDIR/project" > "$TESTDIR/test5.out" 2>&1
exit_code=$?
set -e
if [ "$exit_code" -eq 3 ]; then
    echo "  PASS — exit 3 (NOT ENABLED) as expected"
    grep "SKIP" "$TESTDIR/test5.out" > /dev/null && echo "  Skip confirmed"
else
    echo "  FAIL — wrong exit code: $exit_code"
    cat "$TESTDIR/test5.out"
fi
echo ""

# --- TEST 6: Legacy opt-out (pre-v2.8.0 project) ---
echo "--- TEST 6: Legacy opt-out (pre-v2.8.0 project) ---"
echo "source_canon_grounding: legacy" > "$TESTDIR/project/project-config.md"

set +e
bash "$PLUGIN_ROOT/scripts/source-canon-grounding-gate.sh" "$TESTDIR/project" > "$TESTDIR/test6.out" 2>&1
exit_code=$?
set -e
if [ "$exit_code" -eq 3 ]; then
    echo "  PASS — exit 3 (NOT ENABLED) as expected"
    grep "pre-v2.8.0 project" "$TESTDIR/test6.out" > /dev/null && echo "  Legacy opt-out confirmed"
else
    echo "  FAIL — wrong exit code: $exit_code"
    cat "$TESTDIR/test6.out"
fi
echo ""

echo "=== TEST SUMMARY ==="
echo "All 6 tests completed."
