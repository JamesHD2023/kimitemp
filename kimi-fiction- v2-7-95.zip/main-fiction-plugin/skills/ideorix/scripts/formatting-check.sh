#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 2: Formatting Check
# Counts em-dashes, ellipses, exclamation marks, semicolons.
# Separates narration from dialogue by extracting quoted spans,
# not by splitting whole lines. Handles mixed-mode lines correctly.
# ============================================================
set -euo pipefail

CHAPTER="${1:?Usage: formatting-check.sh <chapter-file> [mode]}"
MODE="${2:-ai}"
if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT
FAIL=0

WORD_COUNT=$(wc -w < "$CHAPTER")

# Strip YAML front matter (between opening and closing ---) and markdown headings.
# Normalize em-dash family imposters (U+2015 HORIZONTAL BAR, U+2E3A/3B TWO/THREE-
# EM, U+FE58 SMALL EM) to U+2014. Some authoring tools (Pages in some locales,
# certain markdown editors, copy-paste from formatted web pages / PDFs) insert
# these visually-identical variants instead of real em-dashes; without
# normalization the regex below misses them and silently passes a chapter that
# violates the em-dash rule.
awk 'BEGIN{fm=0} /^---$/{fm++; next} fm==1{next} /^#/{next} {print}' "$CHAPTER" \
    | perl -CSDA -pe 's/[\x{2015}\x{2E3A}\x{2E3B}\x{FE58}]/\x{2014}/g' \
    > "$TMPDIR/body.txt"

# DIALOGUE: extract content between matching quote pairs.
# Handles both straight " ... " and curly " ... " plus curly ' ... '.
# Markdown processors and modern editors often auto-substitute curly quotes,
# so handling both is required for correct narration / dialogue separation.
# Uses perl -CSDA for proper UTF-8 handling.
perl -CSDA -ne '
    while (/[\x{201C}"]([^\x{201D}"]*)[\x{201D}"]/g) { print "$1\n" }
    while (/[\x{2018}]([^\x{2019}]*)[\x{2019}]/g)    { print "$1\n" }
' "$TMPDIR/body.txt" > "$TMPDIR/dial.txt" 2>/dev/null || true

# NARRATION: remove quoted spans (leave context) — what remains is narration.
perl -CSDA -pe '
    s/[\x{201C}"][^\x{201D}"]*[\x{201D}"]//g;
    s/[\x{2018}][^\x{2019}]*[\x{2019}]//g;
' "$TMPDIR/body.txt" > "$TMPDIR/narr.txt" 2>/dev/null || true

safe_count() { local c; c=$(eval "$1" 2>/dev/null) || true; echo "${c:-0}" | tr -dc '0-9'; }

# Match em-dash (—), en-dash (–), and double-hyphen (--)
NARR_EMDASH=$(safe_count "grep -oE '—|–|--' '$TMPDIR/narr.txt' | wc -l")
DIAL_EMDASH=$(safe_count "grep -oE '—|–|--' '$TMPDIR/dial.txt' | wc -l")
NARR_ELLIPSIS=$(safe_count "grep -o '\.\.\.' '$TMPDIR/narr.txt' | wc -l")
NARR_EXCLAIM=$(safe_count "grep -o '!' '$TMPDIR/narr.txt' | wc -l")
DIAL_SEMICOLON=$(safe_count "grep -o ';' '$TMPDIR/dial.txt' | wc -l")
AND_STARTS=$(safe_count "grep -cE '^\s*(And |And,)' '$CHAPTER'")
BUT_STARTS=$(safe_count "grep -cE '^\s*(But |But,)' '$CHAPTER'")

echo "=== FORMATTING CHECK ==="
echo "Chapter: $CHAPTER"
echo "Word count: $WORD_COUNT"
echo "Mode: $MODE"
echo ""

echo "--- Em-Dashes ---"
if [ "$MODE" = "ai" ]; then
    echo "  Narration em-dashes: $NARR_EMDASH (target: 0)"
    if [ "$NARR_EMDASH" -gt 0 ]; then
        echo "  STATUS: FAIL — $NARR_EMDASH narration em-dashes (zero tolerance)"
        # Show the narration lines containing em-dashes for debugging
        grep -nE '—|–|--' "$TMPDIR/narr.txt" 2>/dev/null | head -10 | sed 's/^/    /'
        FAIL=1
    else
        echo "  STATUS: PASS"
    fi
    echo "  Dialogue em-dashes: $DIAL_EMDASH (cap: ≤3 per chapter)"
    if [ "$DIAL_EMDASH" -gt 3 ]; then
        echo "  STATUS: FAIL — $DIAL_EMDASH dialogue em-dashes (cap: 3)"
        FAIL=1
    else
        echo "  STATUS: PASS"
    fi
else
    # Human-written mode: max 3 per 1000 words narration
    WORDS_DIV=$(( WORD_COUNT / 1000 ))
    [ "$WORDS_DIV" -lt 1 ] && WORDS_DIV=1
    MAX_NARR=$(( WORDS_DIV * 3 ))
    echo "  Narration em-dashes: $NARR_EMDASH (cap: ≤$MAX_NARR for ${WORD_COUNT} words)"
    if [ "$NARR_EMDASH" -gt "$MAX_NARR" ]; then
        echo "  STATUS: FAIL"; FAIL=1
    else
        echo "  STATUS: PASS"
    fi
fi

echo ""
echo "--- Other Punctuation ---"
echo "  Narration ellipses: $NARR_ELLIPSIS (cap: ≤3)"
[ "$NARR_ELLIPSIS" -gt 3 ] && { echo "  STATUS: FAIL"; FAIL=1; } || echo "  STATUS: PASS"
echo "  Narration exclamation marks: $NARR_EXCLAIM (cap: ≤1)"
[ "$NARR_EXCLAIM" -gt 1 ] && { echo "  STATUS: FAIL"; FAIL=1; } || echo "  STATUS: PASS"
echo "  Dialogue semicolons: $DIAL_SEMICOLON (target: 0)"
[ "$DIAL_SEMICOLON" -gt 0 ] && { echo "  STATUS: FAIL"; FAIL=1; } || echo "  STATUS: PASS"

echo ""
echo "--- Sentence Starters ---"
echo "  Sentences starting with 'And': $AND_STARTS (cap: ≤2)"
[ "$AND_STARTS" -gt 2 ] && { echo "  STATUS: FAIL"; FAIL=1; } || echo "  STATUS: PASS"
echo "  Sentences starting with 'But': $BUT_STARTS (cap: ≤2)"
[ "$BUT_STARTS" -gt 2 ] && { echo "  STATUS: FAIL"; FAIL=1; } || echo "  STATUS: PASS"

echo ""
if [ "$FAIL" -eq 1 ]; then
    echo "STATUS: FAIL"
    exit 1
else
    echo "STATUS: PASS"
    exit 0
fi
