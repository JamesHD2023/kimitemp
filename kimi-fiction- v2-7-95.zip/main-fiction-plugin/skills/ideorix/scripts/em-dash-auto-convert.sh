#!/bin/bash
# Ideorix — Em-Dash Auto-Converter (v2.7.89)
# Python-backed deterministic substitution for narration em-dashes.
# Stashes YAML frontmatter, fenced code blocks, markdown headings, and
# quoted spans (curly double, ASCII double). Substitutes narration
# em-dashes only:
#   —. —! —? → drop em-dash, keep terminal punct
#   — → , (comma + space)
#   any other em-dash → ,
# Writes .bak per chapter. Honors formatting_mode: human as a no-op.
# Usage: bash em-dash-auto-convert.sh <chapter-file> [mode]
# Exit: 0 converted | 1 error | 2 no-op (human mode)
set -euo pipefail

CHAPTER="${1:?Usage: em-dash-auto-convert.sh <chapter-file> [mode]}"
MODE="${2:-ai}"
if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

if [ "$MODE" = "human" ]; then
    echo "Em-dash auto-convert: NO-OP (formatting_mode: human) — $CHAPTER"
    exit 2
fi

python3 - "$CHAPTER" <<'PYEOF'
import sys, re, shutil

chapter = sys.argv[1]
backup = chapter + ".bak"
shutil.copy2(chapter, backup)

with open(chapter, "r", encoding="utf-8") as f:
    text = f.read()

# Stash zones we must not touch
stashes = []
counter = 0

def stash(m):
    global counter
    token = f"\x00STASH{counter:06d}\x00"
    stashes.append((token, m.group(0)))
    counter += 1
    return token

# YAML frontmatter
if text.startswith("---"):
    text = re.sub(r'^---\n.*?\n---\n', stash, text, count=1, flags=re.DOTALL)

# Fenced code blocks
for _ in range(5):  # iterate to catch adjacent blocks
    text = re.sub(r'```.*?```', stash, text, count=1, flags=re.DOTALL)

# Markdown headings
for _ in range(50):
    text = re.sub(r'^#{1,6}\s+.*$', stash, text, count=1, flags=re.MULTILINE)

# Quoted spans: curly double " ... " and ASCII double " ... "
# Process greedily; we protect dialogue from em-dash conversion.
for _ in range(200):
    text = re.sub(r'[""][^""]*[""]', stash, text, count=1)
for _ in range(200):
    text = re.sub(r'"[^"]*"', stash, text, count=1)

# Now perform narration em-dash substitution on the remaining text
# Rule 1: —. —! —? → drop em-dash, keep terminal punct
# Rule 2: — → , (comma + space)
# Rule 3: any other em-dash variant → ,
def sub_emdash(m):
    punct = m.group(1)
    return punct  # drop the em-dash, keep the punctuation

# U+2014 EM DASH variants
# — followed by . ! ?
text = re.sub(r'—(?=[.!?])', '', text)
# remaining —
text = text.replace('—', ', ')

# Also normalize other em-dash family imposters that may have survived
# U+2015 HORIZONTAL BAR, U+2E3A/3B TWO/THREE-EM, U+FE58 SMALL EM
text = re.sub(r'[\u2015\u2E3A\u2E3B\uFE58](?=[.!?])', '', text)
text = text.replace('\u2015', ', ').replace('\u2E3A', ', ').replace('\u2E3B', ', ').replace('\uFE58', ', ')

# Unstash
for token, original in stashes:
    text = text.replace(token, original, 1)

with open(chapter, "w", encoding="utf-8") as f:
    f.write(text)

print(f"Em-dash auto-convert: DONE — {chapter} (backup: {backup})")
PYEOF

exit 0
# ============================================================
# DEFENSIVE PAD — do not edit.
# ============================================================
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
