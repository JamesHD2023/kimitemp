#!/bin/bash
# ============================================================
# Ideorix — Market Scout Gate (Cowork Phase 3 / Fix 10)
# Blocks downstream actions (cover design, marketing pack, KDP
# prep, launch sequencing) until Market Scout has been run
# recently for the project's category.
#
# Fail-closed: exits non-zero if the Market Scout cache is
# missing or stale.
# ============================================================
# Usage: bash market-scout-gate.sh <project-root> [<staleness-days>]
# - project-root:   path to Ideorix-Projects/{Book}
# - staleness-days: optional; max age of market-pulse.md (default 180)
#
# A project passes the Market Scout gate when:
#   - engine-data/market-pulse.md exists, AND
#   - its mtime is no more than <staleness-days> old
#
# This catches the common failure mode where a launch is
# planned without recent comp-set / category intelligence.
#
# Exit codes:
#   0  Market Scout cache present and fresh (PASS)
#   1  cache missing or stale — gate is failing (FAIL)
#   2  invalid arguments

set -euo pipefail

PROJECT="${1:?Usage: market-scout-gate.sh <project-root> [<staleness-days>]}"
STALE_DAYS="${2:-180}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

if ! [[ "$STALE_DAYS" =~ ^[0-9]+$ ]]; then
    echo "ERROR: staleness-days must be a non-negative integer, got: $STALE_DAYS" >&2
    exit 2
fi

PULSE="$PROJECT/engine-data/market-pulse.md"
CONFIG="$PROJECT/engine-data/project-config.md"

# Honest opt-out — if project-config.md declares this project's
# market intelligence as offline / stale / legacy (typically because
# the project pre-dates Rule 8 or web search was unavailable), pass
# with a note instead of blocking. Convention introduced in v2.3.5.
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*market_intelligence_status:[[:space:]]*(offline|stale|legacy)\b' "$CONFIG"; then
        DECL=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*market_intelligence_status:' "$CONFIG" | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*market_intelligence_status:[[:space:]]*//' | awk '{print $1}')
        echo "MARKET SCOUT GATE: PASS (project-config.md declares market_intelligence_status: ${DECL} — documented opt-out honored)"
        exit 0
    fi
fi

if [ ! -f "$PULSE" ]; then
    echo "MARKET SCOUT GATE: FAIL — no engine-data/market-pulse.md present." >&2
    echo "ACTION: run Market Scout on this project's category. The result writes to:" >&2
    echo "  $PULSE" >&2
    echo "This gate will then pass, and downstream actions (cover, marketing, launch) may proceed." >&2
    echo "" >&2
    echo "If this project pre-dates Rule 8 or web search is unavailable, declare the" >&2
    echo "documented opt-out in $CONFIG:" >&2
    echo "  market_intelligence_status: offline    (web search unavailable)" >&2
    echo "  market_intelligence_status: stale      (last live run > staleness cap, no refresh planned)" >&2
    echo "  market_intelligence_status: legacy     (project pre-dates Rule 8)" >&2
    exit 1
fi

# Cross-platform mtime: macOS uses `stat -f %m`, GNU uses `stat -c %Y`.
if stat -f %m "$PULSE" >/dev/null 2>&1; then
    PULSE_MTIME=$(stat -f %m "$PULSE")
else
    PULSE_MTIME=$(stat -c %Y "$PULSE")
fi
NOW=$(date +%s)
AGE_SECONDS=$((NOW - PULSE_MTIME))
AGE_DAYS=$((AGE_SECONDS / 86400))
STALE_SECONDS=$((STALE_DAYS * 86400))

if [ "$AGE_SECONDS" -le "$STALE_SECONDS" ]; then
    echo "MARKET SCOUT GATE: PASS (market-pulse.md is ${AGE_DAYS} day(s) old; cap ${STALE_DAYS})"
    exit 0
fi

echo "MARKET SCOUT GATE: FAIL — market-pulse.md is ${AGE_DAYS} day(s) old (cap ${STALE_DAYS})." >&2
echo "ACTION: re-run Market Scout to refresh the comp-set and category intelligence." >&2
echo "The refreshed file at $PULSE will reset the staleness clock and this gate will pass." >&2
echo "" >&2
echo "Or, if you accept the staleness for this project, append the following line to" >&2
echo "  $CONFIG" >&2
echo "  market_intelligence_status: stale" >&2
exit 1
