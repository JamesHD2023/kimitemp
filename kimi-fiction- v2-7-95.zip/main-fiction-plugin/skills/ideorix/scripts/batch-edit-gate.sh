#!/bin/bash
# ============================================================
# Ideorix — Batch Edit Gate
# Blocks Progress Dashboard rendering when a batch edit is due.
# Fail-closed: exits non-zero if gate is unmet.
# ============================================================
# Usage: bash batch-edit-gate.sh <project-root> <current-chapter-number> [<total-chapter-count>]
# - project-root: path to Ideorix-Projects/{Book} (contains engine-data/)
# - current-chapter-number: integer, the chapter just completed
# - total-chapter-count: optional; if current == total, gate also fires for final batch

set -euo pipefail

PROJECT="${1:?Usage: batch-edit-gate.sh <project-root> <chapter-N> [<total>]}"
CHAPTER_N="${2:?Usage: batch-edit-gate.sh <project-root> <chapter-N> [<total>]}"
TOTAL="${3:-0}"

CHECKPOINT="$PROJECT/engine-data/pipeline-checkpoint.md"

if [ ! -f "$CHECKPOINT" ]; then
    echo "BATCH EDIT GATE: PASS (no checkpoint — assume new project, no batch due yet)"
    exit 0
fi

# Determine whether a batch edit is due: every 5th chapter OR the final chapter
BATCH_DUE=0
if [ "$((CHAPTER_N % 5))" -eq 0 ] && [ "$CHAPTER_N" -gt 0 ]; then
    BATCH_DUE=1
    REASON="chapter $CHAPTER_N is divisible by 5"
fi
if [ "$TOTAL" -gt 0 ] && [ "$CHAPTER_N" -eq "$TOTAL" ]; then
    BATCH_DUE=1
    REASON="chapter $CHAPTER_N is the final chapter"
fi

if [ "$BATCH_DUE" -eq 0 ]; then
    echo "BATCH EDIT GATE: PASS (chapter $CHAPTER_N — no batch edit due)"
    exit 0
fi

# Batch edit IS due. Check whether it has run for this boundary.
BOUNDARY="$CHAPTER_N"
if grep -qE "^Batch Edit ${BOUNDARY}:[[:space:]]*complete" "$CHECKPOINT" 2>/dev/null; then
    echo "BATCH EDIT GATE: PASS (batch edit at chapter $BOUNDARY marked complete)"
    exit 0
fi

# Gate is failing.
echo "BATCH EDIT GATE: FAIL — $REASON, and no 'Batch Edit $BOUNDARY: complete' line in checkpoint." >&2
echo "ACTION: run the batch editor (see batch-editor.md), then append the following line to the checkpoint using the bash-direct protocol:" >&2
echo "  Batch Edit $BOUNDARY: complete  ($(date -u '+%Y-%m-%dT%H:%M:%SZ'))" >&2
echo "Only then may the Progress Dashboard render for chapter $CHAPTER_N." >&2
exit 1
