#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 8: Temporal Verification
# Extracts month/season/day references, checks against permitted
# lists, builds timeline reference table.
# ============================================================
# Usage: bash temporal-verify.sh <chapter-file> <permitted-months> <permitted-season>
# permitted-months: comma-separated (e.g., "October,November")
# permitted-season: single value (e.g., "autumn")

set -euo pipefail

CHAPTER="${1:?Usage: temporal-verify.sh <chapter-file> <permitted-months> <permitted-season>}"
PERMITTED_MONTHS="${2:?Usage: temporal-verify.sh <chapter-file> <permitted-months> <permitted-season>}"
PERMITTED_SEASON="${3:?Usage: temporal-verify.sh <chapter-file> <permitted-months> <permitted-season>}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT
FAIL=0

tr '[:upper:]' '[:lower:]' < "$CHAPTER" > "$TMPDIR/lower.txt"

safe_count() { local c; c=$(eval "$1" 2>/dev/null) || true; echo "${c:-0}" | tr -dc '0-9'; }

echo "=== TEMPORAL VERIFICATION ==="
echo "Chapter: $CHAPTER"
echo "Permitted months: $PERMITTED_MONTHS"
echo "Permitted season: $PERMITTED_SEASON"
echo ""

# Extract all month references
ALL_MONTHS="january|february|march|april|may|june|july|august|september|october|november|december"
echo "--- Month References ---"

FOUND_MONTHS=$(grep -oEi "\b($ALL_MONTHS)\b" "$CHAPTER" 2>/dev/null | tr '[:upper:]' '[:lower:]' | sort | uniq -c | sort -rn || true)

if [ -z "$FOUND_MONTHS" ]; then
    echo "  No month references found"
else
    # Use here-string to avoid subshell — FAIL=1 must propagate
    PERMITTED_LOWER=$(echo "$PERMITTED_MONTHS" | tr '[:upper:]' '[:lower:]')
    while read -r count month; do
        [ -z "$month" ] && continue
        if echo "$PERMITTED_LOWER" | grep -qi "$month"; then
            printf "  %-12s %3d occurrences  PERMITTED\n" "$month" "$count"
        else
            printf "  %-12s %3d occurrences  VIOLATION — not in permitted list\n" "$month" "$count"
            FAIL=1
        fi
    done <<< "$FOUND_MONTHS"
fi

# Extract season references
echo ""
echo "--- Season References ---"
SEASONS="spring|summer|autumn|fall|winter"
FOUND_SEASONS=$(grep -oEi "\b($SEASONS)\b" "$CHAPTER" 2>/dev/null | tr '[:upper:]' '[:lower:]' | sort | uniq -c | sort -rn || true)

PERMITTED_SEASON_LOWER=$(echo "$PERMITTED_SEASON" | tr '[:upper:]' '[:lower:]')

if [ -z "$FOUND_SEASONS" ]; then
    echo "  No season references found"
else
    while read -r count season; do
        [ -z "$season" ] && continue
        # "fall" and "autumn" are treated as equivalent
        if [ "$season" = "$PERMITTED_SEASON_LOWER" ] \
            || { [ "$season" = "fall" ] && [ "$PERMITTED_SEASON_LOWER" = "autumn" ]; } \
            || { [ "$season" = "autumn" ] && [ "$PERMITTED_SEASON_LOWER" = "fall" ]; }; then
            printf "  %-10s %3d occurrences  PERMITTED\n" "$season" "$count"
        else
            printf "  %-10s %3d occurrences  CHECK — not the declared season\n" "$season" "$count"
        fi
    done <<< "$FOUND_SEASONS"
fi

# Extract day-of-week references
echo ""
echo "--- Day References ---"
DAYS="monday|tuesday|wednesday|thursday|friday|saturday|sunday"
FOUND_DAYS=$(grep -oEi "\b($DAYS)\b" "$CHAPTER" 2>/dev/null | tr '[:upper:]' '[:lower:]' | sort | uniq -c | sort -rn || true)

if [ -z "$FOUND_DAYS" ]; then
    echo "  No day-of-week references found"
else
    while read -r count day; do
        [ -z "$day" ] && continue
        printf "  %-12s %3d occurrences\n" "$day" "$count"
    done <<< "$FOUND_DAYS"
fi

# Extract time-of-day references
echo ""
echo "--- Time References ---"
TIMES=$(grep -oE '[0-9]{1,2}:[0-9]{2}|[0-9]{1,2} (am|pm|AM|PM|a\.m\.|p\.m\.)|noon|midnight|morning|afternoon|evening|dusk|dawn' "$CHAPTER" 2>/dev/null | sort || true)

if [ -z "$TIMES" ]; then
    echo "  No explicit time references found"
else
    TIMES_COUNTED=$(echo "$TIMES" | uniq -c)
    while read -r count time; do
        [ -z "$time" ] && continue
        printf "  %-20s %3d occurrences\n" "$time" "$count"
    done <<< "$TIMES_COUNTED"
fi

# Weather references
echo ""
echo "--- Weather References ---"
WEATHER_WORDS="rain|raining|rained|sun|sunny|sunshine|wind|windy|cloud|cloudy|fog|foggy|storm|snow|snowing|frost|frosty|hail|sleet|drizzle|overcast|clear"
FOUND_WEATHER=$(grep -oEi "\b($WEATHER_WORDS)\b" "$CHAPTER" 2>/dev/null | tr '[:upper:]' '[:lower:]' | sort | uniq -c | sort -rn || true)

if [ -z "$FOUND_WEATHER" ]; then
    echo "  No weather references found"
else
    while read -r count word; do
        [ -z "$word" ] && continue
        printf "  %-15s %3d occurrences\n" "$word" "$count"
    done <<< "$FOUND_WEATHER"
fi

echo ""
echo "=== SUMMARY ==="
MONTH_VIOLATIONS=$(safe_count "grep -oEi '\b($ALL_MONTHS)\b' '$CHAPTER' | tr '[:upper:]' '[:lower:]' | while read m; do echo '$PERMITTED_MONTHS' | tr '[:upper:]' '[:lower:]' | grep -qi \"\$m\" || echo VIOLATION; done | grep -c VIOLATION")
echo "Month violations: $MONTH_VIOLATIONS"

if [ "$FAIL" -eq 1 ]; then
    echo "STATUS: FAIL"
    exit 1
else
    echo "STATUS: PASS"
    exit 0
fi
