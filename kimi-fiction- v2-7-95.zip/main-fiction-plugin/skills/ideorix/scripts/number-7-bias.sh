#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 7: Number-7 Bias Check
# Extracts all numbers, counts 7-ending frequency.
# ============================================================
# Usage: bash number-7-bias.sh <chapter-file>

set -euo pipefail

CHAPTER="${1:?Usage: number-7-bias.sh <chapter-file>}"
if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

echo "=== NUMBER-7 BIAS CHECK ==="
echo "Chapter: $CHAPTER"
echo ""

# Extract all numeric digits from chapter
grep -oE '[0-9]+' "$CHAPTER" > "$TMPDIR/numbers.txt" 2>/dev/null || true

# Spelled-out numbers containing seven — count only "seven" standalone.
# "seventeen" and "seventy" are already captured by numeric extraction when written as digits,
# and counting them here AND via digit extraction would double-count the same concept.
grep -oEi '\bseven\b' "$CHAPTER" > "$TMPDIR/spelled_sevens.txt" 2>/dev/null || true

# Count numbers ending in 7
TOTAL=$(wc -l < "$TMPDIR/numbers.txt" 2>/dev/null || echo "0")
TOTAL=$(echo "$TOTAL" | tr -dc '0-9'); [ -z "$TOTAL" ] && TOTAL=0
SEVENS=$(grep -cE '7$' "$TMPDIR/numbers.txt" 2>/dev/null || true)
SEVENS=$(echo "$SEVENS" | tr -dc '0-9'); [ -z "$SEVENS" ] && SEVENS=0
SPELLED=$(wc -l < "$TMPDIR/spelled_sevens.txt" 2>/dev/null || echo "0")
SPELLED=$(echo "$SPELLED" | tr -dc '0-9'); [ -z "$SPELLED" ] && SPELLED=0

TOTAL_WITH_SPELLED=$((TOTAL + SPELLED))
SEVENS_WITH_SPELLED=$((SEVENS + SPELLED))

if [ "$TOTAL_WITH_SPELLED" -gt 0 ]; then
    PCT=$((SEVENS_WITH_SPELLED * 100 / TOTAL_WITH_SPELLED))
else
    PCT=0
fi

# Check for hours set to 7. Use grep -c (single integer, no newline-doubling)
# instead of `grep | wc -l || echo 0` which produced "0\n0" under set -o pipefail
# and broke the `[ -gt 0 ]` test downstream (Cowork bug report 2026-05-01).
HOUR_SEVENS=$(grep -ocE '\b7:[0-9]{2}\b|\bseven o.clock\b' "$CHAPTER" 2>/dev/null || true)
HOUR_SEVENS=$(echo "$HOUR_SEVENS" | tr -dc '0-9'); [ -z "$HOUR_SEVENS" ] && HOUR_SEVENS=0

echo "--- Numbers Found ---"
echo "  Numeric digits: $TOTAL"
echo "  Spelled-out sevens: $SPELLED"
echo "  Total number references: $TOTAL_WITH_SPELLED"
echo ""
echo "--- Seven Bias ---"
echo "  Ending in 7 (digit): $SEVENS"
echo "  Spelled sevens: $SPELLED"
echo "  Total seven-references: $SEVENS_WITH_SPELLED"
echo "  Percentage: ${PCT}%"
echo "  Per-chapter threshold: ≤25%"
echo ""

FAIL=0
if [ "$TOTAL_WITH_SPELLED" -lt 3 ]; then
    echo "  STATUS: N/A (fewer than 3 numbers — too small to measure)"
elif [ "$PCT" -gt 25 ]; then
    echo "  STATUS: FAIL — ${PCT}% exceeds 25% chapter threshold"
    FAIL=1
elif [ "$PCT" -gt 15 ]; then
    echo "  STATUS: WARN — ${PCT}% approaching manuscript threshold (15%)"
else
    echo "  STATUS: PASS"
fi

echo ""
echo "--- Hour-7 Check ---"
echo "  Times set to 7:xx or 'seven o'clock': $HOUR_SEVENS"
[ "$HOUR_SEVENS" -gt 0 ] && echo "  STATUS: FLAG — consider changing hour" || echo "  STATUS: PASS"

echo ""
echo "=== SUMMARY ==="
echo "Numbers: $TOTAL_WITH_SPELLED | Sevens: $SEVENS_WITH_SPELLED (${PCT}%) | Hour-7: $HOUR_SEVENS"
if [ "$FAIL" -eq 1 ]; then
    echo "STATUS: FAIL"
    exit 1
else
    echo "STATUS: PASS"
    exit 0
fi
