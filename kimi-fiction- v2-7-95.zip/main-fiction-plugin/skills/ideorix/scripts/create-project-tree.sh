#!/bin/bash
# ============================================================
# Ideorix — Deterministic Project-Tree Creator (v2.7.91)
# Creates a complete, idempotent Ideorix project folder tree.
# Replaces the prior LLM-orchestrated mkdir step with a single
# deterministic bash invocation that the orchestrator cannot
# skip or partially execute.
#
# Idempotent: re-running is safe. Existing project-config.md is
# never overwritten.
# ============================================================
# Usage:
#   bash create-project-tree.sh <title> [--series=<name>] [--root=<path>]
#
# - title:   project / book title (used as directory name)
# - --series: optional series name; creates a nested series tree
# - --root:  optional root path (default: ~/Documents/Ideorix-Projects)
#
# Prints the project root path on stdout for the orchestrator to capture.
# Exit codes:
#   0  success — tree created or already existed
#   1  invalid arguments
#   2  could not create directory
# ============================================================

set -uo pipefail

TITLE=""
SERIES=""
ROOT="${HOME}/Documents/Ideorix-Projects"

while [ $# -gt 0 ]; do
    case "$1" in
        --series=*)
            SERIES="${1#--series=}"
            shift
            ;;
        --root=*)
            ROOT="${1#--root=}"
            shift
            ;;
        --help|-h)
            sed -n '/^# Usage:/,/^# Exit codes:/p' "$0" | sed 's/^# //; s/^#//'
            exit 0
            ;;
        *)
            if [ -z "$TITLE" ]; then
                TITLE="$1"
            fi
            shift
            ;;
    esac
done

if [ -z "$TITLE" ]; then
    echo "Usage: create-project-tree.sh <title> [--series=<name>] [--root=<path>]" >&2
    exit 1
fi

# Sanitise title for directory name (strip leading/trailing spaces,
# collapse internal whitespace to single hyphens).
DIR_NAME="$(echo "$TITLE" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/[[:space:]]\+/-/g')"

if [ -n "$SERIES" ]; then
    SERIES_DIR="$(echo "$SERIES" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/[[:space:]]\+/-/g')"
    PROJECT_ROOT="$ROOT/$SERIES_DIR/$DIR_NAME"
    mkdir -p "$ROOT/$SERIES_DIR/series-data" 2>/dev/null || true
else
    PROJECT_ROOT="$ROOT/$DIR_NAME"
fi

# Create the full tree in one shot.
mkdir -p "$PROJECT_ROOT/manuscript" \
         "$PROJECT_ROOT/marketing" \
         "$PROJECT_ROOT/engine-data/reports" \
         "$PROJECT_ROOT/engine-data/chapters" \
         "$PROJECT_ROOT/engine-data/summaries" \
         "$PROJECT_ROOT/engine-data/revisions" \
         2>/dev/null || {
    echo "ERROR: could not create project directories under $PROJECT_ROOT" >&2
    exit 2
}

# Initial project-config.md — idempotent: never overwrite existing.
CONFIG_FILE="$PROJECT_ROOT/project-config.md"
if [ ! -f "$CONFIG_FILE" ]; then
    CREATED_DATE="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    cat > "$CONFIG_FILE" <<EOF
# Project: $TITLE
Created: $CREATED_DATE
Status: Awaiting manuscript

<!-- Engine-specific fields — append after creation:
Mode: Writers Studio
Genre: (to be set during Edit & Revise or Manuscript Clinic)
NF Category: (non-fiction only)
formatting_mode: ai|human
handoff_status: pending
-->
EOF
fi

echo "$PROJECT_ROOT"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
