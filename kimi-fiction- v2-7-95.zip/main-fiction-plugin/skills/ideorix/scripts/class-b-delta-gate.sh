#!/bin/bash
# ============================================================
# Rule 1b — Class B Delta Pass Gate
# Runs leitmotif-tracker-delta and injury-accumulation-delta
# subagents per chapter. Auto-skips for argumentative NF.
# ============================================================
# Usage: bash class-b-delta-gate.sh <chapter-file> <project-path> [<genre>]

set -euo pipefail

CHAPTER="${1:?Usage: class-b-delta-gate.sh <chapter-file> <project-path> [genre]}"
PROJECT="${2:?Usage: class-b-delta-gate.sh <chapter-file> <project-path> [genre]}"
GENRE="${3:-}"

CHAPTER_NAME=$(basename "$CHAPTER" .md)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Auto-skip for argumentative non-fiction (NF)
# Detect by genre tag or project-mode flag
if [ -f "$PROJECT/engine-data/project-mode.md" ]; then
    if grep -qiE 'non-?fiction|argumentative|essay|memoir' "$PROJECT/engine-data/project-mode.md"; then
        echo "Class B Delta: SKIP — argumentative NF detected in project-mode.md"
        exit 0
    fi
fi
if echo "$GENRE" | grep -qiE 'non-?fiction|argumentative|essay|memoir'; then
    echo "Class B Delta: SKIP — argumentative NF detected via genre arg"
    exit 0
fi

# Check for leitmotif canon
LEITMOTIF_CANON="$PROJECT/engine-data/leitmotif-canon.md"
INJURY_CANON="$PROJECT/engine-data/injury-canon.md"

DELTA_FAIL=0

# --- Subagent A: Leitmotif Tracker Delta ---
if [ -f "$LEITMOTIF_CANON" ]; then
    echo "━━━ Class B Subagent: Leitmotif Tracker Delta ━━━"
    if bash "$SCRIPT_DIR/leitmotif-tracker-delta.sh" "$CHAPTER" "$LEITMOTIF_CANON"; then
        echo "  Leitmotif Delta: PASS"
    else
        echo "  Leitmotif Delta: FAIL"
        DELTA_FAIL=1
    fi
    echo ""
else
    echo "  Leitmotif Delta: SKIP — no leitmotif-canon.md"
fi

# --- Subagent B: Injury Accumulation Delta ---
if [ -f "$INJURY_CANON" ]; then
    echo "━━━ Class B Subagent: Injury Accumulation Delta ━━━"
    if bash "$SCRIPT_DIR/injury-accumulation-delta.sh" "$CHAPTER" "$INJURY_CANON"; then
        echo "  Injury Delta: PASS"
    else
        echo "  Injury Delta: FAIL"
        DELTA_FAIL=1
    fi
    echo ""
else
    echo "  Injury Delta: SKIP — no injury-canon.md"
fi

if [ "$DELTA_FAIL" -eq 0 ]; then
    echo "Class B Delta Gate: PASS"
    exit 0
else
    echo "Class B Delta Gate: FAIL"
    exit 1
fi
