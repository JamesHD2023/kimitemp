#!/bin/bash
# ============================================================
# Subagent: Injury Accumulation Delta
# Checks that character injuries from the chapter match the
# injury canon and flags contradictions / healing violations.
# ============================================================
# Usage: bash injury-accumulation-delta.sh <chapter-file> <injury-canon>

set -euo pipefail

CHAPTER="${1:?Usage: injury-accumulation-delta.sh <chapter-file> <injury-canon>}"
CANON="${2:?Usage: injury-accumulation-delta.sh <chapter-file> <injury-canon>}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER" >&2; exit 1; fi
if [ ! -f "$CANON" ]; then echo "ERROR: Canon file not found: $CANON" >&2; exit 1; fi

# Parse injury canon: each line expected format:
# - Character: <name> | Injury: <description> | Status: <active/healed/fatal>
CANON_PARSED=$(grep -iE '^\s*[-*]\s+Character:' "$CANON" | sed 's/^\s*[-*]\s*//')

if [ -z "$CANON_PARSED" ]; then
    echo "  No injury entries found in canon — skip."
    exit 0
fi

CHAPTER_LC=$(tr '[:upper:]' '[:lower:]' < "$CHAPTER")

CONTRADICTIONS=()

while IFS= read -r line; do
    [ -z "$line" ] && continue
    # Extract character name
    char=$(echo "$line" | grep -oiE 'Character:\s*[^|]+' | sed 's/Character:\s*//' | sed 's/^\s*//;s/\s*$//' | tr '[:upper:]' '[:lower:]')
    # Extract status
    status=$(echo "$line" | grep -oiE 'Status:\s*[^|]+' | sed 's/Status:\s*//' | sed 's/^\s*//;s/\s*$//' | tr '[:upper:]' '[:lower:]')
    # Extract injury description
    injury=$(echo "$line" | grep -oiE 'Injury:\s*[^|]+' | sed 's/Injury:\s*//' | sed 's/^\s*//;s/\s*$//' | tr '[:upper:]' '[:lower:]')

    [ -z "$char" ] && continue

    # Check if character appears in chapter
    if ! echo "$CHAPTER_LC" | grep -qFw "$char"; then
        continue  # Character not in this chapter; no delta to check
    fi

    # Check for contradictions:
    # If status is "active" or "healed", look for contradictions
    case "$status" in
        active|wounded|injured|bleeding|broken|sprained)
            # Healed prematurely? Search for heal/cure/fix/recover words near character name
            if echo "$CHAPTER_LC" | grep -qE "\b(charname\b.*\b(healed|recovered|cured|mended|better|fine|okay|ok|restored|fixed)\b|\b(healed|recovered|cured|mended|better|fine|okay|ok|restored|fixed)\b.*\bcharname\b)"; then
                # Replace charname with actual character for the grep check
                if echo "$CHAPTER_LC" | grep -qE "\b($char\b.*\b(healed|recovered|cured|mended|better|fine|okay|ok|restored|fixed)\b|\b(healed|recovered|cured|mended|better|fine|okay|ok|restored|fixed)\b.*\b$char\b)"; then
                    CONTRADICTIONS+=("$char: injury marked active but chapter suggests healing/recovery")
                fi
            fi
            ;;
        healed|recovered|mended|cured|fine)
            # Re-injured or still suffering? Search for pain/damage words near character
            if echo "$CHAPTER_LC" | grep -qE "\b($char\b.*\b(bleeding|pain|wound|injured|hurt|limp|gasp|clutch|stagger|wince|grimace|nurse|cradl)\b|\b(bleeding|pain|wound|injured|hurt|limp|gasp|clutch|stagger|wince|grimace|nurse|cradl)\b.*\b$char\b)"; then
                CONTRADICTIONS+=("$char: injury marked healed but chapter shows ongoing symptoms")
            fi
            ;;
        fatal|dead|deceased)
            # Character alive? This is a hard contradiction
            if echo "$CHAPTER_LC" | grep -qFw "$char"; then
                CONTRADICTIONS+=("$char: status fatal but character appears in chapter")
            fi
            ;;
    esac
done <<< "$CANON_PARSED"

if [ ${#CONTRADICTIONS[@]} -gt 0 ]; then
    echo "  Injury contradictions found:"
    for c in "${CONTRADICTIONS[@]}"; do echo "    ✗ $c"; done
    exit 1
else
    echo "  No injury contradictions."
    exit 0
fi
