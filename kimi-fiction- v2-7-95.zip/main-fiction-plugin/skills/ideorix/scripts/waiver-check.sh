#!/bin/bash
# ============================================================
# Waiver System for Ideorix Mechanical Audits
# Allows content-level overrides for legitimate violations.
# ============================================================
# Usage: bash waiver-check.sh <chapter-file> <module-name> <project-path>
# Exit 0 = waiver applies, module can be skipped
# Exit 1 = no waiver, run the module normally
# ============================================================

set -euo pipefail

CHAPTER="${1:?Usage: waiver-check.sh <chapter-file> <module-name> <project-path>}"
MODULE="${2:?Usage: waiver-check.sh <chapter-file> <module-name> <project-path>}"
PROJECT="${3:?Usage: waiver-check.sh <chapter-file> <module-name> <project-path>}"

WAIVERS="$PROJECT/references/waivers.md"

if [ ! -f "$WAIVERS" ]; then
    # No waivers file = no waivers possible
    exit 1
fi

CHAPTER_NAME=$(basename "$CHAPTER")

# Check if this chapter+module combination has a waiver
# Format in waivers.md:
# | Chapter | Module | Reason | Expires |
# |---------|--------|--------|---------|
# | ch01.md | number-7-bias | Chapter literally titled "The Seven Stones" | never |

while IFS='|' read -r _ chap mod reason expires _; do
    # Trim whitespace
    chap=$(echo "$chap" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    mod=$(echo "$mod" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    reason=$(echo "$reason" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    expires=$(echo "$expires" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    
    # Skip header and separator rows
    [ "$chap" = "Chapter" ] && continue
    [ -z "$chap" ] && continue
    
    if [ "$chap" = "$CHAPTER_NAME" ] && [ "$mod" = "$MODULE" ]; then
        # Check expiration
        if [ "$expires" != "never" ] && [ -n "$expires" ]; then
            EXPIRE_TS=$(date -d "$expires" +%s 2>/dev/null || echo "")
            if [ -n "$EXPIRE_TS" ]; then
                NOW=$(date +%s)
                if [ "$NOW" -gt "$EXPIRE_TS" ]; then
                    # Waiver expired
                    continue
                fi
            fi
        fi
        
        echo "WAIVER ACTIVE"
        echo "  Module: $MODULE"
        echo "  Chapter: $CHAPTER_NAME"
        echo "  Reason: $reason"
        echo "  Expires: ${expires:-never}"
        exit 0
    fi
done < "$WAIVERS"

# No matching waiver found
exit 1
