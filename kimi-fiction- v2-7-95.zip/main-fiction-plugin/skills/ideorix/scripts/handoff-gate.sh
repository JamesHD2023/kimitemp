#!/bin/bash
# Ideorix — Handoff Gate (v2.7.90)
# Enforces the Handoff Protocol: verifies handoff-checklist.md
# enumerates every editorial stage with a verdict before a
# manuscript is handed off for human edit. Fail-closed.
# v2.7.88: Check 6 — final mechanical re-verification (formatting-check.sh on every chapter).
# v2.7.89: formatting_mode support (ai|human) read from project-config.md.
# v2.7.90: Gate verdict reporting artifact written on every invocation.
# Usage: bash handoff-gate.sh <project-root>
# Exit: 0 PASS | 1 checklist missing/incomplete/unresolved-FAIL/stale | 2 bad args
set -euo pipefail

if [ $# -lt 1 ]; then
 echo "Usage: handoff-gate.sh <project-root>" >&2
 exit 2
fi
PROJECT="$1"
if [ ! -d "$PROJECT" ]; then
 echo "ERROR: project root not found: $PROJECT" >&2
 exit 2
fi

CONFIG="$PROJECT/engine-data/project-config.md"
CHECKLIST="$PROJECT/engine-data/reports/handoff-checklist.md"
CHAPTERS_DIR="$PROJECT/engine-data/chapters"
REPORTS_DIR="$PROJECT/engine-data/reports"
MIN_EDITORIAL_STAGES=14
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Gate verdict artifact (v2.7.90)
ARTIFACT="$REPORTS_DIR/handoff-gate-output.md"

# Read formatting_mode from project-config.md (default ai)
MODE="ai"
if [ -f "$CONFIG" ]; then
 if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*formatting_mode:[[:space:]]*human\b' "$CONFIG"; then
  MODE="human"
 fi
fi

# v2.7.90 — gate verdict reporting
write_artifact() {
    local verdict="$1" code="$2" detail="$3"
    mkdir -p "$REPORTS_DIR"
    local ts
    ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    cat > "$ARTIFACT" <<EOF
# Handoff Gate Verdict Report

- **Timestamp (UTC):** $ts
- **Project Root:** $PROJECT
- **Gate Version:** 2.7.90
- **Verdict:** $verdict
- **Exit Code:** $code
- **Detail:** $detail
- **Formatting Mode:** $MODE
EOF
}

# v2.7.90 — gate_exit replaces bare exit so artifact is always written
gate_exit() {
    local code="$1" verdict="$2" detail="$3"
    write_artifact "$verdict" "$code" "$detail"
    exit "$code"
}

if [ -f "$CONFIG" ]; then
 if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*handoff_status:[[:space:]]*skip\b' "$CONFIG"; then
  gate_exit 0 "PASS" "project-config.md declares handoff_status: skip — documented opt-out honored"
 fi
fi

if [ ! -f "$CHECKLIST" ]; then
 echo "HANDOFF GATE: FAIL — no handoff-checklist.md present." >&2
 echo " Expected: $CHECKLIST" >&2
 echo "ACTION: run the Handoff Protocol end-to-end and record all four steps" >&2
 echo " in engine-data/reports/handoff-checklist.md." >&2
 gate_exit 1 "FAIL" "handoff-checklist.md missing"
fi
if [ ! -s "$CHECKLIST" ]; then
 echo "HANDOFF GATE: FAIL — handoff-checklist.md is zero bytes." >&2
 gate_exit 1 "FAIL" "handoff-checklist.md zero bytes"
fi

MISSING_STEPS=""
for step in '7\.1' '7\.2' '7\.3' '7\.4'; do
 if ! grep -qE "${step}([^0-9]|\$)" "$CHECKLIST"; then
  MISSING_STEPS="$MISSING_STEPS ${step//\\/}"
 fi
done
if [ -n "$MISSING_STEPS" ]; then
 echo "HANDOFF GATE: FAIL — handoff-checklist.md missing step section(s):$MISSING_STEPS" >&2
 gate_exit 1 "FAIL" "missing steps:$MISSING_STEPS"
fi

STAGE_COUNT=$(grep -cE '[Ss]tage[[:space:]]+[0-9]+(\.[0-9]+)?([^0-9]|$).*(PASS|WARN|FAIL|SKIPPED)' "$CHECKLIST" || true)
if [ "$STAGE_COUNT" -lt "$MIN_EDITORIAL_STAGES" ]; then
 echo "HANDOFF GATE: FAIL — Step 7.3 enumerates only $STAGE_COUNT editorial stage(s) with a verdict (minimum $MIN_EDITORIAL_STAGES)." >&2
 echo " A checklist with fewer than $MIN_EDITORIAL_STAGES stage verdicts means Step 7.3 collapsed." >&2
 echo " Run every editorial stage (editorial-suite.md) and record a verdict for each." >&2
 gate_exit 1 "FAIL" "Step 7.3 collapsed: $STAGE_COUNT stages (min $MIN_EDITORIAL_STAGES)"
fi

FAIL_COUNT=$(grep -E '\bFAIL\b' "$CHECKLIST" 2>/dev/null | grep -cvE '\b(RESOLVED|WAIVED)\b' || true)
RESOLUTION_COUNT=$(grep -cE '\b(RESOLVED|WAIVED)\b' "$CHECKLIST" || true)
if [ "$FAIL_COUNT" -gt 0 ] && [ "$RESOLUTION_COUNT" -lt "$FAIL_COUNT" ]; then
 echo "HANDOFF GATE: FAIL — $FAIL_COUNT FAIL verdict(s) but only $RESOLUTION_COUNT resolution(s) (RESOLVED/WAIVED)." >&2
 echo " Every FAIL is a blocking decision item: fix the chapter or record an explicit WAIVED entry." >&2
 gate_exit 1 "FAIL" "$FAIL_COUNT unresolved FAIL(s), $RESOLUTION_COUNT resolution(s)"
fi

if ! grep -qE '^HANDOFF STATUS:[[:space:]]*COMPLETE\b' "$CHECKLIST"; then
 echo "HANDOFF GATE: FAIL — handoff-checklist.md has no 'HANDOFF STATUS: COMPLETE' line." >&2
 gate_exit 1 "FAIL" "HANDOFF STATUS: COMPLETE missing"
fi

if [ -d "$CHAPTERS_DIR" ]; then
 NEWEST=$(find "$CHAPTERS_DIR" -type f -name 'ch*.md' -printf '%T@\n' 2>/dev/null | sort -nr | head -1 | awk -F. '{print $1}')
 [ -z "$NEWEST" ] && NEWEST=0
 CL_MTIME=$(stat -c %Y "$CHECKLIST" 2>/dev/null || stat -f %m "$CHECKLIST" 2>/dev/null || echo 0)
 if [ "$CL_MTIME" -lt "$NEWEST" ]; then
  echo "HANDOFF GATE: FAIL — handoff-checklist.md is stale (older than the most recent chapter)." >&2
  gate_exit 1 "FAIL" "handoff-checklist.md stale"
 fi
fi

# v2.7.88 — Check 6: Final mechanical re-verification.
# Run formatting-check.sh on every chapter file. Fail-closed on violation.
FORMATTING_CHECK="${SCRIPT_DIR}/formatting-check.sh"
if [ -f "$FORMATTING_CHECK" ] && [ -d "$CHAPTERS_DIR" ]; then
 CHAPTER_VIOLATIONS=""
 for ch in "$CHAPTERS_DIR"/ch*.md; do
  [ -f "$ch" ] || continue
  if ! bash "$FORMATTING_CHECK" "$ch" "$MODE" >/dev/null 2>&1; then
   CHAPTER_VIOLATIONS="$CHAPTER_VIOLATIONS $(basename "$ch")"
  fi
 done
 if [ -n "$CHAPTER_VIOLATIONS" ]; then
  echo "HANDOFF GATE: FAIL — Check 6 (mechanical re-verification) failed on chapter(s):$CHAPTER_VIOLATIONS" >&2
  echo " Run scripts/em-dash-auto-convert.sh on each failing chapter, or set formatting_mode: human in project-config.md for human-authored manuscripts." >&2
  gate_exit 1 "FAIL" "Check 6 failed on:$CHAPTER_VIOLATIONS"
 fi
fi

gate_exit 0 "PASS" "checklist present; all four steps recorded; $STAGE_COUNT editorial stages enumerated with verdicts; no unresolved FAIL; status COMPLETE; Check 6 PASS; mode=$MODE"
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
# ............................................................
