#!/bin/bash
# ============================================================
# Ideorix Read-Verification — Threshold Check
# Verifies that extracted content from a user-supplied source
# file meets the per-format minimum character threshold. Used
# by the engine's Read-Verification HARD GATE protocol — the
# canonical spec is `references/read-verification.md`.
#
# After the engine's Read tool extracts content from a user
# file, the content is written to a temp file and this script
# is invoked. The script counts non-whitespace characters and
# compares against the per-format threshold. Exit 0 = above
# threshold (Read succeeded with real content). Exit 1 = below
# threshold (suspect empty-read failure; engine MUST trigger
# the HARD GATE and surface the failure to the user).
#
# Single source of truth for threshold values: editing this
# script changes the threshold across every input-read flow
# in both engines (BYO-canon, 4 importers, manuscript clinic,
# edit-and-revise, heritage-text, analyze-a-book, continue-
# writing/researching).
#
# Usage:
#   read-verification.sh <extracted-content-file> <category>
#
# Categories:
#   pdf      — minimum 100 non-whitespace chars
#   docx     — minimum 100
#   scriv    — minimum 100 (per nested document)
#   epub     — minimum 100
#   md       — minimum 20
#   txt      — minimum 20
#   fountain — minimum 50
#   fdx      — minimum 50
#   json     — minimum 100
#
# Exit:
#   0 = content above threshold (Read succeeded)
#   1 = content below threshold (FAILED_READ — trigger HARD GATE)
#   2 = invocation error (missing file, bad category, etc.)
# ============================================================
set -euo pipefail

usage() {
    echo "Usage: read-verification.sh <extracted-content-file> <category>"
    echo "Categories: pdf docx scriv epub md txt fountain fdx json"
    exit 2
}

FILE="${1:-}"
CATEGORY="${2:-}"

if [ -z "$FILE" ] || [ -z "$CATEGORY" ]; then usage; fi
if [ ! -f "$FILE" ]; then echo "ERROR: file not found: $FILE"; exit 2; fi

case "$CATEGORY" in
    pdf|docx|scriv|epub|json) THRESHOLD=100 ;;
    md|txt)                   THRESHOLD=20 ;;
    fountain|fdx)             THRESHOLD=50 ;;
    *) echo "ERROR: unknown category: $CATEGORY (must be one of: pdf docx scriv epub md txt fountain fdx json)"; exit 2 ;;
esac

# Count non-whitespace chars. Use perl with -CSDA so multibyte
# UTF-8 (curly quotes, em-dashes, etc.) is counted as one logical
# char, not multiple bytes.
NONWS=$(perl -CSDA -e '
    my $c = 0;
    while (<>) { $c += () = /\S/g; }
    print $c;
' < "$FILE")

if [ "$NONWS" -lt "$THRESHOLD" ]; then
    echo "[FAIL] read-verification — $FILE"
    echo "  category: $CATEGORY (threshold: $THRESHOLD non-whitespace chars)"
    echo "  actual:   $NONWS chars"
    echo ""
    echo "Suspect empty-read failure. Engine MUST trigger HARD GATE and"
    echo "surface this failure to the user with the three resolution"
    echo "options (paste / skip / re-upload). See read-verification.md."
    exit 1
fi

echo "[PASS] read-verification — $FILE"
echo "  category: $CATEGORY (threshold: $THRESHOLD; actual: $NONWS chars)"
exit 0
