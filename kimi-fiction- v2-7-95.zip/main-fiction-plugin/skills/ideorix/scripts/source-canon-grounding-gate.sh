#!/bin/bash
# ============================================================
# Source Canon Grounding Gate
# Deterministic verification that the orchestrator is grounded
# in current source-canon file content, not stale memory.
# ============================================================
# Usage: bash source-canon-grounding-gate.sh <project-path>
# Exit 0 = PASS — all verifications succeeded
# Exit 1 = FAIL — one or more verifications failed
# Exit 2 = NO ARTIFACT — artifact missing
# Exit 3 = NOT ENABLED — grounding disabled in config
# ============================================================

set -euo pipefail

PROJECT="${1:?Usage: source-canon-grounding-gate.sh <project-path>}"
ARTIFACT="$PROJECT/engine-data/reports/source-canon-grounding.yaml"
CONFIG="$PROJECT/project-config.md"

# --- Check if enabled ---
if [ -f "$CONFIG" ]; then
    if grep -qE '^source_canon_grounding:\s*disabled' "$CONFIG" 2>/dev/null; then
        echo "GROUNDING: SKIP — source_canon_grounding: disabled in project-config.md"
        exit 3
    fi
    if grep -qE '^source_canon_grounding:\s*legacy' "$CONFIG" 2>/dev/null; then
        echo "GROUNDING: SKIP — pre-v2.8.0 project, opt-out honored (source_canon_grounding: legacy)"
        exit 3
    fi
fi

# --- Check artifact exists ---
if [ ! -f "$ARTIFACT" ]; then
    echo "GROUNDING: FAIL — artifact not found: $ARTIFACT"
    echo "  The orchestrator must produce source-canon-grounding.yaml before generation."
    exit 2
fi

echo "=== SOURCE CANON GROUNDING GATE ==="
echo "Artifact: $ARTIFACT"
echo ""

# --- Parse artifact with Python (robust YAML parsing) ---
python3 - "$ARTIFACT" << 'PYEOF'
import sys, yaml, hashlib, os, re

artifact_path = sys.argv[1]
failures = []
warnings = []

with open(artifact_path, 'r', encoding='utf-8') as f:
    data = yaml.safe_load(f)

project = data.get('project', 'unknown')
step = data.get('step', 'unknown')
files = data.get('files', [])
min_samples = data.get('min_samples_per_file', 3)
min_files = data.get('min_files_with_samples', 1)
required_total = data.get('required_total_samples', 3)

print(f"Project: {project}")
print(f"Step: {step}")
print(f"Files declared: {len(files)}")
print(f"Min samples per file: {min_samples}")
print(f"")

# Track totals
total_samples = 0
files_with_samples = 0

for entry in files:
    path = entry.get('path', '')
    declared_sha = entry.get('sha256', '')
    samples = entry.get('samples', [])
    key_facts = entry.get('key_facts', [])
    
    # Resolve path relative to project root
    full_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(artifact_path))), path)
    
    print(f"--- File: {path} ---")
    
    # 1. File exists
    if not os.path.exists(full_path):
        failures.append(f"{path}: File does not exist at {full_path}")
        print(f"  [FAIL] File does not exist")
        continue
    
    # 2. Read file content
    try:
        with open(full_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        failures.append(f"{path}: Cannot read file: {e}")
        print(f"  [FAIL] Cannot read file: {e}")
        continue
    
    # 3. Compute sha256
    current_sha = hashlib.sha256(content.encode('utf-8')).hexdigest()
    
    if current_sha != declared_sha:
        failures.append(f"{path}: SHA256 mismatch — file changed since artifact was generated (or orchestrator used stale memory)")
        print(f"  [FAIL] SHA256 mismatch")
        print(f"    Declared: {declared_sha}")
        print(f"    Current:  {current_sha}")
        continue
    else:
        print(f"  [PASS] SHA256 matches")
    
    # 4. Verify samples are actual substrings
    sample_hits = 0
    for i, sample in enumerate(samples):
        if sample in content:
            sample_hits += 1
            print(f"  [PASS] Sample {i+1} verified ({len(sample)} chars)")
        else:
            failures.append(f"{path}: Sample {i+1} is NOT in file — fabricated from memory?")
            print(f"  [FAIL] Sample {i+1} NOT FOUND in file")
            print(f"    Sample text: {sample[:80]}...")
    
    # 5. Check minimum samples
    if len(samples) >= min_samples:
        print(f"  [PASS] Sample count: {len(samples)} >= {min_samples}")
    else:
        failures.append(f"{path}: Only {len(samples)} samples, minimum is {min_samples}")
        print(f"  [FAIL] Sample count: {len(samples)} < {min_samples}")
    
    # 6. Check sample distribution (beginning, middle, end)
    if len(samples) >= 3:
        content_len = len(content)
        positions = []
        for sample in samples:
            pos = content.find(sample)
            if pos >= 0:
                positions.append(pos / content_len if content_len > 0 else 0)
        
        if positions:
            has_beginning = any(p < 0.33 for p in positions)
            has_middle = any(0.33 <= p < 0.66 for p in positions)
            has_end = any(p >= 0.66 for p in positions)
            
            if has_beginning and has_middle and has_end:
                print(f"  [PASS] Samples distributed across file (beginning/middle/end)")
            else:
                warnings.append(f"{path}: Samples clustered — not distributed across file")
                print(f"  [WARN] Samples not well distributed (beginning:{has_beginning}, middle:{has_middle}, end:{has_end})")
    
    total_samples += len(samples)
    if len(samples) > 0:
        files_with_samples += 1
    
    print(f"  Key facts claimed: {len(key_facts)}")
    print("")

# --- Global checks ---
print("=== GLOBAL CHECKS ===")

if files_with_samples >= min_files:
    print(f"[PASS] Files with samples: {files_with_samples} >= {min_files}")
else:
    failures.append(f"Only {files_with_samples} files have samples, minimum is {min_files}")
    print(f"[FAIL] Files with samples: {files_with_samples} < {min_files}")

if total_samples >= required_total:
    print(f"[PASS] Total samples: {total_samples} >= {required_total}")
else:
    failures.append(f"Total samples: {total_samples}, required: {required_total}")
    print(f"[FAIL] Total samples: {total_samples} < {required_total}")

print("")

# --- Summary ---
print("=== GROUNDING GATE VERDICT ===")

if failures:
    print(f"STATUS: FAIL")
    print(f"Failures: {len(failures)}")
    for f in failures:
        print(f"  - {f}")
    if warnings:
        print(f"Warnings: {len(warnings)}")
        for w in warnings:
            print(f"  - {w}")
    print("")
    print("ACTION: Re-read all source-canon files, regenerate artifact, re-run gate.")
    sys.exit(1)
else:
    print(f"STATUS: PASS")
    print(f"Files verified: {len(files)}")
    print(f"Total samples verified: {total_samples}")
    if warnings:
        print(f"Warnings: {len(warnings)} (non-blocking)")
        for w in warnings:
            print(f"  - {w}")
    print("")
    print("Proceed with dependent generation.")
    sys.exit(0)
PYEOF
