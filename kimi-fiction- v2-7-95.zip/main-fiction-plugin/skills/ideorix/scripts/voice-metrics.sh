#!/bin/bash
# ============================================================
# Module 8 — Voice Metrics
# Computes filtering-verb ratio, sentence-length statistics,
# and appends one structured row to the voice ledger.
#
# PASS if FP ratio ≤ threshold (default 0.015 = 1.5%)
# WARN if 0.015 < FP ratio ≤ 0.025
# FAIL if FP ratio > 0.025
#
# Output: dashboard text to stdout; ledger append to disk.
# ============================================================
# Usage: bash voice-metrics.sh <chapter-file> <project-path> [<fp-threshold>]

set -euo pipefail

CHAPTER="${1:?Usage: voice-metrics.sh <chapter-file> <project-path> [fp-threshold]}"
PROJECT="${2:?Usage: voice-metrics.sh <chapter-file> <project-path> [fp-threshold]}"
FP_THRESHOLD="${3:-0.015}"
FP_HARD="${4:-0.025}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER" >&2; exit 1; fi

CHAPTER_NAME=$(basename "$CHAPTER" .md)
WORDS=$(wc -w < "$CHAPTER")

# Filtering verb / weak-perception pattern list (space-separated regex fragments)
# These are "filtering" verbs that add narrative distance.
FP_PATTERNS='\b(seemed|appeared|looked|sounded|felt|smelled|tasted|noticed|realized|wondered|thought|considered|decided|remembered|recalled|knew|understood|believed|felt like|found herself|found himself)\b'

# Count occurrences
FP_COUNT=$(grep -oiE "$FP_PATTERNS" "$CHAPTER" | wc -l || true)
if [ -z "$FP_COUNT" ]; then FP_COUNT=0; fi

FP_RATIO=0
if [ "$WORDS" -gt 0 ]; then
    FP_RATIO=$(awk "BEGIN {printf \"%.6f\", $FP_COUNT / $WORDS}")
fi

# Sentence-length stats
# Split on sentence terminators . ! ? followed by space or newline
SENTENCE_DATA=$(sed 's/[.!?]\+/\n/g' "$CHAPTER" | sed '/^\s*$/d' | awk '
{
    gsub(/^\s+|\s+$/, "");
    w = NF;
    if (w > 0) {
        count++;
        total += w;
        if (w > max) max = w;
        if (min == 0 || w < min) min = w;
        if (w <= 5) short++;
        if (w >= 25) long++;
        words[count] = w;
    }
}
END {
    if (count == 0) { print "0 0 0 0 0 0"; exit; }
    mean = total / count;
    # median
    n = asort(words, sorted);
    if (n % 2 == 1) median = sorted[int((n+1)/2)];
    else median = (sorted[n/2] + sorted[n/2 + 1]) / 2;
    printf "%d %d %.1f %.1f %d %d", count, total, mean, median, min, max;
}' || echo "0 0 0 0 0 0")

SENT_COUNT=$(echo "$SENTENCE_DATA" | awk '{print $1}')
SENT_TOTAL=$(echo "$SENTENCE_DATA" | awk '{print $2}')
SENT_MEAN=$(echo "$SENTENCE_DATA" | awk '{print $3}')
SENT_MEDIAN=$(echo "$SENTENCE_DATA" | awk '{print $4}')
SENT_MIN=$(echo "$SENTENCE_DATA" | awk '{print $5}')
SENT_MAX=$(echo "$SENTENCE_DATA" | awk '{print $6}')

# Short / long sentence counts
SHORT_COUNT=$(sed 's/[.!?]\+/\n/g' "$CHAPTER" | awk 'NF>0 && NF<=5 {c++} END {print c+0}')
LONG_COUNT=$(sed 's/[.!?]\+/\n/g' "$CHAPTER" | awk 'NF>=25 {c++} END {print c+0}')

# Determine status
STATUS="PASS"
EXIT_CODE=0
if awk "BEGIN {exit !($FP_RATIO > $FP_HARD)}"; then
    STATUS="FAIL"
    EXIT_CODE=1
elif awk "BEGIN {exit !($FP_RATIO > $FP_THRESHOLD)}"; then
    STATUS="WARN"
    EXIT_CODE=0
fi

# Emit dashboard
printf "  Words:          %d\n" "$WORDS"
printf "  FP count:       %d\n" "$FP_COUNT"
printf "  FP ratio:       %.4f (threshold %.4f, hard %.4f)\n" "$FP_RATIO" "$FP_THRESHOLD" "$FP_HARD"
printf "  Sentences:      %d\n" "$SENT_COUNT"
printf "  Mean length:    %s words\n" "$SENT_MEAN"
printf "  Median length:  %s words\n" "$SENT_MEDIAN"
printf "  Range:          %s – %s words\n" "$SENT_MIN" "$SENT_MAX"
printf "  Short (≤5):     %d  Long (≥25): %d\n" "$SHORT_COUNT" "$LONG_COUNT"
printf "  Status:         %s\n" "$STATUS"

# Append to voice ledger
mkdir -p "$PROJECT/engine-data"
LEDGER="$PROJECT/engine-data/voice-ledger.md"
if [ ! -f "$LEDGER" ]; then
    cat > "$LEDGER" <<'HDR'
# Voice Ledger

Per-chapter voice metrics. FP = filtering-verb ratio.

| Chapter | Words | FP Count | FP Ratio | Sents | Mean | Median | Short ≤5 | Long ≥25 | Status |
|---|---|---|---|---|---|---|---|---|---|
HDR
fi

printf '| %s | %d | %d | %.4f | %d | %s | %s | %d | %d | %s |\n' \
    "$CHAPTER_NAME" "$WORDS" "$FP_COUNT" "$FP_RATIO" "$SENT_COUNT" \
    "$SENT_MEAN" "$SENT_MEDIAN" "$SHORT_COUNT" "$LONG_COUNT" "$STATUS" \
    >> "$LEDGER"

exit "$EXIT_CODE"
