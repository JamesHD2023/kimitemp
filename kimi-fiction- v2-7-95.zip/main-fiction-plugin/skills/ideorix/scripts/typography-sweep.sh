#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Typography Sweep
# Scans a manuscript file for typographic-style artifacts that
# leak into narrative prose: ASCII apostrophes (U+0027), ASCII
# double quotes (U+0022), double-hyphen em-dash imposters (--),
# and three-dot ellipsis imposters (...).
#
# Failure mode addressed (Mitch report, v2.7.4 → v2.7.5):
# When the engine Edits a paragraph and the new_string is
# typed with ASCII quotes instead of the document's typographic
# defaults, the artifact is silently inserted into a 90,000-word
# manuscript. At body-text size U+0027 vs U+2019 are nearly
# indistinguishable, so the artifact is hard to find without a
# scan tool. This script is the safety net behind the v2.7.4
# preventive Edit-tool typographic-fidelity discipline.
#
# Default target: curly typography (publishing standard). Any
# ASCII straight quote, ASCII double quote, double-hyphen, or
# three-dot ellipsis in narrative prose is reported as an artifact.
# Override with --target ascii for explicitly-ASCII manuscripts.
#
# Skips fenced markdown code blocks (``` ... ```) so technical
# content (code samples, NF citations) is not falsely flagged.
#
# Accepts:
#   .md / .txt — read directly
#   .docx      — extracted via unzip (word/document.xml stripped of XML tags)
#
# Exit:
#   0 = clean (no artifacts found)
#   1 = artifacts found (sweep failed)
#   2 = invocation error
# ============================================================
set -euo pipefail

usage() {
    echo "Usage: typography-sweep.sh <file.md|file.docx> [--target curly|ascii] [--quiet]"
    exit 2
}

FILE=""
TARGET="curly"
QUIET=""

while [ $# -gt 0 ]; do
    case "$1" in
        --target)
            TARGET="${2:?--target requires curly or ascii}"
            shift 2
            ;;
        --quiet)
            QUIET="--quiet"
            shift
            ;;
        --help|-h)
            usage
            ;;
        *)
            if [ -z "$FILE" ]; then
                FILE="$1"
                shift
            else
                echo "ERROR: unexpected argument: $1"
                usage
            fi
            ;;
    esac
done

if [ -z "$FILE" ]; then usage; fi
if [ ! -f "$FILE" ]; then echo "ERROR: file not found: $FILE"; exit 2; fi
if [ ! -s "$FILE" ]; then echo "ERROR: file is empty: $FILE"; exit 2; fi
case "$TARGET" in
    curly|ascii) ;;
    *) echo "ERROR: --target must be curly or ascii (got: $TARGET)"; exit 2 ;;
esac

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

EXT="${FILE##*.}"
BODY="$TMPDIR/body.txt"

case "$EXT" in
    docx|DOCX)
        if ! command -v unzip >/dev/null 2>&1; then
            echo "ERROR: unzip required to scan .docx (install via package manager)"
            exit 2
        fi
        unzip -p "$FILE" word/document.xml \
            | perl -CSDA -pe 's/<[^>]+>/ /g' \
            > "$BODY"
        ;;
    md|MD|txt|TXT|markdown)
        awk 'BEGIN{in_fence=0}
             /^```/{in_fence=!in_fence; next}
             in_fence==0{print}' "$FILE" > "$BODY"
        ;;
    *)
        echo "ERROR: unsupported extension .$EXT (need .md, .txt, or .docx)"
        exit 2
        ;;
esac

if [ ! -s "$BODY" ]; then
    echo "ERROR: extracted body is empty (file may be malformed)"
    exit 2
fi

count_pattern() {
    # Pass pattern via env var to avoid perl's end-of-options marker (--).
    SWEEP_PAT="$1" perl -CSDA -e '
        my $pat = $ENV{SWEEP_PAT};
        my $c = 0;
        while (<>) { $c += () = /$pat/g; }
        print $c;
    ' < "$BODY"
}

CURLY_APO=$(count_pattern '\x{2019}')
ASCII_APO=$(count_pattern "'")
CURLY_DQ=$(count_pattern '[\x{201C}\x{201D}]')
ASCII_DQ=$(count_pattern '"')
EM_DASH=$(count_pattern '\x{2014}')
DBL_HYPHEN=$(count_pattern '--')
ELLIPSIS_C=$(count_pattern '\x{2026}')
ELLIPSIS_D=$(count_pattern '\.{3,}')

ARTIFACTS=0
REPORT="$TMPDIR/report.txt"
: > "$REPORT"

flag_category() {
    local label="$1"
    local count="$2"
    local grep_pattern="$3"
    local grep_flag="$4"
    local context_label="$5"

    if [ "$count" -gt 0 ]; then
        ARTIFACTS=$((ARTIFACTS + count))
        {
            echo "── $label ──"
            echo "$context_label: $count occurrence(s)"
            # `-- "$pattern"` ends grep option parsing so a pattern
            # like `--` is taken literally. `|| true` keeps the script
            # alive under set -e + pipefail when head closes the pipe
            # early or grep returns nonzero.
            local matches
            matches=$(grep "$grep_flag" -n -- "$grep_pattern" "$BODY" 2>/dev/null | head -10 || true)
            if [ -n "$matches" ]; then
                echo "$matches" | sed 's/^/  Line /'
            fi
            if [ "$count" -gt 10 ]; then
                echo "  (truncated — $count total)"
            fi
            echo ""
        } >> "$REPORT"
    fi
}

if [ "$TARGET" = "curly" ]; then
    flag_category "ASCII APOSTROPHE ARTIFACTS (U+0027)" "$ASCII_APO" "'" "-F" "Should be U+2019 (curly)"
    flag_category "ASCII DOUBLE-QUOTE ARTIFACTS (U+0022)" "$ASCII_DQ" '"' "-F" "Should be U+201C/U+201D (curly)"
    flag_category "DOUBLE-HYPHEN EM-DASH ARTIFACTS (--)" "$DBL_HYPHEN" '--' "-F" "Should be U+2014 (em-dash)"
    flag_category "THREE-DOT ELLIPSIS ARTIFACTS (...)" "$ELLIPSIS_D" '\.{3,}' "-P" "Should be U+2026 (ellipsis)"
else
    flag_category "CURLY APOSTROPHE ARTIFACTS (U+2019)" "$CURLY_APO" $'\xE2\x80\x99' "-F" "Should be U+0027 (ASCII)"
    flag_category "CURLY DOUBLE-QUOTE ARTIFACTS (U+201C/U+201D)" "$CURLY_DQ" $'\xE2\x80[\x9C\x9D]' "-P" "Should be U+0022 (ASCII)"
    flag_category "EM-DASH ARTIFACTS (U+2014)" "$EM_DASH" $'\xE2\x80\x94' "-F" "Should be -- or - (ASCII)"
    flag_category "ELLIPSIS ARTIFACTS (U+2026)" "$ELLIPSIS_C" $'\xE2\x80\xA6' "-F" "Should be ... (ASCII)"
fi

if [ "$ARTIFACTS" -eq 0 ]; then
    if [ "$QUIET" != "--quiet" ]; then
        echo "[PASS] typography-sweep ($TARGET target) — $FILE"
        echo "  Curly apostrophes: $CURLY_APO  | ASCII: $ASCII_APO"
        echo "  Curly double quotes: $CURLY_DQ  | ASCII: $ASCII_DQ"
        echo "  Em-dashes: $EM_DASH  | Double-hyphens: $DBL_HYPHEN"
        echo "  Ellipses: $ELLIPSIS_C  | Three-dots: $ELLIPSIS_D"
    fi
    exit 0
else
    echo "[FAIL] typography-sweep ($TARGET target) — $FILE"
    echo "  $ARTIFACTS typographic artifact(s) found"
    echo ""
    cat "$REPORT"
    echo "Resolve before pre-press delivery. Inspect each flagged occurrence;"
    echo "fenced markdown code blocks are auto-skipped, so any flagged occurrence"
    echo "is in narrative prose where the typographic target applies."
    exit 1
fi
