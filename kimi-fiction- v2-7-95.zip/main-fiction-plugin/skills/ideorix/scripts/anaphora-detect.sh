#!/bin/bash
# ============================================================
# Anaphora Detection Module
# Detects 3+ consecutive sentences with the same opener.
# Zero tolerance per prose-humaniser.md:167 — CRITICAL AI-ism.
# ============================================================
# Usage: bash anaphora-detect.sh <chapter-file.md> [opener-word-count]
# Exit 0 = no anaphora abuse found
# Exit 1 = anaphora abuse detected (3+ consecutive same-openers)
# ============================================================

set -euo pipefail

CHAPTER="${1:?Usage: anaphora-detect.sh <chapter-file.md> [opener-word-count]}"
OPENER_WORDS="${2:-2}"   # Number of words to consider the "opener" (default: 2)

if [ ! -f "$CHAPTER" ]; then
    echo "ERROR: Chapter file not found: $CHAPTER" >&2
    exit 2
fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

echo "=== ANAPHORA DETECTION ==="
echo "Chapter: $CHAPTER"
echo "Opener definition: first $OPENER_WORDS meaningful word(s) of each sentence"
echo ""

# Step 1: Normalize and split into sentences
# Remove markdown artifacts, then split on sentence terminators
sed -E 's/^[#*|-].*//g; /^[[:space:]]*$/d' "$CHAPTER" | \
    tr '\n' ' ' | \
    sed -E 's/\.{3}/…/g' | \
    perl -CS -pe 's/([.!?])(\s+|\s*"|\s*\x{201d})/$1\n/g' | \
    sed -E 's/^[[:space:]]+//g' | \
    sed -E '/^$/d' > "$TMPDIR/sentences.txt"

# Step 2: Extract openers (first N alphabetic words)
python3 - "$TMPDIR/sentences.txt" "$OPENER_WORDS" "$TMPDIR/openers.txt" << 'PYEOF'
import sys, re

infile = sys.argv[1]
n = int(sys.argv[2])
outfile = sys.argv[3]

with open(infile, 'r', encoding='utf-8') as f:
    sentences = [line.strip() for line in f if line.strip()]

with open(outfile, 'w', encoding='utf-8') as out:
    for sent in sentences:
        # Extract alphabetic words (keep apostrophes for contractions)
        words = re.findall(r"[a-zA-Z]+(?:'[a-zA-Z]+)?", sent)
        if len(words) >= n:
            opener = ' '.join(words[:n]).lower()
            out.write(f"{opener}\t{sent}\n")
        elif len(words) >= 1:
            # Sentence too short for N words, use what we have
            opener = ' '.join(words).lower()
            out.write(f"{opener}\t{sent}\n")
PYEOF

# Step 3: Detect runs of 3+ same openers
python3 - "$TMPDIR/openers.txt" "$TMPDIR/blocks.txt" << 'PYEOF'
import sys

infile = sys.argv[1]
outfile = sys.argv[2]

with open(infile, 'r', encoding='utf-8') as f:
    lines = [line.rstrip('\n') for line in f if line.strip()]

blocks = []
current_opener = None
current_run = []

for line in lines:
    parts = line.split('\t', 1)
    if len(parts) < 2:
        continue
    opener, sentence = parts[0], parts[1]
    
    if opener == current_opener and opener:
        current_run.append(sentence)
    else:
        if len(current_run) >= 3 and current_opener:
            blocks.append((current_opener, current_run))
        current_opener = opener
        current_run = [sentence]

# Check final run
if len(current_run) >= 3 and current_opener:
    blocks.append((current_opener, current_run))

with open(outfile, 'w', encoding='utf-8') as out:
    for opener, sentences in blocks:
        out.write(f"BLOCK: opener=\"{opener}\" | count={len(sentences)}\n")
        for s in sentences:
            out.write(f"    → {s}\n")
        out.write("---\n")
PYEOF

if [ -s "$TMPDIR/blocks.txt" ]; then
    BLOCKS=$(grep -c "^BLOCK:" "$TMPDIR/blocks.txt" 2>/dev/null || true)
    BLOCKS=$(echo "$BLOCKS" | tr -dc '0-9'); [ -z "$BLOCKS" ] && BLOCKS=0
    
    TOTAL_SENTENCES=$(wc -l < "$TMPDIR/openers.txt" 2>/dev/null || true)
    TOTAL_SENTENCES=$(echo "$TOTAL_SENTENCES" | tr -dc '0-9'); [ -z "$TOTAL_SENTENCES" ] && TOTAL_SENTENCES=0
    
    echo "  STATUS: FAIL — Anaphora abuse detected"
    echo ""
    echo "  Violation blocks found: $BLOCKS"
    echo "  Total sentences scanned: $TOTAL_SENTENCES"
    echo ""
    echo "  Details:"
    sed 's/^/  /' "$TMPDIR/blocks.txt"
    echo ""
    echo "  Rule: Two consecutive same-openers is acceptable for rhythm;"
    echo "        three or more is a CRITICAL AI-ism tell."
    echo "        Source: prose-humaniser.md:167"
    echo ""
    echo "=== SUMMARY ==="
    echo "Blocks: $BLOCKS | Sentences: $TOTAL_SENTENCES"
    echo "STATUS: FAIL"
    exit 1
else
    TOTAL_SENTENCES=$(wc -l < "$TMPDIR/openers.txt" 2>/dev/null || true)
    TOTAL_SENTENCES=$(echo "$TOTAL_SENTENCES" | tr -dc '0-9'); [ -z "$TOTAL_SENTENCES" ] && TOTAL_SENTENCES=0
    
    echo "  STATUS: PASS — No anaphora abuse found"
    echo "  Sentences scanned: $TOTAL_SENTENCES"
    echo ""
    echo "=== SUMMARY ==="
    echo "Blocks: 0 | Sentences: $TOTAL_SENTENCES"
    echo "STATUS: PASS"
    exit 0
fi
