#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 1: Forbidden Words Scanner
# Three-tier enforcement with DYNAMIC tier parsing from the .md file.
# Reads <!-- TIER: 1 --> / <!-- TIER: 2 --> / <!-- TIER: 3 --> markers.
# This eliminates the script-vs-markdown sync issue: update the .md,
# the script picks it up automatically.
# ============================================================
# Usage: bash forbidden-words-scan.sh <chapter-file> <forbidden-words-file>

set -euo pipefail

CHAPTER="${1:?Usage: forbidden-words-scan.sh <chapter-file> <forbidden-words-file>}"
FORBIDDEN="${2:?Usage: forbidden-words-scan.sh <chapter-file> <forbidden-words-file>}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi
if [ ! -f "$FORBIDDEN" ]; then echo "ERROR: Forbidden words file not found: $FORBIDDEN"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

TIER3_THRESHOLD=4

# Extract Tier 1 phrases: lines under ## TIER 1 or ## Forbidden Phrases that start with '- '
awk '
    /^## TIER 1/ || /^## Forbidden Phrases/ {in_t1=1; next}
    /^## / && in_t1 {in_t1=0}
    in_t1 && /^- / {sub(/^- /, ""); print tolower($0)}
' "$FORBIDDEN" > "$TMPDIR/phrases.txt"

# Extract Tier 2 and Tier 3 words using tier-state tracking.
# Recognises both <!-- TIER: N --> markers AND ## heading patterns.
# Handles multiple blocks per tier (Fiction has two TIER 2 sections).
# ## headings (not ###) that don't set a tier reset to 0.
awk '
    /<!-- TIER: 2 / || /^## TIER 2/ || /^## .*Zero-Tolerance/ { tier=2; next }
    /<!-- TIER: 3 / || /^## TIER 3/ { tier=3; next }
    /^## / && !/^### / { tier=0 }
    tier==2 && /^[A-Z][a-z]/ { print }
' "$FORBIDDEN" | tr ',' '\n' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | \
    tr '[:upper:]' '[:lower:]' | { grep -E '^[a-z]+$' || true; } | sort -u > "$TMPDIR/tier2.txt"

awk '
    /<!-- TIER: 2 / || /^## TIER 2/ || /^## .*Zero-Tolerance/ { tier=2; next }
    /<!-- TIER: 3 / || /^## TIER 3/ { tier=3; next }
    /^## / && !/^### / { tier=0 }
    tier==3 && /^[A-Z][a-z]/ { print }
' "$FORBIDDEN" | tr ',' '\n' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | \
    tr '[:upper:]' '[:lower:]' | { grep -E '^[a-z]+$' || true; } | sort -u > "$TMPDIR/tier3.txt"

# Ensure Tier 2 doesn't contain Tier 3 words
comm -23 "$TMPDIR/tier2.txt" "$TMPDIR/tier3.txt" > "$TMPDIR/tier2_final.txt"
mv "$TMPDIR/tier2_final.txt" "$TMPDIR/tier2.txt"

T1_COUNT=$(wc -l < "$TMPDIR/phrases.txt")
T2_COUNT=$(wc -l < "$TMPDIR/tier2.txt")
T3_COUNT=$(wc -l < "$TMPDIR/tier3.txt")

T1_VIOLATIONS=0
T2_VIOLATIONS=0
T3_VIOLATIONS=0

echo "=== FORBIDDEN WORDS SCAN (Dynamic Tier Parsing) ==="
echo "Chapter: $CHAPTER"
echo "Words in chapter: $(wc -w < "$CHAPTER")"
echo "Loaded: Tier 1 phrases: $T1_COUNT | Tier 2 words: $T2_COUNT | Tier 3 words: $T3_COUNT"
echo "Tier 3 threshold: ${TIER3_THRESHOLD}+ per chapter"
echo ""

tr '[:upper:]' '[:lower:]' < "$CHAPTER" > "$TMPDIR/lower.txt"

# === TIER 1: Phrases (zero tolerance) ===
echo "--- TIER 1: Forbidden Phrases (zero tolerance) ---"
while IFS= read -r phrase; do
    [ -z "$phrase" ] && continue
    count=$(grep -cE "\b${phrase}\b" "$TMPDIR/lower.txt" 2>/dev/null || true)
    count=$(echo "$count" | tr -dc '0-9'); [ -z "$count" ] && count=0
    if [ "$count" -gt 0 ]; then
        echo "  VIOLATION: \"$phrase\" — $count occurrence(s)"
        T1_VIOLATIONS=$((T1_VIOLATIONS + count))
    fi
done < "$TMPDIR/phrases.txt"
[ "$T1_VIOLATIONS" -eq 0 ] && echo "  CLEAN"

# === TIER 2: AI-signal words (zero tolerance) ===
echo ""
echo "--- TIER 2: AI-Signal Words (zero tolerance) ---"
while IFS= read -r word; do
    [ -z "$word" ] && continue
    count=$(grep -cE "\b${word}\b" "$TMPDIR/lower.txt" 2>/dev/null || true)
    count=$(echo "$count" | tr -dc '0-9'); [ -z "$count" ] && count=0
    if [ "$count" -gt 0 ]; then
        echo "  VIOLATION: \"$word\" — $count occurrence(s)"
        T2_VIOLATIONS=$((T2_VIOLATIONS + count))
    fi
done < "$TMPDIR/tier2.txt"
[ "$T2_VIOLATIONS" -eq 0 ] && echo "  CLEAN"

# === TIER 3: Common words (frequency-limited) ===
echo ""
echo "--- TIER 3: Common Words (flag at ${TIER3_THRESHOLD}+ per chapter) ---"
T3_FLAGGED=0
while IFS= read -r word; do
    [ -z "$word" ] && continue
    count=$(grep -cE "\b${word}\b" "$TMPDIR/lower.txt" 2>/dev/null || true)
    count=$(echo "$count" | tr -dc '0-9'); [ -z "$count" ] && count=0
    if [ "$count" -ge "$TIER3_THRESHOLD" ]; then
        echo "  OVERUSE: \"$word\" — $count times (threshold: $TIER3_THRESHOLD)"
        T3_VIOLATIONS=$((T3_VIOLATIONS + count))
        T3_FLAGGED=$((T3_FLAGGED + 1))
    fi
done < "$TMPDIR/tier3.txt"
[ "$T3_FLAGGED" -eq 0 ] && echo "  CLEAN — no common words exceed threshold"

TOTAL=$((T1_VIOLATIONS + T2_VIOLATIONS + T3_VIOLATIONS))

echo ""
echo "=== SUMMARY ==="
echo "Tier 1 (phrases, zero-tolerance): $T1_VIOLATIONS violations"
echo "Tier 2 (AI-signal words, zero-tolerance): $T2_VIOLATIONS violations"
echo "Tier 3 (common words, ${TIER3_THRESHOLD}+ threshold): $T3_VIOLATIONS overuse instances ($T3_FLAGGED words flagged)"
echo "TOTAL: $TOTAL"

# Only FAIL on Tier 1 or Tier 2 violations
# Tier 3 is advisory (WARN)
if [ "$T1_VIOLATIONS" -gt 0 ] || [ "$T2_VIOLATIONS" -gt 0 ]; then
    echo "STATUS: FAIL (zero-tolerance violations)"
    exit 1
elif [ "$T3_VIOLATIONS" -gt 0 ]; then
    echo "STATUS: WARN (common-word overuse only)"
    exit 0
else
    echo "STATUS: PASS"
    exit 0
fi
