#!/bin/bash
# ============================================================
# Subagent: Leitmotif Tracker Delta
# Checks that recurring motifs/symbols in the chapter match
# the leitmotif canon and detects new unregistered motifs.
# ============================================================
# Usage: bash leitmotif-tracker-delta.sh <chapter-file> <leitmotif-canon>

set -euo pipefail

CHAPTER="${1:?Usage: leitmotif-tracker-delta.sh <chapter-file> <leitmotif-canon>}"
CANON="${2:?Usage: leitmotif-tracker-delta.sh <chapter-file> <leitmotif-canon>}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER" >&2; exit 1; fi
if [ ! -f "$CANON" ]; then echo "ERROR: Canon file not found: $CANON" >&2; exit 1; fi

# Extract registered leitmotif tokens from canon (lines starting with "- " or "* ")
REGISTERED=$(grep -oE '^\s*[-*]\s+\S+' "$CANON" | sed 's/^\s*[-*]\s*//' | tr '[:upper:]' '[:lower:]' | sort -u)

if [ -z "$REGISTERED" ]; then
    echo "  No registered leitmotifs found in canon — skip."
    exit 0
fi

CHAPTER_LC=$(tr '[:upper:]' '[:lower:]' < "$CHAPTER")

MISSING=()
NEW=()

# Check each registered motif for presence
while IFS= read -r token; do
    [ -z "$token" ] && continue
    if echo "$CHAPTER_LC" | grep -qF "$token"; then
        echo "  ✓ Found: $token"
    else
        echo "  ✗ Missing: $token"
        MISSING+=("$token")
    fi
done <<< "$REGISTERED"

# Check for potential new motifs: words appearing ≥3 times, length ≥5, not in canon
# Skip common English stopwords via a concise grep -v pattern
STOPWORDS='^(the|and|that|with|from|they|have|this|were|said|each|which|their|what|your|when|than|them|then|been|would|could|should|will|shall|may|might|must|like|just|only|over|also|after|before|back|into|about|know|think|make|want|come|take|time|very|well|even|more|most|other|some|such|too|way|who|its|his|her|she|him|had|not|but|for|are|was|you|all|can|her|one|our|out|day|get|has|how|man|new|now|old|see|two|did|use|own|tell|much|there|first|water|long|little|words|called|just|where|most|know|get|through|back|much|before|go|good|new|write|our|me|too|any|day|same|right|look|think|also|around|another|came|come|work|three|must|because|does|part|even|place|made|live|where|between|found|own|still|men|say|great|help|home|side|move|both|five|once|never|under|while|last|find|give|eye|hand|never|head|own|leave|feel|seem|turn|world|went|want|next|against|went|thought|light|kind|began|almost|live|page|got|need|started|life|system|set|every|keep|case|fact|book|line|order|group|play|end|why|same|off|house|might|small|since|against|ask|late|home|interest|large|person|open|public|follow|around|why|ask|went|men|read|need|land|different|home|us|move|try|kind|hand|picture|again|change|off|play|spell|air|away|animal|house|point|mother|world|near|build|self|earth|father|head|stand|page|should|country|found|answer|school|grow|study|still|learn|plant|cover|food|sun|four|between|state|keep|eye|never|last|let|thought|city|tree|cross|farm|hard|start|story|saw|far|sea|draw|left|late|run|don|while|press|close|night|real|life|few|north|open|seem|together|next|white|children|begin|got|walk|example|ease|paper|group|always|music|those|often|letter|until|mile|river|car|feet|care|second|book|carry|took|science|eat|room|friend|began|idea|fish|mountain|stop|once|base|hear|horse|cut|sure|watch|color|face|wood|main|enough|plain|girl|usual|young|ready|above|ever|red|list|though|feel|talk|bird|soon|body|dog|family|direct|pose|leave|song|measure|door|product|black|short|numeral|class|wind|question|happen|complete|ship|area|half|rock|order|fire|south|problem|piece|told|knew|pass|since|top|whole|king|space|heard|best|hour|better|true|during|hundred|five|remember|step|early|hold|west|ground|interest|reach|fast|verb|sing|listen|six|table|travel|less|morning|ten|simple|several|vowel|toward|war|lay|against|pattern|slow|center|love|person|money|serve|appear|road|map|rain|rule|govern|pull|cold|notice|voice|unit|power|town|fine|certain|fly|fall|lead|cry|dark|machine|note|wait|plan|figure|star|box|noun|field|rest|correct|able|pound|done|beauty|drive|stood|contain|front|teach|week|final|gave|green|oh|quick|develop|ocean|warm|free|minute|strong|special|mind|behind|clear|tail|produce|fact|street|inch|multiply|nothing|course|stay|wheel|full|force|blue|object|decide|surface|deep|moon|island|foot|system|busy|test|record|boat|common|gold|possible|plane|stead|dry|wonder|laugh|thousand|ago|ran|check|game|shape|equate|hot|miss|brought|heat|snow|tire|bring|yes|distant|fill|east|paint|language|among|grand|ball|yet|wave|drop|heart|am|present|heavy|dance|engine|position|arm|wide|sail|material|size|vary|settle|speak|weight|general|ice|matter|circle|pair|include|divide|syllable|felt|perhaps|pick|sudden|count|square|reason|length|represent|art|subject|region|energy|hunt|probable|bed|brother|egg|ride|cell|believe|fraction|forest|sit|race|window|store|summer|train|sleep|prove|lone|leg|exercise|wall|catch|mount|wish|sky|board|joy|winter|sat|written|wild|instrument|kept|glass|grass|cow|job|edge|sign|visit|past|soft|fun|bright|gas|weather|month|million|bear|finish|happy|hope|flower|clothe|strange|gone|jump|baby|eight|village|meet|root|buy|raise|solve|metal|whether|push|seven|paragraph|third|shall|held|hair|describe|cook|floor|either|result|burn|hill|safe|cat|century|consider|type|law|bit|coast|copy|phrase|silent|tall|sand|soil|roll|temperature|finger|industry|value|fight|lie|beat|excite|natural|view|sense|ear|else|quite|broke|case|middle|kill|son|lake|moment|scale|loud|spring|observe|child|straight|consonant|nation|dictionary|milk|speed|method|organ|pay|age|section|dress|cloud|surprise|quiet|stone|tiny|climb|cool|design|poor|lot|experiment|bottom|key|iron|single|stick|flat|twenty|skin|smile|crease|hole|trade|melody|trip|office|receive|row|mouth|exact|symbol|die|least|trouble|shout|except|wrote|seed|tone|join|suggest|clean|break|lady|yard|rise|bad|blow|oil|blood|touch|grew|cent|mix|team|wire|cost|lost|brown|wear|garden|equal|sent|choose|fall|fit|flow|fair|bank|collect|save|control|decimal|gentle|woman|captain|practice|separate|difficult|doctor|please|protect|noon|whose|locate|ring|character|insect|caught|period|indicate|radio|spoke|atom|human|history|effect|electric|expect|crop|modern|element|hit|student|corner|party|supply|bone|rail|imagine|provide|agree|thus|capital|won|chair|risk|thick|soldier|process|operate|guess|necessary|sharp|wing|create|neighbor|wash|bat|rather|crowd|corn|compare|poem|string|bell|depend|meat|rub|tube|famous|dollar|stream|fear|sight|thin|triangle|planet|hurry|chief|colony|clock|mine|tie|enter|major|fresh|search|send|yellow|gun|allow|print|dead|spot|desert|suit|current|lift|rose|continue|block|chart|hat|sell|success|company|subtract|event|particular|deal|swim|term|opposite|wife|shoe|shoulder|spread|arrange|camp|invent|cotton|born|determine|quart|nine|truck|noise|level|chance|gather|shop|stretch|throw|shine|property|column|molecule|select|wrong|gray|repeat|require|broad|prepare|salt|nose|plural|anger|claim|continent|oxygen|sugar|death|pretty|skill|women|season|solution|magnet|silver|thank|branch|match|suffix|especially|fig|afraid|huge|sister|steel|discuss|forward|similar|guide|experience|score|apple|bought|led|pitch|coat|mass|card|band|rope|slip|win|dream|evening|condition|feed|tool|total|basic|smell|valley|nor|double|seat|arrive|master|track|parent|shore|division|sheet|substance|favor|connect|post|spend|chord|fat|glad|original|share|station|dad|bread|charge|proper|bar|offer|segment|slave|duck|instant|market|degree|populate|chick|dear|enemy|reply|drink|occur|support|speech|nature|range|steam|motion|path|liquid|log|meant|quotient|teeth|shell|neck)$'

FREQUENT=$(echo "$CHAPTER_LC" | tr '[:punct:]' ' ' | tr -s ' ' '\n' | grep -E '^[a-z]{4,}$' | grep -vE "$STOPWORDS" | sort | uniq -c | sort -rn | awk '$1 >= 3 {print $2}' | head -n 20)

while IFS= read -r word; do
    [ -z "$word" ] && continue
    if ! echo "$REGISTERED" | grep -qFx "$word"; then
        NEW+=("$word")
    fi
done <<< "$FREQUENT"

if [ ${#MISSING[@]} -gt 0 ]; then
    echo ""
    echo "  Missing registered leitmotifs:"
    for m in "${MISSING[@]}"; do echo "    - $m"; done
fi

if [ ${#NEW[@]} -gt 0 ]; then
    echo ""
    echo "  Potential new motifs (≥3x, not in canon):"
    for n in "${NEW[@]}"; do echo "    - $n"; done
fi

if [ ${#MISSING[@]} -gt 0 ]; then
    exit 1
else
    exit 0
fi
