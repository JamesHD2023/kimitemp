#!/bin/bash
# ============================================================
# Chapter Integrity Check
# Fires automatically via the v2.7.73 PostToolUse hook on every
# engine-data/*.md write. Checks:
#   1. NULL bytes (should be 0)
#   2. UTF-8 validity
#   3. Frontmatter completeness (if .md)
#   4. Line-count collapse (vs prior version if available)
# ============================================================
# Usage: bash chapter-integrity-check.sh <file-path> [project-path]

set -euo pipefail

FILE="${1:?Usage: chapter-integrity-check.sh <file-path> [project-path]}"
PROJECT="${2:-}"

if [ ! -f "$FILE" ]; then echo "ERROR: File not found: $FILE" >&2; exit 1; fi

FILENAME=$(basename "$FILE")
EXIT_CODE=0

# 1. NULL byte scan
NULL_COUNT=$(grep -cP '\x00' "$FILE" || true)
if [ -z "$NULL_COUNT" ]; then NULL_COUNT=0; fi
if [ "$NULL_COUNT" -gt 0 ]; then
    echo "✗ NULL bytes: $NULL_COUNT"
    EXIT_CODE=1
else
    echo "✓ NULL bytes: 0"
fi

# 2. UTF-8 validity
if iconv -f UTF-8 -t UTF-8 "$FILE" > /dev/null 2>&1; then
    echo "✓ UTF-8: valid"
else
    echo "✗ UTF-8: invalid encoding detected"
    EXIT_CODE=1
fi

# 3. Frontmatter check (for .md files only)
if [[ "$FILE" == *.md ]]; then
    if head -n 1 "$FILE" | grep -qE '^---\s*$'; then
        if grep -qE '^---\s*$' "$FILE" | head -n 10 | tail -n +2; then
            echo "✓ Frontmatter: present"
        else
            # Check if closing --- exists anywhere in first 30 lines
            if head -n 30 "$FILE" | grep -qE '^---\s*$'; then
                echo "✓ Frontmatter: present"
            else
                echo "⚠ Frontmatter: opening --- but no closing delimiter in first 30 lines"
            fi
        fi
    else
        echo "ℹ Frontmatter: none (optional)"
    fi
fi

# 4. Line-count collapse check (compare against .bak if exists)
LINES=$(wc -l < "$FILE")
WORDS=$(wc -w < "$FILE")
if [ -f "$FILE.bak" ]; then
    OLD_LINES=$(wc -l < "$FILE.bak")
    if [ "$LINES" -lt $((OLD_LINES * 90 / 100)) ]; then
        echo "✗ Line collapse: $LINES vs prior $OLD_LINES (>10% drop)"
        EXIT_CODE=1
    else
        echo "✓ Line count: $LINES (prior $OLD_LINES)"
    fi
else
    echo "ℹ Line count: $LINES (no prior baseline)"
fi

# 5. Terminal punctuation check (last non-empty line should end with . ! ? ")
LAST_TERM=$(tail -n 5 "$FILE" | grep -v '^\s*$' | tail -n 1 | grep -oP '.$')
if echo "$LAST_TERM" | grep -qP '[.!?"'"'"']'; then
    echo "✓ Terminal punctuation: '$LAST_TERM'"
else
    echo "⚠ Terminal punctuation: '$LAST_TERM' (expected . ! ? \")"
fi

# 6. Word count sanity (should be > 0)
if [ "$WORDS" -eq 0 ]; then
    echo "✗ Word count: 0"
    EXIT_CODE=1
else
    echo "✓ Words: $WORDS"
fi

if [ "$EXIT_CODE" -eq 0 ]; then
    echo "Chapter integrity: PASS"
else
    echo "Chapter integrity: FAIL"
fi

exit "$EXIT_CODE"
