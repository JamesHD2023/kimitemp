#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 4: Placeholder & Meta-Text Scan
# Detects brackets, TBD, frame leaks, author notes, chapter refs.
# ============================================================
set -euo pipefail

CHAPTER="${1:?Usage: placeholder-scan.sh <chapter-file>}"
if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

FAIL=0

safe_count() { local c; c=$(eval "$1" 2>/dev/null) || true; echo "${c:-0}" | tr -dc '0-9'; }

echo "=== PLACEHOLDER & META-TEXT SCAN ==="
echo "Chapter: $CHAPTER"
echo ""

echo "--- Placeholders ---"
BRACKETS=$(safe_count "grep -nE '\[[A-Za-z0-9]' '$CHAPTER' | grep -v '^\s*#' | wc -l")
TBD=$(safe_count "grep -ciE '\bTBD\b|\bTODO\b|\bPLACEHOLDER\b|\bINSERT\b' '$CHAPTER'")
CURLY=$(safe_count "grep -cE '\{[a-z]' '$CHAPTER'")

echo "  [BRACKET] placeholders: $BRACKETS"
[ "$BRACKETS" -gt 0 ] && grep -nE '\[[A-Za-z0-9]' "$CHAPTER" | grep -v '^\s*#' | head -5 | sed 's/^/    /' && FAIL=1
echo "  TBD/TODO/PLACEHOLDER/INSERT: $TBD"
[ "$TBD" -gt 0 ] && grep -niE '\bTBD\b|\bTODO\b|\bPLACEHOLDER\b|\bINSERT\b' "$CHAPTER" | head -5 | sed 's/^/    /' && FAIL=1
echo "  {curly brace} templates: $CURLY"
[ "$CURLY" -gt 0 ] && FAIL=1

echo ""
echo "--- Author/Editor Notes ---"
NOTES=$(safe_count "grep -cE '\[Author:|\[NOTE:|\[EDITOR:|\[TODO:' '$CHAPTER'")
echo "  Author/editor notes: $NOTES"
[ "$NOTES" -gt 0 ] && FAIL=1

echo ""
echo "--- Chapter/Part References ---"
CH_REFS=$(safe_count "grep -ciE 'in chapter [0-9]|by chapter [0-9]|chapter [0-9]+ of|Part (One|Two|Three|Four|[0-9])' '$CHAPTER'")
echo "  Chapter/Part references: $CH_REFS"
[ "$CH_REFS" -gt 0 ] && grep -niE 'in chapter [0-9]|by chapter [0-9]' "$CHAPTER" | head -5 | sed 's/^/    /' && FAIL=1

echo ""
echo "--- Reader-Addressing ---"
READER=$(safe_count "grep -ciE 'the reader will|as mentioned earlier|as noted above|as we saw|you may recall' '$CHAPTER'")
echo "  Reader-addressing: $READER"
[ "$READER" -gt 0 ] && FAIL=1

echo ""
echo "=== SUMMARY ==="
echo "Placeholders: $BRACKETS | TBD: $TBD | Curly: $CURLY | Notes: $NOTES | Ch-refs: $CH_REFS | Reader: $READER"
[ "$FAIL" -eq 1 ] && echo "STATUS: FAIL" && exit 1 || echo "STATUS: PASS"
