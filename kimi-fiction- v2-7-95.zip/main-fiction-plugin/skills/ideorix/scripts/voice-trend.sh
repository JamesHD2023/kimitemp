#!/bin/bash
# ============================================================
# Module 9 — Voice Trend
# Detects boiled-frog drift across the last 5 chapters by
# comparing current chapter's voice metrics against the
# rolling median of the previous 4.
#
# FAIL if any metric drifts >30% from rolling baseline.
# WARN if drift is 15-30%.
# PASS otherwise.
# ============================================================
# Usage: bash voice-trend.sh <chapter-file> <project-path>

set -euo pipefail

CHAPTER="${1:?Usage: voice-trend.sh <chapter-file> <project-path>}"
PROJECT="${2:?Usage: voice-trend.sh <chapter-file> <project-path>}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER" >&2; exit 1; fi

CHAPTER_NAME=$(basename "$CHAPTER" .md)
LEDGER="$PROJECT/engine-data/voice-ledger.md"

# If no ledger or <5 entries, skip (insufficient history)
if [ ! -f "$LEDGER" ]; then
    echo "  Voice Trend: SKIP — no voice ledger found (need Module 8 to run first)"
    exit 0
fi

# Count ledger rows (skip header lines, count data rows)
ROW_COUNT=$(grep -cE '^\| ch[0-9]+' "$LEDGER" || true)
if [ -z "$ROW_COUNT" ] || [ "$ROW_COUNT" -lt 5 ]; then
    echo "  Voice Trend: SKIP — only $ROW_COUNT chapter(s) in ledger (need ≥5)"
    exit 0
fi

# Extract the last 5 data rows (including current) from ledger
# Ledger columns: | Chapter | Words | FP Count | FP Ratio | Sents | Mean | Median | Short ≤5 | Long ≥25 | Status |
TAIL5=$(grep -E '^\| ch[0-9]+' "$LEDGER" | tail -n 5)

# Current chapter must be the last row
CURRENT_ROW=$(echo "$TAIL5" | tail -n 1)
CURRENT_CH=$(echo "$CURRENT_ROW" | awk -F'|' '{gsub(/ /,"",$2); print $2}')

if [ "$CURRENT_CH" != "$CHAPTER_NAME" ]; then
    echo "  Voice Trend: SKIP — current chapter $CHAPTER_NAME not the latest in ledger (found $CURRENT_CH)"
    exit 0
fi

# Previous 4 rows = rolling baseline
BASE4=$(echo "$TAIL5" | head -n 4)
if [ -z "$BASE4" ]; then
    echo "  Voice Trend: SKIP — no baseline rows available"
    exit 0
fi

# Compute rolling medians for baseline (FP ratio, mean sentence length, median length, short%, long%)
compute_median() {
    local col="$1"
    echo "$BASE4" | awk -F'|' -v c="$col" '
    {
        gsub(/ /,"",$c);
        val = $c + 0;
        if (val != "" && val >= 0) { a[++n] = val; }
    }
    END {
        if (n == 0) { print "0"; exit; }
        asort(a);
        if (n % 2 == 1) print a[int((n+1)/2)];
        else print (a[n/2] + a[n/2+1]) / 2;
    }'
}

FP_MED=$(compute_median 5)
MEAN_MED=$(compute_median 7)
MEDIAN_MED=$(compute_median 8)
SHORT_MED=$(compute_median 9)
LONG_MED=$(compute_median 10)

# Extract current values
CUR_FP=$(echo "$CURRENT_ROW" | awk -F'|' '{gsub(/ /,"",$5); print $5+0}')
CUR_MEAN=$(echo "$CURRENT_ROW" | awk -F'|' '{gsub(/ /,"",$7); print $7+0}')
CUR_MEDIAN=$(echo "$CURRENT_ROW" | awk -F'|' '{gsub(/ /,"",$8); print $8+0}')
CUR_SHORT=$(echo "$CURRENT_ROW" | awk -F'|' '{gsub(/ /,"",$9); print $9+0}')
CUR_LONG=$(echo "$CURRENT_ROW" | awk -F'|' '{gsub(/ /,"",$10); print $10+0}')

# Drift percentage function: abs((cur - med) / med) * 100
# If median is 0, treat drift as 0 if current is also 0, else 100.
drift_pct() {
    awk "BEGIN {
        cur = $1; med = $2;
        if (med == 0) { if (cur == 0) print 0; else print 100; exit; }
        d = (cur - med) / med;
        if (d < 0) d = -d;
        printf \"%.1f\", d * 100;
    }"
}

FP_DRIFT=$(drift_pct "$CUR_FP" "$FP_MED")
MEAN_DRIFT=$(drift_pct "$CUR_MEAN" "$MEAN_MED")
MEDIAN_DRIFT=$(drift_pct "$CUR_MEDIAN" "$MEDIAN_MED")
SHORT_DRIFT=$(drift_pct "$CUR_SHORT" "$SHORT_MED")
LONG_DRIFT=$(drift_pct "$CUR_LONG" "$LONG_MED")

# Determine worst drift
WORST_DRIFT=$(printf '%s\n%s\n%s\n%s\n%s\n' "$FP_DRIFT" "$MEAN_DRIFT" "$MEDIAN_DRIFT" "$SHORT_DRIFT" "$LONG_DRIFT" | sort -n | tail -n 1)

STATUS="PASS"
EXIT_CODE=0
if awk "BEGIN {exit !($WORST_DRIFT > 30.0)}"; then
    STATUS="FAIL"
    EXIT_CODE=1
elif awk "BEGIN {exit !($WORST_DRIFT > 15.0)}"; then
    STATUS="WARN"
    EXIT_CODE=0
fi

# Dashboard
printf "  Baseline (median of prev 4):\n"
printf "    FP ratio: %.4f | Mean: %.1f | Median: %.1f | Short: %.0f | Long: %.0f\n" "$FP_MED" "$MEAN_MED" "$MEDIAN_MED" "$SHORT_MED" "$LONG_MED"
printf "  Current:\n"
printf "    FP ratio: %.4f | Mean: %.1f | Median: %.1f | Short: %.0f | Long: %.0f\n" "$CUR_FP" "$CUR_MEAN" "$CUR_MEDIAN" "$CUR_SHORT" "$CUR_LONG"
printf "  Drift %%:  FP %s%% | Mean %s%% | Median %s%% | Short %s%% | Long %s%%\n" "$FP_DRIFT" "$MEAN_DRIFT" "$MEDIAN_DRIFT" "$SHORT_DRIFT" "$LONG_DRIFT"
printf "  Worst drift: %s%% | Status: %s\n" "$WORST_DRIFT" "$STATUS"

exit "$EXIT_CODE"
