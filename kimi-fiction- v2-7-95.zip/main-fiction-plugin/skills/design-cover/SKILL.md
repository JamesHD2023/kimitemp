---
name: design-cover
description: "Create market-researched book cover concepts with AI image prompts"
---

Launch the Ideorix Cover Designer. Creates genre-accurate cover concepts with prompts for Ideogram, Leonardo.ai, Grok Aurora, and Midjourney — plus print specifications. See `cover-designer.md` in references for the complete protocol.
