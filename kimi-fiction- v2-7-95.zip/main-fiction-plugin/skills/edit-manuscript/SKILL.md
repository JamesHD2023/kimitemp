---
name: edit-manuscript
description: "Run the editorial pipeline on your manuscript"
---

Run the Ideorix editorial pipeline on a manuscript. Supports both Ideorix-generated and user-written manuscripts (BYOM). See `edit-and-revise.md` in references for the complete protocol.
