---
name: research-a-project
description: "Ideorix Non-Fiction: start a new non-fiction book from scratch. Trigger: 'Research a project', 'Write non-fiction', 'Write a [memoir|biography|self-help|history|business] book', 'Start a new non-fiction manuscript', 'Authority profile', 'Research bible'. Launches the NF Phase 1 setup → Authority Profile → Research Bible → chapter-by-chapter pipeline. Non-fiction only (use write-a-book for fiction)."
---

This is a trigger entry point for the Ideorix Non-Fiction engine. To
handle this request:

1. Read and follow `skills/ideorix-nonfiction/SKILL.md` from the same
   plugin (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Full Creative Suite flow at item 1, "Research a New
   Project" (equivalently, Writers Studio "Start New Project").
3. Follow `skills/ideorix-nonfiction/references/research-a-project.md`
   for the complete Phase 1 → Phase 6 NF pipeline (category selection,
   authority profile, research bible, write/edit/publish).

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
