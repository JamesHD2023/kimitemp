---
name: design-cover
description: "Ideorix Non-Fiction: design a non-fiction book cover plus marketing materials. Trigger: 'Cover for my NF book', 'Design a non-fiction cover', 'Blurb for my book', 'Amazon description', 'NF marketing copy', 'Cover and marketing'. NF-specific cover conventions (trade vs academic, category-appropriate typography), AI image prompts, plus blurbs, Amazon NF descriptions, and marketing materials. Non-fiction only."
---

This is a trigger entry point for the Ideorix Non-Fiction engine. To
handle this request:

1. Read and follow `skills/ideorix-nonfiction/SKILL.md` from the same
   plugin (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Writers Studio flow at item 5, "Marketing & Cover".
3. Follow `skills/ideorix-nonfiction/references/cover-designer.md`
   (cover concepts + AI image prompts + print specifications) and
   `skills/ideorix-nonfiction/references/marketing-and-cover.md`
   (blurbs, Amazon descriptions, marketing materials).

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
