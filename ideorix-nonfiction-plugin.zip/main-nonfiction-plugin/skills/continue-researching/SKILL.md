---
name: continue-researching
description: "Ideorix Non-Fiction: resume an in-progress non-fiction book. Trigger: 'Continue researching', 'Resume my non-fiction book', 'Next NF chapter', 'Pick up my memoir', 'Continue my [history|biography|self-help] book'. Reads the NF pipeline checkpoint, runs the prior-chapter continuity pre-load HARD GATE, and dispatches the next unwritten chapter. Non-fiction only."
---

This is a trigger entry point for the Ideorix Non-Fiction engine. To
handle this request:

1. Read and follow `skills/ideorix-nonfiction/SKILL.md` from the same
   plugin (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Full Creative Suite flow at item 2, "Continue
   Researching".
3. Follow `skills/ideorix-nonfiction/references/continue-researching.md`
   for the complete resume protocol (project detection, checkpoint
   read, prior-chapter continuity pre-load, next-chapter dispatch).

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
