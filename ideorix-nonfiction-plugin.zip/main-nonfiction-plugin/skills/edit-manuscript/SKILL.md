---
name: edit-manuscript
description: "Ideorix Non-Fiction: run the editorial pipeline on a finished non-fiction manuscript. Trigger: 'Edit my NF manuscript', 'Edit my [memoir|biography|self-help] book', 'Editorial pass on my non-fiction', 'Fact-audit my NF book', 'Run the NF editor', 'Non-fiction proofreading'. Full Stage 0–13 editorial pipeline including Fact Audit, Citation Keeper, and category-specific axes. Non-fiction only."
---

This is a trigger entry point for the Ideorix Non-Fiction engine. To
handle this request:

1. Read and follow `skills/ideorix-nonfiction/SKILL.md` from the same
   plugin (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Writers Studio flow at item 3, "Edit & Revise".
3. Follow `skills/ideorix-nonfiction/references/edit-and-revise.md`
   (user-facing protocol) and
   `skills/ideorix-nonfiction/references/editorial-suite.md`
   (engine-facing stage specification) for the complete NF editorial
   pipeline.

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
