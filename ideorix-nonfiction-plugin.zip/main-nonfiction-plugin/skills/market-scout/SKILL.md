---
name: market-scout
description: "Ideorix Non-Fiction: live market intelligence for non-fiction. Trigger: 'NF market scout', 'Comp titles for my [memoir|history|biography|self-help] book', 'What sells in non-fiction', 'NF bestsellers', 'BookTube long-form', 'Substack newsletter research', 'Authority parity comps'. NF-shaped market research: category trends, NF bestseller analysis, comp titles by credential + topical proximity, NF reader-demand signals. Non-fiction only."
---

This is a trigger entry point for the Ideorix Non-Fiction engine. To
handle this request:

1. Read and follow `skills/ideorix-nonfiction/SKILL.md` from the same
   plugin (path is relative to the plugin install root, whatever it happens to be at runtime — the only invariant is that `skills/<name>/` paths resolve to the corresponding directories inside the same plugin).
2. Enter the Writers Studio flow at item 7, "Market Scout".
3. Follow `skills/ideorix-nonfiction/references/market-scout.md`
   (user-facing protocol) and
   `skills/ideorix-nonfiction/references/market-scout-protocol.md`
   (engine-facing search + analysis specification) for the complete
   live-market-intelligence run.

All engine state, file conventions, and HARD GATEs are defined in
the parent skill — do not improvise.
