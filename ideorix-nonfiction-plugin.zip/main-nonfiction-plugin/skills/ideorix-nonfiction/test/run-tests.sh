#!/bin/bash
# ============================================================
# Ideorix Non-Fiction — smoke-test runner
# Verifies the audit suite behaves correctly on known-clean and
# known-dirty fixtures + regression tests for every Phase 1 bug.
# ============================================================
# Usage: bash test/run-tests.sh

set -euo pipefail

# Resolve to the plugin root (skills/ideorix-nonfiction/)
TEST_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_ROOT="$(cd "$TEST_DIR/.." && pwd)"
SCRIPTS="$PLUGIN_ROOT/scripts"
FIXTURES="$TEST_DIR/fixtures"
REFERENCES="$PLUGIN_ROOT/references"

cd "$PLUGIN_ROOT"
PASS=0
FAIL=0

assert_pass() {
    local name="$1"; shift
    if "$@" < /dev/null > /dev/null 2>&1; then
        echo "PASS: $name"
        PASS=$((PASS + 1))
    else
        echo "FAIL: $name (expected pass, got non-zero exit)"
        FAIL=$((FAIL + 1))
    fi
}

assert_fail() {
    local name="$1"; shift
    if "$@" < /dev/null > /dev/null 2>&1; then
        echo "FAIL: $name (expected fail, got pass)"
        FAIL=$((FAIL + 1))
    else
        echo "PASS: $name (correctly failed)"
        PASS=$((PASS + 1))
    fi
}

# Set up a per-run test project structure
TEST_PROJ=$(mktemp -d)
trap 'rm -rf "$TEST_PROJ"' EXIT
mkdir -p "$TEST_PROJ/engine-data/chapters"
cp "$FIXTURES/entity-canon.md" "$TEST_PROJ/engine-data/entity-canon.md"
cp "$REFERENCES/forbidden-words.md" "$TEST_PROJ/forbidden-words.md"
cp "$FIXTURES/clean-chapter.md" "$TEST_PROJ/engine-data/chapters/ch01.md"
cp "$FIXTURES/dirty-chapter.md" "$TEST_PROJ/engine-data/chapters/ch02.md"

# === Per-module assertions ===
echo "--- Per-module assertions ---"
assert_pass "formatting clean"     bash "$SCRIPTS/formatting-check.sh"    "$TEST_PROJ/engine-data/chapters/ch01.md"
assert_fail "formatting dirty"     bash "$SCRIPTS/formatting-check.sh"    "$TEST_PROJ/engine-data/chapters/ch02.md"
assert_pass "patterns clean"       bash "$SCRIPTS/pattern-counter.sh"     "$TEST_PROJ/engine-data/chapters/ch01.md"
assert_fail "patterns dirty"       bash "$SCRIPTS/pattern-counter.sh"     "$TEST_PROJ/engine-data/chapters/ch02.md"
assert_pass "placeholders clean"   bash "$SCRIPTS/placeholder-scan.sh"    "$TEST_PROJ/engine-data/chapters/ch01.md"
assert_fail "placeholders dirty"   bash "$SCRIPTS/placeholder-scan.sh"    "$TEST_PROJ/engine-data/chapters/ch02.md"
assert_pass "forbidden clean"      bash "$SCRIPTS/forbidden-words-scan.sh" "$TEST_PROJ/engine-data/chapters/ch01.md" "$TEST_PROJ/forbidden-words.md"
assert_fail "forbidden dirty"      bash "$SCRIPTS/forbidden-words-scan.sh" "$TEST_PROJ/engine-data/chapters/ch02.md" "$TEST_PROJ/forbidden-words.md"
assert_pass "entity canon clean"   bash "$SCRIPTS/entity-canon-verify.sh" "$TEST_PROJ/engine-data/chapters/ch01.md" "$TEST_PROJ"

# === Specific bug-fix regression tests ===
echo ""
echo "--- Regression tests ---"

# Phase 1 Fix 1: en-dash in page range should NOT trip em-dash check
echo "Citation: Hall et al., pp. 49–73." > "$TEST_PROJ/test-endash.md"
assert_pass "Fix 1: en-dash in page range" bash "$SCRIPTS/formatting-check.sh" "$TEST_PROJ/test-endash.md"

# Phase 1 Fix 2: entity canon must load >0 entries (catches the gawk /i regression)
LOADED=$(bash "$SCRIPTS/entity-canon-verify.sh" "$TEST_PROJ/engine-data/chapters/ch01.md" "$TEST_PROJ" < /dev/null 2>&1 | grep -E 'Authorised names/aliases loaded:' | grep -oE '[0-9]+' | head -1 || true)
if [ "${LOADED:-0}" -gt 0 ]; then
    echo "PASS: Fix 2: entity canon loaded $LOADED entries (gawk regression guard)"
    PASS=$((PASS + 1))
else
    echo "FAIL: Fix 2: entity canon loaded 0 entries — gawk regression!"
    FAIL=$((FAIL + 1))
fi

# Phase 1 Fix 3: occurrence count not line count
echo "Most. Most. Most. Most." > "$TEST_PROJ/test-most.md"
# Anchor: "  most" followed by whitespace + digit (the count column),
# distinguishing from "  most scholars agree" which has letters next.
COUNT=$(bash "$SCRIPTS/pattern-counter.sh" "$TEST_PROJ/test-most.md" < /dev/null 2>&1 | grep -E '^  most[[:space:]]+[0-9]' | head -1 | awk '{print $2}' || true)
if [ "${COUNT:-0}" -ge 4 ]; then
    echo "PASS: Fix 3: 'most' counted $COUNT times (occurrence count, not line count)"
    PASS=$((PASS + 1))
else
    echo "FAIL: Fix 3: 'most' counted only $COUNT — should be 4"
    FAIL=$((FAIL + 1))
fi

# Phase 2 Fix 6: mid-paragraph reader address (de-anchored regex)
cat > "$TEST_PROJ/test-midpara.md" << 'EOF'
This is normal prose, and the reader may notice the warning.
EOF
COUNT=$(bash "$SCRIPTS/placeholder-scan.sh" "$TEST_PROJ/test-midpara.md" < /dev/null 2>&1 | grep -E 'Reader direct-address:' | grep -oE '[0-9]+' | head -1 || true)
if [ "${COUNT:-0}" -ge 1 ]; then
    echo "PASS: Fix 6: mid-paragraph reader address detected"
    PASS=$((PASS + 1))
else
    echo "FAIL: Fix 6: mid-paragraph reader address missed"
    FAIL=$((FAIL + 1))
fi

# Phase 2 Fix 8: temporal-verify exact-match guard
mkdir -p "$TEST_PROJ/temptest/engine-data"
cat > "$TEST_PROJ/temptest/engine-data/project-config.md" << 'EOF'
temporal_scope: narrative
permitted_months: ber
permitted_season: autumn
EOF
echo "It was a cold October morning." > "$TEST_PROJ/temptest/chap.md"
# Bug pre-fix: 'ber' as substring of 'october' would silently allow it.
# Post-fix: comma-bounded match correctly rejects October.
if bash "$SCRIPTS/temporal-verify.sh" "$TEST_PROJ/temptest/chap.md" "$TEST_PROJ/temptest" < /dev/null > /dev/null 2>&1; then
    echo "FAIL: Fix 8: 'ber' substring silently allowed October (bug returned)"
    FAIL=$((FAIL + 1))
else
    echo "PASS: Fix 8: 'ber' substring correctly rejected (October flagged)"
    PASS=$((PASS + 1))
fi

# v2.7.62 gate-behaviour tests: Class B Delta Gate + Canon Validation
# Sweep Gate. Verifies the two new artifact-level gates correctly FAIL
# on missing artifacts, PASS on opt-out, and PASS when artifacts are
# present + fresh.
GATE_PROJ=$(mktemp -d)
mkdir -p "$GATE_PROJ/engine-data/chapters" "$GATE_PROJ/engine-data/reports/validate"
echo "# Ch 1" > "$GATE_PROJ/engine-data/chapters/ch01.md"

# Delta gate: FAIL on missing artifacts
assert_fail "v2.7.62 Class B Delta Gate: FAIL on missing artifacts" \
    bash "$SCRIPTS/class-b-delta-gate.sh" "$GATE_PROJ" 1

# Delta gate: PASS on documented opt-out
echo "class_b_delta_status: skip" > "$GATE_PROJ/engine-data/project-config.md"
assert_pass "v2.7.62 Class B Delta Gate: PASS on class_b_delta_status: skip opt-out" \
    bash "$SCRIPTS/class-b-delta-gate.sh" "$GATE_PROJ" 1

# Delta gate: PASS on artifacts present + fresh
rm "$GATE_PROJ/engine-data/project-config.md"
echo "stub" > "$GATE_PROJ/engine-data/reports/validate/leitmotif-tracker-delta-ch01-subagent.md"
echo "stub" > "$GATE_PROJ/engine-data/reports/validate/injury-accumulation-delta-ch01-subagent.md"
sleep 1
echo "stub" > "$GATE_PROJ/engine-data/reports/leitmotif-ledger.md"
echo "stub" > "$GATE_PROJ/engine-data/reports/injury-ledger.md"
assert_pass "v2.7.62 Class B Delta Gate: PASS on artifacts present + fresh ledgers" \
    bash "$SCRIPTS/class-b-delta-gate.sh" "$GATE_PROJ" 1

# v2.7.63 category-aware default: gate must auto-PASS on argumentative-NF
# even when no artifacts are present (the audits don't apply).
rm -rf "$GATE_PROJ"
GATE_PROJ=$(mktemp -d)
mkdir -p "$GATE_PROJ/engine-data/chapters" "$GATE_PROJ/engine-data/reports/validate"
echo "# Ch 1" > "$GATE_PROJ/engine-data/chapters/ch01.md"

echo "nf_shape: argumentative" > "$GATE_PROJ/engine-data/project-config.md"
assert_pass "v2.7.63 Class B Delta Gate: auto-PASS on nf_shape: argumentative" \
    bash "$SCRIPTS/class-b-delta-gate.sh" "$GATE_PROJ" 1

echo "nf_category: business" > "$GATE_PROJ/engine-data/project-config.md"
assert_pass "v2.7.63 Class B Delta Gate: auto-PASS on nf_category: business (argumentative slug)" \
    bash "$SCRIPTS/class-b-delta-gate.sh" "$GATE_PROJ" 1

echo "nf_category: how-to-guide" > "$GATE_PROJ/engine-data/project-config.md"
assert_pass "v2.7.63 Class B Delta Gate: auto-PASS on nf_category: how-to-guide (argumentative slug)" \
    bash "$SCRIPTS/class-b-delta-gate.sh" "$GATE_PROJ" 1

# Narrative-NF category — should NOT auto-skip; gate enforces, FAILs on missing artifacts.
echo "nf_category: memoir" > "$GATE_PROJ/engine-data/project-config.md"
assert_fail "v2.7.63 Class B Delta Gate: FAIL on nf_category: memoir + missing artifacts (narrative NF, audits apply)" \
    bash "$SCRIPTS/class-b-delta-gate.sh" "$GATE_PROJ" 1

# Force-enable override: even on argumentative category, enable forces enforcement.
cat > "$GATE_PROJ/engine-data/project-config.md" <<'EOF'
nf_category: business
class_b_delta_status: enable
EOF
assert_fail "v2.7.63 Class B Delta Gate: FAIL on argumentative category with class_b_delta_status: enable + missing artifacts" \
    bash "$SCRIPTS/class-b-delta-gate.sh" "$GATE_PROJ" 1

# Sweep gate: FAIL on missing report
assert_fail "v2.7.62 Canon Validation Sweep Gate: FAIL on missing report" \
    bash "$SCRIPTS/canon-validation-sweep-gate.sh" "$GATE_PROJ"

# Sweep gate: FAIL on incomplete report (missing one of the four verdicts)
sleep 1
cat > "$GATE_PROJ/engine-data/reports/canon-validation-sweep.md" <<'SWEEP_EOF'
## leitmotif-tracker: PASS
## injury-accumulation: PASS
## humanity-gate: WARN
SWEEP_EOF
assert_fail "v2.7.62 Canon Validation Sweep Gate: FAIL on report missing one of four verdicts" \
    bash "$SCRIPTS/canon-validation-sweep-gate.sh" "$GATE_PROJ"

# Sweep gate: PASS on complete report with all four verdicts
cat > "$GATE_PROJ/engine-data/reports/canon-validation-sweep.md" <<'SWEEP_EOF'
## leitmotif-tracker: PASS
## injury-accumulation: PASS
## humanity-gate: WARN
## intent-preservation: PASS
SWEEP_EOF
assert_pass "v2.7.62 Canon Validation Sweep Gate: PASS on complete report (4/4 verdicts)" \
    bash "$SCRIPTS/canon-validation-sweep-gate.sh" "$GATE_PROJ"

rm -rf "$GATE_PROJ"

# v2.7.64 DOCX Integrity Gate tests. Builds a minimal valid DOCX
# fixture per case and verifies the gate accepts/rejects correctly.
DOCX_TEST_DIR=$(mktemp -d)
build_test_docx() {
    local out_dir="$1" doc_xml_path="$2"
    rm -rf "$out_dir/work"
    mkdir -p "$out_dir/work/word" "$out_dir/work/_rels"
    printf '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>\n' > "$out_dir/work/[Content_Types].xml"
    printf '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>\n' > "$out_dir/work/_rels/.rels"
    cp "$doc_xml_path" "$out_dir/work/word/document.xml"
    (cd "$out_dir/work" && zip -qr "$out_dir/test.docx" .)
}

# Case 1: clean DOCX with valid XML and seven words → PASS
cat > "$DOCX_TEST_DIR/clean.xml" <<'XML_EOF'
<?xml version="1.0" encoding="UTF-8"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body><w:p><w:r><w:t>Hello world this is a clean test.</w:t></w:r></w:p></w:body>
</w:document>
XML_EOF
build_test_docx "$DOCX_TEST_DIR" "$DOCX_TEST_DIR/clean.xml"
assert_pass "v2.7.64 DOCX Integrity Gate: PASS on clean DOCX" \
    bash "$SCRIPTS/docx-integrity-check.sh" "$DOCX_TEST_DIR/test.docx"

# Case 2: missing file → FAIL
assert_fail "v2.7.64 DOCX Integrity Gate: FAIL on missing file" \
    bash "$SCRIPTS/docx-integrity-check.sh" "$DOCX_TEST_DIR/nonexistent.docx"

# Case 3: null byte in document.xml → FAIL
python3 -c "
content = b'<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\n<w:body>\x00<w:p><w:r><w:t>Hello</w:t></w:r></w:p></w:body>\n</w:document>'
open('$DOCX_TEST_DIR/nullbyte.xml', 'wb').write(content)
"
build_test_docx "$DOCX_TEST_DIR" "$DOCX_TEST_DIR/nullbyte.xml"
assert_fail "v2.7.64 DOCX Integrity Gate: FAIL on null bytes in document.xml" \
    bash "$SCRIPTS/docx-integrity-check.sh" "$DOCX_TEST_DIR/test.docx"

# Case 4: malformed XML → FAIL
echo "<w:document><w:body><w:p>unclosed" > "$DOCX_TEST_DIR/malformed.xml"
build_test_docx "$DOCX_TEST_DIR" "$DOCX_TEST_DIR/malformed.xml"
assert_fail "v2.7.64 DOCX Integrity Gate: FAIL on malformed XML" \
    bash "$SCRIPTS/docx-integrity-check.sh" "$DOCX_TEST_DIR/test.docx"

# Case 5: word count matches source MD → PASS
build_test_docx "$DOCX_TEST_DIR" "$DOCX_TEST_DIR/clean.xml"
cat > "$DOCX_TEST_DIR/source.md" <<'MD_EOF'
---
title: Match
---
Hello world this is a clean test.
MD_EOF
assert_pass "v2.7.64 DOCX Integrity Gate: PASS on matched word counts vs source MD" \
    bash "$SCRIPTS/docx-integrity-check.sh" "$DOCX_TEST_DIR/test.docx" "$DOCX_TEST_DIR/source.md"

# Case 6: large word-count drift → FAIL
python3 -c "
words = ' '.join(['drift'] * 200)
print('---\ntitle: Big\n---\n' + words)
" > "$DOCX_TEST_DIR/big.md"
assert_fail "v2.7.64 DOCX Integrity Gate: FAIL on large word-count drift (200 vs 7 words)" \
    bash "$SCRIPTS/docx-integrity-check.sh" "$DOCX_TEST_DIR/test.docx" "$DOCX_TEST_DIR/big.md"

rm -rf "$DOCX_TEST_DIR"

# v2.7.65 Voice audit tests. Cover voice-metrics-audit (per-chapter
# measurement + ledger append), voice-trend-audit (PASS / WARN / FAIL /
# INFO bands + opt-out), and voice-profile-preload-gate (missing /
# skeleton / complete / opt-out).
VOICE_TEST_DIR=$(mktemp -d)
mkdir -p "$VOICE_TEST_DIR/engine-data/reports" "$VOICE_TEST_DIR/engine-data/chapters"

cat > "$VOICE_TEST_DIR/engine-data/chapters/ch01.md" <<'CH'
---
title: Test
---

I remember the morning my mother told me about the box. The light came through the kitchen window slantwise, the way it does in early autumn.

I waited for the kettle to boil. My grandmother had written the note twenty-three years before. We did not know what to expect.

The box itself was nothing remarkable. It sat on the counter between us. We looked at it. I felt the weight of every year we had not spoken about.
CH
assert_pass "v2.7.65 voice-metrics-audit: PASS on FP-rich memoir chapter (always exits 0)" \
    bash "$SCRIPTS/voice-metrics-audit.sh" "$VOICE_TEST_DIR/engine-data/chapters/ch01.md" "$VOICE_TEST_DIR"

# Ledger should now exist with one row
test -f "$VOICE_TEST_DIR/engine-data/reports/voice-metrics-ledger.md" \
    && grep -q '| ch01 |' "$VOICE_TEST_DIR/engine-data/reports/voice-metrics-ledger.md"
if [ $? -eq 0 ]; then
    echo "PASS: v2.7.65 voice-metrics-audit: ledger created + ch01 row appended"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.65 voice-metrics-audit: ledger missing or no ch01 row"
    FAIL=$((FAIL + 1))
fi

# Synthetic ledger: PASS case (healthy 5-chapter run)
TREND_PASS=$(mktemp -d)
mkdir -p "$TREND_PASS/engine-data/reports"
cat > "$TREND_PASS/engine-data/reports/voice-metrics-ledger.md" <<'LEDGER'
# Voice Metrics Ledger

| Timestamp | Chapter | Total paras | FP paras | FP ratio | Sent median | Sent mean | Sent max | FP class | Words |
|---|---|---|---|---|---|---|---|---|---|
| 2026-04-01 10:00:00 | ch01 | 40 | 12 | 0.3000 | 14 | 15.0 | 32 | PASS | 2500 |
| 2026-04-02 10:00:00 | ch02 | 38 | 11 | 0.2895 | 15 | 16.0 | 30 | PASS | 2600 |
| 2026-04-03 10:00:00 | ch03 | 42 | 10 | 0.2381 | 14 | 15.5 | 28 | PASS | 2700 |
| 2026-04-04 10:00:00 | ch04 | 40 | 11 | 0.2750 | 13 | 14.0 | 25 | PASS | 2400 |
| 2026-04-05 10:00:00 | ch05 | 45 | 12 | 0.2667 | 13 | 14.5 | 26 | PASS | 2500 |
LEDGER
assert_pass "v2.7.65 voice-trend-audit: PASS on healthy 5-chapter window" \
    bash "$SCRIPTS/voice-trend-audit.sh" "$TREND_PASS"
rm -rf "$TREND_PASS"

# Synthetic ledger: FAIL case (boiled-frog drift)
TREND_FAIL=$(mktemp -d)
mkdir -p "$TREND_FAIL/engine-data/reports"
cat > "$TREND_FAIL/engine-data/reports/voice-metrics-ledger.md" <<'LEDGER'
# Voice Metrics Ledger

| Timestamp | Chapter | Total paras | FP paras | FP ratio | Sent median | Sent mean | Sent max | FP class | Words |
|---|---|---|---|---|---|---|---|---|---|
| 2026-04-04 10:00:00 | ch04 | 40 | 6  | 0.1500 | 13 | 14.0 | 25 | INFO | 2400 |
| 2026-04-05 10:00:00 | ch05 | 45 | 3  | 0.0667 | 13 | 14.5 | 26 | WARN | 2500 |
| 2026-04-06 10:00:00 | ch06 | 44 | 0  | 0.0000 | 14 | 15.0 | 29 | WARN | 2550 |
| 2026-04-07 10:00:00 | ch07 | 46 | 0  | 0.0000 | 13 | 14.5 | 30 | WARN | 2480 |
| 2026-04-08 10:00:00 | ch08 | 42 | 0  | 0.0000 | 14 | 15.5 | 28 | WARN | 2510 |
LEDGER
assert_fail "v2.7.65 voice-trend-audit: FAIL on boiled-frog drift (3 consecutive zeros + low window-mean)" \
    bash "$SCRIPTS/voice-trend-audit.sh" "$TREND_FAIL"

# Same ledger but with opt-out → PASS
echo "voice_trend_status: skip" > "$TREND_FAIL/engine-data/project-config.md"
assert_pass "v2.7.65 voice-trend-audit: PASS on voice_trend_status: skip opt-out" \
    bash "$SCRIPTS/voice-trend-audit.sh" "$TREND_FAIL"
rm -rf "$TREND_FAIL"

# Insufficient data → exits 0 with INFO
TREND_INFO=$(mktemp -d)
mkdir -p "$TREND_INFO/engine-data/reports"
cat > "$TREND_INFO/engine-data/reports/voice-metrics-ledger.md" <<'LEDGER'
| Timestamp | Chapter | Total paras | FP paras | FP ratio | Sent median | Sent mean | Sent max | FP class | Words |
|---|---|---|---|---|---|---|---|---|---|
| 2026-04-01 10:00:00 | ch01 | 40 | 12 | 0.3000 | 14 | 15.0 | 32 | PASS | 2500 |
LEDGER
assert_pass "v2.7.65 voice-trend-audit: PASS (INFO) on insufficient data" \
    bash "$SCRIPTS/voice-trend-audit.sh" "$TREND_INFO"
rm -rf "$TREND_INFO"

# voice-profile-preload-gate: missing file FAILs
PRELOAD_TEST=$(mktemp -d)
mkdir -p "$PRELOAD_TEST/engine-data"
assert_fail "v2.7.65 voice-profile-preload-gate: FAIL on missing voice-profile.md" \
    bash "$SCRIPTS/voice-profile-preload-gate.sh" "$PRELOAD_TEST"

# Skeleton file FAILs (no fp_target, no exemplar, no prose desc)
cat > "$PRELOAD_TEST/engine-data/voice-profile.md" <<'EOF'
# Voice Profile

This is a stub file with no required fields.
EOF
assert_fail "v2.7.65 voice-profile-preload-gate: FAIL on skeleton voice-profile.md" \
    bash "$SCRIPTS/voice-profile-preload-gate.sh" "$PRELOAD_TEST"

# Complete profile PASSes
cat > "$PRELOAD_TEST/engine-data/voice-profile.md" <<'EOF'
# Voice Profile

fp_target: 0.25
sentence_band_min: 13
sentence_band_max: 19

voice_calibration_exemplar: engine-data/chapters/ch02.md
voice_calibration_exemplar: engine-data/chapters/ch07.md

voice_prose_description: Conversational memoir register with present-tense scene anchoring. The author is in the room.
EOF
assert_pass "v2.7.65 voice-profile-preload-gate: PASS on complete voice-profile.md" \
    bash "$SCRIPTS/voice-profile-preload-gate.sh" "$PRELOAD_TEST"

# Opt-out PASSes even with missing file
rm "$PRELOAD_TEST/engine-data/voice-profile.md"
echo "voice_profile_status: legacy" > "$PRELOAD_TEST/engine-data/project-config.md"
assert_pass "v2.7.65 voice-profile-preload-gate: PASS on voice_profile_status: legacy opt-out" \
    bash "$SCRIPTS/voice-profile-preload-gate.sh" "$PRELOAD_TEST"

rm -rf "$PRELOAD_TEST" "$VOICE_TEST_DIR"

# v2.7.66 Voice Restoration Brief preflight tests. The script's job
# is to FAIL loudly on missing preconditions BEFORE emitting the
# CLASS_B_AUDIT marker; these cover each precondition + the happy path.
RESTORE_TEST=$(mktemp -d)
RESTORE_PROJ="$RESTORE_TEST/proj"
mkdir -p "$RESTORE_PROJ/engine-data/chapters" "$RESTORE_PROJ/engine-data/reports"

# Missing chapter file → FAIL
assert_fail "v2.7.66 voice-restoration-brief: FAIL on missing chapter file" \
    bash "$SCRIPTS/voice-restoration-brief.sh" "$RESTORE_PROJ" 1

# Short chapter (<100 words post-frontmatter) → FAIL
cat > "$RESTORE_PROJ/engine-data/chapters/ch01.md" <<'EOF'
---
title: Stub
---
Too short.
EOF
assert_fail "v2.7.66 voice-restoration-brief: FAIL on <100-word chapter" \
    bash "$SCRIPTS/voice-restoration-brief.sh" "$RESTORE_PROJ" 1

# Substantive chapter; profile + ledger missing → FAIL (voice-profile-preload)
python3 -c "
words = ' '.join(['restoration'] * 200)
print('---\ntitle: Real\n---\n' + words)
" > "$RESTORE_PROJ/engine-data/chapters/ch01.md"
assert_fail "v2.7.66 voice-restoration-brief: FAIL on missing voice-profile.md" \
    bash "$SCRIPTS/voice-restoration-brief.sh" "$RESTORE_PROJ" 1

# Profile complete; ledger missing → FAIL
cat > "$RESTORE_PROJ/engine-data/voice-profile.md" <<'EOF'
fp_target: 0.25
sentence_band_min: 13
sentence_band_max: 19
voice_calibration_exemplar: engine-data/chapters/ch01.md
voice_prose_description: Test register.
EOF
assert_fail "v2.7.66 voice-restoration-brief: FAIL on missing voice-metrics-ledger.md" \
    bash "$SCRIPTS/voice-restoration-brief.sh" "$RESTORE_PROJ" 1

# Profile + ledger present; ledger has no row for this chapter → FAIL
cat > "$RESTORE_PROJ/engine-data/reports/voice-metrics-ledger.md" <<'LEDGER'
| Timestamp | Chapter | Total paras | FP paras | FP ratio | Sent median | Sent mean | Sent max | FP class | Words |
|---|---|---|---|---|---|---|---|---|---|
| 2026-05-13 10:00:00 | ch07 | 12 | 0 | 0.0000 | 13 | 14.0 | 25 | WARN | 200 |
LEDGER
assert_fail "v2.7.66 voice-restoration-brief: FAIL on no ledger row for requested chapter" \
    bash "$SCRIPTS/voice-restoration-brief.sh" "$RESTORE_PROJ" 1

# Add ch01 row → PASS
cat > "$RESTORE_PROJ/engine-data/reports/voice-metrics-ledger.md" <<'LEDGER'
| Timestamp | Chapter | Total paras | FP paras | FP ratio | Sent median | Sent mean | Sent max | FP class | Words |
|---|---|---|---|---|---|---|---|---|---|
| 2026-05-13 10:00:00 | ch01 | 12 | 0 | 0.0000 | 13 | 14.0 | 25 | WARN | 200 |
LEDGER
assert_pass "v2.7.66 voice-restoration-brief: PASS preflight with all preconditions satisfied" \
    bash "$SCRIPTS/voice-restoration-brief.sh" "$RESTORE_PROJ" 1

# Output emits the CLASS_B_AUDIT marker line
if bash "$SCRIPTS/voice-restoration-brief.sh" "$RESTORE_PROJ" 1 2>/dev/null \
    | grep -q '^CLASS_B_AUDIT|voice-restoration-brief|VOICE|references/voice-restoration-brief\.md|-$'; then
    echo "PASS: v2.7.66 voice-restoration-brief: emits CLASS_B_AUDIT marker on success"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.66 voice-restoration-brief: CLASS_B_AUDIT marker missing or malformed"
    FAIL=$((FAIL + 1))
fi

# Out-of-tree exemplar path → FAIL (path-traversal guard)
mkdir -p "$RESTORE_TEST/outside"
echo "outside the project" > "$RESTORE_TEST/outside/exemplar.md"
cat > "$RESTORE_PROJ/engine-data/voice-profile.md" <<'EOF'
fp_target: 0.25
sentence_band_min: 13
sentence_band_max: 19
voice_calibration_exemplar: ../outside/exemplar.md
voice_prose_description: Test register.
EOF
assert_fail "v2.7.66 voice-restoration-brief: FAIL on exemplar path resolving outside project root" \
    bash "$SCRIPTS/voice-restoration-brief.sh" "$RESTORE_PROJ" 1

# Dispatcher restore selector — happy path
cat > "$RESTORE_PROJ/engine-data/voice-profile.md" <<'EOF'
fp_target: 0.25
sentence_band_min: 13
sentence_band_max: 19
voice_calibration_exemplar: engine-data/chapters/ch01.md
voice_prose_description: Test register.
EOF
assert_pass "v2.7.66 validate-dispatcher restore: PASS with chapter arg + preconditions ready" \
    bash "$SCRIPTS/validate-dispatcher.sh" "$RESTORE_PROJ" restore 1

# Dispatcher restore selector — chapter missing → FATAL
assert_fail "v2.7.66 validate-dispatcher restore: FATAL when chapter arg omitted" \
    bash "$SCRIPTS/validate-dispatcher.sh" "$RESTORE_PROJ" restore

rm -rf "$RESTORE_TEST"

# v2.7.67 Paragraph classifier + semantic FP ratio tests.
CLASSIFY_TEST=$(mktemp -d)
CL_PROJ="$CLASSIFY_TEST/proj"
mkdir -p "$CL_PROJ/engine-data/chapters" "$CL_PROJ/engine-data/reports/validate"

# Classifier dispatch: missing chapter → FAIL
assert_fail "v2.7.67 paragraph-classifier-dispatch: FAIL on missing chapter" \
    bash "$SCRIPTS/paragraph-classifier-dispatch.sh" "$CL_PROJ" 1

# Substantive chapter, missing voice-profile → FAIL
python3 -c "
words = ' '.join(['classified'] * 200)
print('---\ntitle: Real\n---\n' + words)
" > "$CL_PROJ/engine-data/chapters/ch01.md"
assert_fail "v2.7.67 paragraph-classifier-dispatch: FAIL on missing voice-profile" \
    bash "$SCRIPTS/paragraph-classifier-dispatch.sh" "$CL_PROJ" 1

# All preconditions ready → PASS
cat > "$CL_PROJ/engine-data/voice-profile.md" <<'EOF'
fp_target: 0.25
sentence_band_min: 13
sentence_band_max: 19
voice_calibration_exemplar: engine-data/chapters/ch01.md
voice_prose_description: Test register.
EOF
assert_pass "v2.7.67 paragraph-classifier-dispatch: PASS with all preconditions" \
    bash "$SCRIPTS/paragraph-classifier-dispatch.sh" "$CL_PROJ" 1

# Verify the CLASS_B_AUDIT marker is emitted
if bash "$SCRIPTS/paragraph-classifier-dispatch.sh" "$CL_PROJ" 1 2>/dev/null \
    | grep -q '^CLASS_B_AUDIT|paragraph-classifier|VOICE|references/paragraph-classifier\.md|-$'; then
    echo "PASS: v2.7.67 paragraph-classifier-dispatch: emits correct CLASS_B_AUDIT marker"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.67 paragraph-classifier-dispatch: marker missing or malformed"
    FAIL=$((FAIL + 1))
fi

# Dispatcher classify selector
assert_pass "v2.7.67 validate-dispatcher classify: PASS with chapter arg" \
    bash "$SCRIPTS/validate-dispatcher.sh" "$CL_PROJ" classify 1
assert_fail "v2.7.67 validate-dispatcher classify: FATAL when chapter arg omitted" \
    bash "$SCRIPTS/validate-dispatcher.sh" "$CL_PROJ" classify

# voice-metrics-audit: ABSENT status when no classifier artifact
cat > "$CL_PROJ/engine-data/chapters/ch01.md" <<'CH'
---
title: Test
---

I remember the morning. I waited. We continued.

The biography was first published in 1923 by a small press. Subsequent editions added research.

"What do you mean?" she asked.
CH
out=$(bash "$SCRIPTS/voice-metrics-audit.sh" "$CL_PROJ/engine-data/chapters/ch01.md" "$CL_PROJ" 2>&1)
if echo "$out" | grep -q "Classifier status:.*ABSENT"; then
    echo "PASS: v2.7.67 voice-metrics-audit: ABSENT status when no classifier artifact"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.67 voice-metrics-audit: expected ABSENT status, got:"
    echo "$out" | grep -i classifier
    FAIL=$((FAIL + 1))
fi

# voice-metrics-audit: FRESH status + semantic ratio when classifier present
cat > "$CL_PROJ/engine-data/reports/validate/paragraph-classifier-ch01-subagent.md" <<'ART'
## Chapter under review
- Path: engine-data/chapters/ch01.md
- Total paragraphs: 3

## Paragraph classifications
| Para # | Lines | Class | Rationale (one clause) |
|---|---|---|---|
| 1 | 5-5 | ANCHOR-NARRATIVE | author observes first-person |
| 2 | 7-8 | EXPOSITORY-THIRDPARTY | biographical detail about subject |
| 3 | 10-10 | DIALOGUE | quoted speech dominant |

## Summary
| Class | Count |
|---|---|
| ANCHOR-NARRATIVE | 1 |
| ANALYTICAL-AUTHOR | 0 |
| EXPOSITORY-THIRDPARTY | 1 |
| DIALOGUE | 1 |
| META-STRUCTURAL | 0 |
| TOTAL | 3 |

## Verdict
PASS

## One-Line Summary
"PASS: ch01 — 3 paragraphs classified"
ART
touch "$CL_PROJ/engine-data/reports/validate/paragraph-classifier-ch01-subagent.md"
out=$(bash "$SCRIPTS/voice-metrics-audit.sh" "$CL_PROJ/engine-data/chapters/ch01.md" "$CL_PROJ" 2>&1)
if echo "$out" | grep -q "Classifier status:.*FRESH" && echo "$out" | grep -q "Semantic FP ratio:"; then
    echo "PASS: v2.7.67 voice-metrics-audit: FRESH + semantic FP ratio computed"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.67 voice-metrics-audit: FRESH status / semantic ratio missing"
    FAIL=$((FAIL + 1))
fi

# voice-metrics-audit: STALE status when chapter is newer than artifact
sleep 1
touch "$CL_PROJ/engine-data/chapters/ch01.md"
out=$(bash "$SCRIPTS/voice-metrics-audit.sh" "$CL_PROJ/engine-data/chapters/ch01.md" "$CL_PROJ" 2>&1)
if echo "$out" | grep -q "Classifier status:.*STALE"; then
    echo "PASS: v2.7.67 voice-metrics-audit: STALE status when classifier older than chapter"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.67 voice-metrics-audit: expected STALE status, got:"
    echo "$out" | grep -i classifier
    FAIL=$((FAIL + 1))
fi

# voice-trend-audit: prefers semantic when ≥3 chapters have it
TREND_SEM=$(mktemp -d)
mkdir -p "$TREND_SEM/engine-data/reports"
cat > "$TREND_SEM/engine-data/reports/voice-metrics-ledger.md" <<'L'
| Timestamp | Chapter | Total paras | FP paras | FP ratio | Sent median | Sent mean | Sent max | FP class | Words | Semantic FP ratio | Classifier status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 2026-04-01 10:00:00 | ch01 | 40 | 5  | 0.1250 | 14 | 15.0 | 32 | INFO | 2500 | 0.3000 | FRESH |
| 2026-04-02 10:00:00 | ch02 | 38 | 4  | 0.1053 | 15 | 16.0 | 30 | INFO | 2600 | 0.2800 | FRESH |
| 2026-04-03 10:00:00 | ch03 | 42 | 5  | 0.1190 | 14 | 15.5 | 28 | INFO | 2700 | 0.2500 | FRESH |
| 2026-04-04 10:00:00 | ch04 | 40 | 4  | 0.1000 | 13 | 14.0 | 25 | INFO | 2400 | 0.2400 | FRESH |
| 2026-04-05 10:00:00 | ch05 | 45 | 5  | 0.1111 | 13 | 14.5 | 26 | INFO | 2500 | 0.2600 | FRESH |
L
out=$(bash "$SCRIPTS/voice-trend-audit.sh" "$TREND_SEM" 2>&1)
if echo "$out" | grep -q "Signal:.*semantic" && echo "$out" | grep -q "STATUS: PASS"; then
    echo "PASS: v2.7.67 voice-trend-audit: prefers semantic signal, PASS where syntactic alone would FAIL"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.67 voice-trend-audit: did not pick semantic signal"
    FAIL=$((FAIL + 1))
fi

# voice-trend-audit: backwards-compat with pre-v2.7.67 ledger format
TREND_LEGACY=$(mktemp -d)
mkdir -p "$TREND_LEGACY/engine-data/reports"
cat > "$TREND_LEGACY/engine-data/reports/voice-metrics-ledger.md" <<'L'
| Timestamp | Chapter | Total paras | FP paras | FP ratio | Sent median | Sent mean | Sent max | FP class | Words |
|---|---|---|---|---|---|---|---|---|---|
| 2026-04-01 10:00:00 | ch01 | 40 | 12 | 0.3000 | 14 | 15.0 | 32 | PASS | 2500 |
| 2026-04-02 10:00:00 | ch02 | 38 | 11 | 0.2895 | 15 | 16.0 | 30 | PASS | 2600 |
| 2026-04-03 10:00:00 | ch03 | 42 | 10 | 0.2381 | 14 | 15.5 | 28 | PASS | 2700 |
| 2026-04-04 10:00:00 | ch04 | 40 | 11 | 0.2750 | 13 | 14.0 | 25 | PASS | 2400 |
| 2026-04-05 10:00:00 | ch05 | 45 | 12 | 0.2667 | 13 | 14.5 | 26 | PASS | 2500 |
L
out=$(bash "$SCRIPTS/voice-trend-audit.sh" "$TREND_LEGACY" 2>&1)
if echo "$out" | grep -q "Signal:.*syntactic" && echo "$out" | grep -q "STATUS: PASS"; then
    echo "PASS: v2.7.67 voice-trend-audit: backwards-compat with v2.7.65 ledger format (syntactic signal)"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.67 voice-trend-audit: did not handle legacy ledger format correctly"
    FAIL=$((FAIL + 1))
fi

rm -rf "$CLASSIFY_TEST" "$TREND_SEM" "$TREND_LEGACY"

# v2.7.68 Phase 6 gate sweep tests. Cover-brief / marketing-pack /
# kdp-metadata / pre-export-typography / launch-readiness.
PHASE6_TEST=$(mktemp -d)
P6="$PHASE6_TEST/proj"
mkdir -p "$P6/engine-data" "$P6/marketing/cover" "$P6/manuscript" "$P6/engine-data/chapters"

# --- cover-brief-gate ---
assert_fail "v2.7.68 cover-brief-gate: FAIL on empty cover/ dir" \
    bash "$SCRIPTS/cover-brief-gate.sh" "$P6"

# Substantive brief with all required fields
cat > "$P6/marketing/cover/cover-brief.md" <<'COVER'
# Concept Name: Test Book Cover

## Visual Concept
A minimal composition centred on a single anchor object suggesting transition. Reads cleanly at thumbnail size, with negative space giving the title room to breathe.

## Color Palette
Deep navy (#0F1A2E), warm amber accent (#C4A562), neutral cream (#E8D5A0). Three-tone palette tuned for digital catalogue thumbnails plus print contrast.

## Typography
Title in classical serif suggesting craft + tradition. Author name in matched italic. Subtitle in sans-serif for contrast.

## Image Prompt
"A weathered door in a moonlit field, photorealistic, cinematic lighting, deep blue sky, warm amber doorframe glow, vertical 6:9 ratio, no text" — for Midjourney v6.

## Mood
Contemplative, anticipatory, literary. Genre signal: memoir with a hint of mystery.

## Score
Aesthetic: 8.5 | Genre signal: 9.0 | Thumbnail survival: 8.0
COVER
assert_pass "v2.7.68 cover-brief-gate: PASS on structured brief" \
    bash "$SCRIPTS/cover-brief-gate.sh" "$P6"

echo "cover_status: skip" > "$P6/engine-data/project-config.md"
rm "$P6/marketing/cover/cover-brief.md"
assert_pass "v2.7.68 cover-brief-gate: PASS on cover_status: skip opt-out" \
    bash "$SCRIPTS/cover-brief-gate.sh" "$P6"
rm "$P6/engine-data/project-config.md"

# Restore cover brief for downstream tests (must be >=800 bytes)
cat > "$P6/marketing/cover/cover-brief.md" <<'COVER'
# Concept Name: Test Book Cover

## Visual Concept
A minimal composition centred on a single anchor object suggesting transition. Reads cleanly at thumbnail size, with negative space giving the title room to breathe. Print-ready at 6x9 trim with 0.125 inch bleed on all sides.

## Color Palette
Deep navy (#0F1A2E), warm amber accent (#C4A562), neutral cream (#E8D5A0). Three-tone palette tuned for digital catalogue thumbnails plus print contrast. Background dominates; type sits in the amber tone for warmth without losing contrast.

## Typography
Title in classical serif suggesting craft + tradition. Author name in matched italic. Subtitle in sans-serif for contrast. All three rendered in cream against the navy ground.

## Image Prompt
"A weathered door in a moonlit field, photorealistic, cinematic lighting, deep blue sky, warm amber doorframe glow, vertical 6:9 ratio, no text on cover" — for Midjourney v6 or DALL-E 3. Seed: 1234567.

## Mood
Contemplative, anticipatory, literary. Genre signal: memoir with a hint of mystery. Reader should feel invited rather than alarmed.

## Score
Aesthetic: 8.5 | Genre signal: 9.0 | Thumbnail survival: 8.0 | Overall: 8.5
COVER

# --- marketing-pack-gate ---
assert_fail "v2.7.68 marketing-pack-gate: FAIL on missing marketing brief" \
    bash "$SCRIPTS/marketing-pack-gate.sh" "$P6"

# Build a complete marketing pack
echo "rendered docx content" > "$P6/marketing/marketing-brief.docx"
cat > "$P6/marketing/marketing-brief.md" <<'MKT'
# Marketing Brief

## Amazon Description
A keyword-rich product description that hooks the reader and drives conversion. Body copy follows the template.

## Back Cover Blurb
A 150-200 word back cover with a tagline that lifts off the page.

## Keywords & Categories
amazonKeywords: k1, k2, k3, k4, k5, k6, k7
bisacCategories: BIO000000, SEL000000, OCC000000

## Social Media Pack
Twitter, Instagram, Facebook, TikTok, LinkedIn posts here.

## Target Audience
Primary persona: literary memoir readers, 35-65, urban.
MKT
assert_pass "v2.7.68 marketing-pack-gate: PASS on complete pack + 5 core sections + cover dependency" \
    bash "$SCRIPTS/marketing-pack-gate.sh" "$P6"

# Strip a required section
cat > "$P6/marketing/marketing-brief.md" <<'MKT_MISSING'
# Marketing Brief
## Amazon Description
Stub.
## Back Cover Blurb
Stub.
## Keywords & Categories
Stub.
## Social Media Pack
Stub.
MKT_MISSING
assert_fail "v2.7.68 marketing-pack-gate: FAIL on missing core section (Target Audience)" \
    bash "$SCRIPTS/marketing-pack-gate.sh" "$P6"

# Restore complete pack
cat > "$P6/marketing/marketing-brief.md" <<'MKT_OK'
# Marketing Brief
## Amazon Description
Body.
## Back Cover Blurb
Body.
## Keywords & Categories
Body.
## Social Media Pack
Body.
## Target Audience
Body.
MKT_OK

# --- kdp-metadata-gate ---
assert_fail "v2.7.68 kdp-metadata-gate: FAIL on missing KDP metadata" \
    bash "$SCRIPTS/kdp-metadata-gate.sh" "$P6"

cat > "$P6/manuscript/MyBook-kdp-metadata.json" <<'KDP'
{
  "title": "My Book",
  "amazonDescription": "An engaging description that runs at least five hundred bytes to clear the minimum size threshold. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
  "keywords": ["k1", "k2", "k3", "k4", "k5", "k6", "k7"],
  "bisacCategories": ["BIO000000", "SEL000000", "OCC000000"],
  "comparableTitles": ["Comp 1", "Comp 2", "Comp 3"],
  "pricing": {"tier": "$9.99"}
}
KDP
assert_pass "v2.7.68 kdp-metadata-gate: PASS on complete KDP metadata (JSON, 7 keywords)" \
    bash "$SCRIPTS/kdp-metadata-gate.sh" "$P6"

# Reduce keywords below 7
python3 -c "
import json
with open('$P6/manuscript/MyBook-kdp-metadata.json') as f: d=json.load(f)
d['keywords'] = d['keywords'][:5]
with open('$P6/manuscript/MyBook-kdp-metadata.json','w') as f: json.dump(d,f)
"
assert_fail "v2.7.68 kdp-metadata-gate: FAIL when JSON keywords array has < 7 entries" \
    bash "$SCRIPTS/kdp-metadata-gate.sh" "$P6"

# Restore
python3 -c "
import json
with open('$P6/manuscript/MyBook-kdp-metadata.json') as f: d=json.load(f)
d['keywords'] = ['k1','k2','k3','k4','k5','k6','k7']
with open('$P6/manuscript/MyBook-kdp-metadata.json','w') as f: json.dump(d,f)
"

# --- pre-export-typography-gate ---
# Curly typography (clean fixture; v2.7.68 typography-sweep fix also
# strips YAML frontmatter so --- delimiters don't false-positive).
# Curly quotes via chr() so shellcheck doesn't flag SC1111 (unicode quote).
python3 -c "
ldq = chr(0x201C); rdq = chr(0x201D); rsq = chr(0x2019)
with open('$P6/engine-data/chapters/ch01.md','w') as f:
    f.write('---\ntitle: Clean\n---\nShe said, ' + ldq + 'I' + rsq + 'm not sure.' + rdq + ' The morning light came through the window.\n')
"
assert_pass "v2.7.68 pre-export-typography-gate: PASS on clean chapter (frontmatter stripped, curly quotes)" \
    bash "$SCRIPTS/pre-export-typography-gate.sh" "$P6"

# Add a dirty chapter (ASCII straight quotes)
python3 -c "
with open('$P6/engine-data/chapters/ch02.md','w') as f:
    f.write('# Ch 2\nShe said, \"I\\'m not sure.\" The morning light came through the window.\n')
"
assert_fail "v2.7.68 pre-export-typography-gate: FAIL on ASCII straight quotes in narrative" \
    bash "$SCRIPTS/pre-export-typography-gate.sh" "$P6"
rm "$P6/engine-data/chapters/ch02.md"

echo "typography_status: skip" > "$P6/engine-data/project-config.md"
assert_pass "v2.7.68 pre-export-typography-gate: PASS on typography_status: skip opt-out" \
    bash "$SCRIPTS/pre-export-typography-gate.sh" "$P6"
rm "$P6/engine-data/project-config.md"

# --- launch-readiness-gate ---
# Missing manuscript export → FAIL
rm -f "$P6/manuscript/MyBook.docx" 2>/dev/null
assert_fail "v2.7.68 launch-readiness-gate: FAIL when manuscript export missing" \
    bash "$SCRIPTS/launch-readiness-gate.sh" "$P6"

# Add manuscript + market-pulse → expect PASS (all constituents pass)
echo "rendered manuscript" > "$P6/manuscript/MyBook.docx"
mkdir -p "$P6/engine-data"
date > "$P6/engine-data/market-pulse.md"
assert_pass "v2.7.68 launch-readiness-gate: PASS when all 5 constituents pass" \
    bash "$SCRIPTS/launch-readiness-gate.sh" "$P6"

echo "launch_readiness_status: skip" > "$P6/engine-data/project-config.md"
# Even with broken constituents, opt-out PASSes
rm -f "$P6/manuscript/MyBook.docx"
assert_pass "v2.7.68 launch-readiness-gate: PASS on launch_readiness_status: skip opt-out" \
    bash "$SCRIPTS/launch-readiness-gate.sh" "$P6"

rm -rf "$PHASE6_TEST"

# v2.7.69 chapter-integrity-check tests. Catches NULL-byte corruption
# from awk-getline-into-heredoc and similar Bash anti-patterns.
CHINT=$(mktemp -d)

# Clean chapter PASS
cat > "$CHINT/clean.md" <<'EOF'
---
title: Clean Chapter
---

# Chapter One

She walked into the room.
EOF
assert_pass "v2.7.69 chapter-integrity-check: PASS on clean chapter" \
    bash "$SCRIPTS/chapter-integrity-check.sh" "$CHINT/clean.md"

# NULL-byte corruption FAIL
printf 'Line one\n\x00\x00\x00 corrupted\nLine three\n' > "$CHINT/null.md"
assert_fail "v2.7.69 chapter-integrity-check: FAIL on NULL bytes (the awk-getline-into-heredoc signal)" \
    bash "$SCRIPTS/chapter-integrity-check.sh" "$CHINT/null.md"

# Truncated frontmatter FAIL
printf -- '---\ntitle: Truncated\n# Body without closing ---\nMore body\n' > "$CHINT/trunc.md"
assert_fail "v2.7.69 chapter-integrity-check: FAIL on unclosed YAML frontmatter (truncation signal)" \
    bash "$SCRIPTS/chapter-integrity-check.sh" "$CHINT/trunc.md"

# Invalid UTF-8 FAIL
printf 'Body line\n\xc3\x28 invalid utf8\nMore body\n' > "$CHINT/bad-utf8.md"
assert_fail "v2.7.69 chapter-integrity-check: FAIL on invalid UTF-8" \
    bash "$SCRIPTS/chapter-integrity-check.sh" "$CHINT/bad-utf8.md"

# Zero-byte FAIL
: > "$CHINT/empty.md"
assert_fail "v2.7.69 chapter-integrity-check: FAIL on zero-byte file" \
    bash "$SCRIPTS/chapter-integrity-check.sh" "$CHINT/empty.md"

# Missing-file FAIL
assert_fail "v2.7.69 chapter-integrity-check: FAIL on missing file" \
    bash "$SCRIPTS/chapter-integrity-check.sh" "$CHINT/nonexistent.md"

rm -rf "$CHINT"

# v2.7.70 PreToolUse Bash anti-pattern hook tests. Drives the hook
# via stdin JSON payloads (the same shape Claude Code passes when
# the hook fires for a Bash invocation) and verifies exit codes.
HOOK="$SCRIPTS/pre-bash-anti-pattern-check.sh"

# Inline assertion that pipes stdin to a command and checks exit code.
assert_hook_exit() {
    local name="$1" expected_exit="$2" payload="$3"
    local actual_exit
    set +e
    echo "$payload" | bash "$HOOK" >/dev/null 2>&1
    actual_exit=$?
    set -e
    if [ "$actual_exit" -eq "$expected_exit" ]; then
        echo "PASS: $name"
        PASS=$((PASS + 1))
    else
        echo "FAIL: $name (expected exit $expected_exit, got $actual_exit)"
        FAIL=$((FAIL + 1))
    fi
}

assert_hook_exit "v2.7.70 bash-anti-pattern hook: PASS (exit 0) on safe ls command" 0 \
    '{"tool_input":{"command":"ls -la /tmp"}}'

assert_hook_exit "v2.7.70 bash-anti-pattern hook: PASS on awk-only (no getline, no heredoc)" 0 \
    '{"tool_input":{"command":"awk \"{print}\" file.md"}}'

assert_hook_exit "v2.7.70 bash-anti-pattern hook: PASS on awk+getline without heredoc (legitimate)" 0 \
    '{"tool_input":{"command":"awk \"NR==1{getline; print}\" file.md"}}'

assert_hook_exit "v2.7.70 bash-anti-pattern hook: PASS on heredoc without awk-getline (legitimate)" 0 \
    '{"tool_input":{"command":"cat > /tmp/out << EOF\nhello\nEOF"}}'

assert_hook_exit "v2.7.73 bash-anti-pattern hook: ADVISE (exit 0; rescoped from BLOCK at v2.7.73) on awk+getline+heredoc" 0 \
    '{"tool_input":{"command":"awk \"/pat/{getline; print}\" in.md > /tmp/out << \"EOF\"\\npayload\\nEOF"}}'

assert_hook_exit "v2.7.70 bash-anti-pattern hook: fail-open (exit 0) on empty payload" 0 \
    ''

assert_hook_exit "v2.7.70 bash-anti-pattern hook: fail-open (exit 0) on malformed JSON" 0 \
    'not-json-at-all'

assert_hook_exit "v2.7.70 bash-anti-pattern hook: fail-open (exit 0) on missing tool_input.command" 0 \
    '{"tool_input":{}}'

# v2.7.71 observability tests. Verify every invocation appends a single
# line to the hook log with the expected shape (timestamp + version +
# decision + reason + command). This is the diagnostic infrastructure
# that lets us identify which command pattern slipped past the matcher
# when a corruption is reported by the user.
HOOK_LOG=$(mktemp)
# Each invocation may exit 2 (BLOCK), which would terminate the script
# under set -e — `|| true` neutralises that.
IDEORIX_HOOK_LOG="$HOOK_LOG" bash -c "echo '{\"tool_input\":{\"command\":\"ls -la\"}}' | bash '$HOOK' >/dev/null 2>&1" || true
IDEORIX_HOOK_LOG="$HOOK_LOG" bash -c "echo '{\"tool_input\":{\"command\":\"awk \\\"/p/{getline; print}\\\" in > out << EOF\\\\npayload\\\\nEOF\"}}' | bash '$HOOK' >/dev/null 2>&1" || true
IDEORIX_HOOK_LOG="$HOOK_LOG" bash -c "echo '' | bash '$HOOK' >/dev/null 2>&1" || true

# Log should have 3 lines (one per invocation).
LOG_LINES=$(wc -l < "$HOOK_LOG")
if [ "$LOG_LINES" -eq 3 ]; then
    echo "PASS: v2.7.71 hook observability: log accumulates one line per invocation (got $LOG_LINES lines)"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.71 hook observability: expected 3 log lines, got $LOG_LINES"
    FAIL=$((FAIL + 1))
fi

# Each log line should match: ISO timestamp | version | decision | reason | command
if grep -qE '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z \| v2\.7\.[0-9]+ \| PASS \| awk=0 getline=0 heredoc=0 splicer=0 \| ls -la$' "$HOOK_LOG"; then
    echo "PASS: v2.7.71 hook observability: PASS line has correct shape (timestamp | version | PASS | signal flags | command)"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.71 hook observability: PASS line shape mismatch"
    echo "  log content: $(cat "$HOOK_LOG")"
    FAIL=$((FAIL + 1))
fi

# ADVISE line should record awk=1 getline=1 heredoc=1 (rescoped from BLOCK at v2.7.73)
if grep -qE '\| ADVISE \| awk=1 getline=1 heredoc=1 splicer=[01] \|' "$HOOK_LOG"; then
    echo "PASS: v2.7.73 hook observability: ADVISE line records all three signals matched"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.73 hook observability: ADVISE line missing signal flags"
    echo "  log content: $(cat "$HOOK_LOG")"
    FAIL=$((FAIL + 1))
fi

# empty-payload reason should be recorded
if grep -qE '\| PASS \| empty-payload \|' "$HOOK_LOG"; then
    echo "PASS: v2.7.71 hook observability: empty-payload reason recorded"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.71 hook observability: empty-payload reason missing"
    FAIL=$((FAIL + 1))
fi

# v2.7.71 regression test: user's actual failing command (from session
# transcript captured 2026-05-14). This is the awk-content-splicer
# pattern that slipped past v2.7.70's matcher. The broadened v2.7.71
# matcher must catch it.
USER_FAILING_CMD_PAYLOAD=$(python3 -c "
import json
cmd = '''awk -v expfile=\"\$TMPDIR/expansion.md\" 'function emit_file(fname,   line) { while ((getline line < fname) > 0) print line; close(fname) } { print } /anchor/ { emit_file(expfile) }' \$CHAPTER > \"\${CHAPTER}.tmp1.\$\$\"'''
print(json.dumps({'tool_input': {'command': cmd}}))
")
assert_hook_exit "v2.7.73 hook: ADVISE (exit 0; rescoped from BLOCK at v2.7.73) on user's actual failing command" 0 \
    "$USER_FAILING_CMD_PAYLOAD"

# v2.7.71 regression: legitimate awk-getline WITHOUT external file read still passes
assert_hook_exit "v2.7.71 hook: PASS on awk-getline without file redirect (legitimate)" 0 \
    '{"tool_input":{"command":"awk \"{ getline next_line; print $0, next_line }\" file.md"}}'

# v2.7.71 chapter-integrity-check line-count collapse detection
COLLAPSE_TEST=$(mktemp -d)
python3 -c "print('x' * 17000, end='')" > "$COLLAPSE_TEST/collapsed.md"
assert_fail "v2.7.71 chapter-integrity-check: FAIL on line-count collapse (17KB, <5 lines)" \
    bash "$SCRIPTS/chapter-integrity-check.sh" "$COLLAPSE_TEST/collapsed.md"

python3 -c "
lines = ['# Chapter\n', '\n']
for i in range(100):
    lines.append('Paragraph %d with some content to add bytes.\n' % i)
import sys; sys.stdout.write(''.join(lines))
" > "$COLLAPSE_TEST/normal.md"
assert_pass "v2.7.71 chapter-integrity-check: PASS on legitimate large multi-line chapter" \
    bash "$SCRIPTS/chapter-integrity-check.sh" "$COLLAPSE_TEST/normal.md"
rm -rf "$COLLAPSE_TEST"

rm -f "$HOOK_LOG"

# ============================================================
# v2.7.72 PostToolUse chapter integrity hook tests. Drives the
# hook via stdin JSON payloads (the same shape Claude Code passes
# when the hook fires for a Write|Edit|MultiEdit on a file) and
# verifies exit codes, fail-open behaviour, and observability.
# ============================================================
POST_HOOK="$SCRIPTS/post-engine-data-write-hook.sh"

assert_post_hook_exit() {
    local name="$1" expected_exit="$2" payload="$3"
    local actual_exit
    set +e
    echo "$payload" | bash "$POST_HOOK" >/dev/null 2>&1
    actual_exit=$?
    set -e
    if [ "$actual_exit" -eq "$expected_exit" ]; then
        echo "PASS: $name"
        PASS=$((PASS + 1))
    else
        echo "FAIL: $name (expected exit $expected_exit, got $actual_exit)"
        FAIL=$((FAIL + 1))
    fi
}

assert_post_hook_exit "v2.7.73 post-write hook: SKIP (exit 0) on non-engine-data path" 0 \
    '{"tool_input":{"file_path":"/tmp/random.md","content":"hi"}}'

assert_post_hook_exit "v2.7.73 post-write hook: fail-open (exit 0) on empty payload" 0 ''

assert_post_hook_exit "v2.7.73 post-write hook: fail-open (exit 0) on malformed JSON" 0 \
    'not-json-at-all'

assert_post_hook_exit "v2.7.73 post-write hook: fail-open (exit 0) on missing file_path" 0 \
    '{"tool_input":{"content":"hi"}}'

POST_HOOK_TMP=$(mktemp -d)
mkdir -p "$POST_HOOK_TMP/project/engine-data/chapters"
CLEAN_CHAPTER="$POST_HOOK_TMP/project/engine-data/chapters/ch01.md"
cat > "$CLEAN_CHAPTER" <<'CLEAN_EOF'
---
chapter: 1
---

# Chapter 1

Multi-line content with enough newlines.

Plenty of newlines.

So the line-count check is fine.
CLEAN_EOF

CLEAN_PAYLOAD=$(python3 -c "import json; print(json.dumps({'tool_input': {'file_path': '$CLEAN_CHAPTER'}}))")
assert_post_hook_exit "v2.7.73 post-write hook: PASS (exit 0) on clean chapter file" 0 \
    "$CLEAN_PAYLOAD"

CORRUPT_CHAPTER="$POST_HOOK_TMP/project/engine-data/chapters/ch02.md"
printf '%s\x00%s\n' "line one" "still corrupted" > "$CORRUPT_CHAPTER"
CORRUPT_PAYLOAD=$(python3 -c "import json; print(json.dumps({'tool_input': {'file_path': '$CORRUPT_CHAPTER'}}))")
assert_post_hook_exit "v2.7.73 post-write hook: FAIL (exit 2) on chapter with NULL bytes" 2 \
    "$CORRUPT_PAYLOAD"

# v2.7.73: broadened scope catches engine-data files at the root level
# (not just engine-data/chapters/). pipeline-checkpoint.md was the
# corruption victim that motivated the broadening.
CHECKPOINT="$POST_HOOK_TMP/project/engine-data/pipeline-checkpoint.md"
cat > "$CHECKPOINT" <<'CHECKPOINT_EOF'
# Pipeline checkpoint

| Ch | Title | Status |
|----|-------|--------|
| 1  | Test  | done   |
| 2  | Test  | done   |
| 3  | Test  | done   |
| 4  | Test  | done   |
| 5  | Test  | done   |
CHECKPOINT_EOF

CHECKPOINT_PAYLOAD=$(python3 -c "import json; print(json.dumps({'tool_input': {'file_path': '$CHECKPOINT'}}))")
assert_post_hook_exit "v2.7.73 post-write hook: PASS (exit 0) on clean engine-data root file (pipeline-checkpoint.md)" 0 \
    "$CHECKPOINT_PAYLOAD"

# v2.7.73: broadened scope catches corruption in non-chapter engine-data
# files. Simulate the 12,588-byte NULL signature from the actual v2.7.72
# pipeline-checkpoint.md corruption incident.
CORRUPT_CHECKPOINT="$POST_HOOK_TMP/project/engine-data/pipeline-checkpoint-corrupted.md"
python3 -c "import sys; sys.stdout.buffer.write(b'\\x00' * 12588)" > "$CORRUPT_CHECKPOINT"
CORRUPT_CHECKPOINT_PAYLOAD=$(python3 -c "import json; print(json.dumps({'tool_input': {'file_path': '$CORRUPT_CHECKPOINT'}}))")
assert_post_hook_exit "v2.7.73 post-write hook: FAIL (exit 2) on NULL-filled engine-data root file (12,588 NULL bytes — actual v2.7.72 corruption signature)" 2 \
    "$CORRUPT_CHECKPOINT_PAYLOAD"

rm -rf "$POST_HOOK_TMP"

# Observability — log shape + decision coverage
POST_HOOK_LOG=$(mktemp)
POST_HOOK_TMP2=$(mktemp -d)
mkdir -p "$POST_HOOK_TMP2/engine-data/chapters"
CLEAN2="$POST_HOOK_TMP2/engine-data/chapters/ch01.md"
cat > "$CLEAN2" <<'CLEAN2_EOF'
---
chapter: 1
---

Test content with enough newlines.
Line two.
Line three.
Line four.
Line five.
CLEAN2_EOF

CLEAN_PAYLOAD2=$(python3 -c "import json; print(json.dumps({'tool_input': {'file_path': '$CLEAN2'}}))")
IDEORIX_CHAPTER_HOOK_LOG="$POST_HOOK_LOG" bash -c "echo '$CLEAN_PAYLOAD2' | bash '$POST_HOOK' >/dev/null 2>&1" || true
IDEORIX_CHAPTER_HOOK_LOG="$POST_HOOK_LOG" bash -c "echo '{\"tool_input\":{\"file_path\":\"/tmp/random.txt\"}}' | bash '$POST_HOOK' >/dev/null 2>&1" || true
IDEORIX_CHAPTER_HOOK_LOG="$POST_HOOK_LOG" bash -c "echo '' | bash '$POST_HOOK' >/dev/null 2>&1" || true

LOG_LINES=$(wc -l < "$POST_HOOK_LOG")
if [ "$LOG_LINES" -eq 3 ]; then
    echo "PASS: v2.7.73 post-write hook observability: log accumulates one line per invocation (got $LOG_LINES lines)"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.73 post-write hook observability: expected 3 log lines, got $LOG_LINES"
    FAIL=$((FAIL + 1))
fi

if grep -qE '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z \| v2\.7\.73 \| PASS \| integrity-clean \|' "$POST_HOOK_LOG"; then
    echo "PASS: v2.7.73 post-write hook observability: PASS line has correct shape"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.73 post-write hook observability: PASS line shape mismatch"
    echo "  log content: $(cat "$POST_HOOK_LOG")"
    FAIL=$((FAIL + 1))
fi

if grep -qE '\| SKIP \| not-engine-data-md \|' "$POST_HOOK_LOG"; then
    echo "PASS: v2.7.73 post-write hook observability: SKIP decision recorded for non-engine-data path"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.73 post-write hook observability: SKIP decision missing"
    FAIL=$((FAIL + 1))
fi

if grep -qE '\| NOOP \| empty-payload \|' "$POST_HOOK_LOG"; then
    echo "PASS: v2.7.73 post-write hook observability: NOOP decision recorded for empty payload"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.73 post-write hook observability: NOOP empty-payload decision missing"
    FAIL=$((FAIL + 1))
fi

rm -f "$POST_HOOK_LOG"
rm -rf "$POST_HOOK_TMP2"

# ============================================================
# v2.7.74 corrections-promotion-scan.sh tests
# ============================================================
PROMOTION_SCAN="$SCRIPTS/corrections-promotion-scan.sh"

EMPTY_REG=$(mktemp)
OUTPUT=$(bash "$PROMOTION_SCAN" "$EMPTY_REG" 2>&1)
EXIT=$?
if [ "$EXIT" -eq 0 ] && echo "$OUTPUT" | grep -q "no promotion candidates"; then
    echo "PASS: v2.7.74 corrections-promotion-scan: empty register reports no candidates"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.74 corrections-promotion-scan: empty register handling broken"
    FAIL=$((FAIL + 1))
fi
rm -f "$EMPTY_REG"

set +e
bash "$PROMOTION_SCAN" "/nonexistent/path/to/register.md" >/dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 2 ]; then
    echo "PASS: v2.7.74 corrections-promotion-scan: missing file exits 2"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.74 corrections-promotion-scan: missing file should exit 2, got $EXIT"
    FAIL=$((FAIL + 1))
fi

SINGLETON_REG=$(mktemp)
cat > "$SINGLETON_REG" <<'SINGLETON_EOF'
# Author Corrections — Test

## 2026-05-01 — Session 1
- category: entity
- field: name
- from: "Bob"
- to: "Robert"
- context: ch1 first mention
- canon-status: not-yet-promoted
SINGLETON_EOF
OUTPUT=$(bash "$PROMOTION_SCAN" "$SINGLETON_REG" 2>&1)
if echo "$OUTPUT" | grep -q "no promotion candidates"; then
    echo "PASS: v2.7.74 corrections-promotion-scan: singleton (1 occurrence) not surfaced"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.74 corrections-promotion-scan: singleton incorrectly surfaced"
    echo "  output: $OUTPUT"
    FAIL=$((FAIL + 1))
fi
rm -f "$SINGLETON_REG"

THREE_REG=$(mktemp)
cat > "$THREE_REG" <<'THREE_EOF'
# Author Corrections — Test

## 2026-05-01 — Session 1
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch7
- canon-status: not-yet-promoted

## 2026-05-02 — Session 2
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch8
- canon-status: not-yet-promoted

## 2026-05-03 — Session 3
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch10
- canon-status: not-yet-promoted
THREE_EOF
OUTPUT=$(bash "$PROMOTION_SCAN" "$THREE_REG" 2>&1)
if echo "$OUTPUT" | grep -q "1 promotion candidate" \
   && echo "$OUTPUT" | grep -q '"Mara" → "Mira"' \
   && echo "$OUTPUT" | grep -q "engine-data/entity-canon.md"; then
    echo "PASS: v2.7.74 corrections-promotion-scan: 3 same-group entries surface 1 candidate with correct target canon"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.74 corrections-promotion-scan: 3-entry group not surfaced correctly"
    echo "  output: $OUTPUT"
    FAIL=$((FAIL + 1))
fi
rm -f "$THREE_REG"

MIXED_REG=$(mktemp)
cat > "$MIXED_REG" <<'MIXED_EOF'
# Author Corrections — Test

## 2026-05-01 — Session 1
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch7
- canon-status: not-yet-promoted

## 2026-05-02 — Session 2
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch8
- canon-status: not-yet-promoted

## 2026-05-03 — Session 3
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch10
- canon-status: promoted
MIXED_EOF
OUTPUT=$(bash "$PROMOTION_SCAN" "$MIXED_REG" 2>&1)
if echo "$OUTPUT" | grep -q "no promotion candidates"; then
    echo "PASS: v2.7.74 corrections-promotion-scan: promoted entries excluded from grouping"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.74 corrections-promotion-scan: promoted entries incorrectly grouped"
    echo "  output: $OUTPUT"
    FAIL=$((FAIL + 1))
fi
rm -f "$MIXED_REG"

MULTI_REG=$(mktemp)
cat > "$MULTI_REG" <<'MULTI_EOF'
# Author Corrections — Test

## 2026-05-01 — Session 1
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch1
- canon-status: not-yet-promoted

## 2026-05-02 — Session 2
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch2
- canon-status: not-yet-promoted

## 2026-05-03 — Session 3
- category: entity
- field: name
- from: "Mara"
- to: "Mira"
- context: ch3
- canon-status: not-yet-promoted

## 2026-05-04 — Session 4
- category: preference
- field: avoid-word
- from: "tapestry"
- to: "(avoid)"
- context: ch4
- canon-status: not-yet-promoted

## 2026-05-05 — Session 5
- category: preference
- field: avoid-word
- from: "tapestry"
- to: "(avoid)"
- context: ch5
- canon-status: not-yet-promoted

## 2026-05-06 — Session 6
- category: preference
- field: avoid-word
- from: "tapestry"
- to: "(avoid)"
- context: ch6
- canon-status: not-yet-promoted
MULTI_EOF
OUTPUT=$(bash "$PROMOTION_SCAN" "$MULTI_REG" 2>&1)
if echo "$OUTPUT" | grep -q "2 promotion candidate"; then
    echo "PASS: v2.7.74 corrections-promotion-scan: 2 qualifying groups reported as 2 candidates"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.74 corrections-promotion-scan: expected 2 candidates"
    echo "  output: $OUTPUT"
    FAIL=$((FAIL + 1))
fi
rm -f "$MULTI_REG"

# ============================================================
# v2.7.75 consecutive-opener-scan.sh tests
# ============================================================
OPENER_SCAN="$SCRIPTS/consecutive-opener-scan.sh"

CLEAN_F=$(mktemp --suffix=.md)
cat > "$CLEAN_F" <<'CLEAN_EOF'
# Chapter

She walked into the room. The chair was empty. Outside, wind moved
through the trees and Mira hesitated. The kettle whistled.

Then the door slammed and the silence felt different.
CLEAN_EOF
OUTPUT=$(bash "$OPENER_SCAN" "$CLEAN_F" 2>&1)
EXIT=$?
if [ "$EXIT" -eq 0 ] && echo "$OUTPUT" | grep -q "PASS"; then
    echo "PASS: v2.7.75 consecutive-opener-scan: clean prose passes"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.75 consecutive-opener-scan: clean prose should pass"
    FAIL=$((FAIL + 1))
fi
rm -f "$CLEAN_F"

TWO_F=$(mktemp --suffix=.md)
cat > "$TWO_F" <<'TWO_EOF'
# Chapter

She looked at the door. She looked at the window. The clock chimed.
The wind moved through the room.
TWO_EOF
OUTPUT=$(bash "$OPENER_SCAN" "$TWO_F" 2>&1)
if echo "$OUTPUT" | grep -q "PASS"; then
    echo "PASS: v2.7.75 consecutive-opener-scan: 2 same-openers pass (rhythm acceptable)"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.75 consecutive-opener-scan: 2 same-openers incorrectly flagged"
    FAIL=$((FAIL + 1))
fi
rm -f "$TWO_F"

THREE_F=$(mktemp --suffix=.md)
cat > "$THREE_F" <<'THREE_EOF'
# Chapter

She looked at the door. She looked at the window. She looked at the clock.
The room had not changed.
THREE_EOF
OUTPUT=$(bash "$OPENER_SCAN" "$THREE_F" 2>&1)
EXIT=$?
if [ "$EXIT" -eq 0 ] \
   && echo "$OUTPUT" | grep -q "STATUS: WARN" \
   && echo "$OUTPUT" | grep -q "consecutive sentences starting with 'she'"; then
    echo "PASS: v2.7.75 consecutive-opener-scan: 3 same-openers emit WARN + cluster details"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.75 consecutive-opener-scan: 3 same-openers should WARN"
    echo "  output: $OUTPUT"
    FAIL=$((FAIL + 1))
fi
rm -f "$THREE_F"

FOUR_F=$(mktemp --suffix=.md)
cat > "$FOUR_F" <<'FOUR_EOF'
# Chapter

The bell rang. The dog barked. The cat hissed. The kettle screamed.
Mira hesitated.
FOUR_EOF
OUTPUT=$(bash "$OPENER_SCAN" "$FOUR_F" 2>&1)
if echo "$OUTPUT" | grep -q "STATUS: WARN" \
   && echo "$OUTPUT" | grep -q "4 consecutive sentences starting with 'the'"; then
    echo "PASS: v2.7.75 consecutive-opener-scan: 4 same-openers reported with correct count"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.75 consecutive-opener-scan: 4-cluster count incorrect"
    echo "  output: $OUTPUT"
    FAIL=$((FAIL + 1))
fi
rm -f "$FOUR_F"

set +e
bash "$OPENER_SCAN" "/nonexistent/chapter.md" >/dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 2 ]; then
    echo "PASS: v2.7.75 consecutive-opener-scan: missing file exits 2"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.75 consecutive-opener-scan: missing file should exit 2, got $EXIT"
    FAIL=$((FAIL + 1))
fi

PHRASE_F=$(mktemp --suffix=.md)
cat > "$PHRASE_F" <<'PHRASE_EOF'
# Chapter

She looked at the door. She walked past the chair. She glanced upward.
The clock chimed.
PHRASE_EOF
OUTPUT=$(bash "$OPENER_SCAN" "$PHRASE_F" 2>&1)
if echo "$OUTPUT" | grep -q "STATUS: WARN"; then
    echo "PASS: v2.7.75 consecutive-opener-scan: opener-words=1 catches single-word repetition"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.75 consecutive-opener-scan: opener-words=1 missed 'she' x 3"
    FAIL=$((FAIL + 1))
fi
OUTPUT=$(bash "$OPENER_SCAN" "$PHRASE_F" --opener-words 2 2>&1)
if echo "$OUTPUT" | grep -q "PASS"; then
    echo "PASS: v2.7.75 consecutive-opener-scan: opener-words=2 distinguishes verbs"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.75 consecutive-opener-scan: opener-words=2 should not flag varied verbs"
    FAIL=$((FAIL + 1))
fi
rm -f "$PHRASE_F"

# ============================================================
# v2.7.76 markdown-to-docx-render.sh tests
# ============================================================
DOCX_RENDER="$SCRIPTS/markdown-to-docx-render.sh"

set +e
bash "$DOCX_RENDER" >/dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 1 ]; then
    echo "PASS: v2.7.76 markdown-to-docx-render: missing arg exits 1"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.76 markdown-to-docx-render: missing arg should exit 1, got $EXIT"
    FAIL=$((FAIL + 1))
fi

set +e
bash "$DOCX_RENDER" "/nonexistent/project/path" >/dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 1 ]; then
    echo "PASS: v2.7.76 markdown-to-docx-render: nonexistent project exits 1"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.76 markdown-to-docx-render: nonexistent project should exit 1, got $EXIT"
    FAIL=$((FAIL + 1))
fi

RENDER_TMP=$(mktemp -d)
mkdir "$RENDER_TMP/engine-data"
set +e
bash "$DOCX_RENDER" "$RENDER_TMP" >/dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 2 ]; then
    echo "PASS: v2.7.76 markdown-to-docx-render: missing chapters directory exits 2"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.76 markdown-to-docx-render: missing chapters dir should exit 2, got $EXIT"
    FAIL=$((FAIL + 1))
fi

mkdir "$RENDER_TMP/engine-data/chapters"
set +e
bash "$DOCX_RENDER" "$RENDER_TMP" >/dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 2 ]; then
    echo "PASS: v2.7.76 markdown-to-docx-render: empty chapters dir exits 2 (no chapters)"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.76 markdown-to-docx-render: empty chapters dir should exit 2, got $EXIT"
    FAIL=$((FAIL + 1))
fi

cat > "$RENDER_TMP/engine-data/chapters/ch01.md" <<'CHAPTER_EOF'
---
chapter: 1
---

# Chapter 1: The SL*18

The Marantz **SL*18** released in 1979. A literal asterisk in a
model number — the input that broke v2.7.x ad-hoc renderers — must
render without infinite-looping. *Italics work*. **Bold works**.

* * *

Em-dashes — like this one — should also pass through.
CHAPTER_EOF

if command -v pandoc >/dev/null 2>&1; then
    set +e
    bash "$DOCX_RENDER" "$RENDER_TMP" >/dev/null 2>&1
    EXIT=$?
    set -e
    if [ "$EXIT" -eq 0 ] && [ -f "$RENDER_TMP/engine-data/manuscript.docx" ]; then
        echo "PASS: v2.7.76 markdown-to-docx-render: end-to-end render produces valid DOCX"
        PASS=$((PASS + 1))
    else
        echo "FAIL: v2.7.76 markdown-to-docx-render: end-to-end render failed (exit $EXIT)"
        FAIL=$((FAIL + 1))
    fi

    if [ -f "$RENDER_TMP/engine-data/manuscript.docx" ] && \
       unzip -p "$RENDER_TMP/engine-data/manuscript.docx" word/document.xml 2>/dev/null | \
       grep -q "SL\*18"; then
        echo "PASS: v2.7.76 markdown-to-docx-render: literal asterisk 'SL*18' preserved in output"
        PASS=$((PASS + 1))
    else
        echo "FAIL: v2.7.76 markdown-to-docx-render: literal asterisk not preserved"
        FAIL=$((FAIL + 1))
    fi
else
    set +e
    OUTPUT=$(bash "$DOCX_RENDER" "$RENDER_TMP" 2>&1)
    EXIT=$?
    set -e
    if [ "$EXIT" -eq 3 ] && echo "$OUTPUT" | grep -q "pandoc not installed"; then
        echo "PASS: v2.7.76 markdown-to-docx-render: missing pandoc exits 3 with install hint"
        PASS=$((PASS + 1))
    else
        echo "FAIL: v2.7.76 markdown-to-docx-render: missing pandoc behaviour wrong (exit $EXIT)"
        FAIL=$((FAIL + 1))
    fi
    echo "SKIP: v2.7.76 markdown-to-docx-render: end-to-end + literal-asterisk-preservation (pandoc not present in this environment)"
fi

rm -rf "$RENDER_TMP"

# ============================================================
# v2.7.77 source-canon-grounding-gate.sh tests
# ============================================================
GROUNDING_GATE="$SCRIPTS/source-canon-grounding-gate.sh"

set +e
bash "$GROUNDING_GATE" >/dev/null 2>&1
EXIT=$?
set -e
if [ "$EXIT" -eq 2 ]; then
    echo "PASS: v2.7.77 source-canon-grounding-gate: missing arg exits 2"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.77 source-canon-grounding-gate: missing arg should exit 2, got $EXIT"
    FAIL=$((FAIL + 1))
fi

GROUNDING_TMP=$(mktemp -d)
mkdir -p "$GROUNDING_TMP/engine-data/reports"

OUTPUT=$(bash "$GROUNDING_GATE" "$GROUNDING_TMP" 2>&1)
EXIT=$?
if [ "$EXIT" -eq 0 ] && echo "$OUTPUT" | grep -q "SKIPPED"; then
    echo "PASS: v2.7.77 source-canon-grounding-gate: missing project-config skips (opt-in default off)"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.77 source-canon-grounding-gate: missing project-config should skip"
    FAIL=$((FAIL + 1))
fi

cat > "$GROUNDING_TMP/engine-data/project-config.md" <<'CFG_EOF'
project_title: Test Project
CFG_EOF
OUTPUT=$(bash "$GROUNDING_GATE" "$GROUNDING_TMP" 2>&1)
EXIT=$?
if [ "$EXIT" -eq 0 ] && echo "$OUTPUT" | grep -q "SKIPPED"; then
    echo "PASS: v2.7.77 source-canon-grounding-gate: project without opt-in flag skips"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.77 source-canon-grounding-gate: no opt-in should skip"
    FAIL=$((FAIL + 1))
fi

# v2.7.78: explicit legacy flag -> SKIPPED with legacy diagnostic
cat > "$GROUNDING_TMP/engine-data/project-config.md" <<'CFG_EOF'
project_title: Test Project
source_canon_grounding: legacy
CFG_EOF
OUTPUT=$(bash "$GROUNDING_GATE" "$GROUNDING_TMP" 2>&1)
EXIT=$?
if [ "$EXIT" -eq 0 ] && echo "$OUTPUT" | grep -qE "legacy.*opt-out honored"; then
    echo "PASS: v2.7.78 source-canon-grounding-gate: explicit 'legacy' flag skips with legacy diagnostic"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.78 source-canon-grounding-gate: legacy flag should produce legacy diagnostic"
    echo "  output: $OUTPUT"
    FAIL=$((FAIL + 1))
fi

# Reset for the subsequent tests that expect 'enable' to be in config
cat > "$GROUNDING_TMP/engine-data/project-config.md" <<'CFG_EOF'
project_title: Test Project
CFG_EOF
echo "source_canon_grounding: enable" >> "$GROUNDING_TMP/engine-data/project-config.md"
set +e
OUTPUT=$(bash "$GROUNDING_GATE" "$GROUNDING_TMP" 2>&1)
EXIT=$?
set -e
if [ "$EXIT" -eq 1 ] && echo "$OUTPUT" | grep -q "artifact missing"; then
    echo "PASS: v2.7.77 source-canon-grounding-gate: opted in without artifact fails with diagnostic"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.77 source-canon-grounding-gate: opted-in/no-artifact behaviour wrong"
    FAIL=$((FAIL + 1))
fi

cat > "$GROUNDING_TMP/engine-data/world-rules.md" <<'WR_EOF'
# World Rules

The Convocation meets every seventh year in the lower chambers.
Iron does not conduct ward-magic in the third age.
Birthing-rites for daughters of the eastern houses are conducted by the Sisters of Veil.
WR_EOF
GROUNDING_SHA=$(sha256sum "$GROUNDING_TMP/engine-data/world-rules.md" | awk '{print $1}')
cat > "$GROUNDING_TMP/engine-data/reports/source-canon-grounding.yaml" <<EOF
generated_at: 2026-05-17T12:00:00Z
sources:
  - file: engine-data/world-rules.md
    sha256: $GROUNDING_SHA
    word_count: 41
    verbatim_samples:
      - "The Convocation meets every seventh year in the lower chambers."
      - "Iron does not conduct ward-magic in the third age."
      - "Birthing-rites for daughters of the eastern houses"
EOF

OUTPUT=$(bash "$GROUNDING_GATE" "$GROUNDING_TMP" 2>&1)
EXIT=$?
if [ "$EXIT" -eq 0 ] && echo "$OUTPUT" | grep -q "PASS"; then
    echo "PASS: v2.7.77 source-canon-grounding-gate: valid artifact with matching samples passes"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.77 source-canon-grounding-gate: valid artifact should pass"
    echo "  output: $OUTPUT"
    FAIL=$((FAIL + 1))
fi

cat > "$GROUNDING_TMP/engine-data/reports/source-canon-grounding.yaml" <<EOF
generated_at: 2026-05-17T12:00:00Z
sources:
  - file: engine-data/world-rules.md
    sha256: $GROUNDING_SHA
    word_count: 41
    verbatim_samples:
      - "The Convocation meets every seventh year in the lower chambers."
      - "Iron does not conduct ward-magic in the third age."
      - "Dragons inhabit the northern mountains and breathe purple fire."
EOF
set +e
OUTPUT=$(bash "$GROUNDING_GATE" "$GROUNDING_TMP" 2>&1)
EXIT=$?
set -e
if [ "$EXIT" -eq 1 ] && echo "$OUTPUT" | grep -q "FABRICATION SIGNAL"; then
    echo "PASS: v2.7.77 source-canon-grounding-gate: fabricated sample triggers FABRICATION SIGNAL diagnostic"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.77 source-canon-grounding-gate: fabrication should be caught"
    FAIL=$((FAIL + 1))
fi

cat > "$GROUNDING_TMP/engine-data/reports/source-canon-grounding.yaml" <<EOF
generated_at: 2026-05-17T12:00:00Z
sources:
  - file: engine-data/world-rules.md
    sha256: $GROUNDING_SHA
    word_count: 41
    verbatim_samples:
      - "The Convocation meets every seventh year in the lower chambers."
      - "Iron does not conduct ward-magic in the third age."
      - "Birthing-rites for daughters of the eastern houses"
EOF
echo "A new rule appended after grounding." >> "$GROUNDING_TMP/engine-data/world-rules.md"
set +e
OUTPUT=$(bash "$GROUNDING_GATE" "$GROUNDING_TMP" 2>&1)
EXIT=$?
set -e
if [ "$EXIT" -eq 1 ] && echo "$OUTPUT" | grep -q "sha256 mismatch"; then
    echo "PASS: v2.7.77 source-canon-grounding-gate: stale sha256 triggers mismatch diagnostic"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.77 source-canon-grounding-gate: stale sha256 should fail"
    FAIL=$((FAIL + 1))
fi

cat > "$GROUNDING_TMP/engine-data/world-rules.md" <<'WR_EOF'
# World Rules

The Convocation meets every seventh year in the lower chambers.
Iron does not conduct ward-magic in the third age.
Birthing-rites for daughters of the eastern houses are conducted by the Sisters of Veil.
WR_EOF
GROUNDING_SHA=$(sha256sum "$GROUNDING_TMP/engine-data/world-rules.md" | awk '{print $1}')
cat > "$GROUNDING_TMP/engine-data/reports/source-canon-grounding.yaml" <<EOF
generated_at: 2026-05-17T12:00:00Z
sources:
  - file: engine-data/world-rules.md
    sha256: $GROUNDING_SHA
    word_count: 41
    verbatim_samples:
      - "The Convocation meets every seventh year in the lower chambers."
      - "Iron does not conduct ward-magic in the third age."
EOF
set +e
OUTPUT=$(bash "$GROUNDING_GATE" "$GROUNDING_TMP" 2>&1)
EXIT=$?
set -e
if [ "$EXIT" -eq 1 ] && echo "$OUTPUT" | grep -q "minimum 3"; then
    echo "PASS: v2.7.77 source-canon-grounding-gate: too few samples (<3) caught"
    PASS=$((PASS + 1))
else
    echo "FAIL: v2.7.77 source-canon-grounding-gate: too-few-samples should fail"
    FAIL=$((FAIL + 1))
fi

rm -rf "$GROUNDING_TMP"

echo ""
echo "============================================"
echo "Tests: $((PASS + FAIL)) | Pass: $PASS | Fail: $FAIL"
[ "$FAIL" -gt 0 ] && exit 1
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
