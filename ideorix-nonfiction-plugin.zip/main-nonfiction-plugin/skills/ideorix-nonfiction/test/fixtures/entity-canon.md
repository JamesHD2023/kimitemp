| Canonical | Aliases |
|---|---|
| Kevin Hall | Hall |
| Tim Spector | Spector |
| Marion Nestle | Nestle |
| National Institutes of Health | NIH |
| Cell Metabolism | |
