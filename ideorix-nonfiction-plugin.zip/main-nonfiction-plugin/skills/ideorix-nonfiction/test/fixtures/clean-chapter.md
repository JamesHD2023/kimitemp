# Chapter 1: Test Clean

The 2019 Hall study at the National Institutes of Health (pp. 49–73)
established that ultra-processed food causes overconsumption. The trial
ran for 28 days in a metabolic ward.

Tim Spector and Marion Nestle have both written about this finding.
Coverage spans 1985–2025 in the published literature.[1]

[1] Hall et al., *Cell Metabolism* 30, no. 1 (2019): 67–77.
