#!/bin/bash
# ============================================================
# Ideorix Non-Fiction Mechanical Audit — Number-7 Bias Check
# NF adaptation: excludes 4-digit years (1500-2100) and numbers
# inside quotation marks (cited statistics).
# ============================================================
# Usage: bash number-7-bias.sh <chapter-file>

set -euo pipefail

CHAPTER="${1:?Usage: number-7-bias.sh <chapter-file>}"
if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

clean_int() { echo "${1:-0}" | tr -dc '0-9' | head -c 10; }

echo "=== NUMBER-7 BIAS CHECK (Non-Fiction) ==="
echo "Chapter: $CHAPTER"
echo "Exclusions: 4-digit years 1500-2100 | numbers inside quotation marks"
echo ""

perl -pe 's/"[^"]*"//g' "$CHAPTER" > "$TMPDIR/prose.txt"
grep -oE '[0-9]+' "$TMPDIR/prose.txt" > "$TMPDIR/all_nums.txt" 2>/dev/null || true

awk '{
    if (length($0) == 4) {
        n = $0 + 0
        if (n >= 1500 && n <= 2100) next
    }
    print
}' "$TMPDIR/all_nums.txt" > "$TMPDIR/numbers.txt"

grep -oEi '\bseven\b' "$TMPDIR/prose.txt" > "$TMPDIR/spelled_sevens.txt" 2>/dev/null || true

TOTAL=$(wc -l < "$TMPDIR/numbers.txt" 2>/dev/null); TOTAL=$(clean_int "$TOTAL")
SEVENS=$(grep -cE '7$' "$TMPDIR/numbers.txt" 2>/dev/null || true); SEVENS=$(clean_int "$SEVENS")
SPELLED=$(wc -l < "$TMPDIR/spelled_sevens.txt" 2>/dev/null); SPELLED=$(clean_int "$SPELLED")
YEARS_EXCLUDED=$(awk 'length($0)==4{n=$0+0; if(n>=1500 && n<=2100) c++} END{print c+0}' "$TMPDIR/all_nums.txt")
YEARS_EXCLUDED=$(clean_int "$YEARS_EXCLUDED")

TOTAL_WITH_SPELLED=$((TOTAL + SPELLED))
SEVENS_WITH_SPELLED=$((SEVENS + SPELLED))

if [ "$TOTAL_WITH_SPELLED" -gt 0 ]; then
    PCT=$((SEVENS_WITH_SPELLED * 100 / TOTAL_WITH_SPELLED))
else
    PCT=0
fi

HOUR_RAW=$(grep -oE '\b7:[0-9]{2}\b|\bseven o.clock\b' "$TMPDIR/prose.txt" 2>/dev/null | wc -l || true)
HOUR_SEVENS=$(clean_int "$HOUR_RAW")

echo "--- Numbers Found ---"
echo "  Numeric digits (post-exclusion): $TOTAL"
echo "  Years 1500-2100 excluded:        $YEARS_EXCLUDED"
echo "  Spelled-out sevens:              $SPELLED"
echo "  Total number references:         $TOTAL_WITH_SPELLED"
echo ""
echo "--- Seven Bias ---"
echo "  Ending in 7 (digit):         $SEVENS"
echo "  Spelled sevens:              $SPELLED"
echo "  Total seven-references:      $SEVENS_WITH_SPELLED"
echo "  Percentage:                  ${PCT}%"
echo "  Per-chapter threshold:       ≤25%"
echo ""

FAIL=0
if [ "$TOTAL_WITH_SPELLED" -lt 3 ]; then
    echo "  STATUS: N/A (fewer than 3 numbers — too small to measure)"
elif [ "$PCT" -gt 25 ]; then
    echo "  STATUS: FAIL — ${PCT}% exceeds 25% chapter threshold"
    FAIL=1
elif [ "$PCT" -gt 15 ]; then
    echo "  STATUS: WARN — ${PCT}% approaching manuscript threshold (15%)"
else
    echo "  STATUS: PASS"
fi

echo ""
echo "--- Hour-7 Check ---"
echo "  Times set to 7:xx or 'seven o'clock': $HOUR_SEVENS"
if [ "$HOUR_SEVENS" -gt 0 ]; then
    echo "  STATUS: FLAG — consider changing hour"
else
    echo "  STATUS: PASS"
fi

echo ""
echo "=== SUMMARY ==="
echo "Numbers: $TOTAL_WITH_SPELLED | Sevens: $SEVENS_WITH_SPELLED (${PCT}%) | Hour-7: $HOUR_SEVENS"
if [ "$FAIL" -eq 1 ]; then echo "STATUS: FAIL"; exit 1; fi
echo "STATUS: PASS"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
