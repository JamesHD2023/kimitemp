#!/bin/bash
# ============================================================
# Ideorix — KDP Metadata Gate (v2.7.68)
# Enforces Phase 6 publishing-metadata discipline. Before the
# project is declared KDP-ready or launch-ready, this gate
# verifies the KDP metadata file exists at the spec-mandated
# path and contains the fields KDP submission requires.
#
# Closes the LLM-contract gap: publishing-formats.md mandates a
# specific structure (Amazon description ≤4000 chars, 7 keywords,
# 3 BISACs, comp titles, pricing) but pre-v2.7.68 nothing
# verified the file's structure before "KDP package complete"
# was claimed. The user could upload a half-finished metadata
# file and discover the gaps at submission time.
# ============================================================
# Usage: bash kdp-metadata-gate.sh <project-root>
#
# Verifies (relative to <project-root>):
#   1. manuscript/*-kdp-metadata.{json,txt,md} exists (any file
#      matching the spec's glob pattern)
#   2. File is non-trivial (>= 500 bytes)
#   3. File contains the required field markers per
#      publishing-formats.md:
#        - title / "title"
#        - description / "description"
#        - keywords (with at least 7 entries OR a "7 keywords"
#          declaration; checked by counting comma-separated
#          entries inside the keywords block when JSON)
#        - bisac / BISAC
#        - comp titles / comparableTitles / comp_titles
#        - pricing / price
#   4. If the metadata is JSON and parseable, the keyword array
#      has at least 7 entries.
#
# Honors opt-out: kdp_status: skip / legacy in project-config.md.
#
# Exit codes:
#   0  KDP metadata present + structured (PASS)
#   1  KDP metadata missing / incomplete (FAIL)
#   2  invalid arguments

set -uo pipefail

PROJECT="${1:?Usage: kdp-metadata-gate.sh <project-root>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

CONFIG="$PROJECT/engine-data/project-config.md"
MANUSCRIPT_DIR="$PROJECT/manuscript"

if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*kdp_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "KDP METADATA GATE: PASS (project-config.md declares kdp_status: skip — documented opt-out honored)"
        exit 0
    fi
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*kdp_status:[[:space:]]*legacy\b' "$CONFIG"; then
        echo "KDP METADATA GATE: PASS (project-config.md declares kdp_status: legacy — pre-v2.7.68 project)"
        exit 0
    fi
fi

if [ ! -d "$MANUSCRIPT_DIR" ]; then
    echo "KDP METADATA GATE: FAIL — manuscript directory missing: $MANUSCRIPT_DIR" >&2
    echo "  ACTION: complete manuscript export + KDP metadata generation per references/publishing-formats.md." >&2
    exit 1
fi

CANDIDATES=$(find "$MANUSCRIPT_DIR" -maxdepth 1 -type f -iname "*kdp-metadata*" \( -name "*.json" -o -name "*.txt" -o -name "*.md" \) 2>/dev/null)

if [ -z "$CANDIDATES" ]; then
    echo "KDP METADATA GATE: FAIL — no KDP metadata file found in $MANUSCRIPT_DIR" >&2
    echo "  Expected: <Title>-kdp-metadata.{json,txt,md} per publishing-formats.md" >&2
    echo "  ACTION: produce the KDP metadata per references/publishing-formats.md." >&2
    exit 1
fi

PASS_FILE=""
FAIL_DETAIL=""

field_present() {
    local file="$1" pattern="$2"
    grep -qiE "$pattern" "$file"
}

for file in $CANDIDATES; do
    [ -f "$file" ] || continue
    size=$(wc -c < "$file" 2>/dev/null || echo 0)
    if [ "$size" -lt 500 ]; then
        FAIL_DETAIL="${FAIL_DETAIL}  - $file: too small ($size bytes; minimum 500)
"
        continue
    fi
    missing=""
    field_present "$file" '"?title"?[[:space:]]*:|^#+[[:space:]]*Title' || missing="$missing title"
    field_present "$file" '"?(amazon)?[Dd]escription"?|^#+[[:space:]]*(Amazon )?Description' || missing="$missing description"
    field_present "$file" '"?keywords"?[[:space:]]*:|^#+[[:space:]]*Keywords' || missing="$missing keywords"
    field_present "$file" '"?bisac' || field_present "$file" '\bBISAC\b' || missing="$missing BISAC"
    field_present "$file" '"?(comparable|comp)_?[Tt]itles?"?|^#+[[:space:]]*(Comp|Comparable)[[:space:]]*[Tt]itles?' || missing="$missing comp_titles"
    field_present "$file" '"?(price|pricing|priceTier)"?|^#+[[:space:]]*Pric(e|ing)' || missing="$missing pricing"

    if [ -n "$missing" ]; then
        FAIL_DETAIL="${FAIL_DETAIL}  - $file: missing required fields:$missing
"
        continue
    fi

    # If JSON, verify keywords array has >= 7 entries.
    case "$file" in
        *.json)
            keywords_ok=$(python3 - "$file" <<'PY' 2>/dev/null || echo "parse-fail"
import json, sys
try:
    with open(sys.argv[1]) as f:
        data = json.load(f)
except Exception:
    print("parse-fail")
    sys.exit(0)
def find_keywords(d):
    if isinstance(d, dict):
        for k, v in d.items():
            if k.lower() in ("keywords", "amazonkeywords", "amazon_keywords") and isinstance(v, list):
                return v
        for v in d.values():
            r = find_keywords(v)
            if r is not None:
                return r
    elif isinstance(d, list):
        for v in d:
            r = find_keywords(v)
            if r is not None:
                return r
    return None
kw = find_keywords(data)
if kw is None:
    print("no-keywords-array")
elif len(kw) < 7:
    print(f"only-{len(kw)}")
else:
    print(f"ok-{len(kw)}")
PY
)
            case "$keywords_ok" in
                ok-*)
                    PASS_FILE="$file"
                    break
                    ;;
                only-*)
                    FAIL_DETAIL="${FAIL_DETAIL}  - $file: keywords array has fewer than 7 entries (got $keywords_ok); KDP requires 7
"
                    continue
                    ;;
                no-keywords-array)
                    # JSON parsed but no keywords array — already counted as missing above via field_present
                    PASS_FILE="$file"
                    break
                    ;;
                parse-fail)
                    FAIL_DETAIL="${FAIL_DETAIL}  - $file: declared JSON but failed to parse
"
                    continue
                    ;;
                *)
                    PASS_FILE="$file"
                    break
                    ;;
            esac
            ;;
        *)
            PASS_FILE="$file"
            break
            ;;
    esac
done

if [ -z "$PASS_FILE" ]; then
    echo "KDP METADATA GATE: FAIL — no candidate KDP metadata file passes the structural check." >&2
    echo "" >&2
    printf '%b' "$FAIL_DETAIL" >&2
    echo "" >&2
    echo "ACTION: complete the KDP metadata per references/publishing-formats.md." >&2
    echo "  Required fields: title, description, keywords (7+), BISAC," >&2
    echo "                   comp_titles, pricing." >&2
    echo "  Minimum size: 500 bytes." >&2
    echo "" >&2
    echo "Opt-outs (if KDP submission is genuinely out of scope):" >&2
    echo "  append to $CONFIG:" >&2
    echo "    kdp_status: legacy   # pre-v2.7.68 project" >&2
    echo "    kdp_status: skip     # KDP not a deliverable" >&2
    exit 1
fi

echo "KDP METADATA GATE: PASS — structured KDP metadata found at $PASS_FILE"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
