#!/bin/bash
# ============================================================
# Ideorix — Voice Restoration Brief (v2.7.66)
# User-invoked Class B audit dispatcher. Validates that every
# precondition is in place (voice-profile, ledger row, chapter,
# exemplars resolve) and emits a CLASS_B_AUDIT marker line the
# engine layer reads to dispatch the actual subagent. Following
# the validate-dispatcher.sh pattern for Class B audits.
#
# This script does NOT itself produce the brief. The brief is
# semantic work that requires a subagent; bash cannot do that.
# Bash's job is to fail loudly on missing preconditions BEFORE
# the subagent dispatch — so the brief never has to write
# "engine-data/voice-profile.md is empty, I can't help you" as
# its first line.
# ============================================================
# Usage: bash voice-restoration-brief.sh <project-root> <chapter-N>
#
# Preflight checks (each FAILs loudly with actionable message):
#   1. project root exists + is a directory
#   2. chapter-N is a positive integer
#   3. engine-data/chapters/ch{NN}.md exists + has >100 words
#      (post-frontmatter strip; <100 words means there is no
#      chapter to restore)
#   4. engine-data/voice-profile.md passes voice-profile-preload
#      gate (calibration corpus is real, not skeleton)
#   5. engine-data/reports/voice-metrics-ledger.md exists AND
#      contains a row for ch{NN} (so the brief subagent has
#      measurement context)
#   6. every voice_calibration_exemplar: path in voice-profile.md
#      resolves to a file inside the project root (preflight
#      catches typo / stale paths before the subagent ever runs)
#
# When all preflight passes, the script:
#   - prints a context summary (paths + ledger row + targets)
#   - emits the CLASS_B_AUDIT marker line for the engine
#   - exits 0
#
# Exit codes:
#   0   preflight passed; CLASS_B_AUDIT marker emitted
#   1   preflight failed (specific message identifies which check)
#   2   invalid arguments

set -uo pipefail

PROJECT="${1:?Usage: voice-restoration-brief.sh <project-root> <chapter-N>}"
CHAPTER_N="${2:?Usage: voice-restoration-brief.sh <project-root> <chapter-N>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi
if ! [[ "$CHAPTER_N" =~ ^[0-9]+$ ]] || [ "$CHAPTER_N" -lt 1 ]; then
    echo "ERROR: chapter-N must be a positive integer, got: $CHAPTER_N" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHAPTER_NN=$(printf '%02d' "$CHAPTER_N")

VOICE_PROFILE="$PROJECT/engine-data/voice-profile.md"
LEDGER="$PROJECT/engine-data/reports/voice-metrics-ledger.md"
CHAPTER_FILE="$PROJECT/engine-data/chapters/ch${CHAPTER_NN}.md"
RETURN_PATH="$PROJECT/engine-data/reports/validate/voice-restoration-brief-ch${CHAPTER_NN}-subagent.md"

echo "=== VOICE RESTORATION BRIEF — preflight ==="
echo "Project: $PROJECT"
echo "Chapter: ch${CHAPTER_NN}"
echo ""

# Check 3: chapter file exists + has substantive content
if [ ! -f "$CHAPTER_FILE" ]; then
    echo "PREFLIGHT FAIL — chapter file not found: $CHAPTER_FILE" >&2
    echo "  ACTION: confirm the chapter exists under engine-data/chapters/" >&2
    echo "  (filename must be ch${CHAPTER_NN}.md — zero-padded two-digit format)" >&2
    exit 1
fi

# Strip YAML frontmatter when line 1 is exactly `---` then count words.
if head -1 "$CHAPTER_FILE" | grep -qE '^---[[:space:]]*$'; then
    WORD_COUNT=$(awk 'NR==1{next} /^---[[:space:]]*$/ && !done {done=1; next} done{print}' "$CHAPTER_FILE" | wc -w)
else
    WORD_COUNT=$(wc -w < "$CHAPTER_FILE")
fi

if [ "$WORD_COUNT" -lt 100 ]; then
    echo "PREFLIGHT FAIL — chapter has only $WORD_COUNT words after frontmatter strip" >&2
    echo "  Voice restoration on a <100-word chapter is not meaningful." >&2
    echo "  ACTION: verify the chapter file is the expected one; finish writing it before requesting restoration." >&2
    exit 1
fi

# Check 4: voice-profile.md preload gate
PRELOAD_GATE="$SCRIPT_DIR/voice-profile-preload-gate.sh"
if [ ! -x "$PRELOAD_GATE" ]; then
    echo "ERROR: voice-profile-preload-gate.sh not found or not executable: $PRELOAD_GATE" >&2
    exit 2
fi
if ! bash "$PRELOAD_GATE" "$PROJECT" >/dev/null 2>&1; then
    echo "PREFLIGHT FAIL — voice-profile.md is missing, empty, or skeleton-only." >&2
    echo "  Run for diagnostic:" >&2
    echo "    bash $PRELOAD_GATE \"$PROJECT\"" >&2
    echo "  Voice restoration without a real calibration corpus would produce a generic brief." >&2
    echo "  ACTION: populate engine-data/voice-profile.md per references/voice-profile.md template." >&2
    exit 1
fi

# Check 5: ledger row exists for this chapter
if [ ! -f "$LEDGER" ]; then
    echo "PREFLIGHT FAIL — voice-metrics-ledger.md not found: $LEDGER" >&2
    echo "  ACTION: run the per-chapter voice metrics audit first:" >&2
    echo "    bash $SCRIPT_DIR/voice-metrics-audit.sh \"$CHAPTER_FILE\" \"$PROJECT\"" >&2
    echo "  (or re-run ideorix-audit.sh; voice-metrics is wired in as Module 8/9)" >&2
    exit 1
fi
if ! grep -qE "^\|[[:space:]]+[^|]+\|[[:space:]]+ch${CHAPTER_NN}[[:space:]]+\|" "$LEDGER"; then
    echo "PREFLIGHT FAIL — no row for ch${CHAPTER_NN} in voice-metrics-ledger.md." >&2
    echo "  The brief subagent needs measurement context to anchor its diagnosis." >&2
    echo "  ACTION: run voice-metrics-audit.sh on this chapter first:" >&2
    echo "    bash $SCRIPT_DIR/voice-metrics-audit.sh \"$CHAPTER_FILE\" \"$PROJECT\"" >&2
    exit 1
fi

# Check 6: every exemplar path in voice-profile.md resolves inside project root
EXEMPLAR_FAIL=0
EXEMPLAR_FAILS=""
while IFS= read -r raw; do
    rel=$(echo "$raw" | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*voice_calibration_exemplar:[[:space:]]*//' | awk '{print $1}' | tr -d '"')
    if [ -z "$rel" ]; then continue; fi
    # Resolve against project root. Reject absolute paths AND paths that
    # escape the project root via .. (the realpath check below catches
    # the latter; this catches the absolute-path case explicitly so the
    # diagnostic is clear).
    if [[ "$rel" = /* ]]; then
        EXEMPLAR_FAILS="${EXEMPLAR_FAILS}  - absolute exemplar path rejected: $rel
"
        EXEMPLAR_FAIL=1
        continue
    fi
    candidate="$PROJECT/$rel"
    if [ ! -f "$candidate" ]; then
        EXEMPLAR_FAILS="${EXEMPLAR_FAILS}  - exemplar not found: $candidate (declared: $rel)
"
        EXEMPLAR_FAIL=1
        continue
    fi
    # realpath comparison so .. traversal is caught even when the file
    # happens to exist outside the project tree. Parenthesised fallback
    # is mandatory: `realpath X || cd X && pwd` parses as
    # `(realpath X || cd X) && pwd` and runs pwd unconditionally,
    # capturing the wrong directory when realpath succeeded.
    rp_project=$(realpath "$PROJECT" 2>/dev/null || (cd "$PROJECT" && pwd))
    rp_candidate=$(realpath "$candidate" 2>/dev/null || echo "")
    if [ -z "$rp_candidate" ] || [[ "$rp_candidate" != "$rp_project"/* && "$rp_candidate" != "$rp_project" ]]; then
        EXEMPLAR_FAILS="${EXEMPLAR_FAILS}  - exemplar resolves outside project root (rejected): $rel → $rp_candidate
"
        EXEMPLAR_FAIL=1
    fi
done < <(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*voice_calibration_exemplar:' "$VOICE_PROFILE" 2>/dev/null || true)

if [ "$EXEMPLAR_FAIL" -eq 1 ]; then
    echo "PREFLIGHT FAIL — one or more voice_calibration_exemplar paths in voice-profile.md don't resolve:" >&2
    printf '%b' "$EXEMPLAR_FAILS" >&2
    echo "  ACTION: fix voice-profile.md exemplar paths; they must be relative to project root and inside the project tree." >&2
    exit 1
fi

# Extract the most recent ledger row for this chapter. Multiple rows
# may exist if the audit was re-run; the brief uses the latest.
LATEST_ROW=$(grep -E "^\|[[:space:]]+[^|]+\|[[:space:]]+ch${CHAPTER_NN}[[:space:]]+\|" "$LEDGER" | tail -1)

# Extract targets from voice-profile.md for the summary.
FP_TARGET=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*fp_target:' "$VOICE_PROFILE" 2>/dev/null | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*fp_target:[[:space:]]*//' | awk '{print $1}')
BAND_MIN=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*sentence_band_min:' "$VOICE_PROFILE" 2>/dev/null | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*sentence_band_min:[[:space:]]*//' | awk '{print $1}')
BAND_MAX=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*sentence_band_max:' "$VOICE_PROFILE" 2>/dev/null | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*sentence_band_max:[[:space:]]*//' | awk '{print $1}')
EXEMPLAR_COUNT=$(grep -cE '^[[:space:]]*[-*+]?[[:space:]]*voice_calibration_exemplar:' "$VOICE_PROFILE" 2>/dev/null || echo 0)

mkdir -p "$(dirname "$RETURN_PATH")"

echo "PREFLIGHT PASS — all preconditions satisfied"
echo ""
echo "Context summary:"
echo "  Chapter file:      $CHAPTER_FILE ($WORD_COUNT words post-frontmatter)"
echo "  Voice profile:     $VOICE_PROFILE"
echo "    fp_target:       ${FP_TARGET:-(missing)}"
echo "    sentence band:   ${BAND_MIN:-?}-${BAND_MAX:-?}"
echo "    exemplars:       $EXEMPLAR_COUNT"
echo "  Metrics ledger:    $LEDGER"
echo "    latest row:      $LATEST_ROW"
echo "  Subagent return:   $RETURN_PATH"
echo ""
echo "Engine layer must now dispatch the voice-restoration-brief"
echo "subagent per references/voice-restoration-brief.md. The"
echo "subagent's structured return MUST land at:"
echo "  $RETURN_PATH"
echo ""
echo "After landing, the engine HARD GATE applies (shape check +"
echo "verdict consistency + citation check + classification"
echo "completeness + no-prose-rewrite heuristic). See the spec for"
echo "the full return contract."
echo ""

# Class B dispatch marker — read by the engine layer (Claude) after
# the bash script exits. Same protocol as validate-dispatcher.sh's
# other CLASS_B_AUDIT emissions.
echo "CLASS_B_AUDIT|voice-restoration-brief|VOICE|references/voice-restoration-brief.md|-"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
