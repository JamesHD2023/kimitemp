#!/bin/bash
# ============================================================
# Ideorix Non-Fiction Mechanical Audit — Pattern Counter
# NF-SPECIFIC patterns: hedging, weasel words, vague quantifiers,
# unsupported assertives, AI NF connectives, frame leaks.
# ============================================================
# Usage: bash pattern-counter.sh <chapter-file> [manuscript-totals-file]

set -euo pipefail

CHAPTER="${1:?Usage: pattern-counter.sh <chapter-file> [totals-file]}"
# Optional 2nd argument (totals-file) reserved for future per-pattern aggregation
# across chapters; not consumed by this script today.

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

# Strip italicised + bold spans (markdown) before counting. Cited paper
# / book / film titles are italicised (e.g. *Most Published Research
# Findings Are False*); flagging crutch words inside them counts the
# referenced work, not the author's prose. Quoted blocks are NOT
# stripped — direct quotation of an interviewee or a primary source
# remains author-attributable in the sense that the author selected
# the quote and could have paraphrased; if the same crutch word
# appears across multiple cited quotes, that's still useful signal.
perl -CSDA -pe '
    s/\*\*[^*\n]+\*\*//g;     # **bold**
    s/__[^_\n]+__//g;         # __bold__
    s/\*[^*\n]+\*//g;         # *italic*
    s/_[^_\n]+_//g;           # _italic_
' "$CHAPTER" > "$TMPDIR/stripped.txt"
tr '[:upper:]' '[:lower:]' < "$TMPDIR/stripped.txt" > "$TMPDIR/lower.txt"
FAIL=0

echo "=== PATTERN COUNTER (Non-Fiction) ==="
echo "Chapter: $CHAPTER"
echo "Words: $(wc -w < "$CHAPTER")"
echo ""

count_pattern() {
    local label="$1" pattern="$2" cap="$3" tolerance="$4"
    local count
    count=$({ grep -oE "$pattern" "$TMPDIR/lower.txt" 2>/dev/null || true; } | wc -l)
    count=$(echo "$count" | tr -dc '0-9'); [ -z "$count" ] && count=0
    local status="PASS"
    if [ "$tolerance" = "zero" ] && [ "$count" -gt 0 ]; then
        status="FAIL"; FAIL=1
    elif [ "$tolerance" = "limited" ] && [ "$count" -gt "$cap" ]; then
        status="FAIL (${count}/${cap})"; FAIL=1
    elif [ "$tolerance" = "limited" ] && [ "$count" -gt 0 ]; then
        status="OK (${count}/${cap})"
    fi
    printf "  %-48s %3d  cap: %-4s  %s\n" "$label" "$count" "$cap" "$status"
}

# === ZERO-TOLERANCE: Academic hedging ===
echo "--- Zero-Tolerance: Academic Hedging ---"
count_pattern "it could be argued"                   "it could be argued"                 0 "zero"
count_pattern "one might suggest"                    "one might suggest"                  0 "zero"
count_pattern "it has been suggested"                "it has been suggested"              0 "zero"
count_pattern "some would say"                       "some would say"                     0 "zero"
count_pattern "it is important to note"              "it is important to note"            0 "zero"
count_pattern "it should be noted"                   "it should be noted"                 0 "zero"

echo ""
echo "--- Zero-Tolerance: Weasel Words (unsourced attribution) ---"
count_pattern "some experts say"                     "some experts (say|believe|argue)"   0 "zero"
count_pattern "it is widely believed"                "it is widely believed"              0 "zero"
count_pattern "many people believe"                  "many people (believe|think|say)"    0 "zero"
count_pattern "most scholars agree"                  "most scholars (agree|believe)"      0 "zero"
count_pattern "studies have shown (unsourced)"       "studies have shown[^[,(]"           0 "zero"
count_pattern "research suggests (unsourced)"        "research suggests[^,(]"             0 "zero"

echo ""
echo "--- Zero-Tolerance: Unsupported Assertives ---"
count_pattern "clearly"                              "\\bclearly\\b"                      0 "zero"
count_pattern "obviously"                            "\\bobviously\\b"                    0 "zero"
count_pattern "of course"                            "\\bof course\\b"                    0 "zero"
count_pattern "undoubtedly"                          "\\bundoubtedly\\b"                  0 "zero"

echo ""
echo "--- Zero-Tolerance: AI NF Transitions ---"
count_pattern "furthermore"                          "\\bfurthermore\\b"                  0 "zero"
count_pattern "moreover"                             "\\bmoreover\\b"                     0 "zero"
count_pattern "interestingly"                        "\\binterestingly\\b"                0 "zero"
count_pattern "notably"                              "\\bnotably\\b"                      0 "zero"
count_pattern "significantly"                        "\\bsignificantly\\b"                0 "zero"
count_pattern "it is worth noting"                   "it is worth noting|it's worth noting" 0 "zero"
count_pattern "needless to say"                      "needless to say"                    0 "zero"

echo ""
echo "--- Zero-Tolerance: Frame Leaks ---"
# "the reader" only flagged when directly addressing the reader (not idiomatic "the reader of")
count_pattern "the reader (direct address)"          "the reader (may|will|might|should|can|must|would|needs|wants)" 0 "zero"
count_pattern "dear reader"                          "\\bdear reader\\b"                  0 "zero"
count_pattern "in this book"                         "\\bin this book\\b"                 0 "zero"
count_pattern "the previous chapter"                 "the previous chapter"               0 "zero"
count_pattern "as mentioned earlier"                 "as mentioned (earlier|above|previously)" 0 "zero"

echo ""

# === FREQUENCY-LIMITED PATTERNS ===
echo "--- Frequency-Limited: Vague Quantifiers ---"
count_pattern "many"                                 "\\bmany\\b"                         4 "limited"
count_pattern "most"                                 "\\bmost\\b"                         4 "limited"
count_pattern "several"                              "\\bseveral\\b"                      3 "limited"
count_pattern "numerous"                             "\\bnumerous\\b"                     2 "limited"
count_pattern "various"                              "\\bvarious\\b"                      3 "limited"

echo ""
echo "--- Frequency-Limited: Common NF overuse ---"
count_pattern "the fact that"                        "\\bthe fact that\\b"                3 "limited"
count_pattern "in order to"                          "\\bin order to\\b"                  3 "limited"
count_pattern "at the end of the day"                "at the end of the day"              1 "limited"
count_pattern "in terms of"                          "\\bin terms of\\b"                  3 "limited"

echo ""
echo "--- Chapter Opening Patterns ---"
# v2.7.40 fix: tolerate the case where the first 5 lines are all
# heading/blank (common when chapters open with `# Title` + several
# `## Subheaders`). Pre-v2.7.40 this aborted under `set -euo pipefail`
# because grep -v returned 1 with no surviving lines, killing the
# whole script before the SUMMARY block was emitted.
FIRST_LINE=$( (head -5 "$CHAPTER" | grep -v '^#' | grep -v '^$' | head -1 | tr '[:upper:]' '[:lower:]') || true )
echo "  First prose line: ${FIRST_LINE:0:80}..."

QUESTION_OPEN=$(echo "$FIRST_LINE" | grep -c "?" 2>/dev/null || true)
DID_YOU_KNOW=$(echo "$FIRST_LINE" | grep -ci "did you know\|have you ever" 2>/dev/null || true)
echo "  Opens with question: $QUESTION_OPEN"
echo "  Opens with 'did you know / have you ever': $DID_YOU_KNOW"
[ "$DID_YOU_KNOW" -gt 0 ] && { echo "  STATUS: FAIL — cliché NF opener"; FAIL=1; }

echo ""
echo "=== SUMMARY ==="
if [ "$FAIL" -eq 1 ]; then echo "STATUS: FAIL"; exit 1; fi
echo "STATUS: PASS"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
