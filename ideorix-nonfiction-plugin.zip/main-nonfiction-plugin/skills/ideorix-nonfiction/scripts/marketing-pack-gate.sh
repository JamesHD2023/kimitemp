#!/bin/bash
# ============================================================
# Ideorix — Marketing Pack Gate (v2.7.68)
# Enforces Phase 6 Marketing discipline. Before the project is
# declared marketing-ready or launch-ready, this gate verifies
# the marketing brief contains the required material types per
# references/marketing-expert.md.
#
# Closes the LLM-contract gap: the user reported that the
# generated marketing brief omitted the cover-image section
# entirely. v2.7.67 and earlier had no way to detect that — the
# DOCX existed and was non-zero, so "marketing complete" reported
# success. v2.7.68 makes the section count + content a verifiable
# precondition.
# ============================================================
# Usage: bash marketing-pack-gate.sh <project-root>
#
# Verifies (relative to <project-root>):
#   1. marketing/marketing-brief.docx exists + non-zero
#   2. A source markdown companion exists at
#      marketing/marketing-brief.md OR marketing/marketing-source.md
#      (the gate reads the markdown for section scanning; the .docx
#      is the rendered output)
#   3. The source markdown contains at least the 5 core marketing
#      material types (Amazon Description, Back Cover Blurb,
#      Keywords & Categories, Social Media Pack, Target Audience).
#      Detection is case-insensitive heading match.
#   4. The cover-brief-gate passes for this project (marketing
#      depends on cover being done).
#
# Honors opt-out: marketing_status: skip / legacy in
# project-config.md.
#
# Exit codes:
#   0  marketing pack present + populated + cover gate passes (PASS)
#   1  marketing pack incomplete / cover gate fails (FAIL)
#   2  invalid arguments

set -uo pipefail

PROJECT="${1:?Usage: marketing-pack-gate.sh <project-root>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="$PROJECT/engine-data/project-config.md"
MARKETING_DIR="$PROJECT/marketing"
BRIEF_DOCX="$MARKETING_DIR/marketing-brief.docx"

if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*marketing_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "MARKETING PACK GATE: PASS (project-config.md declares marketing_status: skip — documented opt-out honored)"
        exit 0
    fi
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*marketing_status:[[:space:]]*legacy\b' "$CONFIG"; then
        echo "MARKETING PACK GATE: PASS (project-config.md declares marketing_status: legacy — pre-v2.7.68 project)"
        exit 0
    fi
fi

FAIL=0
FAIL_LINES=""

if [ ! -f "$BRIEF_DOCX" ]; then
    FAIL_LINES="${FAIL_LINES}  - marketing-brief.docx missing: $BRIEF_DOCX
"
    FAIL=1
elif [ ! -s "$BRIEF_DOCX" ]; then
    FAIL_LINES="${FAIL_LINES}  - marketing-brief.docx is zero bytes: $BRIEF_DOCX
"
    FAIL=1
fi

# Find source markdown — try standard names in order.
SOURCE_MD=""
for candidate in "$MARKETING_DIR/marketing-brief.md" "$MARKETING_DIR/marketing-source.md" "$MARKETING_DIR/marketing-pack.md"; do
    if [ -f "$candidate" ] && [ -s "$candidate" ]; then
        SOURCE_MD="$candidate"
        break
    fi
done

if [ -z "$SOURCE_MD" ]; then
    FAIL_LINES="${FAIL_LINES}  - marketing source markdown missing: expected one of
      $MARKETING_DIR/marketing-brief.md, marketing-source.md, marketing-pack.md
"
    FAIL=1
fi

# Section scan — 5 core material types must be present as headings.
# Heading match is heuristic: any line starting with #+ that contains
# the section keyword (case-insensitive).
section_present() {
    local file="$1" pattern="$2"
    grep -qiE "^#+[[:space:]]*.*${pattern}" "$file"
}

if [ -n "$SOURCE_MD" ]; then
    MISSING_SECTIONS=""
    section_present "$SOURCE_MD" 'Amazon Description'    || MISSING_SECTIONS="$MISSING_SECTIONS Amazon-Description"
    section_present "$SOURCE_MD" 'Back Cover Blurb'      || MISSING_SECTIONS="$MISSING_SECTIONS Back-Cover-Blurb"
    section_present "$SOURCE_MD" 'Keywords.*Categor'     || MISSING_SECTIONS="$MISSING_SECTIONS Keywords-and-Categories"
    section_present "$SOURCE_MD" 'Social Media'          || MISSING_SECTIONS="$MISSING_SECTIONS Social-Media-Pack"
    section_present "$SOURCE_MD" 'Target Audience'       || MISSING_SECTIONS="$MISSING_SECTIONS Target-Audience"
    if [ -n "$MISSING_SECTIONS" ]; then
        FAIL_LINES="${FAIL_LINES}  - marketing source missing required sections:$MISSING_SECTIONS
      (source: $SOURCE_MD)
"
        FAIL=1
    fi
fi

# Cross-check: cover gate must pass. Marketing depends on cover.
COVER_GATE="$SCRIPT_DIR/cover-brief-gate.sh"
if [ -x "$COVER_GATE" ]; then
    if ! bash "$COVER_GATE" "$PROJECT" >/dev/null 2>&1; then
        FAIL_LINES="${FAIL_LINES}  - cover-brief-gate fails for this project (marketing pack depends on cover)
      Run for diagnostic:  bash $COVER_GATE \"$PROJECT\"
"
        FAIL=1
    fi
fi

if [ "$FAIL" -eq 1 ]; then
    echo "MARKETING PACK GATE: FAIL — marketing pack is incomplete." >&2
    echo "" >&2
    printf '%b' "$FAIL_LINES" >&2
    echo "" >&2
    echo "ACTION: complete the marketing pack per references/marketing-expert.md." >&2
    echo "  Required minimum sections: Amazon Description, Back Cover Blurb," >&2
    echo "                              Keywords & Categories, Social Media Pack," >&2
    echo "                              Target Audience." >&2
    echo "  Source markdown must be at marketing/marketing-brief.md (or" >&2
    echo "  marketing-source.md / marketing-pack.md); compiled .docx must" >&2
    echo "  exist at marketing/marketing-brief.docx." >&2
    echo "" >&2
    echo "Opt-outs (if marketing pack is genuinely out of scope):" >&2
    echo "  append to $CONFIG:" >&2
    echo "    marketing_status: legacy   # pre-v2.7.68 project" >&2
    echo "    marketing_status: skip     # marketing not a deliverable" >&2
    exit 1
fi

echo "MARKETING PACK GATE: PASS — marketing-brief.docx + source markdown present, 5 core sections found, cover gate passes"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
