#!/bin/bash
# ============================================================
# Ideorix — PreToolUse Bash Anti-Pattern Advisory Hook (v2.7.73)
# Fires before every Bash tool invocation in any session where
# an Ideorix plugin is installed. Scans the proposed Bash command
# for awk-with-getline patterns historically associated with file
# corruption.
#
# v2.7.73 RESCOPED: previously this hook BLOCKED matched commands
# (exit 2). A controlled v2.7.73 diagnostic confirmed the awk-
# getline matcher was targeting the wrong dimension: the actual
# corruption mechanism is intermittent Cowork-Windows filesystem-
# bridge failure during cross-FS mv, not the bash command pattern.
# Both awk-getline and sed-only commands exhibit the same
# intermittent NULL-byte corruption on the affected environments;
# both work cleanly when the bridge is healthy. Banning awk-getline
# blocked legitimate commands without preventing the actual
# corruption mode.
#
# v2.7.73 behaviour: the hook now emits an ADVISORY (exit 0 + stderr
# note) when the matcher fires, instead of blocking. The advisory
# explains the revised mechanism + the canonical defense
# (verify-after-write via chapter-integrity-check.sh, which already
# fires post-write via the v2.7.72/73 PostToolUse hook). Logging
# behaviour is retained for observability and future diagnostics.
#
# See silent-failure-audit.md row 65 v2.7.73 reassessment for the
# full mechanism narrative and the diagnostic test results that
# motivated the rescope.
# ============================================================
# stdin: JSON from the Claude Code harness with shape
#   { "tool_input": { "command": "<the bash command string>" }, ... }
# stdout: empty (no structured output; we use stderr + exit code)
# stderr: advisory note when the matcher fires
# exit:
#   0  always (advisory only — never blocks)
#
# Fail-open policy: if the JSON is malformed, missing, or the command
# field is empty, exit 0. The hook never blocks.
#
# Observability (v2.7.71+): every invocation appends a single line to
# the hook log so the presence of entries proves the hook fired and
# the entries let us identify which command pattern slipped past the
# matcher when a corruption is reported. Default log location:
#   ${IDEORIX_HOOK_LOG:-${TMPDIR:-/tmp}/ideorix-bash-hook.log}
# Set IDEORIX_HOOK_LOG=/dev/null to disable observability for a
# session that wants to opt out (rare — the log adds no measurable
# overhead and is the only diagnostic we have when corruption recurs).

set -uo pipefail

HOOK_LOG="${IDEORIX_HOOK_LOG:-${TMPDIR:-/tmp}/ideorix-bash-hook.log}"

# Write a log line. Caller passes: decision, reason, command (truncated).
log_invocation() {
    local decision="$1" reason="$2" command="$3"
    # Truncate command to keep log lines bounded.
    local truncated="${command:0:500}"
    if [ "${#command}" -gt 500 ]; then
        truncated="${truncated}...[truncated, full length: ${#command}]"
    fi
    # Replace newlines + tabs with literal \n / \t so each invocation
    # is one log line. Replace \r similarly.
    truncated="${truncated//$'\n'/\\n}"
    truncated="${truncated//$'\r'/\\r}"
    truncated="${truncated//$'\t'/\\t}"
    {
        printf '%s | v2.7.73 | %s | %s | %s\n' \
            "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            "$decision" \
            "$reason" \
            "$truncated"
    } >> "$HOOK_LOG" 2>/dev/null || true
}

# Read stdin payload. Cap at 1 MiB to avoid pathological inputs.
PAYLOAD=$(head -c 1048576 2>/dev/null || true)

if [ -z "$PAYLOAD" ]; then
    log_invocation "PASS" "empty-payload" ""
    exit 0
fi

# Extract .tool_input.command via python3 (more portable than jq).
# Any parse failure → fail-open (exit 0).
COMMAND=$(python3 -c '
import json, sys
try:
    data = json.load(sys.stdin)
except Exception:
    sys.exit(0)
cmd = data.get("tool_input", {}).get("command", "") or ""
sys.stdout.write(cmd)
' <<<"$PAYLOAD" 2>/dev/null || true)

if [ -z "$COMMAND" ]; then
    log_invocation "PASS" "no-command-field" ""
    exit 0
fi

# Match the anti-pattern. v2.7.71 broadens the matcher based on
# observed-actual-command evidence: the corrupting pattern is `awk`
# used as a content-splicer — awk reading content from another file
# via `getline ... <` AND writing the merged result via output redirect.
# This can corrupt the output file (line-count collapse, NULL bytes,
# or both) depending on the awk implementation and line-ending
# conventions, particularly on Windows-bash environments.
#
# Two trigger combinations BLOCK:
#   (1) Original v2.7.70: awk + getline + heredoc on same command
#   (2) New v2.7.71:     awk + `getline ... <` (file redirect into
#                         getline, i.e., content-splicer pattern)
#
# What still PASSES:
#   - `awk '{print}' file.md`                        (no getline)
#   - `awk 'NR==1{getline; print}' file.md`          (getline without
#                                                     external file read)
#   - `cat > out << EOF\n...\nEOF`                   (heredoc without
#                                                     awk-getline)
#
# The user's v2.7.70 corruption-case command (from their session
# transcript) used pattern (2): `awk -v ... '{... getline line <
# fname ...}' $CHAPTER > "${CHAPTER}.tmp"`. The new matcher catches it.
HAS_AWK=0
HAS_GETLINE=0
HAS_HEREDOC=0
HAS_GETLINE_REDIRECT=0

echo "$COMMAND" | grep -qE '\bawk\b'                          && HAS_AWK=1
echo "$COMMAND" | grep -qE '\bgetline\b'                      && HAS_GETLINE=1
echo "$COMMAND" | grep -qE "<<[[:space:]]*[A-Za-z_'\"]"        && HAS_HEREDOC=1
# Content-splicer detection: `getline` followed by `<` (single `<`,
# not `<<` which is heredoc). The regex `getline[^<]*<[^<]` allows
# arbitrary tokens between `getline` and `<` (e.g., `getline line < file`,
# `getline next_line < "other.md"`) but rejects `getline <<` (heredoc).
echo "$COMMAND" | grep -qE 'getline[^<]*<[^<]'                && HAS_GETLINE_REDIRECT=1

REASON="awk=${HAS_AWK} getline=${HAS_GETLINE} heredoc=${HAS_HEREDOC} splicer=${HAS_GETLINE_REDIRECT}"

# Pattern (1): awk + getline + heredoc (v2.7.70 original)
# Pattern (2): awk + getline-redirect-from-file (v2.7.71 new)
MATCH=0
if [ "$HAS_AWK" -eq 1 ] && [ "$HAS_GETLINE" -eq 1 ] && [ "$HAS_HEREDOC" -eq 1 ]; then
    MATCH=1
fi
if [ "$HAS_AWK" -eq 1 ] && [ "$HAS_GETLINE_REDIRECT" -eq 1 ]; then
    MATCH=1
fi

if [ "$MATCH" -eq 1 ]; then
    log_invocation "ADVISE" "$REASON" "$COMMAND"
    cat >&2 <<'ADVISORY_MSG'
ADVISORY from Ideorix PreToolUse hook (v2.7.73). This is informational —
the command is not blocked.

This Bash command uses awk-with-getline (either + heredoc or + file
redirect). Historically (v2.7.68–72) the engine treated these patterns
as the cause of intermittent NULL-byte chapter corruption. A controlled
v2.7.73 diagnostic disproved that: the awk-getline patterns produce
clean output in isolated reproduction. The actual corruption mechanism
is intermittent Cowork-Windows filesystem-bridge failure during the
cross-FS mv that backs the write; both awk-getline and sed-only
commands can be affected equally, but only when the bridge stutters.

The right defense is verify-after-write, not avoid-awk. After any
critical engine-data write, run:

    bash scripts/chapter-integrity-check.sh {path}

If the file came back corrupted (NULL bytes, line-count collapse,
empty), restore from engine-data/snapshots/ and retry. The bridge
failure is intermittent — the retry usually succeeds.

The v2.7.72/73 PostToolUse hook now runs chapter-integrity-check.sh
automatically after every Write|Edit on `engine-data/*.md` files, so
the verification is wired in for those tool paths. For Bash-based
writes, the spec-driven invocation in core-pipeline.md remains the
detective layer.

See core-pipeline.md File Operation Policy and silent-failure-audit.md
row 65 v2.7.73 reassessment for the full mechanism narrative.
ADVISORY_MSG
    exit 0
fi

log_invocation "PASS" "$REASON" "$COMMAND"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
