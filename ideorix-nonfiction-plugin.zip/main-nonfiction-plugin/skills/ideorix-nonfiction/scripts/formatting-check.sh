#!/bin/bash
# ============================================================
# Ideorix Non-Fiction Mechanical Audit — Formatting Check
# NF em-dash rule: ZERO em-dashes (—) in prose, max 2 per chapter
# INSIDE direct quotations only.
# En-dashes (–) and double-hyphens are reported separately and only
# fail when they appear outside numeric/range contexts.
# ============================================================
set -euo pipefail

CHAPTER="${1:?Usage: formatting-check.sh <chapter-file>}"
if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT
FAIL=0

WORD_COUNT=$(wc -w < "$CHAPTER")

# Strip YAML front matter (between opening and closing ---) and markdown headings.
# Normalize em-dash family imposters (U+2015 HORIZONTAL BAR, U+2E3A/3B TWO/THREE-
# EM, U+FE58 SMALL EM) to U+2014. Some authoring tools insert these visually-
# identical variants instead of real em-dashes; without normalization the
# count_occurrences `—` pattern below misses them and silently passes a
# chapter that violates the NF zero-em-dash-in-prose rule.
awk 'BEGIN{fm=0} /^---$/{fm++; next} fm==1{next} /^#/{next} {print}' "$CHAPTER" \
    | perl -CSDA -pe 's/[\x{2015}\x{2E3A}\x{2E3B}\x{FE58}]/\x{2014}/g' \
    > "$TMPDIR/body.txt"

# Strip markdown table-rule lines (rows that are only |, -, :, spaces) — these legitimately
# contain runs of hyphens that are NOT prose punctuation.
grep -vE '^[[:space:]]*\|?[[:space:]]*[-:|][-:|[:space:]]*\|?[[:space:]]*$' "$TMPDIR/body.txt" > "$TMPDIR/body_no_tablerules.txt"

# Extract quoted spans (inside straight " ... " OR curly " ... " OR ' ... ').
# These are the only place em-dashes are allowed in NF.
perl -CSDA -ne '
    while (/[\x{201C}"]([^\x{201D}"]*)[\x{201D}"]/g) { print "$1\n" }
    while (/[\x{2018}]([^\x{2019}]*)[\x{2019}]/g)    { print "$1\n" }
' "$TMPDIR/body_no_tablerules.txt" > "$TMPDIR/quoted.txt" || true

# Strip quoted spans — what remains is prose.
perl -CSDA -pe '
    s/[\x{201C}"][^\x{201D}"]*[\x{201D}"]//g;
    s/[\x{2018}][^\x{2019}]*[\x{2019}]//g;
' "$TMPDIR/body_no_tablerules.txt" > "$TMPDIR/prose.txt" || true

count_occurrences() {
    # Count occurrences (NOT lines) of a pattern in a file.
    # Wrap grep in { || true; } so a no-match (exit 1) doesn't trip set -euo pipefail.
    local pattern="$1" file="$2"
    local count
    count=$({ grep -oE "$pattern" "$file" 2>/dev/null || true; } | wc -l | tr -dc '0-9')
    echo "${count:-0}"
}

# True em-dashes (—) — zero tolerance in prose, cap 2 in quotes
PROSE_EMDASH=$(count_occurrences '—' "$TMPDIR/prose.txt")
QUOTED_EMDASH=$(count_occurrences '—' "$TMPDIR/quoted.txt")

# En-dashes (–) — informational; only flag if they appear OUTSIDE numeric ranges
# (e.g. "the conclusion–and the question" is bad; "pp. 49–73" is fine).
# Strategy: count en-dashes inside numeric ranges separately and subtract.
EN_TOTAL=$(count_occurrences '–' "$TMPDIR/prose.txt")
# Numeric range = digit, optional letters/space, en-dash, digit (matches "49–73", "E214–E219", "1985–2025")
EN_NUMERIC=$(count_occurrences '[0-9A-Za-z]+–[0-9A-Za-z]+' "$TMPDIR/prose.txt")
PROSE_ENDASH_OUTSIDE_RANGE=$(( EN_TOTAL - EN_NUMERIC ))
[ "$PROSE_ENDASH_OUTSIDE_RANGE" -lt 0 ] && PROSE_ENDASH_OUTSIDE_RANGE=0

# Double-hyphens (--) — informational; flag if they appear in prose
# (table-rule lines were stripped above).
PROSE_DBLHYPHEN=$(count_occurrences '\-\-' "$TMPDIR/prose.txt")

# Other punctuation (true occurrence counts)
PROSE_ELLIPSIS=$(count_occurrences '\.\.\.' "$TMPDIR/prose.txt")
PROSE_EXCLAIM=$(count_occurrences '!' "$TMPDIR/prose.txt")
SEMICOLONS=$(count_occurrences ';' "$TMPDIR/prose.txt")

# Sentence-starter caps — count occurrences across the chapter, not lines
AND_STARTS=$({ grep -oE '(^|\n)[[:space:]]*And[[:space:]]+' "$CHAPTER" 2>/dev/null || true; } | wc -l | tr -dc '0-9')
BUT_STARTS=$({ grep -oE '(^|\n)[[:space:]]*But[[:space:]]+' "$CHAPTER" 2>/dev/null || true; } | wc -l | tr -dc '0-9')
[ -z "$AND_STARTS" ] && AND_STARTS=0
[ -z "$BUT_STARTS" ] && BUT_STARTS=0

echo "=== FORMATTING CHECK (Non-Fiction) ==="
echo "Chapter: $CHAPTER"
echo "Word count: $WORD_COUNT"
echo ""

echo "--- Em-Dashes (NF: zero in prose, max 2 inside quotations) ---"
echo "  Prose em-dashes (—): $PROSE_EMDASH (target: 0)"
if [ "$PROSE_EMDASH" -gt 0 ]; then
    echo "  STATUS: FAIL — $PROSE_EMDASH prose em-dashes (zero tolerance)"
    grep -nE '—' "$TMPDIR/prose.txt" 2>/dev/null | head -10 | sed 's/^/    /'
    FAIL=1
else
    echo "  STATUS: PASS"
fi
echo "  Quoted em-dashes (—): $QUOTED_EMDASH (cap: ≤2 per chapter — direct quotations only)"
if [ "$QUOTED_EMDASH" -gt 2 ]; then
    echo "  STATUS: FAIL — $QUOTED_EMDASH quoted em-dashes (cap: 2)"
    FAIL=1
else
    echo "  STATUS: PASS"
fi

echo ""
echo "--- En-Dashes (–) — informational ---"
echo "  Total prose en-dashes: $EN_TOTAL"
echo "  Inside numeric/letter ranges (allowed): $EN_NUMERIC"
echo "  Outside numeric ranges (flag): $PROSE_ENDASH_OUTSIDE_RANGE"
if [ "$PROSE_ENDASH_OUTSIDE_RANGE" -gt 0 ]; then
    echo "  STATUS: WARN — $PROSE_ENDASH_OUTSIDE_RANGE en-dashes outside numeric ranges"
    grep -nE '[^0-9A-Za-z]–[^0-9A-Za-z]|[^0-9A-Za-z]–|–[^0-9A-Za-z]' "$TMPDIR/prose.txt" 2>/dev/null | head -5 | sed 's/^/    /'
else
    echo "  STATUS: PASS"
fi

echo ""
echo "--- Double-Hyphens (--) — informational ---"
echo "  Prose double-hyphens (table rules stripped): $PROSE_DBLHYPHEN"
if [ "$PROSE_DBLHYPHEN" -gt 0 ]; then
    echo "  STATUS: WARN — $PROSE_DBLHYPHEN double-hyphens in prose; consider em-dash or rephrase"
else
    echo "  STATUS: PASS"
fi

echo ""
echo "--- Other Punctuation ---"
echo "  Prose ellipses: $PROSE_ELLIPSIS (cap: ≤2 per chapter)"
if [ "$PROSE_ELLIPSIS" -gt 2 ]; then echo "  STATUS: FAIL"; FAIL=1; else echo "  STATUS: PASS"; fi
echo "  Prose exclamation marks: $PROSE_EXCLAIM (cap: ≤1 per chapter)"
if [ "$PROSE_EXCLAIM" -gt 1 ]; then echo "  STATUS: FAIL"; FAIL=1; else echo "  STATUS: PASS"; fi
echo "  Prose semicolons: $SEMICOLONS (informational — NF allows moderate use)"

echo ""
echo "--- Sentence Starters ---"
echo "  Sentences starting with 'And': $AND_STARTS (cap: ≤2)"
if [ "$AND_STARTS" -gt 2 ]; then echo "  STATUS: FAIL"; FAIL=1; else echo "  STATUS: PASS"; fi
echo "  Sentences starting with 'But': $BUT_STARTS (cap: ≤2)"
if [ "$BUT_STARTS" -gt 2 ]; then echo "  STATUS: FAIL"; FAIL=1; else echo "  STATUS: PASS"; fi

echo ""
if [ "$FAIL" -eq 1 ]; then echo "STATUS: FAIL"; exit 1; fi
echo "STATUS: PASS"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
