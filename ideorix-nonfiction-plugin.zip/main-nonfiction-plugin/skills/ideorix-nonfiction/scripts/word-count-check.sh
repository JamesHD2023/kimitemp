#!/bin/bash
# ============================================================
# Ideorix Non-Fiction Mechanical Audit — Word Count Check
# Strips YAML front matter + trailing markdown emphasis before counting.
# Reliable null-byte detection via tr (grep -c $'\x00' is flaky across GNU grep versions).
# ============================================================
# Usage: bash word-count-check.sh <chapter-file> [target-words]

set -euo pipefail

# Force C locale so wc -w word-boundary classification is identical
# across systems. Without this, locales that treat certain Unicode
# punctuation as word boundaries (or don't) can cause ±1-2% drift in
# counts, false-failing tight tolerances. (Audit finding 2026-05-19.)
export LC_ALL=C

CHAPTER="${1:?Usage: word-count-check.sh <chapter-file> [target-words]}"
TARGET="${2:-2500}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

# Strip YAML front matter ONLY when the file actually starts with --- on line 1.
# Without this guard, Markdown scene-break --- separators mid-chapter were
# being treated as YAML delimiters, silently dropping entire scenes from the
# word count (Cowork bug report 2026-05-01).
if head -1 "$CHAPTER" | grep -qE '^---[[:space:]]*$'; then
    ACTUAL=$(awk 'NR==1{next} /^---[[:space:]]*$/ && !done {done=1; next} done{print}' "$CHAPTER" | wc -w)
else
    ACTUAL=$(wc -w < "$CHAPTER")
fi
PCT=$((ACTUAL * 100 / TARGET))

# Internal target is 110% of published target
INTERNAL=$((TARGET * 110 / 100))
INTERNAL_PCT=$((ACTUAL * 100 / INTERNAL))

# Strip trailing whitespace + markdown emphasis (*, _) + nulls before the
# terminal-punctuation check. Using perl because GNU sed matches $ before
# final \n (won't strip it). Nulls get classified separately by the null-
# byte check below so they're stripped here too — terminal punctuation is
# evaluated against the textual tail.
LAST_CHAR=$(perl -0777 -ne 's/[\s*_\x00]+\z//; print substr($_, -1)' < "$CHAPTER")
PREV_CHAR=$(perl -0777 -ne 's/[\s*_\x00]+\z//; print(length > 1 ? substr($_, -2, 1) : "")' < "$CHAPTER")
LAST_LINE=$(tail -n 3 "$CHAPTER" | grep -v '^$' | tail -1 | head -c 80)

FILE_SIZE=$(stat -c%s "$CHAPTER" 2>/dev/null || stat -f%z "$CHAPTER")
# Reliable null-byte count: delete everything except \0, count bytes.
NULL_BYTES=$(tr -dc '\0' < "$CHAPTER" | wc -c)
# Count of CONSECUTIVE null bytes at EOF (informational diagnostic only —
# the WARN/FAIL classification uses NULL_CLASS below, which is stricter:
# only EXACTLY ONE trailing null AFTER a clean sentence terminator + \n
# qualifies as cosmetic).
TRAILING_NULLS=$(perl -e 'my $c = do { local $/; <STDIN> }; print(($c =~ /(\x00+)\z/) ? length($1) : 0)' < "$CHAPTER")
# Refined null classification:
#   none     = no nulls (PASS)
#   cosmetic = exactly 1 null AND tail matches [.!?]\n\x00 (WARN — single
#              trailing null after clean sentence terminator, content intact)
#   corrupt  = anything else: embedded null, multiple nulls, or trailing
#              null without preceding sentence terminator + newline (FAIL)
NULL_CLASS=$(perl -0777 -e '
    my $c = do { local $/; <STDIN> };
    my $null_count = () = $c =~ /\x00/g;
    if ($null_count == 0) { print "none"; }
    elsif ($null_count == 1 && $c =~ /[.!?]\n\x00\z/) { print "cosmetic"; }
    else { print "corrupt"; }
' < "$CHAPTER")

echo "=== WORD COUNT CHECK ==="
echo "Chapter: $CHAPTER"
echo "File size: $FILE_SIZE bytes"
echo ""
echo "--- Word Count ---"
echo "  Published target: $TARGET"
echo "  Internal target (110%): $INTERNAL"
echo "  Actual words: $ACTUAL"
echo "  % of published target: ${PCT}%"
echo "  % of internal target: ${INTERNAL_PCT}%"

FAIL=0
WARN=0
if [ "$PCT" -lt 90 ]; then
    echo "  STATUS: FAIL — below 90% of target (${PCT}%)"
    FAIL=1
elif [ "$PCT" -gt 125 ]; then
    echo "  STATUS: WARN — above 125% of target (${PCT}%)"
    WARN=1
else
    echo "  STATUS: PASS"
fi

echo ""
echo "--- File Integrity ---"
echo "  Last line: $LAST_LINE"
echo "  Last char: '$LAST_CHAR' (preceded by: '$PREV_CHAR')"
# Terminal punctuation — refined to use both LC and PC:
#   .!?                        → PASS
#   "')]  AND PC ∈ .!?         → PASS (sentence-end inside close, e.g., '."')
#   "')]  AND PC = anything    → WARN (dangling close, e.g., 'running"')
#   alpha AND PC alpha         → FAIL (mid-word truncation, e.g., 'catalo')
#   alpha AND PC = '.'         → WARN (alpha after period; possible truncated
#                                       abbreviation, e.g., 'R.A')
#   alpha AND PC = anything    → WARN (unexpected alphabetic ending)
#   anything else              → WARN (digit, hyphen, em-dash, control char)
case "$LAST_CHAR" in
    '.'|'!'|'?')
        echo "  STATUS: PASS — terminal punctuation"
        ;;
    '"'|"'"|')'|']')
        case "$PREV_CHAR" in
            '.'|'!'|'?')
                echo "  STATUS: PASS — terminal punctuation (sentence-end inside close: '$PREV_CHAR$LAST_CHAR')"
                ;;
            *)
                echo "  STATUS: WARN — terminal punctuation: closing '$LAST_CHAR' without preceding sentence terminator (last 2: '$PREV_CHAR$LAST_CHAR')"
                WARN=1
                ;;
        esac
        ;;
    [A-Za-z])
        case "$PREV_CHAR" in
            [A-Za-z])
                echo "  STATUS: FAIL — terminal punctuation: mid-word truncation (last 2 chars: '$PREV_CHAR$LAST_CHAR')"
                FAIL=1
                ;;
            '.')
                echo "  STATUS: WARN — terminal punctuation: alphabetic '$LAST_CHAR' after '.' (possible truncated abbreviation)"
                WARN=1
                ;;
            *)
                echo "  STATUS: WARN — terminal punctuation: unexpected alphabetic ending '$LAST_CHAR' after '$PREV_CHAR'"
                WARN=1
                ;;
        esac
        ;;
    *)
        echo "  STATUS: WARN — terminal punctuation: non-standard terminator (last char: '$LAST_CHAR'; cosmetic, not a clear truncation)"
        WARN=1
        ;;
esac
printf "  Null bytes: %02d (trailing-only: %02d)\n" "$NULL_BYTES" "$TRAILING_NULLS"
# Refined null-byte classification (NULL_CLASS computed above):
#   none     → PASS
#   cosmetic → WARN (single trailing null after clean [.!?]\n terminator)
#   corrupt  → FAIL (everything else: embedded, multi-null, or trailing
#                    null without [.!?]\n preceding it)
case "$NULL_CLASS" in
    none)
        echo "  STATUS: PASS — null byte check"
        ;;
    cosmetic)
        echo "  STATUS: WARN — null byte check: 1 trailing null after clean sentence terminator (cosmetic, content intact)"
        WARN=1
        ;;
    corrupt)
        EMBEDDED_NULLS=$((NULL_BYTES - TRAILING_NULLS))
        if [ "$NULL_BYTES" -eq "$TRAILING_NULLS" ]; then
            echo "  STATUS: FAIL — null byte check: $TRAILING_NULLS trailing null(s) but tail does not match [.!?]\\n\\0 (treat as corruption, not cosmetic)"
        else
            echo "  STATUS: FAIL — null byte check: $EMBEDDED_NULLS embedded null byte(s) (file corrupted)"
        fi
        FAIL=1
        ;;
esac

echo ""
echo "=== SUMMARY ==="
echo "Words: $ACTUAL / $TARGET (${PCT}%) | File: ${FILE_SIZE}b | Null: $(printf '%02d' $NULL_BYTES) (trailing: $(printf '%02d' $TRAILING_NULLS))"
if [ "$FAIL" -eq 1 ]; then
    echo "STATUS: FAIL"
    exit 1
fi
if [ "$WARN" -eq 1 ]; then
    echo "STATUS: WARN"
    exit 0
fi
echo "STATUS: PASS"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
