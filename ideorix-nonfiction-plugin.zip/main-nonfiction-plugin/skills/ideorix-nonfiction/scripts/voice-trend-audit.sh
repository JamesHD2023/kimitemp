#!/bin/bash
# ============================================================
# Ideorix — Voice Trend Audit (v2.7.65)
# Cross-chapter author-voice drift detection. Reads the
# voice-metrics-ledger.md produced by voice-metrics-audit.sh,
# computes window-mean + slope of FP ratio over the last N
# chapters, and FAILS the pipeline when the boiled-frog drift
# pattern is detected.
#
# Why the per-chapter audit isn't enough:
#   A single chapter at FP=0.000 can be a legitimate
#   anchor-narrative anomaly (a research-heavy chapter, a
#   side-chapter on someone else's story). But Vol 2 of the
#   user's 6-book series shipped with 13 chapters at FP=0.000
#   and a series window-mean of 0.019. No single chapter
#   triggered alarm — each was "explainable" — but the
#   cumulative drift was catastrophic for the author-voice
#   contract. That's the shape this audit catches.
# ============================================================
# Usage: bash voice-trend-audit.sh <project-root> [<window-size>]
#
# Reads:
#   <project-root>/engine-data/reports/voice-metrics-ledger.md
#   <project-root>/engine-data/voice-profile.md      (optional)
#   <project-root>/engine-data/project-config.md     (opt-out)
#
# Window size defaults to 5. Trend audit short-circuits with
# INFO status until window-size chapters of data are in the
# ledger (the slope needs the data).
#
# FAIL conditions (any one):
#   - Window-mean FP ratio < (fp_target * 0.50)
#   - 3+ consecutive zero-FP chapters anywhere in the window
#   - Slope of FP ratio across window < -0.030 per chapter
#     (sustained downward drift)
#
# WARN conditions (any one, only if FAIL didn't trigger):
#   - Window-mean FP ratio < (fp_target * 0.75)
#   - 2 consecutive zero-FP chapters in the window
#   - Slope of FP ratio across window < -0.015 per chapter
#
# Honors opt-out: voice_trend_status: skip / legacy in
# engine-data/project-config.md.
#
# Exit codes:
#   0  trend within tolerance (PASS / WARN / INFO)
#   1  drift detected (FAIL)
#   2  invalid arguments / ledger missing

set -euo pipefail

PROJECT="${1:?Usage: voice-trend-audit.sh <project-root> [<window-size>]}"
WINDOW="${2:-5}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi
if ! [[ "$WINDOW" =~ ^[0-9]+$ ]] || [ "$WINDOW" -lt 2 ]; then
    echo "ERROR: window-size must be an integer >= 2 (got: $WINDOW)" >&2
    exit 2
fi

LEDGER="$PROJECT/engine-data/reports/voice-metrics-ledger.md"
VOICE_PROFILE="$PROJECT/engine-data/voice-profile.md"
CONFIG="$PROJECT/engine-data/project-config.md"

# Documented opt-out — projects that pre-date v2.7.65 or that
# deliberately skip voice-trend audit (e.g., reference / cookbook
# manuscripts where author-voice consistency is not a deliverable)
# can declare:
#   voice_trend_status: skip      (always-skip; informational only)
#   voice_trend_status: legacy    (legacy data; pass with note)
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*voice_trend_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "VOICE TREND AUDIT: PASS (project-config.md declares voice_trend_status: skip — documented opt-out honored)"
        exit 0
    fi
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*voice_trend_status:[[:space:]]*legacy\b' "$CONFIG"; then
        echo "VOICE TREND AUDIT: PASS (project-config.md declares voice_trend_status: legacy — pre-v2.7.65 data, audit skipped)"
        exit 0
    fi
fi

if [ ! -f "$LEDGER" ]; then
    echo "VOICE TREND AUDIT: INFO — voice-metrics-ledger.md not present at $LEDGER"
    echo "  Run voice-metrics-audit.sh per chapter (auto-wired into ideorix-audit.sh) to populate it."
    echo "STATUS: INFO"
    exit 0
fi

# Resolve target from voice-profile.md if present.
FP_TARGET="0.20"
if [ -f "$VOICE_PROFILE" ]; then
    val=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*fp_target:' "$VOICE_PROFILE" 2>/dev/null \
        | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*fp_target:[[:space:]]*//' \
        | awk '{print $1}' || true)
    if [ -n "$val" ]; then FP_TARGET="$val"; fi
fi

# Compute window statistics. Python handles the slope (linear
# regression on chapter index → fp_ratio) and the consecutive-zero
# scan cleanly.
RESULT=$(python3 - "$LEDGER" "$WINDOW" "$FP_TARGET" <<'PY'
import re
import sys

ledger_path = sys.argv[1]
window = int(sys.argv[2])
target = float(sys.argv[3])

# Ledger rows look like (v2.7.67 layout):
#   | timestamp | chapter | total_paras | fp_paras | fp_ratio |
#     sent_median | sent_mean | sent_max | fp_class | words |
#     semantic_fp_ratio | classifier_status |
# Column positions (after split on |, stripping the leading/trailing
# empty):
#   0=timestamp 1=chapter 2=total_paras 3=fp_paras 4=fp_ratio
#   5=sent_median 6=sent_mean 7=sent_max 8=fp_class 9=words
#   10=semantic_fp_ratio (v2.7.67; may be "N/A")
#   11=classifier_status (v2.7.67; ABSENT / FRESH / STALE / etc.)
# Pre-v2.7.67 rows have only columns 0-9; they parse fine with
# semantic_fp_ratio defaulted to None.
rows = []
with open(ledger_path, encoding="utf-8", errors="replace") as f:
    for line in f:
        line = line.strip()
        if not line.startswith("|"): continue
        # Skip header + separator rows.
        if line.startswith("| Timestamp"): continue
        if re.match(r"\|[\s\-|]+\|$", line): continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 5: continue
        try:
            fp_ratio = float(cells[4])
        except ValueError:
            continue
        semantic_fp = None
        if len(cells) >= 11:
            try:
                semantic_fp = float(cells[10])
            except ValueError:
                semantic_fp = None
        rows.append({"chapter": cells[1], "fp_ratio": fp_ratio, "semantic_fp": semantic_fp})

n = len(rows)
print(f"TOTAL_ROWS={n}")
if n < window:
    print(f"STATUS=INFO")
    print(f"REASON=insufficient data ({n} chapters in ledger, window={window})")
    sys.exit(0)

w = rows[-window:]

# v2.7.67: prefer semantic_fp_ratio when present for ≥3 chapters in
# the window (enough rows to build a meaningful trend signal). The
# threshold prevents flapping between semantic + syntactic across
# windows where the classifier has been run sporadically. Mixed
# windows fall back to syntactic to keep the comparison apples-to-
# apples within a single trend evaluation.
semantic_count = sum(1 for r in w if r["semantic_fp"] is not None)
if semantic_count >= 3 and semantic_count == window:
    ratios = [r["semantic_fp"] for r in w]
    signal = "semantic"
else:
    ratios = [r["fp_ratio"] for r in w]
    signal = "syntactic"
print(f"SIGNAL={signal}")
print(f"SEMANTIC_AVAILABLE={semantic_count}/{window}")

chapters_in_window = ", ".join(r["chapter"] for r in w)
mean = sum(ratios) / len(ratios)

# Slope: simple linear regression on x = [0..window-1], y = ratios.
xbar = (window - 1) / 2.0
ybar = mean
num = sum((i - xbar) * (ratios[i] - ybar) for i in range(window))
den = sum((i - xbar) ** 2 for i in range(window))
slope = num / den if den != 0 else 0.0

# Consecutive zeros scan (within window).
max_consec_zeros = 0
cur = 0
for r in ratios:
    if r == 0.0:
        cur += 1
        if cur > max_consec_zeros: max_consec_zeros = cur
    else:
        cur = 0

fail_threshold = target * 0.50
warn_threshold = target * 0.75

status = "PASS"
reasons = []

# FAIL conditions.
if mean < fail_threshold:
    status = "FAIL"
    reasons.append(f"window-mean FP ratio {mean:.4f} below FAIL threshold {fail_threshold:.4f} (target × 0.50)")
if max_consec_zeros >= 3:
    status = "FAIL"
    reasons.append(f"{max_consec_zeros} consecutive zero-FP chapters in window")
if slope < -0.030:
    status = "FAIL"
    reasons.append(f"slope {slope:.4f}/chapter below FAIL threshold -0.030 (sustained downward drift)")

# WARN conditions (only if no FAIL).
if status != "FAIL":
    if mean < warn_threshold:
        status = "WARN"
        reasons.append(f"window-mean FP ratio {mean:.4f} below WARN threshold {warn_threshold:.4f} (target × 0.75)")
    if max_consec_zeros >= 2:
        status = "WARN" if status == "PASS" else status
        reasons.append(f"{max_consec_zeros} consecutive zero-FP chapters in window")
    if slope < -0.015:
        status = "WARN" if status == "PASS" else status
        reasons.append(f"slope {slope:.4f}/chapter below WARN threshold -0.015")

print(f"STATUS={status}")
print(f"MEAN={mean:.4f}")
print(f"SLOPE={slope:.4f}")
print(f"MAX_CONSEC_ZEROS={max_consec_zeros}")
print(f"CHAPTERS={chapters_in_window}")
print(f"FAIL_THRESHOLD={fail_threshold:.4f}")
print(f"WARN_THRESHOLD={warn_threshold:.4f}")
for r in reasons:
    print(f"REASON={r}")
PY
)

STATUS=$(echo "$RESULT" | grep -E '^STATUS=' | head -1 | sed 's/^STATUS=//')
TOTAL_ROWS=$(echo "$RESULT" | grep -E '^TOTAL_ROWS=' | head -1 | sed 's/^TOTAL_ROWS=//')

echo "=== VOICE TREND AUDIT ==="
echo "Ledger:   $LEDGER"
echo "Window:   last $WINDOW chapters"
echo "Target:   FP ratio $FP_TARGET (FAIL <50%, WARN <75%)"
echo "Total rows in ledger: $TOTAL_ROWS"
echo ""

if [ "$STATUS" = "INFO" ]; then
    REASON=$(echo "$RESULT" | grep -E '^REASON=' | head -1 | sed 's/^REASON=//')
    echo "STATUS: INFO — $REASON"
    echo "(audit will graduate to PASS/WARN/FAIL once $WINDOW chapters of data exist)"
    exit 0
fi

MEAN=$(echo "$RESULT" | grep -E '^MEAN=' | head -1 | sed 's/^MEAN=//')
SLOPE=$(echo "$RESULT" | grep -E '^SLOPE=' | head -1 | sed 's/^SLOPE=//')
MAX_ZEROS=$(echo "$RESULT" | grep -E '^MAX_CONSEC_ZEROS=' | head -1 | sed 's/^MAX_CONSEC_ZEROS=//')
CHAPTERS=$(echo "$RESULT" | grep -E '^CHAPTERS=' | head -1 | sed 's/^CHAPTERS=//')
SIGNAL=$(echo "$RESULT" | grep -E '^SIGNAL=' | head -1 | sed 's/^SIGNAL=//')
SEM_AVAIL=$(echo "$RESULT" | grep -E '^SEMANTIC_AVAILABLE=' | head -1 | sed 's/^SEMANTIC_AVAILABLE=//')

echo "--- Window stats ---"
echo "  Signal:                  $SIGNAL  (semantic available for: $SEM_AVAIL chapters)"
echo "  Chapters:                $CHAPTERS"
echo "  Window-mean FP ratio:    $MEAN"
echo "  Slope (per chapter):     $SLOPE"
echo "  Max consecutive zeros:   $MAX_ZEROS"
echo ""

if [ "$STATUS" = "FAIL" ] || [ "$STATUS" = "WARN" ]; then
    echo "--- Findings ---"
    echo "$RESULT" | grep -E '^REASON=' | sed 's/^REASON=/  - /'
    echo ""
fi

case "$STATUS" in
    PASS)
        echo "STATUS: PASS — author-voice trend within tolerance"
        exit 0
        ;;
    WARN)
        echo "STATUS: WARN — early drift signal; review recent chapters before continuing"
        echo "  ACTION: read the affected chapters' opening + closing paragraphs against"
        echo "          voice-profile.md exemplars; if drift is real, restore first-person"
        echo "          register before chapter $((TOTAL_ROWS + 1))."
        exit 0
        ;;
    FAIL)
        echo "STATUS: FAIL — sustained voice drift detected (boiled-frog pattern)"
        echo ""
        echo "  ACTION: do NOT proceed to the next chapter until voice has been restored." >&2
        echo "  Restore options:" >&2
        echo "    1. Rewrite the drifted chapters from voice-profile.md exemplars" >&2
        echo "    2. If this is a research-heavy stretch (anchor narrative legitimately absent)," >&2
        echo "       document it: append to engine-data/project-config.md:" >&2
        echo "         voice_trend_status: skip" >&2
        echo "       (this disables the gate; only use when the drift is genuinely intended)" >&2
        echo "    3. If this is a legacy manuscript pre-dating v2.7.65 voice metrics," >&2
        echo "       append: voice_trend_status: legacy" >&2
        exit 1
        ;;
    *)
        echo "ERROR: unrecognised STATUS from analysis: $STATUS" >&2
        exit 2
        ;;
esac
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
