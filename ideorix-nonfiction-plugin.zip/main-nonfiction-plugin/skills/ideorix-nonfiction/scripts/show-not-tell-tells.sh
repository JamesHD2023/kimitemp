#!/usr/bin/env bash
# show-not-tell-tells.sh — flag physical-tell phrases used 2+ times in one chapter.
#
# Part of the SHOW NOT TELL canon-validation domain (v2.7.30).
# A "physical tell" is body-language description that signals an emotion
# (hands shook, jaw clenched, swallowed hard, eyes narrowed, etc.). When the
# same physical tell appears multiple times in a single chapter, the prose
# reads as either lazy repetition (one emotion repeatedly tagged with the
# same gesture) or muddled emotional mapping (one gesture used to signal
# different emotions). Both are SHOW NOT TELL violations the writer fixes
# by varying the body's vocabulary.
#
# Detection model (v2.7.30, intentionally simple):
#   - Pattern dictionary of ~30 common physical-tell phrases (regex-friendly,
#     case-insensitive)
#   - Per chapter: count matches per pattern; flag any pattern matched 2+ times
#   - Report flagged patterns with their matching line numbers
#
# Future refinement (deferred): emotion classification per match to detect
# "same physical tell, different emotion" specifically (currently any 2+
# match on the same physical-tell phrase is flagged regardless of emotion).
#
# Usage:
#   show-not-tell-tells.sh <chapter-file>
#
# Exit codes:
#   0 — chapter clean (no physical-tell repetition)
#   1 — one or more physical tells repeated 2+ times in this chapter
#   2 — usage / file-not-found error

set -uo pipefail

if [ $# -lt 1 ]; then
    echo "Usage: show-not-tell-tells.sh <chapter-file>" >&2
    exit 2
fi

CHAPTER="$1"

if [ ! -f "$CHAPTER" ]; then
    echo "ERROR: chapter file not found: $CHAPTER" >&2
    exit 2
fi

# Physical-tell patterns. Each entry is a regex matched case-insensitively
# with grep -niE. Word boundaries (\b) are added at match time. Patterns
# err on the side of canonical body-part-collocated phrasings to keep the
# false-positive rate manageable on first ship.
#
# v2.7.36 dictionary tightening:
#   - Dropped "lips parted" — fires on neutral romance / literary prose
#     ("her lips parted slightly to ask"); other lips patterns kept (they
#     carry inherent emotional valence).
#   - Dropped bare-verb patterns "flinched", "recoiled", "stiffened",
#     "shivered" — fired on non-character subjects ("the wind stiffened",
#     "the spring recoiled", "his resolve stiffened"). Catching person-
#     subject usage requires named-entity / pronoun context which a regex
#     dictionary cannot reliably express; the trade-off is missing some
#     real tells in exchange for a clean false-positive profile. A future
#     Class B refinement (semantic context check) can recover the lost
#     coverage.
PATTERNS=(
    # Hands / fingers / fists
    "hands? shook"
    "hands? trembled"
    "hands? (clenched|fisted)"
    "fingers? (curled|tightened|drummed|tapped|trembled|twitched)"
    "knuckles whitened"
    "fists? clenched"

    # Face / eyes / mouth
    "eyes (narrowed|widened|hardened|softened|flickered)"
    "jaw (clenched|tightened|set)"
    "lips? (pressed|tightened|thinned|trembled)"
    "brow furrowed"
    "cheeks (flushed|reddened|coloured|colored)"
    "face (paled|reddened|hardened|tightened)"
    "blinked (rapidly|hard)"

    # Torso / body
    "shoulders (sagged|tightened|stiffened|tensed|slumped)"
    "chest tightened"
    "stomach (clenched|knotted|dropped|lurched|churned)"
    "throat (tightened|closed|thickened)"
    "spine (stiffened|straightened)"

    # Breath
    "swallowed hard"
    "let out a (long )?breath"
    "sucked in a breath"
    "breath caught"
    "sharp intake of breath"
    "exhaled (slowly|sharply)"
)

echo "=== SHOW NOT TELL: physical-tell repetition ==="
echo "Chapter: $(basename "$CHAPTER")"
echo

flag_count=0
total_chapter_repetitions=0

for pat in "${PATTERNS[@]}"; do
    # Match with word boundaries; case-insensitive.
    # v2.7.40 fix: count actual occurrences (grep -oE) rather than
    # matching-line count. Pre-v2.7.40 used wc -l on -niE output, so
    # two repetitions of the same physical tell within a single
    # markdown paragraph line ("He swallowed hard. He swallowed hard.")
    # counted as 1 not 2 — real chapters often have multi-sentence
    # paragraphs on a single line and the audit silently missed
    # repetition there. The line-form match (-niE) is still used for
    # the user-facing display so the writer sees the chapter line
    # context, but the count is now grep -oE | wc -l.
    matches="$(grep -niE "\\b${pat}\\b" "$CHAPTER" 2>/dev/null || true)"
    if [ -z "$matches" ]; then
        continue
    fi
    count="$(grep -oiE "\\b${pat}\\b" "$CHAPTER" 2>/dev/null | wc -l | tr -d ' ')"
    if [ "$count" -lt 2 ]; then
        continue
    fi

    flag_count=$((flag_count + 1))
    total_chapter_repetitions=$((total_chapter_repetitions + count))
    echo "FLAGGED: \"$pat\" matched $count times"
    # Show up to first 6 matching lines for context, indented.
    printf '%s\n' "$matches" | head -6 | sed 's/^/  /'
    if [ "$count" -gt 6 ]; then
        echo "  ... and $((count - 6)) more"
    fi
    echo
done

if [ "$flag_count" -eq 0 ]; then
    echo "[PASS] no physical-tell repetition detected"
    exit 0
else
    echo "[FAIL] $flag_count physical-tell pattern(s) repeated in this chapter ($total_chapter_repetitions total occurrences)"
    echo
    echo "Fix: vary the body's vocabulary. The same gesture for the same"
    echo "emotion twice is repetition; the same gesture for two different"
    echo "emotions is muddled mapping. Both are SHOW NOT TELL violations."
    exit 1
fi
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
