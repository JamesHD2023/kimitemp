#!/bin/bash
# ============================================================
# Ideorix Non-Fiction Mechanical Audit — Manuscript Audit
# Runs per-chapter scans across the full manuscript, aggregates.
# ============================================================
# Usage: bash manuscript-audit.sh <project-root>

set -euo pipefail

PROJECT="${1:?Usage: manuscript-audit.sh <project-root>}"
if [ ! -d "$PROJECT" ]; then echo "ERROR: Project folder not found: $PROJECT"; exit 1; fi

CHAPTERS_DIR="$PROJECT/engine-data/chapters"
if [ ! -d "$CHAPTERS_DIR" ]; then
    echo "ERROR: Chapters folder not found: $CHAPTERS_DIR" >&2
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

CHAPTER_FILES=$(ls "$CHAPTERS_DIR"/ch[0-9][0-9].md 2>/dev/null | sort)
if [ -z "$CHAPTER_FILES" ]; then
    echo "ERROR: No chapter files found in $CHAPTERS_DIR" >&2
    exit 1
fi

echo "=== MANUSCRIPT AUDIT (Non-Fiction) ==="
echo "Project: $PROJECT"
echo "Chapters: $(echo "$CHAPTER_FILES" | wc -l)"
echo ""

TOTAL_WORDS=0
TOTAL_FAIL=0

printf "%-10s %8s %8s %8s %8s %8s\n" "Chapter" "Words" "T1+T2" "T3" "Pattern" "Status"
printf "%-10s %8s %8s %8s %8s %8s\n" "-------" "-----" "-----" "---" "-------" "------"

for chapter in $CHAPTER_FILES; do
    if [ ! -r "$chapter" ]; then
        echo "ERROR: chapter not readable: $chapter" >&2
        exit 1
    fi

    CH_NAME=$(basename "$chapter" .md)
    WORDS=$(awk 'BEGIN{fm=0} /^---$/{fm++; next} fm==1{next} {print}' "$chapter" | wc -w)
    TOTAL_WORDS=$((TOTAL_WORDS + WORDS))

    T12=0
    T3=0
    PATTERN_FAIL=0

    # Run forbidden-words if list present
    # v2.7.50: added engine-fallback so audits work on projects without
    # a local override copy. Pre-v2.7.50 FORBIDDEN could stay empty even
    # though the engine ships forbidden-words.md.
    FORBIDDEN=""
    [ -f "$PROJECT/engine-data/forbidden-words.md" ] && FORBIDDEN="$PROJECT/engine-data/forbidden-words.md"
    [ -f "$PROJECT/forbidden-words.md" ] && FORBIDDEN="$PROJECT/forbidden-words.md"
    [ -z "$FORBIDDEN" ] && [ -f "$SCRIPT_DIR/../references/forbidden-words.md" ] \
        && FORBIDDEN="$SCRIPT_DIR/../references/forbidden-words.md"

    if [ -n "$FORBIDDEN" ]; then
        OUT=$(bash "$SCRIPT_DIR/forbidden-words-scan.sh" "$chapter" "$FORBIDDEN" 2>/dev/null || true)
        T12=$(echo "$OUT" | grep -cE "^  VIOLATION" || true)
        T12=$(echo "$T12" | tr -dc '0-9'); [ -z "$T12" ] && T12=0
        T12=$(echo "$T12" | tr -dc '0-9'); [ -z "$T12" ] && T12=0
        T3=$(echo "$OUT" | grep -cE "^  OVERUSE" || true)
        T3=$(echo "$T3" | tr -dc '0-9'); [ -z "$T3" ] && T3=0
        T3=$(echo "$T3" | tr -dc '0-9'); [ -z "$T3" ] && T3=0
    fi

    # Pattern-counter emits per-pattern FAIL lines plus one summary "STATUS: FAIL" line.
    # Count per-pattern fails only (those end with FAIL or "FAIL (n/n)" — the summary
    # "STATUS: FAIL" doesn't match this anchor).
    PATTERN_OUT=$(bash "$SCRIPT_DIR/pattern-counter.sh" "$chapter" 2>/dev/null || true)
    PATTERN_FAIL_RAW=$(echo "$PATTERN_OUT" | grep -cE 'FAIL$|FAIL \([0-9]+/[0-9]+\)' || true)
    PATTERN_FAIL_RAW=$(echo "$PATTERN_FAIL_RAW" | tr -dc '0-9'); [ -z "$PATTERN_FAIL_RAW" ] && PATTERN_FAIL_RAW=0
    PATTERN_FAIL="$PATTERN_FAIL_RAW"
    PATTERN_FAIL=$(echo "$PATTERN_FAIL" | tr -dc '0-9'); [ -z "$PATTERN_FAIL" ] && PATTERN_FAIL=0

    STATUS="PASS"
    if [ "$T12" -gt 0 ] || [ "$PATTERN_FAIL" -gt 0 ]; then
        STATUS="FAIL"
        TOTAL_FAIL=1
    elif [ "$T3" -gt 0 ]; then
        STATUS="WARN"
    fi

    printf "%-10s %8s %8s %8s %8s %8s\n" "$CH_NAME" "$WORDS" "$T12" "$T3" "$PATTERN_FAIL" "$STATUS"
done

echo ""
echo "=== MANUSCRIPT TOTAL ==="
echo "Total words: $TOTAL_WORDS"
if [ "$TOTAL_FAIL" -eq 1 ]; then
    echo "STATUS: FAIL — at least one chapter has Tier 1/2 or Pattern violations"
    exit 1
fi
echo "STATUS: PASS"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
