#!/bin/bash
# ============================================================
# Ideorix Non-Fiction Mechanical Audit — Entity Canon Verify
# NF: checks proper nouns (figures, sources, institutions, places)
# against the project's entity-canon.md lockfile.
# ============================================================
# Usage: bash entity-canon-verify.sh <chapter-file> <project-root>

set -euo pipefail

CHAPTER="${1:?Usage: entity-canon-verify.sh <chapter-file> <project-root>}"
PROJECT="${2:?Usage: entity-canon-verify.sh <chapter-file> <project-root>}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

CANON="$PROJECT/engine-data/entity-canon.md"
if [ ! -f "$CANON" ]; then
    echo "=== ENTITY CANON VERIFY (skipped) ==="
    echo "  N/A — no entity-canon.md found at $CANON"
    echo "  NF projects should maintain entity-canon.md with figures, sources, institutions, places."
    exit 0
fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

echo "=== ENTITY CANON VERIFY (Non-Fiction) ==="
echo "Chapter: $CHAPTER"
echo "Canon: $CANON"
echo ""

# Build authorised-name set from entity-canon.md
# Parse markdown tables — read only Canonical (col 2) and Aliases (col 3), skip header + separator.
awk -F'|' '
    NR==1 || /^[[:space:]]*\|[-:[:space:]|]+\|[[:space:]]*$/ { next }
    tolower($0) ~ /\|[[:space:]]*canonical[[:space:]]*\|/ { next }
    NF>=3 {
        gsub(/^ +| +$/, "", $2); gsub(/^ +| +$/, "", $3);
        if ($2 != "" && tolower($2) != "canonical") print tolower($2)
        if ($3 != "") {
            n = split($3, a, /, */)
            for (i=1; i<=n; i++) {
                gsub(/^ +| +$/, "", a[i])
                if (a[i] != "" && tolower(a[i]) != "aliases") print tolower(a[i])
            }
        }
    }
' "$CANON" | sort -u > "$TMPDIR/authorised.txt"

# Load real-world entities allowlist (cities, brands, public bodies, document
# field labels, languages, demonyms, calendar / clock terms, currency, well-
# known historical names). The allowlist ships with the plugin and is
# loaded alongside the project's entity-canon.md so that real-world
# capitalised tokens that legitimately appear in chapter prose are not
# flagged as canon drift (Cowork bug report 2026-05-01).
ALLOWLIST="$(dirname "$0")/../references/allowed-real-world-entities.md"
ALLOWLIST_LOADED=0
if [ -f "$ALLOWLIST" ]; then
    awk '
        /^---/ || /^#/ || /^>/ || /^</ { next }
        /^\s*$/ { next }
        {
            n = split($0, words, /[[:space:],.;:()"\[\]]+/)
            for (i = 1; i <= n; i++) {
                w = words[i]
                if (w ~ /^[A-Z][a-zA-Z]+$/) print tolower(w)
            }
        }
    ' "$ALLOWLIST" >> "$TMPDIR/authorised.txt"
    ALLOWLIST_LOADED=1
fi
sort -u -o "$TMPDIR/authorised.txt" "$TMPDIR/authorised.txt"

# Canon state marker. When canon is still being built (e.g. before the
# Ch10 batch-editor checkpoint), the project can mark it `expanding` so
# per-chapter drift surfaces as WARN rather than FAIL — drift entries
# represent new entities awaiting canon expansion, not violations.
# Default (no marker, or any other value) is `locked` = strict / current
# behavior. Marker format: a line in the first 10 of the canon file
# matching `<!-- canon-state: expanding -->`.
CANON_STATE="locked"
if head -10 "$CANON" | grep -qiE '<!--[[:space:]]*canon-state:[[:space:]]*expanding'; then
    CANON_STATE="expanding"
fi

AUTH_COUNT=$(wc -l < "$TMPDIR/authorised.txt")
if [ "$ALLOWLIST_LOADED" -eq 1 ]; then
    echo "Authorised names/aliases loaded: $AUTH_COUNT (project canon + real-world allowlist)"
else
    echo "Authorised names/aliases loaded: $AUTH_COUNT"
fi
echo "Canon state: $CANON_STATE"

# Strip appendix content from the chapter before extracting proper nouns.
# Reference tables (chemical additives, ingredient lists), bibliographic
# entries, glossaries, and other lookup-style appendix content flood the
# candidate list with hundreds of false positives that have nothing to do
# with the prose. Stop at the first heading that begins with '# Appendix'
# (any heading depth, case-insensitive). Authors with non-standard appendix
# labels can rename them or split appendix content to a separate file.
APPENDIX_LINE=$(awk 'tolower($0) ~ /^#+[[:space:]]*appendix/ { print NR; exit }' "$CHAPTER")
if [ -n "$APPENDIX_LINE" ]; then
    head -n $((APPENDIX_LINE - 1)) "$CHAPTER" > "$TMPDIR/body.txt"
    echo "Appendix detected at line $APPENDIX_LINE — content below excluded from canon scan"
else
    cp "$CHAPTER" "$TMPDIR/body.txt"
fi

# Pre-process the chapter: skip endnote-list lines, strip italicised spans,
# strip footnote citation markers, and remove sentence-starter capitals
# before extracting proper-noun candidates. Reduces false positives from:
#   - endnote sections (e.g. "[1] Hall et al., Cell Metabolism...")
#   - italicised journal/work titles (*American Journal of...*)
#   - inline citation markers ([1], [2-4], [12,17])
#   - sentence-starter capitals that aren't proper nouns ("By the way...")
#   - paragraph-start, dialogue-open, and multi-word sentence-start cases
#     that the prior single-line s/// missed (Cowork bug report 2026-05-01),
#     filtered through a stoplist of common pronouns / question-words /
#     temporal markers / structural words.
perl -e '
    use strict;
    use warnings;
    my $text = "";
    while (my $line = <STDIN>) {
        next if $line =~ /^#/;                      # skip markdown headings
        next if $line =~ /^\[\d+(?:[-,]\d+)*\]/;    # skip endnote-list lines
        $line =~ s/\*[^*]*\*//g;                    # strip *italic* spans
        $line =~ s/_[^_]*_//g;                      # strip _italic_ spans
        $line =~ s/\[\d+(?:[-,]\d+)*\]//g;          # strip inline footnote markers
        $text .= $line;
    }

    # Strip sentence-starting capitalised words (after . ! ? or at document start).
    $text =~ s/(?:^|(?<=[.!?])\s+)([A-Z][a-z]+)/ STRIPPED /g;

    # Strip dialogue-opening capitalised words: "Word
    $text =~ s/"([A-Z][a-z]+)/" STRIPPED /g;

    # Strip paragraph-start capitals (after a blank line).
    $text =~ s/(\n\n+)([A-Z][a-z]+)/$1STRIPPED/g;

    # Extract remaining capitalised tokens (single word or multi-word names)
    my %seen;
    while ($text =~ /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g) {
        my $tok = $1;
        next if length($tok) < 2;
        $seen{$tok}++;
    }

    # Stoplist for sentence-starters that slipped through
    my @stoplist = qw(
        The This That These Those There They Their Them
        He She His Her Hers Him
        It Its
        I We You Your Yours Our Ours
        Now Then When Where Why How What Which Who Whom Whose
        Yes No Maybe Sure Right Help OK Okay Hello Hi Hey
        And But Or So Yet Nor For
        After Before Until While Since Although Though If Unless
        Did Do Does Done Tell Told Said Say Says
        Something Someone Somewhere Anything Anyone Anywhere
        Nothing Nobody Nowhere Everything Everyone Everywhere
        Today Yesterday Tomorrow Tonight
        Chapter Part Book Volume Section Page
        Mr Mrs Miss Ms Dr Sir Madam Lord Lady
    );
    my %stop = map { $_ => 1 } @stoplist;

    for my $name (sort keys %seen) {
        next if $stop{$name};
        print "$name\n";
    }
' < "$TMPDIR/body.txt" | grep -v '^$' | sort -u > "$TMPDIR/candidates.txt"

CAND_COUNT=$(wc -l < "$TMPDIR/candidates.txt")
echo "Proper-noun candidates found: $CAND_COUNT"

echo ""
echo "--- Canon Compliance ---"
DRIFT_COUNT=0
while IFS= read -r name; do
    lower_name=$(echo "$name" | tr '[:upper:]' '[:lower:]')

    # Common-word fast path (months, days, honorifics, NF abbreviations).
    case "$lower_name" in
        january|february|march|april|may|june|july|august|september|october|november|december) continue ;;
        monday|tuesday|wednesday|thursday|friday|saturday|sunday) continue ;;
        the|and|but|not|she|her|his|him|they|them|was|were|had|has|have) continue ;;
        mrs|mr|miss|dr|sir|saint|st|prof|professor) continue ;;
        # NF common false positives: country/region acronyms valid without canon entry
        us|usa|uk|eu|uns|nato|un|oecd|nhs|cdc|fda|who) continue ;;
        # Common units/abbreviations
        km|mph|kph|kg|lb|ft|cm|mm|bc|ad|ce|bce) continue ;;
    esac

    # Whole-name lookup. Substring-match (grep -qF) so extracted partial
    # names match longer canon entries (e.g. extracted "National Institutes"
    # matches canon "National Institutes of Health" because "of" / "the" /
    # "and" are lowercase function words the proper-noun extractor stops
    # on). False-positive risk (shorter name appearing inside longer canon
    # entry) is acceptable: in practice the shorter name IS the legitimate
    # reference to the longer entity.
    if grep -qF "$lower_name" "$TMPDIR/authorised.txt" 2>/dev/null; then
        continue
    fi

    # Multi-word fallback: a multi-word candidate (e.g. "Companies House",
    # "Manchester Piccadilly") is allowed if EVERY word is in the authorised
    # set. Handles real-world institutions, places, public bodies.
    if [[ "$lower_name" == *" "* ]]; then
        all_words_authorised=1
        for word in $lower_name; do
            if ! grep -qFx "$word" "$TMPDIR/authorised.txt" 2>/dev/null; then
                all_words_authorised=0
                break
            fi
        done
        if [ "$all_words_authorised" -eq 1 ]; then
            continue
        fi

        # Street / infrastructure suffix pattern: "Wilmslow Road",
        # "Brunswick Street", "Plymouth Grove" — accept any "Word Suffix"
        # form where Suffix is a recognised infrastructure / address term.
        last_word="${lower_name##* }"
        case "$last_word" in
            road|street|avenue|lane|drive|crescent|close|square|terrace|hill|mews|gardens|place|way|walk|park|common|green|bridge|station|junction|roundabout|motorway|bypass|highway|grove|court|gate|view|fields|meadow|estate|circus|row|rise|wynd|brae|loan|vennel|pend|wharf|quay|embankment|parade|broadway|boulevard) continue ;;
        esac
    fi

    echo "  DRIFT: \"$name\" — not in entity canon"
    DRIFT_COUNT=$((DRIFT_COUNT + 1))
done < "$TMPDIR/candidates.txt"

[ "$DRIFT_COUNT" -eq 0 ] && echo "  CLEAN — all proper nouns in canon"

echo ""
echo "=== SUMMARY ==="
echo "Authorised names: $AUTH_COUNT | Candidates: $CAND_COUNT | Drift: $DRIFT_COUNT | State: $CANON_STATE"
if [ "$DRIFT_COUNT" -gt 0 ]; then
    if [ "$CANON_STATE" = "expanding" ]; then
        echo "STATUS: WARN — $DRIFT_COUNT proper noun(s) not yet in canon (canon-state: expanding)"
        echo "Action: drift items above represent new entities awaiting canon expansion. They will need to be added (or fixed if typos) at the canon-lock checkpoint."
        exit 0
    fi
    echo "STATUS: FAIL — $DRIFT_COUNT proper nouns not in entity canon"
    echo "Action: add to entity-canon.md, or fix typo in chapter, or update chapter to use canonical form."
    exit 1
fi
echo "STATUS: PASS"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
