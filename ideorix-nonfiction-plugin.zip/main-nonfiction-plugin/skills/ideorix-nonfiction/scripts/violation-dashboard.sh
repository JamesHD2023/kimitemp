#!/bin/bash
# ============================================================
# Ideorix Non-Fiction Mechanical Audit — Violation Dashboard
# Per-chapter unified dashboard. Runs all 8 audit modules and
# reports each separately so users see the full picture.
# ============================================================
# Usage: bash violation-dashboard.sh <project-root> <chapter-number>

set -euo pipefail

PROJECT="${1:?Usage: violation-dashboard.sh <project-root> <chapter-number>}"
CHAPTER_N="${2:?Usage: violation-dashboard.sh <project-root> <chapter-number>}"

# Allow chapter-number to be either bare ("12") or zero-padded ("ch12" / "12")
CN_DIGITS=$(echo "$CHAPTER_N" | tr -dc '0-9')
if [ -z "$CN_DIGITS" ]; then
    echo "ERROR: chapter number must contain digits: '$CHAPTER_N'" >&2
    exit 1
fi
CHAPTER_FILE="$PROJECT/engine-data/chapters/ch$(printf '%02d' "$CN_DIGITS").md"

FORBIDDEN=""
[ -f "$PROJECT/engine-data/forbidden-words.md" ] && FORBIDDEN="$PROJECT/engine-data/forbidden-words.md"
[ -f "$PROJECT/forbidden-words.md" ]      && FORBIDDEN="$PROJECT/forbidden-words.md"

if [ ! -f "$CHAPTER_FILE" ]; then
    echo "ERROR: Chapter file not found: $CHAPTER_FILE" >&2
    exit 1
fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# v2.7.50: added engine-fallback so audits work on projects without
# a local override copy. Pre-v2.7.50 FORBIDDEN could stay empty even
# though the engine ships forbidden-words.md.
[ -z "$FORBIDDEN" ] && [ -f "$SCRIPT_DIR/../references/forbidden-words.md" ] \
    && FORBIDDEN="$SCRIPT_DIR/../references/forbidden-words.md"

clean_int() { echo "${1:-0}" | tr -dc '0-9' | head -c 10; }

# Helper: extract a number from a labelled output line. Survives no-match
# under set -euo pipefail by wrapping the pipeline in { ... } || true.
extract_number() {
    local input="$1" pattern="$2"
    local result
    result=$({ echo "$input" | grep -E "$pattern" | grep -oE '[0-9]+' | head -1; } || true)
    clean_int "${result:-0}"
}

WORDS=$(awk 'BEGIN{fm=0} /^---$/{fm++; next} fm==1{next} {print}' "$CHAPTER_FILE" | wc -w)

# --- Forbidden words (Tier 1, Tier 2 zero-tolerance + Tier 3 overuse) ---
T1_T2=0
T3=0
if [ -n "$FORBIDDEN" ]; then
    OUT=$(bash "$SCRIPT_DIR/forbidden-words-scan.sh" "$CHAPTER_FILE" "$FORBIDDEN" 2>/dev/null || true)
    T1_T2=$(extract_number "$OUT" '^Tier 1 violations:')
    T2_RAW=$(extract_number "$OUT" 'Tier 2:')
    T3=$(extract_number "$OUT" 'Tier 3 overuse:')
    T1_T2=$((T1_T2 + T2_RAW))
fi

# --- Pattern counter (zero-tolerance + frequency-limited fails) ---
P_OUT=$(bash "$SCRIPT_DIR/pattern-counter.sh" "$CHAPTER_FILE" 2>/dev/null || true)
PATTERN_FAILS=$({ echo "$P_OUT" | grep -cE 'FAIL$|FAIL \([0-9]+/[0-9]+\)'; } || true)
PATTERN_FAILS=$(clean_int "${PATTERN_FAILS:-0}")

# --- Placeholder scan (numeric count, not binary) ---
PH_OUT=$(bash "$SCRIPT_DIR/placeholder-scan.sh" "$CHAPTER_FILE" 2>/dev/null || true)
PLACEHOLDERS=$(extract_number "$PH_OUT" 'Total placeholder indicators:')

# --- Formatting (em-dash + ellipsis + exclamation + sentence starters) ---
F_OUT=$(bash "$SCRIPT_DIR/formatting-check.sh" "$CHAPTER_FILE" 2>/dev/null || true)
FORMATTING_FAILS=$({ echo "$F_OUT" | grep -cE '^  STATUS: FAIL'; } || true)
FORMATTING_FAILS=$(clean_int "${FORMATTING_FAILS:-0}")

# --- Word count ---
WC_TARGET="${3:-2500}"
WC_OUT=$(bash "$SCRIPT_DIR/word-count-check.sh" "$CHAPTER_FILE" "$WC_TARGET" 2>/dev/null || true)
WC_PCT=$({ echo "$WC_OUT" | grep -E 'published target:' | tail -1 | grep -oE '[0-9]+%' | head -1; } || true)

# --- Number-7 bias ---
N7_OUT=$(bash "$SCRIPT_DIR/number-7-bias.sh" "$CHAPTER_FILE" 2>/dev/null || true)
N7_STATUS=$({ echo "$N7_OUT" | grep -E '^STATUS:' | tail -1 | awk '{print $2}'; } || true)

# --- Entity canon ---
EC_OUT=$(bash "$SCRIPT_DIR/entity-canon-verify.sh" "$CHAPTER_FILE" "$PROJECT" 2>/dev/null || true)
EC_STATUS=$({ echo "$EC_OUT" | grep -E '^STATUS:' | tail -1 | awk '{print $2}'; } || true)
EC_DRIFT=$(extract_number "$EC_OUT" 'Drift:')

# --- Temporal verify (opt-in) ---
TV_OUT=$(bash "$SCRIPT_DIR/temporal-verify.sh" "$CHAPTER_FILE" "$PROJECT" 2>/dev/null || true)
TV_STATUS=$({ echo "$TV_OUT" | grep -E '^STATUS:' | tail -1 | awk '{print $2}'; } || true)
[ -z "$TV_STATUS" ] && TV_STATUS="N/A"

# Aggregate worst status
OVERALL="PASS"
[ "$T1_T2" -gt 0 ]            && OVERALL="FAIL"
[ "$PATTERN_FAILS" -gt 0 ]    && OVERALL="FAIL"
[ "$PLACEHOLDERS" -gt 0 ]     && OVERALL="FAIL"
[ "$FORMATTING_FAILS" -gt 0 ] && OVERALL="FAIL"
[ "$N7_STATUS" = "FAIL" ]     && OVERALL="FAIL"
[ "$EC_STATUS" = "FAIL" ]     && OVERALL="FAIL"
[ "$TV_STATUS" = "FAIL" ]     && OVERALL="FAIL"
# T3 overuse downgrades to WARN if no other fails
[ "$OVERALL" = "PASS" ] && [ "$T3" -gt 0 ] && OVERALL="WARN"

CHAPTER_LABEL="ch$(printf '%02d' "$CN_DIGITS")"

echo "=== NF VIOLATION DASHBOARD — Chapter $CN_DIGITS ($CHAPTER_LABEL) ==="
echo ""
echo "| Metric                        | Count    | Status |"
echo "|-------------------------------|----------|--------|"
printf "| Word count                    | %-8s | %s |\n" "$WORDS / $WC_TARGET (${WC_PCT:-?})" "INFO"
printf "| Forbidden T1+T2 violations    | %-8s | %s |\n" "$T1_T2"            "$([ "$T1_T2" -eq 0 ] && echo CLEAN || echo FAIL)"
printf "| Forbidden T3 overuse          | %-8s | %s |\n" "$T3"               "$([ "$T3" -eq 0 ] && echo CLEAN || echo WARN)"
printf "| Pattern violations            | %-8s | %s |\n" "$PATTERN_FAILS"    "$([ "$PATTERN_FAILS" -eq 0 ] && echo CLEAN || echo FAIL)"
printf "| Placeholders                  | %-8s | %s |\n" "$PLACEHOLDERS"     "$([ "$PLACEHOLDERS" -eq 0 ] && echo CLEAN || echo FAIL)"
printf "| Formatting fails              | %-8s | %s |\n" "$FORMATTING_FAILS" "$([ "$FORMATTING_FAILS" -eq 0 ] && echo CLEAN || echo FAIL)"
printf "| Number-7 bias                 | %-8s | %s |\n" "—"                 "${N7_STATUS:-N/A}"
printf "| Entity canon drift            | %-8s | %s |\n" "$EC_DRIFT"         "${EC_STATUS:-N/A}"
printf "| Temporal scope                | %-8s | %s |\n" "—"                 "${TV_STATUS:-N/A}"
echo "|-------------------------------|----------|--------|"
printf "| OVERALL                       | %-8s | %s |\n" ""                  "$OVERALL"
echo ""
echo "Module outputs available at engine-data/audit/${CHAPTER_LABEL}-*.txt"

[ "$OVERALL" = "FAIL" ] && exit 1
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
