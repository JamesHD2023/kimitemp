#!/bin/bash
# ============================================================
# Ideorix — Source Canon Grounding Gate (v2.7.77)
# Verifies that the orchestrator's claim of having read source
# canon files is grounded in the current file content — not in
# stale session memory and not in fabricated samples.
#
# Addresses a failure mode distinct from read-verification.md
# (which catches "Read tool returned empty content"):
#
#   read-verification.md         : the file was read but returned no bytes
#   source-canon-grounding (this): the file was read but the orchestrator
#                                  is now generating downstream content
#                                  from vague session memory rather than
#                                  from the actual file content
#
# Real user incident (2026-05-17): orchestrator was asked to produce
# an outline from worldbuilding files. Orchestrator generated the
# outline from prior-session surface knowledge. User caught the
# inconsistency, asked "did you actually read the worldbuilding?",
# orchestrator admitted: "No, I generated from memory." The outline
# was unusable and the user had to throw away the work and the
# downstream chapter draft.
#
# This gate makes the orchestrator's "I read it" claim falsifiable.
# Before generating outline / bible / dependent content, the
# orchestrator must produce an artifact at:
#   engine-data/reports/source-canon-grounding.yaml
# declaring, for each source file:
#   - current sha256 (proves grounding is in this version, not stale)
#   - 3+ verbatim quoted samples (proves the orchestrator has the
#     actual content available, not just paraphrase)
#
# The gate verifies:
#   - Artifact exists
#   - Each declared source's sha256 matches current file sha256
#   - Each verbatim sample IS a substring of the source file
#     (catches fabrication — paraphrased "quotes" don't match)
# ============================================================
# Usage: bash source-canon-grounding-gate.sh <project-root>
#
# A project passes when:
#   - engine-data/project-config.md does NOT declare
#     source_canon_grounding: enable  (opt-in; skipped by default
#     so existing projects are not affected), OR
#   - engine-data/reports/source-canon-grounding.yaml exists, is
#     well-formed, and every declared source verifies:
#       (a) source file exists on disk
#       (b) current sha256 matches the declared sha256
#       (c) artifact has >=3 verbatim_samples for the source
#       (d) every verbatim_sample is a substring of the source file
#
# Exit codes:
#   0  PASS or SKIPPED (project not opted in)
#   1  FAIL (artifact missing / sha256 stale / fabricated samples /
#      sample count below threshold)
#   2  invalid arguments

set -uo pipefail

if [ $# -lt 1 ]; then
    echo "Usage: source-canon-grounding-gate.sh <project-root>" >&2
    exit 2
fi

PROJECT="$1"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

CONFIG="$PROJECT/engine-data/project-config.md"
ARTIFACT="$PROJECT/engine-data/reports/source-canon-grounding.yaml"

# Opt-in / opt-out honoring.
# v2.7.78: explicit 'legacy' value gets its own diagnostic so users know
# the skip is intentional (vs. "no flag set" which is the default skip).
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*source_canon_grounding:[[:space:]]*legacy\b' "$CONFIG"; then
        echo "SOURCE CANON GROUNDING GATE: SKIPPED (project-config.md declares 'source_canon_grounding: legacy' — pre-v2.7.77 project, opt-out honored)"
        exit 0
    fi
    if ! grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*source_canon_grounding:[[:space:]]*enable\b' "$CONFIG"; then
        echo "SOURCE CANON GROUNDING GATE: SKIPPED (project-config.md does not declare 'source_canon_grounding: enable' — see references/source-canon-grounding.md to enable for canon-grounded projects)"
        exit 0
    fi
else
    # No config file at all -> not opted in
    echo "SOURCE CANON GROUNDING GATE: SKIPPED (no project-config.md; opt-in not declared)"
    exit 0
fi

if [ ! -f "$ARTIFACT" ]; then
    echo "SOURCE CANON GROUNDING GATE: FAIL -- grounding artifact missing" >&2
    echo "  Expected: $ARTIFACT" >&2
    echo "" >&2
    echo "  ACTION: the orchestrator must produce this artifact AFTER reading" >&2
    echo "  source canon files and BEFORE generating outline/bible/dependent" >&2
    echo "  content. See references/source-canon-grounding.md for the format." >&2
    exit 1
fi

# Delegate to python3 for YAML-ish parsing + substring verification.
python3 - "$PROJECT" "$ARTIFACT" <<'PYTHON'
import sys
import hashlib
import re
from pathlib import Path

project_root = Path(sys.argv[1]).resolve()
artifact = Path(sys.argv[2])

try:
    content = artifact.read_text(encoding='utf-8')
except Exception as e:
    print(f"SOURCE CANON GROUNDING GATE: FAIL -- could not read artifact: {e}", file=sys.stderr)
    sys.exit(1)

# Minimal YAML-shape parser for the source-canon-grounding format.
# Avoids a pyyaml dependency; the format is constrained (see spec).
#
# Expected shape:
#   generated_at: <iso>
#   sources:
#     - file: <relpath>
#       sha256: <hex>
#       word_count: <int>
#       verbatim_samples:
#         - "..."
#         - "..."
#         - "..."

sources = []
current = None
in_samples = False

for line in content.splitlines():
    if re.match(r'^\s*-\s*file:\s*(.+?)\s*$', line):
        m = re.match(r'^\s*-\s*file:\s*(.+?)\s*$', line)
        if current is not None:
            sources.append(current)
        val = m.group(1).strip().strip('"').strip("'")
        current = {'file': val, 'sha256': None, 'word_count': None, 'verbatim_samples': []}
        in_samples = False
    elif current is not None and re.match(r'^\s+sha256:\s*(.+?)\s*$', line):
        m = re.match(r'^\s+sha256:\s*(.+?)\s*$', line)
        current['sha256'] = m.group(1).strip().strip('"').strip("'")
        in_samples = False
    elif current is not None and re.match(r'^\s+word_count:\s*(\d+)\s*$', line):
        m = re.match(r'^\s+word_count:\s*(\d+)\s*$', line)
        current['word_count'] = int(m.group(1))
        in_samples = False
    elif current is not None and re.match(r'^\s+verbatim_samples:\s*$', line):
        in_samples = True
    elif current is not None and in_samples:
        m = re.match(r'^\s+-\s+"(.+)"\s*$', line)
        if m:
            current['verbatim_samples'].append(m.group(1))
            continue
        m2 = re.match(r"^\s+-\s+'(.+)'\s*$", line)
        if m2:
            current['verbatim_samples'].append(m2.group(1))
            continue
        # Allow unquoted single-line samples too, conservatively
        m3 = re.match(r'^\s+-\s+(.+?)\s*$', line)
        if m3 and not line.strip().startswith('- file:'):
            current['verbatim_samples'].append(m3.group(1))

if current is not None:
    sources.append(current)

if not sources:
    print("SOURCE CANON GROUNDING GATE: FAIL -- artifact contains no sources", file=sys.stderr)
    print("  The artifact must declare at least one source file under 'sources:'.", file=sys.stderr)
    sys.exit(1)

MIN_SAMPLES = 3
fail_count = 0
fail_lines = []

for src in sources:
    rel_path = src['file']
    declared_sha = src['sha256']
    samples = src['verbatim_samples']

    # Resolve source file path -- relative paths are project-rooted
    if Path(rel_path).is_absolute():
        src_path = Path(rel_path)
    else:
        src_path = project_root / rel_path

    if not src_path.is_file():
        fail_lines.append(f"  - {rel_path}: source file not found on disk at {src_path}")
        fail_count += 1
        continue

    if not declared_sha:
        fail_lines.append(f"  - {rel_path}: artifact missing sha256 field")
        fail_count += 1
        continue

    actual_sha = hashlib.sha256(src_path.read_bytes()).hexdigest()
    if actual_sha != declared_sha:
        fail_lines.append(
            f"  - {rel_path}: sha256 mismatch (file has changed since grounding)\n"
            f"      declared: {declared_sha[:16]}...\n"
            f"      actual:   {actual_sha[:16]}...\n"
            f"      ACTION: orchestrator must re-read the file and regenerate the artifact"
        )
        fail_count += 1
        continue

    if len(samples) < MIN_SAMPLES:
        fail_lines.append(
            f"  - {rel_path}: only {len(samples)} verbatim sample(s) declared (minimum {MIN_SAMPLES})"
        )
        fail_count += 1
        continue

    try:
        file_text = src_path.read_text(encoding='utf-8', errors='replace')
    except Exception as e:
        fail_lines.append(f"  - {rel_path}: could not read source file for sample verification: {e}")
        fail_count += 1
        continue

    missing_samples = [s for s in samples if s not in file_text]
    if missing_samples:
        fail_lines.append(
            f"  - {rel_path}: {len(missing_samples)} of {len(samples)} verbatim sample(s) NOT found in source\n"
            f"      (FABRICATION SIGNAL -- orchestrator quoted text that isn't in the file)"
        )
        for s in missing_samples[:3]:
            disp = s if len(s) <= 80 else s[:77] + '...'
            fail_lines.append(f"          missing: \"{disp}\"")
        fail_count += 1
        continue

if fail_count > 0:
    print(f"SOURCE CANON GROUNDING GATE: FAIL -- {fail_count} source(s) failed verification", file=sys.stderr)
    print("", file=sys.stderr)
    for line in fail_lines:
        print(line, file=sys.stderr)
    print("", file=sys.stderr)
    print("OVERALL ACTION:", file=sys.stderr)
    print("  The orchestrator's claim of having read source canon files cannot be", file=sys.stderr)
    print("  verified. Re-read every failed source file and regenerate the artifact", file=sys.stderr)
    print("  with current sha256s and verbatim samples that are actual substrings of", file=sys.stderr)
    print("  the source text. See references/source-canon-grounding.md for the format.", file=sys.stderr)
    sys.exit(1)

print(f"SOURCE CANON GROUNDING GATE: PASS -- {len(sources)} source(s) verified")
print(f"  All declared sources match current sha256.")
print(f"  All {sum(len(s['verbatim_samples']) for s in sources)} verbatim samples found as substrings of their source files.")
sys.exit(0)
PYTHON

exit $?
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
