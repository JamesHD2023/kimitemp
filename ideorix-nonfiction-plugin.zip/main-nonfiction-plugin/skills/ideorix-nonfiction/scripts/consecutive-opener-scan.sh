#!/bin/bash
# ============================================================
# Ideorix — Consecutive Opener Scan (v2.7.75)
# Detects anaphora abuse: 3+ consecutive sentences starting with
# the same opener. The canonical "She looked at the door. She
# looked at the window. She looked at the clock." pattern that
# prose-humaniser.md ranks as CRITICAL with manuscript-wide cap
# of 0.
#
# Until v2.7.75 this rule lived in spec text only (LLM-contract
# layer); the orchestrator's own self-audit could miss it. v2.7.75
# adds deterministic script-side detection so the cluster is
# caught regardless of whether the orchestrator remembered to
# look for it.
# ============================================================
# Usage:
#   bash consecutive-opener-scan.sh <chapter.md>
#   bash consecutive-opener-scan.sh <chapter.md> --threshold 3
#   bash consecutive-opener-scan.sh <chapter.md> --opener-words 2
#
# Output: PASS line or WARN section listing each detected cluster
#   with line numbers and the actual sentences.
#
# Exit codes:
#   0  scan completed (clean OR violations — violations are reported
#      via STATUS: WARN so the ideorix-audit run_module wrapper
#      surfaces them as WARN, not FAIL; this is deliberate for
#      v2.7.75 to avoid auto-failing already-approved chapters
#      that may contain pre-fix anaphora)
#   2  invalid arguments / missing file
#
# Default behaviour: threshold=3 (the prose-humaniser canonical rule),
# opener-words=1 (first-word matching, the most common anaphora shape).
#
# Honest limits:
# - Sentence segmentation uses a regex (terminator + whitespace +
#   capital letter). Doesn't perfectly handle abbreviations
#   ("Mr. Smith"). False splits are reviewable in output.
# - Does NOT consider context. Ritual / incantatory passages
#   (occult-magic.md), comedy rule-of-three escalations (comedy.md),
#   mystery clue cycles (mystery.md) legitimately use anaphora as
#   craft. The script reports the cluster; classification is left
#   to the reader.

set -uo pipefail

CHAPTER=""
THRESHOLD=3
OPENER_WORDS=1

while [ $# -gt 0 ]; do
    case "$1" in
        --threshold)
            THRESHOLD="${2:-3}"
            shift 2
            ;;
        --opener-words)
            OPENER_WORDS="${2:-1}"
            shift 2
            ;;
        --help|-h)
            sed -n '/^# Usage:/,/^# Honest limits:/p' "$0" | sed 's/^# //; s/^#//'
            exit 0
            ;;
        *)
            if [ -z "$CHAPTER" ]; then
                CHAPTER="$1"
            fi
            shift
            ;;
    esac
done

if [ -z "$CHAPTER" ]; then
    echo "Usage: consecutive-opener-scan.sh <chapter.md> [--threshold N] [--opener-words N]" >&2
    exit 2
fi

if [ ! -f "$CHAPTER" ]; then
    echo "ERROR: file not found: $CHAPTER" >&2
    exit 2
fi

if ! [[ "$THRESHOLD" =~ ^[0-9]+$ ]] || [ "$THRESHOLD" -lt 2 ]; then
    echo "ERROR: --threshold must be an integer >= 2 (got: $THRESHOLD)" >&2
    exit 2
fi

if ! [[ "$OPENER_WORDS" =~ ^[0-9]+$ ]] || [ "$OPENER_WORDS" -lt 1 ]; then
    echo "ERROR: --opener-words must be an integer >= 1 (got: $OPENER_WORDS)" >&2
    exit 2
fi

python3 - "$CHAPTER" "$THRESHOLD" "$OPENER_WORDS" <<'PYTHON'
import re
import sys

path = sys.argv[1]
threshold = int(sys.argv[2])
opener_words = int(sys.argv[3])

try:
    with open(path, encoding='utf-8') as f:
        raw = f.read()
except Exception as e:
    print(f"ERROR: could not read {path}: {e}", file=sys.stderr)
    sys.exit(2)

# Strip YAML frontmatter if present
if raw.startswith('---'):
    end = raw.find('---', 3)
    if end != -1:
        raw = raw[end + 3:]

# Strip fenced code blocks (they aren't prose)
raw = re.sub(r'```.*?```', '', raw, flags=re.DOTALL)

# Collect prose lines + line numbers; skip headings, blockquotes, list items
lines = raw.split('\n')
prose_segments = []  # list of (line_number_1based, text)
for i, line in enumerate(lines, start=1):
    stripped = line.strip()
    if not stripped:
        continue
    if stripped.startswith('#'):
        continue
    if stripped.startswith('>'):
        continue
    if re.match(r'^[-*+]\s', stripped):
        continue
    if re.match(r'^\d+\.\s', stripped):
        continue
    prose_segments.append((i, stripped))

# Sentence segmentation: split on terminator + whitespace + capital/quote.
# Handles em-dash and en-dash and smart-quote starts.
SENTENCE_BOUNDARY = re.compile(
    r'(?<=[.!?])\s+(?=["“”\'‘’—–\-]?[A-Z])'
)

sentences = []  # list of (sentence_text, line_number)
for line_num, text in prose_segments:
    parts = SENTENCE_BOUNDARY.split(text)
    for part in parts:
        s = part.strip()
        if s:
            sentences.append((s, line_num))

def get_opener(sentence, n_words):
    """Return the first n_words of the sentence as a lowercased tuple,
    or None if the sentence has too few alphabetic words. Skips leading
    quote marks, dashes, and other punctuation."""
    # Find first alphabetic character
    m = re.search(r"[A-Za-z]", sentence)
    if not m:
        return None
    s = sentence[m.start():]
    words = re.findall(r"[A-Za-z][A-Za-z'-]*", s)
    if len(words) < n_words:
        return None
    return tuple(w.lower() for w in words[:n_words])

# Detect clusters of >=threshold consecutive sentences with same opener
clusters = []
i = 0
while i < len(sentences):
    opener = get_opener(sentences[i][0], opener_words)
    if opener is None:
        i += 1
        continue
    j = i + 1
    while j < len(sentences):
        next_opener = get_opener(sentences[j][0], opener_words)
        if next_opener == opener:
            j += 1
        else:
            break
    run_length = j - i
    if run_length >= threshold:
        clusters.append({
            'opener': ' '.join(opener),
            'count': run_length,
            'start_line': sentences[i][1],
            'end_line': sentences[j-1][1],
            'sentences': sentences[i:j],
        })
        i = j
    else:
        i += 1

if not clusters:
    print(f"CONSECUTIVE OPENER SCAN: PASS (no clusters of {threshold}+ consecutive "
          f"sentences with the same opener; opener-words={opener_words})")
    sys.exit(0)

# Detection: emit STATUS: WARN so the ideorix-audit run_module wrapper
# treats this as WARN, not FAIL.
print(f"STATUS: WARN")
print(f"CONSECUTIVE OPENER SCAN: WARN ({len(clusters)} cluster(s) of "
      f"{threshold}+ consecutive sentences with the same opener detected)")
print()

for k, cl in enumerate(clusters, 1):
    print(f"--- Cluster {k} (lines {cl['start_line']}-{cl['end_line']}, "
          f"{cl['count']} consecutive sentences starting with '{cl['opener']}') ---")
    for s, ln in cl['sentences']:
        display = s if len(s) <= 120 else s[:117] + '...'
        print(f"  L{ln}: {display}")
    print()

print("RULE: prose-humaniser.md — 3+ consecutive same-openers is CRITICAL")
print("      (max 0 per manuscript in normal prose).")
print()
print("CONTEXT EXEMPTIONS:")
print("  - incantatory / ritual passages (occult-magic.md)")
print("  - comedy rule-of-three escalations (comedy.md)")
print("  - mystery clue cycles (mystery.md, middle-grade.md)")
print()
print("Each cluster is reported here; classification (legitimate craft vs")
print("accidental tell) is the reader's decision. Cluster lines above show")
print("the literal sentences for context.")
sys.exit(0)
PYTHON

exit $?
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
