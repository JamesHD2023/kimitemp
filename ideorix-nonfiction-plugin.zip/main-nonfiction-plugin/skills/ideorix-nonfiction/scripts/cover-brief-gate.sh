#!/bin/bash
# ============================================================
# Ideorix — Cover Brief Gate (v2.7.68)
# Enforces Phase 6 Cover Design discipline. Before any cover
# image is generated, before marketing pack ships, before the
# project is declared launch-ready, this gate verifies that
# a structured cover brief exists per references/cover-designer.md.
#
# Closes the LLM-contract gap: v2.7.67 and earlier only
# required Claude to "follow the cover-designer.md spec." Claude
# could (and did) generate cover prompts directly from training-
# data without producing the structured concept brief the spec
# mandates. Result: 3D product renders instead of book covers.
# v2.7.68 makes the structured brief a verifiable precondition.
# ============================================================
# Usage: bash cover-brief-gate.sh <project-root>
#
# Verifies (relative to <project-root>):
#   1. marketing/cover/ directory exists
#   2. At least one cover concept file exists in it (matching
#      *concept*.{md,json} or cover-brief.{md,json})
#   3. The concept file is non-trivial (>= 800 bytes — empty
#      brief defeats the gate's purpose)
#   4. The concept file contains the required field markers per
#      cover-designer.md output schema:
#        - "conceptName" or "Concept Name"
#        - "visualConcept" or "Visual Concept"
#        - "colorPalette" or "Color Palette"
#        - "typography" or "Typography"
#        - "imagePrompt" or "Image Prompt"
#        - "mood" or "Mood"
#      (case-insensitive; markdown and JSON both supported)
#
# Honors opt-out: cover_status: skip / legacy in project-config.md.
#
# Exit codes:
#   0  cover brief present + populated (PASS)
#   1  cover brief missing / empty / skeleton (FAIL)
#   2  invalid arguments

set -uo pipefail

PROJECT="${1:?Usage: cover-brief-gate.sh <project-root>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

CONFIG="$PROJECT/engine-data/project-config.md"
COVER_DIR="$PROJECT/marketing/cover"

if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*cover_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "COVER BRIEF GATE: PASS (project-config.md declares cover_status: skip — documented opt-out honored)"
        exit 0
    fi
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*cover_status:[[:space:]]*legacy\b' "$CONFIG"; then
        echo "COVER BRIEF GATE: PASS (project-config.md declares cover_status: legacy — pre-v2.7.68 project)"
        exit 0
    fi
fi

if [ ! -d "$COVER_DIR" ]; then
    echo "COVER BRIEF GATE: FAIL — cover directory missing: $COVER_DIR" >&2
    echo "" >&2
    echo "ACTION: produce a structured cover brief before marketing or launch." >&2
    echo "  The spec is at references/cover-designer.md. The brief must" >&2
    echo "  contain the structured concept schema (conceptName, visualConcept," >&2
    echo "  colorPalette, typography, imagePrompt, mood, etc.) — not a free-" >&2
    echo "  form description." >&2
    echo "" >&2
    echo "Write to: $COVER_DIR/cover-brief.md  (or .json)" >&2
    echo "" >&2
    echo "Opt-outs (if cover design is genuinely out of scope):" >&2
    echo "  append to $CONFIG:" >&2
    echo "    cover_status: legacy   # pre-v2.7.68 project" >&2
    echo "    cover_status: skip     # cover design not a deliverable" >&2
    exit 1
fi

# Find concept candidates. Cover-designer outputs may be markdown or
# JSON; the gate accepts either. Prefer files with "brief" or "concept"
# in the name; fall back to any *.md / *.json in the directory.
CANDIDATES=$(find "$COVER_DIR" -maxdepth 1 -type f \( -iname "*brief*" -o -iname "*concept*" \) \( -name "*.md" -o -name "*.json" \) 2>/dev/null)
if [ -z "$CANDIDATES" ]; then
    CANDIDATES=$(find "$COVER_DIR" -maxdepth 1 -type f \( -name "*.md" -o -name "*.json" \) 2>/dev/null)
fi

if [ -z "$CANDIDATES" ]; then
    echo "COVER BRIEF GATE: FAIL — no cover brief file found in $COVER_DIR" >&2
    echo "  Expected: cover-brief.md or *concept*.{md,json}" >&2
    echo "  ACTION: produce a structured cover brief per references/cover-designer.md." >&2
    exit 1
fi

# Walk candidates; PASS if at least one passes the structural checks.
PASS_FILE=""
FAIL_DETAIL=""
REQUIRED_FIELDS="conceptName visualConcept colorPalette typography imagePrompt mood"
# Field aliases (markdown headings vs JSON keys).
field_present() {
    local file="$1" field="$2"
    case "$field" in
        conceptName)    grep -qiE '("conceptName"|conceptName|#+[[:space:]]*Concept[[:space:]]*Name)' "$file" ;;
        visualConcept)  grep -qiE '("visualConcept"|visualConcept|#+[[:space:]]*Visual[[:space:]]*Concept)' "$file" ;;
        colorPalette)   grep -qiE '("colorPalette"|colorPalette|#+[[:space:]]*Color[[:space:]]*Palette)' "$file" ;;
        typography)     grep -qiE '("typography"|typography|#+[[:space:]]*Typography)' "$file" ;;
        imagePrompt)    grep -qiE '("imagePrompt"|imagePrompt|#+[[:space:]]*Image[[:space:]]*Prompt)' "$file" ;;
        mood)           grep -qiE '("mood"|^mood:|#+[[:space:]]*Mood)' "$file" ;;
    esac
}

for file in $CANDIDATES; do
    [ -f "$file" ] || continue
    size=$(wc -c < "$file" 2>/dev/null || echo 0)
    if [ "$size" -lt 800 ]; then
        FAIL_DETAIL="${FAIL_DETAIL}  - $file: too small ($size bytes; minimum 800)
"
        continue
    fi
    missing=""
    for f in $REQUIRED_FIELDS; do
        if ! field_present "$file" "$f"; then
            missing="$missing $f"
        fi
    done
    if [ -n "$missing" ]; then
        FAIL_DETAIL="${FAIL_DETAIL}  - $file: missing required fields:$missing
"
        continue
    fi
    PASS_FILE="$file"
    break
done

if [ -z "$PASS_FILE" ]; then
    echo "COVER BRIEF GATE: FAIL — no candidate cover brief passes the structural check." >&2
    echo "" >&2
    printf '%b' "$FAIL_DETAIL" >&2
    echo "" >&2
    echo "ACTION: produce a structured cover brief per references/cover-designer.md." >&2
    echo "  Required fields: conceptName, visualConcept, colorPalette, typography," >&2
    echo "                   imagePrompt, mood (any case; markdown or JSON)." >&2
    echo "  Minimum size: 800 bytes (the brief must be substantive, not a stub)." >&2
    exit 1
fi

echo "COVER BRIEF GATE: PASS — structured cover brief found at $PASS_FILE"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
