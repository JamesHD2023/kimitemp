#!/bin/bash
# ============================================================
# Ideorix — Voice Profile Preload Gate (v2.7.65)
# Enforces Rule 5 (mandatory-pipeline-rules.md): the project's
# voice-profile.md must exist + be non-trivial before any
# chapter generation begins. This is the artifact-level
# enforcement of what was previously LLM-contract-only ("the
# Writer prompt has the voice profile loaded").
#
# Fail-closed: exits non-zero if voice-profile.md is missing,
# zero bytes, or skeleton-only (no exemplar paths declared).
# ============================================================
# Usage: bash voice-profile-preload-gate.sh <project-root>
#
# A voice-profile passes the preload check when:
#   - engine-data/voice-profile.md exists, non-empty
#   - contains at least one `voice_calibration_exemplar:` line
#     (calibration corpus is the anchor; an empty profile defeats
#     the purpose of the gate)
#   - contains a `fp_target:` value (parseable float)
#   - contains a `voice_prose_description:` section header OR
#     `voice_prose_description:` key (prose description of the
#     voice register the writer is reproducing)
#
# Honors opt-out:
#   - voice_profile_status: legacy   (pre-v2.7.65 manuscript)
#   - voice_profile_status: skip     (intentional opt-out, eg.
#                                     reference / cookbook where
#                                     voice consistency is not a
#                                     deliverable)
#
# Exit codes:
#   0  voice-profile.md present + populated (PASS)
#   1  voice-profile.md missing / empty / skeleton (FAIL)
#   2  invalid arguments

set -euo pipefail

PROJECT="${1:?Usage: voice-profile-preload-gate.sh <project-root>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

CONFIG="$PROJECT/engine-data/project-config.md"
PROFILE="$PROJECT/engine-data/voice-profile.md"

if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*voice_profile_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "VOICE PROFILE PRELOAD GATE: PASS (project-config.md declares voice_profile_status: skip — documented opt-out honored)"
        exit 0
    fi
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*voice_profile_status:[[:space:]]*legacy\b' "$CONFIG"; then
        echo "VOICE PROFILE PRELOAD GATE: PASS (project-config.md declares voice_profile_status: legacy — pre-v2.7.65 manuscript)"
        exit 0
    fi
fi

if [ ! -f "$PROFILE" ]; then
    echo "VOICE PROFILE PRELOAD GATE: FAIL — voice-profile.md missing: $PROFILE" >&2
    echo "" >&2
    echo "ACTION: create the voice profile before chapter generation." >&2
    echo "  The profile is the calibration corpus that anchors author-voice" >&2
    echo "  consistency across the manuscript. See references/voice-profile.md" >&2
    echo "  in the engine for the required structure." >&2
    echo "" >&2
    echo "Minimal viable profile:" >&2
    echo "  fp_target: 0.20" >&2
    echo "  sentence_band_min: 13" >&2
    echo "  sentence_band_max: 19" >&2
    echo "  voice_calibration_exemplar: <relative path to a non-drifted chapter or excerpt>" >&2
    echo "  voice_prose_description: <2-3 sentences naming the register>" >&2
    echo "" >&2
    echo "Opt-outs (for legacy / intentional skip):" >&2
    echo "  append to $CONFIG:" >&2
    echo "    voice_profile_status: legacy   # pre-v2.7.65 manuscript" >&2
    echo "    voice_profile_status: skip     # voice-consistency not a deliverable" >&2
    exit 1
fi

if [ ! -s "$PROFILE" ]; then
    echo "VOICE PROFILE PRELOAD GATE: FAIL — voice-profile.md is empty (zero bytes): $PROFILE" >&2
    echo "  ACTION: populate the profile with calibration exemplars + targets." >&2
    exit 1
fi

# Structural checks. Each is an independent FAIL line so the user
# sees everything that's missing in one pass.
FAIL=0
FAIL_LINES=""

if ! grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*voice_calibration_exemplar:' "$PROFILE"; then
    FAIL_LINES="${FAIL_LINES}  - no voice_calibration_exemplar: lines (the calibration corpus is the anchor; without exemplars the trend audit has no reference voice)
"
    FAIL=1
fi

if ! grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*fp_target:' "$PROFILE"; then
    FAIL_LINES="${FAIL_LINES}  - no fp_target: value (target FP ratio for the project; voice-metrics-audit + voice-trend-audit default to 0.20 without it, which may not match this manuscript)
"
    FAIL=1
fi

if ! grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*voice_prose_description:' "$PROFILE" \
   && ! grep -qiE '^#+[[:space:]]*Voice Prose Description' "$PROFILE"; then
    FAIL_LINES="${FAIL_LINES}  - no voice_prose_description: key or '## Voice Prose Description' section (the prose register the writer is reproducing — what's distinctive about this voice)
"
    FAIL=1
fi

if [ "$FAIL" -eq 1 ]; then
    echo "VOICE PROFILE PRELOAD GATE: FAIL — voice-profile.md is incomplete." >&2
    echo "  Path: $PROFILE" >&2
    echo "" >&2
    printf '%b' "$FAIL_LINES" >&2
    echo "" >&2
    echo "ACTION: complete the missing fields before chapter generation continues." >&2
    echo "See references/voice-profile.md in the engine for the canonical template." >&2
    exit 1
fi

echo "VOICE PROFILE PRELOAD GATE: PASS — voice-profile.md present + populated"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
