#!/bin/bash
# ============================================================
# Ideorix — PostToolUse Engine-Data Integrity Hook (v2.7.73)
# Fires after every Write|Edit|MultiEdit on any `.md` file
# under `*/engine-data/` (chapters, pipeline-checkpoint,
# reports, briefs, ledgers, canon). Runs the detective layer
# chapter-integrity-check.sh on the written file. The check
# script is markdown-aware, not chapter-specific — it scans
# for NULL bytes, UTF-8 validity, frontmatter closure, and
# line-count collapse, all of which apply to any engine-data
# markdown file.
#
# v2.7.73 broadens v2.7.72's scope. v2.7.72 covered chapters
# only; v2.7.73 covers all `engine-data/*.md` after a real-
# session corruption of `pipeline-checkpoint.md` confirmed the
# bridge-intermittency failure mode (see silent-failure-audit.md
# row 65, v2.7.73 reassessment) affects every engine-data write,
# not just chapters.
#
# Scope: covers Write/Edit/MultiEdit writes only. Bash-heredoc
# writes (`cat > file <<EOF`) are NOT covered here — the spec-
# driven invocation in core-pipeline.md remains the detective
# layer for those.
# ============================================================
# stdin: JSON from the Claude Code harness with shape
#   { "tool_input": { "file_path": "<path>", ... }, "tool_response": {...}, ... }
# stdout: empty
# stderr: chapter-integrity-check output if the check fails
# exit:
#   0  hook ran (or no-op on non-engine-data path); integrity check passed
#   2  integrity check failed; surface stderr to Claude
#
# Fail-open policy: malformed JSON, missing file_path, missing
# integrity-check script, or non-engine-data path all exit 0.
#
# Observability: every invocation appends a single line to
#   ${IDEORIX_CHAPTER_HOOK_LOG:-${TMPDIR:-/tmp}/ideorix-chapter-integrity-hook.log}
# Log shape:
#   <ISO-8601 timestamp> | v2.7.73 | <decision> | <reason> | <file_path>
# Decision: PASS | FAIL | SKIP | NOOP
#
# Log env var name retained from v2.7.72 (IDEORIX_CHAPTER_HOOK_LOG)
# for log continuity across the rename — users who set the env
# var in their sessions don't need to update it.

set -uo pipefail

HOOK_LOG="${IDEORIX_CHAPTER_HOOK_LOG:-${TMPDIR:-/tmp}/ideorix-chapter-integrity-hook.log}"

log_invocation() {
    local decision="$1" reason="$2" file_path="$3"
    {
        printf '%s | v2.7.73 | %s | %s | %s\n' \
            "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
            "$decision" \
            "$reason" \
            "$file_path"
    } >> "$HOOK_LOG" 2>/dev/null || true
}

PAYLOAD=$(head -c 1048576 2>/dev/null || true)

if [ -z "$PAYLOAD" ]; then
    log_invocation "NOOP" "empty-payload" ""
    exit 0
fi

FILE_PATH=$(python3 -c '
import json, sys
try:
    data = json.load(sys.stdin)
except Exception:
    sys.exit(0)
fp = data.get("tool_input", {}).get("file_path", "") or ""
sys.stdout.write(fp)
' <<<"$PAYLOAD" 2>/dev/null || true)

if [ -z "$FILE_PATH" ]; then
    log_invocation "NOOP" "no-file-path" ""
    exit 0
fi

# Engine-data path pattern: any .md file under engine-data/ at any
# depth up to one subdirectory (chapters/, reports/, snapshots/, etc.,
# or directly at engine-data/ root).
if ! echo "$FILE_PATH" | grep -qE '/engine-data/([^/]+/)?[^/]+\.md$'; then
    log_invocation "SKIP" "not-engine-data-md" "$FILE_PATH"
    exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INTEGRITY_CHECK="${SCRIPT_DIR}/chapter-integrity-check.sh"

if [ ! -f "$INTEGRITY_CHECK" ]; then
    log_invocation "NOOP" "integrity-check-missing" "$FILE_PATH"
    exit 0
fi

INTEGRITY_OUTPUT=$(bash "$INTEGRITY_CHECK" "$FILE_PATH" 2>&1)
INTEGRITY_EXIT=$?

if [ "$INTEGRITY_EXIT" -ne 0 ]; then
    log_invocation "FAIL" "integrity-exit-${INTEGRITY_EXIT}" "$FILE_PATH"
    echo "$INTEGRITY_OUTPUT" >&2
    cat >&2 <<'POST_BLOCK_MSG'

Surfaced by Ideorix PostToolUse hook (v2.7.73): chapter-integrity-check
flagged the engine-data file written above. The write completed but the
artifact on disk is corrupted (NULL bytes, UTF-8 invalidity, frontmatter
truncation, or line-count collapse).

Most likely cause on Cowork-Windows: intermittent filesystem-bridge
failure during the cross-FS mv that backs the write. The bridge can
allocate the file at expected size but fail to flush bytes, leaving
NULLs. Restore from the snapshot in engine-data/snapshots/ and re-apply
the change. The retry usually succeeds because the failure is
intermittent.

See core-pipeline.md File-Write Hygiene and silent-failure-audit.md
row 65 (v2.7.73 reassessment) for the full mechanism + recovery
playbook.
POST_BLOCK_MSG
    exit 2
fi

log_invocation "PASS" "integrity-clean" "$FILE_PATH"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
