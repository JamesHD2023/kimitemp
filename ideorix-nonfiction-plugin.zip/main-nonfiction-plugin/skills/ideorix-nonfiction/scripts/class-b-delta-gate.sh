#!/bin/bash
# ============================================================
# Ideorix — Class B Delta Pass Gate (v2.7.62)
# Enforces Rule 1b (mandatory-pipeline-rules.md): the per-chapter
# Class B Delta Pass must have run for chapter N before chapter
# N+1 may begin.
#
# Fail-closed: exits non-zero if the expected artifacts for the
# specified chapter are missing or stale.
# ============================================================
# Usage: bash class-b-delta-gate.sh <project-root> <chapter-N>
# - project-root: path to Ideorix-Projects/{Book}
# - chapter-N:    integer chapter number (e.g. 7, 12)
#
# A chapter passes the Class B Delta gate when:
#   - project-config.md declares class_b_delta_status: skip
#     (documented opt-out; passes with note), OR
#   - both expected subagent return files exist:
#       engine-data/reports/validate/leitmotif-tracker-delta-ch{NN}-subagent.md
#       engine-data/reports/validate/injury-accumulation-delta-ch{NN}-subagent.md
#   - AND both running ledgers have mtimes newer than the chapter
#     file (proves the deltas updated them for this chapter):
#       engine-data/reports/leitmotif-ledger.md
#       engine-data/reports/injury-ledger.md
#
# Mtime check prevents the silent-failure shape where a stale ledger
# from a prior chapter satisfies "file exists" without proving the
# current chapter's delta actually ran.
#
# Exit codes:
#   0  All expected artifacts present + fresh (PASS)
#   1  One or more artifacts missing / stale (FAIL)
#   2  Invalid arguments

set -euo pipefail

PROJECT="${1:?Usage: class-b-delta-gate.sh <project-root> <chapter-N>}"
CHAPTER_N="${2:?Usage: class-b-delta-gate.sh <project-root> <chapter-N>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

if ! [[ "$CHAPTER_N" =~ ^[0-9]+$ ]]; then
    echo "ERROR: chapter-N must be a non-negative integer, got: $CHAPTER_N" >&2
    exit 2
fi

CHAPTER_NN=$(printf '%02d' "$CHAPTER_N")

CONFIG="$PROJECT/engine-data/project-config.md"
CHAPTER_FILE="$PROJECT/engine-data/chapters/ch${CHAPTER_NN}.md"
LEITMOTIF_RETURN="$PROJECT/engine-data/reports/validate/leitmotif-tracker-delta-ch${CHAPTER_NN}-subagent.md"
INJURY_RETURN="$PROJECT/engine-data/reports/validate/injury-accumulation-delta-ch${CHAPTER_NN}-subagent.md"
LEITMOTIF_LEDGER="$PROJECT/engine-data/reports/leitmotif-ledger.md"
INJURY_LEDGER="$PROJECT/engine-data/reports/injury-ledger.md"

# Documented opt-out — projects that pre-date v2.7.61 or that
# deliberately skip the per-chapter Class B Delta Pass (e.g.,
# short-form projects where the cost outweighs the catch-cheap
# benefit) can append to engine-data/project-config.md:
#
#   class_b_delta_status: skip
#
# The gate honours the declaration and passes. Stage 9.5 Canon
# Validation Sweep still runs as the safety net.
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*class_b_delta_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "CLASS B DELTA GATE: PASS (project-config.md declares class_b_delta_status: skip — documented opt-out honored)"
        exit 0
    fi
fi

# v2.7.63: category-aware auto-skip for argumentative non-fiction.
# Per-chapter motif tracking and injury continuity audits are
# fiction-shaped concerns that also apply to narrative non-fiction
# (memoir, biography, true-crime, literary journalism, etc.) but
# NOT to argumentative non-fiction (self-help, business, reference,
# cookbook, etc.). When a project is one of the latter, auto-skip
# the gate with a clear rationale message; the user can still force
# the audits on with `class_b_delta_status: enable`.
#
# Three signal sources, in priority order:
#   1. `class_b_delta_status: enable` — explicit user override; force ON
#   2. `nf_shape: argumentative` — explicit user signal; force OFF
#   3. `nf_category: <slug>` lookup against the argumentative-category
#      list below; OFF if matched
#
# Fiction projects don't have nf_shape / nf_category fields in their
# project-config.md, so the new logic is a no-op on the fiction side.
# This preserves byte-identity of the mirrored script.
if [ -f "$CONFIG" ]; then
    # Signal 1: explicit opt-in override
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*class_b_delta_status:[[:space:]]*enable\b' "$CONFIG"; then
        # Skip the auto-skip logic; fall through to artifact check
        :
    elif grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*nf_shape:[[:space:]]*argumentative\b' "$CONFIG"; then
        # Signal 2: explicit argumentative shape declaration
        echo "CLASS B DELTA GATE: PASS (project-config.md declares nf_shape: argumentative — Class B Delta Pass auto-skipped; motif + injury audits don't apply to argumentative non-fiction. Override with class_b_delta_status: enable to force on; Stage 9.5 sweep still runs.)"
        exit 0
    else
        # Signal 3: category lookup. Conservative list — only the
        # high-confidence argumentative categories. Categories not
        # in this list default to the previous v2.7.61 behaviour
        # (audits run). Users can still opt out per-project via
        # class_b_delta_status: skip or nf_shape: argumentative.
        ARGUMENTATIVE_CATEGORIES="self-help psychology-popular philosophy-popular business economics-finance personal-finance health-wellness fitness how-to-guide cooking education parenting technology religion-spirituality popular-science"
        DETECTED_CAT=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*(nf_category|category|category_slug):[[:space:]]*' "$CONFIG" \
            | head -1 \
            | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*(nf_category|category|category_slug):[[:space:]]*//' \
            | awk '{print $1}' \
            | tr -d '"' | tr '[:upper:]' '[:lower:]' || true)
        if [ -n "$DETECTED_CAT" ]; then
            for ac in $ARGUMENTATIVE_CATEGORIES; do
                if [ "$DETECTED_CAT" = "$ac" ]; then
                    echo "CLASS B DELTA GATE: PASS (project-config.md category: ${DETECTED_CAT} is argumentative non-fiction — Class B Delta Pass auto-skipped; motif + injury audits don't apply. Override with class_b_delta_status: enable to force on; Stage 9.5 sweep still runs.)"
                    exit 0
                fi
            done
        fi
    fi
fi

# The chapter file must exist for the gate to be meaningful (if the
# chapter hasn't been written yet there's nothing to audit). Treat
# a missing chapter file as a setup error, not a delta-pass failure.
if [ ! -f "$CHAPTER_FILE" ]; then
    echo "ERROR: chapter file not found: $CHAPTER_FILE" >&2
    echo "       (the gate runs after a chapter is written, before the next chapter begins)" >&2
    exit 2
fi

CHAPTER_MTIME=$(stat -c %Y "$CHAPTER_FILE" 2>/dev/null || stat -f %m "$CHAPTER_FILE" 2>/dev/null || echo 0)

# Track failures so we can report all missing artifacts in one pass
# rather than bailing on the first one.
FAIL=0
FAIL_LINES=""

check_return_file() {
    local label="$1" path="$2"
    if [ ! -f "$path" ]; then
        FAIL_LINES="${FAIL_LINES}  - $label subagent return missing: $path
"
        FAIL=1
        return
    fi
    if [ ! -s "$path" ]; then
        FAIL_LINES="${FAIL_LINES}  - $label subagent return is zero bytes (hallucination guard): $path
"
        FAIL=1
        return
    fi
}

check_ledger() {
    local label="$1" path="$2"
    if [ ! -f "$path" ]; then
        FAIL_LINES="${FAIL_LINES}  - $label ledger missing: $path
"
        FAIL=1
        return
    fi
    local mtime
    mtime=$(stat -c %Y "$path" 2>/dev/null || stat -f %m "$path" 2>/dev/null || echo 0)
    if [ "$mtime" -lt "$CHAPTER_MTIME" ]; then
        FAIL_LINES="${FAIL_LINES}  - $label ledger is stale (mtime older than chapter file — delta pass didn't update it for ch${CHAPTER_NN}): $path
"
        FAIL=1
        return
    fi
}

check_return_file "leitmotif-tracker-delta" "$LEITMOTIF_RETURN"
check_return_file "injury-accumulation-delta" "$INJURY_RETURN"
check_ledger      "leitmotif-tracker-delta"  "$LEITMOTIF_LEDGER"
check_ledger      "injury-accumulation-delta" "$INJURY_LEDGER"

if [ "$FAIL" -eq 1 ]; then
    echo "CLASS B DELTA GATE: FAIL — chapter ${CHAPTER_NN} per-chapter Class B Delta Pass artifacts missing or stale." >&2
    printf '%b' "$FAIL_LINES" >&2
    echo "" >&2
    echo "ACTION: run the Class B Delta Pass for chapter ${CHAPTER_NN}:" >&2
    echo "  bash scripts/validate-dispatcher.sh \"$PROJECT\" delta $CHAPTER_N" >&2
    echo "  (engine layer then dispatches the two Class B subagents per the emitted" >&2
    echo "   CLASS_B_AUDIT marker lines; subagent returns + ledger updates land at" >&2
    echo "   the paths checked above)" >&2
    echo "" >&2
    echo "ALTERNATIVELY: if this project deliberately skips per-chapter Class B" >&2
    echo "checks, append to $CONFIG:" >&2
    echo "  class_b_delta_status: skip" >&2
    echo "  (Stage 9.5 Canon Validation Sweep still runs at end of manuscript)" >&2
    exit 1
fi

echo "CLASS B DELTA GATE: PASS — chapter ${CHAPTER_NN} Class B Delta Pass artifacts present + fresh"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
