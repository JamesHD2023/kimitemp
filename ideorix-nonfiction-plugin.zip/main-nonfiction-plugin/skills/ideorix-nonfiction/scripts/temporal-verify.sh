#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Temporal Verification
# Engine-neutral (mirrored across fiction + non-fiction engines
# as of v2.7.40 per spec-lint Check 7). OPT-IN: requires the
# project's engine-data/project-config.md to declare
# "temporal_scope: narrative" plus permitted months/season.
# Otherwise returns "not applicable" (exit 0).
#
# Pre-v2.7.40 the fiction copy had a different signature
# (chapter-file, permitted-months, permitted-season) which
# broke the v2.7.29 dispatcher's CHAPTER_PROJECT contract for
# fiction projects — running /validate full or /validate prose
# on a fiction project produced shell-error FAILs from this
# script. The fiction script was replaced with this mirrored
# engine-neutral version in v2.7.40.
# ============================================================
# Usage: bash temporal-verify.sh <chapter-file> <project-root>

set -euo pipefail

CHAPTER="${1:?Usage: temporal-verify.sh <chapter-file> <project-root>}"
PROJECT="${2:?Usage: temporal-verify.sh <chapter-file> <project-root>}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

CONFIG="$PROJECT/engine-data/project-config.md"

if [ ! -f "$CONFIG" ]; then
    echo "=== TEMPORAL VERIFICATION (skipped) ==="
    echo "  N/A — no project-config.md found; temporal scope undeclared"
    exit 0
fi

# Tolerate no-match on grep (exit 1 should not kill the script).
# Tolerate both bare lines and markdown bullet-list lines
# (e.g. "- temporal_scope: narrative") for project-config.md keys.
SCOPE=""
if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*temporal_scope:' "$CONFIG" 2>/dev/null; then
    SCOPE=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*temporal_scope:' "$CONFIG" | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*temporal_scope:[[:space:]]*//' | awk '{print $1}')
fi

if [ "$SCOPE" != "narrative" ]; then
    echo "=== TEMPORAL VERIFICATION (skipped) ==="
    echo "  N/A — temporal_scope: ${SCOPE:-unset} (only 'narrative' triggers this check)"
    echo "  To enable, add to project-config.md:"
    echo "    temporal_scope: narrative"
    echo "    permitted_months: October,November"
    echo "    permitted_season: autumn"
    exit 0
fi

PERMITTED_MONTHS=""
if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*permitted_months:' "$CONFIG" 2>/dev/null; then
    PERMITTED_MONTHS=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*permitted_months:' "$CONFIG" | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*permitted_months:[[:space:]]*//')
fi
PERMITTED_SEASON=""
if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*permitted_season:' "$CONFIG" 2>/dev/null; then
    PERMITTED_SEASON=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*permitted_season:' "$CONFIG" | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*permitted_season:[[:space:]]*//')
fi

if [ -z "$PERMITTED_MONTHS" ] || [ -z "$PERMITTED_SEASON" ]; then
    echo "ERROR: temporal_scope is narrative but permitted_months or permitted_season is missing from project-config.md" >&2
    exit 2
fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT
FAIL=0

echo "=== TEMPORAL VERIFICATION (narrative scope) ==="
echo "Chapter: $CHAPTER"
echo "Permitted months: $PERMITTED_MONTHS"
echo "Permitted season: $PERMITTED_SEASON"
echo ""

ALL_MONTHS="january|february|march|april|may|june|july|august|september|october|november|december"
echo "--- Month References ---"
FOUND_MONTHS=$(grep -oEi "\b($ALL_MONTHS)\b" "$CHAPTER" 2>/dev/null | tr '[:upper:]' '[:lower:]' | sort | uniq -c | sort -rn || true)

if [ -z "$FOUND_MONTHS" ]; then
    echo "  No month references found"
else
    PERMITTED_LOWER=$(echo "$PERMITTED_MONTHS" | tr '[:upper:]' '[:lower:]')
    while read -r count month; do
        [ -z "$month" ] && continue
        # Comma-bounded exact match: ensures "ber" doesn't false-match inside "october".
        if echo ",${PERMITTED_LOWER// /}," | grep -qiE ",${month},"; then
            printf "  %-12s %3d occurrences  PERMITTED\n" "$month" "$count"
        else
            printf "  %-12s %3d occurrences  VIOLATION — not in permitted list\n" "$month" "$count"
            FAIL=1
        fi
    done <<< "$FOUND_MONTHS"
fi

echo ""
echo "--- Season References ---"
SEASONS="spring|summer|autumn|fall|winter"
FOUND_SEASONS=$(grep -oEi "\b($SEASONS)\b" "$CHAPTER" 2>/dev/null | tr '[:upper:]' '[:lower:]' | sort | uniq -c | sort -rn || true)
PERMITTED_SEASON_LOWER=$(echo "$PERMITTED_SEASON" | tr '[:upper:]' '[:lower:]')

if [ -z "$FOUND_SEASONS" ]; then
    echo "  No season references found"
else
    while read -r count season; do
        [ -z "$season" ] && continue
        if [ "$season" = "$PERMITTED_SEASON_LOWER" ] \
            || { [ "$season" = "fall" ] && [ "$PERMITTED_SEASON_LOWER" = "autumn" ]; } \
            || { [ "$season" = "autumn" ] && [ "$PERMITTED_SEASON_LOWER" = "fall" ]; }; then
            printf "  %-10s %3d occurrences  PERMITTED\n" "$season" "$count"
        else
            printf "  %-10s %3d occurrences  CHECK — not the declared season\n" "$season" "$count"
        fi
    done <<< "$FOUND_SEASONS"
fi

echo ""
if [ "$FAIL" -eq 1 ]; then echo "STATUS: FAIL"; exit 1; fi
echo "STATUS: PASS"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
