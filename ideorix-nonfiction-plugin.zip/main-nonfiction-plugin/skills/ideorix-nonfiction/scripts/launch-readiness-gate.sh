#!/bin/bash
# ============================================================
# Ideorix — Launch Readiness Gate (v2.7.68)
# Meta-gate that verifies every Phase 6 deliverable is in place
# before the project can be declared ready to ship. Single
# command: "is this project actually ready?"
#
# Chains the existing Phase 6 gates:
#   - market-scout-gate         (market intelligence present + fresh)
#   - cover-brief-gate          (structured cover brief)
#   - marketing-pack-gate       (marketing brief + 5 core sections)
#   - kdp-metadata-gate         (KDP metadata + required fields)
#   - manuscript export check   (at least one rendered manuscript
#                                in manuscript/ — .docx / .epub /
#                                .pdf — that passed docx-integrity)
# ============================================================
# Usage: bash launch-readiness-gate.sh <project-root>
#
# Reports each constituent gate's PASS/FAIL with a final
# composite verdict. Composite FAIL if ANY constituent FAILs.
#
# Honors opt-out:
#   launch_readiness_status: legacy / skip
#
# Exit codes:
#   0  all constituent gates pass + at least one rendered
#      manuscript present (LAUNCH-READY)
#   1  one or more constituent gates fail (NOT LAUNCH-READY)
#   2  invalid arguments

set -uo pipefail

PROJECT="${1:?Usage: launch-readiness-gate.sh <project-root>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="$PROJECT/engine-data/project-config.md"

if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*launch_readiness_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "LAUNCH READINESS GATE: PASS (project-config.md declares launch_readiness_status: skip — documented opt-out honored)"
        exit 0
    fi
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*launch_readiness_status:[[:space:]]*legacy\b' "$CONFIG"; then
        echo "LAUNCH READINESS GATE: PASS (project-config.md declares launch_readiness_status: legacy — pre-v2.7.68 project)"
        exit 0
    fi
fi

echo "=== LAUNCH READINESS GATE ==="
echo "Project: $PROJECT"
echo ""

PASS_COUNT=0
FAIL_COUNT=0
FAILED_GATES=""

run_gate() {
    local label="$1" script="$2"
    shift 2
    if [ ! -x "$script" ]; then
        echo "  [WARN] $label: gate script not executable, skipping ($script)"
        return
    fi
    if bash "$script" "$@" >/dev/null 2>&1; then
        echo "  [PASS] $label"
        PASS_COUNT=$((PASS_COUNT + 1))
    else
        echo "  [FAIL] $label  (run \`bash $script\` for diagnostic)"
        FAILED_GATES="${FAILED_GATES} $label"
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
}

run_gate "Market Scout"     "$SCRIPT_DIR/market-scout-gate.sh"     "$PROJECT"
run_gate "Cover Brief"      "$SCRIPT_DIR/cover-brief-gate.sh"      "$PROJECT"
run_gate "Marketing Pack"   "$SCRIPT_DIR/marketing-pack-gate.sh"   "$PROJECT"
run_gate "KDP Metadata"     "$SCRIPT_DIR/kdp-metadata-gate.sh"     "$PROJECT"

# Manuscript export check: at least one rendered manuscript present.
# (DOCX integrity is checked at write-time per format-docx.md; here we
# only verify *something* shipped.)
MANUSCRIPT_DIR="$PROJECT/manuscript"
EXPORT_FOUND=""
if [ -d "$MANUSCRIPT_DIR" ]; then
    for ext in docx epub pdf rtf; do
        for f in "$MANUSCRIPT_DIR"/*."$ext"; do
            if [ -f "$f" ] && [ -s "$f" ]; then
                EXPORT_FOUND="$f"
                break 2
            fi
        done
    done
fi
if [ -n "$EXPORT_FOUND" ]; then
    echo "  [PASS] Manuscript Export ($EXPORT_FOUND)"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "  [FAIL] Manuscript Export  (no .docx / .epub / .pdf / .rtf found in $MANUSCRIPT_DIR)"
    FAILED_GATES="${FAILED_GATES} Manuscript-Export"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

echo ""
echo "Pass: $PASS_COUNT | Fail: $FAIL_COUNT"
echo ""

if [ "$FAIL_COUNT" -eq 0 ]; then
    echo "LAUNCH READINESS GATE: PASS — project is ready to ship"
    exit 0
fi

echo "LAUNCH READINESS GATE: FAIL — project is NOT launch-ready" >&2
echo "Failing constituents:$FAILED_GATES" >&2
echo "" >&2
echo "ACTION: re-run each failing constituent gate directly for its specific" >&2
echo "  diagnostic + ACTION instructions. The launch readiness gate is the" >&2
echo "  composite check; the failing gate scripts have the prescriptive fixes." >&2
echo "" >&2
echo "Opt-outs (if the launch-readiness check itself is genuinely out of scope):" >&2
echo "  append to $CONFIG:" >&2
echo "    launch_readiness_status: legacy   # pre-v2.7.68 project" >&2
echo "    launch_readiness_status: skip     # bypass meta-check entirely" >&2
exit 1
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
