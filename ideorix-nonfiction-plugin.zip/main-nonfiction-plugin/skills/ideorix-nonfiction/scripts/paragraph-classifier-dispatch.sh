#!/bin/bash
# ============================================================
# Ideorix — Paragraph Classifier Dispatch (v2.7.67)
# User-invoked Class B audit dispatcher. Preflights that the
# chapter + voice-profile are present and substantive, then
# emits the CLASS_B_AUDIT marker line the engine reads to
# dispatch the subagent. Same dispatch-only pattern as
# voice-restoration-brief.sh (v2.7.66).
#
# This script does NOT itself produce classifications. The
# classification is semantic work that requires a subagent.
# Bash's job is to fail loudly on missing preconditions BEFORE
# the subagent dispatch so the classifier never has to write
# "voice-profile.md is empty" as its first output.
# ============================================================
# Usage: bash paragraph-classifier-dispatch.sh <project-root> <chapter-N>
#
# Preflight checks:
#   1. project root exists + is a directory
#   2. chapter-N is a positive integer
#   3. engine-data/chapters/ch{NN}.md exists + has >100 words
#      (post-frontmatter strip; <100 words means there's
#      nothing meaningful to classify)
#   4. engine-data/voice-profile.md passes voice-profile-preload
#      gate (the classifier reads voice_prose_description to
#      disambiguate ANCHOR-NARRATIVE vs ANALYTICAL-AUTHOR per
#      project register; skeleton profile would force a generic
#      classification)
#
# When all preflight passes, the script:
#   - prints a context summary (paths + paragraph count estimate)
#   - emits the CLASS_B_AUDIT marker line for the engine
#   - exits 0
#
# Exit codes:
#   0   preflight passed; CLASS_B_AUDIT marker emitted
#   1   preflight failed (specific message identifies which check)
#   2   invalid arguments

set -uo pipefail

PROJECT="${1:?Usage: paragraph-classifier-dispatch.sh <project-root> <chapter-N>}"
CHAPTER_N="${2:?Usage: paragraph-classifier-dispatch.sh <project-root> <chapter-N>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi
if ! [[ "$CHAPTER_N" =~ ^[0-9]+$ ]] || [ "$CHAPTER_N" -lt 1 ]; then
    echo "ERROR: chapter-N must be a positive integer, got: $CHAPTER_N" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHAPTER_NN=$(printf '%02d' "$CHAPTER_N")

CHAPTER_FILE="$PROJECT/engine-data/chapters/ch${CHAPTER_NN}.md"
RETURN_PATH="$PROJECT/engine-data/reports/validate/paragraph-classifier-ch${CHAPTER_NN}-subagent.md"

echo "=== PARAGRAPH CLASSIFIER — preflight ==="
echo "Project: $PROJECT"
echo "Chapter: ch${CHAPTER_NN}"
echo ""

# Check 3: chapter exists + substantive content
if [ ! -f "$CHAPTER_FILE" ]; then
    echo "PREFLIGHT FAIL — chapter file not found: $CHAPTER_FILE" >&2
    echo "  ACTION: confirm the chapter exists under engine-data/chapters/" >&2
    echo "  (filename must be ch${CHAPTER_NN}.md — zero-padded two-digit format)" >&2
    exit 1
fi

if head -1 "$CHAPTER_FILE" | grep -qE '^---[[:space:]]*$'; then
    WORD_COUNT=$(awk 'NR==1{next} /^---[[:space:]]*$/ && !done {done=1; next} done{print}' "$CHAPTER_FILE" | wc -w)
else
    WORD_COUNT=$(wc -w < "$CHAPTER_FILE")
fi

if [ "$WORD_COUNT" -lt 100 ]; then
    echo "PREFLIGHT FAIL — chapter has only $WORD_COUNT words after frontmatter strip" >&2
    echo "  Paragraph classification on a <100-word chapter isn't meaningful." >&2
    echo "  ACTION: verify the chapter file is the expected one." >&2
    exit 1
fi

# Check 4: voice-profile.md preload gate
PRELOAD_GATE="$SCRIPT_DIR/voice-profile-preload-gate.sh"
if [ ! -x "$PRELOAD_GATE" ]; then
    echo "ERROR: voice-profile-preload-gate.sh not found or not executable: $PRELOAD_GATE" >&2
    exit 2
fi
if ! bash "$PRELOAD_GATE" "$PROJECT" >/dev/null 2>&1; then
    echo "PREFLIGHT FAIL — voice-profile.md is missing, empty, or skeleton-only." >&2
    echo "  Run for diagnostic:" >&2
    echo "    bash $PRELOAD_GATE \"$PROJECT\"" >&2
    echo "  The classifier reads voice_prose_description to disambiguate" >&2
    echo "  author-voice categories per project; without it the classification" >&2
    echo "  would be generic." >&2
    exit 1
fi

# Rough paragraph count for the context summary.
PARA_EST=$(if head -1 "$CHAPTER_FILE" | grep -qE '^---[[:space:]]*$'; then
    awk 'NR==1{next} /^---[[:space:]]*$/ && !done {done=1; next} done{print}' "$CHAPTER_FILE"
else
    cat "$CHAPTER_FILE"
fi | awk 'BEGIN{p=0; in_para=0} /^[[:space:]]*$/ {if (in_para) {p++; in_para=0}} /[^[:space:]]/ {if ($0 !~ /^#/) in_para=1} END{if (in_para) p++; print p}')

mkdir -p "$(dirname "$RETURN_PATH")"

echo "PREFLIGHT PASS — all preconditions satisfied"
echo ""
echo "Context summary:"
echo "  Chapter file:      $CHAPTER_FILE ($WORD_COUNT words post-frontmatter)"
echo "  Paragraph estimate: ~$PARA_EST (subagent will produce exact count)"
echo "  Voice profile:     $PROJECT/engine-data/voice-profile.md"
echo "  Classifier return: $RETURN_PATH"
echo ""
echo "Engine layer must now dispatch the paragraph-classifier"
echo "subagent per references/paragraph-classifier.md. The"
echo "subagent's structured return MUST land at:"
echo "  $RETURN_PATH"
echo ""
echo "After landing, the engine HARD GATE applies (shape check +"
echo "classification completeness vs chapter paragraph count +"
echo "summary consistency + class validity + verdict consistency)."
echo "Once verified, voice-metrics-audit.sh picks up the artifact"
echo "automatically on its next run and emits semantic_fp_ratio"
echo "alongside the existing fp_ratio in voice-metrics-ledger.md."
echo ""

echo "CLASS_B_AUDIT|paragraph-classifier|VOICE|references/paragraph-classifier.md|-"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
