#!/bin/bash
# ============================================================
# Ideorix — Corrections Promotion Scan (v2.7.74)
# Scans engine-data/author-corrections.md for repeated corrections
# (3+ occurrences of the same (category, field, from, to) group
# with canon-status: not-yet-promoted) and reports each group as
# a canon-promotion candidate for user review.
#
# This is the deterministic promotion gate that closes the loop:
# the orchestrator logs corrections at detection time (LLM-side,
# possibly miss-able); this script surfaces repeated patterns
# regardless of whether the orchestrator captured every instance.
#
# See references/author-corrections.md for the full architecture
# and format specification.
# ============================================================
# Usage: bash corrections-promotion-scan.sh <path-to-author-corrections.md>
#
# Output: zero or more PROMOTION CANDIDATE sections to stdout.
#   Each section lists:
#     - The grouped key (category, field, from, to)
#     - Occurrence count
#     - Sessions/contexts where the correction appeared
#     - Target canon file based on category
#
# Exit codes:
#   0  scan completed (zero or more candidates reported; advisory only)
#   2  invalid arguments / missing file / unparseable register

set -uo pipefail

LOG="${1:?Usage: corrections-promotion-scan.sh <author-corrections.md>}"

if [ ! -f "$LOG" ]; then
    echo "ERROR: author-corrections.md not found: $LOG" >&2
    exit 2
fi

if [ ! -s "$LOG" ]; then
    echo "CORRECTIONS PROMOTION SCAN: no promotion candidates (register is empty)"
    exit 0
fi

# Delegate parsing + grouping to python3 (more reliable than bash text
# wrangling for the multi-field record format).
python3 - "$LOG" <<'PYTHON'
import sys
import re
from collections import defaultdict

path = sys.argv[1]
try:
    with open(path, encoding='utf-8') as f:
        content = f.read()
except Exception as e:
    print(f"ERROR: could not read {path}: {e}", file=sys.stderr)
    sys.exit(2)

# Split into per-session entries on `## ` headers. The first split
# segment is the file header (above the first `## `); skip it.
segments = re.split(r'\n(?=## )', content)

groups = defaultdict(list)
current_session = None
seen_groups_per_entry = 0

for segment in segments:
    seg = segment.strip()
    if not seg.startswith('## '):
        continue

    # Extract session header — format: `## YYYY-MM-DD — Session N` or
    # `## YYYY-MM-DD — Session unknown`
    header_match = re.match(r'## (\S+)\s*[—\-]\s*Session\s+(\S+)', seg)
    if header_match:
        current_session = f"{header_match.group(1)} (Session {header_match.group(2)})"
    else:
        current_session = "unknown"

    # Parse `- key: value` field lines. A single entry's fields run
    # until either EOF or a blank line followed by another `## ` (the
    # next entry).
    fields = {}
    for line in seg.splitlines():
        line = line.strip()
        m = re.match(r'^-\s+([a-z][a-z0-9_-]*?):\s+(.+)$', line)
        if m:
            key = m.group(1)
            val = m.group(2).strip()
            # Strip wrapping quotes if present
            if (val.startswith('"') and val.endswith('"')) or \
               (val.startswith("'") and val.endswith("'")):
                val = val[1:-1]
            fields[key] = val

    # An entry is groupable only if it has all five required fields
    # AND canon-status is not-yet-promoted.
    required = ('category', 'field', 'from', 'to', 'canon-status')
    if not all(k in fields for k in required):
        continue
    if fields['canon-status'] != 'not-yet-promoted':
        continue

    key = (fields['category'], fields['field'], fields['from'], fields['to'])
    groups[key].append({
        'session': current_session,
        'context': fields.get('context', ''),
    })

candidates = [(k, v) for k, v in groups.items() if len(v) >= 3]

if not candidates:
    print("CORRECTIONS PROMOTION SCAN: no promotion candidates "
          "(no groups with 3+ unpromoted occurrences)")
    sys.exit(0)

CATEGORY_TARGETS = {
    'entity':        'engine-data/entity-canon.md',
    'preference':    'engine-data/project-config.md or engine-data/forbidden-words.md',
    'architectural': 'story-bible.md or research-bible.md §1-3',
    'constraint':    'story-bible.md or research-bible.md §3',
    'chronology':    'story-bible.md or research-bible.md §4 (timeline)',
}

# Sort: most-repeated groups first
candidates.sort(key=lambda x: (-len(x[1]), x[0]))

print(f"CORRECTIONS PROMOTION SCAN: {len(candidates)} promotion candidate(s)")
print()

for (cat, field, frm, to), occurrences in candidates:
    print(f"--- PROMOTION CANDIDATE ({len(occurrences)} occurrences) ---")
    print(f"  Category:    {cat}")
    print(f"  Field:       {field}")
    print(f"  Correction:  \"{frm}\" → \"{to}\"")
    target = CATEGORY_TARGETS.get(cat, f"(unknown category '{cat}' — manual canon decision)")
    print(f"  Target canon: {target}")
    print(f"  Sessions ({min(len(occurrences), 5)} of {len(occurrences)} shown):")
    for occ in occurrences[:5]:
        ctx = f" — {occ['context']}" if occ['context'] else ""
        print(f"    - {occ['session']}{ctx}")
    if len(occurrences) > 5:
        print(f"    (... and {len(occurrences) - 5} more)")
    print()

print("To promote a candidate:")
print("  1. Update the target canon file with the correction.")
print("  2. Mark every entry in author-corrections.md for this group")
print("     with: canon-status: promoted")
print()
print("To defer a candidate, leave entries as-is (will resurface on next scan).")
print("To reject a candidate, mark entries as: canon-status: rejected")
PYTHON

exit $?
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
