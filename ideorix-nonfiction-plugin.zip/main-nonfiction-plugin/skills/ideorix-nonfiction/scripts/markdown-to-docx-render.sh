#!/bin/bash
# ============================================================
# Ideorix — Shared Markdown-to-DOCX Manuscript Renderer (v2.7.76)
# Converts a project's chapter markdown files into a single .docx
# manuscript via pandoc, with optional reference template for
# styling and optional YAML config for metadata.
#
# Architecture-level fix for the v2.7.x class of ad-hoc per-project
# DOCX generation scripts that re-implemented markdown parsing
# fresh each time. The most-recent symptom was an infinite-loop on
# literal asterisks in source text (model numbers like "SL*18"
# tripping the parser's italic-emphasis search). Pandoc handles
# this and similar inline edge cases robustly; this script wraps
# pandoc so projects share one tested rendering path instead of
# each writing their own.
#
# v2.7.76 foundation scope:
#   - Single-line chapter title format
#   - Body paragraphs + scene breaks
#   - YAML config for project metadata (title, author)
#   - Optional reference template for styling
#   - Integration with docx-integrity-check.sh
#   - Opt-in via project-config.md
#
# NOT yet supported (incremental follow-up):
#   - Two-line chapter titles
#   - ### Section subheadings inside chapters
#   - Front matter / back matter rendering
#   - Footnotes (pandoc supports them natively but no engine
#     orchestration around placement / formatting)
#   - Genre-specific layouts (cookbook recipe blocks, screenplay)
#   - Multi-volume aggregation
#
# See references/markdown-to-docx-render.md for the full spec.
# ============================================================
# Usage: bash markdown-to-docx-render.sh <project-root> [--output <path>]
#
# <project-root>: path to the Ideorix project (e.g.,
#                 ~/Documents/Ideorix-Projects/My-Book/).
#                 The script reads engine-data/chapters/ch*.md and
#                 (if present) engine-data/render-config.yaml +
#                 engine-data/render-template.docx.
#
# Options:
#   --output <path>    Override default output path
#                      (default: <project-root>/engine-data/manuscript.docx)
#   --config <path>    Override config path
#                      (default: <project-root>/engine-data/render-config.yaml)
#   --template <path>  Override reference template path
#                      (default: <project-root>/engine-data/render-template.docx
#                       if present; pandoc default styling otherwise)
#
# Exit codes:
#   0  success — DOCX produced and passed integrity check
#   1  invalid arguments / project structure
#   2  no chapter files found
#   3  pandoc not installed (with install hint)
#   4  pandoc invocation failed
#   5  output DOCX failed integrity check

set -uo pipefail

PROJECT=""
OUTPUT_OVERRIDE=""
CONFIG_OVERRIDE=""
TEMPLATE_OVERRIDE=""

while [ $# -gt 0 ]; do
    case "$1" in
        --output)
            OUTPUT_OVERRIDE="${2:-}"
            shift 2
            ;;
        --config)
            CONFIG_OVERRIDE="${2:-}"
            shift 2
            ;;
        --template)
            TEMPLATE_OVERRIDE="${2:-}"
            shift 2
            ;;
        --help|-h)
            sed -n '/^# Usage:/,/^# Exit codes:/p' "$0" | sed 's/^# //; s/^#//'
            exit 0
            ;;
        *)
            if [ -z "$PROJECT" ]; then
                PROJECT="$1"
            fi
            shift
            ;;
    esac
done

if [ -z "$PROJECT" ]; then
    echo "Usage: markdown-to-docx-render.sh <project-root> [--output <path>] [--config <path>] [--template <path>]" >&2
    exit 1
fi

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 1
fi

CHAPTER_DIR="$PROJECT/engine-data/chapters"
if [ ! -d "$CHAPTER_DIR" ]; then
    echo "ERROR: chapter directory not found: $CHAPTER_DIR" >&2
    exit 2
fi

# Default paths (overridable via flags)
CONFIG="${CONFIG_OVERRIDE:-$PROJECT/engine-data/render-config.yaml}"
TEMPLATE="${TEMPLATE_OVERRIDE:-$PROJECT/engine-data/render-template.docx}"
OUTPUT="${OUTPUT_OVERRIDE:-$PROJECT/engine-data/manuscript.docx}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INTEGRITY_CHECK="$SCRIPT_DIR/docx-integrity-check.sh"

# Collect chapter files in numeric order. We check chapter discovery
# before pandoc availability because "no chapters" is the more
# specific (and more user-actionable) error when both conditions hold.
shopt -s nullglob 2>/dev/null || true
CHAPTERS=()
while IFS= read -r f; do
    CHAPTERS+=("$f")
done < <(find "$CHAPTER_DIR" -maxdepth 1 -type f -name 'ch*.md' | sort)

if [ "${#CHAPTERS[@]}" -eq 0 ]; then
    echo "ERROR: no chapter files (ch*.md) found in $CHAPTER_DIR" >&2
    exit 2
fi

echo "MANUSCRIPT RENDER: found ${#CHAPTERS[@]} chapter file(s) in $CHAPTER_DIR"

# Pandoc check
if ! command -v pandoc >/dev/null 2>&1; then
    echo "ERROR: pandoc not installed" >&2
    case "$(uname -s)" in
        Darwin) echo "  Install: brew install pandoc" >&2 ;;
        Linux)
            if command -v apt >/dev/null 2>&1; then
                echo "  Install: sudo apt install pandoc" >&2
            elif command -v dnf >/dev/null 2>&1; then
                echo "  Install: sudo dnf install pandoc" >&2
            else
                echo "  Install: see https://pandoc.org/installing.html" >&2
            fi
            ;;
        MINGW*|MSYS*|CYGWIN*) echo "  Install: winget install pandoc" >&2 ;;
        *) echo "  Install: see https://pandoc.org/installing.html" >&2 ;;
    esac
    exit 3
fi

# Optional config: extract title + author for pandoc metadata
TITLE=""
AUTHOR=""
if [ -f "$CONFIG" ]; then
    # Minimal YAML parsing — single-line key: value pairs at top level only.
    # Sufficient for the foundation scope (title + author); incremental
    # follow-ups can extend to richer config via python3.
    TITLE=$(grep -E '^title:' "$CONFIG" | head -1 | sed -E 's/^title:[[:space:]]*//; s/^"//; s/"$//' || true)
    AUTHOR=$(grep -E '^author:' "$CONFIG" | head -1 | sed -E 's/^author:[[:space:]]*//; s/^"//; s/"$//' || true)
fi

# Concatenate chapters into a single staging markdown via same-FS temp.
# Same-FS temp follows the v2.7.73 file-write hygiene rule (Linux /tmp
# would EPERM on Cowork-Windows when mv'd to the Windows-mounted output).
STAGED="$PROJECT/engine-data/.manuscript-staged.tmp.$$.md"
trap 'rm -f "$STAGED"' EXIT

{
    # Pandoc metadata block (rendered into the docx as title page if
    # the reference template supports it; otherwise inlined as a top
    # heading + by-line).
    if [ -n "$TITLE" ] || [ -n "$AUTHOR" ]; then
        echo "---"
        [ -n "$TITLE" ] && echo "title: \"$TITLE\""
        [ -n "$AUTHOR" ] && echo "author: \"$AUTHOR\""
        echo "---"
        echo ""
    fi

    for f in "${CHAPTERS[@]}"; do
        # Strip per-chapter YAML frontmatter (chapter metadata) so only
        # the prose body lands in the manuscript.
        python3 -c '
import sys
path = sys.argv[1]
with open(path, encoding="utf-8") as fh:
    content = fh.read()
if content.startswith("---"):
    end = content.find("---", 3)
    if end != -1:
        content = content[end + 3:].lstrip()
sys.stdout.write(content)
' "$f"
        echo ""
        echo ""
    done
} > "$STAGED"

# Verify staged file is non-empty and clean before invoking pandoc.
# Same integrity invariants we apply to chapter writes.
if [ ! -s "$STAGED" ]; then
    echo "ERROR: staged manuscript is zero bytes ($STAGED) — aborting" >&2
    exit 4
fi
if grep -qaP '\x00' "$STAGED" 2>/dev/null; then
    echo "ERROR: staged manuscript contains NULL bytes ($STAGED) — aborting" >&2
    exit 4
fi

# Invoke pandoc. Reference template is optional; pandoc uses sensible
# defaults if not provided.
PANDOC_ARGS=(-f markdown -t docx -o "$OUTPUT")
if [ -f "$TEMPLATE" ]; then
    PANDOC_ARGS+=(--reference-doc="$TEMPLATE")
    echo "MANUSCRIPT RENDER: using reference template $TEMPLATE"
else
    echo "MANUSCRIPT RENDER: no reference template found at $TEMPLATE — using pandoc defaults"
fi

if ! pandoc "${PANDOC_ARGS[@]}" "$STAGED" 2>/dev/null; then
    echo "ERROR: pandoc invocation failed" >&2
    echo "  Re-running with stderr surfaced for diagnosis:" >&2
    pandoc "${PANDOC_ARGS[@]}" "$STAGED" >&2 || true
    exit 4
fi

echo "MANUSCRIPT RENDER: wrote $OUTPUT"

# Post-render integrity check (v2.7.64 docx-integrity-check.sh catches
# NULL bytes in word/document.xml — same shape we catch for chapter
# markdown writes).
if [ -f "$INTEGRITY_CHECK" ]; then
    if bash "$INTEGRITY_CHECK" "$OUTPUT" >/dev/null 2>&1; then
        echo "MANUSCRIPT RENDER: PASS — integrity check clean"
    else
        echo "ERROR: output DOCX failed integrity check ($OUTPUT)" >&2
        echo "  Run: bash $INTEGRITY_CHECK $OUTPUT" >&2
        echo "  for the full diagnostic." >&2
        exit 5
    fi
else
    echo "MANUSCRIPT RENDER: WARN — docx-integrity-check.sh not found at $INTEGRITY_CHECK"
    echo "  Output produced but not verified."
fi

exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
