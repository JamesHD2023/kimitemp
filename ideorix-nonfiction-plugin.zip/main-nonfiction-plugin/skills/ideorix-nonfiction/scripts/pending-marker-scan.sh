#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Pending-Marker Scan
# Scans manuscript and chapter-note files for unresolved
# fact-audit / verification placeholders that must be resolved
# before Stage 13 (NF) / Pre-Pub Verification (fiction) can
# grant READY status.
#
# Failure mode addressed (v2.7.11):
# A user shipped a multi-chapter NF manuscript where six
# substantive factual errors survived all 13 editorial pipeline
# stages. The engine's own self-diagnosis identified that
# chapter notes carrying placeholder language like
# "(specific patent number pending fact-audit)" were treated
# as future tasks rather than as HARD GATEs that must be
# resolved before publication readiness. This script is the
# deterministic detector for that class of placeholder.
#
# Wired into:
#   - Stage 9b (NF External Source Verification) as a
#     prerequisite check before per-claim verification runs
#   - Stage 13 Verification Discipline Gate (NF) as a
#     blocking sub-gate
#   - Fiction Stage 9 (Continuity Audit) when real-world
#     anchors are present — same rule
#
# Patterns detected (case-insensitive):
#   - pending fact-audit
#   - pending Phase 5 fact-audit
#   - pending Phase 4 fact-audit
#   - to be verified
#   - TBD
#   - TK / TKTK (placeholder convention)
#   - specific [X] number pending
#   - (figure pending
#   - [verify]
#   - [check]
#   - [citation needed]
#   - [source needed]
#   - pending verification
#   - TODO: verify
#   - TODO: check
#   - TODO: source
#
# Accepts:
#   - A directory (recursively scans all .md files)
#   - A single file
#
# Exit:
#   0 = clean (no pending markers found)
#   1 = pending markers found (HARD GATE — Stage 13 cannot proceed)
#   2 = invocation error (missing path, etc.)
# ============================================================
set -euo pipefail

usage() {
    echo "Usage: pending-marker-scan.sh <file-or-directory> [--quiet]"
    echo ""
    echo "Scans .md files for unresolved fact-audit placeholders."
    echo "If a directory is given, recursively scans all .md files."
    echo "Exit 0 = clean, 1 = markers found, 2 = invocation error."
    exit 2
}

PATH_ARG="${1:-}"
QUIET="${2:-}"

if [ -z "$PATH_ARG" ]; then usage; fi
if [ ! -e "$PATH_ARG" ]; then echo "ERROR: path not found: $PATH_ARG"; exit 2; fi

# Patterns. Each entry: a case-insensitive grep -E pattern.
PATTERNS=(
    'pending fact-audit'
    'pending phase [0-9]+ fact-audit'
    'pending verification'
    'to be verified'
    '\bTBD\b'
    '\bTKTK?\b'
    'specific .{1,40} pending'
    '\(figure pending'
    '\[verify\]'
    '\[check\]'
    '\[citation needed\]'
    '\[source needed\]'
    'TODO[: ]+verify'
    'TODO[: ]+check'
    'TODO[: ]+source'
    'TODO[: ]+confirm'
    'TODO[: ]+fact'
)

# Build the alternation regex.
REGEX=""
for p in "${PATTERNS[@]}"; do
    if [ -z "$REGEX" ]; then REGEX="$p"; else REGEX="$REGEX|$p"; fi
done

# Collect target files.
TARGET_FILES=()
if [ -d "$PATH_ARG" ]; then
    while IFS= read -r f; do TARGET_FILES+=("$f"); done < <(find "$PATH_ARG" -type f -name "*.md" | LC_ALL=C sort)
elif [ -f "$PATH_ARG" ]; then
    TARGET_FILES+=("$PATH_ARG")
else
    echo "ERROR: not a regular file or directory: $PATH_ARG"
    exit 2
fi

if [ "${#TARGET_FILES[@]}" -eq 0 ]; then
    if [ "$QUIET" != "--quiet" ]; then
        echo "[PASS] pending-marker-scan — no .md files found in $PATH_ARG"
    fi
    exit 0
fi

# Scan. For each file, grep -i -E -n -H against the alternation.
TMPOUT=$(mktemp)
trap 'rm -f "$TMPOUT"' EXIT

TOTAL_HITS=0
for f in "${TARGET_FILES[@]}"; do
    # -i case-insensitive, -E extended regex, -n line numbers, -H always
    # show filename. `|| true` keeps set -e happy when grep finds nothing.
    HITS=$(grep -i -E -n -H "$REGEX" "$f" 2>/dev/null || true)
    if [ -n "$HITS" ]; then
        echo "$HITS" >> "$TMPOUT"
        # Count lines (each hit is one line)
        N=$(echo "$HITS" | wc -l)
        TOTAL_HITS=$((TOTAL_HITS + N))
    fi
done

if [ "$TOTAL_HITS" -eq 0 ]; then
    if [ "$QUIET" != "--quiet" ]; then
        echo "[PASS] pending-marker-scan — ${#TARGET_FILES[@]} file(s) clean (no unresolved fact-audit placeholders)"
    fi
    exit 0
fi

echo "[FAIL] pending-marker-scan — $TOTAL_HITS unresolved placeholder(s) in ${#TARGET_FILES[@]} scanned file(s)"
echo ""
echo "Unresolved fact-audit placeholders found:"
echo ""
sed 's|^|  |' "$TMPOUT"
echo ""
echo "Each placeholder MUST be resolved before Stage 13 (NF) / Pre-Pub Verification (fiction)"
echo "can grant READY status. Three resolutions per placeholder:"
echo "  1. Fill in the verified data (preferred)"
echo "  2. Rephrase the claim to remove the unverifiable specific"
echo "  3. Soften to a hedged general framing (e.g. 'is widely credited with' rather than"
echo "     'patented in 1872') with the evidence available"
echo ""
echo "Re-run this script after resolution to confirm zero matches."
exit 1
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
