#!/bin/bash
# ============================================================
# Ideorix — Pre-Flight Gate (Cowork Phase 3 / Fix 11)
# Blocks chapter generation until the per-chapter pre-flight
# checklist is satisfied. Catches the common failure mode of
# starting to write a chapter without the architectural
# prerequisites (Story Bible loaded, prior chapter summary on
# file, entity canon current, prior chapter editorial pass
# complete where applicable).
#
# Fail-closed: exits non-zero if any required item is missing.
# ============================================================
# Usage: bash pre-flight-gate.sh <project-root> <chapter-N>
# - project-root: path to Ideorix-Projects/{Book}
# - chapter-N:    integer, the chapter ABOUT to be written
#
# The pre-flight checklist requires (for chapter N):
#   1. engine-data/story-bible.md exists (fiction)
#      OR engine-data/research-bible.md exists (NF)
#   2. engine-data/pipeline-checkpoint.md exists
#   3. If N > 1: prior chapter summary present at
#      engine-data/summaries/ch{N-1}-summary.md OR an inline
#      checkpoint marker "Chapter {N-1}: complete"
#   4. engine-data/entity-canon.md exists (fiction) — optional
#      warning, not a hard fail (the canon may not yet exist
#      on the very first run; warn if missing past chapter 3)
#
# Exit codes:
#   0  pre-flight checklist satisfied (PASS)
#   1  checklist incomplete — gate is failing (FAIL)
#   2  invalid arguments

set -euo pipefail

PROJECT="${1:?Usage: pre-flight-gate.sh <project-root> <chapter-N>}"
CHAPTER_N="${2:?Usage: pre-flight-gate.sh <project-root> <chapter-N>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

if ! [[ "$CHAPTER_N" =~ ^[0-9]+$ ]]; then
    echo "ERROR: chapter-N must be a positive integer, got: $CHAPTER_N" >&2
    exit 2
fi

ENGINE_DATA="$PROJECT/engine-data"
CHECKPOINT="$ENGINE_DATA/pipeline-checkpoint.md"
STORY_BIBLE="$ENGINE_DATA/story-bible.md"
RESEARCH_BIBLE="$ENGINE_DATA/research-bible.md"
ENTITY_CANON="$ENGINE_DATA/entity-canon.md"
SUMMARIES_DIR="$ENGINE_DATA/summaries"
CONFIG="$ENGINE_DATA/project-config.md"

# Honest opt-out — if project-config.md declares this project's
# pre-flight as legacy (chapters were written before the Cowork
# Phase 3 pre-flight checklist existed; the prerequisites the gate
# wants to see may not exist on disk in the expected form), pass
# with a note instead of blocking. Same legacy-through refinement
# as outline-conformance: cap the legacy window at chapter N.
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*pre_flight_status:[[:space:]]*legacy\b' "$CONFIG"; then
        # legacy_through is optional; { ... || true; } keeps the no-match
        # grep from tripping pipefail. Both regexes tolerate markdown
        # bullet prefixes (-, *, +) and surrounding whitespace.
        LEGACY_THROUGH=$({ grep -iE '^[[:space:]]*[-*+]?[[:space:]]*pre_flight_legacy_through:' "$CONFIG" || true; } | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*pre_flight_legacy_through:[[:space:]]*//' | sed -E 's/[^0-9].*$//')
        if [ -z "$LEGACY_THROUGH" ] || [ "$CHAPTER_N" -le "$LEGACY_THROUGH" ]; then
            if [ -n "$LEGACY_THROUGH" ]; then
                echo "PRE-FLIGHT GATE: PASS (project-config.md declares pre_flight_status: legacy through chapter ${LEGACY_THROUGH}; chapter ${CHAPTER_N} is within the legacy window)"
            else
                echo "PRE-FLIGHT GATE: PASS (project-config.md declares pre_flight_status: legacy — documented opt-out honored)"
            fi
            exit 0
        fi
    fi
fi

FAIL=0
WARN=0

# Check 1: Bible (story or research) exists
if [ ! -f "$STORY_BIBLE" ] && [ ! -f "$RESEARCH_BIBLE" ]; then
    echo "PRE-FLIGHT GATE: FAIL — neither $STORY_BIBLE nor $RESEARCH_BIBLE exists." >&2
    echo "  ACTION: complete the Bible-building phase before generating chapter ${CHAPTER_N}." >&2
    FAIL=1
fi

# Check 2: pipeline-checkpoint.md exists
if [ ! -f "$CHECKPOINT" ]; then
    echo "PRE-FLIGHT GATE: FAIL — no pipeline-checkpoint.md at $CHECKPOINT." >&2
    echo "  ACTION: complete project setup; the Architect creates the checkpoint when generation begins." >&2
    FAIL=1
fi

# Check 3: prior chapter evidence (only for chapter 2+)
if [ "$CHAPTER_N" -gt 1 ]; then
    PREV=$((CHAPTER_N - 1))
    PREV_SUMMARY=$(printf '%s/ch%02d-summary.md' "$SUMMARIES_DIR" "$PREV")
    PREV_SUMMARY_NOPAD="$SUMMARIES_DIR/ch${PREV}-summary.md"
    PRIOR_OK=0
    if [ -f "$PREV_SUMMARY" ] || [ -f "$PREV_SUMMARY_NOPAD" ]; then
        PRIOR_OK=1
    fi
    if [ -f "$CHECKPOINT" ] && grep -qiE "^Chapter ${PREV}:[[:space:]]*complete" "$CHECKPOINT"; then
        PRIOR_OK=1
    fi
    if [ "$PRIOR_OK" -ne 1 ]; then
        echo "PRE-FLIGHT GATE: FAIL — no evidence chapter $PREV is complete." >&2
        echo "  Looked for: $PREV_SUMMARY (or unpadded), or 'Chapter $PREV: complete' in checkpoint." >&2
        echo "  ACTION: produce the prior chapter summary, or append the checkpoint line." >&2
        FAIL=1
    fi
fi

# Check 4 (warning, not hard fail): entity-canon present after chapter 3
if [ "$CHAPTER_N" -gt 3 ] && [ ! -f "$ENTITY_CANON" ]; then
    echo "PRE-FLIGHT GATE: WARNING — no entity-canon.md after chapter 3 ($ENTITY_CANON)." >&2
    echo "  Recommended: run the entity canon verifier; consistency drift is hard to recover later." >&2
    WARN=1
fi

# Check 5 (v2.7.62 — hard fail): prior chapter's Class B Delta Pass ran.
# When starting chapter N (N > 1), chapter N-1's per-chapter Class B Delta
# Pass (Rule 1b in mandatory-pipeline-rules.md) must have produced its
# expected artifacts. class-b-delta-gate.sh enforces that; invoking it
# here means the pre-flight cycle blocks chapter N if N-1's delta pass
# was skipped. Honors the class_b_delta_status: skip opt-out.
if [ "$CHAPTER_N" -gt 1 ]; then
    PREV_CHAPTER=$((CHAPTER_N - 1))
    DELTA_GATE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/class-b-delta-gate.sh"
    if [ -x "$DELTA_GATE" ]; then
        if ! bash "$DELTA_GATE" "$PROJECT" "$PREV_CHAPTER" >/dev/null 2>&1; then
            echo "PRE-FLIGHT GATE: FAIL — chapter ${PREV_CHAPTER} Class B Delta Pass did not run (Rule 1b)." >&2
            echo "  Re-run the delta pass for chapter ${PREV_CHAPTER}:" >&2
            echo "    bash scripts/validate-dispatcher.sh \"$PROJECT\" delta $PREV_CHAPTER" >&2
            echo "  For diagnostic of which artifacts are missing:" >&2
            echo "    bash $DELTA_GATE \"$PROJECT\" $PREV_CHAPTER" >&2
            echo "  Then re-run pre-flight for chapter ${CHAPTER_N}." >&2
            FAIL=1
        fi
    fi
fi

# Check 6 (v2.7.65 — hard fail): voice-profile.md preloaded.
# Rule 5 (mandatory-pipeline-rules.md) requires the voice profile to be
# loaded before generation. v2.7.64 and earlier enforced this only as an
# LLM contract ("the Writer prompt has the voice profile loaded"); the
# 6-book NF series drift diagnostic showed that LLM-contract enforcement
# is insufficient — chapters drift even when the contract is "satisfied".
# v2.7.65 adds the artifact-level enforcement: voice-profile.md must
# exist + be populated. Honors voice_profile_status: legacy / skip.
PRELOAD_GATE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/voice-profile-preload-gate.sh"
if [ -x "$PRELOAD_GATE" ]; then
    if ! bash "$PRELOAD_GATE" "$PROJECT" >/dev/null 2>&1; then
        echo "PRE-FLIGHT GATE: FAIL — voice-profile.md preload check failed (Rule 5)." >&2
        echo "  For diagnostic of what's missing:" >&2
        echo "    bash $PRELOAD_GATE \"$PROJECT\"" >&2
        echo "  See references/voice-profile.md for the canonical template." >&2
        FAIL=1
    fi
fi

if [ "$FAIL" -eq 1 ]; then
    echo "PRE-FLIGHT GATE: FAIL — chapter ${CHAPTER_N} cannot proceed." >&2
    echo "" >&2
    echo "Or, if this manuscript pre-dates the Cowork Phase 3 pre-flight checklist" >&2
    echo "and you are working on existing chapters, append:" >&2
    echo "  $CONFIG" >&2
    echo "  pre_flight_status: legacy" >&2
    echo "  pre_flight_legacy_through: <highest legacy chapter>   (optional cap)" >&2
    exit 1
fi

if [ "$WARN" -eq 1 ]; then
    echo "PRE-FLIGHT GATE: PASS (with warnings — see above) for chapter ${CHAPTER_N}"
else
    echo "PRE-FLIGHT GATE: PASS for chapter ${CHAPTER_N}"
fi
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
