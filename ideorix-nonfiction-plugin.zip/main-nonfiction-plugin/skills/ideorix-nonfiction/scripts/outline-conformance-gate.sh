#!/bin/bash
# ============================================================
# Ideorix — Outline Conformance Gate (Cowork Phase 3 / Fix 9)
# Blocks chapter advancement until the just-written chapter's
# beats / arc / target-reveal have been verified against the
# Architect's chapter brief or the manuscript outline.
#
# Fail-closed: exits non-zero if conformance is unverified for
# the current chapter.
# ============================================================
# Usage: bash outline-conformance-gate.sh <project-root> <chapter-N>
# - project-root: path to Ideorix-Projects/{Book}
# - chapter-N:    integer, the chapter just completed
#
# Conformance is "verified" when one of these holds:
#   1. engine-data/reports/outline-conformance-{N}.md exists and
#      contains the line "Status: PASS" (or "Status: pass")
#   2. pipeline-checkpoint.md contains a line of the form
#      "Outline Conformance {N}: complete" (case-insensitive)
#
# Either marker is sufficient. The first is produced by the
# Outline Conformance verifier when it runs and writes a report;
# the second is the in-line checkpoint convention used by other
# gate scripts (e.g. batch-edit-gate.sh).
#
# Exit codes:
#   0  conformance verified for this chapter (PASS)
#   1  not verified — gate is failing (FAIL)
#   2  invalid arguments

set -euo pipefail

PROJECT="${1:?Usage: outline-conformance-gate.sh <project-root> <chapter-N>}"
CHAPTER_N="${2:?Usage: outline-conformance-gate.sh <project-root> <chapter-N>}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

if ! [[ "$CHAPTER_N" =~ ^[0-9]+$ ]]; then
    echo "ERROR: chapter-N must be a positive integer, got: $CHAPTER_N" >&2
    exit 2
fi

REPORTS_DIR="$PROJECT/engine-data/reports"
CHECKPOINT="$PROJECT/engine-data/pipeline-checkpoint.md"
CONFIG="$PROJECT/engine-data/project-config.md"

# Honest opt-out — if project-config.md declares this project's
# outline conformance as legacy (chapters were written before Rule
# 10 existed, retrospective OC reports would catch nothing), pass
# with a note instead of blocking. Optional refinement:
# outline_conformance_legacy_through: <int> caps the legacy window
# at chapter N; chapters above N still require a real report.
if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*outline_conformance_status:[[:space:]]*legacy\b' "$CONFIG"; then
        # legacy_through is optional; { ... || true; } keeps the no-match
        # grep from tripping pipefail. Both regexes tolerate markdown
        # bullet prefixes (-, *, +) and surrounding whitespace.
        LEGACY_THROUGH=$({ grep -iE '^[[:space:]]*[-*+]?[[:space:]]*outline_conformance_legacy_through:' "$CONFIG" || true; } | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*outline_conformance_legacy_through:[[:space:]]*//' | sed -E 's/[^0-9].*$//')
        if [ -z "$LEGACY_THROUGH" ] || [ "$CHAPTER_N" -le "$LEGACY_THROUGH" ]; then
            if [ -n "$LEGACY_THROUGH" ]; then
                echo "OUTLINE CONFORMANCE GATE: PASS (project-config.md declares outline_conformance_status: legacy through chapter ${LEGACY_THROUGH}; chapter ${CHAPTER_N} is within the legacy window)"
            else
                echo "OUTLINE CONFORMANCE GATE: PASS (project-config.md declares outline_conformance_status: legacy — documented opt-out honored)"
            fi
            exit 0
        fi
    fi
fi

# Path 1: a written conformance report
REPORT_FILE="$REPORTS_DIR/outline-conformance-${CHAPTER_N}.md"
if [ -f "$REPORT_FILE" ]; then
    if grep -qiE '^Status:[[:space:]]*pass\b' "$REPORT_FILE"; then
        echo "OUTLINE CONFORMANCE GATE: PASS (report at $REPORT_FILE shows Status: PASS)"
        exit 0
    fi
    echo "OUTLINE CONFORMANCE GATE: FAIL — report exists at $REPORT_FILE but does not declare Status: PASS." >&2
    echo "ACTION: review the report, address each non-conformance, re-run the verifier, and ensure the report concludes 'Status: PASS'." >&2
    exit 1
fi

# Path 2: a checkpoint marker
if [ -f "$CHECKPOINT" ]; then
    if grep -qiE "^Outline Conformance ${CHAPTER_N}:[[:space:]]*complete" "$CHECKPOINT"; then
        echo "OUTLINE CONFORMANCE GATE: PASS (checkpoint marker for chapter ${CHAPTER_N})"
        exit 0
    fi
fi

# Neither path satisfied
echo "OUTLINE CONFORMANCE GATE: FAIL — chapter ${CHAPTER_N} has no conformance evidence." >&2
echo "ACTION: run the Outline Conformance verifier on chapter ${CHAPTER_N}. The verifier writes its report to:" >&2
echo "  $REPORT_FILE" >&2
echo "Once the report concludes 'Status: PASS', or once the checkpoint contains a line of the form" >&2
echo "  Outline Conformance ${CHAPTER_N}: complete  ($(date -u '+%Y-%m-%dT%H:%M:%SZ'))" >&2
echo "this gate will pass and the chapter may advance." >&2
echo "" >&2
echo "Or, if this manuscript pre-dates Rule 10 and retrospective OC reports would catch" >&2
echo "nothing (the chapters are already written, fact-checked, and humanised), append:" >&2
echo "  $CONFIG" >&2
echo "  outline_conformance_status: legacy" >&2
echo "  outline_conformance_legacy_through: <highest legacy chapter>   (optional cap)" >&2
exit 1
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
