#!/bin/bash
# ============================================================
# Ideorix — Pre-Export Typography Gate (v2.7.68)
# Wraps the existing typography-sweep.sh as a fail-closed gate
# fired BEFORE any DOCX / EPUB / PDF export. Complements
# docx-integrity-check.sh (v2.7.64) which runs POST-write —
# this gate runs PRE-write so typographic artifacts (ASCII
# straight quotes, double-hyphen em-dashes, three-dot ellipses)
# never get baked into the export.
#
# Closes the LLM-contract gap: export-and-publish.md mentioned
# typography-sweep as guidance but didn't enforce it. The Mitch-
# report failure mode (v2.7.4) — silent ASCII-quote insertion
# during Edits — could still leak through to a published book
# if the typography-sweep wasn't run.
# ============================================================
# Usage: bash pre-export-typography-gate.sh <project-root> [<file>]
#
# When <file> is supplied: runs typography-sweep on that single
# file (used by format-docx.md before writing the chapter or
# manuscript DOCX).
#
# When <file> is omitted: scans every engine-data/chapters/ch*.md
# under <project-root>. Fails closed if any chapter has artifacts.
#
# Honors opt-out: typography_status: skip / legacy in
# project-config.md (e.g., projects that genuinely want ASCII
# typography, or pre-v2.7.68 manuscripts where the typography is
# legacy).
#
# Exit codes:
#   0  no artifacts found (PASS)
#   1  typography artifacts present (FAIL)
#   2  invalid arguments / typography-sweep not found

set -uo pipefail

PROJECT="${1:?Usage: pre-export-typography-gate.sh <project-root> [<file>]}"
TARGET_FILE="${2:-}"

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="$PROJECT/engine-data/project-config.md"
SWEEP="$SCRIPT_DIR/typography-sweep.sh"

if [ ! -x "$SWEEP" ]; then
    echo "ERROR: typography-sweep.sh not found or not executable: $SWEEP" >&2
    exit 2
fi

if [ -f "$CONFIG" ]; then
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*typography_status:[[:space:]]*skip\b' "$CONFIG"; then
        echo "PRE-EXPORT TYPOGRAPHY GATE: PASS (project-config.md declares typography_status: skip — documented opt-out honored)"
        exit 0
    fi
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*typography_status:[[:space:]]*legacy\b' "$CONFIG"; then
        echo "PRE-EXPORT TYPOGRAPHY GATE: PASS (project-config.md declares typography_status: legacy — pre-v2.7.68 typography)"
        exit 0
    fi
    # Honor ASCII-target projects (rare; reference / code / technical
    # content where ASCII typography is intentional). The sweep itself
    # supports --target ascii but the gate needs to know to invoke it.
    TYPOGRAPHY_TARGET="curly"
    if grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*typography_target:[[:space:]]*ascii\b' "$CONFIG"; then
        TYPOGRAPHY_TARGET="ascii"
    fi
else
    TYPOGRAPHY_TARGET="curly"
fi

run_sweep_on() {
    local file="$1"
    local rc=0
    bash "$SWEEP" "$file" --target "$TYPOGRAPHY_TARGET" --quiet > /dev/null 2>&1 || rc=$?
    return "$rc"
}

if [ -n "$TARGET_FILE" ]; then
    if [ ! -f "$TARGET_FILE" ]; then
        echo "PRE-EXPORT TYPOGRAPHY GATE: FAIL — target file not found: $TARGET_FILE" >&2
        exit 1
    fi
    if run_sweep_on "$TARGET_FILE"; then
        echo "PRE-EXPORT TYPOGRAPHY GATE: PASS — $TARGET_FILE clean (target=$TYPOGRAPHY_TARGET)"
        exit 0
    else
        echo "PRE-EXPORT TYPOGRAPHY GATE: FAIL — $TARGET_FILE contains typography artifacts (target=$TYPOGRAPHY_TARGET)" >&2
        echo "  Re-run for diagnostic:" >&2
        echo "    bash $SWEEP \"$TARGET_FILE\" --target $TYPOGRAPHY_TARGET" >&2
        echo "  Fix the artifacts in the source markdown BEFORE re-attempting export." >&2
        exit 1
    fi
fi

# No target file → scan all chapters.
CHAPTERS_DIR="$PROJECT/engine-data/chapters"
if [ ! -d "$CHAPTERS_DIR" ]; then
    echo "PRE-EXPORT TYPOGRAPHY GATE: FAIL — chapters directory missing: $CHAPTERS_DIR" >&2
    exit 1
fi

FAIL=0
FAILED_FILES=""
SCANNED=0
for chapter in "$CHAPTERS_DIR"/ch*.md; do
    [ -f "$chapter" ] || continue
    SCANNED=$((SCANNED + 1))
    if ! run_sweep_on "$chapter"; then
        FAILED_FILES="${FAILED_FILES}    $chapter
"
        FAIL=1
    fi
done

if [ "$SCANNED" -eq 0 ]; then
    echo "PRE-EXPORT TYPOGRAPHY GATE: FAIL — no chapter files found in $CHAPTERS_DIR" >&2
    exit 1
fi

if [ "$FAIL" -eq 1 ]; then
    echo "PRE-EXPORT TYPOGRAPHY GATE: FAIL — typography artifacts in $(echo -n "$FAILED_FILES" | wc -l) of $SCANNED chapter(s):" >&2
    printf '%b' "$FAILED_FILES" >&2
    echo "" >&2
    echo "  Re-run for diagnostic on each:" >&2
    echo "    bash $SWEEP <chapter-file> --target $TYPOGRAPHY_TARGET" >&2
    echo "  Fix the artifacts in source markdown BEFORE re-attempting export." >&2
    echo "" >&2
    echo "Opt-outs:" >&2
    echo "  append to $CONFIG:" >&2
    echo "    typography_status: legacy   # pre-v2.7.68 typography accepted as-is" >&2
    echo "    typography_status: skip     # bypass typography checks entirely" >&2
    echo "    typography_target: ascii    # project deliberately uses ASCII typography" >&2
    exit 1
fi

echo "PRE-EXPORT TYPOGRAPHY GATE: PASS — $SCANNED chapter(s) scanned, no artifacts (target=$TYPOGRAPHY_TARGET)"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
