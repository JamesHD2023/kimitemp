#!/usr/bin/env bash
# validate-dispatcher.sh — Canon validation Class-A (mechanical-script) orchestrator.
#
# Invoked by the engine's /validate dispatcher (see references/validate-dispatcher.md).
# Probes for the per-domain mechanical-audit scripts, runs each that exists,
# captures exit code + first-line stdout per script, emits a pipe-delimited
# status line per audit and a per-domain summary line. Class B (subagent) and
# Class C (engine-protocol) audits are handled by the engine itself; this script
# only orchestrates Class A.
#
# Usage:
#   validate-dispatcher.sh <project_root> <selector> [chapter]
#
# Where <selector> is one of:
#   - all                                       (every domain — equivalent to full)
#   - full | architecture | brief | prose       (level scoping, v2.7.28+)
#   - <DOMAIN_NAME>                             (single domain probe)
#
# [chapter] is optional. Applies to prose level; passed as 4th arg to scripts
# that accept a chapter file path (see run_audit). Format: bare integer (e.g. "3").
# At non-prose levels supplying a chapter is a soft warning; ignored.
#
# Output (stdout, pipe-delimited, parseable):
#   AUDIT|<script>|<domain>|<verdict>|<one_line_summary>|<log_path>
#   CLASS_B_AUDIT|<audit_name>|<domain>|<spec_path>|<severity_cap>
#       (v2.7.32+; engine layer dispatches subagent per spec, applies
#       subagent-output-verification HARD GATE on return, merges verdict
#       into briefing. v2.7.37+: severity_cap field — "WARN" means engine
#       MUST downgrade subagent FAIL → WARN before merge; "-" means no
#       cap; field is authoritative for engine runtime behaviour and is
#       sourced from severity_cap_for_audit() registry below)
#   DOMAIN|<domain>|<pass>|<fail>|<warn>|<skipped>|<class_b_pending>
#   OUT_OF_SCOPE|<domain>|level=<level>
#   END|<pass_total>|<fail_total>|<warn_total>|<skipped_total>|<class_b_total>
#
# Logs (per (domain, script)) written to:
#   <project_root>/engine-data/reports/validate/<DOMAIN>-<script>.log
# (v2.7.36+ — see Log-Path Keying section in validate-dispatcher.md)
#
# Engine-neutral: probes for script existence; missing scripts emit SKIP with reason.

set -uo pipefail

if [ $# -lt 2 ]; then
    echo "usage: validate-dispatcher.sh <project_root> <selector> [chapter]" >&2
    echo "  selector: all | full | architecture | brief | prose | delta | restore | classify | <DOMAIN_NAME>" >&2
    exit 2
fi

PROJECT_ROOT="$1"
DOMAIN_ARG="$2"
CHAPTER_ARG="${3:-}"

if [ ! -d "$PROJECT_ROOT" ]; then
    echo "FATAL|project_root_not_found|$PROJECT_ROOT" >&2
    exit 2
fi

# Locate this script's directory — sibling scripts are in the same dir.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

REPORTS_DIR="$PROJECT_ROOT/engine-data/reports/validate"
mkdir -p "$REPORTS_DIR" 2>/dev/null || true

ALL_DOMAINS="LOGIC CONSISTENCY COHERENCE PHYSICS CHARACTER GENRE ECONOMY INTENT_PRESERVATION AI_ISM_DETECTION SHOW_NOT_TELL"

# Domain → mechanical-script mapping (per canon-validation-taxonomy v2.7.26).
# Engine-agnostic; missing scripts are probed and skipped.
scripts_for_domain() {
    case "$1" in
        LOGIC)                echo "outline-conformance-gate.sh pre-flight-gate.sh" ;;
        CONSISTENCY)          echo "entity-canon-verify.sh" ;;
        COHERENCE)            echo "coherence-function-consecutive.sh" ;;
        PHYSICS)              echo "temporal-verify.sh number-7-bias.sh" ;;
        CHARACTER)            echo "" ;;
        GENRE)                echo "market-scout-gate.sh" ;;
        ECONOMY)              echo "forbidden-words-scan.sh pattern-counter.sh word-count-check.sh" ;;
        INTENT_PRESERVATION)  echo "" ;;
        AI_ISM_DETECTION)     echo "forbidden-words-scan.sh pattern-counter.sh formatting-check.sh typography-sweep.sh placeholder-scan.sh pending-marker-scan.sh" ;;
        SHOW_NOT_TELL)        echo "show-not-tell-tells.sh" ;;
        *)                    echo "" ;;
    esac
}

# ── Class B subagent-audit registry (v2.7.32) ─────────────────────────────
# Class B audits are semantic checks that require a subagent (not a bash
# script) to evaluate. The bash dispatcher does NOT itself dispatch
# subagents — it cannot. Instead, for every Class B audit applicable to a
# domain in scope, the dispatcher emits a CLASS_B_AUDIT line of the form:
#
#   CLASS_B_AUDIT|<audit_name>|<domain>|<spec_path>|<severity_cap>
#
# The slash-command engine (Claude driving /validate) reads these lines
# AFTER the bash dispatcher completes, dispatches a subagent per the
# linked spec, applies subagent-output-verification.md HARD GATE on the
# return, applies the severity_cap field (v2.7.37+: "WARN" = downgrade
# subagent FAIL → WARN before merge; "-" = no cap), and merges each
# subagent's evidence-bearing verdict into the final Validation Briefing
# presented to the user.
#
# Registry: domain → space-separated list of Class B audit names. Each
# name resolves to references/<name>.md in the engine.
class_b_audits_for_domain() {
    case "$1" in
        PHYSICS)              echo "injury-accumulation" ;;
        COHERENCE)            echo "leitmotif-tracker" ;;
        CHARACTER)            echo "humanity-gate" ;;
        INTENT_PRESERVATION)  echo "intent-preservation" ;;
        *)                    echo "" ;;
    esac
}

# v2.7.61: parallel registry for the per-chapter Class B Delta Pass.
# Returns the -delta variant audit name for domains that have one;
# returns empty for domains whose Class B audits are manuscript-scope
# only (CHARACTER, INTENT_PRESERVATION). Used by Rule 1b in
# mandatory-pipeline-rules.md.
class_b_delta_audits_for_domain() {
    case "$1" in
        PHYSICS)              echo "injury-accumulation-delta" ;;
        COHERENCE)            echo "leitmotif-tracker-delta" ;;
        CHARACTER)            echo "" ;;
        INTENT_PRESERVATION)  echo "" ;;
        *)                    echo "" ;;
    esac
}

# ── Class B severity-cap registry (v2.7.37) ──────────────────────────────
# Some Class B audits ship with a severity cap — the engine layer must
# downgrade the subagent's FAIL verdict to WARN before merging into the
# Validation Briefing. Caps exist where the audit is sufficiently
# subjective that a FAIL signal would block work on judgment-call
# findings. The cap is canonical engine behaviour, not a per-run option;
# this registry is the single machine-readable source of truth.
#
# Returns one of:
#   WARN  — engine layer caps subagent FAIL → WARN before merge
#   ""    — no cap; subagent verdict passes through unchanged
#
# The corresponding spec MUST also declare `severity_cap: WARN` in its
# frontmatter so a reviewer reading the spec alone sees the cap. Both
# signals must agree; if the spec frontmatter and this registry diverge,
# the registry is authoritative for the engine's runtime behaviour.
severity_cap_for_audit() {
    case "$1" in
        intent-preservation)  echo "WARN" ;;
        *)                    echo "" ;;
    esac
}

# Per-script invocation class (v2.7.29).
# Each existing audit script has its own argument signature; the dispatcher
# branches on script identity rather than passing a uniform <project_root>
# to every script. Class names are dispatcher-internal:
#
#   PROJECT_ONCE     — script takes <project_root>; runs once per dispatcher
#                      invocation regardless of chapter scope (e.g. market-scout-gate)
#   PROJECT_CHAPTER  — script takes <project_root> <chapter_N>; iterates all
#                      chapters when no chapter supplied
#   CHAPTER          — script takes <chapter_file>; iterates all chapters when
#                      no chapter supplied
#   CHAPTER_PROJECT  — script takes <chapter_file> <project_root>; iterates
#   CHAPTER_FORBIDDEN — script takes <chapter_file> <forbidden-words-file>;
#                       resolves forbidden-words location; iterates
#   CHAPTERS_DIR     — script takes engine-data/chapters/ as a directory
#                      argument; one call per dispatcher invocation; used
#                      to avoid recursing into reports/validate/
#   UNKNOWN          — script not in the registry; dispatcher emits SKIP with
#                      the reason "signature unknown — register in
#                      validate-dispatcher.sh script_class()"
# (The header documented a FILE_OR_PROJECT class through v2.7.38 that was
# removed from the registry during the v2.7.29 → v2.7.32 refactor without
# updating the docstring; v2.7.39 removed the dead documentation. The
# CHAPTERS_DIR class added in v2.7.29 was missing from the docstring.)
script_class() {
    case "$1" in
        market-scout-gate.sh|coherence-function-consecutive.sh)
                                           echo "PROJECT_ONCE" ;;
        pre-flight-gate.sh|outline-conformance-gate.sh)
                                           echo "PROJECT_CHAPTER" ;;
        entity-canon-verify.sh|temporal-verify.sh)
                                           echo "CHAPTER_PROJECT" ;;
        forbidden-words-scan.sh)           echo "CHAPTER_FORBIDDEN" ;;
        number-7-bias.sh|word-count-check.sh|pattern-counter.sh|formatting-check.sh|placeholder-scan.sh|typography-sweep.sh|show-not-tell-tells.sh)
                                           echo "CHAPTER" ;;
        pending-marker-scan.sh)            echo "CHAPTERS_DIR" ;;
        *)                                 echo "UNKNOWN" ;;
    esac
}

# Resolve forbidden-words file location (used by CHAPTER_FORBIDDEN class).
resolve_forbidden_words_file() {
    # v2.7.38 fix: restored engine-internal fallback that v2.7.37
    # incorrectly removed. Both engines DO ship references/forbidden-
    # words.md (~19KB AI-telltale list referenced by prose-humaniser,
    # craft-standards, core-pipeline Stage 13 — see those specs). When
    # a project hasn't copied the wordlist into its own engine-data/,
    # the dispatcher MUST fall through to the engine copy or the
    # ECONOMY + AI_ISM_DETECTION audits silently SKIP for every
    # default project. The v2.7.37 commit's claim that this path was
    # "speculative" was wrong.
    local candidates=(
        "$PROJECT_ROOT/engine-data/forbidden-words.md"
        "$PROJECT_ROOT/forbidden-words.md"
        "$SCRIPT_DIR/../references/forbidden-words.md"
    )
    for f in "${candidates[@]}"; do
        if [ -f "$f" ]; then
            echo "$f"
            return 0
        fi
    done
    echo ""
    return 1
}

# Level → in-scope domain set (v2.7.28; per validate-dispatcher.md § Validation Levels).
domains_for_level() {
    case "$1" in
        full)
            echo "$ALL_DOMAINS"
            ;;
        architecture)
            echo "LOGIC CONSISTENCY COHERENCE PHYSICS CHARACTER GENRE"
            ;;
        brief)
            echo "CONSISTENCY PHYSICS COHERENCE GENRE"
            ;;
        prose)
            echo "CONSISTENCY PHYSICS ECONOMY INTENT_PRESERVATION AI_ISM_DETECTION SHOW_NOT_TELL CHARACTER"
            ;;
        *)
            echo ""
            ;;
    esac
}

# Resolve selector.
# v2.7.61: added `delta` selector for the per-chapter Class B Delta Pass
# (Rule 1b in mandatory-pipeline-rules.md). At `delta` the dispatcher
# emits only the two delta Class B audits (leitmotif-tracker-delta +
# injury-accumulation-delta) and skips ALL Class A audits — the per-
# chapter Class A audits are covered by Rule 1's 6-agent/5-agent
# verification suite + mechanical audit; the delta pass exists to add
# the two per-chapter Class B checks only. Requires the chapter arg.
LEVEL=""
DELTA_MODE=0
if [ "$DOMAIN_ARG" = "all" ] || [ "$DOMAIN_ARG" = "full" ]; then
    LEVEL="full"
    DOMAINS_TO_RUN="$ALL_DOMAINS"
elif [ "$DOMAIN_ARG" = "architecture" ] || [ "$DOMAIN_ARG" = "brief" ] || [ "$DOMAIN_ARG" = "prose" ]; then
    LEVEL="$DOMAIN_ARG"
    DOMAINS_TO_RUN="$(domains_for_level "$LEVEL")"
elif [ "$DOMAIN_ARG" = "delta" ]; then
    LEVEL="delta"
    DELTA_MODE=1
    if [ -z "$CHAPTER_ARG" ]; then
        echo "FATAL|delta_requires_chapter|delta selector requires the [chapter] arg" >&2
        exit 2
    fi
    # Delta mode targets the COHERENCE + PHYSICS domains (the two whose
    # Class B audits have per-chapter delta variants). All other domains
    # are out of scope at delta level.
    DOMAINS_TO_RUN="COHERENCE PHYSICS"
elif [ "$DOMAIN_ARG" = "restore" ]; then
    # v2.7.66: restore selector dispatches the user-invoked voice
    # restoration brief for a specified chapter. Single-audit selector;
    # the brief script does its own multi-precondition preflight
    # (voice-profile-preload, ledger row exists, exemplar paths resolve
    # inside project root). We shell out to it rather than re-walking
    # the same preconditions here.
    if [ -z "$CHAPTER_ARG" ]; then
        echo "FATAL|restore_requires_chapter|restore selector requires the [chapter] arg" >&2
        exit 2
    fi
    BRIEF_SCRIPT="$SCRIPT_DIR/voice-restoration-brief.sh"
    if [ ! -x "$BRIEF_SCRIPT" ]; then
        echo "FATAL|restore_brief_script_missing|$BRIEF_SCRIPT" >&2
        exit 2
    fi
    # Pass-through. The brief script prints its own context summary and
    # emits the single CLASS_B_AUDIT marker that the engine layer reads.
    # Exit code carries through (1 = preflight failed; 0 = preflight
    # passed + marker emitted).
    bash "$BRIEF_SCRIPT" "$PROJECT_ROOT" "$CHAPTER_ARG"
    BRIEF_EXIT=$?
    # Match the dispatcher's END-line convention so downstream
    # callers parsing the stream get a consistent shape.
    if [ "$BRIEF_EXIT" -eq 0 ]; then
        echo "END|0|0|0|0|1"
    else
        echo "END|0|1|0|0|0"
    fi
    exit "$BRIEF_EXIT"
elif [ "$DOMAIN_ARG" = "classify" ]; then
    # v2.7.67: classify selector dispatches the paragraph-classifier
    # for a specified chapter. Same shape as `restore` — single-audit
    # selector, shells out to the dispatch script (which does its own
    # preflight), passes through the exit code, emits a consistent
    # END line for downstream parsers.
    if [ -z "$CHAPTER_ARG" ]; then
        echo "FATAL|classify_requires_chapter|classify selector requires the [chapter] arg" >&2
        exit 2
    fi
    CLASSIFIER_SCRIPT="$SCRIPT_DIR/paragraph-classifier-dispatch.sh"
    if [ ! -x "$CLASSIFIER_SCRIPT" ]; then
        echo "FATAL|classify_dispatch_script_missing|$CLASSIFIER_SCRIPT" >&2
        exit 2
    fi
    bash "$CLASSIFIER_SCRIPT" "$PROJECT_ROOT" "$CHAPTER_ARG"
    CLASSIFY_EXIT=$?
    if [ "$CLASSIFY_EXIT" -eq 0 ]; then
        echo "END|0|0|0|0|1"
    else
        echo "END|0|1|0|0|0"
    fi
    exit "$CLASSIFY_EXIT"
else
    NORMALIZED="$(echo "$DOMAIN_ARG" | tr '[:lower:]' '[:upper:]' | tr ' .-' '___')"
    case " $ALL_DOMAINS " in
        *" $NORMALIZED "*) DOMAINS_TO_RUN="$NORMALIZED" ;;
        *)
            echo "FATAL|unknown_selector|$DOMAIN_ARG" >&2
            echo "FATAL|valid_selectors|all full architecture brief prose delta restore classify $ALL_DOMAINS" >&2
            exit 2
            ;;
    esac
fi

# Soft-warn on chapter at non-prose / non-delta levels.
# At delta + restore levels the chapter arg is REQUIRED (enforced
# above); at prose level it's allowed; at other levels it's ignored.
# (`restore` returns early above and never reaches this line.)
if [ -n "$CHAPTER_ARG" ] && [ -n "$LEVEL" ] && [ "$LEVEL" != "prose" ] && [ "$LEVEL" != "delta" ]; then
    echo "WARN|chapter_arg_ignored|level=$LEVEL chapter=$CHAPTER_ARG (chapter scoping applies only at level=prose or level=delta)" >&2
    CHAPTER_ARG=""
fi

# Build chapter file path if applicable.
CHAPTER_FILE=""
if [ -n "$CHAPTER_ARG" ]; then
    CHAPTER_NN="$(printf '%02d' "$CHAPTER_ARG" 2>/dev/null || echo "$CHAPTER_ARG")"
    CHAPTER_FILE="$PROJECT_ROOT/engine-data/chapters/ch${CHAPTER_NN}.md"
    if [ ! -f "$CHAPTER_FILE" ]; then
        echo "FATAL|chapter_not_found|$CHAPTER_FILE" >&2
        exit 2
    fi
fi

PASS_TOTAL=0
FAIL_TOTAL=0
WARN_TOTAL=0
SKIPPED_TOTAL=0
CLASS_B_TOTAL=0

# ── per-script invocation helper ──────────────────────────────────────────
# Dispatches per script_class. For per-chapter classes (CHAPTER, CHAPTER_*,
# PROJECT_CHAPTER), iterates engine-data/chapters/ch*.md when no chapter is
# supplied; calls once with the chapter file when chapter IS supplied.
# Aggregate verdict: PASS if all per-chapter calls returned 0; FAIL if any
# returned 1 or 2; WARN if any returned >2 and none returned 1 or 2.
#
# Arguments: script_name, domain
run_audit() {
    local script_name="$1"
    local domain="$2"
    local script_path="$SCRIPT_DIR/$script_name"
    # Log-path keying includes domain (v2.7.36 fix): scripts registered to
    # multiple domains (e.g. forbidden-words-scan.sh in both ECONOMY and
    # AI_ISM_DETECTION) previously shared one log file; the second-domain
    # run truncated the first-domain log, so a user clicking through the
    # first-domain AUDIT line saw the wrong run's contents. Per-(domain,
    # script) keying eliminates the collision; each AUDIT line points to
    # a log that contains exactly that invocation.
    local log_path="$REPORTS_DIR/${domain}-${script_name}.log"

    if [ ! -f "$script_path" ]; then
        echo "AUDIT|$script_name|$domain|SKIP|script not present in this engine|-"
        return 2
    fi

    local class
    class="$(script_class "$script_name")"

    if [ "$class" = "UNKNOWN" ]; then
        echo "AUDIT|$script_name|$domain|SKIP|signature unknown — register in script_class()|-"
        return 2
    fi

    # Build the per-chapter file list. Empty for PROJECT_ONCE / CHAPTERS_DIR;
    # one entry when CHAPTER_FILE is supplied; all chapters otherwise.
    local chapters=()
    if [ "$class" = "PROJECT_ONCE" ] || [ "$class" = "CHAPTERS_DIR" ]; then
        chapters=("__no_chapter__")
    elif [ -n "$CHAPTER_FILE" ]; then
        chapters=("$CHAPTER_FILE")
    else
        local glob_path="$PROJECT_ROOT/engine-data/chapters"
        if [ -d "$glob_path" ]; then
            local found=0
            for ch in "$glob_path"/ch*.md; do
                if [ -f "$ch" ]; then
                    chapters+=("$ch")
                    found=1
                fi
            done
            if [ "$found" -eq 0 ]; then
                echo "AUDIT|$script_name|$domain|SKIP|no chapters found at $glob_path|-"
                return 2
            fi
        else
            echo "AUDIT|$script_name|$domain|SKIP|no engine-data/chapters/ directory|-"
            return 2
        fi
    fi

    : > "$log_path"

    local fw_file=""
    if [ "$class" = "CHAPTER_FORBIDDEN" ]; then
        fw_file="$(resolve_forbidden_words_file)"
        if [ -z "$fw_file" ]; then
            echo "AUDIT|$script_name|$domain|SKIP|forbidden-words.md not found in project or engine|-"
            return 2
        fi
    fi

    local worst_exit=0
    local call_count=0
    local fail_count=0
    local skip_count=0

    for ch in "${chapters[@]}"; do
        local exit_code=0
        local invoke_target="$ch"
        case "$class" in
            PROJECT_ONCE)
                bash "$script_path" "$PROJECT_ROOT" >>"$log_path" 2>&1 || exit_code=$?
                invoke_target="$PROJECT_ROOT"
                ;;
            CHAPTERS_DIR)
                # Point at the chapters directory specifically (avoids
                # recursing into reports/validate/ which would re-scan logs).
                local chdir="$PROJECT_ROOT/engine-data/chapters"
                if [ ! -d "$chdir" ]; then
                    echo "AUDIT|$script_name|$domain|SKIP|no engine-data/chapters/ directory|-"
                    return 2
                fi
                bash "$script_path" "$chdir" >>"$log_path" 2>&1 || exit_code=$?
                invoke_target="$chdir"
                ;;
            PROJECT_CHAPTER)
                local chN
                chN="$(basename "$ch" .md | sed 's/^ch0*//')"
                [ -z "$chN" ] && chN="0"
                bash "$script_path" "$PROJECT_ROOT" "$chN" >>"$log_path" 2>&1 || exit_code=$?
                ;;
            CHAPTER)
                bash "$script_path" "$ch" >>"$log_path" 2>&1 || exit_code=$?
                ;;
            CHAPTER_PROJECT)
                bash "$script_path" "$ch" "$PROJECT_ROOT" >>"$log_path" 2>&1 || exit_code=$?
                ;;
            CHAPTER_FORBIDDEN)
                bash "$script_path" "$ch" "$fw_file" >>"$log_path" 2>&1 || exit_code=$?
                ;;
        esac

        call_count=$((call_count + 1))
        # v2.7.39 fix: per-chapter fail_count counts only exit-1 (true
        # FAIL) chapters. Pre-v2.7.39 the condition was "-eq 1 || -eq 2"
        # which over-reported SKIPs as fails in the per-chapter summary
        # line — a leftover from before v2.7.36 reclassified exit-2 as
        # SKIP-equivalent rather than FAIL "configuration error".
        if [ "$exit_code" -eq 1 ]; then
            fail_count=$((fail_count + 1))
        elif [ "$exit_code" -eq 2 ]; then
            skip_count=$((skip_count + 1))
        fi
        if [ "$exit_code" -gt "$worst_exit" ]; then
            worst_exit="$exit_code"
        fi

        # Separator between per-chapter calls in the log.
        if [ "${#chapters[@]}" -gt 1 ] && [ "$ch" != "__no_chapter__" ]; then
            echo "----- end $invoke_target -----" >>"$log_path"
        fi
    done

    local first_line
    first_line="$(head -n 1 "$log_path" 2>/dev/null | tr '|' '/' | tr -d '\n' | cut -c1-160)"
    [ -z "$first_line" ] && first_line="(no output)"

    local summary="$first_line"
    if [ "$call_count" -gt 1 ]; then
        # v2.7.39: surface skip count alongside fail when non-zero so
        # the per-chapter summary distinguishes "5 chapters; 1 fail; 2
        # skip" from "5 chapters; 1 fail" (where skips are silently
        # absorbed). Important after v2.7.36 reclassified exit-2 as SKIP.
        if [ "$skip_count" -gt 0 ]; then
            summary="$call_count chapters; $fail_count fail; $skip_count skip | $first_line"
        else
            summary="$call_count chapters; $fail_count fail | $first_line"
        fi
    fi

    case $worst_exit in
        0)
            echo "AUDIT|$script_name|$domain|PASS|$summary|$log_path"
            return 0
            ;;
        1)
            echo "AUDIT|$script_name|$domain|FAIL|$summary|$log_path"
            return 1
            ;;
        2)
            # v2.7.36 fix: exit-2 from a Class A script is SKIP-equivalent
            # (no inputs / file-not-found / pre-condition not met), not
            # FAIL. Pre-v2.7.36 this was misclassified as FAIL "configuration
            # error", causing /validate at brief level on a project before
            # chapter briefs exist (an entirely normal entry state) to FAIL
            # COHERENCE. The new scripts authored in v2.7.30-v2.7.35 all
            # document exit-2 with SKIP semantics; this case statement now
            # honours that contract.
            echo "AUDIT|$script_name|$domain|SKIP|$summary|$log_path"
            return 2
            ;;
        *)
            echo "AUDIT|$script_name|$domain|WARN|exit $worst_exit: $summary|$log_path"
            return 3
            ;;
    esac
}

# ── per-domain dispatch ───────────────────────────────────────────────────
# When level is set, iterate ALL_DOMAINS and emit OUT_OF_SCOPE for domains
# the level excludes. When LEVEL is empty (single-domain probe), iterate
# only DOMAINS_TO_RUN.
if [ -n "$LEVEL" ]; then
    DOMAINS_ITERATE="$ALL_DOMAINS"
else
    DOMAINS_ITERATE="$DOMAINS_TO_RUN"
fi

for domain in $DOMAINS_ITERATE; do
    # Out-of-scope check (only meaningful when LEVEL is set).
    if [ -n "$LEVEL" ]; then
        case " $DOMAINS_TO_RUN " in
            *" $domain "*) ;;
            *)
                echo "OUT_OF_SCOPE|$domain|level=$LEVEL"
                continue
                ;;
        esac
    fi

    scripts="$(scripts_for_domain "$domain")"
    # v2.7.61: delta mode emits only the -delta Class B variants and
    # skips Class A audits entirely (per-chapter Class A is covered by
    # Rule 1's verification suite, not by /validate).
    if [ "$DELTA_MODE" -eq 1 ]; then
        scripts=""
        class_b_list="$(class_b_delta_audits_for_domain "$domain")"
    else
        class_b_list="$(class_b_audits_for_domain "$domain")"
    fi

    pass=0
    fail=0
    warn=0
    skipped=0
    class_b_pending=0

    # If a domain has no Class A scripts and no Class B audits registered,
    # surface it as UNAUDITED so the briefing names the gap rather than
    # silently skipping. The post-v2.7.35 framework has zero such domains;
    # this branch is reachable only if a future ALL_DOMAINS addition isn't
    # accompanied by an entry in scripts_for_domain() or
    # class_b_audits_for_domain(). Keeping the branch + descriptive
    # message rather than a separate gap_target_for_domain() function
    # eliminates the previously-dead lookup table.
    if [ -z "$scripts" ] && [ -z "$class_b_list" ]; then
        echo "AUDIT|UNAUDITED|$domain|SKIP|domain in ALL_DOMAINS but no Class A or Class B audits registered — register one in scripts_for_domain() or class_b_audits_for_domain()|-"
        skipped=1
        SKIPPED_TOTAL=$((SKIPPED_TOTAL + 1))
        echo "DOMAIN|$domain|0|0|0|$skipped|0"
        continue
    fi

    # Class A: existing per-script invocation.
    if [ -n "$scripts" ]; then
        for script in $scripts; do
            run_audit "$script" "$domain"
            result=$?
            case $result in
                0) pass=$((pass + 1)); PASS_TOTAL=$((PASS_TOTAL + 1)) ;;
                1) fail=$((fail + 1)); FAIL_TOTAL=$((FAIL_TOTAL + 1)) ;;
                2) skipped=$((skipped + 1)); SKIPPED_TOTAL=$((SKIPPED_TOTAL + 1)) ;;
                3) warn=$((warn + 1)); WARN_TOTAL=$((WARN_TOTAL + 1)) ;;
                *) warn=$((warn + 1)); WARN_TOTAL=$((WARN_TOTAL + 1)) ;;
            esac
        done
    fi

    # Class B: emit one CLASS_B_AUDIT line per registered audit. The engine
    # layer above the dispatcher (Claude driving /validate) reads these and
    # dispatches subagents per the linked spec, applying subagent-output-
    # verification HARD GATE on returned evidence, and merges each verdict
    # into the final Validation Briefing.
    if [ -n "$class_b_list" ]; then
        for audit_name in $class_b_list; do
            spec_rel="references/${audit_name}.md"
            spec_abs="$SCRIPT_DIR/../$spec_rel"
            if [ -f "$spec_abs" ]; then
                # v2.7.37: include severity cap (or "-" if none) so the
                # engine layer can apply the cap from the marker line
                # alone without re-reading the spec.
                cap="$(severity_cap_for_audit "$audit_name")"
                [ -z "$cap" ] && cap="-"
                echo "CLASS_B_AUDIT|$audit_name|$domain|$spec_rel|$cap"
                class_b_pending=$((class_b_pending + 1))
                CLASS_B_TOTAL=$((CLASS_B_TOTAL + 1))
            else
                echo "AUDIT|$audit_name|$domain|SKIP|Class B spec not present at $spec_rel|-"
                skipped=$((skipped + 1))
                SKIPPED_TOTAL=$((SKIPPED_TOTAL + 1))
            fi
        done
    fi

    echo "DOMAIN|$domain|$pass|$fail|$warn|$skipped|$class_b_pending"
done

echo "END|$PASS_TOTAL|$FAIL_TOTAL|$WARN_TOTAL|$SKIPPED_TOTAL|$CLASS_B_TOTAL"

if [ "$FAIL_TOTAL" -gt 0 ]; then
    exit 1
fi
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
