---
name: essay-collection-category
description: "Category-specific instructions for essay collections"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Essay Collections. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | essay-collection |
| Display Name | Essay Collection |
| Parent Group | Literature & Fiction > Essays & Correspondence (creative non-fiction subcategory of literary publishing) |
| Typical Word Count | 50,000–80,000 (essay collections vary widely; 12–25 essays at 2,500–5,000 words each is the typical shape; some collections deploy a few longer pieces and many shorter, others run 30+ short pieces) |
| Default Structure | Each essay is a complete standalone unit; collection-level architecture orders essays for cumulative effect (thematic groupings, contrasting tones, escalating intensity, framing first/last); voice is the through-line; subject can vary widely within the same collection |
| Citation Style | Per-essay citation per the essay's mode — personal essays cite minimally, criticism cites cultural texts referenced, political essays cite data and sources, nature essays cite scientific and natural-history sources; collection-level acknowledgements page credits prior publication of individual essays; no cumulative bibliography unless the collection's mode is research-heavy |
| Audience Baseline | Reader who buys for voice as much as subject — willing to follow a particular mind across topics; literary-prose-comfortable; varies sharply by collection's primary mode (personal-essay readers different from cultural-criticism readers different from political-essay readers); audience signalled clearly so reader self-selects |
| Comparable Titles | Joan Didion (*Slouching Towards Bethlehem*, *The White Album*), James Baldwin (*Notes of a Native Son*, *The Fire Next Time*), Susan Sontag (*Against Interpretation*, *Illness as Metaphor*), David Foster Wallace (*A Supposedly Fun Thing I'll Never Do Again*, *Consider the Lobster*), Zadie Smith (*Changing My Mind*, *Feel Free*), Ta-Nehisi Coates (*We Were Eight Years in Power*), Hilton Als (*White Girls*), Eula Biss (*Notes from No Man's Land*, *Having and Being Had*), Leslie Jamison (*The Empathy Exams*), Jia Tolentino (*Trick Mirror*), Hanif Abdurraqib (*They Can't Kill Us Until They Kill Us*), Rebecca Solnit (*Men Explain Things to Me*), Annie Dillard (*Teaching a Stone to Talk*), Geoff Dyer (*Otherwise Known as the Human Condition*), Margo Jefferson (*Negroland*), Brian Doyle, Cheryl Strayed (*Tiny Beautiful Things*), Maggie Nelson (*Bluets*), Anne Carson (*Decreation*) |

## Subcategory Options

When the user selects Essay Collection, prompt for subcategory refinement
based on the collection's primary mode:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| personal-essays | Personal / Memoiristic Essays | Intimate first-person reflection on lived experience; the literary essay tradition closer to memoir than to argument; Strayed / Jamison / Doyle / Lopate lineage | Voice-led; each essay anchored to specific personal experience; thematic groupings often emerge from shared emotional territory rather than chronology; reader trust built through accumulated vulnerability across the collection |
| cultural-criticism | Cultural Criticism | Analysis of culture, media, art, technology, society through the essay form; the Sontag / Wallace / Tolentino / Als lineage; argument and observation in service of cultural understanding | Each essay anchored to specific cultural texts / events / phenomena; longer essays common (5,000–12,000 words); typically deploys close reading, historical context, and the writer's distinctive analytical lens |
| political-social-essays | Political / Social Essays | Argument-driven essays on public issues, race, class, gender, power, justice, current events; the Baldwin / Coates / Solnit-political lineage | Argument-led structure within each essay; evidence-and-data weight comparable to political-commentary category; collection often arranged to build cumulative argument across issues; date-of-writing matters more than other modes |
| humour-observational | Humour / Observational Essays | Comic essays on everyday life, domestic absurdity, the petty indignities of contemporary existence; the Sedaris / Lockwood / much-of-Wallace lineage | Punchline-aware structure within each essay; collection paced for variety (sustained humour fatigues); subject-led grouping; surface comedy concealing deeper emotional or political content is the genre's signature move |
| nature-place-essays | Nature / Place Essays | Essays grounded in landscape, environment, observed natural world; the Dillard / Berry-essays / Solnit-on-place / Macfarlane-shorter-pieces lineage; overlaps with nature-writing category but in essay-collection form | Place- or seasonal- anchored; sensory observation as backbone; reflection arises from observation rather than precedes it; often the slowest-paced essay-collection mode |
| literary-criticism-arts | Literary Criticism / Essays on the Arts | Essays on books, writers, films, music, visual art; the Wood / Smith-on-writing / Sontag-on-film / Lopate-on-cinema lineage | Each essay anchored to specific work, writer, or oeuvre; close reading; the essayist's own aesthetic position made visible; reading-the-canon-from-a-particular-angle structure common |
| lyric-experimental | Lyric / Experimental Essays | Essays that resist conventional argument structure — fragment, list, lyric prose, montage, hybrid forms; the Carson / Nelson / Biss-in-lyric-mode / Sloan / hybrid-tradition lineage | Form is content; each piece's structure is part of its meaning; collection-level architecture often essential for sense-making; the boundary between essay and prose-poem deliberately permeable |

**Default:** If the user does not specify, prompt for the collection's
primary mode (which type of essay carries the bulk of the collection)
and select accordingly; fallback to `personal-essays` for unclear cases
(the most-published essay-collection mode in trade publishing).

## Structural Architect Instructions

```
STRUCTURE
- Each essay is self-contained but connected by theme, voice, or subject
- Collection-level architecture: essays ordered to build, contrast, or accumulate
- Individual essay structure varies: narrative, argumentative, lyric, hybrid
- Opening essay sets the voice and stakes; closing essay provides resolution or expansion

COLLECTION ARCHITECTURE
- Thematic grouping: essays organised into 3-5 sections with thematic headers
- Variety in length: mix shorter (2,000 word) and longer (4,000 word) essays
- Variety in form: narrative essays, analytical essays, personal essays, lyric/experimental
- Avoid repetition: same anecdote or argument should not appear in multiple essays
- Internal references between essays strengthen cohesion

INDIVIDUAL ESSAY BEATS
1. Hook. specific image, question, or moment that opens the essay
2. Exploration. the subject examined from multiple angles
3. Turn. the essay's pivot point where understanding shifts
4. Deepening. complexity added after the turn
5. Landing. a final image or insight that resonates beyond the essay
```

## Content Writer Craft Rules

```
VOICE & TONE
- The essayist's voice IS the product. distinctive, recognisable, authentic
- Each essay must feel like a conversation with a specific mind
- Tone can vary between essays (playful, serious, angry, tender) but the underlying
  voice must be consistent. the reader always knows who's talking

EVIDENCE STANDARDS
- Personal essays: the author's experience is sufficient evidence
- Cultural criticism: specific cultural texts/events as evidence (cite or describe)
- Political essays: data and sourcing expected (same as political commentary)
- All essays: intellectual honesty about what the author knows and doesn't know

PROSE RHYTHM MAPPING
- Ch 1 (first essay) hook: the VOICE must captivate. the reader decides within the first essay whether to trust this mind for an entire collection
- Sentence length: medium (14-22 words) as the baseline; the essayist's rhythm is conversational, precise, and distinctive
- Each essay has its own internal rhythm but the collection's voice is consistent. the reader always knows who is talking
- Tension ≥4 from the first essay. intellectual and emotional tension: the essayist's curiosity and stakes must be palpable
- The essayist's voice IS the product: distinctive, recognisable, authentic. more important here than in any other nonfiction category
- Tone varies between essays (playful, serious, angry, tender) but the underlying voice remains the constant through-line
- Individual essay rhythm follows the five beats: hook, exploration, turn, deepening, landing. each essay a complete arc
- Evidence integration varies by essay type: personal essays rely on experience; cultural criticism relies on specific texts; political essays rely on data
- Short sentences for declarations and observations that land with force; longer sentences for exploration, qualification, and nuance
- The "turn" in each essay. where understanding shifts. is a pacing event; the prose rhythm changes around it
- The "why should I read this book" question is answered by the first essay's voice: this person's mind is worth inhabiting
- Reader engagement across the collection: variety in length (shorter and longer essays), form (narrative, analytical, lyric), and subject sustains interest
- Paragraph rhythm within essays: opening paragraphs hook with specificity; middle paragraphs explore with range; closing paragraphs land with resonance
- Authority delivery through the essayist's distinctive perception. the reader values how this mind sees the world
- Collection-level pacing: the ordering of essays creates its own rhythm. intensity followed by reflection, polemic followed by tenderness
- Each essay must stand alone as a complete reading experience AND contribute to the collection's cumulative effect
- Deploy the essay's final image or sentence with particular care. the landing determines whether the reader turns to the next essay
- Transitions between essays handled by the collection's architecture: thematic groupings, contrasting tones, and accumulating resonance
```

## Quality Check Criteria

The Quality Check agent MUST verify each essay (and the collection
as a whole) against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Each essay self-contained | Individual essays read as complete pieces — open, develop, turn, land — without requiring the reader to have read other essays in the collection; readers who pick up an essay-collection and read non-sequentially are served |
| 2 | Each essay earns its place | No filler. Every essay contributes something the collection would lose without it — a subject only this essay covers, a voice register only this essay deploys, an argument or insight that lives only here. "Cutting-room floor" essays drag the collection |
| 3 | Voice consistency across the collection | The reader can recognise the same writer across essays even when subject and tone vary widely (playful in one essay, elegiac in another, argumentative in a third); voice is the collection's through-line and the reason readers buy collections rather than individual essays |
| 4 | No repetition of anecdotes or arguments | Specific personal anecdotes, cited examples, key arguments, or signature phrases do not appear in multiple essays; readers who notice the same story in three essays lose trust in the collection's care |
| 5 | Per-essay structural integrity | Each essay has the genre's expected shape: hook (specific image / question / moment) → exploration → turn (where understanding shifts) → deepening → landing (final image / insight that resonates beyond the essay) |
| 6 | Variety in length and form | Collection mixes shorter and longer essays; mixes narrative, analytical, lyric, and other modes per the collection's range; sustained sameness fatigues the reader regardless of how strong individual essays are |
| 7 | Per-essay evidence integrity | Each essay's claims meet the evidentiary standard appropriate to its mode — personal essays' lived experience adequately rendered; cultural-criticism essays' textual citation precise; political essays' data sourced; nature essays' natural-history accurate |
| 8 | Collection-level architecture deliberate | The essays are ordered with intent — thematic groupings, contrasting tones, escalating or de-escalating intensity, opening / closing essays chosen to frame; reader can sense the curatorial hand even if they cannot name its principle |
| 9 | Publication history disclosed | Essays previously published in periodicals or anthologies are credited (typically in front matter and / or per-essay note) with original venue and date; substantially revised essays so noted; collection's relationship to prior publication transparent |
| 10 | Date / context of writing visible where it matters | For political, social, and current-events essays where the moment of writing shapes the meaning, the date of writing or original publication is visible to the reader; collections of older essays distinguish "this is how I saw it then" from "this is how I see it now" honestly |

## Source Requirements

### Mandatory Source Types

Source requirements vary by per-essay mode; the collection as a whole
inherits the standards of whichever mode the individual essay is in:

- **Personal essays.** The author's lived experience is the primary
  source. Honest treatment of memory's limits expected (memoir's
  honesty conventions apply); composite characters and time
  compression permitted with disclosure; reconstructed dialogue
  flagged where contentious. See `memoir.md` Source Requirements
  for the full standards inherited.
- **Cultural-criticism essays.** Specific cultural texts —
  films, books, music, art, television, internet phenomena — cited
  precisely (title, year, creator); sustained close reading of
  cited material rather than impression-based summary; relevant
  scholarship in cultural studies, art history, film studies,
  literary criticism cited where the essay engages with prior
  scholarly conversation.
- **Political and social essays.** Data sourced; statistics with
  citation and dating; named primary reporting and original
  documents preferred over summary; policy claims trace to
  primary policy texts; historical claims trace to historical
  scholarship. Same standards as `political-commentary` category
  for political essays.
- **Nature and place essays.** Direct observation; species
  identification accurate; ecological / geological / climate
  claims sourced; field guides credited where used. Same standards
  as `nature-writing` category for nature essays.
- **Literary-criticism and arts essays.** Specific works named
  precisely (book / film / artwork / piece + creator + year);
  sustained engagement with the work rather than positioning;
  prior critical conversation acknowledged where the essay
  enters it; quotations accurate.
- **Lyric / experimental essays.** The form's evidentiary
  expectations are lower (lyric license is part of the form),
  but the essayist's personal experience and observed world are
  still real and treated honestly; invented material is either
  flagged or so clearly fictional in form that no reader is
  misled.

### Collection-Level Source: Publication History

- Essays previously published in periodicals (magazines,
  literary journals, online venues, anthologies) are credited
  with original venue and date — typically in front-matter
  acknowledgements and / or in a per-essay note at the start
  or end of each essay.
- Where essays have been substantially revised for the
  collection, this is noted (typically in author's note).
- Where essays appear in their original form, with publication
  date, readers can place them in the moment of writing — this
  matters particularly for political and current-events essays.
- For collections that include both new-for-this-volume essays
  and previously-published essays, the distinction is made
  visible.

### Source Freshness

- **Essay collections are typically more durable than other
  current-affairs publishing.** Foundational essay-collection
  works (Sontag, Didion, Baldwin, Wallace) age well because the
  voice and the analytical move outlast the specific cultural
  occasion. Books built around capturing a particular cultural
  moment (Trick Mirror's mid-2010s internet, certain
  early-2000s tech criticism collections) age into period
  documents — legitimate, but date-bound.
- **Political / current-affairs essays.** These age fastest.
  Collections built around a particular political moment (an
  election cycle, a crisis, an administration) require explicit
  dating; the date of writing is essential context for political
  essays even when republished years later.
- **Cultural criticism dates more quickly than personal essays.**
  Internet phenomena, platforms, popular cultural texts referenced
  in cultural criticism age fast; the analytical move sometimes
  outlasts the specific reference but the references themselves
  may need contextualisation for later readers.
- **Personal and nature essays age most gracefully.** The
  personal essay's specific moment is its date; the reader does
  not expect it to be current. Nature essays' core observation
  remains valid even as ecological context shifts (the latter
  warranting acknowledgement).
- **Re-issued collections benefit from updated framing.**
  Re-issues warrant new introduction or framing material that
  contextualises older essays for current readers — what's
  changed since, what the essayist now sees differently, what
  has held up.

### Attribution Standards

- **Per-essay attribution per its mode.** Each essay carries
  the citation and attribution standards of its mode (memoir
  conventions for personal, scholarly conventions for criticism,
  data-rigour for political, etc.).
- **Collection-level acknowledgements.** Front matter
  acknowledgements credit prior publication of essays, named
  editors who shaped them, named readers / dedicatees,
  permission grants for reproduced material (lyrics, lengthy
  quotations, images).
- **Author's own previous self.** Where the collection includes
  the author's earlier writing alongside more recent work, the
  evolution of the author's thought is acknowledged honestly;
  contradictions between earlier and later positions are owned
  rather than smoothed over.
- **What is NOT acceptable.** Presenting previously-published
  essays as new without disclosure. Substantially revising
  earlier essays without acknowledgement (light copy-editing
  fine; arguments materially changed should be flagged). Failing
  to credit collaborators on jointly-written or assist-supported
  pieces. Treating the collection as a vehicle for self-promotion
  where the essays' subjects and arguments deserve their own
  evidentiary care.

## Category-Specific Guardrails

### MANDATORY. Essay-Form Integrity (each essay reads standalone)

- Essay collections are bought by readers who often read non-
  sequentially. Each essay therefore stands as a complete
  reading experience — open, develop, turn, land — without
  requiring familiarity with other essays in the collection.
- Per-essay structural integrity: every essay has a hook (a
  specific image, question, or moment that opens), a development
  (subject explored from multiple angles), a turn (where
  understanding shifts — the essay's pivot), a deepening
  (complexity added after the turn), and a landing (final image
  or insight that resonates beyond the essay).
- Cross-references between essays in the collection are
  permissible but must be light — the essay still needs to read
  cleanly without the cross-referenced piece. "As I argued in
  the previous essay..." in essay 4 of a 20-essay collection
  fails the standalone test.
- Unfinished or fragmentary pieces appear in the collection only
  when the form (lyric / experimental) explicitly licenses them;
  otherwise readers experience them as drafts not earned.

### MANDATORY. Voice Consistency Across the Collection

- The essayist's voice IS the collection's product, more
  centrally than in any other non-fiction category. Readers buy
  collections because they want sustained engagement with a
  particular mind. Voice fails the collection if the reader
  cannot recognise the same writer across the essays.
- Voice consistency does not mean tonal sameness. The voice may
  be playful in one essay, elegiac in another, polemical in a
  third — the underlying perceptual and analytical signature
  remains constant.
- Common failure modes:
  - Voice drift across essays written over many years (the
    earlier-self and later-self differ enough that the
    collection feels like two writers); honest acknowledgement
    of the gap is the legitimate response.
  - Mode-mimicry where the essayist adopts a voice borrowed
    from elsewhere (a political-pundit voice in one essay, a
    memoir voice in another, neither distinctively the
    essayist's own).
  - Editor-flattening where the essays were heavily edited
    toward magazine house-style and the author's voice was
    smoothed away.
- The first essay disproportionately determines whether the
  reader trusts the rest of the collection. The opening essay
  must establish the voice with confidence; readers who are not
  captured by the first essay rarely persist.

### MANDATORY. Publication-History Disclosure

- Where essays have appeared previously — in periodicals,
  literary journals, online venues, anthologies, online
  publications, the author's own newsletter / blog — the
  prior publication is credited:
  - Front-matter acknowledgements list prior publications
    with venue, year, and any title changes between original
    and collection version.
  - Per-essay notes (typically italics at start or end of
    each essay) where appropriate to the collection's
    convention.
  - Substantially revised essays flagged with "Significantly
    revised from original publication" or equivalent;
    light-edit revisions standard practice and not requiring
    flag.
- Collections of entirely-new essays (no prior publication)
  are uncommon; where the collection is a mix, the proportion
  is honest. Readers buying "a new collection of essays" are
  entitled to know what's actually new.
- Date of original publication matters particularly for
  political, current-affairs, and time-bound cultural-
  criticism essays where the moment of writing is part of
  the meaning.

### MANDATORY. Collection-Shape Honesty

- The collection's organising principle is named or evident:
  thematic (essays grouped by subject), chronological (by
  date of writing), formal (by essay type), juxtapositional
  (deliberately contrasting), or simply curated-by-voice
  (the essayist's recent work without claimed thematic
  cohesion).
- Where the collection has thematic cohesion, the cohesion is
  real — essays speak to each other, develop a shared
  question, build cumulative argument or insight. Claimed
  cohesion that the collection does not deliver disappoints
  readers who bought for the promised through-line.
- Where the collection is variety-and-voice rather than
  thematic, this is acknowledged honestly. Some of the best
  essay collections (Wallace's *A Supposedly Fun Thing*,
  Smith's *Feel Free*) deliberately collect across subjects;
  the variety is the point. Forcing thematic-cohesion
  framing onto a variety collection mis-sells it.
- Section dividers and sub-titling (where used) reflect the
  actual organising principle rather than imposing structure
  the essays don't carry.

### MANDATORY. Essay-Mode Source Standards Apply

- Each essay inherits the source / evidence standards of its
  mode — see Source Requirements above. The collection as a
  whole does not have a single uniform standard; instead,
  every individual essay meets the standard appropriate to
  what kind of essay it is.
- Where the collection mixes modes (some personal, some
  cultural-criticism, some political), the per-essay mode is
  recognisable from the essay itself; the reader knows what
  evidentiary register they are in.
- Where an essay shifts mode mid-piece (a personal essay
  that turns to political argument; a cultural-criticism
  essay that turns to memoir), the shift is handled with
  awareness of the change in evidentiary register.

### Additional Guardrails

- **No filler.** Every essay earns its place. "Cutting-room
  floor" essays — pieces the author has written but that don't
  meet the collection's standard — should not be included to
  pad to a target word count or page count.
- **Variety across the collection.** Length variety (short
  essays alongside longer), form variety (narrative,
  analytical, lyric, hybrid), tonal variety (playful,
  elegiac, polemical, contemplative), pacing variety (the
  collection alternates intensity and reflection). Sustained
  sameness — even of high quality — fatigues the reader.
- **No repetition of anecdotes or arguments.** A specific
  personal anecdote, cited example, key argument, or
  signature phrase appears in one essay only; recurrence
  across essays signals carelessness in collection assembly.
  Where a recurring image or theme is the collection's point
  (call-and-response across essays), the recurrence is
  deliberate and earned.
- **Opening and closing essays chosen with intent.** The
  first essay establishes voice and stakes; the last essay
  provides resolution, expansion, or earned silence. These
  positions are not random — they shape the reader's overall
  experience.
- **Author's own evolution acknowledged.** Where the
  collection spans many years of writing, the author's
  earlier and later positions may differ. Acknowledging the
  evolution honestly (in introduction, in per-essay note, or
  in framing) is more credible than smoothing over the gap.
- **Permissions and attribution for borrowed material.**
  Quotations from copyrighted material (lyrics, longer
  prose passages, images) within fair-use limits or with
  permission obtained; collection-level permissions list
  in front or back matter.
- **Currency disclosure where it matters.** Political,
  cultural-criticism, and topical essays dated; reader
  given enough context to read older essays as period
  documents rather than expect current-state analysis.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Sophisticated and considered — often a
  single bold colour against neutral (deep red on cream, navy
  on white, ochre on charcoal); or muted literary tones
  (sage, dusk, bone, slate) for collections with reflective
  register; or saturated single colour for collections with
  political / urgent register. Avoid the saturated commercial
  palette that signals self-help or popular-press positioning;
  the cover should signal literary publishing's design culture.
- **Typography:** Literary serif (Garamond, Caslon, Bembo,
  Sabon, Mrs Eaves) is the default — typography signals
  considered prose and continuity with literary essay
  tradition. Display serifs and hand-set typography work for
  collections with strong personality (Wallace, Sedaris-
  influenced humour collections). Sans-serif appears in more
  contemporary / political / cultural-criticism positioning
  (Tolentino, Coates) — clean, confident, modern. Author name
  often given typographic weight equal to or exceeding the
  title — voice-driven purchase means the author's name is
  the brand.
- **Imagery:** Three dominant traditions:
  1. **Pure typography** — title and author name, no image,
     often with single graphic element (a line, a colour
     block, a small icon). The most common contemporary form,
     particularly for established authors. Strong for any
     mode where the prose IS the draw.
  2. **Single evocative photograph or illustration** — a
     resonant image (a face partial-or-obscured, a single
     object, an interior moment, an abstract composition);
     restrained, considered, allusive rather than literal.
     Common for memoir-adjacent and personal-essay collections.
  3. **Abstract / design-led composition** — colour blocks,
     geometric arrangement, typographic-as-graphic; common
     for cultural-criticism and lyric / experimental
     collections where the cover signals contemporary
     literary design culture.
- **Mood:** Considered intelligence. The cover should signal
  "this book is by a writer worth reading at length" — not
  "subject-matter expert delivers content" (commercial
  non-fiction register), not "lifestyle guidance" (self-help
  register). Restraint, deliberate choice, and design-culture
  awareness outsell ornament.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Personal / Memoiristic Essays | Often a single evocative image (often partial-figure or interior scene) or pure typography; warmer palette; serif typography with literary weight; subtitle subdued or absent ("Essays" sufficient where author-brand carries) |
| Cultural Criticism | Pure typography or design-led composition; bolder palette and confident typography; subtitle clarifies the cultural focus where useful ("essays on...") |
| Political / Social Essays | Often pure typography or single resonant image; substantial palette (often single bold colour against neutral); typography urgent and confident; subtitle establishes the political engagement and timeframe where applicable |
| Humour / Observational | More personality-led design (display typography, hand-lettering, illustrated element); warmer palette; typography signals the comic register; subtitle often does work ("Essays") |
| Nature / Place Essays | Inherits nature-writing's visual conventions (botanical / zoological illustration, atmospheric landscape, single natural object) but with essay-collection's typography emphasis; serif typography; subtitle often "essays" + place reference |
| Literary Criticism / Arts | Pure typography or design-led; sophisticated palette; serif typography signals scholarly-adjacent positioning; subtitle clarifies the cultural / literary scope ("essays on books and writing", "essays on art and the artist's life") |
| Lyric / Experimental | Most varied — design-led, often unconventional; the cover may itself signal the formal experiment of the collection; typography frequently treated as image; subtitle minimal or absent |

### Typography Rules

- **Title:** 25–55% of cover area depending on whether image-led
  (smaller) or typography-led (larger). Essay-collection titles
  range from single resonant word or phrase ("Bluets",
  "Negroland", "Slouching Towards Bethlehem", "Bad Feminist") to
  descriptive ("A Supposedly Fun Thing I'll Never Do Again",
  "Notes from No Man's Land"). Both work; the title often does
  less descriptive work than other categories because the author's
  voice is the primary purchase driver.
- **Subtitle:** Often restrained or absent. "Essays" alone is
  common (Sontag's *Against Interpretation* subtitle is "and
  Other Essays"; many contemporary collections use just "Essays"
  or "Selected Essays"). Where the subtitle does work, it
  establishes the collection's organising principle ("essays on
  X", "essays on Y and Z").
- **Author name:** Typically given typographic weight equal to
  or near the title — voice-driven purchase means readers buy
  the author. Established essayists (Sontag, Didion, Wallace,
  Smith, Coates) often have name LARGER than title. Less
  established essayists balance against credentials in subtitle
  or back-cover blurb.
- **Series mark and edition:** Literary essay imprints (FSG
  Originals, Graywolf, Coffee House, NYRB Classics for re-issued
  classics, Penguin Modern Classics) signal positioning to
  category readers; first-edition and re-issue marking matters
  for collectible / literary readers.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Personal / Memoiristic Essays | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Essays (with Biographies & Memoirs > Memoirs as secondary for memoir-leaning collections) |
| Cultural Criticism | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Essays (with Politics & Social Sciences > Social Sciences > Popular Culture as secondary) |
| Political / Social Essays | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics (with Literature & Fiction > Essays & Correspondence > Essays as secondary) |
| Humour / Observational | Kindle Store > Kindle eBooks > Humor & Entertainment > Humor > Essays (and Literature & Fiction > Essays & Correspondence > Essays as secondary) |
| Nature / Place Essays | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Essays (with Science & Math > Nature & Ecology > Natural History as secondary) |
| Literary Criticism / Arts | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Literary Criticism (with Arts & Photography > Criticism for arts-criticism collections) |
| Lyric / Experimental | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Essays (with Literature & Fiction > Poetry > Anthologies as secondary for prose-poem-adjacent work) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Specific cultural / political subject | Kindle Store > Kindle eBooks > Politics & Social Sciences > [Specific Topic — Race / Gender / Class / Religion / etc.] |
| Literary fiction (for highly literary collections) | Kindle Store > Kindle eBooks > Literature & Fiction > Literary Fiction (rare; reserved for collections positioned at literary-prestige market) |
| Memoir (for memoir-leaning collections) | Kindle Store > Kindle eBooks > Biographies & Memoirs > Memoirs |
| Specific demographic / community | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence (with Specific Groups > [Women / LGBTQ+ / African American / Asian American / etc.] as secondary where the collection foregrounds community) |
| Travel | Kindle Store > Kindle eBooks > Travel > Essays & Travelogues (for travel-essay collections) |
| Nature crossover | Kindle Store > Kindle eBooks > Science & Math > Nature & Ecology |
| Arts and photography | Kindle Store > Kindle eBooks > Arts & Photography > Photography & Video (for photo-essay collections) |

### Keyword Recommendations

- The collection's mode + "essays"
  ("personal essays", "cultural criticism essays", "political
  essays", "humour essays", "nature essays", "literary essays",
  "feminist essays", "essays on race", "essays on technology")
- The author's distinctive lens or position
  ("Black essayist", "queer essays", "immigrant essays",
  "millennial essays", "writer's life", "writer-mother",
  "essayist's perspective")
- The collection's subject focus where applicable
  ("essays on the body", "essays on grief", "essays on art",
  "essays on the internet", "essays on motherhood",
  "essays on place", "essays on race in America")
- The essay-tradition signal
  ("literary essays", "creative non-fiction", "personal
  criticism", "lyric essay", "long-form essay",
  "literary journalism")
- Comparable author / brand for discoverability
  (readers of Joan Didion, readers of James Baldwin, readers
  of Zadie Smith, readers of Susan Sontag, readers of
  Jia Tolentino, readers of Hanif Abdurraqib, readers of
  Maggie Nelson)
- Publication / venue signal where prestigious
  ("New Yorker essays", "essays from Harper's", "essays from
  the Paris Review", "selected from a decade of...")
- Avoid generic "essays" / "writings" / "thoughts" in isolation
  — they drown in algorithmic noise; prefer compound phrases
  combining mode + author-lens + subject-focus
- Avoid commercial-self-help framings ("life-changing",
  "transformative", "wisdom") — they signal mis-positioning for
  literary essay-collection readers
