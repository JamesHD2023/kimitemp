---
name: parenting-category
description: "Category-specific instructions for parenting and family non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Parenting / Family. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | parenting |
| Display Name | Parenting / Family |
| Parent Group | Parenting & Relationships |
| Typical Word Count | 50,000–75,000 (problem-solution titles often shorter; comprehensive stage-by-stage references can run 100,000+) |
| Default Structure | Stage-or-challenge chapter spine (developmental stage / age range / specific challenge); recognition-then-reframe rhythm; scripts and worked examples integrated at point-of-need; warmth-and-evidence balance throughout |
| Citation Style | Endnotes for developmental and clinical claims; named researcher and institution in-text where credibility matters ("In a 2018 study at Harvard..."); peer-reviewed sources prioritised over popular parenting writing; current paediatric / child-safety guidance cited where applicable (AAP, RCPCH, NHS) |
| Audience Baseline | Parent, caregiver, or family member acting on behalf of a child or young person; emotionally invested and often exhausted; assume zero clinical training; assume the reader's family does NOT match a "default" structure (single, queer, blended, multigenerational, adoptive, foster, kinship-care, co-parented, all common) |
| Comparable Titles | Daniel Siegel & Tina Payne Bryson (*The Whole-Brain Child*, *No-Drama Discipline*), Emily Oster (*Cribsheet*, *The Family Firm*), Janet Lansbury (*Elevating Child Care*), Ross Greene (*The Explosive Child*, *Raising Human Beings*), Adele Faber & Elaine Mazlish (*How to Talk So Kids Will Listen*), T. Berry Brazelton (*Touchpoints*), Penelope Leach (*Your Baby & Child*), Alfie Kohn (*Unconditional Parenting*), Wendy Mogel (*The Blessing of a Skinned Knee*), Lawrence J. Cohen (*Playful Parenting*), Mona Delahooke (*Beyond Behaviors*), Sarah Ockwell-Smith (*The Gentle Discipline Book*), Pamela Druckerman (*Bringing Up Bébé*) |

## Subcategory Options

When the user selects Parenting / Family, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| pregnancy-infant-care | Pregnancy & Infant Care (0–12 months) | Pregnancy, birth preparation, newborn care, feeding (breast / formula / combination), infant sleep, first-year development, postpartum well-being | Trimester / milestone-led chapters for pregnancy; first-week / first-month / first-year segmentation for infant care; safety-critical content (SIDS / safe sleep / car-seat) prominent; postpartum mental-health awareness woven through |
| early-childhood | Early Childhood (1–5 years) | Toddler and preschool development, separation, language acquisition, self-regulation emergence, play-based learning, daily-rhythm building | Developmental-stage spine; frequent recognition-then-reframe scenarios; concrete scripts for common moments (transitions, big feelings, "no", separations); play-and-learning integration |
| school-age-tween | School-Age & Tween (6–12 years) | School transitions, peer relationships, growing independence, screens / technology, identity formation, pre-adolescent change | Domain-led chapters (school / friendship / family / self) rather than strict age progression; scripts for harder conversations (bullying, body changes, difficult topics); autonomy-vs-connection framing |
| adolescent-teen | Adolescent & Teen (13–21 years) | Adolescent brain development, autonomy, risk and decision-making, mental health, romantic relationships, transitions to adulthood | Brain-development context as anchor; co-regulation rather than control framing; risk topics handled with evidence-based directness (substances, sex, social media, mental health crisis); preserving-relationship-while-setting-limits as recurring theme |
| parenting-philosophy | Parenting Philosophy / Approach | Specific named approaches: gentle / respectful, authoritative, attachment, RIE, conscious, free-range, collaborative problem-solving, etc. | Approach-fundamentals chapter up front; principles → application progression; comparison with alternative approaches handled with respect; explicit acknowledgement that no single approach fits every child / family |
| neurodivergent-special-needs | Neurodivergent / Special Needs | Parenting children with autism, ADHD, learning differences, sensory processing, anxiety, chronic illness, disability — written with current neurodiversity-affirming language | Strengths-based and accommodation-focused rather than deficit-focused; family-systems framing (sibling, parent, child interactions); navigating-diagnosis-and-services chapters; advocacy and self-advocacy support; disability community voices central |
| family-structure-dynamics | Family Structure & Dynamics | Single-parent families, blended / step-family, divorce / separation, adoption, foster and kinship care, queer and chosen-family, multigenerational households, co-parented and donor-conceived families | Structure-respecting framing (none privileged as default); transition-management content (divorce, adoption, foster placement); identity and origin-story support for children; legal and practical context where relevant |

**Default:** If the user does not specify, prompt for the child's age and
the parenting context, then select accordingly; fallback to
`early-childhood` for unclear cases (the developmental window where most
parenting books sell).

## Structural Architect Instructions
```
STRUCTURE
- Organised by developmental stage, age range, or parenting challenge
- Blend developmental science with practical advice
- Include scripts, conversation examples, and age-specific adaptations
- Reassuring, empathetic tone throughout

FORBIDDEN
- Shaming parents or implying a single "correct" approach
- Safety-critical information that contradicts current medical consensus
- Heteronormative/nuclear-family assumptions as the only lens
- One-size-fits-all claims ignoring temperament differences
```

## Content Writer Craft Rules
```
VOICE & TONE
- Empathetic, reassuring, non-judgmental. fellow parent, not authority figure
- Practical: what to actually SAY and DO, not just theory
- Acknowledge that parenting is hard and messy and imperfect
```

### Prose Rhythm Mapping

Chapter 1 opens with the parenting moment every reader recognises. The toddler
melting down in the supermarket. The teenager's door slamming shut. The infant
who will not sleep. Specificity is everything. the reader must think: that is
my life. That is my Tuesday.

Empathetic, warm, specific. Medium sentences (14-20 words) are the baseline.
Short enough to feel conversational. Long enough to carry nuance. Parenting
prose must never sound clinical or detached. this is writing about the most
emotionally saturated experience most people will ever have.

Humour is permitted and welcomed. Not sarcasm. Not self-deprecation that
masks despair. Genuine, warm humour that says: this is absurd and beautiful
and we are all figuring it out. A well-placed funny sentence earns more trust
than a paragraph of reassurance.

Evidence grounds the advice but never leads. The developmental research arrives
after the reader has nodded in recognition. "You have noticed this. Here is
why it happens." Not the reverse. The science validates what the parent has
already observed. This ordering matters. it respects the reader's experience.

Tension minimum: 4. The tension is parental love colliding with parental
exhaustion. Chapter 1 must honour both. The reader should feel seen in their
struggle before they are offered any solution. Recognition before remedy.

Pacing guideline: open with the moment (medium sentences, 14-20 words).
Let the reader sit in it for two paragraphs. Then name the feeling. Then
offer the reframe. Close the chapter with warmth. a sentence that says,
in effect: you are doing harder work than you realise, and this book is here
to help.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Developmental claims sourced | Claims about what children of a given age "typically" do, feel, or need trace to peer-reviewed developmental science or current paediatric / clinical-psychology consensus; folk wisdom and outdated stage theories not presented as current science |
| 2 | Child-safety information current | Safety information (safe-sleep, car-seat, choking, water, medication, screens, online safety) reflects current AAP / RCPCH / NHS / WHO guidance at point of writing; superseded guidance not perpetuated; date / jurisdiction of guidance noted where it might vary |
| 3 | Practical specificity | Advice is implementable today: scripts for what to actually say, examples of what to actually do, age-appropriate variations rather than abstract principle alone; "be more present" replaced with specific behaviours the parent can adopt this evening |
| 4 | Recognition before remedy | Chapter establishes the parent's lived experience first ("you have probably had this Tuesday..."), then offers reframe / strategy; advice handed to a parent who has not yet been seen rarely lands |
| 5 | Family-structure inclusivity | Examples and language do not default to a heterosexual two-parent nuclear family; single-parent, queer, blended, adoptive, foster, multigenerational, and other structures appear as natural variants rather than as exceptional cases |
| 6 | Temperament / individual-child variation acknowledged | Advice does not presume one child for whom the strategy works; temperament differences (sensitivity, intensity, adaptability), neurodivergence, and individual history acknowledged as variables affecting which approach fits |
| 7 | No-shaming tone | Parental choices contested in the broader culture (feeding methods, sleep methods, screen use, working / staying home, schooling choices) presented without shaming language; trade-offs framed honestly without moralising; "good parent / bad parent" framing avoided |
| 8 | Scope-of-practice clarity | Where content approaches clinical territory (anxiety, depression, eating disorders, behavioural disorders, developmental concerns, suspected abuse), the chapter signposts to qualified professionals rather than positioning itself as substitute for assessment |
| 9 | Age-appropriate scripts and examples | Conversation scripts and worked examples calibrated to the developmental stage the chapter addresses; toddler scripts respect toddler comprehension; teen scripts respect adolescent autonomy and brain development |
| 10 | Warmth and humour permitted; saccharine and despair not | Tone is empathetic and grounded; humour is welcomed where it lightens without minimising; the prose neither sentimentalises parenting nor wallows in its difficulties; the reader feels accompanied, not lectured or pitied |

## Source Requirements

### Mandatory Source Types

- **Peer-reviewed developmental and clinical research.** Claims about
  child development, parent-child interaction, attachment,
  self-regulation, cognitive development, sleep, feeding, language
  acquisition, and similar trace to peer-reviewed psychology /
  paediatric / developmental-science journals. The evidentiary
  backbone for all developmental claims.
- **Authoritative paediatric / child-safety guidance.** For safety
  topics (safe sleep, immunisation, car seats, water safety, choking,
  poisoning, abuse signposting, screen time at clinical levels),
  claims trace to American Academy of Pediatrics, Royal College of
  Paediatrics and Child Health, NHS, WHO, ACOG (for pregnancy /
  postpartum), or the equivalent body in the book's primary market.
- **Practitioner expertise.** Where the book draws on the author's
  clinical, educational, or coaching practice with children and
  families, the practice is named (clinical psychologist, paediatric
  developmental specialist, registered midwife, certified educator,
  family therapist) and credentials disclosed; lived experience as
  a parent is also legitimate but is not equivalent to clinical
  training and should not be conflated.
- **Anonymised case studies and family voices.** Real stories from
  families illustrate principles in practice; details should be
  changed sufficiently to protect identifiability of the children
  and families involved; explicit written consent required where
  identifiable details are retained (and even then, children
  cannot meaningfully consent to public depiction in their own
  futures — extra caution warranted).
- **Lived expertise from neurodivergent and disabled communities.**
  For neurodivergent / special-needs content specifically, voices
  from autistic, ADHD, and disabled adults (about their own
  childhoods and experiences) are mandatory inputs alongside
  clinical sources; "nothing about us without us" applies.

### Source Freshness

- **Developmental science evolves.** Pre-2000 stage-theory framings
  (rigid Piagetian stages, certain Bowlby claims, "blank slate"
  framings) have been substantially refined; pre-2010 research on
  trauma, neurodivergence, and adolescent brain development has
  been substantially superseded. Cite current research; flag
  foundational older sources when used and explain why they remain
  relevant.
- **Safety guidance currency.** Safe-sleep guidance, car-seat
  guidance, screen-time guidance, immunisation schedules, and
  feeding-introduction guidance update periodically. Confirm
  against current authoritative bodies at time of writing; note
  "current as of [year]" prominently; direct readers to authoritative
  sources for ongoing currency.
- **Neurodiversity and disability framing.** The shift from
  deficit-and-cure framings to neurodiversity-affirming framings
  has been substantial since c. 2015; pre-2010 autism / ADHD writing
  in particular often reads poorly to current audiences. Current
  community-affirming language (identity-first vs person-first
  varies by community; respect community preference) and
  strengths-based framing expected.
- **Family-structure inclusivity has shifted.** Pre-2010 parenting
  writing often defaulted to heterosexual two-parent nuclear
  families with the alternative structures treated as exceptions.
  Current practice treats family diversity as natural variation;
  outdated framings should be revised in re-issues.

### Attribution Standards

- **Developmental claims sourced.** "Studies show..." is unacceptable
  without citation; "A 2019 longitudinal study at the University of
  Minnesota found..." is the standard. Reader trust depends on this,
  particularly for parenting where bad advice can shape a child's
  development.
- **Distinguish established from contested claims.** Some commonly
  cited findings (the "marshmallow test", certain attachment-style
  classifications, screen-time-as-uniformly-harmful, the "first
  three years" critical-period claim in its strong form) have been
  challenged or refined; if cited, present the current picture
  rather than the popularised version.
- **Borrowed approaches credited.** Parenting concepts from named
  originators (Siegel's whole-brain framing, Greene's collaborative
  problem-solving, Faber & Mazlish's communication patterns, the
  RIE approach from Magda Gerber, the Pikler method, Bowlby /
  Ainsworth attachment foundations) attributed in-line; silent
  borrowing erodes credibility when sources are recognised.
- **Cultural-context honesty.** Much developmental research has
  WEIRD-population bias (Western, Educated, Industrialised, Rich,
  Democratic samples); claims that are likely culturally bounded
  should be flagged as such rather than presented as universal.
- **What is NOT acceptable.** Inventing studies. Citing popular
  press articles that cite studies, without checking the studies.
  Presenting the author's individual parenting experience as
  predictive of typical outcomes for other readers' children.
  Using "the science says" framing for contested or weak findings.

## Category-Specific Guardrails

### MANDATORY. Vulnerable-Third-Party Awareness (the child's interests come first)

- The reader of a parenting book is a parent or caregiver acting on
  behalf of a child. The book's recommendations are recommendations
  the parent will execute on a child who cannot consent to the
  approach. This asymmetry shapes everything.
- Recommendations that risk a child's safety, dignity, or
  attachment must be subject to higher evidentiary and ethical
  scrutiny than self-help recommendations to adults about their
  own lives. "Try this approach with your toddler" is not the same
  as "try this approach with yourself."
- The book sees the child's wellbeing as the primary criterion;
  the parent's convenience is a legitimate consideration but
  cannot override a child's safety or developmental needs.
- Where an approach is genuinely contested (e.g. some sleep-training
  methods, some discipline approaches), the book presents the
  evidence and the trade-offs honestly rather than asserting one
  position as definitive; the parent makes the choice with eyes
  open.

### MANDATORY. No Medical Diagnosis or Treatment Advice

- Parenting writing exists alongside paediatrics, child psychology,
  child psychiatry, and family medicine but is NOT any of them.
- The book may discuss developmental concepts, common patterns, and
  age-appropriate behaviours for the reader's understanding.
- The book MUST NEVER provide diagnostic criteria for the reader to
  self-diagnose their child with a clinical condition (autism, ADHD,
  anxiety disorder, depression, eating disorder, learning disability,
  attachment disorder, etc.).
- The book MUST NEVER advise the reader to discontinue paediatric or
  mental-health treatment, defer assessment when one is warranted,
  or replace clinical care with the book's strategies.
- For symptoms or behaviours that may indicate clinical concern
  (persistent sadness, eating-pattern changes, suicidal ideation,
  self-harm, severe behavioural escalation, suspected abuse,
  developmental milestones substantially missed), the book directs
  the reader to qualified professionals — paediatrician, GP,
  child psychologist, child psychiatrist, family therapist, social
  worker, or relevant helpline — rather than positioning itself as
  the assessment.
- Include a clear disclaimer up front: this book is parenting
  writing, not medical or psychological advice; readers with
  concerns about their child should consult a qualified clinician;
  nothing in the book replaces clinical assessment or treatment.
- The line: parenting writing can support family functioning; it
  cannot replace clinical care for a child in clinical need.

### MANDATORY. Child-Safety Information at Point-of-Need

- Safe-sleep guidance for infants (back-to-sleep, firm flat surface,
  no soft bedding / pillows / bumpers in the cot, room-sharing
  without bed-sharing in the first 6 months per current AAP /
  RCPCH; specific bed-sharing protocols where the family has
  chosen co-sleeping with awareness of the trade-offs).
- Car-seat guidance per current best-practice (rear-facing as long
  as possible per current RAP / NHTSA / RoSPA; specific weight /
  age thresholds per current guidance; isofix / LATCH installation
  notes; second-hand seat warnings).
- Choking-hazard guidance for infant feeding (size and texture of
  age-appropriate food, foods to avoid in the first year, baby-led
  weaning safety considerations).
- Water-safety guidance (active supervision, never alone near water
  even briefly, learn-to-swim age guidance, pool fencing, bath
  safety).
- Online-safety guidance for older children (privacy, predator
  awareness, age-appropriate platform use, parental-tools framing
  rather than surveillance framing).
- Where the book covers any of these, the safety information
  appears at point-of-need with the standard SAFETY callout, NOT
  buried in an appendix; current as of the publication date with
  the "consult current authoritative guidance" caveat.

### MANDATORY. Family-Diversity Inclusivity (no default family)

- Examples and language do not assume a heterosexual two-parent
  married nuclear family as the default with all other structures
  as exceptions. Single parents, same-sex couples, blended and
  step-families, adoptive and foster families, kinship-care
  arrangements, multigenerational households, donor-conceived
  families, co-parented arrangements between non-couples are
  natural variants and appear in the book accordingly.
- "The mother" and "the father" specifically are often less useful
  than "the parent" or "the caregiver"; binary parental-role
  language ("mum does X, dad does Y") treats one structure as
  default and others as awkward.
- Where the book's content genuinely depends on family structure
  (postpartum recovery, gestational parent's body, donor-conception
  identity-formation conversations), structure-specific framing is
  fine — but the book makes clear which content is structure-
  specific and offers alternatives where relevant.
- Cultural-and-class diversity in parenting practice acknowledged;
  practices presented as "good parenting" should be examined for
  their cultural and class assumptions, particularly where they
  conflict with practices common in non-Western or working-class
  contexts.

### MANDATORY. No Shaming of Contested Parental Choices

- Choices contested in the broader parenting culture — feeding
  method (breast / formula / combination / extended breastfeeding /
  early weaning), sleep arrangement (independent sleep / co-sleeping
  / various sleep-training approaches), discipline approach (gentle
  / authoritative / time-out / natural-consequences / various),
  schooling choice (state / private / homeschool / unschool),
  parental work arrangement (full-time work / part-time / stay-at-
  home / shared / single-earner) — are presented WITHOUT shaming
  language regardless of the author's own preferences.
- The book may make recommendations and may explain its reasoning;
  it does not call parents who choose otherwise irresponsible,
  selfish, lazy, or harming their children. Trade-offs are framed
  honestly without moralising.
- Particularly avoid: "good mothers / fathers / parents do X"
  framings, "real X parenting means Y" framings, and contrast-
  shaming where the implicit other ("unlike parents who..."
  ) is held up for negative comparison.
- Awareness that many parental choices are heavily constrained by
  economic, social, structural, and personal-history factors;
  framing structural constraints as personal moral failings is a
  category-defining failure.

### Additional Guardrails

- **Suspected-abuse signposting.** Where the book touches on signs
  of abuse, neglect, or domestic violence affecting children, the
  book directs readers to appropriate authorities and helplines
  rather than positioning the book as adequate guidance for what
  to do; mandatory-reporting context for clinicians and educators
  noted where relevant.
- **Mental-health crisis pathways.** For content addressing
  childhood / adolescent mental health (anxiety, depression,
  self-harm, suicidal ideation), the book includes signposting to
  helplines, crisis support, and qualified professionals
  prominently — front matter, relevant chapters, and resource
  appendix.
- **Postpartum mental-health awareness.** Pregnancy / infant-care
  titles include postpartum depression and postpartum anxiety
  awareness, signs to watch for, and signposting to maternal-
  mental-health services; the parent's wellbeing is part of the
  child's wellbeing, not a competitor for attention.
- **Neurodiversity-affirming language.** Current best practice in
  language use (autism / autistic per individual or community
  preference; "differently wired", "neurodivergent" as community-
  preferred over deficit framing; identity-first vs person-first
  varies by community); deficit-only framings ("suffers from",
  "afflicted with") avoided unless quoting source material.
- **Author's lens disclosed.** The author's own family situation,
  cultural context, and parenting experience shape the book; some
  disclosure ("I am a parent of two; we are a queer two-mum
  household; I trained as a paediatric occupational therapist...")
  helps readers calibrate which elements of the book's perspective
  are universal and which are author-specific.
- **Currency disclosure.** Date the safety guidance ("current as
  of [year]"); name the jurisdiction; direct readers to authoritative
  sources for ongoing currency. Recommendations on screens, social
  media, online safety age fastest.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Warm and reassuring (cream, dusty rose,
  sage, terracotta, oat) for general parenting and gentle-approach
  titles; clean and restrained (white + single accent, navy +
  white, deep green + cream) for evidence-based / data-driven
  titles where the cover should signal authority over softness;
  warmer naturals (mustard, ochre, faded coral) for narrative
  parenting essays and memoir-adjacent positioning. Avoid the
  default "pink-or-blue baby aisle" palette that flags as
  unsophisticated or gender-essentialist.
- **Typography:** Friendly sans-serif (Avenir, Sofia Pro, Avenir
  Next, Calibre) for general parenting; warmer serifs (Garamond,
  Mrs Eaves, Adobe Caslon) for literary parenting essays and
  attachment-tradition titles; substantial sans-serif (Gotham,
  Proxima Nova) for evidence-based titles where authority
  matters. Hand-lettered display fonts work for memoir-adjacent
  and lighter-tone titles; less effective for clinical-adjacent
  positioning.
- **Imagery:** Three dominant traditions:
  1. **Parent-child interaction** — most common; calibrate
     diversity (skin colour, family structure, age representation)
     to signal inclusive readership and avoid implying a default
     family. Stylised illustration often outperforms photography
     for avoiding "this isn't my family" mismatches.
  2. **Symbolic / iconographic** — a single resonant object (a
     pair of small shoes, a hand reaching, a pram, a heart, a
     thread); strong for evidence-based and reflective titles
     where the cover should invite without committing to a
     specific family appearance.
  3. **Pure typography** — for high-trust author brands (Siegel,
     Oster, Greene), data-driven titles, and books where the
     argument is the draw. Often paired with a single colour
     accent or small icon.
- **Mood:** Reassuring competence. The cover should signal "this
  book understands parenting is hard and offers something
  trustworthy" — not "perfect parents make perfect children",
  not "your child is broken and this book will fix them", not
  saccharine sentimentality. Parents in the bookstore are tired;
  the cover that respects that wins.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Pregnancy & Infant Care | Soft palette, often illustration over photography; symbolic imagery (cot, blanket, small shoes) where photography would imply a default family; warm typography with reassuring weight |
| Early Childhood | Slightly bolder palette; child-at-play imagery or stylised illustration; sans-serif typography with friendly weight; subtitle clarifies the age-band ("the toddler years", "ages 1 to 5") |
| School-Age & Tween | Calmer palette; illustration or iconographic (a backpack, a book, an open door); typography signals practical authority; subtitle emphasises the developmental shift the book addresses |
| Adolescent & Teen | Restrained palette (less pastel, more navy / charcoal / single bold accent); often typographic or symbolic rather than figurative; subtitle clarifies the angle (autonomy / mental health / connection) |
| Parenting Philosophy | Signature aesthetic for the named approach (Siegel-and-Bryson have a recognisable style; gentle-parenting titles share a softer language; RIE / respectful-parenting is restrained and clean); typography signals the author or movement |
| Neurodivergent / Special Needs | Affirming palette (avoid pathologising blue / clinical white in favour of warmer or more vibrant choices); symbolic or stylised illustration (avoid puzzle-piece imagery for autism, which the autistic community largely opposes); typography accessible and warm |
| Family Structure & Dynamics | Inclusive imagery — explicitly showing the structure the book addresses (queer family, blended family, adoption); warm palette; typography signals approachability |

### Typography Rules

- **Title:** 30–50% of cover area. Parenting titles can be
  promise-based ("No-Drama Discipline"), descriptive
  ("Cribsheet"), or evocative ("The Whole-Brain Child"). All
  three work; the title must read at thumbnail.
- **Subtitle:** Often essential — does the descriptive work the
  title leaves abstract. "An Economist's Guide to Better,
  More Relaxed Parenting, From Birth to Preschool" (Cribsheet
  Vol 2). "Why Children Get Stuck and How to Help Them" (Greene
  on collaborative problem-solving). Specific subtitle outsells
  vague subtitle.
- **Author name:** Larger for established author-brands (Siegel,
  Bryson, Oster, Greene, Faber, Mazlish); smaller for unestablished
  authors with credentials in subtitle ("by a paediatric
  developmental specialist", "by a family therapist"). Author
  qualifications signalling clinical training (PhD, MD, LCSW,
  MFT, registered midwife) help in this category.
- **Series / co-author marking:** When part of a series (Siegel /
  Bryson collaboration; Greene's Lives in the Balance series;
  Oster's data-driven trilogy), series identity on cover or spine.
  Edition / "Updated for [year]" prominently marked when applicable —
  parenting research and safety guidance evolve, and parents
  buying a 2015 book want to know they have current guidance.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Pregnancy & Infant Care | Kindle Store > Kindle eBooks > Parenting & Relationships > Parenting > Early Childhood (or > Pregnancy & Childbirth for pregnancy-led titles) |
| Early Childhood | Kindle Store > Kindle eBooks > Parenting & Relationships > Parenting > Early Childhood |
| School-Age & Tween | Kindle Store > Kindle eBooks > Parenting & Relationships > Parenting > School-Age Children |
| Adolescent & Teen | Kindle Store > Kindle eBooks > Parenting & Relationships > Parenting > Teenagers |
| Parenting Philosophy | Kindle Store > Kindle eBooks > Parenting & Relationships > Parenting (broad) — and a secondary on Self-Help > Personal Transformation > Inner Child or Personal Growth where philosophy crosses into self-development |
| Neurodivergent / Special Needs | Kindle Store > Kindle eBooks > Parenting & Relationships > Parenting > Special Needs (and / or Health, Fitness & Dieting > Children's Health > [Specific Condition]) |
| Family Structure & Dynamics | Kindle Store > Kindle eBooks > Parenting & Relationships > Family Relationships > [specific structure: Adoption / Blended Families / Single Parents / etc.] |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Family relationships (broad) | Kindle Store > Kindle eBooks > Parenting & Relationships > Family Relationships |
| Education / homeschooling | Kindle Store > Kindle eBooks > Education & Teaching > Homeschooling (or Schools & Teaching) |
| Children's health | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Children's Health |
| Mental health (child / family) | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Mental Health > Anxiety Disorders / Depression / Children's Mental Health |
| Self-help (parent's own work) | Kindle Store > Kindle eBooks > Self-Help > Family Relationships (or Personal Transformation > Inner Child) |
| LGBTQ+ family | Kindle Store > Kindle eBooks > Parenting & Relationships > Family Relationships (with LGBTQ+ Studies cross-listing where relevant) |
| Adoption / fostering | Kindle Store > Kindle eBooks > Parenting & Relationships > Family Relationships > Adoption |
| Pregnancy / postpartum | Kindle Store > Kindle eBooks > Parenting & Relationships > Pregnancy & Childbirth (with Health, Fitness & Dieting > Women's Health > Pregnancy & Childbirth secondary for medical-adjacent) |

### Keyword Recommendations

- The age stage as a phrase
  ("toddler parenting", "tween years", "raising teenagers",
  "newborn care", "first-time parent", "parenting a five-year-old")
- The specific challenge or goal
  ("tantrums", "sleep training", "screen time", "bedtime",
  "sibling rivalry", "anxious child", "ADHD parenting",
  "autism parenting", "raising resilient kids")
- The parenting approach or philosophy
  ("gentle parenting", "respectful parenting", "attachment
  parenting", "RIE", "conscious parenting", "collaborative
  problem solving", "evidence-based parenting")
- The family structure where relevant
  ("single parent", "blended family", "step-parent",
  "adoptive parent", "queer family parenting", "two mums",
  "two dads", "kinship care", "foster parent")
- Comparable author / brand for discoverability
  (readers of Daniel Siegel, readers of Emily Oster, readers of
  Janet Lansbury, readers of Ross Greene, readers of Adele Faber)
- Outcome the parent is seeking
  ("less yelling", "more connection", "better sleep",
  "calmer mornings", "happier family", "stronger relationship")
- Author-credential cues where relevant
  ("by a paediatrician", "by a child psychologist", "by a
  developmental specialist", "by a family therapist")
- Avoid generic "parenting" / "kids" / "family" terms in isolation
  — they drown in algorithmic noise; prefer compound phrases
  combining age + approach + outcome
- Avoid promise-overreach ("perfect parent in 30 days", "fix
  your child in a week") — they signal pulp positioning and
  damage credibility with the readers serious parenting titles
  need to attract
