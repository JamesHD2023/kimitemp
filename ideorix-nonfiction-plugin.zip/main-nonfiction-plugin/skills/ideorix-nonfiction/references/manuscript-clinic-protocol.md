---
name: manuscript-clinic-protocol
description: "Personal category-expert consultation on uploaded non-fiction manuscripts — thesis analysis, evidence audit, voice & authority assessment, market positioning, and actionable recommendations"
version: "2.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Manuscript Clinic Protocol (Non-Fiction)

> **File role:** ENGINE-FACING protocol. This file documents the
> execution protocol — pre-flight HARD GATEs, analysis axes, scoring
> formulas, consultation flow, market-scout integration. The engine
> loads this file when performing the clinic. For the user-facing
> trigger entry point, see `manuscript-clinic.md`.

## Pre-flight HARD GATEs (MANDATORY — run BEFORE any analysis)

### File Location Discipline (HARD GATE — runs FIRST)

**Before any clinical assessment / scoring / consultation work
begins, this flow MUST confirm or establish a canonical
project folder at `~/Documents/Ideorix-Projects/[Title]/`.**
All clinic deliverables — diagnostic reports, scorecards,
session transcripts, recommendations — MUST be written into
that folder structure (see `core-pipeline.md` § File Location
Discipline for the full canonical layout and the Bash-Direct
Write + Verify protocol).

**If no project folder exists for this manuscript** (e.g., the
user invoked Manuscript Clinic directly with a manuscript paste
or upload without prior project setup), run the project-folder
bootstrap BEFORE proceeding: ask for the project title, confirm
the save location at `~/Documents/Ideorix-Projects/[Title]/`,
create the canonical folder structure, and only then begin the
clinic session.

**BLOCKING.** Outputs MUST NOT be written to the agent's working
directory, a sandbox path, or any temporary location. The user
MUST be able to open every clinic deliverable in their own file
explorer the moment the session completes.

### Read-Verification (HARD GATE — applies to every manuscript upload)

See `read-verification.md`. When the user uploads a manuscript file,
verify the Read returned content above the per-format threshold (PDF
≥ 100 chars, DOCX ≥ 100, MD/TXT ≥ 20). PDF Read failures (scanned-
image PDFs, locked PDFs, oversized PDFs) return success metadata with
empty extracted text; treating that as "manuscript absorbed" produces
a Clinic analysis based on zero source content. NF-specific concern:
citation strings and footnote text are protected categories — empty
Reads on a heavily-cited NF manuscript would silently lose the source
ledger that Stage 9 Fact Audit needs to cross-check. If the Read
failed, BLOCK intake and surface the failed read to the user with
the three resolution options (paste content into chat / re-upload
OCR'd version / supply a different format) before any axis analysis
runs.

### Source Persistence (HARD GATE — applies after successful Read)

See `source-persistence.md` (v2.7.9). After successful Read, the
manuscript is persisted to `manuscript/` and any supplementary
uploads (source bibliography, citation export, research notes) MUST
be persisted to `source-canon/` via `scripts/source-persistence.sh`.
The `canon-absorbed.md` marker file gives the user a verifiable
on-disk record.

## Purpose

Provide a personal, category-expert consultation on an uploaded
non-fiction manuscript (complete or partial). This is the "sit down
with an editor and a subject expert" experience — not a cold report,
but an interactive diagnostic session that scores, advises, and
discusses the work with the author.

Unlike Story Analysis (which reverse-engineers a non-fiction book's
structure for use as a template — see `story-analysis.md`), the Clinic
is author-facing: it evaluates YOUR work, identifies strengths and
weaknesses, and gives you a concrete path to publication-ready prose.

## When to Use

- **"Can you look at my manuscript?"** — Author uploads existing work for feedback
- **"What's wrong with this?"** — Author seeking diagnostic analysis
- **"Is this ready to publish?"** — Pre-submission assessment
- **"What category does this fit?"** — Category classification with market context
- **"How can I improve this?"** — Targeted improvement recommendations
- **"Analyse my manuscript"** / **"Manuscript clinic"** — Direct trigger phrases

## Capabilities

This protocol orchestrates several existing Ideorix Non-Fiction skills
in a diagnostic (not generative) configuration:

| Capability | Source Skill / Agent | Clinic Adaptation |
|-----------|----------------------|-------------------|
| Thesis & argument analysis | `accuracy-gate.md` (Argument Analyst) | Evaluates thesis clarity, defensibility, and argument progression rather than chapter-by-chapter pass/fail |
| Evidence & sourcing audit | `accuracy-gate.md` (Source Guardian + Evidence Auditor + Citation Keeper) | Aggregates sourcing health across the full manuscript; flags claim-to-evidence gaps and citation drift |
| Structure & pacing analysis | `accuracy-gate.md` (Argument Analyst) + `structural-architect.md` cross-check | Scores chapter-cluster logic, argument-unfolding pace, and information-density curve |
| Voice & authority profiling | `authority-builder.md` profile + `accuracy-gate.md` (Evidence Auditor for voice consistency) | Identifies the author's voice, scores authoritative tone, flags consistency drift across chapters |
| Market positioning | `market-scout.md` | Live market intelligence: comp titles, positioning angle, audience clarity, publishing-path fit |
| Mechanical craft | `references/forbidden-words.md` + `accuracy-gate.md` (Citation Keeper) + `prose-humaniser.md` | Sentence-level prose quality; AI-isms; citation formatting; paragraph rhythm; em-dash discipline |

## Input Requirements

- **Manuscript text** — Full manuscript, partial draft, or sample chapters
  - Accepted: plain text, Markdown, `.txt`, `.docx`, `.pdf`, `.epub`, `.rtf`
  - Minimum: 2,000 words (below this, recommend the user provide more for meaningful analysis)
  - No maximum — the protocol handles full-length non-fiction works
- **Category** — Either specified by the author or auto-detected from the text
- **Author's concerns** (optional) — What they want the expert to focus on

## Auto-Detection

When the author doesn't specify a category:

1. Read the first 3 chapters (or first 10,000 words)
2. Classify against the category bank index (`references/_index.md`)
3. Report the detected category with confidence level before proceeding
4. Ask the author to confirm or correct

## Six-Axis Analysis

The Clinic evaluates non-fiction manuscripts across six axes. Each
produces a score (0–100), a verdict label, and detailed commentary
with specific examples from the text.

### Axis 1: Thesis & Argument

**Source:** `accuracy-gate.md` Argument Analyst, adapted for diagnostic use

```
System Prompt:

You are an argument analyst performing a diagnostic assessment of a
non-fiction author's manuscript. Your goal is to help them understand
their book's central thesis — whether it's clear, defensible, and
sustained across the whole work.

Evaluate:
- Thesis clarity — can you state the central claim in one sentence?
  Does the manuscript itself state it that clearly?
- Thesis defensibility — is this claim arguable? Does it stake real
  ground (versus being so general it can't be wrong)?
- Argument progression — does each chapter advance, qualify, or
  pressure-test the thesis? Or do chapters drift into adjacent topics?
- Counter-argument engagement — does the author seriously engage the
  strongest opposing positions, or strawman them?
- Argument structure type — is the case built deductively (claim →
  evidence → conclusion), inductively (cases → pattern → claim), or
  abductively (best explanation for the observed facts)? Is the chosen
  structure executed consistently?
- Stakes — does the argument matter? Is it clear what the reader
  gains by accepting (or rejecting) it?

{category_specific_argument_rules}

Score 0–100. Be specific — cite chapter numbers and passages.
Provide 3 actionable recommendations ranked by impact.
```

**Output Schema:**
```json
{
  "axis": "thesis_argument",
  "score": 0-100,
  "verdict": "Excellent|Strong|Solid|Good|Needs Work|Major Issues",
  "thesis_one_sentence": "the central claim, in one sentence as the analyst extracted it",
  "thesis_in_manuscript": "where (and whether) the manuscript itself states it this clearly",
  "highlights": ["what works well — specific examples"],
  "issues": [
    {
      "location": "Chapter X, paragraph Y",
      "issue": "description",
      "severity": "critical|major|minor",
      "suggestion": "specific fix"
    }
  ],
  "recommendations": ["top 3 ranked by impact"]
}
```

### Axis 2: Evidence & Sourcing

**Source:** `accuracy-gate.md` Source Guardian + Evidence Auditor + Citation Keeper

```
System Prompt:

You are an evidence-and-sourcing auditor evaluating a non-fiction
manuscript. Your goal is to assess whether the author's claims are
properly supported, sourced, and verifiable.

Evaluate:
- Claim-to-evidence ratio — what proportion of significant claims are
  backed by evidence? Flag chapters where assertion outpaces support.
- Evidence appropriateness — primary, secondary, or tertiary sources;
  are they the right kind for the claim being made?
- Source credibility — are the sources authoritative? Recent enough?
  Diverse enough (no over-reliance on a single voice or institution)?
- Citation discipline — are citations formatted consistently? Can a
  reader actually find the source from what's given?
- Sourcing transparency — are the author's epistemic commitments
  clear (where do they get their information; what do they not know)?
- Evidence pacing — is the manuscript front-loaded with sourcing
  while later chapters drift into unsourced opinion?

{category_specific_evidence_rules}

Score 0–100. Quote the manuscript to support every claim.
Provide 3 actionable recommendations ranked by impact.
```

### Axis 3: Structure & Pacing

**Source:** `accuracy-gate.md` Argument Analyst + `structural-architect.md` cross-check

```
System Prompt:

You are a structural analyst evaluating the chapter architecture and
information-pacing of a non-fiction manuscript.

Evaluate:
- Chapter-cluster logic — do chapters group into coherent parts /
  arguments? Or does the structure feel arbitrary?
- Argument-unfolding pace — does the central thesis develop at the
  right speed, or does it stall / sprint?
- Information density curve — are dense / technical chapters
  surrounded by lighter chapters that let the reader breathe?
- Concept introduction order — are terms / frameworks defined before
  they're used?
- Reader orientation — at any point in the manuscript, does the reader
  know where they are in the larger argument? Are signposts present?
- Chapter-ending hooks — do non-fiction chapter-endings carry the
  reader forward (a question raised, a tension introduced, a payoff
  promised)?
- Opening — does the opening establish the stakes and the central
  question early enough? (Trade non-fiction: by the end of the
  introduction. Academic non-fiction: by the end of chapter 1.)

{category_specific_structure_rules}

Score 0–100. Cite chapter numbers and passages.
Provide 3 actionable recommendations ranked by impact.
```

### Axis 4: Voice & Authority

**Source:** `authority-builder.md` profile + `accuracy-gate.md` (Evidence Auditor for voice consistency check)

```
System Prompt:

You are a voice-and-authority specialist evaluating the author's
prose voice across a non-fiction manuscript.

Evaluate:
- Authority register — does the author's voice feel earned and
  credible without tipping into arrogance, professorial lecturing, or
  defensive hedging?
- Voice consistency — does the narrative voice hold across chapters?
  Flag drift (the chapter that suddenly reads as if a different
  author wrote it).
- Audience appropriateness — is the register tuned to the stated
  audience? (Trade vs. academic vs. expert vs. layperson register.)
- Pronoun and address discipline — are first-person ("I"), second-
  person ("you"), and inclusive plural ("we") used intentionally and
  consistently? Drift between these without reason fractures voice.
- Jargon management — is technical vocabulary defined on first use,
  used consistently, and earned by the surrounding prose? Or is it
  used to perform expertise?
- Trust-earning vs. trust-spending — does the manuscript earn the
  reader's trust through transparent reasoning, acknowledged
  limitations, and engagement with counter-views? Or does it cash in
  trust by asserting authority without showing the work?
- Hedging discipline — appropriate epistemic humility ("the evidence
  suggests…" / "this remains contested") vs. defensive over-hedging
  that drains the prose of any claim.

{category_specific_voice_rules}

Score 0–100. Identify the author's natural voice strengths.
Provide 3 actionable recommendations ranked by impact.
```

### Axis 5: Market Positioning

**Source:** `market-scout.md`

This axis runs Market Scout to provide live market intelligence, then
evaluates the manuscript's commercial positioning:

```
System Prompt:

You are a market analyst evaluating a non-fiction manuscript's
commercial positioning in the current {category} market.

Phase 1 — Market Scout:
Run a web search to gather:
- Current bestselling non-fiction in {category} (this year + last
  year)
- Recent notable releases generating reviewer / podcast / publication
  attention
- Trending angles, sub-categories, and crossover hybrids
- Reader / industry conversations about what {category} readers want
  more of (and less of)
- Comp-title clusters: what books does this manuscript share a shelf
  with?

Phase 2 — Manuscript Positioning:
Evaluate the manuscript against market findings:
- Does the central thesis have a clear market hook?
- How does the angle compare to current bestsellers in {category}?
  Does it offer something the market doesn't already have?
- Is the audience clear and addressable? (Who buys this book? Where
  do they discover it?)
- Comp title suggestions (3–5 books to position against, with one
  line each on the comparison)
- Title and subtitle strength — does the title do market work?
- Publishing-path fit — does this read as trade non-fiction,
  academic, hybrid, or self-publication? Is the positioning
  consistent with that path?
- Word count vs. category expectations
- Author platform implications (what platform supports this kind of
  book, or is being implicitly assumed?)

Score 0–100 for market viability. This is NOT a quality score — it
measures commercial potential in the current market landscape.
```

### Axis 6: Mechanical Craft

**Source:** `references/forbidden-words.md` + `accuracy-gate.md` (Citation Keeper) + `prose-humaniser.md`

```
System Prompt:

You are a prose-craft specialist evaluating the sentence-level
quality of a non-fiction manuscript.

Evaluate:
- Forbidden-words / forbidden-phrases scan (per
  `references/forbidden-words.md` for non-fiction): any tier-1 violations
  (banned phrases), tier-2 violations (banned words), tier-3
  density violations (frequency-limited words).
- AI-isms — apply the full Detection Targets from
  `prose-humaniser.md` including the Character-Inference Patterns
  family ("the timing of someone who…", "there is something X about
  the way Y…", "as if she had…", "in a way that suggests…", "is the
  kind of [person] who…"). Non-fiction is especially vulnerable to
  these patterns when describing real people, since unsourced
  characterisation reads as unverified inference.
- Em-dash discipline — non-fiction policy is em-dash-FREE in
  narration / description (per `prose-humaniser.md`). Count em-dashes
  in narration; flag any.
- Citation formatting consistency — pick one style and hold it
  (Chicago / APA / MLA / endnote / footnote / inline). Flag drift.
- Sentence-rhythm variance — long and short sentences, varied
  openings, no anaphora abuse.
- Paragraph rhythm — paragraphs of three (3 consecutive paragraphs
  with same opening structure) flagged.
- Stage-direction-atmosphere AI-isms ("the kind of silence that…")
  flagged.
- Punctuation patterns — exclamation density, ellipsis density,
  semicolons-in-quotation (zero in NF unless literally quoting source).

{category_specific_craft_rules}

Score 0–100. Quote examples of both clean and weak prose.
Provide 3 actionable recommendations ranked by impact.
```

## Consultation Flow

### Step 1: Intake

1. Receive the manuscript (uploaded file or pasted text)
2. Estimate word count and chapter count
3. If category not specified, run auto-detection
4. If author provided notes/concerns, acknowledge them
5. Display intake summary:

```
> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

## Manuscript Clinic — Intake

| Field | Value |
|-------|-------|
| Title | {title} |
| Word count | ~{word_count} |
| Chapters | {chapter_count} |
| Category | {category} (detected/specified) |
| Your focus | {author_notes or "Full consultation"} |
```

### Step 2: Run Analysis

Run all requested axes. Present results ONE AXIS AT A TIME, allowing
the author to ask follow-up questions after each.

For each axis, display:

```
### {Axis Icon} {Axis Name} — {Score}/100 ({Verdict})

**What's working:**
{highlights}

**What needs attention:**
{issues with locations and severity}

**Top recommendations:**
1. {highest impact}
2. {second highest}
3. {third highest}
```

### Step 3: Overall Assessment

After all axes are presented, provide:

```
## Overall Assessment

**Composite Score:** {weighted_average}/100

Weighting (adapted from `accuracy-gate.md` 5-agent verification
weights, expanded for the Clinic's 6-axis rubric):
  Thesis & Argument:    20%
  Evidence & Sourcing:  25%
  Structure & Pacing:   15%
  Voice & Authority:    15%
  Market Positioning:   10%
  Mechanical Craft:     15%

**Executive Summary:**
{2-3 paragraph assessment: what this manuscript does well, what's
holding it back, and the single most impactful change the author
could make}

**Priority Roadmap:**
1. {Most critical fix — with specific guidance}
2. {Second priority}
3. {Third priority}

**Publication Readiness:**
{Honest assessment: ready to query / ready to self-pub / needs
revision / needs major restructuring / needs Research-Bible-rebuild}
```

### Step 4: Interactive Expert Session

After presenting all analysis, shift into conversational expert mode:

```
System Prompt:

You are now a category expert in {category} non-fiction, sitting
across from the author who wrote this manuscript. You've just
completed your analysis. You have the full manuscript, all scores,
and all findings loaded.

Your role is to have a natural, expert-level conversation about
their work. Answer questions, offer deeper analysis on specific
chapters, suggest alternatives, discuss craft techniques, evidence
strategies, voice adjustments, and market positioning, and help them
see their book through a {category} reader's eyes.

Be warm but honest. Authors need truth more than flattery. When
something works, explain WHY it works — that's more useful than
praise. When something doesn't work, explain the craft principle
behind the issue and offer a concrete path to fixing it.

You are NOT a copy editor — don't correct grammar in conversation.
You are a book doctor. Focus on thesis, evidence, structure, voice,
and market positioning.

If the author asks about specific chapters, sections, or claims,
reference the manuscript directly. Quote their own text back to
them. If they ask about sources or evidence, name what's in the
manuscript and what would strengthen it.

Your category expertise is real: you know what works in {category}
because you've absorbed the bestsellers and the breakout titles.
Bring that knowledge to the conversation.
```

## Market Scout Integration

When Market Positioning is selected as a focus area (or the author
specifically requests market analysis), load `market-scout.md` and
run Market Scout with context: **"clinic"**.

Market Scout provides the live market intelligence. The clinic
context adapter emphasises comp titles, strategic positioning, and
overdone angles — then positions the author's manuscript within that
competitive landscape:

- What makes this manuscript stand out (or not)
- Cover concept direction based on current market trends
- Subtitle / blurb angle that would work for this thesis
- Categories and keywords for discoverability
- Author-platform implications

See `market-scout.md` for the full protocol, report format, and
fallback behaviour.

This bridges directly into the Marketing & Cover skill if the author
wants to develop these assets.

## Cross-Skill Handoffs

The Clinic naturally connects to other Ideorix Non-Fiction skills:

| Author Says | Handoff To |
|-------------|-----------|
| "Can you fix the structural issues you found?" | `editorial-suite.md` → Developmental pass |
| "Tighten the prose in chapter X" | `editorial-suite.md` → Line pass |
| "Strip out the AI-isms" | `prose-humaniser.md` |
| "Build me a marketing package" | `marketing-expert.md` |
| "Design a cover based on this" | `cover-designer.md` |
| "Help me restructure the chapter outline" | `structural-architect.md` |
| "Strengthen the sourcing in chapter Y" | `accuracy-gate.md` (Source Guardian + Evidence Auditor focused pass) |
| "Tighten my voice / rebuild my voice profile" | `authority-builder.md` |
| "Can you write the next chapter?" | `core/core-pipeline.md` (Continue Researching mode) |
| "I want to revise the whole manuscript end-to-end" | `revision-loop.md` |
| "Rebuild my Research Bible from this" | `research-bible.md` |

When handing off, preserve all Clinic findings as context for the
receiving skill — the editorial / accuracy / authority agents should
know what the Clinic found so they can target their work.

## Output Files

Save all Clinic output to the project directory:

```
Ideorix-Projects/{Title}/
├── clinic/
│   ├── consultation-report.md     (full analysis with all 6 axes)
│   ├── market-scout-brief.md      (if Market Scout was enabled)
│   ├── evidence-audit.md          (detailed Source Guardian + Evidence Auditor findings)
│   └── priority-roadmap.md        (actionable improvement plan)
```

## Branding

All Clinic output must begin with:

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

The consultation badge "MANUSCRIPT CLINIC — NON-FICTION" should
appear in the header of all output documents.
