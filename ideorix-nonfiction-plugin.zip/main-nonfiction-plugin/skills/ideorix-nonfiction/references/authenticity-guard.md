---
name: authenticity-guard-nonfiction
description: "Fact verification and accuracy standards for non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Authenticity Guard — Non-Fiction

## Purpose

Ensure factual accuracy and prevent AI-generated content from introducing
false information, fabricated sources, or inaccurate claims.

## AI Fabrication Prevention

AI language models can confidently generate:
- **Fabricated sources** — books, papers, and studies that don't exist
- **Misattributed quotes** — real quotes assigned to the wrong person
- **Approximate facts** — close to correct but subtly wrong (dates off by a year, statistics rounded incorrectly)
- **Plausible but false claims** — statements that sound true but aren't

### Verification Rules

1. **Every source cited must exist in the Research Bible** — if it's not there, it cannot be cited
2. **Every quote must be attributed to the correct person** — cross-reference the source database
3. **Every statistic must match the original source** — no rounding, no approximation
4. **Every date must be verified** — cross-reference the Research Bible timeline
5. **Every person's credentials must be current** — titles and affiliations change

### AI Pattern Avoidance

Same forbidden phrase patterns as fiction (see `forbidden-words.md`). Additionally:
- Avoid "studies show" without naming the study
- Avoid "experts agree" without naming the experts
- Avoid "research suggests" without citing the research
- Avoid "it is widely known" — cite a source or remove the claim
- Avoid round numbers that feel invented ("approximately 10,000" — is it really?)

## Number Verification

Non-fiction numbers carry more weight than fiction numbers:
- **Statistics:** Must match the cited source exactly
- **Dates:** Must be verified against multiple sources where possible
- **Quantities:** Must be precise, not approximated for narrative convenience
- **Number-7 Bias:** Same AI bias check as fiction applies — scan all numbers for overrepresentation of 7
