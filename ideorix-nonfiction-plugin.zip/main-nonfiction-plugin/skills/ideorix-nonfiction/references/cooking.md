---
name: cooking-category
description: "Category-specific instructions for cooking and food writing non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Cooking & Food Writing. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | cooking |
| Display Name | Cooking & Food Writing |
| Parent Group | Cookbooks, Food & Wine |
| Typical Word Count | 50,000–90,000 (recipe-driven cookbooks vary widely with photography density; narrative food writing often 60,000–80,000; comprehensive reference cookbooks can run 150,000+) |
| Default Structure | Recipe-driven with technique-or-theme chapter spine; standardised recipe format (headnote → yield → times → ingredients in use-order → method → notes); chapter introductions establish the technique or theme that the chapter's recipes demonstrate |
| Citation Style | Cultural and historical claims attributed in headnote or chapter introduction (named source / region / era); food-science claims trace to recognised culinary-science literature (McGee, López-Alt, Modernist Cuisine); allergen and food-safety claims trace to authoritative bodies (FDA, USDA, FSA, NHS); recipe attribution where adapted |
| Audience Baseline | Home cook with kitchen access; assume basic knife skills and equipment unless title says beginner; varies from absolute-novice to professional-trade depending on positioning; allergen awareness assumed; metric/imperial dual measurement common in international markets |
| Comparable Titles | Samin Nosrat (*Salt, Fat, Acid, Heat*), Yotam Ottolenghi (*Plenty*, *Jerusalem*), Julia Child (*Mastering the Art of French Cooking*), Marcella Hazan (*Essentials of Classic Italian Cooking*), Madhur Jaffrey (*Indian Cookery*), Edna Lewis (*The Taste of Country Cooking*), Toni Tipton-Martin (*Jubilee*), J. Kenji López-Alt (*The Food Lab*), Harold McGee (*On Food and Cooking*), Stella Parks (*BraveTart*), Nigella Lawson (*How to Eat*), Anthony Bourdain (*Kitchen Confidential*), Bee Wilson (*First Bite*), Diana Henry, Nadiya Hussain |

## Subcategory Options

When the user selects Cooking & Food Writing, prompt for subcategory
refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| recipe-driven-cookbook | Recipe-Driven Cookbook | Recipes as primary content, organised by course / ingredient / technique / season; the modern mainstream cookbook | Course-or-theme chapter spine; consistent recipe format; chapter intros (1–3 pages) tie recipes to a technique or context; photography-led layout common |
| food-science-technique | Food Science & Technique | The "why" behind cooking — chemistry, physics, biology of cooking; technique mastery rather than recipe collection | Concept-per-chapter (e.g. emulsion, Maillard, gluten development); each chapter explains the science, demonstrates with worked examples, then provides recipes that apply the principle |
| food-memoir-narrative | Food Memoir / Narrative | Personal story told through food; recipes interspersed serving the narrative rather than driving it | Chronological or thematic narrative spine (food memoir is a memoir first); recipes appear at narrative inflection points; food as the lens onto a life, a place, or a relationship |
| cultural-regional | Cultural / Regional Cuisine | Cuisine of a specific place, people, or tradition; deeply attributed and contextualised; written from inside the tradition or in close collaboration with practitioners | Region-or-tradition-led chapter structure; substantial chapter introductions establishing context, history, and contemporary practitioners; recipes attributed to named sources / families / regions |
| diet-specific-lifestyle | Diet-Specific / Lifestyle | Cooking for medical requirements (coeliac, diabetes, kidney), ethical positions (vegan, vegetarian, kosher, halal), or lifestyle frameworks (Mediterranean, plant-based, paleo, low-FODMAP) | Diet-fundamentals chapter up front; recipes designed to meet the constraint without compromise; nutritional context where relevant; substitution rules clearly documented |
| baking-pastry | Baking & Pastry | Bread, cakes, pastry, confectionery — disciplines where precision, ratio, and technique matter more than improvisation | Foundational techniques chapter (mixing methods, hydration, lamination, sugar work) before recipes; weight measurements mandatory; troubleshooting tables for common failure modes; visual doneness cues critical |
| preserving-fermenting | Preserving & Fermenting | Canning, pickling, fermentation, smoking, curing, drying — disciplines with serious food-safety implications (botulism, harmful pathogens, mycotoxins) | Safety-fundamentals chapter mandatory and prominent; pH / temperature / time / salt-percentage specified for every preserve; named test methods (boil-water-bath vs pressure-canning, refractometer, pH strips); failure-recognition guidance throughout |

**Default:** If the user does not specify, prompt for the book's primary
mode (recipe-led / technique-led / narrative-led / culture-led / diet-led)
and select accordingly; fallback to `recipe-driven-cookbook` for unclear
cases.

## Structural Architect Instructions

```
STRUCTURE (varies by subcategory)
- Cookbook: organised by course, ingredient, technique, or season
- Food Science: concept-per-chapter with practical application
- Food Memoir: chronological/thematic narrative with recipes interspersed
- Cultural: by region, dish family, or cultural context
- Diet-Specific: by meal type, nutrition goal, or weekly plan

RECIPE FORMAT (standardised throughout)
- Headnote: 2-4 sentences contextualising the recipe
- Yield: servings and/or quantity
- Prep Time / Cook Time / Total Time
- Ingredient List: precise quantities, listed in order of use
- Method: numbered steps, imperative mood
- Notes/Tips: variations, make-ahead, storage, substitutions

BEATS PER CHAPTER (cookbook)
1. Introduction Beat. theme/concept for this chapter's recipes
2. Technique Beat. core technique explained with why it works
3. Recipe Beat(s). 3-5 recipes demonstrating the technique/theme
4. Variation Beat. adaptations, substitutions, dietary modifications
5. Troubleshooting Beat. what to do when things go wrong

FORBIDDEN
- Imprecise measurements ("a pinch of", "some". unless culturally appropriate)
- Missing cooking temperatures or times
- Recipes that haven't been tested / logical inconsistencies in method
- Cultural appropriation without acknowledgement and context
- Unsafe food handling practices
```

## Content Writer Craft Rules

```
VOICE & TONE
- Warm, knowledgeable, inviting. experienced cook sharing expertise
- Headnotes are personal and story-driven; methods are precise and instructional
- Food writing should make the reader hungry. sensory language is essential

EVIDENCE STANDARDS
- Recipes must be internally consistent (ingredients in method must match ingredient list)
- Food science claims from recognised culinary science sources
- Cultural/historical claims sourced and attributed
- Nutritional claims from reliable databases

SENSORY LANGUAGE
- Every chapter must engage at least 3 senses (sight, smell, taste, texture, sound)
- Cooking sounds: sizzle, bubble, crack, pour
- Describe what "done" looks like: "golden brown", "knife slides in without resistance"
```

### Prose Rhythm Mapping

Chapter 1 opens with the sensory world of the kitchen. Not with a
recipe. Not with a technique. With the smell of garlic hitting hot
oil, the sound of a knife on a wooden board, the warmth of a preheated
oven. The reader must be in the kitchen before they are told anything.

Warm, specific, inviting. Medium sentences (14-20 words) carry the
prose. Short enough to feel like a friend talking while they cook. The
voice is personal. food writing without a personal voice is a manual.

Sensory detail is non-negotiable. Every paragraph engages at least two
senses. Do not neglect sound (the sizzle of butter browning, the crack
of a bread crust) or texture (the give of ripe dough, the resistance
of a properly seared crust).

Tension ≥4. Food writing tension is APPETITE. the reader should want
to cook. The competence gap ("I can't make this" → "I can make this")
is the emotional engine. Ch 1 must create that desire.

Recipe-to-narrative rhythm:
- Headnotes: personal voice, medium sentences (14-20 words). Why this
  recipe matters. The story behind it.
- Method sections: shorter, clearer sentences (10-14 words). Imperative
  mood. Each step one action.
- Sensory checkpoints within recipes: "The onions should smell sweet,
  not sharp. If they're still sharp, give them another minute." These
  bridge instruction and craft.

Sensory progression per chapter:
- Open with olfactory hook (smell travels furthest, triggers memory)
- Build with visual detail (the colour of a properly caramelised onion)
- Land on gustatory/tactile payoff (the first bite, the texture)

Close with invitation, not instruction. the reader should walk toward
their kitchen.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Recipe internal consistency | Every ingredient in the ingredient list is used in the method; every ingredient referenced in the method is in the ingredient list; quantities match across both |
| 2 | Recipe reproducibility | A reader at the target skill level following the recipe literally arrives at the stated outcome; method has been tested by the author at minimum, ideally by a second tester in a different kitchen |
| 3 | Measurement specificity | Quantities given precisely; weight measurements (g / oz) for baking and pastry mandatory; volume + weight for international audiences; "a pinch of" / "to taste" only where culturally appropriate to the recipe's tradition |
| 4 | Temperatures and times realistic | Cooking temperatures and times match the dish's actual chemistry; oven-temperature variance acknowledged where it materially matters; visual / sensory doneness cues given alongside time |
| 5 | Method order correct | Steps in execution order; nothing later required by something earlier; ingredient prep (mise en place) addressed up front or at point-of-need |
| 6 | Yield honest | Stated yield achievable from the listed ingredient quantities; serving size declared; freezing / storage / reheating notes where relevant |
| 7 | Food-safety information present | Internal temperatures for proteins (poultry / pork / ground meat / fish / shellfish), unsafe-food-handling warnings (raw eggs in mayonnaise, raw fish in sushi-style preparations, sprouts, unpasteurised dairy in pregnancy) at point-of-need with the standard SAFETY callout |
| 8 | Allergen disclosure | Recipes containing major allergens (milk, egg, fish, shellfish, tree nuts, peanuts, wheat, soybeans, sesame; expand to local jurisdiction's labelling requirements) are flagged; allergen-aware substitutions offered where practical |
| 9 | Cultural attribution and context | Recipes from named cultural traditions are attributed (region, named source, contemporary or historical practitioner); cultural context briefly established in headnote where the dish has cultural weight; "ethnic" / "exotic" / "authentic" framing avoided |
| 10 | Sensory doneness cues | Recipes include sensory checkpoints alongside time-and-temperature ("the onions should smell sweet, not sharp", "a knife inserted comes out clean", "the dough springs back when pressed"); the reader can recognise success and failure without watching the author cook |

## Source Requirements

### Mandatory Source Types

- **Tested recipes.** The author has cooked every recipe in the book
  to completion at least once; ideally multiple times across
  different conditions (different ovens, different ingredient
  brands, different days). For commercial cookbooks, recipe testing
  by a second tester in a different kitchen is the standard;
  three-tester rounds are best practice for high-stakes baking and
  preserving titles.
- **Culinary-science literature.** Where the book explains why a
  technique works, claims trace to recognised culinary-science
  references — Harold McGee (*On Food and Cooking*), Hervé This
  (*Molecular Gastronomy*), J. Kenji López-Alt (*The Food Lab*),
  *Modernist Cuisine* series, peer-reviewed food-science journals
  for advanced claims.
- **Food-safety authorities.** For internal temperatures, time-in-
  danger-zone, canning safety, allergen labelling, fermentation
  safety — claims trace to FDA Food Code, USDA, FSIS, NIFA / National
  Center for Home Food Preservation (US); FSA, Defra (UK); equivalent
  bodies in other jurisdictions. Anecdote and "my grandmother always
  did it this way" are NOT acceptable evidence on food safety.
- **Cultural attribution.** Recipes from a named cultural tradition
  cite contemporary practitioners, elders, regional cookbooks, or
  scholarly sources. Where the author is writing from inside their
  tradition, that positioning is named. Where the author is writing
  from outside, collaborative attribution and consultation with
  practitioners from the tradition is the standard.
- **Nutritional data.** Where the book offers nutritional analysis
  per recipe, claims trace to USDA FoodData Central or equivalent
  databases (UK CoFID, McCance & Widdowson, EuroFIR); analysis
  software named where used; uncertainty acknowledged.

### Source Freshness

- **Food-safety guidance currency.** Internal-temperature
  recommendations, canning protocols, fermentation safety guidance
  are periodically updated. Confirm against current authoritative
  guidance (FDA Food Code current edition, current National Center
  for Home Food Preservation publications) at time of writing; note
  "current as of [year]". Pre-2010 home-canning guidance has been
  substantially revised in some categories.
- **Allergen labelling regulation.** Major-allergen lists vary by
  jurisdiction and update over time (sesame became the 9th major
  US allergen in 2023). Confirm the relevant list for the book's
  primary market.
- **Ingredient availability.** Equipment recommendations and brand-
  specific ingredient guidance age fastest (3–5 years); fundamental
  technique ages slowest. Date the brand-specific guidance; revisit
  before re-issue.
- **Cultural context.** Discourse around cultural attribution,
  appropriation, and decolonising the cookbook canon has evolved
  rapidly. A cookbook of an "exotic cuisine" framed as a 1990s
  reference book reads poorly now; current titles reckon with the
  framing question explicitly.

### Attribution Standards

- **Recipe origin credited where relevant.** Recipes adapted from
  named sources (a named cookbook, a named chef, a named family
  tradition, a named region) carry the attribution in the headnote
  ("Adapted from..."  / "Inspired by..."  / "Learned from..."). The
  reader should be able to trace any non-original recipe to its
  source.
- **Distinguish original / adapted / classic.** "My version of..."
  signals personal interpretation. "A classic preparation..." signals
  established canon with no single owner. "Inspired by..." signals
  loose adaptation. The differences matter to readers and to the
  authors whose work shaped yours.
- **Cultural attribution beyond recipe-credit.** A book of recipes
  from a culture not the author's own should disclose: the author's
  relationship to the cuisine (lived inside, married into, studied
  with practitioners, professionally trained), who consulted on the
  book, what was retested and verified, and what limits the author
  acknowledges in their authority.
- **Food-science claims sourced.** "Studies show..." is unacceptable
  without citation. "McGee describes..." or "Modernist Cuisine
  documents..." is the standard. Reader trust in the technique
  guidance depends on this.
- **What is NOT acceptable.** Inventing temperatures, times, or
  ratios untested by the author. Presenting traditional recipes as
  the author's own creation. Using "ethnic" / "exotic" / "authentic"
  as marketing without engaging with the framing's problems.
  Promoting brands or equipment with affiliate / sponsored
  arrangements undisclosed.

## Category-Specific Guardrails

### MANDATORY. Food Safety Information at Point-of-Need

- Internal temperatures for proteins must be specified at the
  doneness step, not buried in an appendix:
  - Poultry whole or pieces: 74°C / 165°F minimum
  - Ground meat (beef, pork, lamb, veal): 71°C / 160°F minimum
  - Pork whole cuts: 63°C / 145°F minimum + 3-min rest
  - Beef / lamb / veal whole cuts: 63°C / 145°F minimum + 3-min rest
    (medium-rare); higher per personal preference
  - Fish: 63°C / 145°F minimum (or visual flake test)
  - Egg dishes: 71°C / 160°F minimum
  - Reference current FDA Food Code / USDA / FSA guidance for the
    book's primary market.
- Time-in-danger-zone (4–60°C / 40–140°F): perishable foods should
  not sit in this range for more than 2 hours total (1 hour above
  32°C / 90°F ambient). This rule is mentioned explicitly where
  recipes have an extended out-of-fridge step.
- Raw / undercooked food warnings at point-of-need: raw eggs in
  homemade mayonnaise / aioli / Caesar dressing / mousse (use
  pasteurised eggs OR explicit risk note); raw fish in tartare /
  carpaccio / sushi-style preparations (sashimi-grade source +
  freezing protocol); unpasteurised dairy; sprouts; oysters /
  shellfish.
- Pregnancy and immunocompromised cautions where applicable:
  unpasteurised cheeses, deli meats, soft-served ice cream, raw
  fish, undercooked eggs — flagged as relevant in headnotes for
  recipes likely to attract readers in those populations.

### MANDATORY. Preserving and Fermenting Safety (where applicable)

- For canning, pickling, fermentation, smoking, curing, drying
  recipes, safety is non-optional and the book's category-defining
  failure mode is botulism. Specific requirements:
  - **High-acid vs low-acid distinction explicit.** High-acid foods
    (pH ≤ 4.6 — most fruit, properly acidified pickles, fermented
    products at correct salinity) can be safely water-bath canned;
    low-acid foods (vegetables, meat, poultry, fish, most soups)
    REQUIRE pressure canning. Recipes must specify which method
    and why.
  - **Salt percentage by weight** for fermentation (typically 2–3%
    of total vegetable weight for lacto-ferments; brine percentages
    for brine-fermented and lacto-pickles). Volume measurements are
    not adequate; weight is mandatory.
  - **Processing time and temperature** specified for canning,
    referenced to current National Center for Home Food Preservation
    or equivalent authoritative protocol; book does not invent its
    own canning times.
  - **Failure-recognition guidance**: how to recognise spoilage
    (smell, visual mould vs ferment-yeast, unusual gas, off colour),
    when to discard rather than taste, the principle "when in doubt,
    throw it out."
  - Smoking / curing recipes specify cure-mix percentages, time,
    temperature; reference established methods (Marianski, Ruhlman /
    Polcyn) rather than inventing.
  - Foraging recipes that include wild mushrooms, wild plants, or
    other gather-yourself ingredients carry explicit identification-
    safety language: name the species precisely, list lookalikes,
    direct readers to local expert verification, note that
    misidentification can be fatal.

### MANDATORY. Allergen Disclosure

- Major allergens flagged at recipe level (check current jurisdiction
  list — US: 9 major allergens including sesame as of 2023; UK / EU:
  14 declared allergens; other markets vary). Common allergen
  presence documented in the recipe headnote or via consistent
  visual flag system.
- Where a recipe contains a major allergen, an allergen-aware
  substitution is offered if the dish remains recognisable without
  the allergen ("dairy-free: substitute coconut yoghurt"); where
  the allergen is structural to the dish, that is stated honestly
  rather than offered as a flexible recipe.
- Cross-contamination guidance for severe-allergy households where
  relevant.
- The book does NOT serve as medical advice for diagnosed allergy
  or coeliac disease management; readers with diagnosed conditions
  should follow clinical guidance, not cookbook substitutions, for
  serious-risk cases.

### MANDATORY. Cultural Attribution and Sensitivity

- Recipes from cultural traditions not the author's own require:
  attribution to named sources (chefs, authors, regional traditions,
  family lineages), context establishing why the dish matters in
  its tradition, and engagement with practitioners from the tradition
  during the book's development. Silent borrowing is the
  category's most-criticised failure.
- Avoid the framing-traps: "exotic", "ethnic" (vs European cuisines
  unmarked as such), "authentic" (claimed by an outsider), "the
  best [tradition] cookbook" (when written from outside),
  "demystifying [tradition]" (positions the tradition as needing
  the author's intervention to be understood).
- Where the dish has a contested cultural origin (multiple
  traditions claim hummus / borscht / kibbeh / etc.), acknowledge
  the contest rather than asserting one origin. The acknowledgement
  itself is interesting to the reader and protects against
  community criticism that flattens a genuinely complex history.
- Engage honestly with the appropriation discourse if the book
  could attract its scrutiny. Acknowledging "this is a tradition
  not my own; here is what I learned, from whom, and what I cannot
  claim" reads as integrity, not weakness.

### MANDATORY. Recipe Reproducibility

- A recipe in the book is a contract: a reader at the target skill
  level following the recipe literally arrives at the stated dish.
  Recipes that haven't been tested fail the contract; recipes
  tested only by the author often have hidden assumptions a second
  tester catches.
- Measurement system honest to the audience: weight (grams) for
  baking and pastry mandatory; volume + weight for international
  audiences; mixing measurement systems within the book is
  acceptable but the choice should be deliberate (e.g. cups for
  large-volume produce, grams for precision spices).
- Equipment substitutions where realistic ("a heavy-based pan
  works if you don't have cast iron"; "a stand mixer makes this
  easier but a wooden spoon is fine for the small batch"); equipment
  pretensions ("you'll need a copper bowl") flagged honestly.
- Ingredient substitutions for common dietary accommodations
  (gluten-free flour, dairy-free milk, vegan binders, kosher /
  halal substitutions where applicable) where the dish remains
  meaningfully itself.

### Additional Guardrails

- **Recipe format consistency.** A reader builds expectation from
  the first recipe; format drift across the book frustrates and
  introduces error. Headnote → yield → times → ingredients-in-
  use-order → method-numbered-imperative → notes — same shape
  every recipe.
- **Headnotes earn their place.** Personal voice is what
  distinguishes a cookbook from a recipe database; but headnotes
  that meander without serving the recipe are skipped by readers.
  Two to four sentences is plenty: why this recipe, what's
  distinctive, what to know before starting.
- **Ingredient availability realism.** A recipe that requires an
  ingredient most of the target audience cannot source is a recipe
  most readers will not cook. Either commit to the unusual
  ingredient (and tell the reader where to find it), or offer a
  realistic substitute, or move the recipe to a more specialist
  audience.
- **Yield honesty.** "Serves 4" should mean "4 reasonable adult
  portions"; "makes 12" should mean "12 of the size pictured." Yield
  inflation to make recipes look economical erodes reader trust.
- **Storage and reheating.** Where applicable, document fridge
  storage limits, freezer storage, reheating instructions, and
  whether the dish improves / holds / declines with time.
  Particularly important for batch cooking and meal-prep titles.
- **Currency disclosure.** Date the book where regulation, market,
  or platform turnover would matter; note the food-safety guidance
  as current-as-of-publication and direct readers to authoritative
  sources for ongoing currency.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Warm and inviting (terracotta, sage, cream,
  oat, soft pink) for home-cooking and Mediterranean-adjacent
  cuisines; bold and saturated (deep red, indigo, jade, ochre) for
  cuisines with strong colour traditions (Indian, Mexican, Sichuan,
  Thai); restrained monochrome or single-accent for science-of-
  cooking and technical reference titles; muted naturals (linen,
  sand, smoke) for narrative food memoir.
- **Typography:** Elegant serif (Garamond, Caslon, Adobe Caslon)
  for literary food writing, narrative memoir, and heritage-cuisine
  titles where the typography signals considered prose. Clean sans-
  serif (Avenir, Sofia Pro, Calibre) for contemporary recipe-driven
  books where accessibility is the cue. Display serifs and hand-
  lettering for books with strong personality (Ottolenghi-style).
  In all cases the title must not compete with the cover image —
  usually slightly smaller, often along an edge.
- **Imagery:** Three dominant traditions:
  1. **The finished dish** — a single hero recipe or dish photograph
     beautifully styled. The most common form; the image IS the
     promise of what the reader will make. Photography is the
     dominant cost driver in commercial cookbook publishing.
  2. **Ingredient assembly** — fresh produce, oils, spices, raw
     materials photographed as still life. Strong for technique-
     led, ingredient-led, and cultural / regional cookbooks.
  3. **The kitchen / context** — the author at work, a place, a
     scene. Dominant for narrative food writing and food memoir
     where the cookbook is also a story.
- **Mood:** Appetite. The cover should make the reader hungry. A
  cookbook cover that doesn't trigger appetite has failed
  category-1 even before the typography or composition discussion.
  This is true for every subcategory — even technical-reference
  cookbooks compete for shelf attention against beautifully
  photographed competitors.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Recipe-Driven Cookbook | Hero-dish photography (often the recipe most likely to sell the book at thumbnail); warm or cuisine-appropriate palette; clean typography that doesn't compete with food image |
| Food Science & Technique | Cleaner / more typographic / occasionally diagrammatic; technique-illustration imagery (a perfect Maillard crust, an aerated meringue, a glossy emulsion); palette restrained in service of clarity |
| Food Memoir / Narrative | Place, person, or evocative-object photography rather than dish-led; warmer / more atmospheric palette; serif typography signalling literary positioning; closer to memoir cover language than cookbook cover language |
| Cultural / Regional | Cuisine-tradition-led visual language (red lacquer for Chinese, cobalt blue for Mexican, terracotta for Italian); ingredient-assembly or hero-dish imagery; typography appropriate to cuisine's design culture; subtitle establishes regional or community specificity |
| Diet-Specific / Lifestyle | Ingredient-assembly often replaces hero-dish (signals what's in the food, not just the result); lighter / cleaner palette; typography signals accessibility; subtitle clarifies the constraint and audience |
| Baking & Pastry | Often a single perfect specimen (the loaf, the layer cake, the tarte tatin); high-contrast, sharp focus; typography substantial and confident; series styling common for publisher's baking series |
| Preserving & Fermenting | Jars-of-finished-product imagery; warm earthen palette; typography signals craft / heritage; subtitle clarifies scope (water-bath canning / fermentation / smoking / cure) |

### Typography Rules

- **Title:** 25–45% of cover area in most cookbooks (smaller than
  most NF categories — the photography does most of the selling).
  Title can be evocative ("Plenty", "Salt, Fat, Acid, Heat") or
  descriptive ("Mastering the Art of French Cooking"); both work.
- **Subtitle:** Often essential for category placement and
  reader-promise specificity. "A Vegetable Cookbook" (Plenty
  subtitle). "Mastering the Elements of Good Cooking" (Salt Fat
  Acid Heat). Subtitle does the work of converting an image-
  attracted browser into a buyer.
- **Author name:** Larger for established author-brands (Nigella,
  Ottolenghi, Hazan, Lewis, Bourdain); smaller for unestablished
  authors where the recipes / cuisine carries the cover. Author's
  identity / lineage / training is often referenced in subtitle
  for credentialed positioning.
- **Recipe-count / scope cue:** "120 Recipes" / "Over 100 Recipes"
  often appears as a sticker or banner; can drive purchase but
  should not crowd the food image. Series identity, edition number,
  and award stickers (James Beard, IACP) on cover where relevant
  to category positioning.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Recipe-Driven Cookbook | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Cooking Methods (or Quick & Easy / By Course / etc. per book's organising principle) |
| Food Science & Technique | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Cooking Education & Reference (or Reference > Encyclopedias for comprehensive titles) |
| Food Memoir / Narrative | Kindle Store > Kindle eBooks > Biographies & Memoirs > Memoirs (with Cookbooks, Food & Wine > Reference > Essays as secondary) |
| Cultural / Regional | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Regional & International > [Specific Region / Cuisine] |
| Diet-Specific / Lifestyle | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Special Diet > [Vegan / Vegetarian / Gluten-Free / Diabetes / Mediterranean / etc.] |
| Baking & Pastry | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Baking (with sub-paths Bread / Cakes / Pastry / Cookies as relevant) |
| Preserving & Fermenting | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Canning & Preserving (or Cooking Methods > Specific Ingredients) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Quick & Easy | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Quick & Easy |
| Health-positioned | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Diets & Weight Loss > [Specific approach] |
| Family / kids | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Cooking by Ingredient > For Kids (or Parenting & Relationships > Parenting > Family Health) |
| Outdoor / camp / grill | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Outdoor Cooking |
| Beverage / wine / spirits | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Beverages & Wine |
| Holiday / seasonal | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Entertaining & Holidays |
| Memoir-adjacent narrative | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > Cooks, Food & Wine |

### Keyword Recommendations

- The cuisine, region, or tradition
  ("Italian cookbook", "Indian home cooking", "Mexican regional",
  "Chinese stir-fry", "Mediterranean diet", "Japanese home")
- The dietary or lifestyle constraint
  ("gluten-free baking", "plant-based", "vegan dinners", "low-FODMAP",
  "diabetes-friendly", "kosher", "halal", "kid-friendly")
- The technique or method
  ("sourdough", "pressure cooking", "sheet-pan dinners",
  "one-pan", "slow cooker", "air fryer", "fermentation",
  "water-bath canning")
- The occasion or use-case
  ("weeknight dinners", "meal prep", "entertaining",
  "holiday baking", "make-ahead", "batch cooking")
- Skill-level signal
  ("beginner cookbook", "easy", "step-by-step", "the complete
  guide", "for serious home cooks")
- Comparable author / brand for discoverability
  (readers of Ottolenghi, readers of Ina Garten, readers of
  Samin Nosrat, readers of Madhur Jaffrey)
- Recipe-count signal where impressive
  ("100 recipes", "150 vegetable recipes", "over 200 family
  meals")
- Avoid generic single-word terms ("cookbook", "recipes",
  "cooking") in isolation — they drown in algorithmic noise;
  prefer compound phrases combining cuisine + constraint + outcome
- Avoid "authentic" as keyword for cuisines not the author's own —
  the term is increasingly contested and can hurt rather than help
  positioning
