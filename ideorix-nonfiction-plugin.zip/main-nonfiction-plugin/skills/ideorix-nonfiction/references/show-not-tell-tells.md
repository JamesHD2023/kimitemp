---
name: show-not-tell-tells
description: "Engine-neutral binding/protocol. Per-chapter mechanical scan for physical-tell repetition (same gesture used 2+ times in one chapter). First gap-close in the canon-validation framework Wave 4 sequence (v2.7.30). Class A bash audit invoked via the /validate dispatcher under the SHOW NOT TELL domain. Pattern dictionary covers ~30 canonical body-language phrases (hands shook, jaw clenched, swallowed hard, eyes narrowed, etc.); per-chapter aggregate verdict + line-numbered findings."
version: "2.7.36"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Physical-Tell Repetition Audit

A binding/protocol spec for the SHOW NOT TELL domain (per
`canon-validation-taxonomy.md`). Closes the first gap in the
Wave 4 audit-additions sequence.

## Why this exists

A "physical tell" is body-language description that signals an
emotion: *her hands shook*, *his jaw clenched*, *she swallowed
hard*, *his eyes narrowed*. Physical tells are the engine of
SHOW NOT TELL — they let the reader infer emotional state from
behavior rather than from labelled emotion words ("she felt
afraid"). Used well, they read as observation of a person.

Used poorly, they fail in two recognisable ways:

1. **Lazy repetition** — the same physical tell appears twice
   in one chapter, both times signalling the same emotion. The
   reader notices: *we already saw her hands shake when the
   letter arrived; now they're shaking again at the door — has
   the writer run out of body vocabulary?*

2. **Muddled emotional mapping** — the same physical tell
   appears twice in one chapter, but the second time it signals
   a different emotion. *Her hands shook* in chapter 3 paragraph
   4 (fear of the news) and *her hands shook* in chapter 3
   paragraph 27 (anger at the messenger). Either the writer
   forgot the earlier use, or the body's vocabulary is too
   narrow to distinguish the two states.

Both shapes are SHOW NOT TELL violations the writer fixes by
varying the body's vocabulary — finding a different gesture
for the second instance, or using internal monologue / dialogue
beat / setting detail to carry the emotional weight instead.

## Scope and detection model

v2.7.30 ships a **mechanical pattern-match audit**, not a
semantic emotion-classification audit. The script
(`scripts/show-not-tell-tells.sh`) maintains a dictionary of
~30 canonical physical-tell patterns and counts occurrences
per pattern per chapter. Any pattern matching 2+ times in a
single chapter is flagged.

What the audit catches:

- Literal repetition of the same physical tell in one chapter
  (the lazy-repetition shape, regardless of what emotion each
  instance signals)

What the audit does NOT yet catch (deferred):

- Same emotion expressed via different physical tells (this is
  often correct — varying the body's vocabulary is the goal)
- Distinct physical tells that happen to map to the same
  emotion at different points (requires emotion classification;
  Class B subagent extension would catch this)
- Physical tells outside the v2.7.30 dictionary (~30 canonical
  phrases). Niche tells like "his Adam's apple bobbed" or
  pattern variants the dictionary doesn't cover are not
  flagged. The dictionary can grow in subsequent releases.

The mechanical-only scope is intentional for first ship: low
false-positive rate, fast execution, no subagent dispatch.
Class B refinement (emotion-aware double-tell detection) is
queued for a later release if the mechanical version proves
insufficient.

## Pattern dictionary (v2.7.36)

The dictionary is inline in `scripts/show-not-tell-tells.sh`
PATTERNS array. Each entry is a regex matched case-insensitively
with grep `\b...\b` word boundaries. Categories:

- Hands / fingers / fists (5 patterns)
- Face / eyes / mouth / brow / cheeks (7 patterns; `lips parted`
  removed in v2.7.36 as FP-prone in neutral romance / literary
  prose where "her lips parted slightly to ask" is body language
  without emotional inflection)
- Torso / shoulders / chest / stomach / throat / spine (5 patterns)
- Breath (6 patterns)

Total: ~25 patterns covering canonical body-part-collocated
physical-tell phrasings.

**v2.7.36 dictionary tightening.** The original v2.7.30 dictionary
included four bare-verb patterns (`flinched`, `recoiled`,
`stiffened`, `shivered`). Independent code review surfaced that
these fired on non-character usage: "the wind stiffened against
the sails", "the spring recoiled", "his resolve stiffened" —
none of which are physical tells. Catching person-subject usage
of these verbs requires named-entity / pronoun context which a
regex dictionary cannot reliably express. The bare-verb patterns
were dropped to keep the dictionary's false-positive profile
clean. The trade-off is missing some real tells (e.g. "she
flinched" without an accompanying body-part collocation); a
future Class B refinement (semantic context check) can recover
the lost coverage when the framework gains semantic-tell
detection.

## Invocation

Class A mechanical script invoked by the `/validate` dispatcher
under the SHOW NOT TELL domain. Direct invocation:

```bash
scripts/show-not-tell-tells.sh <chapter-file>
```

Exit codes:

- `0` — chapter clean (no physical-tell repetition)
- `1` — one or more physical tells repeated 2+ times
- `2` — usage / file-not-found error

Output (stdout):

```
=== SHOW NOT TELL: physical-tell repetition ===
Chapter: ch03.md

FLAGGED: "hands? shook" matched 3 times
  42:Her hands shook as she opened the letter.
  89:His hands shook with fury.
  124:By morning, her hands shook again.

[FAIL] 1 physical-tell pattern(s) repeated in this chapter (3 total occurrences)

Fix: vary the body's vocabulary. ...
```

When invoked via the dispatcher, output is captured to
`engine-data/reports/validate/SHOW_NOT_TELL-show-not-tell-tells.sh.log`
(per the v2.7.36 per-(domain, script) log-path convention) and the
dispatcher emits an `AUDIT|...|SHOW_NOT_TELL|PASS|...` or `FAIL`
line.

## How writers should respond to FAILs

The audit is a signal, not a verdict. Two reasonable responses
to a flagged repetition:

1. **Vary the body's vocabulary.** Replace the second instance
   with a different gesture that signals the same emotion. *Her
   hands shook* → *her fingers tightened around the cup*. This
   is the default fix.

2. **Justify the repetition.** Sometimes a physical tell
   recurring across a chapter is intentional — a character's
   tic, a deliberate mirror between two scenes, a motif. In
   these cases the repetition is a craft choice, not a bug.
   The writer notes "intentional motif" and moves on; the
   audit flag remains in the report as documentation.

The audit does not block phase advancement. It is a
**WARN-equivalent** in spirit (output a flag, let the writer
decide), shipped as `FAIL` exit code so the dispatcher's
PASS/FAIL aggregation surfaces it visibly. If false-positive
rate becomes a problem in practice, the audit can be moved to
`exit 3` (WARN) in a follow-up.

## Engine-neutral applicability

Both fiction and narrative non-fiction (memoir, biography,
literary journalism, narrative history) carry physical tells
in their prose and benefit from the same audit. Analytical
non-fiction (business, self-help, reference) typically has
fewer body-language descriptions; the audit runs cleanly on
such manuscripts (zero matches → zero repetitions → PASS) and
is harmless.

## Failure modes prevented

The Silent-Failure Audit catalog (`silent-failure-audit.md`)
tracks the engine's drift-failure shapes. This audit prevents:

- **Lazy-repetition cascade** — the same physical tell drifts
  into a writer's default emotional vocabulary; over time the
  manuscript reads as a small library of recurring gestures
  rather than a person. The audit catches the drift at chapter
  level, when the cost of a fix is one find-and-replace.
- **Muddled mapping cascade** — the same gesture signals
  different emotions in different scenes; the reader's
  emotional vocabulary degrades; subtext leaks. The audit
  catches the conflict at chapter level.
- **Validation-coverage misrepresentation** — without this
  audit, the SHOW NOT TELL domain is UNAUDITED in every
  `/validate` briefing; with it, the domain reports COVERED
  with PASS/FAIL findings.

## See also

- `canon-validation-taxonomy.md` — the 10-domain index this
  audit closes a gap in (SHOW NOT TELL primary-domain table)
- `validate-dispatcher.md` — the `/validate` dispatcher that
  invokes this audit at prose level (and full level)
- `silent-failure-audit.md` — catalog of drift-failure shapes;
  this audit adds row 26
- `prose-humaniser.md` (NF) — broader AI-ism / show-not-tell
  cleanup pass; this audit is one specific pattern within the
  prose-humaniser's larger remit
- `scripts/show-not-tell-tells.sh` — the bash audit script
