---
name: format-pdf
description: "Print-ready PDF generation template"
user-invocable: false
---
<!-- (c) 2025 Ideorix. All rights reserved. Proprietary software — see LICENSE.txt -->
# Print-Ready PDF Generation Template

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.pdf`

This print-ready PDF export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Overview

Generate print-ready PDFs with configurable trim sizes for paperback and hardcover.
Proper margins for binding, chapter headings positioned correctly, page numbers,
and formatting ready for print-on-demand services like KDP Print, IngramSpark,
and Barnes & Noble Press.

## Trim Size Options

| Trim Size | Use Case | Interior Margins |
|-----------|----------|-----------------|
| 5" x 8" | Mass market / compact paperback (fiction-typical) | Inside: 0.75", Outside: 0.5", Top: 0.7", Bottom: 0.7" |
| 5.5" x 8.5" | Standard trade paperback (fiction-typical) | Inside: 0.8", Outside: 0.6", Top: 0.75", Bottom: 0.75" |
| **6" x 9"** | **Standard non-fiction trade (DEFAULT for NF)** | Inside: 0.875", Outside: 0.625", Top: 0.8", Bottom: 0.8" |

**Inside margin (gutter)** is always larger to account for the binding.

**6×9 is the NF default** for trade paperback and hardcover. Non-fiction
buyers expect the larger format for serious work (memoir, business,
academic, narrative NF, biography). 5.5×8.5 is appropriate for shorter
NF (essays, slim self-help, single-topic primers); 5×8 is rare in NF.
The Cover Designer pre-selects 6×9 unless the user overrides during
Phase 0a.

## NF-Specific Formatting

### Footnote rendering

Non-fiction frequently uses footnotes for citations, methodological
caveats, and source attributions. The PDF generator renders footnotes
at the bottom of the page on which their reference appears:

- **Footnote font:** Garamond, 9pt (one point smaller than body)
- **Separator:** thin horizontal rule, 1/3 page width, above the
  first footnote on a page
- **Numbering:** continuous per chapter (resets at chapter start)
  OR continuous through the book (project-config decides; default
  is per-chapter)
- **Inline marker:** superscript number `¹`, `²`, `³` in the body
  text; clickable in interactive PDFs
- **Position:** footnotes float to the bottom of their referencing
  page; long footnotes that exceed remaining page space break to
  the next page with a "continued" indicator

### Bibliography pagination

The bibliography section (when present) takes a dedicated chapter-
break and uses:

- **Chapter heading:** "Bibliography" centred, same Garamond 18pt
  bold as other chapter headings
- **Body font:** Garamond 10pt (smaller than body to fit more
  entries per page)
- **Hanging indent:** 0.25" — first line flush left, subsequent
  lines indented to 0.25"
- **Spacing:** single line spacing within entries, 0.15" between
  entries
- **Sort order:** alphabetical by first author surname (or by
  title for unattributed sources)

### Callouts and sidebars

NF prose often includes callouts (key takeaways, pull quotes,
methodological notes) and sidebars (extended digressions, case
studies, definitions). The PDF generator renders:

- **Callout boxes:** thin border, light grey background fill,
  italic body text, full-width or 70%-width depending on length;
  may break across pages
- **Sidebars:** distinct heading style, 70%-width right-floated
  or full-width, with surrounding body text wrapping where
  appropriate (right-float only on wide enough trim sizes)
- **Pull quotes:** centred, larger font (14pt), italic, no
  border; used sparingly for emphasis

The Content Writer marks callouts and sidebars in chapter prose
using HTML comments — `<!-- callout:start -->` / `<!-- callout:end -->`
— which the PDF generator parses and converts to the appropriate
block format. See `core-pipeline.md` Markdown-Convention Notes
for the full marker set.

## Manuscript Specifications

- **Body font:** Garamond, 11pt (industry standard for print books)
- **Chapter headings:** Garamond, 18pt, bold, centered
- **Line spacing:** 1.3 (tighter than manuscript format — this is a typeset book)
- **Paragraph spacing:** 0pt (use first-line indent instead)
- **First line indent:** 0.3" (except first paragraph after heading or scene break)
- **Page numbers:** Centered in footer, starting from Chapter 1 (not title page)
- **Running headers:** Book title (verso/left pages), Chapter title (recto/right pages)
- **Chapter starts:** Always on recto (right/odd) page — insert blank verso if needed

## Title Page Structure

```
[Recto page — right side]

[generous top margin — ~35% down the page]

[Book Title — 24pt, bold, centered]

[1 blank line]

[Subtitle — 14pt, italic, centered] (if applicable)

[generous space]

[Author Name — 16pt, centered]

[Page break — verso blank, then chapter 1 on next recto]
```

## Chapter Structure

```
[Always starts on recto (odd) page]

[Drop — ~25% from top of page]

[Chapter heading — 18pt, bold, centered]
[e.g., "Chapter 1: The Discovery"]

[2 blank lines]

[Chapter body — 11pt, 1.3 spacing]
[First paragraph: no indent]
[Subsequent paragraphs: 0.3" first line indent]
```

## Scene Break Formatting

```
[blank line — ~1em space]
* * *
[blank line — ~1em space]
```

Centered, with three asterisks separated by spaces. No extra paragraph spacing.

## Node.js Generation Template

```javascript
const PDFDocument = require('pdfkit');

// Trim sizes in points (1 inch = 72 points)
const TRIM_SIZES = {
  '5x8':     { width: 360, height: 576, inside: 54, outside: 36, top: 50.4, bottom: 50.4 },
  '5.5x8.5': { width: 396, height: 612, inside: 57.6, outside: 43.2, top: 54, bottom: 54 },
  '6x9':     { width: 432, height: 648, inside: 63, outside: 45, top: 57.6, bottom: 57.6 }
};

function createPrintPdf(title, author, chapters, options = {}) {
  const trimSize = options.trimSize || '5.5x8.5';
  const dims = TRIM_SIZES[trimSize];
  const font = 'Times-Roman';       // PDFKit built-in (close to Garamond)
  const boldFont = 'Times-Bold';
  const italicFont = 'Times-Italic';

  const doc = new PDFDocument({
    size: [dims.width, dims.height],
    margins: { top: dims.top, bottom: dims.bottom, left: dims.inside, right: dims.outside },
    bufferPages: true,
    info: {
      Title: title,
      Author: author,
      Creator: 'Ideorix Non-Fiction Engine'
    }
  });

  const buffers = [];
  doc.on('data', chunk => buffers.push(chunk));

  let pageNum = 0;

  // --- Title Page ---
  const titleY = dims.height * 0.35;
  doc.font(boldFont).fontSize(24).text(title, dims.inside, titleY, {
    width: dims.width - dims.inside - dims.outside, align: 'center'
  });
  doc.moveDown(2);
  doc.font(font).fontSize(16).text(author, {
    width: dims.width - dims.inside - dims.outside, align: 'center'
  });

  // Blank verso after title page
  doc.addPage();

  // --- Chapters ---
  chapters.forEach((chapter, index) => {
    const heading = `Chapter ${index + 1}: ${chapter.title}`;

    // Start on recto (odd page) — add blank verso if needed
    ensureRectoPage(doc, dims);

    pageNum++;

    // Chapter drop — start ~25% down
    const dropY = dims.height * 0.25;
    doc.font(boldFont).fontSize(18).text(heading, dims.inside, dropY, {
      width: dims.width - dims.inside - dims.outside, align: 'center'
    });
    doc.moveDown(2);

    // Chapter body
    const paragraphs = chapter.content.split('\n\n');
    let isFirstAfterBreak = true;

    paragraphs.forEach(para => {
      const trimmed = para.trim();
      if (!trimmed) return;

      // Scene break
      if (trimmed === '* * *' || trimmed === '---') {
        doc.moveDown(1);
        doc.font(font).fontSize(11).text('* * *', {
          width: dims.width - dims.inside - dims.outside, align: 'center'
        });
        doc.moveDown(1);
        isFirstAfterBreak = true;
        return;
      }

      // Check if we need a new page
      if (doc.y > dims.height - dims.bottom - 50) {
        doc.addPage();
        swapMarginsForPage(doc, dims);
      }

      // Paragraph with conditional indent
      const indent = isFirstAfterBreak ? 0 : 21.6; // 0.3 inches = 21.6pt
      doc.font(font).fontSize(11).text(stripMarkdown(trimmed), {
        width: dims.width - dims.inside - dims.outside - indent,
        align: 'justify',
        indent: indent,
        lineGap: 2.3  // ~1.3 line spacing
      });

      isFirstAfterBreak = false;
    });
  });

  // --- Add running headers and page numbers ---
  const pages = doc.bufferedPageRange();
  for (let i = 2; i < pages.count; i++) {  // Skip title page and blank verso
    doc.switchToPage(i);
    const isRecto = (i % 2 === 0);  // 0-indexed: even = recto after title

    // Page number — centered footer
    doc.font(font).fontSize(9).text(
      String(i - 1),  // Page numbering starts at 1 from first chapter
      0, dims.height - dims.bottom + 20,
      { width: dims.width, align: 'center' }
    );

    // Running header
    if (i > 2) {  // No header on first chapter page
      const headerText = isRecto ? getCurrentChapterTitle(i, chapters) : title;
      doc.font(italicFont).fontSize(8).text(
        headerText,
        dims.inside, dims.top - 25,
        { width: dims.width - dims.inside - dims.outside,
          align: isRecto ? 'right' : 'left' }
      );
    }
  }

  doc.end();
  return new Promise(resolve => {
    doc.on('end', () => resolve(Buffer.concat(buffers)));
  });
}

function ensureRectoPage(doc, dims) {
  // Recto = right page = odd page number in book terms
  // In PDFKit buffered pages, we track via page count
  doc.addPage();
  const currentPage = doc.bufferedPageRange().count;
  if (currentPage % 2 === 1) {
    // We're on a verso — add one more blank page
    doc.addPage();
  }
  swapMarginsForPage(doc, dims);
}

function swapMarginsForPage(doc, dims) {
  // Alternate inside/outside margins for recto/verso
  const currentPage = doc.bufferedPageRange().count;
  const isRecto = (currentPage % 2 === 0);
  if (!isRecto) {
    doc.page.margins.left = dims.outside;
    doc.page.margins.right = dims.inside;
  } else {
    doc.page.margins.left = dims.inside;
    doc.page.margins.right = dims.outside;
  }
}

function getCurrentChapterTitle(pageIndex, chapters) {
  // Simplified — returns chapter title based on page index
  // In production, track chapter start pages during generation
  return chapters.length > 0 ? chapters[0].title : '';
}

function stripMarkdown(text) {
  return text.replace(/\*\*(.+?)\*\*/g, '$1').replace(/\*(.+?)\*/g, '$1');
}
```

## Print-on-Demand Service Notes

### KDP Print (Amazon)
- Upload interior PDF + cover PDF separately
- Bleed setting: "No bleed" for text-only interiors
- Paper: Cream or white (cream preferred for narrative non-fiction)
- Trim sizes supported: all three options above

### IngramSpark
- Same PDF requirements as KDP Print
- Additional trim sizes available (see IngramSpark docs)
- Requires ICC color profile for cover (sRGB for interior)

### Barnes & Noble Press
- Accepts PDF interior files
- Similar trim size options to KDP Print

## Delivery Notes

When delivering a print PDF, include:
- Trim size used
- Page count (for spine width calculation)
- Paper color recommendation (cream for fiction, white for non-fiction)
- Note that a cover PDF is needed separately (see `cover-designer.md`)
