---
name: true-crime-category
description: "Category plugin for True Crime non-fiction. provides structural, craft, quality, and guardrail instructions for all pipeline agents"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# True Crime. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | `true-crime` |
| Display Name | True Crime |
| Parent Group | True Crime |
| Complexity Tier | High |
| Typical Word Count | 65,000–90,000 |
| Reader Expectation | Meticulous investigative narrative that respects victims, pursues truth, and provides genuine insight into criminal behaviour and justice systems |
| Tone Baseline | Measured, respectful, investigative; journalistic rigour with narrative drive. never exploitative or sensationalist |

## Subcategory Options

When the user selects this category, prompt for a subcategory. Each subcategory adjusts structural emphasis and source expectations.

| ID | Subcategory | Focus | Typical Structure |
|----|------------|-------|-------------------|
| `single-case` | Single-Case Investigation | Deep dive into one crime or criminal case. investigation, trial, aftermath | Chronological narrative with investigative reveals |
| `serial-criminal-profile` | Serial Killer / Criminal Profile | Psychological and investigative analysis of serial offenders | Thematic-chronological hybrid with behavioural analysis |
| `wrongful-conviction` | Wrongful Conviction | Cases of miscarried justice, innocence projects, systemic failures | Parallel narrative. the crime and the injustice |
| `cold-case-unsolved` | Cold Case / Unsolved | Unresolved cases, new evidence, amateur investigation, forensic advances | Mystery-investigation structure with evidence-based speculation |
| `organised-white-collar` | Organised / White Collar Crime | Criminal enterprises, fraud, corruption, financial crime | Systems-level analysis with character-driven narrative |

### Subcategory Defaults

- If no subcategory is selected, default to `single-case`.
- If the user's brief spans multiple subcategories, select the dominant one and note secondary influences in the structural plan.

## Structural Architect Instructions

### Core Model: Narrative-Investigative Structure

True crime books must balance two imperatives: compelling storytelling and investigative integrity. Every chapter serves both.

1. **Scene**. Ground the reader in a specific moment, place, and set of characters. Use concrete sensory details drawn from verified sources.
2. **Investigation**. Walk the reader through the evidence, the process of discovery, and the reasoning that connects facts. Show your work.
3. **Context**. Situate the crime within broader systems. law enforcement practices, social conditions, psychological patterns, legal frameworks.
4. **Reflection**. Provide measured analysis. What does this case reveal? What questions remain? What has changed as a result?

### Chapter Architecture

```
Chapter [N]: [Evocative but Respectful Title]

  Opening Scene (400–700 words)
    → Specific moment rendered in vivid, factual detail
    → Establishes time, place, and key figures
    → Creates narrative tension without sensationalism

  Section 1: Background and Context (1,500–2,500 words)
    → Relevant history of the people, place, or institution
    → Social, economic, or psychological context
    → What the reader needs to understand before the central events

  Section 2: The Events (2,500–4,000 words)
    → Chronological account of key events
    → Multiple perspectives where available (investigators, witnesses, community)
    → Evidence presented as it was discovered or revealed

  Section 3: Investigation and Analysis (2,000–3,000 words)
    → Forensic, psychological, or legal analysis
    → Expert perspectives (forensic scientists, criminal psychologists, legal scholars)
    → What was missed, contested, or remains unresolved

  Section 4: Aftermath and Implications (1,000–2,000 words)
    → Impact on victims, families, and communities
    → Legal outcomes and systemic changes
    → Unresolved questions honestly stated

  Chapter Notes (100–200 words)
    → Source summary for key claims in this chapter
    → Bridge to next chapter
```

### Book-Level Arc

- **Prologue:** A single compelling scene that captures the essence of the case and the book's central question.
- **Part I (Chapters 1–3):** The crime. what happened, who was involved, initial discovery.
- **Part II (Chapters 4–7):** The investigation. evidence gathering, suspects, breakthroughs and dead ends.
- **Part III (Chapters 8–10):** The reckoning. trial, verdict, or current status; broader analysis.
- **Epilogue:** Where things stand now; reflections on justice, memory, and unresolved questions.

### Special Structural Elements

- Include a **Cast of Characters** at the front of the book with brief identifying descriptions.
- Include a **Timeline** of key events as an appendix or interleaved at part breaks.
- **Source Notes** organised by chapter at the end of the book (not footnotes. they disrupt narrative flow).
- Where relevant, include **Maps or Location Descriptions** to orient the reader geographically.

## Content Writer Craft Rules

1. **Voice:** Controlled, precise, and humane. The writer is a guide through difficult material, maintaining composure without coldness. Third person unless the author was directly involved in the investigation.
2. **Victim Dignity:** Victims are whole people, not plot devices. Introduce victims with their lives, interests, and relationships before describing their victimisation. Never reduce a person to the manner of their death or suffering.
3. **Scene Reconstruction:** Scenes must be built from verified sources. police reports, trial transcripts, interviews, documented accounts. If a scene involves reasonable inference, flag it: "Based on phone records and witness testimony, it is likely that..."
4. **Violence Policy:** Describe violence only to the degree necessary for the reader to understand what happened and its significance. Never linger on graphic details for dramatic effect. Clinical precision over visceral description.
5. **Perpetrator Treatment:** Present perpetrators as complex human beings without glamorising or excusing their actions. Avoid anti-hero framing. Do not use nicknames coined by media for shock value unless contextually necessary and critically framed.
6. **Dialogue:** Only use direct quotation marks for verified speech. from transcripts, recordings, published interviews, or consistent witness accounts. Use indirect speech for reconstructed conversations.
7. **Pacing:** True crime demands careful pace control. Slow down for critical evidence and key emotional moments. Speed through administrative or procedural passages. Never rush the human impact.
8. **Speculation Management:** Clearly distinguish between established fact, reasonable inference, and speculation. Use explicit language: "The evidence confirms..." vs. "One plausible interpretation is..." vs. "It remains unknown whether..."
9. **Legal Precision:** Use correct legal terminology. "Convicted of" not "guilty of" (unless a jury verdict is specifically referenced). "Alleged" for unproven claims. "Suspect" vs. "person of interest" vs. "defendant" used accurately.
10. **Emotional Restraint:** Trust the facts to carry emotional weight. Avoid instructing the reader how to feel. Let testimony, evidence, and consequences speak for themselves.

### PROSE RHYTHM MAPPING
- Ch 1 hook: the crime or its aftermath. URGENCY from page 1; the reader must feel this matters NOW
- Sentence length: short-medium (10-18 words) as the baseline; true crime inherits thriller rhythm for crime scenes
- High dialogue density from witnesses, investigators, and sources. real voices carry more authority than narration
- Tension ≥7 from chapter 1: crime scenes, discovery moments, and investigative breakthroughs demand sustained intensity
- Victim humanity established early. before the crime is described, the reader must know the person
- Pacing alternates between urgency (crime scenes, chases, revelations) and gravity (victim portraits, systemic analysis, aftermath)
- Scene reconstruction drives the prose: verified details rendered in cinematic present-tense immediacy
- Short paragraphs during action and discovery; longer paragraphs for context, investigation, and reflection
- Evidence integration is the spine: every claim earned by sourced detail, every source made visible to the reader
- Dialogue deployed strategically: direct quotes for key testimony; indirect speech for procedural context
- Clinical precision in violence. short, declarative sentences state what happened without lingering or sensationalising
- Investigative passages use a building rhythm: fact stacks on fact until the implication becomes unavoidable
- Reader engagement across information-dense passages: legal and forensic detail woven into narrative, never dumped in blocks
- Authority delivery through journalistic rigour: the writer earns trust by showing the chain of evidence
- The "why should I read this book" question is answered by the first scene: something happened that demands understanding
- Emotional restraint as rhythm tool: the prose stays measured so the facts can hit harder
- Pacing control: slow down for the human moments (victim's life, family impact); accelerate through procedural sequences
- Chapter endings create urgency: unanswered investigative questions, new evidence surfacing, the next lead waiting

## Quality Check Criteria

The Quality Check agent must verify the following for true crime category manuscripts:

| # | Criterion | Pass Condition |
|---|-----------|----------------|
| 1 | Factual Verification | All dates, names, locations, and case details are verifiable against official records or published reliable sources |
| 2 | Victim Dignity | Every victim is introduced as a full person before any description of their victimisation; no gratuitous or voyeuristic passages |
| 3 | Source Attribution | Every factual claim has a traceable source in the chapter notes; no unattributed assertions of fact |
| 4 | Speculation Flagging | All speculative statements are explicitly marked as inference, theory, or unconfirmed. never presented as established fact |
| 5 | Legal Accuracy | Legal terminology is used correctly; presumption of innocence is respected for uncharged or acquitted individuals |
| 6 | Violence Proportionality | Descriptions of violence serve a clear narrative or analytical purpose; no gratuitous detail beyond what is needed for comprehension |
| 7 | Perpetrator Balance | Perpetrators are not glamorised, mythologised, or given anti-hero treatment; psychological analysis is grounded in evidence |
| 8 | Dialogue Verification | All directly quoted speech is sourced to transcripts, recordings, or consistent documented accounts |
| 9 | Chronological Accuracy | Timeline of events is internally consistent and matches external records |
| 10 | Living Persons Sensitivity | Statements about living persons are factual and defensible; opinions about living persons are clearly marked as such |

## Source Requirements

### Minimum Source Thresholds

- **Per chapter:** Minimum 6 distinct sources.
- **Per book:** Minimum 50 unique sources across the manuscript.
- **Primary sources** (court records, police reports, official transcripts, direct interviews): At least 40% of total.
- **Expert sources** (forensic professionals, criminal psychologists, legal scholars): At least 15% of total.
- **Journalistic sources** (investigative reporting from reputable outlets): Acceptable for supplementary context and narrative detail.

### Acceptable Source Types

| Type | Examples | Notes |
|------|----------|-------|
| Court records | Trial transcripts, judicial opinions, sentencing documents | Preferred primary source for legal proceedings |
| Law enforcement records | Police reports, arrest records, evidence logs (where publicly available) | Subject to FOIA/open records availability |
| Official reports | Coroner/medical examiner reports, forensic lab reports, government inquiries | Required for forensic and cause-of-death claims |
| Interviews | Author-conducted interviews, published interviews in reputable outlets | Must be attributed and dated; note relationship to case |
| Academic research | Criminology journals, forensic science publications, legal reviews | Required for psychological profiles and systemic analysis |
| Investigative journalism | Long-form reporting from established outlets | Acceptable if cross-referenced; note original publication |
| Books | Previously published true crime or legal analysis by credentialed authors | For context and alternative perspectives |

### Prohibited Sources

- Wikipedia as a primary source (acceptable as a starting point for locating primary sources).
- True crime fan forums, Reddit threads, or podcast speculation as evidence for factual claims.
- Unverified social media posts attributed to persons involved in the case.
- Anonymous tips or rumours presented as fact.
- Tabloid reporting without corroboration from a reliable source.

## Category-Specific Guardrails

### Victim Treatment

- **Victims must be treated with dignity at all times.** They are the most important people in any true crime narrative.
- Introduce every victim with details about their life, personality, relationships, and aspirations before describing the crime against them.
- Use victims' names, not just their role in the crime ("the victim"). They were people first.
- Obtain or consider the wishes of victims' families regarding the portrayal of their loved ones where possible.
- Do not include crime scene photographs or gratuitously detailed descriptions of injuries.

### Factual Claims and Official Records

- All factual claims about crimes, investigations, and legal proceedings must be sourced to official records (court documents, police reports, coroner reports) or credible published accounts.
- Where official records are unavailable or sealed, state this explicitly: "Court records for this proceeding remain sealed."
- Do not present media reporting as equivalent to official records. Note when a claim comes from press coverage rather than primary documents.

### Speculation and Theory

- **All speculation must be explicitly flagged.** Use clear language: "One theory holds that..." or "Investigators considered the possibility that..." or "It remains unconfirmed whether..."
- Never present a theory about motive, method, or identity as established fact unless supported by a conviction, confession, or conclusive physical evidence.
- When presenting the author's own analysis or theory, identify it as such and provide the evidentiary basis.

### Violence and Graphic Content

- Describe acts of violence with **clinical precision** only to the extent necessary for the reader to understand the case.
- Never describe violence in a manner designed to shock, titillate, or entertain.
- Avoid detailed descriptions of suffering. State what happened; do not dwell on how it felt.
- Sexual violence must be handled with particular care. describe the legal facts without graphic physical detail.

### Legal Review Considerations

- Flag passages that make claims about living persons who have not been convicted of crimes.
- Flag passages that could be interpreted as defamatory. factual defence must be clearly established.
- Note any cases involving minors. additional sensitivity and potential legal restrictions apply.
- Consider sub judice rules if any aspect of the case is still before the courts.
- Recommend the publisher obtain a legal sensitivity read before publication.

## Cover Design Specifications

| Element | Specification |
|---------|---------------|
| Typography | Bold, high-contrast title. Serif or strong sans-serif. Title should be striking but not garish. Author name in measured weight below. |
| Colour Palette | Dark, atmospheric tones. black, deep navy, dark red, charcoal. High-contrast text (white or cream on dark). Avoid full-colour photographs or bright palettes. |
| Imagery | Abstract or symbolic. shattered glass, lone figure, empty landscape, redacted document, evidence-inspired textures. No explicit crime scene imagery. No blood splatter as decoration. |
| Layout | Title dominant, centred or offset. Subtitle should frame the case or question. "The untold story of..." or "Inside the investigation of..." formats work well. |
| Subtitle | Strongly recommended. Should name the case, location, or central question without spoiling the narrative. |
| Endorsement | One endorsement from a recognised true crime author, investigative journalist, or legal professional if available. |
| Spine | Title + Author. High contrast for shelf visibility. |
| Back Cover | 2–3 sentences of narrative hook (not a full summary), one endorsement quote, brief author bio with relevant credentials (journalism, law enforcement, legal background), barcode. |

## KDP Category Mapping

### Primary Category Path

```
Kindle Store > Kindle eBooks > Biographies & Memoirs > True Crime
```

### Secondary Category Path (select based on subcategory)

| Subcategory | Recommended Secondary KDP Category |
|------------|-------------------------------------|
| `single-case` | Biographies & Memoirs > True Crime > Murder & Mayhem |
| `serial-criminal-profile` | Biographies & Memoirs > True Crime > Serial Killers |
| `wrongful-conviction` | Biographies & Memoirs > True Crime > Law |
| `cold-case-unsolved` | Biographies & Memoirs > True Crime > Murder & Mayhem |
| `organised-white-collar` | Biographies & Memoirs > True Crime > White Collar Crime |

### Keyword Recommendations

- Use 7 keyword slots in KDP.
- Include: "true crime," case-specific term, subcategory descriptor, geographic identifier (if applicable), investigative angle, comparable author name (if applicable), justice/system term.
- Example set: `true crime`, `murder investigation`, `cold case`, `criminal psychology`, `wrongful conviction`, `forensic evidence`, `unsolved mystery`.

### BISAC Codes

| Code | Description |
|------|-------------|
| TRU000000 | TRUE CRIME / General |
| TRU002000 | TRUE CRIME / Murder / General |
| TRU004000 | TRUE CRIME / White Collar Crime |
| TRU002010 | TRUE CRIME / Murder / Serial Killers |
| TRU001000 | TRUE CRIME / Espionage |
