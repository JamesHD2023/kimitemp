---
name: bias-balance-review
description: "User-callable Bias & Balance Review. Runs Stage 10 of the editorial pipeline as a standalone tool — assess fairness of framing, representation of opposing viewpoints, transparency of author position, contextual integrity of statistics, accuracy of cultural representation."
version: "2.3.6"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Bias & Balance Review

## Purpose

Runs the Bias & Balance Review (Stage 10 of the editorial
pipeline) as a standalone, user-callable tool. Assesses the
fairness of framing in a non-fiction manuscript that covers
controversial, political, social, or contested topics —
verifying that opposing viewpoints are represented honestly, the
author's position is transparent rather than disguised as
neutrality, statistics are presented in context, and cultural
representations are accurate and respectful.

Previously runnable only as part of the full editorial pipeline
(Edit & Revise → Stage 10, conditional). v2.3.6 promotes it to a
user-callable agent so authors can run a focused framing pass
without invoking the full editorial sequence.

## When to Use

- **Manuscripts on contested or sensitive topics** — politics,
  religion, social movements, public health, gender, race,
  history with living stakeholders, science with ongoing
  debate, business with strong-opinion content
- **Before submitting** to a publisher or fact-checker
- **Before a launch** that may attract public scrutiny
- **After major revisions** that introduced new positions or
  reframed existing ones
- **When the author suspects** their own perspective may be
  bleeding into framing without acknowledgement

Direct triggers: `"Run a bias and balance review"`,
`"Bias and balance"`, `"Bias check"`, `"Balance review"`,
`"Check my framing"`, `"Is my book balanced?"`.

## Capabilities

| Capability | Behaviour |
|---|---|
| Opposing-viewpoint check | Are opposing viewpoints represented fairly? Or straw-manned? Is the strongest version of the opposing argument given a fair hearing? |
| Transparency check | Is the author's position transparent — or disguised as neutrality? Does the prose claim "objectivity" while implicitly arguing one side? |
| Marginalised perspectives | Are perspectives from affected groups included where relevant? Is their representation accurate, or filtered through outside framing? |
| Cultural representation | Are cultural representations accurate and respectful? Are stereotypes deployed unconsciously? Are sources from within the represented community cited? |
| Self-acknowledged limits | Does the book acknowledge its own limitations and biases — what it doesn't cover, what its perspective is, where the author's lens may colour interpretation? |
| Statistics in context | Are statistics presented in context, with denominators, methodology, and caveats — or cherry-picked? |
| Loaded language | Is loaded language flagged and considered? Does the prose use neutral terms or terms that prejudge the reader? |

## Input Requirements

- **Manuscript** — full draft or partial (chapter range acceptable)
- **Sensitivity rating** — set during project setup (Q-series
  question on content sensitivity, 0-5). Drives this review's
  activation under the editorial pipeline; can be invoked
  manually regardless of rating.
- **Research Bible** — `engine-data/research-bible.md`

## Output

- **Framing assessment** — per-chapter notes on framing choices
  and their implications
- **Opposing-viewpoint balance scorecard** — for each major
  contested point, was the opposing view given fair treatment?
  Score and quote samples
- **Transparency report** — passages where the author's
  position should be made more explicit, or where claimed
  neutrality reads as veiled argument
- **Statistics-in-context audit** — every statistic checked for
  contextual presentation
- **Loaded-language flags** — passages with terms that prejudge;
  alternatives suggested
- **Saved as** `engine-data/reports/bias-balance-{YYYY-MM-DD}.md`

## Routing

- **Pipeline context:** `→ See editorial-suite.md` Stage 10
  ("Bias & Balance Review") for the full editorial-pipeline
  context this stage normally runs in
- **Authority profile:** `→ See authority-builder.md` for how
  the author's voice profile is calibrated; bias review may
  surface tension between declared authority position and
  actual prose framing

## Boundaries (out of scope for v2.3.6)

- **Auto-rewrite** — the review identifies framing issues; it
  does not rewrite the manuscript. The author resolves each
  flagged item.
- **Political-stance enforcement** — the review does not push
  the author toward a particular political or ideological
  position. It checks that whatever position the author holds
  is held transparently and that opposing positions are
  represented fairly. A book can be strongly opinionated and
  still pass bias & balance, provided it doesn't disguise the
  opinion or straw-man opponents.
- **Fact verification** — for accuracy of claims see
  `fact-audit.md`. Bias & Balance assesses framing of facts
  that are otherwise correctly stated.

## Relationship to other tools

- **Fact Audit** verifies facts; **Bias & Balance** verifies
  framing of those facts. Run Fact Audit first (does the
  book say what it says correctly?), then Bias & Balance (is
  what it says framed fairly?).
- **Manuscript Clinic** runs a broader diagnostic across 6
  axes including market positioning. Bias & Balance is more
  focused — specifically the fairness-of-framing axis.
- **Authority Builder** establishes the author's voice
  profile. If the voice profile claims neutrality but the
  prose argues, Bias & Balance will surface that tension.

## When NOT to use

- Manuscripts on uncontested topics (a cookbook, a how-to
  for a tool, a reference book of historical dates) typically
  don't need this review. The editorial pipeline's
  conditional Stage 10 trigger is set this way intentionally.
- That said, the review is available on demand; if an author
  on an "uncontested" topic wants to run it (e.g. a cookbook
  with cultural cuisine the author is not from), they can.
