---
name: biography-category
description: "Category-specific instructions for biography non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Biography. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | biography |
| Display Name | Biography |
| Parent Group | Memoir & Biography |
| Typical Word Count | 90,000–180,000 (single-volume; major-figure biographies routinely run 200,000+ across multiple volumes) |
| Default Structure | Chronological through the subject's life with thematic groupings within periods; scene-anchored opening; analytical voice woven into narrative |
| Citation Style | Endnotes mandatory (Chicago Notes-Bibliography or similar); primary sources cited directly; bibliography appended; image credits where applicable |
| Audience Baseline | General reader interested in the subject; some prior awareness assumed but not specialist knowledge; readable narrative carries the research |
| Comparable Titles | Robert Caro (*The Power Broker*, *Years of Lyndon Johnson*), Walter Isaacson (*Steve Jobs*, *Einstein*, *Da Vinci*), David McCullough (*John Adams*, *Truman*), Hermione Lee (*Virginia Woolf*, *Tom Stoppard*), Stacy Schiff (*Cleopatra*, *The Witches*), Ron Chernow (*Hamilton*, *Grant*, *Washington*), Edmund Morris (*Theodore Rex*), Jung Chang (*Wild Swans*, *Mao*), Lyndall Gordon (*Charlotte Brontë*), Patrick French (*The World Is What It Is: V. S. Naipaul*) |

## Subcategory Options

When the user selects Biography, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| political-historical | Political / Historical | Leaders, statespeople, founders, monarchs, revolutionaries, military figures | Long chronological arc; era as co-protagonist; decisive-moment chapters anchored in primary records (speeches, correspondence, official acts) |
| literary-artistic | Literary / Artistic | Writers, painters, musicians, filmmakers, performers, designers | The Work as second protagonist; alternating life-and-work chapters; close engagement with the artistic output as evidence of inner life |
| business-innovator | Business / Innovator | Entrepreneurs, inventors, scientists in commerce, industry-shaping executives | Origin-to-empire arc; emphasis on decisions, deals, and pivotal failures; institutional context (companies, markets, technologies) carried alongside the personal |
| scientific-intellectual | Scientific / Intellectual | Scientists, philosophers, mathematicians, theorists, scholars | The Idea as second protagonist; intellectual development tracked alongside life events; technical material rendered accessibly |
| sports-cultural | Sports / Cultural Figure | Athletes, coaches, cultural icons, social-movement leaders, entertainers | Career-arc spine with personal-life chapters threaded; performance moments dramatised; rise-fall-redemption pattern often present |
| group-collective | Group / Collective / Family | A family dynasty, team, movement, or partnership rendered as a single biographical subject | Multiple-protagonist structure; thematic chapters covering shared events; genealogical or organisational chart in front matter; chronological with perspective-shifts |
| unauthorised-investigative | Unauthorised / Investigative | Biography written without subject's cooperation; living subject, often controversial | Investigation-as-narrative; transparency about access limits and source-class hierarchy; explicit handling of contested claims; legal review often non-optional |

**Default:** If the user does not specify, prompt for the subject's primary
identity (politician / artist / scientist / etc.) and select accordingly;
fallback to `political-historical` for unclear cases.

## Structural Architect Instructions

```
STRUCTURE
- Chronological through the subject's life, with thematic groupings within periods
- Third-party researcher perspective. the biographer brings analysis, not memory
- High evidence bar: primary sources, archives, interviews, cross-referencing
- Subject contextualised within their historical/social era

BIOGRAPHY ARCHITECTURE
- Subject rendered with DIMENSIONALITY. hagiography and hatchet jobs both fail
- Dialogue ONLY from primary documents, interviews, or contemporaneous accounts
- The biographer's thesis about the subject should be present but not distorting
- Multiple sources cross-referenced for contested events
- Historical context woven throughout. the subject doesn't exist in a vacuum

FORBIDDEN
- Invented dialogue (dialogue must be sourced)
- One-dimensional portrayal (either hagiographic or hostile)
- The subject removed from historical context
- Speculation presented as fact
- Projecting modern values onto historical figures without acknowledgement
```

## Content Writer Craft Rules

```
VOICE & TONE
- Authoritative, narrative, analytical. readable but research-grounded
- The biographer is a guide: "Here is this person. Here is what I found."
- Reads like a novel but with footnotes
- Analysis woven into narrative, not confined to separate analytical sections

PROSE RHYTHM MAPPING
- Ch 1 hook: the SUBJECT must fascinate immediately. open with a scene, not "born in 1847..."
- Scene-based opening: the reader meets the subject in a moment of action, decision, or revealing behaviour
- Sentence length: medium-long (16-24 words) as the baseline; the biographer's rhythm conveys authority and narrative sweep
- Narrative authority through specific detail. the biographer earns trust by showing mastery of the record
- Dialogue from primary sources deployed at moments of maximum impact; paraphrased speech for connective tissue
- Tension ≥4 from chapter 1. the reader must sense the subject's life contains stakes worth 300 pages
- Alternate between scene and analysis: dramatise first, then interpret; never lecture without having shown
- Pacing across information-dense passages: contextual paragraphs stay short (3-5 sentences); narrative paragraphs extend
- The subject's era must breathe through the prose. period-appropriate cadence without pastiche
- Evidence integration is the biographer's craft: sources woven into narrative, not displayed as credentials
- Reader engagement: every chapter must answer "why should I keep reading about this person?"
- Vary rhythm between the subject's public life (more formal, measured) and private life (more intimate, shorter sentences)
- Strategic use of dramatic irony: the biographer knows the ending; the reader feels it approaching
- Authority delivery: the biographer is a guide. "Here is what I found". confident but never omniscient
- Paragraph rhythm: scene paragraphs ground the reader in time and place; analytical paragraphs are crisp and purposeful
- Cross-reference density: when multiple sources confirm a detail, the prose gains weight; when sources conflict, the prose slows to acknowledge
- The "why should I read this book" question must be answered by the subject's life, not by the biographer's commentary
- Chapter endings create momentum through unanswered questions about the subject's trajectory
```

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Factual claims sourced | Every factual assertion traces to a citable source (primary document, archival record, prior scholarship, named interview); footnote density appropriate to claim density |
| 2 | Dialogue sourced | All quoted speech comes from a primary document, recorded interview, transcript, or contemporaneous account; no invented dialogue, even for narrative effect |
| 3 | Subject rendered with dimensionality | Subject portrayed with both strengths and flaws; neither hagiography (saint) nor hatchet job (villain); contradictions and complexity preserved |
| 4 | Historical context woven throughout | The era's social, political, technological, and cultural conditions shape every chapter; the subject is not a free-floating individual against a beige backdrop |
| 5 | Multiple sources on contested events | Where accounts conflict, the prose acknowledges the conflict and gives the reader enough to judge; the biographer's interpretation is offered, not asserted |
| 6 | Speculation flagged | Where the biographer is reasoning beyond the evidence, the prose signals it ("She would have known...", "It is likely..."); facts and inferences are not conflated |
| 7 | Anachronism avoided | Modern values not projected onto historical figures unannounced; where modern reckoning IS the analytical move, it is named as the biographer's framing |
| 8 | Scene-and-analysis rhythm | Chapter alternates dramatised scenes with interpretive analysis; neither pure narrative nor pure analysis dominates |
| 9 | Subject's voice present | Subject's own words (correspondence, speeches, recorded utterances, work) deployed at moments of maximum impact; the reader hears them, not only about them |
| 10 | Reader engagement sustained | Every chapter answers "why should I keep reading about this person?"; the biographer's selectivity (what is included vs cut) serves the larger narrative arc |

## Source Requirements

### Mandatory Source Types

- **Primary documents in the subject's own hand or voice.** Letters,
  diaries, journals, manuscripts, speeches, recorded interviews, emails
  (where applicable). The closer to the subject, the higher the
  evidentiary weight. A biography that does not engage substantially
  with primary sources is not a biography — it is a synthesis.
- **Archival research.** Institutional records (employment, education,
  medical where appropriately accessed, military, financial), official
  correspondence, photographs, contemporaneous newspapers, public
  registers. The archive is the biographer's laboratory.
- **Witness testimony.** Interviews with the subject (if living and
  cooperating), family, colleagues, friends, opponents. Triangulate
  systematically — different witnesses see different sides; conflict
  between accounts is data, not noise.
- **Prior scholarship.** Existing biographies, monographs, scholarly
  articles in the subject's field, era-specific historical studies.
  The biographer engages with this corpus — agreeing, refining,
  refuting — rather than ignoring or duplicating it.
- **Cultural / contextual sources.** For era texture: contemporaneous
  fiction, journalism, music, film, fashion, food, transport, weather
  records. The subject's world rendered specifically rather than via
  decade-stereotype.

### Source Freshness

- **Living subjects:** primary materials may still be in private hands;
  cooperation arrangements determine access. Authorised biographies gain
  intimacy at the cost of independence; unauthorised biographies gain
  independence at the cost of access. The bargain is the biographer's
  to make and disclose.
- **Recently deceased subjects:** estates control letter and journal
  access; cooperation typically transactional. Note in the author's
  note who granted what access on what terms.
- **Historical subjects:** archive access is the limiter rather than
  cooperation. New finds (newly opened archives, recently surfaced
  letters, declassified records) refresh the field; the biographer
  should locate their work relative to those finds.
- **Replication-style validation:** where prior biographies advanced
  contested interpretive claims, the new biographer revisits the source
  base rather than restating prior conclusions. Independent return to
  primary sources is the field's freshness test.

### Attribution Standards

- **Every factual assertion is footnoted.** Endnotes (Chicago Notes-
  Bibliography or equivalent) are the genre's evidentiary backbone.
  Note density should match claim density; a chapter making many
  claims should have many notes.
- **Quotation precision.** Quoted text reproduces the source exactly
  (with bracketed editorial insertions where needed for sense or
  context). Silent rewriting of source quotation is unacceptable.
- **Source-class hierarchy in prose.** "Caro records..." (synthesis
  citation), "In a letter to Eisenhower dated 12 March 1944..."
  (primary source), "His daughter recalled in 1987..." (memory-based
  testimony). Each register signals the evidence's nature; conflating
  them obscures the analytical chain.
- **What is NOT acceptable.** Inventing dialogue. Inventing scenes
  unsourced by primary record. Presenting interpretive speculation as
  established fact. Citing without checking the original. Quoting
  selectively to misrepresent the source's thrust.

## Category-Specific Guardrails

### MANDATORY. Sourced Dialogue (no invention, ever)

- Every quoted utterance in the biography must trace to a primary
  document, recorded interview, contemporaneous transcript, or witness
  account. Invented dialogue is a genre-defining failure: biography
  derives its authority from the difference between recorded and
  reconstructed speech.
- Where the historical record contains paraphrased speech ("She is
  reported to have said...", "Friends recall him remarking..."), render
  it as paraphrase rather than direct quotation.
- Where dialogue is missing entirely from the record, the biographer
  may dramatise the situation in narration but must NOT supply quoted
  speech the subject did not demonstrably say.

### MANDATORY. Dimensionality (no hagiography, no hatchet job)

- Subjects are rendered as full human beings: strengths AND flaws, the
  acts that earned admiration AND those that warrant judgement. The
  reader should be able to argue with the biographer's overall reading
  on the basis of evidence the biographer has fairly presented.
- Hagiography (uncritical celebration) and hatchet job (uncritical
  prosecution) both fail the genre. They are easier than fair
  assessment; they are not biography.
- Where the biographer has a clear thesis about the subject (e.g.
  Caro's reading of LBJ, Chernow's reading of Hamilton), the thesis
  is named and its evidence-base demonstrated, not smuggled in via
  selective inclusion.

### MANDATORY. Legal and Ethical Considerations

- **Defamation (living or recent subjects).** Statements of fact about
  identifiable people that damage reputation must be defensible — true,
  fairly framed opinion, or fair comment on matters of public interest.
  Borderline content needs legal review prior to publication; this is
  particularly acute for unauthorised biographies of living subjects.
- **Privacy.** Some material may be defensibly true but legally or
  ethically constrained — medical records, sealed court documents,
  third-party private correspondence not authorised for publication.
  The biographer's right to know is not always the public's right to
  read.
- **Estate and source agreements.** Letters and unpublished writings
  remain subject to copyright (typically 70 years post-mortem). Quoting
  beyond fair-use bounds requires permission from the estate; this can
  shape what the biographer can or cannot include.
- **Subject cooperation terms.** Authorised biographies often involve
  agreements about access, review, or veto. These agreements must be
  disclosed to the reader (typically in the author's note) so the
  reader can calibrate the biography's independence.

### MANDATORY. Historical Context (no anachronism without acknowledgement)

- Subjects must be situated in their era's social, political,
  intellectual, and material conditions. A 1780s subject judged by
  2020s standards without acknowledging the analytical move
  produces bad biography.
- Where the modern reckoning IS the analytical move (e.g. revisiting
  a celebrated figure's complicity in colonialism, racism, abuse), the
  biographer NAMES the framing as a deliberate present-day reading
  of past evidence, rather than implying the subject had access to
  twenty-first-century moral vocabulary.
- Period-specific institutions, vocabulary, technology, social codes
  must be understood by the biographer well enough to render
  accurately, not borrowed wholesale from later history.

### Additional Guardrails

- **Speculation flagged in prose.** Where the biographer is reasoning
  beyond what the evidence directly supports, the prose signals it:
  "She would have known...", "It is probable that...", "The evidence
  suggests, but does not prove..." The reader can then weight the
  inference appropriately.
- **The Subject's voice present.** A biography in which the reader
  never hears the subject directly — through correspondence, recorded
  speech, the subject's own work — is biography reduced to summary.
  Deploy the subject's voice at moments of maximum interpretive weight.
- **Selectivity is a craft choice.** Biography is not transcript. The
  biographer chooses what to include and what to compress; selection
  serves the larger analytical arc. Dump-everything completeness is a
  sign of analytical failure, not rigour.
- **Era-cadence without pastiche.** The prose may take on era-
  appropriate rhythm (slightly more formal for a 19th-century subject,
  contemporary for a 21st-century one) without lapsing into
  stylistic costume drama.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Dignified and weighty for major-figure / political
  / historical biography (navy, black, deep red, charcoal, often with
  gold or silver typographic accents). Warmer / more textural palettes
  for literary, artistic, and cultural-figure biography (cream, sepia,
  faded photograph tones). Stark monochrome for investigative and
  unauthorised work where the cover should signal seriousness over
  warmth.
- **Typography:** Classical serif (Garamond, Caslon, Bodoni) is the
  default — biography trades on authority, and the typography
  underwrites it. Slab serif or condensed serif for bolder
  contemporary positioning. Sans-serif rare; reserved for sports /
  cultural-figure biography aimed at general-audience accessibility.
- **Imagery:** Three dominant traditions:
  1. **Subject portrait** — the most common form; archival photograph,
     commissioned painting, or carefully framed iconic image. The
     subject's face IS the cover.
  2. **Subject's world** — for collective biography, scientific /
     intellectual biography, or where the subject's image is unavailable
     or overexposed: a defining object, place, or symbol from the
     subject's life.
  3. **Period imagery** — for historical biography where the subject's
     era is itself the draw: a period setting, document, or composition.
- **Mood:** Authority and intimacy in tension. The cover should signal
  "this is a substantial work of research" while inviting the reader
  into the subject's life. Glossy / commercial styling that implies
  light reading typically undersells the work.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Political / Historical | Portrait or iconic image; deep palette; large name typography; subtitle clarifies the period or angle |
| Literary / Artistic | Subject portrait (often less formal — candid or working) OR symbolic object from the subject's practice; warmer palette; serif typography with literary weight |
| Business / Innovator | Subject portrait (commissioned-headshot tradition or working-environment image); confident typography; subtitle emphasises the innovation or sector |
| Scientific / Intellectual | Subject portrait OR signature object (instrument, equation, manuscript page); restrained palette; typography emphasises clarity over decoration |
| Sports / Cultural Figure | Action image OR iconic portrait; bolder palette and typography for general-audience reach; cover may flirt with commercial styling |
| Group / Collective / Family | Group portrait (historic photograph) OR symbolic object representing the collective; longer subtitle or front-cover blurb to clarify the group identity |
| Unauthorised / Investigative | Often deliberately stark — high-contrast portrait, subtitle that signals the angle ("The Untold Story", "Behind the Public Face"); design works hard to look serious rather than tabloid |

### Typography Rules

- **Title:** Often the subject's name alone, or a short evocative phrase
  + the name. For multi-volume or definitive works, the title can
  carry weight ("The Power Broker", "The Rest Is Noise"); for
  competitive market positioning, the subject's name large and direct
  is the safe play.
- **Subtitle:** Does the descriptive work — period, angle, scope. "A
  Life", "A Biography", "The Years of Lyndon Johnson Vol. III",
  "Founding Father", "The Untold Story". Subtitles in biography can
  be longer than other categories without penalty.
- **Author name:** Smaller than subject name as a default; larger only
  for authors whose name itself sells (Caro, McCullough, Isaacson,
  Chernow). For debut biographers, credentials in the subtitle or
  back-cover blurb carry more weight than name-size on the front.
- **Spine and back cover:** Spine carries title + subject name + author;
  back cover prioritises endorsements from named scholars or prior
  biographers in the field, then descriptive blurb, then publisher
  apparatus. Image of subject often repeats on the back jacket flap
  alongside author bio.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Political / Historical | Kindle Store > Kindle eBooks > Biographies & Memoirs > Historical (or > Leaders & Notable People > Political) |
| Literary / Artistic | Kindle Store > Kindle eBooks > Biographies & Memoirs > Arts & Literature (with sub-genre Authors / Artists / Composers / Performing Arts) |
| Business / Innovator | Kindle Store > Kindle eBooks > Biographies & Memoirs > Business (and / or > Professionals & Academics > Business) |
| Scientific / Intellectual | Kindle Store > Kindle eBooks > Biographies & Memoirs > Professionals & Academics > Scientists |
| Sports / Cultural Figure | Kindle Store > Kindle eBooks > Biographies & Memoirs > Sports & Outdoors (or > Arts & Literature for cultural figures) |
| Group / Collective / Family | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups (matching the collective's identity) |
| Unauthorised / Investigative | Kindle Store > Kindle eBooks > Biographies & Memoirs > Leaders & Notable People (with Politics & Social Sciences > Specific Topics secondary) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Period or place | Kindle Store > Kindle eBooks > History > (specific era / region / country) |
| Subject's profession or domain | Kindle Store > Kindle eBooks > (Business / Politics / Arts / Science / Sports / Religion) > (specific sub-domain) |
| Women's biographies | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > Women |
| LGBTQ+ biographies | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > LGBTQ+ |
| Cultural / ethnic biographies | Kindle Store > Kindle eBooks > Biographies & Memoirs > Ethnic & National (specific origin) |
| Royalty / monarchy | Kindle Store > Kindle eBooks > Biographies & Memoirs > Historical > Royalty |
| Military leaders | Kindle Store > Kindle eBooks > Biographies & Memoirs > Military Leaders (or History > Military > Specific Conflict) |

### Keyword Recommendations

- The subject's full name (and any well-known shortenings) — high
  intent and primary discoverability driver
- Era and geography compounds
  ("Tudor England biography", "Victorian London", "20th century American")
- Domain or profession compounds
  ("political biography", "scientific biography", "literary biography")
- Movement, party, or institutional context
  (Reformation, civil rights, Bauhaus, Bell Labs, Federalist Party)
- Comparable biographer names for discoverability
  (readers of Caro, readers of McCullough, readers of Chernow)
- The biography's analytical angle or thesis
  ("revisionist", "definitive", "intimate", "first authorised",
  "newly discovered letters")
- Avoid generic "life of" terms — they drown in algorithmic noise;
  prefer the subject's name + a specific framing word
