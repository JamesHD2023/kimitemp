---
name: political-commentary-category
description: "Category-specific instructions for political and social commentary non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Political / Social Commentary. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | political-commentary |
| Display Name | Political / Social Commentary |
| Parent Group | Politics & Social Sciences |
| Typical Word Count | 60,000–110,000 (polemic / advocacy titles often 50,000–80,000; comprehensive policy or institutional analysis 80,000–130,000; international-affairs / geopolitics 100,000–150,000) |
| Default Structure | Argument-driven: thesis stated early, each chapter a supporting pillar of the overall argument; evidence integration (data + reporting + case study + lived experience) per chapter; counter-argument engagement substantive; conclusion offers practical implications and actionable pathways |
| Citation Style | Endnotes mandatory; named-source attribution for interviews and contested claims; primary documents (policy texts, legislation, court filings, regulatory documents) cited where claims depend on them; statistical claims sourced with dates and methodology where available; bibliography appended; the book's evidence base must be inspectable by readers who want to verify |
| Audience Baseline | Politically-engaged adult reader; varies sharply by mode — fellow-traveller readers (rallying / informing one's own side, polemic / advocacy register) vs. persuadable / heterodox readers (analysis-led, fairness-to-opposed-positions register); audience and mode named explicitly so reader self-selects |
| Comparable Titles | Ta-Nehisi Coates (*Between the World and Me*, *We Were Eight Years in Power*), Naomi Klein (*This Changes Everything*, *Doppelganger*), Anne Applebaum (*Twilight of Democracy*, *Autocracy, Inc.*), Adam Tooze (*Crashed*, *Shutdown*), Ezra Klein (*Why We're Polarized*), Anand Giridharadas (*Winners Take All*), Heather McGhee (*The Sum of Us*), Mehrsa Baradaran (*The Color of Money*), Jane Mayer (*Dark Money*), Michael Sandel (*The Tyranny of Merit*), George Packer (*The Unwinding*, *Last Best Hope*), Francis Fukuyama (*Identity*, *Liberalism and Its Discontents*), Yuval Levin (*A Time to Build*), Patrick Deneen (*Why Liberalism Failed*), Ross Douthat (*The Decadent Society*), John McWhorter (*Woke Racism*), Coleman Hughes (*The End of Race Politics*), Steven Levitsky & Daniel Ziblatt (*How Democracies Die*), Timothy Snyder (*On Tyranny*) |

## Subcategory Options

When the user selects Political / Social Commentary, prompt for subcategory
refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| current-affairs-political-analysis | Current Affairs / Political Analysis | Broad analysis of the contemporary political moment, era, or trend; the Packer / Klein-E / Applebaum / Fukuyama lineage of considered current-affairs commentary | Theme-or-question-led structure across the contemporary moment; data + reporting + analysis blend; named figures and events as recurring cast; broader historical / structural context; audience: politically-engaged general reader |
| political-polemic-advocacy | Political Polemic / Advocacy | Argument-driven advocacy for a specific political position, framework, or cause; the Coates / Klein-N-polemics / Deneen / Hughes lineage; the book's position is the book | Thesis-led structure with each chapter advancing the central argument; counter-arguments engaged in service of the thesis; rhetorical pacing prominent; mobilising-the-base or persuading-the-undecided as primary mode |
| social-justice-equity | Social Justice / Equity / Inequality | Systemic-inequality analysis — race, class, gender, sexuality, disability — examining structures and remedies; the Coates-on-race / McGhee / Baradaran / McWhorter / Hughes lineage spanning left-and-heterodox positions on these issues | Structural-pattern chapter spine; data on disparate outcomes + named-community case studies + institutional / historical analysis; affected-community voices central; remedies discussed alongside problems |
| policy-governance | Policy & Governance | Analysis of specific policies, their effects, and alternatives; the Tooze / Sandel / Klein-E-on-policy / Klinenberg / Levin lineage of policy-anchored work | Policy-domain chapter spine (housing / education / healthcare / financial / environmental / immigration / etc.); historical-context-then-current-state-then-alternatives rhythm; institutional and economic analysis; technical content accessible |
| media-information-power | Media / Information / Platform Power | Analysis of media systems, information ecosystems, propaganda, platform power, the attention economy — how information shapes politics | Media-or-platform-or-mechanism chapter spine; case studies of specific phenomena; information-economic and political-economic analysis combined; affected-community / silenced-perspectives content; current-state-of-the-field tends to date fast |
| democracy-institutions | Democracy / Institutions / Authoritarianism | Focus on democratic systems and their health — institutions, norms, threats, repair; the Levitsky-Ziblatt / Applebaum / Snyder / Mounk lineage | Institution-or-norm chapter spine; historical and comparative cases; current-warning-signs analysis; institutional-design content; audience often the engaged-democratic citizen |
| global-international-affairs | Global / International Affairs / Geopolitics | Analysis of foreign policy, international order, geopolitics, specific regional dynamics; the Tooze-on-international-economy / Mearsheimer / Walt / Fukuyama-on-international lineage | Region-or-crisis chapter spine, or thematic-question across regions; primary-documentation engagement; named scholars and current debate engaged; audience: international-affairs-engaged general reader |

**Default:** If the user does not specify, prompt for the book's mode
(broad current-affairs / specific-position polemic / inequality-focused
/ policy-anchored / media-focused / democracy-focused / international-
focused) and select accordingly; fallback to
`current-affairs-political-analysis` for unclear cases.

## Structural Architect Instructions

```
STRUCTURE
- Argument-driven: thesis stated early, each chapter a supporting pillar
- Evidence blends: data, reporting, case studies, lived experience, expert analysis
- Counter-arguments engaged substantively (not straw-manned)
- Call to action in conclusion (what should change, what the reader can do)

BEATS PER CHAPTER
1. Thesis Beat. the chapter's central claim, clearly stated
2. Evidence Beat. data, reporting, or case study supporting the claim
3. Human Beat. a specific person or community affected by the issue
4. Counter-Argument Beat. the strongest opposing view, fairly presented
5. Synthesis Beat. what the evidence means, how it connects to the book's thesis

CATEGORY ARCHITECTURE
- The author's position must be TRANSPARENT. not disguised as neutrality
- Every chapter must advance the overall argument
- Data and personal narrative must complement each other (neither alone is sufficient)
- The strongest version of opposing arguments must be engaged with
- Practical implications: what does this analysis mean for policy/society/individuals?

FORBIDDEN
- Straw-manning opposing views (present the strongest version, then respond)
- Cherry-picked statistics without context
- Ad hominem attacks substituting for argument
- Claiming neutrality while advocating a position
- Using marginalised communities as props without their voices
- Catastrophising without actionable pathways
```

## Content Writer Craft Rules

```
VOICE & TONE
- Passionate but disciplined. conviction backed by evidence
- The reader should feel the author cares deeply AND has done the research
- Vary between analytical passages (data, policy) and human passages (stories, impact)
- Righteous anger is permitted; unsubstantiated rage is not

EVIDENCE STANDARDS
- Statistics from reputable sources with dates and methodology notes
- Policy analysis from official documents, legislative records, expert testimony
- Lived experience from interviews or documented accounts (attributed)
- Historical context from scholarly sources

PROSE RHYTHM MAPPING
- Ch 1 hook: the argument, sharp and clear. the author's position stated with precision and conviction from paragraph one
- Sentence length: short-medium declarative (12-20 words) as the baseline; commentary prose is punchy, opinionated, and direct
- The author's VOICE is the hook. opinionated, precise, provocative; the reader stays because this mind is worth arguing with
- Tension ≥5 from chapter 1. intellectual tension: the reader must feel that something important is at stake and the author has something urgent to say
- Short declarative sentences for core claims; longer sentences for evidence, context, and nuanced qualification
- Deploy data and statistics at moments of maximum rhetorical impact. a number that makes the argument undeniable
- Alternate between analytical passages (data, policy, systemic analysis) and human passages (stories, lived impact, specific people affected)
- Evidence integration is disciplined: every assertion backed by sourced data, every statistic contextualised, every claim defensible
- Pacing across information-dense passages: policy detail and institutional analysis stay concise; human stories breathe and extend
- The "why should I read this book" question is answered by the argument itself: "This is happening, it matters, and here is why"
- Reader engagement: the author's conviction is contagious; righteous anger is permitted, unsubstantiated rage is not
- Counter-argument engagement as rhythm tool: present the strongest opposing view (slower, more measured prose), then dismantle it (shorter, sharper sentences)
- Paragraph rhythm: claim paragraphs are tight and declarative; evidence paragraphs are detailed and sourced; human-impact paragraphs are narrative and immersive
- Authority delivery through transparency: the author's ideological position is visible, not disguised as neutrality
- Vary tone between chapters: analysis, polemic, reportage, personal testimony. but the voice remains consistent and recognisable
- Solutions and actionable pathways earn their pages: the reader must leave each chapter knowing what could change, not just what is wrong
- The strongest passages alternate between making the reader think and making the reader feel. neither alone sustains a book
- Chapter endings: the argument advances, the stakes escalate, the next dimension of the issue awaits
```

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Thesis clearly stated and consistently advanced | The book's central thesis is articulated early (front matter or introduction) and each chapter visibly contributes to its argument; chapters that wander from the thesis or repeat earlier chapters' arguments without development drag the overall work |
| 2 | Empirical claims sourced and current | Statistical / factual claims trace to named sources with dates and (where applicable) methodology; sources are recent enough that the claim still holds; superseded data is not perpetuated as current |
| 3 | Statistics not cherry-picked or decontextualised | Where the book cites a specific figure, the surrounding context (denominator, comparison, trend, methodology limits) is acknowledged; selective citation that misrepresents the underlying data is the category's most-criticised failure |
| 4 | Counter-arguments engaged in their strongest form | Opposing positions are presented as their adherents would recognise them, then responded to (the steel-man, not the straw-man); books that only engage with weak versions of opposing views fail the persuadable / heterodox reader |
| 5 | Argument distinguished from opinion distinguished from analysis | Argumentative claims (the book's thesis) framed as such; opinion (the author's view, beyond what evidence settles) named as opinion; analytical claims (where the evidence leads) framed with appropriate certainty and uncertainty; conflating the registers obscures the argument |
| 6 | Author's ideological position transparent | The author's political position, partisan affiliation, ideological commitments are visible to the reader rather than disguised as neutrality; the false-balance / "view from nowhere" framing is itself a position and is named where used |
| 7 | Affected-community voices present | Where the book makes claims about specific communities, identity groups, or marginalised populations, voices from inside those groups are inputs alongside the author's analysis; "nothing about us without us" applies; tokenism (one quote per affected community) is not adequate |
| 8 | Solutions / actionable pathways included | Pure critique without alternative is insufficient for the genre's contract with the reader; the book offers specific policy proposals, structural alternatives, or actionable individual / collective pathways; "we should do better" without specifying how is unsatisfying |
| 9 | Catastrophising avoided where evidence does not warrant it | Where the book argues for serious threat / harm / decline, the argument is calibrated to the evidence; doom-loop framings without agency are themselves a misrepresentation of complex situations; hope-and-agency framings without honest engagement with severity are also a misrepresentation |
| 10 | Date and context of writing visible | Political commentary dates fast; the moment of writing is part of the meaning; the book carries explicit dating ("written in [year]", "before / after [event]", "as of [moment]") so readers in later years can place the analysis correctly |

## Source Requirements

### Mandatory Source Types

- **Primary government / institutional documents.** Legislation,
  regulations, court filings and decisions, congressional /
  parliamentary hearing transcripts, executive orders, regulatory
  agency reports, treaty texts, official statistics from
  authoritative bodies (Census Bureau, ONS, Eurostat, OECD,
  IMF, World Bank). The evidentiary backbone for empirical
  political claims; primary documents preferred over summary
  reporting for consequential claims.
- **Peer-reviewed academic research.** Political science,
  economics, sociology, public policy, history, area-studies
  scholarship cited by named scholars in named venues.
  "Research shows..." without citation unacceptable;
  named-scholar attribution and venue (journal / press)
  expected.
- **Reputable journalism.** Named-author reporting from
  established outlets across ideological positioning (NYT,
  WaPo, WSJ, FT, The Atlantic, The New Yorker, ProPublica,
  The Economist, Reuters, AP for foundational reporting; Pro
  Publica, ICIJ, BBC for investigative; Foreign Affairs for
  international); engaging with reporting that may be
  ideologically uncomfortable for the book's position is part
  of the job. Aggregator-and-summary sites (the AllSides /
  Ground / News-aggregator class) verified against original
  reporting.
- **Statistical and survey data with methodology.** Polling
  data with methodology and date (Pew, Gallup, ANES, GSS,
  YouGov, Ipsos, country-specific equivalents); economic
  data with source and date; survey data with sample, dates,
  margin-of-error, and question wording where relevant.
  Polling without methodology disclosure is suspect.
- **Affected-community voices and direct testimony.** For
  claims about specific communities — racial / ethnic
  minorities, immigrant communities, LGBT+ communities,
  disabled people, working-class communities, religious
  minorities, regional / rural populations — voices from
  inside those communities are inputs alongside outside-
  scholar analysis. Named representatives (community
  organisations, scholars from the community, individual
  voices with consent) cited.
- **Opposing-side scholarship and reporting.** A book taking
  position X engages with the strongest scholarship and
  reporting from position Y rather than only with weakest
  representatives of position Y. This protects the book
  against accusations of straw-man engagement and is a
  signature mark of rigorous commentary.

### Source Freshness — POLITICAL COMMENTARY DATES FAST

Political commentary is alongside technology as one of the
highest-currency-sensitivity NF categories. The book must
engage with this honestly:

- **Date the analysis explicitly.** Front matter notes when
  the manuscript was completed and through what date events
  are covered; "as of [date]" framing where the political
  state of play is the subject; data cited with year of
  collection / publication.
- **Specific events and moments dated.** "Following the
  2020 election...", "After the Dobbs decision in June
  2022...", "In the wake of the October 2023 Hamas attacks
  on Israel...". Specific events are time-anchored so the
  reader can place the analysis.
- **Polling and survey data dated and methodology-noted.**
  "A March 2024 Pew survey of 1,500 US adults...". Polling
  ages fast; using a 2018 poll to characterise current
  opinion is a methodological error.
- **Policy positions and figures evolve.** A book describing
  "the current Republican / Democratic / Labour / Conservative
  Party position on X" should specify the moment; positions
  shift, particularly across leadership transitions and
  electoral cycles.
- **International situations evolve.** Books on Russia /
  Ukraine, China, Middle East, climate, AI policy require
  particularly careful dating; situations shift weekly to
  monthly.
- **Foundational works hold up better.** Books making
  structural arguments about democracy, capitalism,
  inequality, identity, foreign-policy frameworks (Sandel,
  Fukuyama-on-history, Klein on shock-doctrine, Tooze
  structural-economic) age more gracefully than books
  capturing a particular political moment.
- **Re-issued editions warrant new framing.** Where the book
  is re-issued years later, an updated introduction or
  framing material acknowledges what has changed since;
  political commentary's reception arc is part of its
  meaning.

### Attribution Standards

- **Empirical claims sourced.** "Studies show..." / "the data
  reveals..." / "polls indicate..." unacceptable without
  citation; named source with date is the standard.
- **Distinguish: fact / claim / argument / opinion.** "X
  occurred on [date]" (fact, sourced). "[Source] argues that
  X..." (claim, attributed). "I argue that X means Y..."
  (the author's argument, framed as such). "I find this
  troubling because..." (opinion, named). Each register has
  different evidentiary standards; conflating them is
  unacceptable.
- **Quote attribution precise.** Quotes from interviews
  attributed by named source where consented; off-the-record
  material flagged; quotes from public speeches / writings
  attributed with venue and date; quotes accurate (no silent
  ellipsis-distortion of meaning).
- **Author positionality and funding disclosed.** Front
  matter discloses: the author's political affiliations or
  party membership where relevant; current and recent
  employment by political organisations, advocacy groups,
  think tanks, or government; funding sources for the book
  or the underlying research; commercial relationships with
  subjects discussed. The reader is entitled to calibrate.
- **What is NOT acceptable.** Inventing statistics. Citation
  laundering through aggregators. Treating partisan-press
  framings as established fact. Quoting opponents
  selectively to misrepresent their position. Failing to
  disclose substantial commercial or political relationships
  with the parties / movements / figures discussed.
  Presenting the author's preferred policy outcome as
  consensus-supported when scholarship is contested.

## Category-Specific Guardrails

### MANDATORY. Author's Position Transparent (no false neutrality)

- Political commentary is genre-defined by its argumentative
  character. The author's position is the book; pretending to
  neutrality where the book actually advocates is dishonest.
- Specific requirements:
  - **Position stated early.** The author's argument, framework,
    or political commitment is articulated in the introduction
    or front matter; readers know what kind of argument they
    are entering.
  - **Partisan affiliation disclosed where relevant.** Current
    or recent party membership, employment by political
    organisations, advocacy roles, government service, think-
    tank affiliations are disclosed in author's note or
    front matter.
  - **Funding sources disclosed.** Where the book or its
    underlying research has been funded by political donors,
    advocacy groups, foundations with declared political
    orientations, this is disclosed; readers calibrate
    accordingly.
  - **Commercial relationships disclosed.** Where the author
    has commercial relationships with subjects of the book
    (advisory roles, consulting, equity, paid speaking
    engagements with related parties), disclosed.
- The "view from nowhere" framing — claims of neutral
  expertise that mask substantive ideological commitments —
  is itself a position; books that adopt it without
  disclosure fail current standards for honest commentary.

### MANDATORY. Steel-Man Engagement with Opposed Positions

- Counter-arguments are presented in their strongest form,
  as their adherents would recognise them, before being
  responded to. The straw-man engagement (engaging only with
  the weakest version of the opposing argument) is the
  category's most-criticised intellectual failure and
  alienates persuadable readers.
- Specific requirements:
  - **Best opposing-side scholarship cited.** A book arguing
    position X engages with the strongest published scholarship
    and reporting from position Y (named scholars, named
    works); not just with op-eds, social media, or fringe
    representatives of position Y.
  - **Opposing arguments stated as advocates would.**
    Position-Y advocates reading the book's account of their
    position should recognise their own argument; substantive
    distortion of opposing views is intellectual cheating.
  - **Internal heterogeneity within opposing positions
    acknowledged.** "Conservatives believe..." / "Progressives
    argue..." flatten coalitions with substantial internal
    debate; the book engages with the specific position it
    is opposing rather than with a flattened opposition.
  - **Disagreement honestly named.** Where the book disagrees,
    it disagrees on substantive grounds with arguments the
    opponent would recognise; mockery, dismissal, "anyone
    who believes this is..." framings are rhetorical victories
    that cost the persuasive purchase the book seeks.
- Steel-man engagement applies regardless of the book's
  political position. Left-leaning books engage with serious
  conservative thought; right-leaning books engage with
  serious progressive thought; centrist or heterodox books
  engage with serious positions across the spectrum.

### MANDATORY. Empirical Rigour on Contested Claims

- Where the book makes empirical claims about politically
  contested matters, the claims trace to peer-reviewed
  scholarship, primary documentation, or named-author
  reporting from authoritative outlets. Specific patterns to
  observe:
  - **Statistics sourced and contextualised.** Specific figure
    + source + date + methodology where applicable; surrounding
    context (denominator, comparison, trend, methodology
    limits) acknowledged where it shapes interpretation.
  - **Cherry-picking avoided.** Where the book selects a
    striking figure, the broader picture is acknowledged; a
    book that builds an argument from extreme cases without
    acknowledging how representative they are misleads.
  - **Disputed empirical claims framed as such.** Where the
    underlying evidence is contested (e.g. specific policy-
    effect claims, contested causal stories, contested
    historical interpretations), the dispute is acknowledged
    rather than the author's preferred answer asserted as
    settled.
  - **Distinguish empirical claim from value claim.** "Crime
    rates have fallen 30% over the last decade" (empirical,
    sourced). "These crime rates are still unacceptably
    high" (value, the author's judgement). Conflating them
    is a common move that obscures the analytical chain.
- The category's political character makes empirical rigour
  more rather than less important; readers across positions
  recognise sloppy sourcing.

### MANDATORY. Treatment of Marginalised Perspectives

- Where the book discusses specific identity groups, marginalised
  communities, or contested-identity matters:
  - **Voices from inside the relevant community are inputs.**
    Not just outside-scholarly analysis of the community.
    Community organisations, community-internal scholars,
    individual voices with consent.
  - **Heterogeneity within communities acknowledged.** No
    community is monolithic; "what Black Americans think
    about..." / "what working-class Britons believe about..."
    framings flatten diverse coalitions and make the book
    less credible to community members.
  - **Community-internal disagreement engaged with.** Where
    the community itself contains substantive disagreement
    on the topic the book discusses, the disagreement is
    represented; using one position from inside the community
    as if it were the consensus position is a form of
    selection bias.
  - **Identity-categories used per current community
    preference.** Identity-first vs person-first language,
    capitalisation conventions, terminology preferences vary
    by community; current best practice respects community
    preference rather than imposing the author's framing.
- The "we / they" framing where "they" is a marginalised
  community discussed by an outside-the-community author is
  a persistent failure mode; books written from outside a
  community handle this with care.

### MANDATORY. Awareness of Commentary-Industry Incentive Structures

- Political commentary exists in a media ecosystem with
  documented incentive structures that shape what gets
  written and what gets attention:
  - **Engagement-driven content.** Hot takes, outrage cycles,
    and contrarian-for-contrarian's-sake framings drive
    short-term engagement; the book distinguishes itself from
    this register or acknowledges where it participates in it.
  - **Partisan-press ecosystems.** Outlets across the
    spectrum have known editorial slants; the book's
    sourcing reflects awareness of slant rather than treating
    one outlet's framing as neutral.
  - **Think-tank funding patterns.** Many think tanks have
    documented funding sources that align with their
    positions; the book that cites think-tank research
    acknowledges this where relevant.
  - **Talking-heads / pundit class self-interest.** The
    commentary industry includes figures whose career depends
    on partisan / contrarian / inflammatory positioning; the
    book engages with arguments rather than with personalities
    where possible, and notes where commentary serves career
    interests.
- The book aims at considered analysis rather than
  participation in the engagement-and-controversy cycle; this
  is reflected in pacing (slower than hot-take), evidence
  density (higher than column-length permits), and counter-
  argument engagement (more substantial than punditry permits).

### MANDATORY. Currency Disclosure (political commentary dates fast)

- Political commentary is alongside technology as one of the
  highest-currency-sensitivity NF categories. The book engages
  with this:
  - Front matter notes when the analysis was completed and
    through what events / data the book is current.
  - Specific events / figures / data are time-anchored so
    later readers can place the analysis.
  - Forward-looking claims framed as scoped predictions
    ("over the next 18-24 months", "through the next
    electoral cycle") rather than open-ended prophecy.
  - The book's argument distinguishes time-bound elements
    (specific party positions, current polling, current
    legislative state) from durable elements (structural
    arguments, historical interpretation, framework claims).
  - Re-issued editions warrant updated framing acknowledging
    what has changed.

### Additional Guardrails

- **Solutions / actionable pathways included.** Pure critique
  without alternative is insufficient for the genre's contract
  with the reader. The book offers specific policy proposals,
  structural alternatives, or actionable individual /
  collective pathways. "We should do better" without specifying
  how is unsatisfying; "the system is broken" without engaging
  with how it might be repaired or replaced is dismissive.
- **Catastrophising and false-balance both avoided.** The
  category's two failure modes are doom-loop framings that
  imply nothing matters or nothing can be done, AND false-
  balance framings that treat empirically settled questions
  as contested. The book navigates between these by treating
  consensus as consensus, uncertainty as uncertainty, and
  agency as real where it exists.
- **Names handled with fairness.** Where specific living
  political figures are discussed, defamation considerations
  apply (claims of fact must be defensible); fairness to the
  figure's actual record (not just the author's preferred
  interpretation) is the standard; where the figure has
  contested versions of events, the contest is acknowledged.
- **Hot-button-issue handling.** For currently-contested
  social issues (abortion, immigration, race, gender, gun
  policy, religion-in-public-life), the book takes its
  position but engages with the strongest opposing argument;
  the goal is persuasion or honest disagreement rather than
  rhetorical victory.
- **Author's positionality on identity claims.** Where the
  author writes about identity-categories not their own,
  consultation, awareness of limits, and humility are
  expected; expertise is not transferable across all
  identity-experience boundaries.
- **No incitement / dehumanisation.** Books across the
  political spectrum can engage with sharp disagreement
  without dehumanising opponents; framings that imply
  opponents are subhuman, inherently malicious, or beyond
  legitimate political engagement are not consistent with
  the genre's conventions for considered work.

## Cover Design Specifications

### Visual Language

- **Colour palette:** High-contrast and statement-making for
  polemic / advocacy positioning (deep red on white / black,
  navy on cream, single saturated colour against neutral).
  More restrained palettes (charcoal / cream, deep blue /
  grey, single accent against neutral) for considered analysis,
  policy, and democracy-and-institutions positioning where
  authority matters more than confrontation. Stark monochrome
  for democracy-threat / authoritarianism-warning books.
- **Typography:** Bold, confident sans-serif (Gotham, Univers,
  Akzidenz-Grotesk, Söhne, Helvetica Neue Heavy) is the
  dominant choice for contemporary political commentary —
  typography signals statement and clarity. Substantial serif
  (Garamond, Adobe Caslon, Bembo) for considered policy /
  analysis / democracy-history positioning where the
  typography signals book-as-considered-work over book-as-
  manifesto. Display fonts and hand-set for rhetorically
  charged advocacy where typography itself participates in
  the argument.
- **Imagery:** Three dominant traditions:
  1. **Pure typography or typographic-with-element** — the
     most common form for current political commentary. Title
     and author large; sometimes single graphic element (a
     line, a star, a colour block, a symbolic mark). Strong
     for argument-led books where the cover trades on the
     thesis.
  2. **Symbolic / institutional imagery** — a flag, a building
     (Capitol, White House, Westminster, court building), a
     resonant object (gavel, ballot, microphone). Common for
     democracy / institutions / policy titles where the
     subject is structural rather than personal.
  3. **Photographic / documentary** — protest movement,
     specific named figure, charged moment. Strong for
     polemic / advocacy and for current-affairs analysis
     anchored to a specific moment or figure.
- **Mood:** Statement with substance. The cover should signal
  "this book takes a position and backs it with rigour" —
  not "magazine column expanded" (commercial-pulp register),
  not "academic study" (gatekeeping register). The cover
  participates in the book's argument; design literacy is
  itself a signal to category readers about the book's
  seriousness.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Current Affairs / Political Analysis | Pure typography or restrained symbolic imagery; restrained palette; substantial serif or confident sans-serif; subtitle clarifies the moment / scope ("America in the [decade]", "After [event]", "The [phenomenon] in [period]") |
| Political Polemic / Advocacy | Bold high-contrast palette; large statement-making typography; sometimes single charged image; subtitle often does the rhetorical positioning ("Why [X] is wrong / right / inevitable / failing") |
| Social Justice / Equity / Inequality | Strong typography often dominant; symbolic imagery where used (the inequality being addressed rendered visually) calibrated to avoid pity-tropes; subtitle establishes the structural-analysis angle ("How [system] [does X]", "The cost of...") |
| Policy & Governance | Often pure typography or restrained iconographic; clean sans-serif; restrained palette signalling institutional weight; subtitle clarifies the policy domain and analytical thesis |
| Media / Information / Platform Power | High-contrast design with media-iconographic elements (screen grid, broadcast tower, social-media interface fragment, pixel pattern); typography often urgent; subtitle establishes the mechanism / threat / case |
| Democracy / Institutions / Authoritarianism | Stark palette (often dark + accent) signalling institutional concern; symbolic imagery (institutional building, flag fragment, broken / stressed visual element); substantial typography; subtitle often rhetorical question or warning ("How [X] dies", "The end of...", "Can [X] survive?") |
| Global / International Affairs / Geopolitics | Often pure typography or world-map / abstract-globe imagery; restrained palette signalling foreign-policy seriousness; serif or substantial sans-serif; subtitle establishes the regional / structural focus |

### Typography Rules

- **Title:** 35–60% of cover area for typography-led covers;
  30–45% for image-led. Political commentary titles often
  work as statement / question / declaration ("Why We're
  Polarized", "How Democracies Die", "The Tyranny of Merit",
  "The End of Race Politics", "Doppelganger") or as
  descriptive ("The Color of Money", "Dark Money", "Winners
  Take All"). The title must read at thumbnail and signal
  the book's thesis and ideological positioning.
- **Subtitle:** Often essential — does the descriptive
  positioning work. "Why Liberalism Failed" subtitle: "Has
  the success of liberalism become its own worst enemy?".
  "How Democracies Die" subtitle: "What History Reveals
  About Our Future". Subtitle clarifies the argument's
  scope, the analytical lens, and the audience. Specific
  subtitle outsells vague.
- **Author name:** Larger for established commentator
  brands (Coates, Klein N, Klein E, Applebaum, Tooze,
  Fukuyama); smaller for unestablished authors with
  credentials in subtitle ("by a [Outlet] columnist", "by
  a former [Office] official", "by a professor of...").
  Author qualification cues — academic position, journalistic
  affiliation, government / advocacy experience, prior
  publications — shape this category's reader trust because
  argumentative authority depends on the author's standing
  within their analytical tradition.
- **Series mark and edition:** Political-publishing imprints
  (FSG, Knopf, Penguin Press, Crown, Henry Holt, Yale UP,
  Princeton UP, Harvard UP for academic-political, Verso
  for left publishing, Encounter for right) signal
  positioning to category readers. Updated editions for
  books whose argument has been overtaken by events;
  paperback re-issues with new framing common.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Current Affairs / Political Analysis | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Public Affairs & Policy (with Politics & Government > Specific Topics > Commentary & Opinion as secondary) |
| Political Polemic / Advocacy | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > Commentary & Opinion (the dedicated commentary-and-opinion shelf) |
| Social Justice / Equity / Inequality | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > Civil Rights (or > Social Sciences > Discrimination & Race Relations / Gender Studies / Class) |
| Policy & Governance | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Public Affairs & Policy (with Specific Topics > [policy domain — Education / Health / Environmental / Welfare / Trade / etc.] as secondary) |
| Media / Information / Platform Power | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Communication & Media Studies (with Computers & Technology > Internet & Social Media > Social Aspects as secondary for tech-platform-focused work) |
| Democracy / Institutions / Authoritarianism | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > Democracy (with > Ideologies > Conservatism / Liberalism / Fascism / Communism per the analytical focus) |
| Global / International Affairs / Geopolitics | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > International & World Politics (with > Specific Topics > Specific Region or > Diplomacy as secondary) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Specific political topic | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > [Privacy & Surveillance / Censorship / Globalization / Human Rights / Terrorism / Immigration / Labor & Industrial Relations / etc.] |
| Specific region / country | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > International & World Politics > [Specific Region: Asian / European / Latin American / Middle Eastern / African / North American / Russian & Former Soviet Union] |
| Sociology of the topic | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Sociology > [Class / Race Relations / Urban / Rural / etc.] |
| History of the issue | Kindle Store > Kindle eBooks > History > World > [Specific Region or Era] (or > Politics & Government > Specific Period) |
| Economics crossover | Kindle Store > Kindle eBooks > Business & Money > Economics > [Specific Topic] |
| Education-policy crossover | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Education Theory & Policy |
| Environmental-policy crossover | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > Environmental Policy |
| Memoir-political crossover | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > Political (for memoir of political life by figures or commentators) |

### Keyword Recommendations

- The book's thesis or topic
  ("polarization", "democratic decline", "wealth inequality",
  "racial capitalism", "the rise of authoritarianism",
  "political philosophy", "public policy analysis",
  "neoliberalism", "the welfare state")
- The political position or framework
  ("conservative thought", "progressive politics", "social
  democracy", "classical liberalism", "post-liberal",
  "New Right", "abolitionist", "communitarian")
- The specific phenomenon or moment
  ("Trump era", "Brexit", "the Great Recession aftermath",
  "post-pandemic politics", "populist moment", "the 2024
  election", "MAGA", "the new culture wars")
- The specific issue
  ("immigration policy", "criminal justice reform",
  "healthcare debate", "education policy", "climate policy",
  "tech regulation", "abortion politics", "free speech")
- Comparable author / brand for discoverability
  (readers of Ta-Nehisi Coates, readers of Anne Applebaum,
  readers of Naomi Klein, readers of Ezra Klein, readers of
  Adam Tooze, readers of Yuval Levin, readers of Patrick
  Deneen)
- Region / country where focused
  ("American politics", "British politics", "European
  politics", "Chinese geopolitics", "Russian foreign policy")
- Avoid generic "politics" / "policy" / "society" in
  isolation — they drown in algorithmic noise; prefer
  compound phrases combining position + topic + period
- Avoid framing-trap keywords ("the truth about", "what
  they don't want you to know", "the secret history of",
  "the real reason") — they signal conspiracy or
  exploitation positioning and damage credibility with the
  serious-reader audience the genre depends on
- Avoid hyper-partisan tribe-marker keywords used as if
  they describe a side ("the radical left", "the far right",
  "the deep state") unless engaging with these terms
  critically; using them as descriptors signals partisan
  positioning to readers across positions and may deter
  readers the book might otherwise persuade
