---
name: personal-finance-category
description: "Category plugin for Personal Finance non-fiction. provides structural, craft, quality, and guardrail instructions for all pipeline agents"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Personal Finance. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | `personal-finance` |
| Display Name | Personal Finance |
| Parent Group | Business & Finance |
| Complexity Tier | Moderate |
| Typical Word Count | 45,000–65,000 |
| Reader Expectation | Clear, actionable guidance they can implement immediately to improve their financial situation |
| Tone Baseline | Encouraging, non-judgmental, practical; a knowledgeable friend, not a condescending lecturer |

## Subcategory Options

When the user selects this category, prompt for a subcategory. Each subcategory adjusts structural emphasis and source expectations.

| ID | Subcategory | Focus | Typical Structure |
|----|------------|-------|-------------------|
| `investing-wealth` | Investing & Wealth Building | Portfolio construction, asset allocation, compound growth, index funds, alternative assets | Progressive complexity from basics to advanced strategies |
| `debt-budgeting` | Debt & Budgeting | Debt elimination, budgeting systems, expense tracking, emergency funds, credit management | Immediate-action chapters building toward financial stability |
| `financial-independence` | Financial Independence | FIRE movement, savings rate optimisation, passive income, lifestyle design, withdrawal strategies | Milestone-based structure from current state to financial freedom |
| `real-estate` | Real Estate | Property investment, house hacking, rental income, REITs, mortgage strategy | Deal-analysis framework with step-by-step transaction guides |
| `retirement` | Retirement Planning | Pension optimisation, drawdown strategies, Social Security/state pension, late-start planning, healthcare costs | Age-stage chapters with scenario-based planning tools |

### Subcategory Defaults

- If no subcategory is selected, default to `investing-wealth`.
- If the user's brief spans multiple subcategories, select the dominant one and note secondary influences in the structural plan.

## Structural Architect Instructions

### Core Model: Progressive Building-Block Structure

Personal finance books must respect the reader's starting point and build competence incrementally:

1. **Foundation**. Establish the core concept or principle in plain language. No assumptions about prior knowledge.
2. **Demonstration**. Show the concept in action through worked examples, scenarios, or case studies with real numbers.
3. **Application**. Provide a step-by-step action plan the reader can follow. Include worksheets, calculators, or decision trees where appropriate.
4. **Progression**. Connect to the next level of complexity, so the reader builds on what they have learned.

### Chapter Architecture

```
Chapter [N]: [Action-Oriented Title]

  Opening Scenario (300–500 words)
    → Relatable financial situation or common mistake
    → "By the end of this chapter, you will be able to..." promise

  Section 1: The Concept (1,200–2,000 words)
    → Core principle explained in plain language
    → Why this matters (real-world impact on wealth/security)
    → Common misconceptions debunked

  Section 2: The Numbers (1,500–2,500 words)
    → Worked examples with specific dollar/pound amounts
    → Comparison scenarios (e.g., "If you start at 25 vs. 35")
    → Tables or charts showing compound effects

  Section 3: Your Action Plan (1,500–2,500 words)
    → Step-by-step instructions
    → Decision framework for different situations
    → Tools and resources recommended (with no affiliate bias)

  Section 4: Common Pitfalls (800–1,200 words)
    → Mistakes to avoid
    → Behavioural traps (loss aversion, lifestyle inflation, etc.)
    → How to course-correct if things go wrong

  Chapter Checklist (200–300 words)
    → Numbered action items
    → "Before you move on, make sure you have..."
    → Bridge to next chapter
```

### Book-Level Arc

- **Part I (Chapters 1–3):** Financial foundations. mindset, current situation assessment, goal setting.
- **Part II (Chapters 4–7):** Core strategies. the primary building blocks of the subcategory topic.
- **Part III (Chapters 8–10):** Advanced moves. optimisation, tax efficiency, scaling.
- **Part IV (Chapter 11–12):** Maintenance and adaptation. long-term management, life-event adjustments.
- **Appendices:** Worksheets, resource lists, glossary of financial terms.

### Special Structural Elements

- Include a **Financial Health Assessment** worksheet in Chapter 1 or as a preliminary section.
- Every chapter must contain at least one **Worked Example** with specific numbers.
- Include **"What If" Scenarios**. age-based, income-based, or situation-based variations so diverse readers see themselves in the content.
- Provide a **Jargon-Free Summary** at the end of any chapter that introduces significant terminology.

## Content Writer Craft Rules

1. **Voice:** Warm, encouraging, and direct. Avoid condescension ("It's simple!") and avoid panic-inducing language ("You're losing money every day!"). Strike the tone of a trusted, knowledgeable friend.
2. **Numbers:** Use specific, realistic numbers in all examples. Adjust for the target market (USD, GBP, EUR, etc. as specified in the brief). Show calculations step by step; do not skip arithmetic.
3. **Jargon Control:** Define every financial term on first use in parentheses or a brief clause. Maintain a glossary. Use plain-language alternatives where possible (e.g., "your investment mix" alongside "asset allocation").
4. **Inclusivity:** Write for readers across income levels. Avoid examples that assume high incomes. Include scenarios for readers starting with modest means.
5. **Behavioural Awareness:** Acknowledge the emotional and psychological dimensions of money. Reference behavioural finance research where it strengthens the guidance.
6. **Specificity:** Replace vague advice ("save more") with concrete actions ("set up an automatic transfer of 10% of your take-home pay to a separate savings account on payday").
7. **Timeliness:** Avoid date-specific tax thresholds, interest rates, or policy details that will age rapidly. Instead, teach the reader how to look up current figures and provide a framework for evaluation.
8. **Cultural Sensitivity:** Money is deeply personal and culturally influenced. Do not assume attitudes toward debt, inheritance, or financial goals. Present options without moral judgment.
9. **Paragraph Length:** Keep paragraphs to 3–5 sentences. Financial content requires white space and breathing room. Use bullet points and numbered lists generously.
10. **Motivation Balance:** Pair every "tough truth" with a constructive path forward. Never leave the reader feeling hopeless about their financial situation.

### Prose Rhythm Mapping

Chapter 1 opens with the reader's financial anxiety. named and normalised.
Not lectured. Not dramatised. Simply acknowledged: you are worried about money,
and that is a rational response to your situation. This is where trust is built.

Direct, warm, practical. Short-to-medium sentences (12-18 words) dominate.
The "you" voice is essential. this book is a conversation, not a broadcast.
"You have probably tried budgeting before. It probably did not stick. That is
not a character flaw. It is a system design problem." That rhythm. That warmth.

Each section delivers one actionable principle. Not three. Not a menu of options.
One clear thing the reader can do, explained fully, with the why before the how.
The principle arrives in a short sentence. The explanation unfolds in medium
sentences. The action step returns to short, imperative clarity.

Tension minimum: 4. Financial anxiety is the tension. it is already present
in the reader before they open the book. The chapter's job is to channel that
anxiety into forward motion. The reader must feel understood, then equipped,
then capable. In that order.

Pacing guideline: open with recognition ("You know that feeling when...").
Follow with normalisation (medium sentences, 14-18 words). Introduce the
first principle by the end of the second section. Close the chapter with
a single, concrete action the reader can take today. stated in a short,
direct sentence. No hedging. No qualifiers. Just the step.

## Quality Check Criteria

The Quality Check agent must verify the following for personal finance category manuscripts:

| # | Criterion | Pass Condition |
|---|-----------|----------------|
| 1 | Mathematical Accuracy | All calculations, compound interest examples, and financial projections are arithmetically correct |
| 2 | Disclaimer Presence | A clear disclaimer that the book is educational, not personalised financial advice, appears in the front matter and is reiterated at the start of investment-related chapters |
| 3 | No Guaranteed Returns | No language promises or implies guaranteed investment returns; all projections use words like "historically," "on average," or "assuming" |
| 4 | Historical Performance Caveat | Every reference to historical investment performance includes a statement that past performance does not guarantee future results |
| 5 | Jurisdiction Awareness | Advice that is jurisdiction-specific (tax rules, account types, regulations) is clearly flagged with the applicable country/region |
| 6 | Product Neutrality | No recommendation of specific financial products, platforms, or advisors that could constitute undisclosed sponsorship |
| 7 | Worked Example Quality | Every chapter contains at least one fully worked numerical example with realistic assumptions |
| 8 | Accessibility | Content is understandable to a reader with no prior financial education |
| 9 | Action Item Specificity | Every action item is concrete and achievable (includes what to do, how to do it, and a reasonable timeline) |
| 10 | Emotional Tone | No shaming language about debt, spending habits, or financial mistakes; tone is constructive throughout |

## Source Requirements

### Minimum Source Thresholds

- **Per chapter:** Minimum 4 distinct sources.
- **Per book:** Minimum 35 unique sources across the manuscript.
- **Academic/research sources** (peer-reviewed studies, institutional research): At least 25% of total.
- **Official/regulatory sources** (government agencies, financial regulators): At least 15% of total.
- **Practitioner sources** (certified financial planners, credentialed professionals): Acceptable for practical guidance.

### Acceptable Source Types

| Type | Examples | Notes |
|------|----------|-------|
| Academic research | Journal of Finance, Journal of Financial Planning, NBER | Required for claims about investment returns, behavioural patterns |
| Government/regulatory | IRS, HMRC, SEC, FCA, Social Security Administration | Required for tax and regulatory information |
| Market data | Vanguard, Morningstar, S&P/Dow Jones Indices, FRED | For historical performance data and market statistics |
| Industry reports | CFP Board, FINRA Foundation, Money and Pensions Service | For financial literacy data and consumer trends |
| Published books | Established personal finance authors with credentials | For framework lineage and complementary perspectives |
| Financial journalism | FT, WSJ, Kiplinger, Money Magazine | For context and trend illustration |

### Prohibited Sources

- Wikipedia as a primary source.
- Financial influencer content (YouTube, TikTok, Instagram) as evidence for financial claims.
- Promotional materials from financial product companies presented as independent research.
- Anonymous forum posts (Reddit, etc.) as financial guidance. may reference for cultural context only with clear labelling.
- Outdated tax/regulatory information (must be current tax year or explicitly labelled as historical).

## Category-Specific Guardrails

### Disclaimer Requirements

- The book **must** include a prominent disclaimer in the front matter stating: this book provides general financial education and is not a substitute for personalised advice from a qualified financial professional.
- Chapters covering investments, tax strategies, or insurance must include a brief disclaimer at the chapter opening.
- The disclaimer must note that financial regulations and tax laws vary by jurisdiction and change over time.

### No Guaranteed Returns

- **Never** state or imply that any investment strategy guarantees positive returns.
- Use hedging language consistently: "historically averaged," "based on past data," "assuming average market conditions."
- When presenting compound growth examples, explicitly state the assumed rate of return and note it is illustrative, not a promise.

### Historical Performance

- Every reference to historical investment returns **must** include: "Past performance is not a guarantee of future results" or equivalent language.
- Do not cherry-pick favourable time periods. When citing returns, use standard long-term periods (10, 20, 30 years) from recognised indices.
- Acknowledge that historical averages include periods of significant loss.

### Jurisdiction-Specific Advice

- Clearly flag any advice that is specific to a particular country's tax system, retirement accounts, or financial regulations.
- Use notation such as: **[US-specific]**, **[UK-specific]**, **[Australia-specific]** as applicable.
- Where possible, provide the general principle that applies universally, then note jurisdiction-specific applications.
- Do not assume the reader is in any particular country unless the book is explicitly scoped to one market.

### Product and Platform Neutrality

- Do not recommend specific financial products, brokerages, or advisory firms by name in a way that constitutes endorsement.
- If mentioning specific platforms as examples, include at least two alternatives and note that the reader should evaluate options based on their own criteria.
- Disclose if the author has any financial relationship with mentioned products or services.

## Cover Design Specifications

| Element | Specification |
|---------|---------------|
| Typography | Clean, approachable sans-serif. Title should feel empowering, not intimidating. Bold weight for title, regular for subtitle. |
| Colour Palette | Trustworthy, optimistic tones. green (wealth/growth), blue (trust/stability), gold (prosperity). White or light backgrounds. Avoid red (panic) or overly dark schemes. |
| Imagery | Abstract growth imagery (upward curves, building blocks, pathways), clean iconography. No photographs of cash, gold bars, or luxury items. No piggy banks. |
| Layout | Title prominent. Subtitle should communicate the specific promise or audience. Author credentials or "Foreword by [Notable Person]" if applicable. |
| Subtitle | Required. Format: "A Step-by-Step Guide to [Specific Outcome]" or "How to [Action] and [Result]." |
| Endorsement | One endorsement from a recognised financial professional, bestselling author, or media personality if available. |
| Spine | Title + Author. Legible at thumbnail size. |
| Back Cover | 3–5 bullet points of reader outcomes, one endorsement quote, author bio with financial credentials, barcode. |

## KDP Category Mapping

### Primary Category Path

```
Kindle Store > Kindle eBooks > Business & Money > Personal Finance
```

### Secondary Category Path (select based on subcategory)

| Subcategory | Recommended Secondary KDP Category |
|------------|-------------------------------------|
| `investing-wealth` | Business & Money > Investing > Introduction |
| `debt-budgeting` | Business & Money > Personal Finance > Budgeting & Money Management |
| `financial-independence` | Business & Money > Personal Finance > Retirement Planning |
| `real-estate` | Business & Money > Real Estate > Investments |
| `retirement` | Business & Money > Personal Finance > Retirement Planning |

### Keyword Recommendations

- Use 7 keyword slots in KDP.
- Include: primary financial topic, subcategory term, target audience descriptor, financial goal phrase, comparable author name (if applicable), actionable phrase, related trending term.
- Example set: `personal finance`, `investing for beginners`, `financial independence`, `money management`, `build wealth`, `retirement planning`, `budgeting guide`.

### BISAC Codes

| Code | Description |
|------|-------------|
| BUS050000 | BUSINESS & ECONOMICS / Personal Finance / General |
| BUS050020 | BUSINESS & ECONOMICS / Personal Finance / Investing |
| BUS050010 | BUSINESS & ECONOMICS / Personal Finance / Budgeting |
| BUS050040 | BUSINESS & ECONOMICS / Personal Finance / Retirement Planning |
| BUS054000 | BUSINESS & ECONOMICS / Real Estate / General |
