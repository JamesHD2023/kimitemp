---
name: video-trailer-designer
description: "AI-powered book trailer storyboard generation with scene-by-scene prompts for Sora, Runway, Pika, Luma, and Kling"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Video Trailer Designer — Engine Skill

## Purpose

The Video Trailer Designer generates complete book trailer storyboards with
scene-by-scene AI video prompts. Each scene is tailored to multiple AI video
platforms, with post-production guidance for assembling the final trailer.

Every output is:
- **Market-researched** — informed by live web search for current book trailer trends
- **Genre-adapted** — matches the visual language and pacing readers expect
- **Multi-platform** — produces optimised prompts for Sora, Runway, Pika, Luma, and Kling
- **Production-ready** — includes text overlays, music suggestions, and editing guidance

## When to Use

Activate when:
- The user requests a book trailer, video trailer, or promotional video concept
- The user wants video prompts for AI video tools
- The user is working in the Publishing Studio / Video Trailer interface

---

## Trailer Styles

| ID | Name | Description | Best For |
|----|------|-------------|----------|
| `cinematic` | Cinematic | Epic movie-trailer style with dramatic lighting and camera movements | Thriller, Fantasy, Sci-Fi, Action, Horror |
| `atmospheric` | Atmospheric | Mood-focused with slow reveals, ambient lighting, and emotional depth | Literary Fiction, Horror, Mystery, Gothic, Drama |
| `character` | Character-Focused | Centers on protagonist(s) with emotional close-ups and personal moments | Romance, Drama, Memoir, Young Adult, Women's Fiction |
| `world` | World/Setting | Showcases the story world with sweeping vistas and environmental shots | Fantasy, Historical Fiction, Sci-Fi, Travel, Epic |
| `action` | Action/Dynamic | Fast-paced with quick cuts, dramatic angles, and high energy | Thriller, Action, Suspense, Adventure, Military |
| `elegant` | Elegant/Artistic | Refined, slow-motion shots with artistic composition | Literary Fiction, Historical, Romance, Upmarket |
| `dark` | Dark/Moody | High contrast, shadows, tension, and unease | Horror, Dark Fantasy, Thriller, Noir, Gothic |
| `whimsical` | Whimsical/Playful | Bright, colourful, magical, with light-hearted energy | Cozy Fantasy, Rom-Com, Middle Grade, Cozy Mystery |

---

## Trailer Configuration

### Duration Options
- **30 seconds** — Social media teaser (3–4 scenes)
- **60 seconds** — Standard book trailer (5–7 scenes)
- **90 seconds** — Extended trailer (7–9 scenes)

### Tone Options
- Dramatic, Mysterious, Romantic, Whimsical, Dark, Hopeful, Tense, Epic

### Aspect Ratios
- **16:9** — YouTube, website (landscape)
- **9:16** — TikTok, Instagram Reels, YouTube Shorts (portrait)
- **1:1** — Instagram feed, Facebook (square)

---

## AI Video Platforms

| Platform | Strength | Best For | Notes |
|----------|----------|----------|-------|
| **Sora** | Highest quality, complex scenes | Hero scenes, establishing shots | OpenAI; best for photorealistic and cinematic |
| **Runway** | Consistent style, good motion | Character moments, atmospheric | Gen-3 Alpha; strong style transfer |
| **Pika** | Quick iteration, stylised | Social media clips, artistic | Good for stylised/illustrated looks |
| **Luma** | 3D-aware, spatial | World-building, environments | Dream Machine; excellent for landscapes |
| **Kling** | Long-form, motion | Action sequences, movement | Good for extended motion and transitions |

### Platform-Specific Prompt Formatting

**Sora:**
- Detailed scene descriptions with camera movement
- Specify duration, aspect ratio, and style
- Best for photorealistic content

**Runway (Gen-3 Alpha):**
- Motion-focused descriptions
- Supports image-to-video (can use cover art as starting frame)
- Style transfer from reference images

**Pika:**
- Concise, style-focused prompts
- Supports various artistic styles
- Good for short, impactful clips

**Luma (Dream Machine):**
- Environment and spatial descriptions
- Excels at sweeping camera movements
- Best for world-building shots

**Kling:**
- Motion-heavy descriptions
- Longer clip generation
- Good for action and movement sequences

---

## Generation Pipeline

### Phase 1: Market Research

Load `market-scout.md` and run Market Scout with context: **"trailer"**.

The trailer context adapter emphasises video marketing trends on BookTok and
YouTube, comp titles with existing trailers, and visual styles/music choices
driving engagement. It also surfaces social media video strategies for pre-orders.

See `market-scout.md` for the full protocol, report format, and fallback behaviour.

### Phase 2: Context Assembly

```
Required:
- Book title, author, genre
- Research Bible (truncated to 3,000 chars)
- Key themes and main characters
- Selected trailer style
- Selected duration
- Selected tone
- Selected aspect ratio

Optional:
- Cover design (if available, can inform visual continuity)
- Custom notes from user
- Live market research data
- Static market benchmarks
```

### Phase 3: Storyboard Generation

The AI generates a complete trailer storyboard with:

1. **Trailer Concept** — Overall vision and approach
2. **Scene Breakdown** — Each scene includes:
   - Scene number and title
   - Duration (seconds)
   - Visual description (detailed imagery, lighting, camera movement)
   - Text overlay (what appears on screen, if any)
   - Audio/mood notes (music style, sound effects, atmosphere)
   - Camera direction (movement type, angle, transitions)
   - Platform prompts (per-platform optimised prompts for Sora, Runway, Pika, Luma, Kling)
3. **Post-Production Guidance**:
   - Text overlay timing and placement
   - Music genre and mood recommendations (with specific track suggestions)
   - Transition types between scenes
   - Tips for combining AI-generated clips in a video editor
   - Platform-specific export settings

---

## Scene Structure by Duration

### 30-Second Trailer (3–4 scenes)

| Scene | Duration | Purpose |
|-------|----------|---------|
| 1 | 8–10s | Hook — arresting opening image that demands attention |
| 2 | 8–10s | Core — the heart of the story in one powerful image |
| 3 | 5–8s | Climax — the moment of highest tension or emotion |
| 4 | 3–5s | Title card — book title, author, release date |

### 60-Second Trailer (5–7 scenes)

| Scene | Duration | Purpose |
|-------|----------|---------|
| 1 | 8–10s | Hook — establish mood and world |
| 2 | 8–10s | Introduce protagonist in their element |
| 3 | 8–10s | The disruption / inciting incident |
| 4 | 8–10s | Rising tension / stakes |
| 5 | 8–10s | Climactic moment (without spoilers) |
| 6 | 5–8s | Emotional peak or mystery deepening |
| 7 | 3–5s | Title card with call to action |

### 90-Second Trailer (7–9 scenes)

| Scene | Duration | Purpose |
|-------|----------|---------|
| 1 | 8–10s | Cold open — arresting visual before title |
| 2 | 8–10s | World establishment |
| 3 | 8–10s | Character introduction |
| 4 | 8–10s | Inciting incident |
| 5 | 8–10s | Complications / stakes rising |
| 6 | 8–10s | Key relationship or conflict moment |
| 7 | 8–10s | Climactic tension |
| 8 | 5–8s | Emotional payoff or question |
| 9 | 3–5s | Title card with call to action |

---

## Genre-Specific Trailer Approaches

### Thriller / Suspense / Mystery
- Quick cuts building tension
- Unreliable narrator hints through visual contradiction
- Piano tension that builds to orchestral
- Domestic scenes with sinister undertones
- Time-lapse or accelerating edits

### Romance
- Warm lighting, golden hour cinematography
- Slow motion eye contact and near-touch moments
- Parallel editing of both characters' worlds
- Soft focus transitions
- Music: acoustic → building emotional score

### Fantasy / Sci-Fi
- Sweeping world-establishing shots
- Magic/tech reveal moments
- Scale contrast (character small against vast world)
- Gradual visual complexity increase
- Music: ethereal → epic orchestral

### Horror / Gothic
- Slow reveals with increasing dread
- Environmental wrongness (subtle distortions)
- Jump scare timing (brief flash frames)
- Sound design emphasis over music
- Desaturated colour palette with single accent

### Literary / Contemporary
- Character-focused close-ups
- Symbolic imagery (repeated motifs)
- Quiet, contemplative pacing
- Natural lighting
- Music: solo instrument or ambient

---

## Output Path

**File output:** `Ideorix-Projects/[Title]/marketing/trailer-storyboard.docx`

---

## Output Schema

```json
{
  "trailerConcept": "string — Overall vision and approach",
  "style": "string — Selected style ID",
  "duration": "number — Total duration in seconds",
  "aspectRatio": "string — 16:9, 9:16, or 1:1",
  "scenes": [
    {
      "sceneNumber": "number",
      "title": "string — Scene title",
      "duration": "number — Duration in seconds",
      "visual": "string — Detailed visual description",
      "textOverlay": "string — On-screen text (null if none)",
      "audioMood": "string — Music/sound notes",
      "cameraDirection": "string — Camera movement and angle",
      "platformPrompts": {
        "sora": "string — Optimised for Sora",
        "runway": "string — Optimised for Runway Gen-3",
        "pika": "string — Optimised for Pika",
        "luma": "string — Optimised for Luma Dream Machine",
        "kling": "string — Optimised for Kling"
      }
    }
  ],
  "postProduction": {
    "textOverlayTiming": "string — When and how to add text",
    "musicSuggestions": ["string — Genre, mood, and specific track ideas"],
    "transitions": "string — Recommended transitions between scenes",
    "editingTips": "string — Tips for assembling in a video editor",
    "exportSettings": {
      "youtube": "string — Resolution, codec, bitrate",
      "tiktok": "string — Resolution, codec, bitrate",
      "instagram": "string — Resolution, codec, bitrate"
    }
  },
  "alternativeApproaches": ["string — Brief alternative concept directions"]
}
```

---

## Quality Criteria

### Visual Storytelling
- Trailer tells a story arc without spoilers
- Each scene has a clear purpose in the emotional progression
- Genre is instantly recognisable from the visual language
- Pacing matches genre expectations

### Platform Optimisation
- Each platform prompt is formatted to that platform's strengths
- Aspect ratio accounted for in all scene compositions
- Duration constraints respected per scene and total
- Text overlays designed for readability at each aspect ratio

### Production Readiness
- Post-production guidance is actionable by a non-professional
- Music suggestions are genre-appropriate and mood-matched
- Transition recommendations create smooth scene-to-scene flow
- Export settings match platform requirements

### Spoiler Prevention
- No plot twists or endings revealed
- Climactic moments suggested, not shown
- Character fates left ambiguous
- Mystery/thriller trailers create questions, not answers

---

## Relationship to Other Engine Files

| Engine File | Relationship |
|-------------|-------------|
| `cover-designer.md` | Cover art can serve as a visual reference for trailer style consistency |
| `marketing-expert.md` | Social media pack TikTok scripts complement trailer content |
| `core-pipeline.md` | Trailer generation happens AFTER manuscript is complete |
| `research-bible.md` | Research Bible provides visual context for scene design |

The Video Trailer Designer is a **post-manuscript tool** — it consumes the
Research Bible and manuscript content to create promotional video concepts that
accurately represent the finished work.
