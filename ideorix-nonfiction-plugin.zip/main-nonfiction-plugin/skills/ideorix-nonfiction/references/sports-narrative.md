---
name: sports-narrative-category
description: "Category-specific instructions for sports and adventure non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Sports / Adventure. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | sports-narrative |
| Display Name | Sports / Adventure Narrative |
| Parent Group | Sports & Outdoors (and Biographies & Memoirs > Sports for biographical / memoir-led titles) |
| Typical Word Count | 70,000–110,000 (single-event narratives 60,000–90,000; biographies 80,000–130,000; comprehensive-history works can run 130,000+; expedition / adventure narratives often 70,000–100,000) |
| Default Structure | Event / season / expedition as chronological spine; physical experience rendered with kinetic precision; analytical pull-back paragraphs alternating with action; build toward climactic moment (championship final, summit, finish line, decisive contest); broader cultural significance interwoven with the personal / team narrative |
| Citation Style | Endnotes for historical, statistical, and contested claims; named-source attribution for interviews and inside-the-team reporting; primary documentation (game records, league archives, federation reports, court filings where applicable) cited; sports-science sources for injury / performance claims; bibliography appended for substantial works |
| Audience Baseline | Reader interested in the sport, the figure, or the broader phenomenon; varies from fan-of-the-sport (single-sport / single-team / single-figure deep dive) to general reader (sport as cultural / narrative subject); technical depth calibrated accordingly with sport-specific terminology defined at first use for non-specialist audiences |
| Comparable Titles | David Halberstam (*The Breaks of the Game*, *Summer of '49*, *October 1964*), Roger Angell (*The Summer Game*, *Late Innings*), Michael Lewis (*Moneyball*, *The Blind Side*), Jane Leavy (*Sandy Koufax*, *The Big Fella: Babe Ruth*), David Maraniss (*When Pride Still Mattered: Vince Lombardi*, *Clemente*), Roger Kahn (*The Boys of Summer*), Mark Kram (*Ghosts of Manila*), David Remnick (*King of the World*), Jeff Pearlman (*Showtime*), Andre Agassi (*Open*), Jonathan Wilson (*Inverting the Pyramid*), Simon Kuper & Stefan Szymanski (*Soccernomics*), Hanif Abdurraqib (*A Little Devil in America*), Jon Krakauer (*Into Thin Air*), Joe Simpson (*Touching the Void*), Alfred Lansing (*Endurance*), Maurice Herzog (*Annapurna*), Wright Thompson (long-form essays), Sally Jenkins |

## Subcategory Options

When the user selects Sports / Adventure Narrative, prompt for subcategory
refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| single-sport-deep-dive | Single Sport / Team / Season Deep Dive | A specific sport, team, season, era, or rivalry examined in depth — the Halberstam / Wilson / Pearlman lineage; inside-the-team reporting with broader cultural framing | Season-or-event chronology; named players and coaches as recurring cast; statistical and analytical context; broader cultural / historical significance woven in; access-based reporting (locker room, sideline, training-camp visits) |
| athlete-memoir-autobiography | Athlete Memoir / Autobiography | A player's own account of their career, often with co-writer; the Agassi *Open* / Phil Jackson / Pete Sampras-style first-person sporting memoir | First-person sporting-life chronology; the inside-the-experience perspective unavailable from outside; transformation arc anchored in the sporting career; the relationship between athletic identity and the person off the field |
| athlete-biography | Athlete Biography (third-person) | Researched biography of an athlete, coach, or sporting figure; the Maraniss / Leavy / Remnick / Kram lineage; cross-references the biography category but with sporting subject and conventions | Chronological life-of-the-figure with the sport as second protagonist; named-source interviews with associates / opponents / family / coaches; primary documentation (contracts, archives, contemporaneous reporting); the figure's place in the sport's history examined |
| mountaineering-extreme-adventure | Mountaineering / Extreme / Adventure | Climbing expeditions, polar journeys, ocean crossings, ultra-endurance events; physical-extremity narrative; the Krakauer / Simpson / Lansing / Herzog lineage | Expedition phases as chapter spine; physical hardship and risk as recurring beats; landscape as adversary or partner; transformation through the physical journey; mortality often present as a recurring theme |
| sports-history-culture | Sports History / Sports Culture | The social, political, racial, gender, economic dimensions of a sport, league, era; the Kahn-on-Brooklyn-Dodgers / Kram-on-Ali-Frazier / Abdurraqib-on-Black-cultural lineage | Era-or-theme chapter spine rather than single-event chronology; named-figure cast across the era; broader social context as substantial subject (race, labour, region, generation); the sport as lens onto the wider culture |
| sports-analytics-business | Sports Analytics / Business / Industry | Data-driven analysis, sports business, league economics, the structural dimensions of sport; the Lewis / Kuper / Szymanski / contemporary-analytics lineage | Question-or-thesis-led structure (the Moneyball-style argument); evidence assembled across multiple cases; numerical and analytical detail accessible to general audience; institutional context (leagues, teams, agents, broadcasters, sponsors); challenges conventional sporting wisdom |
| fan-cultural-criticism | Fan / Cultural / Critical Writing on Sport | The fan's-eye, critic's-eye, cultural-essayist's view of sport — the Bill Simmons-style critical column / Hanif Abdurraqib-style cultural essay / personal-fan-memoir-of-a-team / DFW-on-Federer-style appreciation | Often essay-collection or essay-cycle structure (overlap with essay-collection category); first-person fan / observer / critic positioning; sport-as-cultural-text rather than as-objective-reportage; literary-criticism conventions applied to sporting subject |

**Default:** If the user does not specify, prompt for the book's mode
(single-sport / athlete-memoir / athlete-biography / extreme-adventure /
sports-history / analytics / fan-cultural) and select accordingly;
fallback to `single-sport-deep-dive` for unclear cases.

## Structural Architect Instructions
```
STRUCTURE
- Event/season/expedition provides the chronological spine
- Physical experience must be vivid. put the reader in the race/climb/game
- Build toward a climactic event (the final, the summit, the finish line)
- Interweave personal/team narrative with broader cultural significance

CATEGORY ARCHITECTURE
- Sensory detail and physical specificity are paramount
- Statistics and records matter. sports readers want precision
- The "glory narrative" must be balanced with honest treatment of failure and cost
- Ethical issues (doping, corruption, exploitation) not whitewashed

FORBIDDEN
- Inaccurate event details (scores, times, records, routes)
- Glorification of dangerous behaviour without acknowledging risk
- Hagiography. athletes are human, complex, flawed
- Ignoring the broader context (labour issues, health consequences, systemic problems)
```

## Content Writer Craft Rules
```
VOICE & TONE
- Energetic, visceral, immersive. the reader should feel the physical experience
- Technical detail balanced with emotional narrative
- Present-tense feeling even in past-tense narration (create immediacy)
- Respect for the subject matter. no condescension toward "just sports"
```

### Prose Rhythm Mapping

Chapter 1 opens with the game, the athlete, or the moment of consequence.
The reader is dropped into action. mid-stride, mid-swing, mid-fall. No
preamble. No biography. No context. The body in motion, described with
choreographic precision, and the reader's pulse rising with it.

Two registers, and the writing shifts between them like a broadcast cutting
between the field and the commentary booth. Kinetic short sentences (8-15
words) during action: "He planted his left foot. The defender bit inside.
He was gone." These sentences are fast, physical, present-tense in feel.
They put the reader in the athlete's body.

Medium analytical sentences (16-22 words) during reflection: stepping back
to contextualise what just happened, to explain why that moment mattered in
the arc of a career, a season, a rivalry. The shift from kinetic to
analytical must be clean. a paragraph break, a time shift, a widening
of the lens.

The body in motion demands choreographic precision. Not "he ran fast" but
"his knees drove high, his arms pumped in tight arcs, and the gap between
him and the field opened like a wound." Sports writing fails when it tells
the reader someone was great. It succeeds when the reader sees the greatness
in the movement itself.

Tension minimum: 6. Sports narrative demands the highest tension baseline
of any non-fiction category. The reader must feel that the outcome is
uncertain. even if they know the score. The prose creates this by staying
in the moment, by refusing to foreshadow, by making each action feel like
it could go either way.

Pacing guideline: open with kinetic prose (short sentences, 8-14 words).
Sustain the action for two to three paragraphs. Then pull back to a single
analytical paragraph (medium sentences, 16-22 words). Then plunge back in.
The ratio is roughly three parts action to one part reflection. The chapter
should end at the moment of highest consequence. not after it. Let the
reader carry the impact into the next chapter.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Factual accuracy on competitive results | Scores, times, records, dates, distances, league standings, championship outcomes, statistical claims verified against league / federation / official records; sports readers will catch errors and the credibility cost of even one verifiable mistake is disproportionate |
| 2 | Physical descriptions plausible and consistent | Athletic actions described accurately (a 4.4 forty isn't run while looking sideways; a 6-iron isn't hit 280 yards by an amateur; a successful Olympic lift is not described with the wrong technique); sport-specific vocabulary used correctly |
| 3 | Named-source attribution for inside-the-team reporting | Quotes attributed by name where consented; off-the-record material flagged as such; access bargain disclosed (cooperative / unauthorised / mixed); composite scenes and reconstructed dialogue handled per biography conventions where used |
| 4 | Statistical and analytical claims sourced | Where the book makes statistical or analytical claims (advanced metrics, comparative analysis, historical-record claims), claims trace to named sources (Baseball Reference, Basketball Reference, Pro Football Focus, Opta, StatsBomb, named scholars / analysts); "studies show" / "the numbers say" without citation unacceptable |
| 5 | Distinguishes analytics from impression | Where the book argues from data, the data is shown and the argument follows from it; where the book argues from observation / impression / experience, that is named ("watching the team that season, what struck me was..."); conflating the two registers undermines both |
| 6 | Race / gender / class / sexuality / disability handled with awareness | Sport's history and present is shaped by these dimensions (segregation history, women's-sport access, working-class participation patterns, queer athletes' experience, disabled and Paralympic sport); the book engages where relevant rather than treating sport as a neutral meritocracy |
| 7 | Ethical dimensions engaged honestly | Where the topic touches doping, concussion / CTE, exploitation (NCAA amateurism, agent power, athlete labour), corruption (gambling, FIFA / IOC scandal, match-fixing), the book engages substantively rather than treating these as separable from the on-field story |
| 8 | Glory narrative balanced with cost | Sporting achievement comes with cost — physical (injury, long-term health), psychological (depression / addiction), financial (post-career), relational (career-shortened relationships, broken families); the book honours both the triumph and the cost rather than presenting only the highlight reel |
| 9 | Living-vs-deceased subject ethics | For living subjects, defamation, fairness, and interview-bargain considerations apply (biography conventions); for deceased subjects, primary-source citation, estate-cooperation disclosure, and historical-context standards apply |
| 10 | Action prose creates appropriate tension | Chapters build tension through kinetic prose during action sequences and analytical pull-back during reflection; the reader feels uncertainty about outcome even when they know the score; cliché sports writing ("dug deep", "heart of a champion", "left it all on the field") avoided in favour of specific physical and tactical observation |

## Source Requirements

### Mandatory Source Types

- **Event records and official statistics.** League / federation
  / governing-body archives (MLB.com, NBA.com, NFL.com, FIFA,
  UCI, IOC, ICC, ATP / WTA, etc.); statistical services
  (Baseball Reference, Basketball Reference, Pro Football
  Reference, FBRef, Tennis Abstract, Cricinfo, StatsBomb,
  Opta, Synergy); race / event timing services for
  individual-sport results. The evidentiary backbone for any
  competitive-results claim.
- **Named-source interviews.** Interviews with players,
  coaches, executives, agents, family members, opponents,
  associates conducted by the author and attributed by name
  where consented; ground rules (on the record / on background
  / off the record) marked appropriately; the access bargain
  (authorised / cooperative / unauthorised) disclosed in front
  matter where it shapes the work.
- **Journalistic reporting on the sport / event.** Named-author
  reporting from established sports journalism (NYT, WaPo,
  Sports Illustrated, ESPN long-form, The Athletic, Athletic
  Intelligence, Players' Tribune for athlete voice, named
  beat reporters for specific teams / leagues / events);
  contemporaneous reporting on contested events given priority
  over later reconstruction.
- **Sports science and medical literature.** For performance,
  training, injury, recovery, long-term-health claims —
  peer-reviewed sports science, sports medicine,
  exercise-physiology, neurology (for concussion / CTE
  research), endocrinology (for performance-enhancing-drug
  claims) literature.
- **Primary documentation.** Contracts, court filings, league
  disciplinary records, anti-doping case files, congressional
  / parliamentary hearing transcripts, federation rule books,
  collective-bargaining agreements where applicable —
  primary documents preferred over summary reporting for
  consequential claims.
- **Voices from across the sport's stakeholder community.**
  For sports with substantial labour issues (NCAA athletes,
  minor-league baseball, women's professional sports
  historically underpaid, jockeys, fighters), worker /
  labour / advocacy voices alongside ownership / management
  perspectives; for sports with safety-and-health concerns
  (football / boxing / hockey / rugby / motorsport), athlete
  advocates and medical researchers.

### Source Freshness

- **Statistical and analytical methods evolve.** Pre-2010
  baseball analysis often does not engage with the framework
  now standard (wOBA, FIP, WAR, statcast metrics);
  pre-2010 basketball analysis predates Synergy / Second
  Spectrum data; pre-2010 football analytics predates Pro
  Football Focus; pre-2015 soccer analytics predates the
  StatsBomb / Opta event-data era. Books drawing on advanced
  metrics use current frameworks rather than superseded ones.
- **Concussion and long-term-health science has evolved
  rapidly.** Pre-2010 framings of football / boxing / hockey
  / soccer brain-trauma risk often understate current
  understanding; the BU CTE Center's research, the NFL
  concussion-settlement evidence, and current peer-reviewed
  work shape what current honest writing can claim.
- **Women's sports has expanded sharply.** Pre-2015 books
  often treat women's sports as an addendum to men's sports
  rather than as a substantial subject in its own right;
  current standards expect substantive treatment of women's
  professional leagues (NWSL, WNBA, women's soccer World Cup
  attention, women's tennis history), pay-equity advocacy
  (USWNT lawsuit, Billie Jean King's history), and
  participation patterns.
- **Cultural / political dimensions of sport have become
  more central.** Athlete activism (Colin Kaepernick, the
  WNBA's leadership on social-justice messaging, soccer's
  taking-the-knee, NBA-China dispute, athlete-mental-health
  advocacy from Naomi Osaka / Simone Biles); current
  standards expect engagement rather than the older "stick
  to sports" framing.
- **Coverage of LGBT+ athletes has expanded.** Pre-2015
  treatment was sparse and often deferential to closet
  conventions; current work treats LGBT+ athletes as
  substantial subjects, with awareness of the specific
  histories (Billie Jean King, Glenn Burke, Megan Rapinoe,
  Robbie Rogers, Carl Nassib).
- **Foundational works hold up better.** Halberstam's
  *Boys of Summer* / *Breaks of the Game* / *Summer of '49*,
  Roger Angell's baseball criticism, Roger Kahn — these
  remain foundational because the human material outlasts
  the era's specific stats / contracts / rules.

### Attribution Standards

- **Statistical claims sourced.** "Studies show..." / "the
  data says..." unacceptable without citation; "Per Baseball
  Reference..." / "FBRef shows..." / "Pro Football Focus
  data indicate..." is the standard. Reader trust depends
  on this.
- **Quote attribution precise.** Quotes from interviews
  attributed with date / venue / context where appropriate;
  quotes from contemporaneous reporting attributed with
  publication and date; quotes from documents identified
  with document type.
- **Distinguish: observation / interview / record /
  reconstruction.** "I watched from the press box..."
  (observation). "Brady told me in a 2018 phone interview..."
  (interview). "League records show..." (record).
  "According to teammates' contemporaneous accounts..."
  (reconstruction from witness testimony). Each register
  signals the evidence's nature.
- **Composite scenes / time compression / reconstructed
  dialogue disclosed.** Where the author has dramatised
  scenes the author did not witness — common in
  inside-the-team narrative — the reconstruction methodology
  is disclosed (typically in author's note); reconstructed
  dialogue flagged as approximate where contested.
- **Author positionality disclosed where it matters.** The
  author's relationship to the team / sport / figure
  (long-time fan, former player, beat reporter, hostile
  critic, neutral observer) shapes the work; some
  disclosure helps readers calibrate.
- **What is NOT acceptable.** Inventing competitive-results
  details. Inventing or significantly distorting quotes.
  Citing aggregator sites without checking original sources.
  Treating off-the-record information as on-the-record.
  Presenting individual game footage / stats /
  contemporaneous reporting selectively to support a thesis
  the broader record does not support. Failing to disclose
  cooperative-biography access bargains that limited what
  the book could include.

## Category-Specific Guardrails

### MANDATORY. Factual Accuracy on Competitive Results

- Sports narrative's foundation is verifiable competitive
  detail: scores, times, records, distances, dates, venues,
  league standings, championship outcomes, statistical claims.
  Errors in this domain damage the book irrecoverably because
  sports readers fact-check.
- Specific requirements:
  - **Game and event details verified** against league /
    federation / governing-body records.
  - **Statistical claims** (career totals, single-season
    figures, advanced metrics) verified against authoritative
    statistical services with citation.
  - **Historical "first" / "only" / "best" claims** verified
    rigorously — these claims attract scrutiny from
    sports-trivia communities; verifiable mistakes are
    embarrassing.
  - **Sport-specific terminology used correctly.** A "fastball"
    isn't a "curveball"; a "lift" isn't a "swing"; a "scrum"
    isn't a "ruck"; a "flat-spin" isn't a "wing-over." Books
    that betray basic-vocabulary unfamiliarity lose
    fan-of-the-sport credibility immediately.
- Where claims involve numbers, the numbers are checked;
  where claims involve comparisons across eras (the era-
  adjusted statistics challenge), the methodology is
  acknowledged.

### MANDATORY. Named-Source Reporting Discipline

- Inside-the-team / inside-the-figure access is the category's
  signature mode but creates specific reporting obligations:
  - **Quotes attributed by name** where the source has
    consented; off-the-record material flagged as such
    ("a person familiar with..." / "according to a former
    teammate who requested anonymity to speak candidly...").
  - **The access bargain disclosed.** Authorised biographies
    note the cooperation arrangement; cooperative inside-
    the-team books note what access was granted and what
    review-rights (if any) were extended; unauthorised work
    discloses the lack of cooperation honestly.
  - **Composite scenes flagged.** Where the author has
    constructed a scene from multiple witness accounts or
    has reconstructed events the author did not witness, the
    reconstruction methodology is disclosed in author's note.
  - **Reconstructed dialogue flagged** as approximate where
    contested or consequential; verbatim quotes distinguished
    from paraphrase / reconstruction.
- The fan / reader trust in sports narrative depends on
  knowing what the author saw, what the author was told, and
  what the author has reconstructed from secondary sources.

### MANDATORY. Distinguishing Analytics from Impression

- Sports narrative now operates in a culture saturated with
  advanced statistics; the reader is increasingly literate in
  metrics. The book's analytical claims must be honest about
  their evidentiary basis:
  - **Numerical / analytical claims** show the data and the
    argument follows from it — "Mike Trout's career WAR
    through age 26 ranks higher than every player except
    Babe Ruth and Mickey Mantle"; "In 2017, the Warriors'
    points-per-possession in transition exceeded their
    league-leading half-court figure by..."
  - **Observational / impressionistic claims** are framed as
    such — "watching Federer that summer, what struck me
    was..." / "the team that took the field in the second
    half had a different posture than the one we had seen
    before the half."
  - **Conflating the two undermines both.** The book that
    uses statistics to dress up impression, or that treats
    observation as if it generates the certainty of data,
    fails the contemporary reader.
- Both registers are legitimate; the analytical register is
  not necessarily superior to the observational; but each
  needs to be honest about what kind of claim it is making.

### MANDATORY. Treatment of Race / Gender / Class / Sexuality / Disability in Sport

- Sport's history and present are shaped by these dimensions.
  The book engages where relevant rather than treating sport
  as a neutral meritocracy:
  - **Race in sport.** The colour line and its breaking
    (Robinson, Doby, Brown, the integration of the
    SEC, Wimbledon's Black-American champion gap, women's
    soccer's racial politics, Black NBA leadership history,
    NFL coaching pipeline disparities); the book engages
    where its subject touches these.
  - **Women's sport.** Substantive coverage of women's
    professional leagues, college sport (Title IX history,
    current implementation), pay equity, media coverage
    disparities, the substantial growth of women's sport
    audiences; not added as appendix to men's-sport history
    but treated as substantial subject.
  - **Class.** Sports' relationship to social class —
    boxing / NFL / NBA's working-class pipelines, golf /
    tennis / equestrian's class gates, the cricket caste
    system, soccer's working-class roots and middle-class
    capture, NCAA "amateurism" as labour-rights issue.
  - **Sexuality.** LGBT+ athletes' history (King, Burke,
    Rapinoe, Rogers, Nassib, Griner), the contested
    timeline of out professional athletes by sport, the
    specific dynamics of women's vs men's sports on this
    issue.
  - **Disability and Paralympic sport.** Substantial
    coverage where the book's scope warrants; Paralympic
    history, classification systems, current professional /
    international development.
- Treatment of these dimensions is substantive engagement,
  not box-checking; tokenism is its own failure mode.

### MANDATORY. Injury, Health, and Exploitation Awareness

- Athletic achievement carries documented physical and
  psychological costs that the book engages with rather than
  papers over:
  - **Concussion / CTE and contact-sport brain trauma.**
    Documented in football, boxing, hockey, rugby, soccer,
    martial arts, and motorsport; pre-2010 framings often
    minimise current understanding; the book engages with
    current research where its subject involves contact
    sport.
  - **Athlete mental health.** Depression / anxiety /
    post-career identity crisis / addiction documented as
    common patterns; high-profile current athletes (Naomi
    Osaka, Simone Biles, Michael Phelps, many others)
    have raised the visibility; the book treats this as
    real rather than as career-ending personal failure.
  - **Doping and performance-enhancing drugs.** Handled with
    case-by-case evidentiary care — verified positive tests,
    criminal / civil findings, named-source admissions
    distinguished from rumour; the institutional dynamics
    (testing regimes, NSAID and asthma / TUE complications,
    the BALCO / Lance Armstrong / Russian-state-doping
    histories) acknowledged.
  - **Athlete labour and exploitation.** NCAA "amateurism"
    as documented labour-rights issue, minor-league baseball
    pay, women's professional pay disparities, soccer
    transfer / loan / development-fee structures, jockey /
    fighter / motorsport-driver labour conditions, agent
    power, name-image-likeness changes (in US college
    sport).
  - **Exploitation in extreme sport.** Sherpa labour
    conditions on Himalayan expeditions; commercial
    expedition culture's risks to client and worker;
    coastal / open-water / climbing tourism's worker /
    rescue burden on local communities.
- The "glory narrative" — pure achievement framing without
  cost — is a category failure available to mainstream
  publishing but increasingly rejected by critical readers
  and by current sports journalism.

### MANDATORY. Celebrity-and-Money Complex Awareness

- Major sport is now substantially shaped by money — TV
  rights, sponsorship, agent power, athlete endorsement, NIL
  in college, league valuation. The book engages where
  relevant:
  - **TV money and rights.** League finances driven by
    broadcast deals; the book acknowledges where this
    shapes the sporting product (scheduling, game length,
    rule changes for broadcast, etc.).
  - **Endorsement and athlete wealth.** Top athletes are
    public-figure brands; the relationship between athletic
    achievement and brand value is its own dynamic.
  - **Agent and management power.** Particularly in
    individual-athlete sports (tennis, golf, boxing, MMA)
    and in major-team-sport star-athlete careers, agents and
    management shape outcomes; the book acknowledges where
    this matters.
  - **Owner / executive power.** Team and league ownership
    decisions shape what the on-field product looks like;
    the book engages with ownership where relevant.
  - **Money's distortions.** Star-system economics, the
    minimum-vs-maximum salary gaps, the unpaid-labour
    foundation of college sport, the women's-sport pay-
    structure question.

### Additional Guardrails

- **Cliché sports writing avoided.** "Dug deep", "left it all
  on the field", "heart of a champion", "the sweet science",
  "iron will", "nerves of steel" — these phrases are
  category clichés that signal commercial-publisher writing
  rather than considered sports prose. Specific physical and
  tactical observation outsells cliché.
- **Tactical / technical detail accessible.** Sport-specific
  vocabulary defined at first use for general audiences;
  diagrams / photographs where they meaningfully illuminate;
  the gap between fan-of-the-sport reader and general reader
  bridged with care.
- **Living-vs-deceased subject ethics.** Living subjects
  carry defamation, fairness, and (where applicable)
  cooperation considerations; deceased subjects carry
  primary-source-citation, estate-cooperation, and
  historical-context standards.
- **Author positionality disclosed.** The author's
  relationship to the sport / team / figure (long-time fan,
  former player, beat reporter, occasional spectator,
  hostile critic) shapes the work and is disclosed where it
  affects the analytical lens.
- **Currency disclosure where it matters.** Player career
  trajectories, league-business arrangements, regulatory
  and rule changes evolve; the book dates analysis where
  ongoing currency matters.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Bold and dynamic for action / single-event
  / single-team narratives where the cover should signal energy
  and competition (high contrast, deep saturated single colour
  or team / sport identity colours, often with white or black
  for clarity). Restrained palettes (charcoal / cream / single
  accent) for considered biography, sports-history, and
  analytics titles where authority over excitement is the cue.
  Cooler / starker palettes (slate, white, deep blue) for
  extreme adventure / mountaineering where the natural-world
  scale dominates.
- **Typography:** Bold sans-serif (Gotham, Univers, Bebas
  Neue, Akzidenz-Grotesk) for the dominant action-led /
  single-event positioning — typography signals competition and
  energy. Substantial serif (Garamond, Adobe Caslon, Bembo)
  for biography, considered sports history, and literary sports
  writing where the typography signals book-as-considered-prose
  rather than book-as-magazine-feature. Display / hand-set
  fonts work for cultural-criticism / fan-essayist positioning.
- **Imagery:** Three dominant traditions:
  1. **Athlete / action photography** — the figure or
     defining moment captured in motion or in a charged
     posed image. The most common form for biography,
     single-event, and athlete-memoir titles. The image is
     often the book's promise — "this is the figure / moment
     / story you came for."
  2. **Landscape / environment** — for mountaineering,
     extreme adventure, and place-anchored sports narrative
     (the mountain, the ocean, the pitch / court / track as
     character). Strong for expedition narrative where the
     environment is the antagonist or partner.
  3. **Pure typography or symbolic-object** — for analytics,
     sports-history, fan-cultural-criticism, and literary
     sports writing where the prose is the draw rather than
     the visual hook. Often the strongest choice for
     considered work.
- **Mood:** Competence and consequence. The cover should
  signal "this book takes the sport seriously" — not
  "trade paperback puff-piece" (commercial pulp register),
  not "fanboy hagiography" (uncritical-celebration register).
  Restraint and design literacy outsell shouting.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Single Sport / Team / Season Deep Dive | Action photography of pivotal moment OR team-context image; bold sans-serif typography; team / sport identity colours appropriate; subtitle clarifies the season / team / angle |
| Athlete Memoir / Autobiography | Subject portrait (often a defining or contemplative image rather than action); large name typography (the brand); subtitle sometimes "An Autobiography" / "A Memoir" / specific framing |
| Athlete Biography (third-person) | Subject portrait (often archival / iconic image) OR symbolic-object cover; substantial serif typography; subtitle establishes the angle ("The Years of...", "An Intimate Portrait", "The Definitive Biography") |
| Mountaineering / Extreme / Adventure | Landscape / environment as dominant imagery (mountain, polar, ocean, route); restrained palette signalling scale; substantial typography; subtitle clarifies the expedition / journey ("The 1996 Everest Disaster", "Solo Across the Atlantic") |
| Sports History / Sports Culture | Often archival imagery or iconic moment from the era; warmer palette appropriate to the period; serif typography signals considered historical work; subtitle establishes the era / theme ("Race, Power, and the Game", "The Year That...") |
| Sports Analytics / Business / Industry | Often pure typography or design-led; clean sans-serif palette; restrained imagery (data visualisation, abstract iconographic); subtitle clarifies the analytical thesis ("How..." / "Why..." / "The Hidden..." / "The Inside Story Of...") |
| Fan / Cultural / Critical Writing | Closer to essay-collection cover language; pure typography or single resonant image; warmer palette; subtitle establishes the cultural-criticism mode ("Essays on...", "A Fan's...", "Watching...") |

### Typography Rules

- **Title:** 30–55% of cover area depending on whether image-led
  (smaller) or typography-led (larger). Sports-narrative titles
  range from descriptive ("Moneyball", "Open", "Into Thin
  Air") to evocative ("Boys of Summer", "Ghosts of Manila",
  "King of the World") to subject-name ("Sandy Koufax",
  "Clemente"). All work; the title must read at thumbnail.
- **Subtitle:** Often essential — does the descriptive work.
  "The Art of Winning an Unfair Game" (Moneyball subtitle).
  "A Personal Account of the Mt. Everest Disaster" (Into Thin
  Air subtitle). "A Hero's Life" (Maraniss on Clemente).
  Specific subtitle outsells vague subtitle.
- **Author name:** Larger for established sports-writer brands
  (Halberstam, Lewis, Krakauer, Maraniss, Leavy, Pearlman);
  smaller for unestablished authors with credentials in
  subtitle ("by the [Publication] columnist", "by an
  Olympic gold medallist"). Author qualification cues
  (former player / coach, beat reporter, distinguished
  sports journalist) shape this category's reader trust.
- **Series mark and edition:** Sports-publishing imprints
  (Bantam Sports, Sports Publishing, Triumph Books for
  team / fan publishing; Crown / Random House for major
  literary sports work; Bloomsbury for international
  sports) — these signal positioning. Updated editions
  for biographies of still-active careers, and for sports-
  business books where the regulatory / financial landscape
  has shifted, are common.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Single Sport / Team / Season Deep Dive | Kindle Store > Kindle eBooks > Sports & Outdoors > [Specific Sport: Baseball / Football / Basketball / Soccer / Hockey / etc.] > History (or General per book's focus) |
| Athlete Memoir / Autobiography | Kindle Store > Kindle eBooks > Biographies & Memoirs > Sports & Outdoors (with Sports & Outdoors > [Specific Sport] > Players as secondary) |
| Athlete Biography (third-person) | Kindle Store > Kindle eBooks > Biographies & Memoirs > Sports & Outdoors (with Sports & Outdoors > [Specific Sport] > Players as secondary; same primary as memoir but reader self-selects via "by the author" vs "by the subject") |
| Mountaineering / Extreme / Adventure | Kindle Store > Kindle eBooks > Sports & Outdoors > Outdoor Recreation > Hiking & Camping > Mountaineering (with Biographies & Memoirs > Travelers & Explorers as secondary) |
| Sports History / Sports Culture | Kindle Store > Kindle eBooks > Sports & Outdoors > Miscellaneous > History (with Politics & Social Sciences > Social Sciences > Sociology > Sports & Recreation as secondary for cultural-history positioning) |
| Sports Analytics / Business / Industry | Kindle Store > Kindle eBooks > Business & Money > Industries > Sports & Entertainment (with Sports & Outdoors > Coaching > Statistics for analytics-led titles) |
| Fan / Cultural / Critical Writing | Kindle Store > Kindle eBooks > Sports & Outdoors > Miscellaneous (with Literature & Fiction > Essays & Correspondence > Essays as secondary for essay-collection-style fan / cultural writing) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Specific sport — baseball | Kindle Store > Kindle eBooks > Sports & Outdoors > Baseball |
| Specific sport — football (NFL) | Kindle Store > Kindle eBooks > Sports & Outdoors > Football (American) |
| Specific sport — basketball | Kindle Store > Kindle eBooks > Sports & Outdoors > Basketball |
| Specific sport — soccer | Kindle Store > Kindle eBooks > Sports & Outdoors > Soccer |
| Specific sport — hockey | Kindle Store > Kindle eBooks > Sports & Outdoors > Hockey |
| Specific sport — golf / tennis / cricket / rugby / boxing / etc. | Kindle Store > Kindle eBooks > Sports & Outdoors > [Specific Sport] |
| Olympic / international | Kindle Store > Kindle eBooks > Sports & Outdoors > Olympics & Paralympics (or > Other Team Sports > International) |
| Coaching | Kindle Store > Kindle eBooks > Sports & Outdoors > Coaching > [Specific Sport] |
| Sociology of sport | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Sociology > Sports & Recreation |
| Cultural-history crossover | Kindle Store > Kindle eBooks > History > World > [Specific Era] for sports-history at era-defining scope |

### Keyword Recommendations

- The specific sport (named as the sport's audience names it)
  ("baseball", "NFL football", "Premier League soccer",
  "tennis", "golf", "boxing", "MMA", "cycling", "Formula 1",
  "mountaineering")
- The specific team / figure / event
  ("Boston Red Sox", "Chicago Bulls dynasty", "Tom Brady",
  "Serena Williams", "Lionel Messi", "1980 Miracle on Ice",
  "Tour de France", "Everest")
- The angle / mode
  ("sports biography", "athlete memoir", "sports history",
  "sports analytics", "behind the scenes", "championship
  narrative", "expedition account")
- Era / period markers
  ("the 1990s NBA", "1970s baseball", "post-war football",
  "modern era", "the steroid era")
- Comparable author / brand for discoverability
  (readers of David Halberstam, readers of Michael Lewis,
  readers of Roger Angell, readers of Jon Krakauer, readers
  of Andre Agassi)
- Sport-specific terminology where it signals serious
  audience
  ("sabermetrics", "tactical analysis", "advanced stats",
  "Moneyball-style", "run-pass option", "tiki-taka")
- Avoid generic "sports" / "athlete" / "champion" in
  isolation — they drown in algorithmic noise; prefer
  compound phrases combining specific-sport + team-or-figure
  + angle
- Avoid cliché framings ("greatest of all time", "the inside
  story of triumph", "against all odds", "heart of a
  champion") — they signal commercial-pulp positioning and
  damage credibility with the readers serious sports
  narrative needs to attract
