---
name: coherence-function-consecutive
description: "Engine-neutral binding/protocol. Per-project mechanical scan flagging consecutive chapters that serve the same argumentative (NF) / dramatic (fiction) function. Closes the second gap in the canon-validation framework Wave 4 sequence (v2.7.31). Class A bash audit invoked under the COHERENCE domain, backed by a Class C engine-protocol convention: brief authors declare each chapter's function via a <!-- Function: <value> --> HTML comment. Backwards-compat: missing declarations report as WARN, not FAIL."
version: "2.7.31"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Same-Function-Consecutive Audit

A binding/protocol spec for the COHERENCE domain (per
`canon-validation-taxonomy.md`). Closes the second gap in the
Wave 4 audit-additions sequence (gap-analysis row 2).

## Why this exists

Every chapter in a manuscript serves a function — a job it
does for the larger structure. In non-fiction, this is the
*argumentative function*: thesis-statement, evidence-build,
counter-argument, case-study, synthesis, application,
transition, recap, etc. In fiction, this is the *dramatic
function*: setup, inciting-incident, rising-action, midpoint-
pivot, complication, climax-prep, climax, falling-action,
denouement, transitional-bridge, etc.

Two consecutive chapters that serve the same function fail
the reader in a recognisable way:

- **Non-fiction**: chapter 5 is evidence-build for the central
  thesis; chapter 6 is also evidence-build for the same thesis.
  The reader thinks "we already saw this; why are we still
  building?" Momentum drops; the manuscript reads as padding.
- **Fiction**: chapter 5 is setup of the next plot turn; chapter
  6 is also setup. The story stalls; tension dissipates.
- **Either**: chapter 5 is recap; chapter 6 is recap. The
  reader skims forward looking for new material.

The fix at chapter-brief time is one revision: re-target
chapter 6 to a different function (or, if structurally required,
document the intent explicitly). The cost at draft time is a
chapter rewrite. The audit catches the duplication at brief
time when the cost of a fix is lowest.

## Detection model

v2.7.31 ships a **mechanical adjacency check**, not a semantic
function-classification audit. Brief authors declare each
chapter's function explicitly; the audit reads the
declarations and flags adjacent duplicates.

The convention (Class C engine-protocol):

```
<!-- Function: <value> -->
```

Authored as an HTML comment somewhere in the chapter brief.
Case-insensitive on "Function". The value is drawn from the
canonical function list for the engine (see below).

The bash audit (`scripts/coherence-function-consecutive.sh
<project_root>`):

1. Globs `engine-data/chapter-briefs/ch*-brief.md` in chapter
   order (lexical sort = numerical sort because of zero-padded
   chapter numbers, ch01..ch99)
2. Per brief, extracts the Function declaration via the canonical
   regex (whitespace-trimmed)
3. Builds an ordered chN → function ledger
4. For each adjacent pair (i, i+1) where both have declared
   functions, flags any pair where the values match
5. Briefs missing the declaration are reported as WARN
   (informational; not a FAIL — backwards-compat with projects
   authored before v2.7.31)

What the audit catches:

- Two consecutive chapters declared with the same function

What the audit does NOT catch (deferred):

- Two non-adjacent chapters with the same function (often
  legitimate; e.g. two evidence chapters separated by a
  counter-argument is fine)
- Function-mislabelling (a chapter declared as "synthesis" but
  actually doing "case-study"; would require Class B semantic
  classification)
- Justified adjacent duplicates (a paired evidence sequence
  delivering one extended argument across two chapters); for
  v2.7.31 these are flagged as FAIL and the writer documents
  the choice. A future release may add an inline silencing
  comment (e.g. `<!-- Function: evidence-build [paired:1] -->`)
  if false-positive rate proves intrusive.

## Canonical function lists

These are the recommended values for the `<!-- Function: ... -->`
declaration. The audit does NOT reject unknown values — it only
checks adjacency-equality — so writers may extend the lists for
their own conventions. The canonical lists exist to give brief
authors a shared vocabulary.

**Non-fiction (argumentative function):**

- `thesis-statement` — sets up or refines the central argument
- `evidence-build` — empirical or expert support for the thesis
- `case-study` — extended single-case illustration
- `counter-argument` — engages opposing positions
- `synthesis` — combines evidence streams into a structural claim
- `application` — actionable consequences for the reader
- `historical-context` — situates the argument in time
- `transition` — bridges between two argumentative arcs
- `recap` — restates earlier ground for clarity
- `framing` — methodology, scope, or definitional set-up

**Fiction (dramatic function):**

- `setup` — establishes a state or relationship the plot will disturb
- `inciting-incident` — the disturbance that begins the active plot
- `rising-action` — escalation of stakes or conflict
- `midpoint-pivot` — the structural turn that re-orients the second half
- `complication` — a new obstacle that compounds existing pressure
- `subplot-advance` — moves a non-primary thread forward
- `climax-prep` — gathers forces / stakes for the climactic confrontation
- `climax` — the central confrontation or revelation
- `falling-action` — consequences play out
- `denouement` — final resolution / new equilibrium
- `transitional-bridge` — connects two structural arcs
- `character-arc-pivot` — turns a character's internal arc

## Invocation

Class A mechanical script invoked by the `/validate` dispatcher
under the COHERENCE domain. Direct invocation:

```bash
scripts/coherence-function-consecutive.sh <project-root>
```

Exit codes:

- `0` — no adjacent-function duplicates (briefs with declarations
  are all distinct from neighbours; missing-field briefs surface
  as WARN but not failure)
- `1` — one or more adjacent-function duplicates detected
- `2` — usage / file-not-found error / no chapter-brief files

Output (stdout):

```
=== COHERENCE: same-function-consecutive ===
Project: /path/to/project

Chapter function ledger:
  ch01 : thesis-statement
  ch02 : evidence-build
  ch03 : evidence-build
  ch04 : counter-argument

ADJACENT-FUNCTION DUPLICATES (1):
  FAIL: ch02 + ch03 : both "evidence-build"

[FAIL] 1 adjacent-function duplicate(s) detected
```

Dispatcher class: `PROJECT_ONCE`. Runs once per dispatcher
invocation regardless of chapter scope (the check is project-
wide by definition; per-chapter level still triggers it for
visibility into the COHERENCE domain).

## How writers should respond to FAILs

The audit is a signal, not a verdict. Three reasonable responses:

1. **Re-target the second chapter.** The default fix. Identify
   the second chapter's actual contribution beyond what the
   first already delivers; choose a different function value
   that names that contribution.
2. **Re-order the chapters.** Sometimes the duplication signals
   that two chapters should not be adjacent — a
   counter-argument or transition belongs between them.
3. **Document the intent.** Paired evidence-build sequences,
   call-and-response chapters, deliberate echoes for thematic
   weight — these are craft choices, not bugs. Document the
   pairing in the brief and treat the audit flag as informational.

The audit does not block phase advancement. It is shipped at
`exit 1` (FAIL) so the dispatcher's PASS/FAIL aggregation
surfaces it visibly, but the writer's call on intent is final.

## How to adopt the convention on existing projects

For projects authored before v2.7.31, briefs do not yet have
the `<!-- Function: ... -->` declaration. Two adoption paths:

1. **Forward-only.** New chapters get the declaration; old
   chapters surface as WARN in every audit run. Acceptable on
   nearly-complete projects.
2. **Backfill.** Open each existing brief; identify the function
   from its content; add the declaration. The audit then runs
   cleanly across the full manuscript.

The audit treats missing declarations as WARN (not FAIL)
specifically to allow forward-only adoption.

## Engine-neutral applicability

Both fiction and non-fiction declare chapter function via the
same convention; the canonical function lists differ by engine
(non-fiction: argumentative; fiction: dramatic). The audit
script is engine-neutral — it does not validate the value
against either canonical list, so the same script + spec serve
both engines identically.

## Failure modes prevented

The Silent-Failure Audit catalog (`silent-failure-audit.md`)
tracks the engine's drift-failure shapes. This audit prevents:

- **Adjacent-function-duplicate cascade** — momentum loss,
  perceived padding, reader skim. Caught at brief time when
  the cost of a fix is one brief revision rather than a
  chapter rewrite.
- **Validation-coverage misrepresentation** — without this
  audit, the COHERENCE domain has only the Bible Coverage Audit
  (which doesn't check chapter function). With it, COHERENCE
  reports COVERED for the same-function-consecutive sub-domain;
  leitmotif tracking is the remaining COHERENCE gap (queued
  for v2.7.33).

## See also

- `canon-validation-taxonomy.md` — the 10-domain index this
  audit closes a gap in (COHERENCE primary-domain table)
- `validate-dispatcher.md` — the `/validate` dispatcher that
  invokes this audit at architecture / brief / full level
- `silent-failure-audit.md` — catalog of drift-failure shapes;
  this audit adds row 27
- `core-pipeline.md` step 5 — the brief-authoring step where
  the Function declaration convention is introduced
- `outline-conformance.md` — the existing OC HARD GATE that
  runs at step 5a; coherence-function-consecutive is
  complementary, not overlapping (OC checks brief vs Bible;
  this audit checks adjacent briefs vs each other)
- `scripts/coherence-function-consecutive.sh` — the bash audit script
