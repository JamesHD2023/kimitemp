---
name: literary-nonfiction-category
description: "Category-specific instructions for literary and creative non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Literary Non-Fiction. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | literary-nonfiction |
| Display Name | Literary Non-Fiction |
| Parent Group | Literature & Fiction > Essays & Correspondence (and cross-listed with the relevant subject category — Memoirs, Travel, Politics & Social Sciences, etc., per the book's mode) |
| Typical Word Count | 60,000–110,000 (lyric / fragmented work often shorter at 50,000–70,000; long-form narrative non-fiction and immersion-journalism often 80,000–130,000; literary memoir 60,000–90,000) |
| Default Structure | Variable and often experimental — sustained narrative, braided structure, lyric / fragmented form, essay-cycle; the through-line is literary-prose-as-primary-value rather than a single structural template; scene as the fundamental unit even when ideas are abstract; author's subjectivity as feature not bug |
| Citation Style | Endnotes for factual specifics (verifiable claims about events, people, sources) — formal in-text citation typically avoided as it disrupts literary prose; bibliography appended; named sources for interviews where they appear in narrative; composite-character / time-compression / reconstructed-dialogue conventions disclosed in author's note |
| Audience Baseline | Literary-prose-comfortable reader who buys for sentence-level craft as much as for subject; willing to follow formal experimentation; familiar with the genre's conventions (the New Journalism inheritance, the lyric-essay tradition, the braided-form contemporary moment); often the same reader who buys literary fiction |
| Comparable Titles | Joan Didion (*Slouching Towards Bethlehem*, *The Year of Magical Thinking*), Truman Capote (*In Cold Blood*), Norman Mailer (*The Executioner's Song*, *The Armies of the Night*), John McPhee (*Coming into the Country*, *Annals of the Former World*), Tom Wolfe (*The Right Stuff*, *The Electric Kool-Aid Acid Test*), Susan Orlean (*The Orchid Thief*, *The Library Book*), Janet Malcolm (*The Journalist and the Murderer*), Katherine Boo (*Behind the Beautiful Forevers*), Adrian Nicole LeBlanc (*Random Family*), Maggie Nelson (*The Argonauts*, *Bluets*), Eula Biss (*Notes from No Man's Land*, *Having and Being Had*), Leslie Jamison (*The Empathy Exams*, *Splinters*), Alexander Chee (*How to Write an Autobiographical Novel*), Hilton Als (*White Girls*), Olivia Laing (*The Lonely City*), Geoff Dyer (*Out of Sheer Rage*, *But Beautiful*), Sigrid Nunez (*Sempre Susan*), Hua Hsu (*Stay True*), Patricia Lockwood (*Priestdaddy*) |

## Subcategory Options

When the user selects Literary Non-Fiction, prompt for subcategory
refinement based on the book's primary mode:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| narrative-nonfiction | Narrative Non-Fiction | True events told with novel-quality prose; the New Journalism / Capote / McPhee / Wolfe / Orlean / Boo lineage; sustained narrative is the form | Sustained chronological or braided narrative; scene as the dominant unit; named protagonists across the book's arc; immersive reportage providing the material; novel-form techniques (scene, dialogue, character interiority where verifiable) applied to factual content |
| immersion-reportage | Immersion Journalism / Reportage | The author embeds in a community / institution / situation for sustained period and reports from within; the LeBlanc / Boo / Mehta / Ehrenreich lineage | Long-form embedded research as the spine; named subjects appearing across chapters; ethnographic patience; the author present as observer-and-sometimes-participant; ethical relationship with subjects often itself a subject |
| literary-memoir | Literary Memoir | Memoir written with literary-prose ambition rather than pure narrative-arc service; the Argonauts / How to Write an Autobiographical Novel / Stay True / Priestdaddy / Sempre Susan tradition | Memoir conventions (memoir.md template) plus higher prose-craft expectations; structural choices often departing from chronological convention; the author's consciousness as instrument rather than just narrator; subject-and-form often inseparable |
| lyric-essay-fragmented | Lyric Essay / Fragmented Form | Formal experimentation as the mode — fragment, list, montage, lyric prose, hybrid-with-poetry; the Carson / Nelson / Renata Adler / Lockwood-of-No-One-Is-Talking lineage | Form is content; each piece's structure is part of its meaning; conventional argument and chronology often refused; section breaks and white space as deliberate compositional choices; the boundary between essay and prose-poem permeable |
| braided-hybrid | Braided / Hybrid Form (memoir + essay + reportage) | Books that move between memoir, essay, and reportage modes — the Biss / Jamison / Als / Laing-on-The-Lonely-City / Solnit-at-her-literary lineage | Mode-shift across chapters or within chapters; subject-led structure pulling memoir / essay / reportage as it needs them; the braiding itself is part of the book's argument; per-mode evidentiary standards apply when each mode is in use |
| literary-criticism-as-art | Literary Criticism as Art | Essays on literature, writers, books written with literary-prose ambition — the Dyer-on-Lawrence / Laing-on-Hopper / Wood-of-The-Nearest-Thing-to-Life / Lesser tradition; criticism that is itself literature | Subject-author or subject-work chapter spine; close reading as core craft technique; the critic's own consciousness present as instrument; literary-prose register throughout; cross-references essay-collection and art-culture categories |
| cross-form-experimental | Cross-Form / Experimental | Books that resist conventional categorisation — the Lerner / Heti / Knausgård / Cusk in non-fiction mode / autofiction-adjacent territory; the boundary between fiction and non-fiction deliberately permeable | Conventional category labels resisted; structural and formal innovation central; subject and form inseparable; reader expected to engage with the book on its own terms rather than against genre expectations |

**Default:** If the user does not specify, prompt for the book's mode
(sustained narrative-nonfiction / immersion-reportage / literary-memoir
/ lyric-essay / braided-hybrid / literary-criticism / cross-form-
experimental) and select accordingly; fallback to `narrative-nonfiction`
for unclear cases (the most-published mode in trade literary publishing).

## Structural Architect Instructions

```
STRUCTURE
- Literary craft takes precedence over information delivery
- Structure is variable and often experimental: braided, fragmented, sustained narrative
- Fiction techniques applied to factual material: scene, character, dialogue, metaphor
- Each section must earn its literary ambitions. prose without substance fails

BEATS PER CHAPTER
1. Scene Beat. vivid, present-tense-feeling moment that grounds the reader
2. Reflection Beat. the author's analytical or emotional response to the material
3. Research Beat. factual information woven into the narrative (never dumped)
4. Connection Beat. link between the personal and the universal
5. Resonance Beat. an image, phrase, or idea that echoes across the manuscript

CATEGORY ARCHITECTURE
- Scene is the fundamental unit. even abstract ideas are rendered through concrete moments
- The author's subjectivity is a feature, not a bug. the reader sees through a specific lens
- Form should serve content. experimental structure must illuminate, not obscure
- Facts remain facts even within literary framing. accuracy obligations persist

FORBIDDEN
- Literary technique used to fabricate or distort facts
- Purple prose without substance (style over content)
- Formal experimentation that obscures meaning for its own sake
- Presenting the author's interpretation as objective truth without acknowledgement
- Ignoring accuracy obligations because "it's literary"
```

## Content Writer Craft Rules

```
VOICE & TONE
- Literary, precise, often personal. the author's consciousness is the instrument
- Sentence-level craft matters more here than in any other non-fiction category
- Varied rhythms: short declarative for impact, long flowing for immersion, fragments for disruption
- Show, don't tell. even in non-fiction, dramatise rather than summarise

EVIDENCE STANDARDS
- Facts embedded in narrative, not presented as data
- Sources woven into prose rather than formally cited (endnotes for specifics)
- The author's observation and experience is a valid evidence category
- When writing about real people and events, accuracy is non-negotiable

PROSE STANDARDS (HIGHEST BAR)
- Every sentence must earn its place
- No filler paragraphs, no transitional padding
- Metaphors must be original and precise
- Rhythm varies deliberately. monotony is a prose failure

PROSE RHYTHM MAPPING
- Ch 1 hook: prose IS the hook. the quality of the writing is the reason the reader stays, same as literary fiction
- Sentence length: varied and deliberate (15-28 words range). the literary nonfiction writer controls rhythm as a musician controls tempo
- High metaphor density from the opening page: original, precise, earned metaphors that illuminate rather than decorate
- Deep observation: the author's consciousness is the instrument; what they notice and how they render it IS the content
- Tension ≥4 from chapter 1. aesthetic tension: the reader must feel that this prose is doing something that ordinary nonfiction cannot
- Short declarative sentences for impact and disruption; long flowing sentences for immersion and accumulation; fragments for rupture
- Show, don't tell. even in nonfiction: dramatise through scene, render through image, discover through observation
- Evidence integration is invisible: facts embedded in narrative prose, sources woven into the texture of the writing
- Every sentence must earn its place. no filler paragraphs, no transitional padding, no throat-clearing
- Paragraph rhythm follows the content's emotional logic, not the information's logical sequence
- The "why should I read this book" question is answered by the prose itself: this writing rewards attention at the sentence level
- Reader engagement is sustained by the quality of perception: the reader sees the world differently through the author's eyes
- Authority delivery through craft: the writer earns trust not by citing credentials but by demonstrating mastery of observation and language
- Formal experimentation serves content: braided narratives, fragmented structures, lyric passages all earn their place by illuminating meaning
- Deploy present-tense immediacy and past-tense reflection as complementary rhythms within the same chapter
- The author's subjectivity is a feature: the reader sees through a specific lens, and the lens itself is part of the subject
- Resonance across the manuscript: images, phrases, and ideas planted early return later with accumulated meaning
- Chapter endings aim for resonance, not resolution. an image that lingers, a question that deepens, a silence that speaks
```

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Prose-craft at the highest standard | Sentence-level care evident on every page; original metaphors (not borrowed clichés); deliberate rhythm variation (short declarative for impact, long flowing for accumulation, fragments for rupture); the prose rewards attention as literary fiction does |
| 2 | Factual accuracy maintained within literary framing | All factual claims (events, people, dates, statistics, attributed quotes) accurate to the verifiable record; literary technique never licenses fabrication; the literary-NF scandals (Frey, Lehrer, Daisey, JT LeRoy) all turned on this single failure |
| 3 | Scene-to-summary ratio appropriate | More scene than summary — the genre's signature is dramatised moment, observation, sensory specificity rendered with novel-form techniques rather than information delivery; chapters that tell rather than show fail the genre |
| 4 | Hybrid-form mode shifts handled honestly | Where the book moves between memoir, essay, reportage, criticism modes, each mode's evidentiary standards apply when in use; the reader can recognise which mode they are reading; modes are not silently conflated to smuggle one mode's authority into another |
| 5 | Author's subjectivity acknowledged not hidden | The author's consciousness is part of the book's content (the lens IS the subject); positionality, personal investment, ideological lens visible to the reader; "view from nowhere" framings rejected in favour of acknowledged perspective |
| 6 | Composite / time-compressed / reconstructed material disclosed | Where scenes have been composited from multiple events, where time has been compressed for narrative shape, where dialogue has been reconstructed from memory or from witnesses, the methodology is disclosed (typically in author's note); literary craft does not license invisible editorial intervention in factual material |
| 7 | Form serves content (not form for form's sake) | Formal experimentation — fragment, braid, lyric, hybrid — illuminates the subject rather than performing the author's craft credentials; obscurity in service of meaning differs from obscurity-as-style; the reader who works through the form is rewarded with meaning that simpler form could not have delivered |
| 8 | Real people represented fairly | Where the book engages with identifiable real people, the same fairness standards as biography apply; consent considerations for vulnerable subjects; defamation considerations for living subjects; care with subjects encountered through immersion-reportage who may not have understood their relationship would become a published book |
| 9 | Sources verifiable for the reader who looks | Endnotes, bibliography, or author's note allow the reader who wants to verify factual claims to do so; sources do not need in-text citation interrupting the prose, but they must be inspectable; "trust me, this is true" without verifiability is below the genre's contemporary standard |
| 10 | The prose justifies its literary ambition | Beautiful writing about nothing is still nothing; the literary techniques deployed must serve subject, argument, and meaning; books that perform literary-NF style without earning it through observation, thought, or material fail the discerning reader the genre depends on |

## Source Requirements

### Mandatory Source Types — Per Mode

Source requirements vary by which mode the book is in (or which mode
a particular section is in for braided / hybrid books); the literary
register does not relax the underlying evidentiary standards:

- **Narrative non-fiction and immersion reportage.** Same standards
  as investigative journalism: named sources where consented;
  triangulation of contested claims; primary documentation cited
  in endnotes; substantial reporting time on the ground; the
  scene-and-character techniques borrowed from fiction operate on
  factual material that meets reportage's evidentiary requirements.
  Capote's *In Cold Blood* established the form; LeBlanc's *Random
  Family* and Boo's *Behind the Beautiful Forevers* set current
  best-practice for sustained immersion.
- **Literary memoir.** Memoir conventions apply (memoir.md
  Source Requirements): the author's lived experience as primary
  source; personal artefacts; family / friend / witness accounts;
  public records for verifiable details; acknowledgement of memory
  limits; composite-character / time-compression / reconstructed-
  dialogue disclosure.
- **Lyric / fragmented essay.** The form's evidentiary expectations
  are calibrated to its mode — observed world rendered honestly,
  invented material flagged or so clearly fictional in form that
  no reader is misled, the author's lived experience is real
  experience treated honestly. Lyric license is part of the form
  but does not license fabrication of fact.
- **Braided hybrid.** The most demanding mode — each mode's
  standards apply when in use. The memoir sections meet memoir
  standards; the reportage sections meet reportage standards; the
  essay sections meet essay-collection standards; the literary-
  criticism sections meet art-culture / criticism standards. The
  braiding does not relax any individual mode's requirements.
- **Literary criticism as art.** Cultural-criticism / art-culture
  standards apply: specific works cited precisely; close reading
  of works rather than impression; engagement with prior critical
  conversation; the critic's analytical position made visible.
- **Cross-form / experimental.** Where the book deliberately
  destabilises the fiction / non-fiction boundary, the relationship
  to factual material must be made knowable to the reader (front
  matter, author's note, jacket positioning); books that
  systematically blur the boundary while implying factual
  authority enter the same territory as the literary-NF
  scandals.

### Source Freshness

- **Literary non-fiction is durable.** The genre's foundational
  works (Capote, Mailer, Didion, McPhee from the 1960s–80s; the
  Granta-and-New-Yorker tradition through 1990s; the lyric-essay
  / braided-form contemporary moment from 2000s) age well because
  the prose-craft and observational substance outlast the
  specific subjects.
- **Subject-bound currency varies.** Books on contemporary
  technology, politics, or current-affairs subjects within
  literary-NF inherit those subjects' currency demands; a
  literary-NF book on a 2010s technology platform may read as
  period document a decade later.
- **Reception and critical conversation evolves.** Critical
  conversation around major literary-NF works (the In-Cold-
  Blood / Capote-fabrication question; the In-the-Freud-Archives
  / Malcolm controversy; the recent autofiction-and-memoir
  boundary debates) shapes how new work is received and reviewed.
- **Identity-representation conventions have shifted.** Pre-2010
  literary-NF often handled marginalised-community subjects
  with framings (objectifying, exoticising, speaking-for) that
  read poorly now; current standards expect more voice-from-
  inside-the-subject-community, more positionality awareness.
- **Re-issued classics warrant new framing.** Re-issues of
  foundational literary-NF often add new introductions that
  contextualise the work for current readers — what's held up,
  what the original reception missed, what the book's reception
  has revealed about its moment.

### Attribution Standards

- **Endnotes and bibliography mandatory.** The literary-prose
  register avoids in-text citation that would interrupt the
  reading experience; endnotes (often substantial, often
  conversational) carry the citation apparatus; bibliography
  appended for serious works.
- **Named sources where consented.** Subjects of immersion
  reportage and interview material named where consent has been
  given; pseudonyms or anonymisation where requested or where
  publication might harm subjects; the choice noted.
- **Author's note up-front about methodology.** Substantial
  author's-note covering: the relationship to the subjects;
  the duration and nature of the reporting / observation;
  the use of composite characters where applied; time
  compression where applied; reconstructed dialogue
  protocols; access bargains and what they allowed or
  precluded.
- **Distinguish: observed / told / read / reconstructed /
  composited.** "I watched the riot from the corner..."
  (observation). "Maria told me..." (interview). "Court
  records show..." (research). "What was said over those
  hours can only be reconstructed from witnesses..."
  (reconstruction, with witness sourcing). "I have rendered
  Joe as a composite of three of the men I came to know..."
  (composite, disclosed). Each register signals the
  evidence's nature.
- **Author positionality disclosed.** The author's relationship
  to the subjects, to the place, to the community, to the
  political position represented — disclosed in front matter
  or author's note; the reader calibrates the lens.
- **What is NOT acceptable.** Inventing scenes, characters,
  events, quotes. Compositing without disclosure. Changing
  identifying details so substantially that the subject's
  actual context is altered, without disclosure. Using the
  literary register to obscure factual fragility. Claiming
  reportage authority for material that is actually memory
  / reconstruction / inference. The pattern of literary-NF
  scandals across decades all involve some version of these
  failures.

## Category-Specific Guardrails

### MANDATORY. Factual Material Remains Factual (the literary-NF contract)

- The genre's foundational contract: literary technique enhances
  the rendering of factual material, never licenses fabrication
  of fact. The literary-NF scandals of the past 30 years have
  mostly turned on this single failure — Frey's *A Million
  Little Pieces*, Lehrer's invented Dylan quotes, Daisey's
  fabricated Apple-factory scenes, JT LeRoy's invented
  identity, Stephen Glass's invented sources, the
  Janet-Cooke-as-precursor case. Each used the literary register
  to obscure that the underlying material was not what it
  presented itself as.
- Specific requirements:
  - **Verifiable factual claims accurate.** Events, dates, named
    people, quoted speech, statistics, attributions — accurate
    to the verifiable record.
  - **Reconstructed material flagged.** Scenes the author did
    not witness; dialogue from memory of conversations the
    author was not party to; events known only through
    second-hand testimony — disclosed in author's note where
    they form substantial portions of the book.
  - **Composite characters disclosed.** Where one rendered
    person stands for several real people, the composite is
    disclosed (typically in author's note) and the rendering
    is honest about the consolidation.
  - **Time compression disclosed.** Where events from weeks
    or months are rendered as occurring over a shorter
    period, or vice versa, disclosed.
  - **Quotation accuracy.** Direct quotation reproduces what
    was actually said (per recording, transcript, or careful
    memory of the speaker who can be checked); paraphrase
    distinguished from quotation.
- The literary register is a tool for rendering factual
  material more vividly, not a license to make it up.

### MANDATORY. Hybrid-Form Honesty

- Many literary-NF books move between modes — memoir + essay +
  reportage + criticism in shifting balance. Each mode carries
  its own evidentiary standards, and those standards apply
  whenever the book is in that mode:
  - **Memoir sections:** memoir.md standards (memory honesty,
    other-person fairness, vulnerability, transformation arc
    where applicable).
  - **Reportage sections:** investigative-journalism /
    biography standards (named sources, triangulation,
    primary-document grounding, fairness to subjects).
  - **Essay sections:** essay-collection standards
    (per-essay structural integrity, voice consistency,
    evidence per essay's mode).
  - **Criticism sections:** art-culture / cultural-criticism
    standards (close reading of works cited, interpretation
    framed as interpretation, prior critical conversation
    engaged with).
- The book is honest about which mode it is in at any given
  point. Smuggling reportage authority into memoir-style
  rendering, or memoir-style emotional license into reportage
  obligations, is a category-defining failure. The reader who
  cannot tell which mode they are reading is being misled
  about the book's evidentiary basis.
- Mode shifts can be marked subtly (a section break, a
  pronoun change, a register shift) but they are recognisable
  to the careful reader.

### MANDATORY. Real People Represented Fairly

- Where the book engages with identifiable real people, the
  same fairness standards as biography and immersion-journalism
  apply, regardless of the literary register:
  - **Defamation considerations** for living subjects.
    Statements of fact that damage reputation must be
    defensible — true, fairly framed opinion, or fair comment
    on matters of public interest.
  - **Consent considerations** especially for vulnerable
    subjects encountered through immersion-reportage who
    may not have understood their relationship would become
    a published book — children, people in extremis,
    marginalised-community subjects, people in dependent
    relationships with the author. The Janet Malcolm
    *Journalist and the Murderer* essay remains the
    foundational engagement with this issue.
  - **Identification care.** Anonymisation must actually
    anonymise — changing a name does not anonymise if other
    details (job, location, distinctive history, photographic
    description) make the person identifiable to anyone who
    knows them.
  - **Composite-character disclosure** when used.
  - **Right of reply considerations.** Where the book makes
    contestable claims about identifiable living people,
    consideration of approaching them for response prior to
    publication is the standard.
- The literary-NF tradition includes some of the most ethically
  fraught work in non-fiction (Mailer's *Executioner's Song*
  involved a death-row subject; LeBlanc's *Random Family*
  involved a marginalised-community subject across decades;
  Boo's *Beautiful Forevers* involved Mumbai slum residents);
  the careful tradition handles this with extensive author's-
  note transparency about the relationships and the consent
  bargains.

### MANDATORY. Subjectivity Acknowledged Not Hidden

- Literary non-fiction is built on the author's consciousness
  as instrument — what the author notices, how they render it,
  what lens they bring is part of the book's content. The
  "view from nowhere" framing, where the author pretends to
  neutral observer status, is rejected by the genre's
  contemporary practice.
- Specific requirements:
  - **Author present in the prose** where their presence
    materially shapes the rendering (the immersion reporter's
    relationship to subjects; the memoirist's interiority;
    the critic's analytical position; the lyric-essayist's
    perceptual signature).
  - **Positionality disclosed.** The author's relationship to
    the subject, the community, the place, the political /
    cultural position represented — visible to the reader
    rather than effaced.
  - **Personal investment named.** Where the author has a
    stake in the subject (personal connection, financial
    interest, political commitment, prior relationship with
    subjects), disclosed in author's note where it materially
    affects the work.
- Subjectivity acknowledged is different from subjectivity
  performed. The literary-NF tradition values precise
  observation, calibrated voice, and earned interiority over
  performance of interiority for its own sake.

### MANDATORY. Form Serves Content (not form for form's sake)

- Formal experimentation — fragment, braid, lyric, hybrid —
  is part of the literary-NF tradition's range. The standard:
  formal choices illuminate the subject; the form is content
  rather than decoration.
- Failure modes to avoid:
  - **Obscurity as style.** Difficulty that does not reward
    the reader's work; complexity for its own sake; the
    "literary" performed without earning its difficulty.
  - **Form chosen to flatter the author rather than serve
    the reader.** Formal choices that demonstrate the
    author's craft credentials without illuminating the
    subject.
  - **Experimentation copied without understanding.** Form
    borrowed from a successful predecessor without
    integration into this book's substance.
  - **Padding.** Filler paragraphs, transitional throat-
    clearing, repetition that doesn't earn its place; the
    genre has no patience for word-count padding.
- The standard: every formal choice can be defended as
  serving the book's meaning. Where the form is unconventional,
  the reader who works through it receives meaning that
  conventional form could not have delivered.

### MANDATORY. Prose Justifies its Literary Ambitions

- Literary non-fiction is a category where the prose itself
  is part of the product. The standard: every sentence earns
  its place; every metaphor is original and precise; rhythm
  varies deliberately; observation is specific and earned;
  the prose rewards attention as literary fiction does.
- The "purple prose" failure mode — adjective-laden gushing,
  ornate vocabulary substituted for thought, Strunk-and-White-
  violation as supposed style — is the category's most-
  criticised stylistic failure. Precision and rhythm and
  observation distinguish literary prose from purple prose.
- Beautiful writing about nothing is still nothing. The
  prose must be in service of substance: subject worth
  attending to, thought worth thinking, observation worth
  recording. Style without substance fails the genre.

### Additional Guardrails

- **Literary-vs-popular positioning honest.** The book is
  positioned (by author, agent, publisher) as literary or
  as popular non-fiction; mixing the registers without
  clarity confuses readers and reviewers. Literary positioning
  carries different commercial expectations (smaller print
  runs, prize possibilities, longer shelf-life), different
  critical-reception ecology (the literary review press,
  the literary-fiction reader as primary audience), different
  promotional patterns (longer feature reviews, fewer mass-
  audience media appearances).
- **Prize-and-contest-shaped ecology.** Major literary-NF
  prizes (National Book Award NF, NBCC, Pulitzer NF, Andrew
  Carnegie Medal, PEN/Diamonstein-Spielvogel for the essay,
  Bailie Gifford in UK, Cundill in history-adjacent, Baillie
  Gifford NF) shape the genre's reception and commercial
  arc. Authors and publishers operate within this ecology
  with appropriate awareness; the prize-cultivated reader is
  often the literary-NF buyer.
- **Author's craft-tradition lineage acknowledged.** Literary
  NF has documented lineage (the New Journalism, the New
  York Review essay tradition, the Paris Review, the Iowa
  / NYU non-fiction MFA pipelines, the Granta non-fiction
  tradition, the recent lyric-essay and braided-form
  movements). Books that situate themselves in this lineage
  acknowledge it; books that pretend originality where they
  are clearly working within a tradition read as either naive
  or evasive.
- **The "writer's book" register.** Literary NF often functions
  as the work other writers read to learn craft from; the
  author's awareness that other writers are part of the
  audience shapes the work. Craft visible without being
  performative; the difficulty earned; the labour of writing
  acknowledged sometimes within the book itself.
- **Currency disclosure where it matters.** Subject-bound
  literary NF (on contemporary politics, technology, current
  affairs) inherits its subject's currency demands; pure
  literary work (memoir, lyric essay, criticism) ages more
  gracefully and currency disclosure matters less.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Muted, sophisticated, considered — dusty
  rose, slate, sage, ochre, cream, bone, faded indigo, soft
  charcoal; or single bold colour against neutral as a
  literary-design statement. Avoid commercial-publisher
  saturated palettes; the cover should signal that the book
  belongs in literary-fiction adjacency rather than commercial-
  non-fiction.
- **Typography:** Elegant restrained serif (Garamond, Bembo,
  Adobe Caslon, Sabon, Mrs Eaves, Centaur) is the dominant
  choice — typography signals continuity with literary
  publishing's design culture. Display serifs (Didot, Bodoni,
  hand-set wood-type-influenced) for books with strong
  personality. Sans-serif appears in contemporary literary
  publishing (FSG Originals, Tin House, Graywolf design
  conventions) where modernist-design literacy is the cue.
  The title typically whispers rather than shouts;
  understatement signals confidence in the prose.
- **Imagery:** Three dominant traditions:
  1. **Abstract / impressionistic** — fine-art-influenced
     composition, textural photograph, watercolour or
     painted element, suggestive rather than literal. Strong
     for lyric / fragmented / cross-form-experimental work
     and for many braided-hybrid books.
  2. **Single evocative photograph** — a charged image (a
     person partially obscured, a window, an interior, a
     landscape detail, a found object photographed with care)
     that suggests rather than declares the subject. Strong
     for narrative non-fiction, immersion reportage, and
     literary memoir.
  3. **Pure typography** — title and author name with
     restraint, often centered, often with substantial white
     space. Common for established author-brands and for
     books where the prose is the unambiguous draw.
- **Mood:** Considered intelligence, gallery-grade taste. The
  cover should signal "this book is literary" — not in the
  commercial sense (lifestyle-NF register) but in the
  literary-fiction-adjacent sense (the same reader who buys
  Marilynne Robinson, Rachel Cusk, Hisham Matar in fiction
  buys this in non-fiction). Design as art object; these
  books live on display shelves and on coffee tables. The
  cover IS part of the book's literary-positioning argument.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Narrative Non-Fiction | Often a single resonant photograph — a place, a person partially seen, an iconic detail; warmer or moodier palette appropriate to subject; serif typography signals literary positioning; subtitle establishes the subject-and-scope ("the rise and fall of...", "the year that...") |
| Immersion Journalism / Reportage | Photographic — often an image of the community / context / setting; calibrated to honour subjects (no exoticising or pity-tropes); restrained palette; serif typography; subtitle clarifies the immersion's nature ("a year in...", "inside...") |
| Literary Memoir | Memoir cover language adapted for literary register — single resonant image (interior, object, partial figure) or pure typography; warmer palette; literary serif; subtitle restrained ("A Memoir" sufficient where author-brand carries; specific framing where useful) |
| Lyric Essay / Fragmented | Often the most design-forward — abstract or fragmentary imagery; sometimes the cover itself signals formal experimentation; restrained palette; typography may be treated as image; subtitle minimal or absent |
| Braided Hybrid | Often pure typography or abstract imagery — the cover does not commit to a single mode (memoir / essay / reportage) the book braids; warmer palette; literary serif; subtitle does the descriptive positioning ("Essays on..." / "On...") |
| Literary Criticism as Art | Often pure typography or single-detail-from-the-subject's-work; sophisticated palette; serif typography signals scholarly-literary lineage; subtitle clarifies the subject ("On X", "Reading Y", "Watching Z") |
| Cross-Form / Experimental | Most varied — design often itself part of the book's argument about form; pure typography or unconventional imagery common; subtitle minimal |

### Typography Rules

- **Title:** 25–50% of cover area depending on whether image-led
  (smaller) or typography-led (larger). Literary-NF titles
  range from evocative single phrase ("Bluets", "Splinters",
  "Notes from No Man's Land", "The Lonely City",
  "Stay True") to descriptive-with-character ("How to Write
  an Autobiographical Novel", "Behind the Beautiful
  Forevers", "Random Family") to subject-name ("In Cold
  Blood", "The Right Stuff", "The Library Book"). The
  title typically does less commercial work than other NF
  categories because the prose and the author's reputation
  carry more.
- **Subtitle:** Often restrained. "A Memoir" / "Essays" /
  "A Story" frequently sufficient where author-brand carries.
  Where subtitle does descriptive work, it establishes the
  literary positioning and the subject's specificity
  ("Adventures in the Art of Being Alone" — Laing's
  *Lonely City*; "An Argument" — Nelson's *The Argonauts*
  notably has none; descriptive subtitles in this category
  often shorter and quieter than other NF categories).
- **Author name:** Typography weight depends on author-brand
  status. Established literary-NF brands (Didion, Capote,
  Mailer, McPhee, Malcolm, Boo, Nelson, Biss, Jamison, Als,
  Laing) often have name LARGER than title — voice-driven
  purchase. Less established authors balance against
  credentials in subtitle or back-cover blurb (often quoting
  established authors as endorsers). Author photo on jacket
  flap conventional.
- **Series mark, imprint, and edition:** Literary-NF imprints
  with recognised visual identity (FSG, Knopf, Riverhead,
  Graywolf, Tin House, Coffee House, McSweeney's, Granta,
  Wave Books for lyric-form crossover, NYRB Classics for
  re-issued classics) signal positioning to category readers.
  Prize stickers (Pulitzer, NBA, NBCC) added to subsequent
  printings where won. First-edition collectability matters
  for serious literary-NF readers.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Narrative Non-Fiction | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Essays (with Politics & Social Sciences > Social Sciences > Sociology or Biographies & Memoirs as secondary per the book's subject) |
| Immersion Journalism / Reportage | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Sociology > Urban (for urban immersion); or Politics & Social Sciences > Social Sciences > Anthropology > Cultural for ethnographic-style; or Biographies & Memoirs > Specific Groups > Journalists for the journalist's-account framing |
| Literary Memoir | Kindle Store > Kindle eBooks > Biographies & Memoirs > Memoirs (with Literature & Fiction > Essays & Correspondence > Essays as secondary for memoir-essay crossover) |
| Lyric Essay / Fragmented | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Essays (with Literature & Fiction > Poetry > Anthologies as secondary for prose-poem-adjacent work) |
| Braided / Hybrid Form | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Essays (with Biographies & Memoirs > Memoirs as secondary for memoir-anchored braids) |
| Literary Criticism as Art | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Literary Criticism (with Arts & Photography > Criticism for art-criticism crossover) |
| Cross-Form / Experimental | Kindle Store > Kindle eBooks > Literature & Fiction > Literary Fiction (yes, sometimes — for autofiction-adjacent work positioned at the boundary); or > Essays & Correspondence > Essays per the book's primary mode |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Subject-specific category | Kindle Store > Kindle eBooks > [Politics & Social Sciences / History / Science & Math / Religion & Spirituality / Travel / Sports & Outdoors / Arts & Photography] per the book's subject — literary-NF books also cross-list in subject categories where the subject is substantial |
| Memoir crossover | Kindle Store > Kindle eBooks > Biographies & Memoirs > Memoirs > Personal Memoirs |
| Travel crossover | Kindle Store > Kindle eBooks > Travel > Essays & Travelogues |
| Nature crossover | Kindle Store > Kindle eBooks > Science & Math > Nature & Ecology > Natural History |
| Politics / social-science crossover | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > [Specific Sub] |
| Arts crossover | Kindle Store > Kindle eBooks > Arts & Photography > History & Criticism |
| Specific demographic / community | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > [Women / LGBTQ+ / African American / Asian American / etc.] |
| Literary fiction crossover | Kindle Store > Kindle eBooks > Literature & Fiction > Literary Fiction (rare; reserved for autofiction-adjacent / boundary-crossing work) |

### Keyword Recommendations

- Mode + "non-fiction"
  ("literary non-fiction", "narrative non-fiction", "creative
  non-fiction", "literary memoir", "lyric essay", "long-form
  essay", "immersion journalism", "literary reportage")
- The literary-publishing tradition signal
  ("New Yorker style", "literary essay", "long-form journalism",
  "narrative journalism", "Granta non-fiction", "personal
  criticism")
- Subject-and-author-lens combinations
  ("memoir on [subject]", "essays on [subject]", "literary
  account of [subject]", "reportage from [place]")
- The author's distinctive position where applicable
  ("queer literary memoir", "Black literary essays",
  "immigrant memoir", "writer's life")
- Comparable author / brand for discoverability
  (readers of Joan Didion, readers of John McPhee, readers of
  Maggie Nelson, readers of Eula Biss, readers of Leslie
  Jamison, readers of Hilton Als, readers of Alexander Chee,
  readers of Patricia Lockwood)
- Form-tradition signal where applicable
  ("New Journalism", "lyric essay tradition", "braided form",
  "hybrid memoir", "auto-theory", "personal essay")
- Prize / recognition where applicable
  ("National Book Award finalist", "Pulitzer non-fiction",
  "NBCC", "Granta Best of Young...")
- Avoid generic "non-fiction" / "writing" / "creative" in
  isolation — they drown in algorithmic noise; prefer compound
  phrases combining mode + subject + author-lens
- Avoid commercial-non-fiction framings ("transformative",
  "inspiring", "life-changing", "empowering") — they signal
  mis-positioning for literary-NF readers
