---
name: intent-preservation
description: "Engine-neutral Class B binding/protocol. Subagent-dispatched semantic audit that combines two related checks: (1) theme-leak detection — does the prose accidentally signal a theme the writer's stated intent contradicts; (2) resolution test — do climactic / payoff / synthesis moments actually land on their meaning, or pass through it without weight. Final gap-close in the canon-validation Wave 4 sequence (v2.7.35; INTENT PRESERVATION gap-analysis row 6). Most subjective of the canon-validation audits; ships WARN-only on first release (engine layer downgrades any FAIL subagent verdict to WARN before merging into briefing) — surfaces findings without blocking craft choices. Bible-grounded: every finding cites both the prose moment AND the bible intent statement it diverges from."
version: "2.7.38"
severity_cap: WARN
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Intent Preservation Audit (Theme-Leak + Resolution Test)

A Class B binding/protocol spec for the INTENT PRESERVATION
domain (per `canon-validation-taxonomy.md`). Closes the
**final** gap in the Wave 4 audit-additions sequence
(gap-analysis row 6). Fourth Class B audit using the v2.7.32
framework — see `injury-accumulation.md` for the canonical
Class B structure.

With v2.7.35, all six Wave 4 gap-closes are complete; all
ten canon-validation domains have at least one primary-domain
audit. The framework is **feature-complete**.

## Why this exists

Two related failures in INTENT PRESERVATION:

**Theme-leak.** The writer means to say one thing; the
prose accidentally says another. A novel about fragile
masculinity reads as celebration of the protagonist's
destructive behavior because no narrative consequence ever
lands. A non-fiction book arguing for caution reads as
endorsement because the cautionary examples are too
exciting; the warning evaporates under the thrill. A
memoir intended as accountability reads as
self-aggrandisement because the regrets are framed as
hard-won wisdom rather than acknowledged costs. A
character meant to be sympathetic reads as villainous
because the prose dwells on the things the writer wanted
the reader to forgive.

In each case the bible declares Intent X; the prose carries
Intent Y. The leak is between the writer's stated intent
and the prose's emergent signal. The reader infers
intent-Y; the writer is surprised when the manuscript is
read as the opposite of what they meant.

**Resolution test.** The prose reaches a climactic
moment — a synthesis, a character realisation, a
thematic payoff, a structural turn — and races through it
without weight. The reader experiences the beat as a
listed item rather than a felt arrival. A 12-chapter
arc culminates in two paragraphs of dispatched closure.
A non-fiction argument's central claim is stated in the
final chapter but never given the breath that would make
it land. A character's transformation happens in
summary. The promised meaning was reached technically;
the reader did not arrive there.

Both failures are INTENT PRESERVATION-domain bugs. They
share a structure: the prose's actual delivered intent
diverges from the bible's stated intent. Theme-leak is
divergence in CONTENT (the prose says the wrong thing);
resolution-test is divergence in WEIGHT (the prose says
the right thing but doesn't mean it).

Single-chapter audits cannot catch these failures. The
divergence is between the bible's declared intent and the
manuscript's overall delivered effect — visible only with
end-to-end semantic reading against the intent declarations.

## Why this audit ships WARN-only on first release

Of the six Wave 4 gap-closes, this audit makes the most
subjective judgments. "Does the prose accidentally signal
something the writer didn't intend?" requires inferring
both the writer's intent (partly anchored in the bible,
partly in the prose's apparent shape) and the prose's
emergent signal (which is partly in the eye of the
reader). "Does the resolution land?" requires a
felt-experience judgment that varies by reader.

A FAIL verdict on an audit this subjective is a heavy
signal. To avoid blocking writers on judgment-call
findings while the audit beds in, the engine layer
**downgrades any FAIL subagent verdict to WARN** before
merging into the Validation Briefing. Every finding from
this audit appears in the briefing as WARN, regardless of
the subagent's internal severity assessment.

A future release may lift the WARN-only cap (or move to
a graduated WARN/FAIL split with stricter evidence
requirements for FAIL) once the audit's behaviour on real
manuscripts has been observed. For v2.7.35 first ship, the
discipline is: **surface findings; do not block work**.

## What the audit detects

Two distinct sub-checks, both bundled under this audit:

**Sub-check A: Theme-leak detection.**

For every intent declaration in the bible (theme, message,
authorial intent, character intent, stakes), the subagent
scans the prose for moments that deliver the opposite signal
or a substantively divergent signal. Specifically:

1. The bible declares Intent X (e.g. "the protagonist's
   destructive behaviour is a portrait of fragility, not a
   celebration of strength")
2. The subagent identifies prose moments that land Intent Y
   instead of X (e.g. an action sequence written with
   admiring kinetic energy, no narrative consequence, no
   counterweighting prose, no internal acknowledgment of
   cost)
3. Each finding cites BOTH the bible intent statement AND
   the prose moment(s) that diverge

The threshold for a finding: the divergence must be
substantive (not a single ambiguous line in a 90,000-word
manuscript), and the divergence must be unmitigated (no
counterweighting prose elsewhere addresses the leak).

**Sub-check B: Resolution test.**

For every structural payoff promised by the bible (climax,
synthesis, character resolution, thematic landing,
revelation), the subagent identifies the prose moment that
delivers it and evaluates whether the prose gives the
moment the weight its setup earned. Specifically:

1. The bible declares Payoff X promised in chapter N (e.g.
   "Aida's reconciliation with her sister, the central
   emotional arc, lands in chapter 18")
2. The subagent reads chapter 18 to find the delivery
   moment
3. Evaluates against three criteria:
   - **Page-time proportionality:** does the resolution get
     comparable page-time to its setup? A 12-chapter arc
     resolved in two paragraphs fails this criterion.
   - **Internal weight:** does the prose pause inside the
     moment — sensory detail, internal state, slow time —
     or race past?
   - **Felt arrival:** does the prose deliver the meaning
     in a way the reader will feel, or only describe it?
     Summary statements ("she finally understood her sister")
     without earned moments-of-realisation fail this
     criterion.

A resolution failing 1 of 3 criteria → minor finding; 2 of
3 → moderate; 3 of 3 → strong. All findings emit as WARN
under the v2.7.35 ship constraint.

## Why Class B (subagent), not Class A (bash)

A bash audit cannot perform either check:

- **Theme-leak detection** requires inferring the prose's
  emergent signal from semantic content (admiring vs
  cautionary tone, presence/absence of counterweighting
  context, what the prose dwells on vs what it elides).
- **Resolution test** requires evaluating prose weight
  (page-time + sensory grounding + internal state +
  felt-experience) against a bible-declared promise.
- **Both checks** require cross-referencing prose passages
  against bible declarations of intent — a semantic
  comparison no regex can perform.

The mechanical-bash version would either miss most cases or
false-positive on every adjective. A subagent reading the
bible + prose end-to-end with explicit intent-anchored
evaluation is the right tool.

## How Class B audits are dispatched

Per `validate-dispatcher.md` Step 4b. The bash dispatcher
emits:

```
CLASS_B_AUDIT|intent-preservation|INTENT_PRESERVATION|references/intent-preservation.md|WARN
```

The slash-command engine layer reads the line, dispatches a
subagent per the brief below, applies the engine HARD GATE on
the return (including the WARN-only severity cap), and
merges the verdict into the Validation Briefing.

## Subagent task brief (for the intent-preservation audit)

The slash-command engine constructs the following subagent
brief when this audit is dispatched. Customise only project-
specific paths.

> **Task: Intent Preservation Audit (theme-leak + resolution test)**
>
> **Background.** This audit detects two related INTENT
> PRESERVATION-domain failures: theme-leak (prose accidentally
> signals against the bible's stated intent) and resolution-
> miss (prose reaches a payoff but doesn't land it). You are
> scanning the full manuscript end-to-end with explicit cross-
> referencing against the bible's intent declarations.
>
> **Inputs.**
> - `engine-data/research-bible.md` (NF) or
>   `engine-data/story-bible.md` (fiction) — source of intent
>   declarations and payoff promises
> - `engine-data/chapters/ch*.md` — manuscript chapters in
>   chapter order
>
> **Procedure.**
>
> 1. Extract intent declarations from the bible. Look in:
>    - Architectural Overview (thesis, theme, message)
>    - Author's Intent / Authorial Stance section
>    - Stakes-for-the-Reader section
>    - Character intent statements (what the writer wants the
>      reader to feel about each character)
>    - Per-chapter outline notes that declare emotional /
>      thematic targets
>    Build the Intent Declaration Inventory.
>
> 2. Extract payoff promises from the bible. Look in:
>    - Per-chapter outline entries that mark a chapter as
>      structurally significant (climax, synthesis,
>      resolution, revelation)
>    - Architectural overview's listing of major arcs and
>      where they land
>    - Character-arc declarations of resolution moments
>    Build the Payoff Promise Inventory.
>
> 3. **Sub-check A: Theme-leak detection.** For each Intent
>    Declaration:
>    1. Scan chapters for prose moments that deliver a
>       divergent or opposite signal
>    2. Apply the substantive + unmitigated thresholds (one
>       ambiguous line in 90k words is not a finding;
>       counterweighting prose elsewhere mitigates an apparent
>       leak)
>    3. Record findings with: intent declaration cited from
>       bible, divergent prose moment cited from chapter, one-
>       clause description of the divergence, severity
>       (minor/moderate/strong)
>
> 4. **Sub-check B: Resolution test.** For each Payoff Promise:
>    1. Identify the delivery moment in the prose
>    2. Evaluate against three criteria: page-time
>       proportionality, internal weight, felt arrival
>    3. Record findings for any payoff failing 1+ criteria
>       with: bible promise cited, prose delivery cited, one-
>       clause description of which criterion failed and why,
>       severity (1-of-3 = minor, 2-of-3 = moderate, 3-of-3 =
>       strong)
>
> 5. Aggregate findings. Compute internal verdict:
>    - PASS: no findings
>    - WARN: findings, all minor severity
>    - FAIL: any moderate or strong finding
>
> 6. **WARN-only ship constraint:** the engine layer downgrades
>    your FAIL verdict to WARN before merging into the briefing.
>    You may report your internal severity assessment honestly
>    in the Findings table; the cap applies at merge time, not
>    at your evaluation time.
>
> **Return contract (mandatory; subagent output is rejected
> by the engine if not conformant).** Return a structured
> response with the following sections, each populated even
> if empty:
>
> ```
> ## Intent Declaration Inventory
> | Intent type | Source (bible section) | Statement |
> |---|---|---|
> [populated rows from bible; or single row "(no intent
> declarations in bible — sub-check A not applicable)"]
>
> ## Payoff Promise Inventory
> | Promise | Source (bible section) | Promised chapter |
> |---|---|---|
> [populated rows; or single row "(no payoff promises in
> bible — sub-check B not applicable)"]
>
> ## Sub-check A Findings (theme-leak)
> | Severity | Intent | Bible source | Divergent prose | Description |
> |---|---|---|---|---|
> [one row per finding; or "(no findings)"]
>
> ## Sub-check B Findings (resolution test)
> | Severity | Payoff | Bible source | Delivery prose | Criteria failed |
> |---|---|---|---|---|
> [one row per finding; or "(no findings)"]
>
> ## Internal Verdict
> One of: PASS | WARN | FAIL
> [your honest assessment before the WARN-only cap is applied]
>
> ## Final Verdict (post-cap)
> One of: PASS | WARN
> [PASS if Internal Verdict was PASS; WARN otherwise — the
> engine layer enforces this cap, but state it explicitly so
> the writer sees the relationship]
>
> ## One-Line Summary
> Single line for the briefing's per-audit summary. Format:
> "<final_verdict>: <count> theme-leak finding(s), <count>
> resolution finding(s) — <internal verdict was X>" or
> "PASS: no intent declarations or payoff promises in bible —
> audit not applicable"
> ```
>
> **Discipline.**
> - Cite both halves of every finding: the bible source AND
>   the prose moment. Findings without both citations are
>   stripped by the HARD GATE.
> - For sub-check A: substantive + unmitigated thresholds are
>   non-negotiable. A single ambiguous sentence in a long
>   manuscript is not a finding. Look for patterns and
>   absences (the prose dwells on X without ever
>   counterweighting Y; the warning is undermined by the
>   excitement of the cautionary tale).
> - For sub-check B: a payoff that lands in summary form
>   ("she finally understood") fails the felt-arrival
>   criterion regardless of how much page-time it gets;
>   summary is not landing.
> - When uncertain about a sub-check A finding, do NOT include
>   it. The audit's value depends on findings being credible.
>   The WARN-only cap is generosity from the framework, not
>   permission to fire on weak evidence.
> - Be explicit when no intent declarations or payoff promises
>   exist in the bible. The audit is honestly not applicable
>   in that case; PASS with the audit-not-applicable summary
>   is correct.

## Engine HARD GATE on subagent return

Per `subagent-output-verification.md`, with one
audit-specific addition (the WARN-only cap):

1. **Shape check.** All seven required sections present
   (Intent Declaration Inventory, Payoff Promise Inventory,
   Sub-check A Findings, Sub-check B Findings, Internal
   Verdict, Final Verdict, One-Line Summary). Missing
   section → reject; re-dispatch ONCE; on second failure
   emit `AUDIT|intent-preservation|INTENT_PRESERVATION|FAIL|subagent return non-conformant after retry|-`
   (the WARN-only cap does NOT apply to non-conformance
   FAILs; only to evaluation FAILs).
2. **Citation discipline.** Every Findings row in both
   sub-check tables must contain BOTH a bible source citation
   AND a prose citation. Findings without both are stripped;
   if all findings are stripped and the Internal Verdict was
   FAIL, the Internal Verdict downgrades accordingly.
3. **Hallucination markers.** Reject citations to non-existent
   chapters or non-existent bible sections. Stripped
   citations cause finding rows to be re-evaluated for
   citation discipline (both sides still required); if this
   re-evaluation reduces the surviving findings to zero, the
   Internal Verdict is downgraded.
4. **No-intent-declaration / no-payoff-promise special case.**
   If both inventories are placeholder rows, the audit's PASS
   verdict is preserved with the "audit not applicable"
   summary; no further checks required.
5. **WARN-only severity cap (audit-specific; v2.7.38 reordered).**
   Applied LAST, after all evidence-validation checks (shape,
   citation, hallucination, special case) have produced a
   final, evidence-validated Internal Verdict. The cap then
   forces the briefing's Final Verdict:
   - Internal Verdict PASS → Final Verdict PASS
   - Internal Verdict WARN → Final Verdict WARN
   - Internal Verdict FAIL → Final Verdict WARN (capped)
   The writer sees the cap reflected in the briefing's
   per-audit verdict; the Internal Verdict is preserved in
   the saved subagent return for transparency.

   **Why ordering matters.** Pre-v2.7.38 the cap was applied
   at position #3 (before hallucination strip + special case).
   That ordering was wrong: a FAIL→WARN downgrade could be
   applied to a verdict that, post-hallucination-strip, should
   have been PASS. The cap can only meaningfully apply to a
   verdict derived from validated evidence, so it MUST be the
   last check.

After verification, the engine emits:

```
AUDIT|intent-preservation|INTENT_PRESERVATION|<final_verdict>|<one_line_summary>|<subagent_return_path>
```

...with the full subagent return saved at
`engine-data/reports/validate/intent-preservation-subagent.md`.

## How writers should respond to WARN findings

Three reasonable responses:

1. **Take the finding seriously and revise.** A theme-leak
   the audit surfaces is often genuine — the writer's
   intent did diverge from the prose, and the audit caught
   it. Revise to add counterweighting prose, reframe the
   admiring beats, address the absence of consequence.
   Resolution-miss findings are similar: add page-time,
   slow the prose, ground the moment in sensory detail
   and internal state.
2. **Disagree and document.** Sometimes the audit's
   inferred-divergence is the writer's intentional craft
   choice (the writer wants the reader to feel the
   excitement of the cautionary tale before the warning
   lands; the protagonist's destructive behaviour is
   meant to be ambiguous). Note the disagreement in the
   bible (revising the intent declaration to acknowledge
   the ambiguity); the audit then reads the revised
   intent and may not fire. Or accept the WARN as
   informational and move on.
3. **Recognise the audit's WARN-only stance is the framework
   acknowledging subjectivity.** No INTENT PRESERVATION
   finding should block work. The audit's purpose is to
   surface the writer's blind spots so they can choose
   whether to address them — not to issue verdicts on
   craft.

The audit does not block phase advancement under any
circumstances. WARN findings surface in the briefing for
consideration; the writer's call on each finding is final.

## How to adopt the convention on existing projects

The audit works best on projects whose bibles declare
intent explicitly. For projects whose bibles lack intent
declarations, the audit returns "no intent declarations or
payoff promises in bible — audit not applicable" PASS.

Two adoption paths:

1. **Forward-only.** New projects declare authorial intent +
   payoff promises in the bible at architectural-overview
   time; audit reports against the plan from project
   inception.
2. **Backfill.** For existing projects, add an Authorial
   Intent / Theme / Payoff Promise section to the bible
   capturing the intent the writer holds for the
   manuscript. Run the audit to verify alignment.

## Engine-neutral applicability

Both fiction and non-fiction declare intent that the prose
must preserve. Fiction: thematic intent, character intent,
emotional arcs. Non-fiction: thesis, message, application
intent, stakes-for-the-reader. The audit treats both
engines identically — the bible's intent declarations are
the reference; the prose's delivered effect is the
evaluand.

Reference manuscripts without authorial intent declarations
return the no-intent-declaration PASS.

## Failure modes prevented

Per `silent-failure-audit.md` row 31:

- **Theme-leak cascade** — prose accidentally signals
  against stated intent; manuscript reads as the opposite
  of what the writer meant; reader trust collapses when
  the disconnect is obvious. Surfaced at validate time
  while the manuscript is still revisable.
- **Resolution skim cascade** — climactic moments raced
  through; reader feels the technical-arrival but not the
  felt-arrival; manuscript ends without weight. Surfaced
  before the writer hands the manuscript to beta readers
  whose first feedback would be "the ending didn't land".
- **Validation-coverage misrepresentation** — without this
  audit, INTENT PRESERVATION had only Stage 5 Authorial
  Voice Sweep (partial coverage). With v2.7.35, INTENT
  PRESERVATION has its first primary-domain audit; status:
  COVERED.
- **Subagent-overreach cascade** — subagent fires findings
  on weak evidence (a single ambiguous sentence becomes a
  theme-leak claim); audit becomes noise; writer
  discounts it. Mitigated by substantive + unmitigated
  thresholds in the brief AND by the WARN-only cap (no
  finding can ever block); writer remains in control.
- **Subagent-hallucination cascade** — subagent claims
  bible sources or chapter citations that don't exist.
  Caught by the HARD GATE.

## Framework status post-v2.7.35

With this audit shipped, all six Wave 4 gap-closes are
complete:

- v2.7.30 — SHOW NOT TELL no-double-tell (Class A)
- v2.7.31 — COHERENCE same-function-consecutive (Class A + Class C)
- v2.7.32 — PHYSICS injury-accumulation (first Class B; introduced framework)
- v2.7.33 — COHERENCE leitmotif-tracker (Class B)
- v2.7.34 — CHARACTER 7-criterion humanity-gate (Class B)
- **v2.7.35 — INTENT theme-leak / resolution-test (Class B, WARN-only)**

All ten canon-validation domains now have at least one
primary-domain audit. The dispatcher framework
(v2.7.27-v2.7.32) is feature-complete; the audit set is
feature-complete. Subsequent v2.7.x releases plug into
the existing dispatch model rather than extending it.

## See also

- `canon-validation-taxonomy.md` — the 10-domain index;
  INTENT PRESERVATION primary-domain table now lists this
  audit; Wave 4 gap-analysis fully COVERED
- `validate-dispatcher.md` Step 4b — the Class B Dispatch
  Protocol; this audit is the fourth (and final Wave 4) to
  use it
- `injury-accumulation.md` (v2.7.32) — first Class B audit;
  framework reference implementation
- `leitmotif-tracker.md` (v2.7.33), `humanity-gate.md`
  (v2.7.34) — second and third Class B audits using the
  same framework
- `subagent-output-verification.md` — the HARD GATE applied
  to subagent returns
- `silent-failure-audit.md` — catalog of drift-failure shapes;
  this audit adds row 31 (final Wave 4 row)
