---
name: history-general
description: "Category plugin for General History. chronological and thematic narratives of human civilisation, nations, periods, and reinterpretations of the past"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# General History. Category Plugin

## Metadata

| Key | Value |
|-----|-------|
| Category ID | `history-general` |
| Display Name | General History |
| Parent Group | History |
| Typical Word Count | 70,000 – 120,000 |
| Audience | Educated general readers, history enthusiasts, students |
| Tone Spectrum | Authoritative yet accessible; narrative-driven with analytical depth |
| Comparable Titles | *Sapiens* (Harari), *The Silk Roads* (Frankopan), *SPQR* (Beard) |

## Subcategory Options

When the user selects **General History**, prompt them to choose a subcategory:

| ID | Subcategory | Description |
|----|-------------|-------------|
| `world-history` | World History | Broad sweeps across civilisations and centuries; comparative or global in scope |
| `national-history` | National History | The story of a single nation-state, people, or political entity |
| `period-history` | Period History | Focused on a defined era (e.g., the Renaissance, the Long Nineteenth Century) |
| `thematic-history` | Thematic History | History organised around a theme (trade, disease, technology, religion) rather than chronology |
| `revisionist-history` | Revisionist History | Challenges or reinterprets established historical narratives using new evidence or perspectives |

### Subcategory-Specific Notes

- **World History**: Ensure global balance; avoid Eurocentric framing unless explicitly scoped.
- **National History**: Acknowledge contested borders, minority populations, and colonial legacies.
- **Period History**: Define start and end dates with justification; explain why this periodisation matters.
- **Thematic History**: The theme must remain the organising spine. do not let chronological narrative take over.
- **Revisionist History**: State the orthodox view clearly before presenting the revision; acknowledge counter-arguments.

## Structural Architect Instructions

### Recommended Structures

1. **Chronological**: Chapters advance through time. Best for period and national histories.
2. **Thematic-Chronological Hybrid**: Part I sets the thematic framework, then chapters proceed chronologically within that frame. Best for thematic and world histories.
3. **Argument-Driven**: Each chapter advances a thesis, with historical evidence marshalled in support. Best for revisionist history.

### Standard Chapter Architecture

- **Opening hook**: A vivid scene, primary-source quotation, or surprising fact that anchors the reader in time and place.
- **Context-setting**: Situate the chapter's events within the broader narrative arc.
- **Core narrative/analysis**: Interweave storytelling with interpretation. Every claim of causation must be supported.
- **Voices**: Incorporate at least one primary-source perspective per chapter. a letter, diary entry, speech, or contemporary account.
- **Chapter bridge**: Final paragraph must create momentum toward the next chapter.

### Front and Back Matter

- **Introduction**: State the book's central argument or organising question. Explain scope and limitations.
- **Timeline**: Provide a chronological timeline of key events covered.
- **Maps**: Include at minimum one map per major geographic region discussed.
- **Endnotes**: Prefer endnotes over footnotes for general-audience works.
- **Bibliography**: Divide into Primary Sources and Secondary Sources.
- **Index**: Mandatory; include people, places, events, and concepts.

## Content Writer Craft Rules

1. **Show, then analyse.** Lead with a concrete scene or detail before stepping back to interpret its significance.
2. **Anchor abstractions.** Every generalisation ("the economy declined") must be grounded in specific evidence (trade figures, contemporary accounts, material remains).
3. **Name the people.** Even in sweeping narratives, name individuals. rulers, soldiers, merchants, ordinary citizens. to humanise the account.
4. **Manage chronological complexity.** When jumping between timelines, use clear temporal signposting ("Three decades earlier...", "By the summer of 1789...").
5. **Translate period language.** When quoting archaic sources, provide enough context for modern readers without over-modernising the original voice.
6. **Avoid the textbook voice.** Vary sentence length. Use active voice. Employ narrative techniques. scene-setting, dialogue from sources, dramatic irony.
7. **Respect uncertainty.** Use hedging language ("likely", "the evidence suggests") when the historical record is ambiguous. Never fabricate dialogue or interior thoughts.
8. **Connect past to present sparingly.** Modern parallels can illuminate, but heavy-handed "lessons of history" diminish credibility.
9. **Define terms on first use.** Readers may not know "enclosure", "mercantilism", or "suzerainty". provide brief, seamless definitions.
10. **Maintain consistent periodisation.** If using BCE/CE, use it throughout. If using dynasty names or era labels, introduce them clearly.

### PROSE RHYTHM MAPPING
- Ch 1 hook: the MOMENT that makes the reader care. scene-based, not survey-based; open in a specific time and place
- Sentence length: medium (16-24 words) as the baseline; the historian's rhythm balances narrative momentum with analytical depth
- Sensory period detail from the opening page. the reader must feel the era before understanding it
- Narrative authority earned through specificity: named individuals, precise dates, concrete details from primary sources
- Tension ≥4 from chapter 1. the reader must sense that the outcome of this historical moment was not inevitable
- Alternate between scene and analysis: show first (a vivid moment), then interpret (what it means and why it matters)
- Evidence integration is seamless: primary-source quotations woven into narrative, not walled off as academic exhibit
- Pacing across information-dense passages: analytical paragraphs stay concise (3-5 sentences); narrative passages extend and breathe
- Deploy primary-source voices at emotional and analytical peaks. a letter, a speech, a diary entry that crystallises the moment
- Vary sentence length deliberately: short declarative sentences for turning points; longer sentences for contextual sweep
- The "why should I read this book" question is answered by making the past feel urgent and consequential, not merely educational
- Reader engagement: every chapter must feel like a story unfolding, not a lecture being delivered
- Paragraph rhythm: scene paragraphs ground the reader in time, place, and human experience; analytical paragraphs are crisp and purposeful
- Chronological complexity managed through clear temporal signposting. the reader must always know when they are
- Authority delivery: the historian as confident guide, not distant lecturer; "here is what happened and here is why it matters"
- Connect past to present sparingly but powerfully. modern resonance illuminates; heavy-handed lessons diminish
- Avoid the textbook voice: monotonous sentence length, passive constructions, and abstract generalisations kill narrative history
- Chapter endings create momentum: unresolved consequences, approaching crises, the next historical turn

## Quality Check Criteria

| Criterion | Standard | Method |
|-----------|----------|--------|
| Factual Accuracy | Every date, name, and event must be verifiable against at least two reputable sources | Cross-reference against scholarly consensus |
| Source Density | Minimum 3 endnotes per 1,000 words | Count and audit |
| Narrative Flow | Each chapter reads as a self-contained story while advancing the book's argument | Read-aloud test for pacing |
| Argument Coherence | Central thesis is stated in the introduction and supported in every chapter | Reverse-outline the manuscript |
| Chronological Clarity | Reader can always locate themselves in time | Check for temporal signposting in every section |
| Balance of Perspectives | Contested events present at least two viewpoints | Audit each contested claim |
| Jargon Management | No undefined specialist terms | Glossary check on first pass |
| Anachronism Check | No modern concepts or values projected onto historical actors without acknowledgement | Dedicated anachronism review pass |

## Source Requirements

### Minimum Source Standards

- **Primary sources**: At least 20% of citations must reference primary sources (archives, contemporary documents, archaeological evidence, visual/material culture).
- **Secondary sources**: Rely on peer-reviewed scholarship published within the last 30 years as the backbone; older foundational works are acceptable when identified as such.
- **Source diversity**: No single secondary source may account for more than 15% of citations.
- **Archival research**: For national and period histories, at least some engagement with archival or unpublished material is expected.

### Source Hierarchy

1. Primary documents (letters, treaties, legislation, diaries, archaeological finds)
2. Peer-reviewed monographs and journal articles
3. University press publications
4. Reputable popular histories by credentialled historians
5. Journalistic accounts (use with caution; flag provenance)

### Citation Format

- Chicago Manual of Style, Notes-Bibliography system (17th edition or later).
- Endnotes with full bibliographic details on first reference; shortened form thereafter.
- Bibliography divided into Primary Sources and Secondary Sources.

## Category-Specific Guardrails

### Absolute Rules

1. **No anachronisms.** Do not describe historical actors using modern psychological, political, or social frameworks without explicitly flagging the anachronism.
2. **No invented dialogue.** All quoted speech must come from documented sources. Paraphrased speech must be clearly marked as such.
3. **No single-cause explanations.** Historical events are multi-causal. Present contributing factors with appropriate weight.
4. **No presentism.** Avoid judging historical actors solely by contemporary moral standards; contextualise their worldview.

### Contested Events Protocol

- When covering events where legitimate scholarly disagreement exists, present the dominant interpretation and at least one credible alternative.
- Identify which interpretation the author favours and explain why, with evidence.
- Never present a single interpretation as settled fact when the historiography is actively debated.

### Sensitive Content Guidelines

- **Genocide, slavery, colonialism**: Do not sanitise; do not sensationalise. Use precise, evidence-based language. Centre the experiences of those affected.
- **Religious and cultural claims**: Distinguish between faith-based and evidence-based assertions. Respect belief systems without endorsing supernatural claims as historical fact.
- **National myths**: Identify and interrogate founding myths, national narratives, and popular misconceptions with evidence, not polemic.

### Causation Claims

- Every claim that Event A caused Event B must be supported by:
  - Temporal sequence (A preceded B)
  - Plausible mechanism (how A led to B)
  - Evidence from at least two independent sources
  - Acknowledgement of alternative explanations where they exist

## Cover Design Specifications

| Element | Guideline |
|---------|-----------|
| Imagery | Period-appropriate artwork, maps, artefacts, or architecture. Avoid cliched stock imagery (no generic "old parchment" textures). |
| Typography | Serif fonts convey authority; display serif or engraved-style fonts for title. Subtitle in lighter weight. |
| Colour Palette | Earthy, muted tones (ochre, slate, deep red, navy) suggest gravitas. Avoid neon or overly modern palettes. |
| Layout | Title-dominant. Subtitle and author name clearly legible at thumbnail size. |
| Period Signalling | Cover should visually signal the era or region covered. a medieval manuscript detail for the Middle Ages, a propaganda poster for the twentieth century, etc. |
| Back Cover | Include a 100–150 word synopsis, 2–3 endorsement quotes from historians or major publications, and author credentials. |
| Spine | Title and author name legible; publisher logo at base. |

## KDP Category Mapping

### Primary Categories

| BISAC Code | Category Path |
|------------|---------------|
| HIS000000 | HISTORY / General |
| HIS037000 | HISTORY / World |

### Subcategory-Specific Mappings

| Subcategory | BISAC Code | Category Path |
|-------------|------------|---------------|
| World History | HIS037000 | HISTORY / World |
| National History | HIS015000 | HISTORY / Europe / General (adjust by nation) |
| Period History | HIS037030 | HISTORY / Modern / General (adjust by era) |
| Thematic History | HIS000000 | HISTORY / General |
| Revisionist History | HIS000000 | HISTORY / General |

### Keyword Recommendations

- Include era-specific terms (e.g., "Renaissance", "Cold War", "Ancient Rome")
- Include historiographical terms (e.g., "world history", "global history", "revisionist")
- Target "history of [nation/region]" long-tail phrases
- Include the names of key historical figures covered
- Add thematic terms where applicable ("trade routes", "empire", "revolution")

### Amazon Browse Categories

- Books > History > World
- Books > History > [Region] > [Country]
- Books > History > [Era]
- Kindle Store > Kindle eBooks > History > World
