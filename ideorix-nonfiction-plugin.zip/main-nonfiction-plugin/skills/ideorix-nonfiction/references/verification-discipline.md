---
name: verification-discipline
description: "Verification-Before-Commitment discipline for factual content — three-class labeling (VERIFIED / SPECULATIVE / REJECTED), two-phase WebSearch verification, three-tier quotation rules, seven named anti-patterns. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.6.9"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Verification Discipline (MANDATORY — engine-wide)

## Purpose

Every factual specific committed by Ideorix to a research /
story bible, a chapter, a fact-audit ledger, or a publisher
handoff document MUST be either verified against a real
source via WebSearch or marked explicitly as speculative
content. This file is the canonical single-source-of-truth
protocol; downstream specs (authority-builder, content-
writer, fact-audit, editorial-suite, core-pipeline, quality-
gate, continuity-tracker) reference this protocol rather
than duplicating it.

The discipline exists because Ideorix has historically been
vulnerable to a class of failure where factual specifics —
named papers, named persons, dated events, attributed
statistics, direct quotations — were committed to canon
based on training-data inference rather than verified source
material, then propagated through multiple pipeline stages
and ultimately declared publication-ready without external
verification. The "pre-press fact-verify stack" deferred-to-
publisher framing is the failure mode this discipline
eliminates.

The capability to verify exists in the engine: WebSearch is
available at every layer. The discipline is the binding wire
that converts capability into requirement.

## The Three Classes

Every factual specific in the manuscript falls into exactly
one of three classes:

### VERIFIED

A specific for which WebSearch (or another primary-source
mechanism) has returned a real source that confirms the
specific. The source URL / DOI / publication / page number
/ timestamp is pinned to the research / story bible. The
specific is cited normally in prose with the pinned source
backing it.

**Examples of VERIFIED content:**

- A paper citation where the title, authors, journal, year,
  and DOI all match a real published paper found via
  WebSearch.
- A historical event date confirmed against multiple
  reputable sources.
- A direct quotation that matches verbatim a passage in a
  verified source.
- A corporate event (acquisition, leadership change,
  regulatory action) confirmed via official filings, press
  releases, or contemporaneous press coverage.

### SPECULATIVE

A specific for which WebSearch returned inconclusive
results, or for which the content is by nature forward-
looking, hypothetical, counterfactual, or interpretive.
Content remains in the manuscript only if it is rendered
with explicit speculative-marker language in prose AND
listed in the publisher handoff document.

**Examples of SPECULATIVE content:**

- An anticipated future regulatory action: "if current
  trends continue, the FDA is likely to..."
- A counterfactual scenario: "in a scenario where X
  had happened..."
- An authorial projection: "this analysis projects that..."
- A hypothetical "what such a development would look
  like" passage.
- A reconstruction of historical conversations from secondary
  sources (clearly framed as reconstruction).

**Required prose markers** (use one explicitly):
"hypothetically", "in a scenario where", "if X were to",
"an anticipated", "a projected", "the analysis projects
that", "in effect", "such a development would", "would
look like", "this would suggest".

**Concentrate, don't scatter:** SPECULATIVE content belongs
in clearly delineated chapters or sections (a "Closing
Argument" / "Future Trajectory" / "What Comes Next"
chapter explicitly framed as forward-looking analysis),
not threaded invisibly through documentary chapters.
Cover-copy and marketing copy must reflect the mix — a
book with a speculative concluding chapter cannot be
marketed as pure documentary investigation.

### REJECTED

A specific that cannot be verified and cannot reasonably
be reframed as speculative content. REJECTED specifics
are removed from the manuscript or rewritten as non-
specific.

**Examples of REJECTED content (cannot ship under any
circumstance):**

- A direct quote that doesn't exist in any verified source
  (and isn't a documented historical reconstruction).
- A composite quotation attributed to a single named person.
- A paper citation where neither the paper nor a
  reasonable equivalent can be located.
- A dated event where neither the event nor a reasonable
  proximate event can be located.
- A "plausible-sounding" attribution that has no real
  referent.

## Two-Phase WebSearch Discipline

**Web-Content Verification HARD GATE applies (see
`web-content-verification.md`, v2.7.7).** Every WebFetch and
WebSearch call within this discipline MUST verify the response
returned actual usable content before driving classification:

- **WebFetch:** byte-count threshold (≥ 500 chars), paywall /
  redirect / login-wall pattern detection, title-only
  detection, cached-stale check.
- **WebSearch:** zero-result retry — single zero-result hit is
  suspect (transient backend failure indistinguishable from
  genuine absence); two zero-result hits in succession are
  evidence of genuine absence.

Without this gate, the discipline can over-mark SPECULATIVE
(transient-empty mistaken for genuine absence) or under-mark
by treating paywall stubs as VERIFIED sources. The new binding
is paired: Verification Discipline is the **classification**
layer; Web-Content Verification is the **input-validity** layer
that precedes classification.

### Phase A — Research / Story Bible Construction

**When the bible commits an event / paper / person /
legislation / statistic / corporate fact / institutional
fact to canon, WebSearch MUST run before the bible is
finalized.**

For each committed item:

1. Run WebSearch with sufficient queries to confirm the
   specific exists.
2. Pin the URL / DOI / publication / page-number /
   timestamp to the bible entry.
3. Check for material context the source provides
   (funding sources, conflicts of interest, related
   events, publication context, retraction history).
   Material context that changes interpretation is part
   of the verification, not optional.
4. Items that fail WebSearch verification are flagged
   as SPECULATIVE or REJECTED, never silently committed
   as VERIFIED.

**Topic-landscape sweep is required.** Beyond verifying
specifics already in the bible, Phase A must also run a
"what real events relevant to [topic] happened in [date
range]?" sweep so that the bible captures actually-
existing primary-source material rather than only the
items the model surfaced from training-data context.
The "missed real events entirely" failure mode (FDA
actions, executive orders, legislation cascades that
weren't in the bible because the model didn't know to
look for them) is what this sweep prevents.

### Phase B — Content Writing

**When the writer cites a specific in prose, the cited
specific MUST trace to a Phase-A-verified source in the
bible.**

- If the bible's source is VERIFIED, the writer cites
  with the pinned source.
- If the bible's source is SPECULATIVE, the writer either
  omits the specific or includes it with explicit
  speculative-marker language.
- If the bible's source is REJECTED, the specific does not
  appear in prose at all.
- Quotations get the stricter Three-Tier discipline below.

Re-verification at writing time catches drift if the bible
has been edited between Phase A and Phase B, or if a
chapter is being written in a session that didn't include
the original bible-construction work.

## Three-Tier Quotation Discipline

Quotation handling is governed by a strict three-tier
hierarchy plus hard rejections, drawn from how serious
publishers (Penguin, Norton, Bloomsbury, FSG) and serious
journalism (NYT, FT, New Yorker) handle attributed material.

### Tier 1 — VERBATIM quotation

- Direct quote in quotation marks
- Must be exact, verified against the named source
- Citation includes page number / paragraph location /
  timestamp where applicable
- This is what reviewers, fact-checkers, and lawyers
  expect for any quoted material
- Use sparingly: a verbatim quote earns its place when
  the exact wording matters more than the substance

### Tier 2 — ATTRIBUTED PARAPHRASE

- "X argued that..." / "According to Y..." /
  "Z has documented..."
- **No quotation marks** (this matters — quotation marks
  signal verbatim)
- Captures the substance of the source's position
- Citation included
- This is the workhorse for most non-fiction documentary
  writing and for fiction's historical / contemporary
  fact references

### Tier 3 — AUTHORIAL ANALYSIS

- The author's own framing, interpretation, synthesis
- Not attributed to anyone else
- Can be informed by multiple sources, footnoted as
  appropriate, but framed as the author's view
- This is where the writer's voice does its work

### Hard REJECTIONS — cannot ship under any circumstance

- Direct quotes without verbatim verification
- "X said something like..." or "X is reported to have
  said..." with quotation marks (false specificity —
  drop the quote marks and recast as Tier 2)
- Composite quotations attributed to a single named
  person
- Quotations attributed to plausible-but-fictional contexts
- Plausible-sounding-but-fabricated quotes intended to
  add documentary specificity

## Seven Named Anti-Patterns

The following failure-mode patterns are explicitly named so
that fact-audit and continuity-tracker stages have detection
targets. Each anti-pattern has a documented detection
approach.

### 1. Wrong-Attribution-of-Real-Paper

The model renders a real paper with confident wrong
attribution (wrong authors, wrong title, wrong journal,
wrong year). The paper exists; the citation does not match
it.

**Detection:** WebSearch on every paper citation. Cross-
check authors, title, journal, year, DOI against verified
result. Flag any mismatch.

### 2. Date Drift on Real Events

The event is real; the date the manuscript claims is wrong
(off by days, weeks, or years). Training-data dates are
fuzzy; WebSearch returns the canonical date.

**Detection:** WebSearch on every dated event. Cross-check
the date against the verified result. Flag any drift.

### 3. Detail Errors on Recent Legislation / Statistics

The legislation / statistic is real but the manuscript's
specifics are wrong (wrong number of items covered, wrong
phasing, wrong jurisdiction, wrong thresholds).

**Detection:** WebSearch on the actual statute / dataset.
Cross-check the manuscript's specifics against the primary
source.

### 4. Missed Real Events

A real event that should be in the bible's coverage of the
topic is not — the model didn't surface it from training-
data context. The manuscript has a coverage gap rather
than a wrongness.

**Detection:** Phase A topic-landscape sweep — run
WebSearch queries for "what relevant events happened in
[topic] [date range]?" and reconcile against the bible's
existing coverage. Flag missed events.

### 5. Funding / COI / Context Omissions

The cited person, study, or institution is real but the
manuscript omits material context (funding source,
conflict of interest, publication context, retraction
history) that changes interpretation.

**Detection:** During Phase A verification of each
committed item, explicitly check for funding /
COI / context as a verification dimension. Material
context that changes interpretation must be either
included in the manuscript or noted in the publisher
handoff.

### 6. Topic-Framing Errors

The topic is real but the manuscript's framing of how the
topic is treated by canonical sources is wrong (e.g.,
"the first DGA to address ultra-processed foods" when the
DGA actually uses different terminology and explicitly
declined to address UPF).

**Detection:** WebSearch on the actual primary document.
Read the document's own language and framing. Cross-check
against the manuscript's claim.

### 7. Quotation Fabrications

A quotation that has no verifiable verbatim source — a
plausible-sounding-but-fabricated quote intended to add
documentary specificity. The most damaging anti-pattern.

**Detection:** Every quotation must trace to a Tier 1
verbatim source via WebSearch. Failed verification means
the quotation is REJECTED (removed) or recast as Tier 2
attributed paraphrase (without quotation marks).

### 8. Footnote-Only Fix Drift

When a fact-correction is applied to a footnote / endnote
but the same misattribution still appears in the chapter
prose body. The footnote is fixed; the prose still says
"as Nestle and Petticrew documented in Steele's 2019
paper..." even though Nestle and Petticrew aren't on the
paper. This anti-pattern surfaces during fact-correction,
not during initial writing — the audit catches the wrong
attribution in the citation, applies the fix to the
endnote, but doesn't sweep the prose for the same
misattributed names / titles / dates / phrases. The
result: the manuscript ships with the same wrong
attribution still visible in the prose.

**Detection:** When applying any citation correction,
grep the entire chapter (and where appropriate, the
entire manuscript) for the misattributed string(s) —
author surnames, paper title fragments, dated phrasing,
attributed organisations — and apply the same correction
to ALL instances, not just the footnote / endnote. After
applying, re-grep to confirm the misattributed strings
appear nowhere in the chapter. Report the correction as
complete only when both the footnote AND the prose
mirror are clean. (This anti-pattern was surfaced in
operational use when a bias-balance pass caught two
prose-mirror failures the fact-audit's footnote-only fix
had missed.)

## First-X Priority Flagging Rule (v2.7.11)

A specific subclass of claim is the highest-risk for incorrect
attribution: "first commercial X" / "first patented X" / "first
to develop X" / "first to manufacture X" / "the first [X]".
Trade microhistory and biographical attribution claims of this
class fail at significantly higher rates than other claims
because secondary sources copy each other uncritically and the
canonical first-priority filing is frequently in a jurisdiction
or by an inventor different from the secondary-source consensus.

**Mandatory rule:** every "First X" claim in the manuscript
MUST be triangulated against at least two independent secondary
sources at Stage 9b (NF) / Stage 9 Continuity Audit (fiction
when real-world anchors are present). Resolution paths:

- **Multiple priority claimants exist:** soften the prose to
  acknowledge the contested-priority history. Classify the
  claim as SPECULATIVE in the verification ledger with the
  contested-priority map referenced.
- **Single canonical claimant exists:** verify the specific
  date and patent (if any). Classify as VERIFIED with primary-
  source URL pinned.
- **No canonical claimant can be confirmed:** REJECT the claim
  (remove from prose) or reframe entirely without the priority
  language.

The rule applies to chapter drafting (Phase 3 — Content Writer
flags every First-X claim with `[FIRST-X-CLAIM: {summary}]`
markers) and to Stage 9b verification (markers are removed only
after the claim is resolved per one of the three paths above).

This rule was introduced in v2.7.11 after a documented NF
production failure where six "first patented X" / "first
commercial X" claims survived all 13 editorial pipeline stages
and shipped publication-ready, despite contradicting primary-
source historical record.

## Sampled VERIFIED Re-check Rule (v2.7.11 — applied at Stage 13)

The Stage 13 Publication Readiness Gate (or fiction equivalent
Pre-Pub Verification) MUST sample-verify the verification
ledger's VERIFIED entries before granting READY. The rule
addresses the documented failure mode where a Stage 9 audit
returned VERIFIED status with hallucinated source URLs that
were never spot-checked by the orchestrator.

**Sampling discipline:**

- For at least 10% of VERIFIED ledger entries (minimum 5
  entries; or all entries if fewer than 5 exist), the gate
  runs WebFetch + Web-Content Verification on the pinned
  URL/DOI to confirm the source resolves and contains the
  claimed content.
- Sample selection MUST include: the most recently added
  entries, every entry tied to a "First X" priority claim,
  every entry tied to a patent claim, and a random selection
  to cover the rest.
- Failure of any sample (URL doesn't resolve, paywall stub,
  content doesn't match the claim) downgrades the entry to
  unverified-uncategorized in the ledger and BLOCKS Stage 13.

This rule applies the v2.7.7 Subagent Output Verification
binding to Stage 9b's output: the orchestrator does not trust
the ledger's URL field at face value but spot-checks a
representative sample, treating the ledger as evidence to be
verified rather than a source of truth to be accepted.

## Hard Rules

1. **Pre-cutoff content is NOT exempt.** Pre-cutoff training-
   data errors (wrong-attribution, date-drift, detail-
   errors) are equally dangerous to post-cutoff
   fabrications. The discipline applies to ALL specifics
   regardless of date.

2. **WebSearch is the verification mechanism.** It is the
   binding wire that converts capability into requirement.
   Where WebSearch is unavailable (offline / restricted
   environments), Phase A and Phase B cannot complete; the
   manuscript cannot be declared publication-ready.

3. **"Defer to pre-press" is NOT a valid resolution.**
   Stage 9 Fact Audit cannot complete with non-zero
   unverified items. Stage 13 Publication Readiness
   cannot grant READY with non-zero unverified items.

4. **Three-class output labeling is MANDATORY.** Every
   manuscript delivery includes a per-class manifest:
   X VERIFIED specifics (with pinned sources), Y
   SPECULATIVE specifics (with chapter/section locations
   and prose markers), 0 REJECTED items (or NOT-READY
   verdict).

5. **Quotation discipline is strict.** Three tiers + hard
   rejections, no middle ground.

6. **Material context is part of verification.** Funding
   sources, conflicts of interest, retraction history,
   publication context — when these change interpretation,
   they are not optional add-ons.

7. **First-X priority claims trigger triangulation.** See
   First-X Priority Flagging Rule above.

8. **VERIFIED ledger entries are evidence, not truth.** See
   Sampled VERIFIED Re-check Rule above. The Stage 13 / Pre-
   Pub Verification gate spot-checks a representative sample
   before trusting the ledger.

9. **Pending-marker placeholders are HARD GATEs, not future
   tasks.** `scripts/pending-marker-scan.sh` MUST return
   zero matches before Stage 9b (NF) / Stage 9 Continuity
   Audit (fiction with real-world anchors) can begin AND
   before Stage 13 Publication Readiness can grant READY.

## Output: Publisher Handoff

The manuscript delivery package includes:

1. **The manuscript prose itself** — VERIFIED content cited
   normally; SPECULATIVE content rendered with explicit
   prose markers; zero REJECTED content.

2. **Verification ledger (`engine-data/verification-ledger.md`)**
   — every cited specific listed with class (VERIFIED /
   SPECULATIVE), pinned source URL/DOI for VERIFIED,
   prose-marker phrasing for SPECULATIVE, chapter and
   section reference, verification timestamp.

3. **Speculative content map (`engine-data/speculative-
   content-map.md`)** — every SPECULATIVE passage listed by
   chapter/section with brief description so the publisher's
   editor can confirm placement and framing match the
   imprint's house style.

4. **Stage 13 readiness statement** — explicitly READY only
   when verification ledger has 0 unverified items;
   otherwise NOT-READY with the unverified list as
   blockers.

The publisher's job becomes "review labeled SPECULATIVE
content for editorial fit," not "re-verify everything." This
is the contract the engine commits to: the publisher does
not need to perform third-party fact-checking after Ideorix
declares publication readiness.

## Where This Discipline is Wired

This protocol is referenced by (and binding on) the
following pipeline locations:

- **Story / Research Bible Construction** — Phase A
  WebSearch verification on every committed item;
  topic-landscape sweep; per-item class assignment.
  In the non-fiction engine the wiring lives in the
  Authority Builder agent and the Authority Builder
  protocol. In the fiction engine the wiring lives in
  `core-pipeline.md` § Story Bible construction and in
  the Architect-stage research handling.
- **Outline-to-Chapter Gate** — `outline-conformance.md`
  hard gate refuses to advance to chapter generation if
  the bible has unverified-uncategorized items. (This
  spec exists in both engines and is engine-shared.)
- **Content / Prose Generation** — Phase B re-verification;
  quotation discipline; explicit speculative-marker prose
  for SPECULATIVE content. In the non-fiction engine the
  wiring is in the Content Writer agent; in the fiction
  engine the wiring is in the Writer / Prose Agent.
- **Fact / Continuity Audit** — Stage 9 hardened to require
  WebSearch verification on every cited specific;
  "defer to pre-press" removed as valid resolution;
  per-claim verification ledger produced. In the non-
  fiction engine the wiring is in the Fact Audit agent;
  in the fiction engine the wiring is in the Quality
  Guardian / Canon Validator chain (factual anchor facts
  in historical / contemporary fiction tracked under the
  same three-class discipline).
- **Editorial Suite — Stage 13 Publication Readiness**
  (`editorial-suite.md`, both engines) — refuses READY
  with unverified items; three-class manifest delivered
  to user.
- **Core Pipeline 5-Layer Fact-Check Stack**
  (`core-pipeline.md`, both engines) — WebSearch wired as
  required at Layers 1, 2, and 4.

When editing this file (maintainer task), run `scripts/spec-lint.sh` (the engine's CI discipline) Check 7
to confirm fiction and nonfiction copies remain byte-
identical (this file is in the cross-engine mirror set).
