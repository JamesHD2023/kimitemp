---
name: research-a-project
description: "Start a new non-fiction project from scratch — category selection, 13-question setup, and the full research-and-write pipeline. Or build a Research Bible for writing it yourself."
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Research a New Project

Start the Ideorix Non-Fiction research-and-writing engine from the beginning.

## Two ways to work

### Full Pipeline (default)
Ideorix Non-Fiction researches, outlines, writes, verifies, and edits your entire manuscript — you approve each chapter brief and prose draft, with the 5-agent verification suite running after every chapter and the full editorial pipeline at the end.

### Research Bible Only
Ideorix Non-Fiction builds the complete research framework — Research Bible (thesis, source ledger, key figures, subject context, timeline, counter-arguments, chapter outline), Authority Voice Profile, and category-specific craft notes — then delivers a comprehensive **Research Companion** document. You write the book yourself, in your own voice, citing the sources the engine surfaced for you. When you're done, bring your manuscript back for the full editorial pipeline, powered by the Research Bible already on file.

## What happens

**Full Pipeline:**
1. **Category Selection** — Choose from 33 non-fiction categories across 15 groups (Memoir & Biography, History, Popular Science, Self-Help & Psychology, Business & Finance, True Crime, Health & Wellness, How-To & Guides, Journalism & Commentary, Creative Non-Fiction, Travel & Nature, Culture & Arts, Education & Parenting, Technology, Religion & Spirituality)
2. **13 Setup Questions** — Category, dialect, subcategory, content sensitivity, research scope, length, series position, style guide, structure type, citation style, pen name, target audience, project mode (see table below)
3. **Market Scout (mandatory pre-Phase 2)** — Live competitive landscape: bestsellers, gaps, reader demand, comparable titles, positioning opportunities. Saves to `engine-data/market-pulse.md`. Required before the Research Bible is generated, because a non-fiction book built blind to existing titles risks duplication.
4. **Research Bible (Phase 2)** — Auto-generated thesis, source ledger, key figures (real people with credentials), subject context, timeline, counter-arguments, and chapter outline (Section 9). The Phase 2 Approval Gate presents the completed Research Bible, Entity Canon Lockfile, and Source Registry to you. Chapters cannot begin until you approve.
5. **Chapter Generation** — Structural Architect plans each chapter (Argument Map, Source Checklist, Argument Escalation Check, Knowledge State, Section Budget). Content Writer drafts the prose. Prose Humaniser removes AI-isms.
6. **5-Agent Verification Suite (after every chapter)** — Source Guardian, Evidence Auditor, Citation Keeper, Expert Tracker, Argument Analyst. Numeric V-Score (0–100) reported per agent. Required before the next chapter can begin.
7. **Editorial Pipeline (Phase 5)** — Stage 0 Authority Profile pre-edit pass, then 13 numbered stages: Category-Specific Audit, Proofreader, Copy Editor, Developmental Editor, Alpha Reader, Beta Reader, Conflict Resolution, Surgical Fixes, Full-Manuscript Fact Audit, Bias & Balance Review (conditional), Multi-Source Consistency Pass, Revision Loop (conditional), Publication Readiness Assessment. Plus 2 conditional inserts: Stage 4.5 Repetition Sweep (manuscripts ≥40k words) and Stage 14 Methodological Appendix Builder (academic / policy / scholarly orientation projects).
8. **Delivery** — Formatted manuscript, KDP non-fiction metadata, cover concepts, full editorial report.

**Research Bible Only:**
1. **Category Selection** — Same 33 categories
2. **13 Setup Questions** — Same setup, choosing "Research Bible Only" at Q13
3. **Market Scout** — Same mandatory pre-Phase 2 step
4. **Research Bible** — Auto-generated framework with full source ledger and chapter outline
5. **Research Companion** — Complete research brief delivered as `.docx`
6. **You write the book** — At your own pace, in your own voice, citing the sources the engine surfaced
7. **Return for editing** — Bring your manuscript back for Research-Bible-aware editorial

## How to start

Say any of:
- "Research a project"
- "Write a non-fiction book"
- "Start researching"
- "I want to write about [subject]"
- "New non-fiction project"
- "Build a research bible"

The engine will walk you through every step interactively. You approve each phase before it proceeds.

## What you'll need to decide

| Question | What it controls |
|----------|------------------|
| Category | Subject domain. Loads category-specific craft rules, evidence requirements, KDP category mapping, cover specs. |
| Dialect | American vs British English. Locks Proofreader and downstream agents. |
| Subcategory | Category-internal scoping (e.g., Memoir → Coming-of-Age vs Recovery vs Travel-Memoir). 3–6 options per category. |
| Content sensitivity | 0–5 rating. Drives per-chapter Content Sensitivity flags and Bias & Balance review activation. |
| Research scope | Primary / Secondary / Mixed / Interview-based / Archival. Determines source-corpus expectations and Source Guardian's verification depth. |
| Length tier | Short (~15K) / Standard (~50K) / Comprehensive (~80K) / Reference (~120K). |
| Series position | Standalone / first-in-series / continuation. Triggers Phase 0 (Series Architecture) for series projects. |
| Style guide | Upload existing writing for voice extraction, describe preferred style, or use category defaults. Drives Authority Voice Profile. |
| Structure type | Chronological / Thematic / Problem-Solution / Argument-Driven / Instructional / Narrative / Hybrid. Maps to a framework in `beat-structures-nonfiction.md`. |
| Citation style | Chicago / APA / MLA / Harvard / Informal. Locks bibliography format and in-text citation handling. |
| Pen name | Real name, existing pen name, new pen name (launches Pen Name Studio), or decide later. |
| Target audience | General / Informed / Specialist / Mixed. Configures jargon management, evidence density, explanation depth. |
| Project mode | Full Pipeline or Research Bible Only. |
