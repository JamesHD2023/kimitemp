---
name: dopamine-ladder
description: "Universal six-level reader-engagement framework for scene openings, chapter hooks, scene endings, and per-scene engagement diagnostics. Engine-agnostic, genre-agnostic. Applies wherever fiction prose is generated."
version: "2.3.3"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*


# Dopamine Ladder (Universal Engagement Framework)

This is the universal six-level reader-engagement framework that
applies to every scene, every chapter opening, every chapter
ending, and every key character moment in any genre. Engine-
agnostic and genre-agnostic.

The ladder maps the reader's psychological response curve as they
move through prose: from instant attention capture, through
sustained narrative tension, to long-term emotional bonding. Used
diagnostically, it surfaces which engagement levels a scene is
hitting and which it is missing — and prescriptively, it gives the
Writer a checklist of escalating triggers to deploy when prose
feels flat.

## Why universal

Engagement psychology operates above the genre layer. A romance
first kiss, a thriller set-piece climax, a mystery revelation, and
a literary character moment all need the same six engagement
levers — they just deploy them in different proportions. A scene
that hits Stimulation but never reaches Captivation feels showy
but empty; a scene that hits Captivation without Validation
frustrates; a scene without Affection has nothing to bring the
reader back. These dynamics hold across genres.

The Dopamine Ladder is loaded as a standard prose-craft reference
for every Writer call where engagement matters — i.e. all scene-
level prose generation. Genre files may add genre-specific
emphasis (e.g. romance leans hardest on Affection; thriller leans
hardest on Anticipation), but the six levels themselves are
constant.

---

## The six levels

Each level represents an escalating psychological trigger. They
are sequential when used in scene construction (lower levels
prime the reader for higher levels) but multiple levels can fire
simultaneously in a single sentence.

### Level 1 — Stimulation (Sensory Hook)

**Purpose:** Pull the reader into the scene by stimulating
sensory, emotional, or conceptual attention within the first
line or first paragraph.

**Triggers:**

- A vivid sensory image rooted in a specific detail
- A sharp emotional beat (small or large)
- A contradiction, anomaly, or pattern break
- Sudden motion or change
- A surprising line of dialogue

**Examples of the trigger shape:**

- "The sky cracked open like glass."
- "I didn't realise it was the last morning I'd ever see him alive."
- "The hotel lobby smelled of carpet cleaner and his grandmother's
  perfume. He hadn't expected the second one."

**Diagnostic:** A scene that opens without Stimulation is starting
too early. Cut everything before the point of attention; start
later.

### Level 2 — Captivation (Curiosity Hook)

**Purpose:** Introduce an unresolved question, mystery, or implied
gap the reader must close.

**Triggers:**

- An implicit question raised by what's on the page
- A hint at a secret, withheld information, or a missing piece
- An unexpected problem the reader can't immediately solve
- A pattern broken from what the reader was assuming would
  continue
- Two facts that can't both be true (and the reader wants to
  know which is)

**Triggers in fiction:**

- Micro-mysteries embedded in description ("his coat was hanging
  by the door" after he had said he'd never return)
- Emotional contradictions (warmth offered with cold body
  language)
- Social tension (something unsaid in a room of three people)
- Omitted explanations (a character reacts strongly to something
  the reader doesn't yet know is significant)

**Diagnostic:** A scene that hits Stimulation but not Captivation
will be vivid and forgettable. The reader's eye moves on without
forward pull.

### Level 3 — Anticipation (Narrative Momentum)

**Purpose:** Build forward motion by giving the reader something
specific to expect — but delaying the payoff.

**Triggers:**

- Foreshadowing (a future event implied by present detail)
- Countdown structures (a clock established, time pressure
  active)
- A looming confrontation the reader can see coming
- Misdirections that channel reader prediction toward the wrong
  payoff
- Teasing without revealing key information ("she would tell him
  the truth — but not yet")

**Diagnostic:** A scene that hits Captivation but not Anticipation
generates curiosity that goes nowhere. The reader wonders but
doesn't push forward.

### Level 4 — Validation (Satisfying Payoff)

**Purpose:** Reward the reader by answering the curiosity created
in lower levels — but in a surprising or emotionally impactful
way.

**Triggers:**

- Reveal information that has been earned (planted earlier, not
  appearing fresh in the climax)
- Twist the expected answer (the reader was promised a betrayal;
  deliver one — but from a character they didn't suspect)
- Close one curiosity loop in a way that opens a new, deeper one
- Deliver "ohhh" moments where the reader sees the pattern they
  almost saw
- Earn emotional resonance through accumulated context

**Diagnostic:** A scene that hits Anticipation but not Validation
breaks reader trust. The reader feels strung along. Avoid this
across more than 1-2 consecutive chapters; build cumulative
trust by paying off something.

### Level 5 — Affection (Emotional Bond)

**Purpose:** Make the reader bond with the storyteller — narrator,
POV character, or authorial voice. This is what keeps readers
engaged when plot momentum slows.

**Triggers:**

- Show vulnerability (a flaw, a fear, a wound, a secret hope)
- Share a relatable desire or frustration the reader recognises
- Reveal an insightful worldview through what the character
  notices
- Use humour, wit, or charm appropriate to the character's voice
- Show competence or agency — the character earning their
  position in the story
- Let the character help, protect, or stand up for someone (often
  for someone smaller or weaker)

**Examples of the trigger shape:**

- A grumpy character secretly feeding stray cats
- A hero making an awkward mistake that costs them socially
- A villain revealing a painful memory that contextualises (not
  excuses) their actions
- A POV character noticing something kind about a character the
  plot is asking them to dislike

**Diagnostic:** A scene heavy on plot mechanics but light on
Affection produces "well-constructed but cold" prose. Readers
finish but don't recommend. Especially for romance and character-
driven genres, Affection is the primary engagement engine.

### Level 6 — Revelation (Meaning, Theme, or Personal Insight)

**Purpose:** Deliver a moment — small or large — where the reader
feels: "this story means something." Creates long-term emotional
memory and signals that the work offers value beyond plot.

**Triggers:**

- Character realisation that reframes earlier events
- Thematic echo (a phrase or image returning with new weight)
- Subtle philosophical or emotional insight delivered through
  action, not narration
- Unexpected connection between scenes the reader hadn't
  consciously linked
- A truth revealed at the right emotional moment (Validation +
  Revelation often arrive together at climax)

**Examples of the trigger shape:**

- "She finally understood: the cage was never the door. It was
  the fear of opening it."
- A motif that opened the book returning at the end with its
  meaning inverted
- A character speaking a truth they have been unable to speak
  for the entire book

**Diagnostic:** A scene without Revelation is fine — most scenes
don't carry one. But a *book* without Revelation feels light.
At least one Revelation per act is the working minimum; climax
chapters should always carry one.

---

## Application to scene construction

Not every scene needs all six levels. Use the ladder as a
diagnostic checklist after writing, and as a prescription when
prose feels flat.

### Opening line construction

Combine Levels 1 + 2:

> "The explosion wasn't the strange part. It was the fact that
> everyone acted like they expected it."

(Stimulation: explosion. Captivation: why is "expected it" the
strange part? What do they know that we don't?)

### Scene start template

Stimulation → Captivation → Anticipation rising into the scene
body. By the third paragraph the reader should know what they
want to see happen and what's stopping it.

### Chapter end template

Validation (close one loop) → deeper question opened (re-engage
Captivation) → Affection beat (a moment with the POV character
that bonds the reader to them) → optional Revelation hint.

### Character moment template

Affection → Validation (what the character does pays off something
established) → Revelation (their action reveals a truth about
who they are or what the story is about).

### Almost-moment / unspoken-emotion template

(Especially for romance, but applies to any high-emotion non-
action scene)

Stimulation → Captivation → Anticipation extended → withheld
Validation → Affection from the gap → optional Revelation in
what is *not* said.

---

## Per-scene self-check

Before submitting a scene, the Writer answers:

1. Which of the six levels does this scene hit?
2. Does it hit at least Levels 1, 2, and one of 3/4/5?
3. If the scene is a pivot (chapter open, chapter close, act
   transition, character introduction): does it hit Affection?
4. If the scene is a climax or near-climax: does it hit Revelation?
5. Are the levels firing in a sequence that primes the reader, or
   are they out of order in a way that creates confusion?
6. Is any single level being asked to carry more weight than it
   can (e.g. Stimulation alone trying to substitute for absent
   Captivation, producing showy-but-empty prose)?

If a scene fails 1 or 2, it's a flat scene and needs revision.
If 3 fails on a pivot scene, the reader will skim. If 4 fails on a
climax, the climax won't land.

---

## Genre-specific emphasis (informational, not prescriptive)

Different genres and book categories lean more heavily on
different levels. The genre file may surface genre-specific
overlay if applicable, but the six levels themselves are
constant.

### Fiction

| Genre | Levels typically emphasised |
|---|---|
| Romance | Affection (primary), Captivation, Anticipation, Revelation at HEA |
| Thriller | Anticipation (primary), Stimulation, Validation at set-pieces |
| Mystery | Captivation (primary), Validation at solution, Revelation at climax |
| Domestic thriller | Captivation + Anticipation (sustained), Affection with the trapped protagonist, Revelation at the explosion |
| Literary | Affection, Revelation (primary), Captivation through interiority |
| Fantasy | Stimulation (worldbuilding), Anticipation (quest), Affection with the cast, Revelation at thematic core |
| Horror | Stimulation + Anticipation (primary), Captivation through dread, Validation at the scare |

### Non-fiction

| Category | Levels typically emphasised |
|---|---|
| Memoir | Affection (primary — readers come for the narrator's voice), Revelation at meaning-making moments, Captivation through unfolding life events |
| Narrative non-fiction | Stimulation (vivid scene-setting), Captivation through the central question or mystery, Anticipation, Revelation at thematic payoff |
| Self-help / How-to | Captivation through the problem statement, Validation at each chapter's framework or technique, Affection with the author's authority voice |
| Reference / Comprehensive | Stimulation through clear structure, Validation at each section's payoff, Affection through trust in the author's expertise |
| Biography | Affection with the subject, Captivation through the central question of the life, Revelation at the subject's pivotal moments |
| History | Stimulation through period detail, Captivation through the central historical question, Anticipation through unfolding events, Revelation at thematic synthesis |
| Business | Captivation through the problem framing, Validation at each principle or framework's payoff, Affection with the author's expertise |
| Health / Wellness | Captivation through the reader's pain point, Validation at the technique's payoff, Affection with the author's empathy |
| Cookbook / Practical | Stimulation through evocative description, Validation at each recipe's payoff, Affection with the author's voice and curation |
| Essay collection | Affection (primary — voice is the engine), Revelation at each essay's pivot, Captivation through the conceit |

Cross-genre and cross-category projects should weight per the
dominant emphasis but ensure no level is entirely absent
across the manuscript.

---

## Where this block is loaded

The Dopamine Ladder is referenced from `prose-protocol.md`
(fiction) and `content-writer.md` (non-fiction) as a standard
craft reference — loaded for every Writer call as part of the
universal engagement diagnostic. Genre files may add genre-
specific overlay sections, but the six levels themselves are not
duplicated per genre.

When this file is updated, the change applies everywhere prose is
generated, regardless of genre. No parallel updates to per-genre
files required.
