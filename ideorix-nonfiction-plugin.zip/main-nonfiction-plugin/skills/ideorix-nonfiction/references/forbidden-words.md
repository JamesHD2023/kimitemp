---
name: forbidden-words
description: Comprehensive list of AI-telltale words, phrases, and names that must never appear in generated prose
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Forbidden Words List

## Overview

This list enforces three tiers of non-fiction prose quality, matching the Fiction
plugin's structure (adapted for non-fiction register):

- **TIER 1 — Zero-tolerance phrases (~193 entries):** Multi-word AI-signal
  constructions that should never appear in published non-fiction. Flag on ANY
  occurrence. No threshold.
- **TIER 2 — Zero-tolerance words (~840 entries):** Single words that scream AI
  when they appear even once in non-fiction prose ("luminous", "tapestry",
  "enigmatic", "effulgent"). Flag on ANY occurrence.
- **TIER 3 — Frequency-limited words (~139 entries):** Common English words that
  LLMs overuse but that genuinely belong in normal non-fiction ("enough", "have",
  "might", "therefore"). Flag ONLY when a word appears **4+ times per chapter** —
  that's overuse, not normal prose.

The Writer's Post-Writing Checks (see `content-writer.md`) enforce these tiers.
Tier 3 is a frequency gate, not a zero-tolerance gate — do not rewrite legitimate
uses of Tier 3 words.

- **Evidence Auditor:** Counts forbidden word occurrences as a quality metric
- **Source Guardian:** Verifies that unusual word choices are intentional (e.g., a
  quoted source uses a stylized term)

## Forbidden Phrases (193 entries)

These multi-word constructions are the strongest AI signals. Many are
academic transitions, filler phrases, or formulaic descriptions that
real fiction authors almost never use.

- A bastion of
- A clarion of
- A mosaic of
- A testament to
- After all
- Albeit with
- And yet
- As a consequence
- As a matter of fact
- As a professional
- As a result
- As aforementioned
- As an illustration
- As previously mentioned
- As such
- As well as
- At the outset
- At the same time
- Beacon of hope
- But also
- By contrast
- By the same token
- Carefully considered
- Carefully curated
- Cautionary tale
- Certainly not
- Decided to
- Delving into
- Dizzying in
- Dizzying in its
- Dizzying in their
- Drawing upon
- Drifting between
- Drifting in
- Drifting into
- Drifting through
- Drifting towards
- Drink in
- Driving force
- Embark on a journey
- Embark on an adventure
- Embark on an exploration
- Embark on an odyssey
- Entirely too
- Etched in
- Etched into
- Etched on
- Etched upon
- Etched with
- Even if
- Even though
- From the outset
- Game changer
- Given that
- Glowing in its
- Glowing with
- In a similar vein
- In a way
- In addition
- In any case
- In as much as
- In as much as to say
- In brief
- In concurrence
- In contrast
- In contrast to
- In depth
- In essence
- In fact
- In fine
- In first
- In flashes
- In juxtaposition
- In key respects
- In light of
- In many ways
- In moments
- In normal circumstances
- In order to
- In other words
- In part
- In particular
- In passing
- In perpetuity
- In practice
- In principle
- In proportion
- In short
- In some ways
- In stark contrast
- In stark difference
- In stark reminder
- In sum
- In summary
- In tandem
- In the context of
- In the end
- In the face of
- In the form of
- In the heart of
- In the midst of
- In the wake of
- In this case
- In this instance
- In this light
- In this respect
- In this vein
- In turn
- It bears noting
- It bears repeating
- It comes as no surprise
- It depends on
- It makes sense
- It's important to note
- It's worth noting
- It's worth noting that
- Keep in mind that
- Latch onto
- Leaned forward
- Managing to
- Military precision
- Mist-shrouded landscape
- Mist-shrouded world
- Mist-veiled world
- More often than not
- Needless to say
- Of course
- Of particular note
- Of tremendous
- On closer inspection
- On one hand
- On the contrary
- On the other hand
- On the whole
- One can argue
- One could say
- One might argue
- Out of the box
- Ponder over
- Ponder upon
- Pore over
- Pore through
- Practiced ease
- Redolent of
- Resonate powerfully
- Shifting between
- Shifting perspectives
- Shifting through
- Shifting towards
- Shimmering curtain
- Shimmering mirage
- Shimmering surface
- Shimmering veil
- Shimmering world
- Shouldn’t exist
- Sights unseen
- Sounds unheard
- Stark contrast
- Stark difference
- Stark reminder
- Swathed in
- Sweeping gesture
- Sweeping in
- Sweeping panorama
- Sweeping vistas
- The culmination
- The heart of
- The sea of faces
- The shape of [feeling/abstraction]
- The sum total
- The very essence
- Thematic contours
- To a degree
- To a significant degree
- To an extent
- To be sure
- To consider
- To date
- To ensure
- To illustrate
- To put it bluntly
- To put it simply
- To summarize
- To wit
- Treasure trove
- Twists and turns
- Variegated tapestry
- Vibrant exultation
- Vibrant landscape
- Vibrant symphony
- Vibrant world
- Willfully crafted
- With a view to
- Wordsmith's craft
- A variety of
- A wide range of
- Align with
- Allows for
- At the end of the day
- Boasts a
- Contributes to
- Deeply rooted
- Enables
- Enduring legacy
- Evolving landscape
- Focal point
- Gateway to
- Helps to
- Highlights its
- In conclusion
- Indelible mark
- Integral part of
- Is a reminder of
- Is a testament to
- It becomes clear
- Lasting influence
- Plays a crucial role
- Reflects broader
- Represents a shift
- Resonate with
- Serves as
- Serves to
- Setting the stage
- Stands as
- Synergy between
- That said
- This demonstrates
- This highlights
- This underscores
- Transformative power
- Underscores its
- Valuable insights

---

## TIER 3: Frequency-Limited Words

Common English words that LLMs overuse but that genuinely belong in non-fiction prose.
Flag ONLY when a word appears **4+ times per chapter** (overuse threshold).
1-3 occurrences per chapter is normal prose, not a violation.

Many of these are standard academic/journalistic vocabulary ("have", "therefore",
"essential", "consider", "critical") that cannot be zero-tolerance without breaking
legitimate non-fiction prose. Others are fiction-register words ("whispered",
"trembling", "pensive") that are extremely rare in non-fiction anyway — the
frequency threshold catches any accidental fiction-drift without flagging routine
prose.

<!-- TIER: 3 — frequency-limited, threshold: 4 per chapter -->

Consider, Considerable, Consideration, Contrast, Contrasting, Courage, Critical, Crucial, Drift, Drifting, Echo, Echoes, Embrace, Embraced, Enough, Especially, Essential, Essentially, Established, Foil, Force, Fragile, Fresh, Gasp, Gaze, Gift, Glimpse, Glow, Glowing, Great, Greater, Greatly, Hesitantly, Hum, Hushed, Immediately, Indeed, Instead, Instinctively, Led, Lent, Likewise, Lingering, Live, Lively, Logic, Measured, Mild, Mischievous, Mist, Muse, Musing, Nostalgia, Pensive, Playful, Powerful, Precisely, Precision, Prefer, Provide, Providing, Pulled, Rapidly, Readily, Realm, Remains, Remarkable, Represent, Restful, Restless, Rippling, Robust, Seen, Seeing, Seek, Seeking, Sensation, Settled, Shudder, Silhouettes, Similar, Similarly, Simplicity, Situated, Slender, Slightly, Slowly, Smoldering, Soothing, Sophisticated, Stark, Steadfast, Steadily, Stirring, Strand, Strengthen, Style, Subtlety, Sudden, Suddenly, Suggest, Suggesting, Suppressed, Surround, Surrounded, Surrounding, Sustain, Sustained, Swift, Tempered, Tendency, Tension, Terse, Textures, Themes, Therefore, Thus, Timbre, Timeless, Tinge, Tone, Trembling, Trickle, Triumph, Truly, Twists, Unease, Unexpected, Unfolding, Unique, Uniquely, Urgent, Vital, Void, Wander, Wandered, Wandering, Warmth, Warrant, Whispered, Whispering, Whispers, Wholly, Worthy

---

## TIER 2: Zero-Tolerance Words (844 entries)

Single words that LLMs statistically overuse. Many are perfectly valid English
words, but their frequency in AI output is 10-50x higher than in published fiction.
When a human author uses "luminous" once in a novel, it works. When an LLM uses
it three times per chapter, it's a tell.

### A

Aboard, Absolutely, Abundantly, Accelerate, Accordingly, Acutely, Additionally, Admirable, Admonish, Adroitly, Adulation, Advancing, Aesthetic, Affirmatively, Affluent, Aforementioned, Ah, Aha, Akin, Alas, Albeit, Aligned, All-encompassing, Alluring, Ambiance, Ambiguity, Ambitious, Amid, Amidst, Amorphous, Amplification, Analogous, Analytically, Angelic, Animating, Antecedent, Aperture, Aplomb, Apparent, Appreciably, Apropos, Arcane, Ardently, Arduous, Arguably, Arising, Arresting, Aspects, Aspirant, Assertive, Assiduous, Assimilate, Assuredly, Astounding, Attuned, Authentic, Axiomatically

### B

Backdrop, Beacon, Beguiling, Behold, Beloved, Bemused, Bespoke, Bestowed, Bewildering, Blissfully, Boldly, Bountiful, Breathtaking, Briskly, Broadly, Brusque, Bubbling, Bustling

### C

Cacophony, Calibre, Captivate, Capturing, Carefully, Carelessly, Caress, Certainly, Charmingly, Cherished, Clarity, Clearly, Clever, Cogent, Coherent, Cohesively, Colossal, Combine, Combined, Commemorated, Commendable, Commensurate, Commissioned, Committed, Commonplace, Compelling, Comprehensive, Compulsively, Concatenation, Conceal, Concerted, Concisely, Conclusive, Concomitantly, Concurrently, Conduit, Consequently, Consistently, Conspicuous, Constant, Constantly, Contagious, Contextualized, Continuously, Conundrum, Converge, Convey, Corroborate, Cosmopolitan, Countenance, Coupled, Crafted, Crescendo, Crystalline, Cultivate, Cumulative, Curious, Curiously

### D

Dazzling, Decidedly, Deft, Delicate, Delightfully, Delve, Demonstrate, Densely, Depict, Desirous, Desperately, Despite, Determined, Detonating, Dexterously, Dextrous, Diachronically, Differential, Diligently, Diluted, Diminutive, Distill, Distinctly, Distracting, Diversified, Dizzy, Dizzying, Doting, Drenched, Duly, Dynamically

### E

Eagerly, Effervescent, Effortlessly, Effulgence, Egalitarian, Elegant, Elevate, Elevated, Elicit, Eloquently, Emblematic, Embodies, Embodiment, Eminence, Emphatically, Empowering, Enchantingly, Enclave, Encompass, Encroaching, Endearing, Endlessly, Endow, Enduring, Energetic, Enigma, Enmeshed, Enormity, Enormously, Enriched, Ensure, Entail, Enthrall, Enthralling, Enthrallment, Entirely, Epiphanous, Epitomize, Epitomizes, Epitomizing, Erratic, Erudite, Essentialize, Esteemed, Etched, Eternal, Ethereal, Evocative, Evolving, Exacting, Excellently, Exceptional, Exceptionally, Exhilarating, Exhort, Exigent, Exquisite, Extemporaneously, Extensively, Extol, Extraordinary, Exuberant

### F

Fabled, Fabulously, Facets, Facility, Fanciful, Fastidious, Fatefully, Fervent, Fierce, Fiercely, Filament, Finely, Finite, Flawless, Fleetingly, Fluid, Fluidity, Flush, Fluttering, Folklore, Fomenting, Foremost, Forged, Formidable, Forthrightly, Foster, Furthermore, Fow, Fragrant, Framing, Frenzied, Fretful, Fruitful, Furtive

### G

Galvanize, Garner, Generative, Genuinely, Germane, Gestures, Glean, Glints, Glistening, Global, Glorious, Grappling, Grasping, Gratifying, Gravity, Gregarious, Groundbreaking, Grounded, Guiding

### H

Halcyon, Hallmark, Harmonious, Harness, Harrowing, Hastily, Haunting, Heighten, Herculean, Highlights, Holistic, Honed, Hotbed, However, Hypnotic

### I

Iconic, Imbued, Immaculate, Immense, Immersive, Immutable, Impactful, Imperceptibly, Imperturbably, Implacable, Imply, Implying, Importance, Importantly, Impress, Impressive, Improbably, Impulsive, Incessantly, Incisive, Incisiveness, Incite, Inclusive, Incongruous, Indelible, Indigenous, Indispensable, Indubitably, Ineffable, Ineluctable, Infinitely, Informative, Inherent, Inimitably, Innovative, Innumerable, Inquisitive, Insatiable, Inseparable, Insightful, Insights, Insouciant, Inspired, Inspiriting, Instances, Instill, Integral, Integrates, Integrating, Interestingly, Interleave, Internal, Interwoven, Intimately, Intricate, Intricately, Intriguing, Intuitively, Invariably, Invincible, Inviolable, Invitation, Irrefutable, Irrepressible, Irrevocably, Iteration, Iterative

### J

Jittery, Judiciously

### K

Kaleidoscopic, Keenly, Kindred, Kinetic

### L

Labyrinth, Labyrinthine, Lamentably, Landscape, Languidly, Languorous, Lavish, Leanly, Legendary, Legerity, Legions, Leitmotif, Lending, Leverage, Life-affirming, Light-hearted, Likened, Limitless, Litmus, Lofty, Loitering, Longevity, Longstanding, Lush, Luster, Lustrous, Lyrical

### M

Magnetic, Magnificence, Magnifies, Majestic, Majestically, Majesty, Malleability, Manifestly, Mantle, Masterful, Masterfully, Masterpiece, Matchless, Materialize, Maturation, Matures, Meander, Meandering, Meanderings, Meritorious, Metamorphosis, Meticulous, Meticulously, Mettlesome, Mevitablye, Microscape, Mightily, Milieus, Mindfully, Mindset, Misdirection, Mist-shrouded, Mist-swept, Mist-veiled, Mitigate, Mnemonic, Moat, Momentarily, Momentous, Monumentally, Moreover, Morph, Mouthwatering, Myriad, Mystical, Mystify, Mythical, Mythopoeic

### N

Narrative, Navigate, Nebulous, Nested, Nestled, Nonetheless, Notably, Noteworthy, Novelty, Nurture

### O

Occupying, Odyssey, Oftentimes, Opaque, Open-ended, Opulent, Orchestrate, Orchestrating, Organic, Ornamented, Ornate, Ostensibly, Ostentation, Otherworldly, Outrageously, Overwhelming, Owing

### P

Paradoxical, Paradoxically, Paramount, Partiality, Passionately, Patterning, Peerless, Penetrating, Perceptible, Perceptive, Perchance, Perpetual, Perplexing, Persisting, Persuasively, Pertinence, Pervasive, Phenomenal, Phlegmatic, Piecemeal, Piled, Piquant, Pivotal, Placid, Plausibly, Pleasing, Poignant, Pointedly, Poise, Poised, Ponder, Pondered, Pondering, Ponderous, Ponders, Pore, Pounder, Precipitously, Preeminent, Preemptively, Preeninent, Presages, Presaging, Preside, Preternatural, Prism, Pristine, Proactive, Probing, Problematizing, Profound, Profoundly, Profusely, Profusion, Progressively, Prolific, Prominent, Pronounced, Propelled, Propitious, Propounds, Prosper, Prospered, Prosperity, Protean, Prototypical, Provenance, Proximate, Prudent, Pulsing, Purposeful, Puzzling

### Q

Quiescent, Quintessentially

### R

Radiant, Rarified, Raucous, Ravishing, Re-envision, Reaffirm, Realization, Realms, Rebirth, Recalcitrant, Receptive, Reckon, Recondite, Reconfiguring, Recosider, Recourse, Recurrent, Redolent, Redoubtable, Regal, Regale, Regenerative, Reinvent, Reinvigorate, Relentlessly, Relevance, Remediation, Reminds, Remitting, Remnant, Remunerate, Renowned, Reorient, Replete, Representations, Reputable, Requisite, Resonant, Resonate, Resounding, Resoundingly, Resplendence, Resplendent, Resurgence, Reverberate, Reverberating, Revered, Reverence, Revolving, Richly, Rigorous, Romantic, Rooted, Roseate, Ruminating, Ruminative

### S

Salient, Saliently, Sanguine, Sapient, Saturating, Savory, Scintillating, Scrupulous, Scrutinize, Seamlessly, Searchingly, Sedate, Seemingly, Seize, Semblance, Sensational, Sensibilities, Sensual, Sentience, Sentinel, Serendipitously, Serenity, Sever, Shading, Sheen, Shifting, Shimmer, Shimmering, Silky, Simultaneously, Singularity, Sinuous, Skillfully, Sleek, Slinky, Slither, Soft-spoken, Solely, Soulful, Soundscape, Spellbinding, Spheres, Splendid, Splendor, Spontaneously, Sprawling, Staccato, Staggering, Staid, Steadied, Steely, Stellar, Stentorian, Steppingstone, Stilled, Stitching, Stoic, Storybook, Stratifying, Streamline, Strident, Strikingly, Striven, Strokes, Strut, Stunningly, Sublime, Subsumed, Succinct, Suffused, Suggestive, Summon, Sumptuous, Superbly, Superimposed, Supersede, Superstructure, Supplanted, Supple, Surmounted, Surpass, Surreal, Suspense, Suspiciously, Swath, Swathe, Swathed, Sweeping, Swirling, Symphony, Synergistic, Synergy, Synoptic, Synthe, Synthesize

### T

Tactful, Tactile, Tantalizingly, Tapestry, Tendrils, Tenebrous, Testament, Testify, Thematic, Thematically, Thinly, Thrusting, Thundering, Thunderous, Tidings, Tinkering, Tirelessly, Titilating, Toil, Tolerated, Torrent, Touchstone, Transcend, Transcendent, Transcendental, Transfix, Transfixing, Transformative, Transient, Translucent, Transmute, Transpire, Transposed, Traversed, Traversing, Treatise, Tremulous, Trepidation, Triumphant, Tropes, Truism, Tumultuous, Turbulence, Turmoil, Twi, Twine

### U

Ubiquitous, Unabashedly, Unassailable, Unbounded, Uncanny, Unceasing, Unchanging, Uncharted, Uncluttered, Uncomplicated, Unconventional, Ultimately, Uncover, Underpinned, Underpinning, Underscores, Undeterred, Undulate, Undulous, Unfailingly, Unfurling, Unheralded, Unifying, Unimpeachable, Unimpeded, Unison, Unmatched, Unparalleled, Unravel, Unraveling, Unreservedly, Unseen, Unspoken, Untrammeled, Untrodden, Unveiled, Uplifting, Urbane, Uric, Utilitarian, Utterly

### V

Vacillating, Valiant, Validate, Validation, Vanguard, Vanquish, Variegated, Vastly, Vaulting, Vaunted, Veiled, Venerable, Venerated, Ventured, Verdant, Veritable, Vernal, Versatile, Vertical, Vested, Vibrant, Vibrating, Vignette, Vigorous, Vill, Vindicate, Virtuosic, Visceral, Visionary, Vivacious, Vividly, Voluptuous, Vulnerability

### W

Wafting, Waxes, Weave, Weaving, Whiff, Whimsical, Whimsically, Whimsies, Wield, Willfully, Wistful, Wondrous, Wordsmith, Worker, Workmanship, World-renowned, Worldly, Wreathed

### Y

Yielding

### Z

Zeal

---

## Forbidden Names

These names appear in AI-generated fiction at rates far exceeding real-world
naming patterns. They are AI defaults.

- Chen
- Elara
- Lyra
- Sarah Chen

**Note:** The engine's `authenticity-guard.md` maintains a more comprehensive
banned names list specific to each genre. This list covers the universal worst offenders.

---

## Replacement Strategy

When a forbidden word is detected, the fix is NOT to find a synonym.
The fix is to rewrite the sentence using a completely different approach:

```
WRONG FIX: "The tapestry of autumn colors" → "The mosaic of autumn colors"
           (replaced one forbidden word with another)

RIGHT FIX: "The tapestry of autumn colors" → "Maples had gone orange along
            the ridge, and the oaks were two weeks behind them."
           (replaced the abstraction with a specific, observed detail)
```

**Principle:** Every forbidden word on this list shares one trait:
**vagueness masquerading as eloquence.** The replacement must be SPECIFIC,
CONCRETE, and OBSERVABLE. If you can't see it, hear it, smell it, touch it,
or taste it — rewrite it until you can.