---
name: market-scout
description: "Live non-fiction market intelligence — category trends, NF bestseller analysis, comp titles by credentials/authority, reader-demand signals, and strategic positioning via web search"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Market Scout — Engine Skill (Non-Fiction)

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/engine-data/market-pulse.md`

The Market Scout report MUST be written to the canonical
project's `engine-data/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline.
**HARD GATE — BLOCKING.**

## Purpose

Market Scout provides live market intelligence for any non-fiction category
by searching the web for current NF bestseller data, reader / professional
community discussions, methodological trends, and competitive landscape
analysis. It produces a structured Market Scout Report that informs
decisions across the NF pipeline.

## When to Use

Market Scout is loaded on demand by other skills. It runs in these contexts:

| Context | Triggered By | Purpose |
|---------|-------------|---------|
| `setup` | Research Outline Builder (Step 2 Market Pulse) OR Pre-Phase 2 (if outline pre-supplied) | Inform Research Bible with trending NF frameworks, topical angles, audience expectations, and market gaps |
| `clinic` | Manuscript Clinic (Market Viability axis) | Position an existing NF manuscript within its competitive landscape |
| `cover` | Cover Designer (Phase 1) | Identify current NF bestseller cover trends, visual language, what's dated |
| `marketing` | Marketing Expert (Phase 1) | Marketing copy trends, hooks that convert NF buyers, keywords, audience targeting |
| `trailer` | Video Trailer Designer (Phase 1) | Video marketing trends specific to NF (BookTube long-form, Substack-promotion video, YouTube essay style) |

## Trigger Phrases

Activate when:
- Another skill loads this file for market research
- The user explicitly asks for market research, market analysis, or category trends
- The user says "what's selling in {category}", "market scout", "category demand",
  "comp titles", "who else is writing about this", or "what's the competition"

---

## Inputs

**Required:**
- `category` — The NF category ID (e.g., "popular-history", "memoir",
  "self-help", "popular-science", "business-leadership", "true-crime",
  "narrative-nonfiction")

**Optional:**
- `context` — One of: "setup", "clinic", "cover", "marketing", "trailer"
  (defaults to "setup")
- `manuscript_title` — If positioning a specific manuscript (clinic context)
- `subcategory` — Narrow the search to a specific subcategory if known
  (e.g., "WWII-history" within popular-history; "addiction-memoir" within
  memoir; "habit-formation" within self-help)
- `authority_profile` — Author credentials / lived experience (informs
  comp-title selection: comp on credential parity, not just topic)

---

## Market Research Protocol

### Phase 1: Live Web Search

Run 3–5 targeted web searches for the category's current NF market.
Searches should cover:

1. **Current NF bestsellers** —
   "[category] bestselling books [current year]" + "[category] NYT
   nonfiction list [current year]" + "[category] Goodreads non-fiction list"
2. **Reader and professional community discussions** —
   "[category] readers want [current year] reddit goodreads" +
   "[category] Substack newsletter recommendations" +
   "[category] BookTube long-form review"
3. **Trending frameworks, methodologies, and topical angles** —
   "[category] popular frameworks [current year]" +
   "[category] new perspectives [current year]" +
   "[category] research approaches breakthrough"
4. **Recent notable releases** —
   "best new [category] books [current year]" +
   "[category] critically acclaimed nonfiction"
5. **Market dynamics** —
   "[category] book market demand competition [current year]" +
   "[category] publishing trends agents acquiring"

Adapt search queries to the context:
- `cover` context: Add "nonfiction cover design trends",
  "bestseller covers [category]", "academic vs trade cover [category]"
- `marketing` context: Add "book marketing [category]",
  "Amazon NF description trends", "subhead conventions [category]"
- `trailer` context: Add "book trailer trends nonfiction",
  "BookTube long-form discovery", "Substack video promotion"
- `clinic` context: Add "reader complaints [category]",
  "what NF readers want [category]", "DNF reasons [category]"

### Phase 2: Structured Analysis

Analyse the search results (combined with category-bank data from the
relevant NF category file at `references/<category>.md`) into a
structured Market Scout Report:

**1. Demand vs. Saturation** (3–5 sub-niches within the category):

For each sub-niche, assess:
- Demand level: High / Medium / Low
- Saturation: High / Medium / Low
- Opportunity: Strong / Moderate / Weak

Focus on gaps where reader / professional demand outstrips supply — these
are the positioning goldmines for an NF author.

**2. Trending Frameworks / Topical Angles** (4–6 with momentum):

For each framework or angle:
- Direction: Rising / Peaking / Declining
- Evidence: Brief example of recent NF book(s) using it
- Relevance: How it connects to the user's category/subcategory and
  authority profile

This section directly informs methodological / structural choices in
the Research Bible (parallel to fiction's trope selection, but NF-shaped:
NF readers respond to *how* you frame the material, not which beats you
hit).

**3. Emerging Themes** (3–4 themes):

Fresh topical angles gaining traction in the category. For each:
- What the theme is (e.g., "post-pandemic loneliness research" in
  popular psychology; "rural healthcare collapse" in narrative
  non-fiction; "AI-as-research-collaborator memoir" in memoir)
- Why it resonates now (cultural moment, news cycle, professional /
  academic conversation pushing into mainstream)
- How to incorporate it without being derivative or chasing the news

**4. Reader / Audience Expectations**:
- *Must-have elements* — Non-negotiable for the category (NF readers
  will DNF without these — e.g., source citations in popular history,
  exercises / takeaways in self-help, scene-level narrative in
  narrative non-fiction)
- *Fresh opportunities* — Ways to differentiate within the category
  (a novel framework, an underrepresented voice, a methodological twist)
- *Overdone elements* — What to avoid (clichéd structures, exhausted
  topical takes, overused authority signals)

**5. Comp Titles** (3–5 current NF bestsellers — comp on **credential
parity + topical proximity**, not just topic):

For each comp title:
- Title, author, approximate release date
- Author's authority basis (academic credentials, professional
  experience, lived experience, journalistic record — match this to
  the user's authority profile when possible)
- Why it's relevant (similar topic angle, audience, positioning,
  voice register)
- What it does well that the user can learn from
- What gap it leaves that the user could fill

**6. Price Point Guidance**:
- Optimal price range for the category and format (ebook, trade
  paperback, hardcover; NF hardcovers price higher than fiction —
  account for that)
- Series / sequel pricing strategy if applicable (most NF is
  standalone; some categories — business-leadership, self-help —
  develop into follow-up titles)
- KU (Kindle Unlimited) vs wide distribution recommendation for the
  category (NF skews more wide-distribution than fiction; KU works
  for some categories — health, self-help, business — but not for
  others — heritage history, biography, narrative non-fiction)

**7. Strategic Positioning** (1 paragraph):

Concise, actionable advice for an NF author entering this category right
now. What specific topical angle, framework, authority hook, or approach
would give them the best shot at standing out? How does their credential
basis affect positioning (e.g., "no formal credential" → emphasise lived
experience and journalistic discipline; "academic credential" → make the
expertise readable for a trade audience)?

---

## Context-Specific Output Adapters

After generating the full report, emphasise different sections based on
context:

### Setup Context
**Emphasise:** Trending Frameworks / Topical Angles, Reader Expectations,
Demand vs. Saturation
**De-emphasise:** Price Point, Comp Titles (keep but shorten)
**Additional output:** Present trending frameworks as selectable options
that can feed into the Research Bible's "Section 3: Methodology &
Frame" and "Section 8: Angle Plan". Ask: "Which of these market insights
should we build into your Research Bible? Pick any that resonate."
Use AskUserQuestion with multiSelect: true.

### Clinic Context
**Emphasise:** Comp Titles, Strategic Positioning, Reader Expectations
(overdone elements)
**Additional output:** Position the user's manuscript within the
competitive landscape. What makes it stand out? What's its closest
comp on the credential + topical proximity axis? Where does it need
differentiation?

### Cover Context
**Emphasise:** Comp Titles (focus on their cover designs), Demand vs.
Saturation
**Additional output:** Current NF bestseller cover trends — dominant
colours, typography styles, imagery types, what's dated. Note category
sub-conventions: trade NF skews "designed minimalism + bold sub-title";
academic-leaning NF skews "image + serif title"; memoir skews "photo +
script title"; business / self-help skews "single visual motif + bold
sans-serif". Feed findings into Cover Designer Phase 2.

### Marketing Context
**Emphasise:** Reader Expectations (must-haves for copy), Comp Titles
(for positioning), Price Point
**Additional output:** Keywords and phrases that resonate with NF
readers in this category — typically credential signals + topical
specificity + benefit / promise (for prescriptive NF) or
narrative-promise + voice register (for narrative NF). Hooks and
emotional triggers that convert NF buyers (curiosity gap, expertise
signal, social-proof anchor).

### Trailer Context
**Emphasise:** Comp Titles (look for video trailers — note that NF
trailer presence is weaker than fiction), Emerging Themes
**Additional output:** Current NF trailer trends — BookTube long-form
reviews, author-on-camera interviews, Substack short-form video promo,
YouTube essay-format discovery. NF readers discover books via
recommendation chains (newsletter → review → buy) more than visual
trailers; weight expectations accordingly.

---

## Output

### Report File

Save the full Market Scout Report to:
`Ideorix-Projects/[Title]/engine-data/market-pulse.md`

### Report Format

```markdown
# Market Scout Report — {Category}
Generated: {date}
Context: {context}
Author authority profile: {credential basis, if known}

## Demand vs. Saturation
| Sub-niche | Demand | Saturation | Opportunity |
|-----------|--------|------------|-------------|
| {name}    | {H/M/L}| {H/M/L}   | {S/M/W}     |

## Trending Frameworks / Topical Angles
1. **{Framework / Angle Name}** — {Rising/Peaking/Declining}
   Evidence: {recent NF example}
   Relevance: {fit to user's category and authority profile}

## Emerging Themes
1. **{Theme}** — {why it resonates now in NF discourse}

## Reader / Audience Expectations
**Must-haves:** {list — category-specific}
**Fresh opportunities:** {list}
**Overdone:** {list}

## Comp Titles (credential + topical proximity)
1. **{Title}** by {Author} ({year})
   - Authority basis: {credential type}
   - Relevance: {why this is the closest comp}
   - Strength: {what it does well}
   - Gap: {what it leaves open}

## Price Point Guidance
- Ebook: {range}
- Trade paperback: {range}
- Hardcover (if applicable): {range}
- KU recommendation: {yes/no + category-specific reasoning}
- Wide distribution recommendation: {yes/no + reasoning}

## Strategic Positioning
{paragraph — topical angle + framework + authority hook}
```

---

## Fallback Protocol

If web search is unavailable or fails:

1. Note the failure explicitly: "Market Scout: Live web search unavailable.
   Falling back to static NF category data."
2. Use the NF category file's reader expectations, quality check criteria,
   and category-specific craft techniques as a substitute data source
3. Still produce the report structure, but mark sections as "Based on
   static category data — not live market research"
4. Do NOT fabricate market data, bestseller lists, or trending frameworks.
   If you don't have live data, say so.

---

## Relationship to Other Engine Files

| Engine File | Relationship |
|-------------|-------------|
| `research-outline-builder.md` | Market Scout runs at Step 2 (Market Pulse Research) — feeds trending frameworks and reader expectations into Research Bible choices |
| `manuscript-clinic.md` / `manuscript-clinic-protocol.md` | Market Scout runs when Market Viability is selected — provides competitive landscape for manuscript positioning |
| `cover-designer.md` | Market Scout runs at Phase 1 — provides current NF bestseller cover trends |
| `marketing-and-cover.md` | Market Scout runs at Phase 1 — provides marketing copy trends and NF-buyer psychology |
| `authority-builder.md` | Authority Profile feeds Market Scout's comp-title selection (credential parity matching) |
| `_index.md` | NF category index — Market Scout consults the category file at `references/<category>.md` for static fallback data |
| `core-pipeline.md` | Market Scout is a Tier 2 skill loaded on demand |

---

## Quality Criteria

### Accuracy
- All market claims must be sourced from web search results
- Do not hallucinate bestseller lists, sales figures, or trend data
- If a claim cannot be verified, mark it as "anecdotal" or "estimated"
- For NF specifically: do not invent author credentials, academic
  affiliations, or institutional sources

### Actionability
- Every section must contain information the user can act on
- Avoid vague advice ("write a good book") — be specific
  ("readers in popular-psychology are currently responding to
  frameworks that bridge clinical research and personal practice,
  with a specific example structure: research summary → case study
  → exercise → reflection")

### Recency
- Prioritise data from the current year and last year
- Flag any data older than 2 years as potentially outdated
- NF community signals (Substack, BookTube long-form, professional
  newsletter recommendations) often lag fiction signals by 6–12
  months — emphasise the most recent independent corroboration

### Honesty
- If the category is saturated, say so
- If the category is niche with limited data, acknowledge the limitation
- Do not oversell opportunities — an honest assessment serves the
  author better
- NF-specific: if the author's authority profile doesn't fit the
  category conventions (e.g., no credential basis for a science book,
  no journalistic record for an investigative book), flag the
  positioning challenge directly
