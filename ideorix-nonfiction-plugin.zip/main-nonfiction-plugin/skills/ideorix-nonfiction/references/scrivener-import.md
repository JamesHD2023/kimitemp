---
name: scrivener-import
description: "Import a Scrivener non-fiction project — preserves manuscript prose, binder structure, Key Figures, locations, and research notes"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the user-facing skill. The technical implementation protocol lives in `scrivener-importer.md` (same folder) — loaded by reference once the user triggers an import.


> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine


# Scrivener Import (Non-Fiction)

Bring your Scrivener non-fiction project into Ideorix Non-Fiction. The
importer parses the binder, extracts every chapter's prose, maps your
Characters/People/Places folders into the Research Bible, preserves your
Research folder notes, and lands you in a working Ideorix Non-Fiction
project ready for the full editorial pipeline (Continue Researching,
Edit & Revise, Manuscript Clinic, Fact-Checking, etc.).

Handles two cases automatically:
- **Full-prose Scrivener projects** — your written chapters become
  Ideorix chapter files; you can run them straight through Edit &
  Revise or Manuscript Clinic for a fact-check and editorial pass
- **Outline-only Scrivener projects** — synopses become Section 9
  chapter outline entries ready for chapter generation; you proceed to
  Research Bible review

**Works for any non-fiction category.** Scrivener is the most common
drafting tool for long-form non-fiction — memoir, biography, history,
popular science, investigative journalism, literary non-fiction,
academic works. The importer reads the binder structure without
assuming any particular category format.

## What it does

| Task | What happens |
|------|-------------|
| **Binder parsing** | Reads `.scrivx` XML to map your full project structure |
| **Manuscript extraction** | Each chapter Text item's body RTF → Ideorix chapter file (RTF converted to clean markdown with inline citations preserved) |
| **Synopsis preservation** | Your one-line synopses become Section 9 (Chapter Outline) entries |
| **People/Characters import** | Each item in your Characters, People, or Cast folder → Section 7 (Key Figures) entry |
| **Place import** | Each item in your Places or Locations folder → Section 5 (Subject Context) entry |
| **Research folder import** | Items in Research, Notes, or Sources folders → raw material for Section 4 (Key Sources & Evidence Base), surfaced to the user during Research Bible review |
| **Footnotes & endnotes** | Preserved in chapter prose as markdown footnotes; citation text extracted into a candidate sources list |
| **Folder hierarchy preservation** | Top-level folders (Parts, Sections, Periods) preserved as chapter groupings or Section 6 (Timeline) |
| **Reduced setup** | Skips outline source (already provided); asks only for what Scrivener doesn't record (category, dialect, citation style, voice profile, pen name, research scope) |
| **Smart hand-off** | Full-prose projects → Edit & Revise, Manuscript Clinic, or Fact-Checking pass. Outline-only projects → Research Bible review then chapter generation. |

## How to start

Say any of:
- "Import from Scrivener"
- "Import my Scrivener project"
- "Bring my Scrivener work across"
- "Scrivener import"
- "I have a Scrivener project"

Or pick **Import Project** from the Writers Studio or Full Creative Suite
menu, then choose **Scrivener** as the source.

## How to prepare your Scrivener project

The simplest path:

1. **Close your project in Scrivener** (so the bundle is in a clean state)
2. Find your `.scriv` folder in Finder/Explorer
3. Right-click → **Compress** (Mac) or **Send to → Compressed folder** (Windows)
4. Save the resulting `.zip` to `~/Documents/Ideorix-Projects/imports/`

That's it. The importer accepts:
- A `.zip` of the `.scriv` directory (recommended for cloud transfer)
- The `.scriv` directory itself (if you're already working locally)

You don't need to "Compile" or "Export" anything from Scrivener — the
importer reads the project bundle directly. This preserves footnotes,
inline citations, and formatting that a Compile export might flatten.

## What gets imported

From a Scrivener non-fiction project, the importer brings across:

- **Manuscript prose** — every chapter from the Manuscript/Draft folder, with paragraphs, italics, em dashes, and inline formatting preserved
- **Footnotes and endnotes** — converted to markdown footnotes and extracted as candidate sources
- **Inline comments on citations** — surfaced as fact-check hints for the Evidence Auditor
- **Synopses** — your one-line chapter/scene summaries
- **People** — from Characters, People, Cast, or Subjects folders, whatever you call it
- **Places** — location entries from Places or Locations folder
- **Research folder content** — all RTF notes preserved as raw material for Section 4
- **Notes folder content** — author notes preserved as candidate Research Bible additions
- **Binder hierarchy** — Parts, Sections, Periods, or whatever grouping you used
- **Project title** — from the `.scrivx` ProjectProperties

## What is NOT imported

- **Trash folder content** — silently ignored, never imported
- **Snapshots** — Scrivener's revision history isn't carried across (Ideorix has its own snapshot system)
- **Project settings** (label colours, status flags, custom metadata fields beyond name/description) — v1 ignores these
- **Compile presets** — Ideorix has its own export pipeline (Phase 6)
- **Scrivener research files** (PDFs, web archives, images) — these stay in your local Scrivener project; only text-based notes are imported. A reference list is generated so you can hand-copy source URLs/paths into Section 4 during review.

## What Ideorix will ask you after import

Scrivener doesn't record the things Ideorix Non-Fiction needs for its
research pipeline. After the import completes, you'll be asked for:

1. **Category** — Memoir, Biography, History, Popular Science, True Crime, etc. — controls which category plugin loads
2. **Subcategory** — finer category
3. **Dialect** — US or GB English
4. **Length tier** — inferred from word count, confirmed by you
5. **Research scope** — shallow / standard / deep
6. **Citation style** — inferred from detected footnote/endnote format, confirmed by you
7. **Content sensitivity level** — for memoir with living persons, true crime, sensitive topics
8. **Target audience expertise** — general reader / informed reader / specialist
9. **Voice profile** — attach an existing Authority Voice profile, build one now, or skip
10. **Pen name** — attach existing, create new, or skip

Skipped (Scrivener already provides the answer):
- Outline source — your binder is the outline
- Project mode — inferred from whether the import is full-prose or outline-only
- Structure type — inferred from binder hierarchy

## What you get back

A fully populated Ideorix Non-Fiction project workspace:

```
~/Documents/Ideorix-Projects/{Your Title}/
├── project-config.md              Project metadata + setup answers
├── manuscript/
│   └── chapters/
│       ├── chapter-01.docx        (full-prose mode only)
│       ├── chapter-02.docx
│       └── ...
├── engine-data/
│   ├── research-bible.md          Built from binder hierarchy
│   ├── sources.md                 Candidate sources from footnotes + Research folder
│   ├── figures.md                 Key Figures from People/Characters folder
│   ├── places.md                  Locations from Places folder
│   ├── chapters/                  Raw markdown copies
│   ├── summaries/                 Auto-generated for full-prose mode
│   ├── research-notes/            Preserved Research folder content
│   └── imports/
│       └── scrivener-bundle/      Original .scriv (kept for reference)
└── marketing/
```

From there:
- **Full-prose mode** → choose Edit & Revise, Manuscript Clinic, Fact-Checking pass, or Export & Publish
- **Outline-only mode** → review the Research Bible, then proceed to chapter generation with the Outline Conformance Agent enforcing your binder structure

## Why this matters

Scrivener has been the industry standard for ~20 years, and is the
most common tool for long-form non-fiction drafting. Many non-fiction
writers have decades of work locked inside `.scriv` bundles — manuscripts
in progress, research notes, source references, interview transcripts,
timeline files. This importer is the bridge: bring your existing non-
fiction work into Ideorix's editorial and fact-checking pipeline without
reformatting, retyping, or losing your binder structure and research
notes.

> Protocol: `scrivener-importer.md`
