---
name: plottr-importer
description: Import a Plottr Word export (.docx) into Ideorix Non-Fiction — converts beats, characters, places, and storylines into a starter Research Bible
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the technical protocol document. The user-facing skill lives in `plottr-import.md` (same folder) — that's where the trigger phrases and branding rule live. This file is loaded by reference during import execution.


> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

# Plottr Importer (Non-Fiction)

## Purpose

Convert a Plottr **Word export** (`.docx`) into a working Ideorix
Non-Fiction project with a starter Research Bible — Key Figures, places,
argument threads, timeline, structure beat, and chapter outline — ready
to feed into Research Bible review and then chapter generation. Plottr
imports an OUTLINE: there are no chapters yet, only the structural
blueprint. The handoff is to Phase 2C (Research Bible review), not Phase
3 (chapter generation).

Research-side sections that Plottr can't populate — Key Sources (Section
4), Source Assignments (Section 10), Counter-Arguments (Section 11), and
Research Gaps (Section 12) — are created as empty placeholders for the
user to fill in during Research Bible review.

This is a **one-way import.** Once complete, the Ideorix project becomes
the authoritative working copy.

## When to Use

Trigger phrases:
- "Import from Plottr"
- "Import my Plottr project"
- "Bring my Plottr outline across"
- "Plottr import"
- "I have a Plottr project" / "I'm moving from Plottr"
- "I planned my book in Plottr"

## Prerequisites

The user must provide a **Plottr Word export (`.docx`)**, produced by:

1. In Plottr, open the project to import
2. File → Export → **Word document**
3. Tick the defaults (Outline, Characters, Places, Notes)
4. Save the resulting `.docx`

The user is asked to place the file in
`~/Documents/Ideorix-Projects/imports/` (the importer finds it
automatically) or have the full file path ready.

**Why Word export and not `.pltr` JSON?** The `.docx` format is stable
across Plottr versions and subscription tiers, human-readable, and uses
predictable markers (`Begin Summary` / `End Summary`, `Description` /
`Category` / `Notes` field sequences) that make parsing unambiguous. The
`.pltr` JSON schema has changed across major Plottr releases — building
against `.docx` is more robust.

---

## Input Format Reference

A Plottr Word export contains three top-level sections in this order:

### 1. Outline section
- Begins with the standalone heading `Outline`
- Beats grouped under day headers (e.g. `Saturday`, `Sunday`, `Monday`)
  or date headers for historical non-fiction projects
- Each beat has the structure:
  ```
  {Beat Title} ({Storyline})
  Begin Summary
  {optional summary text — may be empty}
  End Summary
  ```
- Storylines tagged in parentheses: `Main Plot`, plus user-defined threads
  (e.g. `Case Timeline`, `Expert Interviews`, `Archival Research`) and
  template tracks (e.g. `Act 1: Setup`, `Act 2: Development`, `Act 3: Resolution`)
- Day headers represent chronological grouping in Plottr's timeline view
- The same day name may appear multiple times for multi-week stories

### 2. Characters section
- Begins with the standalone heading `Characters`
- Each character is a block of paragraphs:
  ```
  {Full Name}
  (blank)
  Description
  {short bio}
  Category
  {Main | Supporting | Expert | Witness | etc.}
  Notes
  {optional notes}
  Nickname
  {comma-separated aliases, may include parenthetical context}
  Age
  {age}
  Gender
  Race
  Eye Color
  Hair Color
  Skin Color
  Height
  Weight
  Religion
  City of Birth
  Education
  Job Title
  Bad Habits
  Good Habits
  Life Goals
  Fears
  ```
- Not all fields are populated for every character — handle missing fields gracefully
- Custom user-defined fields may also appear with `{Field Name}` / `{value}` pairs

**Non-fiction mapping note:** In non-fiction, Plottr characters represent
REAL PEOPLE. They map to Research Bible Section 7 (Key Figures) not to
Section 2 (Thesis). The `Description`, `Education`, and `Job Title` fields
are particularly important because they become the credentials and role-
in-the-argument for each figure.

### 3. Places section
- Begins with the standalone heading `Places`
- Same format as Characters: `{Name}` / `Description` / `Category` / `Notes`
- May be empty (the heading appears even if no places are defined)

---

## Template Beat Detection

Some beats include Plottr's built-in template instructions, identifiable by:
- A storyline tag matching `Act {N}: {phase}` (e.g. `Act 1: Setup`)
- A `--- Add Your Details Above this Line ---` marker inside the summary
- Template content below the marker (instructional text from Plottr's beat sheet templates)

When parsing:
- The text ABOVE the `--- Add Your Details Above this Line ---` marker is
  the user's actual content for that beat
- The text BELOW the marker is template instructional content — STRIP IT
- If the entire summary is template content (no user content above the marker),
  treat the beat as a structural placeholder, not a real beat

**Detected template tracks** become the STRUCTURE BEAT field for Section 9
chapter entries. The detected template name (Three-Act, Hero's Journey,
In Medias Res, Chronological) is inferred from the storyline tag pattern.

---

## Processing Pipeline

Run these steps in order. Do not parallelise.

### Step 1: Locate the export

Look for a `.docx` file in `~/Documents/Ideorix-Projects/imports/`. If
multiple are found, ask the user which one. If none, ask the user to
provide the full path.

### Step 2: Unpack the .docx

**Read-Verification HARD GATE applies (see `read-verification.md`).**
Before unpacking, verify the Plottr `.docx` Read returned content
above the threshold (≥ 100 chars). DOCX Read failures (locked files,
oversized files, corrupted exports) return success metadata with
empty extracted text — proceeding to ZIP-extraction would produce a
blank document.xml and an empty Research Bible. If the Read failed,
BLOCK and surface the failed read to the user with the three
resolution options (paste / skip / re-upload) before any parse
logic runs.

The `.docx` is a ZIP archive. Extract to a temp directory.

```
{temp_dir}/
├── [Content_Types].xml
├── _rels/
├── docProps/
└── word/
    ├── document.xml      ← the main content
    ├── media/             ← embedded character images (ignore — not used)
    └── ...
```

### Step 3: Parse document.xml

The body is a single line of XML. Extract paragraph text by walking all
`<w:p>` elements and concatenating their `<w:t>` children. Preserve order
and preserve blank paragraphs (they're structural separators between beats
and characters).

### Step 4: Validate top-level structure

Verify the document contains:
- An `Outline` heading (mandatory)
- A `Characters` heading (mandatory)
- A `Places` heading (optional but expected)

If any mandatory heading is missing, surface an error and ask the user to
re-export from Plottr with the standard sections enabled.

### Step 5: Parse the Outline section

Walk paragraphs from `Outline` until `Characters`. Track state:

- **Day/date header detected** when a paragraph matches a day name, a date,
  or a chronological marker. Start a new day group.
- **Beat title detected** when a paragraph matches `^(.+?) \(([^)]+)\)$`. Extract title and storyline tag.
- **Beat content** is everything between `Begin Summary` and `End Summary`.
- **Strip template content** if `--- Add Your Details Above this Line ---` is present.

Build an internal beat ledger:

```
beats = [
  {day: "1942-06-04", title: "Midway battle opens", storyline: "Main Plot", summary: "..."},
  {day: "1942-06-04", title: "Nimitz briefing", storyline: "Command", summary: ""},
  ...
]
```

### Step 6: Parse the Characters section

Walk paragraphs from `Characters` until `Places` (or end). Each character
starts with a non-empty title line followed by a blank then `Description`.

For each character, walk forward collecting alternating field-name /
field-value pairs until the next blank-then-name pattern. Store as a record:

```
figure = {
  name: "Admiral Chester Nimitz",
  description: "Commander-in-Chief, Pacific Fleet...",
  category: "Main",
  nicknames: ["Chester", "The Admiral (official correspondence)"],
  fields: {age: 57, job_title: "Commander-in-Chief, Pacific Fleet", education: "US Naval Academy", ...}
}
```

**Nickname parsing:** Split on commas, but PRESERVE parenthetical context.
Examples:
- `"Chester, The Admiral (official correspondence)"` →
  `["Chester", "The Admiral (official correspondence)"]`
- `"Freddie, Fred (wife), F.J.P. (naval correspondence)"` →
  `["Freddie", "Fred (wife)", "F.J.P. (naval correspondence)"]`

The parenthetical context is critical for the Expert Tracker — it tells
the agent who called the figure what, in which institutional setting.

### Step 7: Parse the Places section

Same algorithm as Characters but with `Description` / `Category` / `Notes`
plus any custom user-defined fields. Often empty — handle gracefully.

### Step 8: Preview and confirm

Display a summary to the user:

```
Plottr import preview:
  Title:         {detected from filename or first paragraph}
  Total beats:   {count}
    Main Plot:   {count}
    Threads:     {list of storyline names with counts}
    Templates:   {list of detected structure beat templates}
  Key Figures:   {count}
  Places:        {count}
  Timeline span: {count days} ({first day} → {last day})

Proceed with import? (yes / cancel)
```

### Step 9: Build the starter Research Bible

Construct a Research Bible with these sections populated from parsed data:

| Research Bible Section | Source |
|---|---|
| Section 1 (Topic Scope) | Title from filename; rest asked at reduced setup |
| Section 2 (Thesis / Central Argument) | EMPTY — user populates during Research Bible review |
| Section 3 (Authority Voice Profile) | EMPTY — user attaches existing profile or builds one at reduced setup |
| Section 4 (Key Sources & Evidence Base) | EMPTY — Plottr has no source concept; user populates during Research Bible review |
| Section 5 (Subject Context) | Each parsed place → location/institutional/geographic entry |
| Section 6 (Timeline / Chronology) | Day/date headers in order, with beats grouped by day |
| Section 7 (Key Figures) | Each parsed character → figure block with name + aliases + description + credentials derived from fields |
| Section 8 (Information Architecture) | Template tracks (Three-Act, Hero's Journey, In Medias Res) populate the structure type |
| Section 9 (Chapter Outline) | Main Plot beats in order, grouped into chapters using the heuristic in Step 10. Threads from non-Main-Plot storylines are woven into the appropriate chapters by day-proximity. |
| Section 10 (Source Assignments) | EMPTY — populated after Section 4 is filled |
| Section 11 (Counter-Arguments) | EMPTY — populated during Research Bible review |
| Section 12 (Research Gaps) | EMPTY — populated during Research Bible review |

### Step 10: Chapter grouping heuristic

Plottr beats don't map 1:1 to non-fiction chapters — they're scenes,
moments, or argument beats. Group consecutive Main Plot beats into
chapters using this rule:

```
target_beats_per_chapter = lookup(length_tier_typical_beats_per_chapter)
  Short Form:         3 beats/chapter
  Standard:           3 beats/chapter
  Comprehensive:      4 beats/chapter
  Reference/Academic: 4 beats/chapter
```

The user picks the length tier during reduced setup. Then group:
- Take the Main Plot beats in order
- Slot the first N beats into Chapter 1
- Slot the next N into Chapter 2
- Continue until exhausted

If thread beats (Command, Case Timeline, Expert Interviews, etc.)
interleave with Main Plot beats by day-grouping, weave them into the
same chapters by their day proximity: "1942-06-04 Main Plot beats +
1942-06-04 Command-thread beats → Chapters in the Midway sequence."

Surface the proposed chapter grouping to the user:

```
Proposed chapter outline (you can adjust before approving):
  Ch 1 (1942-06-03): {beat 1}, {beat 2}, {beat 3}
  Ch 2 (1942-06-04): {beat 4}, {beat 5}, {beat 6}
  Ch 3 (1942-06-05): {beat 7}, {beat 8}, {beat 9}
  ...
```

### Step 11: Reduced Phase 1 setup

Plottr doesn't record certain things Ideorix Non-Fiction needs. Ask only these:

| Question | Why it's needed |
|---|---|
| Category | Plottr has no category field; controls category plugin loading |
| Subcategory | Finer category (e.g. Military History under History) |
| Dialect | US or GB English; Plottr is dialect-agnostic |
| Length tier | Plottr is length-agnostic; needed for chapter grouping heuristic |
| Research scope | Shallow / standard / deep — depth of post-import research pass |
| Citation style | Chicago / MLA / APA / Harvard / Footnotes |
| Content sensitivity level | For true crime, memoir with living persons, sensitive topics |
| Target audience expertise | General / informed / specialist |
| Voice profile | Optional — attach existing or skip |
| Pen name | Optional — attach existing or skip |

Skip these questions (Plottr already provides the answer):
- Outline source (Plottr is the outline)
- Structure type (template tracks already detected)
- Chapter count (derived from beat count + length tier grouping)

### Step 12: Build the workspace

Create the standard Ideorix Non-Fiction project structure at the user-
confirmed path:

```
~/Documents/Ideorix-Projects/{Title}/
├── project-config.md
├── manuscript/
│   └── (empty — chapters generated later)
├── marketing/
└── engine-data/
    ├── research-bible.md       ← starter Research Bible from parsed Plottr data
    ├── sources.md              ← empty (populate during Research Bible review)
    ├── figures.md              ← Key Figures from Plottr characters
    ├── places.md               ← Subject Context entries from Plottr places
    ├── outline.md              ← Section 9 chapter outline
    ├── structure-beat.md       ← Section 9 STRUCTURE BEAT templates
    └── imports/
        └── plottr-export/      ← original .docx for reference (optional)
```

### Step 13: Hand off to Research Bible review

Present the assembled starter Research Bible to the user for review
(Phase 2C in the standard `core-pipeline.md` flow). Clearly flag which
sections need user input:

```
Starter Research Bible ready for review.

POPULATED from Plottr:
  ✓ Section 1 (Topic Scope) — from file title
  ✓ Section 5 (Subject Context) — from Plottr places
  ✓ Section 6 (Timeline) — from Plottr day headers
  ✓ Section 7 (Key Figures) — from Plottr characters
  ✓ Section 8 (Information Architecture) — from template tracks
  ✓ Section 9 (Chapter Outline) — from Plottr beats

NEEDS YOUR INPUT (Plottr doesn't track these):
  ⚠ Section 2 (Thesis / Central Argument)
  ⚠ Section 3 (Authority Voice Profile) — or attach existing
  ⚠ Section 4 (Key Sources & Evidence Base)
  ⚠ Section 10 (Source Assignments)
  ⚠ Section 11 (Counter-Arguments)
  ⚠ Section 12 (Research Gaps)

The Outline Conformance Agent won't engage until these sections are
populated. Proceed to review? (yes / cancel)
```

The user works through the empty sections, then approves the Research
Bible. Once approved, the project is ready to enter Phase 3 (Chapter
Generation). The Outline Conformance Agent will check every chapter
brief against Section 9 — now populated from the user's Plottr outline.

---

## Anti-Patterns

1. **Do NOT discard storyline tags.** Threads are first-class argument
   structure in non-fiction (case timelines, expert arcs, archival
   threads). They map into Section 9 as interleaved sub-sections.
2. **Do NOT auto-merge similar figure names.** "Chester" and "Admiral
   Chester Nimitz" might both appear in beats — preserve both, the
   alias matching is the Expert Tracker's job.
3. **Do NOT strip parenthetical context from nicknames.** "F.J.P. (naval
   correspondence)" tells the engine WHERE that form of the name appears.
   Critical for authentic primary-source voicing.
4. **Do NOT include Plottr template content in beat summaries.** Strip
   everything below `--- Add Your Details Above this Line ---`.
5. **Do NOT fabricate chapter numbers when Plottr has none.** Use the
   chapter grouping heuristic from Step 10. Surface the result for user
   approval before locking it in.
6. **Do NOT treat the import as a complete Research Bible.** It's a
   starter. The research-side sections (Key Sources, Source Assignments,
   Counter-Arguments, Research Gaps) MUST be populated before Phase 3
   can start. The import hand-off explicitly flags this.
7. **Do NOT auto-populate sources from character Notes fields.** If a
   user has jotted source references in Notes, surface them to the user
   as candidate sources but do NOT add them to Section 4 without explicit
   confirmation — source provenance matters too much to auto-infer.

## Error Handling

| Error | Response |
|---|---|
| File not found | Ask user for full path |
| File is not a valid `.docx` | Surface error, ask for re-export |
| `Outline` heading missing | Surface error, ask user to re-export with outline enabled |
| `Characters` heading missing | Surface error, ask user to re-export with characters enabled |
| Empty beat summaries throughout | Warn user — outline has no content, only structure |
| Unrecognised storyline tags | Treat as user-defined thread (woven into Section 9) |
| Character with no Description field | Warn but continue — use empty description |
| Character appears to be fictional | Warn user — Plottr is a fiction tool; confirm this figure is a real person for non-fiction |
| Slug collision with existing project | Append suffix (`-2`, `-3`, etc.) |

## Future Expansion

v2 will add:
- Source reference detection inside beat summaries (parse inline citations, bibliographic notes)
- Custom field detection (Plottr supports user-defined character/place fields; use them as role/affiliation)
- Direct import into specific category plugins (memoir, biography, true crime) with category-aware field mapping
- Multi-book project support (Plottr can store series — currently we import one book at a time)
- `.pltr` JSON support as an alternative to `.docx`
