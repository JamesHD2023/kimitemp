---
name: health-wellness-category
description: "Category plugin for Health and Wellness non-fiction. provides structural, craft, quality, and guardrail instructions for all pipeline agents"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Health & Wellness. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | `health-wellness` |
| Display Name | Health & Wellness |
| Parent Group | Health & Wellness |
| Complexity Tier | High |
| Typical Word Count | 55,000–75,000 |
| Reader Expectation | Evidence-based health guidance they can trust, with clear protocols they can follow |
| Tone Baseline | Empowering, scientifically grounded, compassionate; an informed ally, not a guru or scold |

## Subcategory Options

When the user selects this category, prompt for a subcategory. Each subcategory adjusts structural emphasis and source expectations.

| ID | Subcategory | Focus | Typical Structure |
|----|------------|-------|-------------------|
| `nutrition-diet` | Nutrition & Diet | Evidence-based nutrition, dietary patterns, food science, meal planning, gut health | Science-first chapters building to practical dietary protocols |
| `mental-health` | Mental Health | Anxiety, depression, stress management, emotional regulation, therapy approaches | Psychoeducation chapters with coping strategies and self-assessment tools |
| `sleep-recovery` | Sleep & Recovery | Sleep science, circadian rhythms, recovery protocols, fatigue management, performance rest | Mechanism-to-protocol structure with habit-building frameworks |
| `chronic-illness` | Chronic Illness | Living with chronic conditions, symptom management, patient advocacy, treatment navigation | Condition-management chapters with medical system navigation guides |
| `alternative-complementary` | Alternative & Complementary | Integrative medicine, mindfulness, herbal medicine, acupuncture, yoga therapy | Evidence-review structure with clear efficacy ratings and safety information |

### Subcategory Defaults

- If no subcategory is selected, default to `nutrition-diet`.
- If the user's brief spans multiple subcategories, select the dominant one and note secondary influences in the structural plan.

## Structural Architect Instructions

### Core Model: Science-Then-Protocol Structure

Health and wellness books must lead with evidence before offering guidance. Every chapter follows this sequence:

1. **Science**. Present the current scientific understanding of the topic. Explain the biology, psychology, or mechanism in accessible language. Cite research.
2. **Evidence Review**. Summarise what the research actually shows. Distinguish between strong evidence (randomised controlled trials, systematic reviews) and preliminary findings (observational studies, animal models, small trials).
3. **Protocol**. Translate the evidence into actionable guidance. Provide clear, step-by-step instructions the reader can follow.
4. **Caveats**. State limitations, contraindications, and situations where the reader should consult a healthcare professional.

### Chapter Architecture

```
Chapter [N]: [Clear, Informative Title]

  Opening Hook (300–500 words)
    → Common health belief, surprising research finding, or patient story
    → Central question the chapter will address
    → Disclaimer reminder if topic involves medical decision-making

  Section 1: The Science (1,500–2,500 words)
    → Biological or psychological mechanism explained in plain language
    → Key research studies summarised (authors, sample size, findings)
    → Visual metaphors or analogies to aid understanding
    → Hierarchy of evidence acknowledged

  Section 2: What the Research Shows (1,500–2,500 words)
    → Systematic review of relevant evidence
    → Areas of scientific consensus clearly identified
    → Areas of ongoing debate honestly presented
    → Conflicting studies acknowledged, not hidden

  Section 3: Your Protocol (1,500–2,500 words)
    → Step-by-step actionable guidance
    → Dosages, durations, frequencies where applicable (with evidence basis)
    → Modifications for different populations (age, conditions, fitness levels)
    → How to track progress and adjust

  Section 4: Safety and Caveats (800–1,500 words)
    → Contraindications and who should NOT follow this protocol
    → Potential side effects or risks
    → Drug interactions if applicable
    → When to see a doctor. specific red flags listed

  Chapter Summary (200–400 words)
    → Key scientific findings (3–4 bullet points)
    → Protocol summary (numbered steps)
    → Bridge to next chapter
```

### Book-Level Arc

- **Introduction:** Author's credentials and motivation; the book's evidence philosophy; how to use this book; master disclaimer.
- **Part I (Chapters 1–3):** Foundations. core science, assessment tools, baseline establishment.
- **Part II (Chapters 4–8):** Core protocols. the primary interventions, each grounded in evidence.
- **Part III (Chapters 9–11):** Optimisation and integration. advanced strategies, combining protocols, long-term sustainability.
- **Part IV (Chapter 12):** Maintenance. building lasting habits, adapting to life changes, when to seek professional help.
- **Appendices:** Protocol quick-reference cards, recommended lab tests/assessments, glossary of medical and scientific terms, full reference list.

### Special Structural Elements

- Include a **Health Baseline Assessment** in Chapter 1 or as a preliminary section.
- Every protocol chapter must include a **Quick-Reference Protocol Card**. a one-page summary suitable for printing or bookmarking.
- Include **Evidence Rating Boxes** for key claims, using a clear system (e.g., Strong / Moderate / Preliminary / Insufficient).
- Provide a **"Talk to Your Doctor" Checklist**. questions the reader can bring to their healthcare provider.

## Content Writer Craft Rules

1. **Voice:** Knowledgeable, caring, and measured. Write as a well-informed health educator who respects the reader's intelligence and autonomy. Avoid both clinical coldness and wellness-influencer enthusiasm.
2. **Evidence Language:** Match language strength to evidence strength. "Research demonstrates" for strong evidence (multiple RCTs, meta-analyses). "Studies suggest" for moderate evidence. "Preliminary research indicates" for early-stage findings. "Anecdotal reports suggest" for experiential evidence only.
3. **Mechanism Explanation:** Explain biological and psychological mechanisms using clear analogies. Every complex process should have a plain-language explanation before any technical detail. Example: "Think of your circadian rhythm as an internal clock that tells every cell in your body what time it is."
4. **Study Citations:** When citing studies, include: lead author or institution, year, sample size or study type, and key finding. Do not bury the reader in citation details. summarise the relevance. Full references go in the endnotes.
5. **Inclusivity:** Write for diverse bodies, ages, abilities, and health statuses. Do not assume a baseline of perfect health. Provide modifications and alternatives. Avoid gendered health assumptions unless the topic is explicitly sex-specific.
6. **Weight and Body Language:** Never use shaming language about body size, weight, or appearance. Focus on health markers and functional outcomes rather than aesthetic goals. Use "health" not "weight loss" as the frame unless the reader's brief explicitly requests a weight management book.
7. **Dosage and Specificity:** When providing protocols, be specific: amounts, frequencies, durations, timing. Vague advice ("eat more vegetables") must be made concrete ("aim for 5–7 servings of non-starchy vegetables per day, where one serving equals approximately one cup raw or half a cup cooked").
8. **Jargon Management:** Define all medical and scientific terms on first use. Provide both the technical term and the common name: "inflammation (the body's immune response to perceived threats)." Maintain a glossary.
9. **Paragraph and Section Length:** Keep paragraphs to 3–5 sentences. Use subheadings every 500–700 words. Protocol sections benefit from numbered lists and bullet points.
10. **Empathy and Motivation:** Acknowledge that health changes are difficult. Validate the reader's struggles without patronising. Pair every recommendation with realistic expectations about timelines and outcomes.

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the reader's problem, named specifically. The reader should
  recognise their own experience within the first paragraph.
- **Sentence calibration:** Medium sentences averaging 14–20 words. Empathetic,
  authoritative, and hopeful in equal measure.
- **Evidence through story:** Deliver scientific evidence through narrative, not citation
  dumps. "A 2019 trial at Johns Hopkins found..." is better than a parenthetical
  stack of author-date references.
- **Voice triad:** Every passage should balance three registers. empathy ("this is
  hard"), authority ("here is what the research shows"), and hope ("and here is what
  you can do"). If any register dominates for too long, recalibrate.
- **Rhythm pattern:** Alternate between explanation (science, mechanism, evidence) and
  direct address (you, your body, your experience). The oscillation keeps the reader
  feeling both informed and seen.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In health writing,
  tension is personal stakes. the reader's own body, their own wellbeing.
- **Tension drivers:** The gap between what the reader has tried and what actually works.
  The distance between popular belief and scientific evidence. The promise of agency.
- **Protocol pacing:** When delivering step-by-step protocols, use short crisp sentences
  (8–14 words). Clarity is kindness in health instruction.
- **Paragraph breath:** After a dense science passage, follow with a shorter paragraph
  that translates the finding into personal relevance. The reader needs the bridge.
- **Jargon rhythm:** Introduce a technical term, define it immediately, then use it
  freely afterward. The definition moment should feel natural, not like a glossary
  intrusion.
- **Read-aloud test:** The prose should sound like a knowledgeable friend explaining
  something important over a table. If it sounds clinical or preachy, revise.

## Quality Check Criteria

The Quality Check agent must verify the following for health and wellness category manuscripts:

| # | Criterion | Pass Condition |
|---|-----------|----------------|
| 1 | Peer-Reviewed Citations | Every medical or health claim is supported by at least one peer-reviewed source; claims based on single studies are flagged as such |
| 2 | Medical Disclaimer | A comprehensive disclaimer appears in the front matter and is reiterated before any chapter containing specific medical or health protocols |
| 3 | No Cure Claims | No language claims or implies that any protocol will "cure" a disease or condition unless supported by robust clinical evidence and regulatory approval |
| 4 | Evidence Hierarchy | Claims are matched with appropriate evidence language. strong claims require strong evidence (RCTs, meta-analyses), not observational studies alone |
| 5 | Contraindication Coverage | Every protocol chapter includes a safety section listing contraindications, potential side effects, and drug interactions where relevant |
| 6 | Author Credentials | The author's qualifications to write about health topics are clearly established in the introduction; if the author is not a healthcare professional, expert reviewers are credited |
| 7 | Supplement Caution | Any mention of supplements includes a note about regulatory status, quality variation, and the importance of consulting a healthcare provider |
| 8 | Population Specificity | Protocols note when they are not suitable for specific populations (pregnant/nursing women, children, elderly, those on medications, those with specific conditions) |
| 9 | Source Recency | Primary health research cited is published within the last 10 years unless it is a landmark study; more recent systematic reviews are preferred |
| 10 | Emotional Safety | No shaming, fear-mongering, or guilt-inducing language; health is framed as a positive pursuit, not a moral obligation |

## Source Requirements

### Minimum Source Thresholds

- **Per chapter:** Minimum 8 distinct sources.
- **Per book:** Minimum 70 unique sources across the manuscript.
- **Peer-reviewed research** (clinical trials, systematic reviews, meta-analyses): At least 50% of total.
- **Official health guidelines** (WHO, NHS, CDC, national medical associations): At least 15% of total.
- **Clinical expertise sources** (textbooks, clinical handbooks, expert interviews): Acceptable for protocol detail and clinical context.

### Acceptable Source Types

| Type | Examples | Notes |
|------|----------|-------|
| Systematic reviews/meta-analyses | Cochrane Reviews, published meta-analyses | Highest tier of evidence; preferred for broad claims |
| Randomised controlled trials | Published in peer-reviewed journals | Required for specific intervention efficacy claims |
| Observational studies | Cohort studies, case-control studies in peer-reviewed journals | Acceptable for associations; must not be presented as causal proof |
| Clinical guidelines | NICE, AHA, WHO, national medical associations | Required for standard-of-care claims |
| Medical textbooks | Harrison's, Guyton's, current edition clinical references | For foundational mechanism explanations |
| Expert interviews | Licensed healthcare professionals, researchers | Must include credentials and institutional affiliation |
| Government health data | CDC, ONS, WHO Global Health Observatory | For epidemiological statistics |

### Prohibited Sources

- Wikipedia as a primary source.
- Wellness blogs, influencer content, or social media posts as evidence for health claims.
- Manufacturer-funded studies presented without disclosure of funding source.
- Anecdotal testimonials presented as evidence of efficacy.
- Sources from predatory journals (check against recognised predatory journal lists).
- Retracted studies (verify retraction status of all cited research).

## Category-Specific Guardrails

### Medical Claims and Peer Review

- Every medical or health claim **MUST** cite peer-reviewed research. No exceptions.
- The strength of the claim must match the strength of the evidence. A single small study does not support a definitive claim.
- When citing a study, note the study design (RCT, observational, case study), sample size, and any significant limitations.
- Prefer systematic reviews and meta-analyses over individual studies for broad claims.

### Disclaimer Requirements

- The book **MUST** include a prominent disclaimer in the front matter stating: "This book is for educational purposes only and is not intended as a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition."
- This disclaimer must be reiterated in abbreviated form at the start of any chapter containing specific health protocols, supplement recommendations, or dietary changes.
- The disclaimer must note that individual health needs vary and that the reader should not start, stop, or change any treatment without consulting their healthcare provider.

### No "Cure" Claims

- **Never** claim or imply that any protocol, food, supplement, or practice will "cure" a disease or medical condition unless supported by robust clinical evidence and recognised by regulatory bodies.
- Use accurate language: "may help manage symptoms," "has been associated with improvements in," "some evidence suggests potential benefits for."
- Clearly distinguish between "treating" (medical intervention with regulatory approval) and "supporting" (lifestyle measures that may complement medical treatment).

### Author Credentials

- The author's qualifications to write about health must be clearly established in the introduction.
- If the author is not a licensed healthcare professional, the book must be reviewed by one, and the reviewer must be credited: "Medical review by [Name], [Credentials], [Affiliation]."
- The author's scope of competence must be respected. a nutritionist should not make claims about pharmaceutical treatments, and a psychologist should not make claims about surgical interventions.

### Supplement and Product Guidance

- Any mention of dietary supplements must include a note that supplements are not regulated to the same standard as pharmaceuticals in most jurisdictions.
- Do not recommend specific supplement brands.
- Note that supplement quality varies and recommend readers look for third-party testing certifications (e.g., NSF, USP, ConsumerLab).
- Include potential interactions with common medications.

## Cover Design Specifications

| Element | Specification |
|---------|---------------|
| Typography | Clean, modern sans-serif. Title should feel trustworthy and empowering. Avoid script or decorative fonts that might undermine scientific credibility. |
| Colour Palette | Fresh, natural tones. green (vitality), blue (trust/calm), warm white or cream. Accents in teal, sage, or warm gold. Avoid clinical white-and-blue-only schemes (too medical) or neon wellness palettes (too superficial). |
| Imagery | Abstract natural forms (leaves, water, light, organic shapes), clean geometric patterns suggesting science and clarity. No photographs of perfect bodies. No before/after imagery. No pills or supplements as decorative elements. |
| Layout | Title prominent. Subtitle communicates the evidence-based angle. Author name with credentials (MD, PhD, RD, etc.) if applicable. credentials on the cover build trust in this category. |
| Subtitle | Required. Format: "The Science of [Topic] and How to [Outcome]" or "Evidence-Based [Protocols/Strategies] for [Health Goal]." |
| Endorsement | One endorsement from a recognised medical professional, researcher, or health institution representative if available. Medical credentials of endorser should be visible. |
| Spine | Title + Author (with credentials). Legible at thumbnail size. |
| Back Cover | 3–4 evidence-based promises, one endorsement with credentials, author bio emphasising qualifications and clinical/research experience, barcode. |

## KDP Category Mapping

### Primary Category Path

```
Kindle Store > Kindle eBooks > Health, Fitness & Dieting
```

### Secondary Category Path (select based on subcategory)

| Subcategory | Recommended Secondary KDP Category |
|------------|-------------------------------------|
| `nutrition-diet` | Health, Fitness & Dieting > Diets & Weight Loss > Nutrition |
| `mental-health` | Health, Fitness & Dieting > Mental Health > Anxiety Disorders |
| `sleep-recovery` | Health, Fitness & Dieting > Sleep Disorders |
| `chronic-illness` | Health, Fitness & Dieting > Diseases & Physical Ailments |
| `alternative-complementary` | Health, Fitness & Dieting > Alternative Medicine |

### Keyword Recommendations

- Use 7 keyword slots in KDP.
- Include: primary health topic, subcategory term, "evidence-based" or "science-based" descriptor, target audience or condition, protocol/practical term, comparable author name (if applicable), related trending health term.
- Example set: `health wellness`, `evidence based nutrition`, `science of sleep`, `mental health strategies`, `chronic illness management`, `holistic health`, `wellness protocols`.

### BISAC Codes

| Code | Description |
|------|-------------|
| HEA000000 | HEALTH & FITNESS / General |
| HEA017000 | HEALTH & FITNESS / Nutrition |
| HEA042000 | HEALTH & FITNESS / Sleep & Sleep Disorders |
| HEA010000 | HEALTH & FITNESS / Diet & Nutrition / General |
| HEA029000 | HEALTH & FITNESS / Mental Health |
