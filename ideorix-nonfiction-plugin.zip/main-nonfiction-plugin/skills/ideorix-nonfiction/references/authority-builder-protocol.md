---
name: authority-builder-protocol
description: "Detailed protocol for building non-fiction author authority/voice profiles"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Authority Builder Protocol

## Overview

This protocol powers the Authority Builder. It defines exactly how to analyse
existing writing or conduct a guided conversation to build an Authority Voice
Profile for non-fiction manuscripts.

## Method A: Extract from Existing Writing

### Input Requirements
- Minimum 5,000 words of the author's published or polished non-fiction
- Ideally from the same category as the planned project
- Multiple pieces are better than one (captures range)

### Extraction Process

**Step 1: Tone Analysis**
Read 3 representative passages (opening, middle, closing) and score:

```
TONE POSITIONS (score each on a 10-point scale):

Academic [1] ←————————→ [10] Conversational
  1-3: Formal, third person, citation-heavy, scholarly register
  4-6: Professional but accessible, moderate citations, clear prose
  7-10: Direct address, storytelling, minimal formal citation

Objective [1] ←————————→ [10] Opinionated
  1-3: Neutral, balanced, presents all sides equally
  4-6: Has a perspective but presents evidence before opinion
  7-10: Strong positions, advocacy, the author's view is the book's engine

Formal [1] ←————————→ [10] Intimate
  1-3: Professional distance, no personal disclosure
  4-6: Occasional personal reference, mostly analytical
  7-10: Frequent personal stories, vulnerable, conversational

Cautious [1] ←————————→ [10] Assertive
  1-3: Heavy hedging ("it could be argued", "perhaps", "some suggest")
  4-6: Confident with appropriate qualifiers
  7-10: Direct assertions, bold claims, declarative style
```

**Step 2: Evidence Integration Analysis**
Count and categorise source references in 2,000 words:

```
EVIDENCE STYLE:
- Citations per 1,000 words: {count}
- Primary method: [formal citation / woven narrative / expert witness / invisible+endnotes]
- Direct quote ratio: {percentage of evidence delivered as direct quotes}
- Paraphrase ratio: {percentage delivered as paraphrase}
- "Trust me" ratio: {percentage presented as author's own expertise}
```

**Step 3: Sentence Architecture**
Analyse 20 consecutive sentences:

```
SENTENCE PATTERNS:
- Average sentence length: {word count}
- Shortest: {words} | Longest: {words}
- Fragment usage: {frequency — never / rare / occasional / frequent}
- Rhetorical questions: {frequency}
- List/enumeration style: {numbered / bulleted / prose / none}
- Paragraph length tendency: {short 1-3 / medium 3-5 / long 5+ sentences}
- Signature structures: {any recurring patterns — e.g., "short-short-long",
  "question then answer", "assertion then evidence then implication"}
```

**Step 4: Vocabulary Analysis**
Scan for vocabulary markers:

```
VOCABULARY:
- Jargon density: {technical terms per 1,000 words}
- Vocabulary ceiling: {most complex words used regularly}
- Register consistency: {consistent / shifts by section / shifts by topic}
- Defining behaviour: {defines terms explicitly / assumes knowledge / mixed}
- Favourite words: {3-5 words the author uses notably often}
```

**Step 5: Reader Relationship**
Identify how the author relates to the reader:

```
READER RELATIONSHIP:
- Address mode: {"you" direct / "we" inclusive / third person / "I" personal / mixed}
- Assumed knowledge: {none / basic / intermediate / expert}
- Teaching mode: {instructive / exploratory / provocative / narrative}
- Humour: {frequency and type — dry / self-deprecating / playful / absent}
- Personal disclosure level: {none / rare anecdotes / frequent personal stories}
```

**Step 6: Authority Markers**
How does the author signal expertise:

```
AUTHORITY SIGNALS:
- Primary method: {credentials / experience / depth of research / analytical rigour}
- Credentials mentioned: {yes explicitly / implied / never}
- "I" as expert: {frequent / occasional / rare}
- Hedging frequency: {high / moderate / low}
- Contrarian positioning: {mainstream / occasionally challenges / frequently contrarian}
```

**Step 7: Compile Profile**
Assemble all findings into the standard Authority Voice Profile format
(see `authority-builder.md` for the output template).

**Step 8: Confirm with User**
Present the profile and ask: "Does this sound like you? What would you adjust?"
Apply their corrections.

## Method B: Guided Conversation

### Question Sequence

Present each question, wait for the answer, build the profile progressively.

**Q1: Reader & Expertise**
"Who is your ideal reader? What do they already know about your subject?
Are you writing for beginners, informed readers, or specialists?"

→ Maps to: VOCABULARY LEVEL, READER RELATIONSHIP, ASSUMED KNOWLEDGE

**Q2: Explanation Style**
"When you explain something complex, do you tend to use:
A) Analogies and metaphors ('It's like...')
B) Data and statistics ('The numbers show...')
C) Stories and examples ('When Sarah tried this...')
D) Step-by-step logic ('First... then... therefore...')
E) A mix — describe your blend"

→ Maps to: EVIDENCE INTEGRATION STYLE, METAPHOR SOURCES

**Q3: Tone Preference**
"Read these two paragraphs on the same topic. Which sounds more like how
you'd write it?"

[Present two versions: one academic/formal, one conversational/personal]

→ Maps to: TONE POSITION (Academic ↔ Conversational)

**Q4: Evidence Approach**
"How do you prefer to present your sources?
A) Formal citations throughout (footnotes, in-text references)
B) Woven into the narrative ('When Kahneman studied...')
C) Present conclusions confidently, sources in endnotes for those who want them
D) Mix of approaches depending on the section"

→ Maps to: EVIDENCE INTEGRATION STYLE

**Q5: Reader Relationship**
"What's your relationship with the reader?
A) Teacher — I'm showing them something they don't know
B) Guide — I'm walking alongside them through a complex landscape
C) Peer — We're exploring this together, I just got here first
D) Provocateur — I'm challenging what they think they know"

→ Maps to: READER RELATIONSHIP

**Q6: Tone Scale**
"On a scale of 1-5:
Serious [1] ←→ [5] Playful — where do you sit?
Cautious [1] ←→ [5] Bold — where do you sit?
Distant [1] ←→ [5] Personal — where do you sit?"

→ Maps to: TONE POSITIONS

**Q7: Personal Disclosure**
"How much of yourself do you put in your writing?
A) Very little — the subject speaks for itself
B) Occasional anecdotes — when they serve the argument
C) Frequently — my experience is a core part of the authority
D) It varies — some sections are personal, others analytical"

→ Maps to: EMOTIONAL REGISTER, PERSONAL DISCLOSURE LEVEL

**Step 8: Compile and Confirm**
Build the profile from answers, present it, get user approval.

## Linking to Pen Names

After profile creation, offer:
"Would you like to link this voice profile to a pen name?
This means any future project using that pen name will automatically
load this authority profile."

If yes: save to `~/Documents/Ideorix-Projects/.pen-names/profiles/voices/{slug}-authority.md`
Update the pen name's profile with the voice file reference.

## Profile Storage

Save to: `engine-data/authority-profile.md` (project-specific)
Also save to: `~/.pen-names/profiles/voices/{slug}-authority.md` (if linked to pen name)

The project-specific version is loaded by the Structural Architect, Content Writer,
and Evidence Auditor for every chapter.
