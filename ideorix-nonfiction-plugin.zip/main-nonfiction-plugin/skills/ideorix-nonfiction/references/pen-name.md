---
name: pen-name
description: "Create and manage author pen names with genre-appropriate bios"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
# Pen Name Studio

Create, manage, and select author pen names. Each pen name comes with a genre-tailored
professional bio in three lengths (short, medium, long) and persona notes for consistent
author branding across all your projects.

## What You Can Do

1. **Create a new pen name** — Genre-informed name generation with 5 candidates,
   plus professional author bios in three lengths
2. **View my pen names** — Browse all saved pen names with their bios and usage history
3. **Edit a pen name** — Update name, bios, persona notes, or genre affinity
4. **Delete a pen name** — Remove a pen name profile (with confirmation)
5. **Generate new bios** — Create fresh bio variants for an existing pen name
6. **Back to main menu**

## How It Works

The engine generates pen names that are category-appropriate — memoir
names sound different from business-book names, and a personal-finance
expert's name reads differently from a literary-NF essayist's. Names
are checked for shelf positioning, pronounceability, and uniqueness
within your existing pen name collection.

Each pen name includes:
- **Short bio** (50-75 words) — for Amazon author pages and back-of-book
- **Medium bio** (100-150 words) — for author websites and press kits
- **Long bio** (200-300 words) — for query letters and speaking engagements
- **Persona notes** — voice, social media tone, author photo style guidance

> **Non-fiction pen names do not link to voice profiles.** Author voice for non-fiction is managed through `authority-builder.md`, not through pen-name-linked voice profiles (which are fiction-only). If you carried over a fiction pen that has a linked voice profile, the profile is ignored on the non-fiction side.

Pen names are saved to your local Ideorix Projects folder and persist across all projects.
You can select a pen name during project setup or assign one before export.

→ Protocol: `pen-name-generator.md`
