---
name: fitness-category
description: "Category-specific instructions for fitness & exercise non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Fitness & Exercise. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | fitness |
| Display Name | Fitness & Exercise |
| Parent Group | Health & Wellness |
| Typical Word Count | 50,000–80,000 (programme books often shorter; comprehensive textbooks-for-the-trade can run 100,000+) |
| Default Structure | Three-part architecture: science (why this works) → programme (how to do it) → lifestyle (how to sustain it); each chapter alternates principle → exercise → programming |
| Citation Style | Endnotes for scientific claims; named-coach credit for established methodologies; in-text attribution for studies ("In a 2019 trial at McMaster University..."); peer-reviewed sources prioritised over popular-press fitness writing |
| Audience Baseline | Motivated reader who wants results; varies from absolute beginner to experienced trainee depending on title; assume zero medical training; assume access to typical home or gym equipment unless title says otherwise |
| Comparable Titles | Mark Rippetoe (*Starting Strength*), Bret Contreras (*Glute Lab*, *Strong Curves*), Pavel Tsatsouline (*Simple & Sinister*, *Kettlebell Simple & Sinister*), Stuart McGill (*Back Mechanic*), Christopher McDougall (*Born to Run*), Tim Noakes (*Lore of Running*), Mike Boyle (*New Functional Training for Sports*), Tudor Bompa (*Periodization*), Eric Helms (*The Muscle and Strength Pyramid*), Brad Schoenfeld (*Science and Development of Muscle Hypertrophy*) |

## Subcategory Options

When the user selects Fitness & Exercise, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| strength-training | Strength Training | Resistance training, progressive overload, programming, hypertrophy, powerlifting, weightlifting | Linear progression spine; movement-pattern chapters (squat / hinge / press / pull); programming templates with sets / reps / load / rest specified |
| endurance-cardio | Endurance / Cardio | Running, cycling, swimming, triathlon, rowing, cardiorespiratory base-building | Periodisation framework (base / build / peak / taper); volume-and-intensity guidance per week; race-distance-specific sections |
| flexibility-mobility-yoga | Flexibility / Mobility / Yoga | Movement quality, joint range, mobility practice, yoga as fitness, dynamic and static stretching | Joint-by-joint or movement-pattern structure; assessment / restoration / integration cycle; progression from passive to active mobility |
| sport-specific | Sport-Specific Training | Athletic performance for a named sport (basketball, climbing, martial arts, golf, tennis, etc.) | Sport-demands analysis up front; off-season / pre-season / in-season programming; transferable strength + sport-specific conditioning + skill-work |
| general-fitness-lifestyle | General Fitness / Lifestyle | Accessible fitness for non-athletes; busy-professional programmes; minimal-equipment work; weight-management adjacent | Low-barrier-to-entry framing; short-session programming; habit-formation woven through; broad audience accommodation |
| functional-rehabilitation | Functional / Rehabilitation / Pain | Post-injury return to function, chronic-pain management through movement, postural / pattern correction (back, knee, shoulder) | Assessment-first structure; pain-science framing; graded-exposure progression; explicit "see a clinician if X" branches; conservative load progression |
| nutrition-fitness | Nutrition for Fitness | Performance and body-composition nutrition (macros, fuelling, supplementation, hydration) — the fitness-paired nutrition book, not clinical dietetics | Energy-balance fundamentals; macronutrient roles; meal-timing for training; supplement-evidence triage; minimum 1 chapter on disordered-eating awareness |

**Default:** If the user does not specify, prompt for the primary discipline
(strength / endurance / mobility / general) and select accordingly; fallback
to `general-fitness-lifestyle` for unclear cases.

## Structural Architect Instructions

```
STRUCTURE
- Part 1: The science (why this approach works. anatomy, physiology, evidence)
- Part 2: The programme (how to do it. exercises, progressions, schedules)
- Part 3: The lifestyle (how to sustain it. recovery, nutrition, habit formation)
- Each chapter: explain the principle → demonstrate with specific exercises → provide programming

BEATS PER CHAPTER
1. Principle Beat. the training principle this chapter teaches
2. Science Beat. the physiological/biomechanical evidence
3. Technique Beat. specific exercises with form cues
4. Programming Beat. how to incorporate into a training plan
5. Common Mistakes Beat. what goes wrong and how to fix it

CATEGORY ARCHITECTURE
- Progressive: fundamentals before advanced techniques
- Every exercise must include: muscles targeted, form cues, common errors, progressions/regressions
- Programming must be specific: sets, reps, rest periods, frequency
- Recovery and injury prevention integrated throughout, not relegated to an appendix

FORBIDDEN
- Exercises without form guidance (safety risk)
- "Just push through" pain advice (injury risk)
- Unsourced performance claims ("this will add 50lbs to your squat")
- Body-shaming language or unrealistic transformation timelines
- Supplement recommendations without evidence basis
```

## Content Writer Craft Rules

```
VOICE & TONE
- Authoritative but encouraging. coach, not drill sergeant
- Technical precision balanced with accessibility
- Direct, action-oriented language: "Do this. Here's why. Here's how."

EVIDENCE STANDARDS
- Exercise selection backed by biomechanical research or established coaching practice
- Performance claims cite studies or qualified expert opinion
- Injury prevention advice from sports medicine sources
- Nutrition claims from peer-reviewed dietary research

FORMATTING
- Exercise descriptions use consistent format (name, muscles, setup, execution, cues, variations)
- Tables for programming variables (sets × reps × load × rest)
- Clear section breaks between explanation and instruction
```

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the transformation promise, grounded in science. The reader
  should feel both motivated and reassured that this approach is evidence-based.
- **Sentence calibration:** Short-medium energetic sentences averaging 12–18 words.
  Fitness writing moves. the prose should feel like forward momentum.
- **Motivational without preachy:** Energy comes from directness and specificity, not
  from exclamation marks or empty encouragement. "Do this. Here is why. Here is how."
- **Rhythm pattern:** Alternate between science sentences (slightly longer, explanatory)
  and instruction sentences (short, imperative, direct). The reader shifts between
  understanding and doing.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In fitness writing,
  tension is aspirational. the gap between where the reader is and where they could be.
- **Tension drivers:** The promise of measurable progress. The counterintuitive finding
  that challenges gym folklore. The "you have been doing this wrong" moment.
- **Instruction pacing:** When describing exercises or form cues, use the shortest
  clear sentence possible. "Drive through the heels. Chest up. Hips back." Staccato
  rhythm signals action.
- **Science-to-action bridge:** After every science passage, transition immediately to
  what this means for the reader's training. No science without application.
- **Paragraph energy:** Keep paragraphs to 3–5 sentences in instructional sections.
  Longer paragraphs are permitted in science sections, but even there, break at
  natural turning points.
- **Common-mistake rhythm:** When correcting a misconception, state the myth briefly,
  then give the evidence-based correction at twice the length. The correction should
  outweigh the myth in the reader's memory.
- **Read-aloud test:** The prose should sound like a knowledgeable coach. energetic,
  clear, and direct. If it sounds like a textbook or a motivational poster, revise.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Form / technique accuracy | Every exercise description carries: muscle groups targeted, setup, execution, key cues, common errors, regressions, progressions; descriptions match current sports-science consensus, not gym folklore |
| 2 | Safety prominence | Contraindications and "stop if you feel X" language present at point-of-need with the standard CAUTION callout; risk-of-injury exercises (loaded spinal flexion, behind-the-neck press, deep-knee work for unconditioned trainees) carry explicit warnings |
| 3 | Programming specificity | Sets, reps, rest periods, load progression, frequency, and weekly structure specified; no "do this for a while" hand-waving; programming serves a stated goal (strength / hypertrophy / endurance / mobility) |
| 4 | Evidence base | Performance and physiological claims trace to peer-reviewed sources or established coaching practice with named originator; "studies show" without citation is unacceptable |
| 5 | Progressive overload correctly applied | Strength chapters demonstrate the load / rep / set / frequency progression rules; endurance chapters demonstrate the volume / intensity progression rules; over-progression risks explicit |
| 6 | Recovery and injury-prevention integrated | Recovery (sleep, intra-workout, inter-session) and injury-prevention guidance woven through the programme, not relegated to a single appendix; warm-up and cool-down protocols specific to the chapter's work |
| 7 | Skill / fitness-level honesty | The book's stated audience matches the programme's actual demand; advanced techniques flagged as advanced; beginner programmes do not silently assume a year of prior training |
| 8 | Inclusive accommodation | Beginner / intermediate / advanced (or regression / standard / progression) variants offered for major exercises; equipment substitutions where realistic; body-size and ability variation acknowledged |
| 9 | Body-image / language sensitivity | No body-shaming language, no "ideal body" rhetoric, no fat-phobic framing; before-and-after imagery (where used) is accurate and not misleading; disordered-eating awareness if nutrition is covered |
| 10 | Disclaimer / scope-of-practice clarity | Medical disclaimer present and prominent (not buried); clear acknowledgement that the book is fitness writing not medical advice; "consult a clinician if X" branches at points where readers might confuse fitness work with rehabilitation |

## Source Requirements

### Mandatory Source Types

- **Peer-reviewed sports science research.** Exercise physiology,
  biomechanics, motor learning, performance research published in
  journals such as the *Journal of Strength and Conditioning Research*,
  *Medicine & Science in Sports & Exercise*, *British Journal of Sports
  Medicine*, *Sports Medicine*. The evidentiary backbone for performance
  and physiological claims.
- **Sports medicine and rehabilitation literature.** For injury
  prevention, return-to-sport, and any movement-as-medicine framing —
  *American Journal of Sports Medicine*, *Journal of Orthopaedic &
  Sports Physical Therapy*, NICE / ACSM / NSCA position statements.
  Higher-evidence sources where claims touch injury or pain.
- **Established coaching methodology with named originator.** Training
  systems associated with named coaches (Rippetoe's linear progression,
  Westside conjugate, Bompa periodisation, Maffetone aerobic base) are
  cited with attribution to the originator and the originator's
  primary work. Methodologies are not anonymised.
- **Author's coaching / training experience.** Where the author has
  trained athletes or themselves through the protocols described, that
  experience is named explicitly ("I have programmed this for over
  300 trainees..."); experience supplements but does not replace the
  evidence base.
- **Nutrition: peer-reviewed dietary research and registered-dietitian
  consensus.** For fitness titles that include nutrition guidance,
  claims trace to peer-reviewed sources (International Society of
  Sports Nutrition position stands, Academy of Nutrition and
  Dietetics, Cochrane reviews); celebrity-trainer macro fads are not
  evidence.

### Source Freshness

- **Sports science evolves.** Pre-2010 research on intensity,
  programming, and recovery has often been superseded; pre-2000
  research on women's training, master's training, and youth training
  is frequently outdated. Cite recent research where possible; flag
  where you are citing a foundational older study and explain why it
  remains the reference.
- **Replication awareness.** Several once-foundational fitness claims
  have failed replication (one-set strength claims, glycogen-window
  timing rigidity, central-governor-as-only-fatigue-mechanism). If a
  frequently-cited finding has been challenged, present the current
  picture rather than the legacy claim.
- **Equipment and platform turnover.** Specific brand / model
  recommendations age fastest (3–5 years); programming principles age
  slowest (decades). Date the equipment-specific guidance; cite the
  programming-principle guidance as current state of the field.
- **Regulatory / safety guidance currency.** Where the book offers
  safety guidance (especially for at-risk populations: pregnancy,
  cardiac, post-surgical), confirm against current ACSM / NHS / NICE
  guidance at time of writing; note "current as of [year]".

### Attribution Standards

- **Performance claims sourced.** "Studies show..." is unacceptable
  without the citation. "A 2020 meta-analysis by Schoenfeld and
  colleagues found..." is the standard. Reader trust depends on this.
- **Distinguish established consensus from contested or emerging.**
  "Hypertrophy responds to loading across a wide rep range with
  sufficient effort" — established. "Mind-muscle connection enhances
  hypertrophy" — emerging / contested; flag accordingly.
- **Borrowed protocols credited.** Do not strip a programme down and
  represent it as your own. If the bones come from Rippetoe, Bompa,
  Helms, Tsatsouline, or another named methodologist, name them.
- **Anecdote labelled clearly.** "In my experience..." or "I have
  found that..." sets expectations correctly. Conflating experience
  with evidence is a credibility failure when the reader recognises
  the move.
- **What is NOT acceptable.** Inventing studies, citation laundering
  (citing a popular-press article that cites a study, without
  checking the study), promoting unproven supplements with affiliate
  arrangements undisclosed, presenting individual training results
  as predictive of typical reader outcomes.

## Category-Specific Guardrails

### MANDATORY. No Medical Diagnosis or Treatment Advice

- Fitness writing exists alongside medicine but is not medicine. The
  book may discuss physiological concepts (joint mechanics, nervous-
  system adaptation, recovery science, common training-related
  pain patterns) for the reader's understanding.
- The book MUST NEVER provide diagnostic criteria for the reader to
  self-diagnose a medical condition (heart disease, herniated disc,
  rotator-cuff tear, eating disorder, etc.).
- The book MUST NEVER advise the reader to discontinue medication,
  defer or refuse clinical treatment, or replace clinical care with a
  fitness programme.
- The book MUST NEVER prescribe individual rehabilitative programmes
  for diagnosed injuries; rehabilitation prescription is a clinician's
  scope of practice. The book may describe general movement-quality
  work as a complement to clinical care.
- Include a clear disclaimer up front: this book is fitness writing,
  not medical advice; readers with conditions, pain, or symptoms
  should consult a qualified clinician before beginning any
  programme; nothing in the book replaces medical care.
- The line: fitness writing can support physical capability; it
  cannot replace clinical assessment or treatment.

### MANDATORY. Exercise Safety Information at Point-of-Need

- Every exercise description includes: muscles targeted, setup, key
  form cues, common errors, contraindications (when NOT to do this
  exercise), regressions for less-conditioned trainees, progressions
  for stronger trainees.
- For exercises with notable injury potential (heavy spinal loading,
  ballistic movements, deep ranges, complex coordination, single-
  rep maximum testing) safety language appears at the exercise, not
  buried in surrounding prose: explicit CAUTION callouts, when-to-
  stop criteria, when to seek clinician review.
- "Push through pain" is forbidden language. The book teaches
  trainees to distinguish productive discomfort (effort, fatigue, mild
  delayed soreness) from warning signs (sharp pain, joint pain,
  numbness, dizziness, chest pain) and to stop and reassess on
  warning signs.
- For programmes that may attract trainees with relevant
  contraindications (older adults, postpartum, post-surgical,
  cardiac history, hypertension, joint replacement), explicit
  population-specific warnings or whole sections addressed to that
  population.

### MANDATORY. Injury Liability Awareness

- Every exercise carrying meaningful injury risk warrants both
  technique detail AND scope-of-practice clarity: the book teaches
  the technique, the reader executes the technique, the reader is
  responsible for stopping if the technique is producing pain or
  malformed execution.
- Where the book recommends loaded barbell or dumbbell work, image-
  based or video-based instruction is strongly encouraged; text-only
  instruction for compound lifts is a safety compromise the reader
  should be informed of.
- Author's qualifications relevant to the book's claims (CSCS, RKC,
  USAW, NSCA, BASES, registered dietitian for nutrition, etc.) should
  be disclosed in the front matter; the absence of formal qualification
  does not disqualify the book but the reader is entitled to know.
- Where the book is published in jurisdictions with consumer-protection
  liability for fitness publishing, legal review of safety language
  prior to publication is prudent.

### MANDATORY. No Guaranteed Results, No Transformation Promises

- The book may describe what is typically achievable with consistent
  training over a stated timeframe ("trainees following a beginner
  linear progression typically add 50–100 lbs to their squat in the
  first six months"); the book MUST NEVER guarantee a specific
  outcome for an individual reader ("you will lose 30 lbs in 8
  weeks").
- Individual variability (genetics, training history, recovery
  capacity, life circumstance) is acknowledged; transformation
  imagery (where used) represents real, named individuals with
  honest timelines, not composites or staged results.
- Avoid time-pressured framing that contradicts physiological
  reality ("get shredded in 14 days", "build 20 lbs of muscle in a
  month"); these promises mislead the reader and mark the book as
  fitness pulp rather than serious work.

### Additional Guardrails

- **Body-image and language sensitivity.** No body-shaming
  ("dad-bod", "skinny-fat" used pejoratively, "fat-burning" framed
  as moral); no "ideal body" rhetoric; weight-loss framing
  acknowledges the limits of weight as a health proxy and the
  prevalence of weight-cycling harm; nutrition chapters include
  disordered-eating awareness with signposting to support resources.
- **Equipment access realism.** The book either commits to a
  specific equipment context (commercial gym / home gym / minimal
  equipment / bodyweight only) and stays within it, or explicitly
  branches programming for different access levels. Tacitly
  assuming gym access while presenting as accessible is a category
  failure.
- **Population scope clarity.** State the audience for the programme
  up front (healthy adults / older adults / postpartum / youth /
  athlete-population) and stay within it; cross-population claims
  ("works for everyone") are usually wrong.
- **Pain-science honesty in rehabilitation-adjacent content.**
  Modern pain science (graded exposure, biopsychosocial framing,
  movement-as-medicine) is the current best understanding; legacy
  framings (pain = damage, posture = pain, structural-only causation)
  are superseded and should not be perpetuated.
- **Currency disclosure.** Date the recommendations; signpost which
  guidance is principle-stable (compound lifts, sleep importance)
  and which is currency-sensitive (specific supplement evidence,
  population-specific guidelines).
- **No supplement promotion without evidence base AND disclosure.**
  Supplement recommendations require peer-reviewed evidence of effect
  AND disclosure of any commercial relationship with manufacturers;
  the great majority of marketed fitness supplements have no
  evidence base and should not be recommended at all.

## Cover Design Specifications

### Visual Language

- **Colour palette:** High-contrast bold primaries (red, blue, black,
  yellow, white) for performance / strength / general-fitness titles
  where the cover should signal energy and outcome. Calmer earth
  tones (sage, terracotta, charcoal, cream) for mobility / yoga /
  rehabilitation titles where the cover should signal restorative
  practice. Premium dark + metallic accents for textbook-grade
  comprehensive titles where the cover should signal authority over
  intensity.
- **Typography:** Bold sans-serif (Gotham, Avenir Heavy, Helvetica
  Neue Bold, Proxima Nova Black) for performance and strength —
  uppercase titles common, condensed weights for impact. Slightly
  warmer sans-serif (Avenir, Source Sans, Lato) for general-fitness
  and lifestyle. Serif acceptable for textbook-grade titles where
  authority is the primary signal.
- **Imagery:** Three dominant traditions:
  1. **Body in motion** — athlete or trainee mid-exercise; lifts,
     runs, holds, mobility work. Most common; reader sees themselves
     doing the work. Calibrate the body type and intensity to the
     audience: elite-athletic imagery on a beginner book mis-signals.
  2. **Equipment / context** — barbell, kettlebell, mat, gym
     environment, road, pool. Strong for textbook positioning, for
     equipment-centred methodologies, and for titles avoiding
     body-image foregrounding.
  3. **Pure typography / iconographic** — for textbook, science-of-
     training, and lifestyle titles where the credibility cue is the
     book's voice and structure rather than aspirational imagery.
- **Mood:** Capable, accessible, evidence-based. The cover should
  signal "this is rigorous and you can use it" — not gym-bro
  intimidation, not before-and-after sensationalism, not wellness-
  industry softness. The reader buying a fitness book is committing
  to a programme; the cover must make that commitment feel
  realistic and supported.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Strength Training | Barbell / squat-rack / heavy-lift imagery OR pure typography for textbook positioning; bold sans-serif title; subtitle emphasises the methodology or population |
| Endurance / Cardio | Athlete-in-motion (runner, cyclist, swimmer) with road / track / open-water context; high-energy palette; subtitle clarifies discipline and distance focus |
| Flexibility / Mobility / Yoga | Calmer palette and imagery — practitioner in pose, mat-and-prop arrangement, or anatomical illustration; serif or warm sans-serif typography; restorative not performative mood |
| Sport-Specific | Sport-context imagery (court / field / wall / gi / range); typography signals the sport's culture; subtitle names the sport explicitly |
| General Fitness / Lifestyle | Lifestyle-context imagery (home, park, kitchen alongside training) OR clean typographic; broader-audience body representation; subtitle emphasises accessibility and time commitment |
| Functional / Rehabilitation | Anatomical or movement-quality imagery; restrained palette; serif or clean sans-serif typography; subtitle clarifies the condition or population (low back / knee / shoulder / postpartum / older-adult) |
| Nutrition for Fitness | Food / kitchen / measurement imagery OR macronutrient iconography; warmer palette than performance fitness; subtitle clarifies the relationship to training (fuelling / body composition / performance) |

### Typography Rules

- **Title:** 35–55% of cover area. Fitness titles can be promise-based
  ("Starting Strength", "Body by Science") or descriptive ("The Female
  Athlete Triad"). Both work; the title must read at thumbnail.
- **Subtitle:** Often does the descriptive work the title leaves
  abstract. "A Simple and Practical Guide to Coaching Beginners"
  (Rippetoe). "The Definitive Guide to Mobility for Strength
  Athletes." Specific subtitle outsells vague subtitle by a wide
  margin in this category.
- **Author name:** Larger for established authors whose name carries
  the methodology (Rippetoe, Tsatsouline, McGill, Contreras); smaller
  for unestablished authors where credentials in the subtitle do the
  work. Author qualification cues (PhD, CSCS, DPT) where present
  help in this category.
- **Edition / version marking:** Strength training and programming
  research evolves; "Third Edition" or "Updated for [year]" prominently
  on cover when applicable, to signal the book is currently relevant.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Strength Training | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Exercise & Fitness > Weight Training |
| Endurance / Cardio | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Exercise & Fitness > Aerobics (or Sports & Outdoors > Training > Running / Cycling / Swimming per discipline) |
| Flexibility / Mobility / Yoga | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Exercise & Fitness > Stretching (or > Yoga) |
| Sport-Specific | Kindle Store > Kindle eBooks > Sports & Outdoors > Coaching > [Specific Sport] (and Sports & Outdoors > Individual Sports > [Specific Sport]) |
| General Fitness / Lifestyle | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Exercise & Fitness (broad) |
| Functional / Rehabilitation | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Exercise & Fitness > Injuries & Rehabilitation (and Medical Books > Allied Health Services > Physical Therapy if textbook-grade) |
| Nutrition for Fitness | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Nutrition (and Cookbooks, Food & Wine > Special Diet > Sports & Athletics if recipe-driven) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Personal training / coaching | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Exercise & Fitness > Personal Trainers (textbook-style for working trainers) |
| Specific population — women's fitness | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Exercise & Fitness > Women's Health |
| Specific population — older adult | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Aging |
| Specific population — postpartum | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Women's Health > Pregnancy & Childbirth |
| Pain / movement quality | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Pain Management |
| Sports nutrition (textbook-grade) | Kindle Store > Kindle eBooks > Medical Books > Allied Health Services > Nutrition |
| Self-help / motivation crossover | Kindle Store > Kindle eBooks > Self-Help > Motivational |

### Keyword Recommendations

- The specific discipline / methodology
  ("starting strength", "kettlebell programming", "marathon training",
  "powerlifting for beginners", "yoga for back pain")
- Reader skill / population marker
  ("for beginners", "for women over 40", "for runners", "postpartum",
  "for desk workers", "for athletes")
- Outcome the reader is seeking
  ("build muscle", "lose fat", "increase mobility", "run faster",
  "manage back pain", "return to sport")
- Time / commitment frame where appropriate
  ("12-week programme", "30 minutes a day", "minimal equipment",
  "home workout", "no gym required")
- Comparable methodology / author for discoverability
  (readers of Rippetoe, readers of Tsatsouline, readers of McGill,
  CrossFit-adjacent, kettlebell-based)
- Equipment / context names
  ("barbell", "kettlebell", "dumbbells only", "bodyweight",
  "resistance bands", "Olympic lifting", "calisthenics")
- Avoid generic terms ("fitness", "exercise", "workout") in isolation
  — they drown in algorithmic noise; prefer compound phrases
  combining discipline + population + outcome
- Avoid promise-overreach phrases ("get ripped fast", "transform in
  30 days") — they signal pulp positioning and damage credibility
  with the readers serious fitness titles need to attract
