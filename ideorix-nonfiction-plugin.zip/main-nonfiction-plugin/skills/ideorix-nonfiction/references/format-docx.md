---
name: format-docx
description: "DOCX manuscript generation template"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

# DOCX Generation Template

> **As of v2.7.76 the engine ships a shared markdown-to-DOCX
> renderer** (`scripts/markdown-to-docx-render.sh`, spec at
> `markdown-to-docx-render.md`). New projects use it by default;
> existing projects opt in via `shared_renderer: enable` in
> `engine-data/project-config.md`. The shared renderer wraps
> pandoc, which handles the inline-parser edge cases (literal
> asterisks in model numbers, unmatched delimiters, smart quotes)
> that previously caused per-project ad-hoc renderers to fail.
>
> **This spec is retained** for projects that have not opted in
> and that need to write or maintain a per-project Node.js DOCX
> generator. The patterns below remain canonical for that path.
> When opting in to the shared renderer, the per-project script
> in this spec can be retired.

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.docx`

This DOCX export MUST be written to the canonical
project's `manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## Pre-Write Typography Gate (MANDATORY — runs before every DOCX write)

Before generating any DOCX, invoke the pre-export typography gate
on the source markdown:

```bash
bash scripts/pre-export-typography-gate.sh "{project-root}" "{source-md-path}"
```

When the source path is omitted, the gate scans every
`engine-data/chapters/ch*.md` and FAILs closed if any contain
typographic artifacts (ASCII straight quotes, double-hyphen em-dash
imposters, three-dot ellipses). Fix the source markdown BEFORE
attempting the DOCX write — typographic artifacts baked into the
export are far more expensive to find after publication than to
fix at the source.

The gate honors `typography_status: skip / legacy` and
`typography_target: ascii` in `engine-data/project-config.md`.

This pre-write gate (v2.7.68) complements the post-write integrity
gate below: the pre-write catches artifacts in the SOURCE before
they're written; the post-write catches malformed DOCX after.
Together they bracket the export.

## Post-Write Integrity Check (MANDATORY — runs after every DOCX write)

After generating any DOCX file (chapter, full manuscript, or any other
DOCX output), invoke the integrity check **before reporting success
to the user**:

```bash
bash scripts/docx-integrity-check.sh "{docx-path}" "{source-md-path}"
```

The source MD path is optional; supplying it adds a word-count
parity check against the source. For chapter DOCX exports, ALWAYS
supply the source MD — that's how the gate catches the "DOCX is a
stale snapshot from before the MD was edited" drift.

The gate verifies:
- DOCX file exists, non-zero bytes
- DOCX is a valid zip archive containing `word/document.xml`
- `word/document.xml` is parseable as XML
- `word/document.xml` contains zero `\x00` (null) bytes
- (with MD) word counts agree within ±5% or ±100 words, whichever
  is greater

If the gate exits non-zero, STOP. Do not report DOCX write success
to the user. The DOCX is malformed and Word + LibreOffice will
either refuse to open it or display truncated/wrong content. Fix
the generation pipeline (typical causes: null bytes injected by
Python string operations, stale DOCX-vs-MD drift after the MD was
re-edited), regenerate, and re-run the gate.

This gate exists to prevent the failure class documented in
`silent-failure-audit.md` row 60: a user reported chapters that
Word refused to open (null bytes in document.xml) and chapters
that opened but showed stale word counts (DOCX captured an
earlier MD state). The DOCX export pipeline reported success in
both cases — write completed, file exists on disk, no error
returned. The integrity gate makes the success claim verify
against reality.

## Overview

Generate .docx manuscript files using the `docx` npm package.
This template produces publisher-ready formatting.

## Manuscript Specifications

- **Page size:** US Letter (8.5" x 11")
- **Margins:** 1 inch all sides
- **Body font:** Times New Roman, 12pt
- **Chapter headings:** Times New Roman, 16pt, bold, centered
- **Line spacing:** 1.5
- **Paragraph spacing:** 6pt after each paragraph
- **First line indent:** 0.5 inch (except first paragraph after heading)
- **Page breaks:** Between every chapter
- **Header:** Book title (even pages) / Chapter title (odd pages) — from chapter 2 onward
- **Footer:** Page number, centered

## File Size Expectations

- **Short-form non-fiction (~25,000 words):** 40-65 KB (quick-read, essay collection, topical brief)
- **Standard non-fiction (~60,000 words):** 90-140 KB (memoir, self-help, how-to)
- **Comprehensive non-fiction (~100,000 words):** 140-220 KB (biography, narrative history, investigative)
- **Reference work (~150,000+ words):** 220+ KB (encyclopaedic, academic, textbook)

## Title Page Structure

```
[3 blank lines]

[Book Title — 24pt, bold, centered]

[1 blank line]

[Subtitle — 14pt, italic, centered] (if applicable)

[2 blank lines]

[Author Name — 16pt, centered]

[Page break]
```

## Chapter Structure

```
[Page break before each chapter]

[Chapter heading — 16pt, bold, centered]
[e.g., "Chapter 1: The Discovery"]

[1 blank line]

[Chapter body — 12pt, 1.5 spacing]
[First paragraph: no indent]
[Subsequent paragraphs: 0.5" first line indent]
```

## Scene Break Formatting

Within a chapter, scene breaks are indicated by:
```
[blank line]
* * *
[blank line]
```

Centered, with three asterisks separated by spaces.

## Node.js Generation Template

```javascript
const { Document, Packer, Paragraph, TextRun, AlignmentType,
        PageBreak, Header, Footer, PageNumber } = require('docx');

function createManuscript(title, author, chapters) {
  const doc = new Document({
    sections: [
      // Title page
      {
        properties: { page: { size: { width: 12240, height: 15840 },
                              margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
        children: [
          new Paragraph({ spacing: { before: 3600 } }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: title, bold: true, size: 48, font: 'Times New Roman' })]
          }),
          new Paragraph({ spacing: { before: 400 } }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ text: author, size: 32, font: 'Times New Roman' })]
          }),
        ]
      },
      // Chapter sections
      ...chapters.map((chapter, index) => ({
        properties: {
          page: { size: { width: 12240, height: 15840 },
                  margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } }
        },
        children: [
          // Chapter heading
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 },
            children: [new TextRun({
              text: `Chapter ${index + 1}: ${chapter.title}`,
              bold: true, size: 32, font: 'Times New Roman'
            })]
          }),
          // Chapter content paragraphs
          ...chapter.paragraphs.map((para, pIndex) => new Paragraph({
            spacing: { after: 200, line: 360 },
            indent: pIndex === 0 ? {} : { firstLine: 720 },
            children: [new TextRun({ text: para, size: 24, font: 'Times New Roman' })]
          }))
        ]
      }))
    ]
  });

  return Packer.toBuffer(doc);
}
```

## Content Parsing

Before generating the .docx, parse chapter markdown into paragraphs:

1. Split on double newlines for paragraph breaks
2. Convert scene breaks (`* * *` or `---`) into centered separator paragraphs
3. Handle dialogue paragraphs (start with `"`) — no first-line indent
4. Strip any markdown formatting (`**bold**` → bold TextRun, `*italic*` → italic TextRun)
5. Preserve em-dashes (—), curly quotes, and special characters

## CRITICAL: Paragraph Formatting Requirements

**Regardless of how the .docx is generated** (Node.js docx package, Pandoc,
Python python-docx, or direct XML), every body paragraph MUST have these
properties applied explicitly — do NOT rely on named styles resolving correctly:

**Body paragraphs (all paragraphs after the first in each chapter/scene):**
- First line indent: 0.5 inch (720 twips / 360 EMUs / `ind firstLine="720"`)
- Spacing after: 6pt (120 twentieth-points / `spacing after="120"`)
- Line spacing: 1.5 (360 twentieth-points / `spacing line="360"`)
- Font: Times New Roman, 12pt

**First paragraph after heading or scene break:**
- NO first line indent
- Spacing after: 6pt (same as body)
- Line spacing: 1.5 (same as body)

**Chapter headings:**
- Centered, bold, 16pt
- Spacing after: 20pt (400 twentieth-points)
- Page break before (except chapter 1 which follows the title page)

**If using Pandoc:** You MUST either:
1. Provide a reference.docx with BodyText and FirstParagraph styles properly
   defined (indent + spacing), OR
2. Apply spacing and indent as direct formatting on every paragraph rather
   than relying on style names

**If using Python python-docx:** Apply `paragraph_format.first_line_indent`
and `paragraph_format.space_after` directly on each paragraph object.

**Test:** Open the generated .docx in Word or LibreOffice. If all paragraphs
are flush-left with no indent and no spacing, the formatting was not applied.
This is the most common DOCX generation failure — fix it before delivery.
