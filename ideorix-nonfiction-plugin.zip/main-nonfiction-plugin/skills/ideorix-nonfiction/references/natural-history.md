---
name: natural-history
description: "Category plugin for natural history non-fiction. wildlife, botany, ecology, geology, marine biology"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Natural History. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | natural-history |
| Display Name | Natural History |
| Parent Group | Popular Science |
| Typical Word Count | 65,000–85,000 |
| Default Structure | Species/habitat-centred chapters with seasonal or geographic throughline |
| Citation Style | Endnotes with bibliography; in-text attribution for key researchers |
| Audience Baseline | Nature-curious general reader; no formal science background required |
| Comparable Titles | David Attenborough, Isabella Tree, Merlin Sheldrake, Robin Wall Kimmerer |

## Subcategory Options

When the user selects Natural History, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| wildlife-animal | Wildlife / Animal Behaviour | Species portraits, ethology, migration, predator-prey, social structures | Single-species deep dive, behaviour-as-narrative, seasonal cycle |
| botany-plant | Botany / Plant Life | Plant biology, forests, fungi, symbiosis, ethnobotany | Root-to-canopy exploration, life-cycle narrative, ecosystem web |
| ecology-ecosystems | Ecology / Ecosystems | Biomes, food webs, rewilding, biodiversity, ecosystem services | Place-based chapters, systems-level storytelling, before-and-after |
| geological-earth | Geological / Earth Science | Rocks, minerals, deep time, plate tectonics, volcanoes, paleontology | Deep-time narrative, landscape-as-character, stratigraphic journey |
| marine-biology | Marine Biology | Ocean life, coral reefs, deep sea, fisheries, marine mammals | Depth-zone structure, expedition narrative, underwater observation |

**Default:** If the user does not specify, use `wildlife-animal` conventions as baseline.

## Structural Architect Instructions

### Core Technique: Close Observation + Scientific Research

Natural history writing fuses two traditions: the **field naturalist** who observes
closely and the **research scientist** who explains mechanisms. Every chapter brief
must balance both. the reader should feel they are standing in the habitat AND
understanding the biology.

### Chapter Architecture Patterns

1. **The Field Moment**. Open in a specific place, at a specific time, observing a
   specific organism or phenomenon. Sensory detail is mandatory. The reader must feel
   the mud, hear the birdsong, smell the forest floor.
2. **The Zoom-In**. From the observed moment, narrow focus to a particular behaviour,
   structure, or process. What is happening here, biologically?
3. **The Science Layer**. Introduce the research that explains what was observed.
   Name the scientists. Describe the studies. This is where close observation meets
   peer-reviewed evidence.
4. **The Zoom-Out**. Pull back to the ecosystem, the evolutionary context, the
   geological timeframe. Show how this organism or process connects to larger systems.
5. **The Human Thread**. Where appropriate, connect to human experience, culture,
   history, or impact. Natural history is never just about nature. it is about our
   relationship with nature.

### Evidence Deployment

- **Field observations:** Direct, first-person or reported observation of organisms
  and habitats. These ground the narrative.
- **Scientific studies:** Peer-reviewed research that explains the observed phenomena.
  Method described briefly, results clearly stated.
- **Historical naturalists:** Darwin, Wallace, Humboldt, Carson, Leopold. draw on
  the tradition. Natural history has a rich intellectual lineage.
- **Indigenous and local knowledge:** Where relevant, include traditional ecological
  knowledge with proper attribution and respect.

### Brief Template Additions

For each chapter brief, the Architect MUST include:

- **Primary Organism/Habitat:** The central species, ecosystem, or geological feature.
- **Field Setting:** Specific location and season for the observational frame.
- **Key Behaviour/Process:** The biological or geological process being explored.
- **Research Studies:** 2–3 studies that illuminate the central subject.
- **Sensory Anchors:** Specific sensory details the Writer should develop (sight,
  sound, smell, texture, weather).
- **Scale Shifts:** Planned shifts between micro (cellular, molecular) and macro
  (ecosystem, geological time) perspectives.
- **Human Connection:** How this chapter links to human experience or impact.

## Content Writer Craft Rules

### Voice & Tone

- **Observant and reverent, not sentimental.** Wonder at nature is earned through
  precise description, not adjective-laden gushing.
- **Present tense for field scenes.** "The fox pauses at the edge of the clearing."
  This creates immediacy and presence.
- **Past tense for science and history.** "Tinbergen's 1963 study demonstrated..."
- **Patient.** Natural history writing is allowed to slow down. A paragraph describing
  a single organism in exquisite detail is not a digression. it is the genre.

### Sensory Writing Protocol

- Every chapter must engage at least three senses within the first page.
- Sensory details must be accurate to the habitat and season. Research the soundscape,
  the light quality, the smells of the specific environment.
- Avoid generic nature description. Not "the beautiful forest" but "the beech canopy,
  still bare in late March, letting grey light through to the bluebell leaves pushing
  through last year's leaf litter."

### Species & Taxonomy

- **Common name first,** followed by Latin binomial in italics on first mention:
  "the common swift (*Apus apus*)."
- Subsequent references use common name only unless taxonomic precision matters.
- When discussing multiple related species, a brief taxonomic orientation helps:
  "All three are corvids. the crow family."

### Scale & Time

- Natural history moves between scales constantly. Signal the shifts clearly.
- Microscale: "Under a hand lens, the lichen reveals..."
- Human scale: "Standing at the cliff edge, you can see..."
- Deep time: "Three hundred million years ago, this limestone was a tropical seabed."
- Use concrete time markers, not vague "long ago" language.

### Landscape as Character

- The place where natural history happens is not mere backdrop. Describe landscapes
  with the same care as organisms.
- Include geological substrate, hydrology, vegetation structure, microclimates.
- Return to the same place across the chapter to show how understanding deepens.

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the organism or landscape, vivid and specific. The reader
  should feel placed in the field before any science arrives.
- **Sentence calibration:** Medium-long sentences averaging 16–24 words, with sensory
  immersion woven into the syntax. Let the sentence length mirror the patient gaze of
  the naturalist.
- **Observational precision:** Every descriptive sentence must contain at least one
  detail only a close observer would notice. Generic beauty is the enemy.
- **Sensory layering:** Engage multiple senses within a single paragraph. sight and
  sound in one sentence, texture or smell in the next. The reader inhabits the habitat.
- **Rhythm pattern:** Long, flowing observational sentences punctuated by short,
  factual ones. "The beech canopy filters grey March light through bare branches
  onto the bluebell shoots below. Twelve species nest here."
- **Pace and patience:** Natural history prose is allowed to slow down. A paragraph
  dwelling on a single organism in exquisite detail is not a digression. it is the
  genre doing its work.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. Tension in natural
  history comes from close attention. the reader watches, waits, wonders what the
  organism will do next.
- **Scale-shift rhythm:** Alternate between micro-observation and macro-context within
  each section. The zoom-in and zoom-out creates a breathing rhythm in the prose.
- **Tense as instrument:** Present tense for field scenes creates immediacy. Past tense
  for science and history creates authority. The alternation itself generates rhythm.
- **Seasonal and temporal markers:** Anchor the reader in specific time. "late March,"
  "the second hour after dawn". to create a sense of lived duration in the prose.
- **Read-aloud test:** The prose should feel unhurried when spoken, like a naturalist
  narrating a walk. If it rushes, it betrays the genre.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Field presence | Chapter opens with or contains a vivid, sensorially rich field scene |
| 2 | Species accuracy | All species names, behaviours, and ranges are factually correct |
| 3 | Observation-science balance | Both close observation and peer-reviewed science are present |
| 4 | Scale shifts | Chapter moves between at least two scales (micro/macro/deep time) |
| 5 | Sensory engagement | Minimum three senses engaged per chapter |
| 6 | Taxonomic protocol | Latin binomials on first use, common names thereafter |
| 7 | Evidence density | Minimum 2 cited studies or named researchers per chapter |
| 8 | Landscape specificity | Settings are specific places, not generic "a forest" |
| 9 | Human connection | Chapter connects to human experience, culture, or impact |
| 10 | Voice consistency | Observant, patient, reverent tone maintained throughout |

## Source Requirements

### Mandatory Source Types

- **Peer-reviewed ecology/biology journals:** Primary evidence for species behaviour,
  population data, ecosystem dynamics.
- **Field guides and taxonomic references:** For species identification, range maps,
  habitat descriptions.
- **Historical naturalist texts:** Where the chapter engages with the tradition . 
  Darwin, Carson, Leopold, Humboldt, etc.
- **Conservation status databases:** IUCN Red List, national conservation databases
  for any species discussed.

### Indigenous Knowledge Protocol

- Traditional ecological knowledge (TEK) must be attributed to the specific community
  or knowledge holder, never presented as anonymous folklore.
- Use the community's preferred terminology and framing.
- Acknowledge that TEK often predates and sometimes surpasses Western scientific
  understanding of local ecosystems.
- Do not extract indigenous knowledge without contextualising the relationship between
  the knowledge system and Western science.

### Source Freshness

- **Taxonomy:** Check current accepted names. taxonomy changes frequently. Use the
  most recent accepted classification.
- **Conservation status:** Use the most recent IUCN assessment or national equivalent.
- **Population data:** Cite the most recent available survey data. Note the survey year.
- **Behavioural science:** Classic ethology studies remain valid; new findings should
  be from the last 10 years.

## Category-Specific Guardrails

### MANDATORY. Species Identification Accurate

- Every species mentioned must be identified correctly: common name, Latin binomial,
  and range must align.
- Do not place a species in a habitat or geographic region where it does not occur.
- If a species' taxonomy has recently changed, use the current accepted name and note
  the change if relevant.
- Verify conservation status against current IUCN Red List data.

### MANDATORY. Indigenous Knowledge Attributed

- Any reference to traditional ecological knowledge, indigenous land management, or
  indigenous species names must be attributed to the specific people or community.
- Never present indigenous knowledge as quaint anecdote. Treat it as a knowledge
  system with its own rigour.
- If the book discusses land, acknowledge whose traditional territory it is.

### Additional Guardrails

- Do not anthropomorphise animal behaviour beyond what ethological evidence supports.
  Animals can be described with agency, but do not project human emotions without
  scientific basis.
- Avoid the "balance of nature" myth. Ecosystems are dynamic, not static. Avoid
  language that implies a perfect natural equilibrium that humans disturbed.
- Do not romanticise wilderness as uninhabited. Most "wild" landscapes have been
  shaped by human activity, often indigenous management, for millennia.
- When discussing extinct species, be precise about cause and timing of extinction.
- Avoid "doom-only" narratives. Where conservation challenges are discussed, include
  efforts, successes, or possibilities alongside threats.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Earth tones (deep greens, rich browns, ochre) with accent
  colours drawn from the subject. coral red for marine, ice blue for polar,
  wildflower palettes for botany.
- **Typography:** Elegant serif for title. suggests tradition and authority. Subtitle
  in clean sans-serif for contrast. Author name in moderate weight.
- **Imagery:** Detailed natural illustration (botanical, zoological), photographic
  macro or landscape, or stylised nature patterns. Avoid clip-art animals.
- **Mood:** Quiet wonder, authority, intimacy with the natural world.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Wildlife / Animal Behaviour | Animal portrait or silhouette, habitat suggested |
| Botany / Plant Life | Botanical illustration, leaf/flower detail, forest canopy |
| Ecology / Ecosystems | Landscape vista, ecosystem cross-section, rewilding imagery |
| Geological / Earth Science | Rock strata, fossil forms, dramatic geological landforms |
| Marine Biology | Underwater colour, coral forms, ocean-surface light |

### Typography Rules

- Title: 35–55% of cover area. Consider elegant serif to evoke naturalist tradition.
- Subtitle: Explanatory, clarifying scope. Lighter weight below title.
- Author credentials (PhD, professor, field researcher) strengthen authority if present.
- Consider integration of illustration with typography. text wrapping around natural forms.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Wildlife / Animal Behaviour | Kindle Store > Kindle eBooks > Nonfiction > Science > Biological Sciences > Zoology |
| Botany / Plant Life | Kindle Store > Kindle eBooks > Nonfiction > Science > Biological Sciences > Botany |
| Ecology / Ecosystems | Kindle Store > Kindle eBooks > Nonfiction > Science > Biological Sciences > Ecology |
| Geological / Earth Science | Kindle Store > Kindle eBooks > Nonfiction > Science > Earth Sciences > General |
| Marine Biology | Kindle Store > Kindle eBooks > Nonfiction > Science > Biological Sciences > Marine Biology |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Nature & Ecology | Kindle Store > Kindle eBooks > Nonfiction > Science > Nature & Ecology |
| Essays & Narratives | Kindle Store > Kindle eBooks > Nonfiction > Science > Essays & Narratives |
| Conservation | Kindle Store > Kindle eBooks > Nonfiction > Science > Nature & Ecology > Endangered Species |

### Keyword Recommendations

- Include the primary species, habitat, or geological feature
- Include "natural history" as a keyword
- Include geographic region if the book is place-specific
- Include "nature writing" for crossover literary appeal
- Include comparable author names for discoverability
