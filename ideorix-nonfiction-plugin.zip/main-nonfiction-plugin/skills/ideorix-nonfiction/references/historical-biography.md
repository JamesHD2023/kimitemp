---
name: historical-biography-category
description: "Category-specific instructions for historical biography non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Historical Biography. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | historical-biography |
| Display Name | Historical Biography |
| Parent Group | Memoir & Biography (and History > [Period or Region] where the era / context is foregrounded; cross-listed with both shelves in trade publishing) |
| Typical Word Count | 100,000–180,000 (the period research demand makes historical biographies typically longer than contemporary biographies; multi-volume works on major figures routinely run 200,000+ across volumes; ancient subjects with limited surviving sources sometimes shorter at 80,000–110,000) |
| Default Structure | All biography.md conventions apply, plus historical-research conventions: chronological with thematic analysis woven through; period-accurate scene reconstruction at chapter openings; primary-source quotation at moments of maximum impact; "the historian's craft" visible (what the sources say, what they don't, what the absence means); engagement with prior scholarship throughout |
| Citation Style | Endnotes mandatory and substantial (Chicago Notes-Bibliography or equivalent); primary sources cited with full provenance (archive name, collection, folder / volume reference, document type, date, language, translator where applicable); secondary scholarship engaged with by named-scholar attribution; bibliography appended; period sources distinguished from interpretive scholarship in the notes; image / artefact credits where applicable |
| Audience Baseline | Reader interested in the historical period and / or the figure; varies from generalist history-curious to academic-engaged depending on positioning; some prior period-knowledge may be assumed (an Elizabethan biography assumes some familiarity with Tudor England) but specialist knowledge not required; substantial period context built into the work |
| Comparable Titles | Stacy Schiff (*Cleopatra*, *The Witches*, *Vera*), David McCullough (*John Adams*, *Truman*, *1776*), Ron Chernow (*Hamilton*, *Washington*, *Grant*), Antonia Fraser (*Marie Antoinette*, *Mary Queen of Scots*), Diarmaid MacCulloch (*Thomas Cromwell*, *Christianity*), Hermione Lee (*Virginia Woolf*, *Penelope Fitzgerald*), Lyndall Gordon (*Charlotte Brontë*), Mary Beard (*SPQR*, *Twelve Caesars*), Tom Holland (*Rubicon*, *Persian Fire*), Robert Massie (*Peter the Great*, *Catherine the Great*), Andrea Wulf (*The Invention of Nature: Humboldt*), Annette Gordon-Reed (*The Hemingses of Monticello*), Jill Lepore (*Book of Ages: Jane Franklin*), Stephen Greenblatt (*Will in the World*), Tom Reiss (*The Black Count*), Jonathan Spence (*The Death of Woman Wang*), Adam Hochschild (*King Leopold's Ghost*), Linda Colley (*The Ordeal of Elizabeth Marsh*) |

## Subcategory Options

When the user selects Historical Biography, prompt for subcategory
refinement based on the subject's period:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| ancient-classical | Ancient / Classical | Figures from antiquity through the fall of Rome (c. 3000 BCE – 5th century CE); Egyptian / Mesopotamian / Greek / Roman / Persian / Han Chinese / classical Indian subjects; Cleopatra, Caesar, Augustus, Alexander, Cicero, Boudicca, Confucius, Ashoka, Hatshepsut | Source-scarcity acknowledgement central (often few primary sources, often hostile / posthumous); period-context (Roman legal system, Greek polis, Egyptian religious framework, etc.) substantial; archaeological evidence integrated; reception-history often part of the meaning (Cleopatra's image vs Cleopatra's record) |
| medieval-renaissance | Medieval / Renaissance | 5th–17th century subjects; European medieval, Byzantine, Islamic Caliphate, Mongol, Yuan / Ming / Edo Japanese, late medieval / Renaissance European subjects; Henry VIII, Mary Queen of Scots, Saladin, Genghis Khan, Hildegard of Bingen, Christine de Pizan, Akbar | Primary sources include charters, chronicles, letters (where preserved), official documents in original languages; period religious / political / economic frameworks substantial; gender / class / regional scholarship integrated; original-language primary sources translated with translator credit |
| early-modern-enlightenment | Early Modern / Enlightenment | 17th–18th century; Founding generation, Enlightenment thinkers, exploration / colonial figures, early-industrial figures; Voltaire, Catherine the Great, Hamilton, Adams, Wollstonecraft, Toussaint Louverture, Frederick Douglass (early career), Captain Cook | Substantial preserved correspondence; printing-press era's primary-source density; period scientific / philosophical / political frameworks; colonial / imperial / slavery-and-resistance contexts foregrounded; engagement with current revisionist scholarship |
| nineteenth-century | Nineteenth Century / Industrial Age | Industrial-revolution era through end of 1899; Victorian and Romantic figures, abolition / suffrage / labour leaders, scientific revolutionaries, anti-colonial figures; Victoria, Lincoln, Darwin, Marx, Tubman, Tolstoy, Bismarck, Sojourner Truth, Tagore | Massive surviving documentary record (letters, diaries, newspapers, official records, photographs); period industrial / scientific / colonial / class-and-gender frameworks; engagement with current historiographic re-evaluations (the canon has been substantially revised since c. 1990 to centre previously marginalised figures) |
| twentieth-century-modern | Twentieth-Century Modern | 1900s–1980s; world wars, totalitarianism, decolonisation, civil-rights figures, Cold-War figures; Churchill, Roosevelt, Stalin, Mao, Gandhi, MLK, Mandela, de Beauvoir, Einstein, Marie Curie, Frida Kahlo, Mao | Recent enough that some witnesses may still be living and accessible; documentary record substantial including audio / film / photographs; political / ideological / global-scale-conflict frameworks; subjects often still politically charged; cooperation / authorisation considerations where families or estates retain control |
| contemporary-historical | Contemporary Historical (recent figures in historical perspective) | Late-20th-century figures and recently-deceased subjects whose lives are now sufficiently complete and historically distanced for biographical treatment; varies by figure but often within last 20–40 years (Nelson Mandela, Steve Jobs, Margaret Thatcher, Princess Diana, Václav Havel, RBG) | Documentary and audio / video record substantial; living witnesses and family often available; historiographic distance still developing; contestation about which contemporary framings will hold up over time; explicit positioning relative to the figure's still-active reception arc |
| group-collective-historical | Group / Collective Historical Biography | Multiple-figure historical biography — a family, a movement, a workshop, an intellectual circle; the Hemingses of Monticello (Gordon-Reed), the Lunar Men (Uglow), the Bloomsbury Group, the Founding Mothers, the Romantics, the Algonquin Round Table | Multiple-protagonist structure; thematic chapters covering shared events; genealogical / institutional chart in front matter; chronological backbone with perspective-shifts between figures; the collective itself as biographical subject |

**Default:** If the user does not specify, prompt for the subject's period
(specific century or era) and select accordingly; fallback to
`twentieth-century-modern` for unclear cases (the most-published period
in trade historical-biography publishing).

## Structural Architect Instructions

```
STRUCTURE
- Chronological with thematic analysis woven throughout
- Extra requirements beyond standard biography: period accuracy, primary source density
- Historiographic awareness: engage with how previous scholars have understood this figure
- The historian's craft: what the sources say, what they don't, and what that absence means

CATEGORY ARCHITECTURE
- All biography architecture rules apply (see biography.md)
- PLUS: period-accurate language and context (no anachronisms)
- PLUS: source hierarchy transparency (what's primary, what's interpreted)
- PLUS: engagement with historiographic debates about the subject
- The subject must be understood within their era's values and constraints

FORBIDDEN
- All biography prohibitions apply
- PLUS: Anachronistic language ("networking" for a 16th century figure)
- PLUS: Projecting modern morality without acknowledgement
- PLUS: Presenting one historiographic interpretation as settled fact when debate exists
- PLUS: Filling gaps in the historical record with invented "probable" scenes
```

## Content Writer Craft Rules

```
VOICE & TONE
- Scholarly-accessible: the historian as storyteller with footnotes
- Period atmosphere rendered through contemporary sources (letters, diaries, accounts)
- Confident analysis tempered by honest acknowledgement of what isn't known
- "The evidence suggests..." rather than "It was..."

PROSE RHYTHM MAPPING
- Ch 1 hook: immerse the reader in the era through the subject's eyes. the past must feel lived-in, not described
- Period-appropriate cadence: the prose rhythm should echo the era without descending into pastiche or archaism
- Sensory historical detail from the opening page. what the subject saw, heard, smelled in their world
- Sentence length varies with purpose: measured scholarly analysis (18-26 words), vivid scene-setting (14-20 words)
- Tension ≥4 from chapter 1. the reader must sense that this life, in this era, contains genuine stakes
- The historian-as-storyteller voice: confident analysis tempered by honest acknowledgement of what the sources do not reveal
- Evidence integration is layered: primary sources (letters, diaries, accounts) woven into narrative, not quarantined in footnotes
- Historiographic transparency as rhythm tool: moments of "we don't know" create their own narrative tension
- Deploy direct quotation from period sources at moments of maximum emotional or analytical impact
- Pacing across centuries: the subject's life provides the chronological spine; the era provides the atmospheric depth
- Paragraph rhythm: scene paragraphs transport the reader to the period; analytical paragraphs bring them back to the historian's study
- Strategic use of dramatic irony: the historian knows what the subject could not. use this knowledge to build tension, not superiority
- Reader engagement: every chapter must make the past feel urgent, not merely interesting
- Authority delivery through source specificity: "In a letter dated March 1587..." carries more weight than "It is believed that..."
- Avoid the textbook trap: vary sentence length deliberately; monotonous academic prose is a genre failure
- The "why should I read this book" question is answered by making the subject's world vivid enough to inhabit
- Contextual passages earn their place by illuminating the subject's choices, not by displaying the historian's erudition
- Chapter transitions should feel like turning a page in the subject's life, not closing a textbook chapter
```

## Quality Check Criteria

The Quality Check pipeline tests historical biography against ten
period-fluent, source-rigorous, historiographically-honest standards.
A manuscript that fails three or more is not yet a publishable
historical biography; one that fails any of #1, #2, #3, or #6
should not ship regardless of strength elsewhere (period accuracy,
primary-source provenance, historiographic engagement, and source-
gap honesty are genre-defining).

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Period accuracy — language and concept | No anachronistic vocabulary, framing, or assumption attributable to the historian (period figures may use period vocabulary in quotation); concepts ("networking", "stress", "trauma", "career") not retrojected onto figures whose era did not have them; period-appropriate measurement (leagues / florins / talents not silently converted) with translation footnotes; the subject's world rendered in its own terms before being interpreted in ours |
| 2 | Primary-source density and provenance | Substantial direct engagement with contemporary documents (correspondence, diaries, official records, period publications, depositions, court records, will / probate, parish / civic registers) appropriate to what survives for the era; archive name + collection / folder reference + document type + date in notes for each cited primary source; original-language sources flagged as such with translator attribution; gaps in surviving record acknowledged rather than papered over |
| 3 | Historiographic engagement | Prior major scholars on the subject named and engaged with by argument (not merely listed in bibliography); points where this biography agrees with / extends / departs from established scholarship made explicit; contested questions in the field presented as contested rather than resolved; revisionist scholarship of the last 30 years (post-1995 feminist / postcolonial / social / cultural history of the relevant period) integrated, not ignored |
| 4 | Source-gap honesty | "We don't know" used where the record does not yield an answer; conjecture flagged as conjecture ("it is likely that...", "the evidence permits but does not require..."); silences in the archive named (whose records survive, whose did not, why); invented or imagined scenes prohibited unless explicitly framed as imaginative reconstruction with sources for each element disclosed |
| 5 | Period context — political / social / economic / religious | The subject's world built into the work substantially enough that a reader unfamiliar with the era can navigate the figure's choices; the legal / religious / economic / political framework that constrained or enabled the subject's actions made legible without becoming textbook recitation; context earns its place by illuminating the figure's choices, not by displaying the historian's erudition |
| 6 | Modern-morality framing | When the subject's actions or assumptions diverge sharply from current ethical standards (slaveholding, anti-Semitism, misogyny, colonial violence, religious persecution), the biography neither retroactively excuses ("a man of his time") nor retroactively condemns without contextual depth; the period's own dissenting voices acknowledged where they existed; the gap between then and now made explicit rather than smoothed over |
| 7 | Archive engagement and provenance trail | The biographer has worked with the surviving archival record directly rather than purely through other historians' citations; archive visits / digitisation platforms / collection custodians acknowledged; document discovery / re-examination contributions (if any) clearly attributed; secondary sources used as scholarship to engage with, not as substitutes for primary research |
| 8 | Material culture and visual / archaeological evidence integration | Where relevant to the period (artefacts, portraits, architecture, dress, archaeological sites, surviving objects) integrated as evidence rather than decoration; image / artefact credits with collection-of-record cited; reproductions / reconstructions distinguished from contemporary objects; for ancient subjects in particular, archaeological evidence read alongside textual evidence rather than subordinated to it |
| 9 | Reception-history awareness | The figure's posthumous image (how they have been remembered, mythologised, distorted, weaponised) acknowledged where it shapes available sources or popular understanding; the difference between what the record shows and what the cultural memory says made visible (Cleopatra-the-record vs Cleopatra-the-image; Lincoln-the-record vs Lincoln-the-monument); the biographer's own positioning in this reception arc declared where relevant |
| 10 | Prose craft — historian as storyteller | Period atmosphere rendered through contemporary sensory detail (what the subject saw, smelled, heard) rather than through generic costume-drama vocabulary; sentence rhythm varied (textbook monotone is a genre failure); direct quotation from period sources deployed at moments of maximum impact rather than scattered indiscriminately; chapter openings immerse rather than recap; "the historian's craft" visible (showing the working) without becoming methodological self-display |

A manuscript scoring 8+ on this rubric, with no failures on
the four genre-defining criteria (#1 period accuracy, #2 primary-
source density, #3 historiographic engagement, #6 modern-morality
framing), is publishable historical biography regardless of
era. A manuscript scoring 6–7 needs targeted revision, typically
on archive-engagement, source-gap honesty, or context-
integration. A manuscript scoring below 6 — or failing any of
#1 / #2 / #3 / #6 — needs structural rebuild, not surface revision.

## Source Requirements

Historical biography sits at the intersection of biographical
craft and historical-research convention. Its sources are
substantially heavier than contemporary biography (where
interviews and recent documentation dominate) and substantially
more provenance-disciplined than literary nonfiction (where the
historian's interpretive freedom is greater). Three layers of
requirement structure the work.

### Mandatory Source Types

| Source Tier | Examples | Required Use |
|-------------|----------|--------------|
| Primary — contemporary documents | Correspondence; diaries; account books; legal records (wills, probate, court proceedings, indictments, depositions); parish / civic registers (baptism, marriage, burial); state papers; treaties; ambassadorial dispatches; legislative records; petitions; period newspapers / broadsheets; pamphlets; sermons; period scientific / philosophical / literary publications by or about the subject; ship logs; muster rolls | The evidentiary spine of the biography. Direct engagement (not citation-laundering through prior scholarship) substantial enough that the figure's voice and the period's texture come through the historian's prose. Cited in notes with archive name + collection + folder / volume + document type + date + language + translator (where applicable) |
| Primary — material and visual culture | Portraits / miniatures / sculpture / death masks; surviving personal objects; architecture (residences, public buildings, places of worship attended); dress / textiles / jewellery; coinage; archaeological remains; period maps; period printed images / engravings; for ancient subjects: inscriptions, papyri, ostraca, archaeological sites, numismatic evidence | Used as evidence (not decoration) where relevant; collection-of-record cited; reproductions distinguished from originals; for periods with limited textual record (much of antiquity, some medieval / non-Western contexts), material evidence weighted equally with text |
| Primary — period commentary by contemporaries | Memoirs / autobiographies by people who knew the subject; period biographies; contemporary historical accounts (Plutarch on Caesar; ambassadorial reports on Elizabeth I; Saint-Simon on Louis XIV); contemporary critical / hostile sources (often the most detailed surviving accounts of figures whose own records were destroyed) | Engaged with for what they reveal about the subject AND for what they reveal about the contemporary's agenda; hostile or partisan sources weighed as such; the silence of contemporaries about the subject (where it occurs) noted as evidence in itself |
| Secondary — historiographic scholarship | Major prior biographies; period-history monographs (the era / region / institution / movement within which the subject acted); scholarly journal articles (named journals e.g. *Past & Present*, *American Historical Review*, *English Historical Review*, *Journal of African History*, *Renaissance Quarterly*); revisionist scholarship of the last 30 years; PhD theses and edited volumes; specialist reference works (the *Oxford Dictionary of National Biography*, the *American National Biography*, the *Dictionary of Irish Biography*, etc.) | Engaged with by argument (named scholar, position, why this biography agrees / extends / departs); not used as substitutes for primary research; revisionist scholarship of the last 30 years specifically engaged with — feminist / postcolonial / social / cultural / global / queer / disability history of the relevant period |
| Secondary — interpretive / methodological frameworks | Microhistory; prosopography; gender history; history of emotions; new cultural history; postcolonial historiography; Atlantic / global / connected-histories approaches; environmental / ecological history where relevant | Methodological choices declared in front matter or introduction; the biography's interpretive lens made explicit rather than presented as neutral common sense |
| Tertiary — reference and verification | Calendars / chronologies of the period; specialist gazetteers and atlases; period dictionaries (e.g. Johnson's *Dictionary* for 18th-century English; Du Cange for medieval Latin); genealogical reference works (peerages, registers, complete-peerages); numismatic / sigillographic / paleographic guides for relevant periods; conversion tables (currency, calendar, measurement); biographical dictionaries | Used to verify dates, names, ranks, places, currency conversions; not substitute for primary sources where primary sources exist |

### Source Freshness and the Survival Problem

Unlike contemporary biography, where source freshness usually
means recency, historical biography's source-freshness question
is about **survival**: what remains, what was destroyed (when /
how / by whom), what was created later, what has been
rediscovered. The biography must engage with this honestly.

| Period | Typical Survival Profile | Implications for the Biographer |
|--------|--------------------------|--------------------------------|
| Ancient / classical | Sparse, often hostile, often posthumous, often filtered through later compilers (Plutarch's *Lives* compiled centuries after most subjects); papyri / inscriptions / archaeology supplement text; whole categories of person (women, enslaved, non-elite) typically absent from the surviving record | Source-scarcity acknowledgement central; the gap between record and reconstruction explicitly mapped; archaeological / material evidence weighted heavily; biography must be honest about what cannot be recovered |
| Medieval / Renaissance | Charters, chronicles, legal records, ecclesiastical records survive variably (some periods / regions richer than others); illiterate or non-elite subjects rarely speak in their own voice; women's records often filtered through male relatives' or institutional records; non-European medieval records survive in different forms (Islamic chancery records, Chinese dynastic histories, Mongol oral traditions) | Source-language fluency or expert collaboration required for original-language work; the documentary base for the subject made explicit ("the principal sources for this life are..."); silences in the record (the unrecorded years, the missing letters) named |
| Early modern / Enlightenment | Printing-press density; substantial preserved correspondence; emergence of news media; fuller documentary base for many figures; colonial / imperial archives extensive but differentially preserved (European-administrator records preserved more fully than colonised-people records) | Source abundance for elite European subjects; source absence / fragmentation for many non-elite, non-European, enslaved, indigenous subjects whose lives intersected with these archives; biography of marginalised subjects in this period requires "reading against the grain" of colonial / institutional records |
| Nineteenth century | Massive documentary record (correspondence, diaries, published memoirs, newspapers, photographs, official records, parliamentary papers, census records); growing self-documentation by previously-silenced groups (former enslaved people's narratives, suffrage activists' archives, working-class autodidacts) | Selectivity becomes the discipline (one cannot read everything); explicit choice-making about what to include / exclude; engagement with current historiographic re-evaluations (the canon has been substantially revised since c. 1990 to centre previously marginalised figures) |
| Twentieth century / contemporary historical | Documentary, audio, film, photographic, broadcast, and digital records; living witnesses sometimes still accessible; subjects often still politically charged; family / estate cooperation considerations; classified records (state secrets, intelligence files) variably released | Recency of subject creates contestation about which contemporary framings will hold up; explicit positioning relative to the figure's still-active reception arc; oral history methodology where living witnesses interviewed; FOIA / declassification status of records noted |

### Attribution Standards

| Element | Standard |
|---------|----------|
| Citation style | Chicago Notes-Bibliography (or equivalent scholarly system); endnotes mandatory and substantial; bibliography appended |
| Primary source citations | Archive name + collection / fond / record group + folder / volume / item reference + document type + date + language + translator (for non-English originals) + folio / page reference where applicable |
| Secondary source citations | Author + title + edition + publisher + place + year + page-specific reference; for journal articles: author + title + journal + volume + issue + year + page range + DOI where available |
| Original-language sources | Foreign-language quotation: original text in note (or appendix) + English translation in body OR English translation in body + original-language flag with translator credit; "translation mine" disclosure where the biographer has done the translation |
| Image / artefact credits | Collection-of-record + accession number + photographer / engraver (where known) + reproduction-rights credit (museum, archive, individual rights-holder); for digital images, URL and access date |
| Maps and chronologies | Front matter; cartographer / source for maps cited; chronologies distinguish between firmly-dated events and approximate / disputed dates |
| Family trees / institutional charts | Front matter for biographies where genealogy / institutional position is structurally important; sources for genealogical claims cited |
| Pseudonymous / disputed authorship | Period authorship questions (e.g. *Junius* letters; disputed Shakespeare authorship; pseudonymous abolitionist tracts) acknowledged; current scholarly consensus stated; the biographer's own position declared |
| Currency / measurement conversion | Footnote conversion to modern equivalents on first major occurrence; ongoing references in period units; conversion methodology / source for the conversion table cited (Bank of England historical converter, Measuring Worth, period exchange-rate scholarship) |
| AI / digital tool disclosure | Use of digital text-search tools (e.g. searching digitised newspaper archives), HathiTrust, Google Books, AI translation aids, OCR tools disclosed in methodology note; AI used for substantive interpretation prohibited |

## Category-Specific Guardrails

Historical biography inherits every biography guardrail (see
biography.md) and adds period-specific historiographic
constraints. The combination is what makes the form distinct from
both contemporary biography (no archive-based reconstruction
problem) and from period-history-with-a-figure (the figure, not
the era, remains the structural spine).

### MANDATORY — Period Accuracy

Anachronism is genre-breaking. The historian's own prose must
not retroject vocabulary, concept, or assumption belonging to a
later period onto an earlier subject. This is the single
fastest-detected and most damaging genre failure in trade
historical biography review.

- **Vocabulary** — Words that did not exist or did not mean what they now mean in the subject's period must not appear in the historian's voice. "Networking" applied to a 16th-century courtier; "stress" applied to a Roman general; "trauma" applied to a medieval queen; "career" applied to a figure in a society where occupations were assigned by birth or guild; "teenager" applied to anyone before 1944. Period figures may use period vocabulary in quotation; the historian's framing must not import later vocabulary uncritically.
- **Concept** — Even where the word existed, the concept may not have. "Childhood" as a culturally distinct life-stage is a relatively recent construction (Ariès et al.); "homosexuality" as identity is a 19th-century construction; "race" as biology is an 18th–19th century construction; "the economy" as a discrete sphere is a 19th-century construction; "privacy" as a value is differently configured in different periods. Historians must not import current conceptual maps into earlier periods uncritically.
- **Assumption** — The unstated assumptions of the present (individualism, romantic-love marriage, secular default, nation-state framing, gender binary, child-centred parenting, longevity expectations, work / leisure separation) must not be projected onto figures whose worlds differently arranged these axes.
- **Measurement and currency** — Period figures used period measurement and currency; conversions to modern equivalents belong in footnotes, not in body prose silently substituted for period figures. £100 in 1750 is not £100 today; a "league" is not a kilometre; a "talent" is not a dollar.
- **Calendar and date** — Calendar reforms (Julian → Gregorian transitions in different countries at different times) acknowledged where dates straddle them; "Old Style / New Style" disclosure where applicable.
- **Geography and place-names** — Period names used (Constantinople not Istanbul before 1930; Persia not Iran before 1935; Bombay not Mumbai before 1995 in their period contexts), with current-name footnote on first occurrence; political boundaries as they existed in the period, not as they exist now.

### MANDATORY — Historiographic Honesty

Historical biography is a contribution to a scholarly conversation,
not an isolated act of personal interpretation. The reader is owed
visibility into where the biography sits in that conversation.

- Major prior biographies of the same subject named and engaged with by argument; what this biography agrees with / extends / departs from made explicit.
- Contested questions in the field presented as contested. Did Cleopatra commit suicide or was she murdered? Did Richard III order the murder of the Princes in the Tower? Was Anne Boleyn guilty of any of the charges? Did Mary Queen of Scots write the Casket Letters? These are not settled; biographies that pretend they are settled (in either direction) breach historiographic honesty.
- Revisionist scholarship of the last 30 years engaged with, not ignored. Feminist, postcolonial, social, cultural, global, queer, and disability history of the relevant period have substantially revised understanding of nearly every historical subject; a biography that proceeds as if pre-1995 scholarship is the last word fails this guardrail.
- Sources that contradict the biographer's interpretation engaged with rather than omitted. The reader is owed the strongest counter-evidence, not the weakest.
- The biographer's own positionality (where it materially shapes the work — e.g. national / religious / political / personal connection to the subject or period) declared in front matter rather than concealed under a tone of neutral common sense.

### MANDATORY — Source-Gap Honesty

The historical record is incomplete. Some periods, regions, and
groups left rich documentation; others left almost none. The
biographer's craft includes naming the gaps, not papering over
them.

- "We don't know" is acceptable and necessary. Where the record does not yield an answer, the biography says so rather than inventing a probable answer.
- Conjecture is flagged as conjecture: "it is likely that...", "the evidence permits but does not require...", "no source confirms but the pattern of her later actions suggests...". The reader can distinguish what the biographer knows from what the biographer infers.
- Invented or imagined scenes are prohibited unless the work is explicitly framed as imaginative reconstruction (in which case it is a different genre — historical fiction or narrative nonfiction with disclosure). A historical biography does not "reconstruct" a scene the sources do not document.
- Silences in the archive named: whose records survive, whose did not, why. The unrecorded years of a famous figure's youth; the missing letters; the lost diary; the records destroyed in fire / war / deliberate suppression; the categories of person (women, enslaved, non-elite, illiterate) systematically absent from the record.
- "Reading against the grain" of biased sources (colonial administrators on colonised subjects; male contemporaries on female subjects; orthodox sources on heterodox subjects) acknowledged as method rather than presented as transparent reporting.

### MANDATORY — Modern-Morality Framing

Historical figures held positions, owned people, committed acts,
and assumed truths that diverge sharply from current ethical
standards. The biographer's task is neither to retrospectively
excuse nor to retrospectively condemn, but to make the gap
between then and now visible without flattening either.

- "A man of his time" is not sufficient framing on its own. The period had dissenters; their existence is the strongest evidence that the position was contested in its own day, not merely from ours.
- Slaveholding, imperial violence, anti-Semitism, misogyny, religious persecution, and other now-rejected positions are named for what they are; neither softened with euphemism ("served by", "unfortunate practices of the day") nor flattened with universal condemnation that erases the period's own dissenting voices.
- The period's own dissenting voices acknowledged where they existed (abolitionists during slaveholding; women writing against patriarchy; converts and dissenters challenging religious orthodoxies; contemporaries who criticised colonial violence).
- Where the subject's progressive-for-the-period actions are highlighted, the limits of that progressivism within the figure's own life and society are also shown (the abolitionist who held racial hierarchies; the suffragist who excluded working-class or non-white women; the religious reformer who persecuted the next generation of dissenters).
- The biographer's own ethical engagement with the material declared rather than concealed; the silence of "neutral history" is itself an ethical position and is named as such.

### MANDATORY — Source-Language and Translation Integrity

For subjects whose surviving record is in languages other than
English, translation is interpretation. The reader is owed
visibility.

- Original-language sources flagged as such; translator credited (the biographer where they translated, the published translator otherwise).
- Where the biographer is working with sources in a language they do not read fluently, this is acknowledged and expert collaboration / commissioned translation cited.
- Key untranslatable terms left in original language with explanatory note (Roman *pietas*, medieval *honor*, Renaissance *virtù*, Confucian *ren*, Arabic *adab*, Sanskrit *dharma* — none of these translate cleanly into English single-word equivalents).
- Multiple translations of canonical primary sources (the Bible, the Quran, classical texts) noted with the chosen translation specified and rationale where the choice is interpretively consequential.

### Additional Guardrails

- **Reception-history vs record-history distinction** — The figure's posthumous mythology (how Cleopatra has been depicted, how Lincoln has been monumentalised, how Boudicca has been re-imagined for successive generations) is acknowledged where it shapes available sources or the reader's prior understanding; the biographer's distinction between what the record shows and what the cultural memory says is made visible.
- **National / cultural framing transparency** — The biographer's national, cultural, religious, and political positioning declared where it shapes the work; "British biography of a French subject" or "American biography of a Vietnamese revolutionary" carries framing that should be acknowledged rather than presented as neutral.
- **Image and material-evidence rights** — Reproduction permissions for portraits, manuscripts, artefacts, archaeological photographs, and other visual material secured prior to publication; collection-of-record credited; reproductions / reconstructions distinguished from contemporary objects in caption.
- **Living-descendants sensitivity (where applicable)** — For subjects whose descendants are still living and may be affected by the biography (recent slavery / Holocaust / genocide / colonial-violence subjects), descendant communities consulted where appropriate; descendant scholarship engaged with; the biography does not speak past those most directly inheriting the subject's legacy.
- **Genealogical claim verification** — Family trees in front matter sourced; period genealogical reference works cited; speculative or unproven family connections flagged as such (the "probable" family link, the "claimed but unverified" descent).
- **Archaeological evidence integrity** — Where archaeological evidence is integrated, current consensus on the dating / interpretation of the site / object cited; superseded interpretations flagged as superseded; ongoing excavations / contested attributions acknowledged.
- **Anonymous or composite figures (where used in framing)** — Some subjects (especially in microhistory of non-elite figures) are partly reconstructed from fragmentary records; the methodology of reconstruction declared; composite reconstructions, where they appear at all, explicitly framed and prohibited from being passed off as biography of an individual.
- **Medical-historical claims** — Retrospective diagnoses of historical figures (was Henry VIII syphilitic? did Lincoln have Marfan's? was Joan of Arc epileptic / schizophrenic / autistic?) approached with extreme caution; flagged as speculative; medical-history scholarship engaged with rather than amateur diagnosis offered; the limits of what historical evidence can support medically declared.
- **Confidentiality of contemporary informants (for contemporary-historical subgenre)** — For figures within recent enough range that living family / colleagues / dissidents / former associates have been interviewed, source-protection conventions of contemporary biography apply; named / pseudonymous / off-record distinctions agreed and respected.
- **Front matter completeness** — Methodology note (sources, archives consulted, language base, translator credits); chronology of the subject's life; map(s) of the relevant geography; family / institutional / political chart where structurally relevant; image-credits inventory; abbreviations key for archive references in notes.

## Cover Design Specifications

The historical biography cover signals four things simultaneously
at point-of-sale: (1) this is a serious work of history, not a
costume-drama novelisation; (2) the subject is identifiable; (3)
the period is legible without specialist knowledge; (4) the
imprint is biography / history (not historical fiction, not
academic monograph). Get any of these wrong and the work mis-
shelves itself in the reader's mind before they open it.

### Visual Language

Three traditions dominate trade historical biography cover design;
each carries its own connotations and shelves the book differently.

| Tradition | Visual Approach | Reader Signal | Comp Examples |
|-----------|-----------------|---------------|---------------|
| Period portrait full-bleed | A single contemporary portrait of the subject (oil, miniature, sculpture, drawing, photograph for 19th–20th c subjects), often cropped and overlaid with title typography | "Authoritative trade biography. The subject is the centre. The period is signified by the artefact itself." | Schiff *Cleopatra* (sculpture); Massie *Catherine the Great* (Levitsky portrait); Chernow *Hamilton* (Trumbull portrait); McCullough *John Adams* (Stuart portrait) |
| Period-document or period-object | Manuscript page, letter, map, coat of arms, royal seal, period engraving, period photograph, or significant artefact (the Hampden manuscript, the Hemingses' indenture page, the Cromwell signature, a battle-map, a death-warrant) | "This biography is built from primary sources. The document is the evidence." | Gordon-Reed *The Hemingses of Monticello*; Lepore *Book of Ages*; Wulf *The Invention of Nature*; Holland *Rubicon* (Caesar coin) |
| Conceptual / typographic | Strong typographic treatment of the subject's name + period-evocative palette and ornament, often with a smaller portrait inset or no portrait at all | "The subject is a household name. The book is a major event. Modern editorial sensibility on a classic subject." | Chernow *Grant* (typographic with small portrait); Beard *SPQR* (typographic); MacCulloch *Thomas Cromwell* (typographic with Holbein detail); Reiss *The Black Count* (typographic with sword) |

### Subcategory Variations

| Subcategory | Visual Approach | Palette | Distinctive Element |
|-------------|-----------------|---------|---------------------|
| ancient-classical | Sculpture / coin / fresco / mosaic / inscription detail; often a single iconic surviving image of the subject (or, for figures with no surviving image, a representative period artefact); marble / bronze tonality | Marble white, weathered bronze, Pompeii red, lapis blue, parchment / papyrus tones; gold leaf for typography | Period material rendered with archaeological fidelity; the reader trusts that the artefact shown actually exists in a named collection |
| medieval-renaissance | Period portrait (illuminated manuscript miniature, panel painting, fresco) full-bleed or cropped; period heraldry / coat of arms / royal seal as ornament; gold leaf and rich pigment | Manuscript-illumination palette: gold, ultramarine, vermilion, viridian, crimson; aged-vellum cream | The portrait reads as period (not modern reproduction); typography matches Renaissance / Gothic aesthetic without descending into faux-medieval pastiche |
| early-modern-enlightenment | Oil portrait (often three-quarter pose, period costume); period document inset; period map detail | Oil-painting tonality: deep reds, mahogany browns, slate greys, ivory; Wedgwood-blue and Pompeii-red as accent | The Enlightenment aesthetic — typographic order, classical proportion, restrained ornament — translated into cover layout |
| nineteenth-century | Photograph (where extant) or oil portrait; period document / newspaper clipping / political cartoon; period architecture or industrial imagery as background | Sepia / gold-leaf / black; Victorian crimsons and forest greens; daguerreotype tonality for early photographic subjects | Photographic plates rendered with tintype / daguerreotype texture; period typography (slab serifs, Victorian ornament) styled rather than slavishly imitated |
| twentieth-century-modern | Photograph (almost always — most subjects in this period were extensively photographed); often a single iconic image; sometimes a less-familiar private photograph as alternative; political / wartime / movement-defining context | Mid-century editorial palette: black, white, period-photograph sepia, mid-century reds and blues; bold sans-serif typography possible for politically-significant subjects | The photograph is a known image (Mandela in prison; Curie in laboratory; Kahlo self-portrait) or a deliberately less-known image (the alternative angle, the quiet moment); cover signals modern editorial sensibility |
| contemporary-historical | Photograph (extensive availability); often candid or off-stage rather than official portrait; cover may signal "considered distance" — neither hagiographic nor dismissive | Contemporary editorial palette; muted rather than triumphant; more black-and-white than colour for biographies signalling historiographic distance from the figure's still-active reception | The photograph gestures at the figure's complexity; cover treatment avoids both the worshipful and the takedown registers |
| group-collective-historical | Multiple portraits / silhouettes / period grouping; period document signalling the collective (the manifesto, the institutional record, the family genealogy, the workshop / academy / circle); composite or panel layout | Subcategory-appropriate to the period of the group | The collective itself signified — not just one face standing in for the group; for family / dynasty subjects, family chart / genealogy as visual element; period of the group dictates other variables |

### Typography Rules

- **Title typeface:** Classical serif (Garamond, Caslon, Bembo, Sabon, Trajan for ancient subjects); display weight; subject's name typically dominant when subject is the title (Chernow's *Hamilton*, McCullough's *John Adams*); period-evocative without descending into pastiche (no fake Gothic blackletter for medieval subjects unless the design is sophisticated enough to use it intentionally).
- **Subject's name:** Where the subject's name is the title or the dominant element, set in the largest type; period rank / honorific (King Henry VIII, Queen Mary, the Right Honourable William Pitt, Frederick Douglass) handled per the publisher's house style and the subject's own period-appropriate appellation.
- **Subtitle:** Mandatory for historical biography. Specifies what kind of life this is, what era, what argument. *"A Life"* is too generic; *"The Life of [X] in the Age of Y"*, *"[X] and the Making of Z"*, *"The Tragic Life of X"* — subtitles do real work signalling argument and period. Set in italic serif beneath title; smaller weight than title.
- **Author byline:** Standard placement; for biographers with established imprint (Chernow, Schiff, Beard, MacCulloch), name often given equal weight with subtitle as a draw-factor.
- **Spine treatment:** Subject name + author name + imprint; for dynastic / multi-volume biographies (Massie's Romanov volumes; Chernow's American Founders set), spine designed to align across volumes when shelved together.
- **Forbidden treatments:** Fake-distressed type unless the design is sophisticated enough to use it intentionally; tabloid red / yellow palette (signals popular-history paperback rather than trade biography); blood-spatter / sword graphics (signals historical thriller fiction); romantic / soft-focus imagery (signals historical romance); single-word handwritten title (signals literary memoir); subject's name in quotation marks (signals iconoclast / takedown — sometimes appropriate, often not).

### Series and Imprint Context

Historical biography is often published within prestige imprints
(Knopf / Doubleday / Vintage in the US; Penguin / Allen Lane /
Yale UP / OUP in the UK) whose visual identity sets baseline
expectations. Self-published or small-press historical biography
should observe trade-imprint conventions to avoid signalling
amateur work — period-portrait full-bleed with classical serif
title is the safest default.

### Multi-Volume and Companion-Volume Design

For multi-volume biographies (Massie on the Romanovs; Chernow's
American Founders sequence; Caro on LBJ), each volume's cover
shares family-resemblance design (palette, typography, portrait-
treatment) while marking its distinct period / phase of the
subject's life. Companion volumes (a primary biography plus an
edition of letters; a biography plus a documentary reader) share
visual identity with the primary volume.

## KDP Category Mapping

Historical biography sits at the cross-listing point of two
KDP shelf hierarchies: Biographies & Memoirs > Historical (the
biography shelf, where readers come for *the figure*) and
History > [Period or Region] (the history shelf, where readers
come for *the era*). Trade historical biographies are routinely
listed in both, and the dual placement is the genre's commercial
signature. Choose the primary placement by which shelf the work
positions itself most strongly toward.

### Primary Categories by Subcategory

| Subcategory | Primary KDP Path 1 | Primary KDP Path 2 |
|-------------|-------------------|-------------------|
| ancient-classical | Biographies & Memoirs > Historical > Ancient | History > Ancient Civilizations > [Greece / Rome / Egypt / Mesopotamia / China / India / Persia] |
| medieval-renaissance | Biographies & Memoirs > Historical > Medieval / Renaissance | History > Europe > [Country] > Medieval / Renaissance OR History > [Region] > Medieval |
| early-modern-enlightenment | Biographies & Memoirs > Historical > Early Modern / 18th Century | History > [Region] > 17th Century / 18th Century OR History > Revolutionary (for revolution-era figures) |
| nineteenth-century | Biographies & Memoirs > Historical > 19th Century | History > [Region] > 19th Century OR History > Americas > United States > Civil War (for Civil War figures) |
| twentieth-century-modern | Biographies & Memoirs > Historical > 20th Century | History > [Region] > 20th Century OR History > Military > World War I / II OR History > Africa / Asia > 20th Century |
| contemporary-historical | Biographies & Memoirs > [topical category — Political, Cultural, Scientific, etc.] > Specific Subject | History > [Region] > Late 20th Century OR Politics & Social Sciences > Political Science > [relevant subfield] |
| group-collective-historical | Biographies & Memoirs > Historical > [Period] | History > [Region] > [Period] > Social History |

### Secondary Categories (cross-listing)

| Theme | KDP Path | Use When |
|-------|----------|----------|
| Royalty / dynasty | History > World > Royalty | Subject is monarch / consort / claimant / royal-family figure |
| Military / war | History > Military > [War / Period] | Subject is military commander / soldier / war-affected figure where military context structurally central |
| Political / statecraft | Biographies & Memoirs > Leaders & Notable People > Political | Subject is statesperson / political leader / political activist |
| Religious | Biographies & Memoirs > Leaders & Notable People > Religious | Subject is religious leader / theologian / mystic / reformer / saint |
| Scientific / intellectual | Biographies & Memoirs > Professionals & Academics > Scientists OR Philosophers | Subject is scientist / philosopher / mathematician / scholar |
| Artistic / literary | Biographies & Memoirs > Arts & Literature > [Specific Field] | Subject is writer / artist / composer / architect |
| Activist / reformer | Biographies & Memoirs > Leaders & Notable People > Social Activists | Subject is abolitionist / suffragist / labour leader / civil-rights leader |
| Exploration | Biographies & Memoirs > Travelers & Explorers | Subject is explorer / navigator / travel-writer / colonial-era explorer |
| Women's history | Biographies & Memoirs > Specific Groups > Women OR History > Women in History | Subject is female and women's-history scholarship is structural to the work |
| African-American / African / diaspora history | Biographies & Memoirs > Specific Groups > African-American & Black OR History > Africa / African-American | Subject is part of African / African-American / Black-Atlantic history; diaspora-history scholarship engaged |
| Indigenous / First Nations history | Biographies & Memoirs > Specific Groups > Indigenous Peoples OR History > Americas > Native American | Subject is indigenous / First Nations / Aboriginal / Native American figure; indigenous-history scholarship engaged |
| LGBTQ history | Biographies & Memoirs > Specific Groups > LGBTQ+ OR History > LGBTQ | Subject is LGBTQ historical figure; queer-history scholarship engaged |
| Holocaust / genocide history | History > Holocaust OR History > [Genocide-specific subcategory] | Holocaust / genocide-affected subject; relevant historiographic field engaged |
| Colonial / postcolonial | History > [Region] > Colonialism OR Politics & Social Sciences > Politics & Government > Specific Topics > Colonialism & Post-Colonialism | Colonial-era subject or postcolonial historiographic engagement |
| Economic / business history | Business & Money > Biography & History OR History > [Region] > Economic History | Subject is economic / business / industrial figure; economic-history scholarship engaged |
| Family / dynasty | Biographies & Memoirs > Specific Groups > Family Memoirs (where the family itself is subject) | Group-collective-historical biography of a family / dynasty |
| Reception-history / cultural memory | History > Historiography OR Politics & Social Sciences > Cultural | Biographies foregrounding the figure's posthumous mythology / cultural-memory dimension |

### Keyword Recommendations

KDP allows seven keywords per book. For historical biography,
prioritise keywords that signal subject + period + form +
distinctive angle. Avoid generic single-word keywords ("history",
"biography") that compete against the entire shelf. Combine
named-subject keywords (where the subject is well-known) with
period / theme / approach keywords.

| Keyword Type | Examples |
|--------------|----------|
| Subject name + period | "tudor england biography", "ancient rome biography", "civil war biography", "weimar germany biography" |
| Distinctive form | "narrative history", "popular history", "scholarly biography", "definitive biography", "new biography" |
| Theme / lens | "women in history", "forgotten figure", "untold history", "historical revisionism", "hidden history" |
| Audience signal | "history buff", "history reader", "popular history readers", "general reader history" |
| Period descriptor | "tudor period", "georgian england", "regency britain", "antebellum america", "gilded age", "fin de siècle", "interwar period" |
| Geographic descriptor | "british history", "french history", "american history", "african history", "asian history", "latin american history" |
| Genre signal | "biography history", "history book", "historical biography", "scholarly history", "trade history" |
| Method / approach | "primary source biography", "archive-based history", "feminist history", "global history", "social history", "microhistory", "prosopography" |
| Series / volume | "first volume", "definitive life", "complete biography" — where applicable |

Avoid: keywords that signal historical fiction ("historical
fiction", "historical novel", "historical romance"); keywords
that signal academic monograph ("dissertation", "doctoral
thesis", "academic study") unless the work is positioned for that
shelf; keywords that signal sensational popular history ("shocking
history", "secret history of...", "the real truth") for trade
biography that wants to be taken seriously by review pages.

### Series and Backlist Considerations

For biographers building a historical-biography backlist within
the same period (Chernow's American Founders; Massie's Romanovs;
MacCulloch's Reformation figures; Schiff's early-modern subjects),
keyword and category strategy across the series should reinforce
the imprint — readers who buy one volume should find the others
through the algorithm.

### Front-Matter Marketing Beats

Historical biography's marketing copy works through three signals
the cover and metadata must reinforce: (1) **subject** — who this
is and why they matter; (2) **scholarship** — what new sources /
new argument / new angle this biography brings to a familiar
subject (or what makes an unfamiliar subject worth a reader's
attention); (3) **prose** — that this is a readable book by an
established or distinctive voice, not an academic monograph. The
KDP description, the Look Inside opening, and the back-cover blurb
must hit all three within the first 200 words.
