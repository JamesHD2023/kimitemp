---
name: psychology-popular
description: "Category plugin for popular psychology non-fiction. behavioural, positive, developmental, social, and clinical psychology"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Popular Psychology. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | psychology-popular |
| Display Name | Popular Psychology |
| Parent Group | Self-Help & Psychology |
| Typical Word Count | 65,000–85,000 |
| Default Structure | Study-driven thematic chapters with narrative case material |
| Citation Style | Endnotes with full bibliography; in-text researcher attribution |
| Audience Baseline | Curious general reader interested in understanding human behaviour; no psychology background required |
| Comparable Titles | Daniel Kahneman, Robert Sapolsky, Angela Duckworth, Adam Grant, Oliver Sacks |

## Subcategory Options

When the user selects Popular Psychology, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| behavioural | Behavioural Psychology | Decision-making, biases, heuristics, nudges, irrational behaviour, habits | Study-as-story, bias catalogue with narrative, experiment re-enactment |
| positive | Positive Psychology | Wellbeing, flourishing, strengths, flow, gratitude, resilience | Research-to-life application, assessment-based chapters, evidence for what works |
| developmental | Developmental Psychology | Childhood, adolescence, ageing, attachment, identity formation, lifespan | Age-stage structure, longitudinal study narratives, intergenerational stories |
| social | Social Psychology | Conformity, persuasion, group dynamics, prejudice, identity, culture | Classic experiment narratives, real-world application, system-level analysis |
| clinical-accessible | Clinical (Accessible) | Anxiety, depression, trauma, personality, neurodiversity, therapy approaches | Case-study centred, condition-demystification, treatment landscape overview |

**Default:** If the user does not specify, use `behavioural` conventions as baseline.

## Structural Architect Instructions

### Core Technique: Study-Driven Exposition

Popular psychology books are built on **research studies told as stories**. The study
is not just evidence. it is narrative. The Architect must select studies that are
both scientifically robust and narratively compelling, then design chapters that let
the research tell a story about human nature.

### Chapter Architecture Patterns

1. **The Phenomenon**. Open with a recognisable human behaviour, a puzzling
   observation, or a provocative question. The reader should think: "I've always
   wondered about that" or "I do that. why?"
2. **The Study**. Introduce the key experiment or research programme that illuminates
   the phenomenon. Describe the setup vividly. the reader should be able to picture
   the lab, the participants, the moment of revelation.
3. **The Finding**. Present the results clearly. What did the researchers discover?
   What was surprising? What confirmed or overturned assumptions?
4. **The Mechanism**. Explain why. What psychological process, brain function, or
   evolutionary pressure produces this behaviour? This is the explanatory core.
5. **The Implication**. What does this mean for the reader's life, for society, for
   how we design systems? Popular psychology must connect research to lived experience.
6. **The Qualification**. Where are the limits? Has the study been replicated?
   Does it apply across cultures? What do critics say? Honest qualification builds
   trust.

### Evidence Deployment

- **Landmark studies:** The chapter-defining experiments. Described in narrative detail
  with researcher names, institutional context, and methodology.
- **Supporting studies:** Additional evidence that strengthens or nuances the central
  finding. Referenced more briefly.
- **Meta-analyses:** For establishing the weight of evidence behind a claim. Signal
  this clearly: "Across 47 studies involving over 12,000 participants..."
- **Case material:** Clinical cases, real-world examples, historical events that
  illustrate psychological principles in action.

### Brief Template Additions

For each chapter brief, the Architect MUST include:

- **Central Phenomenon:** The human behaviour or psychological process being explored.
- **Anchor Study:** The primary research study that drives the chapter narrative.
- **Supporting Studies:** 2–3 additional studies that strengthen or nuance the finding.
- **Mechanism Explanation:** The psychological or neurological process to explain.
- **Real-World Applications:** How this research applies to everyday life, policy,
  or system design.
- **Replication Status:** Whether the anchor study has been replicated, and any
  notable replication failures in the chapter's domain.
- **Counter-Perspectives:** Competing explanations or critiques to address.

## Content Writer Craft Rules

### Voice & Tone

- **Intellectually curious, not academic.** Write as someone fascinated by human
  behaviour, not as someone writing a literature review.
- **Respectful of participants.** Research participants are people, not data points.
  When describing studies, treat subjects with dignity.
- **Clear about complexity.** Psychology is messy. Behaviour has multiple causes.
  Do not oversimplify for narrative convenience.
- **Measured confidence.** State findings with appropriate certainty. "The evidence
  strongly suggests" is different from "Science has proven."

### Study Narration

- **Set the scene.** Describe the lab, the year, the researcher, the context. "In
  1971, in the basement of Stanford's psychology department..."
- **Build tension.** Studies have narratives. hypotheses, methods, surprises. Let
  the reader experience the unfolding.
- **Give the numbers, then translate.** "78% of participants conformed at least once"
 . then explain what this means in human terms.
- **Name the researchers.** Popular psychology is a genre of intellectual biography
  as much as science communication. The reader should meet the minds behind the
  findings.

### Explaining Mechanisms

- Use the brain and body concretely. "The amygdala fires before the prefrontal cortex
  can intervene" is clearer than "emotional processing precedes rational processing."
- Evolutionary explanations are useful but must be flagged as hypotheses, not proven
  mechanisms. "One evolutionary account suggests..."
- Distinguish between correlation and causation explicitly. Every time.

### Handling Controversial Studies

- Some famous psychology studies are problematic (Stanford Prison Experiment, ego
  depletion, power posing). If these are discussed:
  - Present the original finding AND the subsequent criticism.
  - Note replication status clearly.
  - Do not build a chapter's argument on a study that has failed replication.
  - Use as historical narrative if needed, but clearly label the evidential status.

### Cultural Sensitivity

- Much of psychology research has been conducted on WEIRD (Western, Educated,
  Industrialised, Rich, Democratic) populations. Acknowledge this limitation.
- When discussing universal claims, note whether cross-cultural evidence exists.
- Do not present Western psychological norms as universal human nature.

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the study or case that changes how you think. A specific
  experiment, a specific finding, a moment where the data defied expectation.
- **Sentence calibration:** Medium sentences averaging 15–22 words. Narrative delivery
  of research. the prose reads like storytelling, but the content is science.
- **Story-then-science rhythm:** Every major finding follows the same beat: set the
  scene, describe the experiment, reveal the result, explain the mechanism, connect
  to life. This sequence is the genre's backbone.
- **Rhythm pattern:** Longer narrative sentences (scene-setting, study description) give
  way to shorter declarative ones (the finding, the implication). "Seventy-eight per
  cent conformed. Every time." The short sentence delivers the punch.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In popular psychology,
  tension is intellectual surprise. the gap between what the reader assumed about
  human behaviour and what the evidence shows.
- **Tension drivers:** The puzzle of human behaviour. The counterintuitive result. The
  moment the reader realises they, too, would have conformed, complied, or misjudged.
- **Researcher as character:** Name the researcher, place them in a setting, give them
  a motivation. "In 1971, in the basement of Stanford's psychology department" is not
  just context. it is scene.
- **Numbers then translation:** Present the data, then immediately translate it into
  human terms. The number is the evidence; the translation is the understanding.
- **Qualification rhythm:** After building conviction, introduce the caveat or competing
  interpretation. The qualification should feel like intellectual honesty, not retreat.
  Place it after the reader has absorbed the finding.
- **Paragraph construction:** Lead each paragraph with the most interesting sentence,
  not the most logical one. The reader follows curiosity, not outlines.
- **Read-aloud test:** The prose should sound like a brilliant dinner companion
  explaining fascinating research. If it sounds like a journal abstract or a
  lecture, revise.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Phenomenon clarity | Human behaviour or psychological process clearly identified and described |
| 2 | Study narration | Anchor study narrated with scene, method, finding, and significance |
| 3 | Evidence robustness | Anchor study has been replicated OR replication status is noted |
| 4 | Mechanism explained | Psychological or neurological process clearly described |
| 5 | Real-world connection | Research connected to everyday life or societal implication |
| 6 | Qualification present | Limits, counter-perspectives, and cultural caveats acknowledged |
| 7 | Researcher attribution | Named researchers and institutions for all major findings |
| 8 | Correlation ≠ causation | No causal claims made from correlational data without flagging |
| 9 | WEIRD awareness | Cross-cultural applicability noted where relevant |
| 10 | Voice consistency | Intellectually curious, measured, respectful tone throughout |

## Source Requirements

### Mandatory Source Types

- **Peer-reviewed psychology journals:** APA journals, Psychological Science, Nature
  Human Behaviour, Journal of Personality and Social Psychology, etc. This is the
  primary evidence base.
- **Meta-analyses and systematic reviews:** For major claims, prefer meta-analytic
  evidence over single studies.
- **Replication studies:** Check Many Labs, Reproducibility Project, and other
  replication efforts for any study featured prominently.
- **Researcher biographies/interviews:** For narrative material about the scientists
  themselves.

### Replication Crisis Protocol

Popular psychology must engage honestly with the replication crisis:

- **Before featuring a study prominently, check its replication status.**
- **Studies that have failed replication** may be discussed as historical narrative
  but must NOT be presented as reliable evidence.
- **Studies with mixed replication** should note the debate: "The original finding
  has been partially supported by subsequent research, though the effect may be
  smaller than initially reported."
- **Well-replicated studies** can be presented with confidence.
- **When in doubt, use meta-analyses** rather than single studies.

### Source Freshness

- **Classic studies** (Milgram, Asch, Bandura): Valid as historical narrative and
  foundational concepts. Note any reinterpretation or criticism.
- **Recent advances:** Claims about "new research" must cite work from the last 5 years.
- **Neuroscience claims:** Brain imaging research is rapidly evolving. Use the most
  recent interpretations, not early fMRI-era oversimplifications.

## Category-Specific Guardrails

### MANDATORY. Replication Crisis Awareness

- Do not build arguments on unreplicated single studies.
- If a study is famous but contested (ego depletion, power posing, Stanford Prison
  Experiment, growth mindset), present both the original claim and the current
  evidential status.
- The phrase "studies show" requires actual plural, replicated studies.
- Prefer effect sizes and meta-analyses over dramatic single findings.

### MANDATORY. Distinguish Established vs Emerging Research

- **Established:** Decades of replication, cross-cultural evidence, broad consensus.
  Present with confidence: "Research consistently demonstrates..."
- **Emerging:** Promising but early-stage. Present with appropriate caveats: "Recent
  research suggests, though more work is needed..."
- **Contested:** Active scientific disagreement. Present the debate: "Researchers
  are divided on this question..."
- **Retracted/debunked:** Do not present as evidence. If discussed, clearly label
  as discredited.

### MANDATORY. No Clinical Advice

- Popular psychology may explain clinical concepts (what depression is, how CBT works,
  what PTSD involves) for general understanding.
- Popular psychology must NEVER provide treatment protocols, diagnostic checklists
  intended for self-diagnosis, or medication guidance.
- Include a clear note: readers experiencing psychological distress should seek
  professional support.
- The line: popular psychology informs and illuminates; it does not treat.

### Additional Guardrails

- Do not reduce complex behaviour to a single cause. Human psychology is
  multi-determined.
- Avoid "brain region X does Y" oversimplification. Brain regions participate in
  networks; no single region "does" anything in isolation.
- Do not use psychiatric diagnoses as personality descriptions. "She's so OCD" or
  "that's narcissistic" trivialises clinical conditions.
- Be careful with evolutionary psychology claims. They are hypotheses, not
  established mechanisms. Label them accordingly.
- Do not generalise from clinical populations to the general public, or vice versa,
  without noting the difference.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Sophisticated, cerebral. Navy, teal, deep purple, white, with
  selective accent colours. Avoid neon or overly casual palettes.
- **Typography:** Strong serif or modern sans-serif for title. The title is the hook . 
  it should be clever, intriguing, readable. Subtitle in contrasting weight.
- **Imagery:** Abstract representations of the mind. optical illusions, geometric
  patterns, brain silhouettes, split images. Avoid literal brain imagery unless
  extremely well executed.
- **Mood:** Intelligent, intriguing, slightly provocative. The cover should ask a
  question the reader wants answered.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Behavioural | Optical illusions, decision trees, split-choice imagery |
| Positive | Warmer palette, upward motion, light-oriented imagery |
| Developmental | Life-stage imagery, growth metaphors, timeline elements |
| Social | Group dynamics imagery, crowd/individual contrast, connection motifs |
| Clinical (Accessible) | Sensitive, non-stigmatising. Abstract emotional imagery. No clinical aesthetics. |

### Typography Rules

- Title: 45–65% of cover area. Clever titles are a genre convention. the title
  should intrigue.
- Subtitle: The explanatory partner. "The Hidden Forces That Shape Our Decisions"
  format.
- Author name: Large if the author is an established researcher or public intellectual.
  Moderate for debut.
- Consider: "Author of [previous bestseller]" line if applicable.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Behavioural | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Psychology & Counselling > Applied Psychology |
| Positive | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Psychology & Counselling > Positive Psychology |
| Developmental | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Psychology & Counselling > Developmental Psychology |
| Social | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Psychology & Counselling > Social Psychology & Interactions |
| Clinical (Accessible) | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Psychology & Counselling > Psychopathology |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Popular Social Science | Kindle Store > Kindle eBooks > Nonfiction > Social Sciences > Popular Social Science |
| Cognitive Psychology | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Psychology & Counselling > Cognitive Psychology |
| Neuropsychology | Kindle Store > Kindle eBooks > Health, Fitness & Dieting > Psychology & Counselling > Neuropsychology |

### Keyword Recommendations

- Include the specific psychological domain (behavioural economics, social psychology, etc.)
- Include "psychology" and "human behaviour"
- Include the core question or phenomenon the book explores
- Include comparable author names for discoverability
- Include "popular psychology" or "psychology for general readers"
- Consider "behavioural science" as a crossover keyword
