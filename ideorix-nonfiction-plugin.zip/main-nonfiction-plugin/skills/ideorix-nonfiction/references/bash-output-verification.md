---
name: bash-output-verification
description: "Bash-Output Verification HARD GATE. When engine specs invoke `find` / `grep` / `awk` / Glob / Bash one-liners and route decisions on the output, exit code 0 with empty result is the danger pattern: 'no error' reads as 'no failures' when it can also mean 'search broken' (wrong path, wrong pattern, file permissions, environment difference). This spec defines the per-invocation output-presence + result-shape verification, the HARD GATE on suspicious empties, and the resolution protocol. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.8"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Bash-Output Verification Protocol (MANDATORY for any flow that routes decisions on Bash command output)

## Purpose

Ensure that Bash command output corresponds to actual search /
extraction / count results before the engine treats it as
authoritative. Several Bash primitives have failure modes
where exit code 0 + empty output is indistinguishable from
"genuinely no results":

**`find` failure modes:**
- Path doesn't exist → silent zero results (exit 0 with
  warning to stderr in some shells, but stdout empty)
- Path exists but search pattern wrong → silent zero results
- Permission denied on subdirs → partial results, no error
- Wrong base directory (running from agent CWD vs project) →
  silent zero results

**`grep` failure modes:**
- No matches in input → exit 1 (well-known)
- Empty input file → exit 1 looks identical to "no matches"
- Pipe upstream failed → exit 1 still produced
- Pattern accidentally matched everything (regex error) →
  exit 0 with all lines

**`awk` / `sed` failure modes:**
- Filter excludes everything → empty stdout, exit 0
- Field separator mismatch → wrong column extracted, no error
- Locale-dependent regex → matches differ across environments

**`glob` (shell pathname expansion) failure modes:**
- No matches with `nullglob` off → literal pattern returned
- No matches with `nullglob` on → empty list
- Wildcard scope wider than intended → unexpected matches

**Composed pipelines:**
- Any failure mid-pipeline produces zero output without
  `pipefail` set
- `command-that-finds-N | wc -l` returns 0 if either the
  command failed silently or there genuinely are zero items

If the engine treats a Bash zero-result as "search succeeded
with nothing found", and the actual cause was "search broken",
downstream decisions cascade against incorrect signal:

- "Forbidden words audit found 0 violations" → ship a chapter
  with violations because `grep` was pointed at the wrong file
- "Entity canon contains 0 entries" → entity-canon-verify
  passes everything because the canon file was empty due to
  a path typo
- "No prior chapters found" → resume flow treats project as
  new and re-processes completed chapters

## Failure mode shape

The pattern is identical to the broader silent-failure shape:
exit code (success metadata) doesn't verify actual effect
(real search ran with real input). Bash-output verification
makes the engine require the actual effect, not just the exit
code.

## When the protocol applies

Every spec that invokes a Bash command and routes a decision
on the output MUST apply this protocol. Specifically (non-
exhaustive):

| Operation | Where used |
|-----------|------------|
| `find` for chapter file enumeration | Continue Writing/Researching, Manuscript Clinic intake, batch operations |
| `grep` for forbidden-word / pattern detection | forbidden-words-scan.sh, pattern-counter.sh, manuscript-audit.sh, formatting-check.sh |
| `awk` / `sed` for content extraction | word-count-check.sh, formatting-check.sh, all chapter audit scripts |
| `wc -l` / `wc -w` on piped output | every audit script that counts |
| `ls` for file existence | File Location Discipline checks, project folder bootstrap |
| `stat` for file metadata | File-Write Hygiene byte-count verification, File-Freshness checks |
| Glob pathname expansion | export-and-publish.md typography-sweep loop, batch-edit-gate.sh |
| Composed pipelines | Most audit scripts use multi-stage pipelines |

## The protocol — three checks per invocation

### Check 1: Expected-shape verification

Before invoking the Bash command, the calling spec MUST declare
the **expected output shape**:

- **Non-empty list** (e.g. `find` for chapter files when at
  least one chapter is expected to exist)
- **Specific count** (e.g. `wc -l` returning a known number of
  bibliography entries)
- **Specific format** (e.g. `awk` returning N tab-separated
  columns)
- **Possibly-empty result** (e.g. `grep` for forbidden words
  where zero hits is the success case)

The expected shape is the verification target. After the
command runs, the actual output MUST match.

### Check 2: Distinguish "search ran with zero results" from "search broken"

When the expected shape is non-empty AND the actual output is
empty, the calling spec MUST:

1. **Verify the search input exists.** If `find {path}` returned
   empty, run `ls {path}` to confirm the path exists. If `grep
   pattern {file}` returned empty, run `ls {file}` to confirm
   the file exists and `wc -l {file}` to confirm it has content.
2. **Verify the search pattern is correct.** Re-run the command
   with a deliberately-broad pattern (e.g. `find {path} -type f
   | head` for find; `grep . {file} | head` for grep) to confirm
   the search infrastructure works.
3. **Distinguish the two cases:**
   - Search input missing → FAILED_BASH (path/file/permission
     issue)
   - Search input present but pattern returned zero → genuine
     empty result (proceed)

For a possibly-empty result (e.g. forbidden-word audit), the
distinguish step is still required when the empty result is
*surprising* — e.g. a chapter file that's been heavily edited
returns zero forbidden-word hits.

### Check 3: HARD GATE — halt on FAILED_BASH

If Check 2 identifies the empty result as a search-broken
failure, the protocol BLOCKS the flow. The engine MUST NOT
treat the bash output as authoritative for downstream
decisions. Surface to the user:

```
HALT — A bash command returned empty results that I expected to be non-empty.
This is most often a path / pattern / permission issue, not a real "zero
results" finding.

Command that returned empty: {command}
Expected shape: {expected_shape}
Actual: empty stdout, exit code {N}

Diagnostic checks:
  - Search input exists: {YES | NO}  (path: {path})
  - Search input has content: {YES | NO}  ({line_count} lines)
  - Broad pattern returns results: {YES | NO}

Likely cause: {diagnosis}

I will NOT use this output as the basis for {downstream_decision}.

Three options:

  A. Fix the underlying issue (path typo, permission, environment
     difference) and re-run the command.
  B. Confirm that an empty result is the correct answer for this
     case (e.g. a brand-new project genuinely has zero chapters).
  C. Skip this check and route the decision a different way.
```

## Required wrapper for engine audit scripts

Engine audit scripts (`*.sh` in `scripts/`) MUST use the
wrapper pattern below for any decision-routing Bash invocation
inside the script:

```bash
# Pattern: search-and-verify
RESULTS=$(find "$CHAPTER_DIR" -name 'ch*.md' 2>/dev/null)
if [ -z "$RESULTS" ]; then
    # Empty — distinguish search-broken from genuine empty
    if [ ! -d "$CHAPTER_DIR" ]; then
        echo "ERROR: chapter directory not found: $CHAPTER_DIR" >&2
        exit 2
    fi
    if [ -z "$(ls -A "$CHAPTER_DIR" 2>/dev/null)" ]; then
        # Directory exists and is empty — genuine "no chapters yet"
        echo "INFO: $CHAPTER_DIR is empty (no chapters yet)" >&2
    else
        # Directory has files but find pattern matched none —
        # likely pattern issue
        echo "WARN: $CHAPTER_DIR has files but no ch*.md matches" >&2
    fi
fi
```

The pattern: never treat `find` / `grep` / `awk` empty stdout
as "the answer" for a downstream decision without first
verifying the search input exists and contains content.

## Pipefail discipline

Every engine audit script MUST set `set -euo pipefail` at the
top. Without `pipefail`, a multi-stage pipeline can have an
upstream failure produce empty output that the downstream
stage then reports as "no results found":

```bash
# WRONG — set -e alone catches direct command failure but not pipeline failures
set -eu
COUNT=$(grep "the way" "$CHAPTER" | wc -l)
# If grep fails (file missing), wc -l returns 0; COUNT is "0";
# script proceeds as if zero matches found.

# CORRECT — pipefail surfaces upstream pipeline failure
set -euo pipefail
COUNT=$(grep "the way" "$CHAPTER" | wc -l)
# If grep fails, the entire pipeline exits non-zero, set -e halts the script.
```

Existing engine scripts already set `set -euo pipefail` at
top. Spec-lint Check 9 (shellcheck -S warning) catches missing
pipefail in new scripts — SC2034 / SC3033 family rules.

## Glob with nullglob discipline

Bash glob expansion has a default behaviour where unmatched
patterns return the literal pattern string:

```bash
# DEFAULT (UNSAFE): if no .docx files exist, $files contains
# the literal string "*.docx"
files=(*.docx)

# SAFE: nullglob makes unmatched patterns produce an empty array
shopt -s nullglob
files=(*.docx)
# If no matches, $files is an empty array — the calling code
# can test ${#files[@]} for genuine emptiness.
```

Engine scripts that use Glob MUST `shopt -s nullglob` (or use
`find` instead). The literal-pattern fallback has caused
silent processing of non-existent files reported as success.

## Anti-patterns this protocol prevents

- **Path-typo silent zero** — `find ./cahpters/` (typo) returns
  empty; engine treats as "no chapters" instead of error.
- **Permission-denied silent zero** — `find` skips dirs without
  read permission; partial results reported as complete.
- **Pipefail-disabled silent zero** — upstream pipeline stage
  fails; downstream `wc -l` reports 0; "audit passed".
- **Glob literal-pattern absorption** — `for f in *.docx` with
  no matches loops once over the literal string `*.docx`.
- **Pattern-bug silent everything** — accidentally-broad regex
  matches all lines; `grep` exit 0 with full stdout treated as
  "found expected match" when actually "matched everything".
- **Empty-input misread** — `grep` on empty file exits 1
  identical to "no matches in non-empty file"; downstream
  cannot distinguish.

## Cross-cutting binding

This protocol is the **eighth cross-cutting binding**. The
canonical catalog of all bindings and audited primitives is
`silent-failure-audit.md`. This binding addresses primitives
#12 (Bash exit codes) and #13 (Glob / Grep result lists) in
that catalog.

Parallel bindings —

1. Architect Mode binding
2. Verification Discipline binding
3. File-Write Hygiene binding
4. Edit-Tool Typographic Fidelity binding
5. Read-Verification binding
6. Web-Content Verification binding
7. Subagent Output Verification binding
8. **Bash-Output Verification binding (this spec)**

## Silent-Failure Audit

This binding spec is exempt from the Silent-Failure Audit
section requirement (Check 10) because it IS audit
infrastructure rather than a feature spec. The exemption is
granted in the engine's spec-lint repo CI discipline `check_silent_failure_audit`
exempt pattern.
