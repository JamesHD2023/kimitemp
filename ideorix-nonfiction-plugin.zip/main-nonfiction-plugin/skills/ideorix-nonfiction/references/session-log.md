---
name: session-log
description: Append-only cross-session journal of working sessions. Each entry records what was done, what was decided, what's open, and any carry-forward flags. Distinct from pipeline-checkpoint (per-chapter state); session-log is a session-level narrative. The orchestrator writes an entry at session close or end-of-milestone; future sessions read recent entries at start to refresh context without re-deriving from per-chapter audits. Engine-agnostic — mirrored across fiction and nonfiction engines.
version: 2.7.74
---

<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Session Log Register

> **Powered by Ideorix** — The Manuscript Engine
> *© James Harvey Media. All rights reserved.*

## Purpose

`engine-data/pipeline-checkpoint.md` records the per-chapter state —
which chapters are approved, which audits passed, voice metrics per
chapter, batch editor verdicts. It is a structured ledger of chapter
outcomes.

It does NOT record:
- What was decided in chat between the user and orchestrator
- What's open for the next session
- What constraints the user has set as carry-forward flags
- The trajectory of decisions across sessions

The session log fills that gap. Each session produces a dated entry
covering four buckets: Done, Decided, Open, Carry-forward. On
resumption, the next session reads the most recent entries at start
and resumes with full context, without having to re-derive the
project's state from per-chapter audit results.

## When to write an entry

Three triggers (any one is sufficient):

1. **End-of-session signal from user.** The user says "stopping for
   now," "see you tomorrow," "let's pause here," "let's call it a
   day," "ttyl," or any other obvious session-close signal. Write the
   entry before acknowledging the close.

2. **End-of-milestone.** After a meaningful milestone — Batch Editor
   PASS verdict, Phase transition, chapter-cluster completion,
   research-bible §N completion, voice-trend recalibration — append
   an entry even if the session is continuing.

3. **Start-of-session safety net.** If a new session begins and the
   most recent session-log entry is older than the most recent
   chapter approval in pipeline-checkpoint, the orchestrator infers
   that the prior session ended without an explicit close. The
   orchestrator appends a "best-effort" recap entry for the prior
   session based on what changed in pipeline-checkpoint, then
   proceeds with the new session.

## Format

`engine-data/session-log.md` (append-only):

```markdown
# Session Log — {Project Title}

*Append-only journal of working sessions. New entries are appended;
existing entries are never edited or removed. Each entry covers Done,
Decided, Open, and Carry-forward. On session start, the orchestrator
reads the most recent 3–5 entries to refresh context.*

## {ISO date} — Session {N}

**Done:**
- Drafted Chs 9-10. Both approved (V-Score 91.40, 91.80).
- Batch Editor 2 ran (PASS WITH CARRYFORWARD FLAGS).
- Remediated "I think" ration breaches in Chs 9 and 10.

**Decided:**
- "I think" ration tightened to ≤2 per chapter (strict) for Ch 11+
- Voice diversification for Ch 11+ — alternatives to "I find", "I should say", "what strikes me"
- FP target band for Ch 11: 0.25–0.27 to flatten voice-trend slope
- "quietly" remains EXHAUSTED at 4/4 vol-wide; zero use permitted

**Open:**
- No outstanding decisions; Ch 11 brief ready when user signals continuation

**Carry-forward flags for Ch 11+:**
- "I think" ≤2 per chapter — strict enforcement
- "I find this" ≤1 per chapter
- Voice-tic diversification (alternatives noted above)
- "quietly" EXHAUSTED at 4/4 — zero use permitted
- Voice-trend WARN — Ch 11 target FP 0.25–0.27
```

Each entry MUST have the four bucket headers in order (Done, Decided,
Open, Carry-forward) even if a bucket is empty. An empty bucket reads
as `(none)`. The fixed structure lets future sessions skim entries
quickly and lets a parser extract carry-forward flags
programmatically if needed.

Date format: ISO 8601 (`YYYY-MM-DD`). Session number is the project's
running session count.

## Read protocol on session start

At the start of every session (or at the start of a continuation-book
Phase 1 cross-check — see core-pipeline.md PHASE 1 CONTINUATION-BOOK
CROSS-CHECK), the orchestrator MUST read the most recent 3–5 entries
from `engine-data/session-log.md` and use them to:

1. **Identify active carry-forward flags.** The "Carry-forward flags"
   bucket of the most recent session lists constraints for the
   current session. These are non-negotiable until updated.

2. **Identify open items.** "Open" items may need user attention at
   session start. Surface any items the user can decide before chapter
   work resumes.

3. **Identify trajectory.** Recent "Decided" entries show the direction
   the project has taken. Do not re-litigate decisions that are
   already on the record.

The read is non-destructive — it informs the orchestrator's behaviour
for the session.

## Write protocol on session end / milestone

When a write trigger fires, the orchestrator:

1. Computes the entry contents from session state:
   - **Done:** concrete actions taken (chapters drafted, audits run,
     batch editor verdicts, remediations applied, research bibles
     extended). Cross-reference pipeline-checkpoint for the
     authoritative chapter-approval state.
   - **Decided:** rules, ratios, ratios-tightenings, voice-diversification
     protocols, FP target bands — anything the user agreed to in chat
     that constrains future work.
   - **Open:** questions still requiring user input; candidate
     decisions not yet made.
   - **Carry-forward flags:** the operational constraints that the
     next session's chapter work must respect.

2. Determines session number — read most recent entry's session
   number and increment, OR if no prior entry, start at 1.

3. Appends the entry using the same-FS-temp + post-write integrity
   pattern (see core-pipeline.md File Operation Policy). The
   post-engine-data-write-hook will run chapter-integrity-check.sh on
   the file automatically; if the bridge stutters during the write,
   the corruption is flagged immediately.

## Cap and archival

The session log grows unboundedly. For a typical book project (4–8
months active work, ~30–60 sessions) the file stays under 50 KB and
needs no maintenance. For very long projects (multi-year, series
work) the orchestrator (under user direction) can archive entries
older than 6 months to `engine-data/archives/session-log-archive-{date}.md`
and trim the active file to the most recent 6 months of entries.

**Archive discipline (2-pass safety):** before any archival
operation that removes entries from the active file, the
orchestrator must verify:

1. The archive file exists and contains the entries to be removed.
2. The archive file passes `chapter-integrity-check.sh` (no NULL
   bytes, valid UTF-8).
3. The active file's count after trim equals the count before trim
   minus the count of archived entries.

If any check fails, the trim is aborted and the active file is
preserved as-is. This is the operational application of the 2-pass
removal discipline (described below).

## 2-pass removal discipline (general principle)

When the engine ever supports auto-removal of items from
append-only registers (this spec's archival, future "long-absent
canon" audits, future "abandoned-Chekhov's-gun" detection, etc.),
the removal MUST satisfy the 2-pass rule:

> An item may be removed (or flagged for removal) only after it has
> been absent from inputs across TWO CONSECUTIVE detection runs.
> A single absence is insufficient evidence.

Rationale: a single absence may be coincidence (a Chekhov's gun the
author is deliberately holding for later; a character offscreen for
the current chapter cluster). Two consecutive absences is stronger
evidence that the item is genuinely abandoned. The discipline trades
detection latency for false-positive reduction in cases where
incorrect removal would be costly to recover from.

The 2-pass discipline is currently used by the session-log archival
flow (above). When new auto-removal features are added, this
principle MUST be followed and documented in the feature's spec.

## Distinguishing session-log from pipeline-checkpoint

| Concern | pipeline-checkpoint | session-log |
|---|---|---|
| Scope | Per-chapter state | Per-session state |
| Granularity | Chapter row + status columns | Free-form narrative + flags |
| Update pattern | Updated at chapter approval | Appended at session end / milestone |
| Read at session start | Yes — for chapter status | Yes — for carry-forward flags and open items |
| Authoritative for | Audit verdicts, V-Scores, approval state | Decisions made in chat, carry-forward constraints |

Both files are read at session start. They answer different
questions: pipeline-checkpoint answers "where am I in the manuscript
pipeline"; session-log answers "what did we agree to last time and
what are the rules for now."

## Limits and honest caveats

- **Entries are LLM-written.** Format adherence depends on the
  orchestrator following this spec. The four-bucket structure is a
  discipline, not a parser-enforced contract — though the test suite
  validates representative entries against the structure.
- **Append-only is by convention.** If the orchestrator rewrites the
  file destructively, prior entries can be lost. The
  post-engine-data-write-hook will catch NULL/UTF-8 corruption but
  not unintended rewrites. Treat the file as append-only by spec.
- **Best-effort recap entries** (Trigger 3) reconstruct from
  pipeline-checkpoint and may miss decisions that were only in chat.
  This is acknowledged in the entry itself with a `[recap, may be
  incomplete]` marker after the session header.

## Related specs

- `pipeline-checkpoint.md` (runtime per-chapter state, see
  `core-pipeline.md`)
- `author-corrections.md` — companion register for user corrections
- `core-pipeline.md` PHASE 1 CONTINUATION-BOOK CROSS-CHECK —
  incorporates session-log read at resumption
- `core-pipeline.md` File Operation Policy — same-FS-temp + post-write
  integrity pattern for engine-data writes

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification binding are
documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Bash append (`>>`) to engine-data file | "Append succeeded" | Bridge intermittency → NULL fill at target size | Post-engine-data-write-hook (v2.7.73+) runs chapter-integrity-check.sh on the file; FAIL surfaces immediately |
| Read most recent N entries at session start | "Loaded recent session context" | File missing / malformed / truncated | Read-verification protocol: orchestrator confirms read returned non-empty content matching expected `## <date> — Session <N>` header pattern before proceeding |
| Archive trim (future, with 2-pass safety) | "Trim succeeded" | Active file truncated without archive saved → entry loss | 2-pass discipline + pre-trim integrity check on archive file (see Archival section above) |
| Best-effort recap entry (Trigger 3) | "Reconstructed prior session" | Reconstruction misses chat-only decisions | Entry explicitly marked `[recap, may be incomplete]`; user can extend the entry on review |
