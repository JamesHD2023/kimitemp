---
name: rhetoric-library
description: "Rhetorical strategies for non-fiction — the equivalent of fiction's trope library"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Rhetoric Library — Non-Fiction Strategies

## Overview

Where fiction uses tropes (enemies-to-lovers, chosen one, locked room), non-fiction
uses rhetorical strategies — patterns for presenting information, building arguments,
and engaging readers. The user selects strategies during setup; the Structural
Architect deploys them across chapters.

## Strategy Categories

### Narrative Strategies

How information is delivered through story.

| Strategy | Description | Best For |
|----------|------------|----------|
| **Anecdote-as-Evidence** | A specific story that proves a point — the reader experiences the evidence rather than being told about it | Self-help, Business, Popular Science |
| **Expert Witness** | Introduce a real expert who "testifies" through quotes and interviews — the reader trusts the expert's authority | Journalism, Health, Technology |
| **Personal Confession** | The author reveals vulnerability or failure — builds trust and demonstrates the stakes are real | Memoir, Self-Help, Creative NF |
| **Historical Parallel** | Draw a connection between a past event and the current subject — "this has happened before, and here's what we can learn" | History, Political, Business |
| **Thought Experiment** | Invite the reader to imagine a scenario — "What if..." — making abstract concepts tangible | Philosophy, Science, Technology |
| **Socratic Questioning** | Build understanding through a sequence of questions the reader answers internally — leading them to the conclusion rather than stating it | Philosophy, Education, Self-Help |
| **Immersion Scene** | Drop the reader into a vivid, present-tense scene — they experience the subject rather than reading about it | True Crime, Travel, Creative NF, Memoir |
| **The Reveal** | Withhold a key piece of information until the moment it will have maximum impact — then recontextualise everything before it | True Crime, Journalism, Popular Science |

### Structural Strategies

How arguments are built across sections and chapters.

| Strategy | Description | Best For |
|----------|------------|----------|
| **Thesis-Antithesis-Synthesis** | Present a position, present the opposition, then forge a new understanding from both | Philosophy, Political, Academic |
| **Nested Arguments** | Major thesis contains smaller claims, each proven independently, that combine into the larger case | Business, Science, Policy |
| **The Pivot** | Midway through the book, reframe the reader's understanding — what they thought the book was about changes | Popular Science, Journalism, Creative NF |
| **Cumulative Evidence** | Each chapter adds another piece of evidence — the case builds gradually until the conclusion feels inevitable | True Crime, History, Business |
| **Problem-Escalation-Solution** | Present a problem, show it's worse than the reader thought, then offer the solution when they're ready for it | Self-Help, Health, Business |
| **The Callback** | Reference earlier content in a new light — "Remember X from Chapter 3? Here's what we didn't know then" | All categories — powerful for cohesion |
| **Parallel Tracks** | Two storylines running simultaneously that converge later — often a "then" and "now" structure | Biography, History, True Crime |

### Authority Strategies

How the author establishes and maintains credibility.

| Strategy | Description | Best For |
|----------|------------|----------|
| **Credentials Establishment** | Lead with the author's qualifications early — "I spent 20 years researching..." | Academic, Health, Business |
| **Vulnerability Pivot** | The author admits what they got wrong — paradoxically increasing trust | Memoir, Self-Help, Creative NF |
| **Expert Consensus** | Show that multiple independent experts agree — weight of evidence, not just one voice | Science, Health, Policy |
| **Maverick Position** | Explicitly acknowledge the author's view differs from mainstream — and explain why that's a strength | Business, Philosophy, Technology |
| **Show Your Work** | Walk the reader through the research process itself — transparency builds trust | Journalism, Science, True Crime |
| **Earned Authority** | Demonstrate expertise through the quality of observation and analysis, not credentials | Nature, Travel, Creative NF |

### Engagement Strategies

How to keep the reader turning pages.

| Strategy | Description | Best For |
|----------|------------|----------|
| **Opening Hook Types** | Startling statistic, provocative question, vivid scene, counter-intuitive claim, "what if", personal anecdote | All categories |
| **Chapter Cliffhanger** | End each chapter with an unanswered question or an incomplete revelation — the non-fiction equivalent of a page-turner | True Crime, Journalism, Popular Science |
| **The Callback** | Reference earlier content in new light | All categories |
| **Data Surprise** | Present a statistic that contradicts the reader's assumption — cognitive dissonance creates engagement | Business, Science, Health, Policy |
| **The Human Cost** | Attach abstract data to a specific person's experience — make statistics feel real | Journalism, Health, Political, True Crime |
| **Future Stakes** | Show the reader what happens if nothing changes — urgency drives engagement | Environment, Health, Technology, Policy |
| **Reader Challenge** | Directly challenge the reader's assumptions — "You probably think X. Here's why that's wrong" | Self-Help, Business, Philosophy |

## Strategy Selection During Setup

The Structural Architect selects 3-5 strategies based on the category and the
book's specific needs. These become the recurring rhetorical tools deployed
across chapters — giving the book a consistent "voice" in how it presents
information.

## Strategy Deployment Rules

- **Variety:** No single strategy used in more than 40% of chapters
- **Consistency:** At least 2 strategies should recur throughout the book
- **Category fit:** Strategies must match the category's conventions
- **Tracking:** The Architect logs which strategies were used per chapter
  to ensure variety and prevent repetition fatigue
