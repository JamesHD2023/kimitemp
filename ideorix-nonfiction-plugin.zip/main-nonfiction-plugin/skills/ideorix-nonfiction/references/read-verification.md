---
name: read-verification
description: "Read-Verification HARD GATE protocol. When the engine reads user-supplied source files (worldbuilding documents, importer bundles, existing manuscripts, public-domain heritage texts, source-canon files), the Read tool can return success metadata with no content — particularly for PDFs. Without this gate the engine builds on missing foundations and produces an hour of fabricated work the user has to throw away. This spec defines the per-file content-presence check, the HARD GATE on failure, and the user-paste fallback chain. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.6"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Read-Verification Protocol (MANDATORY for any flow that reads user-supplied source files)

## Purpose

Ensure that every Read against a user-supplied source file
returns actual content before the engine treats the file as
absorbed. The Read tool can return a successful response —
filename, byte size, status code — with empty or near-empty
extracted text. This is most common for `.pdf` (PDF parsers
fail silently on certain encodings, scanned-image PDFs, locked
or password-protected PDFs, oversized PDFs), but also occurs
with `.docx` (python-docx extraction failures on certain
templates), `.scriv` bundles (parse failures on nested
documents), and any binary format the Read tool cannot decode.

If the engine treats a successful-but-empty Read as
"content absorbed", three failures cascade:

1. **Silent data loss.** The user's content never enters the
   engine's working state.
2. **Silent confabulation.** Without the source content, any
   downstream agent (Outline Builder, Architect, Bible
   Constructor) fabricates material that contradicts the user's
   actual canon — and presents it confidently as faithful.
3. **User wastes hours of work.** The user catches the
   contradiction only after seeing the fabricated output, by
   which point an entire pipeline pass is wasted and trust is
   damaged.

This protocol is the HARD GATE that catches the empty-read
before any downstream agent runs.

## Failure mode addressed

A Beta user (March 2026) ran the BYO-canon flow with eight
worldbuilding PDFs. The engine's PDF Read tool returned
successful responses for all eight, but extracted text for
seven of them was empty or below the meaningful threshold.
The engine treated all eight as absorbed and built an Act 1
outline that contradicted her canon in every fundamental
worldbuilding decision. She rejected the outline twice, the
engine apologised twice and tried again from the same
fabricated baseline, and only on the third rejection did it
self-diagnose and surface the empty-read failure. By then she
had spent over an hour on the session.

The v2.7.0 BYO-canon Step 0 HARD GATE verified files **existed**
in the `source-canon/` folder but did NOT verify the read
**returned content**. This protocol closes that gap.

## When the protocol applies

Every flow that reads user-supplied source files MUST apply
this protocol. Specifically:

| Flow | Spec | Read scope |
|------|------|------------|
| BYO-canon Step 0 | byo-canon.md (fiction only) | Every file under `source-canon/` |
| Novelcrafter Importer | novelcrafter-importer.md (fiction only) | Imported `.json` / `.md` bundle |
| Plottr Importer | `plottr-importer.md` | Plottr `.docx` export |
| Scrivener Importer | `scrivener-importer.md` | `.scriv` bundle (every nested document) |
| Screenplay Importer | screenplay-importer.md (fiction only) | Source `.fountain` / `.fdx` / `.pdf` / `.docx` |
| Manuscript Clinic | `manuscript-clinic.md` | Existing manuscript file |
| Edit & Revise | `edit-and-revise.md` | Every chapter file in `manuscript/chapters/` (returning user) |
| Heritage Text | `heritage-text.md` | Source public-domain text |
| Analyze a Book | `analyze-a-book.md` | Existing book file |
| Continue Writing / Continue Researching | continue-writing.md (fiction) / continue-researching.md (NF) | Existing project's `engine-data/` files |

For runtime files the engine itself wrote earlier in the
session (`engine-data/` checkpoint, summaries, briefs), the
protocol does NOT apply — the engine wrote them, so they are
known-good (the File-Write Hygiene binding verifies on-disk
integrity at write time).

## The protocol — three steps

### Step 1: Read with content-presence check

For each file in scope, perform the Read and immediately verify
the extracted content meets the per-format threshold:

| File extension / class | Minimum non-whitespace characters | Rationale |
|------------------------|-----------------------------------|-----------|
| `.pdf` | 100 | Even a single-page PDF has 100+ chars; below this is a parse failure |
| `.docx` | 100 | A meaningful DOCX paragraph is 50+ words ≈ 250 chars; threshold is generous |
| `.scriv` bundle | 100 per nested document | Each document inside the bundle checked separately |
| `.md` / `.txt` | 20 | A meaningful markdown file has at least a heading + line of content |
| `.fountain` / `.fdx` | 50 | A meaningful screenplay has at least a slug + character + dialogue |
| `.json` (importer bundle) | 100 | Empty JSON `{}` is 2 chars — anything below 100 is a malformed export |

If the Read returns content **below** the threshold (after
stripping whitespace), record the file in a `FAILED_READS`
list with: filename, reported byte size from Read response,
actual extracted character count.

### Step 2: HARD GATE — halt if any reads failed

After all in-scope files have been read, check `FAILED_READS`:

- **If empty (all reads returned content):** proceed.
- **If non-empty (one or more failed):** the protocol BLOCKS
  the flow. The engine MUST NOT call any downstream agent
  (Outline Builder, Architect, Bible Constructor, Importer
  parser, Manuscript Clinic analyser, Heritage Text restorer,
  etc.) until every failed read has a resolution.

The user MUST be told **exactly which files came back empty**
in a single clear message. Format:

```
HALT — Some of your source files came back empty when I tried to read them.
This is most often a PDF extraction failure on this end, not a problem
with your files.

Files I could NOT extract content from:
  - {filename1}.pdf  (file size: {size1} KB; extracted: {chars1} chars)
  - {filename2}.pdf  (file size: {size2} KB; extracted: {chars2} chars)
  - ...

Files I read successfully:
  - {filename3}.pdf  ({chars3} chars absorbed)
  - ...

I will NOT proceed without those missing files — if I do, I'd be
building on missing foundations and the output would silently
contradict your canon.

Three options to resolve:

  A. Paste the content of each missing file into chat. I'll absorb
     it directly from your message. (Most reliable for PDFs.)

  B. If a file is intentionally empty or you don't want it included,
     tell me which to skip and confirm.

  C. Re-upload the missing files — sometimes a re-upload extracts
     cleanly, especially if the original was a scanned image PDF
     and you upload an OCR'd version.

Which option for each missing file?
```

### Step 3: Resolve every failed read before advancing

The engine waits for the user's response. For each failed file
the user must select A (paste content), B (confirm empty / skip),
or C (re-upload).

- **Option A:** the user pastes content into chat. The engine
  absorbs from the chat message and re-runs Step 1 against the
  pasted content (the same threshold check applies — if the
  pasted content is also below threshold, ask again).
- **Option B:** the user confirms the file should be skipped.
  The engine records the skip in `engine-data/read-verification-log.md`
  and proceeds without that file.
- **Option C:** the user re-uploads. The engine re-Reads and
  re-runs Step 1 against the re-uploaded file.

Only when **every** entry in `FAILED_READS` has a resolution
does the engine proceed past the HARD GATE.

## Page-by-page PDF Read discipline (v2.7.8 extension)

When a flow Reads a PDF using the `pages:` parameter to
iterate through pages incrementally (large PDFs, source books,
heritage texts > 10 pages), the threshold check applies to
**EACH page**, not just the first. The Read tool can return
content for the title page and empty content for later pages
within the same iteration — the failure shape is identical to
single-file empty reads but per-page rather than per-file.

**Per-iteration discipline:**

1. After each `pages: "N"` Read, run the threshold check
   against that page's extracted content using the same `.pdf`
   threshold (≥ 100 chars).
2. Pages below threshold are flagged in `FAILED_READS` with
   the format `{filename}#page-{N}` and the reported page
   metadata (e.g. dimensions, byte count) so the user knows
   which pages came back empty.
3. A multi-page PDF where pages 1-3 succeed but pages 4-7 fail
   is NOT a partial success — it's a partial failure. The HARD
   GATE applies: the flow halts and surfaces the missing pages.
4. The user resolves missing pages with the same three options:
   paste content (with explicit page-N labels), confirm-skip,
   re-upload (with the per-page failure list, the user can
   re-upload an OCR'd version that extracts cleanly).

**Resolution-paste format for missing pages:**

```
PAGE-{N}: {pasted content for page N}
PAGE-{M}: {pasted content for page M}
```

The engine splits the paste on `PAGE-{N}:` markers and
absorbs each page's content as if it had been Read directly.
The same threshold check applies to pasted content — if
pasted content for a page is below threshold, ask again.

**Anti-pattern this prevents:** engine treats "first page
extracted successfully" as "PDF absorbed" and skips the rest
silently. The user never learns chapters 4-7 of their source
book are missing from the engine's working state.

## What the protocol does NOT do

- It does **not** attempt bash-based extraction fallbacks
  (`pdftotext`, `unzip`, `docx2txt`, etc.). The Read tool runs
  in environments where bash is often unavailable (Claude
  Desktop, claude.ai), so the bash-fallback chain is unreliable.
  The user-paste fallback is the only universally reliable path.
- It does **not** auto-retry the same Read on the same file
  expecting different results. Read tool failures are
  deterministic per-file; retrying without a re-upload wastes
  time.
- It does **not** apply to engine-internal files written
  earlier in the session (`engine-data/` checkpoint, summaries,
  briefs). The File-Write Hygiene binding handles those.
- It does **not** apply to `.docx` template files
  (`catalog-report-template.docx`, `sales-summary-template.docx`)
  — those are read by `pandoc` via `catalog-render.sh`, not by
  the engine's Read tool.

## Logging

The engine writes a per-session read-verification log:

```
~/Documents/Ideorix-Projects/[Title]/engine-data/read-verification-log.md
```

Format:

```markdown
# Read-Verification Log — {Title}

## Session {YYYY-MM-DDTHH-MM} — {Flow Name (e.g. BYO-canon Step 0)}

Files read:
- {filename1}.pdf — PASS — {chars1} chars
- {filename2}.pdf — FAIL → resolved by Option A (paste) — {chars2_pasted} chars absorbed
- {filename3}.pdf — FAIL → resolved by Option B (skipped, user confirmed)
- {filename4}.pdf — FAIL → resolved by Option C (re-upload) — {chars4_reupload} chars

Threshold rules applied: pdf=100 docx=100 md=20 txt=20 fountain=50 fdx=50 json=100
```

The log persists across sessions so a returning user can see
which files were skipped and why.

## Tier 4 behavioral assertion

The deterministic test harness (`tests/run-behavioral.sh`) runs
this protocol's threshold check against fixture files:

- f06-empty-pdf-extracted.txt — simulates a PDF Read response
  with empty content (5 chars only); must trigger HARD GATE
- f07-near-threshold-md.md — exactly 19 chars; must trigger
  HARD GATE for `.md` (threshold = 20)
- f08-just-over-threshold-pdf.txt — exactly 100 chars; must
  PASS for `.pdf`
- f09-empty-docx-extracted.txt — empty extraction; must
  trigger HARD GATE for `.docx`

If the threshold logic regresses against any fixture, CI blocks
the release.

## Anti-patterns this protocol prevents

- **Silent empty-read absorption:** engine reports "read your
  worldbuilding" with zero content actually loaded.
- **Silent confabulation:** Outline Builder / Architect / Bible
  Constructor fabricates content that contradicts the user's
  canon because the canon was never absorbed.
- **"I'll just work with what I have":** engine partial-absorbs
  N of M files and proceeds with the gaps, producing output
  the user has to manually compare against missing source.
- **Bash-extraction false confidence:** engine tries
  `pdftotext` / `unzip` and reports "extraction succeeded"
  when the workspace doesn't have those tools available.
- **Repeated apologise-and-retry-from-bad-state:** user rejects
  output, engine apologises, engine re-runs with the same
  empty-read foundation, output is fabricated again. (The
  documented BYO-canon Beta-user pattern.)
- **Hour-of-fabricated-work:** engine builds an entire pipeline
  pass on missing foundations before the user catches it.

## Cross-cutting binding

This protocol is the **fifth cross-cutting binding** in the
engine — parallel to:

1. Architect Mode binding (byo-canon.md in fiction; Q13 = Research Bible Only in NF; plus Quality Guardian)
2. Verification Discipline binding (`verification-discipline.md`)
3. File-Write Hygiene binding (`core-pipeline.md` § File-Write Hygiene)
4. Edit-Tool Typographic Fidelity binding (`core-pipeline.md` § Edit-Tool Typographic Fidelity)
5. **Read-Verification binding (this spec)**

Every spec listed in the "When the protocol applies" table
above invokes this binding at its read step. The binding is
the single source of truth — if the threshold rules need
adjustment, edit this file and the rule propagates everywhere.
