---
name: heritage-text
description: "Modernize public domain texts — update archaic spelling, fix OCR artifacts, apply modern formatting while preserving the original voice"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Heritage Text Refiner

Modernize public domain source texts while preserving the original words, voice, and meaning.

## File Location Discipline (MANDATORY — HARD GATE — runs FIRST)

**Before any modernization / OCR-repair / formatting work
begins, this flow MUST confirm or establish a canonical
project folder at `~/Documents/Ideorix-Projects/[Title]/`.**
The modernized manuscript, change log, formatting decisions,
and any companion outputs MUST be written into that folder
structure (see `core-pipeline.md` § File Location Discipline
for the canonical layout and Bash-Direct Write + Verify
protocol).

**If no project folder exists for this text** (e.g., the user
pasted or uploaded a public-domain source directly without
prior project setup), run the project-folder bootstrap BEFORE
proceeding: ask for the project title, confirm the save
location, create the canonical folder structure, and only then
begin modernization.

**HARD GATE — BLOCKING.** Outputs MUST NOT be written to the
agent's working directory, a sandbox path, or any temporary
location. The user MUST be able to open the modernized
manuscript in their own file explorer the moment processing
completes.

## What it does

| Task | What happens |
|------|-------------|
| **Spelling modernization** | Updates archaic spellings to current conventions (e.g., long-s "ſ" → "s") |
| **OCR artifact repair** | Fixes character misreads, broken words, damaged punctuation from scanning |
| **Style normalization** | Applies Chicago Manual of Style punctuation and formatting |
| **Structural formatting** | Chapter titles as Markdown headers, preserved paragraph and stanza breaks |
| **Fidelity guarantee** | Zero word substitution — only spelling and transcription errors are corrected |

## How to start

Say any of:
- "Refine this heritage text"
- "Clean up this classic text"
- "Modernize the spelling in this text"
- "Fix OCR errors in this text"
- "Prepare source material"
- "Process this public domain text"
- "Format this classic text"

## Input options

- **Paste text** — Paste the full text or excerpt directly
- **Markdown file** — Provide a `.md` file of the source
- **Project Gutenberg text** — Headers and footers are removed automatically

**Read-Verification HARD GATE applies (see `read-verification.md`).**
When the user supplies a heritage text via uploaded file (most often
a `.md` or `.txt` from Project Gutenberg, or a `.pdf` of a scanned
public-domain edition), verify the Read returned content above the
per-format threshold. Heritage-text PDFs are commonly scanned-image
files where the Read tool returns success metadata with empty or
near-empty extracted text. Running the modernizer / OCR-fixer on
empty content would silently produce zero output and a "completed"
flow with nothing to show. Failed Reads BLOCK and surface the
failure to the user with the three resolution options (paste content
/ re-upload an OCR'd version / supply a different format).

**Source Persistence HARD GATE applies (see `source-persistence.md`,
v2.7.9).** After successful Read, the original heritage text is
persisted to `manuscript/source-original.{ext}` BEFORE the
modernization pass runs — preserving the unmodified source so the
user can compare modernization choices against the original, and so
the source is available for re-modernization with different
parameters in a future session.

## Use cases

- **Research material** — Clean up reference texts before using them for world-building
- **Adaptation prep** — Prepare classic texts that inform a retelling
- **Style study** — Produce readable versions of archaic texts for craft analysis
- **Anthology assembly** — Process multiple heritage texts into a consistent format

## What you get back

A fully refined text plus a summary report showing spelling updates, OCR repairs, footnotes removed, headers formatted, and a fidelity confirmation that no words were substituted.

> **Tip:** The more text you provide, the better the consistency. Maximum recommended length is 150,000 words per session.
