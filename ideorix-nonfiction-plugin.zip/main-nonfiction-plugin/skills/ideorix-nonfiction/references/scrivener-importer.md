---
name: scrivener-importer
description: Import a Scrivener project (.scriv bundle) into Ideorix Non-Fiction — preserves manuscript prose, binder structure, Key Figures, places, and research notes
version: "1.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the technical protocol document. The user-facing skill lives in `scrivener-import.md` (same folder) — that's where the trigger phrases and branding rule live. This file is loaded by reference during import execution.


> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine

# Scrivener Importer (Non-Fiction)

## Purpose

Convert a Scrivener project (`.scriv` bundle) into a working Ideorix
Non-Fiction project. Handles two cases: (a) **fully drafted manuscripts**
— chapter prose extracted into Ideorix chapter files, footnotes preserved,
sources extracted; and (b) **outline-only projects** — synopses become
Section 9 chapter outline entries, no prose yet. Both cases build a
starter Research Bible from the binder structure.

Research-side sections that Scrivener can't fully populate on its own —
Section 2 (Thesis), Section 10 (Source Assignments), Section 11
(Counter-Arguments), Section 12 (Research Gaps) — are created as
placeholders, informed by whatever the user has in their Notes and
Research folders, for completion during Research Bible review.

This is a **one-way import.**

## When to Use

Trigger phrases:
- "Import from Scrivener"
- "Import my Scrivener project"
- "Bring my Scrivener work across"
- "Scrivener import"
- "I have a Scrivener project"

## Prerequisites

The user provides a `.scriv` bundle. Two acceptable forms:
1. A `.zip` of the `.scriv` directory (recommended for cloud transfer)
2. The `.scriv` directory itself (if working locally)

Place at `~/Documents/Ideorix-Projects/imports/` or have the path ready.

## Input Format Reference

A Scrivener 3 project is a directory bundle:

```
{Project Name}.scriv/
├── {Project Name}.scrivx     ← binder XML (project structure)
├── Files/
│   └── Docs/                  ← per-item content files
│       ├── {id}.rtf            ← body content (RTF — chapters, figure bios, research notes)
│       ├── {id}_synopsis.txt   ← plain-text synopsis (one-line summary)
│       └── {id}_notes.rtf      ← RTF notes
├── Settings/
└── Snapshots/
```

**Binder XML structure** (`{Project Name}.scrivx`):

```xml
<ScrivenerProject Version="1.5">
  <Binder>
    <BinderItem ID="0" Type="DraftFolder">
      <Title>Manuscript</Title>
      <Children>
        <BinderItem ID="3" Type="Folder">
          <Title>Part One — The Setup</Title>
          <Children>
            <BinderItem ID="4" Type="Text">
              <Title>Chapter One: Origins</Title>
            </BinderItem>
            ...
          </Children>
        </BinderItem>
        ...
        <BinderItem ID="200" Type="Folder">
          <Title>People</Title>
          ...
        </BinderItem>
        <BinderItem ID="211" Type="Folder">
          <Title>Places</Title>
        </BinderItem>
        <BinderItem ID="212" Type="Folder">
          <Title>Research</Title>
        </BinderItem>
        <BinderItem ID="213" Type="Folder">
          <Title>Notes</Title>
        </BinderItem>
      </Children>
    </BinderItem>
    <BinderItem ID="2" Type="TrashFolder">...</BinderItem>
  </Binder>
</ScrivenerProject>
```

**Item types:**
- `DraftFolder` — the manuscript root (always ID 0)
- `Folder` — a grouping (e.g. "Part One", "People", "Places", "Research")
- `Text` — a leaf document (a chapter, section, figure bio, or research note)
- `TrashFolder` — ignore entirely

**Content lookup by binder ID:**
- Body prose: `Files/Docs/{id}.rtf` (may not exist if outline-only)
- Synopsis: `Files/Docs/{id}_synopsis.txt`
- Notes: `Files/Docs/{id}_notes.rtf`

## Processing Pipeline

### Step 1: Locate and unpack

If user provides a `.zip`, extract to a temp directory. Walk the result
to find the `.scriv` bundle inside (the zip may contain it at the root or
nested).

### Step 2: Parse the binder XML

**Read-Verification HARD GATE applies (see `read-verification.md`).**
Verify the `.scrivx` Read returned content above threshold (≥ 100
chars). The Read tool can return success metadata with empty content
on certain Scrivener bundle structures (older project format
versions, locked permissions, oversized binders). Empty `.scrivx`
content would parse to an empty BinderItem tree and a project with
zero chapters. The same gate applies in Step 4 — every Text-item
nested document MUST be verified to return content above the
per-format threshold; any document whose Read returns empty is
flagged in `FAILED_READS` and surfaced to the user with resolution
options before the binder tree is finalised. NF-specific note:
citation/source-attribution documents inside the `Research/Notes`
folder are protected categories — empty Reads on those documents
silently lose the source ledger, which the Verification Discipline
binding at Phase 2G then cannot cross-check.

Read `{Project Name}.scrivx`. Walk the BinderItem tree, building an
in-memory tree:

```python
{
  id: "0", type: "DraftFolder", title: "Manuscript",
  children: [
    {id: "3", type: "Folder", title: "Part One — The Setup", children: [
      {id: "4", type: "Text", title: "Chapter One: Origins", children: []},
      {id: "5", type: "Text", title: "Chapter Two: First Evidence", children: []},
      ...
    ]},
    ...
  ]
}
```

### Step 3: Identify top-level sections

Inside the DraftFolder (Manuscript), look for these well-known folders
(non-fiction writers use many variations — match flexibly):

- **Chapter/section folders** — typically grouped by Part, Section, Period,
  or Era (everything that ISN'T the special folders below)
- **People / Characters / Cast / Subjects** folder — real-person bios
- **Places / Locations / Settings** folder — geographic/institutional entries
- **Research / Sources / Evidence** folder — research notes and source references
- **Notes** folder — author notes, working ideas
- **Timeline / Chronology** folder — date-based organisation

If a folder name doesn't match a known pattern, treat it as a chapter
group (since non-fiction Scrivener users freely customise folder names:
"Archival Materials", "Interview Transcripts", "Evidence Timeline").

### Step 4: Extract each Text item's content

For each Text item in the binder, attempt to load:
1. Body RTF: `Files/Docs/{id}.rtf` — if present, this is the prose or note
2. Synopsis: `Files/Docs/{id}_synopsis.txt` — always check
3. Notes: `Files/Docs/{id}_notes.rtf` — optional

Convert RTF to markdown using the embedded RTF parser. Strip RTF control
codes, preserve paragraph breaks, normalise inline formatting (italic,
bold, em dashes).

**Footnote preservation (non-fiction critical):** Scrivener stores
footnotes as inline RTF objects. Detect these and convert to markdown
footnote syntax (`[^1]` references at use, `[^1]: citation text` at end
of chapter). The footnote TEXT is additionally extracted to a candidate
source list for Section 4.

**Inline citation detection:** Common in-text citation patterns (Chicago
author-date `(Smith 2020, 42)`, MLA `(Smith 42)`, footnote markers) are
flagged and preserved verbatim.

**Detect outline-only vs full-prose mode:**
- If MOST chapter items have body `.rtf` files → full-prose mode
- If MOST chapter items only have `_synopsis.txt` → outline-only mode
- Mixed → treat as outline-only with partial drafts (warn the user)

### Step 5: Strip Plottr template content

Some `.scriv` files come from Plottr's "Export to Scrivener" feature. In
these, synopses contain Plottr template instructions. Detect by the
`--- Add Your Details Above this Line ---` marker. Strip everything
below the marker (template content) before using the synopsis.

This is the same template-stripping rule as the Plottr Importer — see
`plottr-importer.md`.

### Step 6: Preview and confirm

Display a summary:

```
Scrivener import preview:
  Title:         {ProjectTitle from .scrivx or filename}
  Mode:          {Full prose | Outline-only | Mixed}
  Chapters:      {count of Text items in chapter folders}
  Key Figures:   {count of Text items in People/Characters folder}
  Places:        {count}
  Research notes: {count of items in Research folder}
  Footnotes:     {total extracted from prose}
  Candidate sources: {unique source entries pulled from footnotes + Research}
  Total words:   {sum of body RTF word counts, if any}

Proceed? (yes / cancel)
```

### Step 7: Build the starter Research Bible

Map binder content to Research Bible sections:

| Research Bible Section | Source |
|---|---|
| Section 1 (Topic Scope) | ProjectTitle from `.scrivx`; boundaries inferred from first chapter or Notes folder |
| Section 2 (Thesis / Central Argument) | EMPTY — user populates during Research Bible review; Notes folder content surfaced as candidate thesis material |
| Section 3 (Authority Voice Profile) | EMPTY — user attaches existing profile or builds one at reduced setup |
| Section 4 (Key Sources & Evidence Base) | **STARTER** — candidate sources from footnotes + Research folder items. User reviews and confirms each during Research Bible review. |
| Section 5 (Subject Context) | Each Text item in the Places folder |
| Section 6 (Timeline / Chronology) | Top-level chapter folders if they look like dates/periods/eras; Timeline folder content if present |
| Section 7 (Key Figures) | Each Text item in the People/Characters/Cast/Subjects folder. Body RTF → bio block; synopsis → role-in-argument summary. |
| Section 8 (Information Architecture) | Inferred from binder hierarchy (Part → Section → Chapter structure) |
| Section 9 (Chapter Outline) | Chapter Text items in binder order, with synopsis as the Section 9 entry text; footnote density per chapter informs KEY SOURCES per chapter |
| Section 10 (Source Assignments) | **STARTER** — derived from which footnotes appear in which chapters (auto-mapped from in-text citations) |
| Section 11 (Counter-Arguments) | EMPTY — user populates during Research Bible review |
| Section 12 (Research Gaps) | EMPTY — Notes folder content surfaced as candidate research gap material |

### Step 8: Build manuscript files (full-prose mode only)

For each chapter Text item with a body `.rtf`:
1. Convert RTF → markdown (with footnotes preserved)
2. Save to `engine-data/chapters/ch{NN}.md`
3. Save to `manuscript/chapters/chapter-{NN}.docx` (the user-facing copy)
4. Extract citation markers and add to `engine-data/citation-index.md`
5. Generate a chapter summary from the prose for `engine-data/summaries/`

For outline-only items: skip — chapters will be generated by the
Structural Architect and Content Writer using the Section 9 outline.

### Step 9: Research folder handling

The Research folder (or Sources, Evidence, etc.) often contains the
richest non-fiction material. Walk every Text item:

- Save each as-is to `engine-data/research-notes/{slug}.md` (markdown converted from RTF)
- Parse each for detectable source references:
  - Bibliographic lines (Author, Title, Year pattern)
  - URLs
  - DOI/ISBN patterns
  - Named archives or collections
- Append detected source candidates to `engine-data/sources.md` under a
  "CANDIDATE — needs confirmation" section
- Surface the full Research folder contents to the user during Research
  Bible review as browsable reference material

Do NOT auto-promote candidates to confirmed sources. The user must
explicitly accept each one during review. Source provenance matters.

### Step 10: Reduced Phase 1 setup

Scrivener doesn't record:
- Category, subcategory, dialect, length tier, research scope
- Citation style preference, content sensitivity, audience expertise
- Voice profile, pen name

Ask for these during the post-import setup. Skip questions that the
binder structure already answers (chapter outline source, project mode,
structure type from hierarchy).

**Citation style inference:** Look at the first 10 footnotes extracted.
Match patterns:
- `Smith, John. _Book Title_. Publisher, 2020, 42.` → Chicago notes
- `Smith, John (2020). _Book Title_. Publisher.` → APA
- `Smith 42` → MLA (in-text)
- `(Smith 2020, 42)` → Chicago author-date
- Propose the inferred style to the user for confirmation.

### Step 11: Build the workspace and hand off

Create the standard Ideorix Non-Fiction project structure. For full-prose
mode, hand off to **Research Bible review** first (to populate Thesis,
Counter-Arguments, and confirm candidate sources), then to **Edit &
Revise** or **Manuscript Clinic**. For outline-only mode, hand off to
**Research Bible review → chapter generation**.

Present the starter Research Bible status clearly:

```
Starter Research Bible ready for review.

POPULATED from Scrivener binder:
  ✓ Section 1 (Topic Scope) — from .scrivx project title
  ✓ Section 5 (Subject Context) — from Places folder
  ✓ Section 6 (Timeline) — from Part/Section folders
  ✓ Section 7 (Key Figures) — from People folder
  ✓ Section 8 (Information Architecture) — from binder hierarchy
  ✓ Section 9 (Chapter Outline) — from Manuscript folder structure
  ⧗ Section 4 (Key Sources) — {N} CANDIDATE sources from footnotes + Research folder
  ⧗ Section 10 (Source Assignments) — auto-derived from in-text citations

NEEDS YOUR INPUT:
  ⚠ Section 2 (Thesis / Central Argument)
  ⚠ Section 3 (Authority Voice Profile) — or attach existing
  ⚠ Section 11 (Counter-Arguments)
  ⚠ Section 12 (Research Gaps)
  ⚠ Confirm {N} candidate sources from Section 4

Research folder files available at engine-data/research-notes/ for
reference during review.

The Outline Conformance Agent won't engage until these sections are
populated. Proceed to review? (yes / cancel)
```

## Anti-Patterns

1. **Do NOT include Scrivener Trash folder content.** Trash items should
   be ignored entirely.
2. **Do NOT lose binder hierarchy.** Folder structure conveys grouping
   intent (Parts, Sections, Periods) — preserve it as Section 8
   (Information Architecture) and chapter grouping metadata.
3. **Do NOT include Plottr template content** in synopses — strip below
   the `--- Add Your Details Above this Line ---` marker.
4. **Do NOT silently merge same-named items.** If two figures have the
   same name in different binder positions (common in non-fiction —
   two "John Smith" figures with different roles), preserve both with a
   disambiguator and warn the user.
5. **Do NOT discard `_notes.rtf` content.** Notes often contain valuable
   author intent — append to the relevant Research Bible section as
   "Author notes" rather than dropping.
6. **Do NOT auto-promote candidate sources to Section 4.** Candidates
   from footnotes and Research folder content are flagged for user
   review. Source provenance is too important to auto-infer.
7. **Do NOT strip footnotes from chapter prose.** Non-fiction prose
   needs its citations preserved. Convert to markdown footnotes, keep
   the citation text, and extract to the candidate source list.
8. **Do NOT discard Research folder PDFs and binary files.** They can't
   be imported as prose, but generate a reference list so the user can
   hand-copy the file paths or URLs into Section 4.
9. **Do NOT assume a single citation style.** Let the inference pass
   surface its best guess and ASK the user to confirm. Mixed or
   inconsistent citation formats are common in draft non-fiction.

## Error Handling

| Error | Response |
|---|---|
| `.scrivx` file missing | Surface error, ask user to verify the bundle |
| Binder XML malformed | Fall back to filename-based parsing |
| RTF parse failure | Skip that item, warn user, continue |
| Body RTF missing for chapter | Treat as outline-only for that chapter |
| Trash folder contains items | Ignore — never import |
| Custom folder name (e.g. "Archival Sources") | Treat as a research folder; include in candidate sources scan |
| No People/Characters folder found | Warn but continue — Section 7 stays empty for user to populate |
| Footnote RTF marker unparseable | Preserve literal text inline, flag for user to manually convert |
| Citation style cannot be inferred | Ask user to pick Chicago/MLA/APA/Harvard/Footnotes at reduced setup |
| Research folder contains PDFs/binaries | List them in `engine-data/imports/binary-reference-list.md` with file paths |

## Future Expansion

v2 will add:
- Direct import of Scrivener research PDFs with text extraction
- Scrivener label/status metadata preservation (as revision markers)
- Tag-based source categorisation (primary vs secondary vs tertiary)
- Comment extraction (Scrivener inline comments → editorial notes)
- Multi-language binder support
