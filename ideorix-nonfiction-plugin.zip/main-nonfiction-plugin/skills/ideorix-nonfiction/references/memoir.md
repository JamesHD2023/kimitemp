---
name: memoir-category
description: "Category-specific instructions for memoir non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Memoir. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | memoir |
| Display Name | Memoir |
| Parent Group | Memoir & Biography |
| Typical Word Count | 60,000–85,000 |
| Default Structure | Chronological or thematic scene-driven narrative with present-day reflective voice; transformation arc mandatory |
| Citation Style | Personal voice; selective verifiable detail (dates, public events, institutions) integrated into prose; no formal endnotes; flag reconstructed dialogue as approximate where contentious |
| Audience Baseline | General reader seeking intimate, transformative human story; emotional sophistication assumed; no academic background required |
| Comparable Titles | Mary Karr (*Lit*, *The Art of Memoir*), Tara Westover (*Educated*), Cheryl Strayed (*Wild*), Roxane Gay (*Hunger*), Maggie O'Farrell (*I Am, I Am, I Am*), Vivian Gornick (*Fierce Attachments*), Kiese Laymon (*Heavy*), Lidia Yuknavitch (*The Chronology of Water*), Patti Smith (*Just Kids*), Ta-Nehisi Coates (*Between the World and Me*) |

## Subcategory Options

When the user selects Memoir, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| coming-of-age | Coming-of-Age / Childhood | Formative years, family origin, first awakenings, identity formation | Chronological with key-scene anchors; transformation across childhood-to-adulthood; bookended by then/now reflection |
| addiction-recovery | Addiction & Recovery | Substance use, treatment, recovery journey, relapse and re-stabilisation | Three-act recovery arc (descent / rock-bottom / recovery); scene-by-scene from chosen origin point through stabilisation; reflective coda |
| trauma-survival | Trauma & Survival | Processing acute or sustained difficult experience (abuse, war, accident, illness, loss) | Non-chronological permitted (trauma's temporal disorder is honest); spiral structure circling the central event; explicit safety frames at extremity |
| illness-medical | Illness / Medical / Body | Chronic illness, caregiver journey, body as subject, diagnosis and management | Diagnosis-as-inciting-incident pattern; alternating scene + medical-context chapters; long arc of accommodation rather than cure |
| travel-displacement | Travel / Displacement / Migration | Memoir structured around journeys, migration, geographic upheaval, exile | Place-based chapters as the structural unit; movement-as-arc; arrival and return as bookends |
| celebrity-public-figure | Celebrity / Public Figure | A well-known person's intimate perspective, often de-mythologising the public persona | Public-event-anchored chapters with private revelation; behind-the-scenes structure; selective intimacy (not full disclosure) |
| food-creative-practice | Food / Creative Practice / Vocation | Memoirs centred on food, art, craft, music, or another creative discipline as the lens | Practice-as-spine structure; scene-by-scene through creative milestones; the work itself becomes a co-protagonist |

**Default:** If the user does not specify, use `coming-of-age` conventions as
baseline (most universally instructive of memoir mechanics).

## Structural Architect Instructions

```
STRUCTURE
- Chronological or thematic around pivotal life events
- The fundamental unit is the SCENE. vivid, sensory, dramatised moments
- Dialogue is reconstructed, not transcribed. but must feel authentic
- Present-day narrator looking back, drawing meaning from past events
- TRANSFORMATION ARC is mandatory: who was I then vs who am I now

BEATS PER CHAPTER
1. Scene Beat. vivid, dramatised moment rendered with full sensory detail
2. Context Beat. the circumstances around the scene (era, family, culture)
3. Reflection Beat. present-day narrator's understanding of what happened
4. Connection Beat. how this moment connects to the memoir's larger arc
5. Anticipation Beat. what the reader senses is coming (dramatic irony)

MEMOIR ARCHITECTURE
- The SCENE is sacred: show, don't tell. Dramatise, don't summarise.
- Every chapter must advance the transformation arc
- The narrator must demonstrate self-awareness and growth
- Other real people rendered with complexity, not reduced to villains/props
- Selective: memoir is not autobiography. choose the moments that matter

FORBIDDEN
- Summarising events that should be dramatised ("That year was hard.")
- Other people reduced to one-dimensional roles
- The narrator as faultless hero. vulnerability IS the genre
- Endless recounting without reflection or meaning
- Fabricated events presented as real (memoir contract with reader)
```

## Content Writer Craft Rules

```
VOICE & TONE
- Intimate, reflective, honest. the reader is being trusted with something real
- First person, past tense (standard). present tense for heightened moments
- Two time layers: the experiencing self (then) and the narrating self (now)
- Sensory specificity: what did the kitchen smell like? What song was playing?

EVIDENCE STANDARDS
- The author IS the primary source. personal memory and experience
- Where memory is uncertain, acknowledge it: "I think it was Tuesday" is honest
- Factual details (dates, public events, institutions) should be verified
- Other people's dialogue reconstructed from memory. flagged as approximate if contentious

SCENE STANDARDS
- Every scene: who, where, when, what happened, what it felt/sounded/smelled like
- Minimum 3 sensory details per scene
- Dialogue in at least 50% of scenes (memoir without voices is essay, not memoir)
- Emotional interiority. what the experiencing self felt, what the narrating self now understands

PROSE RHYTHM MAPPING
- Ch 1 hook: the VOICE is the hook. intimate, specific, sensory from the opening line
- The reader must feel trusted with something private before page 2
- Sentence length: medium (15-22 words) as the baseline; the memoirist's rhythm is confessional, not clipped
- Vulnerability from page 1. the narrator earns the reader's time by risking something real
- High interiority throughout: this genre IS interiority. the narrator's inner life is the content
- Sensory specificity drives authority: what the room smelled like, what song was playing, what the light did
- Dialogue reconstructed but emotionally precise. the reader hears real voices, not summaries
- Vary sentence length around the emotional peaks: shorter at moments of impact, longer in reflection
- The experiencing self (then) uses present-tense-feeling immediacy; the narrating self (now) uses measured retrospection
- Tension ≥4 from chapter 1. emotional tension, not plot tension; the reader must sense stakes in the narrator's inner life
- Avoid information-dump pacing: context arrives through scene, not exposition blocks
- Reflection beats earn their place only after a scene has landed. never reflect before dramatising
- The transformation arc generates its own pacing: the reader must feel the narrator changing
- Evidence integration is personal. memories, sensory fragments, reconstructed dialogue are the "sources"
- Paragraph rhythm: scene paragraphs are longer and immersive; reflection paragraphs are shorter and pointed
- Reader engagement across information-dense passages: weave backstory into action, never pause the memoir to explain
- Authority delivery is earned through specificity. the more precise the memory, the more the reader trusts
- Every chapter must end with forward momentum: emotional questions unanswered, not cliffhangers
```

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Scene-driven | Chapter is built from at least one fully dramatised scene; "telling" passages support but do not replace scene |
| 2 | Sensory specificity | Minimum 3 distinct sensory details per scene (sight, sound, smell, touch, taste); details are specific (the *song*, the *room*) not generic |
| 3 | Two time-layers present | Both the experiencing self (then) and the narrating self (now) appear in the chapter; the gap between them carries meaning |
| 4 | Reflection earns its place | Reflection beats follow scene beats; no philosophising before the reader has seen what is being reflected on |
| 5 | Transformation arc advancing | The chapter moves the narrator's understanding or self-conception measurably forward (or shows productive resistance to that movement) |
| 6 | Other people rendered with complexity | Real people in the chapter are not reduced to villain / saint / prop; their agency and interior life are acknowledged even when the harm they caused is named |
| 7 | Vulnerability demonstrated | The narrator reveals something costly to self-image (fault, fear, complicity, confusion); perfect protagonists fail the genre |
| 8 | Memory honesty | Where memory is uncertain, it is acknowledged ("I think it was Tuesday"); reconstructed dialogue is flagged as approximate where contentious |
| 9 | Voice consistency across time-layers | The experiencing self speaks in age-appropriate register; the narrating self in measured retrospection; switches are deliberate and signalled |
| 10 | Theme beneath the personal story | The chapter advances the memoir's underlying question (what does it mean to belong / forgive / survive / become); personal events serve a larger inquiry |

## Source Requirements

### Mandatory Source Types

- **Author's memory and lived experience.** The author IS the primary source.
  Memory carries the genre's authority; specific sensory recall is the
  evidence the reader needs to trust the narrator.
- **Personal artefacts.** Photographs, letters, journals, diaries, voice
  notes, text messages, emails. Use to verify dates, sequences, names, and
  dialogue. A photograph of the kitchen anchors the smell of the kitchen.
- **Family / friend / witness accounts.** Where the memoir touches events
  another person experienced, their account corrects, supplements, or
  challenges the narrator's memory. Cross-checked, not deferred to.
- **Public records.** For dates, addresses, public events, institutional
  facts (school enrolment, hospital admissions, court records, news of the
  day). The verifiable details ground the unverifiable interior.

### Source Freshness

- **Contemporary memoir** (events within the last ~10 years): expect
  detailed memory; flag what is unclear; defend chronology against
  contemporaneous records.
- **Retrospective memoir** (childhood, decades-old events): memory is
  reconstruction; this is honest. Flag uncertainty in the prose voice
  ("I think it was September") rather than burying it.
- **Historical memoir** (life in a different era): supplement memory with
  period research (newspapers, music, food prices, fashion, local idiom)
  to render the era specifically rather than generically.

### Attribution Standards

- **Distinguish remembered from reconstructed from researched.** "I
  remember she said..." (memory). "She would have said..." (reconstruction).
  "According to the hospital records..." (research). Each register is
  legitimate; conflating them is not.
- **Composite characters and time compression are permitted but disclosed.**
  An author's note or in-text acknowledgement should make clear when a
  single rendered "friend" stands for several, or when events from two
  weeks have been compressed into one scene for narrative clarity.
- **Other people's dialogue is reconstructed.** Memoir does not have
  recordings. Render dialogue with emotional and tonal accuracy; flag any
  reconstructed exchange as approximate where the speaker contests the
  account or where the words carry consequence (e.g. legal, reputational).
- **What is NOT acceptable.** Inventing events that did not happen.
  Inventing people who did not exist (composites are different — a
  composite is a representation of real people with disclosure).
  Presenting research as memory or memory as research.

## Category-Specific Guardrails

### MANDATORY. Memory Honesty (the memoir contract)

- Memoir is a contract with the reader: this happened, and I am telling
  it as truthfully as I can given the limits of memory. Fabricating
  events and presenting them as real breaks the contract irrevocably.
- Where memory is uncertain, say so in the prose voice. "I think it was
  Tuesday." "I have asked my sister and she remembers it differently."
  This honesty strengthens, not weakens, the narrator's authority.
- Reconstructed dialogue is permitted (memoir has no recordings), but
  must be flagged as approximate where contested or consequential.
- Composite characters and time compression are permitted with author-
  note disclosure (typically front-matter or end-matter).
- The line: imaginative reconstruction in service of remembered truth is
  legitimate; invention presented as memory is not.

### MANDATORY. Other-Person Fairness (real people in your prose)

- Other real people in the memoir are not props for the narrator's
  arc. They have agency, interior life, and their own version of every
  shared event. Render that complexity even when the harm they caused
  is being named.
- Avoid one-dimensional rendering. The mother who failed you was also
  a person; the friend who saved you was also fallible. Memoir gains
  authority by refusing the easy reduction.
- Where another person is identifiable and consequentially portrayed,
  consider whether to (a) approach them for comment, (b) anonymise or
  composite, (c) render with extra care to fairness, or (d) defer
  publication until circumstances allow. The choice is the author's
  but it must be conscious.

### MANDATORY. Legal and Ethical Considerations

- **Defamation.** Statements of fact about identifiable living people
  that damage reputation must be defensible — true, opinion clearly
  framed as opinion, or fair comment on matters of public interest.
  Borderline content needs legal review prior to publication.
- **Privacy and consent.** Identifiable depictions of private life —
  particularly minors, mental health, sexuality, illness — warrant
  explicit consent or thorough anonymisation. Children deserve special
  protection: they cannot consent to permanent public depiction.
- **Identification.** Anonymisation is harder than it looks. Changing
  a name does not anonymise if other details (job, location, distinctive
  history) make the person identifiable to anyone who knows them.
  When in doubt, change more details or composite further.
- **Sensitive content frames.** Memoir touching abuse, addiction, self-
  harm, or suicide should consider an author's note flagging content
  and pointing to support resources where appropriate.

### Additional Guardrails

- **The narrator must be vulnerable.** Perfect-victim or faultless-hero
  narrators fail the genre. The reader trusts narrators who admit fault,
  confusion, complicity, mixed feeling. Vulnerability IS the genre.
- **Scenes are sacred — show, do not tell.** Summary is for connective
  tissue between scenes, not a substitute for them. "That year was
  hard" is not memoir; the dramatised Tuesday morning that made the
  year hard is.
- **The transformation arc is non-negotiable.** The reader needs to
  understand what changed in the narrator across the memoir's span —
  not "the events that happened to me" but "who I became as a result
  of those events." Memoir without transformation is autobiography,
  diary, or chronicle.
- **Selectivity is a craft choice.** Memoir is not autobiography. Choose
  the moments that serve the transformation arc; cut the moments that
  don't, however dear they are to the writer.
- **Theme beneath the personal.** The strongest memoirs are about more
  than the events. They are inquiries into a question — what does it
  mean to belong, forgive, survive, become. Pin the question early;
  return to it when the narrative drifts.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Warm and human (soft cream, dusk, amber, faded pastel)
  for intimate / coming-of-age / family memoir. Saturated single colour
  (deep red, navy, ochre) for trauma / survival / political memoir where
  the cover should signal weight. Cool atmospheric tones (greys, slate,
  faded blue) for travel / displacement / illness memoir.
- **Typography:** Serif (Garamond, Caslon, Sabon) for literary and
  retrospective memoir — the typography signals "this is considered
  prose, not journalism." Clean sans-serif (Gotham, Avenir) for
  contemporary, recovery, and celebrity memoir where accessibility
  matters more than literary positioning.
- **Imagery:** Three dominant traditions:
  1. **Author's face** — celebrity memoir, public-figure memoir.
     The face is the brand.
  2. **Symbolic object** — a single resonant item (a pair of boots,
     a kitchen window, a child's hand) that carries the memoir's central
     metaphor. Most common for literary and trauma memoir.
  3. **Atmospheric place** — a landscape, a building, a doorway. Most
     common for travel, place-based, and historical memoir.
- **Mood:** Invitation to an interior. The cover should feel like being
  trusted with something private; not a catalogue, not a manifesto.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Coming-of-Age / Childhood | Warm palette, often a child-perspective image (low angle, close-up of object); typography with some hand-set quality |
| Addiction & Recovery | High-contrast palette (often dark + single bright accent); plain typography; restraint over decoration |
| Trauma & Survival | Saturated single colour or stark monochrome; symbolic object or absence; serif typography signalling considered prose |
| Illness / Medical / Body | Cool atmospheric palette; body fragment or medical-adjacent object (window, bed, instrument); careful not to medicalise the cover |
| Travel / Displacement / Migration | Landscape imagery, often with horizon line; map elements occasionally; warm or cool depending on tone |
| Celebrity / Public Figure | Author's face, often in unguarded moment; large name typography; subtitle clarifies the angle |
| Food / Creative Practice / Vocation | Object-driven (a kitchen, an instrument, a workspace); warm palette; typography references the practice's visual culture |

### Typography Rules

- **Title:** 35–55% of cover area. Memoir titles trade on resonance, not
  description; one or two evocative words is often stronger than a
  descriptive phrase.
- **Subtitle:** Often does the descriptive work the title leaves alone.
  "A Memoir" suffices for literary positioning; longer subtitles
  ("A Memoir of Recovery", "A Daughter's Reckoning") signal the
  promise to the reader.
- **Author name:** Large for established authors (Mary Karr, Ta-Nehisi
  Coates); moderate for debut. The name's weight signals the author's
  prior authority with the reader.
- **Spine and back cover:** The spine carries title + author + small
  publisher mark; back cover prioritises endorsement quotes from named
  authors over descriptive blurb.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Coming-of-Age / Childhood | Kindle Store > Kindle eBooks > Biographies & Memoirs > Memoirs |
| Addiction & Recovery | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > Substance Abuse |
| Trauma & Survival | Kindle Store > Kindle eBooks > Biographies & Memoirs > Memoirs (with Self-Help > Abuse secondary if applicable) |
| Illness / Medical / Body | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > Sick (or Disabled) |
| Travel / Displacement / Migration | Kindle Store > Kindle eBooks > Biographies & Memoirs > Travelers & Explorers |
| Celebrity / Public Figure | Kindle Store > Kindle eBooks > Biographies & Memoirs > Arts & Literature (or Sports / Politics per profession) |
| Food / Creative Practice / Vocation | Kindle Store > Kindle eBooks > Biographies & Memoirs > Arts & Literature (with profession-specific secondary) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Personal Memoirs (broad) | Kindle Store > Kindle eBooks > Biographies & Memoirs > Memoirs > Personal Memoirs |
| Family relationships | Kindle Store > Kindle eBooks > Parenting & Relationships > Family Relationships |
| Women's biographies | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > Women |
| LGBTQ+ memoirs | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > LGBTQ+ |
| Cultural / ethnic | Kindle Store > Kindle eBooks > Biographies & Memoirs > Ethnic & National (specific origin) |
| Historical context | Kindle Store > Kindle eBooks > History > (Period or Region) |
| Religious / spiritual | Kindle Store > Kindle eBooks > Religion & Spirituality > Religious Studies > Personal Growth |

### Keyword Recommendations

- The memoir's central life event or relationship as a phrase
  ("recovery memoir", "mother daughter memoir", "war memoir")
- The transformation arc as a noun
  (resilience, reckoning, reinvention, return, reconciliation)
- Demographic or cultural markers where relevant
  (single mother, immigrant, queer, working class, first generation)
- Comparable author names for discoverability
  (readers of Mary Karr, Cheryl Strayed, Ta-Nehisi Coates)
- Emotional registers the reader is seeking
  (grief, healing, courage, witness, survival)
- Genre signals
  ("memoir", "literary memoir", "personal essay collection")
- Avoid generic single-word terms ("life", "story", "journey") — they
  drown in algorithmic noise; prefer specific compound phrases.
