---
name: help-nonfiction
description: "Quick reference for all non-fiction commands, phases, and categories"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Help — Ideorix Non-Fiction

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine

## Quick Commands

| Command | What It Does |
|---------|-------------|
| "Research a project" | Start a new non-fiction manuscript from scratch |
| "Continue researching" | Resume an in-progress project |
| "Edit my manuscript" | Run the editorial pipeline on your writing |
| "Export to DOCX" | Generate formatted manuscript files |
| "Design a cover" | Create cover concepts with AI image prompts |
| "Marketing" | Generate blurbs, descriptions, social media packs |
| "Market Scout" | Live market intelligence for any category |
| "Authority Builder" | Build a reusable author voice profile |
| "Analyze a book" | Reverse-engineer any book's structure |
| "Manuscript clinic" | Scored analysis with expert consultation |
| "Pen name" | Create and manage pen names |
| "Heritage text" | Modernize public domain texts |
| "Menu" | Return to the main menu |
| "Help" | Show this reference |

## Pipeline Phases

| Phase | What Happens |
|-------|-------------|
| 0 | Series Architecture (if multi-volume) |
| 1 | Interactive Setup — 13 questions configure the engine |
| 2 | Research Bible — topic scope, thesis, sources, outline |
| 3 | Chapter Generation — architect brief → write → verify → repeat |
| 4 | Verification — 5 agents check every chapter automatically |
| 5 | Editorial — 13-stage manuscript-wide editorial pass |
| 6 | Delivery — formatted files, KDP metadata |
| 7 | Publishing Studio — covers, marketing (on demand) |

## Available Categories

| Group | Categories |
|-------|-----------|
| **Memoir & Biography** | Memoir, Biography, Historical Biography |
| **History** | General History, Military History, Social History, Microhistory |
| **Popular Science** | Popular Science, Natural History, Environmental |
| **Self-Help & Psychology** | Self-Help, Popular Psychology, Popular Philosophy |
| **Business & Finance** | Business, Economics/Finance, Personal Finance |
| **True Crime** | True Crime |
| **Health & Wellness** | Health/Wellness, Fitness |
| **How-To & Guides** | How-To Guides, Cooking/Food Writing |
| **Journalism & Commentary** | Investigative Journalism, Political/Social Commentary |
| **Creative Non-Fiction** | Literary Non-Fiction, Essay Collections |
| **Travel & Nature** | Travel Writing, Nature Writing |
| **Culture & Arts** | Art/Music/Culture, Sports/Adventure |
| **Education & Parenting** | Education, Parenting |
| **Technology** | Technology/Digital |
| **Religion & Spirituality** | Religion/Spirituality |

## Verification Agents

| Agent | What It Checks |
|-------|---------------|
| Source Guardian | Every claim sourced, no unsupported assertions |
| Evidence Auditor | Argument quality, craft commandments, voice compliance |
| Citation Keeper | Citation format, bibliography completeness |
| Expert Tracker | Real people accurately represented |
| Argument Analyst | Thesis progression, logical coherence |

## Structural Frameworks

| Framework | Best For |
|-----------|----------|
| Problem-Solution | Self-help, business, how-to |
| Chronological Narrative | Memoir, biography, history |
| Argument-Driven | Commentary, philosophy, policy |
| Thematic Exploration | Popular science, cultural criticism |
| Case Study Cascade | Business, education, psychology |
| Investigation/Revelation | Journalism, true crime |
| Journey/Transformation | Memoir, travel, spiritual |
| Instructional Progressive | How-to, reference, guides |
| Compare-Contrast | History, science, philosophy |
| Question-Driven | Science, philosophy, social |
| Biographical Arc | Biography, business memoir |
| Seasonal/Cyclical | Nature, agriculture, memoir |

## Export Formats

DOCX, Atticus DOCX, EPUB, PDF, Markdown, RTF, Standard Manuscript Format, Academic (with bibliography/citations)

## Need More Help?

Say "Menu" to return to the main menu, or ask any question about how Ideorix works.
