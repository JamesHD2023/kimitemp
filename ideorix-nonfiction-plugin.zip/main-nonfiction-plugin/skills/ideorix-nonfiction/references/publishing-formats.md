---
name: publishing-formats-nonfiction
description: "KDP metadata and export format templates for non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# KDP Metadata & Export Formats — Non-Fiction

## File Location Discipline (MANDATORY)

**Output files:**
- KDP metadata document → `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-kdp-metadata.{ext}`
  (typically `.json` or `.txt` depending on the metadata
  profile — categories, keywords, BISAC codes, A+ Content
  blocks)
- Per-platform metadata variants (if produced) → same
  `manuscript/` folder with platform suffix
  (`{Title}-kdp-metadata.json`, `{Title}-apple-metadata.json`, etc.)

These outputs MUST be written to the canonical project's
`manuscript/` subfolder, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## KDP Metadata Gate (MANDATORY — v2.7.68+)

Before the project is declared KDP-ready or launch-ready, the
gate verifies the KDP metadata file exists at the spec-mandated
path and contains the fields KDP submission requires:

```bash
bash scripts/kdp-metadata-gate.sh "{project-root}"
```

The gate verifies:
- `manuscript/*-kdp-metadata.{json,txt,md}` exists, >= 500 bytes
- Contains: title, description, keywords, BISAC, comp_titles, pricing
- If JSON: keywords array has at least 7 entries (KDP requires 7)

If the gate fails, the project is NOT submission-ready — complete
the missing fields in the metadata file BEFORE attempting KDP
upload. Half-finished metadata uploaded to KDP wastes the
submission cycle.

Opt-outs: `kdp_status: legacy / skip` in
`engine-data/project-config.md`.

## KDP Info Document Structure

Generate a companion .docx containing everything needed for Amazon KDP publishing.

### Required Sections

**1. Book Information**
- Title, Subtitle (common in non-fiction), Author name, Publication date

**2. Amazon Book Description** (max 4,000 characters)
- Hook paragraph → 2-3 premise paragraphs → Credentials line → Call-to-action
- Include category keywords naturally

**3. Amazon Keyword Phrases (7 required)**
- 2 broad category keywords
- 2 topic/theme keywords
- 2 specific niche keywords
- 1 comp-based keyword

**4. BISAC Categories (3 suggestions)**

**5. Pricing Suggestion**
- Short Form (under 30K): $2.99-$4.99
- Standard (30-60K): $4.99-$9.99
- Comprehensive (60K+): $9.99-$14.99
- Reference (~120K+): $14.99-$24.99

**6. Comparable Titles (3-5)** — same category, published within 3 years

**7. Target Audience**

**8. Cover Image Prompt** — see `cover-designer.md`

## Export Formats

| Format | File | Best For |
|--------|------|----------|
| DOCX (Default) | format-docx.md | Editing, submission |
| Atticus DOCX | format-atticus-docx.md | Atticus formatting |
| EPUB 3.3/3.2 (Universal Standard) | format-epub.md | Wide distribution, e-readers, all major retailers |
| PDF | format-pdf.md | Print review |
| Markdown | format-markdown.md | Plain text editing |
| RTF | format-rtf.md | Submission to outlets |
| SMF | format-smf.md | Agent/publisher submission |

### Non-Fiction Specific Additions

All formats must support:
- **Bibliography / References** — formatted per selected citation style
- **Index** — keyword index for reference works
- **Footnotes / Endnotes** — per citation style selection
- **Table of Contents** — with section depth appropriate to the book
