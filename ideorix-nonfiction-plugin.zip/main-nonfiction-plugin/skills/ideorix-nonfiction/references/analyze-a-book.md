---
name: analyze-a-book
description: "User-facing skill: reverse-engineer any non-fiction book into a structural blueprint and a genericized template the author can use to scaffold an original work in the same family"
version: "1.0"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the user-facing skill. The technical
> implementation protocol lives in `story-analysis.md` (same folder)
> — that's where the chapter-by-chapter scanner and the whole-book
> synthesis logic live. This file holds the trigger phrases, the
> intake flow, and the branding rule.


> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

Ideorix Non-Fiction** — The Research & Writing Engine` before any
other output.

---

# Analyze a Book — Non-Fiction

## File Location Discipline (MANDATORY — HARD GATE — runs FIRST)

**Before any analysis / extraction work begins, this flow MUST
confirm or establish a canonical project folder at
`~/Documents/Ideorix-Projects/[Title]/`** (where `[Title]` is
the analysed book's title or a user-chosen project name). The
extracted argument structure, source ledger, evidence map,
chapter outline, comp analysis, and any companion outputs MUST
be written into that folder structure (see `core-pipeline.md`
§ File Location Discipline for the canonical layout and
Bash-Direct Write + Verify protocol).

**If no project folder exists for this analysis**, run the
project-folder bootstrap BEFORE proceeding: ask for the project
title, confirm the save location, create the canonical folder
structure, and only then begin extraction.

**HARD GATE — BLOCKING.** Outputs MUST NOT be written to the
agent's working directory, a sandbox path, or any temporary
location. The user MUST be able to open every blueprint
deliverable in their own file explorer the moment the analysis
completes.

## Purpose

Take any published non-fiction book and reverse-engineer it. The
output is a **structural blueprint** plus a **genericized template**
the user can adopt to scaffold an original book in the same family.

This is the right tool when an author says any of:

- *"I want to write something like {Book X}."*
- *"Help me understand why {Book X} works so well."*
- *"What's the structural pattern of bestselling {category} books?"*
- *"Can you analyse my manuscript against {Book X} as a reference?"*

It is NOT plagiarism assistance — the genericized template strips the
source book's specific subject, claims, and content, leaving only the
structural skeleton.

## Trigger Phrases

The following phrases route here automatically:

- *"Analyze this book"* / *"Analyse this book"*
- *"Reverse-engineer {Book X}"*
- *"What's the structure of {Book X}?"*
- *"I want to write like {Book X}"*
- *"Build me a template based on {Book X}"*

## Intake Flow

### Step 1: Source Book Acquisition

Ask the user for the source material. Accept any of:

```
How would you like to provide the source book?

  A. Upload the full text (.txt, .docx, .pdf, .epub, .md)
  B. Paste the text into chat
  C. Provide the title and author — I'll work from publicly
     available reviews, summaries, and excerpts
     (less precise than full-text analysis but workable for
     well-known books)

Type A, B, or C.
```

If A or B: proceed directly to Step 2 with the full text.

**Read-Verification HARD GATE applies (see `read-verification.md`)
when the user uploads a file (Option A).** Verify the Read returned
content above the per-format threshold (PDF ≥ 100 chars, DOCX ≥ 100,
EPUB ≥ 100, MD/TXT ≥ 20). A failed Read on an uploaded book file
produces a structural "analysis" of zero source content with
fabricated chapter-level observations. Failed Reads BLOCK and
surface the failure to the user with resolution options (paste
content / re-upload OCR'd PDF / fall back to Option C with title +
author) before any structural extraction runs. Option B (pasted
text) is exempt from the gate — pasted content is in the chat
message, not behind a Read tool.

**Source Persistence HARD GATE applies (see `source-persistence.md`,
v2.7.9) when the user uploads a file (Option A).** After successful
Read, the source book is persisted to `source-canon/{filename}`
BEFORE the structural extraction runs. The canon-absorbed.md marker
file gives the user an audit trail of which book was analyzed and
when. Option B (paste) and Option C (title + author) are exempt —
no upload to persist.

If C: confirm the title + author, search for reliable structural
information about the book (reviews from professional outlets, the
book's own table of contents if available, publisher synopses, expert
analyses), and proceed to Step 2 with whatever fidelity that allows.
Flag at the start of the output: *"This analysis is based on
publicly available information about the book, not a full-text read.
Treat structural inferences as approximations."*

### Step 2: Confirm Scope

```
What's the goal of this analysis?

  A. Full structural blueprint + genericized template
     (the standard output — what most users want)

  B. Just the structural blueprint (no template)
     (use when the user wants to study the book, not template it)

  C. Just the genericized template (skip the blueprint detail)
     (use when the user wants to start writing fast and doesn't
     need the deep dive)

  D. Comparison mode — compare this book to my manuscript
     (use when the user wants to see how their own work stacks up
     against the reference; routes through Manuscript Clinic with
     the source book's blueprint loaded as the comparison reference)

Type A, B, C, or D.
```

### Step 3: Run the Analysis

Hand off to `story-analysis.md` with the chosen scope. That file
handles:

1. **Phase 1: Chapter-by-Chapter Micro-Analysis** — every chapter
   scored on purpose, opening technique, argument structure,
   evidence types and density, voice register, scaffolding,
   chapter-ending technique, and pacing.

2. **Phase 2: Whole-Book Synthesis** — extracts the central thesis,
   chapter-cluster structure, argument-progression curve, evidence
   rhythm, voice profile, scaffolding density curve, pacing curve,
   and market-positioning signals.

3. **Genericized Template Generation** — produces a stripped
   template the user can use as a brief for `research-bible.md`
   Phase 1.

### Step 4: Deliver

Display the output inline AND save to:

```
Ideorix-Projects/{Project-Title or "ad-hoc"}/
├── analysis/
│   ├── source-book-name.md
│   ├── per-chapter-micro-analysis.md
│   ├── structural-blueprint.md
│   └── genericized-template.md
```

If the user is running in ad-hoc mode (no active project), save to a
temporary `ad-hoc/{book-name}-analysis/` folder and offer to attach
the analysis to a new or existing project.

### Step 5: Offer Next Step

After delivering, ask:

```
What's next?

  A. Use this template to plan my own book
     → routes to research-bible.md (Phase 1 with template loaded)

  B. Build me a chapter outline from this template
     → routes to structural-architect.md

  C. Compare my manuscript to this template
     → routes to manuscript-clinic.md (with template as reference)

  D. Analyse another book to broaden the pattern
     → loops back to Step 1 with a new source

  E. I'm done for now
```

## Output Files

Per Step 4 above. The four artifact files are:

| File | What it is |
|---|---|
| `source-book-name.md` | Title, author, publication year, category, length, edition (the source's metadata) |
| `per-chapter-micro-analysis.md` | The Phase 1 chapter-by-chapter scan |
| `structural-blueprint.md` | The Phase 2 whole-book synthesis |
| `genericized-template.md` | The reusable template (the deliverable the user takes forward) |

## Cross-Skill Handoffs

| User Action | Handoff To |
|---|---|
| Use template to plan a new book | `research-bible.md` (Phase 1, template loaded as brief) |
| Build chapter outline from template | `structural-architect.md` |
| Compare own manuscript to template | `manuscript-clinic.md` (template loaded as reference) |
| Analyse more books to extract a pattern | Loop back to Step 1 |

## Branding

All Analyze a Book output must begin with:

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

The badge "ANALYZE A BOOK — NON-FICTION" should appear in the header
of all output documents.
