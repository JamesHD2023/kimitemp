---
name: popular-science
description: "Category plugin for popular science non-fiction. physics, biology, neuroscience, medicine, mathematics"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Popular Science. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | popular-science |
| Display Name | Popular Science |
| Parent Group | Popular Science |
| Typical Word Count | 70,000–90,000 |
| Default Structure | Thematic chapters with narrative throughline |
| Citation Style | Endnotes (author-date in text where needed) |
| Audience Baseline | Educated general reader, no specialist knowledge assumed |
| Comparable Titles | Bill Bryson, Mary Roach, Carlo Rovelli, Ed Yong |

## Subcategory Options

When the user selects Popular Science, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| physics-cosmology | Physics / Cosmology | Fundamental forces, quantum mechanics, astrophysics, space-time, dark matter/energy | Concept-escalation (simple to mind-bending), historical narrative of discovery |
| biology-evolution | Biology / Evolution | Evolutionary theory, genetics, microbiology, origin of life, biodiversity | Organism-centred stories, deep-time narrative, branching tree exploration |
| neuroscience-cognitive | Neuroscience / Cognitive Science | Brain function, consciousness, perception, memory, decision-making | Case-study driven, experiment-to-insight, subjective experience as entry point |
| medicine-public-health | Medicine / Public Health | Disease, medical breakthroughs, epidemiology, healthcare systems, pandemics | Patient-zero narratives, detective structure, systems-level analysis |
| mathematics-cs | Mathematics / Computer Science | Number theory, algorithms, AI, cryptography, statistics, logic | Puzzle-first framing, historical biography of thinkers, proof-as-story |

**Default:** If the user does not specify, use `physics-cosmology` conventions as baseline.

## Structural Architect Instructions

### Core Technique: Explanatory Analogy

The fundamental craft move of popular science is the **explanatory analogy**. taking
an abstract or counterintuitive concept and mapping it onto something the reader
already understands. Every chapter brief MUST include at least one primary analogy
for the central concept being introduced.

### Chapter Architecture Patterns

1. **The Hook**. Open with a concrete, vivid moment: an experiment, a discovery, a
   failure, a question someone asked. Never open with a definition.
2. **The Stakes**. Within the first section, establish why this matters. What changes
   if we understand this? What breaks if we don't?
3. **The Escalation**. Build from accessible to challenging. Each section should raise
   the conceptual bar slightly, using the previous section as a foundation.
4. **The Expert Voices**. Integrate researcher quotes and perspectives. The reader
   should feel they are meeting the people behind the science.
5. **The Synthesis**. End each chapter by connecting the concept to the book's larger
   argument or the next chapter's territory.

### Evidence Deployment

- **Primary sources first:** Original papers, researcher interviews, lab observations.
- **Layered explanation:** Introduce the finding, explain the method (briefly), give
  the result, then interpret significance.
- **Counterarguments included:** Where scientific debate exists, present it. Do not
  flatten consensus where none exists.

### Brief Template Additions

For each chapter brief, the Architect MUST include:

- **Central Concept:** The one big idea this chapter teaches.
- **Primary Analogy:** The main analogy that will carry the explanation.
- **Analogy Limits:** Where the analogy breaks down (the Writer must acknowledge this).
- **Key Studies/Experiments:** 2–4 specific studies or experiments to feature.
- **Expert Voices:** Named researchers to quote or reference.
- **Jargon Register:** Technical terms introduced in this chapter with plain-language
  definitions.

## Content Writer Craft Rules

### Voice & Tone

- **Curious, not lecturing.** The author is a fellow traveller, not a professor.
  Write as someone discovering alongside the reader.
- **Concrete before abstract.** Always ground a concept in a physical, sensory, or
  narrative example before moving to the theoretical.
- **Sentence variety is mandatory.** Alternate between short punchy statements and
  longer, more flowing explanations. Monotonous rhythm kills science writing.
- **Wit is welcome, gimmicks are not.** Humour that emerges from the material is
  effective. Forced jokes undermine authority.

### Analogy Execution

- Introduce the analogy with a clear signal: "Think of it like..." or "Imagine..."
- Develop the analogy with enough detail that the reader can hold it in mind.
- State where the analogy fails: "But here's where the comparison breaks down..."
- Return to the precise science after the analogy has done its work.

### Jargon Protocol

- **First use:** Define in plain language, in context, within the sentence or the
  sentence immediately following.
- **Subsequent uses:** Use freely. the reader has been taught.
- **Never assume:** Even common scientific terms (gene, neuron, wavelength) get a
  brief contextual gloss on first appearance.

### Paragraph Construction

- Lead with the most interesting sentence, not the most logical one.
- Each paragraph should advance the argument or introduce new information.
- Transitions between paragraphs should feel inevitable, not mechanical.
- Avoid "topic sentence + three supporting sentences + conclusion" school-essay form.

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the WONDER. Start with a specific, surprising observation
  or experiment that makes the reader lean forward.
- **Sentence calibration:** Clean, precise sentences averaging 14–20 words. Science
  writing dies in bloat. trim every clause that does not earn its place.
- **Complexity through clarity:** Complex ideas delivered in accessible prose. If a
  sentence needs re-reading, it needs rewriting.
- **Metaphor frequency:** Bridge the abstract to the concrete at a rate of roughly
  1 metaphor per 200 words. Each metaphor must illuminate, not decorate.
- **Rhythm pattern:** Alternate short declarative sentences (6–10 words) with longer
  explanatory ones (18–25 words). The short sentence punches; the long sentence
  unfolds. Neither dominates.
- **Paragraph breath:** Vary paragraph length. a single-sentence paragraph after a
  dense four-sentence block creates emphasis and pacing.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In popular science,
  tension is curiosity-driven: the reader must always want to know what comes next.
- **Tension drivers:** Unanswered questions, counterintuitive findings, the gap between
  what we assumed and what the evidence shows.
- **Pacing within sections:** Open each section briskly (hook in 2 sentences), slow
  for explanation (methodical middle), accelerate toward the section's insight.
- **Connective tissue:** Transitions between paragraphs should create forward pull,
  not mechanical signposting. "But here is what nobody expected" beats "Next, we
  will examine."
- **Read-aloud test:** Every paragraph should sound natural spoken aloud. If the
  writer stumbles reading it, the reader will stumble reading it.

### Number & Data Handling

- Contextualise every number: "400 billion stars. more than every grain of sand on
  every beach in Wales."
- Round appropriately for narrative flow. Precision matters in papers, not in prose.
- Use comparisons the reader can visualise.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Explanatory clarity | A non-specialist reader can explain the central concept after reading |
| 2 | Analogy integrity | Primary analogy is developed, limits acknowledged, science not distorted |
| 3 | Evidence density | Minimum 3 cited sources per chapter, with method and significance noted |
| 4 | Expert voices | At least 1 named researcher quoted or paraphrased per chapter |
| 5 | Jargon handling | Every technical term defined on first use |
| 6 | Narrative momentum | Chapter has a clear arc. hook, escalation, synthesis |
| 7 | Accuracy | All scientific claims match peer-reviewed sources in the Research Bible |
| 8 | Contextualised numbers | No raw statistics without comparison or context |
| 9 | Voice consistency | Curious-guide tone maintained; no lecturing, no dumbing-down |
| 10 | Chapter connectivity | End of chapter connects to the book's throughline or next chapter |

## Source Requirements

### Mandatory Source Types

- **Peer-reviewed papers:** At least 60% of evidence claims must trace to published,
  peer-reviewed research.
- **Researcher interviews/quotes:** Direct attribution to named scientists. Secondary
  quotes from published interviews are acceptable.
- **Institutional data:** WHO, NASA, CERN, NIH, national academies. use for
  statistical claims.

### Source Freshness

- **Baseline science:** Classic papers and foundational studies are always valid.
- **Current claims:** Any claim about "recent research" must reference work published
  within the last 5 years relative to the book's publication date.
- **Retracted/corrected:** Cross-check against retraction databases. Never cite
  retracted work as current science.

### Attribution Standards

- Name the researcher(s), institution, and year for every significant finding.
- When popularising, still give the reader enough to find the original paper.
- Distinguish between: the study showed X (direct), experts believe X (consensus),
  some researchers argue X (contested).

## Category-Specific Guardrails

### MANDATORY. Analogies Must Not Distort Science

- Every analogy MUST be checked by the Quality agent for scientific accuracy.
- If an analogy implies a mechanism that does not exist, it must be revised or removed.
- Common offenders: "the brain is a computer" (misleading), "genes are blueprints"
  (inaccurate), "electrons orbit like planets" (wrong).
- The test: would a working scientist in the field object to this analogy? If yes,
  fix it.

### MANDATORY. Distinguish Fact from Speculation

- Established science: state as fact. "Light travels at 299,792,458 metres per second."
- Scientific consensus: signal consensus. "The evidence overwhelmingly supports..."
- Active debate: signal debate. "Researchers are divided on whether..."
- Speculation: label clearly. "One provocative hypothesis suggests..."
- Never present a hypothesis as established fact. Never present consensus as mere opinion.

### MANDATORY. Jargon Defined

- No technical term may appear without a plain-language definition on first use.
- Glossary at the back is supplementary, not a substitute for in-text definition.

### Additional Guardrails

- Do not anthropomorphise molecules, cells, or physical forces unless clearly flagged
  as metaphorical.
- Do not oversimplify to the point of inaccuracy. It is better to say "this is
  complicated" than to say something wrong simply.
- Acknowledge uncertainty. Science is a process, not a set of final answers.
- Avoid the "great man" narrative. science is collaborative. Credit teams and
  predecessors.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Deep blues, blacks, whites. cosmic/scientific register. Accent
  colours (electric blue, gold, deep red) for focal elements.
- **Typography:** Clean sans-serif for title; modern, confident. Subtitle in lighter
  weight. Author name prominent if established, subtle if debut.
- **Imagery:** Abstract or macro-scale visuals. nebulae, neural networks, molecular
  structures, mathematical patterns. Avoid literal laboratory imagery.
- **Mood:** Wonder, precision, intellectual adventure.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Physics / Cosmology | Cosmic scale. galaxies, light, space-time visualisations |
| Biology / Evolution | Organic forms. DNA helices, cellular structures, tree of life |
| Neuroscience / Cognitive | Neural imagery. brain scans, synaptic patterns, perception art |
| Medicine / Public Health | Human body, microscopy, epidemiological maps |
| Mathematics / CS | Geometric patterns, fractals, algorithmic visualisations |

### Typography Rules

- Title: 40–60% of cover area. Bold. One to four words ideal.
- Subtitle: Explanatory. Sits below title in lighter weight.
- Author credentials (PhD, Professor at X) may appear if they bolster authority.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Physics / Cosmology | Kindle Store > Kindle eBooks > Nonfiction > Science > Physics > General |
| Biology / Evolution | Kindle Store > Kindle eBooks > Nonfiction > Science > Biological Sciences > General |
| Neuroscience / Cognitive | Kindle Store > Kindle eBooks > Nonfiction > Science > Biological Sciences > Neuroscience |
| Medicine / Public Health | Kindle Store > Kindle eBooks > Nonfiction > Science > Medicine |
| Mathematics / CS | Kindle Store > Kindle eBooks > Nonfiction > Science > Mathematics > General |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| General Science | Kindle Store > Kindle eBooks > Nonfiction > Science > General |
| History of Science | Kindle Store > Kindle eBooks > Nonfiction > Science > History & Philosophy |
| Technology & Society | Kindle Store > Kindle eBooks > Nonfiction > Science > Technology |

### Keyword Recommendations

- Include the specific scientific discipline (quantum physics, evolutionary biology, etc.)
- Include "popular science" or "science for general readers"
- Include comparable author names where appropriate for discoverability
- Include the core concept or question the book answers
