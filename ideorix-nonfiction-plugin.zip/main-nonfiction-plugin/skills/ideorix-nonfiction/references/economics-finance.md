---
name: economics-finance-category
description: "Category plugin for Economics and Finance non-fiction. provides structural, craft, quality, and guardrail instructions for all pipeline agents"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Economics & Finance. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | `economics-finance` |
| Display Name | Economics & Finance |
| Parent Group | Business & Finance |
| Complexity Tier | High |
| Typical Word Count | 60,000–90,000 |
| Reader Expectation | Rigorous analysis made accessible; data-driven insights with clear methodology |
| Tone Baseline | Intellectually engaging, analytically precise, avoids both academic dryness and oversimplification |

## Subcategory Options

When the user selects this category, prompt for a subcategory. Each subcategory adjusts structural emphasis and source expectations.

| ID | Subcategory | Focus | Typical Structure |
|----|------------|-------|-------------------|
| `macroeconomics` | Macroeconomics | Monetary/fiscal policy, inflation, employment, GDP, trade balances | Thematic chapters building from fundamentals to current debates |
| `behavioural-economics` | Behavioural Economics | Cognitive biases, decision-making, nudge theory, experimental findings | Phenomenon-per-chapter with research summaries and real-world applications |
| `economic-history` | Economic History | Financial crises, trade evolution, institutional development, long-run trends | Chronological or thematic narrative with analytical commentary |
| `international-finance` | International Finance | Currency markets, global capital flows, sovereign debt, trade policy | Systems-level analysis with country-specific case studies |
| `development-economics` | Development Economics | Poverty, aid effectiveness, institutional quality, growth models | Problem-intervention-evidence structure with field research |

### Subcategory Defaults

- If no subcategory is selected, default to `macroeconomics`.
- If the user's brief spans multiple subcategories, select the dominant one and note secondary influences in the structural plan.

## Structural Architect Instructions

### Core Model: Data-Driven Analysis

Every chapter in an economics/finance book should follow this analytical engine:

1. **Question**. Open with a clear, specific economic question or puzzle. The reader must understand what this chapter investigates and why it matters.
2. **Evidence**. Present data, research findings, and historical examples that address the question. Show the reader the evidence before drawing conclusions.
3. **Analysis**. Interpret the evidence through one or more economic frameworks. Explain competing interpretations where they exist.
4. **Implications**. Draw out what the findings mean for policy, markets, individuals, or future research.

### Chapter Architecture

```
Chapter [N]: [Title Framing the Central Question]

  Opening Puzzle (400–600 words)
    → Surprising fact, historical anecdote, or counterintuitive data point
    → Central question clearly stated

  Section 1: Setting the Stage (1,500–2,500 words)
    → Historical or institutional context
    → Key definitions and concepts required for the chapter
    → Why conventional wisdom may be incomplete or wrong

  Section 2: The Evidence (2,500–4,000 words)
    → Primary data presentation (charts described, studies summarised)
    → Multiple sources of evidence triangulated
    → Acknowledgement of data limitations

  Section 3: Competing Explanations (1,500–2,500 words)
    → Present at least two interpretive frameworks
    → Evaluate strengths and weaknesses of each
    → Author's reasoned position with caveats

  Section 4: So What? (1,000–2,000 words)
    → Policy implications
    → Market or investment implications (if applicable)
    → What remains unknown or debated

  Chapter Summary (200–400 words)
    → Key findings (3–5 bullet points)
    → Bridge to next chapter
```

### Book-Level Arc

- **Part I (Chapters 1–3):** Establish the core question, provide necessary background, introduce the analytical framework.
- **Part II (Chapters 4–8):** Progressive evidence chapters, each examining a facet of the central thesis.
- **Part III (Chapters 9–11):** Synthesis, policy implications, and forward-looking analysis.
- **Conclusion:** Summary of findings, areas of uncertainty, and call for further inquiry.

### Special Structural Elements

- Include a **Glossary** of economic and financial terms as an appendix.
- Each chapter should include at least one **data visualisation description** (chart, graph, or table) that the production team can render.
- Where relevant, include **Historical Sidebar** boxes (300–500 words) connecting current dynamics to past episodes.

## Content Writer Craft Rules

1. **Voice:** Authoritative and precise. Write for an intelligent general reader, not a specialist. Imagine explaining to a well-read friend who does not have an economics degree.
2. **Data Integration:** Never present a number without context. Every statistic needs a comparison point (historical trend, cross-country comparison, or benchmark). "Inflation rose to 8.5%" is insufficient; "Inflation rose to 8.5%, its highest level since 1981" gives context.
3. **Model Explanation:** When introducing an economic model or theory, explain the intuition first in plain language, then add technical detail for readers who want it. Use footnotes or sidebars for equations.
4. **Narrative Anchors:** Ground abstract economic concepts in human stories. Every chapter should feature at least one real person. a policymaker, an entrepreneur, a worker, a household. whose experience illustrates the economic forces at play.
5. **Intellectual Honesty:** Present disagreements among economists fairly. Do not straw-man opposing views. Identify where the author's position sits in the professional spectrum.
6. **Temporal Precision:** Always specify time periods for economic data. "GDP grew by 3%" is meaningless without a year or quarter.
7. **Causation vs. Correlation:** Explicitly flag when evidence shows correlation rather than causation. Use language like "associated with" rather than "caused by" when appropriate.
8. **Jargon Policy:** Define all technical terms on first use. Maintain a running terminology awareness. do not assume the reader remembers a definition from three chapters ago. Brief reminders are acceptable.
9. **Paragraph Discipline:** Keep paragraphs to 4–6 sentences. Use subheadings every 600–900 words. Data-heavy sections benefit from shorter paragraphs.
10. **Transitions:** Each section should end with a sentence that points toward the next section's question or evidence.

### Prose Rhythm Mapping

Chapter 1 opens with the paradox or crisis that makes economics human. Not with
a definition. Not with a model. With a moment. a bread line, a bank run, a
price that made no sense. that forces the reader to ask: how did this happen?

Medium sentences (15-22 words) are the workhorse. They carry data, narrative,
and analysis without exhausting the reader or oversimplifying the economics.
Resist the pull toward long academic constructions. Resist equally the pull
toward staccato oversimplification. The medium sentence is the sweet spot for
rigorous-yet-readable economic prose.

Data must arrive through narrative, not tables. "By Tuesday afternoon, the
spread had widened to 300 basis points" is prose. A table is not. When a
number appears, embed it in a sentence that gives it human consequence. The
reader should feel the number before they analyse it.

Tension minimum: 4. Economic writing earns tension through stakes, not jargon.
The reader must understand who loses if this goes wrong. Whose savings. Whose
jobs. Whose country. Abstract economic forces become concrete through the people
they act upon.

Pacing guideline: open with the human moment, then pull back to the systemic
view. The first three paragraphs should read like journalism. By the fourth
paragraph, the analytical framework begins to emerge. but gently, as
explanation for what the reader has already witnessed. Let the reader feel
the puzzle before you hand them the tools to solve it.

## Quality Check Criteria

The Quality Check agent must verify the following for economics and finance category manuscripts:

| # | Criterion | Pass Condition |
|---|-----------|----------------|
| 1 | Data Accuracy | All statistics, dates, and figures are verifiable against cited sources |
| 2 | Source Currency | Economic data is the most recent available unless historical analysis requires older data |
| 3 | Model Transparency | Every economic model or theory is explained with its assumptions and known limitations |
| 4 | Balance of Views | Chapters presenting debated topics include at least two perspectives with fair treatment |
| 5 | Causation Discipline | No unqualified causal claims without supporting evidence (e.g., randomised studies, natural experiments, or robust econometric analysis) |
| 6 | Prediction Avoidance | No forecasts presented as certainties; all forward-looking statements are clearly labelled as projections or scenarios |
| 7 | Glossary Completeness | Every technical term used in the text appears in the glossary |
| 8 | Visual Data Integrity | Chart/graph descriptions match the data cited in the text; no misleading axis scales or cherry-picked date ranges |
| 9 | Accessibility | A non-specialist reader can follow the main argument without requiring external references |
| 10 | Structural Coherence | The book builds a cumulative argument; no chapter is a standalone essay disconnected from the arc |

## Source Requirements

### Minimum Source Thresholds

- **Per chapter:** Minimum 8 distinct sources.
- **Per book:** Minimum 60 unique sources across the manuscript.
- **Academic/research sources** (peer-reviewed journals, working papers, institutional reports): At least 40% of total.
- **Official data sources** (central banks, statistical agencies, international organisations): At least 20% of total.
- **Journalistic sources:** Permitted for narrative colour and contemporary context, not as sole evidence for economic claims.

### Acceptable Source Types

| Type | Examples | Notes |
|------|----------|-------|
| Academic journals | AER, QJE, Econometrica, Journal of Finance | Required for theoretical and empirical claims |
| Working papers | NBER, CEPR, IMF Working Papers, World Bank Policy Research | Acceptable if from recognised institutions; note "working paper" status |
| Official data | BLS, ONS, Eurostat, World Bank WDI, IMF WEO | Preferred for all macroeconomic statistics |
| Central bank publications | Fed, ECB, BoE speeches, minutes, research | Primary source for monetary policy analysis |
| Industry/financial data | Bloomberg, FRED, Refinitiv | Acceptable for market data |
| Books | Published economics books by credentialed authors | For historical context, intellectual lineage |
| Journalism | FT, The Economist, WSJ, Bloomberg | For narrative context; must be cross-referenced for factual claims |

### Prohibited Sources

- Wikipedia as a primary source.
- Unattributed blog posts or opinion pieces without author credentials.
- Partisan think-tank reports presented as neutral analysis (may be cited if affiliation is disclosed).
- Social media posts as evidence for economic claims.
- Cryptocurrency promotional materials or white papers presented as independent analysis.

## Category-Specific Guardrails

### Statistical Integrity

- All statistics must be **sourced** to a specific publication, dataset, or report with a retrievable reference.
- When presenting aggregate statistics (e.g., "average income"), specify the **measure** (mean, median, mode), the **population**, and the **time period**.
- Do not use relative statistics ("doubled") without providing the absolute baseline.

### Model Limitations

- Every economic model or theory presented must include an explicit statement of its **assumptions** and **known limitations**.
- Do not present any single model as the definitive explanation. Acknowledge where models disagree and why.
- When using simplified models for accessibility, note the simplification: "This is a simplified representation; the full model also accounts for..."

### Prediction and Certainty

- **Never present economic predictions as certainties.** All forward-looking statements must use conditional language ("If current trends continue," "Under this scenario," "Models suggest").
- When citing forecasts from institutions (IMF, OECD, etc.), note the institution's historical forecast accuracy where relevant.
- Distinguish between **scenarios** (possible futures) and **forecasts** (probability-weighted expectations).

### Political Neutrality

- Present economic policy debates with analytical balance. Do not advocate for a political party or ideology.
- When the author's analysis favours a particular policy approach, state the reasoning transparently and acknowledge counter-arguments.
- Avoid politically loaded language ("socialist," "neoliberal") unless defining it precisely in context.

### Financial Advice Boundary

- This is an educational and analytical work, not investment advice. Include a clear disclaimer.
- Do not recommend specific financial instruments, stocks, or investment strategies.
- Historical financial performance data must be accompanied by the note that past performance does not guarantee future results.

## Cover Design Specifications

| Element | Specification |
|---------|---------------|
| Typography | Serif or modern sans-serif title; clean, intellectual aesthetic. Author name with credentials if prominent (e.g., "Professor," "Former [Role]"). |
| Colour Palette | Sophisticated, muted tones. deep blue, slate grey, forest green, burgundy. White or cream backgrounds acceptable. Avoid bright or playful colours. |
| Imagery | Abstract data visualisations, geometric patterns, or symbolic imagery (scales, graphs, currency motifs rendered artistically). No literal photographs of money or stock tickers. |
| Layout | Title dominant. Subtitle essential. should communicate the book's specific angle. Author credentials or institutional affiliation below author name if notable. |
| Subtitle | Required. Format: "How [Topic] Shapes [Broader Outcome]" or "The [Adjective] Story of [Economic Phenomenon]." |
| Endorsement | One endorsement from a recognised economist, financial journalist, or policymaker on front cover if available. |
| Spine | Title + Author. Must be legible at thumbnail size. |
| Back Cover | 3–4 bullet points summarising key insights, one or two endorsement quotes, brief author bio emphasising credentials, barcode. |

## KDP Category Mapping

### Primary Category Path

```
Kindle Store > Kindle eBooks > Business & Money > Economics
```

### Secondary Category Path (select based on subcategory)

| Subcategory | Recommended Secondary KDP Category |
|------------|-------------------------------------|
| `macroeconomics` | Business & Money > Economics > Macroeconomics |
| `behavioural-economics` | Business & Money > Economics > Behavioural Economics |
| `economic-history` | Business & Money > Economics > Economic History |
| `international-finance` | Business & Money > Economics > International Economics |
| `development-economics` | Business & Money > Economics > Development & Growth |

### Keyword Recommendations

- Use 7 keyword slots in KDP.
- Include: primary economic topic, subcategory term, key theory or framework name, target audience descriptor, comparable author name (if applicable), outcome-oriented phrase, related policy or market term.
- Example set: `economics`, `macroeconomics explained`, `monetary policy`, `economic history`, `financial crises`, `behavioural economics`, `global economy`.

### BISAC Codes

| Code | Description |
|------|-------------|
| BUS039000 | BUSINESS & ECONOMICS / Economics / General |
| BUS039020 | BUSINESS & ECONOMICS / Economics / Macroeconomics |
| BUS069030 | BUSINESS & ECONOMICS / Economics / Comparative |
| BUS023000 | BUSINESS & ECONOMICS / Economic History |
| BUS027000 | BUSINESS & ECONOMICS / Finance / General |
