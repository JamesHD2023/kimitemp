---
name: research-bible
description: "Research Bible generation protocol — the non-fiction equivalent of Story Bible"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Research Bible Generation Protocol

## Overview

The Research Bible is the non-fiction equivalent of the fiction Story Bible. It is the
canonical reference document for the entire project — topic scope, thesis, sources,
subject context, chapter outline, and authority voice profile all live here.

Every downstream agent (Structural Architect, Content Writer, verification agents,
editorial suite) reads from the Research Bible. If it's not in the Research Bible,
it doesn't exist in the project.

## Research Bible Integrity Rule — Always Full Content (MANDATORY)

**Every time the Research Bible is written, every section must contain
its complete current content. NEVER use elision placeholders or
references to a "previous version".**

Forbidden patterns in ANY Research Bible section:

- `*(Unchanged from previous version)*`
- `*(See original entries for...)*`
- `*(See previous draft...)*`
- `[content omitted — same as last draft]`
- `[see earlier version]`
- Any language that refers to a "previous version", "original",
  "prior draft", "earlier version", or "last draft" as a separate
  source the reader can consult

**Why (non-fiction specific stakes):** There is no "previous version"
on disk. The Research Bible is a single file. Every downstream agent
that reads it programmatically — Structural Architect, Content
Writer, Source Guardian, Evidence Auditor, Citation Keeper, Expert
Tracker, Argument Analyst, fact-checker — sees the placeholder, not
the content. For non-fiction this is even more serious than fiction:
a Section 4 (Key Sources) that reads *"Unchanged from previous
version"* leaves the Citation Keeper with no citations to verify and
the Content Writer with no attributions to anchor claims to. A
Section 7 (Key Figures) with the same placeholder lets the Expert
Tracker verify nothing, and misquotes can slip through as factual
errors.

**The rule:**

1. When editing the Bible, READ the existing file in full first.
2. Hold every section's content in memory.
3. Modify only the sections that need to change.
4. When writing the updated Bible, output every section's complete
   content — modified or not.
5. If a section is unchanged from the last read, COPY ITS VERBATIM
   CONTENT from the in-memory read into the new write. Do not
   compress to a shorthand marker. Do not write a reference back to
   a version that will no longer exist after your Write tool call
   returns.

**Elision is destruction, not preservation.** Writing
*"Unchanged from previous version"* deletes the content that was
previously there — because the previous version was the file you
are about to overwrite.

This rule applies to every Phase 2 generation (Foundation, Research
Architecture, Source Extraction, Entity Canon) AND to every later
update the user requests (*"add the new 2024 study to Section 4"*,
*"revise the thesis statement in Section 2"*, etc.). Partial updates
must rewrite the full file with every section's complete content.
The Write tool is not diff-aware — it replaces the file whole.

**Self-check before every Research Bible Write tool call:** Does any
section I'm about to write contain the string "previous version",
"original", "prior draft", "earlier version", or "see previous" as
a reference? If yes, STOP, retrieve the actual content from my
in-memory read of the existing Bible, and replace the placeholder
with the verbatim content. Only then write. For non-fiction, an
additional check: does any Section 4 (Sources), Section 7 (Key
Figures), or Section 6 (Timeline) entry contain elision? Those
sections feed the verification agents directly and their integrity
is load-bearing for fact-checking.

## When to Generate

- After Phase 1 (Interactive Setup) completes
- Before any chapter writing begins
- The Research Bible must be approved by the user before Phase 3 starts

## Phase 2A: Foundation

### System Prompt

```
You are a research architect specialising in {category} non-fiction. Your job is
to build the foundational Research Bible for a {length_tier} book.

Build a comprehensive, structured reference document that the Structural Architect
and Content Writer will use for every chapter. Accuracy and completeness are paramount.

Category: {category}
Subcategory: {subcategory}
Structure Type: {structure_type}
Target Audience: {audience_expertise_level}
Research Scope: {research_scope}
Citation Style: {citation_style}
```

### Required Sections

**1. Topic Scope**
- Central topic (1-2 sentences)
- Boundaries: what the book covers and what it explicitly excludes
- Why this book, why now — the gap it fills or the argument it makes
- One-sentence thesis statement

**2. Thesis / Central Argument**
- Primary thesis (the book's core claim or question)
- Supporting arguments (2-4 pillars that support the thesis)
- Counter-arguments the book must address
- Thematic question the book asks (the "so what?")

**3. Authority Voice Profile (MANDATORY)**

Build a voice profile for the author's non-fiction prose. This profile controls
how every chapter sounds and is loaded by the Structural Architect, Content Writer,
and Evidence Auditor for every chapter.

```
AUTHORITY VOICE PROFILE — {Author Name / Pen Name}

TONE POSITION:
  Academic ←——→ Conversational: [position on spectrum]
  Objective ←——→ Opinionated: [position]
  Formal ←——→ Intimate: [position]
  Cautious ←——→ Assertive: [position]

EVIDENCE INTEGRATION STYLE:
  [How the author weaves sources into prose — heavy citation / narrative
   integration / "trust me" expert / data-driven with visualisation cues]

SENTENCE ARCHITECTURE:
  [Typical patterns — complex analytical / short declarative / mixed /
   long flowing / fragmented for emphasis]
  Average sentence length tendency: [short / medium / long / varied]
  Paragraph length tendency: [short punchy / medium balanced / long flowing]

VOCABULARY LEVEL:
  [Specialist / Accessible-expert / Deliberately simple / Mixed by section]
  Jargon tolerance: [defines everything / assumes some knowledge / specialist only]

READER RELATIONSHIP:
  [Teacher / Guide / Peer / Provocateur / Storyteller / Analyst]
  How the author addresses the reader: [direct "you" / inclusive "we" /
   objective third person / personal "I"]

AUTHORITY MARKERS:
  [What signals this author's expertise — specificity of data, depth of
   sourcing, analytical frameworks, personal experience, credentials]

METAPHOR SOURCES:
  [Where the author draws analogies from — everyday life, science, sport,
   history, technology, nature, etc.]

EMOTIONAL REGISTER:
  [How the author handles emotion in non-fiction — analytical distance /
   controlled passion / raw honesty / dry wit / righteous anger]

VOICE CONTRAST SUMMARY (for multi-author or edited volumes):
  [What makes this voice immediately distinguishable from a generic
   non-fiction voice. The signature.]
```

**4. Key Sources & Evidence Base**
For each major source:
- Source name and type (book, paper, interview, archive, dataset)
- Author/institution and credentials
- What it contributes to the argument
- Reliability assessment (peer-reviewed, primary, secondary, anecdotal)
- Any bias or limitation to note
- Chapters where it's most relevant

**5. Subject Context**
- Historical period(s) covered
- Geographic scope
- Cultural/social context
- Field of study or industry
- Current state of knowledge/debate

**6. Timeline / Chronology**
- Key dates and events in chronological order
- If narrative non-fiction: the story's timeline
- If thematic: the chronological context for each theme
- Research timeline: when key discoveries or events occurred

**7. Key Figures**
For each real person central to the book:
- Full name and any name variations
- Birth/death dates (if relevant)
- Credentials and institutional affiliation
- Role in the book's argument (source, subject, expert, antagonist)
- Key quotes or positions attributed to them
- Relationship to other key figures
- Chapters where they appear

## Phase 2B: Research Architecture

### Required Sections

**8. Information Architecture**
- How the argument/information is revealed across the book
- Structure type implementation (chronological, thematic, problem-solution, etc.)
- Chapter-by-chapter flow: what each chapter contributes to the thesis
- Reader knowledge state at each chapter boundary

**9. Chapter Outline**
For each chapter:
```
Chapter {N}: "{Title}"
- THESIS CONTRIBUTION: What this chapter argues or establishes
- KEY SOURCES: [list of sources deployed in this chapter]
- KEY FIGURES: [real people who appear/are discussed]
- SECTIONS:
  - Section 1: [topic] — [source] — ~{N} words
  - Section 2: [topic] — [source] — ~{N} words
  - Section 3: [topic] — [source] — ~{N} words
- ARGUMENT POSITION: [where reader should be at chapter end]
- STRUCTURE BEAT: [which structural framework beat this chapter serves]
```

**10. Source Assignments**
Map every source to the chapters where it's used. This ensures:
- No source is cited without being in the Research Bible
- No chapter lacks source support
- Sources are distributed across the manuscript, not front-loaded

**11. Counter-Arguments & Objection Register**

For each major argument in the book, list its top 3-5 likely reader
objections. This is the structured register that tracks what readers
will push back on, where each objection is addressed, and how strong
the rebuttal is.

```
OBJECTION REGISTER:

Argument: {the book's claim}
  Objection 1: {what a sceptical reader would say}
    Addressed in: Ch {N}, para {approx}
    Rebuttal method: {refute / acknowledge / incorporate / complicate}
    Rebuttal strength: {strong / adequate / weak / unaddressed}
    Source supporting rebuttal: {citation}

  Objection 2: {next likely pushback}
    Addressed in: {chapter or "NOT YET ADDRESSED"}
    ...
```

**Rebuttal strength scoring:**
- **Strong:** Rebuttal cites peer-reviewed evidence or primary data
  that directly contradicts the objection
- **Adequate:** Rebuttal acknowledges the objection and provides a
  reasonable response, but doesn't eliminate it entirely
- **Weak:** Rebuttal is brief, dismissive, or relies on authority
  rather than evidence
- **Unaddressed:** The objection exists but the manuscript doesn't
  engage with it — this is a gap the Argument Analyst should flag

The Argument Analyst validates objection coverage per chapter. Any
major argument with an "unaddressed" objection is flagged as a
structural gap that must be resolved before editorial.

For each counter-argument or alternative perspective:
- The position
- Who holds it and why
- Where in the book it's addressed
- How the author responds (refute, acknowledge, incorporate, complicate)

**12. Research Gaps**
- What the author doesn't know yet
- Areas needing additional research
- Edge cases that require careful handling
- Potential factual landmines (contested claims, evolving science, political sensitivity)

### Category-Specific Research Bible Extensions (CONDITIONAL)

Load from the category bank file. Examples:
- **Memoir:** Emotional arc map, memory reliability notes, legal sensitivity for real people
- **True Crime:** Evidence chain, legal status of case, victim sensitivity protocol
- **Popular Science:** Replication status of key studies, expert consensus level per claim
- **Business:** Company verification data, financial claim sources, survival/selection bias notes
- **History:** Source hierarchy (primary > secondary), historiographic debates to acknowledge

### Output

Write to: `Ideorix-Projects/[Title]/engine-data/research-bible.md`

Phase 2C extracts sources to: `Ideorix-Projects/[Title]/engine-data/sources.md`

## Phase 2C: Source Extraction

### Protocol

After the Research Bible is complete, extract all key entities into a structured
database at `engine-data/sources.md`:

**Source entries:**
- Source name, type, author, date, reliability rating
- Key claims supported by this source
- Chapters where cited

**Figure entries:**
- Full name, credentials, role in book
- Key positions/quotes
- Chapters where referenced

**Organisation entries:**
- Name, type, founding date, relevance
- Chapters where referenced

**Claim entries:**
- The claim
- Supporting sources
- Confidence level (established fact / strong evidence / emerging / contested / author's analysis)
- Chapters where deployed

This structured database enables per-chapter Context Scoping — the Structural
Architect and Content Writer load only the entries relevant to the current chapter.

### Output

Write to: `Ideorix-Projects/[Title]/engine-data/sources.md`

---

## Entity Canon Lockfile (MANDATORY — Writer & Verifier input)

After source extraction, the Research Bible generator MUST also produce a
**flat, mechanical name lookup** used by the Content Writer's pre-load
and by the Source Guardian / Expert Tracker's canon-compliance check.
This is a separate file from `sources.md`, formatted for one purpose:
trivially-scannable name lookups that catch drift at a glance.

**Why this exists (production failure on the fiction side):** A fiction
manuscript had the father's canonical name set to "Matthew" in the Story
Bible character description, but Ch10 prose established "Mark". The
Continuity Guardian missed it because the Bible description was in
paragraph form, not a structured flat lookup. The drift carried through
3 chapters. The non-fiction equivalent is more serious: drift in a key
figure's name, a source author's name, or an institutional name is a
**factual error**. If a real scholar is listed as "Dr Jane Thompson" in
the Research Bible and the prose drifts to "Dr Jane Thomson", the book
has misattributed a quote. The entity canon lockfile prevents this.

### File location

`Ideorix-Projects/[Title]/engine-data/entity-canon.md`

### File format (non-fiction)

```markdown
# Entity Canon — {Title}
Last updated: Phase {N}, Chapter {N}
Lock level: HARD — every name in prose must match a row below.

## Key Figures (real people — Section 7)

| ID | Canonical Name | Also Known As / Credentials / Short Forms | Role | First appears |
|----|----------------|-------------------------------------------|------|---------------|
| fig.thompson_jane | Dr Jane Thompson | Jane Thompson, Thompson, the Harvard economist | Lead economist quoted | Ch 2 |

## Sources (Section 4 — works cited)

| ID | Canonical Title | Author(s) | Year | Short form used in prose | First appears |
|----|-----------------|-----------|------|--------------------------|---------------|
| src.thompson_2024 | The Labour Paradox | Thompson, Jane | 2024 | Thompson (2024) | Ch 2 |

## Organisations / Institutions

| ID | Canonical Name | Aliases / Short forms | Type | First appears |
|----|----------------|----------------------|------|---------------|
| org.lse | London School of Economics | LSE, the School | university | Ch 3 |

## Places (Section 5 — subject context)

| ID | Canonical Name | Aliases | Type | First appears |
|----|----------------|---------|------|---------------|

## NEW ENTITIES PENDING APPROVAL

(Populated by the Structural Architect when a new brief introduces an
entity not in the canon. User must approve each row before it is
promoted to the main tables. The Content Writer MAY NOT produce prose
for a chapter whose brief introduces a PENDING entity until the row is
approved.)

| Proposed by | Type | Canonical Name | Aliases | Context | Status |
|-------------|------|----------------|---------|---------|--------|
```

### Population rules

**At Phase 2 (Research Bible generation):** Research Bible generator
creates entity-canon.md with one row per Key Figure, Source, Institution,
and Place from the Research Bible. Every named figure gets a canonical
full name with credentials, a list of short forms the prose is
authorised to use, and a role description. Sources follow citation-style
conventions (e.g., "Thompson, Jane" for Chicago; prose short form is
"Thompson (2024)").

**Canonical name rules for non-fiction:**
1. The canonical name of a real person is **the most formal form used
   in the first prose reference** — usually first-reference includes
   credentials ("Dr Jane Thompson of the LSE") and subsequent references
   use a short form ("Thompson"). Both the canonical name and every
   approved short form must be in the aliases column.
2. **Never truncate names silently.** If the canon has "Dr Jane Thompson"
   and prose uses "Dr Jane Thomson" (typo), that is CRITICAL DRIFT, not
   a harmless variation. A misspelled real person's name is a factual
   error in non-fiction — it's worse than in fiction.
3. Source canonical form follows the project's citation style (MLA,
   Chicago, APA, or author-specified). Short forms used in prose (e.g.,
   "Thompson (2024)") go in the aliases column.
4. Institutions: canonical full name + approved short forms. "London
   School of Economics" canonical; "LSE" and "the School" as aliases.

**When entities are introduced mid-manuscript:**
1. The Structural Architect notices the brief introduces a figure or
   source not in the canon (e.g., a supporting quote from a previously
   uncited scholar)
2. The Architect adds a NEW ENTITIES PENDING APPROVAL row with its
   proposal for canonical name + credentials + aliases + source citation
3. At the User Review Gate (step 6), the user sees the pending entity
   and must approve. For a new source, the user also confirms the
   source is real and the citation is correct — non-fiction requires
   source-level due diligence, not just name approval.
4. On approval, the row moves to the main table. The Source Guardian
   also appends the source to the main sources.md ledger if it's new.
5. The Content Writer now sees the new canonical name in its pre-load.

**Update discipline:**
Same as fiction — write-rarely, read-every-chapter. Every update is
user-approved. Do NOT silently normalise a drift by updating the canon
to match the prose. The Source Guardian reports drift; the user decides
what the truth is; only user-approved changes update the file.

### Integration points

- **Content Writer pre-load** (`content-writer.md` + core-pipeline step
  6a Step B) — reads entity-canon.md and injects a flat quick-reference
  into the Writer's ENTITY CANON (HARD LOCK) block. Because real names,
  source titles, and institution names are frequently misquoted by
  LLMs, the flat table at the top of the prompt is the front-line
  defence.
- **Source Guardian + Expert Tracker** (`accuracy-gate.md` — see Canon
  Compliance Check) read the same file and run a mechanical
  extract-and-match pass on every proper noun in the chapter.
- **Pipeline checkpoint** tracks `Canon Check: {clean | {N} drift}`
  per chapter.

---

## Research Companion (Research Bible Only Mode)

If the user selected "Research Bible Only" in Phase 1, generate a Research Companion
document — a single .docx designed to sit beside the author while they write.

Structure:
- **Part 1: Your Book at a Glance** — Topic, thesis, scope, audience, structure
- **Part 2: Your Sources** — Annotated source list with what each contributes
- **Part 3: Your Key Figures** — Prose profiles of each real person in the book
- **Part 4: Your Argument** — Chapter-by-chapter outline with evidence assignments
- **Part 5: Category Craft Notes** — Writing advice specific to this category
- **Part 6: When You're Done** — Instructions for bringing the manuscript back

Write to: `Ideorix-Projects/[Title]/manuscript/research-companion.docx`
