---
name: craft-fundamentals-nonfiction
description: "Universal mechanical craft fundamentals for non-fiction prose. Engine-specific to the NF engine (forked from the fiction craft-fundamentals.md in v2.7.45 because the fiction version's suspense/POV/atmospheric-description framing didn't apply to non-fiction's argument-rhythm/authority-voice/evidence-pacing concerns). Loaded into every Content Writer call as a standard craft reference. Covers argument tension, evidence pace modulation, detail tiers, authority-voice control, and chapter/book endings."
version: "2.7.45"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*


# Craft Fundamentals (Non-Fiction)

This file consolidates universal mechanical craft principles
that apply to every paragraph, every chapter, every non-fiction
project. Loaded into the Content Writer prompt's
`{craft_fundamentals_load}` slot for every Writer call.

The five sections below are orthogonal. Each addresses a
different mechanical problem in argument-level prose generation.
Apply all five in parallel; none conflicts with the others.

These fundamentals SUPPLEMENT the category file's craft rules
and the dopamine-ladder universals. Where this file's guidance
overlaps with category-specific guidance, the more specific
rule wins.

---

## 1. Argument Tension

Non-fiction's analogue to fiction's suspense. A reader keeps
reading because the argument keeps a tension alive — a question
posed that hasn't yet been answered, a contradiction surfaced
that hasn't been resolved, a stake established that hasn't been
paid off. Tension is what makes prose feel like it's going
somewhere even when no character is in danger.

### At the sentence level

- Open with the question the paragraph will answer. Not the
  answer. Not "This chapter explains X." Open with the
  question X is the answer to.
- Plant the contradiction before you resolve it. Two sentences
  apart: "[the conventional view]." → "[but the data show
  otherwise]." The space between them is the tension.
- Withhold the conclusion until you've earned it. A claim made
  on page 1 of a chapter has nothing left to deliver on page
  10. A claim made on page 10 lands.

### At the paragraph and scene level

- Each paragraph should leave the reader with at least one
  unresolved beat the next paragraph addresses. Beat = a
  question, a tension, a "but wait", a counter-claim, a hook.
- Do not chain "and then..." paragraphs. Each paragraph that
  doesn't advance the argument is dead weight; cut it.

### At the chapter level

- Open the chapter with the question the chapter will close
  by answering.
- Plant the counter-argument in the first third. Address it
  in the middle. Resolve it (or acknowledge it stands) by the
  end.
- Close with the next chapter's question, not this chapter's
  answer.

### At the book level

- The book's central thesis must be a contested claim, not an
  obvious one. Obvious claims do not earn 60,000 words.
- The book's argument arc has setup (Why this question
  matters), evidence-build (the case), counter-argument
  engagement (the strongest objections, fairly stated), and
  resolution (what we now know).

### What this means for the Writer

- Do NOT open paragraphs with "In this section we will
  examine…" or "This chapter argues that…" — these surface
  the conclusion before the tension.
- DO open paragraphs with the question, the contradiction,
  the surprising data point, or the case that brings the
  question to life.
- Every paragraph the Writer produces must pass the test:
  "what's the unresolved beat at the end of this paragraph
  that pulls the reader into the next?"

---

## 2. Evidence Pace Modulation

Non-fiction prose alternates between **fast** (claim-and-move-on)
and **slow** (extended evidence, case study, demonstration).
Mismanagement produces either: (a) a wall of un-evidenced
assertions that read as hot takes; or (b) a slog of evidence
without claim that loses the reader.

### Slow stuff fast

Some material is non-essential context: dates, names of
secondary sources, definitions of well-known terms, brief
historical background. Move through it quickly. Two sentences,
not two paragraphs. The reader does not need every actor's
biography to follow the argument.

Signature: "X (a [one-clause description]) [verb]ed [the
relevant action]. The [next thing happened]." Move on.

### Fast stuff slow

Some material is the chapter's load-bearing evidence: the case
study that demonstrates the thesis, the data point that
contradicts the conventional view, the testimony that brings
the abstract to life. Slow down. Give it the page-time its
weight requires.

Signature: case studies get full paragraphs. Key data points
get explicit unpacking. Testimony gets quoted verbatim plus
context. The reader's attention is being asked for; pay it
back by making the moment land.

### The rule of contrast

A chapter that runs fast for 80% of its length must slow down
for 20% to give the evidence its weight. A chapter that runs
slow for 80% of its length must speed up for 20% to keep
momentum. The Writer chooses where to invest.

### Diagnostic

If the chapter reads as a list of un-evidenced claims, you
have not slowed down enough for the load-bearing evidence.
If the chapter reads as a slog of details without payoff, you
have not sped up enough through the context.

---

## 3. Detail Tiers

Every non-fiction passage operates at one of three detail
tiers. Mixing tiers without intent produces prose that feels
either thin (all Tier 1) or bogged down (all Tier 3).

### Tier 1 — Anchoring detail

The minimum specificity required to ground the reader in the
case being made. Names, dates, places, single attribution. One
sentence each.

> "In 1957, the U.S. Surgeon General's office reviewed the
> emerging cancer-and-tobacco data."

This locates the reader. Use frequently and lightly.

### Tier 2 — Demonstrating detail

The detail that makes the claim land. The specific patient's
case in a medical book, the specific testimony in a history
book, the specific business pivot in a strategy book. Two to
five sentences.

> "Hammond followed 187,766 men over twenty months. The
> heaviest smokers died at twenty-four times the rate of
> non-smokers. Even moderate smokers died at thirteen times
> the rate. The data was incompatible with chance."

This earns the claim. Use deliberately at every chapter's
load-bearing moment.

### Tier 3 — Methodological detail

The detail that establishes the author's authority — citation,
source caveat, methodological note, limitation acknowledgment.
Footnote-length usually; in-prose where the reader needs to
trust the claim.

> "The study had limitations: it was observational, not
> randomised; the cohort skewed male and Western. Subsequent
> randomised work (mostly on animal models) confirmed the
> association without fully resolving the causal mechanism."

This builds trust. Use sparingly, where it matters.

### What to cut — superfluous detail

Detail that does not anchor, demonstrate, or methodologically
ground is decoration. Cut it. Specifically:
- Biographical detail of secondary actors who don't appear
  again
- Comprehensive lists of related-but-not-central work
- Hedging that doesn't add nuance
- Definitions of terms a literate reader already knows

### Sensory specificity over inventory

When sensory detail is used (rare in NF but legitimate in
narrative non-fiction), one telling specific detail beats a
catalogue. "The library smelled of cedar shelving and pipe
tobacco" beats "the library was old, full of books, with a
distinctive aroma".

---

## 4. Authority-Voice Control

Non-fiction's analogue to fiction POV. The narrator is the
author, but the author has different voices available — and
the choice of voice affects how the reader reads every claim.

### The three voice options

| Voice | Position | Best for |
|---|---|---|
| **Authoritative** | "Here is what we know." | Reference, business, academic |
| **Investigative** | "Here is what I found." | Journalism, narrative NF, popular science |
| **Reflective** | "Here is what I think and why." | Essay, opinion, popular philosophy |

### The consistency rule

Pick a voice and hold it. Drift between voices in the same
chapter produces prose that reads as unsure of itself. A
chapter that opens authoritative and slides into reflective
loses the reader's trust in the authority of the opening.

### Voice and evidence rhythm

- Authoritative voice carries claims; the evidence is in the
  footnotes.
- Investigative voice carries the narrative of finding the
  evidence; the evidence is in the prose.
- Reflective voice carries the reasoning; the evidence is
  the writer's experience and judgment.

A book can mix voices across chapters but each chapter should
be tonally consistent.

### What this means for the Writer

- Determine the chapter's voice from the category file and
  the project's authority profile (`engine-data/authority.md`).
- Do not slip into a different voice mid-chapter.
- Quote attribution must match the voice: authoritative voice
  uses minimal attribution ("The data show"); investigative
  voice uses full attribution ("Hammond's 1957 cohort
  study..."); reflective voice uses personal attribution
  ("I have come to think that...").

---

## 5. Chapter and Book Endings

Endings are where retention is won or lost. A good ending
makes the reader want the next chapter. A weak ending makes
them put the book down.

### Chapter endings — the three patterns

| Pattern | Function | When to use |
|---|---|---|
| **Synthesis** | Summarise the argument the chapter built | When the next chapter starts a new thread |
| **Turn** | Hand off a new tension to the next chapter | When the argument is continuous |
| **Beat** | Close on a single image / observation / line | When emotional resonance is the goal (narrative NF, memoir) |

### What not to end on

- A list of bullet points (kills momentum)
- "In the next chapter, we will examine..." (the wrong kind of
  forward link — replace with a question or a tension)
- A long quotation (gives the last word to someone else)
- A platitude or homily ("And so we see that hard work matters")

### Book endings — the three deliverables

A book's final chapter must deliver:

1. **The full resolution of the central thesis** — what the
   book set out to argue, now argued in full
2. **The reader's takeaway** — what to do with what they now
   know (action, perspective shift, framework)
3. **The unsettled remainder** — what the book does NOT
   resolve, what remains open, what the next book / next
   conversation must address

A book that resolves everything fails to invite continued
engagement. A book that resolves nothing fails to land. The
ratio is roughly 70% resolution / 20% takeaway / 10%
unsettled remainder.

### What this means for the Writer

- The chapter brief should specify which ending pattern the
  chapter uses.
- The final chapter's outline must explicitly allocate the
  three book-ending deliverables.
- A chapter draft that closes with a list, a platitude, or a
  "next chapter we'll discuss..." pointer fails this fundamental
  and must be revised.

---

## See Also

- `dopamine-ladder.md` — Universal engagement diagnostic with
  NF-categories table
- `core-pipeline.md` — Master workflow that invokes this file
- The category file selected at project start — category-
  specific craft rules that supplement (and where conflict,
  override) these universal fundamentals
- `prose-humaniser.md` — Post-Writer pass that catches the
  AI-isms these fundamentals' "what not to do" lists describe
