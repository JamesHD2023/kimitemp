---
name: nature-writing-category
description: "Category-specific instructions for nature writing non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Nature Writing. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | nature-writing |
| Display Name | Nature Writing |
| Parent Group | Travel & Nature (and Science & Math > Nature & Ecology where the science is foreground) |
| Typical Word Count | 60,000–90,000 (essay-collections often 50,000–70,000; place-portrait and species-portrait books often 70,000–100,000; comprehensive natural-history works can run 100,000+) |
| Default Structure | Seasonal / cyclical / thematic spine reflecting natural rhythms; close observation as the core technique (specific, detailed, patient); progression from observation → ecological context → reflection within most chapters; science and lyric coexist without either dominating |
| Citation Style | Scientific names (Latin binomials) on first reference for species; named taxonomists / scientists for biological claims; field guides and authoritative reference works cited; peer-reviewed research for ecological / climate / conservation claims; indigenous knowledge holders explicitly credited where their knowledge is referenced; endnotes mandatory for any claim beyond the author's direct observation |
| Audience Baseline | Reader interested in the natural world, with varying technical depth; from contemplative-literary reader (essay / philosophical / nature-memoir) to active-naturalist reader (species-portrait / observation) to environmentally-engaged reader (conservation / climate). Audience named so reader self-selects; technical depth calibrated accordingly |
| Comparable Titles | Annie Dillard (*Pilgrim at Tinker Creek*), Rachel Carson (*Silent Spring*, *The Sea Around Us*), Aldo Leopold (*A Sand County Almanac*), Robert Macfarlane (*The Wild Places*, *Landmarks*, *Underland*), Helen Macdonald (*H is for Hawk*, *Vesper Flights*), Barry Lopez (*Arctic Dreams*, *Of Wolves and Men*), Peter Matthiessen (*The Snow Leopard*), Edward Abbey (*Desert Solitaire*), Robin Wall Kimmerer (*Braiding Sweetgrass*), Suzanne Simard (*Finding the Mother Tree*), David George Haskell (*The Forest Unseen*, *The Songs of Trees*), Bernd Heinrich (*Mind of the Raven*, *Winter World*), Sy Montgomery (*The Soul of an Octopus*), Carl Safina (*Beyond Words*), Kathleen Jamie (*Sightlines*, *Findings*), Mary Oliver (*Upstream*), Terry Tempest Williams (*Refuge*), Wendell Berry (essays) |

## Subcategory Options

When the user selects Nature Writing, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| natural-history-observation | Natural History / Observation | Detailed study of species, ecosystems, landscapes through close patient observation; the Dillard / Macfarlane / Haskell tradition; observation-as-method central | Seasonal or thematic chapter spine; each chapter anchored to specific observed phenomena; science woven into observation rather than imposed; long contemplative paragraphs; reader is taught to see |
| species-portrait | Species Portrait / Animal Behaviour | Sustained engagement with a single species or species-group — birds, octopuses, ravens, wolves, trees as protagonists; the Macdonald / Montgomery / Heinrich / Safina lineage | Subject-as-character structure (the species is the protagonist); behaviour-and-evolutionary-context chapters; named individual animals where the author has known them; arc often follows the author's deepening understanding of the subject |
| place-portrait-landscape | Place Portrait / Landscape | Deep sustained connection to a specific place — Abbey's desert, Lopez's Arctic, Berry's Kentucky, Jamie's Scotland; landscape-as-protagonist | Place-led chapter spine; geological / ecological / human-history layers of the place; seasonal cycles often as structural backbone; long residency or repeated visits as the authority basis |
| conservation-environmental | Conservation / Environmental | Environmental urgency combined with natural observation; the Carson lineage updated for climate crisis; eco-criticism and eco-grief and pathways-of-engagement | Threat / system-under-stress chapter spine; observation establishes what's being lost or transformed; scientific evidence on threats and mechanisms; activism / hope / agency considered honestly; avoids both eco-doom and false-balance |
| nature-memoir | Nature Memoir | Personal experience (often grief, illness, transition, displacement) refracted through sustained natural observation; the Macdonald *H is for Hawk* / Williams *Refuge* lineage | Memoir conventions in service of nature-writing observation; outer-natural-world and inner-emotional-world braided; transformation arc anchored in both; species or place as second protagonist of the personal story |
| philosophical-contemplative | Philosophical / Contemplative | Nature as lens for larger questions about meaning, time, mortality, attention; the Oliver / Berry / Thoreau lineage; essay-form often dominant | Essay or essay-cycle structure; observation occasions reflection rather than the reverse; literary essay tradition (Berry, Oliver, Annie Dillard's Holy the Firm); shorter chapters / discrete pieces |
| indigenous-tek | Indigenous Knowledge / Traditional Ecological Knowledge | Nature writing centred in indigenous knowledge systems — Kimmerer, Tyson Yunkaporta, Vine Deloria, Indigenous-led environmental writing; written from inside indigenous traditions, in collaboration, or with explicit acknowledgement of the framing | Traditional knowledge as evidence-base alongside Western science (the "two-eyed seeing" framing); land acknowledgement and naming conventions per community preference; community-consent disclosure; reciprocity and gift-economy framings often central |

**Default:** If the user does not specify, prompt for the book's mode
(observation-led / species-portrait / place-portrait / conservation-led /
memoir-led / philosophical / indigenous-led) and select accordingly;
fallback to `natural-history-observation` for unclear cases.

## Structural Architect Instructions
```
STRUCTURE
- Thematic or seasonal/cyclical organisation reflecting natural rhythms
- Close observation is the core technique. specific, detailed, patient
- Builds from observation to ecological insight to philosophical reflection
- Science and poetry coexist. neither dominates

CATEGORY ARCHITECTURE
- The natural world must be rendered through DIRECT observation, not abstraction
- Scientific accuracy underpins lyrical prose
- Indigenous/traditional ecological knowledge attributed and contextualised
- Environmental urgency must not cross into despair-without-agency

FORBIDDEN
- Anthropomorphising animals without scientific basis
- Species misidentification
- Romanticising nature while ignoring environmental destruction
- Appropriating indigenous ecological knowledge without attribution
```

## Content Writer Craft Rules
```
VOICE & TONE
- Contemplative, precise, often elegiac. the naturalist as witness
- Sensory detail paramount: what does the moss feel like, what does the dawn sound like
- Scientific precision combined with lyrical beauty
- The author is both observer and participant
```

### Prose Rhythm Mapping

Chapter 1 opens with the landscape or creature, observed with precision. Not
named and categorised. observed. The reader sees before they understand.
A movement in the bracken. The shape of a wing against grey sky. The texture
of bark under a hand. Observation is the first act of nature writing.

Medium-long contemplative sentences (18-28 words) set the pace. Nature writing
earns its slow rhythm because the natural world rewards patience. The prose
must model the attention it asks of the reader. unhurried, detailed, willing
to stay with a single image until it yields its meaning.

Scientific accuracy and lyrical observation coexist without tension. The Latin
name and the metaphor can live in the same paragraph. "The peregrine falcon
(Falco peregrinus) folded and dropped. a dark syllable falling through the
grammar of the sky." Precision serves beauty. Beauty serves understanding.

Patience in the prose is essential. Nature writing that rushes fails the genre.
Let a description of a single tree take a full paragraph. Let the dawn arrive
over three sentences. The reader who has picked up this book has chosen slowness.
Honour that choice.

Tension minimum: 3. The tension in nature writing is attention itself. the
slow revelation of what careful observation uncovers. It can also be ecological:
the marsh that is shrinking, the species that is vanishing, the silence where
birdsong once was.

Pacing guideline: open with close observation (long contemplative sentences,
20-28 words). Hold the reader in the sensory moment for three to four
paragraphs. Let the scientific or ecological context emerge from the
observation. never imposed from outside, always arising from what is seen.
A shorter sentence can punctuate the longer flow, but sparingly. The rhythm
is the rhythm of walking through a landscape. Steady. Attentive. Unhurried.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Species identification accurate | Every species named is correctly identified; common name used per the regional / cultural convention; Latin binomial given on first reference where the book engages substantively with the species; misidentification anywhere in the book damages the book's whole credibility |
| 2 | Natural-history claims accurate | Behaviour, ecology, evolutionary context, range, status claims about species and ecosystems trace to current natural-history scholarship; folk biology not presented as current science; one-off observations distinguished from documented species patterns |
| 3 | Scientific claims sourced | Ecological, climate, geological, evolutionary, biogeographical claims trace to peer-reviewed literature or authoritative reference works; popular-press summaries verified against primary research; "studies show" without citation unacceptable |
| 4 | Anthropomorphism disciplined | Animal behaviour described with care: sensory and behavioural specificity is welcome ("the raven returned to the carcass three times" / "the wolf's gaze tracked the elk"); ascribing human emotional or cognitive states ("the otter was happy", "the tree wanted to grow toward the light") only where the science supports the framing or where the author flags it explicitly as anthropomorphic shorthand |
| 5 | Observation specific and original | Sensory detail describes THIS encounter with THIS landscape / animal / plant (the specific lichen on this rock, the specific dawn over this estuary), not generic nature-writing palette ("majestic", "primal", "ancient", "untouched"); cliché nature description fails the genre's signature requirement |
| 6 | Climate / ecological honesty | Where the book's subject is affected by climate change, habitat loss, biodiversity decline, pollution, the book engages this honestly; "pristine" / "untouched" / "stable" framings of ecosystems actually under stress avoided; the romanticisation-or-doom-loop trap navigated |
| 7 | Indigenous knowledge attributed | Where the book draws on traditional ecological knowledge, indigenous land-management practice, or knowledge systems originating with indigenous peoples, attribution is named and explicit (community / nation / individual knowledge holder); appropriation without attribution is a category-defining failure |
| 8 | Wilderness / anthropocene framing engaged | "Wilderness" framings (untouched, pristine, beyond human influence) are now contested in nature writing; the book either acknowledges that most "wild" places are inhabited / managed / shaped by humans (often by indigenous peoples for millennia) or addresses the wilderness concept as the contested category it is |
| 9 | Naturalist-vs-scientist distinction maintained | The author's own observations (legitimate amateur natural-history) are framed as such; credentialed scientific claims trace to credentialed sources; citizen-science contributions where relevant are credited; the prose distinguishes "I have watched this happen" from "research has established this happens" |
| 10 | Reader's attention rewarded | The chapter's slow patient observation pays off — the reader who slows down to the prose's pace receives something they would not have noticed on their own; the prose models the attention it asks of the reader rather than just demanding it |

## Source Requirements

### Mandatory Source Types

- **Author's direct observation.** The author has observed the
  natural phenomena they write about, with the patience and
  duration the prose implies. Nature writing's authority is
  observational; books that synthesise without seeing fail the
  category's contract with the reader. Where observation is
  occasional rather than sustained, this is disclosed.
- **Peer-reviewed scientific research.** For ecological,
  evolutionary, biogeographical, behavioural, climate,
  geological, and physiological claims — claims trace to
  peer-reviewed work in the relevant discipline. Popular-press
  framings of science verified against primary research before
  citation; popular framings often outpace or distort the
  underlying findings (the "wood wide web" mycorrhizal-internet
  framing is a current example warranting care).
- **Authoritative field guides and reference works.** For species
  identification, range, status, life history — recognised field
  guides per region (Sibley, Peterson, Collins, Crossley for
  birds; relevant regional guides for plants, mammals, herps,
  invertebrates), monographs, and natural-history references.
  Scientific names verified against current taxonomic authority
  (e.g. IOC for birds, Catalogue of Life, ITIS, regional
  authorities) — taxonomy revises and a 1990s name may have
  been superseded.
- **Conservation status data.** For status claims — endangered,
  threatened, recovering, extinct — the IUCN Red List,
  national / regional conservation listings (USFWS endangered-
  species listings, JNCC, equivalents in other jurisdictions),
  and recent population assessments. Status changes; the book's
  status claims are dated.
- **Indigenous knowledge holders and community sources.** Where
  the book draws on traditional ecological knowledge, indigenous
  land-management practice, indigenous taxonomies, or community-
  held knowledge of place — the relevant nation / community is
  named, knowledge holders credited where consent has been given,
  and the relationship between the author and the knowledge-
  source community disclosed. Appropriation is the category's
  most-criticised failure.
- **Local naturalist communities and citizen science.** Bird
  records via eBird, plant records via iNaturalist, fungal
  records via Mushroom Observer, mammal-tracker networks, marine
  observation networks — citizen science is a major contribution
  to current natural-history knowledge and is credited where
  used; named individual contributors where their specific
  observations are referenced.

### Source Freshness

- **Climate science accelerates.** Pre-2010 climate framings often
  understate current consensus; pre-2018 framings often understate
  current observed impacts. The book's climate content reflects
  current IPCC reports (or equivalent) and current observed-
  impact research; landscape descriptions written 10+ years ago
  may describe ecosystems that have since shifted (glaciers,
  fire-prone forests, coral reefs, sea-ice, alpine meadows,
  estuarine systems all under documented rapid change).
- **Conservation status changes.** IUCN listings update; species
  improve, decline, or are reclassified; "near-threatened" in 2015
  may be "endangered" or "least concern" now. Status claims dated
  and verified against current authorities.
- **Taxonomic revisions are continuous.** Genetic-phylogenetic
  research has revised many bird, mammal, plant, and especially
  fungal taxonomies in the last 20 years; species have been
  split, lumped, renamed. The book uses current taxonomy and
  notes where the older name is more familiar to general readers.
- **Indigenous-knowledge framings have evolved.** Pre-2015
  popular nature writing often rendered indigenous ecological
  knowledge anonymously, generically, or as "traditional wisdom"
  without naming source communities. Current standards require
  community-specific attribution, consent, and ideally collaboration
  with knowledge-holder communities.
- **Anthropocene framing has become standard.** "Wilderness"
  framings have been contested by William Cronon, Mark Dowie, and
  others; current scholarship treats most "wild" landscapes as
  human-shaped over long periods. The book engages with the
  current framing rather than perpetuating the prior one.
- **Foundational works hold up better.** Observation-led essays
  (Dillard, Leopold, Lopez) age more gracefully than status-and-
  threat content; historical natural-history works (Carson) remain
  foundational but require contextualisation about what has
  changed since.

### Attribution Standards

- **Scientific claims sourced.** "Studies show..." unacceptable
  without citation; "A 2021 paper in *Nature* by Smith and
  colleagues found..." is the standard. Reader trust in the
  natural-history content depends on this.
- **Field guide / monograph credit for identification and
  natural-history detail.** Where the book draws on a specific
  reference work (a field guide, a monograph on a species or
  group), the work is credited; the author's observation is
  distinguished from the reference-work synthesis.
- **Indigenous knowledge attribution: community and individual.**
  When TEK is referenced, the originating community or nation is
  named (e.g. "the Anishinaabeg understanding of...", "as the
  Pitjantjatjara term *tjukurpa* names..."); individual knowledge
  holders are credited where they have given consent. The book
  does not treat TEK as common-property "wisdom" detachable from
  its sources.
- **Distinguish: observation / record / synthesis.** "I watched
  the female peregrine return to the eyrie three times..."
  (observation). "eBird records show this species declining 12%
  in this region since 2010..." (record / data). "Recent research
  on raptor populations suggests..." (scientific synthesis). Each
  register signals the evidence's nature.
- **Anthropomorphism flagged when used.** Where the prose
  describes animal behaviour in language that ascribes human
  emotional or cognitive content ("the raven decided", "the wolf
  wanted") — and where such framing exceeds what the science
  supports — the prose either flags the framing as anthropomorphic
  shorthand or uses behaviourally-precise alternatives ("the
  raven moved to a new perch", "the wolf turned toward the elk").
- **What is NOT acceptable.** Inventing observations. Inventing
  species or hybrids. Citing field guides without checking
  current taxonomy. Presenting indigenous knowledge as universal
  ecological insight without attribution. Using superseded
  conservation status. Asserting popular-press distortions of
  science (the "wood wide web" in its strong form, certain
  large-language-model-style claims about animal cognition,
  certain elephant-grief framings) as established science when
  the underlying evidence is contested.

## Category-Specific Guardrails

### MANDATORY. Scientific Accuracy is Non-Negotiable

- Nature writing is a category where lyrical prose lives alongside
  scientific claim, but lyrical license never extends to factual
  claim. Misidentified species, invented behaviour, distorted
  ecology damage the book irrecoverably.
- Specific requirements:
  - **Species identification.** Every named species correctly
    identified per current taxonomy; common name appropriate to
    region; Latin binomial on first substantive reference.
  - **Behaviour claims.** Behaviours described match what the
    species does; behaviours plausibly observed by the author
    distinguished from behaviours documented in literature.
  - **Ecology and natural history.** Range, habitat, life cycle,
    diet, predator-prey relationships, succession patterns
    accurate per current natural-history understanding.
  - **Climate and earth-system science.** Claims about climate,
    weather patterns, geology, hydrology, ocean systems trace to
    current peer-reviewed science.
- A single confident misidentification (the warbler that's
  actually a vireo, the moth presented as a butterfly, the wolf
  behaviour ascribed to a coyote) damages the whole book's
  credibility; readers in nature writing's audience often have
  enough natural-history literacy to spot errors.

### MANDATORY. Anthropomorphism Discipline

- Nature writing inherits a literary tradition of giving voice
  and presence to non-human life — this is part of the genre's
  power. But ascribing human emotional or cognitive content to
  animals and plants requires careful calibration.
- The current state of animal-cognition science increasingly
  supports nuanced rendering of complex animal experience
  (corvid intelligence, cetacean social bonds, octopus problem-
  solving, elephant grief-related behaviours). The book may
  draw on this where the science supports it.
- Rendering should match what the science actually establishes:
  observable behaviour rendered specifically, evolutionary or
  ecological context explained, inferred experience flagged as
  inference rather than asserted as fact.
- The framing-traps to avoid:
  - Disney-grade anthropomorphism ("the bunny was sad to leave
    her family") — sentimentalises and misrepresents.
  - Behavioural-anthropic shorthand presented as fact ("the wolf
    decided to leave" — when "the wolf left" is what was
    observed).
  - Inverted projection where the author's emotional state is
    projected onto the landscape ("the meadow grieved its
    departing wildflowers").
  - Plant-cognition claims that go beyond current evidence
    (some plant-signalling research is solid; plant-decision-
    making framings often outpace the data).
- The legitimate move is precise observation + ecological /
  evolutionary context; sentimental projection is the failure
  mode.

### MANDATORY. Indigenous Knowledge Attribution and Land Acknowledgement

- Where the book draws on indigenous knowledge — traditional
  ecological knowledge, indigenous taxonomies, place-naming,
  land-management practice, indigenous understandings of species
  and ecosystems — attribution is named and explicit:
  - The originating community or nation is named (e.g.
    "Anishinaabeg understanding", "Pitjantjatjara naming",
    "Yup'ik knowledge of...", "Maori scientific tradition").
  - Individual knowledge holders are credited where they have
    consented to be named.
  - The author's relationship to the knowledge is disclosed:
    member of the community, in collaboration with knowledge
    holders, drawing on published scholarship by indigenous
    scholars, drawing on synthesis by non-indigenous scholars
    of indigenous traditions.
  - Where the book is set on indigenous lands, land
    acknowledgement appears (typically in front matter and
    relevant chapters) — naming the indigenous nations whose
    territory the place lies on.
- The framing-traps to avoid:
  - "Native wisdom" / "ancient indigenous knowledge" / "the
    traditional way" — generic, depersonalised, and reproduces
    the noble-savage trope.
  - Treating TEK as common-property folk knowledge detachable
    from its sources.
  - Citing TEK only where it confirms Western-science findings
    (selectively elevating indigenous knowledge to Western-science
    status only when convenient).
  - Romanticising traditional practices in ways the originating
    communities would not recognise.
- Where the author is not from the community whose knowledge is
  being engaged with, consultation with that community before
  publication is the standard; community-led nature writing
  (where indigenous authors write from inside their traditions)
  is the increasingly central form.

### MANDATORY. Climate and Ecological Honesty

- The natural world the book describes is a world undergoing
  documented rapid change: climate disruption, biodiversity
  decline, habitat loss, pollution accumulation, species range
  shifts, phenological mismatches. The book engages this
  honestly.
- Specific requirements:
  - **Ecosystems described as currently exist.** Not as they
    existed in the author's youth or in earlier nature writing's
    era, where the prior state has changed substantively. Where
    the book describes a remembered or historical state, this
    is dated.
  - **"Pristine" / "untouched" / "stable" framings disciplined.**
    Most ecosystems are now affected by climate, by historical
    or current human use, by introduced species, by pollution
    deposition. The framing of these systems as outside human
    influence is increasingly inaccurate.
  - **Loss named precisely.** Where species, habitats, or
    ecological functions have declined or been lost in the
    author's observed lifetime or in the documented record, the
    loss is named with the species / habitat / function, the
    timeframe, and the documented cause where known.
  - **Doom-loop and false-balance both avoided.** Catastrophic
    framing without agency leaves readers paralysed; false-
    balance framing that treats environmental science as
    contested where consensus exists misrepresents the state of
    knowledge. The book navigates between these by treating
    consensus as consensus, uncertainty as uncertainty, and
    pathways for engagement as real where they exist.
  - **Eco-grief permitted, eco-doom avoided.** Honest mourning
    for loss is part of contemporary nature writing's emotional
    register; nihilistic doom-loops that imply nothing matters
    or nothing can be done are themselves a misrepresentation
    of the science.

### MANDATORY. Wilderness vs Anthropocene Framing

- The "wilderness" concept — places untouched, beyond human
  influence, properly empty of people — has been substantively
  contested in nature writing and environmental thought (William
  Cronon's "The Trouble with Wilderness", Mark Dowie's
  *Conservation Refugees*, indigenous critiques of the wilderness
  paradigm). Most "wild" places have been inhabited, managed,
  shaped — often by indigenous peoples for millennia.
- The book either:
  - Acknowledges the human history of "wild" places, including
    indigenous presence and management; OR
  - Engages with the wilderness concept as the contested
    category it is, naming the framing rather than asserting
    it as real.
- "Discovery" / "first to..." / "pristine" / "virgin"
  framings of inhabited or human-shaped places are not used.
- The Anthropocene framing — humans as ecological force at
  geological scale — is current scholarly consensus and shapes
  how nature writing currently engages with its subject.

### Additional Guardrails

- **Specificity over generic nature-writing palette.** The
  category's biggest stylistic failure is generic prose
  ("majestic eagles soaring", "ancient forests whispering",
  "primal nature"); specific observation (this eagle, this
  morning, this particular pine and the lichen on its bark) is
  the antidote.
- **Author's natural-history credentials disclosed.** The
  author's relationship to the natural world being described
  is named: lifelong birder, recent learner, trained ecologist,
  amateur botanist, indigenous knowledge holder, observer-from-
  outside. This shapes the reader's calibration.
- **Naturalist-observation distinguished from scientific claim.**
  "I have watched this happen" is legitimate as observation;
  "this is how this species behaves" requires either documented
  natural-history support or framing as the author's observation.
- **Patience in the prose.** Nature writing's signature is
  unhurried attention; prose that rushes fails the genre. The
  reader who chose this book chose slowness; honour that choice.
- **Place-naming per local convention.** Place names (mountains,
  rivers, lakes, regions) per local / indigenous naming where
  applicable; the book may use settler-colonial place names where
  those are the dominant current usage but acknowledges
  indigenous names where relevant ("Mount McKinley / Denali", "Uluru
  / Ayers Rock").
- **Photography and direct contact ethics.** Where the book
  describes locating, approaching, photographing, or interacting
  with wildlife, the impact of these activities is acknowledged;
  best-practice (distance, non-disturbance during breeding /
  roosting, leave-no-trace, no-bait practices) signposted where
  the book might encourage readers toward similar engagement.
- **Currency disclosure where it matters.** Climate / status /
  population / range claims dated; reader directed to
  authoritative sources (IUCN, regional conservation agencies,
  current peer-reviewed literature) for ongoing currency.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Natural and seasonal — greens (forest, moss,
  fern), earth tones (loam, bark, sand, lichen), sky blues
  (overcast grey, dawn rose, dusk indigo), water greens and
  silvers, autumn ochres and rusts. Restrained and seasonal-
  appropriate to the subject. Deeper / starker palettes (slate,
  charcoal, monochrome) for conservation / climate-urgent titles
  where the cover should signal weight. Avoid the saturated
  greeting-card-nature palette that signals decorative rather
  than considered prose.
- **Typography:** Understated literary serif (Garamond, Bembo,
  Caslon, Mrs Eaves) is the default — typography signals
  considered prose and continuity with literary nature-writing
  tradition. Slab serif or warmer-character serifs for more
  contemporary positioning. Sans-serif rare in this category;
  reserved for conservation / science-led titles where directness
  is the cue. Hand-set / illustrated typography can work where
  the book has a strong personal-naturalist register.
- **Imagery:** Three dominant traditions:
  1. **Botanical / zoological illustration** — drawn detail of
     the subject (a single bird, plant, leaf, feather, shell,
     skull, footprint); elegant, restrained, often the strongest
     choice for species-portrait and natural-history titles.
     Carries a long tradition (Audubon, Bewick, the Victorian
     natural-history publishing aesthetic) that signals
     considered observation.
  2. **Landscape photography** — atmospheric image of the place
     or ecosystem (a moor, a forest interior, a coastline, a
     dawn over water); strong for place-portrait and contemplative
     titles. Calibrate to avoid the most-photographed-cliché
     vistas that signal stock-image rather than personal
     observation.
  3. **Single object / detail / texture** — a single resonant
     natural object (a feather, a stone, a piece of bone, a
     leaf, a print) photographed cleanly; or close-up detail of
     bark, water, lichen, mineral; strong for essay-collection
     and contemplative-naturalist titles.
- **Mood:** Quiet attention. The cover should signal "this book
  rewards patience" — not "magnificent nature" (touristic
  register), not "imminent catastrophe" (eco-doom register;
  conservation titles use weight differently). Restraint and
  specificity outsell ornament and stock-imagery.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Natural History / Observation | Botanical / zoological illustration tradition; restrained palette; serif typography signals literary positioning; subtitle clarifies the subject ("a year of...", "the natural history of...") |
| Species Portrait / Animal Behaviour | Single-species image (often illustration, sometimes photography) — the species IS the cover; warm palette appropriate to the species; subtitle clarifies the species or species group and the angle ("the secret life of...", "what we're learning about...") |
| Place Portrait / Landscape | Landscape photography or atmospheric place-image; palette appropriate to the place's character (greens for forest, blue-grey for coast, ochre for desert); serif typography; subtitle establishes the place's specificity |
| Conservation / Environmental | Often deeper / starker palette (slate, monochrome with single colour accent); image may signal threat (a single image of loss / change / human impact) without doom; typography substantial; subtitle establishes the urgency and the scope |
| Nature Memoir | Memoir cover language adapted for nature register — single resonant image (the species or place that anchors the book), warmer palette, literary typography; subtitle establishes the personal frame ("a story of...", "a memoir of...") |
| Philosophical / Contemplative | Often pure typography or restrained symbolic imagery (a leaf, a stone, an opening through trees); essay-collection cover language; warmer palette; serif typography signals literary essay tradition |
| Indigenous Knowledge / TEK | Visual language led by the originating community's preferences and conventions; often features culturally significant imagery (specific plants, animals, landscapes from the community's ecology); typography respectful of the cultural register; subtitle credits community and author's relationship to it |

### Typography Rules

- **Title:** 25–45% of cover area for image-led covers; 40–60% for
  typography-led essay covers. Nature-writing titles work as
  evocative single phrase ("Pilgrim at Tinker Creek", "Arctic
  Dreams", "H is for Hawk"), as place name ("Walden", "Trieste",
  "Findings"), as descriptive ("The Wild Places", "Braiding
  Sweetgrass"). All work; the title must read at thumbnail.
- **Subtitle:** Often essential for the category, particularly
  for emerging authors. Does the descriptive work — names the
  subject, the place, the angle. "A Memoir of the Forest" /
  "Notes from a Naturalist" / "Indigenous Wisdom, Scientific
  Knowledge, and the Teachings of Plants" (Kimmerer's
  *Braiding Sweetgrass* subtitle is a good example of explicit
  framing). Specific subtitle outsells vague subtitle.
- **Author name:** Larger for established nature-writer brands
  (Macfarlane, Kimmerer, Macdonald, Lopez); smaller for
  unestablished authors with credentials in subtitle ("by an
  ornithologist", "by an amateur naturalist", "by an indigenous
  scholar of..."). Author qualification cues — naturalist
  credentials, decades of observation in a place, scientific
  background, indigenous community membership — help in this
  category.
- **Series mark and edition:** Literary nature-writing imprints
  (Granta, Little Toller, NYRB Classics, Penguin Modern Classics
  for re-issues, university-press natural-history series) where
  applicable — these signal positioning to category readers.
  Re-issues warrant updated framing where ecological context
  has shifted significantly.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Natural History / Observation | Kindle Store > Kindle eBooks > Science & Math > Nature & Ecology > Natural History (with Science & Math > Biological Sciences > Biology as secondary for science-led titles) |
| Species Portrait / Animal Behaviour | Kindle Store > Kindle eBooks > Science & Math > Biological Sciences > Animals > [Specific Group: Birds / Mammals / Marine Life / Insects & Spiders / etc.] |
| Place Portrait / Landscape | Kindle Store > Kindle eBooks > Travel > Travel Writing (with Science & Math > Nature & Ecology as secondary; or Literature & Fiction > Essays & Correspondence for literary place-portrait) |
| Conservation / Environmental | Kindle Store > Kindle eBooks > Science & Math > Nature & Ecology > Environmental Conservation (with Politics & Social Sciences > Politics & Government > Specific Topics > Environmental Policy as secondary) |
| Nature Memoir | Kindle Store > Kindle eBooks > Biographies & Memoirs > Memoirs (with Science & Math > Nature & Ecology > Natural History as secondary) |
| Philosophical / Contemplative | Kindle Store > Kindle eBooks > Literature & Fiction > Essays & Correspondence > Essays (with Science & Math > Nature & Ecology > Natural History as secondary) |
| Indigenous Knowledge / TEK | Kindle Store > Kindle eBooks > Science & Math > Nature & Ecology > Natural History (with Religion & Spirituality > Earth-Based Religions or History > World > Indigenous Peoples as secondary depending on framing) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Birding / ornithology | Kindle Store > Kindle eBooks > Science & Math > Biological Sciences > Animals > Birds |
| Marine / ocean | Kindle Store > Kindle eBooks > Science & Math > Biological Sciences > Animals > Marine Life (and Sports & Outdoors > Outdoor Recreation > Beaches & Oceans for crossover) |
| Botanical / plants | Kindle Store > Kindle eBooks > Science & Math > Biological Sciences > Botany (and Crafts, Hobbies & Home > Gardening & Horticulture for garden-naturalist titles) |
| Geology / earth science | Kindle Store > Kindle eBooks > Science & Math > Earth Sciences > Geology |
| Climate science | Kindle Store > Kindle eBooks > Science & Math > Earth Sciences > Climatology |
| Hiking / outdoor | Kindle Store > Kindle eBooks > Sports & Outdoors > Outdoor Recreation > Hiking & Camping |
| Specific region / country | Kindle Store > Kindle eBooks > Travel > [Continent] > [Country] |
| Photography (illustrated) | Kindle Store > Kindle eBooks > Arts & Photography > Photography & Video > Subjects & Themes > Nature & Wildlife |

### Keyword Recommendations

- The specific subject — species, place, ecosystem
  ("ravens", "octopus", "lichens", "mycelia", "the Sahara",
  "Cairngorms", "Mojave Desert", "Pacific Northwest forest",
  "estuarine ecology")
- The angle or mode
  ("nature memoir", "natural history", "wildlife observation",
  "place portrait", "conservation writing", "environmental
  essay", "field naturalist")
- The natural-history discipline
  ("ornithology", "botany", "mycology", "marine biology",
  "ethology", "ecology", "geology", "limnology")
- The contemplative / literary register signal
  ("nature essays", "literary nature writing", "naturalist's
  journal", "field notebook")
- Conservation and climate framings where applicable
  ("biodiversity loss", "climate writing", "rewilding",
  "ecological restoration", "indigenous land management",
  "anthropocene")
- Comparable author / brand for discoverability
  (readers of Annie Dillard, readers of Robert Macfarlane,
  readers of Helen Macdonald, readers of Robin Wall Kimmerer,
  readers of Barry Lopez, readers of Mary Oliver)
- Season / cycle markers where the book has them
  ("a year in...", "seasons of...", "winter", "spring",
  "migration", "breeding season")
- Avoid generic single-word terms ("nature", "wildlife",
  "outdoors") in isolation — they drown in algorithmic noise;
  prefer compound phrases combining subject + place + mode
- Avoid framing-trap keywords ("majestic", "primal", "untouched",
  "pristine", "ancient", "wild" used in the touristic sense) —
  they signal commercial-nature-writing positioning and damage
  credibility with the readers serious nature writing needs to
  attract
