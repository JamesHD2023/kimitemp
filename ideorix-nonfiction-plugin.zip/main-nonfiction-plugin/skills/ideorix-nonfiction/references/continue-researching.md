---
name: continue-researching
description: "Resume an in-progress non-fiction project"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Continue Researching

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine

## Trigger Phrases

- "Continue researching"
- "Resume my project"
- "Continue writing [title]"
- "Pick up where I left off"

## What Happens

The engine checks your `Ideorix-Projects/` folder for existing projects and
resumes from exactly where you left off.

## What you'll need

Your project folder should contain:
- `engine-data/pipeline-checkpoint.md` — the authoritative record of which chapters are complete and where each is in the pipeline. **If this file is missing, the engine treats the project as new** (legacy mode) and you risk re-processing completed chapters. Always copy this file when moving projects between machines.
- `engine-data/research-bible.md` — Your Research Bible from Phase 2
- Completed chapter files

## Resume Protocol

**Read-Verification HARD GATE applies (see `read-verification.md`)
to every Read of user-supplied source files** (`research-bible.md`,
`sources.md` if user-edited externally, any source-canon documents
the user has added since last session). NF-specific concern: an
empty Read on `sources.md` silently destroys the source ledger that
the Verification Discipline binding and Stage 9 Fact Audit cross-
check against — every cited specific in subsequent chapters would
fall through unverified. Failed Reads BLOCK the resume flow and
surface the failure to the user with resolution options before any
new chapter generation runs. Engine-written runtime files
(`pipeline-checkpoint.md`, `entity-canon.md`, chapter summaries,
verification reports) are exempt — the File-Write Hygiene binding
verified them at write time.

**Source Persistence HARD GATE applies (see `source-persistence.md`,
v2.7.9).** If the user uploads NEW supplementary canon when resuming
(updated source bibliography, additional research documents, revised
citation database), the engine MUST persist each new file to
`source-canon/` via `scripts/source-persistence.sh` BEFORE any new
chapter generation runs. The canon-absorbed.md marker accumulates
across sessions, giving an audit trail of every absorbed source.
NF-specific concern: source ledger drift across sessions is the
single most damaging type of canon drift — the Verification Discipline
binding cross-checks against `sources.md`, and any silent absorption-
without-persistence breaks that chain.

1. Check `Ideorix-Projects/` for matching project folders
2. Read `engine-data/pipeline-checkpoint.md` — this tells the engine exactly
   where to resume
3. Read `engine-data/research-bible.md` to restore full research context
4. Read `engine-data/sources.md` — build source index for lightweight lookup.
   Full source profiles are loaded per-chapter via Context Scoping.
5. Read the latest `engine-data/summaries/` files for continuity
6. Run the Pre-Flight Check on the last completed chapter
7. Resume from the next incomplete step

## Returning with a Completed Manuscript (Research Bible Only Projects)

If you used Research Bible Only mode and have written the book yourself:

1. Engine reconnects to your Research Bible and source database
2. Validates your manuscript against the established research framework
3. Reconciles any changes you made (new sources, restructured arguments)
4. Builds an Authority Voice Profile from YOUR prose
5. Runs the full editorial pipeline with fact-checking — with the advantage
   of already knowing your research framework intimately

→ See `core-pipeline.md` for the complete return flow protocol.
