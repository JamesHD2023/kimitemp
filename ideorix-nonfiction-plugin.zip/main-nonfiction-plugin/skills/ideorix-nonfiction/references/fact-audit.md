---
name: fact-audit
description: "User-callable Full-Manuscript Fact Audit. Runs Stage 9 of the editorial pipeline as a standalone tool — verify every factual claim, build source / claim / citation / date / expert / organisation registries, flag discrepancies across the manuscript."
version: "2.6.9"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Fact Audit

## Verification Discipline Binding (MANDATORY — Stage 9 hardened)

This audit operates under `verification-discipline.md` as
the Stage 9 verification stage. The discipline replaces the
previous "pre-press fact-verify stack" framing in three
binding ways:

1. **WebSearch verification is REQUIRED, not optional, for
   every cited specific in the manuscript.** The audit
   reconciles every cited paper / person / event /
   legislation / statistic / quotation against the bible's
   `engine-data/verification-ledger.md` AND re-runs
   WebSearch on each ledger entry to confirm the pinned
   source still resolves and the specifics still match.
   Drift between the bible's pinned source and the
   manuscript's prose is itself a finding.

2. **"Defer to pre-press" is REMOVED as a valid
   resolution.** Items that fail WebSearch verification at
   Stage 9 are BLOCKING — the audit cannot complete with
   non-zero unverified-uncategorized items. The only
   resolutions are: promote to VERIFIED (with corrected
   specifics if needed), reframe as SPECULATIVE (with
   explicit prose markers added to the manuscript), or
   REJECT (remove from prose). The publisher does NOT do
   the engine's verification work.

3. **Per-claim verification ledger is the audit's
   primary deliverable.** For every cited specific in
   the manuscript, the audit produces a ledger row:
   chapter / section / specific / class
   (VERIFIED / SPECULATIVE / REJECTED) / pinned source
   URL/DOI for VERIFIED / prose-marker phrasing for
   SPECULATIVE / verification timestamp / re-verification
   date.

The eight named anti-patterns from `verification-
discipline.md` are the audit's detection targets. In order
of historical incidence:

- **Wrong-Attribution-of-Real-Paper** — confident wrong
  authorship / title / journal on a real paper. WebSearch
  every paper citation; cross-check authors, title,
  journal, year, DOI.
- **Date Drift on Real Events** — fuzzy-from-training
  dates. WebSearch every dated event; cross-check.
- **Detail Errors on Recent Legislation / Statistics** —
  WebSearch the actual statute / dataset; cross-check
  manuscript specifics against primary source.
- **Missed Real Events** — coverage gaps. Run a topic-
  landscape sweep at audit time to surface anything the
  Phase A sweep at bible-construction missed.
- **Funding / COI / Context Omissions** — material
  context that changes interpretation. Verify each
  cited person / study / institution for funding source,
  conflict of interest, retraction history.
- **Topic-Framing Errors** — WebSearch the actual primary
  document; read its language; cross-check manuscript
  framing.
- **Quotation Fabrications** — every quotation must trace
  to a Tier 1 verbatim source. Fabricated quotes are
  REJECTED outright (removed from prose) or recast as
  Tier 2 attributed paraphrase (without quotation marks).
- **Footnote-Only Fix Drift (prose-mirror sweep)** — when
  the audit applies a citation correction to a footnote /
  endnote, the same misattribution often still appears in
  the chapter prose body. The audit MUST grep the entire
  chapter for the misattributed string(s) — author
  surnames, paper title fragments, dated phrasing,
  attributed organisations — and apply the same correction
  to ALL instances, not just the citation. After applying
  the correction, re-grep to confirm the misattributed
  strings appear nowhere in the chapter before reporting
  the correction as complete. A footnote correction
  without a prose-body correction leaves the manuscript
  with the same wrong attribution still visible to the
  reader.

The Fact Audit's Stage 13 handoff is conditioned on the
ledger having zero unverified-uncategorized items. If
non-zero, Stage 13 publication readiness verdict is
NOT-READY with the unverified list as explicit blockers.

## Stage 9 Architecture — 9a + 9b Split (v2.7.11)

Stage 9 is now structurally split into two distinct sub-stages
to address the documented gap where the previous single-stage
design conflated **internal-consistency checking** with
**external truth verification**, and the latter was
implementation-skipped while the former passed cleanly.

### Stage 9a — Internal Consistency Audit

The audit dimension Stage 9 previously performed under the
"Fact Audit" name. Sweeps the COMPLETE manuscript for cross-
chapter consistency:

- **Source Index** — Every source cited, where, and how many times
- **Claim Registry** — Every factual claim with its supporting source
- **Citation Cross-Reference** — Bibliography entries matched to in-text citations
- **Date & Chronology Tracker** — Every date mentioned, verified for arithmetic consistency (ages match birth dates; durations match start/end markers; chronologies don't contradict)
- **Expert Registry** — Every person named, their credentials, where they appear (consistency only — credentials are externally verified at 9b)
- **Organisation Registry** — Every organisation named, verified details (consistency only — facts are externally verified at 9b)
- **Patent number format plausibility** — patents claimed for a given era have format consistent with that era's actual patent numbering
- **Name spelling consistency** — same person / place / organisation spelled the same way every time

Stage 9a produces a per-discrepancy ledger and resolves all
internal contradictions before 9b begins. 9a's verdict can be
PASS (no contradictions) or FAIL (contradictions surfaced for
resolution).

### Stage 9b — External Source Verification (NEW — the gap-closer)

The audit dimension that was named but not actually performed
in the previous Stage 9 design. For every concrete factual
claim in the manuscript, mechanically verify the claim against
external sources via WebSearch + WebFetch (both bound to
`web-content-verification.md`).

**Concrete factual claim categories MUST include (not exhaustive):**

- Patent claims — patent number, inventor, year, filing
  jurisdiction, title
- "First X" priority claims — first-commercial / first-patented
  / first-to-develop / first-to-manufacture (see "First-X
  Priority Flagging" section below)
- Founding dates — every company / organisation founding date
- Biographical specifics — birthplace, prior employment,
  education, death circumstances, named anchor-life events
- Statistics with specific numbers — "approximately N
  corporations", "X% of Fortune Y", "N billion units sold",
  any cited figure with quantitative specificity
- Named historical events with dates — every dated event
  attributed in the manuscript
- Quoted claims from secondary sources — accuracy of paraphrase
  vs the original source
- Specific product model numbers — any model / version / part
  number cited

For each claim category, the audit's mechanical procedure:

1. **Extract the claim** — the audit subagent extracts every
   instance of the claim type from the manuscript prose,
   producing a per-claim row in the verification ledger
2. **Run WebSearch** with sufficient queries to confirm the
   specific exists. Web-Content Verification HARD GATE applies
   (paywall stub detection, byte-count threshold, transient-
   empty retry-and-distinguish)
3. **Cross-reference at least two independent sources** for
   contested-priority claims; one source plus the official
   record (corporate-history page / official patent database /
   government registry) for non-contested claims
4. **Classify** per `verification-discipline.md`: VERIFIED
   (WebSearch confirmed, source pinned), SPECULATIVE (claim
   plausible but not confirmed at primary-source level;
   requires explicit prose hedging), REJECTED (claim contradicted
   by primary source — must be removed or rephrased)
5. **Update the manuscript** if the classification requires
   prose change (REJECTED claims removed; SPECULATIVE claims
   hedged; VERIFIED claims retained as-is with source pinned
   in the ledger)

### Pending-Marker Resolution Gate (HARD GATE — runs BEFORE Stage 9b begins)

Before Stage 9b can start, the audit MUST run
`scripts/pending-marker-scan.sh` against the manuscript and
all chapter notes. Any unresolved placeholder (e.g. "(pending
fact-audit)", "[verify]", "TBD", "(specific patent number
pending)", etc.) BLOCKS Stage 9b from starting until
resolved.

For each detected placeholder, the resolution path is one of:

1. **Fill in the verified data** — preferred. The placeholder
   is replaced with the verified specific.
2. **Rephrase the claim to remove the unverifiable specific**
   — second-best. The claim becomes general enough that no
   specific-fact-checking is required (e.g. "patented in 1872"
   becomes "patented in the 1870s").
3. **Soften to a hedged general framing** — third-best. The
   claim is reframed with appropriate hedging language (e.g.
   "is widely credited with" rather than "patented in 1872").

The pending-marker scan is then re-run. Stage 9b begins only
when the script returns zero matches.

This rule closes the documented gap where Volume 1 of a
multi-volume NF series shipped with chapter-note placeholders
treated as future tasks rather than HARD GATEs.

## First-X Priority Flagging (MANDATORY at draft + Stage 9b)

The class of claim most likely to be wrong in trade-microhistory
NF is the "first X" attribution — "[Person] patented the first
[X]" / "[Person] invented the first [X]" / "The first commercial
[X] was [Y]" / "[Person] was the first to develop [X]" /
"[Company] was the first to manufacture [X]". These claims are
high-risk because secondary sources copy each other
uncritically; the canonical first-priority filings are
frequently in different jurisdictions or by different inventors
than the secondary-source consensus suggests.

**During chapter drafting** (Phase 3 step 7 — Content Writer):

- The Writer MUST flag every "First X" claim with a
  marker visible to Stage 9b. Marker convention:
  `[FIRST-X-CLAIM: {summary}]` placed inline immediately
  after the claim. The marker is removed (along with the
  claim being verified or hedged) at Stage 9b.

**During Stage 9b** (External Source Verification):

For every flagged "First X" claim:

1. Run WebSearch specifically for "[X] history" or "first [X]"
   to find competing claimants
2. If multiple priority claimants exist:
   - Soften the chapter language to acknowledge the contested
     history (e.g., "[Person A] in [country] and [Person B] in
     [country] both filed for similar patents in [year range]")
   - Update the verification ledger with the contested-
     priority finding
   - The claim is classified SPECULATIVE with the contested-
     history map referenced in the ledger
3. If only one canonical claimant exists:
   - Verify the specific date and patent (if any)
   - Classify as VERIFIED with primary-source URL pinned
4. If no canonical claimant can be confirmed:
   - REJECT the claim (remove from prose) or reframe entirely
     ("[Person] is among the early commercial developers of
     [X]" rather than "[Person] was the first")

## Patent-Claim Handling Protocol (MANDATORY at Stage 9b)

Every claim of the form "[Person] patented [X] in [year]" /
"[Person] holds a patent on [X]" / "[Person]'s [year] patent"
MUST resolve to ONE of three states before Stage 9b can pass:

1. **Specific patent number cited and verified** — the patent
   number appears in the prose AND has been verified to exist
   in the relevant patent database (USPTO / EPO / WIPO / etc.)
   AND the inventor / year / title match the prose attribution.
   The verification ledger entry includes the patent database
   URL.

2. **Hedged framing** — the prose uses appropriate hedging
   language ("filed for a patent" / "developed... around" /
   "is widely credited with" / "[Person]'s work in the
   [decade]") that does not commit to a specific patent number
   the audit cannot verify.

3. **Removed entirely** — if neither a verified patent number
   nor an appropriate hedge resolves the claim, the patent
   attribution is removed from the prose. The chapter's argument
   is rebuilt around verifiable facts.

The audit MUST NOT pass "[Person] patented [X]" through to
Stage 13 without one of these three resolutions. This is the
rule that would have caught the documented Henry C. Leland
rubber-stamp error in the Volume 1 case.

## Worked Examples — Errors caught by Stage 9b that Stage 9a missed

The following examples are drawn from a documented NF
production failure (Volume 1 of a multi-volume series, May
2026) where six substantive factual errors survived all 13
editorial pipeline stages of the previous Stage 9 design.
Each example illustrates a specific Stage 9b detection:

### Example 1: Pollock 657 Swivel Chair (Model-Number Error)

- **Manuscript claim:** "[Designer]'s 1963 Executive Chair, the
  657 series, became the iconic..."
- **Reality:** The 657 was the designer's earlier 1960 Sling
  chair model. The 1963 Executive Chair was the 1250 series.
- **Stage 9a (Internal Consistency):** PASS — the 657
  attribution was used consistently across the chapter.
- **Stage 9b (External Source Verification):** FAIL — WebSearch
  on "[Designer] 657 chair" surfaces the 1960 Sling, not the
  1963 Executive. The model number must be corrected (1250) or
  the chapter rewritten without the specific model number.

### Example 2: Henry C. Leland Rubber-Stamp Patent (Patent That Doesn't Exist)

- **Manuscript claim:** "Leland patented the first multi-character
  rubber stamp in 1864."
- **Reality:** Leland never filed a patent for this. The claim
  has been "widely viewed with scepticism since 1910" in the
  rubber-stamp historian community.
- **Stage 9a (Internal Consistency):** PASS — single-chapter
  claim, no contradictions.
- **Stage 9b (Patent-Claim Handling Protocol):** FAIL — no
  patent number can be cited and verified in the USPTO
  database; no canonical primary source supports the
  attribution. The claim must be rephrased ("Leland is
  sometimes credited with early rubber-stamp work, though
  rubber-stamp historians have viewed this attribution with
  scepticism since 1910") or removed entirely.

### Example 3: Halsey Taylor Drinking Fountain (Multiple Biographical Errors)

- **Manuscript claim:** "Halsey Taylor, an Indiana businessman,
  patented his drinking fountain in 1906 after starting a
  bicycle company."
- **Reality:** Taylor was an Ohio businessman (not Indiana);
  his prior employer was Packard Electric Co. (Shop
  Superintendent — not a bicycle company); the patent / first
  product was 1912 (not 1906); the product was the Puritan
  Sanitary Fountain (specific name).
- **Stage 9a (Internal Consistency):** PASS — single chapter,
  internally consistent biographical claims.
- **Stage 9b (Biographical Specifics Verification):** FAIL —
  Wikipedia + corporate-history sources contradict every
  biographical specific. The chapter requires substantial
  revision on every biographical claim.

### Example 4: Luther Haws Bubbler (Date Error)

- **Manuscript claim:** "Luther Haws patented the bubbler in
  1909."
- **Reality:** Haws invented the bubbler in 1906; the company
  was formed in 1909. Conflating invention date with company-
  formation date is the error.
- **Stage 9a (Internal Consistency):** PASS.
- **Stage 9b (Founding-Date Verification):** FAIL — the
  corporate-history page shows 1906 invention / 1909 company.
  The chapter must distinguish the two dates.

### Example 5: Vaaler Paperclip Patents (Jurisdictional Error)

- **Manuscript claim:** "Vaaler filed his paperclip patent in
  Germany 1899 and Norway 1901."
- **Reality:** Germany filed 1900, granted 1901; the second
  filing was in the US (not Norway) — filed and granted 1901.
- **Stage 9a (Internal Consistency):** PASS — internally
  consistent.
- **Stage 9b (Patent-Claim Handling):** FAIL — patent database
  WebSearch on "Vaaler paperclip patent" surfaces the German
  and US filings, not Norwegian. The chapter must correct the
  jurisdictional framing.

### Example 6: Bíró Hungarian Patent Priority (Contested-Priority Error)

- **Manuscript claim:** "Bíró's Hungarian patent was the first
  filing for the modern ballpoint pen."
- **Reality:** The canonical first-priority filings are British
  and French, both 15 June 1938. The Hungarian filing was
  later.
- **Stage 9a (Internal Consistency):** PASS.
- **Stage 9b (First-X Priority Flagging):** FAIL — WebSearch
  on "ballpoint pen first patent history" surfaces the British
  + French priority filings. The chapter must rephrase to
  acknowledge the contested-priority history.

These six examples illustrate the failure shape Stage 9b
catches: claims that pass internal-consistency checking but
fail external-source verification. Each error is the same
class — specific factual attribution that secondary sources
copy uncritically and that contradicts primary-source or
careful-tertiary-source verification.

## File-Write Hygiene (MANDATORY — applies to every chapter file this audit modifies)

When the Fact Audit applies citation fixes, source flags, or
correction edits to chapter files, the chained-Edit truncation
safeguard documented in `core-pipeline.md` § Chained-Edit
Truncation Safeguard applies in full:

- **Prefer Write over chained Edit for chapter-scale citation
  rewrites.** When a fact correction requires substantial
  rewriting (more than half a section), Write the whole
  revised section once.
- **Cap individual Edit replacements at ~2 KB.** Citation /
  source fixes should rarely exceed this.
- **Run `scripts/word-count-check.sh` after every chapter file
  this audit edits**, not just at audit completion. Citation
  insertions can change word count in ways that mask
  truncation if not specifically verified.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) before reporting fact-audit completion on
  a given chapter.

**HARD GATE — BLOCKING.** Truncation in a fact-audited chapter
is especially serious — citation insertions and source
attributions that disappear silently undermine the audit's
core deliverable. Any truncation MUST be repaired before the
audit report claims the chapter is fact-cleared.

## Purpose

Runs the Full-Manuscript Fact Audit (Stage 9 of the editorial
pipeline) as a standalone, user-callable tool. Verifies every
factual claim in a non-fiction manuscript against the Research
Bible and external sources, builds master reference tables, and
flags discrepancies for the author to resolve.

Previously runnable only as part of the full editorial pipeline
(Edit & Revise → Stage 9). v2.3.6 promotes it to a user-callable
agent so authors can run a focused fact pass without invoking the
full editorial sequence.

## When to Use

- **Before submitting** to a publisher, agent, or fact-checker
- **Before a launch** when last-minute claims have been added
- **After major revisions** that introduced new sources or claims
- **Pre-press-release** when a journalist may pick up specific
  claims and verify them
- **Periodic mid-process check** during a long writing project to
  catch drift before it compounds

Direct triggers: `"Run a fact audit"`, `"Fact audit"`,
`"Check my facts"`, `"Verify the facts in my manuscript"`,
`"Source audit"`.

## Capabilities

| Capability | Behaviour |
|---|---|
| Claim Extraction | Reads the manuscript and extracts every factual claim into a structured table (statistic, date, quote, credential, historical-fact, scientific-claim, etc.) |
| Source Index | Every source cited, where, and how many times |
| Claim Registry | Every factual claim with its supporting source |
| Citation Cross-Reference | Bibliography entries matched to in-text citations; orphan citations flagged |
| Date & Chronology Tracker | Every date verified for accuracy; chronological inconsistencies surfaced |
| Expert Registry | Every named person, their credentials, where they appear |
| Organisation Registry | Every named organisation, verified details |
| Cross-Manuscript Consistency | Same fact stated differently in two chapters → flagged as error until author confirms |

## Input Requirements

- **Manuscript** — full draft or partial (chapter range acceptable)
- **Research Bible** — `engine-data/research-bible.md` (used as
  the canonical source of truth for cross-checking)
- **Sources / bibliography** — `engine-data/sources.md` if present

## Output

- **Source Index table** — every cited source with usage count
  and locations
- **Claim Registry** — every factual claim with verification
  status (Verified / Unverified / Discrepancy / Needs source)
- **Discrepancy report** — claims that conflict across chapters
  or with the Research Bible, listed with locations for
  resolution
- **Citation cleanup list** — orphan citations, missing citations,
  formatting drift
- **Saved as** `engine-data/reports/fact-audit-{YYYY-MM-DD}.md`

## Routing

- **Implementation:** `→ See fact-checking-protocol.md` for the
  mechanical claim-extraction and verification protocol
- **Pipeline context:** `→ See editorial-suite.md` Stage 9
  ("Full-Manuscript Fact Audit") for the full editorial-pipeline
  context this stage normally runs in
- **Verification agents:** `→ See accuracy-gate.md` for the
  Source Guardian, Evidence Auditor, and Citation Keeper agents
  that this audit invokes

## Boundaries (out of scope for v2.3.6)

- **Live web verification** — Fact Audit checks claims against
  the Research Bible and provided sources. It does not perform
  live web searches to verify external facts independently
  (that would risk introducing unverified or stale data).
- **Auto-fix** — Fact Audit identifies issues; it does not
  modify the manuscript. The author resolves each flagged item.
- **Bias and balance** — Fact Audit checks accuracy, not
  framing. For the framing pass see `bias-balance-review.md`.

## Relationship to other tools

- **Manuscript Clinic** runs a broader diagnostic across 6 axes
  (thesis, evidence, structure, voice, market, mechanics). Fact
  Audit drills deeper on the evidence axis specifically.
- **Bias & Balance Review** assesses framing. Run Fact Audit
  first (does the book say what it says correctly?), then
  Bias & Balance (is what it says framed fairly?).
- **Source Guardian** verifies claims at the chapter level
  during the editorial pipeline; Fact Audit aggregates across
  the full manuscript.
