---
name: series-architect-nonfiction
description: "Multi-volume non-fiction series architecture and planning"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Series Architecture — Non-Fiction

## Purpose

Plan and maintain continuity across a multi-volume non-fiction project.
Non-fiction series differ from fiction series: instead of recurring characters
and escalating plot, non-fiction series expand a topic across volumes, deepen
expertise, or explore different facets of a subject.

## When to Run

- Phase 0: Before Phase 1 setup, when the user indicates a series project (Q7)
- Triggered by: "Book 1 of a series", "First in a planned series", "Continuation"

## Series Types for Non-Fiction

| Type | Description | Example |
|------|------------|---------|
| **Topic Expansion** | Each volume covers a different aspect of the same subject | "A History of X" — Vol 1: Origins, Vol 2: Growth, Vol 3: Modern Era |
| **Deepening Expertise** | Each volume goes deeper into the same subject | Beginner → Intermediate → Advanced guides |
| **Geographic/Thematic** | Same methodology applied to different regions/themes | Regional cookbooks, country-specific travel guides |
| **Chronological** | Each volume covers a different time period | Decade-by-decade histories |
| **Annual/Periodic** | Updated editions with new data | Annual market reports, yearly guides |

## Series Bible Structure

Create `series-data/series-bible.md` with (series-level files live in
`series-data/` under the master series folder, not in any individual
volume's `engine-data/` — see the MANDATORY Series Folder Structure
section below for the full layout):

### 1. Series Overview
- Series title and subtitle
- Number of planned volumes
- Series type (from table above)
- Unifying thesis or question across all volumes
- Target audience progression (same audience deepening, or expanding audience)

### 2. Volume Plan
For each planned volume:
- Title and scope
- How it connects to previous volumes
- What new ground it covers
- Key sources unique to this volume
- What the reader should know from prior volumes

### 3. Cross-Volume Continuity
- Consistent terminology across volumes
- Source citations that carry across (same source cited same way)
- Cross-references between volumes ("As discussed in Volume 1...")
- Style and voice consistency
- Formatting and structure consistency

### 4. Series-Level Arguments
- If the series builds an argument across volumes, track the thesis development
- Which evidence pillars are established in which volume
- How counter-arguments are distributed across the series

## Series Research Guardian

When a series bible exists, the 6th verification agent (Series Research
Guardian) activates and checks:
- Cross-volume source consistency
- No contradictions between volumes
- Thesis builds across volumes
- Key figures described consistently
- Terminology consistent

## Series Folder Structure (MANDATORY)

When a project is identified as a non-fiction series (Phase 1 series
question: "Volume 1" or "Volume 2-N"), the Series Architect creates a
MASTER SERIES FOLDER with individual volume folders nested inside:

```
Ideorix-Projects/[Series Title]/
├── series-data/                     ← Series-level canonical state (shared across all volumes)
│   ├── series-bible.md              ← Cross-volume continuity, terminology, source consistency, thesis development
│   └── series-plan.docx             ← User-facing series summary
├── shared/                          ← Cross-volume non-canonical artefacts
│   └── (combined-volume PDFs, source archives spanning multiple
│        volumes, cross-volume reports, miscellany — material that
│        spans volumes but is NOT part of the series-canonical bible)
├── volume-1-{title-slug}/           ← Individual volume folder (full standard NF project structure)
│   ├── engine-data/
│   │   ├── research-bible.md
│   │   ├── chapter-briefs/
│   │   ├── chapters/
│   │   ├── summaries/
│   │   ├── reports/
│   │   ├── entity-canon.md
│   │   └── ... (all standard per-volume NF files)
│   ├── manuscript/
│   ├── marketing/
│   └── clinic/                      ← (if used by the project)
├── volume-2-{title-slug}/           ← Created when the user starts Volume 2
│   ├── engine-data/
│   ├── manuscript/
│   ├── marketing/
│   └── clinic/
└── volume-3-{title-slug}/           ← Created when the user starts Volume 3
    ├── engine-data/
    ├── manuscript/
    ├── marketing/
    └── clinic/
```

**Rules:**
- Series-level files live in `series-data/`, NOT in any individual
  volume's `engine-data/`. The series bible is the cross-volume
  reference; each volume's research bible is the per-volume reference.
- Individual volume folders are created AS NEEDED — when the user
  starts Volume 1, only `volume-1-{title-slug}/` is created alongside
  `series-data/`. Volume 2 and 3 folders are created when the user
  begins those volumes (see "Returning to a Series Project" below for
  the explicit creation step).
- Volume folder names use the pattern `volume-N-{title-slug}/` —
  volume number plus a kebab-case slug of the volume title. Example:
  Volume 2 of "Products That Changed the 20th Century" with title
  "Living Room" becomes `volume-2-living-room/`.
- The `series-data/` folder uses a DIFFERENT name from `engine-data/`
  deliberately — this prevents confusion between series-level and
  volume-level state files. A folder named `engine-data/` always
  belongs to a specific volume; `series-data/` always belongs to the
  series.
- The `shared/` folder holds cross-volume artefacts that are NOT
  series-canonical: combined-volume PDFs, source archives spanning
  multiple volumes, cross-volume reports, miscellany. Material that
  belongs in `series-data/` (the canonical series bible, terminology
  glossary, cross-volume continuity rules) MUST NOT live in `shared/`.
- Each volume folder has the FULL standard NF project structure
  (`engine-data/`, `manuscript/`, `marketing/`, `clinic/` if used)
  identical to a standalone NF project.

**Path pattern for series volumes:**
`Ideorix-Projects/[Series Title]/volume-{N}-{slug}/engine-data/chapters/ch01.md`

Compare standalone:
`Ideorix-Projects/[Book Title]/engine-data/chapters/ch01.md`

The only difference is the intermediate `[Series Title]/volume-{N}-{slug}/`
path. All per-volume paths (chapters, reports, summaries, entity-canon,
etc.) remain the same relative to the volume folder root.

## Returning to a Series Project

When the user starts Volume 2+:

1. **Create the new volume folder FIRST** — before loading any prior
   content or writing any new file. Path:
   `Ideorix-Projects/[Series Title]/volume-{N}-{slug}/` with the full
   standard NF project structure inside (`engine-data/`, `manuscript/`,
   `marketing/`, `clinic/` if used). DO NOT write to the previous
   volume's `engine-data/` — every per-volume file (research-bible.md,
   chapters/, summaries/, reports/, entity-canon.md) belongs inside
   the NEW volume's folder. See the MANDATORY Series Folder Structure
   section above.
2. Load the series bible from `series-data/series-bible.md`.
3. Load Volume {N-1}'s Research Bible from
   `volume-{N-1}-{slug}/engine-data/research-bible.md` for continuity.
4. Identify carry-over sources, figures, and arguments.
5. Configure the new volume's Research Bible at
   `volume-{N}-{slug}/engine-data/research-bible.md` to build on prior
   work.
