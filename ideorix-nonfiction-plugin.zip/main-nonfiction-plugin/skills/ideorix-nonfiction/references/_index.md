---
name: category-index
description: "Master index of all available non-fiction categories"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Non-Fiction Category Bank — Index

## How to Use

When the user selects a category, read the corresponding file from this package.
Each file contains category-specific instructions for ALL agents in the pipeline.

## Available Categories

### Memoir & Biography
| ID | Name | File | Status |
|----|------|------|--------|
| memoir | Memoir | memoir.md | Ready |
| biography | Biography | biography.md | Ready |
| historical-biography | Historical Biography | historical-biography.md | Ready |

### History
| ID | Name | File | Status |
|----|------|------|--------|
| history-general | General History | history-general.md | Ready |
| military-history | Military History | military-history.md | Ready |
| social-history | Social History | social-history.md | Ready |
| microhistory | Microhistory | microhistory.md | Ready |

### Popular Science
| ID | Name | File | Status |
|----|------|------|--------|
| popular-science | Popular Science | popular-science.md | Ready |
| natural-history | Natural History | natural-history.md | Ready |
| environmental | Environmental / Climate | environmental.md | Ready |

### Self-Help & Psychology
| ID | Name | File | Status |
|----|------|------|--------|
| self-help | Self-Help / Personal Development | self-help.md | Ready |
| psychology-popular | Popular Psychology | psychology-popular.md | Ready |
| philosophy-popular | Popular Philosophy | philosophy-popular.md | Ready |

### Business & Finance
| ID | Name | File | Status |
|----|------|------|--------|
| business | Business / Entrepreneurship | business.md | Ready |
| economics-finance | Economics & Finance | economics-finance.md | Ready |
| personal-finance | Personal Finance | personal-finance.md | Ready |

### True Crime
| ID | Name | File | Status |
|----|------|------|--------|
| true-crime | True Crime | true-crime.md | Ready |

### Health & Wellness
| ID | Name | File | Status |
|----|------|------|--------|
| health-wellness | Health & Wellness | health-wellness.md | Ready |
| fitness | Fitness & Exercise | fitness.md | Ready |

### How-To & Guides
| ID | Name | File | Status |
|----|------|------|--------|
| how-to-guide | How-To / Reference / Guides | how-to-guide.md | Ready |
| cooking | Cooking & Food Writing | cooking.md | Ready |

### Journalism & Commentary
| ID | Name | File | Status |
|----|------|------|--------|
| investigative-journalism | Investigative Journalism | investigative-journalism.md | Ready |
| political-commentary | Political / Social Commentary | political-commentary.md | Ready |

### Creative Non-Fiction
| ID | Name | File | Status |
|----|------|------|--------|
| literary-nonfiction | Literary Non-Fiction | literary-nonfiction.md | Ready |
| essay-collection | Essay Collections | essay-collection.md | Ready |

### Travel & Nature
| ID | Name | File | Status |
|----|------|------|--------|
| travel-writing | Travel Writing | travel-writing.md | Ready |
| nature-writing | Nature Writing | nature-writing.md | Ready |

### Culture & Arts
| ID | Name | File | Status |
|----|------|------|--------|
| art-culture | Art / Music / Culture | art-culture.md | Ready |
| sports-narrative | Sports / Adventure | sports-narrative.md | Ready |

### Education & Parenting
| ID | Name | File | Status |
|----|------|------|--------|
| education | Education / Teaching | education.md | Ready |
| parenting | Parenting / Family | parenting.md | Ready |

### Technology
| ID | Name | File | Status |
|----|------|------|--------|
| technology | Technology / Digital | technology.md | Ready |

### Religion & Spirituality
| ID | Name | File | Status |
|----|------|------|--------|
| religion-spirituality | Religion / Spirituality | religion-spirituality.md | Ready |

---

**Total: 33 categories across 15 groups.**

## Category File Format

Every category file follows the same structure:

```
# [Category Name] — Category Plugin

## Metadata
## Subcategory Options
## Structural Architect Instructions
## Content Writer Craft Rules
## Quality Check Criteria
## Source Requirements
## Category-Specific Guardrails
## Cover Design Specifications
## KDP Category Mapping
```
