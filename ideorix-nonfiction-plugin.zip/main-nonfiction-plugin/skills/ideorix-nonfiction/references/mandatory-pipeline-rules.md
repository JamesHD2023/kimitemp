---
name: mandatory-pipeline-rules
description: "Ideorix Non-Fiction mandatory pipeline rules (NON-NEGOTIABLE). File Operation Policy + Rules 1-10. Extracted from SKILL.md in v2.7.53 to slim the eager-load surface; loaded as a Tier-1 reference at session start. These rules override speed, momentum, and user impatience; violations caused real damage in production."
version: "2.7.53"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# MANDATORY PIPELINE RULES — Ideorix Non-Fiction (NON-NEGOTIABLE)

These rules override ALL other considerations including speed, momentum,
and user impatience. They exist because violations caused real damage in
production.

> **Enforcement venue caveat (read this first):**
>
> "MANDATORY", "BLOCKING", and "HARD GATE" language throughout this file
> and the engine's reference specs describes an **LLM-contract**, not
> runtime code. The engine layer that enforces these rules is Claude
> reading the spec at dispatch time — not a runtime checker, not a
> static analyser, not a CI hook. (The exceptions are the bash audit
> scripts under `scripts/`, which ARE real code and DO enforce their
> contracts; everything else is documentation discipline.) The rules
> remain binding — Claude's job is to follow them — but if you're
> reading this expecting a runtime exception to halt the agent on a
> violation, that's not what happens. See `validate-dispatcher.md`
> § Implementation Venue for the full discussion. The engine's
> verification infrastructure (silent-failure audit bindings,
> Class A/B/C audits) closes this gap by giving Claude evidence-bearing
> checks it must follow, with measurable on-disk artefacts as proof.

## File Operation Policy (MANDATORY — self-contained)

**THE WRITE TOOL IS NOT RELIABLE FOR FILE PERSISTENCE.**

First documented April 2026 (last verified May 2026): the Claude Desktop
virtiofs mount silently drops Write tool calls to subdirectory paths.
If this is no longer reproducible in your environment, the bash side-
file + mv-swap protocol remains REQUIRED for Class 1 (new file
creation) regardless — the protocol is also POSIX-atomic and works
identically across every environment tested, so there is no benefit
to backing it out. This policy is self-contained.

**Critical-path files:** `pipeline-checkpoint.md`, `reports/ch{NN}-*.md`,
`market-pulse.md`, `research-bible.md`, `chapter-briefs/ch{NN}-brief.md`,
`chapters/ch{NN}.md`, `summaries/ch{NN}-summary.md`, `entity-canon.md`,
`running-banlist.md`, `project-config.md`.

**Write protocol (MANDATORY):**
```bash
# Set the target path explicitly so it can be reused for the temp path.
TARGET={target-path}

# Write to a SAME-FILESYSTEM temp file. Cross-device mv (e.g., /tmp →
# workspace mount) is non-atomic — copy+unlink falls back when the
# filesystems differ, and in some sandboxes (Cowork: /tmp vs.
# /sessions/.../mnt/) the unlink step is denied. Net result: silent
# overwrite-failure where the source lands in /tmp but the target is
# left unchanged, AND `stat -c %s` returns the OLD size on overwrite-
# failure. Same-FS rename is POSIX-atomic and works in every env tested.
TMP="${TARGET}.tmp.$$"
cat > "$TMP" << 'PAYLOAD_EOF'
{content}
PAYLOAD_EOF
mv "$TMP" "$TARGET"
sync
ls -la "$TARGET"
ACTUAL=$(stat -c %s "$TARGET")
if [ -z "$ACTUAL" ] || [ "$ACTUAL" = "0" ]; then
    echo "ERROR: write failed for $TARGET (actual bytes: '$ACTUAL')"
    exit 1
fi
```

If ls or stat fails, re-run. Only after byte-count passes, update
checkpoint. The checkpoint update itself uses this same protocol.

**Do NOT use the Write tool for any critical-path file.**
**Do NOT use the Edit tool for any critical-path file.**
**Do NOT use the Read tool to verify existence.**
**Do NOT dispatch to a subagent for any file-writing step.**

**Stale bash-mount troubleshooting (occasional; harness-level):**

In some sandboxed environments the bash workspace's view of the user's
Documents folder can become stale relative to the harness's view —
Edit/Write tool calls reach disk through the harness, but the bash
mount sometimes doesn't invalidate its cache. Symptom: `Read` tool
shows the chapter at (say) 3,785 words; `wc -w` from bash on the same
file shows 2,407 words. The two disagree because bash is reading a
snapshot.

**Diagnostic — one command tells you the answer:**

```bash
# Compare bash word count against the harness-reported size.
echo "bash sees: $(wc -w < {chapter-path}) words"
# If this is dramatically lower than what the Read tool just showed,
# the bash mount is stale.
```

**Workaround (works without restart):**

1. Write the live chapter content to a fresh path under `/tmp/` or
   under a different subdirectory of the project — somewhere the stale
   bash cache hasn't pinned. The harness writes through; bash reads
   cleanly from the new path.
2. Run audits / exports / mechanical checks against the fresh path.
3. The canonical chapter file at the original path is still correct
   (harness wrote through; it's just bash's *view* that was stale).
   The Read-tool verification you've already done is sufficient
   evidence.

**Or restart the session.** Restart is safe — files on disk persist
through the harness; restarting only flushes the cached bash view.
Nothing on disk is lost (chapter file, .docx, project-config,
checkpoint, all persist). After restart, `wc -w` should match what
`Read` shows.

**Why this matters for the pipeline:** while the mount is stale, any
bash-based audit (`word-count-check.sh`, `formatting-check.sh`,
`manuscript-audit.sh`, the orchestrator, the Pre-Flight gate) will
read the stale view and may report false-FAIL — "below 90% target",
"file truncated", "missing terminal punctuation" — on a chapter that
is in fact complete. If a chapter passes a Read-tool word-count sanity
check but fails a bash audit with a much-lower count, suspect a stale
mount before suspecting the chapter.

## Rule 1: Accuracy-Gate Five (Per-Chapter Verification) After EVERY Chapter

After writing each chapter, you MUST run ALL 5 agents in the
**Accuracy-Gate Five**: Source Guardian, Evidence Auditor, Citation
Keeper, Expert Tracker, Argument Analyst. This is the **per-chapter
verification** suite — NOT the same as the post-writing mechanical
checks (word count, placeholders, attribution scan), and NOT the same
as the **Editorial Five** (Proofreader, Copy Editor, Developmental
Editor, Alpha Reader, Beta Reader) which runs at the **end of the
manuscript** as part of the Editorial pipeline (Stage 0 + 13 numbered
+ 2 conditional editorial stages).

**Post-writing checks (word count, formatting) ≠ Accuracy-Gate Five (per-chapter verification).**
Completing post-writing checks does NOT satisfy the verification requirement.
**Accuracy-Gate Five ≠ Editorial Five.** The Accuracy-Gate Five runs
**every chapter** as you write; the Editorial Five runs **once at the
end** of the manuscript during the editorial pipeline. Substituting one
for the other is a common reading error; the names are deliberately
distinct so a fast reader cannot conflate them.

**Agent names and scoring are LOCKED (DO NOT SUBSTITUTE):**

| Agent | Role | Score Range |
|---|---|---|
| **Source Guardian** | Source accuracy, citation validity | 0–100 |
| **Evidence Auditor** | Claim support, evidence strength | 0–100 |
| **Citation Keeper** | Citation format, attribution completeness | 0–100 |
| **Expert Tracker** | Expert credential verification, balance | 0–100 |
| **Argument Analyst** | Thesis coherence, argument progression | 0–100 |

Scoring is NUMERIC (0–100), not PASS/FAIL. V-Score is the weighted
average. A V-Score of 100 should be exceptionally rare — well-written
prose still has issues that a careful Evidence Auditor or Argument
Analyst will surface. A perfect 100 across all five agents on a real
manuscript chapter is a stronger signal of agent under-engagement
(or fabricated scores) than of perfection.

**V-Score = 100 HARD GATE (hallucination defense):** if the
weighted V-Score equals 100 — or if all five individual agent scores
are 100 — STOP. Do NOT mark the chapter verified. Re-dispatch the
five agents with an explicit "be skeptical; find at least one
concrete improvement opportunity" instruction. The second-pass
result is the binding one. If the second pass also returns 100,
flag the chapter for user review with the verdict "verification
returned an implausible result twice — please spot-check by hand
before accepting." Log the double-100 occurrence to
`engine-data/run.log` for cross-chapter pattern detection.

After all 5 agents run:
1. Calculate the weighted cross-agent score (V-Score)
2. Save the report to `engine-data/reports/ch{NN}-verification.md`
   using the bash-direct write protocol from the File Operation Policy
3. Verify the file with Bash `ls + stat` (existence + non-zero bytes)
4. Display the Progress Dashboard with ALL 5 numeric scores
5. Update the pipeline checkpoint

**If you skip this step, errors compound across chapters.**

## Rule 1b: Class B Delta Pass (Per-Chapter, runs after Accuracy-Gate Five)

After the Accuracy-Gate Five completes and BEFORE the Progress
Dashboard renders, run the per-chapter Class B Delta Pass via the
validate dispatcher in delta mode:

```bash
bash scripts/validate-dispatcher.sh --delta --chapter {NN} "{project-root}"
```

This dispatches the two per-chapter Class B subagent audits:

- **`leitmotif-tracker-delta`** (COHERENCE domain) — scans this
  chapter for new motif instances, compares against the running
  `engine-data/reports/leitmotif-ledger.md`, flags PRESENCE-MISS or
  EVOLUTION-FLAT findings.
- **`injury-accumulation-delta`** (PHYSICS domain) — scans this
  chapter for new injuries / recoveries / actions, compares against
  the running `engine-data/reports/injury-ledger.md`, flags
  CAPABILITY-VIOLATION or RECOVERY-IMPLAUSIBLE findings.

Both audits use the v2.7.32 Class B dispatch protocol (CLASS_B_AUDIT
marker line → engine layer dispatches subagent → HARD GATE on
return → merge verdict). See `leitmotif-tracker-delta.md` and
`injury-accumulation-delta.md` for the audit specs.

**Why per-chapter, not end-of-manuscript:** motif drift and injury
continuity violations are cheap to fix at write-time and expensive
to retro-revise after subsequent chapters depend on the broken
state. The per-chapter delta catches each divergence the moment it
lands; the full-manuscript versions still run at Phase 5 Stage 9.5
(Canon Validation Sweep) for final-arc verification.

**Verdict handling.** Findings surface on the Progress Dashboard
alongside the V-Score but do NOT block chapter approval — the
writer chooses whether to revise now or carry forward. Two other
Class B audits (humanity-gate, intent-preservation) do NOT run
per-chapter because they need manuscript-scope evidence; they run
once at Stage 9.5 only.

**Cost discipline.** Two extra subagent dispatches per chapter
(~30 dispatches for a 30-chapter epic + 4 at Stage 9.5 = ~64 total
vs the pre-v2.7.61 pattern of 4 at Stage 9.5 only). The catch-cheap
trade-off justifies the cost; if a project needs to opt out,
append `class_b_delta_status: skip` to
`engine-data/project-config.md` (the dispatcher honours the
declaration and skips per-chapter delta runs; Stage 9.5 still
runs as the safety net).

**Category-aware default (v2.7.63 — NF-specific).** The per-chapter
delta is **on by default for narrative non-fiction** (memoir,
biography, true crime, literary journalism, narrative history,
microhistory, travel writing, nature writing, sports narrative, etc.)
where leitmotifs + injury / physical-event continuity actually apply,
and **auto-skipped for argumentative non-fiction** (self-help,
business, economics-finance, personal-finance, psychology-popular,
philosophy-popular, popular-science, health-wellness, fitness,
how-to-guide, cooking, education, parenting, technology,
religion-spirituality). The `class-b-delta-gate.sh` reads
`engine-data/project-config.md` and:

- Honors `class_b_delta_status: skip` (existing explicit opt-out)
- Honors `class_b_delta_status: enable` (new v2.7.63 explicit override
  — force the audits on even for argumentative-NF categories)
- Auto-skips when `nf_shape: argumentative` is declared
- Auto-skips when `nf_category:` matches the argumentative list above
- Otherwise enforces the per-chapter Class B Delta Pass

Auto-skips print a clear rationale message identifying which signal
matched (`nf_shape` or specific `nf_category`). The Stage 9.5 Canon
Validation Sweep still runs in all cases as the manuscript-scope
safety net.

## Em-Dash Policy (Non-Fiction)

**Default rule:** Zero em-dashes in NF narration, description, and
analysis. The Content Writer, Humaniser, and Batch Editor target
ZERO em-dashes in all generated prose.

**Single exception:** Up to 2 em-dashes per chapter are permitted
*inside direct quotations* — where they reproduce the source
verbatim and the engine cannot rewrite. The exception does NOT
license em-dashes anywhere else; if narration or paraphrased
analysis uses an em-dash, that is a violation regardless of
chapter-level count.

See `content-writer.md` EM DASH RULES for the full specification
(span-extraction logic, quotation detection, narration vs dialogue
boundary handling).

## Rule 2: Pre-Flight Check Before Every New Chapter

Before starting the Structural Architect for Chapter N+1:
1. Read `engine-data/pipeline-checkpoint.md`
2. Confirm the previous chapter has ALL fields completed
3. If ANY field is missing: STOP and complete it before proceeding

**Pre-Flight file reconciliation (MANDATORY):**

Before trusting checkpoint fields, reconcile each "Yes" against disk:
```bash
ls -la {file} && stat -c %s {file}
```
If missing or zero bytes: flip to "No", log via the engine's standard
error stream and add a note to `engine-data/pipeline-checkpoint.md`,
alert the user, re-run the failed step.

**Gate enforcement (MANDATORY):**

Before generating Chapter N, run:

```bash
bash scripts/pre-flight-gate.sh "{project-root}" {chapter-N}
```

The gate checks: Research Bible exists, pipeline-checkpoint.md exists,
prior-chapter summary or "Chapter N-1: complete" marker present (when
N > 1), and (warning only) entity-canon.md present after chapter 3. If
the gate exits non-zero, STOP. Resolve the missing prerequisite and
re-run the gate. Only when the gate exits zero may Chapter N begin.
See `pre-flight-gate.sh` for the exact checklist.

**Legacy opt-out:** for projects that pre-date Cowork Phase 3 and
whose chapters were written without the pre-flight checklist existing,
append to `engine-data/project-config.md`:

```
pre_flight_status: legacy
pre_flight_legacy_through: <highest legacy chapter>   # optional cap
```

The gate honors the declaration and passes. Without
`pre_flight_legacy_through`, all chapters pass; with the cap, only
chapters ≤ N pass under the legacy banner — chapter N+1 onward must
satisfy the real checklist.

## Rule 3: Progress Dashboard After Every Chapter

The user MUST see a formatted dashboard with all 5 agent scores, word
count, issue counts, and the progress bar. This is the user's only
evidence that the pipeline is working.

## Rule 4: Never Offer to Skip Verification

Do NOT offer "skip future reviews" or suggest batching verification.
The 5-agent suite runs per-chapter, automatically.

## Rule 5: Authority Voice Profile Loaded for ALL Manuscripts

Load the Authority Voice Profile from Research Bible Section 3 for
EVERY chapter. The Structural Architect, Content Writer, and Evidence
Auditor all need it.

**Gate enforcement (MANDATORY, v2.7.65+):**

The Authority Voice Profile from Research Bible Section 3 is the
LLM-contract piece. The artifact-level piece is
`engine-data/voice-profile.md` — the calibration corpus the audit
pipeline measures against. Before any chapter is generated, the
voice-profile-preload-gate (invoked as Check 6 of pre-flight-gate.sh)
verifies the file exists and contains the required fields:

```bash
bash scripts/voice-profile-preload-gate.sh "{project-root}"
```

This blocks chapter generation if `voice-profile.md` is missing,
empty, or skeleton-only (no `fp_target:`, no
`voice_calibration_exemplar:`, no `voice_prose_description:`). See
`references/voice-profile.md` for the canonical template.

**Why this is gated, not just a contract:** v2.7.64 and earlier
enforced voice loading purely as an LLM contract ("the Writer
prompt has the voice profile loaded"). The 6-book NF series voice
diagnostic showed catastrophic drift even under that contract —
Vol 2 shipped with thirteen chapters at zero first-person, series
window-mean FP=0.019 against a target of 0.25. The drift was
invisible to per-chapter audits because each individual chapter
was "explainable." The artifact-level gate makes the calibration
corpus a verifiable precondition, and the new
`voice-metrics-audit.sh` + `voice-trend-audit.sh` modules (run
automatically as Modules 9-10 of `ideorix-audit.sh`) measure the
chapters against it so drift gets caught at write-time, not at
publication.

**Documented opt-outs:** append to `engine-data/project-config.md`:

```
voice_profile_status: legacy   # manuscript pre-dates v2.7.65
voice_profile_status: skip     # voice-consistency not a deliverable
                               # (reference / cookbook / pure-data)
voice_trend_status: skip       # disable cross-chapter drift audit
voice_trend_status: legacy     # pre-v2.7.65 voice-metrics data
```

The gates honor the declaration and pass.

**Restoration workflow (v2.7.66+):** when the trend audit FAILs and a
chapter needs rewriting, the user can invoke the Voice Restoration
Brief — a per-chapter Class B diagnostic that produces a structured
rewrite plan (paragraph classification, target-voice exemplar
quotes, rewrite hints, risk callouts). The brief never rewrites
prose; the writer rewrites by hand using it as the guide. Trigger:

```bash
bash scripts/validate-dispatcher.sh "{project-root}" restore {N}
```

See `references/voice-restoration-brief.md` for the full audit
contract.

**Higher-fidelity drift signal (v2.7.67+):** the v2.7.65 fp_ratio is
a syntactic proxy ("paragraphs containing first-person pronouns /
total paragraphs"). It catches catastrophic drift but produces
false-INFO/WARN on chapters with legitimately recessed author-voice
(extended quoted dialogue, biographical detours, case studies). The
paragraph-classifier audit produces a per-paragraph semantic
classification (ANCHOR-NARRATIVE / ANALYTICAL-AUTHOR /
EXPOSITORY-THIRDPARTY / DIALOGUE / META-STRUCTURAL); voice-metrics-
audit reads the classifier artifact when present and emits a
semantic_fp_ratio (FP-presence within author-voice paragraphs only)
alongside the existing fp_ratio. The trend audit prefers semantic
when ≥3 of the window's chapters have it. Trigger:

```bash
bash scripts/validate-dispatcher.sh "{project-root}" classify {N}
```

Run once per chapter (typically before invoking the restoration
brief, so the brief can use the pre-computed classification as a
starting point). The artifact persists at
`engine-data/reports/validate/paragraph-classifier-ch{NN}-subagent.md`
and is automatically picked up by voice-metrics-audit's next run.
See `references/paragraph-classifier.md` for the full audit contract.

Phase 5 Stage 14 (auto-rewrite when drift is detected) is deferred
to v2.7.68 or beyond — auto-rewrite touches prose and is held until
the brief workflow has been used in practice and rewrite patterns
are well-understood.

## Rule 6: Batch Deep Edit Every 5 Chapters (MANDATORY)

After completing Chapter 5, 10, 15, 20, 25 (and the final chapter),
run the Batch Editor across the last 5 chapters BEFORE starting the
next chapter.

## Rule 7: Full Manuscript Editorial Pass After Final Chapter

After the FINAL chapter, run the full Phase 5 Editorial Pipeline
before delivery.

**Phase 6 gate sweep (MANDATORY — v2.7.68+):**

Phase 6 covers cover design, marketing pack, KDP metadata, and
launch sequencing. v2.7.67 and earlier enforced these as
LLM-contract rules — Claude was supposed to follow the
cover-designer / marketing-expert / publishing-formats specs,
but nothing verified at the artifact level. The result: covers
generated as 3D product renders instead of book covers; marketing
briefs that omitted the cover-image section entirely; KDP
metadata uploaded with half-completed fields.

v2.7.68 closes this with five new gates:

```bash
bash scripts/cover-brief-gate.sh           "{project-root}"  # cover concept structured per cover-designer.md
bash scripts/marketing-pack-gate.sh        "{project-root}"  # marketing-brief.docx + 5 core sections + cover dependency
bash scripts/kdp-metadata-gate.sh          "{project-root}"  # KDP file present + 7 keywords + 3 BISACs + comps + pricing
bash scripts/pre-export-typography-gate.sh "{project-root}"  # source typography clean (pairs with v2.7.64 post-write DOCX gate)
bash scripts/launch-readiness-gate.sh      "{project-root}"  # composite meta-gate: all four + manuscript export
```

Each gate fails closed when its precondition is unmet and prints
a specific diagnostic + ACTION. The launch readiness gate is the
single command for "is this project ready to ship?" — it chains
the four constituent gates plus a manuscript-export check.

**Documented opt-outs:** append to `engine-data/project-config.md`:

```
cover_status: legacy | skip                 # cover design out of scope
marketing_status: legacy | skip             # marketing pack out of scope
kdp_status: legacy | skip                   # KDP submission out of scope
typography_status: legacy | skip            # bypass typography sweep
typography_target: ascii                    # project deliberately uses ASCII typography
launch_readiness_status: legacy | skip      # bypass the composite meta-check
```

The gates honor each declaration and pass. Use sparingly —
each opt-out is a documented decision that voice / cover /
marketing / KDP isn't a deliverable for this specific project.

## Rule 8: ALWAYS Run Market Scout Before Research Bible (MANDATORY)

Before generating the Research Bible, ALWAYS run Market Scout to
assess the current marketplace — bestsellers, gaps, reader demand,
comparable titles, and positioning opportunities. Save the report to
`engine-data/market-pulse.md` and present key findings to the user
BEFORE Research Bible generation begins.

**Offline fallback:** If web search is unavailable, write a minimal
`engine-data/market-pulse.md` with
`STATUS: offline — market scout skipped` and confirm with the user
via AskUserQuestion before continuing.

**Record the status in the project config (MANDATORY):**

After creating the offline stub, append these lines to
`engine-data/project-config.md` using the bash-direct write protocol:
```
market_intelligence_status: offline
market_intelligence_last_attempt: {ISO-8601 timestamp}
```

**Retry path:** At any later point, the user can say "re-run Market
Scout" to re-attempt. If successful, overwrite `market-pulse.md` and
update `market_intelligence_status: live` +
`market_intelligence_last_run: {timestamp}` in `project-config.md`.

**Dashboard flag:** While `market_intelligence_status` is `offline`,
every Progress Dashboard must include a visible line:
`Market intelligence: OFFLINE — retry when online`.

**Why:** A non-fiction book built without market awareness risks
duplicating existing titles. Market Scout ensures the thesis, angle,
and positioning are differentiated from the start. This applies to
EVERY project regardless of how the outline was sourced.

**Gate enforcement (MANDATORY):**

Before any downstream action that depends on market intelligence
(cover design, marketing pack, KDP prep, launch sequencing), run:

```bash
bash scripts/market-scout-gate.sh "{project-root}" [staleness-days]
```

Default staleness cap is 180 days. If the gate exits non-zero
(`market-pulse.md` missing or older than the cap), STOP. Re-run
Market Scout to refresh `engine-data/market-pulse.md`, then re-run
the gate. Only when the gate exits zero may the downstream action
proceed. See `market-scout-gate.sh` for the exact check.

**Documented opt-out:** if web search is unavailable, the project
pre-dates Rule 8, or the staleness is acknowledged and won't be
refreshed before launch, append one of these lines to
`engine-data/project-config.md`:

```
market_intelligence_status: offline   # web search unavailable
market_intelligence_status: stale     # last live run > cap, no refresh planned
market_intelligence_status: legacy    # project pre-dates Rule 8
```

The gate honors the declaration and passes. This matches the v2.3.5
Market Scout opt-out convention used elsewhere in the engine (offline
fallback, retry path, dashboard flag).

## Rule 9: ONE Chapter at a Time — User Approval Required (MANDATORY)

**Write chapters sequentially, ONE at a time.** After each chapter
completes its full cycle (Architect → Writer → Humaniser →
Verification → Dashboard), present the completed chapter to the user
and WAIT for approval before starting the next chapter.

**Do NOT:**
- Offer to write multiple chapters at once
- Auto-continue to the next chapter without user approval
- Batch-generate chapters to "save time"
- Skip the approval step between chapters for any reason

**Why:** Chapter-by-chapter approval ensures the user maintains
creative control. Batch generation removes the user from the loop
and produces chapters that compound errors without correction.

**Documented user override (rare):** If the user has explicitly assumed
the risk and wants the engine to chain multiple chapters in one turn
(e.g., a power user finalising a draft where each chapter has already
been individually approved in a prior session, or a back-to-back
rerun of two adjacent chapters after a fix), the engine MAY chain on
user request only if ALL of the following are true:
1. The user has stated the override explicitly in the current turn
   ("Yes, chain chapters N and N+1 in one go — I take responsibility
   for skipping the per-chapter approval gate").
2. The engine appends a log line to `engine-data/project-config.md`
   under a `## User Overrides` section recording: ISO timestamp,
   override scope (chapters affected), and the verbatim user quote.
   Use the bash side-file + mv-swap protocol if creating the file;
   Edit tool for append-to-existing.
3. Per-chapter verification (Architect → Writer → Humaniser →
   Verification → Dashboard) still runs for every chapter; only the
   between-chapter approval pause is waived.

The override is per-request, not session-sticky. The default is
always Rule 9 strict.

## Rule 10: Outline Conformance Report MUST Exist Before Brief is Shown (MANDATORY)

The Outline Conformance Agent (see `outline-conformance.md`) is the
engine's ONLY brief-time verifier — it runs at Phase 3 step 5a, BEFORE
the chapter brief is presented to the user at the User Review Gate
(step 6).

**The rule:** You MAY NOT present any chapter brief to the user until
`engine-data/reports/ch{NN}-outline-conformance.md` has been written
to disk AND verified with Bash `ls` per the File Operation Policy in
core-pipeline.md.

**Do NOT:**
- Skip step 5a because the brief "looks obviously aligned with Section 9"
- Narrate the conformance check and proceed to step 6 without actually
  running the agent
- Present the brief and the conformance report in the same message
  while silently skipping the agent run (a hallucinated report is a
  worse failure than a missing one)
- Treat a clean-looking brief as evidence that the check can be skipped

**Required execution order for EVERY chapter:**
1. Structural Architect generates the draft brief (step 5)
2. Outline Conformance Agent runs against the draft (step 5a)
3. Report file is written to `engine-data/reports/ch{NN}-outline-conformance.md`
4. Verify the report file exists with Bash `ls {project-path}/engine-data/reports/ch{NN}-outline-conformance.md` — do NOT use the Read tool for existence verification (see File Operation Policy in core-pipeline.md)
5. Update the pipeline checkpoint: OC Report = Yes, OC Verdict = PASS/WARN/FAIL
6. ONLY THEN present the brief + the report to the user (step 6)

**Why this rule exists:** The Outline Conformance Agent was specified
as "MANDATORY, BLOCKING" at step 5a but was skipped on a Chapter 12
brief in a production run. The skipped check would have caught a
Story Bible Mythology Discipline violation. The user caught the
violation manually, but the whole point of the OC Agent is that users
should NOT have to catch drift themselves. On the non-fiction side
the equivalent risks are silent counter-argument drops, unauthorised
new sources that bypass the source ledger, and thesis-contribution
re-scoping that leaves downstream chapters with nothing new to say.
The check must actually run, every time, before the brief is shown —
and its verdict must flow through the pipeline checkpoint to the
post-chapter Progress Dashboard so the user has visible confirmation
that it ran.

**Enforcement:** The pre-flight check before starting Chapter N+1
reads the pipeline checkpoint and refuses to start a new chapter if
Chapter N shows `OC Report: No` or `OC Verdict: -`. See
`core-pipeline.md` Pre-Flight Check protocol.

**Gate enforcement (MANDATORY):**

After Chapter N is complete and before advancing to Chapter N+1, run:

```bash
bash scripts/outline-conformance-gate.sh "{project-root}" {chapter-N}
```

The gate passes when either
`engine-data/reports/outline-conformance-{N}.md` exists and contains
`Status: PASS`, OR `engine-data/pipeline-checkpoint.md` contains a
line of the form `Outline Conformance {N}: complete`. If the gate
exits non-zero, STOP. Run the Outline Conformance verifier on chapter
N (or append the checkpoint marker if the verifier already ran), then
re-run the gate. Only when the gate exits zero may Chapter N+1 begin.
See `outline-conformance-gate.sh` for the exact check.

**Legacy opt-out:** Rule 10 was added to catch drift between the
Structural Architect's chapter brief and the manuscript outline at
*brief generation time*. For projects that were written before Rule
10 existed, retrospective OC reports catch nothing — the chapters are
already written, fact-checked, and verified. Append to
`engine-data/project-config.md`:

```
outline_conformance_status: legacy
outline_conformance_legacy_through: <highest legacy chapter>   # optional cap
```

The gate honors the declaration and passes. With
`outline_conformance_legacy_through: 21`, chapters 1-21 pass under
the legacy banner; chapter 22 onward must produce a real OC report.
