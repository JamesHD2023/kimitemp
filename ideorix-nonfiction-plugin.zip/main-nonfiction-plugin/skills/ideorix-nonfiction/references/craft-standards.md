---
name: craft-standards-nonfiction
description: "Universal non-fiction prose rules, craft commandments, and quality standards"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Non-Fiction Craft Standards

## The 7 Non-Fiction Craft Commandments

Every chapter of every non-fiction manuscript must honour these commandments.
They are scored by the Evidence Auditor (0-10 each, 70 total).

### 1. EVIDENCE NOT ASSERTION (weight: highest)

Never state a factual claim without supporting evidence. The evidence appears
before or alongside the claim. never as an afterthought appended to justify
a pre-stated position.

**Strong:** "A 2024 MIT study of 12,000 remote workers found that productivity
increased 13% when employees chose their own schedules. suggesting that
autonomy, not location, drives performance."

**Weak:** "Remote work increases productivity. Studies have shown this."

**Automatic fail:** Claims presented as fact with no source, no qualifier,
and no analytical framework. "Everyone knows..." "It's obvious that..."
"Experts agree..." (which experts? cite them).

### 2. CLEAR ATTRIBUTION

The reader must always be able to identify where information comes from.
Attribution can be woven into prose, cited formally, or signalled through
context. but it must be identifiable.

**Woven:** "When Daniel Kahneman and Amos Tversky ran their landmark 1979
experiment on loss aversion..."

**Formal:** "Loss aversion, first documented by Kahneman and Tversky (1979),
describes the tendency..."

**Unacceptable:** "Research has shown that people fear losses more than they
value gains." (Which research? When? By whom?)

### 3. DEFINED SCOPE

Each section should be explicit about what it covers. Scope creep is the most
common non-fiction structural failure. a section about market strategy that
drifts into organizational culture, then into leadership philosophy, then
into personal anecdote. Stay in the lane the Architect designed.

**Test:** Can you state this section's topic in one sentence? If you need
two sentences, the scope is too broad.

### 4. SPECIFIC EXAMPLES

Every abstract concept must be grounded in at least one concrete example.
Examples are how non-fiction earns the reader's trust. they prove the
author has done the work and isn't operating at the level of generality.

**Abstract:** "Innovation requires failure."
**Specific:** "When James Dyson built 5,126 failed vacuum prototypes between
1979 and 1984, each failure taught him something the previous one hadn't."

### 5. PACING = COMPLEXITY

Match prose rhythm to cognitive load:
- **Dense evidence sections:** Shorter paragraphs, clear topic sentences,
  frequent mini-summaries, white space between ideas
- **Narrative passages:** Longer paragraphs, flowing prose, sensory detail
- **Transitional passages:** Brief, directional, never laboured
- **Complex arguments:** Break into numbered steps or bullet points when
  prose alone would obscure the logic

### 6. JARGON MANAGEMENT

Define every technical term on first use. After definition, use freely.
Readers abandon books that make them feel stupid. and they should never
need to Google a term the author could have defined in six words.

**Exception:** If target audience is "specialist," industry-standard
terminology may be used without definition. But even specialists appreciate
precision.

### 7. ACCURATE DETAILS

Every fact must be verifiable. Dates, names, statistics, quotes, locations,
institutional details. all must match the source material. When in doubt,
check. When still in doubt, flag it.

**Zero tolerance for:** Wrong dates, misspelled names, misattributed quotes,
invented statistics, or "approximate" numbers presented as precise.

---

## Universal Non-Fiction Prose Rules

### Source Integration Styles

The author's preferred style (from the Authority Voice Profile) determines
how sources appear in prose:

| Style | How It Looks | Best For |
|-------|-------------|----------|
| **Woven narrative** | Sources appear as characters in the story: "When Smith discovered..." | Memoir, narrative NF, popular science |
| **Analytical citation** | Sources appear as evidence: "Smith (2024) found that..." | Academic, business, policy |
| **Expert witness** | Sources appear as voices: "'The data is unambiguous,' Smith told me." | Journalism, interview-based |
| **Invisible sourcing** | Facts presented confidently, sources in endnotes only | General audience, self-help |

### The "Just Lecture" Test

The non-fiction equivalent of fiction's "Just Talk" Test.

**Test:** If you remove all evidence, examples, anecdotes, and source material
from a section, is there still insight? If what remains is just a sequence of
unsupported assertions, the section fails.

**Every section must contain:**
- At least one specific piece of evidence (data, quote, study, example)
- At least one concrete illustration (anecdote, case study, scenario)
- A clear analytical point (not just "here are facts" but "here's what they mean")

### Paragraph Architecture

Non-fiction paragraphs follow a different rhythm than fiction:

**Topic sentence first**. In expository sections, lead with the paragraph's
main point. The reader should know what the paragraph is about from its
first sentence. (Narrative sections may defer the point for dramatic effect.)

**One idea per paragraph**. If a paragraph contains two distinct ideas,
split it. White space is your friend in non-fiction.

**Transitions matter**. The last sentence of each paragraph should connect
to the first sentence of the next. Abrupt topic shifts without transitions
are a structural failure.

### The Information Discovery Test

For every section where the author presents research, data, or evidence:
is it DRAMATISED or REPORTED?

A section that reads like a briefing needs at least ONE of:
- An anecdote or case study interleaved with the data
- A time pressure or narrative element creating urgency
- A counter-argument creating intellectual tension
- An emotional stake revealed by the information itself

Solo-exposition sections (pure data delivery with no narrative element)
must not exceed 30% of any chapter's sections.

---

## Punctuation Standards (12-Point Reference)

Non-fiction uses the same punctuation standards as fiction. See the universal
punctuation reference for the full 12-point ruleset.

**Proofreader enforces (7 mechanical rules):**
1. Direct address commas
2. Apostrophe accuracy
3. Reported speech punctuation
4. Colon usage
5. Introductory phrase commas
6. En dash vs hyphen
7. Slash filter

**Copy Editor enforces (5 stylistic rules):**
8. Dialogue tags vs action beats (for interview quotes)
9. Em dash vs ellipsis
10. Semicolon usage
11. Exclamation mark discipline (rare in non-fiction. max 1 per 5,000 words)
12. Ellipsis strategy

---

## Metonymy. Prose Enrichment

Metonymy substitutes a related attribute for the thing itself. It is one of the
clearest positive signals of human writing. AI almost never uses it unprompted,
defaulting instead to literal, explicit language.

**What it is:**
- "The White House" instead of "the US administration"
- "Whitehall" instead of "the British government"
- "Wall Street" instead of "the financial industry"
- "The bench" instead of "the judiciary"
- "Silicon Valley" instead of "the tech industry"
- "The Lancet" instead of "leading medical journals"

**Why it matters in non-fiction:** Metonymy compresses meaning and signals that
the author is embedded in the subject matter. A political writer says "the Hill"
not "Congress." A science writer says "the lab" not "the research facility."
The choice of metonym reveals the author's familiarity with the domain.

### Category-Specific Metonyms

The Writer should draw from metonyms natural to the category:

**Business / Finance:** Wall Street, the City (London finance), the market,
the boardroom, the bottom line, Main Street (ordinary economy)

**History / Politics:** the Crown, the Hill, Whitehall, the Kremlin, the
Élysée, the Oval Office, Downing Street, the floor (parliamentary debate)

**Science / Medicine:** the lab, the bench (laboratory research), the ward,
the lancet, the field (academic discipline), peer review (the system, not the act)

**True Crime / Journalism:** the beat, the wire, the desk (editorial),
the press, the fourth estate, Fleet Street

**Self-Help / Psychology:** the couch (therapy), the chair (authority/power)

**Memoir:** Place-as-identity metonyms specific to the author's story

### Usage Rules

- **Target:** 2-4 metonyms per chapter in non-fiction. Less than fiction. the
  priority is clarity over colour.
- **Audience-appropriate:** A general reader book can use "Wall Street." An
  academic text should use the literal term unless the metonym is field-standard.
- **First use clarity:** Context must establish the meaning on first appearance.
- **Don't force it:** Literal language is the default in non-fiction. Metonymy
  enriches, it doesn't replace precision.

---

## Em-Dash Policy (Two-Tier)

Em-dash handling depends on the project mode:

**AI-generated prose (Full Pipeline):**

Em-dashes are BANNED in all prose. Target: 0 in all narration and
description. Do not use em-dashes in any non-quoted prose output.
Replace every em-dash with the construction that best fits the context:

- **Subordinate clause:** use a comma or restructure the sentence
- **Parenthetical aside:** use parentheses or commas
- **Explanatory addition:** use a colon
- **Abrupt shift:** use a period and start a new sentence
- **Nothing:** Many em-dash phrases can simply be cut or restructured

Em-dashes ARE permitted in direct quotations only, where the original
source material uses them, up to a maximum of 2 per chapter. An
ellipsis means trailing off (the speaker chooses to stop). An em-dash
means being cut off (external interruption or abrupt halt).

**Direct-quote em-dash limit:** Maximum 2 per chapter. More than 2
direct-quote em-dashes per chapter means the prose is over-relying
on the device.

Any em-dash found outside of direct quotations is a violation and
must be removed.

**Human-written prose (Writers Studio / Edit & Revise):**

Em-dashes are permitted but density-limited. Target: 3 or fewer per
1,000 words. When editing human-written prose:
- Do NOT remove em-dashes that are used correctly
- DO flag when density exceeds 3 per 1,000 words
- Suggest alternatives for the weakest uses only

---

## Number-7 Bias

AI text generation has a measurable bias toward the number 7. All numbers in
non-fiction prose are scanned:
- Per-chapter threshold: >25% ending in 7 = replace for even distribution
- Manuscript-wide threshold: >15% = actively avoid in subsequent chapters
- Particularly important for statistics, dates, and quantities in non-fiction
  where numerical accuracy matters more than in fiction

---

## Citation Formatting Quick Reference

| Style | In-Text | Bibliography |
|-------|---------|-------------|
| **Chicago (Notes)** | Superscript numbers¹ → footnotes/endnotes | Bibliography at end |
| **APA** | (Author, Year) in text | References list at end |
| **MLA** | (Author Page) in text | Works Cited at end |
| **Harvard** | (Author Year) in text | Reference list at end |
| **Informal** | Woven into prose, endnotes for interested readers | Further Reading at end |

The selected citation style is locked during Phase 1 (Q10) and enforced
consistently by the Citation Keeper verification agent.
