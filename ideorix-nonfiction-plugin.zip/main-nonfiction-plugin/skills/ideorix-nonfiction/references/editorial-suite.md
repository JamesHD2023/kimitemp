---
name: editorial-suite
description: "Non-fiction editorial pipeline — Stage 0 Authority Profile pre-edit pass plus 13 numbered stages (Stage 1 Category-Specific Audit through Stage 13 Publication Readiness Assessment), plus 2 conditional stages (Stage 4.5 Repetition Sweep for manuscripts ≥40k words; Stage 14 Methodological Appendix Builder for academic / policy / scholarly orientation projects). Canonical reference count: Stage 0 + 13 numbered; up to 16 total when both conditional stages run."
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Non-Fiction Editorial Suite

## File-Write Hygiene (MANDATORY — applies to every chapter file any stage of this pipeline touches)

The non-fiction editorial pipeline runs Edit / rewrite
operations on the manuscript across multiple stages (Category
Audit → Proofreader → Copy Editor → Dev Editor → Alpha Reader
→ Beta Reader → Conflict Resolution → Surgical Fixes → Fact
Audit → Bias & Balance → Multi-Source Consistency → Revision
Loop → Publication Readiness). The chained-Edit truncation
safeguard documented in `core-pipeline.md` § Chained-Edit
Truncation Safeguard applies in full to every stage that
writes to a chapter file:

- **Prefer Write over chained Edit for chapter-scale rewrites.**
- **Cap individual Edit replacements at ~2 KB.**
- **Run `scripts/word-count-check.sh` after every chapter file
  any stage writes or edits**, not just at pipeline completion.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) before reporting per-stage success.

**HARD GATE — BLOCKING.** A truncated chapter file caught at
any stage MUST be repaired before the pipeline advances. The
multi-stage nature of this pipeline makes silent truncation
especially dangerous — a corrupted chapter that propagates
across three or four downstream stages may be unrecoverable.
For non-fiction, citation insertions and source attributions
are particularly vulnerable to silent loss; the Fact Audit
stage's own File-Write Hygiene section reinforces this.

## Overview

The editorial pipeline runs on the COMPLETE manuscript after all chapters are
written and verified. It provides manuscript-wide analysis that per-chapter
verification cannot — cross-chapter argument coherence, cumulative source
patterns, voice drift across the full work, and overall thesis delivery.

## Per-Stage File Freshness Check (MANDATORY)

**Before EACH editorial stage (not just pre-editorial),** verify that the
chapter files being read are the current versions:

```bash
stat -c '%Y %n' {path}/engine-data/chapters/ch*.md | sort -n
```

If any chapter file's timestamp is NEWER than the start of the current
editorial stage (i.e., the file was modified while editorial is running),
that stage MUST re-read the updated file before proceeding.

**Why:** Editorial can span hours or days. If a chapter is rewritten
mid-editorial (user request, surgical fix, recovery from truncation),
later stages must read the updated version, not a stale cache from
when the pipeline began. Adds <3 seconds per stage.

## Pipeline Stages

```
Stage 0:    Authority Profile (build/verify before editing)
Stage 1:    Category-Specific Audit
Stage 2:    Proofreader
Stage 3:    Copy Editor
Stage 4:    Developmental Editor
Stage 4.5:  Repetition Sweep (CONDITIONAL — manuscripts ≥40k words)
Stage 5:    Alpha Reader
Stage 6:    Beta Reader
Stage 7:    Conflict Resolution
Stage 8:    Surgical Fixes
Stage 9:    Full-Manuscript Fact Audit
Stage 10:   Bias & Balance Review (CONDITIONAL)
Stage 11:   Multi-Source Consistency Pass
Stage 12:   Revision Loop (CONDITIONAL)
Stage 13:   Publication Readiness Assessment
Stage 14:   Methodological Appendix Builder (CONDITIONAL — academic/policy projects)
```

---

## Stage 0: Authority Profile

### Output

Stage 0 MUST write `engine-data/editorial-stage0-authority-profile.md` summarising:
- Voice profile validated against Research Bible §3 (yes/no)
- Specific authority markers in the manuscript (3–5 examples)
- Any drift from the declared profile (with chapter+line references)
- Stage status: PASS / WARN / FAIL

### Detail

Build a forensic profile of the manuscript's voice BEFORE any editing begins.
If the project already has an Authority Voice Profile from Phase 2, validate
it against the actual manuscript prose. If the manuscript was brought in by a
user (Writers Studio), build the profile from scratch.

**Profile captures:**
- Tone position (academic ↔ conversational, objective ↔ opinionated)
- Evidence integration style
- Sentence architecture patterns
- Vocabulary level and jargon density
- Reader relationship approach
- Authority markers and credibility signals

**Golden rule:** A missed fix is better than a voice violation. The Authority
Profile takes precedence over all editorial suggestions.

---

## Stage 1: Category-Specific Audit

### Output

Stage 1 MUST write `engine-data/editorial-stage1-category-audit.md` summarising:
- Category file applied (e.g. memoir, popular-science)
- Category-specific checks run and findings
- Stage status: PASS / WARN / FAIL

### Detail

Load the category bank file and run category-specific checks:

- **Memoir:** Scene-to-summary ratio, transformation arc present, reflection depth
- **Biography:** Source diversity, subject dimensionality, context integration
- **Popular Science:** Analogy accuracy, consensus representation, jargon accessibility
- **Business:** Case study verification, framework consistency, actionability
- **History:** Primary source density, anachronism check, multi-perspective balance
- **True Crime:** Victim dignity, factual accuracy, speculation flagging
- **Self-Help:** Actionable takeaway per chapter, claim-evidence balance, credentials clarity
- **How-To:** Instruction accuracy, sequential correctness, completeness

---

## Stage 2: Proofreader

### Output

Stage 2 MUST write `engine-data/editorial-stage2-proofreader.md` summarising:
- Mechanical issues found (grammar, punctuation, citation format)
- Per-chapter counts
- Stage status: PASS / WARN / FAIL

### Detail

Grammar, spelling, punctuation, tense consistency, subject-verb agreement.
**Universal — same as fiction.** Non-fiction specific additions:
- Citation format consistency (matching selected style)
- Acronym/abbreviation expansion consistency
- Proper noun accuracy (real people, real places, real organisations)

---

## Stage 3: Copy Editor

### Output

Stage 3 MUST write `engine-data/editorial-stage3-copy-editor.md` summarising:
- Sentence-level changes by category (clarity, jargon, redundancy, transitions)
- Per-chapter counts
- Stage status: PASS / WARN / FAIL

### Detail

Word choice precision, sentence rhythm, clarity, readability.
Non-fiction specific additions:
- Jargon flagging (undefined technical terms)
- Source integration flow (citations woven naturally, not dumped)
- Redundancy check (same point made in multiple chapters without development)
- Transition quality between sections and chapters

---

## Stage 4: Developmental Editor

### Output

Stage 4 MUST write `engine-data/editorial-stage4-developmental.md` summarising:
- Structural assessment findings (thesis development, pacing, ordering)
- Counter-argument coverage check
- Conclusion-vs-introduction promise alignment
- Stage status: PASS / WARN / FAIL

### Detail

Full manuscript structure assessment:
- Does the thesis/argument develop across chapters?
- Is the information architecture working? (Does the reader know what they
  need to know when they need to know it?)
- Pacing: where does the book drag? Where does it rush?
- Are counter-arguments addressed at the right points?
- Does the conclusion deliver on the introduction's promise?
- Chapter ordering: would the book be stronger with chapters rearranged?

---

## Stage 4.5: Repetition Sweep (CONDITIONAL — recommended for manuscripts ≥40,000 words)

Cross-chapter argument-repetition detection and
consolidation pass. Sits between the Developmental Editor's
structural recommendations (Stage 4) and the Alpha Reader's
first-impression assessment (Stage 5). Catches recurring
arguments, phrases, and examples that appear across multiple
chapters and could be tightened — by replacing 1-2 instances
with explicit cross-references — rather than left as full
restatements. See `repetition-sweep.md` for the three
detection lanes (phrase-level, argument-level, example /
vignette), the consolidation report format, and the
KEEP / CROSS-REFERENCE / CONSOLIDATE / DELETE / TIGHTEN
recommendation taxonomy.

The Stage 4.5 output is
`engine-data/reports/repetition-sweep-{YYYY-MM-DD}.md` — a
structured consolidation report. The user (or the editorial
pipeline) actions the recommendations; the sweep does NOT
auto-consolidate (repetition is sometimes deliberate for
rhetorical reinforcement, pedagogical scaffolding, or motif).

This stage is RECOMMENDED for any manuscript ≥40,000 words.
For shorter works, the Developmental Editor's structural
feedback typically suffices and Stage 4.5 may be skipped.

→ See `repetition-sweep.md` for the full protocol.

## Stage 5: Alpha Reader

### Output format

Stage outputs MUST be written as `.md` files only:
  - `engine-data/editorial-stage5-alpha-reader.md`

If a `.docx` derivative is needed for human review, generate it on demand
from the `.md` source via `pandoc`. Do NOT keep both formats in
`engine-data/` — the mechanical audit and pipeline-checkpoint
reconciliation only track `.md`.

### System Prompt
```
You are an Alpha Reader — an intelligent, curious general reader. NOT an
expert in this subject. You represent the target audience: someone who
picked up this book because the topic interested them.

SCOPE RULE (MANDATORY): Read ONLY the chapter files in
engine-data/chapters/. Do NOT read chapter briefs, the Research Bible,
the outline, or any planning document. You are a reader, not a
production insider. Every quote in your report must come from the
chapter files and must appear verbatim in the prose. If you cannot find
a quote in the chapter text, do not use it.

Read as a READER, not an analyst. Report your genuine experience:
did you learn something? Were you engaged? Did you trust the author?
Could you follow the argument? Would you recommend this book?

DEPTH REQUIREMENT: Reference SPECIFIC chapters throughout. Every
observation must cite at least one chapter number. Each section requires
full paragraphs (3-6 sentences), not brief notes. The complete report
should be substantial and deeply detailed.
```

### Output Format (MANDATORY — use this exact structure)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  📖  ALPHA READER REPORT
  {Title} by {Author}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Overall Impression

| Metric | Score | Reaction |
|--------|-------|----------|
| **Story** | {N}% | {emoji} |
| **Reader Fit** | {N}% | {emoji} |

**Why {story_emoji}:**
{Full paragraph (4-6 sentences). What worked? What kept you reading?
What nearly lost you? Did the argument hold your attention as a non-
expert? When did you feel most engaged? Reference at least 3 chapters.}

**Why {fit_emoji}:**
{Full paragraph (4-6 sentences). How well did this match what you look
for in non-fiction? Did you feel smarter after reading? Was the author
trustworthy? Would you buy their next book? Reference chapters.}

**⭐ Favorite Line:**
> "{exact quote}" — Chapter {N}

{Full paragraph (3-4 sentences) on why this line landed.}

───────────────────────────────────────────────

## My Emotion by Chapter

| Ch | Title | Emotion | Strength | % |
|----|-------|---------|----------|---|
| 01 | {title} | {emoji} ({name}) | {●●●●○} | {N} |
| ... | ... | ... | ... | ... |

**Emotional Peak:** Chapter {N} — {2-3 sentences}
**Emotional Dip:** Chapter {N} — {2-3 sentences}
**Where I Almost Stopped:** {Chapter {N} — 2-3 sentences. Most valuable
data point in the report.}

───────────────────────────────────────────────

## Big Picture

### 🎯 Premise & Thesis
{Full paragraph (4-6 sentences). Is the central argument compelling?
Did it make you want to keep reading? When did the thesis become clear?
Is the opening strong enough to survive browsing? Reference chapters.}

### 📐 Structure & Flow
{Full paragraph (4-6 sentences). Did the book build logically? Could
you follow the argument? Were there chapters that felt out of order
or unnecessary? Did each chapter earn its place? Reference chapters.}

### ⏱️ Pacing
{Full paragraph (4-6 sentences). Where did it drag? Where did it fly?
Was the balance between explanation and evidence right? Did technical
sections feel too dense? Did narrative sections feel too light? Reference
specific chapters.}

### 🔬 Credibility
{Full paragraph (4-6 sentences). Did you trust the author? Did the
evidence convince you? Were there moments where you thought "really?"
Did the author acknowledge complexity and uncertainty, or oversimplify?
Reference chapters.}

### 🧭 Accessibility
{Full paragraph (4-6 sentences). Could you follow the argument without
being an expert? Were technical terms defined? Were analogies effective?
Was there a moment where you felt lost? Reference chapters.}

───────────────────────────────────────────────

## 💚 What Made Me Excited or Enlightened

{Bulleted list of 4-6 moments. EACH bullet: chapter number, what happened,
WHY it worked as a learning or engagement moment.}

## 🔶 What Felt Flat or Confusing

{Bulleted list of 3-5 moments. EACH bullet: chapter number, the issue,
a constructive suggestion for improvement.}

## 🔴 Holes or Issues to Fix

{Critical problems with chapter references, or "None found."}

## ❓ Questions Left in My Head

{Bulleted list of 3-5 questions. For each, note whether the unanswered
question WORKS (invites further reading), FRUSTRATES (feels like an
oversight), or IS DELIBERATE (clearly intentional).}

───────────────────────────────────────────────

## Final Thoughts

| Factor | Rating |
|--------|--------|
| **"I Can't Put It Down"** | {High / Moderate / Low} |
| **"Re-Read" Factor** | {High / Moderate / Low} |
| **Would Recommend** | {Yes / With caveats / No} |

**"I Can't Put It Down":** {Full paragraph (3-4 sentences).}
**"Re-Read" Factor:** {Full paragraph (3-4 sentences).}
**Would Recommend:** {Full paragraph (3-4 sentences). To whom? Why?}

**Final Summary:**
{Full paragraph (5-7 sentences). What worked at the highest level.
What would elevate it. End positive and motivating.}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Delivery Format

**MANDATORY:** After generating the Alpha Reader report, deliver it as a downloadable `.docx` file named `Alpha-Reader-Report-{Title}.docx`. The visual formatting (box-drawing lines, emoji indicators, tables, star ratings) must be preserved in the Word document using appropriate heading styles, table formatting, and Unicode characters. Also display the report inline for immediate reading.

---

## Stage 6: Beta Reader (Domain-Expert Persona Loop — v2.7.11)

Stage 6 was historically a single-pass simulation of a generic
"informed reader". As of v2.7.11, Stage 6 runs as a **persona
loop**: 4-8 domain-expert personas relevant to the manuscript's
subject matter, each loaded with specialist expertise, each
running a separate full pass on the chapters relevant to its
domain.

The previous generic-reader simulation missed factually-wrong
claims that domain experts would have caught immediately —
documented Volume 1 production failure included a chair-model-
number mistake (caught by an office-furniture historian persona),
a non-existent patent attribution (caught by a patent historian
persona), and multiple biographical errors (caught by a period-
specific historian persona). The persona loop closes that gap.

### Persona Enumeration (MANDATORY)

Per `beta-reader-personas.md`, the Architect identifies 4-8
domain-expert personas during Phase 2 (Bible construction) and
writes them to `engine-data/beta-reader-personas.md`. Each
persona has:

- A specific specialist territory (named scholars / works the
  persona would reference)
- A chapter list (which chapters this persona reads)
- A reading-list baseline (3-5 canonical works the persona's
  detection threshold rests on)
- Detection priorities (specific error classes this persona is
  best positioned to catch)

### Per-Persona Dispatch (MANDATORY — Subagent Output Verification binding)

The Beta Reader stage runs the persona loop:

1. Load `engine-data/beta-reader-personas.md`.
2. For each persona, dispatch a Beta Reader subagent with the
   persona's specialist context as system prompt. Per
   `subagent-output-verification.md`, the dispatch prompt MUST
   include explicit task scope, required evidence format
   (file path + line number + exact extracted text of the
   flagged claim + persona's domain-specific reasoning), and a
   FAILED_DISPATCH return contract.
3. Each persona returns a domain-specific report — flagged
   claims, contested-priority cases, attribution questions,
   technical mis-statements, jargon-precision concerns.
4. Main agent spot-checks at least one evidence item per
   persona return before treating the report as authoritative.
5. Aggregate all persona reports into the consolidated Stage 6
   output. Cross-persona contradictions are themselves findings
   (one persona accepts a claim another contests — the
   Architect resolves before Stage 7).

### Output format

Stage outputs MUST be written as `.md` files only:
  - `engine-data/editorial-stage6-beta-reader.md` (consolidated)
  - `engine-data/editorial-stage6-beta-reader-{persona-N}.md` (per-persona, one per persona)

If a `.docx` derivative is needed for human review, generate it on demand
from the `.md` source via `pandoc`. Do NOT keep both formats in
`engine-data/` — the mechanical audit and pipeline-checkpoint
reconciliation only track `.md`.

### System Prompt
```
You are a Beta Reader — a {category} subject expert who has read hundreds
of {category} books. You know what sells, what gets reviewed well, and what
readers in this category actually want.

SCOPE RULE (MANDATORY): Read ONLY the chapter files in
engine-data/chapters/. Do NOT read chapter briefs, the Research Bible,
the outline, or any planning document. You are a reader, not a
production insider. Every quote in your report must come from the
chapter files and must appear verbatim in the prose. If you cannot find
a quote in the chapter text, do not use it.

Read this manuscript as a CATEGORY-SAVVY READER: Is the research rigorous
enough? Are the claims original? How does it compare to the best in the
category? Would this sell?

DEPTH REQUIREMENT: Reference SPECIFIC chapters throughout. Full paragraphs
(3-6 sentences) for every section. The complete report should be as
detailed as the Alpha Reader report.
```

### Output Format (MANDATORY — use this exact structure)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  📚  BETA READER REPORT — {Category} Expert Assessment
  {Title} by {Author}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Overall Impression: {N} ⭐ (out of 5)

| Metric | Score | Reaction |
|--------|-------|----------|
| **Story** | {N}% | {emoji} |
| **Reader Fit** | {N}% | {emoji} |

**Why {story_emoji}:**
{Full paragraph (4-6 sentences). Category-specific — does this deliver
what {category} readers expect? How does research rigour compare to the
category's best? Are the claims original? Reference at least 3 chapters.}

**Why {fit_emoji}:**
{Full paragraph (4-6 sentences). As a category expert — how well does
this match your expectations? What would other experts in this field
think? Reference chapters.}

**⭐ Favorite Line:**
> "{exact quote}" — Chapter {N}

{Full paragraph (3-4 sentences) on why this works for a {category} reader.}

───────────────────────────────────────────────

## My Emotion by Chapter

| Ch | Title | Emotion | Strength | % |
|----|-------|---------|----------|---|
| ... | ... | ... | ... | ... |

**Emotional Peak:** Chapter {N} — {2-3 sentences}
**Emotional Dip:** Chapter {N} — {2-3 sentences}
**Where I Almost Stopped:** {Chapter {N} — 2-3 sentences.}

───────────────────────────────────────────────

## Expert Assessment

### Research & Evidence
{Full paragraph (4-6 sentences). Is the research rigorous enough for
this category? Are sources credible and current? How does source quality
compare to published leaders? Are there gaps a subject expert would
notice? Reference specific chapters and sources.}

### Argument & Originality
{Full paragraph (4-6 sentences). Are the claims original? Does this add
to the conversation or repackage common knowledge? What's the most
original contribution? What's the most derivative section? Reference
chapters.}

### Authority & Voice
{Full paragraph (4-6 sentences). Does the author sound credible? Is
the voice appropriate for this category and audience? How does the
authority compare to established voices in the field? Reference chapters.}

### Prose & Style
{Full paragraph (4-6 sentences). Is the writing effective for this type
of non-fiction? Are complex ideas explained clearly? Any passages that
feel AI-generated or try too hard? What prose moments impressed you?
Reference chapters.}

### Continuity & Accuracy
{Full paragraph (3-4 sentences). Any factual errors, contradictions,
or consistency problems that a subject expert would catch? Reference
chapters if issues found, or note as clean.}

───────────────────────────────────────────────

## Specific Feedback

### 💚 Favorite moments/lines
{Bulleted list of 4-6 highlights. EACH: chapter, what happened, WHY it
works for a {category} reader, how it compares to published {category} books.}

### 🔶 Least favorite / where attention drifted
{Bulleted list of 3-5 weak spots. EACH: chapter, the issue, a specific
constructive suggestion, whether this would bother general readers or
only category experts.}

### ❓ Questions left in my head
{Bulleted list of 3-5 questions. For each: the question, whether the
ambiguity WORKS / FRUSTRATES / IS DELIBERATE, and whether category
readers would accept or resist it.}

### 💔 Emotional reactions
{Full paragraph (3-4 sentences). How did the book make you FEEL as a
category expert? Did it change your thinking? Was there genuine insight?}

───────────────────────────────────────────────

## 📊 Category Scorecard

| Dimension | Score | Assessment |
|-----------|-------|-----------|
| **Category Authenticity** | {N}/100 | {2-3 sentences — does it feel like a real {category} book?} |
| **Market Readiness** | {N}/100 | {2-3 sentences — could this sell in today's market?} |

### Comp Titles
{For each of 2-3 titles: title, author, why comparable, where this
manuscript matches and diverges.}

### Market Notes
{Full paragraph (3-4 sentences). Market positioning, target demographic,
trend alignment.}

───────────────────────────────────────────────

## Final Thoughts

| Factor | Rating |
|--------|--------|
| **"I Can't Put It Down"** | {High / Moderate / Low} |
| **"Re-Read" Factor** | {High / Moderate / Low} |
| **Conventions** | {Fresh / Well-executed / Tired} |

**"I Can't Put It Down":** {Full paragraph (3-4 sentences).}
**"Re-Read" Factor:** {Full paragraph (3-4 sentences).}
**Conventions:** {Full paragraph (3-4 sentences).}

**Final Summary:**
{Full paragraph (5-7 sentences). Definitive category-expert wrap-up.
Single biggest strength. Single most impactful improvement. How it
compares to published books. End positive and motivating.}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Delivery Format

**MANDATORY:** After generating the Beta Reader report, deliver it as a downloadable `.docx` file named `Beta-Reader-Report-{Title}.docx`. The visual formatting (box-drawing lines, emoji indicators, tables, star ratings, category scorecard) must be preserved in the Word document using appropriate heading styles, table formatting, and Unicode characters. Also display the report inline for immediate reading.

---

## Stage 7: Conflict Resolution

Six editorial agents produce hundreds of recommendations. Some contradict:
the Copy Editor wants a shorter section; the Dev Editor says that argument
needs expansion. This stage detects contradictions, ranks all issues by
impact, and surfaces conflicts for the author.

---

## Stage 8: Surgical Fixes

Apply the top 5-7 highest-impact fixes with minimum edits. Every fix
checked against the Authority Voice Profile. Precision, not overhaul.

### Stage 8 — Tracked-Changes Mode (when user requests tracked output)

When the user requests editorial feedback as tracked-changes
rather than inline application — phrases like "track changes
rather than apply them", "give me a tracked-changes version",
"I want to review changes before accepting" — Stage 8 operates
in **tracked-changes mode** under the canonical protocol in
`tracked-changes.md`.

In tracked-changes mode, Stage 8 does NOT apply edits inline
to chapter MD files. Instead, it produces a structured change
record (one row per suggested edit) that the
`tracked-changes.md` Phase B / Phase C pipeline consumes to
emit a Word-compatible tracked-changes DOCX with mandatory
integrity verification.

**HARD REQUIREMENT — BLOCKING:** Any tracked-changes DOCX
emission MUST follow `tracked-changes.md` end-to-end. The
three-phase protocol (DOCX-Read with Integrity Capture →
Mark Changes on intermediate → DOCX-Write with Integrity
Verification) and the per-paragraph fingerprinting + word-
count parity + SHA256 base-text preservation checks at
Phase C are the structural counter-protocol against the
documented silent-paragraph-drop failure mode (mid-sentence
cutoffs at page boundaries that dropped 2-3 sentences in
operational use).

Stage 8 in tracked-changes mode MUST NOT emit the DOCX
without the integrity report verdict reading "READY FOR
DELIVERY". A NOT-READY verdict surfaces specific failures
(paragraph index missing / word count mismatch / SHA256
mismatch on paragraph X) to the user; the agent does NOT
ship a manuscript that has lost source content.

For non-fiction tracked-changes, the integrity check is
especially important because citation insertions and source
attributions are particularly vulnerable to silent loss
(the Fact Audit stage's own File-Write Hygiene section
already reinforces this). The tracked-changes integrity
report explicitly verifies that no citation footnote /
endnote / source attribution has been dropped during the
DOCX round-trip.

→ See `tracked-changes.md` for the full three-phase
protocol, integrity verification gates, and integrity
report format.

**Research Bible Section 9 reconciliation (MANDATORY — runs AFTER all
Stage 8 fixes are applied):**

If any fix MOVED a section between chapters (e.g., "move the key
argument from Ch 12 to Ch 11"), RESTRUCTURED a chapter's section
order, or REMOVED/ADDED significant content:

1. Identify which Section 9 entries are now stale (the chapter
   outline says "Ch 12 delivers the central thesis argument" but
   the fix moved it to Ch 11)
2. Update Research Bible Section 9 to reflect the post-fix reality
3. If this is a series project, verify the fix didn't break series
   continuity

**Why this matters:** Section 9 is the canonical reference for series
planning and future editorial passes. If it's stale after editorial
restructuring, downstream consumers will work from incorrect data.

Fixes that don't restructure (e.g., word choice, source attribution
corrections, jargon clarification) do NOT require Section 9 updates.

---

## Stage 9: Full-Manuscript Fact Audit (split 9a + 9b — v2.7.11)

Stage 9 is structurally split into two distinct sub-stages.
The previous single-stage design conflated internal-
consistency checking with external truth verification; the
latter was implementation-skipped while the former passed
cleanly — leading to documented production failures where six
substantive factual errors survived all 13 editorial pipeline
stages.

### Stage 9a — Internal Consistency Audit

Post-fix sweep building master reference tables for cross-
chapter consistency:

1. **Source Index** — Every source cited, where, and how many times
2. **Claim Registry** — Every factual claim with its supporting source
3. **Citation Cross-Reference** — Bibliography entries matched to in-text citations
4. **Date & Chronology Tracker** — Every date mentioned, verified for arithmetic consistency (ages match birth dates; durations match start/end markers)
5. **Expert Registry** — Every person named, their credentials, where they appear (consistency only — externally verified at 9b)
6. **Organisation Registry** — Every organisation named, verified details (consistency only — externally verified at 9b)
7. **Patent number format plausibility** — patents claimed for an era have format consistent with that era's actual numbering
8. **Name spelling consistency** — same person / place / organisation spelled the same way every time

Compare ALL references across the full manuscript against the
Research Bible. Flag any internal discrepancy — same fact
stated differently in two chapters is ALWAYS an error until
the author confirms otherwise.

Stage 9a verdict: PASS (no internal contradictions) or FAIL
(contradictions surfaced for resolution before 9b begins).

### Stage 9b — External Source Verification (NEW — v2.7.11)

After Stage 9a clears, every concrete factual claim in the
manuscript is mechanically verified against external sources
via WebSearch + WebFetch. See `fact-audit.md` § Stage 9
Architecture for the full Stage 9b protocol. Summary:

**Pending-Marker Resolution Gate (HARD GATE before 9b starts)**
— `scripts/pending-marker-scan.sh` MUST return zero matches
across the manuscript and chapter notes. Unresolved
"(pending fact-audit)" / "[verify]" / "TBD" / similar
placeholders BLOCK Stage 9b from starting until resolved.

**First-X Priority Flagging** — every "first commercial X" /
"first patented X" / "first to develop X" / "first to
manufacture X" claim is triangulated against at least two
independent secondary sources to detect contested-priority
cases. Contested cases are softened to acknowledge competing
claimants; non-contested cases are pinned to a primary source.

**Patent-Claim Handling Protocol** — every "[Person] patented
[X]" claim resolves to one of three states: verified patent
number cited (with database URL pinned), hedged framing
("filed for a patent" / "is widely credited with"), or removed
entirely.

**Concrete-claim coverage** — patent numbers, founding dates,
biographical specifics, statistics with specific numbers, named
historical events with dates, quoted claims from secondary
sources, specific product model numbers — all verified.

**Web-Content Verification binding** (`web-content-
verification.md`) MANDATORY for every WebSearch / WebFetch in
9b — paywall-stub detection, byte-count threshold, and retry-
and-distinguish for transient empty results.

**Subagent Output Verification binding** (`subagent-output-
verification.md`) MANDATORY for the 9b dispatch — evidence-
bearing return contract, main-agent spot-check of evidence,
FAILED_DISPATCH on missing or invalid evidence.

Stage 9b output: per-claim verification ledger
(`engine-data/verification-ledger.md`). Each row carries a
class (VERIFIED / SPECULATIVE / REJECTED) with pinned source
URL for VERIFIED and prose-marker phrasing for SPECULATIVE.

**Stage 9b HARD GATE:** zero unverified-uncategorized items in
the ledger before Stage 10 (or 11 / 13) can begin.

---

## Stage 9.5: Canon Validation Sweep (post-Fact-Audit Class B re-verification)

Run all four Class B canon-validation audits against the post-Stage-9b
manuscript. Stage 9.5 is the final-arc verification — it re-checks
what the per-chapter Class B Delta Pass already covered plus the two
audits that only work at manuscript scope.

```bash
bash scripts/validate-dispatcher.sh --full "{project-root}"
```

Audits dispatched:

| Audit | Domain | Per-chapter ran? | Why also here |
|---|---|---|---|
| `leitmotif-tracker` | COHERENCE | Yes (delta) | Full-arc verification — confirms motif/metaphor evolution arc landed across the manuscript (in NF: recurring metaphor / example arc that illustrates the central thesis) |
| `injury-accumulation` | PHYSICS | Yes (delta) | Applies to narrative non-fiction (memoir, biography, literary journalism) where physical-event continuity matters; soft-skip on argument-shaped NF where injuries don't feature |
| `humanity-gate` | CHARACTER | No (manuscript-only) | Per-character 7-criterion scorecards need the whole manuscript visible. NF scope: applies to memoir / biography / literary journalism where character interiority matters; soft-skip on reference / self-help where the audit isn't applicable |
| `intent-preservation` | INTENT PRESERVATION | No (manuscript-only) | Theme-leak detection + resolution test against the bible's declared thesis intent; works across all NF categories |

Each audit follows its own spec's HARD GATE return contract. The
sweep produces a consolidated report at
`engine-data/reports/canon-validation-sweep.md` (Class 1 file; use
the bash-direct write protocol). The four per-audit findings flow
into the final editorial report the writer reviews before delivery.

**Verdict handling.** Stage 9.5 findings surface as part of the
editorial report. FAIL verdicts on humanity-gate or
intent-preservation do NOT block Phase 6 delivery — these are
subjective audits designed to surface concerns, not enforce
thresholds. FAIL verdicts on leitmotif-tracker or
injury-accumulation at Stage 9.5 are typically caught by the
per-chapter delta already; if Stage 9.5 surfaces a NEW finding,
that's a delta-drift signal worth investigating.

**Gate enforcement (v2.7.62, MANDATORY).** After Stage 9.5 produces the
consolidated `engine-data/reports/canon-validation-sweep.md`, run:

```bash
bash scripts/canon-validation-sweep-gate.sh "{project-root}"
```

The gate verifies the sweep report exists, is non-empty, contains a
verdict line per Class B audit (leitmotif-tracker, injury-accumulation,
humanity-gate, intent-preservation), and isn't stale relative to the
most-recent chapter file. If the gate exits non-zero, STOP. Phase 6
Delivery MAY NOT proceed until the sweep report is complete and fresh.
See `canon-validation-sweep-gate.sh` for the exact checks.

**Opt-out.** Append `class_b_full_status: skip` to
`engine-data/project-config.md` to skip Stage 9.5 (not recommended;
the four audits are the manuscript-scale verification layer for
the COHERENCE, PHYSICS, CHARACTER, and INTENT PRESERVATION domains).

→ See `leitmotif-tracker.md`, `injury-accumulation.md`,
`humanity-gate.md`, `intent-preservation.md` for individual audit
specs.
→ See `validate-dispatcher.md` for the `--full` flag and the
sweep-aggregation protocol.

---

## Stage 10: Bias & Balance Review (CONDITIONAL)

Run if the manuscript covers controversial, political, social, or contested topics.

**Checks:**
- Are opposing viewpoints represented fairly (not straw-manned)?
- Is the author's position transparent (not disguised as neutrality)?
- Are marginalised perspectives included where relevant?
- Are cultural representations accurate and respectful?
- Does the book acknowledge its own limitations and biases?
- Are statistics presented in context (not cherry-picked)?

---

## Stage 11: Multi-Source Consistency Pass

Ensures the same source is used consistently across the manuscript:
- Same source cited the same way every time
- No contradictory claims from the same evidence
- Source reliability assessments consistent
- Expert positions quoted consistently (not selectively in different chapters)

---

## Stage 12: Revision Loop (CONDITIONAL)

Run when Alpha/Beta scores remain below convergence thresholds after Stage 8 fixes.

**Auto-activation:** If Alpha stars < 4.5 or Beta stars < 4.0 or
Category Fit < 85%, offer the revision loop.

See `revision-loop.md` for the full orchestrator protocol.
Iterates: analyse → diagnose → fix → validate until convergence.
Maximum 5 iterations, maximum 7 fixes per iteration.

---

## Stage 13: Publication Readiness Assessment

### Verification Discipline Gate (MANDATORY — BLOCKING — hardened v2.7.11)

Before this stage assesses any other readiness dimension, it
MUST first run the following five sub-gates in sequence. The
verdict can only be **READY FOR PUBLICATION** when all five
clear:

**Sub-gate 1 — Pending-Marker Scan (HARD GATE).**
Run `scripts/pending-marker-scan.sh` against the manuscript
directory and `engine-data/`. Any unresolved
"(pending fact-audit)" / "[verify]" / "TBD" / similar
placeholder BLOCKS publication. The pending-marker scan is
deterministic and re-runnable; it must return zero matches.

**Sub-gate 2 — Verification Ledger Completeness (HARD GATE).**
Check `engine-data/verification-ledger.md` produced by Stage 9b
(External Source Verification):

- Zero ledger entries are unverified-uncategorized
- Every VERIFIED entry has a pinned URL / DOI / source
- Every SPECULATIVE entry has explicit prose markers in the
  manuscript AND appears in
  `engine-data/speculative-content-map.md`
- Zero REJECTED items remain in prose
- The "pre-press fact-verify stack" item count is **0**

**Sub-gate 3 — Sampled VERIFIED Re-check (HARD GATE — v2.7.11).**
For at least 10% of VERIFIED ledger entries (minimum 5
entries; or all entries if fewer than 5 exist), the gate
runs WebFetch + Web-Content Verification on the pinned
URL/DOI to confirm the source resolves and contains the
claimed content. This applies the v2.7.7 Subagent Output
Verification binding to Stage 9b's output: the engine does
not trust the ledger's URL field at face value but spot-
checks a representative sample.

Failure of any sample (URL doesn't resolve, paywall stub,
content doesn't match the claim) downgrades the entry to
unverified-uncategorized in the ledger and BLOCKS Stage 13.
The audit must re-classify the entry (re-VERIFIED with
corrected URL, downgraded to SPECULATIVE with prose hedging,
or REJECTED) before Stage 13 re-runs.

**Sub-gate 4 — First-X Priority Sweep (HARD GATE — v2.7.11).**
Grep the manuscript for "first commercial" / "first patented"
/ "first to develop" / "first to manufacture" / "the first
[X]" patterns. Every match must:

- Have a corresponding ledger entry classified VERIFIED with
  a pinned source confirming the priority claim, OR
- Have a corresponding ledger entry classified SPECULATIVE
  with the contested-priority history mapped in
  `engine-data/speculative-content-map.md`, OR
- Have been rephrased in prose to avoid the priority claim
  entirely (verified by re-grepping after the rephrase)

Unmatched "first X" claims BLOCK Stage 13.

**Sub-gate 5 — Patent-Claim Coverage (HARD GATE — v2.7.11).**
Grep the manuscript for "patented" / "patent" / "filed for a
patent" / "patent number" / specific patent-number patterns.
Every "[Person] patented [X]" claim must:

- Have a verified patent number cited in the prose, with the
  database URL pinned in the ledger, OR
- Use hedged framing ("filed for a patent" / "is widely
  credited with" / "[Person]'s [decade] work in [field]")
  that does not commit to specifics, OR
- Have been removed entirely (verified by re-grepping)

Unmatched specific-patent claims BLOCK Stage 13.

If any of these conditions fail, the verdict is
**NOT-READY-FOR-PUBLICATION**, with the failing items
listed as explicit blockers shown to the user. "Defer to
pre-press" / "publisher will verify" / "external
verification stack" are NOT valid paths to a READY
verdict. The engine cannot offload its verification work
to the publisher; that defeats the engine's contract with
the author.

The Stage 13 user-facing report includes the three-class
manifest:

```
VERIFICATION SUMMARY (per verification-discipline.md):
  VERIFIED specifics:    {N}  (all sources pinned)
  SPECULATIVE specifics: {N}  (all marked in prose, mapped in handoff)
  REJECTED items in prose: 0   (else verdict = NOT-READY)
  Unverified-uncategorized: 0  (else verdict = NOT-READY)
```

The publisher handoff package therefore contains the
manuscript itself, the `engine-data/verification-ledger.md`,
the `engine-data/speculative-content-map.md`, and this
readiness statement. The publisher's job is reduced to
"review labeled SPECULATIVE content for editorial fit" —
not "re-verify everything Ideorix wrote."

### Publishing-Standard Readiness Dimensions

After (and only after) the Verification Discipline Gate
clears, Stage 13 assesses the standard publishing
readiness dimensions:

- All factual claims sourced
- All citations correctly formatted
- Authority voice consistent throughout
- Argument coherent from introduction to conclusion
- No unresolved editorial issues above "minor" severity
- Word count within target range
- All Research Bible entries accurately reflected in prose

**STATUS: READY FOR PUBLICATION | NEEDS ATTENTION (list remaining issues)**


## Stage 14: Methodological Appendix Builder (CONDITIONAL — recommended for academic / policy / scholarly orientation projects)

After Stage 13 grants READY FOR PUBLICATION, this stage
optionally builds a publisher-ready methodological appendix
consolidating the manuscript's evidentiary apparatus into a
single reference document. Third-party reviews of academic
non-fiction consistently request exactly this consolidation
— both as a credibility signal (it makes methods explicit)
and as a practical reproducibility tool (readers,
journalists, fact-checkers can verify specifics in minutes
rather than hours).

The appendix has five sections:

- **Section A: Frameworks Operationalised** — every
  classification scheme / taxonomy / scoring rubric the
  manuscript depends on, defined as the manuscript actually
  applies it
- **Section B: Data Sources Consolidated** — every
  dataset / survey / archive / database with provenance,
  year, version, access notes
- **Section C: Studies Cited Summary Table** — every
  peer-reviewed study cited with authors, year, journal,
  design, sample size, key finding, citation locations
- **Section D: Reproducibility Checklist** — 3-5 specific
  verification checks any reader / journalist can run in
  10 minutes
- **Section E: Methods & Limits Digest** — consolidated
  methodological caveats from across the prose

The appendix is built from existing project artifacts
(verification-ledger.md, research-bible.md,
speculative-content-map.md, sources.md, manuscript prose)
rather than newly authored content. It is a structured
re-presentation of material the manuscript already
contains.

**Outputs:**

- `manuscript/{Title}-methodological-appendix.docx`
  (publisher-ready DOCX deliverable)
- `engine-data/methodological-appendix.md` (engine
  reference copy)

This stage is RECOMMENDED for projects with academic /
policy / scholarly orientation. For trade non-fiction or
memoir, it may be unnecessary and can be skipped — but for
non-fiction targeting policy audiences, journal review,
seminar use, or academic citation, it materially improves
the manuscript's reception.

→ See `methodological-appendix.md` for the full protocol.

