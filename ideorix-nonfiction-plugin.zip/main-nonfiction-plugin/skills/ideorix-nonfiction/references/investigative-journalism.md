---
name: investigative-journalism-category
description: "Category-specific instructions for investigative journalism non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Investigative Journalism. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | investigative-journalism |
| Display Name | Investigative Journalism |
| Parent Group | Politics & Social Sciences > Journalism (and cross-listed with Biographies & Memoirs > True Crime, Business & Money > Industries, or relevant subject category per the investigation's focus) |
| Typical Word Count | 80,000–140,000 (single-investigation books often 90,000–120,000; institutional / industry exposés 100,000–150,000; data-driven multi-strand investigations can run 130,000+) |
| Default Structure | Investigation / revelation framework — initial observation → digging deeper → unexpected connections → resistance / pushback → breakthrough → scale of wrongdoing → implications → reckoning. Alternates between the narrative (what happened) and the meta-narrative (how we found out); pacing borrows from thriller fiction (information withheld then revealed; chapter cliffhangers); the investigative process itself is partly the story |
| Citation Style | Endnotes mandatory and substantial; named-source attribution where consented; primary documents cited with specificity (date, page, section, source / FOIA release reference); document images / facsimiles where they materially support the claim; named-anonymous source attributions ("a senior official familiar with the matter", "a former [Company] engineer") with the access bargain disclosed; pre-publication legal review explicitly noted in author's note where conducted |
| Audience Baseline | Public-interest reader — politically engaged, willing to follow long evidence chains, expecting accountability journalism's evidentiary rigour; varies from generalist news-reader (institutional / political exposé titles) to specialist (industry-focused, technical investigations); audience-named so reader self-selects |
| Comparable Titles | Carl Bernstein & Bob Woodward (*All the President's Men*), Seymour Hersh (*Reporter*, multi-decade national-security investigations), Jane Mayer (*Dark Money*, *The Dark Side*), Lawrence Wright (*The Looming Tower*, *Going Clear*), Patrick Radden Keefe (*Say Nothing*, *Empire of Pain*), Ronan Farrow (*Catch and Kill*), Jodi Kantor & Megan Twohey (*She Said*), David Cay Johnston (*Perfectly Legal*, *Free Lunch*), Eric Schlosser (*Fast Food Nation*, *Command and Control*), Bethany McLean & Peter Elkind (*The Smartest Guys in the Room*), John Carreyrou (*Bad Blood*), Sheelah Kolhatkar (*Black Edge*), Andrea Elliott (*Invisible Child*), Eyal Press (*Beautiful Souls*, *Dirty Work*), Andy Greenberg (*Sandworm*), Anand Gopal (*No Good Men Among the Living*), Maria Ressa (*How to Stand Up to a Dictator*) |

## Subcategory Options

When the user selects Investigative Journalism, prompt for subcategory
refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| long-form-single-investigation | Long-Form Single Investigation | One story / event / scandal / wrongdoing explored in depth over months or years; the Bernstein-Woodward / Farrow / Kantor-Twohey / Carreyrou lineage | Chronological investigation spine; named protagonists (the wrongdoers, the victims, the witnesses, the journalists) recurring across the book; pacing built from the gradual accumulation of evidence; reckoning / implications / aftermath chapters at conclusion |
| corporate-financial-investigation | Corporate / Financial Investigation | Business, financial-services, market, or industry wrongdoing — fraud, accounting scandal, regulatory failure, market manipulation, executive misconduct; the McLean-Elkind / Carreyrou / Kolhatkar / Lewis-of-The-Big-Short lineage | Company-or-figure spine; financial / regulatory / accounting context accessible to general readers; named executives, investigators, and victims; primary documentation (SEC filings, court documents, internal corporate records) central |
| institutional-exposé | Institutional Exposé | Systemic failure or corruption within an organisation, profession, industry, or institution — religious institutions, universities, military, police, healthcare systems, sports federations; the Going-Clear / Spotlight-on-Catholic-abuse / Empire-of-Pain / NXIVM lineage | Institution-as-system structural analysis; victim-and-witness testimony central; institutional-defence / cover-up dynamics as recurring pattern; reform / accountability / impunity outcomes considered |
| political-government-accountability | Political / Government Accountability | Government wrongdoing, political corruption, intelligence-and-national-security accountability, electoral integrity; the Bernstein-Woodward / Hersh / Mayer / Coppins lineage | Named-figure-in-government spine; primary documentation (court filings, hearing transcripts, FOIA-released documents, leaked materials); institutional-process knowledge required of the journalist; legal / political / constitutional implications considered |
| immersion-narrative-reportage | Immersion Narrative Reportage | Sustained embedded reporting that surfaces an accountability story — typically about marginalised communities, institutional failure as experienced from below, war / conflict zones, hidden labour conditions; the Elliott-on-Invisible-Child / Press / LeBlanc-Random-Family / Boo-Beautiful-Forevers lineage (cross-references literary-nonfiction) | Subject-life-as-spine over years; named subjects and their full lives (not just the angle the investigation foregrounds); ethnographic patience; the journalist-subject relationship itself often part of the book's substance |
| data-driven-investigative | Data-Driven / Document-Centric Investigation | Investigation built primarily from leaked documents, FOIA records, data analysis, network analysis — the ICIJ Pandora-and-Panama-Papers / Spotlight-style document-led investigations; the data and the documents are the primary evidence | Document-or-dataset spine; methodology disclosure central; named collaborators / outlets / contributors where the work is collaborative; visualisation / structural-network rendering accessible to general readers; technical detail calibrated for non-specialist audiences |
| cybersecurity-tech-investigation | Cybersecurity / Technology Investigation | Hacking, surveillance, platform abuse, cyber-warfare, online harm — the Greenberg-Sandworm / Krebs / Hill-on-Clearview / Aspen-Reilly-on-Pegasus lineage; cross-references technology category | Threat / actor / incident spine; technical detail accessible to general readers; named victims / targets / investigators; institutional context (state actors, criminal groups, platform companies); current-state-of-threat acknowledged (this category dates fast) |

**Default:** If the user does not specify, prompt for the investigation's
primary mode (single story / corporate / institutional / political /
immersion / data-led / cyber) and select accordingly; fallback to
`long-form-single-investigation` for unclear cases.

## Structural Architect Instructions

```
STRUCTURE
- Investigation/Revelation framework: Initial observation → Digging deeper → Unexpected
  connections → Resistance → Breakthrough → Scale → Implications → Reckoning
- Alternate between: the narrative (what happened) and the investigation (how we found out)
- Pacing borrows from thriller fiction: information withheld then revealed, chapter cliffhangers

BEATS PER CHAPTER
1. Discovery Beat. new information surfaces, reframes what was known
2. Source Beat. a person provides evidence, testimony, or access
3. Verification Beat. claims are checked, confirmed, or challenged
4. Resistance Beat. obstacles, pushback, legal threats, stonewalling
5. Implications Beat. what the discovery means for the wider picture

CATEGORY ARCHITECTURE
- The INVESTIGATION is the spine: every chapter must advance the inquiry
- Sources must be layered: documents → interviews → official responses → analysis
- The reader must be able to follow the chain of evidence
- Show the journalist's process: how leads were followed, what dead ends looked like
- Build toward a revelation that reframes everything

FORBIDDEN
- Speculation presented as fact
- Anonymous sources without editorial justification
- Fabricated dialogue or composite characters
- Conclusions not supported by documented evidence
- Identifying protected sources
- Gratuitous detail that doesn't serve the investigation
```

## Content Writer Craft Rules

```
VOICE & TONE
- Precise, measured, authoritative. the journalist as trusted guide
- Show the process: "The document showed..." "When asked, the spokesperson said..."
- Tension through information control, not melodrama
- Direct quotes from sources for key moments; paraphrase for context

EVIDENCE STANDARDS
- Highest bar: every factual claim must be independently verifiable
- Direct quotes from interviews, documents, official records
- Multiple sources for contested claims (minimum 2 independent confirmations)
- Documents cited with specificity (date, page, section)

ATTRIBUTION CHAIN
- Every claim: where did this information come from?
- Every source: why should the reader trust them?
- Every document: what is it, who created it, how was it obtained?

PROSE RHYTHM MAPPING
- Ch 1 hook: the discovery or the wrongdoing. reporter's-eye urgency from the first paragraph
- Sentence length: short-medium (10-18 words) as the baseline; investigative prose is precise, measured, and propulsive
- Scene reconstruction drives the opening: the reader is placed at the moment of discovery or revelation
- High source-dialogue density. real voices (witnesses, investigators, officials) carry more authority than narration
- Tension ≥6 from chapter 1: something is wrong, someone is hiding it, and the investigation has begun
- Pacing borrows from thriller fiction: information withheld then revealed; each chapter ends with a question or a lead
- The investigation IS the narrative spine: every paragraph advances the inquiry or deepens the reader's understanding
- Evidence integration is the genre's signature: documents cited with specificity (date, page, section), sources made visible
- Short paragraphs for revelations and key testimony; longer paragraphs for context, verification, and implications
- Deploy direct quotes from sources at moments of maximum impact; paraphrase for procedural and contextual connective tissue
- The "why should I read this book" question is answered by the wrongdoing itself: something happened that demands exposure
- Reader engagement across information-dense passages: legal, financial, and institutional detail woven into the investigative narrative
- Authority delivery through process transparency: show how leads were followed, what dead ends looked like, how evidence was verified
- Paragraph rhythm mirrors the investigative process: discovery (short, urgent), verification (measured, careful), implications (expansive, analytical)
- Alternate between the narrative (what happened) and the investigation (how we found out). this dual track sustains pacing
- Tension through information control, not melodrama: what the reader knows, what they suspect, what has not yet been revealed
- Resistance beats (stonewalling, legal threats, sources going silent) create their own pacing and tension
- Chapter endings create investigative momentum: a new document, a reluctant source, a contradiction that demands resolution
```

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Every major claim supported by documented evidence | Each consequential factual claim traces to primary documentation, named source, or multiple corroborating sources; the reader following the endnote / citation chain can verify the basis of the claim; "I learned that..." without sourcing is below the genre's standard |
| 2 | Two-source rule (or higher) for contested claims | Contested claims about identifiable subjects — particularly claims of wrongdoing — supported by at least two independent sources (named documents, named witnesses, named records); single-source contested claims either elevated to multi-source standard, framed as single-source with the source's relationship and motive disclosed, or omitted |
| 3 | Source identification or anonymity justification | Sources named where consented; where anonymous, the editorial justification is visible to the reader ("[Subject] requested anonymity to discuss matters they were not authorised to disclose"); blanket anonymous sourcing without justification fails the genre |
| 4 | Document specificity | Documents cited with date, title, page or section, and provenance (FOIA release, court filing number, leaked source, official publication); document images / facsimiles where they materially support consequential claims; "internal documents show..." without specificity inadequate |
| 5 | Right of reply provided to identified subjects | Subjects of the investigation given opportunity to respond before publication; their response (or refusal) recorded in the relevant chapter; "the company / individual / institution did not respond to a detailed list of questions sent on [date]" is the standard formulation where appropriate |
| 6 | Defamation and privacy considered | Statements of fact about identifiable subjects defensible (true, fairly framed opinion, or fair comment on matters of public interest); pre-publication legal review conducted for high-risk claims; private information used only where public-interest defence supports it |
| 7 | Source motive and relationship disclosed | Where the source has personal interest (revenge, gain, score-settling, plea-bargain incentive, axe to grind), the motive is disclosed to the reader; the source's prior relationship to the subjects of the investigation visible; sources are not laundered through anonymity to obscure their interests |
| 8 | Chronology accurate and consistent | Dates, sequences, and relative timing of events accurate to the documented record; where sources disagree on timing, the disagreement is acknowledged; the chronological backbone of the investigation can be reconstructed from the book |
| 9 | Speculation distinguished from fact | Where the journalist is reasoning beyond the evidence ("this pattern suggests...", "it remains unclear whether..."), the prose signals it; conclusions presented as documented when they rest on inference are the genre's most-criticised analytical failure |
| 10 | Victims and affected parties treated with dignity | Subjects of harm — survivors of abuse, victims of corporate wrongdoing, families of those harmed — treated as full human beings with agency rather than as evidence in service of the journalist's story; sensitivity-of-content frames where appropriate; subjects' own framing of their experience preserved where consented |

## Source Requirements

### Mandatory Source Types

- **Primary documents.** Court records (filings, depositions,
  rulings, dockets); FOIA / FOI releases; SEC and other
  regulatory filings; internal corporate, government, or
  institutional documents (leaked, disclosed, or obtained
  via legal process); financial records; emails / messages /
  communications; audit reports; inspector-general reports;
  congressional / parliamentary hearing transcripts and
  exhibits. Primary documents are the genre's evidentiary
  backbone — their absence is a structural weakness.
- **Named-source interviews.** Direct interviews with
  participants — subjects, witnesses, officials, victims,
  experts, defenders, opponents — conducted by the journalist
  and attributed by name where consented. Interview ground
  rules (on the record / on background / off the record /
  not for attribution) marked appropriately and
  consistently. Substantial reporting time and access shape
  the book's authority.
- **Anonymous sources where editorially justified.** Some
  consequential information — particularly from whistleblowers,
  intelligence sources, employees of institutions discussed,
  victims unwilling to be named — is available only on
  anonymous terms. The book uses anonymous sourcing where
  necessary, justified to the reader, and consistently
  described ("a senior official familiar with the matter",
  "a former [Company] engineer who left the company in
  [year]", "a victim who requested anonymity to discuss
  the abuse"); editorial standards are higher for anonymous
  than named sourcing.
- **Official statements and on-the-record responses.**
  Statements from institutions, companies, and named
  subjects — issued during the investigation, in response
  to the journalist's questions, in court filings, in
  press conferences — quoted accurately and contextualised.
- **Verifiable data and analysis.** Datasets with provenance
  (where acquired, methodology of collection, reliability
  notes); analysis methodology disclosed; software / tools
  used named where relevant; collaboration with named
  data scientists or research-organisation partners
  acknowledged. The methodology can be inspected by readers
  with the relevant expertise.
- **Specialist scholarship and reference works.** For
  technical, scientific, legal, financial, historical, or
  international contexts, named scholars and reference works
  cited where the investigation engages with specialist
  domains.

### Source Freshness — Investigations Date in Specific Ways

- **Live legal cases evolve.** Where the investigation
  touches active criminal or civil proceedings, the book's
  account is dated; subsequent developments (verdicts,
  appeals, settlements, new charges, vacated convictions)
  may substantially change the record. Front matter notes
  the date through which events are covered.
- **Subjects respond after publication.** Major investigative
  works often generate responses, retractions of prior
  positions by subjects, additional reporting by other
  outlets that complicates or extends the original. Re-issued
  editions warrant updated framing reflecting post-publication
  developments.
- **Document discovery continues.** Investigations that broke
  ground often get extended by subsequent FOIA releases,
  later-released archives, or new whistleblowers; the book's
  account is the state of the record at time of writing,
  not the final word.
- **Source landscape evolves.** Witnesses die or recant;
  documents become public that were sealed; new institutional
  records emerge; the original investigation's source base
  expands or shifts. The book's reception sometimes shifts
  with the source landscape.
- **Foundational works hold up better.** Methodologically
  rigorous works (Hersh's My Lai reporting, Bernstein and
  Woodward's Watergate, Mayer on torture, McLean and Elkind
  on Enron) age well because the documentary record they
  established remains the record; works that depend heavily
  on a single anonymous source or a single dramatic moment
  age more variably as the source landscape evolves.

### Attribution Standards

- **Every consequential claim sourced.** Endnotes are
  substantial and inspectable; the reader who wants to
  verify can trace each consequential claim to its
  evidentiary basis.
- **Named-vs-anonymous sourcing distinguished consistently.**
  Named sources quoted in attributable form; anonymous
  sources described with as much detail as anonymity permits
  ("a former senior State Department official who served
  in the relevant office during the relevant period");
  anonymous source's role and access made knowable even
  where their identity is protected.
- **Document attribution precise.** Document type, date,
  page or section, source / provenance specified — "an
  internal email dated 14 March 2018 from [Title] to
  [Title], obtained through litigation discovery"; "the
  company's 2019 annual report (10-K filing), pages 47-48";
  "FBI 302 interview report dated [date], FOIA release [ID]".
- **Corroboration noted where consequential.** "These
  accounts were confirmed by [N] independent sources,
  including [description of source classes]" — the reader
  can see that the contested claim has been triangulated.
- **Right-of-reply responses quoted or paraphrased.** "When
  asked about [allegation], a spokesperson for [Company]
  said in a statement that [response]" / "[Subject] declined
  multiple requests for interviews, including a detailed
  list of questions sent on [date]; [Subject's lawyer]
  responded that..." — the subjects' positions are visible
  to the reader.
- **Source motive disclosed where relevant.** "[Source] is
  currently in litigation with [Company] over their
  termination" / "[Source] has a long-standing personal
  conflict with [Subject] dating to [period]" / "[Source]
  has cooperated with prosecutors as part of a plea
  agreement" — incentives that might shape testimony
  visible to the reader so they can calibrate.
- **What is NOT acceptable.** Inventing sources or
  documents. Misrepresenting documents (selective excerpting
  that distorts meaning). Quoting sources beyond what they
  said or in context they did not intend. Failing to seek
  right of reply from named subjects of allegation. Using
  anonymous sources to make claims that no named source
  would corroborate. Burying evidence that complicates the
  book's thesis. Failing to disclose conflicts of interest
  (the journalist's prior relationships with subjects,
  funding sources for the investigation, commercial
  interests in the outcome).

## Category-Specific Guardrails

### MANDATORY. Source Protection (the journalist's first ethical obligation)

- The journalist's first ethical obligation is to protect sources
  who have been promised anonymity. Source-protection failures
  damage not only the individual source but the broader
  reporting ecosystem — future sources will not come forward
  if prior sources were burned.
- Specific requirements:
  - **Anonymous-source agreements honoured.** Where a source
    has been promised anonymity, that promise is kept
    indefinitely; the source's identity is not revealed to
    editors / fact-checkers / lawyers without the source's
    consent (and is rarely revealed even to those parties
    in highly sensitive matters); the source is not
    identifiable through unique combinations of details
    that would burn them to readers who could put the
    pieces together.
  - **Source-burn risk assessment.** Before publishing
    information from anonymous sources, the journalist
    assesses whether the published details — even with
    the source's name protected — would identify them to
    parties who could harm them (employers, hostile
    governments, criminal actors).
  - **Whistleblower-law awareness.** Sources who are
    employees of the institution being investigated may
    have legal protections (in some jurisdictions, statutory
    whistleblower protections); the journalist's reporting
    accounts for these where applicable.
  - **Journalist-shield laws and their limits.** The
    journalist understands the legal protections available
    in the relevant jurisdiction (federal vs state shield
    laws in the US, Article 10 ECHR / various national
    journalistic-source-protection laws in Europe, weaker
    or absent protections in many countries); operates
    accordingly.
  - **Encryption and operational security.** Where sources
    require it, the journalist uses encrypted communication
    (Signal, secure document-drop systems, in-person meets
    where digital communication is risky); the book's
    methodology may discuss this honestly without burning
    specific sources' operational practice.
- Source-protection extends after publication: legal and
  political pressure to identify sources can intensify
  post-publication; the journalist's commitment is durable,
  not contingent on convenience.

### MANDATORY. Defamation and Libel Awareness

- Investigative journalism by definition makes consequential
  claims about identifiable subjects; defamation / libel
  exposure is a structural feature of the work. The book
  manages it rather than ignoring it:
  - **Statements of fact must be defensible.** True (the
    journalist can prove the statement); fairly framed
    opinion (clearly distinguished from fact, on a basis the
    audience can assess); fair comment on matters of public
    interest (where applicable in the jurisdiction);
    reportage privilege (accurate reporting of contested
    public allegations between identified parties).
  - **Pre-publication legal review.** Major investigative
    works receive pre-publication legal review covering
    defamation / libel / privacy / sub judice / contempt
    / national security restrictions per the relevant
    jurisdictions; the book's author's note often discloses
    that such review was conducted.
  - **Jurisdiction awareness.** Defamation law varies
    substantially across jurisdictions — US (high First
    Amendment protection, "actual malice" standard for
    public figures, stronger journalist protections);
    UK and Commonwealth (lower bar for plaintiffs, stricter
    publication standards); various European jurisdictions
    (stronger privacy / GDPR considerations); books published
    internationally consider exposure across markets.
  - **Public-vs-private subject distinction.** Public
    figures (politicians, executives, officials in their
    public capacity) face higher bars to recover for
    defamation than private individuals; the book operates
    within this distinction with awareness.
  - **"No comment" recorded honestly.** Where subjects have
    declined to respond to questions or refused interviews,
    this is recorded ("did not respond to detailed questions
    sent on [date]" / "declined repeated requests for
    interviews"); refusal-to-respond is not invented, nor
    is it conflated with denial.

### MANDATORY. Two-Source Rule (or Higher) for Contested Claims

- The two-source standard — at minimum two independent
  sources for contested or consequential claims, particularly
  claims of wrongdoing about identifiable subjects — is the
  category's foundational evidentiary rule.
- Specific requirements:
  - **Independence of sources.** Two sources who heard the
    same thing from a single source are not two independent
    sources; the count tracks independent knowledge of the
    underlying fact.
  - **Higher standards for higher stakes.** Claims of crime,
    abuse, fraud, malfeasance attract higher sourcing
    standards than claims of poor judgement or interpersonal
    conflict; the most consequential claims often warrant
    three or more sources plus documentary corroboration.
  - **Single-source reporting flagged where used.** Where a
    significant claim rests on a single source, the
    single-source reliance is acknowledged ("according to
    [Source], the only person to have witnessed the
    [event]..."); the source's relationship and motive is
    visible; the reader knows the evidentiary fragility.
  - **Document corroboration weighted heavily.** A primary
    document substantiating a claim is often equivalent to
    multiple witness sources; documentary evidence is the
    investigation's most durable foundation.

### MANDATORY. Right of Reply

- Identifiable subjects of investigation are given meaningful
  opportunity to respond before publication. The right of
  reply protects against reputational harm, surfaces
  corrections, and is a defence in defamation contexts:
  - **Detailed list of allegations sent in advance.** Not a
    vague "we're writing about you"; specific questions
    addressing specific allegations, with reasonable response
    deadline.
  - **Response (or refusal) quoted accurately.** The
    subject's position included in the relevant chapter, in
    sufficient detail that the reader can weigh it.
  - **Late or partial responses noted.** Where the response
    arrived after deadline, after the book was substantially
    complete, or addressed only some allegations, the
    timing and scope are recorded.
  - **Subjects' lawyers' communications referenced where
    relevant.** Counsel responses on behalf of subjects are
    documented; legal threats made during reporting are
    noted in the account where they shape the work.
- The right-of-reply standard does not give subjects the
  right to suppress publication; it gives them the right to
  be heard before publication.

### MANDATORY. Public-Interest Defence and Privacy Calibration

- Investigative journalism often surfaces information that
  subjects would prefer kept private. The book's use of
  private information operates within the public-interest
  framework:
  - **Public-interest test.** Information is published where
    its public interest outweighs the subject's privacy
    interest; the test is real, not pro forma. Sex lives,
    medical conditions, family matters published only where
    they bear materially on the public-interest story.
  - **Proportionality.** Detail published is calibrated to
    what the public-interest story requires; gratuitous
    detail beyond the story's needs is not in the public
    interest.
  - **Vulnerable subjects.** Children, victims of abuse,
    people in extremis, deceased subjects' families warrant
    extra care; the public-interest threshold is higher and
    sensitivity considerations more demanding.
  - **GDPR and personal-data considerations.** For European
    publication, personal data of identifiable individuals
    requires lawful basis; the journalistic exemption
    applies but its limits matter.

### MANDATORY. Ethics of Undercover and Deception-Based Reporting

- Undercover reporting (where the journalist enters a
  situation without disclosing their identity / role) and
  deception-based reporting (false-name communications,
  use of stings) are sometimes journalistically justified
  but require ethical justification:
  - **Public-interest necessity.** The story is materially
    important AND could not have been obtained through
    open reporting. Undercover is a last resort, not
    convenience.
  - **Minimisation.** The deception is no greater than
    necessary; the journalist does not commit material
    wrongdoing in the course of the deception.
  - **Disclosure to the reader.** The book discloses the
    methods used; the reader knows that the access was
    obtained via deception so they can calibrate.
  - **Editorial sign-off.** Major undercover work is
    typically conducted with editorial / legal pre-approval,
    not as a single journalist's unilateral decision.
- Some forms of deception (false credentials in regulated
  contexts; entering private property under false pretences;
  inducing crimes) can carry legal exposure regardless of
  journalistic justification; the reporting is calibrated
  to legal as well as ethical limits.

### MANDATORY. Subjects of Harm Treated with Dignity

- Where the investigation centres on victims of crime, abuse,
  corporate harm, institutional failure — the survivors and
  their families are subjects with agency rather than
  evidence in service of the journalist's story:
  - **Consent considerations.** Survivors' participation is
    consensual; identification (named vs anonymous) is
    their choice; the framing of their experience is informed
    by their own framing where they are willing to share.
  - **Trauma-aware reporting.** Repeated detailed
    re-narration of traumatic events is calibrated to the
    survivor's preferences; gratuitous re-traumatisation
    avoided.
  - **Sensitivity-of-content frames.** Content notes /
    sensitivity warnings where survivors of similar harm
    might be affected by the reading; signposting to
    support resources where appropriate.
  - **Named-survivor decisions respected.** Where a survivor
    has chosen to be publicly named, that public identity
    is honoured; where they have chosen anonymity, that is
    honoured.
  - **No props.** Survivors of harm are not stitched into
    the journalist's narrative arc as illustration; their
    agency, their interpretation of events, their lives
    beyond the harm are visible.

### Additional Guardrails

- **Methodological transparency in author's note.** A
  substantial author's note covers: the duration and nature
  of the reporting; the access bargains where any were
  made; the use of anonymous sources and the editorial
  justification; right-of-reply outreach; pre-publication
  legal review; conflicts of interest disclosed; reporting
  partners and contributors credited.
- **Conflicts of interest disclosed.** Prior relationships
  with subjects, financial interests in the outcome,
  political affiliations relevant to the investigation,
  funding sources for the reporting (where the book is
  funded by a foundation, organisation, or other party
  with views on the subject) — disclosed to the reader so
  they can calibrate.
- **Speculation distinguished from fact.** Where the
  journalist is reasoning beyond what the evidence
  demonstrates ("the pattern is consistent with...", "this
  raises the question whether..."), the prose flags it;
  conclusions presented as documented when they rest on
  inference are the genre's most-criticised analytical
  failure.
- **Sub judice / contempt awareness.** Where active legal
  proceedings could be prejudiced by publication
  (jurisdictions vary on this — UK contempt-of-court rules
  are particularly stringent during live trials), the book's
  publication timing and content are calibrated;
  pre-publication legal review covers this.
- **Subject's own evidence accurately represented.** Where
  the subject's own statements, prior writings, on-the-
  record positions are used as evidence, they are
  represented accurately in their context, not selectively
  excerpted to misrepresent.
- **Currency disclosure.** Investigative work dates with
  legal proceedings, regulatory developments, subjects'
  subsequent admissions or denials; the book is honest
  about the moment of writing.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Dark, serious, documentary — deep
  blacks, navy, charcoal, deep red as the dominant family;
  white or pale-gold typography for contrast; institutional
  / monochrome / archival palette signalling the
  evidentiary register. High-contrast palettes signal the
  category's urgency. Avoid commercial true-crime saturated
  reds-and-yellows that signal pulp positioning.
- **Typography:** Two dominant traditions:
  1. **Bold serif** (Caslon, Garamond, Bembo Bold, Plantin)
     signalling continuity with newspaper-headline tradition
     and book-of-record gravitas.
  2. **Condensed sans-serif** (Akzidenz-Grotesk Condensed,
     Helvetica Bold Condensed, custom-condensed) signalling
     contemporary investigative-publishing aesthetic and
     headline-grade impact.
  Title and subtitle weighted for thumbnail readability;
  the title typically declarative or interrogative ("The
  [Topic]", "How [X] [happened]", "Inside [Institution]").
- **Imagery:** Three dominant traditions:
  1. **Documentary photography** — institutional buildings,
     archival-document overlay, surveillance / archive
     aesthetic, sometimes obscured / partial / shadowed
     subject portrait. Calibrated to signal seriousness
     rather than sensationalism.
  2. **Document / redaction imagery** — fragments of
     primary documents, redaction bars, institutional
     letterheads, file-folder iconography. Strong for
     document-centric and political-government investigations.
  3. **Pure typography or near-typography** — title
     dominant against neutral or dark ground, often with
     single graphic element (a redaction bar, a line, an
     icon). Common for the most established investigative
     authors and for books where the title's claim is the
     draw.
- **Mood:** Sober authority. The cover should signal "this
  book has done the work and tells you what it found" — not
  "thriller-paced exposé" (true-crime pulp register), not
  "academic study" (gatekeeping register). The cover is
  often understated relative to the explosiveness of the
  story; the understatement is itself a signal of seriousness.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Long-Form Single Investigation | Documentary photography (the place, the institution, the figure) OR pure typography; bold serif or condensed sans-serif; subtitle clarifies the investigation's scope ("the inside story of...", "how [X] [happened]") |
| Corporate / Financial Investigation | Often institutional photography (corporate building, executive image, financial document overlay) OR pure typography; restrained palette; serif typography; subtitle emphasises the company / figure / scandal name |
| Institutional Exposé | Institutional imagery (the building, the symbol, the letterhead) often with implied weight or shadow; dark palette; serif typography; subtitle establishes the institution and the failure ("inside [institution]: [accountability framing]") |
| Political / Government Accountability | Pure typography or institutional imagery (Capitol / White House / parliament / court building); deep palette; bold serif; subtitle clarifies the political context and accountability angle |
| Immersion Narrative Reportage | Photographic image of the community / context (calibrated to honour subjects, not exoticise); warmer palette than other subcategories; serif typography signalling literary-NF crossover; subtitle clarifies the immersion |
| Data-Driven / Document-Centric Investigation | Document-overlay imagery; redaction bars; data-visualisation fragment; restrained palette; clean typography; subtitle clarifies the methodology ("the [documents] / [data] that revealed...") |
| Cybersecurity / Technology Investigation | Abstract / digital / network imagery; high-contrast palette; clean modern sans-serif; subtitle clarifies the threat / actor / case |

### Typography Rules

- **Title:** 35–60% of cover area for typography-led covers;
  30–45% for image-led. Investigative-journalism titles
  often work as declarative ("Bad Blood", "Catch and
  Kill", "She Said", "Dark Money", "Empire of Pain") or
  named-subject ("All the President's Men", "The Smartest
  Guys in the Room", "Going Clear"). Title must read at
  thumbnail and signal the book's claim and gravity.
- **Subtitle:** Often essential — does the descriptive
  positioning work. Subtitles in investigative work tend
  to be specific and substantial: "Secrets and Lies in a
  Silicon Valley Startup" (*Bad Blood*); "The Hidden
  History of the Billionaires Behind the Rise of the
  Radical Right" (*Dark Money*); "Lies, Spies, and a
  Conspiracy to Protect Predators" (*Catch and Kill*).
  Specific subtitle outsells vague.
- **Author name:** Larger for established investigative
  brands (Woodward, Hersh, Mayer, Wright, Farrow, Keefe,
  Carreyrou); smaller for unestablished authors with
  credentials in subtitle ("by the [Outlet] reporter who
  broke the [story]", "by a Pulitzer Prize-winning
  investigator"). Author qualification cues (newspaper /
  magazine masthead, prior major investigations, prizes)
  shape this category's reader trust because the
  investigation's authority depends on the journalist's
  standing.
- **Series mark, imprint, and edition:** Investigative-
  journalism imprints (Knopf, Crown, Random House, Penguin
  Press, Simon & Schuster's investigative-titles list,
  Doubleday) signal positioning. Updated editions for
  works whose subjects have generated post-publication
  developments are common (post-trial editions, post-
  settlement editions, post-Congressional-hearing
  editions).

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Long-Form Single Investigation | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > Commentary & Opinion (or > Public Affairs & Policy depending on subject); cross-list with subject category per the investigation's focus |
| Corporate / Financial Investigation | Kindle Store > Kindle eBooks > Business & Money > Industries > [Specific Industry] (with Politics & Social Sciences > Politics & Government > Specific Topics > Corruption & Misconduct as secondary) |
| Institutional Exposé | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Sociology > [Religion / Education / Healthcare / Military / etc. per institutional focus]; or Religion & Spirituality > Comparative Religion for religious-institution exposés; or > Specific Topics > Discrimination & Race Relations / Civil Rights for civil-rights-failure focus |
| Political / Government Accountability | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > [Privacy & Surveillance / National & International Security / Federal Jurisdiction / etc. per focus] |
| Immersion Narrative Reportage | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Sociology > Urban (or > Anthropology > Cultural for ethnographic-style); cross-references literary-nonfiction category |
| Data-Driven / Document-Centric Investigation | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > Public Affairs & Administration (with Computers & Technology > Computer Science > Big Data as secondary for analytics-led investigations) |
| Cybersecurity / Technology Investigation | Kindle Store > Kindle eBooks > Computers & Technology > Security & Encryption (with Politics & Social Sciences > Politics & Government > Specific Topics > Privacy & Surveillance as secondary) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| True crime crossover | Kindle Store > Kindle eBooks > Biographies & Memoirs > True Crime (where the investigation centres on criminal wrongdoing — corporate fraud trials, organised crime, abuse cases, white-collar criminal prosecutions) |
| Specific industry | Kindle Store > Kindle eBooks > Business & Money > Industries > [Healthcare / Finance / Technology / Energy / Pharmaceuticals / etc.] |
| Specific political topic | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > [Privacy & Surveillance / Censorship / National & International Security / Constitutional Law / etc.] |
| History (for reckoning-with-the-past investigations) | Kindle Store > Kindle eBooks > History > World > [Specific Era or Region] |
| Specific social issue | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > [Discrimination & Race Relations / Gender Studies / Disability / etc.] |
| Memoir crossover (for journalist-memoir of an investigation) | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > Journalists |
| Law / legal | Kindle Store > Kindle eBooks > Law > Legal History (or > Specific Topics) where the investigation is fundamentally legal in shape |
| Religion / spirituality | Kindle Store > Kindle eBooks > Religion & Spirituality > Religious Studies (for institutional-religious investigations like Going Clear, Catholic-abuse exposés) |

### Keyword Recommendations

- The investigation's subject as a phrase
  ("Theranos investigation", "opioid crisis", "Trump
  administration corruption", "Catholic church abuse",
  "Wirecard fraud", "NSA surveillance", "Russian
  interference", "Big Pharma", "Sackler family")
- The journalistic mode
  ("investigative journalism", "long-form investigation",
  "investigative reporting", "exposé", "muckraking",
  "accountability journalism", "national-security reporting")
- The institutional focus
  ("corporate fraud", "political corruption", "intelligence
  abuse", "regulatory capture", "institutional cover-up",
  "religious-institution abuse", "police misconduct",
  "tech-platform abuse")
- The methodology where notable
  ("FOIA documents", "leaked records", "data-driven
  investigation", "whistleblower", "undercover reporting",
  "long-form embed")
- Comparable journalist / brand for discoverability
  (readers of Bob Woodward, readers of Seymour Hersh,
  readers of Jane Mayer, readers of Patrick Radden Keefe,
  readers of Ronan Farrow, readers of John Carreyrou,
  readers of Lawrence Wright)
- Outlet / context where prestigious
  ("New Yorker investigation", "New York Times investigation",
  "ProPublica", "BBC Panorama-style", "Spotlight-style",
  "ICIJ investigation")
- Award / recognition where applicable
  ("Pulitzer Prize-winning", "George Polk Award", "IRE
  Award", "Loeb Award")
- Avoid generic "exposé" / "scandal" / "truth" / "secret"
  in isolation — they signal commercial true-crime pulp
  positioning and damage credibility with serious
  investigative-reading audiences; prefer compound phrases
  combining specific institution / story + journalistic
  mode + outcome
- Avoid sensationalist framings ("the shocking truth", "the
  hidden story", "what they don't want you to know") —
  serious investigative journalism's authority depends on
  the opposite register: sober claim, evidentiary substance,
  documented detail
