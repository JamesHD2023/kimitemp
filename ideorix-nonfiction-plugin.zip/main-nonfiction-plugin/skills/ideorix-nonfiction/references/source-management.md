---
name: source-management
description: "Source registration, tracking, and bibliography management for non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Source Management Protocol

## Purpose

Manage all sources throughout the non-fiction manuscript lifecycle — from initial
registration during Research Bible creation through per-chapter deployment to
final bibliography generation.

## Source Registration

When a source is added to the Research Bible, register it with:

```
SOURCE ENTRY:
  Name: {full title or description}
  Type: book | paper | article | interview | archive | dataset | report | website
  Author/Institution: {who created it}
  Date: {publication or creation date}
  Reliability: peer-reviewed | primary | secondary | anecdotal | expert-opinion
  Bias Notes: {any known bias, perspective, or limitation}
  Key Contribution: {what this source adds to the argument — 1-2 sentences}
  Chapters Used: {list of chapters where this source is cited}
```

## Source Hierarchy

Sources have different evidentiary weight:

| Level | Type | Weight | Example |
|-------|------|--------|---------|
| 1 | Primary sources | Highest | Original documents, first-hand accounts, raw data |
| 2 | Peer-reviewed research | High | Published studies, meta-analyses |
| 3 | Expert interviews | High | Direct quotes from credentialed experts |
| 4 | Secondary sources | Medium | Books synthesising primary research |
| 5 | Journalistic reporting | Medium | Investigative articles from reputable outlets |
| 6 | Tertiary sources | Lower | Encyclopaedias, textbooks, Wikipedia |
| 7 | Anecdotal evidence | Lowest | Personal stories, individual cases |

**Rule:** Critical claims should be supported by Level 1-3 sources. Level 6-7
sources should never be the sole support for a major argument.

## Citation Tracking

Maintain a running citation index at `engine-data/citation-index.md`:

```
| Source | Ch1 | Ch2 | Ch3 | ... | Total |
|--------|-----|-----|-----|-----|-------|
| Smith 2024 | 2 | 0 | 3 | ... | 5 |
| WHO Report | 0 | 1 | 0 | ... | 1 |
```

This tracks:
- Which chapters use which sources (for Context Scoping)
- Over-reliance on any single source
- Orphan sources (in Research Bible but never cited)
- Source distribution across the manuscript

## Source Gap Detection

After each chapter's verification, check:
- Are any Research Bible sources still unused? (Flag for future chapters)
- Are any chapters relying on a single source? (Suggest diversification)
- Are there claims that need stronger sources? (Upgrade from Level 5-7 to Level 1-3)

## Bibliography Generation

At Phase 6 (Delivery), compile the full bibliography from the citation index:
- Format per selected citation style (Chicago/APA/MLA/Harvard)
- Alphabetical by author surname
- Include all cited sources — exclude uncited Research Bible entries
- Verify every in-text citation has a bibliography entry and vice versa

## Permissions Tracking

For sources requiring permission (extensive direct quotes, reproduced tables,
images, proprietary data):

```
PERMISSION ENTRY:
  Source: {what needs permission}
  Rights Holder: {who owns it}
  Status: not-requested | requested | granted | denied
  Notes: {any conditions or limitations}
```

Flag in the Publication Readiness Assessment if any permissions are unresolved.
