---
name: how-to-guide-category
description: "Category-specific instructions for how-to, reference, and guide non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# How-To / Reference / Guides. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | how-to-guide |
| Display Name | How-To / Reference / Guide |
| Parent Group | Practical / Reference |
| Typical Word Count | 35,000–70,000 (shorter than narrative NF; reference titles can run longer when comprehensive) |
| Default Structure | Sequential building-block: fundamentals → intermediate → advanced; each chapter is one discrete procedure or skill cluster; reproducibility is the contract |
| Citation Style | Light citation (named authorities for safety / regulatory claims; named source for borrowed techniques); appendix of further-reading rather than scholarly endnotes |
| Audience Baseline | Motivated reader who wants to DO the thing — not be persuaded it's worth doing; assume zero prior knowledge unless the title signals an intermediate or advanced level |
| Comparable Titles | Marie Kondo (*The Life-Changing Magic of Tidying Up*), Tim Ferriss (*The 4-Hour Workweek*, *Tools of Titans*), David Allen (*Getting Things Done*), Atul Gawande (*The Checklist Manifesto*), Anne Lamott (*Bird by Bird*), Stephen King (*On Writing*), Cal Newport (*Deep Work*, *Digital Minimalism*), Bryan Caplan (*The Case Against Education*), Christopher Schwarz (*The Anarchist's Tool Chest*), Edward Tufte (*The Visual Display of Quantitative Information*) |

## Subcategory Options

When the user selects How-To / Reference / Guide, prompt for subcategory
refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| writing-publishing | Writing & Publishing | Craft guides, genre conventions, the publishing process, self-publishing, author marketing | Concept-example-exercise rhythm; chapter-as-craft-element; worked examples from the author's or canonical writers' work |
| home-improvement-diy | Home Improvement & DIY | Renovation, repair, building projects, gardening structures, vehicle maintenance | Project-as-chapter; tools-and-materials front-matter per project; numbered procedures with photographs / diagrams; safety callouts mandatory |
| craft-hobby | Craft & Hobby | Knitting, woodworking, photography, ceramics, calligraphy, baking-as-craft, gardening, music | Skill-progression spine: mark-making → simple project → composite project → mastery work; each chapter has a finished output the reader can show |
| career-professional | Career & Professional | Job search, skill development, industry navigation, freelance / consulting practice, interview craft | Stage-of-career chapters (entry / mid / senior / pivot); template artefacts (CVs, proposals, scripts) rendered explicitly; case studies from real practitioners |
| life-skills-practical | Life Skills & Practical | Organisation, productivity, personal systems, time management, decision-making | Diagnose-design-deploy framework; reader's current system audited first; new system introduced incrementally; weekly / monthly review rhythm built in |
| technology-software | Technology & Software | Tutorials for software / hardware / workflow tools; automation; programming primers; consumer-tech adoption | Version-aware (named software / version at chapter top); screenshots / diagrams; "if you see X instead of Y" branching; companion repository or downloadable assets common |
| reference-comprehensive | Reference / Comprehensive | A standing reference the reader returns to repeatedly (recipe collection, field guide, technique encyclopedia, glossary) | Topic-clustered rather than progressive; thorough indexing essential; cross-references between entries; designed for non-linear reading |

**Default:** If the user does not specify, prompt for the discipline / craft
the book teaches and select accordingly; fallback to `craft-hobby` for
unclear cases (its structure adapts most readily to other practical domains).

## Structural Architect Instructions

```
STRUCTURE
- Sequential, building-block order: fundamentals → intermediate → advanced
- Each chapter builds on the previous. prerequisites stated explicitly
- Core unit: the step-by-step procedure with clear inputs and outputs

BEATS PER CHAPTER
1. Concept Beat. what skill/technique this chapter teaches and why it matters
2. Prerequisites Beat. what the reader needs to know/have before starting
3. Instruction Beat. step-by-step procedure (the bulk of each chapter)
4. Practice Beat. exercises, projects, or application opportunities
5. Troubleshooting Beat. common problems and solutions
6. Next Steps Beat. what to learn next, how this connects to upcoming chapters

CATEGORY ARCHITECTURE
- Front-load foundational skills. never assume knowledge you haven't taught
- Every procedure must be REPRODUCIBLE by the target skill level
- Materials/tools/prerequisites listed BEFORE the procedure, not discovered mid-step
- Include "checkpoint" moments where the reader can verify they're on track
- End each chapter with a practical exercise or project

FORBIDDEN
- Steps out of order (critical safety and clarity failure)
- Assumed knowledge not covered in earlier chapters
- Vague instructions ("do it properly" instead of "apply pressure for 30 seconds")
- Missing safety warnings for potentially dangerous procedures
- Procedures that require tools/materials not listed in prerequisites
```

## Content Writer Craft Rules

```
VOICE & TONE
- Clear, direct, encouraging. expert friend teaching you
- Second person ("you") is standard
- Precise language: measurements, quantities, durations specified
- Action-oriented: imperative mood for instructions ("Sand the surface", not "The surface should be sanded")

EVIDENCE STANDARDS
- Instructions based on author expertise and tested procedures
- Safety information from relevant authorities
- Alternative methods acknowledged when they exist
- Specific product/tool recommendations backed by experience

FORMATTING
- Numbered steps for sequential procedures
- Bullet points for non-sequential lists (tools, materials)
- Bold for key terms, warnings, and critical steps
- Tables for specifications, measurements, comparisons
- "TIP:" and "WARNING:" callout formats standardised throughout
```

### Prose Rhythm Mapping

Chapter 1 opens with the transformation promise and the author's credibility
to deliver it. "By the end of this book, you will be able to...". stated
plainly, without hype. Then a brief demonstration of why the author is the
right guide: experience, not credentials. Show, do not list.

Clear, direct, step-oriented. Short sentences (10-16 words) dominate. The
how-to voice wastes nothing. Every sentence either teaches, clarifies, or
moves the reader to the next action. Ornament is cut. Repetition is cut.
What remains is pure instruction with just enough warmth to keep the reader
engaged.

Instructional rhythm follows a three-beat pattern: concept, example, action.
First, name what the reader needs to understand. Second, show it in practice.
Third, tell them exactly what to do. This cycle repeats throughout every
chapter. It is the heartbeat of effective how-to prose.

Tension ≥4. The tension in how-to writing is the competence gap. the
reader can't do this yet but wants to. Chapter 1 must make the
destination vivid and the path credible. The reader should finish
the chapter believing: I can actually do this.

Pacing guideline: open with the promise (short, direct sentences, 10-14
words). Follow with a brief origin story or motivating example (medium,
14-18 words). Then deliver the first small win. a quick technique or
insight the reader can use immediately. End the chapter with a clear
preview of the learning path ahead. Every sentence earns its place or
gets cut.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Reproducibility | A target-skill-level reader following the chapter's procedure literally arrives at the stated outcome; no hidden steps, no assumed-knowledge gaps |
| 2 | Sequential correctness | Procedural steps are in the order they must be executed; nothing earlier depends on something later; checkpoint moments verify the reader is on track |
| 3 | Prerequisites stated up-front | Required tools, materials, software, prior knowledge listed BEFORE the procedure begins, not discovered mid-step |
| 4 | Safety information prominent | For any hazardous procedure (sharp tools, heat, electricity, height, chemicals, structural), warnings appear at point-of-need with the standard WARNING callout — not buried in surrounding prose |
| 5 | Specificity over hand-waving | Quantities, durations, temperatures, dimensions, version numbers specified; "do it properly" replaced with "apply firm pressure for 30 seconds" |
| 6 | Consistent skill level | The chapter does not silently jump in difficulty mid-way; intermediate techniques in a beginner chapter are flagged or deferred to a later chapter |
| 7 | Imperative voice in instructions | Step text is action-led ("Sand the surface", "Open the file menu") rather than descriptive or passive ("The surface should be sanded") |
| 8 | Troubleshooting present | "What went wrong?" coverage for every major procedure: common failure modes, how to recognise them, how to recover; restored-state checkpoint after recovery |
| 9 | Concept-example-action rhythm | Each new technique is named (concept), demonstrated (example), then handed to the reader (action); no concept stays abstract, no example floats unattached to action |
| 10 | Forward-momentum at chapter end | Chapter closes with either a small win the reader can show, an exercise that consolidates the lesson, or a clear bridge to the next chapter's skill |

## Source Requirements

### Mandatory Source Types

- **Author's tested practice.** How-to derives its primary authority
  from doing-the-thing-many-times. The author has built the cabinet,
  written the books, run the company, kept the system. Procedures in
  the book are procedures the author has executed and verified.
- **Authoritative safety / regulatory sources.** Where the topic
  touches safety (electrical, structural, food-safety, fire, child,
  health, chemical) or regulation (tax, employment law, building
  code), claims trace to named authorities — building code clauses,
  manufacturer specifications, government safety bodies, professional-
  body guidelines. Anecdotal "this worked for me" is not adequate
  evidence on safety claims.
- **Peer practitioners.** Where the author's method is one of several
  legitimate approaches, named peer practitioners are acknowledged
  with their alternative methods. Pretending one's own method is the
  only method is a credibility failure.
- **Manufacturer / vendor documentation.** For technology, software,
  tools — version-specific behaviour traces to vendor documentation,
  not to the author's recollection. Documented behaviour is more
  reproducible than remembered behaviour.

### Source Freshness

- **Software / technology titles:** specify version at chapter top
  ("This chapter assumes [Software] v3.2 or later"); revisit and
  re-test against current versions before re-issue. A how-to-software
  book published more than 18 months ago should be presumed stale
  until re-verified.
- **Regulatory / legal / tax content:** date the guidance ("Current
  as of [year]"); name the jurisdiction; note that the reader should
  verify current rules with the relevant authority before relying on
  the book's procedures.
- **Craft / hobby / DIY:** longer-stable content; tool models change
  but technique persists. Date major equipment recommendations; revisit
  every 5 years for catalogue freshness.
- **Career / professional advice:** market and platform turnover is
  fast; revisit job-search and platform-specific guidance every 2–3
  years; principles outlast specifics, but specifics are what readers
  buy the book for.

### Attribution Standards

- **Borrowed techniques credited.** Where a technique, framework, or
  template comes from a named practitioner or prior work, name them
  in-line ("Adapted from David Allen's Getting Things Done capture
  rule..."). Silent borrowing erodes the author's credibility when the
  source is recognised by even one reader.
- **Safety claims sourced.** "Wear eye protection" is universal
  practice and needs no citation; "Lithium-ion batteries should be
  stored below X°C in a fireproof container" needs the citation
  (manufacturer / regulator). Specific numerical or material claims
  on safety attract liability; cite them.
- **Distinguish established practice from author preference.** "The
  standard approach is X. I prefer Y because Z." This honesty makes
  the author's preferences usable for the reader rather than mistaken
  for universal rule.
- **What is NOT acceptable.** Inventing measurements, durations, or
  temperatures untested by the author. Presenting personal preference
  as universal best practice. Omitting safety information for hazardous
  procedures because the author "always does it this way without
  problems."

## Category-Specific Guardrails

### MANDATORY. Safety Information Cannot Be Buried

- For any hazardous procedure (sharp tools, heat, electricity above
  low-voltage, height, structural load, chemicals, fire risk, food
  safety, vehicular work, child-related), safety appears at the
  point-of-need with the standard WARNING callout — NOT in surrounding
  prose, NOT only at chapter open, NOT only in an appendix.
- Where the procedure carries serious harm potential, the warning
  precedes the action it warns about: "WARNING: this circuit must be
  isolated at the consumer unit before any of the following steps."
- A how-to book that gets a reader hurt because the warning was
  buried, omitted, or under-stated is a category failure regardless
  of how good the rest of the prose is.
- Safety precaution language is conventional for a reason; reuse the
  established formulations rather than inventing decorative variants.

### MANDATORY. Sequential Integrity (a misordered step is a critical failure)

- The procedural sequence is the book's promise. Steps must be in the
  order they need to be executed; nothing later is required by
  something earlier; nothing earlier secretly depends on something
  later.
- Where a procedure has dependencies (e.g. "before you start, ensure
  the wood is fully dry"), the dependency is stated as a prerequisite
  before step 1, not discovered at step 5.
- Where a single procedure has branches (different action for
  different conditions), the branches are explicit ("If the surface
  is already painted: ... If the surface is bare: ..."); the reader
  should never have to guess which path applies.
- Every chapter contains at least one "checkpoint" moment where the
  reader can verify they are on track before continuing.

### MANDATORY. Skill-Level Consistency

- The chapter's assumed skill level is the chapter's contract with
  the reader. A beginner chapter that silently jumps to intermediate
  technique mid-way breaks the contract.
- If an intermediate technique appears in a beginner chapter, it must
  be flagged ("This is an intermediate step you can skip on your first
  pass; come back when you have completed Chapter 6") or moved to its
  proper place.
- The book overall must be honest in its level positioning. A book
  marketed as beginner-friendly that requires intermediate prerequisites
  in chapter 1 disappoints the reader and earns negative reviews.

### MANDATORY. The "Obvious to the Author" Trap

- What the author does without thinking is exactly what the reader has
  never done. Steps that the author skips because they are "obvious"
  are precisely the steps a reader will fail at. Test the procedure
  against a beta reader at the target skill level — if they trip on
  step 4, step 4 is missing detail, not them missing intelligence.
- When in doubt, include the obvious step rather than omit it. The
  cost of stating the obvious to one reader is mild irritation; the
  cost of skipping it for another is the procedure failing entirely.

### Additional Guardrails

- **Troubleshooting is part of the procedure, not an appendix.** "What
  went wrong?" coverage for major procedures includes: the most
  common failure modes, how to recognise each, how to recover, and how
  to prevent the failure on next attempt.
- **Do not over-promise.** "By the end of this chapter you will be
  able to..." is a good frame; "By the end of this chapter you will
  be a master of..." is hype that the reader will measure your work
  against and find lacking.
- **Calibrate ornament to the reader's task.** A how-to reader is on
  task — they want to do the thing. Ornamental prose that delays the
  next instruction is friction. Warmth and personality belong, but
  in service of the instruction, not at its expense.
- **Tool / product recommendations must be tested by the author.** If
  the author hasn't used the recommended tool, the recommendation
  doesn't belong; if the author has used it and dislikes it, that is
  data the reader should have. Affiliate-driven recommendations
  without disclosure are a credibility failure.
- **Currency disclosure where it matters.** Date the procedure where
  technology, regulation, market, or platform turnover would make the
  guidance go stale; tell the reader explicitly where to verify
  currency before relying on the book.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Warm and inviting for craft / hobby / domestic
  topics (cream, terracotta, soft green, natural-wood tones); clean
  and professional for career / technology / business titles (white
  + single accent, navy, deep red, charcoal); high-contrast for
  reference / utility titles where the cover is doing thumbnail
  work in a crowded category.
- **Typography:** Clean sans-serif (Gotham, Avenir, Helvetica Neue,
  Proxima Nova) is the default — how-to trades on clarity, and the
  typography signals "you can read this and follow it." Subtitle
  weight matters as much as title weight: the subtitle is doing
  the descriptive work that converts a browser into a buyer.
- **Imagery:** Three dominant traditions:
  1. **Tool / material / instrument** — the object the reader will
     work with, photographed cleanly. Strong for craft, DIY,
     instrument-led practice, technical reference.
  2. **Finished result** — what the reader will achieve, rendered
     aspirationally but not unrealistically. Strong for cooking,
     organising, design, project-led practice.
  3. **Process / hands at work** — author's hands or anonymous hands
     mid-procedure, signalling "this is something a human like you
     does." Strong for craft, instructional, beginner-friendly
     positioning.
- **Mood:** Competent, accessible, achievable. The cover should
  signal "you can do this, and this book will show you how" — not
  "this is so advanced you need to buy it to understand it." The
  reader who buys a how-to is committing to attempt the task; the
  cover must make the attempt feel realistic.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Writing & Publishing | Restrained, literary feel; typewriter / pen / book stack imagery, or pure typography; warm or muted palette; reference to canonical writing-on-writing tradition (King, Lamott, Strunk & White) |
| Home Improvement & DIY | Tool-led photography (saw, drill, bricks, paint roller); rugged colour palette; bold sans-serif title; subtitle emphasises clear scope ("the complete weekend kitchen") |
| Craft & Hobby | Finished-piece OR in-progress-piece photography; warm natural palette; typography with handcraft quality (slight serif, hand-set feel); softer than DIY |
| Career & Professional | Clean professional palette (navy / white / single accent); abstract / typographic / iconographic over photographic; subtitle does heavy lifting on what the reader will achieve |
| Life Skills & Practical | Iconographic, abstract, or single object that represents the system (a key, a clock, a notebook); restrained palette; typography emphasises calm and order |
| Technology & Software | High-contrast palette; abstract or iconographic; version / year visible if version-bound; series styling common when the publisher has an instructional series |
| Reference / Comprehensive | Substantial-feeling cover (heavier weight, often dark + gold/silver accent); typographic with strong hierarchy; subtitle establishes scope ("the definitive guide to X") |

### Typography Rules

- **Title:** 30–50% of cover area. How-to titles can be descriptive
  ("The Anarchist's Tool Chest") or promise-based ("The 4-Hour
  Workweek"); both work, but the title must read at thumbnail.
- **Subtitle:** Often more important than title for category placement.
  The subtitle answers "what will I be able to do after reading?" —
  "Build any cabinet in a weekend", "From idea to published novel",
  "The complete guide to home automation". Specific subtitle outsells
  vague subtitle.
- **Author name:** Smaller than title for unestablished authors
  (the credential is in the book's promise, not the name); larger
  for authors whose name carries the brand (Marie Kondo, Tim Ferriss,
  Stephen King for *On Writing*).
- **Series mark and edition:** If part of a series, series identity
  on spine and back; if a new edition, "Second Edition" / "Updated
  for [year]" prominently — readers need to know they're buying
  current information.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Writing & Publishing | Kindle Store > Kindle eBooks > Reference > Writing, Research & Publishing Guides > Writing Skills (or Publishing & Books) |
| Home Improvement & DIY | Kindle Store > Kindle eBooks > Crafts, Hobbies & Home > Home Improvement & Design > How-to & Home Improvements |
| Craft & Hobby | Kindle Store > Kindle eBooks > Crafts, Hobbies & Home > Crafts & Hobbies > (specific craft: Knitting / Woodworking / Photography / Sewing / etc.) |
| Career & Professional | Kindle Store > Kindle eBooks > Business & Money > Job Hunting & Careers (or Skills > the relevant sub-skill) |
| Life Skills & Practical | Kindle Store > Kindle eBooks > Self-Help > Self-Management > Time Management (or Health, Fitness & Dieting > Mental Health > Self-Esteem; depends on sub-focus) |
| Technology & Software | Kindle Store > Kindle eBooks > Computers & Technology > (specific software / hardware / programming language); for consumer-tech how-to use Computers & Technology > Personal Computers |
| Reference / Comprehensive | Kindle Store > Kindle eBooks > Reference > (specific reference type: Encyclopedias / Dictionaries / Quotations / etc.) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Education & Teaching | Kindle Store > Kindle eBooks > Education & Teaching > (Subjects > specific subject) |
| Personal transformation | Kindle Store > Kindle eBooks > Self-Help > Personal Transformation |
| Productivity / efficiency | Kindle Store > Kindle eBooks > Self-Help > Self-Management > Time Management |
| Business skills | Kindle Store > Kindle eBooks > Business & Money > Skills > (Communication / Negotiation / Leadership) |
| Cooking-as-craft | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Cooking Methods (for craft-of-cooking how-tos) |
| Outdoor / sport / fitness | Kindle Store > Kindle eBooks > Sports & Outdoors > (specific activity) |
| Parenting / child | Kindle Store > Kindle eBooks > Parenting & Relationships > Parenting > (specific topic) |

### Keyword Recommendations

- The specific procedure or skill the book teaches as a phrase
  ("how to build a workbench", "knit your first sweater",
  "set up a personal CRM", "publish on KDP")
- Outcome / result the reader will achieve
  ("finished cabinet", "first novel published", "inbox zero",
  "running a half marathon")
- Tools / platforms / software named where relevant for SEO
  ("Notion", "Lightroom", "AutoCAD", "Scrivener", "Excel")
- Reader skill-level signal
  ("beginner", "step-by-step", "complete guide", "for absolute
  beginners", "from scratch")
- Time / commitment frame where appropriate
  ("weekend project", "30-day plan", "hour-a-day", "in one season")
- Comparable author names for discoverability
  (readers of Marie Kondo, readers of Tim Ferriss, readers of
  David Allen)
- Avoid generic single-word terms ("guide", "manual", "book") — they
  drown in algorithmic noise; prefer the specific procedure +
  outcome compound
