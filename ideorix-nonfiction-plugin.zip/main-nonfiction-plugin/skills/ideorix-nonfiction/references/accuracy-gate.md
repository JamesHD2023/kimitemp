---
name: accuracy-gate
description: "5 non-fiction verification agent protocols with scoring schemas"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Non-Fiction Verification Agents Protocol

## Subagent Output Verification Binding (MANDATORY for every dispatched verification agent — v2.7.7+)

The five verification agents in this gate are **dispatched as
subagents**. Every dispatch MUST conform to the Subagent Output
Verification protocol (`subagent-output-verification.md`):

- Each dispatch prompt MUST specify the **explicit task scope**
  (chapter file path, sources ledger to cross-check, exact items
  to verify) and the **required evidence format** (file path,
  line number, exact extracted text, source reference where
  applicable).
- Each subagent's return MUST contain evidence the main agent
  can spot-check. NF-specific concern: citation/source-attribution
  claims MUST include the (file path, line, exact citation text,
  source ledger entry referenced) so the main agent can verify
  the cited claim against the source. Narrative claims of
  "verification passed" without per-citation evidence are
  FAILED_DISPATCH.
- The main agent MUST spot-check at least one evidence item per
  subagent return before treating the result as authoritative.
  Discrepancy between claimed evidence and actual file content
  is FAILED_DISPATCH.

This binding addresses the documented subagent failure modes:
hallucinated audit completion, stub completion, scope-drift
extrapolation, confident-wrong specifics, acknowledgement-as-
completion. See `subagent-output-verification.md` for the full
failure-mode list and the evidence-bearing return-contract
template.

## Overview

Five verification agents analyse each chapter AFTER the Content Writer produces it.
They return STRUCTURED reports with scores, severity levels, and specific fixes.
This is NOT prose feedback — it's typed, actionable, cross-referenceable data.

## When to Run

**DEFAULT — Per-chapter (MANDATORY, automatic, HARD GATE):**
Run all 5 agents after each chapter is written. Fix critical issues before
writing the next chapter. This prevents error accumulation.

**CRITICAL DISTINCTION — Post-Writing Checks vs Verification Suite:**

| Post-Writing Checks (Steps 8-9) | 5-Agent Verification Suite (Step 12) |
|---|---|
| Word count vs target | Source Guardian |
| Placeholder scan | Evidence Auditor |
| Attribution scan | Citation Keeper |
| Jargon check | Expert Tracker |
| AI-ism markers | Argument Analyst |
| Mechanical, fast | Deep editorial, structured reports |
| Does NOT produce a report file | MUST produce a report file |
| Does NOT produce scores | MUST produce 5 individual + 1 weighted score |
| Necessary but NOT sufficient | The actual quality gate |

**HARD GATE — Report File Requirement:**
The verification suite is NOT complete until:
1. All 5 agents have run and produced structured output
2. A cross-agent analysis with weighted score has been calculated
3. The consolidated report has been written to
   `engine-data/reports/ch{NN}-verification.md` using the bash
   side-file + mv-swap protocol (Class 1: NEW per-chapter file in a
   subdirectory — the Write tool silently drops virtiofs subdir
   writes; see `core-pipeline.md` File Operation Policy → "MANDATORY
   WRITE PROTOCOL — Class 1"). After the mv, run the post-write
   integrity check (`ls -la` + `stat -c %s` on the target path); the
   `ls` exit code IS the existence proof — do NOT Read the report
   back to verify existence
4. The progress dashboard has been displayed to the user in conversation
5. The pipeline checkpoint has been updated with the score and the
   "Report Saved" field set to Yes — the checkpoint is the cross-
   chapter audit trail

**IMPORTANT:** Do NOT offer alternatives to per-chapter verification.
Do NOT suggest skipping, batching, or running a "lightweight" version.

## Context Scoping for Verification (Token Efficiency)

Verification agents receive scoped context:
1. **Source scoping:** Load source profiles ONLY for sources cited in the chapter
2. **Summary scoping:** Last 3 chapter summaries in full. Earlier as one-line precis.
3. **Full source index for fact-checking:** A lightweight lookup list of all source
   names, dates, and key claims (not full profiles) for the Source Guardian's
   canonical check. Full profiles loaded only if a mismatch is detected.

---

## Agent 1: Source Guardian

### Purpose
Verify every factual claim is sourced. Detect unsupported assertions. Check
citation accuracy against the Research Bible.

### System Prompt
```
You are the Source Guardian — a specialist fact-checker for {category} non-fiction.
Your job is to verify that every factual claim in this chapter is supported by
a documented source. You do NOT rewrite; you ONLY analyse and report.

SCOPE: You are evaluating Chapter {chapter_number}.
Only report issues where THIS chapter:
- Makes factual claims without source support
- Cites sources incorrectly or inconsistently
- Presents opinion as fact without qualification
- Uses unsourced generalisations

CANONICAL SOURCE CHECK (MANDATORY — run BEFORE any other analysis):
Cross-check these against the Research Bible and source database:
1. EVERY cited source name must match the source database exactly
2. EVERY date cited must match the source's recorded date
3. EVERY statistic must match the source's recorded value
4. EVERY quote must match the source's recorded text
5. EVERY person's credentials must match their Research Bible entry

CANON COMPLIANCE CHECK (MANDATORY, MECHANICAL — run FIRST before anything
else):
This is the first check the Source Guardian runs on every chapter. It
is mechanical, not judgement-based. Follow the exact procedure:

  1. Read `engine-data/entity-canon.md` with the Read tool. Extract the
     Key Figures, Sources, Organisations/Institutions, and Places tables.
     Build an in-memory name-set from the Canonical Name column AND
     every short form / alias in the Also Known As columns. Every form
     the manuscript is authorised to use is now in this set.

  2. Scan the full chapter prose for every proper-noun-shaped token:
     - Capitalised multi-word sequences (e.g., "Dr Jane Thompson",
       "London School of Economics")
     - Capitalised words mid-sentence that are likely proper nouns
     - Possessives with proper-noun roots ("Thompson's")
     - Citation short-forms ("(Thompson 2024)", "Thompson, 2024")

  3. For each candidate, check the authorised name-set:
     - If it matches a Canonical Name or alias → PASS, record
     - If it does not match → add to Canon Drift list with exact quote
       and location

  4. Non-fiction drift severity: a misspelled real person's name is
     CRITICAL and blocking — it is a factual error, not a stylistic
     one. A misquoted source title is CRITICAL. Flag each drift at
     CRITICAL severity in the ISSUES list below.

  5. If `engine-data/entity-canon.md` does not exist or is empty: STOP.
     Set Canon Check to "blocked" and alert the user. The Research
     Bible's Entity Canon Lockfile protocol (see `research-bible.md`)
     did not run or failed. Source Guardian cannot complete until the
     canon file exists.

  6. Do NOT use the prose-format sources.md entries as the source of
     truth for this check. sources.md has paragraph-form descriptions;
     entity-canon.md is the flat authoritative lookup. Always use
     entity-canon.md for Canon Compliance.

**Why this check is mechanical, not judgement-based:** The fiction
engine had a production failure where a character's canonical name was
set in the Story Bible but prose drifted across 3 chapters before the
user caught it manually. The non-fiction equivalent is more serious:
drift in a real person's name, a source author, or an institution is
a factual error that damages the book's credibility. This check runs
BEFORE any other analysis, uses a flat table lookup, and is the first
line of defence against name drift.

UNSUPPORTED CLAIM DETECTION:
Flag these patterns:
- "Research shows..." (which research?)
- "Studies have found..." (which studies?)
- "Experts agree..." (which experts?)
- "It is widely known..." (source needed)
- "Some people believe..." (who? cite them)
- Any factual assertion without an identifiable source

NEVER RATIONALISE MISSING SOURCES. If a claim has no source, flag it.
Do not assume the author "must have a source." No source = error.
```

### Required Output Schema
```
STATUS: pass | warning | fail
SCORE: 0-100

CANONICAL SOURCE CHECK:
For each source, date, statistic, quote, and credential:
- ITEM: [what was cited]
- RESEARCH BIBLE VALUE: [canonical value]
- MATCH: yes | NO — CRITICAL
List all checks performed, not just failures.

CANON COMPLIANCE REPORT (MECHANICAL — run FIRST):
- Canon file loaded: Yes / No (path: engine-data/entity-canon.md)
- Total canonical Key Figures: {N}
- Total canonical Sources: {N}
- Total canonical Institutions/Organisations: {N}
- Total canonical Places: {N}
- Total aliases indexed: {N}
- Proper-noun candidates found in chapter: {N}
- Matches against canonical names or aliases: {N}
- Drift items (not in canon): {N}
- Verdict: clean | {N} drift | blocked (canon file missing)

Drift detail (for each unmatched name-shaped token):
- TOKEN: "{exact text from chapter}"
- LOCATION: line {N}, sentence starts "..."
- CATEGORY: Key Figure | Source | Institution | Place | Unknown
- PLAUSIBLY REFERS TO: {closest canonical match} (fuzzy)
- RECOMMENDATION: Add alias | Declare new entity (user verifies) | Rewrite
- FACTUAL RISK: {brief note on what could be wrong — misattributed quote,
  misspelled real person, wrong institution}

The drift verdict MUST be written to the pipeline checkpoint's
"Canon Check" column and flows into the post-chapter Progress Dashboard's
"Canon Drift" line. Non-fiction drift items are always CRITICAL because
they are factual errors, not stylistic ones.

SOURCE DIVERSITY METRICS (MANDATORY — per chapter):

Analyse the distribution of sources cited in this chapter:

1. **Source count:** How many distinct sources are cited?
2. **Dominant source:** Which source is cited most? What % of
   citations does it account for?
3. **Discipline concentration:** Are all sources from the same
   discipline? (e.g., all psychology, all economics)
   - Flag if >70% of citations are from one discipline
4. **Perspective diversity:** Do the cited sources represent
   multiple viewpoints, or do they all support the same position?
   - Flag if all sources support the same conclusion (echo chamber)
5. **Recency:** What is the median publication year of cited sources?
   - Flag if median is >10 years old for a field with active research
6. **Geographic origin:** Are sources exclusively from one country
   or region?
   - Advisory flag if >80% from one country

Report:
```
SOURCE DIVERSITY:
  Sources cited this chapter: {N}
  Dominant source: {name} ({N}% of citations)
  Discipline concentration: {low/medium/high} — {details}
  Perspective diversity: {diverse/mixed/narrow} — {details}
  Recency median: {year}
  Geographic spread: {broad/regional/single-country}
  Overall: {balanced / concentration-risk / narrow}
```

Flag chapters where concentration is HIGH or perspective is NARROW
as WARN. The author may have valid reasons (a chapter focused on one
study) but should be aware.

UNSUPPORTED CLAIMS:
For each unsupported claim found:
- CLAIM: [the assertion]
- LOCATION: [line/paragraph]
- SEVERITY: minor (background context) | moderate (supporting point) | critical (key argument)
- SUGGESTION: [add source X, or qualify as author's analysis]

SOURCE AUDIT TABLE:
| Source | Times Cited | Correct | Issues |
|--------|------------|---------|--------|

ISSUES:
For each issue:
- TYPE: unsourced | misattributed | inaccurate | inconsistent
- SEVERITY: minor | moderate | critical
- DESCRIPTION: [specific problem]
- QUOTE: [exact text]
- SUGGESTION: [how to fix]

SUMMARY: [1-3 sentence overview]
```

---

## Agent 2: Evidence Auditor

### Purpose
Evaluate argument quality, evidence strength, prose craft, and authority voice.

### System Prompt
```
You are the Evidence Auditor — evaluating argument quality and prose craft
for Chapter {chapter_number} of a {category} non-fiction manuscript.

{category_quality_check_criteria}

Score each dimension 0-100:
- ARGUMENT STRENGTH: How well claims are supported by evidence
- CATEGORY FIT: How well it meets {category} reader expectations
- PACING: Appropriate information density for this position
- EVIDENCE INTEGRATION: How naturally sources are woven into prose

7 NON-FICTION CRAFT COMMANDMENTS — Score each 0-10:
1. Evidence Not Assertion
2. Clear Attribution
3. Defined Scope
4. Specific Examples
5. Pacing = Complexity
6. Jargon Management
7. Accurate Details

LOGICAL FALLACY DETECTION:
Flag any instance of: straw man, ad hominem, false equivalence, post hoc
ergo propter hoc, appeal to authority (without credentials), slippery slope,
cherry-picking, survivorship bias, false dichotomy.
```

### Required Output Schema
```
STATUS: pass | warning | fail
ARGUMENT STRENGTH: 0-100
CATEGORY FIT: 0-100
PACING: 0-100
EVIDENCE INTEGRATION: 0-100

7 NON-FICTION CRAFT COMMANDMENTS:
  EVIDENCE_NOT_ASSERTION: 0-10
  CLEAR_ATTRIBUTION: 0-10
  DEFINED_SCOPE: 0-10
  SPECIFIC_EXAMPLES: 0-10
  PACING_COMPLEXITY: 0-10
  JARGON_MANAGEMENT: 0-10
  ACCURATE_DETAILS: 0-10
  TOTAL: 0-70
  STATUS: excellent (60-70) | acceptable (45-59) | needs-revision (below 45)

AUTHORITY VOICE COMPLIANCE:
Load the Authority Voice Profile. Check 3+ passages:
1. VOCABULARY LEVEL: Match? yes | drift-detected
2. SENTENCE ARCHITECTURE: Match? yes | drift-detected
3. EVIDENCE INTEGRATION STYLE: Match? yes | drift-detected
4. READER RELATIONSHIP: Match? yes | drift-detected
5. AUTHORITY MARKERS: Match? yes | drift-detected
VOICE VERDICT: consistent | minor-drift | significant-drift

PACING SLIDER VALIDATION:
  Architect Targets vs Prose Delivery for each slider

LOGICAL FALLACIES DETECTED:
For each: type, location, description, severity

WORD COUNT VALIDATION:
  Target vs Actual with per-section breakdown

ISSUES:
For each: category, severity, description, quote, suggestion

STRENGTHS: [2-3 things the chapter does well]
```

---

## Agent 3: Citation Keeper

### Purpose
Verify all citations are accurate, consistent, and properly formatted.

### System Prompt
```
You are the Citation Keeper — verifying citation accuracy and consistency
for Chapter {chapter_number}. Citation style: {citation_style}.

CHECKS:
1. FORMAT: Every citation matches the selected style (Chicago/APA/MLA/Harvard)
2. COMPLETENESS: Every cited source appears in the bibliography/endnotes
3. ORPHANS: No citations in text that lack a bibliography entry
4. PHANTOMS: No bibliography entries that are never cited
5. CONSISTENCY: Same source cited the same way every time
6. DATE ACCURACY: Historical dates and publication dates are correct
7. CHRONOLOGICAL LOGIC: In narrative sections, events are in correct order
```

### Required Output Schema
```
STATUS: pass | warning | fail
SCORE: 0-100

CITATION AUDIT TABLE:
| Citation | Format Correct | In Bibliography | Consistent | Issues |
|----------|---------------|-----------------|------------|--------|

CHRONOLOGY CHECK:
For each date/time reference:
- DATE: [what was stated]
- CONTEXT: [where in the chapter]
- CONSISTENT WITH PRIOR CHAPTERS: yes | no

ISSUES:
For each: type, severity, description, location, suggestion

SUMMARY: [1-3 sentence overview]
```

---

## Agent 4: Expert Tracker

### Purpose
Verify that real people are accurately represented throughout the manuscript.

### System Prompt
```
You are the Expert Tracker — verifying that all real people mentioned in
Chapter {chapter_number} are accurately and consistently represented.

CHECKS:
1. NAME ACCURACY: Every name spelled correctly (match Research Bible)
2. CREDENTIALS: Professional titles and affiliations are current and accurate
3. QUOTE ATTRIBUTION: Quotes are attributed to the correct person
4. POSITION ACCURACY: Individuals' views and positions are not misrepresented
5. CONSISTENCY: Same person described consistently across chapters
6. BIOGRAPHICAL FACTS: Dates, institutions, achievements match Research Bible
```

### Required Output Schema
```
STATUS: pass | warning | fail
SCORE: 0-100

EXPERT AUDIT TABLE:
For each person mentioned:
| Name | Credentials Match | Quotes Accurate | Position Represented Fairly | Consistent |
|------|------------------|-----------------|---------------------------|------------|

ISSUES:
For each: type, severity, person, description, Research Bible value, chapter value

SUMMARY: [1-3 sentence overview]
```

---

## Agent 5: Argument Analyst

### Purpose
Verify the book's thesis is served by evidence progression. Check for logical
gaps and argument coherence.

### System Prompt
```
You are the Argument Analyst — evaluating argument progression and structural
coherence for Chapter {chapter_number} of a {category} non-fiction manuscript.

CHECKS:
1. THESIS SERVICE: Does this chapter meaningfully advance the book's central thesis?
2. ARGUMENT ESCALATION: Is complexity/insight increasing from previous chapters?
3. LOGICAL GAPS: Are there jumps in logic or missing connective tissue?
4. CONTRADICTIONS: Does this chapter contradict claims in earlier chapters?
5. STRUCTURE BEAT: Does this chapter deliver its assigned structural beat?
6. COUNTER-ARGUMENTS: Where relevant, are opposing views acknowledged?
7. READER POSITION: Is the reader's knowledge state clear and advancing?
```

### Required Output Schema
```
STATUS: pass | warning | fail
SCORE: 0-100
BEAT DELIVERY: delivered | partial | missed

STRUCTURE BEAT:
  Current Beat: {beat_name}
  Target position: {percentage}%
  Chapter position: {actual_percentage}%
  Delivery status: delivered | partial | missed

ARGUMENT TRAJECTORY:
| Ch | Complexity | Insight Level | Trend |
|----|-----------|--------------|-------|

THESIS ADVANCEMENT:
  Does this chapter advance the thesis? yes | partially | no
  How: [specific contribution]

LOGICAL GAP CHECK:
  Gaps found: [list or "none"]

COUNTER-ARGUMENT STATUS:
  Required: [list of counter-arguments this chapter should address]
  Addressed: [list of those actually addressed]
  Missing: [list of those skipped]

ISSUES:
For each: type, severity, description, suggestion

SUMMARY: [1-3 sentence overview]
```

---

## Agent 6: Series Research Guardian (Multi-Volume Projects Only)

### When to Run
Only active when `series-data/series-bible.md` exists (in the parent
series folder) or `engine-data/series-bible.md` exists (legacy layout).

### Purpose
Validate cross-volume consistency: source continuity, argument continuation,
no contradictions between volumes.

### Checks
- Sources cited in prior volumes cited consistently
- Thesis builds across volumes without contradiction
- Key figures described consistently across volumes
- Cross-volume references are accurate

---

## Cross-Agent Analysis

### Weighted Scoring Formula

```
Standard:
  Source Guardian × 0.25 + Evidence Auditor × 0.20 + Citation Keeper × 0.15
  + Expert Tracker × 0.25 + Argument Analyst × 0.15

Series (when Agent 6 active):
  Source × 0.20 + Evidence × 0.15 + Citation × 0.10
  + Expert × 0.20 + Argument × 0.15 + Series × 0.20
```

### Score Calibration Anchors

```
95-100: EXCEPTIONAL — Publishable quality. Rigorous sourcing. Flawless accuracy.
        Should appear in <5% of chapters.

90-94:  STRONG — Minor issues only. One soft citation, one small scope drift.
        This is a good chapter.

85-89:  SOLID — 2-3 issues. An unsupported claim, a formatting inconsistency.
        Acceptable chapter.

80-84:  ACCEPTABLE — Noticeable issues but nothing that breaks the argument.
        Proceed with notes.

75-79:  NEEDS WORK — Significant sourcing gaps or logical issues. Fix before
        proceeding.

70-74:  WEAK — Substantial revision needed. Multiple unsupported claims or
        logical failures.

Below 70: FAIL — Fundamental issues. Missing sources, inaccurate facts, or
          argument collapse. Rewrite.
```

---

## Verification Report File Format (MANDATORY)

Every chapter verification MUST produce a report file.

**File path:** `engine-data/reports/ch{NN}-verification.md`

```markdown
# Verification Report — Chapter {N}: "{Title}"
Generated: {timestamp}

## Scores
| Agent | Score | Status |
|-------|-------|--------|
| Source Guardian | {score}/100 | {pass/warning/fail} |
| Evidence Auditor | {score}/100 | {pass/warning/fail} |
| Citation Keeper | {score}/100 | {pass/warning/fail} |
| Expert Tracker | {score}/100 | {pass/warning/fail} |
| Argument Analyst | {score}/100 | {pass/warning/fail} |
| **Weighted Total** | **{score}/100** | **{status}** |

## Issues
### Critical
{list or "None"}

### Moderate
{list or "None"}

### Minor
{list or "None"}

## Source Audit Summary
Total claims: {N} | Sourced: {N} | Unsourced: {N}

## Word Count
Target: {target} | Actual: {actual} | {percentage}%

## Structure Beat
Beat: "{beat_name}" — {delivered/partial/missed}

## Fixes Applied
{list or "None — clean pass"}
```

**After writing the report file via the Class 1 bash protocol:**
1. The report file `engine-data/reports/ch{NN}-verification.md` is
   a Class 1 NEW file in a subdirectory — write it with the bash
   side-file + mv-swap pattern from `core-pipeline.md` File
   Operation Policy, NOT the Write tool. Verify with `ls -la` +
   `stat -c %s` on the target path; the `ls` exit code IS the
   existence proof — do NOT Read the file back to confirm. If the
   `ls` check fails, STOP and alert the user.
2. Display the Progress Dashboard to the user
3. Update the pipeline checkpoint

---

## Revision Protocol

If chapter score is below 80 or any agent returns "fail":

1. Collect all critical issues across all 5 agents
2. Present to user with recommended fixes
3. Apply fixes SURGICALLY — do not rewrite the chapter
4. Re-run only the agents that flagged critical issues
5. Verify scores improved before proceeding
