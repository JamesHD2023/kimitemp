---
name: import-project
description: "Import an existing non-fiction project from another writing or planning tool (Plottr and Scrivener supported; more sources coming)"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Import Project (Non-Fiction)

Bring your existing non-fiction work from another writing or planning tool
into Ideorix Non-Fiction. The importer parses your outline, manuscript
prose, key figures, places, timeline, and research notes, then lands the
result in a working Ideorix Non-Fiction project with a starter Research
Bible ready for the full research-and-writing pipeline.

## What it does

| Task | What happens |
|------|-------------|
| **Outline import** | Your beats, chapter synopses, or structural outline become Section 9 (Chapter Outline) entries in the Research Bible |
| **Manuscript import** | If the source tool stores prose (Scrivener), each chapter becomes an Ideorix chapter file, ready for Edit & Revise, Manuscript Clinic, or Fact-Checking |
| **Key Figures import** | Characters / People / Cast entries → Section 7 (Key Figures) — name, aliases, biographical detail, credentials, role in the argument |
| **Subject Context import** | Places / Locations entries → Section 5 (Subject Context) — geographic, institutional, and scene scope |
| **Timeline preservation** | Day-grouped or date-indexed timelines → Section 6 (Timeline / Chronology) |
| **Research notes triage** | Source-like material from Research or Notes folders is surfaced during Research Bible review as candidate Section 4 (Key Sources) entries — never auto-promoted, because source provenance is too important to infer |
| **Footnote preservation** | Where the source tool stores footnotes in prose (Scrivener), citations are preserved in chapter files and extracted as a candidate sources list |
| **Reduced Phase 1 setup** | Skips setup questions the source tool already answered; asks only for what Ideorix Non-Fiction needs (category, dialect, length tier, research scope, citation style, voice profile, pen name) |
| **Choose your next step** | Hand off to Research Bible review, Continue Researching, Edit & Revise, Manuscript Clinic, or Fact-Checking depending on whether you imported an outline or full prose |

## Supported sources

| Source | Status | Type | Notes |
|--------|--------|------|-------|
| **Plottr** | ✓ Supported | Outline-only | Word export (.docx) — beats, storylines, characters, places, timeline → starter Research Bible. Best for narrative non-fiction (memoir, biography, true crime, narrative history, investigative journalism). |
| **Scrivener** | ✓ Supported | Full-prose or outline | `.scriv` bundle (zipped) — full binder, prose chapters, People/Places/Research folders, footnote preservation, citation-style inference. Works for any non-fiction category. |
| Campfire | Planned | Outline | |
| World Anvil | Planned | Reference | |
| Notion / Obsidian | Planned | Outline + notes | |

**Novelcrafter is not currently supported on the non-fiction side.** Novelcrafter's
data model is fiction-focused (codex of characters, locations, objects,
subplots) and doesn't map cleanly onto the Research Bible's source-driven
structure. If you wrote non-fiction in Novelcrafter, export as markdown and
use **Scrivener import** with a converted `.scriv` bundle, or paste the
manuscript text directly into a new Ideorix Non-Fiction project.

More sources are added as users ask for them. If you use a tool that isn't
listed, export your work as markdown and ask — most tools that export
markdown can be imported with minor tweaks to the parser.

## How to start

Say any of:
- "Import project"
- "Import my existing work"
- "Import from Plottr"
- "Import from Scrivener"
- "Bring my Plottr outline across"
- "Bring my Scrivener project across"
- "I have a Plottr project"
- "I have a Scrivener project"

Or pick **Import Project** from the Writers Studio or Full Creative Suite
menu, then choose the source.

## Source routing

The dispatcher checks which source the user named (or asks) and hands off
to the right importer:

```
User says "Import project"  →  Ask "Which tool?"  (Plottr / Scrivener / Other)
User says "Plottr"          →  plottr-import.md    →  plottr-importer.md
User says "Scrivener"       →  scrivener-import.md →  scrivener-importer.md
```

If the user says "Novelcrafter", explain that Novelcrafter is fiction-focused
and offer the Scrivener conversion path OR a manual paste-in.

## After any import

Every importer lands the project in the same place:

```
~/Documents/Ideorix-Projects/{Your Title}/
├── project-config.md             Project metadata + setup answers
├── manuscript/imported/          Chapters (full-prose imports only)
├── engine-data/
│   ├── research-bible.md         Sections 1–11 — filled from source tool
│   ├── entities/                 Key Figures, Subject Context, Timeline
│   ├── research-notes/           Imported notes, candidate sources
│   └── summaries/                Chapter synopses from the export
├── marketing/
└── imports/{source-tool}-export/ Original unpacked export (for reference)
```

From there, you choose your next step based on what you imported:

- **Full-prose Scrivener project** → Edit & Revise, Manuscript Clinic,
  Fact-Checking, or Export & Publish
- **Outline-only Plottr or Scrivener project** → Research Bible review,
  then chapter generation via Continue Researching

## Bible Coverage Audit (MANDATORY — HARD GATE — runs after import, before any editing)

Importers extract entities (key figures, places, organisations,
recurring concepts) from imported documents into the research bible
and entity-canon. Extraction is best-effort: PDFs with imperfect text
extraction lose entities silently; lore docs that only imply entities
through context get under-extracted; subplots referenced obliquely in
prose may name a place/event the extractor doesn't catalogue.

Without this gate, the user starts editing with a bible that LOOKS
complete but is actually a 70-90% subset of what the manuscript
references. The engine then sees gaps and **invents** to fill them
during chapter generation, surfacing as "new" characters or "new"
subplots the user didn't write — typically caught only after wasted
work.

**The Bible Coverage Audit closes this gap at import time.** Every
entity referenced in the manuscript prose is reconciled against the
bible BEFORE the user begins editing. Gaps are surfaced as a triage
list (Add to bible / One-off mention / Typo for existing entity /
Skip for now). The cost of fixing a gap at import time is one
append-line per entity; the cost of fixing it after generated prose
has been built on top is an order of magnitude higher.

**Invocation:** every importer calls the Bible Coverage Audit
immediately after writing the bible and before unblocking downstream
editing flows. The audit is a HARD GATE — editing flows (chapter
generation, Manuscript Clinic, Edit & Revise, Fact-Checking, Export &
Publish) are BLOCKED until the audit completes and the user reconciles
the flagged entities.

**Full protocol:** see `bible-coverage-audit.md` for the audit method,
the triage UI, the persistence step, and the bulk-action shortcuts
(`all-add` / `all-oneoff` / `all-skip`) for clean imports where only
a few outliers need individual attention.

**Re-running:** the user can re-run the audit at any time by saying
"audit my bible coverage" — useful after importing additional source
material, after a major round of edits where new entity references
have accumulated, or as a sanity check before publishing.

## What Ideorix Non-Fiction will ask you after import

Source tools don't record everything the non-fiction engine needs. After
the import completes, you'll be asked for:

1. **Category** — controls which category file loads (craft rules, evidence
   requirements, fact-checking depth)
2. **Dialect** — US or GB English
3. **Length tier** — inferred from imported word count or beat density,
   confirmed by you
4. **Research scope** — how deep the fact-checking pass should run
5. **Citation style** — MLA, Chicago, APA, or author-preferred (Scrivener
   import can infer this from existing footnotes)
6. **Voice profile** — attach an existing Authority Voice Profile, build one
   now via Authority Builder, or skip
7. **Pen name** — attach an existing pen name, create one, or skip

Everything else (source assignments, counter-arguments, thesis refinement,
market positioning) is populated during Research Bible review.

## Importer protocols

Each source tool has its own protocol file that the dispatcher invokes:

| Source | User-facing doc | Protocol |
|--------|-----------------|----------|
| Plottr | `plottr-import.md` | `plottr-importer.md` |
| Scrivener | `scrivener-import.md` | `scrivener-importer.md` |

> See each importer's user-facing doc for the export instructions specific
> to that tool.
