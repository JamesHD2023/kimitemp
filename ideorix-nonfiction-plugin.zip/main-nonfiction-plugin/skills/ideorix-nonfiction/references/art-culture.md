---
name: art-culture-category
description: "Category-specific instructions for art, music, and culture non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Art / Music / Culture. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | art-culture |
| Display Name | Art / Music / Culture |
| Parent Group | Arts & Photography (and Performing Arts for theatre / dance / film) |
| Typical Word Count | 60,000–110,000 (criticism collections often 60,000–80,000; comprehensive histories of art forms 90,000–130,000; major artist / movement biographies 100,000–180,000; illustrated books often shorter in word count but with substantial visual content) |
| Default Structure | Chronological (history of an art form), thematic (cultural criticism, cross-form analysis), or biographical (single artist / movement). Each chapter typically grounded in specific works examined closely (ekphrasis as core craft technique); historical and cultural context woven through; analysis presented as interpretation rather than asserted as objective truth |
| Citation Style | Endnotes for historical and scholarly claims; named-source attribution for interviews and primary documents; specific works cited precisely (artist, title, year, medium, dimensions where applicable, current location); image credits and reproduction permissions where applicable; named scholars and prior critics engaged with where the book enters existing critical conversation; bibliography appended for substantial works |
| Audience Baseline | Reader interested in the art form at varying technical depth — from the literate generalist who reads Berger, Hughes, or Ross to the specialist with formal training. Assume some prior interest but no formal training; key terms defined at first use; visual / aural literacy assumed within the form's general audience |
| Comparable Titles | John Berger (*Ways of Seeing*, *About Looking*), Robert Hughes (*The Shock of the New*), Olivia Laing (*The Lonely City*, *Funny Weather*), Sarah Thornton (*Seven Days in the Art World*, *33 Artists in 3 Acts*), Mary Gabriel (*Ninth Street Women*), Greil Marcus (*Lipstick Traces*, *Mystery Train*), Alex Ross (*The Rest Is Noise*, *Wagnerism*), Carl Wilson (*Let's Talk About Love*), Hanif Abdurraqib (*They Can't Kill Us Until They Kill Us*, *A Little Devil in America*), Pauline Kael (*For Keeps*, *5001 Nights at the Movies*), David Thomson (*The Biographical Dictionary of Film*), Hilton Als (*White Girls*, theatre criticism for *The New Yorker*), Wesley Morris, Susan Sontag (*Against Interpretation*, *On Photography*), Margo Jefferson (*Negroland*, *On Michael Jackson*) |

## Subcategory Options

When the user selects Art / Music / Culture, prompt for subcategory
refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| visual-art-history-criticism | Visual Art History & Criticism | Painting, sculpture, photography, installation, performance art; movements, artists, individual works; the Berger / Hughes / Saltz / Smith / Laing tradition | Movement-or-artist chapter spine; ekphrasis (vivid description of the work) as the recurring craft beat; historical and cultural context; close reading of representative works rather than survey-level coverage |
| music-history-criticism | Music History & Criticism | Genres, eras, individual musicians and bands, cultural impact of music; the Marcus / Ross / Wilson / Sheffield / Sanneh / Abdurraqib lineage | Genre-or-era chapter spine, or single-artist deep-dive; close reading of specific recordings / performances / songs; cultural and historical context; technical musical detail calibrated to general-audience accessibility |
| film-cinema-criticism | Film & Cinema Criticism | Films, filmmakers, movements, the cinema as form; the Kael / Ebert / Thomson / Morris / Dargis lineage | Director / movement / film-by-film structure; close reading of specific scenes, performances, formal choices; production and reception context; criticism's own tradition engaged with where applicable |
| theatre-performance-dance | Theatre / Performance / Dance | Plays and productions, performance art, dance and choreography; the Als / Homans / performance-studies lineage | Production-or-work-anchored chapters; the ephemeral-art problem (writing about live performance the reader cannot see); close attention to performer, choreographer, director choices; performance-history context |
| architecture-design | Architecture & Design | Buildings, designers, design movements, urban form, decorative arts; the Rybczynski / Huxtable / design-history lineage | Building / designer / movement chapters; close reading of specific structures or designs; technical and material detail accessible to general audience; urban / social / political context |
| cross-form-cultural-criticism | Cross-Form Cultural Criticism | Cultural criticism that ranges across art forms — music + film + visual + literature + popular culture; the Sontag / Als / Jefferson / Tolentino / Gay broader-criticism lineage (overlap with essay-collection category) | Theme-or-question-led structure; works from multiple forms examined as evidence; the critic's distinctive perceptual lens central; often essay-collection in form |
| creative-biography | Creative Biography (Artist / Musician / Filmmaker) | Biography of a specific creative figure — painter, musician, composer, filmmaker, choreographer, designer; the Mary Gabriel / Hagan / artistic-biography lineage (cross-references biography category) | Biographical chronology with the work as second protagonist; close engagement with the artistic output as evidence of inner life; production and reception context; positioned within the figure's tradition / movement |

**Default:** If the user does not specify, prompt for the art form
(visual / music / film / theatre-dance / architecture-design / multi-form)
and select accordingly; fallback to `visual-art-history-criticism` for
unclear cases (the broadest contemporary trade publishing in this
category).

## Structural Architect Instructions
```
STRUCTURE
- Chronological (history of an art form), thematic (cultural criticism), or biographical
- Core challenge: ekphrasis. making visual/auditory art vivid through prose
- Each chapter examines specific works, artists, or cultural moments
- Analysis must be accessible without dumbing down

CATEGORY ARCHITECTURE
- Specific works of art/music/film are the evidence. describe them vividly
- Historical and cultural context essential. art doesn't exist in a vacuum
- Critical interpretation presented as interpretation, not objective truth
- Non-Western traditions treated with equal analytical depth

FORBIDDEN
- Non-Western art treated as "exotic" or "primitive"
- Critical assertions without supporting close reading of specific works
- Name-dropping without analysis (mentioning artists without examining their work)
- Academic jargon without definition
```

## Content Writer Craft Rules
```
VOICE & TONE
- Accessible-intellectual. passionate expertise shared generously
- Vivid descriptions that let readers "see" or "hear" the art discussed
- Critical analysis grounded in specific details of specific works
- Enthusiasm is permitted. genuine passion for the subject is an asset
```

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the work, the artist, or the moment. A specific painting,
  performance, composition, or cultural rupture described with ekphrastic precision.
  The reader should see or hear the art through the prose.
- **Sentence calibration:** Medium-long flowing sentences averaging 16–26 words. Art
  and culture writing needs syntactic grace. the sentence should mirror the sensory
  richness of its subject.
- **Ekphrastic precision:** When describing a work of art, every detail must be
  accurate and evocative. Colour, form, texture, composition, sound. the description
  should be vivid enough that someone viewing the work would recognise it.
- **Sensory richness:** Engage multiple senses even when the art form primarily
  addresses one. Describe the weight of a sculpture, the silence before a musical
  phrase, the smell of oil paint in a studio.
- **Rhythm pattern:** Longer, flowing descriptive sentences alternate with shorter
  analytical ones. "The blue deepens from cobalt to ultramarine as the eye moves
  left, pooling in the lower corner where the figure turns away. Rothko wanted you
  to stand close." Description, then insight.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In art and culture
  writing, tension lives in interpretation. what the work means, why it matters,
  what it reveals about its moment.
- **Tension drivers:** The gap between what the viewer sees and what the artist
  intended. The cultural moment that made this work necessary. The argument the work
  makes with its predecessors.
- **Critical voice:** Interpretation presented as interpretation, not objective truth.
  "One way to read this" is honest; "this painting means" is overreach. The reader
  should feel invited to see, not told what to think.
- **Context rhythm:** Alternate between close reading of the work itself and the
  cultural, historical, or biographical context that illuminates it. Neither should
  dominate. the work and its world explain each other.
- **Passion is permitted:** Genuine enthusiasm for the subject is an asset in this
  genre. The prose should convey that the writer cares deeply. but care expressed
  through precision, not through adjective-laden gushing.
- **Read-aloud test:** The prose should sound like a brilliant gallery companion . 
  knowledgeable, perceptive, passionate, and generous. If it sounds like a catalogue
  essay or a lecture, revise.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Works described accurately (ekphrasis) | Specific works of art, music, film, performance, design described with enough precision that someone viewing / hearing / experiencing the work would recognise it; sensory and formal detail accurate; metaphor and imagery serve recognition rather than impressionistic substitution |
| 2 | Attribution precise | Every work named with creator, title, year, medium / format, current location or recording / publisher where applicable; "the Vermeer in The Hague" / "*Kind of Blue*, Columbia, 1959" / "*Citizen Kane*, RKO, 1941, dir. Orson Welles" — readers can find what the book references |
| 3 | Critical interpretation supported by close reading | Claims about what a work means, how it works, why it matters trace to specific features of the work that the reader can verify ("the diagonal of the composition pulls the eye toward..."); name-drop without analysis (the artist mentioned but the work not examined) is the category's most common failure |
| 4 | Interpretation framed as interpretation | "One reading of this work..." / "I see this as..." / "This painting can be understood as..." — interpretive claims are framed as the critic's reading; "this painting means X" overreach avoided where multiple readings are legitimate |
| 5 | Historical and cultural context substantive | Works are situated in their moment — what was happening in the art form, in the artist's life, in the surrounding culture, that shaped the work; context illuminates rather than imposes; the work and its context explain each other |
| 6 | Non-Western art treated with full analytical depth | Art from cultures not the author's own receives the same close-reading rigour as canonical Western work; the same analytical vocabulary; the same engagement with named scholars / critics from inside the tradition; tokenism and exoticism avoided |
| 7 | Critical voice without gatekeeping | The book's analytical position is held with confidence (criticism's job is judgement) but does not foreclose other readings; access criticism (helping readers see / hear what they hadn't) distinguished from gatekeeping (positioning the critic between the reader and the work) |
| 8 | Market and power awareness | Where the chapter touches the art world's institutions (galleries, museums, auction houses, record labels, studios, festivals, prize panels), the power dynamics are visible — who gets shown / collected / reviewed / promoted, and on what terms; the canon as constructed rather than discovered |
| 9 | Living-vs-deceased subject ethics | For living artists, the same fairness standards as biography (interview rights, defamation care, contestable claims handled with care); for deceased artists, the same scholarly-honesty standards as historical work (estate cooperation disclosed, primary sources cited) |
| 10 | Image / reproduction rights addressed | Where the book reproduces images, recordings, lyrics, or performance footage, rights are cleared; image credits accurate and complete; fair-use claims for criticism-and-commentary verified rather than assumed; permissions list in front or back matter |

## Source Requirements

### Mandatory Source Types

- **The works themselves.** Primary engagement with the actual
  art, music, film, performance, design — not paraphrased through
  prior criticism. The author has seen the paintings (in person
  where possible, in high-quality reproduction otherwise),
  listened to the recordings (the actual recordings, not summary
  by other critics), watched the films (in their best available
  form), attended the productions or seen archival film of them.
  The category's authority depends on this primary engagement;
  writing-about-writing-about-art fails the standard.
- **Artist's own materials.** Artist statements, interviews,
  letters, journals, manifestos, sketchbooks; for musicians:
  liner notes, demo recordings, contemporaneous press;
  for filmmakers: production notes, interviews, screenplays,
  shooting drafts, contemporaneous press; for performers:
  interviews, programme notes, contemporaneous reviews of the
  performances.
- **Art-historical / musicological / film-studies / performance-
  studies scholarship.** Peer-reviewed work in the relevant
  discipline; named critics' prior writing on the subject;
  scholarly catalogues raisonnés (where applicable); reference
  works (Grove Music Online for music, the Oxford Companion
  series for various forms, MoMA's Cubism / Abstract Expressionism
  / etc. exhibition catalogues for art-historical canon).
- **Exhibition catalogues, programme notes, liner notes,
  production documentation.** Primary documentation of how the
  work was presented, what its makers and curators said about
  it at the time, what the immediate critical response was.
- **Voices from inside the cultural traditions written about.**
  For art / music / film / performance from cultures not the
  author's own — particularly indigenous, African, Asian,
  Latin American, Middle Eastern, and other non-Western
  traditions — voices from within those traditions are
  mandatory inputs alongside Western critical scholarship.
  Scholars, critics, and practitioners from the tradition
  named and engaged with rather than treated only as objects
  of Western interpretation.
- **Interviews where access is available.** For living artists
  / musicians / filmmakers / performers, interviews are common
  and credited; the access bargain (cooperative biography vs.
  unauthorised) disclosed. Where interviews are off-record or
  background, the use is marked appropriately.

### Source Freshness

- **Primary works are stable but interpretation evolves.** The
  works themselves do not date; interpretive frameworks for
  approaching them do. Late-20th-century theoretical frames
  (psychoanalytic, structuralist, deconstructionist), 21st-
  century frames (postcolonial, queer, ecological, decolonial),
  feminist and anti-racist re-readings of canonical work — the
  current state of the interpretive field matters even when
  the works are old.
- **Canon revision is continuous.** The art-historical and
  musical canons have been substantially expanded over the
  last 30 years to include women artists / composers, artists
  of colour, queer artists, non-Western traditions previously
  marginalised. Books that engage with the canon as it stood
  in 1990 may need updating to reflect contemporary scholarship's
  reframings.
- **Living artists / musicians / filmmakers continue to work.**
  A monograph or critical study published mid-career often
  reads as incomplete a decade later as the artist's body of
  work expands; revised editions warranted on substantial
  reframing or new bodies of work.
- **Reception history matters.** A film panned at release
  and rehabilitated later (Heaven's Gate, Showgirls), a
  composer dismissed in their lifetime and canonised later
  (Mahler, Janáček), an artist marginalised by gender / race
  and reclaimed (Lee Krasner, Alma Thomas, Carmen Herrera),
  an album misunderstood at release (*Kid A*, *Yeezus*) — the
  arc of reception is part of the work's meaning. Books
  engage with the current state of reception rather than
  freezing the artist or work in their original critical
  reception.
- **Performance and ephemeral forms have their own currency.**
  Theatre and performance art exist primarily in the moment;
  books about them work largely from documentation
  (recordings, photographs, reviews, interviews, scripts);
  dating the production discussed essential.

### Attribution Standards

- **Specific works cited precisely.** Every work named with
  creator, title (italicised per house style), year, medium
  / format, dimensions where applicable, current location
  / publisher / studio. "Cézanne, *Mont Sainte-Victoire seen
  from Bibémus*, c. 1897, oil on canvas, 65 × 81 cm,
  Baltimore Museum of Art" / "Coltrane, *A Love Supreme*,
  Impulse!, 1965" / "Tarkovsky, *Stalker*, 1979, Mosfilm".
- **Borrowed criticism credited.** Where the book's reading of
  a work is informed by named prior critics — Berger on
  Vermeer, Greenberg on abstract expressionism, Kael on
  *McCabe & Mrs. Miller*, Marcus on Sly Stone — the prior
  critic is credited; silent borrowing of someone else's
  reading is a category-defining failure that other critics
  in the field will recognise.
- **Distinguish: observation / interpretation / fact.** "The
  painting is roughly two metres tall" (observation /
  attribution-from-museum-record). "I read this composition
  as..." (interpretation, framed as such). "Cézanne painted
  this in his Aix studio in autumn 1897" (biographical fact,
  sourced). Each register signals the evidence's nature.
- **Image / quotation rights disclosed.** Reproduction
  permissions for images, lyrics quoted at length, lengthy
  prose quotations — credited and within fair-use bounds or
  with permission; permissions list in front or back matter.
  For fair-use claims under criticism-and-commentary,
  verified against current case law rather than assumed.
- **Author positionality disclosed where it shapes the work.**
  The author's relationship to the form (practitioner /
  critic / scholar / amateur enthusiast), to the artist or
  movement (personal acquaintance / disciple / antagonist /
  outsider), to the cultural tradition (insider / outsider)
  — disclosed where it affects the analytical lens.
- **What is NOT acceptable.** Inventing works or attributions.
  Misattributing works (the wrong painting, the wrong year,
  the wrong location). Citing reproductions without engaging
  with the actual work. Borrowing prior critics' readings
  without credit. Claiming to have heard / seen / experienced
  works the author has not. Treating canon-formation as
  natural rather than constructed when the construction is
  the analytical move available.

## Category-Specific Guardrails

### MANDATORY. Critical Engagement (close reading, not name-dropping)

- The category's signature failure is name-dropping without
  analysis — the artist mentioned but the work not examined,
  the album cited but the music not described, the film
  referenced but the scene not read. Names without works
  serve nothing the reader needs.
- Every artist / musician / filmmaker / performer named in
  substantive analysis must be paired with at least one
  specific work examined in enough depth that the reader
  understands why this artist matters for what the chapter
  is arguing.
- "Close reading" means attention to specific features the
  reader can verify: the diagonal of the composition, the
  modal mixture in the second verse, the cut from the
  protagonist's face to the empty room, the choreographer's
  use of unison vs. canon. Vague evaluative claims
  ("brilliant", "masterpiece", "groundbreaking") without
  evidence are decoration, not analysis.
- The work IS the evidence. The chapter must demonstrate that
  the author has engaged with the work directly and at depth —
  not synthesised through other critics, not relied on
  reputation, not paraphrased a reproduction or a Spotify
  preview.

### MANDATORY. Attribution and Image Rights

- Every work named with full attribution: creator, title (in
  italics per house style), year, medium / format / dimensions
  where applicable, current location / publisher / studio.
  Errors in attribution (wrong year, wrong medium, wrong
  museum) damage the book's credibility specifically because
  art-world readers are often able to verify and notice.
- For reproductions in the book:
  - **Image rights cleared.** Permissions obtained from rights
    holders (artists / estates / museums / image agencies);
    fees paid; permissions list in front or back matter.
  - **Fair-use claims under criticism-and-commentary verified.**
    The fair-use safe harbour for criticism is real but
    not unlimited; lengthy or commercially-valuable
    reproductions warrant legal review or permission rather
    than assumed fair use.
  - **Image credits accurate.** Every image credited with
    creator, title, date, medium, current owner / source of
    reproduction, photographer of the reproduction where
    applicable.
- For lyrics, lengthy musical-score quotations, lengthy prose
  passages, or extended dialogue from films — same standards
  apply; permissions cleared or fair-use justified.
- Where the book is published in jurisdictions with stronger
  moral-rights regimes (Europe particularly), additional
  attention to droit moral — artists' rights to be properly
  attributed and to object to derogatory treatment of their
  work.

### MANDATORY. Distinguishing Curation from Reportage from Criticism

- Three distinct modes — and books often mix them, but
  honestly:
  - **Curation.** The book selects which artists / works /
    moments to include and present; the selection is the
    argument. ("These are the painters who matter for
    understanding..."; "These are the albums that
    transformed...".) The selection-as-argument is named
    and defended.
  - **Reportage.** The book describes what happened — at
    the gallery opening, in the studio, during the recording
    session, on the production. Standards: named sources,
    dated observation, fairness to subjects, accuracy of
    fact.
  - **Criticism.** The book offers a reading of the work — what
    it does, how it works, what it means. Standards: close
    reading of the work, interpretation framed as
    interpretation, prior critical conversation engaged
    with.
- Books that smuggle one mode's authority into another fail
  honesty — reporting framed as criticism (without the
  interpretive move); selection-curation framed as objective
  history (without acknowledging the selection's argument);
  criticism framed as reportage (without acknowledging the
  interpretive lens). Each mode has its own honesty
  requirements.

### MANDATORY. Cultural-Context Honesty (especially for art from cultures not the author's own)

- Art, music, film, performance from cultures not the author's
  own require:
  - **Engagement with critics, scholars, and practitioners
    from inside the culture.** Indigenous, African,
    Asian, Latin American, Middle Eastern critical
    traditions exist; the book engages with named scholars
    and critics from inside those traditions rather than
    only with Western interpreters of those traditions.
  - **Avoiding exoticism and primitivism.** "Exotic" / "primitive"
    / "tribal" framings of non-Western art are categorical
    failures; art from any culture is contemporary work made
    by living people (or recent ancestors of living people)
    in a tradition with its own internal logic and history.
  - **Anti-canonisation honesty.** Where the book engages
    with the canon (which it usually does), the construction
    of the canon — by whom, when, on what terms — is
    visible. The Western art-historical canon was built by
    specific people in specific institutions for specific
    purposes; treating it as natural rather than constructed
    is a failure available to current scholarship.
  - **Repatriation and provenance.** Works held in Western
    museums whose acquisition history involves colonial
    extraction, looting, or coerced sale increasingly warrant
    explicit acknowledgement; the book engages with this
    where the work's provenance is at issue.

### MANDATORY. Market and Power Awareness

- The art / music / film / culture industries have power
  structures — galleries, museums, auction houses, record
  labels, studios, streaming platforms, festivals, prize
  panels — that shape what gets made, shown, recorded,
  distributed, remembered. The book engages with these
  rather than treating the canon as the result of pure
  aesthetic merit.
- Specific power-aware moves available:
  - **Who gets shown / collected / promoted / canonised.**
    Documented disparities by gender, race, class, sexuality,
    geography in the art form's history and present.
  - **Market dynamics.** Auction prices, gallery
    representations, recording contracts, distribution deals
    — these shape careers and reputations in ways that are
    legitimate context for criticism.
  - **Institutional politics.** Museum boards, festival
    programmers, prize panels, critical-reception ecologies
    — the gatekeepers of the field.
  - **Labour and credit.** Studio assistants, session
    musicians, uncredited collaborators, indigenous
    informants whose work shapes "the artist's" output
    without acknowledgement.
- The acknowledgement of market and power need not be
  reductive; great work emerges within and despite these
  structures, and noticing them does not deny the work's
  achievement.

### MANDATORY. Critical Voice Without Gatekeeping

- Criticism's job is judgement; pretending to neutrality is
  a different failure. The critic's analytical and aesthetic
  position is held with confidence.
- But criticism that positions itself as the gateway to the
  work — without which the reader cannot understand or
  appreciate — fails the reader. Access criticism (helping
  readers see / hear / experience what they had not noticed)
  is what the genre at its best does; gatekeeping criticism
  (positioning the critic between the reader and the work)
  is what the genre at its worst does.
- Specific gatekeeping patterns to avoid:
  - Vocabulary deployed to exclude rather than to specify
    (jargon that doesn't earn its place).
  - Reference-density designed to demonstrate the critic's
    learning rather than to illuminate the work.
  - "Real X" framings that position the critic as arbiter of
    authentic / serious / important work.
  - Foreclosing dismissals ("of course this is trash" /
    "anyone who likes this doesn't understand X") that don't
    do the work of engagement.
- Generosity in critical voice: the reader is invited into
  the work, given tools to engage with it, treated as a peer.

### Additional Guardrails

- **Living-vs-deceased subject ethics.** Living artists carry
  defamation, fairness, and (where relevant) interview-bargain
  considerations like biography. Deceased artists carry
  estate-cooperation, primary-source-citation, and historical-
  context standards.
- **Performance and ephemeral-form documentation.** For
  theatre / dance / performance art / live music — works
  that exist primarily in the moment — the book's source
  material is documentation (recordings, photographs,
  reviews, interviews, scripts, choreographic notation).
  Date the production discussed; acknowledge what is
  recoverable from the documentation and what is not;
  attend to the gap between performance-as-experienced and
  performance-as-documented.
- **Translation issues.** For lyrics, librettos, scripts, and
  primary sources in languages other than the book's,
  translation source named; significant interpretive
  variations across translations acknowledged where they
  shape the reading.
- **Personal taste flagged where it shapes the analysis.**
  All criticism has a perceiving subject; honest criticism
  acknowledges where the analytical position is shaped by
  the critic's particular perceptual / aesthetic / cultural
  position rather than presenting it as universal judgement.
- **Currency disclosure where it matters.** Living-artist
  monographs, critical surveys of currently-active forms,
  reception-history claims — date them; acknowledge that
  critical reception evolves and the book is a snapshot.
- **Distinguish review from extended criticism.** A 1,500-
  word review of an exhibition or album does work different
  from a 30,000-word critical essay; the book's chapters
  are clear about which mode they are in.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Sophisticated and considered — often
  drawn from the art form's own visual culture (gallery white
  for visual art; saturated single colour from the album cover
  for music; deep monochrome for film criticism; theatre's
  warmer greys-and-reds; architecture's restrained neutrals).
  Avoid commercial-publisher palettes that signal lifestyle
  or self-help; the cover should signal that the book lives
  in the same visual world as its subject.
- **Typography:** Elegant serif (Garamond, Bembo, Caslon,
  Sabon) for art-historical and music-criticism positioning
  — typography signals continuity with the gallery-catalogue,
  liner-note, programme-note traditions. Cleaner sans-serif
  (Helvetica, Univers, Akzidenz-Grotesk) for contemporary art
  and design criticism where the typography signals modernist-
  design culture. Display fonts and hand-lettering for
  music-criticism with strong personality (the Marcus / Sheffield
  / Sanneh tradition) and humour-adjacent cultural criticism.
- **Imagery:** Three dominant traditions:
  1. **Detail from the subject work** — a fragment of a painting,
     a frame from a film, an album-cover detail, a building's
     facade detail, a photograph of a performance. Calibrated
     to the book's central subject; permissions cleared. The
     most common form for single-artist / single-work / single-
     movement books.
  2. **Pure typography or design-led** — title and author name,
     no image (or with a single graphic element). Common for
     cross-form criticism, cultural-criticism collections, and
     books where rights clearance for image use is impractical.
     Often the strongest choice for book-as-argument over
     book-as-illustrated.
  3. **Subject portrait** — the artist / musician / filmmaker
     / performer themselves, usually photographed with care
     (often archival image, often in a working moment rather
     than a posed publicity shot). Common for creative
     biography.
- **Mood:** Considered intelligence with aesthetic awareness.
  The cover should signal "this book is in conversation with
  the art form's own visual culture" — not "academic textbook"
  (gatekeeping register), not "popular guide to" (commercial
  populism register). The book's design literacy is itself a
  signal to category readers.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Visual Art History & Criticism | Detail from a subject work (fragment of painting / sculpture / photograph) OR pure typography; sophisticated palette; serif typography signals art-historical lineage; subtitle clarifies the critical / historical scope |
| Music History & Criticism | Album-cover-aesthetic-influenced design; often saturated single colour or photographic image of performance / instrument / artist; typography ranges from elegant serif (classical / jazz history) to bolder display (rock / pop / hip-hop criticism); subtitle clarifies the genre / era / artist focus |
| Film & Cinema Criticism | Frame-from-film or single resonant cinematic still; restrained palette; serif or clean sans-serif typography; subtitle establishes the director / era / argument |
| Theatre / Performance / Dance | Performance photography or production still; warmer palette; serif typography signals theatre-publishing tradition; subtitle clarifies the form and angle ("a critical history of...", "essays on...") |
| Architecture & Design | Building / object photography (often architectural detail rather than full-building shot); clean sans-serif typography signals design-publishing culture; restrained palette; subtitle clarifies the building / movement / designer focus |
| Cross-Form Cultural Criticism | Pure typography or design-led; sophisticated palette; serif or contemporary sans-serif depending on positioning; subtitle clarifies the critical scope |
| Creative Biography | Subject portrait (often archival / working-image rather than posed) OR symbolic object from the subject's practice; serif typography with weight; subtitle clarifies the angle ("a life", "a biography", "the years of...") |

### Typography Rules

- **Title:** 25–50% of cover area depending on whether image-led
  (smaller) or typography-led (larger). Art-culture titles
  range from evocative ("The Lonely City", "The Shock of the
  New") to descriptive ("The Rest Is Noise", "Seven Days in
  the Art World") to subject-name-as-title ("Ninth Street
  Women"). All work; the title must read at thumbnail.
- **Subtitle:** Often essential — does the descriptive work
  the title leaves abstract. "Adventures in the Art of Being
  Alone" (Laing's *Lonely City* subtitle). "Listening to the
  Twentieth Century" (Ross's *Rest Is Noise* subtitle).
  Specific subtitle outsells vague subtitle in this category
  because reader self-selection by form / scope / angle is the
  buying decision.
- **Author name:** Larger for established critic / author-brands
  (Berger, Hughes, Kael, Marcus, Ross, Als); smaller for
  unestablished authors with credentials in subtitle or
  back-cover blurb ("by the [Publication] critic", "by an
  art historian at..."). Author qualification cues
  (curatorial / critical / scholarly position) help in this
  category because reader trust depends on the author's
  authority within the field.
- **Series mark and edition:** Art-publishing imprints
  (Phaidon, Prestel, Thames & Hudson, MoMA Press, Aperture,
  University of California Press for music history) and
  film-criticism imprints (Knopf, FSG, Library of America for
  Kael / Ebert) signal positioning. Substantial illustrated
  books often note edition and printing history; major
  art-history references often update across editions.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Visual Art History & Criticism | Kindle Store > Kindle eBooks > Arts & Photography > History & Criticism (with Arts & Photography > Individual Artists / Painting / Sculpture / Photography per the book's focus) |
| Music History & Criticism | Kindle Store > Kindle eBooks > Arts & Photography > Music > History & Criticism (with Music > Genres > [Specific Genre] for genre-focused books) |
| Film & Cinema Criticism | Kindle Store > Kindle eBooks > Humor & Entertainment > Movies > History & Criticism (and Performing Arts > Film & Television > History & Criticism) |
| Theatre / Performance / Dance | Kindle Store > Kindle eBooks > Humor & Entertainment > Performing Arts > Theatre (or > Dance for dance-focused) |
| Architecture & Design | Kindle Store > Kindle eBooks > Arts & Photography > Architecture (with > Decorative Arts & Design for design-focused titles) |
| Cross-Form Cultural Criticism | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Popular Culture (with Literature & Fiction > Essays & Correspondence > Essays as secondary) |
| Creative Biography (Artist / Musician / Filmmaker) | Kindle Store > Kindle eBooks > Biographies & Memoirs > Arts & Literature (with Arts & Photography > Individual Artists or Music > Biographies as secondary per the figure's discipline) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Specific artist / musician / filmmaker | Kindle Store > Kindle eBooks > Biographies & Memoirs > Arts & Literature > [Specific Artist where listed] |
| Specific art-form sub-discipline | Kindle Store > Kindle eBooks > Arts & Photography > [Painting / Sculpture / Photography / Drawing / Mixed Media] |
| Specific music genre | Kindle Store > Kindle eBooks > Arts & Photography > Music > Genres > [Classical / Jazz / Rock / Hip-Hop / Country / Folk / etc.] |
| Specific film / TV focus | Kindle Store > Kindle eBooks > Humor & Entertainment > Television > History & Criticism (or > Movies > Genre Films > [Specific Genre]) |
| Performing arts (broader) | Kindle Store > Kindle eBooks > Humor & Entertainment > Performing Arts > Theatre / Dance |
| Architecture / specific style | Kindle Store > Kindle eBooks > Arts & Photography > Architecture > [Buildings / Specific Movements / Urban & Land Use] |
| Cultural studies | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Popular Culture |
| Photography (illustrated criticism) | Kindle Store > Kindle eBooks > Arts & Photography > Photography & Video > History & Criticism |

### Keyword Recommendations

- The art form + critical / historical mode
  ("art criticism", "music criticism", "film criticism",
  "theatre criticism", "cultural criticism", "art history",
  "music history")
- The specific artist / movement / period / work
  ("abstract expressionism", "the Velvet Underground",
  "Stanley Kubrick", "Pina Bausch", "Le Corbusier", "Bauhaus",
  "the New Hollywood", "Fluxus", "punk rock", "bebop")
- The form's specific sub-discipline
  ("painting", "sculpture", "photography", "filmmaking",
  "choreography", "architecture", "graphic design",
  "performance art")
- The cultural / critical lens
  ("feminist art history", "decolonising the canon",
  "queer cinema", "Black music criticism", "indigenous
  performance", "post-colonial art", "the politics of...")
- Comparable critic / brand for discoverability
  (readers of John Berger, readers of Robert Hughes, readers
  of Pauline Kael, readers of Greil Marcus, readers of Alex
  Ross, readers of Hanif Abdurraqib, readers of Olivia Laing)
- Era / period markers where applicable
  ("the 1960s", "post-war", "twenty-first century", "early
  modern", "contemporary art")
- Avoid generic "art" / "music" / "culture" / "movies" in
  isolation — they drown in algorithmic noise; prefer
  compound phrases combining form + period + critical-lens
- Avoid framing-trap keywords ("primitive", "tribal",
  "exotic", "world music" used as catch-all) for art and
  music from cultures not the author's own — they signal
  outdated framings and damage credibility with the readers
  serious art-criticism needs to attract
