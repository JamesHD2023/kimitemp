---
name: voice-restoration-brief
description: "Per-chapter voice-drift restoration brief (Class B audit, engine-neutral). On user request, dispatches a subagent to analyse a drifted chapter against engine-data/voice-profile.md, classify every paragraph (anchor-narrative / expository / drifted-summary / ambiguous), and produce a structured rewrite brief the user studies before rewriting. v1 detection infrastructure (FP-pronoun based; Class B paragraph classifier deferred to v2.7.67) — paired with voice-metrics-audit.sh / voice-trend-audit.sh in v2.7.65. User-invoked via the validate-dispatcher 'restore' selector or directly via scripts/voice-restoration-brief.sh."
version: "2.7.66"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Voice Restoration Brief

A user-invoked Class B audit that produces a structured per-chapter
rewrite plan when voice has drifted. The brief is what the writer
reads BEFORE rewriting — it identifies which paragraphs are off,
quotes target-voice exemplars to study, and gives concrete
rewrite hints. The writer still rewrites by hand; the brief is the
diagnostic, not the prose.

## Why this audit exists

v2.7.65 shipped the eyes: voice-metrics-audit + voice-trend-audit
catch drift, the voice-profile-preload gate makes the calibration
artifact a verifiable precondition. But knowing drift is real and
knowing what to do about it are different problems. A writer
faced with a "Vol 2 chapter 14: FP=0.000 against target 0.25"
verdict still has to figure out: which paragraphs are the actual
drift? Where does anchor-narrative belong here? What does the
correct voice sound like for THIS chapter's content?

The restoration brief answers those questions per-chapter, in a
structured format the writer can work against.

## When this audit runs

User-invoked. The brief is not part of the per-chapter automatic
cycle — it fires when the writer chooses a chapter to restore. The
trigger paths:

- `bash scripts/validate-dispatcher.sh "{project}" restore {N}`
  — dispatcher emits a single CLASS_B_AUDIT line for this audit,
  engine layer dispatches the subagent
- `bash scripts/voice-restoration-brief.sh "{project}" {N}` —
  same effect, useful when scripting batches
- `/restore <N>` slash command (where available) — wraps the
  dispatcher invocation

The voice-trend-audit may recommend invoking the brief in its
FAIL output, but the brief itself never runs automatically. Auto-
rewrite is explicitly NOT part of this release — Phase 5 Stage 14
Voice Restoration (the auto-rewrite tool) is deferred until the
brief workflow has been used in practice and the rewrite patterns
are well-understood.

## Class B dispatch

Same dispatch pattern as other Class B audits. The bash dispatcher
emits:

```
CLASS_B_AUDIT|voice-restoration-brief|VOICE|references/voice-restoration-brief.md|-
```

The engine layer reads the line, dispatches a subagent per the
brief below, applies the engine HARD GATE on return, writes the
verified brief to
`engine-data/reports/validate/voice-restoration-brief-ch{NN}-subagent.md`.

## Subagent task brief

> **Task: Voice Restoration Brief**
>
> **Background.** A long-form manuscript has measurably drifted
> from its declared author/narrator voice. The user is rewriting
> drifted chapters by hand and needs a structured per-chapter plan:
> which paragraphs are the drift, which are legitimate, what to add
> or remove, which exemplars to study. You are producing that plan.
> You are NOT rewriting prose. You are producing a diagnostic.
>
> **Inputs.**
> - `engine-data/voice-profile.md` — the calibration corpus:
>   fp_target, sentence_band_min/max, voice_calibration_exemplar
>   paths, voice_prose_description, optional voice_calibration_avoid
> - `engine-data/chapters/ch{NN}.md` — the chapter under review
> - `engine-data/reports/voice-metrics-ledger.md` — measurements
>   for this and surrounding chapters (so you can see the local
>   trend, not just the single-chapter snapshot)
> - Each path under `voice_calibration_exemplar:` in voice-profile.md
>   — read these so you can quote-cite target-voice anchors in the
>   brief
>
> **Procedure.**
> 1. Read the inputs in order: voice-profile.md first (to load the
>    target voice description + exemplars), then the chapter, then
>    the ledger row for this chapter (and the surrounding window
>    for trend context).
> 2. For each paragraph in the chapter, classify into one of four
>    categories:
>    - **ANCHOR-NARRATIVE** — paragraph reproduces the target
>      voice. First-person register active OR consistent close-POV
>      cadence consistent with voice-profile. No rewrite needed.
>    - **EXPOSITORY-OK** — paragraph is research / third-party /
>      reference content where the absence of first-person is
>      legitimate. (E.g. a memoir's biographical detour about a
>      historical event the author wasn't part of.) No rewrite
>      needed. Cite the structural reason.
>    - **DRIFTED-SUMMARY** — paragraph SHOULD have been
>      anchor-narrative but reads as abstract / third-person /
>      academic-distance. Rewrite required. This is the working
>      target of the brief.
>    - **AMBIGUOUS** — judgement call; would be anchor-narrative
>      in some readings of the chapter's purpose, expository in
>      others. Flag and explain the trade-off; do not prescribe.
> 3. For each DRIFTED-SUMMARY paragraph, produce a rewrite hint:
>    - What to add (specific first-person sensory anchor, scene
>      detail, author-as-participant beat)
>    - What to remove (academic hedge, third-person framing,
>      summary verb-form)
>    - Which exemplar paragraph from voice-profile.md exemplars to
>      study — cite path:line of the anchor exemplar
> 4. Quote 3-5 voice-checkpoint passages from voice-profile.md
>    exemplars (short — 1-3 sentences each — but VERBATIM, with
>    path:line citations). These are the "what the voice sounds
>    like at its best" reference the writer reads before rewriting.
> 5. Identify any RISK CALLOUTS — paragraphs where blind rewriting
>    would hurt the chapter: structural transitions, places where
>    expository distance is genuinely needed, places where the
>    drift may be intentional rather than accidental.
> 6. Produce the structured return.
>
> **Return contract (mandatory).**
>
> ```
> ## Chapter under review
> - Path: engine-data/chapters/ch{NN}.md
> - Ledger row (most recent for this chapter):
>   FP ratio {x.xxxx} | sent_median {N} | total_paras {N}
> - Voice-profile target: FP {x.xx}, sentence band {min}-{max}
> - Trend context: {brief description of the surrounding 5-chapter
>   window from the ledger — e.g. "ch12 0.20 → ch13 0.10 → ch14
>   0.00 → ch15 0.00 → THIS ch16 0.05; downward slope sustained"}
>
> ## Voice checkpoints (verbatim from exemplars)
> 1. "{quoted passage}"
>    — {exemplar path}:line {N}
> 2. "{quoted passage}"
>    — {exemplar path}:line {N}
> [3-5 total]
>
> ## Per-paragraph classification
> | Para # | Lines | Class | Rationale (one clause) |
> |---|---|---|---|
> [one row per paragraph; classes in the four-category set above]
>
> ## Rewrite hints (DRIFTED-SUMMARY paragraphs only)
> ### Paragraph {n} (lines {a}-{b})
> - Current first sentence: "{short quote}"
> - Add: {specific anchor element}
> - Remove: {specific drift element}
> - Study exemplar: {exemplar path}:line {N} (which demonstrates
>   the move this paragraph needs)
> [one section per DRIFTED-SUMMARY paragraph]
>
> ## Risk callouts
> - Para {n}: {specific risk — e.g. "transition paragraph; FP
>   addition risks breaking the chapter-bridge cadence"}
> [or "(none — every DRIFTED-SUMMARY paragraph is safe to rewrite)"]
>
> ## Verdict
> One of: RESTORE-VIABLE | PARTIAL-RESTORE | NO-DRIFT-DETECTED
> - RESTORE-VIABLE: chapter has clear DRIFTED-SUMMARY paragraphs +
>   structural room to restore voice; rewrite the flagged paragraphs
> - PARTIAL-RESTORE: chapter is structurally constrained (mostly
>   expository by design; FP addition would be forced); restore the
>   {N} flagged paragraphs but accept the chapter's voice profile
>   will remain below per-project target — document in
>   project-config.md as voice_calibration_avoid: ch{NN} so the
>   trend audit knows this chapter is structurally exempt
> - NO-DRIFT-DETECTED: measurement was a false positive; no rewrite
>   needed; consider voice_calibration_avoid only if the chapter's
>   structural design genuinely demands the lower FP ratio
>
> ## One-Line Summary
> "{verdict}: ch{NN} — {drifted-summary count} para(s) flagged for
>  rewrite, {ambiguous count} ambiguous, {risk count} risk(s)"
> ```
>
> **Discipline.**
> - Quote every exemplar VERBATIM with path:line citation. No
>   paraphrasing. The writer needs the exact target-voice text in
>   front of them, not your interpretation.
> - Classify every paragraph. No skipping. If genuinely uncertain,
>   use AMBIGUOUS with a clear rationale — that's a legitimate
>   output, "didn't classify" is not.
> - Per-paragraph line numbers cite the chapter file as written.
>   Use the chapter's actual line numbers, not paragraph-index
>   offsets.
> - Do NOT rewrite prose in the brief. Rewrite hints are
>   instructions for the user, not prose for them to paste in. If
>   you find yourself drafting full replacement paragraphs, stop —
>   that's Phase 5 Stage 14 territory, deferred to v2.7.67.
> - If the chapter is genuinely fine (NO-DRIFT-DETECTED), say so.
>   The brief is allowed to verdict against itself.

## Engine HARD GATE on return

Per `subagent-output-verification.md`. Specific checks:

1. **Shape check.** All seven sections present (`## Chapter under
   review`, `## Voice checkpoints`, `## Per-paragraph
   classification`, `## Rewrite hints`, `## Risk callouts`, `##
   Verdict`, `## One-Line Summary`).
2. **Verdict consistency.** Verdict is one of the three declared
   values. One-Line Summary verdict-prefix matches.
3. **Citation check.** Every voice-checkpoint quote MUST have a
   path:line citation. Every rewrite hint MUST have a "Study
   exemplar" citation. No floating quotes.
4. **Classification completeness.** Per-paragraph classification
   row count matches the chapter's actual paragraph count
   (calculated from the chapter file post-frontmatter, with
   tolerance ±1 for parse edge cases).
5. **No-prose-rewrite.** Rewrite hints contain instructions, not
   full prose paragraphs. If a "rewrite hint" section is longer
   than ~120 words OR contains 3+ consecutive sentences without
   a prescriptive instruction marker ("Add:", "Remove:", "Study:",
   "Consider:"), flag as suspicious — the subagent may be
   drafting prose contrary to discipline.

After verification, the engine emits:

```
AUDIT|voice-restoration-brief|VOICE|<verdict>|<one_line_summary>|<subagent_return_path>
```

## Brief output landing path

`engine-data/reports/validate/voice-restoration-brief-ch{NN}-subagent.md`

Mirror the existing Class B return file convention (same directory
as leitmotif-tracker-delta-ch{NN}-subagent.md, injury-accumulation-
delta-ch{NN}-subagent.md, etc.). The user opens the file in their
editor, reads it before rewriting, deletes it when the rewrite is
complete.

## Silent-Failure Audit

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (voice-profile.md) | "Read succeeded" | Skeleton file (no real exemplars) | voice-profile-preload-gate (v2.7.65) FAIL precondition before this audit ever runs |
| Read (chapter file) | "Read succeeded with N bytes" | Empty extraction post-frontmatter strip | voice-restoration-brief.sh preflight word-count check (FAIL on <100 words after strip — there's no chapter to restore) |
| Read (voice-metrics-ledger.md) | "Read succeeded" | No ledger row for this chapter | voice-restoration-brief.sh preflight FAIL if no ledger row exists for chN; user prompted to run voice-metrics-audit first |
| Read (exemplar files) | "Read succeeded" | Exemplar path resolves outside project root (traversal) or doesn't exist | voice-restoration-brief.sh preflight resolves each `voice_calibration_exemplar:` path against project root with realpath, FAIL on missing or out-of-tree |
| Subagent (brief production) | "Returned complete" | Brief is shape-valid but the verdict is fabricated, classifications wrong, or rewrite hints turned into prose drafts | Engine HARD GATE (this spec § "Engine HARD GATE on return"): shape check, verdict consistency, citation check (no floating quotes), classification completeness (count matches chapter), no-prose-rewrite heuristic |
| Write (brief to subagent path) | "Write succeeded" | Subdir flush failure | mkdir -p before write; bash-direct write protocol per File Operation Policy Class 1 (NEW files) |
