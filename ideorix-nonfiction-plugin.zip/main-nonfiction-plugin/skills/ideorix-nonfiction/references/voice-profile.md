---
name: voice-profile
description: "Canonical template + protocol for engine-data/voice-profile.md — the calibration artifact that anchors author-voice consistency across an NF manuscript. Read by voice-metrics-audit.sh, voice-trend-audit.sh, and the voice-profile-preload-gate. Without this file populated, the writer has no reference voice to reproduce and drift becomes invisible until a reader catches it."
version: "2.7.65"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Voice Profile — Non-Fiction

The voice-profile.md is the **calibration corpus** for author-voice
across the manuscript. The writer reproduces a voice; the audit
pipeline measures whether the reproduction held; the trend audit
fires when the measurements drift away from this profile. Without
the profile, all three pieces are guessing.

## Why this artifact exists

Across the v2.7.65 voice-metrics work the engine catalogued a
catastrophic drift shape: a 6-book NF memoir series where Vol 2
shipped with thirteen chapters at zero first-person, and the series
window-mean for that volume sat at FP=0.019 (target 0.25). No single
chapter triggered alarm — each was "explainable" as a research-heavy
or third-party-focused chapter — but the cumulative drift broke the
author-voice contract.

The fix needed three pieces:

1. **Per-chapter measurement** (voice-metrics-audit.sh) — records
   FP ratio + sentence-length stats to a ledger.
2. **Cross-chapter trend detection** (voice-trend-audit.sh) — reads
   the ledger, flags drift patterns the per-chapter view cannot see.
3. **The voice-profile.md artifact** — gives the writer a concrete
   reference voice to reproduce AND gives the audits a target to
   measure against. This is that piece.

The voice-profile-preload-gate.sh runs as part of pre-flight and
blocks chapter generation when the profile is missing or skeleton-
only. That is deliberate: a manuscript without a documented voice
profile is a manuscript where drift is undetectable.

## Required file structure

The profile lives at `engine-data/voice-profile.md`. Minimum viable
content (all five keys required):

```markdown
# Voice Profile

fp_target: <float, 0.0-1.0>
sentence_band_min: <int, minimum acceptable median sentence length>
sentence_band_max: <int, maximum acceptable median sentence length>

voice_calibration_exemplar: <relative path to exemplar chapter 1>
voice_calibration_exemplar: <relative path to exemplar chapter 2>
voice_calibration_exemplar: <relative path to exemplar chapter 3>

voice_prose_description: <2-4 sentences describing the register the
writer is reproducing — what is distinctive about this voice; what
the reader should feel; what mistake the writer must not make>
```

Recommended additional sections:

```markdown
## Voice-Avoid List

Chapters that exhibit drift and should NOT be used as exemplars.
Listed so the calibration corpus stays clean — the engine never
trains on a drifted chapter.

voice_calibration_avoid: <relative path to drifted chapter 1>
voice_calibration_avoid: <relative path to drifted chapter 2>

## Anchor Voice Markers

Specific phrases / cadences / metaphors that recur in the author's
voice. The writer reads these before generating each chapter so the
register stays consistent at the sentence level (not just at the
statistical level).

- <phrase or cadence 1>
- <phrase or cadence 2>
```

## Field guide

### `fp_target`

The target first-person paragraph ratio. A paragraph is "first-
person" if it contains any of `I, me, my, mine, myself, we, us,
our, ours, ourselves` as a standalone word.

Calibration ranges by NF category:

| Category                       | Typical fp_target |
|--------------------------------|-------------------|
| Memoir                         | 0.40–0.60         |
| Narrative non-fiction (1P)     | 0.25–0.40         |
| Self-help (author-as-guide)    | 0.15–0.25         |
| Business / how-to              | 0.10–0.20         |
| Biography (3P about subject)   | 0.00–0.05         |
| Academic / reference           | 0.00–0.05         |

If you don't know yet, run voice-metrics-audit.sh on three
non-drifted exemplar chapters and average the FP ratios. That
empirical baseline is your `fp_target`.

### `sentence_band_min` / `sentence_band_max`

The acceptable median sentence-length band. Default 13–19 for NF
prose; widens to 10–22 for memoir with conversational register;
tightens to 15–20 for business / reference. Set whatever matches
the exemplar chapters' actual measurements.

### `voice_calibration_exemplar`

The most important field. At least one path is required; three is
the recommended floor. Each path points to a chapter (or excerpt
file) where the author-voice was demonstrably correct — not drifted,
not over-corrected. The calibration corpus is what the writer reads
before each new chapter to re-anchor the voice register.

Picking exemplars:

- **Span the manuscript**: one early chapter, one mid-manuscript,
  one late. Voice can shift gradually across a long manuscript
  even when no individual chapter looks drifted; spanning the
  exemplar set keeps the anchor honest.
- **Avoid first chapters of new sections**: those tend to be
  scaffolding-heavy and not voice-representative.
- **Prefer chapters where the audit metrics matched target**: pull
  voice-metrics-ledger.md and pick rows where fp_ratio + sentence
  median both landed in-band.
- **If no chapter is exemplar-quality, write a 500-1500 word
  excerpt that IS, and use that as the exemplar**. The exemplar
  format is identical to a chapter file (frontmatter + prose).

### `voice_prose_description`

A short prose description naming what the voice IS and what it is
NOT. Two to four sentences. Examples:

> "Conversational memoir register with present-tense scene anchoring.
> The author is in the room, on the page, in the moment. Sentences
> run mid-length with short punctuation beats for emphasis. The
> writer must NOT collapse into third-person summary or abstract
> historical framing — when the temptation arises, return to the
> exemplar chapters before continuing."

> "First-person guide register. The author is an experienced
> practitioner addressing a reader-as-apprentice. Sentences are
> conversational but precise; jargon is unpacked the first time it
> appears. The writer must NOT slip into academic distance or
> third-person abstraction. The reader-addressing 'you' is allowed
> and expected; 'we' is allowed sparingly for shared-practitioner
> framing."

### `voice_calibration_avoid` (optional)

When a manuscript has known-drifted chapters (e.g., Vol 2 of the
user's series), list them explicitly so the calibration corpus
never accidentally pulls from them. The audit pipeline doesn't
auto-train, but human users picking chapters to study before
writing can mis-pick a drifted one without this list.

## How the audits use this file

- **voice-metrics-audit.sh** reads `fp_target`, `sentence_band_min`,
  `sentence_band_max` to set per-chapter classification thresholds.
  Falls back to defaults (0.20 / 13 / 19) if the profile is absent;
  the preload gate prevents that fallback path in real projects.
- **voice-trend-audit.sh** reads `fp_target` to compute the
  window-mean FAIL threshold (target × 0.50) and WARN threshold
  (target × 0.75). The slope thresholds are absolute.
- **voice-profile-preload-gate.sh** (Pre-Flight Check 6) verifies
  the profile exists + is populated before chapter N+1 generation.

## When to revise the profile

Bump the `version:` in frontmatter and re-export when:

- The exemplar chapters change (a new exemplar is identified, or
  a previously-trusted exemplar is found to drift).
- The `fp_target` is revised (typically because empirical
  measurements settled at a different value than the initial
  estimate — measure, don't guess).
- The prose description tightens (a previously-acceptable register
  is reclassified as drift).

Do NOT lower `fp_target` because chapters keep failing the audit.
That is the audit telling you the voice has drifted, not the
profile being too strict. Fix the chapters, keep the profile.

## Silent-Failure Audit

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (voice-profile.md) | "Read succeeded" | Skeleton file (empty headers, no fp_target) | voice-profile-preload-gate.sh structural check (FAIL on no fp_target / no exemplar / no prose-description) |
| Read (voice-metrics-ledger.md) | "Read succeeded" | Stale ledger (no recent chapters appended) | voice-trend-audit short-circuits to INFO until window-size rows exist; trend cannot detect drift on stale data |
| Write (voice-metrics-ledger.md append) | "Append succeeded" | Subdir flush failure on a new project | mkdir -p before append; standard append path; lazy header on first write so partial-write recovery is well-defined |
| LLM-Writer (chapter generation) | "Voice profile referenced" | Profile cited but voice not reproduced | voice-metrics-audit measures the produced chapter; voice-trend-audit catches sustained divergence; profile preload makes the reference verifiable not just claimed |
