---
name: travel-writing-category
description: "Category-specific instructions for travel writing non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Travel Writing. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | travel-writing |
| Display Name | Travel Writing |
| Parent Group | Travel & Nature |
| Typical Word Count | 60,000–100,000 (literary travel often 70,000–90,000; expedition / adventure narratives 80,000–110,000; guidebooks much longer at 150,000+ but with different word-density conventions; place-portrait books around 80,000) |
| Default Structure | Journey or place provides the spine (geographic progression / itinerary, OR a single place in depth); inner journey mirrors outer journey; each chapter typically anchored to a specific place, leg, or thematic encounter; arrival-now-then-context-later rhythm; place rendered with sensory and human specificity, not generic description |
| Citation Style | Endnotes for historical / cultural / political claims; in-text attribution for named local sources, scholars, prior travel writers cited; named-translator credit where local-language sources used; primary-historical sources distinguished from secondary scholarship; date-of-visit declared early so practical and political claims can be calibrated |
| Audience Baseline | Reader curious about a place, a journey, or about travel itself; varies from armchair-reader (literary travel, place-portrait) to active-traveller (guidebook, practical) to scholarly-engaged (historical travel, literary place-portrait); audience named so reader self-selects |
| Comparable Titles | Bruce Chatwin (*In Patagonia*, *The Songlines*), Paul Theroux (*The Great Railway Bazaar*, *Dark Star Safari*), Jan Morris (*Trieste and the Meaning of Nowhere*, *Venice*), Pico Iyer (*The Lady and the Monk*, *Falling Off the Map*), Peter Hessler (*River Town*, *Country Driving*), William Dalrymple (*City of Djinns*, *From the Holy Mountain*), Patrick Leigh Fermor (*A Time of Gifts*), Robert Macfarlane (*The Old Ways*, *Underland*), Suketu Mehta (*Maximum City*), Kapka Kassabova (*Border*, *To the Lake*), Colin Thubron (*Shadow of the Silk Road*), Bill Bryson (*A Walk in the Woods*, *Notes from a Small Island*), Dervla Murphy (*Full Tilt*), Geoff Dyer (*Yoga for People Who Can't Be Bothered to Do It*), Cheryl Strayed (*Wild*) |

## Subcategory Options

When the user selects Travel Writing, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| literary-immersive | Literary / Immersive Travel | Place rendered with the depth a novelist gives a protagonist; observation, atmosphere, prose-as-craft central; the journey is real but the prose is the draw | Place-anchored chapters; sensory-immersion-then-reflection rhythm; long arc serves a thematic or human-encounter throughline; literary-prose register throughout |
| adventure-expedition | Adventure / Expedition | Physical challenge as narrative spine — long-distance walks, climbs, expeditions, ocean crossings, off-grid endurance journeys | Expedition phases as chapter spine; physical hardship and risk as recurring beats; landscape rendered as adversary or partner; transformation through the physical journey as the arc |
| journey-itinerary-narrative | Journey / Itinerary Narrative | A specific itinerary or route as the book's structural backbone — railway routes, road trips, river journeys, pilgrimages, named long-distance trails | Geographic progression chapter spine; arrivals and departures as natural chapter punctuation; companion travellers, locals encountered en route as recurring cast; the route itself as protagonist |
| cultural-immersion-expat | Cultural Immersion / Expat | Living within a culture not one's own — for months or years; the depth that comes from staying rather than passing through | Time-based or thematic chapters reflecting the rhythm of living-there; named locals appear repeatedly across chapters; language acquisition often as throughline; the gap between visitor and resident as recurring tension |
| historical-travel | Historical Travel | Journey through a place's past as much as its present — following historical figures, retracing ancient routes, walking battlefields, exploring archaeological depth | Layered-time structure (ancient past / recent past / present); primary historical sources cited inline; physical place as evidence-of-history; the author's contemporary observations in dialogue with the historical record |
| travel-essays-reflection | Travel Essays & Reflection | Travel as lens for ideas — essays where place serves a question rather than the question serving the place; armchair-reader-friendly | Essay-collection or thematic-essay-cycle structure; place as occasion for reflection on home, identity, displacement, time; shorter chapters (essay-length); literary essay tradition rather than journey narrative |
| guidebook-utility | Guidebook / Practical Travel | Practical guidance for travellers planning their own trip — the Lonely Planet / Rough Guides / Fodor's tradition (overlaps with how-to-guide category) | Place-by-place organisation with consistent practical-information format (transport / lodging / food / sights / safety); periodic revision cycle (typically 2–4 years); date stamping mandatory throughout |

**Default:** If the user does not specify, prompt for the book's mode
(literary place-portrait / journey-narrative / immersive-residence /
historical / essays / guidebook) and select accordingly; fallback to
`literary-immersive` for unclear cases where the prose is the draw.

## Structural Architect Instructions
```
STRUCTURE
- Journey/itinerary provides the spine (geographic progression)
- Inner journey mirrors outer journey (what the traveller learns)
- Place-as-character: landscapes, cities, cultures rendered with sensory vividness
- Each chapter: a specific place or leg of the journey

CATEGORY ARCHITECTURE
- The PLACE must be vivid enough that the reader experiences it
- The author's positionality (tourist, outsider, privileged traveller) acknowledged
- Local perspectives included. not just the outsider's gaze
- Historical and political context engaged with, not erased for aesthetics

FORBIDDEN
- Places reduced to stereotypes or exotica
- Indigenous cultures treated as spectacle
- "Discovery" language for places that already have inhabitants
- Travel writing that is actually autobiography set in interesting locations
```

## Content Writer Craft Rules
```
VOICE & TONE
- Observant, curious, self-aware. the author sees and reflects
- Sensory language essential: every chapter engages 3+ senses
- Self-deprecating honesty about the traveller's limitations
- Place rendered through specific detail, not generic description
```

### Prose Rhythm Mapping

Chapter 1: you are THERE. The reader does not ease into the place. they arrive.
The first sentence puts them in the heat, the noise, the light, the smell. No
preamble. No airport. No journey-to-the-journey. The place itself, rendered with
the force of physical presence.

Immersive sensory prose. Medium-long flowing sentences (16-28 words) for
place immersion; shorter reflective sentences (12-16 words) for the inner
journey. what the place means, not just what it looks like. Travel writing
earns its longer sentences because place requires accumulation. the colour
of the wall, the sound from the courtyard, the smell of rain on hot stone.
These details layer. They need room. But the inner voice needs brevity . 
"I had been here before. I had not been this person." Alternate between
outer immersion and inner reflection to create the dual rhythm
and build, carrying the reader deeper into the scene.

The specific over the general. Always. Not "beautiful sunset" but "the sky
turned the colour of a bruised peach, and the fishing boats became silhouettes."
Not "bustling market" but "a woman in a green headscarf stacking pyramids of
turmeric beside a boy selling mobile phone cases." The specific is what makes
place real. The general is what makes it forgettable.

Place is character. It has moods, contradictions, a history that shows in its
surfaces. The writing must render place with the same complexity and attention
that a novelist gives to a human protagonist. Flat description is failure.

Tension minimum: 4. The tension in travel writing is the encounter between
the self and the unfamiliar. Chapter 1 must establish that encounter. the
moment of arrival, of disorientation, of the senses overwhelmed by newness.

Pacing guideline: open in the middle of the scene (long flowing sentences,
20-28 words). Let three paragraphs pass before any reflection or context.
The reader earns the explanation after they have experienced the place. Then
a shorter reflective sentence lands. Then back into the sensory flow.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Place rendered with sensory specificity | At least 3 distinct sensory details per scene that could only describe THIS place (not generic "bustling market", but "a woman in a green headscarf stacking pyramids of turmeric beside a boy selling mobile phone cases"); the specific over the general always |
| 2 | Place rendered with human specificity | Real people in the chapter — named where appropriate, sketched with enough detail to be actual humans rather than props; locals appear with their own agency, interior life, and view of the place; the author is among them rather than above them |
| 3 | Author's positionality acknowledged | The traveller's relationship to the place is named: tourist, expat, returnee, scholar, journalist, descendant; passport / visa / language / class privilege made visible where it shapes the encounter; the prose does not pretend the author is a neutral observer |
| 4 | "Discovery" and "exotic" framings avoided | Inhabited places are not described as "discovered" or "untouched"; cultures and peoples are not framed as "exotic", "mysterious", "ancient" in ways that flatten their lived contemporary reality; the prose meets the place on its own terms |
| 5 | Local voices central | Local perspectives on the place — quoted, named, contextualised — appear alongside the author's observations rather than only as colour or backdrop; "nothing about us without us" applies to communities the book writes about |
| 6 | Historical and political context honest | Where the place's history or current politics shape what the traveller is seeing (colonial legacies, recent conflict, current political tension, contested borders, displaced populations), context is engaged with rather than aestheticised away |
| 7 | Inner-journey and outer-journey balance | Memoir conventions where the author IS the subject (transformation, vulnerability, reflection); reportage conventions where the place / people are the subject (accuracy, attribution, fairness); the book's mix is deliberate and the modes are not silently conflated |
| 8 | Practical information accurate and dated | Where the chapter includes practical detail (visa, currency, transport, lodging, safety, language), the information is current at time of research, dated in the prose ("as of [year]"), and the reader is directed to authoritative sources for ongoing currency |
| 9 | Cultural / linguistic accuracy | Place names, personal names, religious / cultural terms in local languages spelled / transliterated correctly per convention; translations attributed; pronunciation guides where useful; insider terminology defined |
| 10 | Environmental / ethical awareness | Where the chapter recommends or describes travel patterns, environmental costs (carbon, overtourism on fragile sites) and ethical considerations (indigenous-land sensitivity, sex tourism, exploitation tourism, photographing people without consent) acknowledged where they materially affect the reader's choices |

## Source Requirements

### Mandatory Source Types

- **Author's direct travel experience.** The author has been to the
  places they write about, for the duration the book implies.
  Travel writing's authority depends on this — books that
  reconstruct journeys the author did not make, or that compress
  brief visits into the appearance of long immersion, fail the
  category's contract with the reader. Where the author is
  writing about a place visited briefly or via second-hand
  research, this is disclosed.
- **Local voices and perspectives.** People who live in the
  places the book describes are inputs alongside the author's
  observations: named conversations, attributed quotes,
  acknowledgements of locals who guided / hosted / shared their
  knowledge. For sustained-residence books this is the bulk of
  the source material; for journey narratives it is at minimum
  a substantial proportion.
- **Historical and cultural scholarship.** Where the book engages
  with a place's history, archaeology, religious / cultural
  traditions, or political context, claims trace to recognised
  scholarship — historians, anthropologists, scholars from the
  region, archaeological reports, peer-reviewed work in area
  studies. Scholars from the region itself are prioritised over
  Western interpreters of the region.
- **Prior travel writers and primary documents.** Where the book
  is in conversation with a tradition of travel writing about the
  same place (the Silk Road has Marco Polo, Ibn Battuta, Sven
  Hedin, Colin Thubron; Patagonia has Darwin, Chatwin, Theroux),
  prior writers are engaged with rather than ignored. Where the
  book retraces a historical figure's journey, primary
  documentation (letters, journals, period reporting) is used,
  not modern paraphrase.
- **Practical-information sources for guidebook content.** For
  practical detail (transport, currency, visa, accommodation,
  safety, opening hours), authoritative sources current at time
  of research: government travel advisories (FCDO, US State
  Department, equivalents), official tourism boards, transport
  operators' published information, locally produced reference
  works, recent first-person accounts from named travellers.
- **Voices from communities written about.** For travel writing
  that engages substantively with named communities — indigenous
  peoples, religious communities, ethnic minorities — voices from
  inside those communities are mandatory inputs alongside outsider
  observation. Without those voices the work risks being
  travel writing ABOUT a community rather than travel writing
  WITH a community.

### Source Freshness

- **Practical information ages fastest.** Visa rules, currency,
  transport routes, lodging, opening hours, restaurant
  recommendations, safety conditions can change month to month.
  Practical-information chapters carry "current as of [year /
  month]" stamps; readers are directed to current authoritative
  sources for ongoing currency; revised editions warranted on
  2–4 year cycles for guidebook content.
- **Political and security situations evolve fast.** Books about
  conflict zones, post-conflict regions, places undergoing
  political transition need explicit dating; the picture in 2018
  may not match 2024. Where the book's central arc depends on a
  political moment, the moment is named precisely.
- **Climate and environmental conditions shift.** Glaciers retreat,
  reefs bleach, wildfire seasons extend, drought and flood
  patterns change; books about natural environments visited 10+
  years ago may describe a landscape that no longer exists. The
  book engages with this honestly rather than presenting fixed
  landscapes as enduring.
- **Cultural representation conventions evolve.** Travel writing
  framings that read as enlightened in earlier decades (the
  exoticist gaze, the "discovery" framing, the noble-traveller
  mode) read poorly now; current standards expect more
  positionality awareness, more local-voice centrality, less
  centring of the traveller's interiority over the place. Books
  re-issued from earlier decades warrant updated framing where
  appropriate.
- **Foundational works hold up better.** Place-portrait books
  (Morris on Trieste / Venice; Mehta on Mumbai), historical-
  travel works (Dalrymple on the Eastern Christian Mediterranean),
  and literary essays grounded in observation rather than
  practical detail age more gracefully than guidebook-utility
  content.

### Attribution Standards

- **Date the journey explicitly.** "I travelled the route in
  [year]" / "I lived in [city] from [years]" — readers calibrate
  political, economic, and cultural claims against the date of
  research. Compressed-time presentations of multiple visits
  disclosed as such.
- **Named sources where consented.** Locals who shared their
  knowledge, hosted, guided, taught are named where they have
  consented to publication; where anonymity is requested or where
  publication might endanger them (in repressive jurisdictions,
  in close-knit communities), pseudonyms are used and the choice
  noted.
- **Translation source named.** For local-language sources —
  conversations, written texts, signs, songs — the translator
  named (the author themselves; a named local interpreter; a
  published translator); transliteration convention chosen and
  applied consistently.
- **Distinguish observed / told / read.** "I watched the
  ceremony..." (direct observation). "Locals told me..." (witness
  testimony, source attributed where possible). "Historians of
  the region note..." (scholarly source). Each register signals
  the evidence's nature.
- **Composite scenes and time compression disclosed.** Where the
  author has compressed multiple visits into a single rendered
  scene, or composited several conversations into one rendered
  exchange, this is disclosed in author's note or in-text where
  consequential.
- **What is NOT acceptable.** Inventing places visited or people
  met. Presenting research-derived material as personal observation.
  Using stock-exotic descriptions where specific observation is
  expected. Anonymous "locals" repeatedly cited without any
  identification when identification is feasible. Claiming
  lengthy residence on the basis of brief visits.

## Category-Specific Guardrails

### MANDATORY. Place-Representation Honesty (no exotica, no discovery)

- The places and peoples in the book are not exotic, mysterious,
  ancient, untouched, or undiscovered — they are contemporary
  places with contemporary inhabitants who have their own
  perspectives on where they live. The framing-traps to avoid:
  - "Exotic" / "exotically" / "exotic flavours / sights / customs"
    — frames non-Western places as objects of Western consumption.
  - "Untouched" / "unspoiled" / "primitive" — erases the
    inhabitants and the place's own modernity.
  - "Mysterious" / "inscrutable" / "secret" — positions the
    place as a puzzle for the outside reader rather than as a
    place its inhabitants understand quite well.
  - "Discovered" / "found" — the place was already there; the
    author found it, not the place.
  - "Authentic" — claimed by an outsider, almost always wrong;
    the question of which version of a place is "authentic" is
    contested by its inhabitants and not the visitor's to settle.
  - "The real X" — same trap as "authentic"; positions the
    visitor as arbiter of authenticity.
- Where the book's marketing or earlier travel-writing tradition
  uses these framings, the book's prose contests them rather than
  reproduces them.
- Specificity is the antidote to exoticism: a specific Tuesday
  morning, a specific named woman, a specific named neighbourhood
  cannot be exotic in the way that "the East" or "the desert" or
  "tribal Africa" can.

### MANDATORY. Author Positionality Disclosure

- The author's relationship to the place is named and visible in
  the prose: tourist, business traveller, expat resident,
  returnee / diaspora-descendant, scholarly visitor, journalist,
  invited guest, descendent of the colonial power, descendant of
  the colonised. Each positionality shapes what is observable,
  what is closed to the author, what biases the author brings.
- Privilege made visible where it shapes the encounter: passport
  privilege (visa-free travel, freedom to leave), language
  privilege (English-or-major-European-language reach), economic
  privilege (the cost of a week in the place vs. local annual
  income), gender privilege (different places open to different
  travellers), race privilege (visibility / safety / treatment
  differs by author's perceived race in different places).
- The book does not pretend the author is a neutral observer.
  Travel writing's strongest tradition has always been visible
  positionality (Theroux, Morris, Iyer, Hessler all wear their
  lens openly); books that pretend to a view from nowhere
  flatten both the place and the encounter.
- For descendants writing about ancestral places, or expats
  writing about long-resident places, the residency / return
  status is disclosed rather than hidden; the reader calibrates
  the authority differently.

### MANDATORY. Local Voice Centrality

- Local people who appear in the book are characters with agency,
  not props for the traveller's narrative. Specifically:
  - Named where they have consented to be named.
  - Quoted accurately (translated where needed, with translation
    source noted).
  - Granted interior life — what they are doing, why, how it fits
    their wider life — rather than rendered only through their
    interaction with the traveller.
  - Acknowledged in author's note for their contribution to the
    book; where they have shared knowledge, that contribution is
    credited.
- The book's centre of gravity for descriptions of the local
  reality is local voices, not outsider interpretation. Where
  the author offers interpretation, it is offered as
  interpretation rather than asserted as the place's truth.
- For communities that have been historically misrepresented or
  spoken-over in travel writing (indigenous peoples, ethnic
  minorities, religious minorities, communities with histories
  of colonisation), the book either includes voices from inside
  those communities or acknowledges the limits of writing about
  them from outside.

### MANDATORY. Historical and Political Context

- The places the book describes have histories — often histories
  shaped by colonialism, conflict, displacement, economic
  exploitation, climate impact. Aestheticising the place by
  erasing this context is a category-defining failure.
- Specific historical / political content the book engages with
  honestly where relevant:
  - Colonial history of the place visited and the author's
    position relative to it.
  - Recent or current conflict, post-conflict reconstruction,
    civil unrest.
  - Borders and contested territory: places where naming,
    affiliation, citizenship are politically loaded (the book
    chooses naming conventions deliberately, with awareness).
  - Indigenous land status: the book acknowledges where it is
    travelling on indigenous land, especially in settler-colonial
    contexts (Americas, Australia, NZ, etc.).
  - Religious / ethnic conflict where active.
  - Displacement: refugees, internally displaced persons,
    diaspora, gentrification, tourism-driven displacement.
- The book takes positions where positions are warranted; "above
  it all" framings are themselves a position, often the comfort
  of the privileged outsider.

### MANDATORY. Environmental and Tourism Ethics

- Travel writing recommends, implicitly or explicitly, that
  readers visit places. This carries ethical weight in an era
  of overtourism, climate crisis, and tourism-driven harm. The
  book engages this rather than ignores it:
  - **Carbon awareness.** Long-haul flight is the largest carbon
    contributor of most international travel; the book may
    acknowledge this honestly rather than pretending the journey
    is carbon-neutral. Where the book celebrates frequent flying
    or extreme-distance travel, the climate context is at least
    acknowledged.
  - **Overtourism awareness.** Specific places (Venice, Bali,
    Iceland sites, Machu Picchu, Mount Everest base camp, Amsterdam
    canals, Barcelona's Gaudí sites, Bhutan's monasteries) are
    documented as suffering from tourism volumes; the book
    recommending visits to fragile sites does so with awareness,
    not as a discovery moment.
  - **Indigenous-land sensitivity.** Travel onto indigenous land,
    photography of ceremony, recommendation of sacred sites for
    visitors require explicit consideration of community consent
    and community benefit; the book does not treat indigenous
    cultural property as visitor amenities.
  - **Exploitation tourism.** Sex tourism, voluntourism harm,
    orphanage tourism, slum tourism, wildlife exploitation — the
    book does not normalise, recommend, or romanticise these.
  - **Photography ethics.** Photographing identifiable people
    without consent, especially children, especially in vulnerable
    circumstances, is documented as harmful; the book reflects
    this in both its own practice and any guidance given.
- Where the book's pleasure depends on patterns of travel that
  cause harm, the tension is acknowledged rather than evaded.

### MANDATORY. Practical-Information Accuracy and Currency

- Where the book offers practical guidance (visa, transport,
  currency, lodging, safety, language, health), the information
  is current at time of research; dated explicitly in the book;
  reader directed to authoritative sources (FCDO / State
  Department / equivalent travel advisories; embassy websites;
  current locally-produced sources) for ongoing currency.
- Safety / health information receives particular care: women
  travelling alone, LGBT+ travellers, travellers of colour,
  disabled travellers, travellers carrying medications all face
  jurisdiction-specific risks that the book either addresses
  honestly or directs the reader to authoritative current
  sources.
- Currency-disclosure for guidebook-utility content: revision
  cycle 2–4 years; readers buying older editions told they may
  be out of date.

### Additional Guardrails

- **Memoir-vs-journalism mode disclosed.** Travel writing sits
  between memoir and journalism. Where the book is primarily
  about the author's inner journey, memoir conventions apply
  (vulnerability, transformation, recognition-then-reflection,
  honesty about memory limits). Where the book is primarily
  about the place / people, reportage conventions apply (accuracy,
  named sources, fairness to subjects). Most travel books are
  both; the book is honest about which mode it is in at any given
  point, rather than smuggling memoir authority into reportage
  claims or vice versa.
- **The "I" earns its space.** First-person is inevitable in
  travel writing but should serve the place rather than displace
  it. A book where the traveller's mood, opinions, and life crowd
  out the place is autobiography set in interesting locations
  rather than travel writing.
- **Comp-tradition acknowledgement.** Where the book is in dialogue
  with a tradition of writing about the same place, prior writers
  are credited; the book situates itself as one voice in a
  conversation rather than as the discoverer of the conversation.
- **Language / linguistic care.** Place names, personal names,
  cultural / religious terms in local languages spelled correctly
  per local convention; transliteration consistent; insider
  vocabulary defined on first use; macarons, accents, diacritics
  preserved in print where possible.
- **Author's relationship to the place's language disclosed.**
  Reading vs speaking vs translating-with-help vs no local-
  language all yield different access; the reader benefits from
  knowing.
- **Self-deprecating honesty about traveller's limitations.** The
  best travel writing is self-aware about getting things wrong,
  about misunderstanding, about being the awkward outsider.
  Performing competence the author did not have erodes credibility.
- **Currency disclosure where it matters.** Guidebook content,
  political claims, environmental claims, security claims all
  warrant explicit dating; the reader's life or safety may depend
  on knowing whether the information is current.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Rich and evocative for literary travel and
  place-portrait titles (deep blues, ochre, dusk pink, warm
  earth tones, sun-bleached pastels); saturated single-region
  palettes for cultural-immersion titles (warm cuisine-and-
  textile colours of the place); cooler / starker palettes
  (grey, slate, white, navy) for adventure / expedition titles
  where the cover should signal seriousness; cleaner / more
  informational palettes (white + accent, or branded series
  colour) for guidebook-utility titles. Avoid the saturated
  travel-poster palette that signals tourist-brochure rather
  than considered prose.
- **Typography:** Elegant serif (Garamond, Caslon, Bembo) for
  literary travel and place-portrait — typography signals
  considered prose and continuity with travel-writing tradition.
  Slightly more characterful sans-serif (Calibre, Brandon
  Grotesque) for adventure / expedition where directness is
  the cue. Display fonts and hand-lettering for essay-collection
  and personality-led titles. Series-styled clean sans-serif for
  guidebook publishers (Lonely Planet, Rough Guides, DK Eyewitness,
  Bradt, Footprint each have recognisable visual identities).
- **Imagery:** Three dominant traditions:
  1. **Landscape / place photography** — the most common form;
     a defining image of the place (a coastline, a city skyline,
     a mountain, a doorway, a market scene). Calibrate to avoid
     the most-photographed-cliché shots that signal stock-image
     rather than personal observation.
  2. **Object / detail / map** — a single resonant object from
     the place (a teapot, a textile, a chair, a doorway), or a
     stylised map; strong for literary-travel titles where the
     cover should suggest depth rather than spectacle.
  3. **Pure typography or typographic-with-element** — for
     essay collections, criticism-adjacent travel writing, and
     established author-brand titles where the prose is the draw.
- **Mood:** Considered intimacy with a place. The cover should
  signal "this book takes me somewhere worth going, in prose
  worth reading" — not "tourist destination guide" (commercial
  pulp register), not "exotic adventure" (orientalist register).
  Restraint and specificity outsell ornament and stock-imagery.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Literary / Immersive Travel | Single defining-image landscape OR symbolic object photography; warm or atmospheric palette appropriate to place; serif typography signals literary positioning; subtitle ("a portrait of...") establishes mode |
| Adventure / Expedition | Stark palette and powerful single image (mountain, route, expedition group, solo figure dwarfed by landscape); typography substantial and direct; subtitle clarifies the journey's nature and stakes |
| Journey / Itinerary Narrative | Route-evocative imagery (railway, road, river, trail) OR map-styled cover; warm typography; subtitle names the route or means of travel ("a journey by train across...", "a thousand miles on foot...") |
| Cultural Immersion / Expat | Person-in-place photography or single-detail imagery from the culture; warmer palette appropriate to the place's design culture; subtitle establishes the years lived and the relationship ("a year in...", "a decade among...") |
| Historical Travel | Period-evoking imagery (architecture, archaeological detail, manuscript fragment) OR landscape with historical resonance; serif typography with weight; subtitle clarifies the historical lens ("in the footsteps of...", "tracing the...", "the search for...") |
| Travel Essays & Reflection | Often pure typography or restrained symbolic imagery; closer to literary-essay cover language than travel-photography; subtitle establishes the essay-collection or reflective frame |
| Guidebook / Practical Travel | Series-styled typography (publisher's recognised visual identity); often photo grid or single landmark image; clear edition / year on cover; spine standardised within publisher's series |

### Typography Rules

- **Title:** 30–50% of cover area for typography-led covers; 25–35%
  for landscape-image-led covers. Travel titles work as place
  names ("Trieste", "Patagonia", "Venice"), as evocative phrases
  ("The Songlines", "Border", "City of Djinns"), or as
  description ("A Walk in the Woods", "The Great Railway
  Bazaar"). All three work; the title must read at thumbnail.
- **Subtitle:** Often essential — does the descriptive work the
  title leaves abstract. "And the Meaning of Nowhere" (Morris on
  Trieste). "A Journey to the Edge of Russia and the Last
  Place..." Specific subtitle outsells vague subtitle in this
  category, particularly for places less internationally
  recognised by name.
- **Author name:** Larger for established travel-writer brands
  (Theroux, Iyer, Bryson, Macfarlane, Dalrymple); smaller for
  unestablished authors with credentials in subtitle ("by a
  former [Region] correspondent", "by a writer who has lived in
  [Place] for twenty years"). Author qualification cues — long
  residence, language fluency, prior recognition for the place
  — help in this category.
- **Series mark and edition:** Guidebook publishers' series
  identity prominent; literary travel imprint (Eland, NYRB
  Classics, Penguin Travel Library, Granta) where applicable —
  these signal positioning to category readers; new editions /
  "Updated for [year]" essential for guidebook content.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Literary / Immersive Travel | Kindle Store > Kindle eBooks > Travel > Travel Writing (with Biographies & Memoirs > Travelers & Explorers as secondary for memoir-leaning titles) |
| Adventure / Expedition | Kindle Store > Kindle eBooks > Travel > Travel Writing > Adventure (and Sports & Outdoors > Mountaineering / Sailing / Other for activity-specific titles) |
| Journey / Itinerary Narrative | Kindle Store > Kindle eBooks > Travel > Travel Writing (with the specific transport / route mode often in Travel > Specialty Travel > [Backpacking / Train / Cycling / Cruises]) |
| Cultural Immersion / Expat | Kindle Store > Kindle eBooks > Travel > [Specific Region or Country] (with Biographies & Memoirs > Specific Groups > Travelers & Explorers as secondary) |
| Historical Travel | Kindle Store > Kindle eBooks > Travel > Travel Writing (with History > World > [Specific Region or Era] as secondary) |
| Travel Essays & Reflection | Kindle Store > Kindle eBooks > Travel > Essays & Travelogues (with Literature & Fiction > Essays & Correspondence as secondary for literary-essay positioning) |
| Guidebook / Practical Travel | Kindle Store > Kindle eBooks > Travel > [Specific Region / Country / City] (with Specialty Travel > [Backpacking / Family / Luxury / Budget] as secondary) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Specific region | Kindle Store > Kindle eBooks > Travel > [Africa / Asia / Australia & South Pacific / Caribbean / Central America / Europe / Latin America / Middle East / North America / Polar / South America] |
| Specific country / city | Kindle Store > Kindle eBooks > Travel > [Continent] > [Country / City] |
| Memoir-led travel | Kindle Store > Kindle eBooks > Biographies & Memoirs > Travelers & Explorers |
| Adventure / outdoor crossover | Kindle Store > Kindle eBooks > Sports & Outdoors > [Mountaineering / Hiking / Sailing / Cycling / Kayaking] |
| Historical context | Kindle Store > Kindle eBooks > History > World > [Specific Region or Era] |
| Food / culinary travel | Kindle Store > Kindle eBooks > Cookbooks, Food & Wine > Regional & International (cross-listed for food-led travel writing) |
| Religious / spiritual travel | Kindle Store > Kindle eBooks > Religion & Spirituality > [Tradition] (for pilgrimage and spiritual-journey writing) |
| Photography (illustrated travel) | Kindle Store > Kindle eBooks > Arts & Photography > Photography & Video > Subjects & Themes > Travel |

### Keyword Recommendations

- The specific place, named precisely
  ("travel writing Mongolia", "Patagonia journey", "memoir
  Tokyo", "Kyoto residence", "Silk Road", "Camino de Santiago",
  "Trans-Siberian railway")
- The mode of journey
  ("solo travel", "long walk", "year living abroad",
  "expedition memoir", "travel essays", "guidebook")
- The region / continent
  ("Africa travel", "Latin American journey", "Central Asia",
  "Pacific Islands", "Eastern Europe travel")
- The traveller's identity / lens where relevant
  ("woman traveller", "solo female travel", "queer travel
  writing", "diaspora return", "expat memoir", "immigrant
  perspective")
- The activity / mode where relevant
  ("by train", "on foot", "cycling", "sailing", "by motorbike",
  "long-distance walking", "river journey")
- Comparable author / brand for discoverability
  (readers of Bruce Chatwin, readers of Paul Theroux, readers
  of Pico Iyer, readers of Bill Bryson, readers of Robert
  Macfarlane)
- Period of travel where it shapes the book
  ("travel in the 1970s", "post-Soviet", "post-pandemic",
  "before tourism")
- Avoid generic single-word terms ("travel", "journey",
  "adventure") in isolation — they drown in algorithmic noise;
  prefer compound phrases combining place + mode + traveller-lens
- Avoid framing-trap keywords ("exotic", "untouched", "hidden",
  "secret", "real", "authentic", "discover") for cultures and
  places not the author's own — they signal exoticist positioning
  and damage credibility with the readers serious travel writing
  needs to attract
