---
name: beat-structures-nonfiction
description: "12 non-fiction structural frameworks for chapter-by-chapter organisation"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Non-Fiction Structural Frameworks

## Overview

Non-fiction books follow structural patterns just as fiction follows beat structures.
The user selects a framework during Phase 1 (Q9), and the Structural Architect uses
it to design each chapter's role in the overall book.

## Framework Selection

During setup, present these options based on the selected category:

| Framework | Best For | Categories |
|-----------|----------|-----------|
| Problem-Solution | Self-help, business, how-to | Self-help, Business, Health, How-To |
| Chronological Narrative | Memoir, biography, history | Memoir, Biography, History, True Crime |
| Argument-Driven | Commentary, philosophy, policy | Political, Philosophy, Academic |
| Thematic Exploration | Popular science, cultural criticism | Pop Science, Culture, Nature |
| Case Study Cascade | Business, education, psychology | Business, Education, Psychology |
| Investigation/Revelation | Journalism, true crime | Journalism, True Crime, Technology |
| Journey/Transformation | Memoir, travel, spiritual | Memoir, Travel, Religion, Creative NF |
| Instructional Progressive | How-to, reference, guides | How-To, Cooking, Education |
| Compare-Contrast | History, science, philosophy | History, Science, Philosophy |
| Question-Driven | Science, philosophy, social | Pop Science, Philosophy, Commentary |
| Biographical Arc | Biography, business memoir | Biography, Business |
| Seasonal/Cyclical | Nature, agriculture, memoir | Nature, Travel, Memoir |

## The 12 Frameworks

### 1. Problem-Solution

The reader has a problem. The book solves it.

```
Beat 1 (0-8%):    THE PROBLEM — Define the problem vividly. The reader must recognise it.
Beat 2 (8-15%):   WHY IT MATTERS — Stakes, consequences, scale of the problem.
Beat 3 (15-25%):  FAILED APPROACHES — What doesn't work and why. Build credibility.
Beat 4 (25-40%):  THE FRAMEWORK — Introduce the solution framework / core principle.
Beat 5 (40-60%):  IMPLEMENTATION — Detailed how-to. The bulk of the book.
Beat 6 (60-75%):  COMPLICATIONS — Edge cases, obstacles, what to do when it's hard.
Beat 7 (75-85%):  EVIDENCE — Proof it works. Case studies, data, testimonials.
Beat 8 (85-95%):  MASTERY — Advanced application, optimisation, next level.
Beat 9 (95-100%): TRANSFORMATION — The reader's new reality. Call to action.
```

### 2. Chronological Narrative

Events unfold in time order. The reader experiences the story as it happened.

```
Beat 1 (0-10%):   CONTEXT — The world before. Setting, era, key players.
Beat 2 (10-20%):  INCITING EVENT — The moment everything changed.
Beat 3 (20-35%):  RISING ACTION — Consequences unfold, stakes escalate.
Beat 4 (35-50%):  COMPLICATIONS — Setbacks, revelations, new information.
Beat 5 (50-60%):  MIDPOINT SHIFT — New understanding reframes earlier events.
Beat 6 (60-75%):  ESCALATION — Pressure mounts toward the crisis point.
Beat 7 (75-85%):  CLIMAX — The decisive moment, battle, discovery, or decision.
Beat 8 (85-95%):  AFTERMATH — Immediate consequences.
Beat 9 (95-100%): REFLECTION — What it meant. Legacy. The long view.
```

### 3. Argument-Driven

The book makes a case. Each chapter is a pillar of evidence.

```
Beat 1 (0-10%):   THESIS STATEMENT — The claim, clearly and boldly stated.
Beat 2 (10-20%):  CONTEXT — Why this argument matters now.
Beat 3 (20-35%):  EVIDENCE PILLAR 1 — First major supporting evidence.
Beat 4 (35-50%):  EVIDENCE PILLAR 2 — Second major supporting evidence.
Beat 5 (50-60%):  COUNTER-ARGUMENTS — Strongest objections, fairly presented.
Beat 6 (60-70%):  REBUTTAL — Systematic response to counter-arguments.
Beat 7 (70-80%):  EVIDENCE PILLAR 3 — Third evidence stream (often the most compelling).
Beat 8 (80-90%):  SYNTHESIS — How the evidence streams combine.
Beat 9 (90-100%): CONCLUSION — Thesis restated with full evidentiary weight. Implications.
```

### 4. Thematic Exploration

Each chapter explores a different facet of the central subject.

```
Beat 1 (0-10%):   INTRODUCTION — The subject and why it fascinates.
Beat 2 (10-25%):  FACET 1 — First angle of exploration.
Beat 3 (25-40%):  FACET 2 — Second angle, contrasting or complementing the first.
Beat 4 (40-55%):  FACET 3 — Third angle, deepening complexity.
Beat 5 (55-70%):  CONNECTIONS — How the facets relate to each other.
Beat 6 (70-80%):  FACET 4 — The unexpected angle the reader didn't see coming.
Beat 7 (80-90%):  SYNTHESIS — New understanding from the combined exploration.
Beat 8 (90-100%): REFLECTION — What the exploration reveals about the subject and the reader.
```

### 5. Case Study Cascade

Framework introduced, then proven through multiple case studies.

```
Beat 1 (0-10%):   THE FRAMEWORK — Core model or theory presented.
Beat 2 (10-25%):  CASE STUDY 1 — First application. The "textbook" example.
Beat 3 (25-40%):  CASE STUDY 2 — Second application. The complication or exception.
Beat 4 (40-55%):  CASE STUDY 3 — Third application. The surprise or counterexample.
Beat 5 (55-70%):  PATTERN RECOGNITION — What the cases share. What differs.
Beat 6 (70-80%):  PRINCIPLES — Distilled lessons from the case studies.
Beat 7 (80-90%):  APPLICATION — How the reader can apply these principles.
Beat 8 (90-100%): PREDICTION — What the framework suggests about the future.
```

### 6. Investigation / Revelation

The author discovers something. The reader discovers it with them.

```
Beat 1 (0-10%):   INITIAL OBSERVATION — Something doesn't add up.
Beat 2 (10-20%):  FIRST DIG — Surface-level investigation. Early findings.
Beat 3 (20-35%):  DEEPER — The rabbit hole deepens. Unexpected connections.
Beat 4 (35-50%):  RESISTANCE — Obstacles, dead ends, pushback.
Beat 5 (50-60%):  BREAKTHROUGH — The key insight or discovery.
Beat 6 (60-75%):  SCALE — The discovery is bigger than expected.
Beat 7 (75-85%):  IMPLICATIONS — What this means for the reader and the world.
Beat 8 (85-95%):  EVIDENCE ASSEMBLY — The full picture, laid out.
Beat 9 (95-100%): RECKONING — What must change. What probably won't.
```

### 7. Journey / Transformation

The author (or subject) changes through experience.

```
Beat 1 (0-10%):   STARTING POINT — Who I was. What I believed. Where I stood.
Beat 2 (10-20%):  CATALYST — The event or decision that started the journey.
Beat 3 (20-35%):  THE PATH — What the journey looked like. The early stages.
Beat 4 (35-50%):  OBSTACLES — What was hard. What nearly stopped me.
Beat 5 (50-65%):  THE TURNING POINT — The moment everything shifted.
Beat 6 (65-80%):  INTEGRATION — Making sense of the change.
Beat 7 (80-90%):  NEW REALITY — Who I am now. What I understand now.
Beat 8 (90-100%): OFFERING — What I can give the reader from this experience.
```

### 8. Instructional Progressive

Skills build sequentially from fundamentals to mastery.

```
Beat 1 (0-10%):   FOUNDATIONS — Core concepts. Prerequisites. Mindset.
Beat 2 (10-25%):  FUNDAMENTALS — Basic skills and techniques.
Beat 3 (25-40%):  INTERMEDIATE — Building on fundamentals. First real challenges.
Beat 4 (40-55%):  PRACTICE — Exercises, projects, application.
Beat 5 (55-70%):  ADVANCED — Complex techniques. Edge cases.
Beat 6 (70-80%):  INTEGRATION — Combining skills into complete workflows.
Beat 7 (80-90%):  MASTERY — Expert-level application. Troubleshooting.
Beat 8 (90-100%): INDEPENDENCE — The reader can now continue alone. Resources.
```

### 9. Compare-Contrast

Two or more subjects examined in parallel, revealing insights through juxtaposition.

```
Beat 1 (0-10%):   SETUP — The subjects and why comparing them is illuminating.
Beat 2 (10-25%):  SUBJECT A — Deep examination of the first subject.
Beat 3 (25-40%):  SUBJECT B — Deep examination of the second subject.
Beat 4 (40-55%):  UNEXPECTED SIMILARITIES — What they share that isn't obvious.
Beat 5 (55-70%):  KEY DIFFERENCES — What separates them and why it matters.
Beat 6 (70-85%):  SYNTHESIS — What the comparison teaches us about both.
Beat 7 (85-100%): IMPLICATIONS — What this means for the reader's understanding.
```

### 10. Question-Driven

A big question structures the book. Each chapter is a partial answer.

```
Beat 1 (0-10%):   THE QUESTION — Posed clearly. Why it matters.
Beat 2 (10-20%):  FIRST ANSWER — The obvious answer. Why it's incomplete.
Beat 3 (20-35%):  DEEPER QUESTIONS — The question fractures into sub-questions.
Beat 4 (35-50%):  COMPLICATIONS — What makes the question harder than expected.
Beat 5 (50-65%):  NEW EVIDENCE — Information that changes the equation.
Beat 6 (65-80%):  REFRAMING — The question itself changes as understanding deepens.
Beat 7 (80-90%):  RESOLUTION (or PRODUCTIVE AMBIGUITY) — The best answer available.
Beat 8 (90-100%): NEW QUESTIONS — What this answer opens up next.
```

### 11. Biographical Arc

A life story structured around growth, crisis, and legacy.

```
Beat 1 (0-10%):   ORIGINS — Context, family, early influences.
Beat 2 (10-20%):  FORMATION — Education, early career, formative experiences.
Beat 3 (20-35%):  RISE — Achievements, breakthroughs, public recognition.
Beat 4 (35-50%):  CRISIS — The defining challenge, controversy, or failure.
Beat 5 (50-65%):  RESPONSE — How the subject responded to crisis.
Beat 6 (65-80%):  LEGACY BUILDING — Later career, mature work, influence.
Beat 7 (80-90%):  ASSESSMENT — What the life meant. Historical perspective.
Beat 8 (90-100%): REFLECTION — The biographer's thesis about the subject.
```

### 12. Seasonal / Cyclical

Organised around natural cycles, seasons, or recurring patterns.

```
Beat 1 (0-10%):   THE CYCLE INTRODUCED — What pattern structures this book.
Beat 2 (10-25%):  BEGINNING — The start of the cycle (spring, dawn, genesis).
Beat 3 (25-40%):  GROWTH — Expansion, development, increasing complexity.
Beat 4 (40-55%):  PEAK — Full expression, maximum intensity.
Beat 5 (55-70%):  DECLINE — Contraction, loss, simplification.
Beat 6 (70-85%):  RETURN — The cycle begins again. What's changed.
Beat 7 (85-100%): WHAT THE CYCLE TEACHES — The insight earned by completing one full turn.
```

---

## Beat-to-Chapter Mapping

```
Story% = ((chapterNumber - 1) / (totalChapters - 1)) × 100
```

For each chapter, calculate its position and determine which beat it should serve.
The Structural Architect receives this target and designs the chapter accordingly.

**Tolerance:** ±5% — a beat can be delivered slightly early or late.

**Overdue detection:** If a beat passes its target position by more than 10%,
flag it as overdue in the Argument Analyst's report.
