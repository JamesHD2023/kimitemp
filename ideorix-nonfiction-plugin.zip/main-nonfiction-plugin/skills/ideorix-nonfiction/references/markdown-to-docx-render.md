---
name: markdown-to-docx-render
description: Shared markdown-to-DOCX manuscript renderer. Replaces the ad-hoc per-project DOCX generation scripts that each implemented markdown parsing fresh and accumulated parser bugs (literal asterisks in model numbers infinite-looping, unmatched delimiters, smart-quote drift, etc.). Wraps pandoc with optional reference template + YAML config for project metadata, calls docx-integrity-check.sh on the output. Opt-in for existing projects (set shared_renderer enable in project-config.md); default for new projects. Engine-agnostic — mirrored across fiction and nonfiction engines.
version: 2.7.76
---

<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

# Shared Markdown-to-DOCX Manuscript Renderer

> **Powered by Ideorix** — The Manuscript Engine
> *© James Harvey Media. All rights reserved.*

## Purpose

Through v2.7.x the engine shipped DOCX rendering as a *spec* — `format-docx.md`
told Claude how to write a per-project DOCX generation script using the Node.js
`docx` package. Each project (each volume of each series) generated its own
renderer fresh from that spec. The result: every project re-implemented
markdown parsing, and every project re-introduced the same class of inline
parser bugs (literal asterisks in model numbers tripping infinite loops,
unmatched delimiters, smart-quote drift).

This spec replaces the per-project pattern. One shared renderer, audited and
tested, used by every project that opts in. Pandoc handles the markdown
parsing — it is battle-tested on the inline edge cases that broke the
ad-hoc renderers — so the engine doesn't carry its own parser at all.

## Architecture

```
project-root/
├── engine-data/
│   ├── chapters/
│   │   ├── ch01.md
│   │   ├── ch02.md
│   │   └── ...
│   ├── render-config.yaml          (optional — project metadata)
│   ├── render-template.docx        (optional — pandoc reference template for styling)
│   └── manuscript.docx             (output)
└── ...
```

Flow:

1. Caller invokes `scripts/markdown-to-docx-render.sh <project-root>`.
2. The script finds all `engine-data/chapters/ch*.md` files in numeric order.
3. If `engine-data/render-config.yaml` exists, the script extracts `title:`
   and `author:` for pandoc metadata. (Foundation-scope config; richer
   options in incremental follow-ups.)
4. The script concatenates chapters into a same-FS staging markdown file
   (`engine-data/.manuscript-staged.tmp.$$.md` — same-FS-temp pattern per
   `core-pipeline.md` v2.7.73 File Operation Policy), stripping per-chapter
   YAML frontmatter so only prose lands in the manuscript.
5. The script verifies the staged file is non-zero, NULL-byte free, and
   UTF-8 valid before invoking pandoc.
6. The script calls pandoc with `--reference-doc=engine-data/render-template.docx`
   if a template is present; otherwise pandoc uses its built-in defaults.
7. Output written to `engine-data/manuscript.docx`.
8. `docx-integrity-check.sh` runs on the output. PASS exits 0; FAIL exits 5.

## Usage

```bash
bash scripts/markdown-to-docx-render.sh <project-root>
```

Optional flags:

- `--output <path>` — override output location (default `<project>/engine-data/manuscript.docx`)
- `--config <path>` — override config location
- `--template <path>` — override reference template location

## Configuration

`engine-data/render-config.yaml` (foundation scope, optional):

```yaml
title: "The Manuscript Title"
author: "The Author Name"
```

The current v2.7.76 foundation reads `title` and `author` only; richer
configuration (font families, indent specifications, layout variants, etc.)
arrives in incremental follow-ups. Styling control until then is via the
pandoc reference template (`engine-data/render-template.docx`).

## Reference template

If a styled template is present at `engine-data/render-template.docx`, pandoc
applies its styles to the rendered manuscript. Without a template, pandoc
uses its built-in defaults (Times New Roman 12pt body, no indent, single
spacing — distinguishable from typical Ideorix manuscript expectations).

To create a reference template:
1. Open Microsoft Word (or LibreOffice).
2. Set the default paragraph style to match Ideorix manuscript conventions:
   - Times New Roman, 12pt body
   - 0.5" first-line indent (body paragraphs)
   - 1.5 line spacing
   - 6pt spacing after
3. Save as `engine-data/render-template.docx`.

The next render uses your template.

## Opt-in for existing projects

By default, existing projects (those with their own ad-hoc renderer) keep
using their per-project script. To migrate a project to the shared renderer,
add this line to `engine-data/project-config.md`:

```
shared_renderer: enable
```

When the orchestrator (or the user manually) runs the export step, it
checks for `shared_renderer: enable` and routes to the shared renderer
instead of writing/running a per-project script. The migration is one
line; no project files need to move.

## Default for new projects

New projects created with `core-pipeline.md` setup automatically use the
shared renderer. The setup step creates a minimal `render-config.yaml`
with the project's title and author drawn from the bible. The user can
extend it as needed.

## What this foundation supports

- Single-line chapter title format (`# Chapter 1: Title`)
- Body paragraphs (any markdown prose pandoc handles)
- Scene breaks (`* * *` or `---`)
- Inline bold / italic / code (pandoc-native handling; no edge-case bugs)
- Literal asterisks, underscores, brackets, backticks in prose (pandoc
  handles these correctly — this is the v2.7.x bug class that motivated
  the renderer)
- Smart quotes, em-dashes, en-dashes (pandoc preserves these)
- Per-chapter YAML frontmatter (stripped from output, used only for
  engine-side metadata)
- Optional title / author via render-config.yaml
- Optional styling via reference template

## What this foundation does NOT yet support

Documented gaps, with incremental-follow-up priority:

1. **Two-line chapter title format** — e.g., Vol 2's "### Notes" + main title
   layout. Workaround until supported: project keeps its ad-hoc renderer
   (don't opt in to shared yet).

2. **`### Section` subheadings inside chapters** — pandoc renders these as
   Heading 3 by default. If the reference template defines a Heading 3
   style, that's used. Otherwise the rendering is generic. Richer
   per-heading-level config arrives in follow-up.

3. **Front matter / back matter** (TOC, copyright, dedication, acknowledgments,
   bibliography). Add manually to the output DOCX for now; engine-side
   front/back-matter rendering is a follow-up.

4. **Footnotes** — pandoc supports markdown footnote syntax (`[^1]`) natively,
   but engine-side orchestration (footnote numbering, placement at chapter
   end vs. manuscript end) is not yet wired in.

5. **Genre-specific layouts** — cookbook recipe blocks, screenplay format,
   poetry. Each needs its own config schema; planned as follow-up specs.

6. **Multi-volume aggregation** — single-volume scope today; multi-volume
   compilation requires a separate cover/TOC step.

7. **Existing-project migration helpers** — for now, opt-in is a single config
   line and the existing project's ad-hoc renderer becomes deletable. A
   migration script (compares pre/post DOCX for parity) is follow-up.

## Limits and honest caveats

- **Pandoc is a runtime dependency.** The script detects pandoc and exits 3
  with an install hint if missing. CI environments and user machines both
  need pandoc installed. Catalog-render has the same dependency; this is
  not a new burden.
- **Styling without a template is generic.** Projects that need specific
  font / indent / spacing must provide `render-template.docx`. A planned
  follow-up ships a default Ideorix manuscript template that projects
  can use as a starting point.
- **No parser-edge-case tests are needed here** — pandoc has its own test
  suite for those. The engine tests focus on integration: chapters found,
  args validated, pandoc invoked correctly, integrity check runs on output.
- **Same-FS-temp discipline applies.** The script writes its staging file
  next to the target on the project's filesystem, not in `/tmp`. This is
  the v2.7.73 file-write hygiene rule. Linux `/tmp` → Windows-mount mv
  is rejected by Cowork-Windows with EPERM.

## Silent-Failure Audit

This feature uses the following primitives. For each, the success-claim,
divergence failure mode, and verification binding are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Chapter file discovery (`find … -name 'ch*.md'`) | "Found N chapter files" | Empty result | Exit 2 with explicit "no chapter files found" error |
| Same-FS staging concatenation | "Staged manuscript written" | Bridge intermittency → NULL fill at target size | Post-staging NULL-byte scan + UTF-8 check before invoking pandoc; abort with exit 4 if corrupted |
| Pandoc invocation | "Wrote DOCX" | Pandoc returns non-zero (malformed markdown, missing template, etc.) | Exit 4 with stderr re-run for diagnosis |
| Post-render integrity check (`docx-integrity-check.sh`) | "DOCX is clean" | Bridge intermittency during pandoc's write → NULL bytes in word/document.xml | Exit 5 if integrity check fails; user retries (failure is intermittent) |
| Reference template (optional) | "Pandoc used my template" | Template missing → silent fallback to defaults | Console message announces "no reference template found at X — using pandoc defaults" so the user can spot the discrepancy if styling looks wrong |

## Related specs

- `format-docx.md` — the pre-v2.7.76 spec describing how to write a per-project
  Node.js DOCX renderer. Retained for projects that have not yet opted in
  to the shared renderer. New projects skip this and use the shared path.
- `docx-integrity-check.sh` — post-render NULL-byte check, called by this
  renderer
- `pre-export-typography-gate.sh` — runs before invoking the renderer
  (typography sweep on the chapter source)
- `catalog-render.sh` — the existing shared renderer for sales catalogs;
  this spec follows the same pandoc-wrapper pattern
- `core-pipeline.md` File Operation Policy — same-FS-temp discipline applied
  to the staging step
