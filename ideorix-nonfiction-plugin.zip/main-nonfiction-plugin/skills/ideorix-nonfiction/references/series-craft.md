---
name: series-craft
description: "Universal craft principles for series fiction. Engine-agnostic, genre-agnostic, conditional load (fires on series projects only). Covers same-but-different, no-required-reading-order, attribute-every-line in early books, small defined cast, linear chronology, and series character consistency."
version: "2.3.4"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*


# Series Craft (Universal — Conditional Load)

This file is loaded into the Writer prompt's
`{series_craft_load}` slot **conditionally** — only when the
project being generated is part of a series (set at project
setup or implied by the presence of a series-bible.md file or
multi-volume project structure). Standalone projects do not
trigger it; zero token cost when irrelevant.

Series fiction has its own craft requirements distinct from
standalone novels. The reader picks up the next instalment for
familiarity (the comfort of returning to a known character)
and freshness (the need for a story they haven't already read).
Those two pulls are in tension. Series craft is the discipline
of balancing them.

## The Same-But-Different Mantra

The single most important principle in series fiction:
**each book in a series should be the same but different.**

The "same" is what brings the reader back: the protagonist's
voice, their core nature, the trope set, the emotional
contract.

The "different" is what makes the reader buy the new book:
fresh setting, fresh case, fresh secondary cast, fresh
emotional arc within the same protagonist.

Neither dominates. Too much "same" and the books become
interchangeable; readers fall away around book 5 or 6 because
they've stopped feeling fresh. Too much "different" and the
reader doesn't get what they came for; readers fall away
because the book they bought isn't the book they wanted.

### Working application

For each new instalment, identify:

1. **The fixed points** — what stays the same. Character
   voice, core relationships, the protagonist's moral
   architecture, the genre contract.

2. **The variable points** — what changes. Setting (often a
   new geography), the central case or problem, the
   secondary cast for this book, the emotional sub-arc the
   protagonist is on this time.

3. **The architectural shift** — at least one structural
   change between books. Not necessarily a big one, but one
   significant enough that the reader can articulate "this
   one was the X book." Could be: a new location, a new
   trope combination, a new POV experiment, a new emotional
   register, a new external pressure on the protagonist.

If three consecutive books have no architectural shift between
them, the series is at risk of staling. Plan the next book to
introduce one.

## No-Required-Reading-Order Rule

A series should be designed so that a reader picking up Book 7
first can read it as a complete experience without having read
Books 1-6.

This is a commercial as well as a craft consideration. Readers
discover series at any point — they hear a recommendation,
they see a copy in a bookstore or airport, they encounter a
TV adaptation. If they have to find Book 1 first before they
can engage, many give up.

### Working application

- **Don't assume backstory.** Whatever the reader needs to
  know to follow this book must be conveyed within this
  book, even if that means restating something that was
  established in an earlier instalment.

- **Avoid heavy callbacks to past cases.** A character
  saying "remember when we worked on the embassy case in
  Berlin?" alienates the new reader. Reframe such moments —
  if the embassy case is relevant, summarise its substance
  rather than referencing it as a shared memory.

- **Re-introduce returning characters as if for the first
  time.** A returning best friend, mentor, or rival should
  be characterised on first appearance in this book as if
  the reader has never met them. Returning readers will
  recognise the description; new readers will be onboarded.

- **Foreground the protagonist's current moment.** What the
  protagonist wants and fears RIGHT NOW carries more weight
  than what they wanted and feared in previous books.

The exception: serial trilogies or quartets that are
deliberately published as a single multi-volume story
(e.g. The Lord of the Rings) can require sequential reading.
But this should be an explicit creative decision, not a
default outcome of casual series construction.

## Attribute-Every-Line Discipline (Early Books Especially)

In the first one or two books of a series, where the
protagonist's voice is still being established and the cast
of returning characters is being introduced, every line of
dialogue should carry an attribution ("he said," "she said,"
"the detective said").

### Why

New readers in early books are still learning who the
characters are. They haven't yet developed an ear for the
distinct voice of each. Without attribution, they have to
flip back to find the most recent attribution and count
turn-takings to figure out who is speaking now. That's a
speed bump the early-series writer must remove.

By Book 3 or 4, returning readers know the cast well enough
that some attributions can be dropped — the voices are
established, the rhythms recognisable. Lighter attribution
becomes acceptable, even desirable.

### Working application

- Books 1-2: every line of dialogue attributed.
- Books 3-4: the protagonist and one or two key supporting
  characters can sometimes go un-attributed within tight
  back-and-forth exchanges; everyone else still gets
  attributed.
- Book 5+: the writer can use the lighter convention common
  in standalone fiction (attribute on shifts, leave clear
  back-and-forths to the reader's ear).

The rule is calibrated for new readers entering the series
late. A new reader picking up Book 4 needs more attribution
than a returning reader.

## Small, Defined Cast Per Book

A series can have a large cumulative cast across all its
volumes, but each individual book should keep its on-page cast
small and clearly defined.

### Why

The reader is being asked to track:

- The protagonist (and any returning regulars)
- The new cast specific to this book (the case, the romantic
  interest, the antagonist, the supporting players)

If the new cast is too large, the reader cannot retain who is
who. They start to merge characters, mis-remember names, and
lose the thread.

### Working application

- Limit named new characters per book to roughly 6-10 (the
  number scales with book length and cast complexity, but
  this is the working range).
- For minor characters, prefer descriptive identifiers
  ("the pawn shop guy," "the night manager," "the woman in
  the green coat") over given names. The reader retains a
  descriptive identifier more easily than an unfamiliar name.
- Returning regulars do not count against the new-cast limit
  (the reader already has them).
- Where a character recurs from a previous book in a minor
  role, descriptive identification ("the FBI handler from
  the New Orleans case") helps both new and returning
  readers.

## Linear Chronology Preferred

In series fiction, linear chronological narration is
preferable to elaborate flashback structures, time-jumps, or
non-linear timelines.

### Why

The series reader is already managing complexity — multiple
books, multiple casts, multiple cases, possibly years of
publication time between instalments. Adding chronological
complexity within a single book taxes the reader's attention
unnecessarily.

Linear chronology also serves the no-required-reading-order
rule: a new reader entering the series doesn't have the
context to navigate a non-linear book structure.

### Working application

- Default to start-at-the-beginning-and-go-forward.
- Brief flashbacks (a paragraph, a scene at most) are
  acceptable when they convey backstory the reader needs at
  this moment.
- Avoid framing devices (a present-day narrator looking back
  at events from years ago) unless the framing is itself
  central to the story's premise.
- Avoid alternating-timeline structures (chapter 1 in 2010,
  chapter 2 in 2024, chapter 3 in 2010, etc.) in series
  fiction unless the alternation is the structural premise.

## Series Character Consistency

The protagonist's character should remain consistent across
the series, with only modest organic evolution.

### Why

Series readers come back for the protagonist. If the
protagonist changes substantially between books — adopts new
philosophies, develops new skills, undergoes major personality
shifts — the reader has not received what they paid for.

This is the opposite of the standalone novel rule. In a
standalone, character arc and growth are central; the
protagonist at the end is meaningfully different from the
protagonist at the beginning. In a series, the protagonist's
core remains stable across books. They can grow within a
book, but they reset (mostly) between books.

### Working application

- The protagonist's voice should sound the same in Book 7 as
  in Book 1.
- Their core values and moral architecture should be
  unchanged.
- Skills accumulated within a book may carry forward, but
  shouldn't compound dramatically (the protagonist doesn't
  become 10x more capable across 10 books).
- Resist the temptation to "develop" the protagonist
  through ever more intense backstory, ever more dramatic
  emotional revelations, ever-deeper trauma. Each new
  layer added to the protagonist makes them less
  recognisable to the returning reader.

### What can change

- Their immediate emotional state (this book's relationship
  is happy; next book it isn't)
- Their geographic location, employment situation, or
  current case
- Their secondary relationships (a friend made in Book 5
  might be absent from Book 6's setting)
- Their evolving understanding of their world (modest
  drift; not radical reframings)

### What should not change

- Voice (interior monologue rhythm, vocabulary, sentence
  patterns)
- Core values
- Signature behaviours (the things they always do — the
  protagonist's "rituals" or "tells")
- Moral architecture
- The contract with the reader (if Book 1 promised one
  type of story, Book 7 should still deliver that type
  of story)

## Avoiding the Falling-In-Love Trap

A common series-author failure is falling in love with the
protagonist over many books. The author's affection grows
imperceptibly across each instalment, and the protagonist
gradually becomes too good — too noble, too capable, too
attractive, too always-right.

This is fatal to series longevity. The protagonist becomes
unbelievable, and the reader's bond — which was built on a
character they could relate to — weakens.

### Working application

- Aim to **like the protagonist slightly less than the reader
  does.** Stay critical of them. Notice their flaws. Show
  their limits.
- Include third-party perspectives that see the protagonist
  honestly — not always positively. Other characters can
  notice the protagonist's quirks, blind spots, irritating
  habits, or moral compromises.
- Resist the urge to give the protagonist new superpowers,
  new accomplishments, new escalating mastery. Series
  protagonists work best when they are competent without
  becoming superhuman.
- Resist the urge to romance the reader on the protagonist's
  behalf. Don't tell the reader the protagonist is cool;
  let the protagonist be cool through behaviour and let
  the reader make their own decision.

## Non-fiction series — adaptations to the principles above

Most of the principles above transfer directly to NF series. Key
adaptations:

- **Same-but-different mantra** applies cleanly — fixed points
  for NF are author voice, subject domain, methodology /
  framework consistency, the reader-author relationship.
  Variable points are the specific topic per book, the case
  studies / recipes / examples per book, the angle on the
  domain.
- **No-required-reading-order rule** applies cleanly — a
  cookbook reader picking up Book 4 should be able to use it
  without owning Books 1-3; a business-book reader entering
  the series at any point should get the framework that
  matters for this book.
- **Attribute-every-line discipline** is less applicable —
  NF prose has less direct dialogue per page than fiction, so
  the calibration is "attribute on shifts of authority — when
  the author is paraphrasing a source, citing an expert,
  speaking from personal experience, or restating an
  established term." Calibrated to book number same as fiction
  (heavier in early books, lighter in later).
- **Small, defined cast per book** maps to: small, defined set
  of named experts / sources / case-study subjects per book.
  Cumulative across the series can be larger; per-book stays
  manageable. Use descriptive identifiers ("the cardiologist
  from the 2018 trial") for minor figures.
- **Linear chronology preferred** applies less rigidly — NF
  often has thematic rather than chronological structure
  within a book. The principle that holds is: don't ask the
  reader to manage non-linear complexity unless the
  structure's the point.
- **Series character consistency** maps to: **author voice
  consistency**. The NF author's voice — vocabulary,
  authority register, evidence-integration style, reader
  relationship — must remain stable across books. The author
  doesn't undergo dramatic personality shifts between
  Book 3 and Book 7. Modest evolution acceptable; radical
  reframings (changing methodological school, abandoning
  established positions without explanation) signal series
  staling.
- **Falling-in-love trap** maps to: **falling-in-love-with-
  one's-authority trap**. The NF author who, over many books,
  becomes too sure of their position, too dismissive of
  alternative views, too reliant on past success — same
  failure pattern. Stay critical of own positions across the
  series.

NF series subgenres with stronger same-but-different
expectations than average:

- **Cookbook series** — readers expect consistent recipe
  format, ingredient sourcing philosophy, equipment
  assumptions. The "what's different" is the topical
  collection (Italian / Indian / weeknight / holiday).
- **Business book series** — readers expect consistent
  framework architecture and case-study quality. The
  "what's different" is the new framework or new domain
  application.
- **Academic / reference series** — readers expect
  consistent methodological approach and citation depth.

## Where this block is loaded

The `{series_craft_load}` slot in `prose-protocol.md` (fiction)
and `content-writer.md` (non-fiction) pulls from this file
**conditionally** — only when the project is part of a series.
The slot is filled with a one-line "not applicable" stub for
standalone projects.

This conditional loading keeps the universal-craft prompt
content lean for standalone projects while ensuring series
projects get the specific guidance they need to maintain
consistency across instalments and avoid the common series-
fiction failures.

When this file is updated, the change applies everywhere
series fiction is generated, regardless of genre. No parallel
updates to per-genre files required.
