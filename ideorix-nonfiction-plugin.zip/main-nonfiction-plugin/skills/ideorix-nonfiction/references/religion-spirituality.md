---
name: religion-spirituality-category
description: "Category-specific instructions for religion and spirituality non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Religion / Spirituality. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | religion-spirituality |
| Display Name | Religion / Spirituality |
| Parent Group | Religion & Spirituality |
| Typical Word Count | 50,000–80,000 (devotional and meditation guides often shorter; comparative-religion and theological / historical work can run 100,000+) |
| Default Structure | Varies by subcategory; the unifying pattern is scene-or-text-anchored chapter openings (a narrative moment, a scriptural passage, a historical event) followed by reflection / interpretation / application; chapters either build cumulatively (theology / formation / philosophy) or stand independently (devotional / essay / wisdom collection) |
| Citation Style | Sacred texts cited within the conventions of their tradition (book.chapter.verse for Tanakh / Bible / Qur'an; sutra / discourse name for Buddhist canon; Sanskrit name + verse for Hindu texts); secondary scholarship endnoted; named teachers / theologians / scholars credited in-text; clear distinction between primary tradition sources, secondary scholarship, and the author's own interpretation |
| Audience Baseline | Varies sharply: from devotee within the author's tradition (devotional / theology) to seeker / curious general reader (meditation / comparative / spiritual memoir) to scholarly-engaged reader (comparative-religion / religious-history). Audience is named explicitly so readers self-select |
| Comparable Titles | C.S. Lewis (*Mere Christianity*), Henri Nouwen (*The Return of the Prodigal Son*), Anne Lamott (*Traveling Mercies*), Barbara Brown Taylor (*Learning to Walk in the Dark*), Thich Nhat Hanh (*Peace Is Every Step*, *The Miracle of Mindfulness*), Pema Chödrön (*When Things Fall Apart*), Sharon Salzberg (*Lovingkindness*), Tara Brach (*Radical Acceptance*), Abraham Joshua Heschel (*The Sabbath*), Karen Armstrong (*A History of God*, *The Case for God*), Huston Smith (*The World's Religions*), Krista Tippett (*Becoming Wise*), Reza Aslan (*Zealot*, *No God But God*), Bart Ehrman (*How Jesus Became God*), Eckhart Tolle (*The Power of Now*), Diana Butler Bass |

## Subcategory Options

When the user selects Religion / Spirituality, prompt for subcategory
refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| devotional-daily-practice | Devotional / Daily Practice | Daily readings, prayer-and-reflection guides, liturgical-year companions, practice manuals — written from inside a specific tradition for practitioners | Daily / weekly / seasonal entry format; scriptural or canonical text + reflection + practice prompt; consistent length per entry; rhythm-of-life pacing rather than cumulative argument |
| spiritual-memoir-journey | Spiritual Memoir / Faith Journey | Personal narrative of conversion, doubt, formation, deconstruction, return, or seeker journey — uses memoir conventions in service of a spiritual / religious arc | Memoir's chronological / thematic spine; transformation arc anchored on a faith trajectory; recognition-then-reflection rhythm; the author's tradition / lack of tradition disclosed early |
| meditation-contemplative | Meditation / Contemplative Practice | Mindfulness, insight, loving-kindness, contemplative-prayer, centering prayer, contemplative practices across traditions written for practitioners — instruction-led | Concept → guided-practice → integration cycle per chapter; specific instructions for posture / breath / attention; common-difficulty troubleshooting; long-arc programme structure for serious practitioners |
| theology-faith-formation | Theology / Faith Formation | Theology written for the general reader of a tradition; faith-formation curriculum; doctrinal exploration; engaging with central claims of the tradition for readers seeking depth within their tradition | Doctrinal-theme or scriptural-corpus chapter spine; exegesis + application; historical theological development sometimes as backbone; named theological tradition or school positioned explicitly |
| comparative-religion-academic | Comparative Religion / Religious Studies | Scholarly or accessibly-academic treatment of multiple traditions — pattern-spotting, contrast, history of religion as a field | Theme-or-question across traditions (e.g. "the problem of suffering across traditions"); each tradition treated with depth and respect; author's positionality (insider / outsider / academic) disclosed |
| eastern-philosophy-practice | Eastern Philosophy & Practice for Western Readers | Buddhism, Hinduism, Taoism, Zen, Vedanta written for predominantly Western readers — bridges scholarly tradition with contemporary practice | Concept introduction with original-language terms (Sanskrit / Pali / Chinese / Tibetan) defined; canonical-source anchoring; practice translation for contemporary lay practitioners; explicit acknowledgement of the cultural translation involved |
| religious-history-criticism | Religious History / Textual Criticism | Scholarly or popular-scholarly historical work on religious origins, scripture authorship, founder biography, denominational history, religious institutions through time | Chronological or topical historical structure; primary-source engagement (manuscripts, archaeology, contemporaneous accounts); current-scholarly-consensus stance distinct from traditional / devotional accounts; treats faith claims as historical-claims-to-be-examined rather than asserted or dismissed |

**Default:** If the user does not specify, prompt for the book's mode
(written from inside a tradition / written about traditions / personal
spiritual narrative / contemplative practice instruction) and select
accordingly; fallback to `spiritual-memoir-journey` for unclear cases
where the book is more personal than systematic.

## Structural Architect Instructions
```
STRUCTURE (varies by subcategory)
- Devotional: daily reading / one concept per chapter format
- Meditation: instruction blended with philosophy
- Comparative: thematic-analytical across traditions
- Spiritual memoir: narrative/chronological
- Eastern philosophy: concept-then-practice structure

FORBIDDEN
- Presenting one tradition's claims as universal truth without acknowledging specificity
- Misrepresenting other faith traditions
- Exploiting spiritual vulnerability for manipulative purposes
- Dangerous practices without appropriate cautions (intense fasting, extreme meditation)
```

## Content Writer Craft Rules
```
VOICE & TONE
- Ranges from intimate-pastoral (devotional) to intellectually rigorous (comparative)
- Respect for the sacred without losing analytical clarity
- Personal experience valid as evidence in this category
- Space for mystery. not everything must be explained
```

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the human need that faith addresses. A universal experience
 . grief, wonder, moral crisis, longing. shown through a specific person or moment.
- **Sentence calibration:** Medium sentences averaging 15–22 words. Measured, respectful,
  searching. The prose should feel like it is reaching toward something, not declaring it.
- **Personal experience grounding the spiritual:** Abstract theological claims must be
  anchored in lived experience or historical narrative. The reader enters through the
  human door before encountering the divine.
- **Rhythm pattern:** Alternate between narrative (story, testimony, historical moment)
  and reflection (meaning, theology, interpretation). The narrative gives the reader
  something to hold; the reflection gives them something to think about.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In religious and
  spiritual writing, tension comes from the gap between human experience and the
  transcendent. the questions that resist easy answers.
- **Tension drivers:** The doubt within faith. The suffering that challenges belief.
  The moment of encounter that defies explanation. The distance between doctrine and
  lived experience.
- **Space for mystery:** Not every paragraph needs a conclusion. Some sentences should
  open into silence. The prose should occasionally gesture toward what cannot be said.
- **Reverence without sentimentality:** Sacred subjects demand dignity in the prose, but
  sentimentality weakens rather than honours them. Precision is a form of reverence.
- **Multi-tradition sensitivity:** When discussing traditions other than the book's
  primary focus, the prose should adopt the same measured care. No tradition is
  described with less attentiveness than any other.
- **Paragraph pace:** Allow longer paragraphs for meditative passages. Shorter
  paragraphs for moments of testimony or direct address. Let the form follow the
  spiritual content.
- **Read-aloud test:** The prose should sound like a person speaking about what matters
  most to them. with care, with honesty, without performance. If it sounds like a
  pulpit or a pamphlet, revise.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Tradition framing disclosed | The author's relationship to the tradition(s) discussed is clear: writing from inside (named tradition, named lineage / denomination / school), writing as scholar, writing as seeker, writing as comparative-academic; readers can calibrate the perspective without guessing |
| 2 | Theological / philosophical claims attributed | Claims about a tradition's beliefs or practices trace to that tradition's primary sources (scripture, canonical texts, authoritative teachers) or recognised secondary scholarship; claims are not laundered through generic "all religions teach..." formulations |
| 3 | Scriptural and canonical citation precise | Quotations from sacred texts cite chapter and verse (or sutra / discourse / paragraph) using the convention of the tradition; translation source named where multiple translations exist; original-language terms transliterated and defined where used |
| 4 | Other traditions represented accurately | Where the book references traditions other than the author's primary one, those traditions are represented in terms their own practitioners would recognise; no caricature, no straw-manning, no flattening to "Eastern wisdom" or "Abrahamic religions" generalisations |
| 5 | Faith claims and empirical claims distinguished | Where the book makes claims that depend on faith (existence of God / the divine, miraculous events, post-mortem realities, scriptural inerrancy) those are framed as faith claims; where it makes claims subject to historical or scientific evidence (when a text was written, what archaeology shows, who was the historical founder) those follow the evidence rather than tradition's preferred narrative |
| 6 | Scholarly honesty on contested historical claims | For religious-history and biblical-criticism content: current scholarly consensus presented honestly even where it complicates traditional accounts (multiple authorship of canonical texts, dating of composition, contested founder biographies, mythologising over time); the book does not assert traditional positions as established history when scholarship disagrees |
| 7 | No proselytising as default | For general-audience books, the prose does not assume the reader shares the author's faith; conversion-as-implicit-goal framing is reserved for explicitly evangelical / devotional within-tradition titles where the audience expects it; otherwise the prose meets the seeker, the curious, and the unbeliever where they are |
| 8 | Practice cautions where psychological effects are real | Meditation, fasting, breathwork, ritual practices, and similar that can trigger psychological distress (depersonalisation, dissociation, panic, depressive episodes, mania, psychosis-spectrum events in vulnerable practitioners) carry appropriate cautions and signposts to qualified support; "trauma-sensitive" framing where relevant |
| 9 | Mystery preserved without obscurantism | Sacred subjects are allowed to remain mysterious where the tradition treats them as such (apophatic theology, koans, ineffability traditions); but mystery is not used as a shield against precise thought — the prose distinguishes "this is properly beyond articulation" from "I have not bothered to articulate this" |
| 10 | Vulnerable readers protected | The prose does not exploit spiritual longing, grief, or crisis for manipulative ends; does not promise outcomes (healing, prosperity, divine intervention) that depend on faith without saying so; does not position the author / book / community as exclusive or indispensable access to the sacred |

## Source Requirements

### Mandatory Source Types

- **Primary tradition sources.** Sacred texts in their canonical form
  (Tanakh, Bible, Qur'an, Pali / Sanskrit / Tibetan Buddhist canons,
  Hindu scriptures including Vedas / Upanishads / Bhagavad Gita /
  Puranas, Daoist canonical texts, Sikh Guru Granth Sahib, etc.);
  authoritative commentaries within the tradition; recognised teachers
  and theologians historical and contemporary. The evidentiary
  backbone for any claim about a tradition's beliefs and practices.
- **Translation source named.** For texts not in the original
  language, the translation used is named — this matters because
  translation choices shape interpretation in this category more
  than in most. "King James Version" / "NRSV" / "JPS Tanakh" /
  "Pickthall" / "Yusuf Ali" / "Easwaran's Bhagavad Gita" / "Bhikkhu
  Bodhi's translation" carry different connotations and theological
  implications.
- **Religious studies / academic scholarship.** Peer-reviewed
  scholarship in religious studies, biblical / Qur'anic studies,
  Buddhology, Indology, history of religions; named scholars
  (Karen Armstrong, Bart Ehrman, Reza Aslan, Diana Eck, Jonathan
  Z. Smith, Wendy Doniger, Robert Bellah, Jaroslav Pelikan,
  Elaine Pagels, etc.) cited where their work informs the book's
  positions. Required for comparative-religion, religious-history,
  and any work treating the tradition academically.
- **Within-tradition theological scholarship.** For
  theology / faith-formation work, the relevant theological canon
  for the book's tradition: Augustine, Aquinas, Calvin, Barth,
  Rahner, Niebuhr, Tillich, Bonhoeffer for Christian; Maimonides,
  Heschel, Buber, Soloveitchik for Jewish; al-Ghazali, Ibn 'Arabi,
  Sayyid Qutb, Fazlur Rahman for Islamic; Buddhaghosa, Nagarjuna,
  Tsongkhapa, Dogen, the Dalai Lama for Buddhist; Adi Shankara,
  Ramanuja, Vivekananda, Gandhi, Krishnamurti for Hindu — selected
  per relevance.
- **Author's lived practice and experience.** Where the author
  draws on their own spiritual or religious experience (memoir,
  devotional, contemplative-practice instruction), that experience
  is named and contextualised; the author's lineage, training,
  initiation, ordination, or formation is disclosed where it
  shapes the book's authority.
- **Voices from the tradition the author is writing about.** For
  any tradition the author is writing about from outside,
  contemporary practitioner voices and scholarly voices from
  within the tradition are central inputs — not just the author's
  reading of the tradition's texts. "Nothing about us without us"
  applies to religious traditions as it does to other identity
  categories.

### Source Freshness

- **Primary sources are stable but interpretation evolves.** Sacred
  texts themselves do not date; interpretive frameworks for
  approaching them do. Late-20th-century neo-orthodox readings,
  liberation-theology readings, feminist-theological readings,
  postcolonial readings, ecological-theological readings — the
  current state of the interpretive field matters even when the
  primary text is ancient.
- **Religious-studies scholarship updates.** Pre-1990 textual
  criticism, historical-Jesus scholarship, dating of canonical
  texts, archaeology of biblical / Qur'anic / Buddhist sites has
  been substantially refined; the book engages with current
  scholarship rather than the field's prior consensus where they
  diverge. Bart Ehrman, Reza Aslan, Karen King, and similar
  represent current popular-scholarly state of biblical studies;
  comparable currency for other traditions.
- **Religious-history framings have shifted.** Pre-2010 framings
  of "world religions" as discrete bounded systems have been
  challenged by scholars like Brent Nongbri, Jonathan Z. Smith,
  Tomoko Masuzawa; current scholarship treats "religion" itself
  as a contested category. Comparative-religion writing should
  engage with this critique rather than perpetuate the older
  framework uncritically.
- **Devotional content has longer shelf life** but is not exempt
  from currency: a 1950s devotional written for a homogeneously-
  Christian audience reads differently in a contemporary multi-
  faith / post-Christendom context; re-issues warrant updated
  framing where appropriate.

### Attribution Standards

- **Tradition-internal claims attributed.** "Christianity teaches
  X" is rarely accurate without specification — Catholic, Orthodox,
  Lutheran, Reformed, evangelical, Anabaptist, charismatic, liberal-
  Protestant, etc. teach overlapping but distinct things. Equivalent
  precision required for Judaism (Orthodox, Conservative,
  Reform, Reconstructionist, Renewal, Hasidic, etc.), Islam (Sunni,
  Shia, Sufi, Salafi, Ahmadi, etc.), Buddhism (Theravada, Mahayana,
  Vajrayana, Zen, Pure Land, Tibetan, Western Insight, etc.),
  Hinduism (Vaishnava, Shaiva, Shakta, various darshanas, etc.),
  and other traditions. Specify the lineage or school being
  represented.
- **Borrowed practices credited.** Spiritual practices borrowed
  across traditions (Buddhist mindfulness in secular form, Sufi
  practices in Western contemplative work, Hindu yoga in Western
  fitness contexts) carry attribution to their tradition of origin;
  the borrowing-and-adaptation move is named rather than concealed.
- **Distinguish: doctrine / interpretation / personal view.** "The
  Catholic Church teaches..." (doctrine, citable to Catechism /
  conciliar documents) differs from "many Catholics today
  interpret..." (interpretation, citable to representative theologians
  or surveys) which differs from "I have come to believe..."
  (personal view). Each is legitimate; conflating them obscures
  the analytical chain.
- **Author positionality disclosed.** The author's relationship to
  the tradition(s) discussed shapes the work — practising adherent,
  former adherent / deconstructor, sympathetic outsider, scholarly
  observer, comparative-religion specialist, seeker. This positionality
  should be disclosed early so the reader can calibrate.
- **What is NOT acceptable.** Misrepresenting other traditions to
  elevate one's own. Caricaturing "fundamentalist" / "liberal" /
  "atheist" / "spiritual but not religious" positions as
  intellectual straw men. Claiming universal consensus across
  traditions where there is not one. Citing scriptures without
  context to support positions the surrounding text does not
  support. Asserting traditional accounts of contested historical
  matters as historical fact when current scholarship disagrees.

## Category-Specific Guardrails

### MANDATORY. Tradition-Representation Honesty (inside vs outside)

- Every chapter's stance toward the tradition(s) it discusses must
  be transparent. Writing from inside the tradition (a Christian
  writing about Christian theology, a Buddhist teaching Buddhist
  meditation, a Jewish writer interpreting Torah) is one register;
  writing about traditions from outside (a Christian comparing
  Buddhism, an academic treating Islam, a secular author surveying
  world religions) is another. Mixing the two without disclosure
  confuses the reader and can offend the represented tradition.
- The author's positionality is disclosed early — typically in
  the introduction or the relevant chapter's opening — and re-
  signalled where it materially affects the chapter's argument.
- Where the author writes about a tradition not their own, the
  prose acknowledges its outsider position with appropriate
  humility; consultation with practitioners and scholars from
  inside the tradition is the standard before publication.
- Writing about a tradition the author has left (deconversion
  memoir, deconstruction work, ex-fundamentalist accounts) is
  legitimate but the perspective is named — readers benefit from
  knowing the perspective is post-tradition rather than from
  outside it.

### MANDATORY. Faith Claims vs Empirical Claims (separate registers)

- Claims about historical events (when did Jesus live, when was
  the Qur'an compiled, did the Buddha exist as a single
  historical person, when were the Vedas composed) are subject
  to historical evidence and follow current scholarship even
  where it complicates traditional accounts.
- Claims about textual authorship and composition (single vs
  multiple authorship of biblical books, the Qur'an's compilation
  history, the layered authorship of Hindu and Buddhist canonical
  texts, the apostolic vs later composition of New Testament
  letters) follow current scholarship when treated historically,
  follow tradition's account when treated devotionally — but
  the register being used is named.
- Claims about the divine, ultimate reality, post-mortem outcomes,
  miracles, supernatural events — these are faith claims, framed
  as such. They are not subject to scientific or historical
  disproof in the same way; the book may assert them as faith
  positions but does not present them as established empirical
  fact.
- The book engages honestly with the tension where faith claims
  and empirical findings appear to conflict (literal six-day
  creation vs current cosmology, biblical historicity vs
  archaeological record, miracle accounts vs naturalistic
  explanation); the engagement may resolve into faith,
  reinterpretation, agnosticism, or skepticism, but the engagement
  itself is honest rather than evasive.

### MANDATORY. Other-Tradition Respect (no caricature, no dismissal)

- When discussing traditions other than the book's primary focus,
  representation meets the same standard the author would want for
  their own tradition: practitioners from the represented tradition
  should recognise their own beliefs and practices in the
  description.
- Avoid the framing-traps:
  - "Eastern wisdom" / "the wisdom of the East" — flattens
    distinct traditions (Buddhism, Hinduism, Daoism, Confucianism,
    Shinto, Sikhism) into a single exotic category.
  - "Abrahamic religions" can be useful for some scholarly
    purposes but flattens distinct traditions when overused.
  - "Primitive" / "tribal" / "ancient" / "indigenous spirituality"
    framings that treat other traditions as anthropological
    curiosities rather than living practices.
  - "Fundamentalist" used as a slur rather than a descriptor of a
    specific theological / hermeneutic position.
  - "True Christianity / Buddhism / Islam / etc. is..." (positions
    the speaker as arbiter of authentic tradition).
- Critique is legitimate; caricature is not. A book may robustly
  disagree with another tradition's claims while representing those
  claims fairly. Disagreement based on misrepresentation is
  intellectually weak and damages the book's credibility.
- For meditation / mindfulness / contemplative content drawing on
  Buddhist / Hindu / Daoist / Sufi / contemplative-Christian
  practices, attribute the source tradition rather than presenting
  practices as universal or author-originated.

### MANDATORY. No Proselytising as Default for General Audience

- Books marketed to general audiences (typical Religion &
  Spirituality bookstore placement, most trade publishing) do not
  assume the reader shares the author's faith. Conversion-as-
  implicit-goal framing reads as manipulative to non-aligned
  readers and is reserved for explicitly evangelical / devotional
  / within-tradition titles where the audience expects it.
- The book may offer testimony, witness, and invitation without
  pressure; "this is what I believe and why" is appropriate;
  "here is why you should believe this" requires the title and
  marketing to make that goal explicit.
- For devotional and within-tradition titles where the audience is
  clearly co-religionist, normal devotional / formational
  conventions apply; the audience expects and seeks that register.
- Exclusivity claims (only this tradition / community / teacher
  has access to the sacred / salvation / enlightenment) are
  particularly fraught for general-audience publishing and warrant
  the most careful framing.

### MANDATORY. Vulnerable-Reader Protection

- Spiritual longing, grief, crisis, and searching make readers
  particularly vulnerable to manipulation. The book respects this
  rather than exploiting it.
- Specific protections:
  - **No prosperity-gospel framings.** Promising material outcomes
    (wealth, healing, success) as reliable consequences of faith /
    practice / payment is the category's most exploitative pattern;
    the book does not participate in it.
  - **No author-as-exclusive-channel framings.** The book / author /
    community is not positioned as exclusive or indispensable
    access to the sacred; readers are not made dependent on
    continuing engagement with the author / paid programmes /
    inner-circle access.
  - **No coercive crisis-framing.** Eternal-damnation framings, fear-
    based conversion appeals, urgency-of-decision pressure tactics,
    family-rupture-as-spiritual-cost framings — these are patterns
    associated with high-control religion and spiritual abuse; the
    book does not deploy them.
  - **Mental-health awareness.** Religious / spiritual experience can
    coincide with or be confused with mental-health crisis (mania,
    psychosis-spectrum events, depression, dissociation); the book
    does not encourage readers to interpret all such experience as
    spiritual rather than potentially clinical, and signposts to
    qualified support where relevant.
- Where the book engages topics of spiritual abuse, high-control
  religious groups, deconversion, religious trauma — handles them
  with awareness that some readers are processing recent or active
  harm.

### MANDATORY. Practice Cautions (where psychological effects are real)

- Meditation and contemplative practices: extended retreat, intense
  practice, certain insight-tradition methods can trigger
  difficult psychological events — depersonalisation, derealisation,
  dark-night-of-the-soul phenomena, panic, dissociation,
  destabilising insight. The "Varieties of Contemplative Experience"
  research (Britton et al.) documents this; the book mentions it
  honestly for any practice-instruction content.
- Fasting, sleep deprivation, ritual breathwork, holotropic
  practices, plant-medicine adjacencies — these carry physical
  and psychological risks; intense versions are not recommended
  without qualified guidance and explicit caution.
- Trauma-aware framing where relevant: contemplative practices
  can surface traumatic material; trauma-sensitive teachers (David
  Treleaven, Willoughby Britton, Kristin Neff) have developed
  protocols that should be referenced where the book is offering
  practice-instruction to general audiences.
- Vulnerability populations (history of psychosis, severe
  dissociation, active eating disorder, recent acute trauma)
  warned that intense practice may be contraindicated or warrant
  professional support alongside.

### Additional Guardrails

- **Mystery without obscurantism.** Sacred subjects may properly
  resist articulation (apophatic theology, koans, the
  nondual / "neti neti" tradition); but mystery is not a substitute
  for clear thought where clear thought is possible. The prose
  distinguishes "this is properly beyond articulation" from "I
  have not bothered to articulate this."
- **Sentimentality is not reverence.** Sacred subjects demand
  precision; saccharine prose weakens rather than honours them.
  Specific image, specific story, specific text — these carry
  weight that "moving" / "powerful" / "transformational" abstractions
  do not.
- **Original-language terms used carefully.** Sanskrit, Pali, Arabic,
  Hebrew, Aramaic, Greek, Tibetan, Chinese terms that carry meaning
  not capturable in English: define them on first use, transliterate
  consistently, italicise per house style. Don't use them
  decoratively for spiritual flavour; use them where the term does
  work the English cannot.
- **Cultural context for practices.** A practice that emerged in a
  specific cultural / religious context (Tibetan tantric practice,
  Sufi dhikr, Jewish meditation, Christian contemplative prayer,
  yogic asana) carries that context; presenting it stripped of
  context, as universal-spiritual-technique, is a form of
  appropriation that erases the tradition's claim on it.
- **Honest about tensions within the author's own tradition.** Most
  traditions have substantial internal debate, contested doctrine,
  and disagreements between schools; honest representation of one's
  own tradition includes those tensions rather than presenting a
  monolithic "what we believe."
- **Currency disclosure where it matters.** Religious-history
  scholarship updates; contemplative-science research updates;
  current state of inter-religious dialogue evolves. Date the
  scholarship being engaged; signpost where currency matters for
  the reader's ongoing learning.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Serene and contemplative palettes work across
  the category — deep blues / indigos, gold / amber, ivory / cream,
  warm earth tones (terracotta, ochre, sienna), tradition-specific
  hues (saffron / orange for Buddhist and Hindu, dark green for
  Islamic, deep purple / red for Christian liturgical) where
  invoked carefully. Avoid saturated commercial palettes that
  signal self-help over reflection.
- **Typography:** Elegant serif (Garamond, Adobe Caslon, Bembo,
  Sabon) for theology / devotional / traditional positioning where
  the typography signals considered prose and continuity with
  tradition. Restrained sans-serif (Avenir, Sofia Pro) for
  contemporary / accessible / interfaith / secular-spirituality
  positioning. Calligraphic / brush-lettered display fonts for
  meditation / contemplative / Eastern-philosophy titles where
  the typography itself can carry tradition (carefully — avoid
  pastiche calligraphy that imitates rather than respects the
  source).
- **Imagery:** Three dominant traditions:
  1. **Symbolic / iconographic** — a single resonant symbol from
     the tradition (a cross, a Buddha figure, a candle, a mandala,
     hands in prayer, calligraphy, sacred geometry); strong for
     tradition-specific titles. Calibrate carefully: religious
     symbols carry weight and using them outside their tradition
     can read as appropriation.
  2. **Natural / contemplative** — light through trees, water
     surface, mountain, sky, sunrise, candle flame; strong for
     contemplative / meditation / interfaith / nature-spirituality
     titles where the visual signals reflection without committing
     to a specific tradition.
  3. **Abstract / typographic** — pure typography, abstract pattern,
     calligraphic mark; strong for theology, religious history,
     and titles where the argument is the draw rather than a
     visual hook. Frequently the most timeless choice for
     scholarly titles.
- **Mood:** Contemplation. The cover should signal "this book
  invites reflection" — not "this book solves your life problems"
  (self-help register), not "this book is exclusive insider truth"
  (cult / high-control register). The reader picking up a religion-
  spirituality title is in a reflective register; the cover should
  meet them there. Restraint usually outperforms ornament.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Devotional / Daily Practice | Tradition-specific palette and imagery (a single symbolic object, a candle, a sacred space); often series-mark or liturgical-year cue; serif typography signals continuity with devotional tradition |
| Spiritual Memoir / Faith Journey | Memoir cover language — symbolic object, atmospheric place, or face — adapted for the spiritual register; warm or muted palette; typography literary rather than ecclesial |
| Meditation / Contemplative | Calmer / more contemplative palette (sage, dusty blue, cream); abstract / natural imagery (water, breath-like flow, single object); restrained typography; no figurative imagery of practitioner that might mismatch reader |
| Theology / Faith Formation | Substantial-feeling cover (heavier weight, often serif on subtle background); tradition-appropriate visual cues (cross, Hebrew letter, calligraphic Arabic, dharma wheel) used carefully; subtitle clarifies the doctrinal angle and audience |
| Comparative Religion / Academic | Often pure typography or restrained symbolic imagery to avoid privileging one tradition; scholarly serif; subtitle establishes the comparative scope; series styling common where part of an academic press list |
| Eastern Philosophy & Practice | Tradition-respectful imagery (carefully — avoid pastiche); calligraphic-influenced typography sometimes effective; warmer palette (saffron, ochre, indigo); subtitle clarifies the bridge ("a Western introduction to..." / "for contemporary practitioners") |
| Religious History / Criticism | Scholarly cover language — typography-led or archival-imagery-led; restrained palette; substantial subtitle establishing the angle ("the historical Jesus", "the origins of..." , "the making of..."); often relates more to history-publishing visual conventions than to religion-publishing ones |

### Typography Rules

- **Title:** 30–50% of cover area. Religion / spirituality titles
  often work as evocative phrase or single resonant word ("Silence",
  "The Sabbath", "Wild Mercy", "Dark Night"); descriptive titles
  also legitimate ("Mere Christianity", "The Case for God"). The
  title must read at thumbnail.
- **Subtitle:** Often essential. Does the descriptive work the
  title leaves abstract — the author's tradition / position, the
  book's mode (memoir / theology / comparative / historical), the
  audience. "An Anchor for the Soul in Anxious Times". "Reflections
  on Faith and Doubt". "A Buddhist's Guide to Christianity".
  Subtitle calibration is particularly important in this category
  because reader self-selection by tradition / mode is the buying
  decision.
- **Author name:** Larger for established author-brands within the
  tradition (Lewis, Nouwen, Lamott, Thich Nhat Hanh, Pema Chödrön,
  Tippett, Armstrong); smaller for unestablished authors with
  credentials in subtitle. Author qualifications signalling
  tradition-internal authority (clergy title, academic position,
  monastic ordination, decades of practice) shape this category's
  reader trust.
- **Series / publisher cue:** Religious / spiritual publishers
  (Sounds True, Shambhala, IVP, Eerdmans, HarperOne, Orbis, Jewish
  Lights, Paulist, etc.) often have visual-identity conventions
  that signal their position to category readers; new titles within
  series typically inherit the visual language. Edition / "Updated
  for [year]" applicable mainly for re-issued classics.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Devotional / Daily Practice | Kindle Store > Kindle eBooks > Religion & Spirituality > [Specific Tradition] > Worship & Devotion (or > Christian Books & Bibles > Christian Living > Devotionals; equivalent paths for other traditions) |
| Spiritual Memoir / Faith Journey | Kindle Store > Kindle eBooks > Biographies & Memoirs > Religious (with Religion & Spirituality > [Tradition] secondary) |
| Meditation / Contemplative | Kindle Store > Kindle eBooks > Religion & Spirituality > Buddhism (for Buddhist meditation) OR Religion & Spirituality > New Age & Spirituality > Meditation (for secular / cross-tradition) OR > Christian Books & Bibles > Christian Living > Spiritual Growth (for contemplative Christian) |
| Theology / Faith Formation | Kindle Store > Kindle eBooks > Religion & Spirituality > [Specific Tradition] > Theology (or equivalent path within tradition's category tree) |
| Comparative Religion / Academic | Kindle Store > Kindle eBooks > Religion & Spirituality > Comparative Religion |
| Eastern Philosophy & Practice | Kindle Store > Kindle eBooks > Religion & Spirituality > Buddhism / Hinduism / Taoism (per primary tradition); Religion & Spirituality > Eastern as fallback |
| Religious History / Criticism | Kindle Store > Kindle eBooks > Religion & Spirituality > Religious Studies (and History > World > Religious for historical-anchored titles) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Christianity (specific) | Christian Books & Bibles > Theology / Spiritual Growth / Christian Living / Bible Study (per content) |
| Buddhism (specific) | Religion & Spirituality > Buddhism > Tibetan / Zen / Theravada / Mahayana / Pure Land |
| Judaism (specific) | Religion & Spirituality > Judaism > Theology / Holidays / History / Sacred Writings |
| Islam (specific) | Religion & Spirituality > Islam > Theology / Sunnism / Shi'ism / Sufism / Qur'an |
| Hinduism (specific) | Religion & Spirituality > Hinduism > Sacred Writings / History / Theology |
| New Age / spiritual but not religious | Religion & Spirituality > New Age & Spirituality > [Mysticism / Mindfulness / etc.] |
| Self-help / personal-growth crossover | Self-Help > Spiritual / Personal Transformation |
| Memoir-led spiritual narrative | Biographies & Memoirs > Memoirs > Personal Memoirs (with Religious as secondary) |

### Keyword Recommendations

- The specific tradition or denomination
  ("Catholic spirituality", "Reform Jewish", "Sufi practice",
  "Theravada Buddhist", "evangelical Christian", "Vedanta")
- The mode of the book
  ("daily devotional", "spiritual memoir", "comparative religion",
  "theology for laypeople", "meditation guide", "religious history")
- The reader's stage / state
  ("seeker", "deconstruction", "doubt", "spiritual formation",
  "new convert", "long-time practitioner", "interfaith")
- The practice or theme
  ("contemplative prayer", "mindfulness", "lectio divina",
  "loving-kindness", "centering prayer", "Sabbath", "fasting",
  "prayer practice")
- Comparable author / brand for discoverability
  (readers of Thich Nhat Hanh, readers of C.S. Lewis, readers of
  Karen Armstrong, readers of Pema Chödrön, readers of Henri Nouwen)
- Mode-of-engagement cue
  ("for skeptics", "for seekers", "for those leaving the church",
  "for anyone who has wondered...")
- Avoid generic single-word terms ("faith", "spirituality",
  "religion", "God") in isolation — they drown in algorithmic
  noise; prefer compound phrases combining tradition + mode +
  audience-state
- Avoid framing-traps as keywords ("authentic", "true", "the
  real meaning of...") — they signal proselytising or insider-
  truth-claims that narrow the audience
