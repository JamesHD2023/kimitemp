---
name: plottr-import
description: "Import a Plottr project into Ideorix Non-Fiction — beats become chapter outline entries, characters become Key Figures, places become Subject Context, timeline preserved into the Research Bible"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **File role:** This is the user-facing skill. The technical implementation protocol lives in `plottr-importer.md` (same folder) — loaded by reference once the user triggers an import.


> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Plottr Import (Non-Fiction)

Bring your Plottr outline straight into Ideorix Non-Fiction. The importer
parses your beats, characters, places, subplots, and timeline, then
builds a starter Research Bible ready to feed into chapter generation.
Plottr is an OUTLINE-ONLY tool — there are no chapters yet, only the
structural blueprint. The importer skips straight to Research Bible
review and hands off to chapter generation as soon as you approve it.

**Works best for:** narrative non-fiction projects where Plottr is a
natural fit — memoir, biography, true crime, narrative history,
investigative journalism, historical non-fiction, and creative
non-fiction. Plottr's beat/character/timeline model maps cleanly onto
these forms. For heavily source-driven academic or reference works
(popular science, textbook, how-to), the imported structure is a
starting point — you'll flesh out the Research Bible's source and
evidence sections after import.

## What it does

| Task | What happens |
|------|-------------|
| **Beats → chapter outline** | Main Plot beats become Section 9 (Chapter Outline) entries. The engine groups them into chapters using your chosen length tier (3-4 beats per chapter). Each beat becomes a sub-section inside its chapter. |
| **Storylines → argument threads** | Non-Main-Plot tracks (e.g. "Case Timeline", "Expert Interviews") become argument threads woven into the chapters at the appropriate beat position. |
| **Template tracks → structure beat** | Plottr beat sheet templates (Hero's Journey for memoir, Three-Act for narrative non-fiction) populate the STRUCTURE BEAT field of each Section 9 chapter. |
| **Characters → Key Figures** | Each Plottr character becomes a full Section 7 (Key Figures) entry — name, aliases (from Nickname), role in the argument, credentials derived from job/age/education fields. |
| **Alias preservation** | Your character nicknames (with parenthetical context) flow through to the Expert Tracker — critical for "how did they sign their letters" and "what did contemporaries call them". |
| **Places → Subject Context** | Each Plottr place becomes a Section 5 (Subject Context) entry for geographic and institutional scope. |
| **Day headers → Timeline** | Plottr's day-grouped timeline becomes Section 6 (Timeline / Chronology). |
| **Reduced Phase 1 setup** | Skips outline source, structure type, and chapter count questions (already provided). Only asks for what Plottr doesn't record: category, dialect, length tier, research scope, citation style, voice profile, pen name. |
| **Research-side starter fields** | Creates empty placeholders for Section 4 (Key Sources), Section 10 (Source Assignments), and Section 11 (Counter-Arguments) — these can't come from Plottr; you populate them during Research Bible review. |
| **Hand off to Research Bible review** | The assembled Research Bible is presented for approval. Once approved, you proceed to chapter generation with the full Outline Conformance Agent in place. |

## How to start

Say any of:
- "Import from Plottr"
- "Import my Plottr project"
- "Bring my Plottr outline across"
- "Plottr import"
- "I have a Plottr project"
- "I planned my book in Plottr"

Or pick **Import Project** from the Writers Studio or Full Creative Suite
menu, then choose **Plottr** as the source.

## How to prepare your Plottr export

Before running the importer:

1. Open your project in Plottr
2. **File → Export → Word document**
3. Tick the defaults (Outline, Characters, Places, Notes)
4. Save the resulting `.docx` file
5. Place the `.docx` in `~/Documents/Ideorix-Projects/imports/` (the
   importer finds it automatically) or have the full file path ready

**Why Word export and not the native `.pltr` JSON format?** The Word
export is stable across all Plottr versions and subscription tiers,
human-readable, and uses predictable markers that make parsing rock-solid.
The `.pltr` JSON schema has changed across major Plottr releases — Word
export is the more robust target.

## What gets imported

From a Plottr Word export, the importer brings across:

- **Outline beats** — every beat in every storyline, in chronological order, with summaries
- **Storyline tracks** — Main Plot becomes the chapter spine; everything else (subplots/threads) becomes woven argument threads in Section 9
- **Beat sheet templates** — Three-Act, Hero's Journey, etc. — populated as the project's structure beat reference
- **Characters** — name, nicknames (with parenthetical context preserved as aliases), description, category, age, gender, nationality, education, job title, institutional affiliation, habits, goals, fears — all mapped into Key Figures biographical fields
- **Places** — name, description, category, notes, custom fields
- **Day-grouped timeline** — preserved as Section 6 (Timeline / Chronology)
- **Book title** — pulled from the Plottr file name

## What is NOT imported

- **Plottr template instructional content** — the "What does your protagonist want?" boilerplate Plottr pastes into template beats is automatically stripped (everything below `--- Add Your Details Above this Line ---` is recognised and removed)
- **Embedded character images** — Plottr character thumbnails are not used by Ideorix
- **Custom Plottr tags and labels** — v1 ignores them; v2 will support them
- **Multi-book Plottr projects** — currently imports one book at a time; v2 will handle series
- **Manuscript prose** — Plottr doesn't store prose, only structure. To import a written manuscript, use Scrivener import instead.
- **Sources and citations** — Plottr isn't a research tool. Key Sources (Section 4), Source Assignments (Section 10), and Counter-Arguments (Section 11) must be populated during Research Bible review.

## What Ideorix will ask you after import

Plottr doesn't record certain things Ideorix Non-Fiction needs for its
research pipeline. After the import completes, you'll be asked for:

1. **Category** — Memoir, Biography, True Crime, History, Popular Science, etc. — controls which category plugin loads (research standards, fact-check rules, citation format)
2. **Subcategory** — finer category (e.g. Military History under History)
3. **Dialect** — US or GB English
4. **Length tier** — controls the chapter grouping heuristic (how many beats per chapter)
5. **Research scope** — shallow / standard / deep — how exhaustively the Research Bible is built out post-import
6. **Citation style** — Chicago / MLA / APA / Harvard / Footnotes
7. **Content sensitivity level** — for true crime, memoir with living persons, politically sensitive topics
8. **Target audience expertise** — general reader / informed reader / specialist
9. **Voice profile** — attach an existing Authority Voice profile, build one now, or skip
10. **Pen name** — attach an existing pen name, create one, or skip

Skipped (Plottr already provides the answer):
- Outline source — Plottr is the outline
- Structure type — template tracks already detected
- Chapter count — derived from beat count + length tier grouping

## What you get back

A fully populated Ideorix Non-Fiction project workspace ready for chapter generation:

```
~/Documents/Ideorix-Projects/{Your Title}/
├── project-config.md              Project metadata + setup answers
├── manuscript/                    (empty — chapters generated next)
├── engine-data/
│   ├── research-bible.md          Starter Research Bible from Plottr data
│   ├── sources.md                 Empty source database (populate during review)
│   ├── figures.md                 Key Figures from Plottr characters
│   ├── places.md                  Location entries from Plottr places
│   ├── outline.md                 Section 9 chapter outline
│   ├── structure-beat.md          Section 9 STRUCTURE BEAT template tracks
│   └── imports/
│       └── plottr-export/         Original .docx (kept for reference)
├── marketing/
└── ...
```

From there you go straight into Phase 2C (Research Bible review). Once
you've populated Section 4 (Key Sources), Section 10 (Source Assignments)
and Section 11 (Counter-Arguments), the project enters Phase 3 (chapter
generation) with the Outline Conformance Agent watching every brief
against the chapter outline you imported from Plottr. No setup phase to
slog through — Plottr already did the structural work.

## Why this is uniquely valuable

Narrative non-fiction writers plan their books carefully. Memoirists
storyboard emotional arcs. Biographers map subject chronologies. True
crime writers track case timelines. With this importer, that planning
work isn't wasted — it becomes the **structural spine of the Research
Bible** that the Outline Conformance Agent uses to keep every chapter
on plan. The chain:

> **Plan narrative in Plottr → Import to Ideorix Non-Fiction → Research Bible populated with your structure → Write with the Outline Conformance Agent enforcing your plan → Manuscript that delivers what you planned.**

That workflow doesn't exist anywhere else for non-fiction.

## Research vs outline — what Plottr can and can't do

Plottr is a **story architecture** tool. It's excellent for narrative
structure but not designed for source management or argument mapping.
After import, expect to spend meaningful time in Research Bible review
fleshing out:

- **Section 4 — Key Sources & Evidence Base**: Plottr doesn't track sources
- **Section 10 — Source Assignments**: Plottr has no concept of citations-per-chapter
- **Section 11 — Counter-Arguments**: Plottr has no concept of opposing positions
- **Section 12 — Research Gaps**: Plottr has no concept of "what you don't know yet"

These are the non-fiction-specific sections. The Plottr importer populates
everything Plottr *does* track (structure, chronology, characters,
places) and leaves these empty for you to fill in during review. The
Research Bible review process is where you convert a narrative outline
into a researched argument.

> Protocol: `plottr-importer.md`
