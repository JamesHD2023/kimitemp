---
name: methodological-appendix
description: "Builds a publisher-ready methodological appendix from the verification ledger, research bible, speculative content map, and manuscript prose — operationalised definitions, data sources consolidated, studies summary table, reproducibility checklist, methods & limits digest. Optional Stage 14 of the non-fiction editorial pipeline; recommended for academic / policy / scholarly orientation projects."
version: "2.6.10"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

# Methodological Appendix Builder

## Purpose

Produce a publisher-ready methodological appendix that
consolidates the manuscript's evidentiary apparatus into a
single reference document. Third-party reviews of academic
non-fiction consistently request this consolidation — both
as a credibility signal (it makes methods explicit) and as
a practical reproducibility tool (readers, journalists,
fact-checkers, policy analysts can verify specifics in
minutes rather than hours).

The five things reviewers ask for, every time:

1. Operationalised definitions of any classification
   frameworks the manuscript relies on (NOVA, citation
   styles, taxonomies, scoring rubrics)
2. Consolidated data-source provenance (every dataset /
   survey / archive / database with year, version, access
   notes)
3. Cited studies summary table (authors, year, journal,
   design, sample size, effect size where applicable, key
   findings)
4. Reproducibility checklist — 3-5 quick verification
   checks any reader can run in 10 minutes
5. Methods & limits digest (consolidated methodological
   caveats from across the prose)

The appendix is built from existing project artifacts
rather than newly authored content. It is a structured
re-presentation of material the manuscript already
contains, consolidated for the publisher's reference.

## File Location Discipline (MANDATORY — HARD GATE — runs FIRST)

**Output files:**

- `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-methodological-appendix.docx`
  (publisher-ready DOCX deliverable, formatted for direct
  publisher submission)
- `~/Documents/Ideorix-Projects/[Title]/engine-data/methodological-appendix.md`
  (engine reference copy in Markdown, paired with the
  verification ledger and speculative content map)

These outputs MUST be written to the canonical project's
subfolders, NOT to the parent
`~/Documents/Ideorix-Projects/` folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline and
`export-and-publish.md` § File Location Discipline for the
binding gate. **HARD GATE — BLOCKING.**

## When to Use

- **Stage 14 of the editorial pipeline** (after Stage 13
  Publication Readiness verdict = READY). This is the
  default invocation; the appendix is built from a
  manuscript that has already cleared the verification
  ledger and Stage 13 gate, ensuring consistency between
  the appendix and the prose.
- **On-demand:** "Build the methodological appendix" /
  "Generate the publisher-ready appendix" / "Run Stage 14".
- **As part of Phase 6 Delivery:** the appendix is an
  optional but strongly recommended deliverable for
  projects with academic / policy / scholarly orientation.
  For trade-non-fiction or memoir, it may be unnecessary.

## Required Inputs

The builder reads (and is conditioned on the prior existence
of):

1. `engine-data/verification-ledger.md` — every cited
   specific with class (VERIFIED / SPECULATIVE), pinned
   source URL/DOI for VERIFIED, prose-marker phrasing for
   SPECULATIVE, chapter / section reference, verification
   timestamp.
2. `engine-data/research-bible.md` — Sections 4 (Key
   Sources), 5 (Subject Context), 6 (Timeline), 7 (Key
   Figures), 9 (Chapter Outline). Frameworks operationalised
   here.
3. `engine-data/speculative-content-map.md` — list of
   SPECULATIVE entries by chapter / section.
4. The manuscript chapter files in `manuscript/chapters/`
   — for extracting methodological caveats and hedging
   language (Section E source).
5. `engine-data/sources.md` — full source ledger with
   provenance.

If any required input is missing, the builder halts and
flags the missing input rather than fabricating content.
The appendix is a CONSOLIDATION of existing artifacts, NOT
new content generation.

## The Five Sections

### Section A — Frameworks Operationalised

For every classification framework, taxonomy, analytical
scheme, or scoring rubric the manuscript depends on,
provide:

- Name and source of the framework (with citation)
- Operationalised definition as the manuscript actually
  applies it (not just the framework's general definition,
  but how this specific manuscript used it)
- Decision rules / coding criteria where applicable
- Edge cases and how the manuscript handled them
- Citation to the framework's primary source(s)
- Chapter / section references where the framework is
  first introduced and where it is applied

Example for a manuscript using NOVA classification:

```
NOVA Classification (Monteiro 2009, 2010, 2019)

Group 1 — Unprocessed or minimally processed foods
  Definition: [as applied in this manuscript]
  Examples (UK products): [if relevant]
  Coding rules for ambiguous products: [where the
    manuscript drew the line]

Group 2 — Processed culinary ingredients
  [ditto]

Group 3 — Processed foods
  [ditto]

Group 4 — Ultra-processed foods
  Definition: [as applied]
  The three diagnostic markers used in this manuscript:
    1. [marker 1]
    2. [marker 2]
    3. [marker 3]
  Coding rules for edge cases (e.g., bread, yoghurt,
    fermented foods): [as applied]

Citations:
  - Monteiro CA. 2009. Public Health Nutrition 12(5):729-31.
  - Monteiro CA et al. 2010. Cad. Saúde Pública 26(11):2039-49.
  - Monteiro CA et al. 2019. Public Health Nutrition 22(5):936-41.

First introduced: Chapter 2, §2
Applied across: Chapters 4, 5, 11, 14, 16
```

For trade non-fiction with no formal frameworks, this
section may be brief (or omitted). For policy / academic
work, it is the appendix's most-consulted section.

### Section B — Data Sources Consolidated

Every dataset, survey, archive, database, or institutional
data source referenced in the manuscript:

- Source name and provider
- Year / version / accession date / collection period
- Access notes (publicly available URL, institutional
  access, FOIA disclosure number, paywall, archive
  location)
- Geographic / temporal scope
- Used for which claims (with chapter / section reference)

This consolidates the verification-ledger.md content into a
publisher-readable table. Where the verification ledger has
fine-grained per-citation entries, Section B aggregates by
SOURCE (one row per dataset, with all the claims that draw
from it listed).

```
| Source | Provider | Year | Access | Scope | Used in |
| ------ | -------- | ---- | ------ | ----- | ------- |
| NDNS Years 9-11 | Public Health England / FSA | 2016-2019 | gov.uk public download | UK adult / child diets | Ch 4 §2; Ch 16 §1 |
| NHANES 2017-2018 | CDC | 2017-2018 | cdc.gov public | US adult diets | Ch 4 §3 |
| ENSANUT 2018-19 | INSP Mexico | 2018-2019 | insp.mx public | Mexican adult diets | Ch 11 §3 |
| US Right to Know FOIA archive | USRTK | 2015-2024 | usrtk.org | AND internal documents | Ch 14 §2; Ch 16 §1 |
[etc.]
```

### Section C — Studies Cited Summary Table

Every peer-reviewed study cited in the manuscript:

```
| Lead author | Year | Journal | Vol/pp | DOI | Design | n | Key finding | Cited in |
| ----------- | ---- | ------- | ------ | --- | ------ | - | ----------- | -------- |
| Hall KD et al. | 2019 | Cell Metabolism | 30:67-77 | 10.1016/j.cmet.2019.05.008 | Inpatient RCT crossover | 20 | UPF arm consumed +508 kcal/day; +0.9 kg in 14 days | Ch 5 §1; Ch 8 §3 |
| Berry SE et al. | 2020 | Nature Medicine | 26:964-73 | 10.1038/s41591-020-0934-0 | Twin/observational PREDICT-1 | 1,002 | Personalised glycaemic response variability | Ch 10 §2 |
| Srour B et al. | 2019 | BMJ | 365:l1451 | 10.1136/bmj.l1451 | NutriNet-Santé cohort | 105,159 | UPF intake associated with cardiovascular events | Ch 8 §3 |
[etc.]
```

For each entry, the verification timestamp from the audit
ledger is also recorded so the publisher can confirm when
each citation was last verified.

### Section D — Reproducibility Checklist

3-5 quick verification checks any reader, journalist, or
fact-checker can run in 10 minutes. Each check is specific,
named, and points to a verifiable primary source. Examples:

```
1. **Hall RCT verification**
   Locate Hall et al. 2019 at Cell Metabolism July 2019
   (DOI 10.1016/j.cmet.2019.05.008). Confirm: 28-day
   inpatient crossover, n=20, +508 kcal/day on UPF arm.

2. **NOVA classification rules**
   Locate Monteiro CA et al. 2019 at Public Health
   Nutrition 22(5):936-41. Cross-reference the three
   diagnostic markers used in this manuscript (Chapter 2 §3)
   against the paper's Table 1 definitions.

3. **SDIL implementation date**
   Verify the Soft Drinks Industry Levy implementation
   date as 6 April 2018 via gov.uk (HMRC).

4. **Mexico soda tax effect size**
   Locate Colchero MA et al. 2017 at Health Affairs
   36(3):564-71 (DOI 10.1377/hlthaff.2016.1231). Confirm
   year-2 reduction figure of 9.7%.

5. **Industry-funded science bias finding**
   Locate Lesser LM et al. 2007 at PLoS Medicine 4(1):e5
   (or the manuscript's primary source for the
   five-times-bias finding). Confirm methodology and
   effect size.
```

The checklist length is calibrated to manuscript size and
academic intensity — 3 checks for trade non-fiction, 5 for
policy / academic. Each check picks a HIGH-STAKES claim
(one that anchors the manuscript's argument) and provides
the exact verification path.

### Section E — Methods & Limits Digest

A consolidated paragraph (or short series of paragraphs)
summarising methodological caveats from across the prose:

- What the manuscript can claim with confidence (the
  causal-evidence anchors: RCTs, dose-response cohort
  studies, mechanistic experiments)
- What it argues circumstantially (institutional patterns,
  case-study evidence, industry-document analysis)
- What it acknowledges as inferential or projection (the
  SPECULATIVE content layer, with reference to the
  speculative-content-map)
- What the limits of the evidence base are (the
  manuscript's own self-acknowledged limits — e.g., "no
  community ethnography", "no household-level
  observational data", "limited geographic representation
  outside North America / UK / Brazil")
- What further research would clarify (research gaps the
  manuscript identifies)

This digest is sourced from the prose's existing hedging
language; it does NOT introduce new caveats. It is a
re-presentation that lets the publisher / reader see the
manuscript's epistemic posture in one place.

## Construction Workflow

```
1. Read engine-data/verification-ledger.md
2. Read engine-data/research-bible.md (Sections 4-7, 9)
3. Read engine-data/speculative-content-map.md
4. Read engine-data/sources.md
5. Read manuscript chapter files (for Section E digest)

6. Build Section A:
   - Identify every classification framework / taxonomy /
     scoring rubric mentioned in research-bible §4 (Key
     Sources) or applied in chapter prose
   - For each, extract the operationalised definition from
     the manuscript's first introduction passage
   - Record decision rules, edge cases, citations

7. Build Section B:
   - Aggregate verification-ledger.md entries by SOURCE
     (one row per dataset, not per claim)
   - Cross-reference research-bible §5 (Subject Context)
     for institutional sources
   - Format as Markdown table

8. Build Section C:
   - Filter verification-ledger.md to peer-reviewed studies
     only (papers with DOIs)
   - For each, extract: authors, year, journal, vol/pp,
     DOI, study design, n, key finding, cited locations
   - Format as Markdown table
   - Pin the verification timestamp from the ledger

9. Build Section D:
   - Identify 3-5 high-stakes claims (one per major
     argumentative anchor)
   - For each, write a specific verification path with
     exact source location
   - Reproducibility check should be runnable in <10 min

10. Build Section E:
    - Grep manuscript chapter files for hedging language
      ("we cannot claim", "this evidence does not", "the
      limits of this analysis", "would require further
      research", "the manuscript does not assert", etc.)
    - Aggregate by argumentative claim
    - Synthesise into 4-paragraph digest:
      (a) confident claims (b) circumstantial claims
      (c) speculative content (d) acknowledged limits
      (e) research priorities

11. Render to Markdown (engine-data copy)
12. Render to DOCX (publisher-ready, with proper
    typography, table formatting, citation style matching
    the manuscript's chosen style — Chicago / APA / MLA /
    Harvard)

13. Verify on-disk integrity (Bash + word count check)
14. Update project-config.md with Stage 14 completion timestamp
15. Update pipeline-checkpoint.md
```

## Output Format

The DOCX is structured as a numbered appendix that can be
included in the manuscript's print edition or delivered to
the publisher as a supplementary document:

```
APPENDIX A — METHODOLOGICAL FRAMEWORK
  A.1 Frameworks Operationalised
  A.2 Data Sources
  A.3 Studies Cited
  A.4 Reproducibility Checklist
  A.5 Methods & Limits

[front matter: title, manuscript reference, verification
timestamp, build date]
[references: complete bibliography of cited studies, with
verification ledger as supplementary material]
```

The Markdown engine-copy is the same content in a format
suitable for re-rendering or for inclusion in future
catalog-overview reports.

## Anti-Patterns This Appendix Closes

The appendix is a structural answer to recurring
third-party-review feedback:

- **"Provide a methodological appendix on survey→NOVA
  mapping"** — Section A operationalises the framework
- **"A consolidated data table would help reproducibility"**
  — Section B aggregates data sources
- **"A short methodological annex on the RCT design"** —
  Section C summarises study designs
- **"Reproducibility checks a journalist could run quickly"**
  — Section D provides them
- **"Where the book attributes corporate strategy, indicate
  archive locations or accession details"** — Sections B
  and C carry FOIA / archive / institutional access
  references
- **"Acknowledge what the book does and does not claim"**
  — Section E consolidates the manuscript's epistemic
  posture in one place

## Integration with Phase 6 Delivery

When this appendix is built, `export-and-publish.md` § Phase
6 Delivery includes the methodological appendix in the
publisher handoff package alongside:
- The manuscript itself
- The verification ledger
- The speculative content map
- The Stage 13 readiness statement
- The methodological appendix (this file's output)
- KDP / publisher metadata

The publisher's reviewer can therefore review the manuscript,
confirm verified claims via the ledger, see speculative
content marked in the map, AND consult a single appendix
that answers the standard "how was this argued?" questions.

## Version Stamp Convention

When this spec or its outputs are substantively updated,
bump the `version:` field in this file's frontmatter to
match the plugin version that introduced the change. See
`verification-discipline.md` for the full version-stamp
convention.
