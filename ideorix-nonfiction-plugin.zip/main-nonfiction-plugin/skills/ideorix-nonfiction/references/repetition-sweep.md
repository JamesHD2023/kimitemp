---
name: repetition-sweep
description: "Cross-chapter argument-repetition detection and consolidation pass. Catches recurring arguments / phrases / examples that appear across multiple chapters and could be tightened by replacing 1-2 instances with cross-references rather than full restatements. Stage 4.5 of the editorial pipeline (between Developmental Editor and Alpha Reader)."
version: "2.6.10"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

# Repetition Sweep

## Snapshot before overwrite (v2.7.41 HARD GATE — `destructive-mutation-snapshot.md`)

When this sweep applies consolidation edits (replacing repeated
passages with cross-references), the affected chapters are
overwritten in place. Per the canonical destructive-mutation
snapshot protocol, every chapter the sweep mutates MUST be
snapshotted to `engine-data/snapshots/ch{NN}.pre-repetition-sweep.{ISO-timestamp}.md`
BEFORE the overwrite. See `destructive-mutation-snapshot.md`
for the full HARD GATE sequence.

Snapshot path appears in the sweep's per-chapter consolidation
report so the user has a reversion path for any consolidation
they later disagree with.

## Purpose

Catch and tighten cross-chapter argument repetition —
arguments / phrases / examples that recur across multiple
chapters and could be consolidated by replacing 1-2
instances with cross-references rather than full
restatements. This is a **structural-editorial** pass, not
a sentence-level one: the Copy Editor stage handles
sentence echoes and word-level redundancy; this pass
handles ARGUMENT repetition.

The pattern third-party reviewers consistently flag:

- "Some sections repeat the same structural claims across
  multiple chapters"
- "Repetitions of the [theme phrase] across several
  chapters slow the reading"
- "The same argumentative move appears with different
  rhetorical wrapping in three places"
- "Each repetition adds a new documentary example, which
  is valuable, but the synthesis could be tightened to
  reduce redundancy"

The pass identifies repetition candidates and produces a
consolidation report; the editorial pipeline (or the user)
decides which instances to keep, which to convert to
cross-references, and which to delete. The pass does NOT
auto-apply consolidations — repetition is sometimes
deliberate (rhetorical reinforcement, pedagogical
scaffolding for non-linear readers, anchoring a recurring
motif). The judgement of which instances to tighten
remains editorial.

## File-Write Hygiene (MANDATORY)

When the sweep applies consolidation edits to chapter
files, the chained-Edit truncation safeguard documented in
`core-pipeline.md` § Chained-Edit Truncation Safeguard
applies in full: prefer Write over chained Edit for
chapter-scale rewrites, cap individual Edit replacements at
~2 KB, run `scripts/word-count-check.sh` after every
chapter file the sweep edits, and verify on-disk integrity
via Bash before declaring the sweep complete.
**HARD GATE — BLOCKING.**

## File Location Discipline (MANDATORY)

**Output file:** `~/Documents/Ideorix-Projects/[Title]/engine-data/reports/repetition-sweep-{YYYY-MM-DD}.md`

The sweep's consolidation report MUST be written to the
canonical project's `engine-data/reports/` subfolder, NOT
to the parent Ideorix-Projects folder, the agent's working
directory, or any sandbox / temporary path. See
`core-pipeline.md` § File Location Discipline.
**HARD GATE — BLOCKING.**

## When to Use

- **Stage 4.5 of the editorial pipeline** (between
  Developmental Editor / Stage 4 and Alpha Reader / Stage
  5). The DevEditor produces structural recommendations;
  Stage 4.5 catches what the DevEditor flagged at the
  argument-recurrence level and proposes consolidations.
- **On-demand:** "Run repetition sweep" / "Tighten cross-
  chapter repetition" / "Find repeated arguments".
- **As a manuscript-clinic pass** for projects that have
  already shipped earlier editorial stages and are
  preparing for publication.

## Detection Approach

The sweep operates in three parallel detection lanes —
each picks up a different scale of repetition.

### Lane 1: Phrase-Level Recurrence

Identify exact-or-near-exact phrases that appear across
multiple chapters:

- Multi-word noun phrases (3+ words) that appear ≥3 times
  across ≥2 chapters
- Distinctive metaphors or rhetorical phrases (e.g., "the
  system is designed to profit from confusion", "the
  industry playbook", "the four-pillar architecture")
  appearing in multiple chapters
- Specific numerical claims or named studies cited in
  multiple chapters (these are usually intentional —
  flagged but not auto-recommended for consolidation)

For each phrase candidate, the sweep records:
- The exact phrase
- Chapter / section / line numbers of every occurrence
- A "first introduction" location (where the phrase is
  defined or first deployed with full force)
- "Echo" locations (where it reappears with less context)

### Lane 2: Argument-Level Recurrence

Identify recurring argumentative MOVES that appear in
different rhetorical wrapping across chapters. This is
harder to detect mechanically — it requires reading the
manuscript and identifying the underlying claim being
made, not the surface phrasing.

Common argument-level recurrences:

- The same causal claim made in three different chapters
  with different examples
- The same critique pattern (e.g., "industry-funded
  research is biased") repeated in multiple chapters with
  different exemplars
- The same reform-limit observation (e.g., "reformulation
  cannot solve this") restated across chapters
- The same defining distinction (e.g., NOVA Group 4
  diagnostic markers) re-explained at multiple points

For each argument-level recurrence, the sweep records:

- The argumentative claim (in plain summary)
- Where the argument is FIRST made in full
- Where it RECURS (with brief description of each
  recurrence's specific contribution)
- Whether each recurrence adds new evidence or merely
  restates

### Lane 3: Example / Vignette Recurrence

Identify case studies, vignettes, named-event references,
or illustrative examples that appear in multiple chapters.

- A specific named company / person / event referenced in
  multiple chapters (these are often intentional — the
  manuscript builds out a character or institution across
  the arc)
- A specific anecdote or scene that recurs (e.g., "the
  OXXO morning queue", "Hall's metabolic-ward week")
- A specific archive or document referenced multiple
  times (e.g., FOIA disclosure X, internal memo Y)

For each example-level recurrence, the sweep records:

- The example
- Where it is first introduced in full
- Where it recurs and what the recurrence is asked to do

## Consolidation Report Output

The sweep's deliverable is a structured report at
`engine-data/reports/repetition-sweep-{YYYY-MM-DD}.md`
with three sections corresponding to the detection lanes,
plus a fourth Recommendations section.

```
# Repetition Sweep Report — {Title} — {Date}

## Section 1: Phrase-Level Recurrences

| Phrase | Occurrences | First introduction | Echo locations | Recommendation |
| ------ | ----------- | ------------------ | -------------- | -------------- |
| "the four-pillar architecture" | 7 | Ch 3 §2 | Ch 5, 11, 14, 17, 18, 20 | **CROSS-REFERENCE** echoes after Ch 5 |
| "profit from confusion" | 4 | Ch 1 §3 | Ch 5, 7, 14 | **CONSOLIDATE** — keep Ch 1 + Ch 14, remove from 5, 7 |
| [etc.] | | | | |

## Section 2: Argument-Level Recurrences

[Each argumentative recurrence with chapter map]

## Section 3: Example / Vignette Recurrences

[Each example-level recurrence with chapter map]

## Section 4: Recommendations

For each recurrence flagged, one of:

- **KEEP AS-IS** — repetition is deliberate (rhetorical
  reinforcement, pedagogical scaffolding, motif)
- **CROSS-REFERENCE** — keep the first full instance, replace
  later instances with explicit cross-references ("as
  introduced in Chapter 3 §2", "see the playbook diagram in
  Chapter 5")
- **CONSOLIDATE** — keep two instances (typically first +
  most-developed); remove others
- **DELETE** — remove all but the first
- **TIGHTEN** — keep all instances but compress later ones

The user (or the editorial pipeline) decides which
recommendation to action per row.
```

## Workflow

```
1. Read all manuscript chapter files in
   manuscript/chapters/

2. Lane 1: Phrase-level detection
   - Build a frequency map of all 3+ word phrases
   - Flag phrases appearing ≥3 times across ≥2 chapters
   - Cross-reference against research-bible §11 motif map
     (if present) — manuscripts may explicitly designate
     motif phrases as intentional
   - Exclude: section headings, table headers, citation
     short-forms, established terminology (NOVA Group 4,
     UPF, etc.)

3. Lane 2: Argument-level detection
   - Read each chapter and extract the argumentative claims
     made in that chapter
   - Build a claim map: which chapters make which claims
   - Flag claims made in 3+ chapters
   - For each flagged claim, characterise whether each
     recurrence adds (a) new evidence (b) new framing
     (c) new application or merely restates
   - Pure restatements are stronger candidates for
     consolidation than evidence-additive recurrences

4. Lane 3: Example / vignette detection
   - Index named entities and specific incidents across
     chapters (people, organisations, events, places,
     archives, documents)
   - Flag entities appearing in 3+ chapters
   - Note: cross-chapter references to the same entity
     are often deliberate (the manuscript builds a thread)
     — distinguish "introductions of" from "callbacks to"

5. Synthesise the consolidation report at
   engine-data/reports/repetition-sweep-{YYYY-MM-DD}.md

6. Present the report to the user (or to the editorial
   pipeline) for action

7. If the user authorises consolidations, apply them via
   the file-write hygiene protocol (Write-not-chained-Edit
   for chapter-scale rewrites, word-count-check after
   each, on-disk verification)

8. Update pipeline-checkpoint.md and project-config.md
   with Stage 4.5 completion timestamp
```

## Calibration: When Repetition Is Earned

The sweep distinguishes between problematic and earned
repetition. Earned repetition includes:

- **Pedagogical scaffolding** — defining a key concept the
  first time and reminding readers in later chapters where
  the manuscript has been off the topic for a stretch
- **Rhetorical motif** — a phrase the manuscript
  intentionally uses as a recurring device (and the
  research-bible motif map records as such)
- **Cross-chapter callbacks** — referring back to an
  earlier example to illustrate a new claim
- **Cumulative argument** — making the same observation
  about three different cases to demonstrate a pattern
  (the pattern itself is the point; the repetition is
  evidence-additive)
- **Reader-onboarding** — a key term re-introduced at a
  natural break in the book where new readers might enter
  (e.g., a new Part)

Problematic repetition is:

- **Argument-level restatement** without new evidence or
  new application — the same claim made three different
  ways across three chapters with no incremental value
- **Phrase echo** of a distinctive rhetorical phrase that
  becomes tic-like through over-use
- **Vignette over-use** — a vivid example deployed once
  effectively, then deployed two more times for less
  return

The sweep's recommendations distinguish these. KEEP AS-IS
covers earned repetition. CROSS-REFERENCE / CONSOLIDATE /
DELETE / TIGHTEN cover the problematic cases.

## Anti-Patterns This Sweep Closes

- **Cumulative-argument-fatigue** — readers tire of
  watching the same argument restated. Cumulative is fine;
  cumulative-restatement is wearying.
- **Motif-tic** — a distinctive phrase that becomes a
  verbal tic when over-used.
- **Rhetorical-wrapping recurrence** — the same point
  re-skinned in different rhetorical clothing across
  chapters, hoping the reader doesn't notice it's the
  same point.
- **Example over-deployment** — a vignette that earned
  its place once but was reused for diminishing returns.

## Integration with Editorial Pipeline

Stage 4.5 (this sweep) sits between Stage 4 (Developmental
Editor) and Stage 5 (Alpha Reader). The DevEditor's
structural feedback often surfaces "feels repetitive in
places" as a high-level note; Stage 4.5 turns that note
into a concrete consolidation list with specific
recommendations.

If the user skips Stage 4.5, Stages 5-12 still run
normally — but the Alpha / Beta Reader stages may register
the repetition as an emotional-engagement dip
("attention drifted in Chapters 5-7"), and the
post-pipeline manuscript may carry repetition that
third-party reviewers flag.

The sweep is therefore RECOMMENDED for any non-fiction or
fiction project ≥40,000 words — at scale, cross-chapter
repetition is mechanical and worth catching mechanically.
For shorter works, manual editorial judgement typically
suffices.
