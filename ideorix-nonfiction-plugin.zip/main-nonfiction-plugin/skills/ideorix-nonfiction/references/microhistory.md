---
name: microhistory
description: "Category plugin for Microhistory. a single object, event, place, or concept used as a lens to illuminate a broader historical period or process"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Microhistory. Category Plugin

## Metadata

| Key | Value |
|-----|-------|
| Category ID | `microhistory` |
| Display Name | Microhistory |
| Parent Group | History |
| Typical Word Count | 55,000 – 90,000 |
| Audience | Curious general readers, history enthusiasts seeking fresh angles, book-club readers, gift-book buyers |
| Tone Spectrum | Engaging and surprising; scholarly substance with a storyteller's voice; the pleasure of unexpected connections |
| Comparable Titles | *Salt* (Kurlansky), *The Professor and the Madman* (Winchester), *Longitude* (Sobel), *Cod* (Kurlansky), *A Day in the Life of Medieval England* (Mortimer) |

## Subcategory Options

When the user selects **Microhistory**, prompt them to choose a subcategory:

| ID | Subcategory | Description |
|----|-------------|-------------|
| `object-history` | Object History | A single commodity, invention, or artefact (salt, cod, the pencil, the colour mauve) as a lens into global history |
| `event-history` | Event History | A single day, week, year, or circumscribed event that illuminates an era (1066, the year 1000, a single trial, a shipwreck) |
| `place-history` | Place History | A single location. a city block, an island, a building, a crossroads. and the history that flowed through it |
| `concept-history` | Concept History | The biography of an idea, a word, a unit of measurement, or a cultural practice across time |
| `biography-as-microhistory` | Biography-as-Microhistory | An obscure or forgotten individual whose life cracks open the world they inhabited |

### Subcategory-Specific Notes

- **Object History**: The object is the thread, not the subject. Every chapter must show how the object connects to larger forces (economics, empire, technology, culture).
- **Event History**: Establish what makes this event a meaningful prism. Avoid a mere blow-by-blow account; extract significance.
- **Place History**: Layer time. show what happened on this spot across centuries or decades. The genius loci must emerge.
- **Concept History**: Trace how the concept changed meaning across contexts. Avoid abstraction; anchor each stage in specific people and places.
- **Biography-as-Microhistory**: The individual matters because they are a window, not because they are exceptional. Ordinariness is the point.

## Structural Architect Instructions

### Recommended Structures

1. **Radial**: The micro-subject sits at the centre; chapters radiate outward to different aspects of the macro-world it illuminates. Each chapter departs from the subject and returns to it. Best for object and concept histories.
2. **Chronological Journey**: Follow the subject through time. from origin to present (or from obscurity to significance). Best for object histories and biography-as-microhistory.
3. **Concentric Circles**: Begin with the smallest scale (the object, the room, the moment) and expand outward in each chapter to wider and wider contexts. Best for place and event histories.
4. **Braided Narrative**: Interweave the micro-story with the macro-story, alternating between close-up and wide-angle chapters. Best when the connection between micro and macro needs sustained argument.

### Standard Chapter Architecture

- **The hook**: Open with the micro-subject in a vivid, specific moment. A chunk of salt in a Roman soldier's pay. A fish on a Newfoundland drying rack. A forgotten inventor bent over a workbench.
- **The pivot**: Reveal the unexpected connection. how does this small thing link to a vast historical process?
- **The macro lens**: Explore the broader history that the micro-subject illuminates. This is the chapter's analytical core.
- **Evidence and story**: Weave together primary sources, scholarly interpretation, and narrative storytelling. Every claim must be supported; every page must be readable.
- **The return**: Circle back to the micro-subject. Show how the macro context changes our understanding of the small thing we started with.
- **The bridge**: Connect to the next chapter's departure point. Microhistories thrive on momentum and the pleasure of discovery.

### Required Supplementary Material

- **Introduction**: Must explicitly state the book's premise. why this micro-subject, and what larger story does it unlock?
- **Maps**: Where the subject has a geographic journey (trade routes, migration paths, exploration), provide maps.
- **Timeline**: A chronological overview of the micro-subject's journey through history.
- **Illustrations**: Photographs, engravings, diagrams, or reproductions of the micro-subject and its contexts.
- **Endnotes**: Prefer endnotes; the tone should invite general readers, not intimidate them.
- **Bibliography**: Single list organised alphabetically is acceptable; divide into sections if source types are diverse.
- **Index**: Include the micro-subject and all its variant names, plus people, places, and concepts.

## Content Writer Craft Rules

1. **The micro must illuminate the macro.** This is the genre's iron law. Every chapter must demonstrate a clear, substantive connection between the small subject and a larger historical force. If a passage does not connect back, cut it.
2. **Surprise is the engine.** The reader picks up a book about salt or a pencil because they want to be surprised by how much history hides in the mundane. Deliver unexpected connections on every page.
3. **Earn your digressions.** Tangents are permitted. encouraged, even. but only if they ultimately loop back to the central subject. A digression that does not reconnect is a flaw.
4. **Write with sensory detail.** Describe how the object looks, feels, smells, tastes. Describe the place. its weather, its sounds, its architecture. Microhistory lives in the concrete.
5. **Show the web of connections.** Draw explicit links between chapters and themes. The reader should feel the subject's tendrils reaching into every corner of human life.
6. **Keep the pace brisk.** Microhistories are often shorter than standard histories. Move efficiently. Each chapter should feel like an essay. tight, purposeful, and complete.
7. **Wear scholarship lightly.** The research should be deep, but the prose should be welcoming. Avoid academic jargon. Write for the reader who picks this book up in an airport.
8. **Use the present tense strategically.** Occasional shifts to present tense can create immediacy. "It is 1492, and a block of salt is worth more than a human life in parts of West Africa." Use sparingly for maximum effect.
9. **Humanise every era.** Even when tracing an object or concept across millennia, anchor each era in specific named individuals. A Roman salt merchant. A medieval cod fisherman. A Victorian chemist.
10. **End with resonance, not a lecture.** The conclusion should leave the reader seeing the everyday world differently. noticing the small things that contain hidden histories. Do not moralize; illuminate.

### PROSE RHYTHM MAPPING
- Ch 1 hook: the OBJECT or EVENT that opens the world. precise, specific, curious; the reader holds it in their mind's eye
- Sentence length: medium (14-20 words) as the baseline; the microhistorian's rhythm is brisk, curious, and propulsive
- The reader should feel "I had no idea..." by page 3. surprise is the genre's engine; deliver it early and often
- Tension ≥4 from chapter 1. not dramatic tension but intellectual tension: "How does this small thing connect to everything?"
- Sensory detail about the micro-subject from the opening paragraph: how it looks, feels, smells, weighs, tastes
- The pivot from micro to macro is the genre's defining rhythm: close-up on the object, then pull back to reveal the world it unlocks
- Evidence integration wears its scholarship lightly: deep research rendered in accessible, welcoming prose
- Pacing is brisk. microhistories are shorter than standard histories; every paragraph earns its place or gets cut
- Deploy unexpected connections at regular intervals: the reader's delight in discovery sustains engagement across chapters
- Short paragraphs for revelations and surprising facts; longer paragraphs for the macro-historical context they illuminate
- The "why should I read this book" question is answered by the first pivot: "This tiny thing changed the world, and here is how"
- Reader engagement across information-dense passages: technical detail (chemistry, economics, manufacturing) arrives through story, not lecture
- Authority delivery through the pleasure of expertise: the writer knows this subject deeply and shares that knowledge generously
- Paragraph rhythm mirrors the radial structure: depart from the micro-subject, explore the macro, return to the micro with new understanding
- Humanise every era through named individuals: a Roman merchant, a medieval fisherman, a Victorian chemist. specific people in specific places
- Strategic present-tense shifts for maximum immediacy: "It is 1492, and a block of salt is worth more than a human life"
- Digressions earn their place by looping back: every tangent must return to the central subject within the chapter
- Chapter endings create the pleasure of anticipation: the micro-subject is about to enter a new era, a new geography, a new connection

## Quality Check Criteria

| Criterion | Standard | Method |
|-----------|----------|--------|
| Micro-Macro Connection | Every chapter demonstrates an explicit, substantive link between the micro-subject and a larger historical process or theme | Connection audit per chapter |
| Factual Accuracy | All dates, names, quantities, and events verified against reliable sources | Cross-reference check |
| Narrative Engagement | The book sustains the reader's curiosity; no chapter feels like filler or a dead end | Pacing review and beta-reader feedback |
| Digression Discipline | Every tangent reconnects to the central subject within the same chapter or the next | Tangent-tracking audit |
| Source Depth | Research is evident and substantive, not merely superficial or anecdotal | Source audit. minimum 2 endnotes per 1,000 words |
| Sensory Specificity | Physical descriptions of the micro-subject and its contexts appear in every chapter | Detail inventory |
| Chronological Clarity | The reader always knows when and where they are, even as the narrative moves across centuries and continents | Temporal-spatial signposting check |
| Surprise Factor | Each chapter contains at least one genuinely unexpected fact, connection, or revelation | Novelty audit |

## Source Requirements

### Minimum Source Standards

- **Primary sources**: At least 20% of citations must reference primary material. trade records, patent filings, archaeological reports, contemporary accounts, visual and material evidence.
- **Cross-disciplinary sources**: Microhistory often requires sources from outside traditional history. science, economics, anthropology, art history, material science. Embrace cross-disciplinary research.
- **Material evidence**: When writing about an object, engage with the physical object itself. museum collections, archaeological specimens, manufacturing processes. Do not rely solely on textual sources about the object.
- **Geographic breadth**: If the micro-subject has a global story, sources must reflect that breadth. not only Western European and North American perspectives.

### Source Hierarchy

1. Material evidence. the object, place, or artefact itself and its physical context
2. Primary documents directly related to the micro-subject (trade ledgers, patents, recipes, legal records)
3. Contemporary accounts and descriptions by people who encountered the subject
4. Scholarly monographs and articles from relevant disciplines
5. Scientific and technical literature (for object and concept histories)
6. Popular histories and journalistic accounts (use with source criticism)
7. Museum catalogues, exhibition materials, and curatorial scholarship

### Citation Format

- Chicago Manual of Style, Notes-Bibliography system (17th edition or later).
- Endnotes with full bibliographic details on first reference; shortened form thereafter.
- For material evidence, cite the object's location, catalogue number, and any relevant conservation or analysis reports.
- Bibliography may be a single alphabetical list or divided by chapter, depending on the diversity of sources.

## Category-Specific Guardrails

### Absolute Rules

1. **The micro must illuminate the macro.** If a chapter or section does not demonstrate a clear connection between the micro-subject and a larger historical process, it must be revised or removed. This is the genre's defining contract with the reader.
2. **No tangents without return.** Every digression must loop back to the central subject. A fascinating aside about sixteenth-century shipbuilding is only justified if it reconnects to the book's micro-subject.
3. **No false significance.** Do not exaggerate the micro-subject's historical importance to justify the book's existence. Honest framing builds trust with the reader.
4. **No invented details.** If the specific details of a historical moment are unknown, say so. Do not fill gaps with imagination.

### Scope Discipline

- **Define the lens clearly.** The introduction must establish precisely what the micro-subject is and what it is not. A book about "salt" must define whether it covers all salt, table salt, salt taxation, or some other scoping.
- **Maintain focus.** The micro-subject must appear in every chapter, even when the narrative has zoomed out to the macro level. If the subject disappears for more than a few pages, the book has lost its thread.
- **Know when to stop.** Microhistories can become unfocused as authors discover ever more connections. Not every connection deserves inclusion. Curate ruthlessly.

### Sensitive Content Guidelines

- **Exploitation and suffering**: Many micro-subjects (sugar, cotton, rubber, spices) are entangled with slavery, colonialism, and exploitation. Address these histories fully and honestly. Do not reduce human suffering to a colourful anecdote in the story of a commodity.
- **Indigenous knowledge**: When the micro-subject's history involves indigenous peoples' knowledge, practices, or resources, acknowledge their role and agency. Do not frame indigenous contributions as mere background to European "discovery."
- **Environmental impact**: Where the micro-subject has environmental consequences (overfishing, deforestation, mining), address them substantively.

### Common Pitfalls to Avoid

- **The everything book**: Trying to connect the micro-subject to every aspect of human history. Be selective. Depth on fewer connections beats shallow breadth.
- **Boring origins chapter**: "Chapter 1: The Chemistry of Salt" can be deadly. Lead with story and weave in technical detail, not the reverse.
- **Losing the thread**: The most common structural failure. Every chapter must visibly connect to the micro-subject.
- **Treating the subject as inherently fascinating**: It is not. The writer's job is to reveal the fascination through unexpected connections and vivid storytelling.

## Cover Design Specifications

| Element | Guideline |
|---------|-----------|
| Imagery | The micro-subject itself, rendered beautifully. a close-up photograph, an elegant illustration, or a period engraving. Simplicity is power. A single cod. A grain of salt. A compass. |
| Typography | Clean, modern serif or transitional serif fonts. The title (often a single word) should be bold and large. Subtitle explains the scope ("A World History", "The Biography of...", "How X Changed Everything"). |
| Colour Palette | Bold, often built around the subject itself. sea blue for a maritime subject, warm gold for a spice, industrial grey for a manufactured object. A single strong colour against white or cream can be very effective. |
| Layout | Object-centred. The micro-subject dominates the cover. Minimal clutter. These books sell on curiosity, and the cover must provoke the question: "How can a whole book be about that?" |
| Back Cover | 100–120 word synopsis that teases the surprising connections. 2–3 endorsement quotes emphasising readability and revelation. Author credentials. |
| Spine | Single-word or short title must be legible and eye-catching. Consider a small illustration of the micro-subject on the spine. |

## KDP Category Mapping

### Primary Categories

| BISAC Code | Category Path |
|------------|---------------|
| HIS000000 | HISTORY / General |
| HIS036000 | HISTORY / Social History |

### Subcategory-Specific Mappings

| Subcategory | BISAC Code | Category Path |
|-------------|------------|---------------|
| Object History | HIS000000 | HISTORY / General (+ relevant thematic category, e.g., SCI000000 for science-related objects) |
| Event History | HIS000000 | HISTORY / General (+ era-specific category) |
| Place History | HIS000000 | HISTORY / General (+ region-specific category) |
| Concept History | HIS000000 | HISTORY / General (+ PHI000000 Philosophy if applicable) |
| Biography-as-Microhistory | BIO000000 | BIOGRAPHY & AUTOBIOGRAPHY / General (+ HIS000000) |

### Keyword Recommendations

- Include the micro-subject as a standalone keyword (e.g., "salt", "cod", "longitude")
- Pair the subject with "history" (e.g., "history of salt", "salt world history")
- Include "microhistory" as a keyword for readers who seek the genre specifically
- Target curiosity-driven phrases ("how X changed the world", "the hidden history of X", "the story of X")
- Include era and region terms relevant to the book's scope
- Add comparable-title author names as keywords where appropriate (e.g., "like Kurlansky", "fans of Simon Winchester")

### Amazon Browse Categories

- Books > History > World
- Books > History > Social History
- Books > Humor & Entertainment > Trivia & Fun Facts (if the book has a lighter tone)
- Books > Science & Math > History & Philosophy (for science-related objects)
- Kindle Store > Kindle eBooks > History > World
- Kindle Store > Kindle eBooks > Nonfiction > Social Sciences
