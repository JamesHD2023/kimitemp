---
name: story-analysis
description: Reverse-engineers existing non-fiction books into reusable structural blueprints — extracts thesis architecture, evidence patterns, voice profile, chapter-cluster structure, and market positioning, then produces genericized templates an author can use to scaffold an original work
version: "2.0"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Story Analysis Protocol — Non-Fiction (Structure Scanner)

## Purpose

Analyse an existing non-fiction book to extract its structural DNA —
thesis architecture, evidence patterns, voice profile, chapter-cluster
logic, sourcing density, and market positioning. Then produce a
**genericized template** an author can use as a blueprint to scaffold
a similarly-shaped original work.

This is NOT plagiarism assistance. The output strips the source book's
specific subject, claims, and content, leaving only the structural
skeleton — the same way "longform argumentative non-fiction with
narrative case studies" describes *Range*, *Quiet*, and *Atomic
Habits* simultaneously.

## When to Use

- **"I want to write something like {Book X}"** — Analyse the
  reference book, extract its structure, use as a template for the
  new project
- **Study mode** — Author wants to understand what makes a non-fiction
  book work (thesis design, evidence rhythm, voice register)
- **Category research** — Extracting patterns from multiple books in a
  category (popular science, memoir, business, history, etc.)
- **Self-analysis** — Author wants to analyse their own completed
  manuscript against a recognisable template
- Triggered by `analyze-a-book.md` (the user-facing skill)

## Two-Phase Process

### Phase 1: Chapter-by-Chapter Micro-Analysis

Process each chapter individually (split by H1 headers, chapter
markers, or the source book's own chapter divisions).

#### System Prompt

```
You are an expert non-fiction analyst performing a structural autopsy
of a published non-fiction book. Your job is to extract the craft
decisions, not to judge the content.

For each chapter, produce a precise structural analysis that another
non-fiction author could use to understand HOW this book works at the
chapter level.

Be specific. Quote the text. Name the techniques. A useful analysis is
one that teaches craft, not one that summarises subject matter.

Per chapter, identify:

1. **Chapter purpose in the larger argument** — what does this chapter
   contribute to the book's thesis? (Setup / case / counter-case /
   synthesis / payoff / methodological aside / etc.)

2. **Opening technique** — does the chapter open with: a scene? a
   case study? a question? a counter-intuitive claim? a personal
   anecdote? a data point? a quote? Identify and name the move.

3. **Argument structure used** — deductive / inductive / abductive /
   analogical / comparative / case-stack? Which structure does this
   chapter run on?

4. **Evidence types and density** — for the chapter, count and
   classify the kinds of evidence used (primary source / secondary
   source / data / personal anecdote / case study / interview / quote
   from authority / counter-example). What is the evidence density
   per page?

5. **Voice and register** — sentence-rhythm signature; jargon level;
   pronoun discipline (I / you / we / one); hedging vs. assertion
   ratio.

6. **Internal scaffolding** — does the chapter use sub-headings?
   numbered lists? boxed callouts? footnotes vs. endnotes? Identify
   and quantify.

7. **Chapter-ending technique** — does it close with: a question? a
   foreshadow of the next chapter? a synthesis? a case payoff? a
   reflection? Identify and name.

8. **Length and pacing** — word count; ratio of dense-argument prose
   to lighter narrative / reflection prose; placement of dense and
   light passages within the chapter.
```

#### Per-Chapter Output Format

```json
{
  "chapter_number": N,
  "chapter_title": "...",
  "word_count": N,
  "purpose_in_argument": "setup | case | counter-case | synthesis | payoff | methodological aside | other",
  "opening_technique": "scene | case_study | question | counter-intuitive_claim | personal_anecdote | data_point | quote | other",
  "opening_quote": "first 1-2 sentences for reference",
  "argument_structure": "deductive | inductive | abductive | analogical | comparative | case_stack",
  "evidence": {
    "primary_sources": N,
    "secondary_sources": N,
    "data_points": N,
    "personal_anecdotes": N,
    "case_studies": N,
    "interviews": N,
    "authority_quotes": N,
    "counter_examples": N,
    "density_per_page": "low | medium | high"
  },
  "voice": {
    "sentence_rhythm": "short | varied | long-winded | scholarly",
    "jargon_level": "lay | educated-lay | semi-technical | technical | academic",
    "pronoun_discipline": "I | you | we | one | mixed | drift",
    "assertion_vs_hedging_ratio": "high-assertion | balanced | high-hedging"
  },
  "scaffolding": {
    "subheadings": N,
    "numbered_lists": N,
    "boxed_callouts": N,
    "footnotes_or_endnotes": "footnote | endnote | inline | none",
    "footnote_count": N
  },
  "ending_technique": "question | next-chapter_foreshadow | synthesis | case_payoff | reflection | other",
  "ending_quote": "last 1-2 sentences for reference",
  "pacing_note": "where dense passages and lighter passages sit within the chapter"
}
```

### Phase 2: Whole-Book Synthesis

After all chapters are analysed, produce a synthesis covering the
book's overall structural pattern.

#### System Prompt

```
You are now synthesising the chapter-by-chapter analyses into a
whole-book structural blueprint.

Identify:

1. **Central thesis architecture** — What is the book's one-sentence
   thesis? Where in the book is it stated explicitly? How does the
   chapter-cluster structure prove (or pressure-test) it?

2. **Chapter-cluster logic** — Do the chapters group into named
   parts? If so, what is each part's function in the larger
   argument? If not, what is the implicit grouping?

3. **Argument-progression curve** — Does the argument escalate,
   spiral, accumulate cases, or pressure-test the thesis through
   counter-arguments? Map the curve.

4. **Evidence rhythm** — What proportion of evidence is primary vs.
   secondary? Where does the book lean heaviest on each? Are
   anecdotes / data / case studies / quotes interleaved on a
   pattern, or distributed evenly?

5. **Voice profile (full-book)** — Sentence-rhythm signature;
   jargon strategy (when explained, when assumed); pronoun
   discipline; how the author earns trust over the course of the
   book.

6. **Scaffolding density curve** — Where do the heaviest sub-
   headings, callouts, lists, and footnotes sit? Are they front-
   loaded, evenly distributed, or back-loaded?

7. **Pacing curve** — Plot the dense-argument vs. lighter-narrative
   ratio across the book. Where does the book "breathe"?

8. **Market-positioning signals** — From the structural choices
   alone (without subject knowledge), what audience does this book
   target? What publishing path? What comp-title cluster?
```

#### Whole-Book Output Format

```markdown
# Structural Blueprint — {Source Book Title}

## One-Sentence Thesis (extracted)
{thesis}

## Where the thesis is stated explicitly
{chapter / page reference, or "not stated explicitly — implied across the work"}

## Chapter-Cluster Structure

| Part | Chapters | Function in Argument |
|---|---|---|
| Part I — {name or "implicit"} | Ch. 1–N | setup / framing |
| Part II — ... | ... | ... |

## Argument-Progression Curve

{2–3 paragraph description of how the argument develops, escalates,
or accumulates. Cite the chapters where pivotal turns occur.}

## Evidence Rhythm

| Evidence Type | Whole-Book Count | Density Pattern |
|---|---|---|
| Primary sources | N | front-loaded / even / back-loaded / clustered |
| Secondary sources | N | ... |
| Data points | N | ... |
| Personal anecdotes | N | ... |
| Case studies | N | ... |
| Interviews | N | ... |
| Authority quotes | N | ... |
| Counter-examples | N | ... |

## Voice Profile

- **Sentence rhythm:** {short / varied / long-winded / scholarly}
- **Jargon strategy:** {when explained, when assumed}
- **Pronoun discipline:** {I / you / we / one — and any drift}
- **Assertion-to-hedging ratio:** {…}
- **Trust-earning technique:** {how the author builds reader trust
  across the book — transparency about limitations, engagement with
  counter-views, etc.}

## Scaffolding Density Curve

{Plot of subheading / callout / list / footnote density across the
book. Front-loaded? Evenly distributed? Back-loaded? What does the
pattern signal?}

## Pacing Curve

{Where the book runs dense and where it lets the reader breathe.
Cite chapters and the dense / light proportion at key points.}

## Market-Positioning Signals

- **Implied audience:** {…}
- **Implied publishing path:** {trade / academic / hybrid / self-pub}
- **Comp-title cluster:** {3–5 books this book sits with on a shelf}

---

## GENERICIZED TEMPLATE

(This is the deliverable an author can use as a blueprint for an
original work in the same shape.)

### Recommended chapter-cluster structure

{N parts, with each part's function specified — but stripped of the
source book's specific topic.}

### Recommended argument curve

{Paragraph describing the recommended argument-progression pattern
this template would support.}

### Recommended evidence mix

{Suggested proportions of evidence types for an original work
following this template.}

### Recommended voice register

{Sentence-rhythm guidance, jargon strategy, pronoun discipline.}

### Recommended scaffolding density

{Subheading / callout / list / footnote guidance for an original
work in this template.}

### Recommended pacing pattern

{Where to run dense; where to let the reader breathe.}

---

## How to use this template

1. Take the genericized template above.
2. Plug in YOUR own thesis, evidence, and subject matter.
3. The structural shape will produce a book in the same family as
   the source — without copying any of the source's specific content.
4. Use this as the starting brief for `research-bible.md` Phase 1
   (Concept & Thesis), then `structural-architect.md` for the chapter
   outline.
```

## Output Files

```
Ideorix-Projects/{Project-Title}/
├── analysis/
│   ├── source-book-name.md                 (the source's metadata)
│   ├── per-chapter-micro-analysis.md       (Phase 1 output)
│   ├── structural-blueprint.md             (Phase 2 output)
│   └── genericized-template.md             (the template the user takes forward)
```

## Cross-Skill Handoffs

| Author Says | Handoff To |
|-------------|-----------|
| "Use this template to plan my book" | `research-bible.md` (Phase 1, with the genericized template loaded as the brief) |
| "Build me a chapter outline based on this template" | `structural-architect.md` |
| "How does my manuscript compare to this template?" | `manuscript-clinic.md` (with the source book's structural blueprint loaded as a comparison reference) |
| "Find me 3 more books like this one to analyse" | `market-scout.md` (request comp-title cluster, then re-run Story Analysis on each) |

## Branding

All Story Analysis output must begin with:

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

The badge "STRUCTURAL BLUEPRINT — NON-FICTION" should appear in the
header of all output documents.
