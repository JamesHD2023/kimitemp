---
name: business-entrepreneurship-category
description: "Category plugin for Business and Entrepreneurship non-fiction. provides structural, craft, quality, and guardrail instructions for all pipeline agents"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Business / Entrepreneurship. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | `business` |
| Display Name | Business / Entrepreneurship |
| Parent Group | Business & Finance |
| Complexity Tier | Moderate–High |
| Typical Word Count | 55,000–80,000 |
| Reader Expectation | Actionable frameworks supported by real-world evidence |
| Tone Baseline | Authoritative yet accessible; practitioner-to-practitioner |

## Subcategory Options

When the user selects this category, prompt for a subcategory. Each subcategory adjusts structural emphasis and source expectations.

| ID | Subcategory | Focus | Typical Structure |
|----|------------|-------|-------------------|
| `startup-venture` | Startup & Venture | Founding stories, fundraising, scaling, product-market fit | Narrative arc from idea to scale with embedded frameworks |
| `leadership-management` | Leadership & Management | Team building, organisational culture, executive decision-making | Principle-per-chapter with illustrative case studies |
| `marketing-sales` | Marketing & Sales | Customer acquisition, brand building, sales systems, digital strategy | Problem-solution pairs with actionable playbooks |
| `strategy-innovation` | Strategy & Innovation | Competitive advantage, disruption theory, business model design | Thesis-driven chapters with analytical deep dives |
| `small-business` | Small Business | Owner-operator concerns, cash flow, local marketing, hiring | Practical guide format with checklists and templates |

### Subcategory Defaults

- If no subcategory is selected, default to `strategy-innovation`.
- If the user's brief spans multiple subcategories, select the dominant one and note secondary influences in the structural plan.

## Structural Architect Instructions

### Core Model: Thesis–Case Study–Framework

Every chapter in a business book should follow this tripartite engine:

1. **Thesis**. Open with a clear, arguable claim about the business topic. The reader must understand within the first two paragraphs what this chapter will prove or demonstrate.
2. **Case Study**. Support the thesis with one or more real-world examples. These must be specific (named companies, named individuals, verifiable timelines) rather than hypothetical.
3. **Framework**. Distil the insight into a reusable model, matrix, checklist, or decision tree that the reader can apply to their own situation.

### Chapter Architecture

```
Chapter [N]: [Compelling Title]

  Opening Hook (300–500 words)
    → Anecdote, surprising statistic, or counterintuitive claim
    → Thesis statement by end of opening section

  Section 1: The Landscape / Context (1,500–2,500 words)
    → Current state of the problem or opportunity
    → Why this matters now (market data, trend analysis)

  Section 2: Case Study Deep Dive (2,000–3,500 words)
    → Primary case study with narrative detail
    → Supporting mini-cases (2–3 paragraphs each)
    → Contrast case: what failure looks like

  Section 3: The Framework (1,500–2,500 words)
    → Visual or textual model
    → Step-by-step application guide
    → Common pitfalls and how to avoid them

  Section 4: Implementation (1,000–1,500 words)
    → "Monday morning" action items
    → Scaling considerations
    → Metrics to track

  Chapter Summary (200–400 words)
    → Key takeaways (3–5 bullet points)
    → Bridge to next chapter
```

### Book-Level Arc

- **Part I (Chapters 1–3):** Establish the problem landscape and the author's central thesis.
- **Part II (Chapters 4–8):** Build the argument through progressive case studies and frameworks.
- **Part III (Chapters 9–11):** Synthesis, advanced applications, and future outlook.
- **Conclusion:** Call to action and resource guide.

### Special Structural Elements

- Include an **Executive Summary** (1–2 pages) before Chapter 1 for time-pressed readers.
- Each chapter must end with a **Key Takeaways** box (3–5 bullets).
- Where applicable, include **Founder/Leader Spotlight** sidebars (300–500 words).

## Content Writer Craft Rules

1. **Voice:** Confident but not arrogant. Write as a knowledgeable peer, not a lecturer. Avoid "I believe" hedging. state positions directly and support them.
2. **Jargon Management:** Define industry terms on first use. If a term is widely understood in business (e.g., "ROI," "MVP"), no definition needed. If domain-specific (e.g., "ARR," "TAM"), provide a brief parenthetical.
3. **Data Presentation:** Integrate statistics into narrative prose. Avoid data dumps. Every number must have context (comparison, trend, or implication).
4. **Anecdotes:** Open at least 60% of chapters with a story. Stories must have a protagonist, a challenge, a turning point, and a resolution or lesson.
5. **Actionability:** Every chapter must contain at least one element the reader can implement within 7 days. Label these clearly.
6. **Transitions:** End each chapter with a conceptual bridge to the next. The reader should feel a logical pull forward.
7. **Sentence Rhythm:** Mix short declarative sentences with longer analytical ones. Avoid consecutive sentences over 30 words.
8. **Analogies:** Use one strong analogy per chapter to make abstract concepts concrete. Avoid sports metaphors unless the subcategory is explicitly sports-business.
9. **Quotations:** Use direct quotes from interviews, published sources, or speeches. Attribute fully. Do not fabricate quotes.
10. **Paragraph Length:** Business readers skim. Keep paragraphs to 3–5 sentences maximum. Use subheadings every 500–800 words.

### Prose Rhythm Mapping

Chapter 1 opens with the problem or opportunity, shown through a specific company
or person. The reader must see a real protagonist in a real situation before any
framework appears. This is where credibility is earned. through narrative precision.

Case-study rhythm: medium sentences (15-22 words) carry the narrative forward,
painting the scene, introducing the protagonist, establishing the stakes. Then
shorter analytical sentences (12-16 words) land the key insights. The pattern
is: story, story, story. insight. Story, story. insight.

Alternate between these two registers throughout the chapter. The narrative
sentences breathe. The analytical sentences punch. Never let analysis run longer
than two consecutive sentences before returning to story. Never let story drift
longer than four sentences without surfacing the point.

Tension minimum: 4. The opening must create genuine suspense about the outcome.
The reader should not know, from the first page, whether this company survived.
Whether this bet paid off. Whether this leader was right.

Pacing guideline: open with a scene (medium sentences, 15-22 words). Establish
the human stakes before introducing the business problem. Let the first data
point arrive no earlier than the fourth paragraph. When the data lands, deliver
it in a short sentence. make the number hit. Then immediately contextualise
with a medium sentence that explains why that number matters.

## Quality Check Criteria

The Quality Check agent must verify the following for business category manuscripts:

| # | Criterion | Pass Condition |
|---|-----------|----------------|
| 1 | Thesis Clarity | Every chapter has a single identifiable thesis stated within the first 500 words |
| 2 | Case Study Verification | All named companies and individuals are real and verifiable; dates and figures are accurate |
| 3 | Framework Consistency | Each framework is internally consistent. steps do not contradict each other |
| 4 | Actionability Score | Every chapter contains at least one concrete, time-bound action item |
| 5 | Data Currency | Statistics and market data are no older than 3 years unless historical context requires it |
| 6 | Source Attribution | All claims of fact have a traceable source; no unsupported generalisations |
| 7 | Jargon Accessibility | No undefined acronym or technical term on first use |
| 8 | Narrative Flow | Chapter-to-chapter transitions are logical; no orphan chapters |
| 9 | Balance of Evidence | No chapter relies on a single case study without acknowledging alternative perspectives |
| 10 | Reader Fatigue Check | No section exceeds 3,500 words without a subheading or visual break |

## Source Requirements

### Minimum Source Thresholds

- **Per chapter:** Minimum 5 distinct sources.
- **Per book:** Minimum 40 unique sources across the manuscript.
- **Primary sources** (interviews, financial filings, company reports): At least 30% of total.
- **Academic/research sources** (peer-reviewed journals, working papers): At least 20% of total.
- **Journalistic sources** (reputable publications): Permitted for context and narrative colour.

### Acceptable Source Types

| Type | Examples | Notes |
|------|----------|-------|
| Company filings | SEC filings, annual reports, investor decks | Preferred for financial claims |
| Academic research | HBR, journals, NBER working papers | Required for theoretical claims |
| Interviews | Author-conducted or published in reputable outlets | Must be attributed and dated |
| Industry reports | McKinsey, Gartner, CB Insights, Statista | Acceptable for market sizing |
| Books | Previously published business books | For historical context and framework lineage |
| News/journalism | FT, WSJ, Bloomberg, The Economist | For narrative colour, not sole evidence |

### Prohibited Sources

- Wikipedia as a primary source (acceptable as a starting point for verification).
- Anonymous blog posts or unattributed Medium articles.
- Social media posts as sole evidence for claims of fact.
- Self-published books without independent verification of claims.

## Category-Specific Guardrails

### Survivorship Bias

- When presenting success stories, **always acknowledge survivorship bias** explicitly. Example: "Company X succeeded with this approach, but it is worth noting that many firms attempted similar strategies without the same outcome."
- Where possible, include a **contrast case**. a company or leader that followed a similar path but failed, with analysis of the divergence.

### Framework Integrity

- All frameworks must be **internally consistent**. If a framework has 5 steps, no step may contradict another.
- Frameworks must be **testable**. the reader should be able to apply the framework and evaluate whether it produces the claimed outcome.
- Do not present frameworks as universal laws. Include scope conditions: "This framework applies best when [conditions]."

### Financial Claims

- Revenue figures, valuations, and growth rates must be sourced to verifiable documents.
- Do not present projections as facts. Clearly label forward-looking statements.
- When discussing company performance, specify the time period and metric definition.

### Advice Liability

- Include a general disclaimer that the book provides educational content, not professional business, legal, or financial advice.
- When recommending specific strategies, note that outcomes depend on context, market conditions, and execution.

### Diversity of Evidence

- Do not rely exclusively on Silicon Valley or US-centric case studies unless the book is explicitly scoped to that market.
- Include international examples where relevant.
- Represent diverse founders, leaders, and business models.

## Cover Design Specifications

| Element | Specification |
|---------|---------------|
| Typography | Bold sans-serif title; author name in lighter weight. Clean, modern hierarchy. |
| Colour Palette | Professional tones. navy, charcoal, white, with one accent colour (teal, gold, or red). Avoid neon or playful palettes. |
| Imagery | Abstract geometric patterns, minimal iconography, or clean photography. No clip art. No stock photos of handshakes. |
| Layout | Title dominant (60%+ of cover real estate). Subtitle in smaller type below. Author name at bottom or top depending on author prominence. |
| Subtitle | Include if the book has a specific framework or promise. Format: "A [Framework/Method] for [Outcome]." |
| Endorsement | If available, one endorsement blurb on the front cover from a recognised business figure. |
| Spine | Title + Author. Legible at thumbnail size. |
| Back Cover | 3–4 bullet points of key promises, one endorsement quote, brief author bio (2–3 sentences), barcode. |

## KDP Category Mapping

### Primary Category Path

```
Kindle Store > Kindle eBooks > Business & Money > Entrepreneurship
```

### Secondary Category Path (select based on subcategory)

| Subcategory | Recommended Secondary KDP Category |
|------------|-------------------------------------|
| `startup-venture` | Business & Money > Entrepreneurship > Startup |
| `leadership-management` | Business & Money > Management & Leadership > Leadership |
| `marketing-sales` | Business & Money > Marketing & Sales > Marketing |
| `strategy-innovation` | Business & Money > Management & Leadership > Strategy & Competition |
| `small-business` | Business & Money > Small Business & Entrepreneurship > Small Business |

### Keyword Recommendations

- Use 7 keyword slots in KDP.
- Include: category-specific term, subcategory term, key framework name, target audience descriptor, comparable author name (if applicable), outcome-oriented phrase, related trending term.
- Example set: `entrepreneurship`, `business strategy`, `startup growth framework`, `founders and CEOs`, `leadership playbook`, `scaling business`, `innovation management`.

### BISAC Codes

| Code | Description |
|------|-------------|
| BUS025000 | BUSINESS & ECONOMICS / Entrepreneurship |
| BUS071000 | BUSINESS & ECONOMICS / Leadership |
| BUS043000 | BUSINESS & ECONOMICS / Marketing / General |
| BUS063000 | BUSINESS & ECONOMICS / Strategic Planning |
| BUS060000 | BUSINESS & ECONOMICS / Small Business |
