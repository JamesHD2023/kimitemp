---
name: export-and-publish
description: "Format your finished non-fiction manuscript for publishing — DOCX/EPUB/PDF export, KDP metadata, and submission-ready files"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*


# Export & Publish

Prepare your finished non-fiction manuscript for publication or submission.

## File Location Discipline (MANDATORY — HARD GATE — applies to every output this flow produces)

**All Phase 6 deliverables MUST be written into the
canonical project folder structure.** Specifically:

- **Manuscript exports** (DOCX, Atticus DOCX, EPUB, PDF,
  RTF, Markdown, SMF) →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}.{ext}`
- **KDP metadata** →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-kdp-metadata.{ext}`
- **Methodological appendix** (CONDITIONAL — academic /
  policy / scholarly orientation projects, produced by
  Stage 14 of the editorial pipeline) →
  `~/Documents/Ideorix-Projects/[Title]/manuscript/{Title}-methodological-appendix.docx`
  (engine reference copy at
  `engine-data/methodological-appendix.md`).
  See `methodological-appendix.md` for the five-section
  builder spec.
- **Marketing assets** (cover concepts, blurbs, social
  pack, query letters, trailer assets) →
  `~/Documents/Ideorix-Projects/[Title]/marketing/...`
- **Editorial / verification reports** generated during
  Phase 6 →
  `~/Documents/Ideorix-Projects/[Title]/engine-data/reports/...`

See `core-pipeline.md` § File Location Discipline for the
full canonical project layout.

**HARD GATE — BLOCKING.** Outputs MUST NOT be written to:

- The agent's working directory
- The parent `~/Documents/Ideorix-Projects/` folder (the
  most common bug — files end up alongside other projects
  instead of inside this project's subfolder, making them
  effectively invisible to the user when looking in the
  project folder)
- A sandbox or temporary path
- Any non-canonical location

The user MUST be able to open every Phase 6 deliverable
in their own file explorer at the canonical project
subfolder the moment processing completes. The Phase 6
Delivery flow has historically been vulnerable to dropping
manuscript exports in the parent `Ideorix-Projects/`
folder rather than the project's `[Title]/manuscript/`
subfolder; this section is the explicit counter-protocol.

When invoking any of the per-format specs below
(`format-docx.md`, `format-epub.md`, etc.), this
File Location Discipline binds them — each format spec
also reiterates its specific destination, but THIS gate
is the authoritative one and supersedes any ambiguity.

## Typography Sweep Gate (MANDATORY — HARD GATE — runs before every prose export)

Before assembling the final manuscript file (DOCX, EPUB, PDF,
SMF, RTF, Markdown, Atticus DOCX), run the pre-export typography
gate against the project. The gate wraps `typography-sweep.sh`
with fail-closed semantics + opt-out handling (v2.7.68+):

```sh
bash scripts/pre-export-typography-gate.sh "{project-root}"
```

When invoked without a specific file, the gate scans every
`engine-data/chapters/ch*.md` automatically. To gate a single
file (per-chapter export), pass the file path as a second arg.

**HARD GATE — BLOCKING.** If the gate fails:

1. Halt the export flow.
2. Report the per-chapter artifact list to the user.
3. Wait for resolution (user normalizes, or explicitly opts-in
   to ASCII target via `--target ascii` re-run).
4. Re-run the gate before proceeding.

**Rationale:** the engine's Edit-tool typographic-fidelity
discipline (`core-pipeline.md` § Edit-Tool Typographic Fidelity)
is preventive — it stops curly-vs-ASCII mismatches from being
inserted during normal Edits. The sweep is the detective layer:
even if an artifact slips through (paste-in, importer, partial
Edit, manual user touch-up), the sweep catches it before any
publishable file is assembled. See `typography-sweep.md` for
the full spec, exit codes, and category list.

**Non-fiction-specific note:** NF citations and footnotes are
**especially vulnerable** to typographic mismatch because
citation strings often round-trip through reference managers
(Zotero, Mendeley, EndNote) that normalize to ASCII, while the
surrounding narrative is curly. The sweep catches the mismatch;
the user can then decide whether to normalize the citation or
accept the inconsistency (some style guides explicitly require
ASCII for in-line citations even in curly-quoted prose).

**Skipped only when:**

- The user has explicitly declared ASCII typography for the
  manuscript (e.g. technical / programming books with heavy
  code blocks). In that case the gate runs with `--target ascii`
  and inverts.

## Available formats

| Format | Use case | Spec |
|--------|----------|------|
| **DOCX** | Industry-standard manuscript format with proper margins and headers | `format-docx.md` |
| **Atticus DOCX** | Formatted for the Atticus authoring tool | `format-atticus-docx.md` |
| **EPUB 3.3 / 3.2** | Universal e-book format for all major retailers | `format-epub.md` |
| **PDF** | Print-ready with proper pagination and trim sizes | `format-pdf.md` |
| **Markdown** | Clean plain text for version control and editing | `format-markdown.md` |
| **RTF** | Rich Text Format for maximum compatibility | `format-rtf.md` |
| **SMF** | Standard Manuscript Format for agent/publisher submission | `format-smf.md` |
| **KDP Metadata** | Amazon Kindle Direct Publishing companion document | `publishing-formats.md` |

For full per-format specifications, see the linked spec for each format.

## How to start

Say any of:
- "Export my manuscript as DOCX"
- "Generate KDP metadata"
- "Prepare my book for Amazon"
- "Format for submission"
- "Create an EPUB"

## Non-fiction specific outputs

All format outputs include the elements that distinguish non-fiction from fiction:

- **Bibliography / References** — formatted per the citation style locked at Q10 (Chicago / APA / MLA / Harvard / Informal)
- **Index** — keyword index for reference works
- **Footnotes / Endnotes** — per citation style selection
- **Table of Contents** — with section depth appropriate to the book

Permissions tracked during research (see `source-management.md` Permissions Tracking) are flagged at Phase 5 Stage 13 (Publication Readiness Assessment) if any are unresolved.

## KDP Package

Generated as a companion `.docx`. The content elements (description, keywords, BISACs, comp titles) are produced by Marketing Expert — see `marketing-and-cover.md` and `marketing-expert.md` for how each is generated. This spec describes what the packaged `.docx` contains:

- **Book information** — title, subtitle (common in non-fiction), author name, publication date
- **Amazon Book Description** (max 4,000 chars) — hook paragraph → premise paragraphs → credentials line → call-to-action
- **7 keyword phrases** — 2 broad / 2 topic / 2 niche / 1 comp-based
- **3 BISAC category recommendations** (non-fiction tree)
- **Pricing suggestion** — Short Form (under 30K) $2.99–$4.99 / Standard (30–60K) $4.99–$9.99 / Comprehensive (60K+) $9.99–$14.99
- **Comparable titles** — 3–5 in the same category, published within 3 years
- **Target audience** — pulled from Q12 setup
- **Cover image prompt** — see `cover-designer.md`

Pricing brackets are independent of the Q6 length tiers — they're market-suggestive based on competitive comp-title data, not derived from setup choices.

> **Tip:** Always run the full editorial pipeline (Phase 5) before exporting. The Stage 13 Publication Readiness Assessment is the gate — if it flags unresolved permissions, missing citations, or unaccounted Research Bible entries, fix those before export.

## Launch Readiness Gate (MANDATORY — v2.7.68+)

Before declaring the project ready to ship — KDP upload, cover
generation, marketing campaign — run the launch readiness gate.
It chains all five constituent Phase 6 gates and reports a single
composite verdict:

```bash
bash scripts/launch-readiness-gate.sh "{project-root}"
```

Constituents (each fails closed independently):
- **Market Scout** — market-pulse.md present + fresh
- **Cover Brief** — structured cover brief per cover-designer.md
- **Marketing Pack** — marketing-brief.docx + 5 core sections + cover dependency
- **KDP Metadata** — KDP file present + required fields + 7 keywords
- **Manuscript Export** — at least one rendered manuscript file in `manuscript/`

If the composite FAILs, re-run each failing constituent gate
directly for its specific diagnostic + ACTION instructions. The
launch readiness gate is the composite check; the constituent
scripts have the prescriptive fixes.

This is the v2.7.68 fix for the Phase 6 LLM-contract gap: cover
+ marketing + KDP + launch were rules Claude was supposed to
follow but nothing verified at the artifact level. The five new
gates make every step a verifiable precondition rather than a
disciplined-Claude assumption.

Opt-outs: `launch_readiness_status: legacy / skip` in
`engine-data/project-config.md`.
