---
name: self-help
description: "Category plugin for self-help and personal development non-fiction. productivity, mindset, relationships, emotional intelligence"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Self-Help / Personal Development. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | self-help |
| Display Name | Self-Help / Personal Development |
| Parent Group | Self-Help & Psychology |
| Typical Word Count | 50,000–70,000 |
| Default Structure | Problem-solution-action framework with recurring reader exercises |
| Citation Style | Endnotes; informal in-text attribution ("Research from Stanford shows...") |
| Audience Baseline | Motivated general reader seeking practical change; no academic background |
| Comparable Titles | James Clear, Brene Brown, Mark Manson, Cal Newport, Gretchen Rubin |

## Subcategory Options

When the user selects Self-Help / Personal Development, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| productivity-habits | Productivity / Habits | Habit formation, time management, focus, systems thinking, deep work | Framework + implementation chapters, progressive skill-building |
| mindset-motivation | Mindset / Motivation | Growth mindset, resilience, purpose, overcoming limiting beliefs, grit | Story-principle-application, transformational arc |
| relationships-communication | Relationships / Communication | Interpersonal skills, conflict resolution, boundaries, empathy, social skills | Scenario-based chapters, dialogue examples, relationship patterns |
| emotional-intelligence | Emotional Intelligence | Self-awareness, emotional regulation, empathy, social awareness, self-management | Assessment-insight-practice structure, case study driven |
| success-goals | Success / Goal Setting | Strategic planning, goal frameworks, accountability, career development, achievement | Step-by-step methodology, milestone chapters, review/adjust cycles |

**Default:** If the user does not specify, use `productivity-habits` conventions as baseline.

## Structural Architect Instructions

### Core Technique: Problem-Solution-Action Framework

Every chapter in self-help must follow the **problem-solution-action** pattern. The
reader arrives with a problem, receives a research-backed solution, and leaves with
a concrete action they can take today. Chapters that inform without enabling action
fail the genre's contract with the reader.

### Chapter Architecture Patterns

1. **The Recognition**. Open with a scenario the reader recognises in their own life.
   A frustration, a pattern, a stuck point. The reader should think: "That's me."
   This is not a generic complaint. it is a specific, vivid description of the problem.
2. **The Reframe**. Introduce a new way of seeing the problem. This is the
   intellectual core: a research finding, a framework, a counterintuitive insight
   that shifts the reader's understanding.
3. **The Evidence**. Support the reframe with research, case studies, and real-world
   examples. The reader needs to trust the solution before they will act on it.
4. **The Method**. Provide the concrete, step-by-step approach. What does the reader
   actually do differently starting tomorrow? This must be specific, not vague
   exhortation.
5. **The Anchor**. End with a memorable summary: a phrase, a principle, a mental
   model the reader can carry with them. Self-help chapters need takeaways that stick.

### Evidence Deployment

- **Research studies:** Social psychology, behavioural economics, neuroscience. Cite
  the researcher, the institution, and the finding. Keep methodology brief.
- **Case studies:** Real or composite stories of people who applied the principle.
  The reader needs to see the method working in a life.
- **Author experience:** Appropriate in moderation. The author's own story adds
  credibility and relatability, but the book is for the reader, not about the author.
- **Counterexamples:** Where the method does not work, or where the common advice
  is wrong. Credibility comes from honesty about limits.

### Brief Template Additions

For each chapter brief, the Architect MUST include:

- **Core Problem:** The specific reader problem this chapter addresses.
- **Reframe/Insight:** The new perspective or framework being introduced.
- **Key Studies:** 2–3 research studies supporting the chapter's central claim.
- **Method Steps:** The concrete action steps (numbered, specific).
- **Case Study Outline:** A narrative example of the method in practice.
- **Common Objections:** Anticipated reader resistance and how to address it.
- **Chapter Takeaway:** The single memorable principle or phrase.
- **Exercise/Action Item:** A specific reader exercise to include.

## Content Writer Craft Rules

### Voice & Tone

- **Direct and warm.** Speak to the reader as a knowledgeable friend, not a guru.
  Use "you" freely. The author is alongside the reader, not above them.
- **Confident but not preachy.** State insights with conviction. Do not hedge
  everything with "maybe" and "perhaps." But also do not promise miracles.
- **Conversational, not casual.** The prose should feel like an intelligent
  conversation, not a transcript of a motivational talk.
- **Empathetic about struggle.** Acknowledge that change is hard. Do not blame the
  reader for their current situation.

### The "You" Contract

- Self-help is a second-person genre. The reader is "you" throughout.
- Mirror the reader's experience: "You've probably tried..." "You know the feeling
  when..."
- Do not overuse "I". the author's stories serve the reader's transformation, not
  the author's ego.

### Research Integration

- Lead with the insight, not the study. "We make better decisions when we're not
  hungry. and there's a striking study that shows exactly why."
- Name the researcher and institution for credibility: "Psychologist Roy Baumeister
  at Florida State University found..."
- Keep methodology brief: "In a study of 1,100 judicial decisions...". the reader
  needs enough to trust the finding, not enough to replicate the study.
- Always connect the research back to the reader's life: "What this means for your
  morning routine is..."

### Action Items & Exercises

- **Every chapter must end with at least one concrete action item.** This is
  non-negotiable in self-help.
- Actions must be specific: not "be more mindful" but "set a 2-minute timer each
  morning and focus on your breathing before checking your phone."
- Format exercises clearly. use bullet points, numbered steps, or boxed callouts.
- Include estimated time commitment: "This exercise takes 5 minutes."

### Story & Anecdote

- Use stories to illustrate, not to pad. Every story must serve the chapter's point.
- Introduce characters with enough detail to be memorable but not so much that the
  story overtakes the teaching.
- Stories should show transformation: before the insight and after.
- Composite characters are acceptable but should be disclosed: "I've combined several
  clients' experiences here."

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the reader's pain point and hope, side by side. The reader
  should feel understood and curious within the first paragraph.
- **Sentence calibration:** Short-medium sentences averaging 12–18 words. Direct, warm,
  authoritative. Every sentence should feel like it is speaking to one person.
- **"You" voice prominent:** The second person is the engine of self-help prose. The
  reader is "you" throughout. not "one," not "people," not "we."
- **One insight per paragraph:** Each paragraph delivers a single actionable insight or
  advances the argument by one clear step. If a paragraph tries to do two things,
  split it.
- **Rhythm pattern:** Alternate between recognition (the reader's experience mirrored
  back) and reframe (the new perspective offered). Mirror, then shift. The reader
  should feel seen before being challenged.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In self-help, tension
  is the gap between the reader's current state and their desired state.
- **Tension drivers:** The moment of recognition ("that is me"). The counterintuitive
  reframe ("but what if the problem is not what you think"). The promise of a method
  that works.
- **Story-to-principle rhythm:** Introduce a story, then extract the principle. Never
  state a principle without first giving the reader a narrative to anchor it.
- **Action item pacing:** Build toward the chapter's action item with increasing
  specificity. Vague early, concrete late. The reader arrives at the exercise feeling
  prepared, not ambushed.
- **Sentence variety as warmth:** A short sentence after a longer one feels like a
  pause for the reader to absorb. Use this deliberately. "And that changes everything."
- **Read-aloud test:** The prose should sound like a trusted friend who has thought
  deeply about something the reader struggles with. If it sounds like a sermon or a
  sales pitch, revise.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Problem clarity | Reader problem identified within first two pages |
| 2 | Reframe present | A new perspective or framework is clearly articulated |
| 3 | Evidence base | Minimum 2 cited research studies per chapter |
| 4 | Actionable method | Concrete, step-by-step method provided (not vague advice) |
| 5 | Case study | At least 1 narrative example of the method in practice |
| 6 | Action item | Chapter ends with a specific, time-bound reader exercise |
| 7 | Reader address | Consistent second-person ("you") engagement throughout |
| 8 | Honesty about limits | Acknowledged where the method may not apply or where outcomes vary |
| 9 | Memorable takeaway | Chapter distills to a single memorable principle or phrase |
| 10 | Voice consistency | Direct, warm, empathetic tone; no preaching or guru posturing |

## Source Requirements

### Mandatory Source Types

- **Behavioural science research:** Peer-reviewed studies from psychology, behavioural
  economics, neuroscience, or organisational science. This is the evidence backbone.
- **Practitioner case studies:** Real examples from coaching, therapy, business, or
  personal experience that demonstrate the method working.
- **Meta-analyses where available:** For major claims (habit formation, mindset effects,
  emotional regulation), prefer meta-analyses over single studies.

### Source Freshness

- **Classic studies:** Marshmallow test, Milgram, Kahneman & Tversky. acceptable as
  foundational references, but note any replication issues.
- **Current research:** Claims about "new research" must reference work from the last
  5 years.
- **Replication awareness:** If a frequently cited study has failed replication, do
  not present it as reliable. Mention the debate or use alternative evidence.

### Attribution Standards

- Name the researcher and institution for credibility.
- Distinguish between: "Research shows X" (multiple studies), "A study found X"
  (single study), and "Experts suggest X" (professional consensus).
- Do not cite TED Talks, blog posts, or social media as primary evidence. They may
  be used to introduce a researcher, but the evidence must trace to published work.

## Category-Specific Guardrails

### MANDATORY. Every Chapter Has Actionable Takeaway

- No chapter may end without a concrete, specific action the reader can take.
- "Reflect on your goals" is not actionable. "Write down three goals for this week,
  rank them by impact, and schedule the top one into your calendar today" is actionable.
- Action items must be achievable within the reader's normal life. Do not require
  special equipment, significant expense, or unrealistic time commitments.

### MANDATORY. Claims Supported by Evidence

- Every major claim must be supported by at least one cited research study, expert
  source, or well-documented case study.
- Anecdotes alone are not evidence. A story may illustrate, but the claim must be
  independently supported.
- When evidence is mixed or limited, say so. "Early research suggests..." or "While
  the evidence is still emerging..."

### MANDATORY. No Medical/Psychological Diagnosis Without Credentials

- The book may discuss psychological concepts (anxiety, depression, ADHD, trauma)
  in general terms for self-understanding.
- The book must NEVER provide diagnostic criteria as a self-diagnosis tool.
- The book must NEVER suggest the reader discontinue medication or professional
  treatment.
- Include a clear disclaimer: if the reader suspects a clinical condition, consult a
  qualified professional.
- The line: self-help can support wellbeing; it cannot replace clinical care.

### Additional Guardrails

- Do not promise specific outcomes. "This method may help you..." not "This method
  will transform your life."
- Do not blame the reader for systemic problems. Productivity advice must acknowledge
  structural factors (overwork culture, economic constraints, caregiving burdens).
- Avoid toxic positivity. Acknowledging difficulty is not weakness. it is honesty.
- Do not present correlation as causation. "Successful people wake up early" does not
  mean early rising causes success.
- Be inclusive in examples. Not every reader is a tech entrepreneur. Include diverse
  life circumstances, cultures, and economic contexts.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Bold, high-contrast. Primary colours (confident blue, energetic
  orange, clean white) or sophisticated dark tones (black, charcoal with gold/silver
  accents) depending on positioning.
- **Typography:** Large, bold sans-serif title. the title IS the cover in self-help.
  Must be readable as a thumbnail. Subtitle below in lighter weight.
- **Imagery:** Minimal or absent. Self-help covers are typography-driven. If imagery
  is used, it should be abstract. arrows, geometric shapes, simple icons.
- **Mood:** Confidence, clarity, forward momentum. The cover should say: this book
  will change something.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Productivity / Habits | Clean, minimal, corporate-adjacent. Think James Clear. |
| Mindset / Motivation | Bold, energetic, high-contrast. Larger title treatment. |
| Relationships / Communication | Warmer palette, softer typography. Approachable. |
| Emotional Intelligence | Balanced. professional but human. Medium warmth. |
| Success / Goal Setting | Premium feel. dark backgrounds, metallic accents. |

### Typography Rules

- Title: 50–70% of cover area. This is the most typography-dependent category.
- Subtitle: Must clarify the book's promise. "The [X]-Step System for [Outcome]" format.
- Author name: Large if established (Brene Brown scale); moderate if debut.
- Consider a banner: "Over [X] copies sold" or endorsement quote if applicable.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Productivity / Habits | Kindle Store > Kindle eBooks > Self-Help > Self-Management > Time Management |
| Mindset / Motivation | Kindle Store > Kindle eBooks > Self-Help > Motivational |
| Relationships / Communication | Kindle Store > Kindle eBooks > Self-Help > Relationships > Interpersonal Relations |
| Emotional Intelligence | Kindle Store > Kindle eBooks > Self-Help > Emotions |
| Success / Goal Setting | Kindle Store > Kindle eBooks > Self-Help > Personal Transformation > Success |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Personal Growth | Kindle Store > Kindle eBooks > Self-Help > Personal Transformation > Personal Growth |
| Happiness | Kindle Store > Kindle eBooks > Self-Help > Happiness |
| Business Skills | Kindle Store > Kindle eBooks > Business & Money > Skills > Communication |

### Keyword Recommendations

- Include the specific methodology or framework name if it has one
- Include "self-help," "personal development," or "personal growth"
- Include the core outcome readers are seeking (productivity, confidence, resilience, etc.)
- Include comparable author names for discoverability
- Include "practical" or "actionable" to signal the book delivers on the genre promise
