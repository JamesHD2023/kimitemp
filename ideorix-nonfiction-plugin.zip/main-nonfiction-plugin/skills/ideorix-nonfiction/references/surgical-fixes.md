---
name: surgical-fixes-nonfiction
description: "Precision editing protocol for non-fiction — minimum edits, maximum impact"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Surgical Fixes Protocol — Non-Fiction

## File-Write Hygiene (MANDATORY)

This protocol's core discipline (precisely targeted Edits, no
wholesale chapter rewrites) is structurally aligned with the
chained-Edit truncation safeguard documented in
`core-pipeline.md` § Chained-Edit Truncation Safeguard, but
the safeguard's specific bindings still apply:

- **Cap individual Edit replacements at ~2 KB.** Surgical fixes
  should rarely exceed this; if a single fix needs more, split
  it into multiple smaller Edits.
- **Run `scripts/word-count-check.sh` after every chapter file
  this protocol edits**, not just at the end of the revision
  set. Word-count drift after a "single-line fix" is the
  signature of silent truncation.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) before reporting fix success. The Edit
  tool's success return does not confirm on-disk integrity.

**HARD GATE — BLOCKING.** A truncated chapter file caught at
this stage MUST be repaired (clean Write of the full intended
content, post-write integrity verification) before subsequent
fixes are applied to the same file.

## Purpose

Apply the highest-impact editorial fixes with minimum edits. Never rewrite
surrounding content. Every fix checked against the Authority Voice Profile.

## When to Run

- After the verification agents identify critical and moderate issues
- During the Revision Loop's fix phase
- During Phase 5 Editorial (Stage 8: Surgical Fixes)

## Protocol

1. Collect all issues ranked CRITICAL across all 5 verification agents
2. Rank by impact: which fix would improve the manuscript most?
3. Select top 5-7 fixes per chapter
4. Apply each fix surgically:
   - Change ONLY the specific text that has the issue
   - Do NOT rewrite surrounding paragraphs
   - Do NOT "improve" adjacent content while you're there
   - Check every fix against the Authority Voice Profile
5. After applying: re-run the specific agent that flagged the issue
6. Confirm the score improved

## Fix Categories (Non-Fiction Specific)

| Category | What to Fix | How |
|----------|------------|-----|
| **Unsourced claim** | Add source attribution | Insert citation from Research Bible |
| **Misattributed quote** | Correct attribution | Match to correct source in source database |
| **Logical fallacy** | Restructure argument | Rewrite the specific logical step |
| **Citation format** | Fix formatting | Match to selected citation style |
| **Jargon undefined** | Add definition | Insert definition on first use |
| **Factual error** | Correct fact | Match to Research Bible source |
| **Voice drift** | Restore voice | Match to Authority Voice Profile |
| **Scope creep** | Tighten focus | Remove tangential content |

## Rules

- Maximum 7 fixes per pass
- Every fix must be reversible (snapshot taken before applying)
- Fixes must not introduce new issues
- The Authority Voice Profile takes precedence over all editing preferences
- If a fix would require rewriting more than 3 sentences, flag it for
  the user rather than applying it automatically
