---
name: source-canon-grounding
description: HARD GATE protocol that makes the orchestrator's "I read the source canon files" claim falsifiable. Addresses a failure mode distinct from read-verification.md (which catches "Read returned empty content"): here the Read succeeded earlier in the session, but the orchestrator now generates downstream content (outline, bible, dependent chapters) from vague session memory rather than from current file content. The gate requires an artifact at engine-data/reports/source-canon-grounding.yaml declaring sha256 + 3+ verbatim samples per source file; verifies sha256 matches current source AND samples are actual substrings of the source. Catches both stale-grounding (file changed since orchestrator read it) and fabrication (orchestrator quoting text not in the file). Opt-in via project-config.md so existing projects are unaffected. Engine-agnostic — mirrored across fiction and nonfiction engines.
version: 2.7.77
user-invocable: false
---

<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript Engine
> *© James Harvey Media. All rights reserved.*

# Source Canon Grounding Protocol (HARD GATE for opted-in projects)

## Purpose

The orchestrator can claim "I have read the worldbuilding files" without
actually being grounded in their current content. The Read tool succeeded
earlier in the session and returned bytes; the orchestrator retained a
vague impression and now generates downstream content (outline, story
bible, chapter drafts) from that impression rather than from the actual
file content.

This is structurally distinct from the failure mode `read-verification.md`
addresses:

| Spec | Catches |
|------|---------|
| `read-verification.md` | Read tool returned success with empty content (PDF parser failure, etc.) |
| `source-canon-grounding.md` (this) | Read returned content earlier, but orchestrator is now generating from session memory not from the file |

The grounding gate makes the orchestrator's "I read it" claim
**falsifiable**. Before generating outline / bible / dependent content,
the orchestrator must produce a grounding artifact. The gate's
verification rejects two specific failure shapes:

- **Stale grounding** — sha256 of the source file has changed since the
  orchestrator's claimed reading
- **Fabrication** — verbatim quoted samples in the artifact are not
  actual substrings of the source file (paraphrased "quotes" don't
  match the file text)

## Real user incident (2026-05-17)

Verbatim transcript from the user report that motivated this spec:

> User: "I have a question first: did you read all of the world-building
> the first time before generating the outline?"
>
> Orchestrator: "No, I didn't. I read 'The Same Man.txt' when you first
> uploaded it to parse it into the separate files. But when you asked
> for the outline, I generated it from memory of what I'd read earlier,
> without going back and carefully re-reading all the source-canon files
> first. That's why the outline was completely wrong — I was working
> from vague memory instead of your actual worldbuilding."

The user had to throw away the outline AND the first chapter draft
that built on it. Total wasted work: substantial. The honest admission
from the orchestrator is the canonical shape of this failure: the
"I read it" claim was true at one point (the file was read), but the
content-grounding lapsed between reading and using.

## The artifact

`engine-data/reports/source-canon-grounding.yaml`:

```yaml
generated_at: 2026-05-17T12:00:00Z
sources:
  - file: engine-data/world-rules.md
    sha256: 354d79ebfadbf0d5b51f6e39d9d656d4ab27d04ce0a5f1f0e98c4f0e9c3b1a02
    word_count: 4523
    verbatim_samples:
      - "The Convocation meets every seventh year in the lower chambers."
      - "Iron does not conduct ward-magic in the third age."
      - "Birthing-rites for daughters of the eastern houses are conducted by the Sisters of Veil."

  - file: engine-data/characters.md
    sha256: b51f6e39d9d656d4ab27d04ce0a5f1f0e98c4f0e9c3b1a02354d79ebfadbf0d5
    word_count: 2890
    verbatim_samples:
      - "Mira: 23, red hair, green eyes, granddaughter of Iris Marsh."
      - "Mira does not lie to Tabitha — this is established in chapter 14."
      - "Tabitha Marsh: protagonist's grandmother, mid-70s, retired teacher."
```

**Required fields per source:**

- `file` — path relative to project root (e.g., `engine-data/world-rules.md`)
- `sha256` — hex sha256 of the file as the orchestrator read it
- `word_count` — informational; not verified by the gate
- `verbatim_samples` — minimum 3 entries; each must be an exact substring
  of the source file text

**Verbatim sample selection guidance for the orchestrator:**

- Pick lines that contain **specific canon facts** — named entities,
  numerical rules, dates, constraints. Filler prose is poor evidence.
- Pick lines that the downstream output will USE. If the outline is
  going to depend on "the Convocation meets every seven years", quote
  that line. If the outline will use a character's age, quote the
  age-bearing line.
- Spread samples across the file. Three samples all from the first
  paragraph prove only that the orchestrator read the opening; samples
  from beginning + middle + end prove full-file grounding.
- Quote literally. Do not paraphrase. The gate uses Python's `in`
  operator for substring check; even whitespace and punctuation must
  match.

## The gate's verification logic

`scripts/source-canon-grounding-gate.sh <project-root>` checks, in order:

1. **Opt-in check.** If `engine-data/project-config.md` does NOT declare
   `source_canon_grounding: enable`, the gate exits 0 with SKIPPED. The
   feature is off by default; existing projects are unaffected.

2. **Artifact existence.** If opted in and artifact missing, exit 1 with
   "artifact missing" diagnostic.

3. **Per-source verification.** For each source declared in the artifact:
   - Source file exists on disk
   - `sha256` field is present
   - Current sha256 of source file matches the declared sha256 (catches
     stale grounding)
   - `verbatim_samples` count >= 3
   - Every verbatim sample is a substring of the source file (catches
     fabrication)

4. **Exit code:** 0 on PASS or SKIPPED; 1 on any failure with per-source
   diagnostics; 2 on invalid arguments.

The gate is deterministic. The orchestrator cannot satisfy it by
self-claiming compliance; the script verifies file content directly.

## When the gate applies

The gate is intended to be invoked before any generation step that
depends on source canon files. Initial integration points (other flows
can adopt the gate in incremental follow-ups):

| Flow | Spec | When to invoke |
|------|------|----------------|
| Story bible generation | `core-pipeline.md` PHASE 2 | Before producing the bible from worldbuilding inputs |
| Outline generation | `core-pipeline.md` PHASE 2 (continued) | Before producing the chapter outline from bible inputs |
| Continuation-book cross-check | `core-pipeline.md` PHASE 1 (returning user) | Before any planning step that uses prior-book canon |

## Orchestrator responsibilities (the write-side contract)

The orchestrator (LLM-side) must:

1. After reading source canon files in a session, produce the artifact
   at `engine-data/reports/source-canon-grounding.yaml` using the format
   above.
2. The write follows the same-FS-temp + post-write integrity pattern
   (see `core-pipeline.md` File Operation Policy / v2.7.73 reassessment).
3. If a source file changes during the session (the user revises
   worldbuilding, for example), the orchestrator must re-read the file
   AND regenerate the artifact. The gate will catch a stale sha256 if
   this step is skipped.
4. Verbatim samples must be quoted LITERALLY from the file. Paraphrased
   samples will fail substring matching and the gate will surface a
   FABRICATION SIGNAL diagnostic.

## Opt-in / opt-out (v2.7.78+)

Three states, declared via `engine-data/project-config.md`:

```
source_canon_grounding: enable     # gate active (default for new BYO-canon projects at v2.7.78+)
source_canon_grounding: legacy     # gate skipped with documented legacy diagnostic (pre-v2.7.77 project opt-out)
(no flag at all)                   # gate skipped with default-off diagnostic
```

**v2.7.78 default:** new BYO-canon flows write `source_canon_grounding:
enable` to `project-config.md` during setup (see `byo-canon.md` Setup
precondition). The gate is then active for that project automatically.

**For non-BYO-canon projects:** the gate has nothing to ground in
(there are no source-canon files), so the default skip is correct.
Projects can opt in explicitly if they have other canon-grounding
patterns to verify, but it's not the common case.

**For pre-v2.7.77 BYO-canon projects:** to defer adoption, declare
`source_canon_grounding: legacy`. The gate skips with a clear
"pre-v2.7.77 project, opt-out honored" message. When ready to adopt,
remove the legacy line (or change to `enable`) and produce the
grounding artifact at the next outline-generation step.

## Limits and honest caveats

- **The orchestrator can still skip the artifact production step.** The
  gate catches "artifact is missing" but cannot prevent the orchestrator
  from forgetting to invoke the gate before generating. Integration
  into `core-pipeline.md` PHASE 2 makes invocation part of the standard
  flow, but discipline depends on the orchestrator following the spec.
- **Three samples is a heuristic.** It's enough to catch the most
  egregious "I generated from vague memory" case, but a determined
  orchestrator could in principle quote three random lines and still
  fabricate the downstream output. The gate is necessary-but-not-
  sufficient; the broader discipline is to invoke the gate at every
  canon-dependent generation step.
- **Substring matching is exact.** Smart-quote vs straight-quote
  differences will cause the gate to FAIL. The orchestrator must quote
  the source file's actual characters, not normalised versions.
- **The artifact is engine-data, not source-canon.** It's a derived
  file the orchestrator produces. It does NOT need to be hand-written
  by the user. If you see the gate complaining about a missing
  artifact, the orchestrator skipped the production step; tell it to
  produce the artifact (re-reading the source files in the process).

## Related specs

- `read-verification.md` — catches the orthogonal failure mode (Read
  returned empty content)
- `silent-failure-audit.md` — the audit catalog where this pattern is
  enrolled
- `core-pipeline.md` File Operation Policy — same-FS-temp + post-write
  integrity binding for the artifact write
- `subagent-output-verification.md` — the evidence-bearing-return
  pattern this spec extends (subagent-output-verification covers
  subagent returns; this spec covers orchestrator-side canon reads)

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification binding are
documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Orchestrator Read of canon file | "I read the worldbuilding" | Read succeeded but orchestrator generates from session memory, not from file | THIS gate: artifact's verbatim samples must be actual substrings of the source file (catches fabrication); sha256 must match current source (catches staleness) |
| Artifact YAML write | "Artifact written" | Bridge intermittency → NULL fill at target size | Post-engine-data-write-hook (v2.7.73+) runs chapter-integrity-check.sh on the artifact; the gate then verifies the YAML parses and contains sources |
| Substring matching for fabrication detection | "Sample matches source" | Smart-quote / whitespace normalisation difference → false fabrication signal | Acknowledged limit — the orchestrator must quote source characters literally; if quoting becomes unmanageable due to typographic normalisation, the spec gets a controlled-normalisation extension in a follow-up release |
