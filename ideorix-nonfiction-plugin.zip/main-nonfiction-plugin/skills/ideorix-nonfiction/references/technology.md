---
name: technology-category
description: "Category-specific instructions for technology and digital non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Technology / Digital. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | technology |
| Display Name | Technology / Digital |
| Parent Group | Computers & Technology |
| Typical Word Count | 60,000–90,000 (industry-narrative books often 80,000–120,000; concept-explainers 60,000–80,000; criticism / ethics 70,000–100,000; how-to-implementation often shorter at 40,000–70,000) |
| Default Structure | Thematic or chronological: one technology / concept / company / question per chapter; "how it works → how it got here → where it's going → why it matters" rhythm; ethical implications woven through rather than relegated to a final chapter; named human protagonists wherever possible |
| Citation Style | Endnotes mandatory for technical and historical claims; named-source attribution for industry interviews; primary documentation (papers, specifications, court filings, regulatory documents) cited where claims depend on them; explicit version / date stamps on technology-specific claims |
| Audience Baseline | Curious general reader without technical training (default); industry-adjacent reader for industry-narrative titles; technically-literate reader for some explainer / criticism titles. Audience named explicitly so reader self-selects; technical depth calibrated accordingly |
| Comparable Titles | Walter Isaacson (*Steve Jobs*, *The Innovators*, *Elon Musk*), Brad Stone (*The Everything Store*, *Amazon Unbound*), Tim Wu (*The Master Switch*, *The Attention Merchants*), Shoshana Zuboff (*The Age of Surveillance Capitalism*), Cathy O'Neil (*Weapons of Math Destruction*), Virginia Eubanks (*Automating Inequality*), Safiya Umoja Noble (*Algorithms of Oppression*), Ruha Benjamin (*Race After Technology*), Sherry Turkle (*Alone Together*, *Reclaiming Conversation*), Nicholas Carr (*The Shallows*, *The Glass Cage*), Melanie Mitchell (*Artificial Intelligence: A Guide for Thinking Humans*), Stuart Russell (*Human Compatible*), Cal Newport (*Digital Minimalism*, *Deep Work*), Andy Greenberg (*Sandworm*), Bruce Schneier (*Click Here to Kill Everybody*), Kashmir Hill (*Your Face Belongs to Us*), James Bridle (*New Dark Age*, *Ways of Being*) |

## Subcategory Options

When the user selects Technology / Digital, prompt for subcategory
refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| ai-emerging-technology | AI & Emerging Technology | Artificial intelligence, machine learning, robotics, biotech, quantum computing, novel hardware, brain-computer interfaces — explaining or interrogating technologies still in active development | Concept-then-implication structure; named systems / named labs / named papers as anchors; explicit version / capability / date stamps; speculation flagged distinctly from current reality |
| tech-industry-business | Tech Industry & Business / Silicon Valley | Companies, founders, mergers, IPOs, the business and culture of major tech firms; industry-as-subject narrative non-fiction | Company-life or founder-life chronology; named protagonists; primary-source interviews and documents; tension between official narrative and observed reality as recurring pattern |
| digital-culture-society | Digital Culture & Society | How technology shapes social life, attention, relationships, work, politics, identity — Turkle / Carr / Newport / Doctorow lineage | Domain-led chapter spine (attention / relationships / work / politics / parenting); social-science evidence + cultural observation + first-person reporting; case studies of representative individuals or communities |
| cybersecurity-privacy | Cybersecurity & Privacy | Threats, breaches, surveillance, infosec practice, digital-rights — Schneier / Greenberg / Hill lineage | Threat / actor / incident-led chapter structure; primary investigation narrative; technical-detail-then-social-implication rhythm; explicit current-state-of-threat acknowledgement (this category dates fastest) |
| tech-criticism-ethics | Tech Criticism & Ethics | Algorithmic bias, surveillance capitalism, automation harm, platform power, AI safety / ethics — O'Neil / Noble / Benjamin / Eubanks / Zuboff / Russell lineage | Argument-led structure with case-study chapters; documented harm / observed pattern / critical analysis; engages with industry's own framings and contests them; community-affected voices central |
| tech-explainer-popular | Tech Explainer for General Audience | Concept-explainers for non-specialist readers — what AI is, how the internet works, what blockchain does, what to know about [emerging tech] | Reader's-existing-mental-model first; analogy-led explanation; "what we know / what we don't know / what's contested" framing; minimal jargon, every term defined; visual / diagram support common |
| how-to-implementation | How-To & Implementation | Tutorial books for specific software, platforms, programming languages, professional tools (overlaps with how-to-guide category) | Version-dated; sequential procedural; screenshot- / diagram-led; companion repository or downloadable assets common; dependency-and-prerequisite framing prominent |

**Default:** If the user does not specify, prompt for the book's primary
mode (industry / culture / criticism / explainer / how-to / cybersecurity)
and select accordingly; fallback to `tech-explainer-popular` for unclear
cases.

## Structural Architect Instructions
```
STRUCTURE
- Thematic or chronological: one technology/concept per chapter
- "How it works, how it got here, where it's going, why it matters"
- Technical concepts made accessible through analogy and narrative
- Ethical implications engaged with throughout, not confined to a final chapter

FORBIDDEN
- Predictions presented as certainties (flag as speculation)
- Company narratives repeated uncritically from press releases
- Jargon without definition for general audience
- Ignoring ethical implications of the technology discussed
- Breathless techno-optimism OR unrelenting doom without nuance
```

## Content Writer Craft Rules
```
VOICE & TONE
- Curious, analytical, accessible. explaining complex things clearly
- Technical accuracy maintained even when simplified
- Future-oriented but grounded. enthusiasm tempered by evidence
- The human impact of technology always foregrounded
```

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the innovation or disruption, shown through human impact.
  A person whose life, work, or world changed because of this technology. The human
  comes before the machine.
- **Sentence calibration:** Clean, precise prose averaging 14–20 words. Technical
  writing demands clarity above all. every sentence should do exactly one job.
- **Technical concepts through analogy and narrative:** Never explain a technology in
  the abstract when a concrete comparison or story will do. "Think of encryption as
  a lock that only mathematics can pick" beats a formal definition.
- **Jargon explained on first use:** Every technical term gets a plain-language
  definition the first time it appears. After that, use it freely. the reader has
  been taught.
- **Rhythm pattern:** Alternate between narrative (human story, historical moment,
  concrete scenario) and exposition (how the technology works, what it does, why it
  matters). The story creates investment; the exposition delivers understanding.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In technology writing,
  tension comes from consequence. what this technology makes possible, for good or
  ill, and who decides.
- **Tension drivers:** The gap between what technology can do and what it should do.
  The moment a tool outgrows its creator's intentions. The race between innovation
  and regulation.
- **Analogy discipline:** One strong analogy per major concept. Develop it enough to
  illuminate, then move on. Stacking analogies confuses rather than clarifies.
- **Pace calibration:** Speed up for narrative passages (the origin story, the race to
  ship, the moment of breakthrough). Slow down for explanation passages (how it works,
  what the risks are). The reader should feel the difference.
- **Ethical integration:** Weave ethical considerations into the prose as they arise,
  not as a separate moralising section. The question "but should we?" belongs next to
  the explanation of "here is how."
- **Read-aloud test:** The prose should sound like a sharp journalist explaining
  something consequential. If it sounds like a press release or an academic paper,
  revise.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Technical accuracy preserved through simplification | Simplifying analogies and explanations do not introduce factual errors; specialists reading the book would recognise the simplified version as a faithful (if shorter) rendering of how the technology actually works; analogies acknowledged as such ("think of it as...") rather than asserted as identity |
| 2 | Version / date / capability stamping | Technology-specific claims carry explicit version (software version, model name, platform release year) and the date the analysis was written; "as of [year]" framing where capability or behaviour will plausibly change; future-tense claims about expected change handled with appropriate hedging |
| 3 | Speculation flagged distinctly from established reality | Predictions, projections, and forward-looking claims are framed as speculation ("if current trends continue", "researchers expect", "this remains contested"); not presented as fact; the strength of evidence behind each prediction signalled |
| 4 | Industry framings examined critically | Company-supplied narratives, marketing language, and PR framings are examined rather than repeated; where the official narrative is contested, the contest is noted; "the company says X but documents / interviews / observed reality show Y" is the standard analytical move |
| 5 | Ethical implications integrated | Ethical considerations woven through chapters as they arise rather than confined to a final chapter; impact on different stakeholders (users, workers, third parties, communities, environments) acknowledged where the technology touches them; "but should we" question lives next to "here is how" |
| 6 | Jargon management calibrated to audience | Every technical term gets a plain-language definition on first use for the target audience; specialist audiences may have shorter on-ramps but the book's stated audience matches the on-ramp depth; jargon used freely after definition; glossary appended where terminology load is high |
| 7 | Affected-community voices present | For technology with documented disparate impacts (algorithmic decision-making, surveillance, automation, content moderation), voices from affected communities are inputs alongside developer / academic / journalist sources; "nothing about us without us" applies |
| 8 | Privacy / surveillance / accessibility implications named | Where the book recommends or describes products, platforms, services — privacy implications (data collection, third-party sharing, retention), surveillance affordances (employer / state / household monitoring), and accessibility (screen-reader compatibility, language coverage, low-bandwidth usability) are noted where they materially affect readers |
| 9 | Non-Western context acknowledged | Where claims are framed as universal but actually reflect Silicon Valley / US / Western European reality, acknowledged as such; major non-Western tech ecosystems (Chinese platforms, Indian payments / identity, African mobile-money, regulatory regimes outside the US) acknowledged where the topic warrants |
| 10 | Avoids both techno-optimism and doom-loop framings | The chapter does not breathlessly celebrate the technology's promise OR catastrophise its harms; the tension between possibility and risk is presented honestly with both sides given evidentiary weight; reader can form a calibrated view rather than receive a position |

## Source Requirements

### Mandatory Source Types

- **Primary technical documentation.** Specifications, protocols,
  research papers, official documentation from the technology's
  developers / standards bodies / academic creators (IEEE, RFCs,
  arXiv preprints, peer-reviewed journals, vendor technical
  documentation). The evidentiary backbone for any claim about
  how the technology actually works.
- **Peer-reviewed research on societal impact.** Where the book
  makes claims about technology's effects on attention, mental
  health, work patterns, social relationships, political
  participation, inequality — claims trace to peer-reviewed work
  in psychology, sociology, economics, communication studies,
  human-computer interaction, science and technology studies (STS).
  Popular framings (the "dopamine loop" of social media; the
  "rewiring" of attention; the "death of print") often outpace
  the underlying evidence and warrant care.
- **Investigative journalism and primary reporting.** For industry
  / company / incident / policy content, named-source reporting
  from established technology journalists (NYT, WaPo, Bloomberg,
  Wired, MIT Tech Review, The Information, Rest of World, 404 Media,
  Pro Publica) and named-author original reporting; not chains of
  citation through aggregators.
- **Named-source interviews.** Authors of technology books
  routinely conduct primary interviews with technologists,
  founders, researchers, policy makers, affected community members.
  Interviews are attributed (named source where consented; named
  role where the source requires anonymity) and dated.
- **Court filings, regulatory documents, and primary policy
  texts.** For platform-power, antitrust, content-moderation,
  surveillance, and AI-policy content — claims trace to primary
  legal and regulatory documents (DOJ filings, FTC complaints,
  EU DMA / DSA / GDPR / AI Act, congressional hearing transcripts,
  national-regulator findings) rather than to summary reporting.
- **Affected-community accounts.** For technology with documented
  disparate impacts — algorithmic discrimination, surveillance of
  marginalised communities, automation harm, content moderation
  affecting specific populations — community accounts and
  community-led research are inputs alongside developer /
  academic / journalist sources.

### Source Freshness — TECHNOLOGY DATES FASTEST

Technology is the highest-currency-sensitivity category in
non-fiction. A book written in 2022 about LLM capability is
substantially out of date by 2024; a book written in 2010 about
mobile platforms describes a different industry from today's. The
book must engage with this honestly:

- **Date the analysis explicitly.** Front matter states when the
  research was completed; chapters carry "as of [year]" framing
  where the state of the technology is the subject; capability /
  market / regulatory claims are time-stamped throughout.
- **Software / model / platform versions named.** "The 2024 version
  of [Software]" / "GPT-4-class models in 2024" / "the EU AI Act
  as enacted in 2024" — version specificity protects the book
  against reading badly when the technology shifts.
- **Forward-looking claim restraint.** "The future of X" framings
  age badly. Scoped speculation ("over the next two to three
  years, [vendor] is expected to..." or "the trajectory of [tech]
  through 2027 will likely depend on...") works better than
  open-ended futurology.
- **Capability claims about AI systems particularly volatile.**
  Specific benchmark performance, cost per token, model
  capabilities — these change quarterly. Frame in trajectory and
  category terms rather than asserting fixed numbers that will
  read as wrong within a year.
- **Currency-sensitive content benefits from short revision cycles.**
  Technology titles often warrant updated editions every 2–4 years;
  the book that does not plan for this will look dated quickly.
  Authors should consider what the book's argument depends on and
  what the book's currency depends on, separately.
- **Foundational works hold up better.** Books making structural
  arguments about technology (Wu's *The Master Switch* on
  consolidation cycles; Zuboff on surveillance capitalism's
  business model; Carr on attention shifts) age more gracefully
  than books making capability or feature claims.

### Attribution Standards

- **Technical claims sourced.** "Studies show..." is unacceptable
  without citation; "A 2023 paper from [lab] published in [venue]
  found..." is the standard. Reader trust in the technical
  framing depends on this.
- **Industry sources distinguished.** "An Apple spokesperson
  confirmed..." (official source) differs from "according to
  internal documents reviewed by..." (leaked / disclosed source)
  differs from "former engineers describe..." (memory-based
  testimony). Each register signals the evidence's nature; conflating
  them obscures the analytical chain.
- **Distinguish: capability / claim / projection / speculation.**
  "The system can perform X" (verifiable capability). "The vendor
  claims the system performs X" (vendor claim subject to scrutiny).
  "Researchers project that systems of this class will perform X"
  (projection from named researchers). "If current trends
  continue..." (speculation). Each is legitimate; conflating them
  is a credibility failure.
- **Affiliate / commercial relationship disclosed.** Where the
  author has a commercial relationship with a recommended vendor
  (consulting client, advisory board, equity stake, affiliate
  arrangement, sponsored content), it is disclosed in the book.
  Technology coverage with undisclosed commercial relationships
  is a category-defining ethical failure.
- **What is NOT acceptable.** Inventing capabilities, citation
  laundering through aggregators, treating vendor claims as
  established fact, using superseded research to support current-
  state arguments, presenting one-shot demos as typical performance,
  attributing capability or harm to "AI" / "the algorithm" / "the
  internet" without specifying the actual system involved.

## Category-Specific Guardrails

### MANDATORY. Currency-Sensitivity Disclosure

- Technology is the highest-currency-sensitivity NF category. The
  book must engage with this rather than ignore it.
- Front matter discloses when the research and writing were
  completed and notes the categories of claim that are time-bound
  (specific capabilities / vendors / regulations / market positions)
  vs claims expected to age more gracefully (structural arguments,
  historical narratives, ethical frameworks).
- Capability / version / market claims are time-stamped at the
  point they appear, not only in front matter: "as of late 2024",
  "the 2024 version of [Software]", "in the year ending [date],
  [Company] reported..." These stamps protect both the author's
  credibility and the reader's ability to recalibrate when reading
  the book later.
- Forward-looking claims framed as scoped projections from named
  sources rather than open-ended prophecy. "By 2030..." reads
  worse than "Over the next 2-3 years, researchers at [lab] expect
  [system class] to..." Scoped projections age into testable
  predictions; open-ended prophecy ages into embarrassment.
- Where the book's central argument depends on time-bound claims,
  authors plan for revised editions on a 2–4 year cycle and signal
  this in front matter.

### MANDATORY. Industry Framing Critical Examination

- Company-supplied narratives (founder mythologies, official
  histories, marketing language, press releases, prepared
  statements) are examined rather than repeated. Where the
  official narrative differs from what documents, observed
  behaviour, court filings, or independent reporting show, the
  difference is the story.
- Marketing terminology (what vendors call "AI", "the cloud",
  "blockchain", "Web3", "the metaverse") is interrogated rather
  than adopted; the book defines what these terms actually refer
  to in technical and business reality.
- The technology industry has documented patterns of: over-claiming
  capability in marketing, suppressing internal concerns about
  product harms, framing competitive concerns as user-benefit
  arguments, treating regulation as illegitimate interference.
  The book engages these patterns rather than ignoring them when
  describing industry positions.
- "Disruption", "innovation", "the future is here", "10x" language
  warrants particular skepticism. These framings serve specific
  industry interests and reproduce them when adopted uncritically.

### MANDATORY. Privacy, Surveillance, and Accessibility Ethics

- When recommending or describing software / platforms / services,
  the book identifies:
  - **Privacy implications.** What data the product collects, what
    it shares with third parties, what retention policies apply,
    what user-control affordances exist; surveillance affordances
    (employer monitoring, parental monitoring, government
    surveillance compatibility) where they materially affect
    readers.
  - **Accessibility status.** Screen-reader compatibility,
    keyboard-only navigation, language coverage, low-bandwidth
    usability, hearing / visual / motor accessibility — particularly
    for tools the book recommends as broadly applicable. The book
    distinguishes "we recommend this product to all readers" from
    "we recommend this product, with the accessibility caveats
    noted, to readers for whom it works."
  - **Algorithmic bias considerations.** For automated decision-
    making systems, content recommendation, content moderation,
    the book acknowledges documented disparate-impact research
    where it exists and refrains from presenting these systems as
    neutral / objective / "just math."
- Where the book adopts a critical stance on surveillance /
  privacy / algorithmic harm, it engages substantively (not
  merely rhetorically) with the technical and economic mechanisms
  that produce these outcomes.

### MANDATORY. Affiliate and Commercial-Relationship Disclosure

- Technology titles routinely cover products and services that
  many authors have commercial relationships with (consulting
  clients, advisory boards, equity, sponsored content, affiliate
  arrangements). All such relationships are disclosed in the book —
  typically in front matter and re-noted at points of relevant
  recommendation.
- Affiliate links in supplementary materials disclosed; the
  book does not function as undisclosed advertising for vendors.
- Where the author is currently employed by or has been recently
  employed by companies discussed, the relationship is disclosed
  and the analysis treats the conflict openly.
- Sponsored content (paid corporate content within the book)
  is incompatible with this category's standards; if a book is
  sponsored, its sponsorship must be disclosed clearly enough that
  readers can calibrate.

### MANDATORY. Non-Western and Non-US-Centric Framing

- The technology landscape is not Silicon Valley. Major non-Western
  ecosystems (Chinese platforms — WeChat, Douyin, Tencent, Baidu,
  Alibaba; Indian payments and identity — UPI, Aadhaar, Jio;
  African mobile-money — M-Pesa, MTN MoMo; Korean and Japanese
  platforms — Line, Kakao, LINE Pay) shape the global picture and
  often lead in their domains.
- Regulatory landscapes differ sharply across jurisdictions: EU
  GDPR / DSA / DMA / AI Act, US sectoral regulation, Chinese
  cyberspace administration regimes, Indian data protection,
  African Union frameworks. "The regulatory environment" is rarely
  monolithic.
- Where claims are framed as universal but reflect Western /
  Anglophone / US reality, acknowledged as such. "American
  consumers" is not the same as "consumers"; "Big Tech"
  conventionally refers to specific US firms and the language
  should mark this rather than treat it as the global default.
- For genuinely global topics, the book includes voices,
  examples, and analysis from beyond US / Western European
  contexts.

### Additional Guardrails

- **Avoid both techno-optimism and doom-loop framings.** The
  category's two failure modes are breathless celebration and
  totalising catastrophism; neither serves the reader. The
  honest position acknowledges promise and harm in proportion
  to evidence, with both sides given evidentiary weight.
- **Specificity over abstraction.** "AI" / "the algorithm" /
  "the internet" / "the platform" name nothing precisely. The
  book identifies the actual system involved (specific model
  family, specific company, specific regulatory regime, specific
  protocol) and reasons from there.
- **Demo discipline.** Public demos and one-shot examples are
  not typical performance; cherry-picking demo behaviour to
  characterise general capability is the category's most common
  factual error. Where demos are referenced, the book contextualises
  them against documented typical-case performance.
- **Reader's mental model engaged.** Technology readers arrive with
  prior beliefs, often incorrect, about how systems work. The book
  identifies the relevant misconceptions ("you may have read that
  AI 'thinks like a human' / blockchain is 'tamper-proof' / VPNs
  'make you anonymous' — here is what is actually true") and
  works from there rather than asserting facts that will collide
  with the reader's existing model.
- **Citations to primary sources.** Citation laundering (citing
  popular-press summaries that cite research, without checking
  the research) is a recurring error in popular technology
  writing; the book traces back to primary sources before relying
  on a claim.
- **Author positionality disclosed.** The author's relationship to
  the technology being covered shapes the work — practitioner,
  former practitioner, academic, journalist, advocate, affected
  community member. Some disclosure helps readers calibrate
  ("I worked at [company] from [years]; I am writing this from
  the perspective of a researcher who has consulted for several
  vendors discussed; my own family was affected by..." etc.).
- **Currency-sensitive guidance directs to authoritative sources.**
  Where the topic depends on rapidly changing fact (current model
  capabilities, current regulation, current threats), the book
  signposts where readers can find current information rather
  than treating its own version as enduring.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Cool and contemporary (deep blue, slate,
  white + bold accent) for industry-narrative and emerging-tech
  titles where the cover should signal authority over playfulness.
  Stark monochrome (black + single saturated accent — red, yellow,
  cyan) for criticism / ethics titles where the cover should
  signal seriousness and confrontation. Warmer palettes (cream,
  ochre, soft red) for digital-culture / explainer titles where
  the cover should signal accessibility and human concern.
  Avoid the saturated-neon "tech-forward" aesthetic that signals
  pulp futurism rather than considered analysis.
- **Typography:** Clean modern sans-serif (Helvetica Neue, Univers,
  Akzidenz-Grotesk, Söhne, Apercu) is the default — technology
  trades on clarity and the typography signals it. Slightly more
  characterful sans-serifs (Brandon Grotesque, GT Pressura, Calibre)
  for accessible / explainer / popular positioning. Serif fonts
  appear in technology-criticism titles deliberately — to signal
  literary / humanistic engagement against the industry's own
  visual language. Title at thumbnail-readable weight is essential.
- **Imagery:** Three dominant traditions:
  1. **Pure typography or typographic-with-element** — the most
     common form for current technology publishing. Title large,
     subtitle substantial, often with a single graphic element
     (line, dot, abstract geometry). Strong for criticism /
     ethics / industry-narrative titles where the cover trades
     on the argument.
  2. **Subject portrait** — for industry-narrative / founder-
     biography titles (Steve Jobs face, Sam Altman, Elon Musk).
     Common in the Walter Isaacson / Brad Stone tradition. The
     subject's face IS the book's promise.
  3. **Abstract / iconographic / object** — a single resonant
     object (a chip, a device, a hand, a server, a circuit
     fragment) photographed cleanly; or abstract iconographic
     work; effective for explainer and popular-science
     positioning.
- **Mood:** Considered intelligence. The cover should signal
  "this book examines technology rigorously" — not "this book
  hypes the future" (techno-optimist register) or "this book
  catastrophises everything" (doom register). Restraint outsells
  ornament; the typography and layout do most of the work.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| AI & Emerging Technology | Clean typography on confident background; abstract / iconographic single element (a node, a network, a chip); palette restrained (often black + single accent); subtitle clarifies the angle and audience |
| Tech Industry & Business | Subject portrait OR iconic-object imagery (the company logo treated boldly, a product); strong typography hierarchy with subject name large; subtitle establishes the angle ("the inside story", "the rise and fall", "the untold history") |
| Digital Culture & Society | Warmer palette than industry titles; iconographic or human-context imagery (hands, screens, a person at a window); typography that signals literary engagement rather than reportage |
| Cybersecurity & Privacy | Stark palette (black + red is conventional for the category); abstract or symbolic imagery (a key, a face partially obscured, a network glow); urgent typography; subtitle establishes the threat / topic specificity |
| Tech Criticism & Ethics | Often pure typography or restrained symbolic; serif fonts increasingly common (signal humanistic critique against industry's own visual language); palette can be confrontational (high contrast) or restrained (academic) per the book's register |
| Tech Explainer for General Audience | Friendlier palette and warmer typography; iconographic or stylised imagery; explanatory subtitle ("what every reader should know about...", "a guide to..." , "the basics of..."); often series-styled when part of a publisher's explainer line |
| How-To & Implementation | Often clean typography + screenshot or product image; clear edition / version on cover; series-styled when part of a publisher's technical-press list (O'Reilly, Manning, Pragmatic) |

### Typography Rules

- **Title:** 30–55% of cover area for typography-led covers; 25–35%
  for portrait-led covers. Technology titles work as descriptive
  ("Weapons of Math Destruction"), evocative ("The Shallows"),
  or character-driven ("Steve Jobs"). All three work; the title
  must read at thumbnail.
- **Subtitle:** Often essential — does the descriptive work the
  title leaves abstract. Technology subtitles tend longer than
  other categories: "How Big Data Increases Inequality and
  Threatens Democracy" / "What the Internet Is Doing to Our
  Brains" / "The Battle for the Soul of the Internet". The
  subtitle does the reader-targeting work.
- **Author name:** Large for established author-brands (Isaacson,
  Stone, Wu, Carr, Schneier, Zuboff); smaller for unestablished
  authors with credentials in subtitle ("by a technology
  ethicist", "by a former [Company] engineer", "by a security
  researcher"). Author qualification cues matter in this category
  because reader trust depends on technical credibility.
- **Edition / version marking essential.** "Updated edition",
  "Second edition", "Updated for [year]" prominently on cover
  for any title where the underlying technology has shifted; the
  reader buying a 2018 book on AI in 2025 wants to know whether
  it's been refreshed. Series-mark for publisher technical-press
  lists where applicable.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| AI & Emerging Technology | Kindle Store > Kindle eBooks > Computers & Technology > Computer Science > AI & Machine Learning (or Science & Math > Technology > [specific emerging-tech sub] for cross-disciplinary positioning) |
| Tech Industry & Business | Kindle Store > Kindle eBooks > Business & Money > Industries > Technology (and Biographies & Memoirs > Business if founder-narrative) |
| Digital Culture & Society | Kindle Store > Kindle eBooks > Politics & Social Sciences > Social Sciences > Communication & Media Studies (or Computers & Technology > Internet & Social Media > Social Aspects) |
| Cybersecurity & Privacy | Kindle Store > Kindle eBooks > Computers & Technology > Security & Encryption (or > Networking & Cloud Computing > Network Security) |
| Tech Criticism & Ethics | Kindle Store > Kindle eBooks > Computers & Technology > Computer Science (with Politics & Social Sciences > Philosophy > Ethics & Morality secondary; or > Social Sciences > Sociology) |
| Tech Explainer for General Audience | Kindle Store > Kindle eBooks > Science & Math > Technology (broad; the popular-science-of-tech shelf) |
| How-To & Implementation | Kindle Store > Kindle eBooks > Computers & Technology > [Specific Software / Hardware / Programming Language] (matches the how-to-guide category mapping for technology-specific tutorials) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Specific industry / vertical | Kindle Store > Kindle eBooks > Business & Money > Industries > [Healthcare / Finance / Education / etc.] for tech-and-industry crossover |
| Computer programming | Kindle Store > Kindle eBooks > Computers & Technology > Programming Languages > [Specific Language] |
| Internet & social media | Kindle Store > Kindle eBooks > Computers & Technology > Internet & Social Media > [Social Aspects / E-commerce / Web Development] |
| Hardware & devices | Kindle Store > Kindle eBooks > Computers & Technology > Hardware & DIY |
| Data and analytics | Kindle Store > Kindle eBooks > Computers & Technology > Databases & Big Data |
| Politics / regulation | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > Privacy & Surveillance |
| Investigative journalism | Kindle Store > Kindle eBooks > Politics & Social Sciences > Politics & Government > Specific Topics > Censorship; or Biographies & Memoirs > Specific Groups > Journalists |
| Self-help (for digital well-being) | Kindle Store > Kindle eBooks > Self-Help > Self-Esteem (for digital-minimalism / attention crossover) |

### Keyword Recommendations

- The specific technology, system, or platform
  ("ChatGPT", "large language models", "machine learning",
  "blockchain", "TikTok algorithm", "facial recognition",
  "encryption", "Web3", "cybersecurity")
- The angle or argument
  ("the future of AI", "history of the internet", "how
  algorithms work", "tech industry exposé", "platform power",
  "surveillance capitalism", "algorithmic bias", "AI safety")
- The audience cue
  ("for non-technical readers", "for executives", "for
  developers", "for policymakers", "for skeptics", "for
  parents", "complete guide", "introduction to")
- Currency / version cue where applicable
  ("2024", "current state", "updated", "latest" — used carefully;
  these age fast)
- Specific named systems, companies, regulations
  ("OpenAI", "GDPR", "EU AI Act", "Section 230", "Cambridge
  Analytica", "Snowden disclosures")
- Comparable author / brand for discoverability
  (readers of Walter Isaacson, readers of Tim Wu, readers of
  Cathy O'Neil, readers of Shoshana Zuboff)
- Avoid generic single-word terms ("technology", "tech",
  "digital") in isolation — they drown in algorithmic noise;
  prefer compound phrases combining technology + angle + audience
- Avoid breathless / pulp framings ("revolutionise", "disrupt",
  "transform everything", "the new gold rush") — they signal
  hype-positioning that damages credibility with the readers
  serious technology titles need to attract
- Avoid catastrophising framings ("the end of...", "the death
  of...", "the destruction of...") unless the book's actual
  argument supports the framing; both hype and doom keywords
  attract bad reviews when the content is more measured
