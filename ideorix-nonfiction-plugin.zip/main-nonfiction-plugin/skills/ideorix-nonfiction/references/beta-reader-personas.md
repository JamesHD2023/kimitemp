---
name: beta-reader-personas
description: "Domain-Expert Beta Reader Personas. Specialised subject-matter-expert personas the Stage 6 Beta Reader simulation MUST instantiate per project — generic 'informed reader' simulation does not catch domain-specific factual errors that cluster in trade microhistory, biographical specifics, technical attribution, and contested-priority claims. Per-volume persona enumeration is mandatory; the Beta Reader stage runs one full pass per persona, each loaded with its specialist expertise."
version: "2.7.11"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *© James Harvey Media. All rights reserved.*

# Domain-Expert Beta Reader Personas (MANDATORY for Stage 6 in any NF manuscript with technical, historical, biographical, or attribution claims)

## Purpose

Stage 6 (Beta Reader) in `editorial-suite.md` historically
simulated a generic "informed reader" — an articulate non-
specialist with curiosity about the subject. That simulation
catches structural problems (argument coherence, accessibility,
pacing) but misses the class of factual error that clusters in
NF: domain-specific attribution mistakes, contested-priority
claims, technical mis-statements, and biographical specifics
that secondary sources copy uncritically.

This spec mandates per-volume **domain-expert persona
enumeration** for the Beta Reader stage. Each persona is loaded
with specialist expertise and runs a full pass on the chapters
relevant to its domain. The personas are project-specific; the
Architect identifies them during Phase 2 Bible construction
based on the manuscript's subject matter.

## Failure mode addressed

A user (May 2026) shipped Volume 1 of a multi-volume non-
fiction series — *Products That Changed the 20th Century,
Volume 1: The Office* — through the full 13-stage editorial
pipeline. Stage 6 Beta Reader passed cleanly. Six substantive
factual errors survived to publication-ready status:

- A specific chair model number attributed to the wrong product
  family (a 1960 sling chair confused with a 1963 executive chair)
- A patent attributed to a person who never filed one (a "widely
  viewed with scepticism since 1910" claim presented as fact)
- A drinking-fountain inventor's biography wrong on multiple
  specifics (state of residence, prior employer, patent year,
  product type)
- A bubbler invention year off by three years from the canonical
  date
- A paperclip patent priority claim with the wrong jurisdictional
  framing
- A "first patent" priority claim where the canonical first-
  filings were in different jurisdictions

Every one of these errors would have been caught by a Beta
Reader loaded with the relevant domain expertise — an office-
furniture historian for the chair, a patent historian for the
patent claims, a workplace-design historian for the priority
claims. The generic "informed reader" had no specialist
threshold for noticing.

This spec closes that gap by requiring domain personas, named
explicitly per project, loaded with subject-matter context, and
run as separate per-chapter passes.

## Per-project persona enumeration discipline

During Phase 2 (Bible construction), the Architect identifies
the manuscript's domain coverage and enumerates 4-8 domain-
expert personas relevant to the volume's content. Personas are:

- **Specific enough to load real expertise** — "rubber stamp
  historian" rather than "industrial historian", "Action Office
  / hot-desking workplace-design historian" rather than "design
  expert"
- **Drawn from the actual academic / specialist communities**
  that would publish in the manuscript's domain — not invented
  composite roles
- **Mapped to specific chapters** — each persona has a chapter
  list it is responsible for, not "the whole manuscript"
- **Loaded with the persona's reading list** — the Architect
  identifies 3-5 canonical works the persona would know and
  whose claims would constitute the persona's baseline

The persona enumeration is written to:

```
~/Documents/Ideorix-Projects/[Title]/engine-data/beta-reader-personas.md
```

Format:

```markdown
# Beta Reader Personas — {Title}

## Persona 1: {Specific role}

- **Specialist territory:** {sub-domain, with named scholars / works the persona would reference}
- **Chapters this persona reads:** {chapter numbers}
- **Reading list (claim baseline):** {3-5 canonical works}
- **Detection priorities:** {specific error classes this persona is best positioned to catch}

## Persona 2: {Specific role}

[same structure]

[...4-8 personas total]
```

## Per-volume persona libraries (worked examples)

The following are non-exhaustive starter libraries by NF
category. The Architect can adapt or extend per project; the
enumeration must always be project-specific, not template-only.

### Office / Workplace History (e.g. Vol 1: The Office)

- **Office-furniture historian** — Galen Cranz / Adrian Forty /
  Nikil Saval territory; Action Office, panel furniture,
  ergonomic chair history, modular workstation development
- **Workplace-design historian** — open-plan vs cellular,
  Bürolandschaft, Quickborner Team, hot-desking, activity-based
  working
- **Calculator collector / vintage-computing historian** —
  mechanical calculators, electromechanical office machines,
  early electronic calculators, compressed-displacement chapters
- **Telecommunications historian** — PBX, intercom, extension
  culture, push-button vs rotary, business-line tariff history
- **Labour-history scholar** — clerical work, gender in office
  labour, Davies / Strom / DeVault territory
- **Patent attorney / patent historian** — every patent claim,
  priority dating, first-to-file vs first-to-invent, jurisdictional
  filings
- **Period-specific oral-history specialist** — anchor-scene
  texture (smells, sounds, social register of the era covered)

### Domestic / Living-Room History

- **Furniture historian** — domestic seating, modular living-
  room, mid-century to contemporary
- **Television / broadcast historian** — set design, broadcast
  formats, family-viewing patterns
- **Magazine / mass-media historian** — TV Guide, Reader's
  Digest, Life, the magazine ecosystem of the era
- **Domestic-electronics historian** — radios, hi-fi, VCRs,
  game consoles
- **Home-appliance historian** — vacuum, iron, food-prep, the
  domestic-labour mechanisation arc
- **Patent attorney / patent historian** — same role as Office;
  every domestic patent claim
- **Period-specific oral-history specialist** — domestic-life
  texture by decade

### Kitchen / Food-Preparation History

- **Culinary historian** — food culture, kitchen culture, the
  professional-to-domestic kitchen arc
- **Appliance historian** — refrigerator, stove, microwave,
  dishwasher development
- **Food-science historian** — preservation, processing,
  ready-meal industry
- **Kitchen-design historian** — Frankfurt Kitchen lineage,
  cabinet systems, golden-age-of-design kitchen
- **Cookware / utensil historian** — non-stick coating, knife
  steel, cast iron culture
- **Patent attorney / patent historian** — patent claims
- **Period-specific oral-history specialist**

### Bathroom / Plumbing History

- **Plumbing / sanitation historian** — Roman through Victorian
  through modern arc; Crapper / Twyford / fixtures lineage
- **Hygiene-product historian** — soap, toothpaste, deodorant,
  shampoo development; Procter & Gamble / Unilever territory
- **Bathroom-fixture historian** — toilet, shower, bath-tub
  evolution; specific manufacturer history
- **Public-health historian** — sanitation movement, hand-
  washing, indoor plumbing as public-health intervention
- **Patent attorney / patent historian** — patent claims
- **Period-specific oral-history specialist**

### Personal / Wearable History (e.g. Watches, Glasses, Pens)

- **Horological historian** — watch movement development,
  quartz crisis, mechanical revival
- **Optical historian** — eyeglass / contact-lens / corrective
  lens technology arc
- **Writing-instrument historian** — fountain pen, ballpoint,
  felt-tip, the pen industry's manufacturing history
- **Fashion / wearable-design historian** — for luxury-product
  chapters
- **Patent attorney / patent historian**
- **Period-specific oral-history specialist**

### Transportation History (cars, bikes, planes)

- **Automotive historian** — manufacturer-specific, era-specific
  expertise (early-auto, post-war, oil-crisis era, etc.)
- **Bicycle historian** — frame design, derailleur development,
  manufacturing arcs
- **Aviation historian** — commercial aviation, military aviation,
  general aviation each as separate sub-domain
- **Industrial-design historian** — for product-category chapters
- **Patent attorney / patent historian**
- **Period-specific oral-history specialist**

### Media / Communication History (TV, radio, print, internet)

- **Broadcast historian** — radio, television, cable, satellite
  development arcs
- **Print-media historian** — newspaper, magazine, book industry
  history
- **Telecommunications historian** — telegraph, telephone,
  cellular, internet protocol stack development
- **Computer / personal-computing historian** — mainframe-to-
  PC arc; Apple / IBM / Microsoft territory
- **Internet historian** — ARPANET / commercial internet /
  Web 1.0 / Web 2.0
- **Patent attorney / patent historian**
- **Period-specific oral-history specialist**

### Health / Medicine History

- **Medical historian** — specific era, specific specialty
  (anaesthesia, surgery, pharma, public health) as separate
  personas
- **Pharmaceutical-industry historian** — drug discovery,
  regulatory history, Big Pharma arc
- **Public-health historian** — epidemiology, vaccination,
  sanitation as public-health intervention
- **Medical-device historian** — stethoscope through MRI;
  device-specific personas where relevant
- **Patent attorney / patent historian** — pharma patents
  specifically; very different from industrial patents
- **Period-specific oral-history specialist**

### Sport / Leisure History

- **Sports-equipment historian** — equipment development per
  sport (tennis racquet, golf club, ski binding, etc.)
- **Sports-business historian** — league formation, broadcasting
  rights, merchandising arcs
- **Outdoor / recreation historian** — backpacking, climbing,
  cycling, watersports as separate sub-domains
- **Toy / game historian** — board games, video games, plush /
  doll industry as separate sub-domains
- **Patent attorney / patent historian**
- **Period-specific oral-history specialist**

## How the Stage 6 Beta Reader runs each persona

Per `editorial-suite.md` Stage 6 (updated v2.7.11), the Beta
Reader stage now runs as a **persona-loop** rather than a
single pass:

1. Read `engine-data/beta-reader-personas.md` to load the
   project's persona enumeration.
2. For each persona:
   a. Construct the dispatch prompt with the persona's
      specialist territory, reading list, and detection
      priorities loaded as system context.
   b. Identify the chapters this persona is responsible for
      (per the persona's chapter list).
   c. Dispatch the Beta Reader subagent with the persona-
      loaded system prompt and the chapter list.
   d. Subagent returns a per-persona report: domain-specific
      flags, contested-priority claims caught, attribution
      questions raised, jargon-precision concerns, technical
      misstatements identified.
3. Aggregate persona reports into the consolidated Stage 6
   Beta Reader output. Cross-persona contradictions are
   themselves findings (one persona accepts a claim another
   contests — the Architect resolves).

**Subagent Output Verification binding (MANDATORY — see
`subagent-output-verification.md`).** Each persona dispatch
MUST include explicit task scope, required evidence format
(file path, line number, exact extracted text of the flagged
claim, persona's domain-specific reasoning), and a
FAILED_DISPATCH return contract for cases where the persona
cannot complete (e.g., the chapter content is empty, the
chapter file failed Read-Verification). The main agent spot-
checks at least one evidence item per persona return.

## What this protocol does NOT do

- It does **not** replace Stage 9b External Source Verification
  — the Beta Reader catches claims a domain expert would
  question; Stage 9b mechanically verifies the claims. Both
  stages are required.
- It does **not** apply to NF projects with no technical /
  historical / biographical / attribution layer (memoir of
  pure personal experience, philosophy without empirical
  claims, etc.). For those projects the Beta Reader runs as
  a single generic informed-reader pass.
- It does **not** require the personas to fully replicate
  human academic expertise — the persona-load is a domain-
  context loading exercise, calibrating the Beta Reader's
  threshold for noticing rather than promising domain-PhD-
  level rigor.

## Anti-patterns this protocol prevents

- **Generic-reader miss** — claims that domain experts would
  catch but generic informed readers would not (the canonical
  Pollock 657 / Henry Leland / Halsey Taylor errors)
- **Single-pass coverage** — one Beta Reader pass attempting to
  cover all domains in a manuscript spanning multiple specialist
  territories
- **Architect-default personas** — using a generic template
  persona list rather than enumerating per-project specialists
- **Persona-without-chapters** — a persona named but never
  assigned specific chapters, so the persona's expertise is
  not actually loaded against any specific text
- **Persona-without-reading-list** — a persona named but not
  loaded with the canonical works that constitute its baseline,
  reducing the persona to a label rather than a domain-context
  load

## Cross-references

- `editorial-suite.md` Stage 6 — the runtime spec that invokes
  this persona enumeration
- `core-pipeline.md` Phase 2 (Bible construction) — where the
  persona enumeration is performed
- `subagent-output-verification.md` — binding governing the
  Beta Reader subagent dispatch
- `fact-audit.md` § Stage 9 Architecture (9a + 9b split,
  v2.7.11) — Stage 9b verifies claims the personas flag

## Silent-Failure Audit

This spec is exempt from the Silent-Failure Audit section
requirement (Check 10) because it IS audit infrastructure
rather than a feature spec. The exemption is granted in
the engine's spec-lint repo CI discipline `check_silent_failure_audit` exempt
pattern (this is an "audit" file by name).
