---
name: core-pipeline-nonfiction
description: "Master pipeline orchestrator for Ideorix Non-Fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Non-Fiction Core Pipeline

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine
> *The Ideorix writing, editing, and publishing system is © 2025 James Harvey Media. All rights reserved.*

## License Note

Licence verification is handled by SKILL.md on session start. Do not duplicate it here.

---

## Cross-Cutting Bindings (engine-wide)

This pipeline binds nine cross-cutting protocols. Every spec
in the engine MUST conform to these where applicable. The
canonical catalog is `silent-failure-audit.md`.

1. **Architect Mode** — Q13 = Research Bible Only encoding (NF)
2. **Verification Discipline** — when real-world anchors are present (`verification-discipline.md`)
3. **File-Write Hygiene** — every critical-path file write (this section + Subagent dispatch forbidden + Chained-Edit Truncation Safeguard + File-Freshness Post-Write Discipline)
4. **Edit-Tool Typographic Fidelity** — every Edit on user manuscripts (this file § Edit-Tool Typographic Fidelity)
5. **Read-Verification** — every Read of user-supplied source files (`read-verification.md`)
6. **Web-Content Verification** — every WebFetch / WebSearch (`web-content-verification.md`)
7. **Subagent Output Verification** — every evidence-bearing subagent dispatch (`subagent-output-verification.md`)
8. **Bash-Output Verification** — every Bash command whose output routes a decision (`bash-output-verification.md`)
9. **AskUserQuestion Disambiguation** — every user question whose answer routes a decision (`ask-user-disambiguation.md`)

The discipline that catches new instances before they ship is
documented in CLAUDE.md § Silent-Failure Audit Discipline and
enforced by the engine's spec-lint repo CI discipline Check 10.

## File Operation Policy — Bash-Direct Write + Verify

**THE WRITE TOOL IS NOT RELIABLE FOR FILE PERSISTENCE.**

First documented April 2026 (last verified May 2026): the Claude
Desktop virtiofs mount silently drops writes to subdirectory paths.
The Write tool reports success but files do not reach the user's disk.
This was confirmed across multiple projects. Root-level files persist
normally; subdirectory writes fail silently. The bash side-file +
mv-swap protocol below is POSIX-atomic and works identically across
every environment tested; if the underlying virtiofs bug is no longer
reproducible, the protocol still applies (it adds no overhead and
removes a class of silent-overwrite failures).

**v2.7.42 split: bash protocol vs. Edit/Write tool by file class.**

The previous policy mandated bash cat-and-mv for ALL critical-path
files. v2.7.42 splits the policy by file class because of a real
production incident where the bash protocol corrupted a long-lived
state file (`pipeline-checkpoint.md` reduced to 60K nulls + 2K
trailing valid content after ~18 cumulative bash appends across one
session).

The two file classes:

**Class 1: NEW file creation.** Files born from this write — chapter
drafts, briefs, audit reports, snapshots, per-chapter outputs, fresh
report files. The bash side-file + mv-swap pattern is REQUIRED for
these (the virtiofs subdirectory-write bug is real and the bash
protocol bypasses it). The rest of this section governs Class 1.

**Class 2: LONG-LIVED STATE FILES** modified across many sessions and
also modified by the harness's Edit/Write tools. These include:

- `engine-data/pipeline-checkpoint.md`
- `engine-data/research-bible.md` / `engine-data/story-bible.md`
- `engine-data/entity-canon.md`
- `engine-data/project-config.md`
- `engine-data/running-banlist.md`
- `engine-data/section-delivery-log.md`
- Any audit-ledger file maintained over multiple sessions

For Class 2 files, **DO NOT use bash cat-and-mv.** Use the Edit tool
(for surgical changes) or the Write tool (for full rewrites) only.
Rationale: the bash mount can hold a stale view of these files after
the harness has Edit-modified them. A bash `cat existing > tmp` reads
from the stale view — often returning zeros where the previous
allocation's blocks have been deallocated. The subsequent append +
mv faithfully writes a corrupted file. Each subsequent bash append
reproduces the corruption because each one starts from the now-
corrupted on-disk state. The post-write checks (`ls`, `stat`,
`tail`) all probe metadata or trailing bytes; none catch a leading
null prefix.

**MANDATORY post-write integrity check for Class 2 files (regardless
of write tool):** after any write to a long-lived state file, run a
one-line header check to confirm the file's expected first line is
present:

```bash
head -1 {project-path}/engine-data/pipeline-checkpoint.md \
    | grep -q '^# Pipeline Checkpoint' \
    || echo "FATAL: pipeline-checkpoint.md header missing — file may be corrupted"
```

This catches corruption on the first occurrence rather than after 18
cumulative appends. Tail-byte checks and size checks both miss
leading-null corruption; only a header check surfaces it.

**MANDATORY WRITE PROTOCOL — Class 1 (NEW file creation):**

Do NOT use the Write tool or Edit tool for any Class 1 critical-path
file. Instead, use the bash side-file + mv-swap pattern:

```bash
# 1. Write content to a TEMPORARY file (new file — always works)
cat > /tmp/ideorix-write-{filename} << 'IDEORIX_EOF'
{file content here}
IDEORIX_EOF

# 2. Move the temporary file to the target path (replaces inode)
mv /tmp/ideorix-write-{filename} {target-path}/{filename}

# 3. Force filesystem sync
sync

# 4. Verify existence
ls -la {target-path}/{filename}

# 5. Verify byte count
stat -c %s {target-path}/{filename}
wc -w {target-path}/{filename}
```

**Why this works:** Creating a new file via bash succeeds reliably.
The `mv` command replaces the file's identity (inode) at the target
path, bypassing the virtiofs caching that causes in-place writes to
fail.

**For chapter files, ALSO run the integrity check after mv:**

```bash
bash scripts/chapter-integrity-check.sh {path}/engine-data/chapters/ch{NN}.md
```

The integrity check (v2.7.69+) verifies the chapter `.md` is
on disk, non-zero, contains zero NULL bytes (`\x00`), is valid
UTF-8, and (if a YAML frontmatter was opened on line 1) the
frontmatter is closed within the first 50 lines. NULL bytes
are the canonical silent-failure signal for the awk-getline-
into-heredoc anti-pattern (see below) and other Bash patterns
that report exit 0 while corrupting the output stream.

For pre-v2.7.69 verification (word-count parity + last-line
terminal-punctuation), `scripts/word-count-check.sh` still
applies — invoke it alongside the integrity check:

```bash
bash scripts/chapter-integrity-check.sh {path}/engine-data/chapters/ch{NN}.md
bash scripts/word-count-check.sh        {path}/engine-data/chapters/ch{NN}.md {target-words}
```

Together these verify: (1) word count is plausible (>=90% of
brief target), (2) last line ends with terminal punctuation
(not mid-word), (3) no null bytes, (4) UTF-8 valid, (5)
frontmatter closed. If any check fails, the write produced a
corrupted file. STOP — do NOT mark the checkpoint column as Yes.

This is mandatory after every chapter-file Write at step 7
(Content Writer) and step 10 (Humaniser). The check exits
non-zero on any failure; the orchestrator must STOP and re-run
the agent rather than marking the checkpoint column as Yes.

**Bash-Write Corruption (v2.7.69 first observed; mechanism reassessed v2.7.73):**

Across v2.7.68–v2.7.72 the engine observed multiple user-session
incidents in which a bash write to a chapter or engine-data file
returned exit 0 but produced a corrupted artifact — NULL-byte fill,
line-count collapse, or both, at the expected file size.
v2.7.69–v2.7.71 inferred the cause as specific awk-getline command
patterns and shipped a preventive matcher; v2.7.72 added a
PostToolUse integrity check on chapter writes. The intermittent
recurrences across those releases (each on a different command
shape) prompted a controlled v2.7.73 diagnostic that disproved the
command-pattern theory.

**Actual mechanism (confirmed at v2.7.73):** intermittent failure of
the Cowork-Windows filesystem bridge (FUSE / SMB / 9P shim layer)
during the cross-FS `mv` that backs the write. The bridge allocates
the destination file at the expected byte size but fails to flush
the actual bytes, leaving NULLs. The bash command itself is innocent —
awk-getline, sed-only, and `cat > … <<EOF` all exhibit the same
corruption profile when the bridge stutters, and all produce clean
output when the bridge is healthy. A v2.7.73 isolated reproduction
ran awk + matching-anchor, awk + non-matching-anchor, and sed `i\`
control on identical sacrificial files: all three produced clean,
identical output. The corruption is environmental, not pattern-based.

**Also confirmed at v2.7.73:** writing a side-file to Linux `/tmp`
and then `mv`ing across to the Windows-mounted target is **rejected
outright** by the bridge with `Operation not permitted` (EPERM).
The same-filesystem temp pattern (`SIDE="${TARGET}.tmp.$$"`) is the
only viable write idiom on Cowork-Windows. Any earlier guidance to
write side-files in `/tmp/` was environmentally wrong and should be
ignored.

**The canonical defense is verify-after-write, not avoid-awk.**
After any critical engine-data write, run the integrity check:

```bash
bash scripts/chapter-integrity-check.sh {path}/engine-data/{file}.md
```

If the check fails, the write was caught by a bridge stutter.
Restore from `engine-data/snapshots/` and retry — the failure is
intermittent, the retry usually succeeds.

**The recommended write pattern** for any engine-data file is the
same-filesystem temp-then-mv plus integrity check:

```bash
TARGET={path}/engine-data/{file}.md
SIDE="${TARGET}.tmp.$$"
# Write the new content to SIDE — any tool works (cat heredoc, sed,
# awk, or Write tool); pattern choice doesn't affect corruption rate.
cat > "$SIDE" << 'IDEORIX_EOF'
{new content}
IDEORIX_EOF
mv "$SIDE" "$TARGET"
sync
bash scripts/chapter-integrity-check.sh "$TARGET"
```

For chapter and engine-data writes via the Write/Edit/MultiEdit
tools, the v2.7.72/73 PostToolUse hook runs the integrity check
automatically — no manual invocation required for those paths.
For bash-driven writes (heredoc, sed, awk), invoke the check
explicitly as shown above.

**On the v2.7.70/71 anti-pattern matcher:** the PreToolUse hook
that historically blocked awk-getline patterns is rescoped at
v2.7.73 to ADVISORY-only (exit 0 + stderr note). It no longer
blocks. The matcher continues to log every Bash invocation for
diagnostic continuity, but the BLOCK behaviour was preventing
legitimate commands without actually preventing the corruption
mode. See `silent-failure-audit.md` row 65 (v2.7.73 reassessment)
for the full diagnostic narrative.

**Chained-Edit Truncation Safeguard (read this carefully):**

The Edit tool can truncate mid-word when the replacement text is
large (typically >2 KB per call) or when the file is large
(>15 KB) and the orchestrator is making multiple sequential Edit
calls on the same file. The signature is unambiguous: the file
ends in mid-word, mid-sentence, or mid-token (`workin`,
`operating ou`, `Iron-House-adjacen`). The orchestrator's Bash +
Write verification output reports success even though the file is
corrupt.

This is a tool-layer behaviour at the file-edit infrastructure
level. It is not specific to any project, genre, or user prompt.
It is reproducible across sessions and not solved by restarting.

**Mitigations (apply in this order):**

1. **Prefer Write over chained Edit for chapter-scale rewrites.**
   When you are extending or revising a chapter and the change
   touches more than half the file, write the whole revised
   chapter once via the bash-heredoc + mv pattern rather than
   accumulating sequential Edit patches. A single Write rarely
   truncates; chained Edits on >15 KB files truncate frequently.

2. **Cap individual Edit replacements at ~2 KB.** If you must use
   Edit (because you're patching a known section of a large
   file), keep each Edit's `new_string` under approximately 2 KB.
   Split a 6 KB section rewrite into three 2 KB Edits rather than
   one 6 KB Edit.

3. **Run the integrity check after EVERY chapter-file Edit, not
   just at the end of the pipeline.** The chapter-file integrity
   check (`scripts/word-count-check.sh`) is mandatory at the major
   pipeline stages (post-Content-Writer, post-Humaniser, post-fix).
   It is ALSO mandatory after any interactive / out-of-pipeline
   Edit that touches a chapter file. Truncation caught after one
   Edit is recoverable; truncation that propagates through
   multiple editorial stages may not be.

4. **For chained-Edit work that cannot be avoided, run the spot
   check between Edits:**
   ```bash
   tail -c 200 {path}/engine-data/chapters/ch{NN}.md
   ```
   If the last 200 characters end mid-word, the most recent Edit
   truncated. Discard, re-stage, and use Write or smaller Edits.

5. **Never declare a chapter complete on the basis of the Edit
   tool's success return.** The Edit tool reports success even
   when the on-disk file is truncated. Verification is integrity
   check + word count, not tool-call return status.

The same safeguard applies to other large pipeline files
(entity-canon.md when the canon grows past ~10 KB; pipeline-
checkpoint.md once the chapter table is long; running-banlist.md
in the late stages of a long manuscript). When any
critical-path file is being edited and the file is over ~10 KB,
prefer Write over chained Edit and run the integrity check after
each modification.

**ALL verification reads use bash, not the Read tool.** The Read tool
may show a cached view that doesn't match disk. Use `cat`, `head`,
`tail`, `wc`, `grep` via bash for any verification check. The Read
tool is acceptable only for loading content into the prompt (Research
Bible, entity canon, summaries for the Architect) — never for
confirming a write succeeded.

**Critical-path files (bash-direct write + verify REQUIRED):**
- `engine-data/entity-canon.md` (Phase 2D)
- `engine-data/pipeline-checkpoint.md` (Phase 2E + per-chapter)
- `engine-data/running-banlist.md` (Phase 2E + per-chapter)
- `engine-data/chapter-briefs/ch{NN}-brief.md` (step 5a)
- `engine-data/chapters/ch{NN}.md` (step 7 + step 10)

**Run log (MANDATORY — observability):**

After every critical-path Write + Bash `ls` verification (whether
successful or failed), append one line to `engine-data/run.log`:

```
{iso8601} | {phase} | {step} | {agent} | {verdict} | {artifact_path}
```

Example:
```
2026-04-22T19:35:12Z | Phase3 | step7 | content-writer | OK | engine-data/chapters/ch01.md
2026-04-22T19:36:08Z | Phase3 | step18 | checkpoint | OK | engine-data/pipeline-checkpoint.md
2026-04-22T19:38:44Z | Phase3 | step5a | oc-agent | FAIL | engine-data/reports/ch02-outline-conformance.md
```

Use bash-append:
```bash
echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) | $PHASE | $STEP | $AGENT | $VERDICT | $PATH" >> {project_root}/{title}/engine-data/run.log
```

The run log is for debugging silent failures. When the user reports
"chapter X never appeared," the run log shows whether the Write was
attempted, whether `ls` saw the file, and what step it happened at.

1. **After a Write tool call on a critical-path file, call Bash
   `ls {expected-path}` to confirm the file is on disk.** This is
   NOT a Read-back — `ls` shows the filename and metadata only,
   never the content, and does not pin the file to the Sources
   panel.

   **Critical-path files (Bash ls verification REQUIRED):**
   - `engine-data/entity-canon.md` (Phase 2D)
   - `engine-data/pipeline-checkpoint.md` (Phase 2E + per-chapter updates)
   - `engine-data/running-banlist.md` (Phase 2E starter + per-chapter updates)
   - `engine-data/chapter-briefs/ch{NN}-brief.md` (step 5a)
   - `engine-data/chapters/ch{NN}.md` (step 7 Content Writer + step 10 Humaniser)
   - `engine-data/reports/ch{NN}-humaniser-notes.md` (step 10)
   - `engine-data/reports/ch{NN}-verification.md` (step 12)
   - `engine-data/summaries/ch{NN}-summary.md` (step 13)
   - `engine-data/revisions/ch{NN}-v{N}.md` (step 14)

   **If Bash `ls` returns "No such file or directory":** The Write
   tool was not actually called. STOP. Re-run the step. Do NOT mark
   the pipeline checkpoint column as Yes.

2. **Do NOT Read a file back to verify it exists.** Use Bash `ls`
   instead. `Read` loads content (expensive, pins to Sources panel);
   `ls` confirms existence (cheap, invisible to Sources panel). They
   are not interchangeable.

3. **Trust the pipeline-checkpoint as the source of truth for "did
   this step complete"** — once the Bash ls check has passed and the
   checkpoint column has been updated.

4. **Use the Read tool only when you need the CONTENT of a file.**
   Valid uses: loading running banlist into the Content Writer's
   opening hard constraints, loading entity canon, loading a chapter
   for verification, loading the Research Bible for Architect
   context. Invalid uses: existence-verification reads (use Bash ls).

5. **For cross-chapter checks**, read the pipeline-checkpoint once
   and trust the recorded field values — but remember, checkpoint
   fields are only truthful if step 18 correctly performed its Bash
   ls verification before writing Yes.

### Bash ls invocation pattern

The canonical pattern:

```bash
ls -la {expected-full-path}
```

Exit 0 with a size > 0 → file exists, proceed.
"No such file or directory" or empty output → Write tool was not
invoked. STOP.

Do NOT use Bash `cat`, `head`, or `tail` on the expected path —
those are content-loading operations. `ls` is the existence check.

### Edit-Tool Typographic Fidelity (MANDATORY for any Edit on user manuscripts)

**Word DOCX files use typographic curly characters by default**:
U+2018 `'` and U+2019 `'` (single quotes); U+201C `"` and U+201D
`"` (double quotes); U+2013 `–` and U+2014 `—` (en/em-dashes);
U+2026 `…` (ellipsis). When Read returns a chapter file converted
from DOCX, these Unicode characters are preserved as their actual
code points — even though many editors and renderers display them
visually identical to their ASCII counterparts (`'`, `"`, `-`,
`--`, `...`).

The Edit tool matches `old_string` byte-for-byte. If the source
file has `don't` (curly U+2019) and the agent constructs an Edit
with `old_string: "don't"` using ASCII U+0027, the Edit fails to
find the target. The change either silently drops, or — worse —
the agent retries with shell-escaping or string-escaping that
introduces new artifacts (`’`, `\'`, `'`) into the file
content.

This is a documented operational failure mode: it surfaced when a
user ran a tracked-changes editorial pass and reported that some
suggested changes had not been applied to their manuscript despite
the agent reporting success. For non-fiction in particular,
citations / footnotes / source attributions often contain curly
quotes and en-dashes (page ranges, date ranges, name initials),
making typographic fidelity especially important.

**Rules for any Edit on a user manuscript chapter file:**

1. **Read before Edit, every time.** Before constructing any
   Edit `old_string`, run Read on the same file to see the exact
   byte representation of the target passage. Copy bytes from
   the Read output into `old_string` — do NOT retype from visual
   memory.

2. **Preserve typographic style in `new_string`.** If the
   surrounding text uses curly quotes, the replacement uses
   curly quotes. If the source uses em-dashes, the replacement
   uses em-dashes. The agent MUST NOT silently normalize curly →
   straight (or vice versa) as a side effect of editorial fixes.

3. **If Edit fails to find an obviously-present target, suspect
   typographic mismatch.** Re-Read the file and inspect the bytes
   of the target passage. Common culprits:
   - Single quote: `'` (U+0027 ASCII) vs `'` (U+2019 curly)
   - Double quote: `"` (U+0022 ASCII) vs `"` `"` (U+201C/U+201D curly)
   - Apostrophe in contractions (don't / can't / it's): nearly
     always U+2019 in DOCX-sourced text
   - Dash: `-` (U+002D ASCII hyphen-minus) vs `–` (U+2013 en-dash,
     used for page ranges 23–47 and date ranges 2019–2023) vs
     `—` (U+2014 em-dash, used for parenthetical asides)
   - Ellipsis: `...` (three ASCII dots) vs `…` (U+2026 single
     character)
   - Non-breaking space: ` ` (U+0020 normal) vs ` ` (U+00A0
     non-breaking) — particularly common in French-language
     prose and in date / number formatting

4. **For tracked-changes flows specifically**, the Typographic
   Fidelity binding in `tracked-changes.md` extends this rule to
   the change-record pipeline: byte-faithful capture at Phase A,
   byte-faithful change records at Phase B, profile verification
   at Phase C.

5. **For citation / source-attribution edits specifically** (NF
   concern): citations often use curly quotes for paper titles,
   en-dashes for page ranges, and special characters for author
   initials. A typographic mismatch in a citation Edit can
   produce a corrupted or unfindable citation in the manuscript
   even when the citation correction itself is bibliographically
   correct.

**This rule does NOT prohibit normalization** — if the user has
explicitly requested quote / dash / ellipsis normalization (e.g.,
"convert all straight quotes to curly throughout the manuscript"
or as part of a Heritage Text modernization pass), the engine
performs the requested operation as a deliberate, logged change.
The rule prohibits SILENT normalization as a side effect of
something else.

### File-Freshness Post-Write Discipline (v2.7.8 extension)

File-Write Hygiene verifies on-disk integrity AT WRITE TIME
(byte count, line count, word count, terminal-character check).
The discipline catches truncation and Write tool failures the
moment they happen.

**Extension:** when a spec READS a file the engine wrote
earlier in the same session, the engine MUST verify the file
hasn't been modified externally (by the user, by a parallel
process, or by another agent) since the last engine write.
Without this check, an in-context value (e.g. a Research Bible
held in the agent's working memory) can diverge from the
on-disk version after the user edits the file mid-flow, and
subsequent writes overwrite the user's edits silently.

**Per-read discipline:**

1. The engine maintains a per-session ledger of files it has
   written, recording (file path, mtime at write, sha256 at
   write).
2. Before re-reading any of those files in the same session,
   run `stat -c %Y {path}` and compare to the recorded
   mtime. If different, the file was modified externally.
3. If modified externally, the engine MUST re-Read the file
   in full (do NOT trust in-context cached version) AND
   surface to the user before any subsequent write:

```
NOTICE — {file_path} was modified after I wrote it earlier in
this session.
  Engine-write mtime: {recorded_mtime}
  Current mtime:      {actual_mtime}

I'll re-read the file to capture your changes before
proceeding. If you'd rather I overwrite your changes with the
engine's working version, tell me explicitly.
```

4. Re-Read invokes Read-Verification (per-format threshold) to
   ensure the freshly-read content is real (not empty due to
   user mid-edit save).

**Flows where this discipline is critical:**

- Phase 5 editorial stages (already wired with per-stage file
  freshness check; this is the foundation of that pattern,
  generalized)
- Continue Researching (re-loads existing project's prior
  chapter files, sources, research-bible; user may have
  hand-edited between sessions or mid-session)
- Edit & Revise (returning user; user may have edited
  manuscript files since last engine touch)
- Tracked-Changes Phase A → C (source DOCX might be modified
  between Phase A capture and Phase C write — NF-specific
  concern: citations and footnotes are protected categories
  that the user is most likely to hand-edit)

**Anti-pattern this prevents:** engine writes Research Bible
at T=0; user manually edits bible at T=5; engine writes a
chapter brief at T=10 against its T=0 in-memory version;
brief contradicts the user's T=5 edits. The user catches it
only when reviewing the brief or a subsequent chapter. NF-
specific blast radius: the source ledger that the Verification
Discipline binding cross-checks against can drift silently
across this gap.

### Subagent dispatch forbidden for file-writing steps

Subagents run in isolated contexts. Their Write tool calls may not
propagate to the user's filesystem, causing silent persistence
failures.

**The following pipeline steps MUST run in the parent conversation —
subagent dispatch is FORBIDDEN:**

- Step 5a: OC Agent's Write of the brief + audit footer
- Step 7: Content Writer's Write of the initial chapter draft
- Step 10: Humaniser's Write of the cleaned chapter + humaniser-notes
- Step 12: Verification's Write of the consolidated report
- Step 13: Chapter summary Write
- Step 14: Pre-save revision snapshot Write
- Step 18: Pipeline checkpoint update Write
- Phase 2D: Entity canon Write
- Phase 2E: Pipeline checkpoint + running banlist starter Writes

Subagents MAY be used for pure reasoning (text analysis, conformance
checks on in-memory content) but NOT for any step that ends in a
Write to disk. If a subagent returns claiming to have written files,
the parent conversation MUST re-do the Writes in the parent context
and verify with Bash ls.

### Why this policy exists

Commit 1 ("Trust the Write Tool") removed defensive Read-backs to
reduce Sources panel clutter and save tokens. What it missed: the
Read-backs forced the engine to actually call Write in the first
place — because a narrated-but-unsaved file would fail the Read-back
loudly. Without that check, "Trust the Write tool" became "Trust
the engine's narration that it called Write."

Bash ls is the correct replacement: verifies persistence (like
Read-back did) without loading file content (unlike Read-back).
Critical files get verified; Sources panel stays clean.

**This policy applies retroactively.** Any older protocol text
that says "Read the file back to confirm" is DEPRECATED. Use Bash
ls instead.

---

## Graceful Degradation for Pre-Hardening Projects

This policy covers three project states:

- **New project** (starting fresh) → **MODERN MODE — all new features active**
- **Existing project with modern schema** (pipeline-checkpoint.md present with
  the new columns) → **MODERN MODE — all new features active**
- **Existing project with legacy schema** (chapters on disk, no
  pipeline-checkpoint.md, or progress-dashboard.md instead) → **LEGACY
  MODE — only after explicit user confirmation**

### The rule

1. **DEFAULT to MODERN MODE.** Every project is modern unless clearly proven
   otherwise. Missing state files on a new project are NOT evidence of
   legacy — they're an instruction to INITIALIZE.

2. **Only engage LEGACY MODE when ALL THREE of these are true:**
   - `engine-data/pipeline-checkpoint.md` is missing OR has the old schema
     (no `OC Report` / `OC Verdict` / `Banlist Loaded` / `Canon Loaded` /
     `Canon Check` columns)
   - Actual chapter files exist under `engine-data/chapters/` (i.e., this
     is a resumed project, not a new one)
   - The user explicitly confirms via AskUserQuestion: *"This project was
     started under an older Ideorix Non-Fiction version. Continue in
     legacy-compatibility mode (no mid-run migration) or run the migration
     tool to upgrade it to the modern schema?"*

   Without ALL THREE, default to MODERN MODE and initialize missing files.

3. **Never silently degrade a new project to legacy.** Missing
   `entity-canon.md` on a project with zero chapters means "not created yet"
   — run the Research Bible's Entity Canon Lockfile protocol (Phase 2D) to
   create it. It does NOT mean "legacy project."

### Decision tree (authoritative)

```
IF engine-data/chapters/ directory exists AND contains ch{NN}.md files:
    # Project has existing chapters — could be resumed modern or legacy
    IF engine-data/pipeline-checkpoint.md exists:
        IF checkpoint has the new columns (OC Report, OC Verdict, etc.):
            mode = MODERN
        ELSE:
            # Old schema checkpoint
            ASK user: "Upgrade schema to modern, or continue legacy?"
            mode = user choice
    ELSE:
        # Chapters but no checkpoint — legacy project
        ASK user: "This looks like a pre-hardening project. Continue in
                  legacy mode, or run migration to modernize?"
        mode = user choice
ELSE:
    # No chapters — new project
    mode = MODERN
    # Initialize all new-schema files during Phase 2
```

### MODERN MODE requirements (what the pipeline MUST do)

In MODERN MODE, the pipeline MUST produce and maintain these files:

| File | Created at | Contents |
|---|---|---|
| `engine-data/pipeline-checkpoint.md` | Phase 2E (before the Approval Gate) | New-schema checkpoint with all columns, schema header, header-row-only tables (see Pipeline Checkpoint section) |
| `engine-data/entity-canon.md` | Phase 2D (after Source Extraction) | Flat name lookup generated from Research Bible Section 7 (Key Figures), Section 4 (Sources), and Section 5 (Subject Context) |
| `engine-data/running-banlist.md` | Phase 2E (before the Approval Gate) | Empty starter with HARD CONSTRAINTS / WATCHLIST / RETIRED sections, header tables with no rows |
| `engine-data/reports/ch{NN}-outline-conformance.md` | Step 5a of each chapter | OC Agent audit (or embedded as IDEORIX:AUDIT footer in brief file) |
| `engine-data/reports/ch{NN}-humaniser-notes.md` | Post-Humaniser step 10 of each chapter | Humaniser detection report + change summary (see `prose-humaniser.md` Output section) |
| `engine-data/reports/ch{NN}-verification.md` | Step 12 of each chapter | Consolidated 5-agent verification report |

**If any of these files is missing DURING a run on a new or modern project,
STOP and create it rather than degrading to legacy mode.**

### LEGACY MODE requirements (only after explicit user confirmation)

In LEGACY MODE, skip the new-feature steps:
1. Skip Phase 2D (Entity Canon Lockfile generation)
2. Skip Running Banlist initialization
3. Skip step 5a (OC Agent) during chapter generation
4. Skip Canon Compliance Check in Source Guardian / Expert Tracker
5. Skip Writer Pre-Load steps 6a A (banlist) and 6a B (canon) — use empty placeholders
6. Preserve the project's existing dashboard schema (`progress-dashboard.md`
   stays; don't start a competing `pipeline-checkpoint.md`)

Non-fiction-specific hardening (fact-checking protocol, citation verification,
Source Guardian's core checks) all remain active in both modes. The File
Operation Policy (Trust the Write Tool) also applies regardless of mode.
Legacy mode is a compatibility layer for old projects, not a feature-limited
tier for new ones.

### Why this matters

Previous builds had a looser detection rule that silently engaged LEGACY
mode on new projects whose Phase 2D hadn't run yet. Result: new projects
got the old pipeline behavior, the OC Agent never ran, the Entity Canon
was never created, and users had no indication that the new features were
disabled. This version defaults to MODERN and requires explicit
confirmation for LEGACY — safer, more transparent, and prevents silent
degradation.

## Writing Style Directive — Use "Section N" in full

When referring to Research Bible sections in any generated output (Research
Bible itself, chapter briefs, verification reports, dashboards, Phase
summaries, approval-gate prompts, user-facing messages), write
**"Section N"** in full. Do NOT use the "Section" (section symbol) as shorthand.
Examples:

- CORRECT: "See Research Bible Section 4 (Key Sources)."
- CORRECT: "Section 7 lists every Key Figure."
- WRONG: "See Research Bible Section 4."
- WRONG: "Section 7 lists every Key Figure."

Non-technical readers frequently do not recognise the "Section" symbol, and it
creates a pseudo-legalistic tone that conflicts with accessible non-fiction
prose. "Section" is universally understood; "Section" is not. This directive
applies to every user-facing artefact the engine generates. It does NOT
apply to user-supplied content — if the user's own outline uses "Section",
preserve it verbatim.

## File Location Discipline (MANDATORY)

Every file the pipeline produces has ONE canonical location. Inventing
new locations, subfolders, or intermediate artefacts is a protocol
violation. Users lose trust and waste tokens when the engine-data root
fills with unrecognised files.

### Canonical directory structure

```
Ideorix-Projects/[Title]/
├── manuscript/              ← User-facing final deliverables (.docx, .epub, etc.)
├── marketing/               ← Cover concepts, blurbs, social-media assets
└── engine-data/             ← Internal engine state
    ├── research-bible.md
    ├── sources.md
    ├── entity-canon.md
    ├── pipeline-checkpoint.md
    ├── running-banlist.md
    ├── humaniser-tracker.md
    ├── market-pulse.md
    ├── outline.md
    ├── project-config.md
    ├── research-companion.docx    (Research Bible Only mode)
    ├── chapters/              ← Final chapter prose, ONE file per chapter
    │   └── ch{NN}.md
    ├── chapter-briefs/        ← Structural Architect briefs (with IDEORIX:AUDIT footer)
    │   └── ch{NN}-brief.md
    ├── summaries/             ← 3-5 sentence continuity summaries
    │   └── ch{NN}-summary.md
    ├── reports/               ← All per-chapter verification + humaniser reports
    │   ├── ch{NN}-outline-conformance.md     (FAIL overflow only — rare)
    │   ├── ch{NN}-humaniser-notes.md
    │   ├── ch{NN}-verification.md
    │   ├── ch{NN}-preview-report.md          (on-demand only)
    │   ├── ch{NN}-oc-detail.md                (FAIL overflow only)
    │   ├── batch-{N}-edit.md
    │   ├── batch-{N}-health-report.md
    │   └── batch-{N}-preview-report.md
    └── revisions/             ← Automatic pre-save snapshots
        └── ch{NN}-v{N}.md
```

### Files the pipeline MUST NOT write

**Outline-time intermediate work (FORBIDDEN at engine-data root):**
- `concept-seeds.md`, `thesis-seeds.md`
- `protagonist.md`, `antagonist.md`, `supporting-cast.md` (fiction
  idioms; non-fiction should never produce these regardless)
- `genre-architecture.md`, `hook-positioning.md`
- `chapter-outline.md` (the chapter outline lives in Research Bible
  Section 9 and in `outline.md`)
- `ending.md`, `tension-tracker.md`
- `key-figures.md` separate from the Research Bible or sources.md

Non-fiction outlining consolidates everything into the Research Bible
and `outline.md`. Persisting intermediate reasoning as separate root
files is forbidden.

**Intermediate chapter drafts (FORBIDDEN — HARD ERROR):**
- `ch{NN}-draft.md` — the most common mistake. Users look for `ch01.md`;
  a `-draft` suffix hides the chapter from them. If found, rename to
  `ch{NN}.md` immediately.
- `ch{NN}-writer-draft.md`
- `ch{NN}-humanised.md`, `ch{NN}-humanized.md`
- `ch{NN}-final.md` (use `chapters/ch{NN}.md` instead)
- `ch{NN}-pre-humaniser.md`, `ch{NN}-post-writer.md`

The chapter filename is ALWAYS `ch{NN}.md` — no suffix of any kind.
The Content Writer and Humaniser pass the prose in memory. Only the
FINAL prose after both passes is persisted, and only to
`chapters/ch{NN}.md`.

**Per-chapter report files outside `reports/` (FORBIDDEN):**

Any `ch{NN}-verification.md`, `ch{NN}-humaniser-notes.md`,
`ch{NN}-preview-report.md` etc. at engine-data root. These must live
under `engine-data/reports/`.

**Checkpoint schema invention (FORBIDDEN):**

When Phase 2E creates `pipeline-checkpoint.md`, the Chapter Progress
table's column headers MUST be exactly:

```
| Ch | Brief | OC Report | OC Verdict | Banlist Loaded | Canon Loaded | Written | Saved | Verified (disk) | Humanised | V-Score | Canon Check | Report Saved | Summary |
```

Do NOT substitute free-form column names ("Structural Architect
brief", "Content Writer draft", "Source Guardian", "Dashboard shown",
"{Username} approved", etc.). The step 6 OC-Report pre-gate check
reads the `OC Report` column by exact name; renaming it breaks the
gate.

### Self-check before every Write tool call

1. Is this path in the canonical directory structure above? If not,
   STOP — do not invent a new location.
2. Is this file in the FORBIDDEN list? If yes, STOP — keep the content
   in memory or merge it into the canonical file that consolidates it.
3. If this is a chapter report, is it under `reports/`? If not, correct
   the path before writing.
4. If this is a chapter prose file, is it at `engine-data/chapters/ch{NN}.md`?
   If not, correct the path before writing. **NEVER write chapter prose to
   `manuscript/`, `manuscript/chapters/`, or the `engine-data/` root.** The
   `manuscript/` folder is for user-facing `.docx` deliverables at Phase 6
   only. If `engine-data/chapters/` does not exist, create it before writing.

The rule: **if it isn't in the canonical directory structure, it doesn't
get persisted.** Internal reasoning stays in memory. Consolidation
lives in the designated canonical file.

---

## Phase 0: Series Architecture (Optional)

If the user indicates a multi-volume non-fiction project during Q7, run the
Series Architecture protocol before Phase 1 setup.

See `series-architect-nonfiction.md` for the full protocol.

---

## Phase 1: Interactive Setup (13 Questions)

### Phase 1 Continuation-Book Cross-Check (MANDATORY, BLOCKING, HARD GATE — Book N where N > 1)

**THIS IS A HARD GATE — NOT A SUGGESTION:**

When setting up a continuation book in a non-fiction series, Phase 1
answers MUST be validated against the Series Architecture BEFORE the
setup summary is shown to the user.

- You MAY NOT display the Phase 1 Summary until the cross-check has
  actually run and every field carries a source citation.
- You MAY NOT present Phase 1 answers without citations.
- You MAY NOT proceed to Phase 2 until synthesis items are approved.
- "The answers look correct, I'll skip the formal check" is a PROTOCOL
  VIOLATION. Run the check. Every continuation book. Every time.

**Trigger:** Q7 = "Continuation of an existing series" AND series-data/
files exist from a prior Phase 0 run.

**Execution procedure:**

1. After all Phase 1 questions are answered but BEFORE the summary
   is assembled, read the Series Architecture in full.
2. For EACH answer, classify as: `[locked — architecture Section N]`,
   `[carry-forward — architecture Section N]`, `[new — synthesis from Section N,
   needs user approval]`, or `[standalone — no constraint]`.
3. If ANY `[locked]` answer doesn't match architecture: STOP and
   correct before proceeding.
4. Assemble the summary WITH the SOURCE column.
5. Use AskUserQuestion for each synthesis item — the pipeline cannot
   proceed without explicit approval for every synthesis item.

**Rules:**

1. **Extraction where architecture speaks.** If the Series Architecture
   specifies a value for this book, the Phase 1 answer MUST match.
   Label: `[locked — architecture Section N]`

2. **Synthesis requires labelling.** Where architecture is silent,
   synthesis is permitted but must be labelled:
   `[new — synthesis from Section N, needs user approval]`

3. **Category merges forbidden.** If the architecture separates concepts
   (e.g., planted questions, real evidence threads, counter-argument
   seeds), Phase 1 MUST NOT collapse them into a single field.

4. **Carry-forward items are non-negotiable.** Unresolved threads,
   active argument lines, and character/source trajectories from prior
   books are automatically included:
   `[carry-forward from Book N-1 — architecture Section N]`

5. **Cross-check before display.** Every field in the setup summary must
   have a source citation or synthesis label before the user sees it.

Present each question interactively. Wait for the user's answer before proceeding.

### Q1: Category Selection

```
What type of non-fiction are you writing?

MEMOIR & BIOGRAPHY         HISTORY                  POPULAR SCIENCE
  Memoir                     General History          Popular Science
  Biography                  Military History         Natural History
  Historical Biography       Social History           Environmental
                             Microhistory

SELF-HELP & PSYCHOLOGY     BUSINESS & FINANCE       TRUE CRIME
  Self-Help                  Business                 True Crime
  Popular Psychology         Economics & Finance
  Popular Philosophy         Personal Finance

HEALTH & WELLNESS          HOW-TO & GUIDES          JOURNALISM & COMMENTARY
  Health & Wellness          How-To Guides            Investigative Journalism
  Fitness                    Cooking & Food           Political/Social Commentary

CREATIVE NON-FICTION       TRAVEL & NATURE          CULTURE & ARTS
  Literary Non-Fiction       Travel Writing           Art/Music/Culture
  Essay Collections          Nature Writing           Sports/Adventure

EDUCATION & PARENTING      TECHNOLOGY               RELIGION & SPIRITUALITY
  Education                  Technology/Digital       Religion/Spirituality
  Parenting
```

Load the selected category file from the category bank.

### Q2: English Dialect Lock

```
Which English dialect for your manuscript?

  A. American English (US spelling, vocabulary, conventions)
  B. British English (UK spelling, vocabulary, conventions)
```

Lock the dialect for all downstream agents. The Proofreader enforces dialect
consistency throughout. Character quotes and direct speech from sources may
use any dialect for authenticity; narrative prose must match the project dialect.

### Q3: Subcategory Selection

Present subcategories from the loaded category file. Each category has 3-6
subcategories that configure category-specific rules.

### Q4: Content Sensitivity Level

```
Content sensitivity rating (how intense is the subject matter?):

  0 — General audience, no sensitive content
  1 — Mild: occasional difficult topics discussed at a distance
  2 — Moderate: detailed discussion of difficult topics (illness, conflict, trauma)
  3 — Significant: graphic medical detail, violence, explicit personal disclosure
  4 — Intense: disturbing content integral to subject (war, abuse, forensic detail)
  5 — Academic/clinical: clinical detail requiring mature reader
```

### Q5: Research Scope

```
What type of sources will this book draw on?

  A. Primary sources (original documents, first-hand accounts, raw data)
  B. Secondary sources (published books, academic papers, journalism)
  C. Mixed (combination of primary and secondary)
  D. Interview-based (expert interviews as primary evidence)
  E. Archival (historical documents, records, correspondence)
```

### Q6: Length Tier

```
Target length:

  A. Short Form     ~15,000 words  |  6 chapters   | ~2,500 words/chapter
  B. Standard       ~50,000 words  | 20 chapters   | ~2,500 words/chapter
  C. Comprehensive  ~80,000 words  | 30 chapters   | ~2,700 words/chapter
  D. Reference      ~120,000 words | 40 chapters   | ~3,000 words/chapter
```

### Q7: Series or Standalone

```
Is this a standalone book or part of a series?

  A. Standalone
  B. First in a planned series
  C. Continuation of an existing series
```

If B or C, trigger Phase 0 (Series Architecture) if not already completed.

### Q8: Style Guide

```
How should this book sound?

  A. Upload existing writing — I'll analyse your voice and match it
  B. Describe your preferred style — I'll build a profile from your description
  C. Use category defaults — optimised for {category}
```

If A: Launch Authority Builder (extraction mode).
If B: Launch Authority Builder (guided conversation mode).
If C: Generate default Authority Voice Profile for the category.

### Q9: Structure Type

```
How should the book be organised?

  A. Chronological — events in time order
  B. Thematic — organised by topic/theme
  C. Problem-Solution — define problem, present solution
  D. Argument-Driven — thesis with supporting evidence
  E. Instructional — skills building sequentially
  F. Narrative — story-driven non-fiction
  G. Hybrid — combination (describe in notes)
```

Map to the appropriate framework from `beat-structures-nonfiction.md`.

### Q10: Citation Style

```
Citation format:

  A. Chicago (Notes & Bibliography) — standard for history, humanities
  B. APA — standard for psychology, social sciences, education
  C. MLA — standard for literature, language, arts
  D. Harvard — common in UK/Australian academic publishing
  E. Informal — sources woven into prose, endnotes for interested readers
```

### Q11: Pen Name

```
Author name for this project:

  A. Use my real name: [enter name]
  B. Select an existing pen name: [list from .pen-names/index.md]
  C. Create a new pen name (launches Pen Name Studio)
  D. Decide later
```

### Q12: Target Audience Expertise

```
Who is this book for?

  A. General reader — no specialist knowledge assumed
  B. Informed reader — basic familiarity with the subject expected
  C. Specialist — professional or academic audience
  D. Mixed — accessible but with depth for specialists
```

This configures jargon management, evidence density, and explanation depth.

### Q13: Project Mode

```
How would you like to work?

  A. Full Pipeline — I'll research, outline, write, verify, and edit your
     manuscript chapter by chapter. You approve every step.

  B. Research Bible Only — I'll build the complete research framework
     (Research Bible, source database, chapter outline, Research Companion)
     and then stop. You write the book yourself, then bring it back for
     professional editorial.
```

### Setup Complete

After Q13, display confirmation:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PROJECT CONFIGURED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Title:      {title}
  Category:   {category} > {subcategory}
  Length:     {tier} (~{words} words, {chapters} chapters)
  Structure:  {structure_type}
  Citations:  {citation_style}
  Audience:   {audience_level}
  Mode:       {project_mode}
  Dialect:    {dialect}
  Author:     {pen_name or real name}

  Saved to: ~/Documents/Ideorix-Projects/{Title}/

  Proceeding to Phase 2: Research Bible Generation...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Phase 2: Research Bible Generation

### MARKET SCOUT — MANDATORY PRE-PHASE 2 STEP

**Before generating the Research Bible, ALWAYS run Market Scout** — regardless of
how the project was set up. Market Scout provides the competitive landscape that
shapes thesis positioning, gap identification, and strategic differentiation
in the Research Bible.

1. Load `market-scout.md` (or `market-scout-protocol.md`)
2. Run Market Scout with context: **"setup"** and the selected category
3. Save the report to `engine-data/market-pulse.md`
4. Present the key findings to the user before Research Bible generation begins:
   - Current bestsellers and dominant titles in this category
   - Market gaps and underserved angles
   - Reader expectations and demand signals
   - Comparable titles and positioning opportunities
5. The Market Scout report feeds into the Research Bible to ensure the manuscript
   is positioned competitively from the start

**Why this is mandatory:** Market Scout provides the competitive landscape that
shapes thesis differentiation, gap exploitation, and reader-audience alignment
in the Research Bible. Without it, the manuscript is built blind to what already
exists on the shelf. A non-fiction book that duplicates existing titles without
differentiation will struggle regardless of quality. This step ensures every
project benefits from live market intelligence before the research framework
is built.

---

See `research-bible.md` for the full protocol.

**Phase 2A:** Foundation — Topic Scope, Thesis, Authority Voice Profile, Key Sources,
Subject Context, Timeline, Key Figures

**Phase 2B:** Research Architecture — Information Architecture, Chapter Outline,
Source Assignments, Counter-Arguments, Research Gaps

**Phase 2C:** Source Extraction — Structured database of all sources, figures,
organisations, claims

**Phase 2D: Entity Canon Lockfile (MANDATORY, BLOCKING)**

After Phase 2C completes and BEFORE the Research Bible Approval Gate,
generate the Entity Canon Lockfile. This step is **mandatory for every
new project**. It is not optional, not conditional on mode, and not
skippable. Skipping it breaks the Writer's pre-load (step 6a Step B),
the Source Guardian / Expert Tracker's Canon Compliance Check (step 12),
and produces the "Canon Loaded = No" / "Canon Check = blocked" failure
mode observed in testing.

**Execution:**

1. Load `research-bible.md` and run the Entity Canon Lockfile protocol
   in full (see "Entity Canon Lockfile (MANDATORY — Writer & Verifier
   input)" section in `research-bible.md`).
2. Build the entity canon rows from:
   - Research Bible **Section 7 (Key Figures)** → Key Figures table
   - Research Bible **Section 4 (Key Sources)** → Sources table
   - Research Bible **Section 5 (Subject Context)** → Organisations +
     Places tables
3. Write the completed lockfile to:
   `Ideorix-Projects/[Title]/engine-data/entity-canon.md`
4. **Verify the write with Bash ls (MANDATORY):**
   ```bash
   ls -la {project-path}/engine-data/entity-canon.md
   ```
   If ls returns "No such file or directory", the Write tool was not
   invoked. STOP. Re-run the Write in the parent conversation (not a
   subagent) and re-verify.
5. Update the pipeline checkpoint's Canon-Loaded-ready state so Chapter 1
   can pass the pre-flight check.

**You MAY NOT proceed to the Research Bible Approval Gate (and the user
MAY NOT be asked to approve the Bible) until entity-canon.md has been
successfully written.** Present the Entity Canon Lockfile to the user
alongside the Research Bible so the user reviews the canonical names,
credentials, and citation short forms in a single pass.

**Why this gate is here (not folded into Phase 2C):** In testing, the
engine wrote the Research Bible and sources.md but silently skipped the
lockfile, then degraded the project into legacy-pre-hardening mode on
Chapter 1 because entity-canon.md was missing. The fix is to make the
lockfile a NAMED phase step with its own invocation rule, rather than
an inline responsibility of Phase 2C extraction. For non-fiction the
stakes are higher than fiction: a drifted real-person name is a
factual error, not a continuity slip. See `research-bible.md` Entity
Canon Lockfile section for the full protocol.

**Outputs:**
- `engine-data/research-bible.md`
- `engine-data/sources.md`
- `engine-data/entity-canon.md`
- `engine-data/outline.md`
- `engine-data/research-companion.docx` (if Research Bible Only mode)

**Phase 2E: Pipeline State Initialization (MANDATORY, BLOCKING)**

After Phase 2D (Entity Canon Lockfile) completes and BEFORE the Research
Bible Approval Gate, initialize the two infrastructure files that every
modern-mode chapter requires. This step is **mandatory for every new
project**. It is not optional, not conditional on mode, and not skippable.
Skipping it means the first chapter cycle has no source-of-truth checkpoint
to write to and no banlist file for the Writer Pre-Load step 6a Step A to
read.

**Execution:**

1. **Create the Pipeline Checkpoint file** at
   `Ideorix-Projects/[Title]/engine-data/pipeline-checkpoint.md` using the
   full v2-schema template (see "Pipeline Checkpoint" section below).
   Populate with:
   - Schema header: `<!-- schema: ideorix-nonfiction-checkpoint v2 -->`
   - Pipeline Status: Phase = Phase 2 complete, Current chapter = 0, Mode =
     per-chapter verification
   - Chapter Progress table: column headers only, no data rows yet
   - Word Count Tracker: column headers only
   - Batch Edit Status: column headers only
   - Flags: empty
   - Next Action: "Awaiting Research Bible Approval Gate; then write
     Chapter 1"

2. **Create the Running Banlist starter file** at
   `Ideorix-Projects/[Title]/engine-data/running-banlist.md`. This is a
   one-time initialization — the Humaniser updates it after every chapter.
   The starter must contain:
   - A short preface explaining what the file is
   - `## HARD CONSTRAINTS` — empty list (no patterns promoted yet; starter
     header only)
   - `## WATCHLIST` — empty list
   - `## RETIRED` — empty list

3. **Verify both writes with Bash ls (MANDATORY):**
   ```bash
   ls -la {project-path}/engine-data/pipeline-checkpoint.md
   ls -la {project-path}/engine-data/running-banlist.md
   ```
   If either Bash ls returns "No such file or directory", the Write tool
   was not invoked for that file. STOP. Re-run the Write in the parent
   conversation (not a subagent) and re-verify. Do NOT proceed to step 4
   until Bash ls confirms BOTH files on disk.

4. **Forbidden root-file scan (MANDATORY):**
   ```bash
   ls {project-path}/engine-data/
   ```
   Inspect the output for any FORBIDDEN filenames (see File Location
   Discipline above). If any are found, STOP and alert the user. Do
   NOT silently delete.

5. Update the in-memory pipeline state so the Research Bible Approval Gate
   (and subsequently Phase 3) can reference both files.

**You MAY NOT proceed to the Research Bible Approval Gate until both files
have been successfully written.**

**Why this gate is here:** Same failure mode observed in fiction testing —
the engine generated the Research Bible, sources.md, entity-canon.md, and
market-pulse.md, then went straight into the Approval Gate and on to
Chapter 1 without creating pipeline-checkpoint.md or running-banlist.md.
Chapter 1 "completed" its cycle but there was no checkpoint to update and
no banlist for Chapter 2's Writer Pre-Load to read. Named phase step
prevents the lazy-creation failure.

**Running Banlist starter format:**

```markdown
# Running Banlist — {Title}
<!-- Updated by the Prose Humaniser after every chapter. Read by the
     Content Writer pre-load (step 6a Step A). -->
Last updated: Phase 2 (starter — no chapters written yet)

This file records Writer-Humaniser feedback across the manuscript.
Patterns that recur in two or more chapters are promoted to HARD
CONSTRAINTS, which become opening-prompt hard bans for the Writer.
Patterns in WATCHLIST are advisory. Patterns in RETIRED were once
HARD but have been clean for 5 consecutive chapters.

## HARD CONSTRAINTS

(No entries yet — patterns will be promoted from the Humaniser's
chapter reports starting at Chapter 2.)

| Pattern | First flagged | Chapters where flagged | Promotion trigger |
|---------|---------------|-----------------------|-------------------|

## WATCHLIST

(No entries yet.)

| Pattern | First flagged | Chapters where flagged | Promoted if |
|---------|---------------|-----------------------|-------------|

## RETIRED

(No entries yet.)

| Pattern | First flagged | Last flagged | Clean chapters since |
|---------|---------------|--------------|---------------------|
```

Additional Phase 2 outputs after 2E:
- `engine-data/pipeline-checkpoint.md`
- `engine-data/running-banlist.md`

#### PHASE 2F: RESEARCH BIBLE CONFORMANCE CHECK (MANDATORY, BLOCKING)

After Phase 2E and BEFORE the Approval Gate, run a traceability pass
on the draft Research Bible. Every element must either trace to the
user's source material / outline with citation, or be flagged as an
expansion (in-book only, low cost) or invention (cross-book, requires
[PLACEHOLDER] and user approval). Contradictions with source material,
series architecture, or established facts are FORBIDDEN — STOP and
fix before presenting.

For series projects: additionally check against the Series Bible's
volume plan, ensuring this book's Research Bible doesn't pre-fire
content assigned to later volumes.

Produce a traceability summary at the top of the Approval Gate
presentation:
```
TRACEABILITY SUMMARY:
  Citations (from source material): {N} elements
  Expansions (in-book only): {N} elements
  Inventions (cross-book, [PLACEHOLDER]): {N} — REQUIRE YOUR APPROVAL
  Contradictions found: {N}
```

#### PHASE 2G: VERIFICATION DISCIPLINE GATE (MANDATORY, BLOCKING)

After Phase 2F (Conformance Check) and BEFORE the Approval
Gate, run the Phase A WebSearch verification per
`verification-discipline.md`. Every factual specific
committed to the Research Bible — every entry in Key Sources
(Section 4), Subject Context (Section 5), Timeline
(Section 6), Key Figures (Section 7), and the Source
Assignments / cited papers / cited persons / dated events /
attributed statistics across the bible — MUST be classified
as one of three classes:

- **VERIFIED** — WebSearch returned a real source. URL / DOI
  / publication / page-number pinned to the bible entry.
  Material context (funding, COI, related events) checked
  and recorded.
- **SPECULATIVE** — WebSearch returned inconclusive or the
  content is by nature forward-looking / counterfactual /
  interpretive. The bible entry carries the SPECULATIVE
  marker; downstream content writing must use explicit
  speculative-marker prose.
- **REJECTED** — Cannot be verified, cannot be reframed as
  speculative. Removed from the bible.

The gate also runs the **topic-landscape sweep**: WebSearch
queries for "what real events relevant to [topic] happened
in [date range covered by the bible]?" — reconciled against
the bible's existing coverage to surface the "missed real
events entirely" failure mode. Any real events surfaced by
the sweep that the bible does not cover are added (with
VERIFIED class and pinned source) before the gate clears.

**Outputs:**

- `engine-data/verification-ledger.md` — per-entry list:
  bible section, item, class (VERIFIED / SPECULATIVE /
  REJECTED), pinned source URL/DOI for VERIFIED, prose
  marker phrasing for SPECULATIVE, verification timestamp.
- `engine-data/speculative-content-map.md` — list of
  SPECULATIVE entries that will appear in the manuscript,
  by chapter / section, so downstream stages and the
  publisher know where speculative content lives.

**Hard gate — BLOCKING:**

This phase MUST NOT advance to the Approval Gate while the
verification ledger contains entries that are
unverified-uncategorized (i.e., neither VERIFIED nor
SPECULATIVE nor REJECTED). "Defer to pre-press" is NOT a
valid resolution. The Approval Gate cannot present a bible
to the user with unverified items still in scope.

The discipline applies regardless of date — pre-cutoff
training-data drift (wrong-attribution, date-drift, detail-
errors on real papers / events / legislation) is equally
dangerous as post-cutoff fabrication. WebSearch verifies
every specific, not just post-cutoff items. See
`verification-discipline.md` for the seven named anti-
patterns this gate is designed to catch.

#### RESEARCH BIBLE APPROVAL GATE (MANDATORY, BLOCKING)

After Phase 2G (Verification Discipline Gate) completes:

1. **Display the COMPLETE Research Bible** to the user as formatted text in
   the conversation. This includes: Topic Scope, Thesis, Authority Voice
   Profile, Key Sources, Subject Context, Timeline, Key Figures,
   Information Architecture, Chapter Outline, Source Assignments,
   Counter-Arguments, and Research Gaps.
2. **Display the Entity Canon Lockfile** — show the Key Figures, Sources,
   Organisations, and Places tables so the user can verify canonical
   names, credentials, and citation short forms.
3. **Use AskUserQuestion** with options:
   - "Approve Research Bible — proceed to chapter generation"
   - "Request changes" (specify what to modify)
   - "Add details" (user wants to supplement the Bible)
4. **Do NOT proceed to Phase 3 (or Phase 2.5 — Research Bible Only
   delivery) until the user approves.**

**Why this gate exists:** In testing, the Research Bible was saved to disk
without being shown to the user. The user had no opportunity to catch
misattributed quotes, incorrect credentials, or source inconsistencies
before chapter generation began. In non-fiction, these errors are factual
errors — worse than fiction continuity slips. Showing the Research Bible
and Entity Canon upfront catches problems at the cheapest possible point
in the pipeline.

---

## Phase 3: Chapter Generation

See `structural-architect.md` and `content-writer.md` for agent protocols.
See `beat-structures-nonfiction.md` for structural framework integration.
See `rhetoric-library.md` for rhetorical strategy guidance.

For EACH chapter (written sequentially, never out of order):

0. **Context Scoping (MANDATORY, runs before any agent)** — Read the chapter
   outline entry and identify which sources, key figures, and subject contexts
   appear. Load ONLY those source profiles from `sources.md` for this chapter's
   Structural Architect, Content Writer, and Verification agents. Also scope
   summaries: last 3 in full, earlier chapters as one-line precis only.
   **Exception:** For Chapter 1 and the final chapter, load full sources.

   **Disk re-read rule (MANDATORY — context compression defence):**
   At the start of EVERY chapter's generation cycle, re-read ALL source
   files from disk. Do NOT rely on in-memory state from earlier chapters.
   Claude's context management may compress or evict earlier token blocks
   during long sessions, making in-memory copies of files stale.

   Files that MUST be re-read from disk at the start of each chapter:
   - `engine-data/pipeline-checkpoint.md` (already required by pre-flight)
   - `engine-data/research-bible.md` (Section 9 entry for this chapter)
   - `engine-data/entity-canon.md` (loaded at step 6a)
   - `engine-data/running-banlist.md` (loaded at step 6a)
   - `engine-data/summaries/ch{NN-1}-summary.md` (last 3 summaries)

   Never assume "I already loaded the Bible earlier in this session."
   The checkpoint file is the ONLY persistent cross-chapter state — all
   other files must be re-read from disk at each chapter boundary.

1. **Read category file** for category-specific instructions
2. **Calculate structure target** from `beat-structures-nonfiction.md`
3. **Check planted questions/revelations** (Chekhov's Guns for non-fiction)
4. **Check rhetoric strategy plan** — which strategies deploy this chapter
5. **Structural Architect** generates chapter brief.

   **Argumentative-function declaration (v2.7.31, Class C convention).**
   The brief MUST include a single HTML comment of the form:

   ```
   <!-- Function: <value> -->
   ```

   ...where `<value>` is drawn from the canonical argumentative-function
   list in `coherence-function-consecutive.md` (`thesis-statement`,
   `evidence-build`, `case-study`, `counter-argument`, `synthesis`,
   `application`, `historical-context`, `transition`, `recap`, `framing`).
   The value should differ from the previous chapter's declaration unless
   the structure explicitly requires the same function (rare; document
   the intent in the brief if so). The Same-Function-Consecutive Audit
   (`coherence-function-consecutive.md`) reads these declarations at
   `/validate` time and flags adjacent duplicates as FAIL. Briefs missing
   the declaration surface as WARN, not FAIL — backwards-compat for
   pre-v2.7.31 projects, but new briefs are expected to include it.

5a. **Outline Conformance Agent (MANDATORY, BLOCKING, HARD GATE)** — runs
    BEFORE the User Review Gate. Checks the draft brief against Research Bible
    Section 9 (Chapter Outline) and Section 11 (Counter-Arguments). Catches
    thesis drift, dropped sections, silent counter-argument removals, and
    unauthorised new figures/sources before the Content Writer runs. See
    `outline-conformance.md` for the full check specification. Report is
    written to `engine-data/reports/ch{NN}-outline-conformance.md` and
    surfaced alongside the brief at step 6.

    **THIS IS A HARD GATE — NOT A SUGGESTION:**
    - Skipping this step is the single most common way cumulative outline
      drift becomes invisible in a non-fiction manuscript. In production,
      a Chapter 12 fiction brief drifted into new-mythology territory
      (a Story Bible violation) and the check was skipped because the
      brief "looked aligned." The non-fiction equivalent is a chapter
      brief that silently re-scopes its thesis contribution, drops a
      required counter-argument, or invents a new source that Section 4
      does not list. Each individual brief reads as coherent on its own.
      The drift is only visible to an agent zoomed out to the full
      Research Bible and the remaining-chapter capacity.
    - You MAY NOT present the brief to the user at step 6 until the
      Outline Conformance Agent has actually run, written its report
      via the Write tool, and updated the pipeline-checkpoint's
      `OC Report` field to "Yes".
    - You MAY NOT "narrate" the conformance check and proceed. The
      agent must actually run, and the Write tool must actually be
      invoked to persist the report. The checkpoint field is the
      proof the step completed. (See File Operation Policy above —
      trust the Write tool and the checkpoint; don't Read the report
      back.)
    - "The brief looks fine, Section 9 seems aligned, I'll skip the formal
      check this time" is a PROTOCOL VIOLATION regardless of how obviously
      clean the brief appears. Run the agent. Every brief. Every time.

    **Execution procedure (follow in order):**
    1. Load Section 9 (Chapter Outline) for Chapter N from the Research Bible
    2. Load Section 11 (Counter-Arguments) and Section 4 (Key Sources)
    3. Load `engine-data/section-delivery-log.md` (if it exists) for the
       sustainability check
    4. Receive the draft brief content from step 5 (in-memory from the
       Structural Architect — do NOT Read from a file, the brief hasn't
       been written yet)
    5. Run the 6 checks as specified in `outline-conformance.md` (Thesis
       Contribution Match, Required Section Delivery, No Silent Drops, No
       Unauthorised Additions, Zoom-Out Sustainability, Counter-Argument
       Coverage)
    6. **Produce the audit footer** in this format:
       ```
       <!-- IDEORIX:AUDIT:BEGIN v1 -->

       ## Outline Conformance Audit (Non-Fiction)
       Verdict: {PASS | WARN | FAIL}
       Ran at: Chapter {N} brief-generation time
       Agent: Outline Conformance Agent (6 checks)

       Check A (Thesis Contribution Match):   {result} — {reason if not pass}
       Check B (Required Section Delivery):   {result} — {...}
       Check C (No Silent Drops):             {result} — {...}
       Check D (No Unauthorised Additions):   {result} — {...}
       Check E (Zoom-Out Sustainability):     {result} — {...}
       Check F (Counter-Argument Coverage):   {result} — {...}

       {drift detail list if any}
       {recommendations if any}

       <!-- IDEORIX:AUDIT:END -->
       ```
    7. **Check audit length.** Count the lines between the BEGIN and END
       markers (inclusive).
       - **If audit ≤ 100 lines:** append the full audit block to the
         brief content in memory.
       - **If audit > 100 lines:** write the full audit to
         `engine-data/reports/ch{NN}-oc-detail.md` as an overflow file
         (single Write tool call). Append a SUMMARY audit block to the
         brief instead: verdict + top 3 drift items + pointer line.
         The summary is still wrapped in
         `<!-- IDEORIX:AUDIT:BEGIN v1 -->` / `<!-- IDEORIX:AUDIT:END -->`
         markers for consistency.
    8. **Write the combined brief + audit footer** to
       `engine-data/chapter-briefs/ch{NN}-brief.md` via the Write tool.
       Single Write tool call containing brief content + audit footer.
       Trust the Write tool. Do NOT Read the file back.
    9. Update `engine-data/pipeline-checkpoint.md` — set Chapter N's
       "OC Report" field to "Yes" and record the verdict (PASS / WARN /
       FAIL). The checkpoint is the cross-chapter status ledger and the
       Progress Dashboard's OC Verdict line reads from here.
    10. Only then proceed to step 6 (User Review Gate).

    **Consolidation note (v1):** Prior to v1, the OC Agent wrote its
    report as a separate file `engine-data/reports/ch{NN}-outline-
    conformance.md`. As of v1 of the `IDEORIX:AUDIT` footer, the audit
    is consolidated into the brief file to reduce per-chapter file
    count and Claude Desktop's Sources panel clutter. The separate OC
    report file is no longer produced in the common case — only as
    an overflow file for FAIL cases exceeding the 100-line cap. See
    `outline-conformance.md` Output Format section for full
    specification.

6. **User review (MANDATORY, BLOCKING)** — present brief AND conformance
    report, get approval.

    **Pre-gate check (MANDATORY, HARD GATE, runs BEFORE the AskUserQuestion call):**
    Before you may present the brief to the user, confirm that step 5a
    completed. This is a fail-closed gate — any uncertainty MUST block
    presentation of the brief.

    **Check procedure:**
    1. Read `engine-data/pipeline-checkpoint.md` ONCE (no re-reads).
    2. Locate the Chapter Progress table — the table whose header row
       begins `| Ch |`.
    3. Confirm the header row contains `OC Report` and `OC Verdict` as
       exact column names. If the checkpoint has been written with a
       different column schema (e.g., "Structural Architect brief"
       instead of "Brief", or no OC Report column at all), that is a
       Phase 2E schema violation — STOP. Re-run Phase 2E with the
       canonical v2-schema column headers. See File Location
       Discipline above (Checkpoint schema invention — FORBIDDEN).
    4. Locate the row for the current chapter N.
       - If no row exists, step 5a was skipped. STOP. Return to step
         5a, run the Outline Conformance Agent, and let it create the
         row with OC Report populated.
       - If the row exists but `OC Report` is not "Yes" OR `OC Verdict`
         is blank, step 5a ran incompletely (e.g., did not Write the
         audit footer into the brief or did not update the checkpoint).
         STOP. Re-run step 5a in full.
    5. Only when BOTH `OC Report = Yes` AND `OC Verdict ∈ {PASS, WARN,
       FAIL}` may you proceed to display the brief.

    There is no "this brief looks clean, we can skip OC this time"
    override. The OC Agent is a blocking upstream dependency of step 6,
    not an optional audit. (Do NOT Read the OC report file itself as an
    existence check — trust the checkpoint. See File Operation Policy
    above.)

    **Why this gate fails closed:** In testing, the Structural
    Architect completed its brief, the engine moved directly to the
    user review gate without invoking step 5a, and the OC Agent was
    silently skipped. Failing closed is the only way to make the gate
    load-bearing.
6a. **Writer Pre-Load (MANDATORY, BLOCKING)** — Before the Content Writer
    generates any prose for this chapter, the pipeline MUST pre-load TWO
    files into the Writer prompt: (A) the Running Banlist as OPENING HARD
    CONSTRAINTS (see `content-writer.md` "Running Banlist" section) and
    (B) the Entity Canon Lockfile as ENTITY CANON (see `research-bible.md`
    Entity Canon Lockfile section).

    **Execution procedure:**

    **Step A — Running Banlist pre-load:**
    1. Read `engine-data/running-banlist.md` with the Read tool
    2. Extract the HARD CONSTRAINTS section verbatim (not WATCHLIST, not
       RETIRED, not BREACH LOG)
    3. Inject it into the Content Writer's User Prompt Template at the
       `{opening_hard_constraints}` slot — the FIRST block of the prompt,
       before RESEARCH BIBLE EXCERPT
    4. If the file does not exist (Chapters 1 and 2 of a new manuscript),
       use the single-line placeholder: "No recurring patterns promoted
       yet — universal forbidden-words.md rules still apply."

    **Step B — Entity Canon pre-load:**
    1. Read `engine-data/entity-canon.md` with the Read tool
    2. Extract the Key Figures, Sources, Organisations/Institutions, and
       Places tables verbatim (all four — do NOT truncate)
    3. **Check the NEW ENTITIES PENDING APPROVAL section.** If the current
       chapter's brief introduced a new figure, source, or institution and
       it has NOT been approved by the user, STOP. The brief should have
       surfaced the pending entity at the User Review Gate (step 6) for
       approval — including source verification for new sources. Return
       to step 6 and get approval before proceeding.
    4. Inject the approved canon tables into the Content Writer's User
       Prompt Template at the `{entity_canon}` slot — which sits just
       below the OPENING HARD CONSTRAINTS block, above RESEARCH BIBLE
       EXCERPT
    5. If `entity-canon.md` does not exist, the Research Bible phase did
       not produce it. STOP and run the Research Bible's Entity Canon
       Lockfile protocol (`research-bible.md`) before proceeding. The
       Content Writer MAY NOT run without an entity canon — in non-fiction,
       running without a canon risks factual drift in real people, source
       citations, or institution names.

    **Checkpoint update:**
    6. Update `engine-data/pipeline-checkpoint.md` — set Chapter N's
       "Banlist Loaded" field to "Yes" AND "Canon Loaded" field to "Yes"

    **Why this step exists (production failure):** In a real manuscript
    run, Ch12 and Ch13 both needed the same surgical fixes: em dashes in
    narration, "the way [pronoun]" overuse, "the kind of" despite ban.
    The Humaniser had flagged the patterns. The Batch Editor's
    feed-forward "notes" had mentioned them. But the Writer never
    internalised them because feed-forward notes are advisory — they do
    not dominate attention the way opening hard constraints do. This
    step moves recurring patterns out of advisory feed-forward and into
    the Writer prompt's opening block where attention is strongest.

    **Banlist Loaded is a HARD GATE.** The Content Writer MAY NOT run
    (step 7) until this step has completed and the checkpoint's
    `Banlist Loaded` field is "Yes" for the current chapter.

    **Step C — Prior-Chapter Continuity Pre-Load (v2.7.43, MANDATORY for chapter N ≥ 2):**

    Authored in response to a real user-reported incident: a session
    started fresh, Claude read the project's session-notes summary,
    wrote chapter 6 with fabricated continuity (introducing new
    characters with no connection to chapters 1-5), and on review
    admitted having never read the prior chapters. Session-notes
    summary is not a substitute for actual chapter context.

    For every chapter N ≥ 2, the engine MUST Read the prior-chapter
    summaries (or the chapters themselves if summaries are missing)
    BEFORE the Content Writer runs:

    1. For chapter N, identify the relevant prior-chapter set:
       - **Default:** the last 3 chapters' summaries
         (`engine-data/summaries/ch{N-1}-summary.md`,
         `ch{N-2}-summary.md`, `ch{N-3}-summary.md`)
       - **Exception:** chapter 2 reads only ch01-summary; chapter 3
         reads ch02 + ch01.
       - **Final-chapter exception:** the final chapter reads ALL
         prior chapter summaries in full, not just the last 3.

    2. Read each summary file with the Read tool. If a summary file
       is MISSING (the chapter was written but the summary step at
       step 13 didn't complete), the fallback is to Read the
       chapter file directly (`engine-data/chapters/ch{NN}.md`).
       Missing summaries are themselves a pipeline gap and should
       be surfaced to the user; do NOT proceed without continuity
       data.

    3. Inject the loaded summaries into the Content Writer's User
       Prompt Template at the `{prior_chapter_continuity}` slot —
       which sits below ENTITY CANON and above RESEARCH BIBLE
       EXCERPT, marked clearly as "PRIOR-CHAPTER CONTINUITY" so
       the Writer treats it as canon, not flavour.

    4. Update the checkpoint's `Continuity Loaded` field to "Yes"
       for the current chapter.

    **Continuity Loaded is a HARD GATE.** The Content Writer MAY NOT
    run (step 7) until this step has completed and the checkpoint's
    `Continuity Loaded` field is "Yes" for the current chapter. A
    chapter-N-write without this gate is the failure shape that
    introduces fabricated continuity and broken character arcs.

    Pre-v2.7.43 the spec recommended "re-read all source files from
    disk" (line 1343-1358 of this file) but did not enforce it as a
    HARD GATE — the Disk re-read rule was advisory. v2.7.43 promotes
    prior-chapter continuity to a checked checkpoint field on parity
    with Banlist and Entity Canon. Sessions where Claude skips this
    step are now structurally caught.

7. **Content Writer** executes brief into prose
   — Applies the Running Banlist HARD CONSTRAINTS loaded at step 6a
     (zero tolerance, non-negotiable, zero per chapter)
7a. **User reviews prose (MANDATORY, BLOCKING)**
8. **Prose quality check** — no placeholders, no brackets, no meta-text
9. **Word count enforcement (MANDATORY, BLOCKING)**
9a. **Pre-Humaniser Violation Capture (MANDATORY)** — Before the Humaniser
   runs, capture first-draft violation counts via bash (narration em-dashes,
   frame leaks, forbidden word hits, Writer retry count, word-count %).
   Record to `engine-data/model-health.md`. These feed the Model Health
   Monitor at step 18. See fiction `core-pipeline.md` Model Health Monitor
   section for the full spec — same two-tier WATCH/STOP thresholds apply
   to non-fiction.
10. **Prose Humaniser (MANDATORY)** — strip AI patterns
11. **Prose Craft Improver** (optional)
12. **Verification agents (MANDATORY, BLOCKING, HARD GATE)** — Run ALL 5
    agents: Source Guardian, Evidence Auditor, Citation Keeper, Expert Tracker,
    Argument Analyst.

    **THIS IS A HARD GATE — NOT A SUGGESTION:**
    - The verification suite is NOT the same as the post-writing checks
    - Steps 8-9 are mechanical QA. Step 12 is the 5-AGENT VERIFICATION SUITE
    - FILE GATE: report must exist on disk at `engine-data/reports/ch{NN}-verification.md`
    - Fix critical issues BEFORE proceeding

13. **Chapter summary (MANDATORY, BLOCKING)** — 3-5 sentences for
    continuity + source deployment notes. Write to
    `engine-data/summaries/ch{NN}-summary.md`.

    **Bash ls verification (MANDATORY):**
    ```bash
    ls -la {project-path}/engine-data/summaries/ch{NN}-summary.md
    ```
    If ls returns "No such file or directory", STOP and re-run.

14. **Snapshot (MANDATORY, BLOCKING)** — revision safety before saving.
    Write to `engine-data/revisions/{YYYY-MM-DDTHH-MM}_{stage}/ch{NN}.md`.

    **Bash ls verification (MANDATORY):**
    ```bash
    ls -la {project-path}/engine-data/revisions/{snapshot-folder}/ch{NN}.md
    ```
    If ls returns "No such file or directory" AND the source chapter
    existed, STOP and re-run.

15. **Save** brief, chapter, and summary to workspace
16. **Post-save file verification (MANDATORY, BLOCKING)**
17. **Update tracking** — structure beat delivery, rhetoric strategy progress
18. **Update pipeline checkpoint (MANDATORY, BLOCKING, HARD GATE)** —
    Append or update the row for Chapter {N} in
    `engine-data/pipeline-checkpoint.md` with every column populated from
    the completed cycle: `Brief`, `OC Report`, `OC Verdict`, `Banlist
    Loaded`, `Canon Loaded`, `Written`, `Saved`, `Verified (disk)`,
    `Humanised`, `V-Score`, `Canon Check`, `Report Saved`, `Summary`. Also
    update the Word Count Tracker row and the Next Action line.

    **This step is not optional and not a suggestion:**
    - You MAY NOT display the Progress Dashboard or move to the next
      chapter until the checkpoint row for Chapter {N} has been written
      via the Write tool AND Bash ls has confirmed the file on disk.
    - You MAY NOT "narrate" the checkpoint update and proceed.
    - If `engine-data/pipeline-checkpoint.md` does not exist at this
      point, the Phase 2E step was skipped during Phase 2. STOP and
      run Phase 2E.

    **Column-by-column Bash ls verification before marking Yes:**

    Each `Yes` in the checkpoint row must be backed by a prior Bash ls
    that confirmed the corresponding file on disk:

    | Column | Bash ls target |
    |---|---|
    | `Brief: Yes` | `ls -la {path}/engine-data/chapter-briefs/ch{NN}-brief.md` |
    | `Written: Yes` | `ls -la {path}/engine-data/chapters/ch{NN}.md` |
    | `Humanised: Yes` | `ls -la {path}/engine-data/chapters/ch{NN}.md` (post-Humaniser overwrite) |
    | `Report Saved: Yes` | `ls -la {path}/engine-data/reports/ch{NN}-verification.md` |
    | `Summary: Yes` | `ls -la {path}/engine-data/summaries/ch{NN}-summary.md` |

    Any column whose Bash ls has NOT passed MUST stay `No` or `-`.
    Do NOT mark `Yes` based on narration or in-memory state.

    After the checkpoint update Write:
    ```bash
    ls -la {project-path}/engine-data/pipeline-checkpoint.md
    ```

    **Batch Edit Gate (MANDATORY, BLOCKING — checked at step 18):**

    Before displaying the Progress Dashboard, check whether this chapter
    triggers a batch edit:

    ```
    IF chapter_number % 5 == 0 OR chapter_number == total_chapters:
        batch_edit_required = TRUE
    ELSE:
        batch_edit_required = FALSE
    ```

    If TRUE: STOP. Run step 19 FIRST. Do NOT display the Progress
    Dashboard or present the approval gate until the Batch Health Report
    is written to `engine-data/reports/batch-{N}-edit.md` (Bash ls
    verified) and the checkpoint updated with `Batch Edit: Yes`.

    If FALSE: Proceed directly to Progress Dashboard and approval gate.

19. **Batch deep edit (every 5th chapter, MANDATORY, BLOCKING)** —
    If this chapter number is divisible by 5 (or is the final chapter),
    run the Batch Editor (see `batch-editor.md`). MANDATORY — do NOT
    offer as optional, do NOT say "would you like me to run it." Just
    run it. The Batch Edit Gate at step 18 blocks the Progress
    Dashboard until this step completes.

    1. Write Batch Health Report to
       `engine-data/reports/batch-{N}-edit.md` — Bash ls verified.
    2. Apply surgical fixes to affected chapters — Write + Bash ls each.
    3. Update checkpoint: `Batch Edit: Yes`.
    4. Display the report inline.
    5. THEN proceed to Progress Dashboard + approval gate.

### File Verification Gate

After saving each chapter's files, IMMEDIATELY verify they exist on disk:

```
POST-SAVE VERIFICATION CHECKLIST:
1. Chapter file:  engine-data/chapters/ch{NN}.md — exists, non-empty, correct heading
2. Chapter brief: engine-data/chapter-briefs/ch{NN}-brief.md — exists, non-empty
3. Chapter summary: engine-data/summaries/ch{NN}-summary.md — exists, 3-5 sentences

IF ANY FILE FAILS: re-attempt save. If second attempt fails: STOP and alert user.
```

### Pipeline Checkpoint

Write to: `engine-data/pipeline-checkpoint.md`

Update after EVERY chapter completes its full cycle.

```markdown
# Pipeline Checkpoint — {Title}
<!-- schema: ideorix-nonfiction-checkpoint v2 (post-hardening: OC Report, OC Verdict, Banlist Loaded, Canon Loaded, Canon Check columns required) -->
Last updated: Chapter {N} — {timestamp}

## Pipeline Status
Phase: {current_phase}
Current chapter: {N} of {total}
Mode: per-chapter verification

## Chapter Progress
| Ch | Brief | OC Report | OC Verdict | Banlist Loaded | Canon Loaded | Written | Saved | Verified | Humanised | V-Score | Canon Check | Report Saved | Summary |
|----|-------|-----------|------------|----------------|--------------|---------|-------|----------|-----------|---------|-------------|--------------|---------|
| 1  | Yes   | Yes       | PASS       | n/a (first ch) | Yes          | Yes     | Yes   | Yes      | Yes       | 94      | clean       | Yes          | Yes     |

**OC Report column rules:** The OC Report column MUST be "Yes" before the
brief for that chapter is presented to the user at step 6. A row that shows
Brief=Yes but OC Report=No indicates step 5a was skipped — this is a
protocol violation; stop and run the Outline Conformance Agent before doing
anything else with that chapter. The OC Verdict column records the brief-time
verdict (PASS / WARN / FAIL) and feeds the post-chapter Progress Dashboard's
"Outline Conformance" line.

**Banlist Loaded column rules:** The Banlist Loaded column MUST be "Yes"
before the Content Writer generates any prose for that chapter (step 7).
A row that shows OC Verdict populated but Banlist Loaded=No indicates
step 6a was skipped — this is a protocol violation; stop and run the
Writer Pre-Load before proceeding. Chapters 1 and 2 use "n/a (first ch)"
because the banlist has no promoted entries yet. From Chapter 3 onwards,
Banlist Loaded must be "Yes" before the Content Writer runs.

**Canon Loaded column rules:** The Canon Loaded column MUST be "Yes"
before the Content Writer generates any prose for that chapter (step 7,
Step B of the pre-load). Unlike Banlist Loaded, Canon Loaded applies
from Chapter 1 onwards — the Entity Canon exists from Phase 2 (Research
Bible generation) and every chapter needs it. A row with Canon Loaded=No
means step 6a Step B was skipped or engine-data/entity-canon.md is
missing. STOP and run the Research Bible's Entity Canon Lockfile protocol
if the file doesn't exist, or re-run the pre-load if it does.

**Canon Check column rules:** The Canon Check column records the output
of the Source Guardian's Canon Compliance Check (see `accuracy-gate.md`)
for that chapter. Values: `clean`, `{N} drift`, or `blocked`. Non-fiction
drift items are ALWAYS CRITICAL because they are factual errors (misspelled
real people, misattributed sources, wrong institution names). Canon Check
is populated after verification (step 12) and flows into the post-chapter
Progress Dashboard's "Canon Drift" line.

## Word Count Tracker
| Ch | Target | Actual | % | Status |
|----|--------|--------|---|--------|
Running average: {avg}% of target

## Batch Edit Status
| Batch | Chapters | Status | Score | Weakest Ch | Fixes Applied |
|-------|----------|--------|-------|------------|---------------|

## Number-7 Bias Tracker
Total numbers: {count} | Ending in 7: {count} ({percentage}%)
Status: {OK ≤15% | WARNING 15-25% | CRITICAL >25%}

## Audits Passed
| Audit | Passed at | Report path |
|-------|-----------|-------------|
| bible-coverage-audit | 2026-04-30T11:14:22Z | engine-data/reports/bible-coverage-audit.md |
| fact-audit-9a | 2026-05-02T08:06:51Z | engine-data/reports/ch{NN}-verification.md (per-chapter) |
| fact-audit-9b | 2026-05-04T14:32:09Z | engine-data/reports/external-source-verification.md |

## Flags
- {patterns approaching limits}
- {persistent shortfalls}
- {batch editor notes}

## Next Action
{what should happen next}
```

**Audits Passed column rules:** This section is the project-level
audit-gate ledger. Every audit gate that passes (Bible Coverage Audit,
Stage 9a Internal Consistency, Stage 9b External Source Verification,
Pre-Pub Sampled VERIFIED Re-check, etc.) MUST append a row when the
gate is granted. The row records the audit name, ISO 8601 UTC pass-time,
and the on-disk path of the audit report file. The list is **derived**
state — `references/producer-state-protocol.md` defines the
state-reconciliation HARD GATE that scans the filesystem for audit-
report files at every Director invocation, repairs the list if rows
are missing, and flags DIVERGENCE if the list claims an audit passed
but the report file is absent on disk. Append-only: never delete or
overwrite a row; if an audit needs to be re-run, append a new row with
the new timestamp and report path. The list is the truth-source for
"what audit gates has this project cleared?" — read by Director Agent
when recommending next step, and by Stage 13 Pre-Pub before granting
READY.

### Pre-Flight Check (MANDATORY before every new chapter)

Before running the Structural Architect for Chapter N+1, perform this
check. The check reads `pipeline-checkpoint.md` ONCE and trusts its
recorded field values. Do NOT Read individual report files to verify
existence (see File Operation Policy above — the checkpoint is the
authoritative cross-chapter status ledger).

1. Read `engine-data/pipeline-checkpoint.md` — this is the only Read
   required for pre-flight.
2. Confirm the previous chapter has ALL of these fields populated:
   - Brief: Yes
   - OC Report: Yes
   - OC Verdict: PASS / WARN / FAIL (not "-" or blank)
   - Banlist Loaded: Yes (or "n/a (first ch)" for Chapters 1-2)
   - Canon Loaded: Yes
   - Written: Yes
   - Saved: Yes
   - Verified: Yes
   - Humanised: Yes
   - V-Score: populated (not "-" or blank)
   - Canon Check: clean / {N} drift (not "-" or blank). If drift > 0 and
     unresolved, STOP and surface the drift to the user before starting
     Chapter N+1.
   - Report Saved: Yes
   - Summary: Yes
3. If ANY field is missing or blank: STOP. The corresponding step did
   not complete. Investigate and complete it before starting Chapter N+1.

**Pre-Flight file reconciliation (MANDATORY):**

For each checkpoint field marked "Yes" on the previous chapter, verify
the actual file exists on disk with non-zero bytes:

```bash
ls -la {file-path} && stat -c %s {file-path}
```

If ANY file is missing or zero-bytes, flip the checkpoint field to "No",
log to `engine-data/run.log`, alert the user, and re-run the failed step.

Pre-Flight passes ONLY when every field is "Yes" AND every referenced
file passes existence + non-zero-byte checks. Trust the checkpoint only
after reconciliation confirms the files are actually on disk.

### PHASE 4: VERIFICATION (runs automatically after each chapter)

See `accuracy-gate.md` for the 5 agent protocols.

**Fact-Check Stack (4 layers — when each fires):**

The non-fiction engine has four complementary fact-checking layers.
Each fires at a different point in the pipeline:

| Layer | File | When it fires | What it checks |
|---|---|---|---|
| **Source Management** | `source-management.md` | Phase 2 (Bible generation) | Source cataloguing, reliability rating, bibliography |
| **Fact-Checking Protocol** | `fact-checking-protocol.md` | Phase 3 step 7 (during writing) | Systematic claim verification as content is written |
| **Accuracy Gate** | `accuracy-gate.md` | Phase 4 step 12 (post-chapter) | 5-agent verification including Source Guardian |
| **Authenticity Guard** | `authenticity-guard.md` | Phase 3 step 10 (Humaniser) | AI pattern removal, name verification |

The Source Guardian (Agent 1 in accuracy-gate.md) is the primary
per-chapter fact-checker. The other three layers are supplementary:
source-management feeds the Bible, fact-checking-protocol feeds the
Writer, authenticity-guard feeds the Humaniser.

**Default:** Per-chapter verification after every chapter.
Run all 5 agents, save report, display dashboard, update checkpoint.

**Verification Report Gate (MANDATORY, BLOCKING):**
1. Save report to `engine-data/reports/ch{NN}-verification.md` via the
   Write tool. The Write MUST run in the parent conversation — subagent
   dispatch is forbidden for file-writing steps.

   **Bash ls verification (MANDATORY):**
   ```bash
   ls -la {project-path}/engine-data/reports/ch{NN}-verification.md
   ```
   If ls returns "No such file or directory", STOP. Re-run the Write
   in the parent conversation and re-verify. Do NOT mark the
   checkpoint `Report Saved` column Yes until Bash ls confirms the
   file on disk.
2. If score < 80: STOP and fix
3. Update checkpoint with V-Score and "Report Saved: Yes"
4. **Display to the user in this order (post-chapter presentation protocol):**
   a. **Progress Dashboard** first (see Progress Dashboard below).
   b. **5-agent verification summary** — compact view showing each
      agent's verdict + top findings. Full report is in the file;
      summary is for user review.
   c. **Chapter approval gate** — AskUserQuestion with options:
      "Approve — move to Chapter {N+1}", "Request revisions", "Read
      chapter in full".
   d. **Do NOT auto-display the full chapter prose after the dashboard.**
      The user has already seen the prose during the Humaniser's
      in-conversation display. If the user picks "Read chapter in
      full", THEN display the prose on-demand.

   **Summary block format:**

   ```
   5-Agent Verification Summary — Chapter {N}

   Continuity Guardian   : {PASS/WARN/FAIL} — {one-line finding}
   Quality Guardian      : {PASS/WARN/FAIL} — {one-line finding}
   Timeline Keeper       : {PASS/WARN/FAIL} — {one-line finding}
   Source Guardian       : {PASS/WARN/FAIL} — {one-line finding}
   Expert Tracker        : {PASS/WARN/FAIL} — {one-line finding}

   Overall score: {N}/100
   Full report: engine-data/reports/ch{NN}-verification.md
   ```

   Then present the approval gate. The full chapter prose is NOT
   auto-displayed — user requests it explicitly via "Read chapter in
   full".

### Progress Dashboard (MANDATORY — display after EVERY chapter)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Chapter {N} of {total}: "{chapter_title}"  ✓ COMPLETE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Score: {weighted_score}/100
  ┌──────────────────────────────────────┐
  │ Source:    {score}  │ Evidence:  {score}  │
  │ Citation:  {score}  │ Expert:    {score}  │
  │ Argument:  {score}  │                     │
  └──────────────────────────────────────┘
  Words: {actual}/{target} ({percentage}%)
  Issues: {critical} critical · {moderate} moderate · {minor} minor
  Beat: "{beat_name}" — {delivered|partial|missed}
  Outline Conformance: {verdict} (brief-time, pre-Writer)
  Canon Drift: {clean | {N} drift | blocked} (Source Guardian)

  Progress: [{filled_bar}{empty_bar}] {N}/{total} chapters
  Running avg score: {avg}  |  Running avg words: {word_avg}%

  Next: Chapter {N+1}: "{next_title}"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Enforcement rules:**
- This dashboard MUST be output as text in the conversation after every
  chapter — not just saved to a file.
- The **Outline Conformance** line is read from the pipeline-checkpoint's
  `OC Verdict` column for the current chapter (populated at step 5a by
  the Outline Conformance Agent). This line is **informational only** —
  it does NOT contribute to the weighted Score. Its purpose is
  traceability: the user can see at a glance that the brief-time check
  ran and what it found, alongside the chapter's post-writing scores.
  Format:
    - `PASS` — brief conformed cleanly
    - `WARN — {N} soft issues` — brief shipped with flagged issues
    - `FAIL — user override (Research Bible updated)` — user kept the brief
       and Section 9 (Chapter Outline) was updated
    - `FAIL — user override (brief kept as-is)` — user explicitly kept a
       non-conforming brief without updating Section 9
    - `FAIL — brief revised` — the original brief was revised and re-ran
       conformance before writing (shows the final verdict)
    - `n/a (pre-Outline-Conformance chapter)` — chapter was produced before
       the Outline Conformance Agent existed
  The checkpoint already has the verdict; the dashboard reads it from
  there. Do NOT Read the OC report file itself for this purpose (see
  File Operation Policy above — we trust the checkpoint). Do NOT re-run
  the conformance agent at post-chapter time — it runs at brief-time
  only (Phase 3 step 5a).

---

### PHASE 5: EDITORIAL PIPELINE

See `editorial-suite.md` for full protocols.

Run on complete manuscript (ALL 13 stages):

**Foundation:** 0. Authority Profile → 1. Category-Specific Audit
**Mechanical:** 2. Proofreader → 3. Copy Editor
**Structural:** 4. Dev Editor → 5. Alpha Reader → 6. Beta Reader → 7. Conflict Resolution
**Fixes & Audit:** 8. Surgical Fixes → 9. Full-Manuscript Fact Audit
**Conditional:** 10. Bias & Balance Review → 11. Multi-Source Consistency
**Refinement:** 12. Revision Loop (if scores below threshold)
**Final Gate:** 13. Publication Readiness Assessment

---

### PHASE 6: DELIVERY

1. Generate .docx manuscript with proper formatting
2. Generate bibliography/endnotes (per selected citation style)
3. Generate KDP metadata .docx (description, keywords, categories, comp titles)
4. Save all outputs to manuscript folder
5. Present final summary with word count, scores, editorial highlights
6. Display Cover Design notification

---

### PHASE 7: PUBLISHING STUDIO (Optional — On Demand)

- **Cover Designer** — market-researched concepts with AI image prompts
- **Marketing Expert** — blurbs, descriptions, social media, query letters
- **Market Scout** — live market intelligence for the category

---

## File Management

All output goes to: `{project_root}/[Book Title]/`

The project folder is split into two areas:
- **`manuscript/`** — User-facing files in .docx format (editable in Word/Google Docs)
- **`engine-data/`** — Internal engine files used by Claude for continuity and return visits

### Path Resolution (MANDATORY — runs once per project at Phase 1)

**Never pass `~` through to Write/Bash operations.** `~` expansion behaviour
varies between shells and operating systems. Before creating any project
files:

1. Resolve the home directory via bash:
   ```bash
   HOME_ABS=$(echo $HOME)   # Linux/macOS
   # Windows Claude Desktop: echo $USERPROFILE if $HOME is empty
   ```
2. Construct the full project path:
   `{HOME_ABS}/Documents/Ideorix-Projects/{sanitised_title}/`
3. Store the resolved absolute path in `project-config.md` as
   `project_root:` — all subsequent phases READ project_root from
   project-config.md, never re-expand `~`.

### Project Title Sanitisation (MANDATORY)

Before using the user's title as a folder name:

1. Strip any `..` (prevents path traversal)
2. Replace any `/` or `\` with `-`
3. Strip leading/trailing whitespace
4. Trim to 100 characters maximum
5. If empty after sanitisation, fall back to `Untitled Project`

Store the sanitised version as `sanitised_title:` in project-config.md
(used for folder/file names). Store the user's ORIGINAL title as
`display_title:` (used in all user-facing output — headers, dashboards,
KDP metadata). Sanitisation preserves usability without altering the
user's chosen title in display contexts.

> **IMPORTANT — Local-First Storage:**
> The Cowork workspace is **ephemeral** — files are lost if the skill is deleted or
> reinstalled. All project files MUST be saved to the user's **local filesystem**,
> which persists across sessions and skill updates.
>
> At the START of every session, ask the user where they want projects saved.
> Default: `~/Documents/Ideorix-Projects/`. Other good options:
> - `~/Desktop/Ideorix-Projects/` (easy access)
> - A folder inside Google Drive Desktop sync path (automatic cloud backup)
>
> **Why local?** The desktop app has full filesystem access. Saving locally means
> the user keeps their Research Bible, chapters, sources, and engine-data even if
> the skill is updated, reinstalled, or the workspace is cleared. Files are also
> available offline and can be opened in any editor.

## Cowork Space Monitor (MANDATORY — runs at session start)

**Why this exists:** The Cowork workspace is a ~10 GB ephemeral filesystem.
Users who save projects to Cowork instead of local storage accumulate
snapshots, research bibles, source databases, reports, and imports until
they hit the cap and the engine starts failing silently. This monitor
catches the problem before the first chapter is generated.

**At the START of every session** (after the licence header, before the
Front Gate menu), check Cowork's free space:

```bash
df -h /home/user 2>/dev/null | awk 'NR==2 {print $4}'
```

**Trigger logic:**

| Free Space | Action |
|---|---|
| > 2 GB | Silent — proceed normally |
| 500 MB – 2 GB | Display soft warning at session start (one-line note) |
| < 500 MB | Display HARD warning + diagnostic with biggest space consumers |
| < 100 MB | BLOCK new project creation entirely until space is freed |

**Soft warning template (500 MB – 2 GB):**

```
⚠ Cowork workspace: {free} free of 9.7 GB. Consider migrating projects
  to your local filesystem (~/Documents/Ideorix-Projects/) — Cowork is
  ephemeral and will lose all files on workspace reset.
```

**Hard warning template (< 500 MB):**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ⚠ COWORK WORKSPACE NEARLY FULL — {free} free of 9.7 GB

  Your projects are saved in the ephemeral Cowork workspace, which has
  a hard cap. When it fills up, the engine will start failing silently
  on snapshots, research bibles, and reports. Worse, Cowork can be reset
  at any time, taking all your project files with it.

  Top space consumers:
{list_top_consumers}

  Recommended actions:
    1. Move active projects to ~/Documents/Ideorix-Projects/ (local disk)
    2. Delete old engine-data/revisions/ folders for finished projects
    3. Delete old engine-data/imports/ folders for completed imports

  Run "/space" for full diagnostic and migration guidance.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Diagnostic — top space consumers:**

```bash
du -sh ~/Ideorix-Projects/*/engine-data/revisions 2>/dev/null | sort -h | tail -3
du -sh ~/Ideorix-Projects/*/engine-data/imports 2>/dev/null | sort -h | tail -3
du -sh ~/Ideorix-Projects/* 2>/dev/null | sort -h | tail -3
```

These three queries identify the largest revisions folders, the largest
import caches, and the largest project folders overall. Display the top 3
of each in the warning so the user knows exactly what to clean up.

**Block threshold (< 100 MB):**

If free space is below 100 MB, refuse to start a NEW project. Display:

```
⛔ Cowork workspace nearly exhausted — {free} free.

The engine cannot safely start a new project at this space level.
Snapshots, chapter files, and research bibles will fail to write.

Required actions before continuing:
  1. Move existing projects to ~/Documents/Ideorix-Projects/ (local disk)
  2. Or delete old projects from Cowork to free space
  3. Or work on an existing project that's already in your local filesystem

The engine will resume normal operation once Cowork has at least 500 MB free.
```

The user can still work on local-filesystem projects in this state — only
NEW project creation in Cowork is blocked.

## Cowork Project Setup Hard-Block (MANDATORY — Start New Project)

**When the user runs Start New Project or Research a New Project, after they specify the save path:**

Resolve the path to absolute. If it resolves to a Cowork-only path
(typically `/home/user/...` without `/mnt/` or `/Users/` or similar
local-filesystem markers), STOP and present this AskUserQuestion:

```
⚠ The path you specified — {path} — is in the Cowork workspace.

Cowork is ephemeral. Your project will be lost if:
  - The workspace is reset
  - You reinstall the Ideorix Non-Fiction skill
  - Cowork hits its 9.7 GB storage cap

For research and writing work that you care about, save to your local filesystem:
  - Mac:     ~/Documents/Ideorix-Projects/
  - Windows: C:\Users\{name}\Documents\Ideorix-Projects\
  - Or:      a folder inside Google Drive / Dropbox / OneDrive sync

Options:
  1. Use the recommended local path (~/Documents/Ideorix-Projects/)
  2. Specify a different path
  3. Continue with Cowork anyway (I understand the risks — for testing/throwaway only)
```

**If the user picks option 3**, log the choice to `engine-data/project-config.md`
with a `cowork_acknowledged: true` flag and proceed. Do NOT prompt again
for the same project — the user has explicitly accepted the risk.

**If the user picks option 1**, set the path to `~/Documents/Ideorix-Projects/`
and continue with project creation.

**If the user picks option 2**, re-prompt for the path and re-run the
Cowork detection. Loop until they choose a non-Cowork path or explicitly
accept Cowork.

This hard-block exists because soft warnings have not been sufficient —
users still default to Cowork without realising the implications, and the
cost of losing a research bible or half-written manuscript is high. The
block adds 30 seconds to project setup and prevents hours of lost work.

---

## Project File Structure

```
~/Documents/Ideorix-Projects/[Title]/
├── manuscript/
│   ├── {title}.docx                    # Final formatted manuscript
│   ├── {title}-kdp-metadata.docx       # KDP publishing metadata
│   └── research-companion.docx         # Research Bible Only mode deliverable
├── marketing/
│   ├── cover-concepts/                 # Cover design outputs
│   ├── blurbs/                         # Marketing copy
│   └── social-media/                   # Social media assets
└── engine-data/
    ├── research-bible.md               # Research Bible (Phase 2)
    ├── sources.md                      # Extracted source database (Phase 2C)
    ├── outline.md                      # Chapter outline
    ├── chapter-briefs/                 # Structural Architect outputs
    ├── chapters/                       # Raw chapter text
    ├── summaries/                      # Chapter summaries
    ├── reports/                        # Verification and editorial reports
    ├── revisions/                      # Automatic revision snapshots
    ├── pipeline-checkpoint.md          # Pipeline progress tracker
    ├── citation-index.md              # Source citation tracking
    └── project-config.md              # Project metadata from Phase 1
```

---

## Returning to a Project

When a user says "continue researching [title]" or returns to an existing project:

1. Check `Ideorix-Projects/` for matching project folders
2. Check `engine-data/project-config.md` for project mode
3. Read `engine-data/research-bible.md` to restore research context
4. Read `engine-data/sources.md` — build source index for lightweight lookup
5. Read latest `engine-data/summaries/` for continuity
6. Read `engine-data/pipeline-checkpoint.md` for exact resume point
7. Run Pre-Flight Check on last completed chapter
8. Resume from the next incomplete step

## Returning to a Research Bible Only Project

When a user returns with a completed manuscript:

1. Reconnect to Research Bible and source database
2. Validate manuscript against established research framework
3. Reconcile changes (new sources, restructured arguments)
4. Build Authority Voice Profile from the user's prose
5. Run the full editorial pipeline (Phase 5) — with the advantage of
   already knowing the research framework intimately

---

## Support Protocols

| Protocol | File | Purpose |
|----------|------|---------|
| Structural Architect | `structural-architect.md` | Chapter brief generation |
| Content Writer | `content-writer.md` | Prose execution |
| Research Bible | `research-bible.md` | Research framework generation |
| Outline Conformance | `outline-conformance.md` | Brief-time outline drift check (6th verification agent) |
| Accuracy Gate | `accuracy-gate.md` | 5 verification agents |
| Editorial Suite | `editorial-suite.md` | 13-stage editorial pipeline |
| Craft Standards | `craft-standards.md` | Non-fiction prose rules |
| Beat Structures | `beat-structures-nonfiction.md` | 12 structural frameworks |
| Rhetoric Library | `rhetoric-library.md` | Rhetorical strategies |
| Prose Humaniser | `prose-humaniser.md` | AI-ism removal |
| Forbidden Words | `forbidden-words.md` | Banned AI phrases |
| Source Management | `source-management.md` | Source tracking and bibliography |
| Fact-Checking | `fact-checking-protocol.md` | Systematic claim verification |
| Authority Builder | `authority-builder.md` | Author voice profiles |
| Revision Loop | `revision-loop.md` | Iterative improvement |
