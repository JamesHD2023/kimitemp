---
name: authority-builder
description: "Build a reusable author authority/voice profile for non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Authority Builder

> **Powered by Ideorix Non-Fiction** — The Research & Writing Engine

## Purpose

Build a reusable author authority/voice profile that controls how non-fiction
manuscripts sound. Unlike fiction's voice profiles (which capture narrative
character), the Authority Profile captures the author's expertise voice —
how they present evidence, establish credibility, and relate to readers.

## When to Use

- During Phase 1 setup (Q8) when the user uploads existing writing
- From the Writers Studio menu (option 7)
- Anytime the user says "Build a voice" or "Authority Builder"

## Two Creation Methods

### Method A: Build from Existing Writing

The user uploads 5,000+ words of their published or polished non-fiction writing.
The engine analyses it and extracts:

**Tone Analysis:**
- Academic ↔ Conversational position
- Objective ↔ Opinionated position
- Formal ↔ Intimate position
- Cautious ↔ Assertive position

**Evidence Integration Style:**
- How does the author introduce sources? (woven, cited, invisible)
- How often are sources cited per 1,000 words?
- Direct quotes vs paraphrasing ratio
- Does the author "show their work" or present conclusions?

**Sentence Architecture:**
- Average sentence length
- Paragraph length tendency
- Use of fragments, lists, rhetorical questions
- Complexity patterns (simple declarative vs complex analytical)

**Vocabulary Analysis:**
- Jargon density (technical terms per 1,000 words)
- Vocabulary ceiling (most complex words used)
- Register consistency (formal throughout or shifts by section)

**Reader Relationship:**
- Direct address ("you") vs inclusive ("we") vs objective (third person)
- Teaching mode vs peer mode vs storyteller mode
- Humour frequency and type
- Personal disclosure level

**Authority Markers:**
- How does the author signal expertise?
- Credentials mentioned or implied?
- Data-driven or experience-driven?

### Method B: Guided Conversation

If the user has no existing writing to upload, build the profile through
interactive questions:

1. "Who is your ideal reader? What do they already know about this subject?"
2. "When you explain something complex, do you tend to use analogies, data,
   stories, or step-by-step logic?"
3. "Read these two paragraphs on the same topic — which sounds more like you?"
   (Present academic vs conversational versions)
4. "Do you prefer to cite sources formally, weave them into narrative, or
   present conclusions and put sources in endnotes?"
5. "What's your relationship with the reader — teacher, guide, peer, or
   provocateur?"
6. "Rate your preferred tone: serious ← 1 2 3 4 5 → playful"
7. "How much personal experience do you share in your writing?"

Build the profile from answers and confirm with the user.

## Profile Output Format

```
AUTHORITY VOICE PROFILE — {Author Name / Pen Name}

TONE POSITION:
  Academic ←——→ Conversational: {position}
  Objective ←——→ Opinionated: {position}
  Formal ←——→ Intimate: {position}
  Cautious ←——→ Assertive: {position}

EVIDENCE INTEGRATION STYLE:
  {description}

SENTENCE ARCHITECTURE:
  {patterns, average lengths, signature structures}

VOCABULARY LEVEL:
  {specialist / accessible / mixed}
  Jargon tolerance: {high / moderate / low}

READER RELATIONSHIP:
  {teacher / guide / peer / provocateur / storyteller}
  Address style: {you / we / third person}

AUTHORITY MARKERS:
  {what signals this author's expertise}

METAPHOR SOURCES:
  {where analogies come from — everyday life, science, sport, history, etc.}

EMOTIONAL REGISTER:
  {analytical distance / controlled passion / raw honesty / dry wit}

VOICE SIGNATURE:
  {what makes this voice immediately distinguishable from generic non-fiction}
```

## Linking to Pen Names

Authority profiles link to pen names (same as fiction). An author might have:
- "Dr. Sarah Mitchell" — formal, academic authority voice (for textbooks)
- "Sarah Mitchell" — accessible, conversational voice (for popular audience)
- Both use the same source material, different authority profiles.

## Persistence

Profiles saved to: `~/Documents/Ideorix-Projects/.pen-names/profiles/`
Loaded automatically when the pen name is selected during project setup.
