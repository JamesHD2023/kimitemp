---
name: environmental
description: "Category plugin for environmental and climate non-fiction. climate science, conservation, environmental justice, sustainability"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Environmental / Climate. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | environmental |
| Display Name | Environmental / Climate |
| Parent Group | Popular Science |
| Typical Word Count | 70,000–90,000 |
| Default Structure | Problem-evidence-solutions with narrative case studies |
| Citation Style | Endnotes with full bibliography; in-text attribution for data |
| Audience Baseline | Engaged general reader; climate-aware but seeking deeper understanding |
| Comparable Titles | Elizabeth Kolbert, Naomi Klein, Dahr Jamail, Michael Mann, Robin Wall Kimmerer |

## Subcategory Options

When the user selects Environmental / Climate, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| climate-science | Climate Science | Atmospheric physics, carbon cycle, tipping points, climate modelling, paleoclimate | Data-driven narrative, model-to-reality, historical climate parallels |
| conservation | Conservation | Species protection, habitat restoration, rewilding, protected areas, biodiversity loss | Place-based case studies, before-and-after, conflict-and-resolution |
| environmental-justice | Environmental Justice | Pollution burdens, climate inequality, indigenous rights, frontline communities, corporate accountability | Community-centred narrative, systemic analysis, testimony and data |
| sustainability | Sustainability | Circular economy, renewable energy, food systems, urban design, degrowth | Solutions-focused, systems thinking, comparative case studies |
| nature-place | Nature & Place Writing | Landscape, belonging, solastalgia, sense of place, ecological grief and hope | Literary-personal, place-as-character, seasonal or temporal structure |

**Default:** If the user does not specify, use `climate-science` conventions as baseline.

## Structural Architect Instructions

### Core Technique: Urgency + Accuracy

Environmental writing must convey the genuine urgency of ecological and climate crises
while maintaining rigorous scientific accuracy. The Architect must design chapters that
are **emotionally compelling without being manipulative** and **scientifically precise
without being dry**.

### Chapter Architecture Patterns

1. **The Witness Scene**. Open with a specific place, community, or organism
   experiencing environmental change. The reader must see the stakes in concrete,
   human or ecological terms before encountering data.
2. **The Science Foundation**. Lay out the scientific evidence clearly. What do we
   know? How do we know it? What is the confidence level? Climate science operates
   on probabilities. communicate them honestly.
3. **The Systems View**. Pull back to show how the specific case connects to larger
   systems: global carbon cycles, economic structures, political decisions, feedback
   loops. Environmental problems are never isolated.
4. **The Human Dimension**. Who is affected? Who is responsible? Who is acting?
   Environmental writing without people is incomplete. Include communities,
   scientists, activists, policymakers.
5. **The Path Forward**. Every chapter that diagnoses a problem must gesture toward
   solutions, actions, or possibilities. Not false optimism. honest assessment of
   what can be done.

### Evidence Deployment

- **Climate data:** IPCC reports, NOAA, NASA, Met Office, peer-reviewed climate
  journals. Always cite the assessment, the confidence level, and the date.
- **Case studies:** Specific places, communities, and ecosystems experiencing change.
  Named locations, named people, specific dates.
- **Economic and policy data:** World Bank, UNEP, national environmental agencies.
  Environmental writing must engage with economics and politics.
- **Indigenous and local knowledge:** Traditional land management, indigenous climate
  observations, community-led conservation. Always attributed.

### Brief Template Additions

For each chapter brief, the Architect MUST include:

- **Central Environmental Issue:** The specific problem or theme this chapter addresses.
- **Witness Location:** The primary place or community grounding the chapter.
- **Key Data Points:** 3–5 specific statistics or findings to anchor the argument.
- **Systems Connections:** How this issue connects to broader environmental systems.
- **Human Voices:** Named individuals. scientists, community members, activists,
  policymakers. to feature.
- **Solutions Component:** Specific actions, policies, technologies, or community
  responses to include.
- **Emotional Calibration:** Guidance on the urgency-to-hope ratio for this chapter.

## Content Writer Craft Rules

### Voice & Tone

- **Urgent but not hysterical.** The facts are alarming enough. Let the evidence
  carry the weight. Do not add rhetorical panic.
- **Empathetic but not patronising.** Communities affected by environmental crisis
  are agents, not victims. Write about people with dignity and agency.
- **Honest about uncertainty.** Climate projections have ranges. Ecological outcomes
  are complex. Say "models project" not "science proves."
- **Solutions-aware.** Even in the darkest chapters, the reader should sense that
  action is possible and meaningful.

### Data Presentation

- Contextualise every statistic. "2 degrees" means nothing without explaining the
  baseline, the timeframe, and the consequences.
- Use concrete comparisons: "An area of rainforest the size of Belgium is lost
  every year."
- Present ranges, not false precision: "Between 1 and 3 million species face
  extinction risk this century."
- Always date your data. "As of 2024, atmospheric CO2 stood at 422 ppm."

### Place Writing

- Environmental writing is always about specific places. Generic "the planet" language
  is weak. Name the river, the glacier, the neighbourhood, the farm.
- Describe environmental change through sensory detail: what the place looks like now,
  what it looked like before, what it may look like in the future.
- Let landscape carry emotional weight without telling the reader what to feel.

### Community & Justice

- Centre the voices of affected communities, especially those on the frontlines of
  climate impact.
- Name people. Use direct quotes. Give the reader someone to connect with.
- Acknowledge that environmental harm is unevenly distributed. by race, class,
  geography, and colonial history.
- Do not extract stories from marginalised communities without providing context and
  agency.

### Balancing Doom and Hope

- Every chapter that presents a crisis must include at least one element of agency:
  a solution being tried, a community resisting, a technology emerging, a policy
  succeeding.
- Do not manufacture false hope. Some situations are dire. But complete despair
  paralyses action. and the purpose of environmental writing is to catalyse action.
- Distinguish between optimism (things will be fine) and hope (action is meaningful
  even when outcomes are uncertain).

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the stakes. What is at risk, shown through a specific
  place or species. The reader must see the loss before they hear the data.
- **Sentence calibration:** Medium sentences averaging 14–22 words. Urgency lives in
  precision, not in breathlessness.
- **Urgency without alarmism:** The prose should convey gravity through concrete detail,
  not through exclamation or hyperbole. Let the facts carry the weight.
- **Human story grounding the data:** Every data-heavy passage must be preceded or
  followed by a human moment. a farmer, a scientist, a child in a flooded town.
  Statistics land harder when they have a face.
- **Rhythm pattern:** Alternate between place-writing (sensory, immersive, slower) and
  evidence-writing (data-driven, precise, faster). The oscillation keeps the reader
  both feeling and thinking.
- **Tension baseline:** Maintain narrative tension ≥5 throughout. Environmental writing
  carries inherent stakes. the prose must honour that urgency without letting it
  become monotone alarm.
- **Tension drivers:** The gap between what is happening and what could be done. The
  distance between scientific knowledge and political action. The clock running down.
- **Paragraph calibration:** Short paragraphs for impact after a long evidentiary
  passage. A one-sentence paragraph stating a stark fact can land like a verdict.
- **Data delivery:** Contextualise every number within the sentence that presents it.
  "An area of rainforest the size of Belgium" is prose; "4.1 million hectares" alone
  is a report.
- **Hope rhythm:** After sustained passages of crisis, introduce a turn. a solution
  attempted, a community resisting, a policy working. The reader needs breath.
- **Read-aloud test:** The prose should sound like a person who cares deeply but thinks
  clearly. If it sounds like a lecture or a scream, recalibrate.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Scientific accuracy | All climate/environmental claims match IPCC or peer-reviewed sources |
| 2 | Data integrity | Statistics dated, sourced, contextualised, and presented with appropriate ranges |
| 3 | Witness grounding | Chapter anchored in specific place, community, or ecosystem |
| 4 | Systems thinking | Local/specific case connected to systemic/global context |
| 5 | Human voices | At least 1 named individual. scientist, community member, or policymaker |
| 6 | Solutions presence | Every problem chapter includes at least one concrete solution or action |
| 7 | Justice lens | Uneven distribution of environmental harm acknowledged where relevant |
| 8 | Emotional calibration | Urgency without hysteria; honesty without despair |
| 9 | Indigenous inclusion | Indigenous perspectives included and properly attributed where relevant |
| 10 | Voice consistency | Urgent-but-measured tone maintained; no preaching or lecturing |

## Source Requirements

### Mandatory Source Types

- **IPCC Assessment Reports:** The gold standard for climate science claims. Cite the
  specific working group, chapter, and confidence level.
- **Peer-reviewed environmental science:** For ecological, biological, and atmospheric
  claims not covered by IPCC synthesis.
- **Government and institutional data:** NOAA, NASA, EPA, UNEP, World Bank, national
  meteorological agencies for statistical claims.
- **Community and indigenous sources:** Testimony, oral history, community-led research.
  Attributed to named individuals or organisations.

### Source Freshness

- **Climate data:** Must use most recent available datasets. Climate science moves
  fast. a 5-year-old projection may be outdated.
- **Policy landscape:** Legislation, international agreements, and corporate commitments
  change rapidly. Verify currency at time of writing.
- **Ecological data:** Population counts, deforestation rates, ocean temperatures . 
  use the most recent published data and note the survey date.

### Attribution Standards

- Distinguish between IPCC statements (consensus), individual studies (evidence), and
  expert opinion (interpretation).
- For climate projections, always specify the scenario (SSP1-2.6, SSP5-8.5, etc.)
  and the timeframe.
- Credit community-led research and citizen science alongside institutional science.

## Category-Specific Guardrails

### MANDATORY. Scientific Consensus Represented

- The scientific consensus on anthropogenic climate change is not a matter of debate
  in this genre. Present it as established science.
- Where genuine scientific debate exists (climate sensitivity ranges, tipping point
  timelines, specific ecological projections), represent the range of scientific
  opinion accurately.
- Do not give equal weight to fringe positions. The "balance" is within the scientific
  mainstream, not between science and denial.

### MANDATORY. Solutions Not Just Doom

- No chapter may end on pure despair. This is a structural requirement, not a
  suggestion.
- Solutions must be honest. do not oversell a technology or policy. But include them.
- Distinguish between individual action, community action, corporate responsibility,
  and policy change. Do not place systemic burdens on individual consumers.

### MANDATORY. Indigenous Perspectives Included

- Where the book discusses land, ecosystems, or environmental management, include
  indigenous perspectives and knowledge systems.
- Traditional ecological knowledge often contains insights that Western science is
  only now documenting. Present TEK with respect and rigour.
- Acknowledge colonial histories that contributed to environmental destruction.
- Use indigenous place names alongside colonial names where possible and appropriate.

### Additional Guardrails

- Do not use "natural disaster" for events with anthropogenic drivers. Use "climate
  disaster" or "extreme weather event" as appropriate.
- Avoid eco-anxiety amplification without providing agency. The reader should feel
  moved to act, not paralysed.
- Do not blame individuals for systemic problems. Acknowledge structural drivers . 
  fossil fuel industry, policy failures, economic systems.
- Be precise about timelines. "By 2050" is different from "by 2100." Climate
  communication depends on temporal precision.
- Do not conflate weather and climate. A single heatwave is weather; a trend of
  increasing heatwaves is climate.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Earth and sky. deep greens, ocean blues, amber/gold for hope
  elements. Desaturated tones for crisis; vivid colour for resilience.
- **Typography:** Bold sans-serif for urgency. Consider all-caps title for impact.
  Subtitle in lighter weight to add nuance.
- **Imagery:** Aerial landscapes (before/after), dramatic natural phenomena (glaciers,
  fires, floods), or striking nature photography. Abstract earth-system
  visualisations for climate science titles.
- **Mood:** Gravity tempered by beauty. The cover should say: this matters, and
  it is worth fighting for.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Climate Science | Data visualisation, atmospheric imagery, temperature colour scales |
| Conservation | Wildlife or habitat imagery, contrast between loss and recovery |
| Environmental Justice | Community-centred imagery, industrial/natural juxtaposition |
| Sustainability | Clean design, green/blue palette, future-oriented imagery |
| Nature & Place Writing | Landscape photography, painterly quality, literary aesthetic |

### Typography Rules

- Title: 40–60% of cover area. Short, punchy titles work best in this category.
- Subtitle: Essential for specificity. "What Climate Change Means for [X]" format.
- Author name: Prominent if they are a known climate voice. Moderate otherwise.
- Consider a strapline from a prominent endorser (Bill McKibben, Greta Thunberg, etc.)
  if available.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Climate Science | Kindle Store > Kindle eBooks > Nonfiction > Science > Earth Sciences > Climatology |
| Conservation | Kindle Store > Kindle eBooks > Nonfiction > Science > Nature & Ecology > Endangered Species |
| Environmental Justice | Kindle Store > Kindle eBooks > Nonfiction > Politics & Social Sciences > Social Sciences > Human Geography |
| Sustainability | Kindle Store > Kindle eBooks > Nonfiction > Science > Environment > Sustainability |
| Nature & Place Writing | Kindle Store > Kindle eBooks > Nonfiction > Science > Nature & Ecology > Nature Writing |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Environmental Policy | Kindle Store > Kindle eBooks > Nonfiction > Politics & Social Sciences > Politics > Environmental Policy |
| Science Essays | Kindle Store > Kindle eBooks > Nonfiction > Science > Essays & Narratives |
| Nature & Ecology | Kindle Store > Kindle eBooks > Nonfiction > Science > Nature & Ecology > General |

### Keyword Recommendations

- Include "climate change" or "environmental" as appropriate
- Include the specific focus area (rewilding, ocean acidification, environmental justice, etc.)
- Include "sustainability" if solutions-focused
- Include geographic specificity if place-based
- Include comparable author names for discoverability
- Consider "nature writing" for literary-environmental crossover
