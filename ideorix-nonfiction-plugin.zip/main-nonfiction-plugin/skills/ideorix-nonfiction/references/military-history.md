---
name: military-history
description: "Category plugin for Military History. wars, campaigns, strategy, and the human experience of armed conflict across all eras"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Military History. Category Plugin

## Metadata

| Key | Value |
|-----|-------|
| Category ID | `military-history` |
| Display Name | Military History |
| Parent Group | History |
| Typical Word Count | 80,000 – 130,000 |
| Audience | Military history enthusiasts, veterans, strategy students, general history readers |
| Tone Spectrum | Authoritative and precise; balances strategic analysis with personal narrative |
| Comparable Titles | *The Guns of August* (Tuchman), *Stalingrad* (Beevor), *The Killer Angels* (Shaara) |

## Subcategory Options

When the user selects **Military History**, prompt them to choose a subcategory:

| ID | Subcategory | Description |
|----|-------------|-------------|
| `ancient-warfare` | Ancient Warfare | Conflicts from earliest recorded history through the fall of Rome (c. 476 CE) |
| `medieval-early-modern` | Medieval & Early Modern | From post-Roman warfare through the Napoleonic era (c. 500 – 1815) |
| `world-wars` | World Wars | The First and Second World Wars, including interwar period conflicts |
| `modern-conflicts` | Modern Conflicts | Post-1945 wars. Korea, Vietnam, Falklands, Gulf Wars, Afghanistan, asymmetric warfare |
| `naval-air-special-ops` | Naval / Air / Special Operations | Domain-specific military history. sea power, air power, and unconventional warfare |

### Subcategory-Specific Notes

- **Ancient Warfare**: Source material is limited and often biased (victor accounts). Flag provenance explicitly.
- **Medieval & Early Modern**: Address the evolution of technology (longbow, gunpowder, fortification) as a driver of tactical change.
- **World Wars**: The bibliography is vast. Position the book's contribution clearly. what new angle, source, or theatre does it cover?
- **Modern Conflicts**: Classified material, living participants, and ongoing geopolitical sensitivity require extra care with claims.
- **Naval / Air / Special Operations**: Technical detail must be accurate but accessible. Define specialist terminology on first use.

## Structural Architect Instructions

### Recommended Structures

1. **Campaign Narrative**: Chapters follow the arc of a campaign or war. build-up, opening moves, turning points, resolution, aftermath. Best for single-conflict accounts.
2. **Dual-Perspective**: Alternating chapters or sections between opposing sides. Best for books that aim to represent "both sides of the hill."
3. **Strategic-to-Tactical Zoom**: Chapters open with the strategic picture, then zoom into a specific battle, unit, or individual. Best for combining grand strategy with human experience.
4. **Thematic-Chronological Hybrid**: Organise by themes (logistics, intelligence, morale, technology) while moving chronologically within each theme.

### Standard Chapter Architecture

- **Situation report**: Open with the strategic context. what is at stake, who commands, what forces are deployed.
- **Terrain and conditions**: Describe the physical environment. Geography shapes battles; readers must visualise the ground.
- **The action**: Narrate the engagement with clarity. Use unit designations, place names, and timestamps to orient the reader.
- **The human element**: Incorporate first-person accounts. letters home, oral histories, after-action reports. to anchor the reader in lived experience.
- **Analysis**: After narrating what happened, explain why. Assess decisions, errors, innovations, and luck.
- **Consequences**: What changed as a result? Casualties, territorial shifts, political fallout, morale effects.

### Required Supplementary Material

- **Maps**: Minimum one operational map per major engagement. Maps must show troop positions, movements, terrain features, and key timestamps. Label clearly.
- **Timelines**: Include a master campaign timeline in the front matter and mini-timelines at the start of each chapter covering multi-day operations.
- **Order of Battle**: For significant engagements, provide an order-of-battle appendix listing formations, commanders, and approximate strengths.
- **Glossary**: Military terminology glossary in the back matter.
- **Endnotes**: Prefer endnotes for general readership; footnotes acceptable for academic-leaning works.
- **Bibliography**: Divide into Primary Sources, Secondary Sources, and Official Histories / War Diaries.
- **Index**: Must include unit designations, place names, personal names, and weapons systems.

## Content Writer Craft Rules

1. **Strategy and suffering are inseparable.** Never present battles as abstract chess games. Behind every arrow on a map are human beings. Balance operational analysis with personal experience.
2. **Clarity in chaos.** Combat is confusing. The writer's job is to make it comprehensible without falsifying the fog of war. Use clear spatial and temporal markers.
3. **Name the soldiers.** Where sources permit, name individual combatants at every level. generals, NCOs, privates, medics, civilians caught in the crossfire.
4. **Respect technical accuracy.** Weapon ranges, unit organisations, logistics capacities, and tactical doctrines must be accurate. Military-literate readers will catch errors instantly.
5. **Show the wait.** War is long stretches of boredom punctuated by terror. Do not edit out the monotony, the logistics, the marching. these are as much the experience of war as the fighting.
6. **Write terrain.** Describe the ground. A river, a ridgeline, a forest, a stretch of open desert. these features determine outcomes. The reader must see the battlefield.
7. **Translate military language.** On first use, explain acronyms, unit structures, and doctrinal terms. A "battalion" is roughly 500–800 soldiers; a "division" is 10,000–15,000. Give the reader scale.
8. **Handle casualties with gravity.** Report casualty figures precisely when known; state when figures are disputed or estimated. Never use casualty numbers as mere decoration.
9. **Avoid hindsight bias.** Do not judge commanders for failing to foresee outcomes that only became clear later. Assess decisions based on information available at the time.
10. **Contextualise within the home front.** Wars are fought by societies, not just armies. Address political, economic, and social dimensions that shaped the conflict.

### PROSE RHYTHM MAPPING
- Ch 1 hook: the battle, the decision, or the moment of consequence. the reader is dropped into the action or the weight of command
- Sentence length: SHORT in action sequences (8-15 words) for urgency and chaos; medium-long in strategic analysis (18-28 words) for authority and scope
- Tension ≥6 from chapter 1. military history demands stakes from the first page; lives and nations hang in the balance
- The dual rhythm is the genre's signature: staccato combat prose alternating with measured strategic assessment
- Terrain description earns its place: geography determines outcomes, and the reader must see the ground before the fight
- Deploy first-person accounts (letters home, oral histories, after-action reports) at moments of maximum emotional impact
- Dialogue from primary sources only. attributed, dated, and placed in context; reconstructed speech forbidden
- Pacing alternates between the command tent (slow, deliberate, analytical) and the front line (fast, visceral, immediate)
- Evidence integration: casualty figures stated precisely and sourced; disputed figures presented as ranges with explanation
- Short paragraphs during combat: one action, one observation, one consequence per paragraph; the reader feels the compression of battle
- Longer paragraphs for strategic context: the reader steps back to see the whole theatre, the logistics, the political dimension
- Reader engagement across information-dense passages: technical detail (weapons, formations, logistics) woven into human experience, not catalogued
- Authority delivery through precision: correct unit designations, accurate weapon ranges, proper terminology. military-literate readers catch errors instantly
- The "why should I read this book" question is answered by the human cost visible from the first page
- Avoid hindsight bias in the prose rhythm: present decisions as they were made, with the information available at the time
- Emotional gravity in casualty passages: the prose slows, the sentences lengthen, the reader is made to feel the weight of the numbers
- The home front earns its pages: political and social context paced as counterpoint to the military narrative, not as interruption
- Chapter endings: the next battle approaches, the next decision looms, the consequences of this chapter's events ripple outward

## Quality Check Criteria

| Criterion | Standard | Method |
|-----------|----------|--------|
| Factual Accuracy | Dates, unit designations, commanders, and casualty figures verified against official records | Cross-reference with at least two independent sources |
| Map Accuracy | All maps correspond precisely to textual descriptions; no contradictions between map and narrative | Map-to-text audit |
| Balance of Perspectives | Both/all belligerent perspectives represented; civilian experience included | Perspective audit per chapter |
| Technical Precision | Weapons, equipment, and tactical descriptions are correct for the period | Subject-matter expert review |
| Narrative Clarity | Reader can follow the sequence of events without confusion | Read-through with timeline cross-check |
| Human Element | Every chapter includes at least one personal account or named individual experience | First-person source audit |
| Casualty Reporting | All casualty figures are sourced; disputed figures are flagged | Source audit for all numerical claims |
| Chronological Integrity | No unexplained jumps in time; transitions between timeframes are clearly signposted | Timeline continuity check |

## Source Requirements

### Minimum Source Standards

- **Primary sources**: At least 25% of citations must reference primary material. war diaries, unit histories, personal letters, oral histories, after-action reports, photographic evidence.
- **Official histories**: Engage with relevant national official histories (e.g., British Official History, US Army Green Books, Australian Official Histories).
- **Multiple belligerent perspectives**: Sources from at least two opposing sides must be consulted.
- **Veteran accounts**: Where living memory exists, incorporate oral histories or published memoirs with appropriate source criticism.

### Source Hierarchy

1. Official war diaries, after-action reports, and operational records
2. Personal letters, diaries, and memoirs written during or immediately after the conflict
3. Official national histories and staff studies
4. Peer-reviewed monographs and journal articles
5. Published veteran memoirs (note bias and timing of publication)
6. Journalistic accounts and war correspondence (contemporary)
7. Documentary and photographic evidence

### Citation Format

- Chicago Manual of Style, Notes-Bibliography system (17th edition or later).
- Endnotes with full bibliographic details on first reference; shortened form thereafter.
- Archival sources must include repository name, collection reference, and document identifier.
- Bibliography divided into: Unpublished Primary Sources, Published Primary Sources, Official Histories, Secondary Sources.

## Category-Specific Guardrails

### Absolute Rules

1. **No glorification of war.** Present combat with unflinching honesty. Courage and skill deserve recognition, but war's destruction, waste, and suffering must never be minimised or romanticised.
2. **No dehumanisation of any side.** Every combatant. ally and enemy. is a human being. Avoid language that reduces any group to caricature or abstraction.
3. **Casualty figures must be sourced.** Every numerical claim about deaths, wounds, or prisoners must cite a specific source. Where figures are disputed, present the range and explain the discrepancy.
4. **No invented tactical details.** If the sequence of a battle is uncertain, say so. Do not fabricate specifics to fill gaps in the historical record.

### Representation Protocol

- **All belligerents**: Present the perspective, motivations, and experience of all sides in a conflict. A book about D-Day must include the German defenders' experience. A book about Stalingrad must include both Soviet and German perspectives.
- **Civilians**: War's impact on non-combatants must be addressed. Displacement, occupation, bombing, and famine are integral to military history.
- **Marginalised combatants**: Address the contributions and experiences of colonial troops, minority soldiers, women in war, and resistance fighters where relevant.

### Sensitive Content Guidelines

- **War crimes and atrocities**: Report factually with evidence. Do not sanitise, but do not linger gratuitously. Provide context for why atrocities occurred without excusing them.
- **Prisoners of war**: Address treatment of POWs with reference to applicable conventions and actual practice.
- **Nuclear weapons**: Discuss with full acknowledgement of the human cost; avoid treating as merely a strategic abstraction.
- **Ongoing conflicts**: Exercise heightened caution with claims about recent or ongoing wars. Distinguish between confirmed facts, credible reports, and allegations.

### Avoiding Common Pitfalls

- **Great Man syndrome**: Do not attribute outcomes solely to commanders. Logistics, weather, terrain, morale, and chance all play roles.
- **Technological determinism**: New weapons matter, but so do doctrine, training, leadership, and will. Avoid "the X won the war" narratives.
- **Hindsight generals**: Assess decisions based on what was known at the time, not on outcomes that became clear only later.
- **Clean war myth**: No war is clean. Address logistics failures, friendly fire, desertion, and breakdown of discipline as normal aspects of armed conflict.

## Cover Design Specifications

| Element | Guideline |
|---------|-----------|
| Imagery | Period-authentic photography, artwork, or cartography. Black-and-white photography is powerful for twentieth-century conflicts. Avoid glamourised Hollywood-style depictions. |
| Typography | Bold, commanding serif or slab-serif fonts for title. Clean sans-serif for subtitle. Must convey authority and seriousness. |
| Colour Palette | Muted, sombre tones. charcoal, khaki, deep navy, steel grey, dried-blood red. Avoid bright or cheerful palettes. |
| Layout | Title-dominant with strong imagery. Maps or tactical diagrams as design elements can work well. |
| Period Signalling | Cover must immediately communicate the era. a Great War photograph, a medieval battlefield painting, a satellite reconnaissance image for modern conflicts. |
| Back Cover | 100–150 word synopsis emphasising the human story as well as the strategic. 2–3 endorsements from military historians or veterans. Author credentials, especially any military background or archival access. |
| Spine | Title and author legible; consider subtle military-themed design element (a unit flash, map contour line, or period weapon silhouette). |

## KDP Category Mapping

### Primary Categories

| BISAC Code | Category Path |
|------------|---------------|
| HIS027000 | HISTORY / Military / General |
| HIS027130 | HISTORY / Military / Strategy |

### Subcategory-Specific Mappings

| Subcategory | BISAC Code | Category Path |
|-------------|------------|---------------|
| Ancient Warfare | HIS027010 | HISTORY / Military / Ancient |
| Medieval & Early Modern | HIS027010 | HISTORY / Military / Ancient (or HIS027000 General) |
| World Wars | HIS027090 | HISTORY / Military / World War I (or HIS027100 World War II) |
| Modern Conflicts | HIS027110 | HISTORY / Military / Vietnam War (adjust by conflict) |
| Naval / Air / Special Ops | HIS027040 | HISTORY / Military / Naval (or HIS027000 General) |

### Keyword Recommendations

- Include conflict-specific terms (e.g., "World War II", "Vietnam War", "Battle of Gettysburg")
- Include branch/domain terms (e.g., "naval warfare", "air combat", "special forces")
- Target "military history of [conflict/era]" long-tail phrases
- Include commander names and unit designations where applicable
- Add thematic terms ("strategy", "tactics", "leadership", "logistics", "combat")

### Amazon Browse Categories

- Books > History > Military > General
- Books > History > Military > [Specific War/Conflict]
- Books > History > Military > Strategy
- Books > History > Military > Naval / Aviation / Special Forces
- Kindle Store > Kindle eBooks > History > Military
