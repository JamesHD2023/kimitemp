---
name: source-persistence
description: "Source Persistence HARD GATE. When the engine accepts user-uploaded files (manuscript, codex, worldbuilding documents, character sheets, importer bundles, source books, supplementary canon), the absorbed content MUST be persisted to the canonical project folder with a user-verifiable marker file. Without persistence the engine has the content in working memory but the user has no on-disk artifact to confirm what was absorbed, no way to re-use the source in a future session, and no evidence trail when editorial output diverges from canon. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.9"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Source Persistence Protocol (MANDATORY for any flow that accepts user uploads)

## Purpose

Ensure that every user-uploaded file the engine absorbs is
also written to disk in a known canonical location, with a
user-verifiable marker file listing what was absorbed. Without
this protocol the engine can claim absorption without proof,
the user has no way to re-use the content in a future session,
and downstream divergence (editorial drift, fabrication,
canon contradictions) cannot be cross-checked against the
absorbed source.

This is the silent-failure pattern applied to the persistence
layer:

> The engine returns success metadata ("I read your codex") that
> diverges from actual effect (no on-disk artifact preserved).
> The user trusts the success-claim, downstream output is
> generated, and the user catches the divergence only after
> editorial output reveals canon drift — by which point the
> source is gone (the upload session ended, the in-memory copy
> was lost when the conversation rotated).

## Failure mode addressed

A user (Mitch, May 2026) uploaded an HTML codex alongside his
manuscript when running Edit & Revise on "Secrets of
Silvergrove". The engine read the codex, used it during the
editorial pipeline (alpha-reader, beta-reader, dev-editor
reports cite specific codex entries), and produced a tracked-
changes deliverable. After the session, the user inspected the
project folder and found:

- The modified Word file (manuscript output)
- Editorial reports (alpha/beta/dev reader)
- A voice profile
- `engine-data/market-pulse.md`
- **No source-canon/ directory**
- **No copy of the HTML codex anywhere**

The engine had absorbed the codex into working memory, used
it correctly during editorial work (confirmed by codex
references in the reports), and then discarded the in-memory
copy when the session ended. The user has no way to:

1. Verify what was absorbed (only indirect evidence via reports)
2. Re-use the codex in a future session without re-uploading
3. Cross-check editorial drift against the absorbed source

This is the gap. The fix: persist every absorbed file to disk
with a marker file the user can spot-check.

## When the protocol applies

Every flow that accepts user uploads of supplementary canon
(beyond the primary input) MUST apply this protocol. Currently:

| Flow | Spec | Primary input | Supplementary canon? |
|------|------|---------------|----------------------|
| BYO-canon Step 0 | byo-canon.md (fiction) | source-canon/ folder | Already covered (this IS the canon-absorbing entry point) |
| Importers | novelcrafter / plottr / scrivener / screenplay-importer.md | Importer bundle | Already covered (v2.7.0 wires source-canon/ persistence) |
| Edit & Revise | edit-and-revise.md | Manuscript | **Codex / worldbuilding / character sheets uploaded alongside MUST be persisted** |
| Manuscript Clinic | manuscript-clinic.md | Manuscript | Same — supplementary uploads MUST be persisted |
| Continue Writing | continue-writing.md (fiction) | Existing project files | New supplementary uploads MUST be persisted |
| Continue Researching | continue-researching.md (NF) | Existing project files | Same |
| Heritage Text | heritage-text.md | Source public-domain text | Source MUST be preserved (not just the modernised output) |
| Analyze a Book | analyze-a-book.md | Source book | Source MUST be preserved when uploaded as file |

For BYO-canon and importers the persistence is already done.
This protocol covers the other six flows, where supplementary
canon historically went into context only.

## The protocol — three steps

### Step 1: Detect supplementary canon among uploads

When the user provides files via upload, the engine
distinguishes:

- **Primary input** — the file the flow is built around
  (manuscript for Edit & Revise; existing book for Analyze;
  source text for Heritage Text)
- **Supplementary canon** — any other uploaded file that
  isn't the primary input (codex HTML, character sheets,
  worldbuilding docs, source bibliographies, anything the
  user is providing as context)

Heuristic for detection:
1. Identify the primary input from the flow's expected file
   type (manuscript = largest .docx / .md with chapter
   structure; source book = largest narrative file).
2. Every other uploaded file is supplementary canon.
3. If ambiguous (multiple files of the same type, none
   clearly primary), the engine MUST ask the user to confirm
   which is primary. (See `ask-user-disambiguation.md` for
   the disambiguation protocol.)

### Step 2: Persist with verification

For the primary input:
- Persist to `~/Documents/Ideorix-Projects/[Title]/manuscript/`
  per the format spec (Edit & Revise → original DOCX preserved
  as `{Title}-original.docx`; Heritage Text → original under
  `manuscript/source-original.{ext}`).

For supplementary canon:
- Create `~/Documents/Ideorix-Projects/[Title]/source-canon/`
  if it doesn't exist (`mkdir -p` discipline; verify with
  `ls -la` per File-Write Hygiene).
- Copy each supplementary file to
  `source-canon/{original-filename}` preserving the original
  format (HTML stays HTML; PDF stays PDF; markdown stays
  markdown).
- For binary formats the engine can't easily re-read on
  resume (e.g. compiled .scriv bundles), ALSO produce a
  text extraction at `source-canon/{name}-extracted.md` so
  Continue-* flows can re-Read the markdown easily.
- Verify each write per File-Write Hygiene (Bash ls + byte
  count + non-zero size).

Both writes use the bash-direct heredoc protocol from the
File-Write Hygiene binding — Write/Edit tool calls are NOT
permitted for these absorptions. Subagent dispatch is also
forbidden (existing rule).

### Step 3: Write the canon-absorbed marker file

After all persistence completes, write
`~/Documents/Ideorix-Projects/[Title]/engine-data/canon-absorbed.md`
with the following format. This file is APPENDED across
sessions (each session adds a new dated block) so the user can
audit the full history of absorbed content:

```markdown
# Canon Absorbed — {Title}

## Session {YYYY-MM-DDTHH-MM} — {Flow Name}

Files absorbed:

| File | Source | Persisted to | sha256 (first 16) | First-200-char excerpt |
|------|--------|--------------|-------------------|-------------------------|
| {primary_filename} | upload (original size: {bytes}) | manuscript/{primary_filename} | {sha} | {excerpt} |
| {supp_filename_1}.html | upload (original size: {bytes}) | source-canon/{supp_filename_1}.html | {sha} | {excerpt} |
| {supp_filename_2}.docx | upload (original size: {bytes}) | source-canon/{supp_filename_2}.docx | {sha} | {excerpt} |

Read-Verification thresholds applied: pdf=100 docx=100 html=100 md=20 fountain=50

Status: ALL_PERSISTED | PARTIAL ({N} files persisted, {M} failed)
```

The first-200-char excerpt is the user's spot-check tool. They
can open the marker file and confirm "yes, that opening text
matches my codex" — or if it doesn't, surface a Read-Verification
or persistence failure that needs correction.

### HARD GATE — halt on FAILED_PERSIST

If any persistence step fails (write returns error, Bash ls
verification fails, byte-count mismatch), the protocol BLOCKS
the flow. The engine MUST NOT call any downstream agent
(editorial pipeline, importer parser, Clinic analyser, Heritage
modernizer, etc.) until every absorbed file has either:

- Successfully persisted to its canonical location, OR
- Been explicitly skipped by the user with a logged reason

Per-failure resolution mirrors Read-Verification:

```
HALT — I absorbed {N} of your uploaded files but couldn't persist {M} of them
to the project folder. This means the editorial work I run now would not have
an on-disk record you can audit later.

Files I persisted successfully:
  - {file1} → manuscript/{file1} ({bytes} bytes confirmed)
  - {file2} → source-canon/{file2} ({bytes} bytes confirmed)

Files I could NOT persist:
  - {failed1}  (reason: {error})

Three options to resolve:

  A. Retry the persistence (most failures are transient).
  B. Confirm the file should be skipped (the absorbed copy in
     working memory is used for this session only; no on-disk
     trace).
  C. Halt the flow entirely; resolve the underlying issue
     (path permission, disk space) and re-run.

Which option for each failure?
```

## Binary-format extraction discipline

Some uploaded formats can't be re-read directly by the engine's
Read tool on a future session (compiled .scriv bundles, .epub
archives, .pdf with scanned-image content). For these:

1. Persist the original binary file as the canonical artifact.
2. ALSO produce a text extraction at
   `source-canon/{name}-extracted.md` containing the absorbed
   markdown/text content, with frontmatter recording the
   extraction details:

   ```markdown
   ---
   source_file: {original_filename}.scriv
   extraction_method: scrivener-importer / unzip / etc.
   extraction_date: {YYYY-MM-DD}
   sha256_of_source: {hash}
   ---

   # Extracted content from {original_filename}

   {absorbed text content}
   ```

3. The Continue-* flows that re-load existing project files
   prefer the `-extracted.md` artifact for re-reading
   (deterministic, no re-extraction needed). The original
   binary file is preserved for archival / re-export.

## Logging

Beyond `canon-absorbed.md`, every persistence operation is also
logged to the per-session run log:

```
~/Documents/Ideorix-Projects/[Title]/engine-data/run.log
```

Per-persistence entry:

```
[YYYY-MM-DDTHH-MM] SOURCE_PERSIST
  Source: upload
  File: {filename}
  Category: primary | supplementary
  Persisted to: {canonical_path}
  Bytes: {N}
  sha256: {hash}
  Status: ALL_PERSISTED | FAILED_PERSIST (reason: {...})
```

## Integration with other bindings

This protocol pairs with three existing bindings:

1. **Read-Verification** (`read-verification.md`, v2.7.6) —
   the read-presence check runs FIRST. Empty Reads trigger
   the HARD GATE there, before persistence is attempted.
2. **File-Write Hygiene** (`core-pipeline.md`) — the persistence
   write uses the bash-direct heredoc protocol; subagent
   dispatch forbidden; verify with Bash ls + byte count.
3. **AskUserQuestion Disambiguation** (`ask-user-disambiguation.md`,
   v2.7.8) — when primary-vs-supplementary detection is
   ambiguous, the engine asks the user (single-decision
   question; ambiguous responses trigger confirmation echo).

## What the protocol does NOT do

- It does **not** apply to BYO-canon Step 0 (already
  persists `source-canon/` content as the entry-point flow)
  or to importers (already persist via the importer protocols
  added in v2.7.0).
- It does **not** apply to engine-internal files written
  earlier in the session (`engine-data/` working state). The
  File-Write Hygiene binding already covers those.
- It does **not** transform or reformat the absorbed content.
  HTML stays HTML; binary stays binary. The extraction-as-
  markdown step is additive (both are saved), not a replacement.
- It does **not** auto-merge supplementary canon with existing
  `source-canon/` content if the user re-uploads. Conflicts
  surface to the user (e.g. "you previously uploaded codex.html
  on 2026-04-12; this upload is named the same — replace,
  rename, or skip?").

## Anti-patterns this protocol prevents

- **Silent codex absorption** — engine reads user's codex
  during a session, uses it for editorial work, discards the
  in-memory copy when the session ends; user has no on-disk
  evidence of what was absorbed (the documented Mitch
  May-2026 failure mode).
- **Re-upload tax** — user has to re-upload supplementary
  canon every session because the engine doesn't preserve it.
- **Audit gap** — user catches editorial drift but can't
  cross-check against the absorbed source (the source no
  longer exists on their disk).
- **Trust gap** — user has only the engine's claim of
  absorption with no verifiable artifact; the engine could
  have absorbed partially or interpreted incorrectly and
  the user can't confirm post-hoc.

## Cross-cutting binding

This protocol is the **tenth cross-cutting binding**. The
canonical catalog of all bindings and audited primitives is
`silent-failure-audit.md`. This binding addresses primitive
#21 (User-uploaded canon persistence) in that catalog.

Parallel bindings —

1. Architect Mode binding
2. Verification Discipline binding
3. File-Write Hygiene binding
4. Edit-Tool Typographic Fidelity binding
5. Read-Verification binding
6. Web-Content Verification binding
7. Subagent Output Verification binding
8. Bash-Output Verification binding
9. AskUserQuestion Disambiguation binding
10. **Source Persistence binding (this spec)**

## Silent-Failure Audit

This binding spec is exempt from the Silent-Failure Audit
section requirement (Check 10) because it IS audit
infrastructure rather than a feature spec. The exemption is
granted in the engine's spec-lint repo CI discipline `check_silent_failure_audit`
exempt pattern.
