---
name: fact-checking-protocol
description: "Mechanical fact verification protocol for non-fiction manuscripts"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Fact-Checking Protocol

## Purpose

Systematic, mechanical verification of every factual claim in the manuscript.
This runs as part of Stage 9 (Full-Manuscript Fact Audit) in the editorial
pipeline, and can also be invoked per-chapter by the Source Guardian.

## Process

### Token-Budget Discipline (read BEFORE Step 1 on long manuscripts)

A 120K-word NF manuscript typically carries ~2,500-3,500 factual
claims. Extracting them into a single in-context table is a context-
window risk: the table alone can run 40-60K tokens, then Step 2
(source verification) requires re-reading every claim against the
Research Bible, then Step 3 (confidence classification) requires the
same, and the chapter prose is still in context. A naive single-pass
extraction is reliably context-overflow on full-manuscript runs.

**Required protocol for manuscripts ≥ 25,000 words OR ≥ 8 chapters:**

1. **Chunked per-chapter extraction.** Run Steps 1-3 against each
   chapter independently. Save each chapter's claim table to
   `engine-data/reports/ch{NN}-fact-checks.md` using the bash-direct
   write protocol per `mandatory-pipeline-rules.md` File Operation
   Policy. Do NOT keep prior chapters' tables in context — the
   per-chapter file is the source of truth.
2. **Consolidation pass.** After all chapters are extracted, run a
   single Consolidation Pass that reads only:
   - The per-chapter fact-check files (one at a time, summarising
     each before loading the next)
   - The Research Bible source ledger
   - A small running aggregate (claim-count totals per Level A-F,
     cross-chapter source overlap, repeated-claim detection)
3. **Final Stage-9 report.** The Stage-9 Fact Audit report aggregates
   the per-chapter results into the manuscript-wide totals shown in
   Step 4 below. Per-chapter files remain on disk as the audit trail.

**Manuscripts under 25,000 words / 8 chapters** may use single-pass
extraction without chunking. The chunk boundary is conservative:
err on the side of chunking when the manuscript is on the edge.

**Why this matters:** Pre-chunking discipline, Stage 9 on long
manuscripts silently truncated the claim table at ~1,500-2,000 claims
because the model ran out of context and started compressing rather
than emitting. Truncated tables passed downstream verification with
fewer findings than the manuscript actually had — the hallucination
shape was "table looks complete because it ends, but it ended
because we ran out of room." Chunking eliminates the truncation
trigger by capping each pass at one chapter's worth of claims
(~80-150) instead of the full-manuscript tail.

### Step 1: Claim Extraction

Read the chapter/manuscript and extract every factual claim into a table:

```
| # | Claim | Type | Source Cited | Location |
|---|-------|------|-------------|----------|
| 1 | "GDP grew 3.2% in Q3 2024" | statistic | Fed Reserve Report | Ch3, p.12 |
| 2 | "Einstein published in 1905" | date | Not cited | Ch1, p.3 |
| 3 | "Dr. Smith leads the MIT lab" | credential | Interview transcript | Ch5, p.8 |
```

**Claim types:** statistic, date, quote, credential, historical-fact, scientific-claim,
geographic-fact, institutional-fact, biographical-fact, legal-claim

### Step 2: Source Verification

For each claim, verify against the Research Bible and source database:

```
| # | Claim | Research Bible Value | Match | Action |
|---|-------|---------------------|-------|--------|
| 1 | "GDP grew 3.2%" | "GDP grew 3.2% (Fed Q3 Report)" | YES | None |
| 2 | "Einstein 1905" | "Einstein published 4 papers 1905" | YES | None |
| 3 | "Dr. Smith leads MIT lab" | "Dr. Smith, Director, MIT AI Lab" | YES (verify title) | Check "leads" vs "Director" |
```

### Step 3: Confidence Classification

Categorise each claim by verifiability:

| Level | Category | Description | Action |
|-------|----------|-------------|--------|
| A | Documented Fact | Verifiable from primary sources | Confirm and cite |
| B | Expert Opinion | Attributed to a named expert | Confirm attribution |
| C | Author's Analysis | The author's interpretation of evidence | Label as analysis |
| D | Reasonable Inference | Logical conclusion from evidence | Flag as inference |
| E | Speculation | Not directly supported by evidence | Flag prominently |
| F | Unverifiable | Cannot be confirmed or denied | Flag for author decision |

**Rule:** Level E and F claims must be explicitly qualified in the prose
("It is possible that...", "One interpretation suggests..."). Unqualified
speculation presented as fact is a CRITICAL error.

### Step 4: Output

```
FACT-CHECK REPORT — Chapter {N} / Full Manuscript

Total claims checked: {N}
Level A (Documented):   {N} ({%})
Level B (Expert):       {N} ({%})
Level C (Analysis):     {N} ({%})
Level D (Inference):    {N} ({%})
Level E (Speculation):  {N} ({%}) — MUST be qualified in text
Level F (Unverifiable): {N} ({%}) — MUST be flagged for author

ERRORS FOUND:
| # | Claim | Issue | Severity | Fix |
|---|-------|-------|----------|-----|

UNQUALIFIED SPECULATION:
| # | Claim | Location | Suggested Qualifier |
|---|-------|----------|-------------------|

MISSING SOURCES:
| # | Claim | Location | Suggested Source |
|---|-------|----------|-----------------|
```

## When to Run

- **Per-chapter:** The Source Guardian runs a lightweight version during verification
- **Full manuscript:** Stage 9 of the editorial pipeline runs the complete protocol
- **On demand:** User can request "fact-check chapter N" or "fact-check the manuscript"
