---
name: social-history
description: "Category plugin for Social History. the lives, labours, and cultures of ordinary people as the engine of historical understanding"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Social History. Category Plugin

## Metadata

| Key | Value |
|-----|-------|
| Category ID | `social-history` |
| Display Name | Social History |
| Parent Group | History |
| Typical Word Count | 70,000 – 110,000 |
| Audience | General readers interested in "history from below," students of social sciences, cultural studies readers |
| Tone Spectrum | Empathetic and grounded; scholarly rigour with an accessible, human-centred voice |
| Comparable Titles | *The Making of the English Working Class* (Thompson), *A People's History of the United States* (Zinn), *The Return of Martin Guerre* (Davis) |

## Subcategory Options

When the user selects **Social History**, prompt them to choose a subcategory:

| ID | Subcategory | Description |
|----|-------------|-------------|
| `labour-working-class` | Labour & Working-Class History | Unions, strikes, workplace conditions, the experience of waged and unwaged labour across eras |
| `gender-womens` | Gender & Women's History | The historical experiences, roles, and struggles of women and gender-diverse people |
| `racial-ethnic` | Racial & Ethnic History | The histories of racial and ethnic communities, including systemic oppression and cultural resilience |
| `cultural-everyday` | Cultural & Everyday Life | Food, dress, housing, leisure, family structures, and the texture of daily existence in past societies |
| `immigration-migration` | Immigration & Migration | The movement of peoples. voluntary and forced. and the social transformations that follow |

### Subcategory-Specific Notes

- **Labour & Working-Class History**: Foreground the workers themselves, not just union leaders or legislative milestones. Include informal and domestic labour.
- **Gender & Women's History**: Go beyond "notable women" lists. Examine structural conditions, legal frameworks, and the experiences of ordinary women.
- **Racial & Ethnic History**: Centre the voices of the communities being discussed. Avoid framing non-white histories solely through the lens of oppression; include agency, culture, and joy.
- **Cultural & Everyday Life**: Use material culture. objects, buildings, images. as primary evidence. Avoid antiquarianism; connect the everyday to larger social forces.
- **Immigration & Migration**: Include push and pull factors, journey experiences, reception, and long-term integration or exclusion. Address both voluntary migration and forced displacement.

## Structural Architect Instructions

### Recommended Structures

1. **Thematic**: Chapters organised around aspects of social life (work, home, belief, leisure, protest). Best for cultural and everyday-life histories.
2. **Chronological with Social Focus**: Time-based chapters that consistently foreground ordinary people's experiences rather than political events. Best for labour and migration histories.
3. **Voices-Led**: Each chapter anchored by a specific individual or community whose story illuminates a broader social pattern. Best for gender, racial, and ethnic histories.
4. **Case-Study Mosaic**: A series of deep dives into specific communities, workplaces, neighbourhoods, or moments that collectively build a larger picture.

### Standard Chapter Architecture

- **A life, a moment, a place**: Open with a specific person, scene, or location drawn from primary sources. Ground the reader in the tactile reality of the past.
- **Widen the lens**: Move from the specific to the general. what does this individual experience reveal about broader social patterns?
- **Evidence and argument**: Present the historical evidence. oral histories, material culture, statistical data, legal records. and build the chapter's analytical point.
- **Counter-narratives**: Acknowledge where the dominant historical record is silent or biased. Discuss what is missing and why.
- **Connections**: Link the chapter's themes to the book's larger argument and to other chapters.
- **Return to the human**: Close by returning to a personal story or concrete detail that crystallises the chapter's meaning.

### Required Supplementary Material

- **A note on sources**: A dedicated section explaining the evidentiary base. what sources exist, what is missing, and how gaps have been addressed.
- **Photographs and illustrations**: Wherever possible, include images of the people and places discussed. Prioritise vernacular photography, material culture, and community-generated images over official portraits.
- **Glossary**: Define period-specific and discipline-specific terms (e.g., "indenture", "enclosure", "miscegenation laws").
- **Endnotes**: Prefer endnotes for general readership.
- **Bibliography**: Divide into Primary Sources (oral histories, archives, material culture) and Secondary Sources.
- **Index**: Must include community names, place names, personal names, and thematic terms.

## Content Writer Craft Rules

1. **Centre lived experience.** The fundamental unit of social history is the human life. Begin and return to specific people, families, and communities.
2. **Let sources speak.** Quote liberally from diaries, letters, oral histories, and testimony. The voices of ordinary people are the genre's greatest strength.
3. **Describe the material world.** What did people eat? What did their homes look like? What did they wear? What tools did they use? Material detail anchors social history in reality.
4. **Quantify where possible.** Wages, prices, hours worked, infant mortality rates, migration numbers. statistics give structure to personal narratives.
5. **Resist the tidy narrative.** Social change is messy, uneven, and contested. Do not impose a false arc of progress (or decline) on complex historical processes.
6. **Acknowledge silence.** Many of the people social history studies left few written records. Be transparent about what is known, what is inferred, and what is lost.
7. **Use institutions as windows, not as protagonists.** Discuss laws, unions, churches, and governments as they affected daily life. not as self-contained stories.
8. **Write across class.** Even within "working-class history," there are hierarchies. skilled vs. unskilled, employed vs. unemployed, free vs. unfree. Capture internal complexity.
9. **Place matters.** Social history is often intensely local. Describe neighbourhoods, factories, fields, and kitchens with geographic specificity.
10. **Connect, do not lecture.** Draw connections between past social conditions and their legacies, but avoid turning history into a sermon. Trust the reader to make their own moral judgements.

### PROSE RHYTHM MAPPING
- Ch 1 hook: the human story within the social shift. open with a specific person whose life embodies the larger pattern
- Sentence length: medium (15-22 words) as the baseline; the social historian's rhythm is empathetic, grounded, and human-scaled
- Individual experience grounding the macro trend from page 1. the reader meets a person before they meet a thesis
- Tension ≥4 from chapter 1. the reader must sense that this person's life is shaped by forces larger than themselves
- Primary-source voices carry the rhythm: quote liberally from diaries, letters, oral histories, and testimony
- Alternate between the individual and the systemic: a life described, then the forces that shaped it, then back to the life
- Evidence integration blends the qualitative and quantitative: a wage figure given meaning by the family it fed
- Pacing across information-dense passages: statistical and analytical paragraphs stay short and purposeful; narrative paragraphs extend
- Material-world description anchors the prose: what people ate, wore, lived in, worked with. specificity makes the past real
- Deploy quantitative evidence (wages, prices, mortality rates) at moments where numbers make the human cost concrete
- Paragraph rhythm: personal-narrative paragraphs are warm and immersive; analytical paragraphs are measured and concise
- The "why should I read this book" question is answered by making ordinary lives feel extraordinary and consequential
- Reader engagement: every chapter must feel like discovering a world the reader did not know existed
- Authority delivery through empathy and rigour combined: the historian cares about these people AND has done the research
- Silence acknowledgement as rhythm element: "We do not know" creates its own kind of tension and honesty
- Resist the tidy narrative in the prose rhythm itself. social change is messy; the prose should reflect uneven, contested progress
- Vary between the intimate (a single family, a single workplace) and the panoramic (the movement, the era, the transformation)
- Chapter endings: the individual's story continues; the social forces are still in motion; the reader wants to know what happens next

## Quality Check Criteria

| Criterion | Standard | Method |
|-----------|----------|--------|
| Voice Representation | Every chapter must include at least two direct quotations from primary sources authored by or attributable to the social group being studied | Primary-source audit |
| Factual Accuracy | All dates, names, statistics, and events verified against reliable sources | Cross-reference check |
| Source Diversity | Evidence drawn from at least three types of source (e.g., oral, archival, material, statistical) across the manuscript | Source-type inventory |
| Narrative Humanity | Named individuals appear in every chapter; no chapter is purely abstract or analytical | Named-person audit |
| Analytical Depth | Each chapter articulates at least one interpretive claim, not merely a descriptive account | Argument mapping |
| Silence Acknowledgement | The manuscript explicitly addresses gaps in the historical record at least once per section | Gap-identification review |
| Sensitivity | Language is respectful and historically precise; no slurs are used without direct quotation and contextualisation | Language review |
| Structural Coherence | Chapters build cumulatively toward the book's central argument | Reverse-outline test |

## Source Requirements

### Minimum Source Standards

- **Primary sources**: At least 30% of citations must reference primary material. oral histories, diaries, letters, material artefacts, parish records, court documents, photographs.
- **Oral histories**: Where available, oral history transcripts and recordings are essential. Note the date of recording and the relationship between interviewer and subject.
- **Material culture**: Engage with physical objects, buildings, landscapes, and visual culture as evidence, not merely illustration.
- **Statistical evidence**: Use census data, wage records, demographic studies, and economic indicators to support qualitative claims.

### Source Hierarchy

1. Oral histories and first-person testimony from the communities studied
2. Personal documents. diaries, letters, family records, vernacular photography
3. Material culture and archaeological evidence
4. Official records. census, court, parish, immigration, employment
5. Contemporary journalism and social investigation
6. Peer-reviewed monographs and journal articles
7. Community and local histories

### Citation Format

- Chicago Manual of Style, Notes-Bibliography system (17th edition or later).
- Endnotes with full bibliographic details on first reference; shortened form thereafter.
- Oral history citations must include interviewee name (or pseudonym with explanation), date, interviewer, and repository.
- Material culture citations must include object description, date, location, and repository or collection.
- Bibliography divided into: Oral Histories, Archival and Unpublished Sources, Published Primary Sources, Secondary Sources.

## Category-Specific Guardrails

### Absolute Rules

1. **Centre lived experience, not ideology.** The book's argument must emerge from evidence about how people actually lived, not from a predetermined ideological framework imposed on the past.
2. **Avoid retroactive value judgements.** Do not condemn historical actors for failing to hold modern values. Contextualise beliefs and behaviours within their time while still acknowledging harm done.
3. **No ventriloquism.** Do not put words or thoughts into historical subjects' minds. If inferring feelings or motivations, make the inference explicit and evidence-based.
4. **No monolithic groups.** Avoid treating any social group as homogeneous. "Women", "workers", "immigrants" are not uniform categories. capture internal diversity.

### Representation Protocol

- **Agency**: Always present marginalised groups as agents of their own history, not merely as victims of oppression. Show resistance, adaptation, creativity, and community-building alongside suffering.
- **Self-naming**: Use the terms that historical communities used for themselves, with explanation where those terms have changed. Note when modern terminology is being applied retrospectively.
- **Intersectionality**: Acknowledge that social categories (class, race, gender, religion) intersect and shape one another. A working-class woman's experience differs from a working-class man's.

### Sensitive Content Guidelines

- **Oppression and violence**: Report systemic oppression and episodes of violence factually, with full evidence. Neither minimise nor sensationalise.
- **Slurs and period language**: When quoting sources that contain offensive language, retain the original wording within quotation marks, with a brief contextual note. Never use slurs in the author's own voice.
- **Trauma**: When discussing traumatic experiences (enslavement, forced migration, sexual violence, child labour), maintain a tone of gravity and respect. Avoid voyeurism.
- **Living communities**: When writing about communities that still exist, be aware that descendants may read the book. Write with accuracy and with care.

### Common Pitfalls to Avoid

- **Romanticising poverty**: Hardship is not picturesque. Do not aestheticise deprivation or present suffering as ennobling.
- **Nostalgia**: Avoid implying that past social arrangements were simpler, purer, or more authentic than the present.
- **Tokenism**: Do not include a single chapter on women or minorities as a gesture. Social diversity must be woven throughout.
- **Determinism**: Whether economic, cultural, or technological. avoid suggesting that outcomes were inevitable. Historical actors always had choices, even if constrained.

## Cover Design Specifications

| Element | Guideline |
|---------|-----------|
| Imagery | Vernacular photography, material culture, community scenes. Prioritise images of real people and real places over artistic abstractions. Black-and-white photography can be powerful. |
| Typography | Warm, humanist serif or clean sans-serif fonts. Avoid overly formal or decorative typefaces. The feel should be approachable and grounded. |
| Colour Palette | Warm, earthy tones. sepia, brown, warm grey, muted gold, forest green. Alternatively, strong documentary-style black-and-white with a single accent colour. |
| Layout | Image-forward where strong photography is available. Title must be legible at thumbnail size. |
| Period Signalling | Cover should evoke the era and the people. a factory floor, a domestic interior, a migration route, a community gathering. Avoid generic or cliched imagery. |
| Back Cover | 100–150 word synopsis centring the human stories. 2–3 endorsements from historians or relevant community voices. Author credentials and connection to the subject. |
| Spine | Title and author legible; warm colour tone consistent with front cover. |

## KDP Category Mapping

### Primary Categories

| BISAC Code | Category Path |
|------------|---------------|
| HIS036000 | HISTORY / Social History |
| SOC026000 | SOCIAL SCIENCE / Sociology / General |

### Subcategory-Specific Mappings

| Subcategory | BISAC Code | Category Path |
|-------------|------------|---------------|
| Labour & Working-Class | HIS036010 | HISTORY / Social History / General (+ SOC051000 Social Classes & Economic Disparity) |
| Gender & Women's | HIS058000 | HISTORY / Women |
| Racial & Ethnic | HIS056000 | HISTORY / African American & Black (adjust by group) |
| Cultural & Everyday Life | HIS036000 | HISTORY / Social History |
| Immigration & Migration | HIS036060 | HISTORY / Social History / General (+ SOC007000 Emigration & Immigration) |

### Keyword Recommendations

- Include community-specific terms (e.g., "working class", "women's history", "Black history", "immigrant experience")
- Include era-specific terms (e.g., "Victorian", "Gilded Age", "postwar")
- Target "social history of [topic/place/era]" long-tail phrases
- Include methodological terms ("oral history", "history from below", "everyday life")
- Add thematic terms ("labour", "gender", "migration", "community", "class")

### Amazon Browse Categories

- Books > History > Social History
- Books > History > Women in History
- Books > History > African American (adjust by community)
- Books > Politics & Social Sciences > Sociology
- Kindle Store > Kindle eBooks > History > Social History
