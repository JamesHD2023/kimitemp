---
name: batch-editor-nonfiction
description: "5-chapter deep editorial pass for non-fiction — cross-chapter analysis"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Batch Editor — Non-Fiction

## Snapshot before overwrite (v2.7.41 HARD GATE — `destructive-mutation-snapshot.md`)

The Batch Editor overwrites user-approved chapter prose across
5 chapters per batch. Before any chapter is overwritten, the
Batch Editor MUST snapshot the current chapter to
`engine-data/snapshots/`. This is a HARD GATE: per chapter, if
the snapshot fails, that chapter is NOT overwritten in this
batch (the batch may continue on remaining chapters or abort
entirely depending on the user's preference).

```bash
# Per chapter, BEFORE applying the batch's edits to ch{NN}.md:
mkdir -p {project-path}/engine-data/snapshots
TS=$(date -u +"%Y-%m-%dT%H-%M-%SZ")
SRC={project-path}/engine-data/chapters/ch{NN}.md
SNAP={project-path}/engine-data/snapshots/ch{NN}.pre-batch-editor.${TS}.md
cp "$SRC" "$SNAP"
if [ ! -s "$SNAP" ]; then
    echo "FATAL: snapshot creation failed for ch{NN} at $SNAP"
    echo "       Batch Editor will SKIP ch{NN}; user content unmodified."
    continue   # or exit 1 to abort the whole batch
fi
ls -la "$SNAP"
```

The batch report MUST list each chapter's snapshot path so the
user can revert any chapter individually. Multiple snapshots of
the same chapter accumulate naturally (batch 1 → snapshot;
batch 2 → another snapshot; etc.).

## File-Write Hygiene (MANDATORY — applies to every chapter file this protocol touches)

This protocol performs cross-chapter Edit / rewrite operations
on chapter files in 5-chapter blocks. The chained-Edit
truncation safeguard documented in `core-pipeline.md` § Chained-
Edit Truncation Safeguard applies in full and is binding here:

- **Prefer Write over chained Edit for chapter-scale rewrites.**
  When the change touches more than half a chapter file, write
  the whole revised chapter once via the bash-heredoc + mv
  pattern rather than accumulating sequential Edit patches.
- **Cap individual Edit replacements at ~2 KB.** Split larger
  rewrites into multiple smaller Edits.
- **Run `scripts/word-count-check.sh` after every chapter file
  this protocol writes or edits**, not just at the end of the
  batch. Truncation caught after one Edit is recoverable;
  truncation that propagates through multiple editorial stages
  may not be.
- **Verify on-disk integrity via Bash** (`ls -la` + `wc -w` +
  tail-byte check) before reporting batch success — the
  Edit/Write tool's success return does not confirm on-disk
  integrity, and the Read tool can return cached content that
  masks corruption.

**HARD GATE — BLOCKING.** A truncated chapter file caught at
this stage MUST be repaired (clean Write of the full intended
content, post-write integrity verification) before the batch
report is delivered. This protocol has historically been the
site of silent truncation events; this section is the explicit
counter-protocol.

## Purpose

The Batch Editor runs a deep editorial pass across the last 5 chapters every
time a chapter divisible by 5 is completed (chapters 5, 10, 15, 20, 25, and
the final chapter). It catches cross-chapter patterns that per-chapter
verification cannot: accumulating AI-isms, argument drift, evidence
imbalance, authority voice degradation, and pacing flatlines.

## When to Run

- After Chapter 5, 10, 15, 20, 25, and the final chapter
- MANDATORY — the Batch Editor MUST complete before the next chapter begins
- Produces a Batch Health Report displayed to the user

## The 7 Analyses

### Analysis 1: AI-Ism Accumulation Audit

Scan the full 5-chapter batch for AI-telltale patterns from `forbidden-words.md`.
Per-chapter checks catch individual violations; the batch check catches
accumulation patterns — the same phrase appearing once per chapter across 5
chapters is technically under per-chapter limits but signals AI generation.

### Analysis 2: Argument Trajectory

Map the argument progression across the 5-chapter batch:
- Is the thesis advancing or stalling?
- Is complexity increasing or plateauing?
- Are new evidence pillars being introduced or is the same evidence recycled?
- Does the argument build or repeat?

### Analysis 3: Evidence Distribution

Check source usage across the batch:
- Is any single source over-relied upon (>30% of citations)?
- Are there chapters with significantly fewer sources than others?
- Is the evidence hierarchy maintained (Level 1-3 for key claims)?
- Are new sources being introduced or has the well run dry?

### Analysis 4: Authority Voice Consistency

Compare the Authority Voice Profile against 3 representative passages from
each chapter in the batch:
- Is the voice drifting across chapters? (common in long manuscripts)
- Is vocabulary level consistent?
- Is evidence integration style consistent?
- Is the reader relationship consistent?

### Analysis 5: Pacing Analysis

Map the pacing sliders across the 5-chapter batch:
- Are consecutive chapters monotonously similar?
- Is information density appropriate for this section of the book?
- Are there 2+ consecutive chapters at low engagement?
- Does the pacing match the structural framework's expectations?

### Analysis 6: Source Consistency

Check that sources are cited consistently across the batch:
- Same source cited the same way in all chapters?
- No contradictory claims from the same evidence?
- Expert positions quoted consistently (not selectively)?

### Analysis 7: Fact Accumulation Check

Cross-reference all factual claims across the batch:
- Any facts that contradict each other between chapters?
- Any statistics that shift between chapters?
- Any experts whose credentials are described differently?

## Output: Batch Health Report

```
BATCH HEALTH REPORT — Chapters {N-4} to {N}

AI-ISM ACCUMULATION: {clean / warning / critical}
ARGUMENT TRAJECTORY: {advancing / stalling / repeating}
EVIDENCE DISTRIBUTION: {balanced / skewed toward {source}}
VOICE CONSISTENCY: {consistent / minor drift / significant drift}
PACING: {varied / monotonous / {specific issue}}
SOURCE CONSISTENCY: {consistent / {issues found}}
FACT CONSISTENCY: {clean / {contradictions found}}

ISSUES REQUIRING FIXES:
{list with severity and recommendation}

RUNNING BANLIST UPDATES (Channel A — permanent, opening hard constraints):
{patterns promoted to HARD CONSTRAINTS this batch, with promotion trigger}

FEED-FORWARD NOTES FOR NEXT BATCH (Channel B — advisory, one-batch lifespan):
{guidance for the Structural Architect for the next 5 chapters — pacing,
 voice, evidence distribution. NOT patterns that recurred across chapters;
 those go into Channel A / the Running Banlist.}
```

Save to `engine-data/reports/batch-{N}-health.md` via the bash-direct
write protocol (`cat >/tmp/...` + `mv` + `sync` + `ls -la`). Batch
health reports are critical-path files; a Write-tool call that reports
success while the file fails to land on disk will corrupt the next
batch's feed-forward.
Display to user in conversation.

## Feeding Forward

After the batch edit completes, the results feed into the NEXT batch's
generation via TWO channels, each with different durability:

### Channel A — Running Banlist (permanent, Writer-facing opening constraints)

Patterns detected by the Batch Editor are written into
`engine-data/running-banlist.md` under the same protocol the Humaniser
uses (see `prose-humaniser.md` "Running Banlist"). All writes to
`running-banlist.md` use the bash-direct protocol (`cat >/tmp/...` +
`mv` + `sync` + `ls -la`). This is the ONLY channel that is guaranteed
to land at the top of future Content Writer
prompts as opening hard constraints.

1. **AI-ism patterns found in 2+ chapters of the batch** → PROMOTE
   DIRECTLY to HARD CONSTRAINTS (skipping WATCHLIST — the Batch Editor
   sees 5 chapters of data at once, so consecutive-chapter detection is
   immediate). Promotion trigger: "batch editor — {N} chapters in batch".
2. **Per-chapter surgical-fix recurrence** → If the same pattern needed
   surgical fixes in 2+ chapters of the batch, it is PROMOTED to HARD
   CONSTRAINTS with a "recurring fix burden — {N} chapters" note in the
   Rule field. This is the production-failure signal — if the same
   surgical pattern had to be applied twice, the Content Writer is not
   learning from feed-forward and the pattern needs to become an opening
   hard constraint on the next chapter.
3. **Batch-wide breach of existing HARD CONSTRAINTS** → If a pattern
   already in HARD CONSTRAINTS appeared in the batch, log it as a breach
   (see `prose-humaniser.md` Breach Reporting). Breach logs prefix the
   pattern's Rule field with "⚠ REPEATED BREACH — {N} breaches".

### Channel B — Batch-level corrections (advisory, one-batch lifespan)

Corrections that don't fit the pattern-ban shape feed forward as advisory
notes for the NEXT batch only. These do NOT land in the running banlist.

1. **Argument trajectory issues** → If the argument is stalling or
   repeating, flag in the next Architect brief: "Previous batch had
   {issue}. The next batch must advance the thesis by {specific beat}."
2. **Evidence distribution skew** → If one source dominated, require the
   next batch's Architect brief to diversify source deployment.
3. **Voice drift** → Add to the next Content Writer prompt: "Voice audit
   detected drift from the Authority Profile on {specific markers}.
   Re-anchor to profile Section 3."
4. **Word count trend** → If batch average < 95%, next batch's Architect
   briefs must include expanded dramatization / evidence-deployment notes.

### Why two channels

Channel A is permanent and dominates the next chapter's Writer prompt
opening — used for patterns the Content Writer must NEVER produce again
(zero tolerance). Channel B is advisory and lives one batch — used for
corrections relative to batch conditions that don't make sense as
standing rules.

**Production rule:** if a surgical pattern needs to be fixed in 2+
consecutive chapters, it is NOT a Channel B advisory — it is a Channel A
hard constraint. The recurring fix burden IS the promotion signal. See
`prose-humaniser.md` Promotion Protocol for the full rules.
