---
name: education-category
description: "Category-specific instructions for education and teaching non-fiction"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Education / Teaching. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | education |
| Display Name | Education / Teaching |
| Parent Group | Education & Teaching (and Politics & Social Sciences > Education Policy where the book is policy-focused) |
| Typical Word Count | 50,000–90,000 (practitioner / classroom-method books often 50,000–70,000; education-policy and reform titles 70,000–110,000; comprehensive learning-science treatments 80,000–120,000) |
| Default Structure | Varies by mode — practitioner / method books typically use principle → classroom example → implementable technique rhythm; policy / reform titles use argument-driven structure (political-commentary template); learning-science books typically use research-finding → classroom-application rhythm. The unifying pattern is observed-classroom-reality before pedagogical-framework abstraction; the book earns authority through grounded specificity |
| Citation Style | Endnotes mandatory; named-researcher and institution attribution for empirical claims ("In a 2018 study at the University of Edinburgh, researchers found..."); peer-reviewed sources prioritised; meta-analyses preferred over single studies for major claims; classroom anecdotes anonymised per student-privacy standards; named educator-practitioners credited for techniques and approaches |
| Audience Baseline | Educator-reader as primary audience for practitioner / method / classroom-management books — varies from new teacher to experienced lead-teacher / department-head / administrator depending on title; policy-engaged reader for reform / policy titles; education-curious general reader for learning-science crossover; audience named so reader self-selects |
| Comparable Titles | Doug Lemov (*Teach Like a Champion*), Daniel Willingham (*Why Don't Students Like School?*, *When Can You Trust the Experts?*), John Hattie (*Visible Learning*), Diane Ravitch (*The Death and Life of the Great American School System*), Linda Darling-Hammond (*The Flat World and Education*), Paul Tough (*How Children Succeed*, *The Years That Matter Most*), Lisa Delpit (*Other People's Children*), Gloria Ladson-Billings (*The Dreamkeepers*), Eve Ewing (*Ghosts in the Schoolyard*), Natalie Wexler (*The Knowledge Gap*), E.D. Hirsch (*Cultural Literacy*, *The Schools We Need*), Pasi Sahlberg (*Finnish Lessons*), Anya Kamenetz (*The Stolen Year*, *The Test*), Andrew Delbanco (*College*), William Deresiewicz (*Excellent Sheep*), Daniel Coyle (*The Talent Code*), Peter Brown / Henry Roediger / Mark McDaniel (*Make It Stick*), John Holt (*How Children Learn*, *How Children Fail*) |

## Subcategory Options

When the user selects Education / Teaching, prompt for subcategory
refinement based on the book's primary mode and audience:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| teaching-methods-pedagogy | Teaching Methods & Pedagogy | Specific teaching techniques, classroom approaches, instructional practice; the Lemov / Bennett / Wexler / Pondiscio / specific-method-advocacy lineage; written for practising teachers | Technique-by-technique chapter spine OR thematic cluster of techniques; principle → classroom example → implementable script; named methods attributed (the "Cold Call" technique, retrieval practice, dual coding); subject- and stage-specific examples |
| learning-science-cognitive-psychology | Learning Science / Cognitive Psychology | How people learn — cognitive psychology, neuroscience, evidence-based principles applied to education; the Willingham / Make-It-Stick / Hattie / Coyle lineage | Research-finding → classroom-application rhythm; named researchers and studies cited; replication awareness explicit (the field has substantial replication issues); evidence-strength ranking guidance for readers |
| classroom-management-practical | Classroom Management & Practical Pedagogy | Behaviour management, classroom routines, student engagement, daily-practice questions; close to how-to-guide but written for teaching context | Routine / situation / challenge chapter spine; specific scripts, language, procedures; common-failure-modes troubleshooting; first-week / first-month / first-term pacing for new teachers; subject- and grade-specific calibration |
| education-policy-reform | Education Policy & Reform | Systemic analysis, policy advocacy, school-system reform — the Ravitch / Darling-Hammond / Tough / Sahlberg / Hirsch lineage of education-as-political-subject writing | Argument-driven (political-commentary template); policy-domain or thesis chapter spine; data, case-studies, international comparison; counter-argument engagement; proposals / actionable pathways |
| equity-justice-education | Equity, Justice, and Education | Educational equity — race, class, language, disability — and the systemic dimensions of opportunity / outcome gaps; the Delpit / Ladson-Billings / Ewing / Inoue / Kozol-on-inequality lineage | Structural-pattern chapter spine; data on disparate outcomes + named-community case studies + critical-pedagogy analysis; affected-community voices central; remedies discussed alongside problems; intersection with critical race theory and culturally-relevant-pedagogy traditions |
| higher-education | Higher Education | Universities, colleges, post-secondary teaching and learning, the academy as institution; the Delbanco / Kronman / Deresiewicz / Zaloom / Cathy-Davidson lineage | Higher-ed-specific structural questions (admissions, curriculum, debt, faculty, governance, what-college-is-for); historical and comparative context; institution-as-subject framing; audience often higher-ed-engaged general reader plus academics |
| alternative-education-homeschool | Alternative Education / Homeschool | Education outside conventional school structures — homeschool, unschool, Montessori, Reggio Emilia, Waldorf, charter, alternative-school methods; the Holt / Mackenzie / specific-tradition-advocates lineage | Tradition-fundamentals chapter up front; principles → application progression; comparison with conventional schooling handled honestly; explicit acknowledgement of the legal / structural context for the alternative; family-and-child variation acknowledged |

**Default:** If the user does not specify, prompt for the book's mode
(practitioner-method / learning-science / classroom-management / policy-
reform / equity-justice / higher-ed / alternative-education) and select
accordingly; fallback to `teaching-methods-pedagogy` for unclear cases
(the most-published practitioner-trade mode).

## Structural Architect Instructions
```
STRUCTURE
- Principle-example-technique: state principle, show in classroom, provide implementable technique
- Each chapter addresses a specific teaching challenge or pedagogical concept
- Real classroom scenarios as evidence (anonymised appropriately)
- Ready-to-use materials, scripts, and templates where applicable

FORBIDDEN
- Learning myths perpetuated (learning styles, left-brain/right-brain)
- Pedagogy without classroom evidence
- One-size-fits-all claims (acknowledge different contexts)
- Student identification in anecdotes without anonymisation
```

## Content Writer Craft Rules
```
VOICE & TONE
- Practitioner-to-practitioner: collegial, practical, encouraging
- "I tried this and here's what happened" narrative authority
- Specific enough to implement, conceptual enough to adapt
```

### Prose Rhythm Mapping

Chapter 1 opens with the student, the teacher, or the moment that illuminates
the thesis. A specific classroom. A specific day. The reader sees a real scene
before encountering any pedagogical framework. Education writing earns its
authority through observed reality, not credential.

Medium sentences (15-22 words) carry the narrative and the analysis. This is
prose that respects both the complexity of teaching and the reader's time.
Avoid the twin traps of academic density and patronising simplicity. Write
as one practitioner to another. collegial, grounded, precise.

Evidence arrives through story. Not "research shows that retrieval practice
improves retention" but "Ms. Okafor's third-period class spent the first
five minutes writing everything they remembered from yesterday." The study
can follow. The scene comes first. Always the scene first.

Accessible authority is the tonal target. The writer has expertise but wears
it lightly. No lecturing. No jargon without immediate translation. The reader
should feel like a colleague is sharing hard-won insight over coffee, not like
a professor is delivering a keynote.

Tension minimum: 4. The tension in education writing comes from the gap between
what we know works and what actually happens in classrooms. Chapter 1 must
make that gap vivid. through a moment where teaching succeeded against odds,
or where a system failed a student it should have served.

Pacing guideline: open with the scene (medium sentences, 15-22 words). Let
the moment breathe for two to three paragraphs. Then name the principle it
illustrates. Build outward from the particular to the general, never the reverse.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Pedagogical claims sourced and current | Empirical claims about how people learn / what works in classrooms trace to peer-reviewed educational research; meta-analyses and replicated findings preferred over single studies; popular-press summaries verified against primary research; "research shows" without citation unacceptable |
| 2 | Replication awareness explicit | The educational-research field has substantial replication challenges; high-profile findings that have failed replication or had effect sizes substantially reduced (learning styles, original growth-mindset effect sizes, multiple intelligences, brain-gym, certain neuro-education claims) are not perpetuated as current science; where the book engages with such findings, current state of evidence is presented |
| 3 | Distinguishes empirical claim from method advocacy | "This technique has been shown effective in [X studies]" (empirical claim, sourced) is distinct from "I find this technique works in my classroom" (practitioner observation) is distinct from "All teachers should adopt this approach" (advocacy). Conflating the registers — particularly presenting advocacy as if it were empirical claim — is the genre's most common analytical failure |
| 4 | Practitioner voices central | For practitioner / method / classroom-management books, voices and experiences of educators are inputs alongside the author's; named-educator examples (with consent), real-classroom anecdotes (with student-privacy protections), practitioner perspectives on what does and doesn't work; books written entirely from outside the classroom on classroom practice are weakened by the gap |
| 5 | Equity considerations engaged | Where the book makes claims about teaching, learning, schools, or outcomes, the structural dimensions (race, class, language, disability, prior-preparation, family circumstance, school-resource disparity) are acknowledged where relevant; "this works for all students" claims interrogated against the variation; "achievement gap" framings handled with awareness of their critique |
| 6 | Age, stage, and subject specificity | Methods, claims, and prescriptions calibrated to the developmental stage and subject domain they apply to; early-years methods do not transfer cleanly to secondary; secondary methods do not transfer cleanly to primary; reading instruction differs from mathematics differs from history; the book is honest about its scope |
| 7 | Student privacy respected | Real students mentioned in classroom anecdotes anonymised effectively (changed name, sufficient detail-changes that the student is not identifiable to anyone who knows them); consent considerations for any identified students; particular care for students discussed in challenging or disclosed contexts (struggling students, students with diagnosed conditions, students in family circumstances) |
| 8 | Educator dignity preserved | Where the book critiques practice, profession, or system, the critique engages with the constraints educators actually work within (class size, resourcing, mandate, parent / community pressure, training, time); "blame the teacher" framings for systemic failures avoided; "teacher hero" framings that ignore systemic factors avoided |
| 9 | Policy / political dimension acknowledged where relevant | Where the book's claims touch contested education policy (school choice, testing, teacher evaluation, charter / public, curriculum debates, integration / segregation, funding), the political dimension is acknowledged rather than treated as settled or apolitical; the book's own policy position is visible to the reader |
| 10 | Implementable specificity | Where the book recommends practice, the practice is specified concretely enough that an educator could actually try it on Monday morning — exact scripts, specific procedures, materials needed, time estimates, common-failure modes; vague "be more X" / "create a culture of Y" exhortation without specifics fails the practitioner reader |

## Source Requirements

### Mandatory Source Types

- **Peer-reviewed educational research.** Empirical claims about
  learning, teaching, and student outcomes trace to peer-reviewed
  research in education, cognitive psychology, developmental
  psychology, sociology of education, or relevant subject-pedagogy
  fields. Named journals (*American Educational Research Journal*,
  *Educational Researcher*, *Review of Educational Research*,
  *Journal of Educational Psychology*, *Reading Research Quarterly*,
  *Mathematics Education Research Journal*, etc.); named scholars
  and institutions cited.
- **Meta-analyses and systematic reviews.** For major claims about
  what works in education, meta-analyses (Hattie's syntheses, the
  EEF Toolkit in the UK, the Best Evidence Encyclopedia, IES
  Practice Guides in the US) preferred over single studies.
  Effect sizes reported with appropriate caveats; small effect
  sizes not presented as transformative.
- **Educator-practitioner voices.** For practitioner / method /
  classroom-management books, voices and experiences of educators
  are inputs alongside the author's; named-educator examples
  (with consent and credit), descriptions of practice from
  practitioners-in-the-field, peer-practitioner endorsements
  where relevant.
- **Authoritative practice frameworks.** Where the book engages
  with established frameworks (universal design for learning,
  multi-tiered systems of support, response to intervention,
  cognitive load theory, Rosenshine's principles of instruction,
  Bloom's taxonomy and its revisions), frameworks are attributed
  to their developers and engaged with rather than appropriated
  silently.
- **Government and institutional data.** For policy and outcomes
  claims — Department of Education / DfE / equivalent national
  bodies; OECD PISA / TIMSS / PIRLS data; NAEP in the US;
  national / state / local assessment data; school-funding /
  staffing / outcome statistics; longitudinal study data
  (ECLS in the US; Millennium Cohort in UK; etc.).
- **Voices from communities affected by educational policy /
  practice.** For equity / justice / outcomes-gap content,
  voices from inside affected communities (students, families,
  community organisations, scholars from the community) are
  inputs alongside outside-scholar analysis.

### Source Freshness — Educational Research Has Specific Replication Issues

Education is one of the social-science fields with the most documented
replication challenges. The book engages with this honestly:

- **Notable findings that have failed replication or had effect
  sizes substantially reduced:**
  - **Learning styles** (visual / auditory / kinesthetic
    preference matched to instruction) — never reliably
    replicated; consensus among learning scientists is that
    learning styles in the popular sense are myth.
  - **Growth mindset** (Dweck) — replications show much smaller
    effect sizes than original work; current evidence supports
    a smaller real effect particularly for low-achieving
    students rather than the universal transformative effect
    popularised.
  - **Multiple intelligences** (Gardner) — useful as a frame
    for valuing different cognitive strengths; weak as an
    empirical claim about distinct, separable intelligences.
  - **Brain Gym, certain neuro-education claims, "right-brain
    / left-brain" learning** — debunked; not consistent with
    current neuroscience.
  - **Hattie's "visible learning" effect sizes** — methodologically
    contested by researchers including Pierre-Jérôme Bergeron
    and others; the book engages with the contestation rather
    than treating Hattie's rankings as settled.
  - **The 21st-century-skills framing** — useful at high level,
    weakly supported as empirical claim about specific
    transferable skills.
  - **Specific intervention claims with weak evidence** — IB
    programmes' broad claims, certain SEL programme claims at
    scale, certain charter-school replication claims.
- The book that perpetuates these as current science when current
  evidence is contested or negative fails the educator audience,
  who are increasingly research-literate and recognise the
  failures.

- **Education-policy currency:**
  - Policy landscapes shift with political cycles; books on US
    education policy written before 2020 may be substantially
    out of date on accountability, federal-state dynamics, charter-
    school growth patterns, post-pandemic learning loss.
  - Common Core / curriculum debates / standardised-testing
    debates have evolved substantially; current state matters.
  - Post-COVID-era learning loss, the "science of reading"
    movement, AI in education are current shaping forces;
    pre-2020 framings often miss them.

- **Equity-discourse currency:**
  - The language and frameworks of educational equity have
    evolved (achievement gap → opportunity gap → opportunity-
    debt framings; multicultural education → culturally relevant
    pedagogy → culturally sustaining pedagogy → abolitionist
    teaching trajectories); books engage with current state.

- **Foundational works hold up better.** Holt's *How Children
  Learn / Fail*, Hirsch's foundational work on cultural
  literacy, Delpit's *Other People's Children*, Kozol's
  inequality reporting — these remain foundational because the
  observations and structural arguments outlast the era's
  specific data.

### Attribution Standards

- **Empirical claims sourced.** "Studies show..." / "research
  indicates..." / "evidence suggests..." unacceptable without
  citation; "A 2019 meta-analysis by [researcher / institution]
  in [journal]..." is the standard. Reader trust in education
  writing depends on this — educator readers especially can
  tell when claims rest on weak or no evidence.
- **Distinguish: study finding / pedagogical method / popular
  framing.** "Retrieval practice has been shown across multiple
  studies to improve long-term retention" (study finding,
  sourced). "The 'Cold Call' technique developed by Doug Lemov..."
  (named pedagogical method, attributed). "Many teachers
  describe this as 'building thinking classrooms'..." (popular
  framing in the practitioner community, named as such). Each
  register has different evidentiary standards.
- **Borrowed methods credited.** Where the book draws on named
  pedagogical methods (UDL, RTI, MTSS, Rosenshine's principles,
  cognitive load theory, retrieval practice, dual coding,
  spaced practice, interleaving), methods are attributed to
  developers and primary scholarship cited; silent borrowing
  erodes credibility.
- **Practitioner anonymity vs. acknowledgement.** Where named
  educators have shared classroom practice, named with consent
  and contribution credited (typically in acknowledgements
  and at point of citation in the relevant chapter); where
  educators or schools are described in challenging
  contexts, anonymisation effective enough to protect the
  educator / institution from identification.
- **What is NOT acceptable.** Citing failed-replication
  findings as current science. Treating popular-press
  summaries of education research as primary evidence.
  Presenting personal classroom experience or single-school
  case studies as if they generalise. Failing to cite primary
  scholarship for borrowed methods. Distorting research
  findings to support pedagogical advocacy. Identifying
  students or educators in ways that make them recognisable
  to those who know them, without consent.

## Category-Specific Guardrails

### MANDATORY. Educational-Research Evidentiary Standards

- Education writing is read by an audience that is increasingly
  research-literate; teachers, school leaders, and policy
  makers can identify when claims rest on weak or contested
  evidence. The category's evidentiary standards are
  correspondingly demanding:
  - **Effect-size and confidence-interval awareness.** Where
    the book reports research findings, effect sizes are
    reported with appropriate caveats; small effect sizes
    (Cohen's d < 0.4) are not presented as transformative;
    confidence intervals and replication status disclosed
    where they shape interpretation.
  - **Distinguish well-replicated from preliminary findings.**
    Cognitive-psychology findings with strong replication
    (spacing effect, retrieval practice, interleaving for
    related material) presented as such; preliminary,
    contested, or failed-replication findings (many SEL
    interventions at scale, certain growth-mindset claims,
    learning styles) presented honestly.
  - **Subject-domain specificity.** Reading research differs
    from mathematics research differs from history-pedagogy
    research; the book is honest about which domain its
    claims apply to and where transfer is contested.
  - **Population specificity.** Findings from particular
    student populations (US elementary, UK secondary, urban
    / suburban / rural, specific demographics, English-
    speaking vs multilingual contexts) do not transfer
    automatically; the book is honest about scope.

### MANDATORY. Failed-Replication and Edu-Myth Avoidance

- The category's most-criticised failure is perpetuating
  educational myths and failed-replication findings as if they
  were current science. Specific patterns to avoid:
  - **Learning styles myth.** Visual / auditory / kinesthetic
    preference matched to instruction has not been replicated
    despite decades of attempts; the consensus among learning
    scientists is that learning styles in this sense are
    myth. Books that present them as current science fail.
  - **Growth-mindset over-claiming.** Mindset framing has
    real but modest effects (especially for lower-achieving
    students), substantially smaller than original Dweck-popular-
    press claims and contested in some replications. The
    book that presents universal-transformative-effect claims
    fails the contemporary research literacy standard.
  - **Multiple intelligences as separate cognitive
    capacities.** Useful as a frame for honoring different
    strengths; weak as an empirical claim about distinct
    intelligences in the cognitive-psychology sense.
  - **Brain Gym, "right-brain / left-brain" learning,
    most "neuro-education" claims.** Inconsistent with current
    neuroscience; not perpetuated.
  - **Some popular frameworks with weaker-than-claimed
    evidence.** The 21st-century-skills framing, certain
    grit-as-universal-predictor claims, some specific SEL
    programme effects-at-scale, "21st-century learner" /
    "digital native" framings.
- Where the book engages with these — even to disagree —
  current state of the evidence is presented; the book does
  not perpetuate the popular framing while gesturing at the
  research as if to balance it.

### MANDATORY. Practitioner-Voice Centrality and Educator Dignity

- Education writing about teaching practice without educator
  voices, written from outside the classroom, has limited
  authority with the educator audience. Specific requirements:
  - **Educator voices included.** For practitioner / method /
    classroom-management books, real teachers' experiences,
    examples, perspectives are inputs alongside the author's;
    named where consented and credited.
  - **Educator dignity preserved.** Where the book critiques
    practice, profession, or system, the critique engages
    with constraints educators actually work within (class
    size, resourcing, mandate, parent / community pressure,
    training time, working conditions, pay).
  - **"Blame the teacher" framings avoided.** Systemic
    failures (under-resourced schools, weak training pipelines,
    impossible workloads, accountability-pressure regimes,
    inadequate special-education support) are not laid at
    individual teachers' feet.
  - **"Teacher hero" framings calibrated.** Stories of
    individual teachers achieving exceptional outcomes are
    legitimate; framings that imply the system would work
    if everyone tried harder, while ignoring the structural
    factors that make extraordinary effort necessary, are
    misleading.
  - **No "what's wrong with teachers today" framings** that
    pathologise an entire profession; nuanced engagement
    with how practice is and could be different.

### MANDATORY. Equity Considerations (achievement-gap framing and beyond)

- Where the book makes claims about teaching, learning,
  outcomes, or schools, structural dimensions are
  acknowledged where relevant:
  - **Race, class, language, disability dimensions.**
    Educational outcomes are shaped by race, class, language
    background, disability status, immigration status,
    geographic context, school resourcing, prior preparation.
    Books that ignore these structural shapings while making
    claims about teaching effectiveness mislead.
  - **"Achievement gap" framings used with awareness.** The
    "achievement gap" framing has been critiqued for placing
    the gap problem at the level of student outcomes rather
    than at the level of opportunity / resourcing / structural
    inequity that produces those outcomes ("opportunity gap"
    or "education debt" framings, per Ladson-Billings, are
    increasingly preferred). The book uses framing
    deliberately, with awareness of the critique.
  - **Multilingual learner inclusion.** English-language-
    learner / multilingual-learner population is large and
    growing; pedagogical recommendations honest about how
    they apply (or do not) to multilingual contexts;
    monolingual-default framings flagged.
  - **Disability / SEN inclusion.** Methods and recommendations
    consider students with disabilities, identified special
    educational needs, and the full range of neurodivergent
    learners; "all students benefit from..." claims
    interrogated against this variation.
  - **Cultural-context honesty.** Methods that work in
    high-resource / monolingual / high-trust contexts may
    not transfer to low-resource / multilingual / structurally-
    challenged contexts; the book is honest about scope.

### MANDATORY. Policy-Politics Awareness (the field is contested)

- Education touches deeply contested policy questions; books
  that pretend to apolitical pedagogical-neutrality where
  they are actually taking policy positions mislead:
  - **School-choice debates** (charter / private / public /
    voucher) — engaged with rather than ignored where the
    book's claims touch them; the book's own position
    visible.
  - **Standardised testing debates** — accountability,
    high-stakes-testing, opt-out movements; the book's
    position on testing's role visible.
  - **Curriculum debates** (Common Core in US; national
    curriculum in UK; "science of reading" vs balanced-
    literacy; explicit-instruction vs constructivism) —
    where the book takes a side, the side is visible and
    its evidence base examined; "everyone knows" framings
    avoided.
  - **Teacher-evaluation and professionalisation debates** —
    value-added measurement, teacher-prep pipelines,
    alternative certification.
  - **Integration / segregation / equity remediation
    debates** — the structural questions about who attends
    school with whom and how that shapes opportunity.
  - **Critical race theory / culturally responsive education
    debates** — politically charged in some jurisdictions;
    the book engages substantively rather than performatively.
- The book's own policy position visible; "the research
  shows we should..." framing where the research is contested
  is intellectually dishonest.

### MANDATORY. Age, Stage, and Subject Specificity

- Education writing's most common scope error is
  generalisation across stages and subjects where methods do
  not transfer:
  - **Early-years (0–5) methods do not transfer cleanly to
    primary; primary methods do not transfer cleanly to
    secondary; secondary methods do not transfer cleanly to
    higher-ed.** Each stage has its own developmental
    appropriateness, evidence base, and constraints.
  - **Subject-specific pedagogy.** Reading instruction,
    mathematics instruction, writing instruction, science
    inquiry, history, arts, and physical education each
    have their own pedagogical traditions and evidence
    bases; cross-subject generalisation often fails.
  - **The book is honest about scope.** Title, subtitle, and
    introduction make clear which stage(s) and subject(s)
    the book applies to; "for all teachers" claims are
    typically over-claims unless the book genuinely covers
    universal principles.

### MANDATORY. Student Privacy and Dignity

- Where the book includes classroom anecdotes, real students
  are protected:
  - **Anonymisation effective.** Changed names plus
    sufficient detail-changes that the student is not
    identifiable to anyone who knows them; particular care
    for unique cases (the only ELL in the school, the
    student with the disclosed condition, etc.).
  - **Consent for identifiable students.** Where students
    are discussed in identifiable contexts (with parental
    consent for younger students), the consent is real and
    documented.
  - **Sensitive contexts handled with care.** Students
    discussed in challenging contexts (struggling, with
    diagnosed conditions, in difficult family
    circumstances) treated with extra anonymisation
    standards and dignity.
  - **No deficit-framing of named or anonymised students.**
    Specific students are not used as illustrations of
    pathology; methods are illustrated through what worked
    rather than through what was wrong with the student.

### Additional Guardrails

- **Implementable specificity.** Recommendations specific
  enough to try Monday morning — exact scripts, specific
  procedures, materials, time estimates, common-failure
  modes, what success looks like. Vague "be more X" /
  "create a culture of Y" exhortation without specifics
  fails the practitioner reader.
- **Subject-and-stage-appropriate examples.** Examples
  drawn from contexts the book applies to; mismatch
  between claimed scope (e.g. "for K-12 teachers") and
  actual examples (e.g. only secondary classroom anecdotes)
  weakens the work.
- **The "what works" / "evidence-based practice" framing
  used with humility.** Education research has substantial
  uncertainty; "evidence-based" claims are honest about
  the strength and scope of evidence rather than over-
  claiming consensus.
- **Educator-as-author positionality disclosed.** The
  author's own teaching experience (years, levels, subjects,
  contexts) and current role (classroom teacher, leader,
  consultant, academic, advocate, journalist) shapes the
  work and is disclosed.
- **Reform-and-change framings honest about implementation.**
  Recommendations for systemic change are honest about
  the political and resource constraints implementation
  faces; "schools should just..." framings that ignore
  the political economy of schooling lose credibility with
  educator readers.
- **Currency disclosure.** Education-policy claims, specific-
  intervention-effect claims, technology-in-education claims
  date faster than principle-level claims; the book is
  honest about the moment of writing.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Warm and approachable for practitioner /
  classroom-method books (sage, sky blue, warm yellow / cream,
  terracotta, soft red — palettes that signal accessibility to
  the educator audience). Restrained / institutional palettes
  (charcoal, navy, deep green, white-with-accent) for policy /
  reform titles where authority over warmth is the cue. Bolder
  palettes for equity / justice titles where the cover should
  signal the political weight of the argument. Avoid the
  saturated commercial-self-help palette — educator readers
  recognise commercial-non-fiction styling as a mismatch with
  serious education writing.
- **Typography:** Friendly serif (Garamond, Adobe Caslon, Bembo,
  Mrs Eaves) for practitioner / method books — typography
  signals considered prose and respect for the educator
  audience. Substantial sans-serif (Avenir, Sofia Pro, Calibre)
  for policy / reform / contemporary positioning. Display fonts
  for personality-led titles (some method-advocate authors with
  strong public profiles). Book-design literacy is itself a
  signal to educator readers about whether the book takes
  itself seriously as a text-for-the-profession.
- **Imagery:** Three dominant traditions:
  1. **Classroom / educator imagery** — students in classrooms
     (calibrated to honour subjects, avoid stereotyping,
     show diverse contexts), teachers in working moments,
     classroom-context still life. The most common form for
     practitioner / method books. Calibrate to avoid the
     stock-classroom-photo cliché (teacher pointing at
     blackboard while diverse smiling students raise hands)
     that signals lifestyle-NF rather than serious work.
  2. **Symbolic / iconographic** — a chair, a desk, a
     book, a notebook, an apple, a piece of chalk, a
     specific subject's icon (a microscope for science
     ed, a globe for social studies, etc.); restrained,
     considered, allusive. Strong for policy / reform /
     equity / higher-ed titles where the cover argues
     rather than illustrates.
  3. **Pure typography** — title and author name, often
     with substantial white space; common for established
     author-brands (Lemov, Willingham, Ravitch, Hattie)
     and for books where the title's claim is the draw.
- **Mood:** Considered respect for the profession. The cover
  should signal "this book takes education and educators
  seriously" — not "edutainment" / "lifestyle teacher" register,
  not "reform-movement-pamphlet" register. The educator reader
  in the bookstore is tired, busy, and overstretched; the cover
  that respects their time and intelligence wins.

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Teaching Methods & Pedagogy | Classroom-context imagery (calibrated to avoid clichés) OR symbolic / iconographic; warm palette; serif typography signals practitioner-friendly literary positioning; subtitle clarifies the method or focus ("Strategies for...", "Classroom-tested techniques for...") |
| Learning Science / Cognitive Psychology | Often pure typography or restrained iconographic (a brain motif, a graph, a textbook spine); cleaner sans-serif palette; subtitle clarifies the cognitive-science angle ("How students learn...", "The science of...") |
| Classroom Management & Practical | Classroom-routines imagery (a desk arrangement, a daily-schedule fragment, a wall display) OR pure typography; warmer palette; subtitle establishes the level / focus ("Strategies for the elementary classroom", "First-year teacher essentials") |
| Education Policy & Reform | Pure typography or institutional imagery (a school building, a graduation, a contested-reform symbol); restrained palette; substantial typography; subtitle clarifies the policy thesis ("How [system] [does X]", "Why [Y] matters", "What [education] needs") |
| Equity, Justice, and Education | Often pure typography or photographic imagery centring affected communities (calibrated to honour rather than pity); palette can be bolder (single saturated colour) signalling argument's weight; subtitle establishes the equity argument ("Race / class / language / disability and the [school system]") |
| Higher Education | Pure typography or institutional imagery (a campus, a library, a lecture hall); restrained palette signalling academic seriousness; serif typography; subtitle establishes the higher-ed-specific question ("What [college] [does / should do]", "The future of [the academy]") |
| Alternative Education / Homeschool | Warmer / more domestic imagery (kitchen-table, outdoor learning, family-context); softer palette; warmer typography; subtitle clarifies the alternative tradition ("A guide to...", "The essentials of [Montessori / homeschool / unschooling]") |

### Typography Rules

- **Title:** 30–55% of cover area. Education titles work as
  declarative ("Visible Learning", "Why Don't Students Like
  School?", "Teach Like a Champion", "The Knowledge Gap"),
  question ("Who's Afraid of the Big Bad Dragon?"), or
  evocative ("Ghosts in the Schoolyard"). The title must
  read at thumbnail and signal the book's mode and
  audience.
- **Subtitle:** Often essential — does the descriptive
  positioning work. Subtitles in practitioner / method books
  typically establish what the book teaches and to whom
  ("[N] Techniques for Putting Students on the Path to
  College" — Lemov *Teach Like a Champion*); policy /
  reform subtitles establish the argument's scope ("How
  [system] [fails / could be remade]"); equity subtitles
  establish the structural argument's frame.
- **Author name:** Larger for established education-author
  brands (Lemov, Willingham, Ravitch, Hirsch, Ladson-Billings,
  Hattie, Tough); smaller for unestablished authors with
  credentials in subtitle ("by a 20-year teacher", "by a
  professor of education at...", "by a former assistant
  secretary of education"). Author qualification cues
  (classroom experience years, leadership positions,
  research affiliations) shape this category's reader trust
  because educator readers calibrate by author authority
  within the field.
- **Series mark and edition:** Education-publishing imprints
  (Jossey-Bass, ASCD Press, Heinemann, Stenhouse, Corwin,
  Routledge education imprints, Harvard Education Press,
  Beacon, Teachers College Press) signal positioning to
  educator readers; new-edition marking essential where
  research has updated or methods have evolved.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Teaching Methods & Pedagogy | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Instruction Methods (with > Curriculum & Lesson Plans for curriculum-anchored books) |
| Learning Science / Cognitive Psychology | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Education Theory (with Health, Fitness & Dieting > Mental Health > Cognitive Psychology as secondary for crossover) |
| Classroom Management & Practical | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Classroom Management |
| Education Policy & Reform | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Education Theory (with Politics & Social Sciences > Politics & Government > Specific Topics > Education Policy as secondary) |
| Equity, Justice, and Education | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Education Theory (with Politics & Social Sciences > Social Sciences > Discrimination & Race Relations or > Specific Topics > Civil Rights as secondary per the equity focus) |
| Higher Education | Kindle Store > Kindle eBooks > Education & Teaching > Higher & Continuing Education > [Adult & Continuing Education / Schools / Teaching] |
| Alternative Education / Homeschool | Kindle Store > Kindle eBooks > Education & Teaching > Homeschooling (with > Schools & Teaching > Specific Skills for skill-focused alternatives) |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| Specific subject pedagogy | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Curriculum & Lesson Plans > [Reading & Phonics / Mathematics / Science & Technology / Social Studies / Arts & Music] |
| Specific level | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > [Early Childhood / Elementary / Middle School / High School / Higher Education] |
| Educator development / professional learning | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Funding (or > Schools & Teaching > Educational Reference > Professional Development) |
| Special education | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Special Education > [Specific Sub] |
| Educational psychology | Kindle Store > Kindle eBooks > Education & Teaching > Schools & Teaching > Counseling (or > Educational Psychology) |
| Tutoring / supplemental instruction | Kindle Store > Kindle eBooks > Education & Teaching > Test Preparation (for testing-focused) or > Reference > Words, Language & Grammar (for language) |
| Parent-as-educator | Kindle Store > Kindle eBooks > Parenting & Relationships > Parenting (for parent-audience books crossing into education) |
| Memoir of teaching | Kindle Store > Kindle eBooks > Biographies & Memoirs > Specific Groups > Educators |

### Keyword Recommendations

- The pedagogical method or framework
  ("retrieval practice", "spaced learning", "explicit
  instruction", "Rosenshine's principles", "cognitive load
  theory", "universal design for learning", "culturally
  responsive teaching", "differentiated instruction",
  "project-based learning")
- The educator audience cue
  ("for new teachers", "for experienced teachers", "for
  school leaders", "for elementary teachers", "for middle
  school", "for high school", "K-12", "for teacher
  educators")
- The subject area where applicable
  ("teaching reading", "math instruction", "science
  pedagogy", "writing instruction", "history teaching",
  "ESL / multilingual learners", "special education")
- The level
  ("early childhood education", "elementary teaching",
  "middle school", "secondary teaching", "higher
  education", "college teaching")
- The policy / system focus
  ("education policy", "school reform", "education
  inequality", "achievement gap", "opportunity gap",
  "school funding", "teacher quality", "education
  research")
- Comparable author / brand for discoverability
  (readers of Doug Lemov, readers of Daniel Willingham,
  readers of Diane Ravitch, readers of Lisa Delpit,
  readers of Paul Tough, readers of John Holt)
- Specific framework / movement
  ("the science of reading", "PYP / IB", "Reggio Emilia",
  "Montessori", "Waldorf", "competency-based education",
  "no excuses charters", "anti-racist teaching")
- Avoid generic "education" / "teaching" / "school" in
  isolation — they drown in algorithmic noise; prefer
  compound phrases combining method + level + audience
- Avoid trend-chasing keywords from failed-replication
  research ("learning styles", "left-brain right-brain",
  "multiple intelligences" used as if science) — they
  signal mis-positioning to the research-literate educator
  audience
- Avoid commercial-self-help framings ("transform your
  classroom", "secrets of great teachers", "the [N]
  habits of highly effective teachers") — they signal
  edutainment positioning that damages credibility with
  serious educator readers
