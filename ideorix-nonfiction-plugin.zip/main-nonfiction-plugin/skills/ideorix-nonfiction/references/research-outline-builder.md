---
name: research-outline-builder
description: "Non-fiction outline builder — delegates to Market Scout + Structural Architect"
---

# Research Outline Builder

The non-fiction outline builder is not a separate agent — it is the combined output of two existing agents:

- **Market Scout** (`market-scout.md`) — supplies live market demand, comp titles, positioning
- **Structural Architect** (`structural-architect.md`) — builds the category-appropriate outline structure

When a reference points to `research-outline-builder.md`, it means: run Market Scout, then feed its output into the Structural Architect for outline construction.

For the full outline-building flow, see `core-pipeline.md` Phase 2.
