---
name: validate-dispatcher
description: "Engine-neutral feature spec. The /validate command dispatcher routes validation requests through the canon-validation-taxonomy 10-domain index, invokes per-domain audits (Class A bash scripts; Class B subagent-dispatched specs), collects PASS/FAIL/WARN/SKIP findings, and emits a structured Validation Briefing. Read-only on project state outside of producer-state-protocol auto-repair. See the Roadmap section below for version history."
version: "2.7.39"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# /validate — Canon Validation Dispatcher

A user-invocable orchestrator that runs every domain check the
canon-validation-taxonomy indexes and emits a structured report.
v2.7.27 ships full-validation only — `/validate <book>` checks
all 10 domains. v2.7.28 adds the level argument and per-level
domain subsetting; v2.7.29-v2.7.33 close the five domain gaps
the taxonomy currently lists as UNAUDITED.

## Why this exists

The taxonomy (`canon-validation-taxonomy.md`, v2.7.26) lists
every audit / gate / verification protocol the engine ships,
indexed by the 10 quality domains. Without a dispatcher, a user
asking "is this manuscript passing every domain?" must know to
invoke ten different protocols and assemble the results
themselves. The dispatcher collapses that to one command.

The dispatcher is **not** a new audit — every check it invokes
already exists. Its value is:

- **Aggregation**: one call, ten domain reports, collected into
  one Validation Briefing.
- **Coverage transparency**: domains currently UNAUDITED are
  explicitly named in the report (rather than silently skipped).
- **State integration**: passing audits are appended to
  `engine-data/pipeline-checkpoint.md` `## Audits Passed` via
  the producer-state-protocol auto-repair path.
- **Routing legibility**: the user, the engine, and the
  Director Agent share one organising vocabulary (the 10
  domains) for talking about quality.

## Invocation contract

Trigger phrases registered in SKILL.md:

- `/validate <book>` — slash form, full validation
- `/validate <book> <level>` — slash form, level-scoped (v2.7.28)
- `/validate <book> <level> <chapter>` — slash form, level + chapter (v2.7.28)
- `validate <book> [level] [chapter]` — alias without slash
- "Validate my book" / "Validate <book>"
- "Validate <book> at <level>" / "Run <level> validation on <book>"
- "Validate chapter N of <book>" (resolves to level=prose, chapter=N)
- "Run validation" / "Run the 10-domain check"
- "Check every domain" (resolves to level=full)

The `<book>` argument is the project folder name (the
directory under `~/Documents/Ideorix-Projects/`). If absent or
ambiguous, the dispatcher invokes `ask-user-disambiguation.md`
discipline before proceeding.

The `<level>` argument is one of:

- `architecture` — pre-brief, post-bible (Phase 2 complete,
  Phase 3 step 5 not yet started)
- `brief` — post-brief, pre-write (per-chapter Architect output
  exists; Content Writer has not yet run)
- `prose` — post-write (per chapter or whole-manuscript prose
  exists; runs prose-quality domains)
- `full` — every domain checked; default when level is omitted

The `<chapter>` argument is the chapter number (1-indexed). It
applies only to `prose` level; supplying it at `architecture` or
`brief` level emits a soft warning and runs the level over its
natural scope (the whole project / the whole brief set).

When level is omitted entirely, the dispatcher defaults to
`full`. v2.7.27 behaviour (full-only) is preserved for users
who continue to invoke `/validate <book>` without a level.

## Validation levels (v2.7.28)

Each level invokes a documented subset of the 10 domains. The
mapping is canonical — taxonomy cross-references (`canon-
validation-taxonomy.md` § Validation levels) and the bash
orchestrator (`scripts/validate-dispatcher.sh`) both honour the
same per-level domain set, so user-facing scope and machine-
side dispatch agree.

| Level | Domains invoked |
|---|---|
| **architecture** | LOGIC, CONSISTENCY, COHERENCE, PHYSICS, CHARACTER, GENRE |
| **brief** | CONSISTENCY, PHYSICS, COHERENCE, GENRE |
| **prose** | CONSISTENCY, PHYSICS, ECONOMY, INTENT PRESERVATION, AI-ISM DETECTION, SHOW NOT TELL, CHARACTER (voice + humanity-gate per-chapter re-check) |
| **full** | All 10 domains |
| **delta** (v2.7.61) | COHERENCE, PHYSICS (Class B delta variants only — leitmotif-tracker-delta + injury-accumulation-delta). Per-chapter scope; requires the chapter arg. Class A audits not run at this level (covered by Rule 1's verification suite). See `leitmotif-tracker-delta.md` and `injury-accumulation-delta.md` for audit specs and `mandatory-pipeline-rules.md` Rule 1b for the dispatch protocol. |

The level → domain mapping rationale:

- **architecture** runs at the Story Bible / Research Bible
  approval gate (Phase 2D-2F + Phase 2G for NF). Domains that
  apply at the structural-document level: foundation logic, bible-
  vs-setup consistency, structural coherence (outline tension,
  antagonist plan), structural physics (timeline, ticking-clock
  setup), character (humanity-gate from bible profiles), and full
  genre conformance. ECONOMY / INTENT PRESERVATION / AI-ISM /
  SHOW-NOT-TELL apply to prose, not bibles, and are deferred to
  the prose level.
- **brief** runs at Phase 3 step 5a (per-chapter brief written;
  Content Writer not yet invoked). Domains that apply at the
  brief level: cross-brief consistency, physics continuity (the
  brief's planned events fit the timeline + injury ledger),
  coherence (the brief delivers the antagonist pressure / pacing
  the architecture promised), and genre beats (this chapter's
  beat fires correctly). LOGIC has been validated at architecture
  and is not re-run; CHARACTER's humanity gate is project-level
  and not re-run per brief.
- **prose** runs at Phase 3 step 7-12 (chapter written;
  optionally before or after step 12 verification). All seven
  prose-level domains. CHARACTER at this level is voice-
  consistency + humanity-gate per-chapter (does the character
  continue to exhibit the criteria the bible established?), not
  the full bible-level humanity construction.
- **full** is the union — every domain, used pre-submission and
  pre-publication.

When a level is supplied, domains outside that level's set are
**reported as out-of-scope** in the briefing's domain-by-domain
summary (not run, not failed, not warned — explicitly skipped
with the rationale "level={X} does not include this domain").
This preserves the principle that gaps and skips are always
visible to the user.

## The dispatcher protocol

### Step 1: Resolve the project, level, and chapter

Determine the project root from `<book>` argument or active
context. If multiple projects match or context is empty,
invoke `ask-user-disambiguation.md` HARD GATE with the
candidate list. Single-decision, confirmation echo on
ambiguous answers.

Resolve the level. If supplied, validate against
{architecture, brief, prose, full}; if not supplied, default
to `full`. Resolve the chapter argument; valid only at
`prose` level — if supplied at another level, emit a soft
warning and ignore.

Reject level/chapter combinations that don't make sense:

- `architecture` requested but Phase 2 not complete →
  surface "Phase 2 not yet complete; architecture-level
  validation has nothing to check" and stop.
- `brief` requested but no brief files exist under
  `engine-data/chapter-briefs/` → surface "no chapter briefs
  found; run Phase 3 step 5 first" and stop.
- `prose` with chapter N requested but
  `engine-data/chapters/ch{NN}.md` doesn't exist → surface
  "chapter N has not been written yet" and stop.

Verify `engine-data/pipeline-checkpoint.md` exists. If not,
the project has not yet completed Phase 2E. Report:

```
Validation cannot proceed: pipeline-checkpoint.md not found
at engine-data/. Run Phase 2E (Pipeline State Initialization)
or, for new projects, complete Phase 2 (Story Bible /
Research Bible).
```

Then stop.

### Step 2: Reconcile project state

Invoke `producer-state-protocol.md` HARD GATE. Apply the
protocol in full (Read pipeline-checkpoint.md, bash-list
filesystem audit-report evidence, compute the LIST-MISSING /
CLAIM-FABRICATED / CONSISTENT delta, auto-repair LIST-MISSING,
halt on CLAIM-FABRICATED).

If reconciliation halts on DIVERGENCE, the dispatcher's
output is exactly the divergence message from the protocol —
no validation runs until the user resolves. This preserves
the Director Agent's pattern (state correctness is a
prerequisite for any orchestration).

### Step 3: Read the taxonomy mapping

Load `canon-validation-taxonomy.md` (under
`read-verification.md` HARD GATE). Extract the per-domain
audit assignments — every row in every primary-domain table.
Build the dispatch list:

```
domain → [list of audits to invoke]
```

For domains the taxonomy marks UNAUDITED in the gap analysis,
the dispatch list contains zero audits — the report explicitly
names the domain as gapped, with the target release for
closure.

### Step 4: Invoke per-domain audits (filtered by level)

The level (resolved at Step 1) selects a domain subset per
the Validation Levels mapping above. For each domain in
**canonical order** (1 LOGIC → 10 SHOW NOT TELL):

- If the domain is **in-scope for this level**, invoke the
  audits the taxonomy assigns to it. Three invocation
  classes (below).
- If the domain is **out-of-scope** for this level, emit a
  one-line OUT-OF-SCOPE marker in the briefing (no audits
  run; not counted as PASS / FAIL / WARN; explicitly visible
  to the user as a level-scope skip).
- If the domain is **UNAUDITED** in the taxonomy gap analysis,
  emit a UNAUDITED marker with the target release (regardless
  of in-scope status — UNAUDITED is reported even at full
  level so the user always sees the gap roadmap).

When `chapter` is supplied at `prose` level, audits that
accept a chapter file path are invoked with that file;
project-level audits run unscoped. The bash orchestrator
passes the chapter as a fourth argument to scripts that
accept it.

The three invocation classes:

**Class A: Mechanical audit script**

Invoked via bash. Apply `bash-output-verification.md` HARD
GATE — verify exit code, expected-shape output, no silent
empty-result misread.

```bash
# v2.7.27 form (level=full, all domains):
scripts/validate-dispatcher.sh <project_root> all

# v2.7.28 forms — level-scoped:
scripts/validate-dispatcher.sh <project_root> architecture
scripts/validate-dispatcher.sh <project_root> brief
scripts/validate-dispatcher.sh <project_root> prose [chapter]
scripts/validate-dispatcher.sh <project_root> full

# v2.7.28 form — single-domain probe (unchanged from v2.7.27):
scripts/validate-dispatcher.sh <project_root> <DOMAIN_NAME>
```

The orchestrator reads the per-level domain set, iterates the
in-scope domains in canonical order, runs each domain's
mechanical scripts, captures PASS/FAIL/WARN per audit, emits
structured stdout the engine consumes.

**v2.7.29 signature normalisation.** Each existing audit script
has its own argument shape (`<project_root> <chapter_N>`,
`<chapter_file> <project_root>`, `<chapter_file> <forbidden-words-file>`,
plain `<chapter_file>`, etc.). The dispatcher resolves each
script's signature class via the `script_class()` registry in
`scripts/validate-dispatcher.sh` and constructs the call
accordingly. Six classes are documented:

| Class | Shape | Examples |
|---|---|---|
| `PROJECT_ONCE` | `<project_root>` — runs once per dispatcher invocation | market-scout-gate.sh |
| `PROJECT_CHAPTER` | `<project_root> <chapter_N>` — iterates chapters when no chapter supplied | pre-flight-gate.sh, outline-conformance-gate.sh |
| `CHAPTER` | `<chapter_file>` — iterates chapters when no chapter supplied | number-7-bias.sh, word-count-check.sh, pattern-counter.sh, formatting-check.sh, placeholder-scan.sh, typography-sweep.sh |
| `CHAPTER_PROJECT` | `<chapter_file> <project_root>` — iterates | entity-canon-verify.sh, temporal-verify.sh |
| `CHAPTER_FORBIDDEN` | `<chapter_file> <forbidden-words-file>` — resolves forbidden-words location, iterates | forbidden-words-scan.sh |
| `CHAPTERS_DIR` | `<chapters_directory>` — points at engine-data/chapters/ to avoid recursing into reports/validate/ | pending-marker-scan.sh |

When a chapter argument is supplied at `prose` level, the
dispatcher invokes per-chapter classes once with that chapter.
When no chapter is supplied (full / level=prose / level=brief
without chapter), the dispatcher iterates `engine-data/chapters/
ch*.md` and aggregates verdicts: PASS if every chapter PASSed;
FAIL if any FAILed; WARN if any returned an unexpected exit
code and none FAILed. The aggregate verdict + per-chapter call
count + per-chapter fail count are surfaced in the summary line:
`AUDIT|<script>|<domain>|<verdict>|<N> chapters; <M> fail | <first_line>|<log_path>`.

A script not in the `script_class()` registry is reported as
SKIP with the reason "signature unknown — register in
script_class()" rather than guessed-at. New scripts added to
the dispatcher mapping must register their signature class.

**v2.7.36 verdict mapping (Class A scripts).** The dispatcher
maps a script's exit code to the AUDIT line's verdict:

| Exit | Verdict | Semantics |
|---|---|---|
| 0 | PASS | The audit ran successfully and found no issues |
| 1 | FAIL | The audit ran successfully and found issues |
| 2 | SKIP | The audit could not run — pre-condition not met (no inputs, file-not-found, project-state-not-ready). Pre-v2.7.36 this was misclassified as `FAIL` "configuration error"; that mapping caused brief-level `/validate` runs on projects before chapter-briefs existed (an entirely normal entry state) to FAIL COHERENCE. The corrected mapping treats exit-2 as SKIP-equivalent so the briefing reports the audit as not-yet-applicable rather than failed. |
| 3+ | WARN | Unexpected exit; the audit ran but produced a non-canonical signal worth surfacing for inspection |

New Class A scripts MUST honour this mapping: exit-2 reserved
for SKIP-equivalent pre-condition misses; exit-1 reserved for
true audit failures (issues detected in the manuscript).

**v2.7.36 log-path keying.** Per-script logs are written to:

```
<project_root>/engine-data/reports/validate/<DOMAIN>-<script_name>.log
```

The DOMAIN prefix is essential: scripts registered to multiple
domains (e.g. `forbidden-words-scan.sh` runs under both ECONOMY
and AI_ISM_DETECTION) previously shared one log file, so the
second-domain run truncated the first-domain log and the user
clicking through the first-domain AUDIT line saw the wrong
run's contents. The DOMAIN prefix gives each (domain, script)
pair its own log file and eliminates the collision.

**Class B: Subagent-bound audit**

Invoked via subagent dispatch (Quality Gate, Accuracy Gate,
Beta Reader Persona Loop, etc.). Apply
`subagent-output-verification.md` HARD GATE — evidence-bearing
return contract; reject hallucinated audit claims.

**Class C: Engine-protocol audit**

Audits implemented as protocols the engine itself follows
(Edit-Tool Typographic Fidelity, File-Write Hygiene compliance
sweep). The engine performs the protocol inline and records
PASS/FAIL.

For each audit invocation, capture:

- Audit name
- Domain
- Verdict (PASS / FAIL / WARN)
- Finding (one-line summary; for FAIL/WARN, include location)
- Fix recommendation (for FAIL/WARN)
- Evidence path (which file / report / log line grounds the
  verdict)

### Step 4b: Class B subagent dispatch (v2.7.32+)

In addition to the Class A bash audits invoked above, the
dispatcher emits **CLASS_B_AUDIT** marker lines for every
Class B audit applicable to the in-scope domains:

```
CLASS_B_AUDIT|<audit_name>|<domain>|<spec_path>|<severity_cap>
```

The fifth field, `<severity_cap>`, was added in v2.7.37 and
carries the audit's severity-cap declaration (or `-` for none).
A non-empty cap means the engine layer MUST downgrade the
subagent's verdict to the cap severity before merging into
the briefing. Currently:

| Audit | Cap | Reason |
|---|---|---|
| `injury-accumulation` | `-` | No cap; subagent verdict passes through |
| `injury-accumulation-delta` | `-` | v2.7.61 per-chapter delta variant; same severity rules as parent |
| `leitmotif-tracker` | `-` | No cap; subagent verdict passes through |
| `leitmotif-tracker-delta` | `-` | v2.7.61 per-chapter delta variant; same severity rules as parent |
| `humanity-gate` | `-` | No cap; subagent verdict passes through |
| `intent-preservation` | `WARN` | Most subjective Class B audit; subagent FAIL → WARN at merge time so judgment-call findings surface without blocking craft choices |

The cap is sourced from the dispatcher's `severity_cap_for_audit()`
registry. The corresponding spec also declares `severity_cap: WARN`
in its frontmatter for human readers; both signals must agree, but
the registry is authoritative for the engine's runtime behaviour.
Pre-v2.7.37 the cap was documented only in the spec prose and
relied on the engine layer reading the spec end-to-end; v2.7.37
adds the marker-line field so an engine layer parsing only the
dispatcher output can apply the cap.

Class B audits are semantic checks that cannot be performed
by bash (character-state tracking, semantic injury detection,
leitmotif evolution, theme leakage, etc.). The bash dispatcher
itself does NOT dispatch the subagent — bash cannot invoke
Claude subagents. Instead, the slash-command engine layer
(Claude driving `/validate`) is responsible for the dispatch.

**Engine layer two-phase flow:**

1. **Phase 1 (bash dispatcher):** Run
   `validate-dispatcher.sh <project_root> <selector> [chapter]`.
   Capture all output lines. The bash phase completes when the
   `END|...` line is emitted.
2. **Phase 2 (engine subagent dispatch):** For each
   `CLASS_B_AUDIT|<audit_name>|<domain>|<spec_path>|<severity_cap>`
   line in the captured output:
   1. Read the linked spec file (e.g.
      `references/injury-accumulation.md`) to retrieve the
      subagent task brief and the evidence-bearing return
      contract.
   2. Construct the Agent tool invocation using the brief
      verbatim from the spec, substituting only project-
      specific paths (`<project_root>/engine-data/chapters/`,
      etc.).
   3. Dispatch the subagent. Do NOT inline-summarise the
      brief — the subagent must receive the full spec brief
      so it sees its evidence-bearing return contract.
   4. Receive the subagent's structured return.
   5. Apply the **subagent-output-verification.md HARD GATE**
      on the return:
      - Shape conformance: all required sections per the
        spec's return contract are present
      - Citation discipline: every claim that requires a
        citation per the spec has chapter:line (or equivalent)
        citations
      - Hallucination markers: cited chapters / files exist;
        out-of-range citations rejected
      - Verdict consistency: empty findings → PASS; non-empty
        findings → at least WARN
      Failures of the HARD GATE: re-dispatch ONCE with an
      "amend output to satisfy spec section X" message; if
      second attempt fails, emit
      `AUDIT|<audit_name>|<domain>|FAIL|subagent return non-conformant after retry|-`
      and write the rejected return to
      `engine-data/reports/validate/<audit_name>-subagent-rejected.md`.
   6. **Apply the severity cap (v2.7.37+).** If the
      `<severity_cap>` field on the CLASS_B_AUDIT marker line
      is non-empty (e.g. `WARN`), and the verified subagent
      verdict is more severe than the cap (e.g. FAIL when the
      cap is WARN), downgrade the verdict to the cap severity
      before merging. The cap does NOT apply to non-conformance
      FAILs from the HARD GATE itself (those reflect protocol
      failure, not audit judgement). The audit's spec
      frontmatter MUST also declare the same cap; the marker-
      line field is authoritative for runtime, the frontmatter
      is informative for human reviewers.
   7. Translate the verified, cap-applied return into an
      `AUDIT|...` line equivalent and merge it into the final
      Validation Briefing alongside Class A verdicts. Save the
      full subagent return to
      `engine-data/reports/validate/<audit_name>-subagent.md`
      for user inspection.

**The user sees a single unified briefing.** Class A and
Class B verdicts are merged in domain order; the two-phase
mechanics are invisible unless they fail. The briefing
includes a footer summary noting how many Class B audits
were dispatched (per the END line's class_b_total field).

**Why this two-phase split.** Bash cannot invoke Claude
subagents; subagents cannot invoke bash scripts in the
same execution model the dispatcher uses. The split keeps
each phase doing what it can do well: bash for fast
mechanical aggregation + emission of registry data; subagent
for semantic depth on specific audits. The CLASS_B_AUDIT
line is the contract between the two.

**Adding a new Class B audit.** Three steps:
1. Author the binding/protocol spec at
   `references/<audit_name>.md` following the canonical
   sections used by `injury-accumulation.md` (Why this
   exists, Why Class B, Subagent task brief, Engine HARD
   GATE on subagent return, How writers should respond to
   FAILs, Engine-neutral applicability, Failure modes
   prevented, See also). The Engine HARD GATE section
   should follow a 5-check structure (shape, citation,
   verdict consistency, hallucination markers, audit-
   specific special case); orderings 3-5 may vary by
   audit's domain semantics. If the audit needs a severity
   cap (signal sufficiently subjective that FAIL would
   block work on judgment-call findings), add
   `severity_cap: WARN` to the spec's frontmatter.
2. Register the audit in the dispatcher's
   `class_b_audits_for_domain()` function: append the
   audit name to its domain's case branch. If the audit
   has a severity cap, also register it in
   `severity_cap_for_audit()`. Both signals must agree;
   the registry is authoritative for runtime.
3. Mirror the spec across both engines (per Cross-Engine
   Mirrored Files convention) and add it to spec-lint's
   MIRRORED_FILES + Check 10 exempt list.

No bash script is required for the Class B audit itself —
the spec IS the audit definition; the subagent IS the
invocation; the engine HARD GATE IS the verification.

### Step 5: Append newly-passed audits to the project ledger

For every audit that returns PASS and is **not yet** present
in `engine-data/pipeline-checkpoint.md` `## Audits Passed`,
append a row using the bash-direct write protocol per
`producer-state-protocol.md` § Step 4 (auto-repair):

```
| <audit_name> | <ISO 8601 UTC> | <report_path> |
```

Apply Bash `ls` post-write verification + run.log entry. The
ledger now reflects the validation run; subsequent Director
Agent invocations will see the updated audits-passed set.

Audits returning FAIL or WARN are NOT appended — the ledger
is for passing gates only. The Validation Briefing surfaces
them; the user resolves; the next dispatcher run picks up
the new PASS state.

### Step 6: Emit the Validation Briefing

Output format:

```
═════════════════════════════════════════════════════════════════
VALIDATION BRIEFING — {Project Title}
Validation level: {architecture|brief|prose|full}
{ chapter scope: ch{NN}  (only when chapter supplied at prose level) }
Run at: {ISO 8601 UTC}
═════════════════════════════════════════════════════════════════

DOMAIN-BY-DOMAIN SUMMARY

  1. LOGIC                         {N PASS} / {M FAIL} / {K WARN}   { OUT-OF-SCOPE for level=brief|prose }
  2. CONSISTENCY                   {N PASS} / {M FAIL} / {K WARN}
  3. COHERENCE                     {N PASS} / {M FAIL} / {K WARN}
  4. PHYSICS                       {N PASS} / {M FAIL} / {K WARN}   (UNAUDITED gap → injury-accumulation tracker, target v2.7.29)
  5. CHARACTER                     {N PASS} / {M FAIL} / {K WARN}   (UNAUDITED gap → 7-criterion humanity gate, target v2.7.30)
  6. GENRE                         {N PASS} / {M FAIL} / {K WARN}   { OUT-OF-SCOPE for level=prose }
  7. ECONOMY                       {N PASS} / {M FAIL} / {K WARN}   { OUT-OF-SCOPE for level=architecture|brief }
  8. INTENT PRESERVATION           {N PASS} / {M FAIL} / {K WARN}   (UNAUDITED gap → theme-leak / resolution test, target v2.7.32)
  9. AI-ISM DETECTION              {N PASS} / {M FAIL} / {K WARN}   { OUT-OF-SCOPE for level=architecture|brief }
 10. SHOW NOT TELL                 {N PASS} / {M FAIL} / {K WARN}   (UNAUDITED gap → no-double-use physical tell, target v2.7.33)

PASSING AUDITS ({TOTAL_PASS})
  • {domain} — {audit_name}: {one-line summary}
  ...

FAILING AUDITS ({TOTAL_FAIL})
  • {domain} — {audit_name}
    Finding: {one-line summary at location}
    Fix:     {what needs to change}
    Evidence: {report path}
  ...

WARNINGS ({TOTAL_WARN})
  • {domain} — {audit_name}
    Finding: {one-line summary at location}
    Note:    {why this is a soft signal, not a hard fail}
  ...

UNAUDITED DOMAINS (gap analysis)
  • PHYSICS         injury-accumulation tracker        target v2.7.29
  • CHARACTER       7-criterion humanity gate          target v2.7.30
  • COHERENCE       leitmotif tracker (gap subset)     target v2.7.31
  • INTENT PRES.    theme-leak / resolution test       target v2.7.32 WARN-only
  • SHOW NOT TELL   no-double-use physical tell        target v2.7.33

NEWLY APPENDED TO Audits Passed LEDGER ({N})
  {audit_name} | {ISO} | {report_path}
  ...

NEXT
  {recommended next action — e.g. "Resolve {N} FAIL items, then
   re-run /validate"; or "All 10 domains green; ready for next
   pipeline phase or pre-pub gate"}

═════════════════════════════════════════════════════════════════
```

The summary line per domain shows counts even when domain is
UNAUDITED (zero of all three). The "newly appended" section
is empty if no new PASSes accumulated since the last run.

## Read-only discipline

The dispatcher itself **never writes** to:

- Manuscript files (chapters, briefs, summaries)
- Audit-report files (the audits themselves write reports;
  the dispatcher consumes them)
- Bibles, voice profiles, banlists, entity-canon

The single write the dispatcher performs is the
`## Audits Passed` ledger append (Step 5), via the
producer-state-protocol auto-repair path. That write is
governed by File-Write Hygiene + Bash `ls` verification +
run.log entry, identical to every other ledger update in
the pipeline.

Audits the dispatcher invokes may themselves write (Quality
Gate writes ch-verification.md; bible-coverage writes
bible-coverage.md; etc.). Those writes are governed by each
audit's own File-Write Hygiene compliance — the dispatcher
does not relax their constraints.

## Implementation venue (v2.7.39 explicit clarification)

The framework is split across two implementation venues — one bash, one
LLM. Understanding which lives where is essential to reading the
contracts correctly:

**Bash venue (the dispatcher script).**
`scripts/validate-dispatcher.sh` is real code. It runs Class A audits,
emits parseable AUDIT / DOMAIN / OUT_OF_SCOPE / END / CLASS_B_AUDIT
lines, manages the per-domain registry, the script-class registry, and
the severity-cap registry. The engine's spec-lint Check 8/9 enforces
its syntactic correctness; the engine's repo-level Tier 4 dispatcher-
runner CI discipline (not shipped in the plugin distribution; lives
under `tests/runners/` in the source repo) enforces its behavioural
correctness against fixtures.

**LLM venue (the engine layer).**
The "engine layer" referenced throughout this spec — the consumer that
reads `CLASS_B_AUDIT` lines, dispatches subagents per linked spec,
applies the `subagent-output-verification.md` HARD GATE, applies the
severity cap from the marker line's fifth field, merges verdicts into
the briefing, handles HARD GATE retry-once logic — is **not a code
path**. There is no `commands/validate.md` slash-command file, no
agent file, no Python/bash implementation that owns the two-phase flow.
The engine layer is **Claude reading the spec at dispatch time** when
the user invokes a `/validate` trigger phrase from `SKILL.md`.

This is by design for a SKILL-based plugin: skills are documentation
the LLM reads and follows. The framework's contracts are LLM contracts,
not code contracts. They are enforced by Claude's discipline in
following the spec, not by a runtime checker.

**Implications:**

- When this spec says "the engine layer dispatches a subagent", it
  means: Claude (who has read this spec because the user said
  `/validate`) issues an Agent tool call per the linked Class B spec's
  Subagent task brief.
- When it says "apply the HARD GATE on return", it means: Claude
  inspects the subagent's structured return against the spec's
  return-contract sections and either accepts or re-dispatches.
- When it says "apply the severity cap", it means: Claude reads the
  CLASS_B_AUDIT marker line's fifth field, and if it's `WARN`,
  downgrades the subagent's FAIL verdict before merging into the
  briefing.

**What this means for review and regression risk:**

- Behavioural test coverage for the bash venue is meaningful (the
  engine's repo-level Tier 4 dispatcher-runner CI discipline catches
  dispatcher regressions before they ship).
- Behavioural test coverage for the LLM venue is structurally
  impossible at the test-runner level — Claude's discipline is
  verifiable only by inspection of actual `/validate` runs.
- The `severity_cap` field on CLASS_B_AUDIT lines + the
  `severity_cap_for_audit()` registry + the spec frontmatter
  (`severity_cap: WARN`) form a three-signal contract whose
  enforcement is also LLM-contract-only. The redundancy is
  defence-in-depth: Claude reading the marker line, the registry, OR
  the frontmatter alone is sufficient to know the cap exists.
- Adding a `commands/validate.md` slash-command implementation that
  owns the two-phase flow as code would convert the LLM contract to
  a code contract. That is a meaningful future improvement but is
  out of scope for the v2.7.x line; it would represent architectural
  change appropriate for v2.8.0+.

## What the dispatcher does NOT do

- Does not fix FAIL findings. The Validation Briefing names
  fixes; the user (or engine in fix-flow) applies them.
  Re-running `/validate` after fixes shows updated state.
- Does not chain into next-step recommendations beyond the
  one-line "NEXT" hint. For phase-graph routing, use the
  Director Agent (`director-protocol.md`).
- Does not synthesise novel domain coverage beyond what
  the taxonomy maps. UNAUDITED domains stay UNAUDITED in
  the report; the dispatcher does not improvise replacements.
- Does not skip domains to save time. v2.7.27 is full-only.
  v2.7.28 will add level scoping for partial validation.
- Does not invoke audits whose preconditions aren't met
  (e.g. Stage 9b requires Stage 9a complete; per-chapter
  audits require the chapter exists). Preconditions are
  surfaced as audit-skipped notes in the briefing.

## Silent-Failure Audit

This feature uses the following primitives. For each, the
success-claim, divergence failure mode, and verification
binding are documented:

| Primitive | Success-claim | Failure mode | Verification |
|-----------|---------------|--------------|--------------|
| Read (taxonomy + pipeline-checkpoint) | "Read succeeded with N bytes" | Empty / partial extraction; stale cached view | `read-verification.md` HARD GATE invoked at Step 3 (taxonomy) and Step 2 (via producer-state-protocol Step 1) |
| Bash (script invocations) | "Exit 0; PASS reported" | Empty result misread as PASS; path typo; pipefail-disabled silent failure | `bash-output-verification.md` HARD GATE invoked per audit-script invocation at Step 4 |
| Subagent dispatch (Quality / Accuracy Gate, Persona Loop) | "Subagent returned complete with verdict" | Hallucinated PASS / stub finding / no evidence | `subagent-output-verification.md` HARD GATE invoked per subagent-bound audit at Step 4 |
| Pipeline-checkpoint state-claim | "Audits Passed list says X passed" | Claim diverges from filesystem reality | `producer-state-protocol.md` HARD GATE invoked at Step 2 — halts on DIVERGENCE before validation runs |
| Write (ledger append) | "Append succeeded" | Subdir flush failure; partial write | `core-pipeline.md` § File-Write Hygiene applied at Step 5 (bash-direct write + Bash `ls` + run.log entry) |
| AskUserQuestion (project disambiguation) | "Got an answer" | Compound / ambiguous response interpreted unilaterally | `ask-user-disambiguation.md` HARD GATE invoked at Step 1 when project resolution is ambiguous |
| Cross-domain orchestration | "All domains reported" | Domain skipped silently; UNAUDITED gap not surfaced | This spec's Step 4 explicitly enumerates all 10 domains; UNAUDITED ones are reported as gaps in the briefing, not omitted |

The dispatcher is a thin orchestration layer. Every primitive
it uses already has a fix binding in the silent-failure-audit
catalog; the dispatcher's correctness rests on invoking those
bindings at the documented steps.

## Failure modes prevented

- **Cross-domain blindness** — running individual audits one
  by one and forgetting that one domain (e.g. INTENT
  PRESERVATION) was never checked. The dispatcher enumerates
  every domain explicitly; gaps are reported as gaps, not
  silently skipped.
- **Stale-state validation** — running validation against a
  pipeline-checkpoint.md whose `## Audits Passed` ledger
  diverges from filesystem reality. Step 2 reconciles before
  any audit runs.
- **Audit-result fabrication** — the dispatcher cannot
  silently mark an audit PASS without the underlying audit
  actually running with its evidence-bearing return. Every
  invocation goes through the appropriate verification HARD
  GATE.
- **Ledger append fabrication** — the Audits Passed append
  uses bash-direct write + Bash `ls` verification, identical
  to step 18 chapter-table updates. A failed write is caught
  by the same ls check that catches every other ledger
  failure.
- **Domain-coverage misrepresentation** — UNAUDITED domains
  appear in every briefing with their target release. The
  user can never read the briefing and conclude all 10
  domains were covered when five gaps remain.

## Roadmap context

This dispatcher is the central piece of the Canon Validation
Framework adoption sequence. Original plan (5 novel-check
releases + v2.8.0-rc1 pipeline restructure) was reassessed
after v2.7.28 smoke-testing surfaced (a) script-signature
heterogeneity as a real blocker rather than polish, (b) most
novel checks are Class B (subagent) not Class A (bash) — so
each release is a spec + engine-protocol, not a new bash
script, and (c) the proposed pipeline restructure was
speculative — existing phase HARD GATEs are minimal blocking
checks the dispatcher would slow down rather than improve.

Revised 7-release sequence (sequenced by complexity):

| Release | Scope | Class | Risk |
|---|---|---|---|
| v2.7.26 | Taxonomy spec + gap analysis published | Doc | Shipped |
| v2.7.27 | `/validate` dispatcher — full validation only | Bash + spec | Shipped |
| v2.7.28 | Level scoping: architecture / brief / prose / full + per-chapter | Bash + spec | Shipped |
| v2.7.29 | Dispatcher signature normalisation: `script_class()` registry + per-class dispatch + iterate-all-chapters fallback | Bash + spec | Shipped |
| v2.7.30 | Gap close: SHOW NOT TELL no-double-use physical tell — `show-not-tell-tells.md` + `.sh`; first novel-check shipped | Class A | Shipped |
| v2.7.31 | Gap close: COHERENCE same-function-consecutive — `coherence-function-consecutive.md` + `.sh`; Class C engine-protocol convention (`<!-- Function: <value> -->`) added to core-pipeline step 5; Class A bash audit reads briefs and flags adjacent duplicates | Class C + Class A | Shipped |
| v2.7.32 | Class B dispatch protocol introduced + first Class B audit: PHYSICS injury-accumulation — `injury-accumulation.md`; bash dispatcher emits `CLASS_B_AUDIT` lines, engine layer dispatches subagent per spec, applies subagent-output-verification HARD GATE on return, merges verdict | Class B framework + first Class B audit | Shipped |
| v2.7.33 | Gap close: COHERENCE leitmotif tracker — `leitmotif-tracker.md`; second Class B audit using the v2.7.32 framework; extracts motif plan from bible, verifies prose lands as planned and evolves rather than repeats unchanged; COHERENCE domain now fully COVERED | Class B (uses v2.7.32 framework) | Shipped |
| v2.7.34 | Gap close: CHARACTER 7-criterion humanity gate — `humanity-gate.md`; third Class B audit; per-character scorecard against contradiction / independent existence / five emotional registers / private self / competing desires / surprise behavior / stated-values-vs-behavior gap; graduated severity (6-7=PASS, 4-5=WARN, 0-3=FAIL); CHARACTER domain gains its first primary-domain audit | Class B (uses v2.7.32 framework) | Shipped |
| v2.7.35 — final Wave 4 gap-close | Gap close: INTENT PRESERVATION theme-leak / resolution test — `intent-preservation.md`; fourth Class B audit; bible-grounded (every finding cites both bible source AND prose moment); WARN-only severity cap (engine layer downgrades any FAIL subagent verdict to WARN to surface findings without blocking craft choices on the most subjective audit); INTENT PRESERVATION domain gains its first primary-domain audit. **All ten canon-validation domains now COVERED; framework feature-complete.** | Class B (WARN-only) | Shipped |
| v2.7.36 — fix release | Fix release after independent code review of v2.7.29-v2.7.35. Three production bugs + one cosmetic + adversarial test coverage. Bugs fixed: (a) cross-domain log-path collision; (b) exit-2 misclassified as FAIL not SKIP; (c) show-not-tell FP patterns; (d) injury-accumulation HARD GATE off-by-one. Plus new `tests/runners/runner-validate-dispatcher.sh` Tier 4 runner. | Bug fixes + tests | Shipped |
| v2.7.37 — design polish | Brittleness items from the same review: deleted dead `gap_target_for_domain()`; added severity-cap mechanism (registry + marker line field + spec frontmatter); HARD GATE template canonicalised; `resolve_forbidden_words_file()` simplified (note: this last item was reverted in v2.7.38 — see below). | Refactor + framework polish | Shipped |
| v2.7.38 — second-pass review fixes | Pass-2 review found regressions caused by v2.7.37: forbidden-words.md engine fallback wrongly removed; typography-sweep blanket exit-2→SKIP swallowed real errors. Plus intent-preservation HARD GATE ordering bug (cap applied before hallucination strip) + 4 documentation drift sites. | Bug fixes + reorder | Shipped |
| **v2.7.39 (current) — third-pass fixes** | Pass-3 review found 5 cumulative-state issues: typography-sweep doc drift; this taxonomy/dispatcher's frontmatter version frozen at 2.7.26 across 13 content updates + roadmap stale; 3 byte-identical scripts not in spec-lint MIRRORED_FILES; dead `FILE_OR_PROJECT` documentation in dispatcher header; `run_audit()` per-chapter `fail_count` over-counted SKIPs as fails. Plus new "Implementation venue" section in this spec acknowledging the engine-layer consumer of CLASS_B_AUDIT lines is Claude reading the spec, not a code path under `commands/`. | Cumulative-state cleanup + architectural clarification | Low |
| v2.8.0 | Reserved for genuine architectural change (multi-project workflows, new engine mode, OR converting the LLM-contract Class B dispatch protocol into a code-contract under `commands/`). NOT a pipeline restructure. | — | Deferred |

When v2.7.30-v2.7.35 ship, the UNAUDITED rows in the briefing
collapse to PASS / FAIL / WARN like every other domain. The
dispatcher framework itself is feature-complete at v2.7.29;
subsequent releases plug in new audit invocations through the
existing Class A / B / C dispatch model.

The deferred v2.8.0 is intentional. Major-minor bumps signal
architectural change; shipping a major-minor for "all gaps
closed" would erode the meaning of the version number. The
Canon Validation Framework completion is just the natural
progression of v2.7.x.

## See also

- `canon-validation-taxonomy.md` — the 10-domain index this
  dispatcher routes through; the gap analysis names the
  five UNAUDITED domains
- `silent-failure-audit.md` — primitives catalog; this
  dispatcher's correctness rests on its bindings
- `producer-state-protocol.md` — state-reconciliation HARD
  GATE invoked at Step 2 + ledger append protocol at Step 5
- `director-protocol.md` — the orchestration layer; together
  with this dispatcher answers "where am I + what next +
  is this passing every quality bar?"
- `read-verification.md` / `bash-output-verification.md` /
  `subagent-output-verification.md` / `ask-user-disambiguation.md`
  — primitive HARD GATEs the dispatcher delegates to
- `scripts/validate-dispatcher.sh` — the bash orchestrator
  that runs Class A (mechanical-script) audits and emits
  structured output the engine consumes
