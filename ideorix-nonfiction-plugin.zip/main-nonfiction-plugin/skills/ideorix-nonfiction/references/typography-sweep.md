---
name: typography-sweep
description: "Typography Sweep — automated scan for typographic-style artifacts (ASCII apostrophes, ASCII double quotes, double-hyphen em-dash imposters, three-dot ellipsis imposters) that leak into curly-default narrative prose. Safety net behind the Edit-tool typographic-fidelity discipline. Runs as a HARD GATE at pre-press delivery and is available as a standalone audit tool. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.5"
user-invocable: true
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Typography Sweep (MANDATORY pre-press gate; standalone audit tool)

## Purpose

Detect and report typographic-style artifacts that leak into a
manuscript's narrative prose so they can be cleaned out before
delivery — closing the loop opened by the Edit-tool typographic-
fidelity discipline (see `core-pipeline.md`, "Edit-Tool Typographic
Fidelity").

The Edit-tool discipline is **preventive**: it stops the engine
from inserting ASCII straight quotes into a curly-quoted manuscript
during an Edit. Typography Sweep is the **detective and corrective**
layer: even if a stray ASCII apostrophe or double-hyphen artifact
slips through (e.g. from a paste-in, a partial Edit, an importer
that didn't normalize), the sweep finds it before pre-press
delivery.

This script exists because a single-quote / double-quote artifact
mixed into a 90,000-word manuscript is hard to find by eye — at
body-text size U+0027 vs U+2019 are nearly indistinguishable, and
a global search/replace risks overcorrecting (e.g. legit ASCII
chars inside fenced code blocks or technical citations). The sweep
strips fenced code automatically and reports each artifact with
line-level context so the user can triage individually.

## Failure mode addressed

A user (Mitch, May 2026) reported that single-quotes in passages
the engine wanted to change "would leave single and/or double-quote
artifacts inside a work — and they might be hard to find and
eliminate." This script is the safety net the v2.7.4 Edit-tool
fidelity rule pointed to but didn't yet provide.

## Categories scanned

For a curly-target manuscript (default), the sweep flags any of:

| Category | Preferred (target) | Artifact (flagged) |
|----------|---------------------|--------------------|
| Apostrophe / single-quote | U+2019 (right single quotation mark) | U+0027 (ASCII apostrophe) |
| Double-quote | U+201C / U+201D (left/right double quotation marks) | U+0022 (ASCII double quote) |
| Em-dash | U+2014 (em-dash) | `--` (double hyphen) |
| Ellipsis | U+2026 (horizontal ellipsis) | `...` (three ASCII dots) |

Single ASCII hyphen `-` is **not** flagged — it is legitimate for
compound words (e.g. *self-aware*, *pre-press*).

For an ASCII-target manuscript (rare; opt-in via `--target ascii`),
the sweep inverts: flags any U+2019 / U+201C / U+201D / U+2014 /
U+2026 in narrative prose.

## Usage

```sh
scripts/typography-sweep.sh <file.md|file.docx> [--target curly|ascii] [--quiet]
```

- Default `--target` is `curly` (publishing standard for narrative prose).
- `.md` / `.txt` input is read directly; fenced code blocks
  (` ``` ... ``` `) are auto-skipped so technical content is not
  falsely flagged.
- `.docx` input is extracted via `unzip -p file.docx word/document.xml`,
  XML tags stripped via `perl -CSDA -pe 's/<[^>]+>/ /g'`, then scanned.
- `--quiet` suppresses the per-category PASS summary; FAIL output
  always prints.

**Exit codes:**

| Exit | Meaning |
|------|---------|
| 0    | Clean — no artifacts found |
| 1    | Artifacts found — sweep failed; report printed |
| 2    | SKIP-equivalent invocation error: usage misuse, file genuinely missing, bad `--target` value (v2.7.38 refinement) |
| 3    | WARN — environment / malformed-input error: `unzip` not installed, file is empty, unsupported extension, malformed `.docx` with empty extracted body (v2.7.38 refinement; previously these were exit-2, which the validate-dispatcher's blanket exit-2 → SKIP mapping silently swallowed) |

## When the sweep runs

**As a HARD GATE — automatically:**

- **Stage 14 (fiction) / Stage 15 (NF) — Pre-press delivery.** Every
  chapter file in the project's `manuscript/` directory MUST pass
  the sweep before the final assembled DOCX is built. Failure
  blocks delivery; the engine reports the artifact list to the
  user and waits for resolution.
- **Tracked-Changes Phase C (`tracked-changes.md`).** The new check
  (e: typographic-profile preservation) calls this script against
  the output DOCX as part of the integrity verification phase.

**As a standalone audit — user-invocable:**

- "Run typography sweep on chapter 3"
- "Scan my manuscript for ASCII quote artifacts"
- "Audit typography across all chapters"

The user-facing trigger is wired into `SKILL.md` Writers Studio
menu under the audit/scan section.

## What the sweep does NOT do

- It does **not** modify the file. The output is a report.
  Normalization is the user's call (per-occurrence, in their
  editor) so legitimate ASCII chars (e.g. URLs, code snippets
  outside fenced blocks) are not auto-mangled.
- It does **not** check formatting validity (em-dash spacing,
  dialogue tagging, etc.) — that is `formatting-check.sh`'s job.
  The two scripts are orthogonal: this enforces *uniformity of
  typographic style*; the other enforces *valid use of the
  characters present*.
- It does **not** read inside `.pdf` — only `.md`, `.txt`, `.docx`.
  Pre-press delivery converts to PDF after typography is locked,
  so this is the right scope.

## Integration with Edit-tool fidelity

The Edit-tool fidelity discipline (preventive) and the Typography
Sweep (detective) form a paired safety net:

1. **Preventive — Edit-tool typographic fidelity** (`core-pipeline.md`):
   when the engine performs an Edit on a user manuscript, the
   `new_string` MUST match the surrounding document's typographic
   style byte-for-byte. Read the file before Edit; preserve curly
   chars where present; suspect typographic mismatch on any
   unexplained Edit failure.
2. **Detective — Typography Sweep** (this spec): if an artifact
   somehow makes it into the manuscript (paste-in, importer,
   partial flow), the pre-press HARD GATE catches it before
   delivery and surfaces it for the user to clean.

The combination is the closed loop — preventing artifacts from
entering, and catching any that slip through.

## Tier 4 behavioral assertion

The deterministic test harness (`tests/run-behavioral.sh`) runs
this script against fixture manuscripts:

- f01-clean-curly.md — must exit 0 (zero artifacts)
- f02-mixed-quotes.md — must exit 1 with expected artifact counts
- f03-curly-with-stray-ascii.md — must exit 1, exactly 1 ASCII-apo
- f04-fenced-code-with-ascii.md — must exit 0 (code blocks skipped)
- f05-ascii-target.md — must exit 0 with `--target ascii`

If the script regresses against any fixture, CI blocks the release.

## Anti-patterns this spec prevents

- **Silent ASCII insertion:** Edit producing `"Don't"` (U+0027)
  inside a manuscript that uses `"Don't"` (U+2019) elsewhere.
- **Mixed-style manuscript shipped:** pre-press DOCX delivered
  with both curly and straight quotes mixed across chapters.
- **Hard-to-find artifacts:** user notices a glyph looks wrong
  in the proof but cannot locate all occurrences without a tool.
- **Overcorrection from global search/replace:** user runs
  blanket `'` → `'` across the manuscript and mangles legit
  ASCII inside code samples or technical citations.
- **Importer drift:** content imported from Novelcrafter, Plottr,
  Scrivener, or screenplay tools arrives with ASCII typography
  and is never normalized to the engine's curly default.

## Relationship to other gates

| Gate | Concern | Stage |
|------|---------|-------|
| `formatting-check.sh` | Em-dash spacing, ellipsis usage, narration vs dialogue separation | Per-chapter, Stage 3 / Stage 5 editorial |
| `placeholder-scan.sh` | Bracketed placeholders (`[insert ...]`) left unfilled | Per-chapter, Stage 3 |
| `forbidden-words-scan.sh` | Prohibited tokens (LLM tells, banned phrases) | Per-chapter, Stage 5 |
| `word-count-check.sh` | Per-chapter word target compliance | Per-chapter, Stage 3 |
| **`typography-sweep.sh`** | **Typographic-style uniformity (curly vs ASCII)** | **Pre-press, Stage 14 / 15 (and Tracked-Changes Phase C)** |
| `manuscript-audit.sh` | Cross-chapter assembled audit (composite) | Pre-press, Stage 14 / 15 |

Each gate is single-purpose; the sweep stays orthogonal to all
existing checks. Run it any time as a standalone audit.
