---
name: director-orchestration-protocol
description: "Engine-neutral binding/protocol. The recommendation HARD GATE applied to every Director Briefing. Every claim in the briefing must cite (a) a specific pipeline-checkpoint field, (b) filesystem evidence, (c) prerequisite-phase check, (d) prerequisite-audit check. Recommendations that cannot be grounded against all four are REJECTED. Prevents hallucinated next-step, prerequisite-skip recommendations, and stale-state cascades."
version: "2.7.25"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Director Orchestration Protocol

A binding/protocol spec invoked by `director-protocol.md` Step 4
(Compute the recommendation). The protocol is the recommendation
HARD GATE — every claim in a Director Briefing must satisfy four
grounding requirements before the briefing is emitted. Claims that
fail any requirement are REJECTED, and the Director's output
becomes "no grounded recommendation possible — here is the raw
state for your review" with the obstacles listed.

## Why this exists

Subagent / orchestrator output is a known silent-failure shape:
the agent returns "complete" with a recommendation, the user
trusts the recommendation, the recommendation skips a
prerequisite, the user proceeds, the next phase fails or
fabricates against the missing foundation. The
`subagent-output-verification.md` binding catches the file-
writing variant; this protocol catches the recommendation-
producing variant.

The Director Agent is read-only and produces a structured
recommendation. The recommendation is **only useful** if it is
grounded — if a human auditor can trace every claim to a
verifiable artifact (a pipeline-checkpoint field, a filesystem
file, a phase-graph rule, an audit-ledger row). Ungrounded
recommendations are exactly the silent-failure shape the
discipline catalog tracks: a success-claim ("here is your next
step") that diverges from actual effect ("the step skips a
prerequisite the engine requires").

This protocol makes grounding mandatory and machine-checkable.

## Invocation contract

Invoked by `director-protocol.md` Step 4 immediately before the
briefing is emitted to the user. Operates on the recommendation
candidate(s) the Director has computed from current state.

**Block emission until grounding is complete.** If grounding
fails for the primary recommendation, the Director may attempt
to ground an alternative path; if no path can be grounded, emit
the "no grounded recommendation possible" briefing and stop.

This protocol is NOT invoked by:

- Per-flow pipeline transitions (those have their own HARD GATEs
  built into `core-pipeline.md`)
- User-issued direct-flow invocations ("run Stage 9b now") — the
  user is the grounding authority for direct invocations; this
  protocol applies only when an agent (the Director) is producing
  a recommendation on the user's behalf

## The four grounding requirements

Every claim in a Director Briefing must cite all four:

### Requirement 1: Pipeline-checkpoint field citation

The claim must point to a specific field in
`engine-data/pipeline-checkpoint.md` that supports it. Acceptable
citations:

- `## Pipeline Status` `Phase:` field value
- `## Pipeline Status` `Current chapter:` field value
- `## Audits Passed` row (audit name + iso + report path)
- Chapter-table column value for a specific row
- `## Word Count Tracker` field
- `## Number-7 Bias Tracker` value
- `## Flags` line text

The claim names the field and quotes its current value. Hand-
wavy phrasing ("the project is in mid-Phase-2D-ish") is
REJECTED.

### Requirement 2: Filesystem evidence

The claim must reference at least one on-disk artifact whose
existence supports the claim. Acceptable evidence:

- An audit-report file at the path cited in `## Audits Passed`
- A chapter file at `engine-data/chapters/ch{NN}.md`
- A bible file at `engine-data/research-bible.md` or
  `engine-data/story-bible.md`
- A run.log line entry timestamp
- The presence (or absence) of an expected file in
  `engine-data/reports/`

The Director Agent has already gathered this evidence in Step 2
(via `producer-state-protocol.md` reconciliation). The protocol
checks that the citation matches a real evidence row from that
gathering. Citations to files NOT in the gathered evidence set
are REJECTED.

### Requirement 3: Prerequisite-phase check

The recommendation names the engine pipeline phase it advances
into and verifies that the prior phase is fully complete. The
phase-graph rules:

- A phase advancement is grounded only if the prior phase's
  defining artifacts exist on disk.
- Phase 2D → Phase 2E requires entity-canon.md present.
- Phase 2E → Phase 3 requires pipeline-checkpoint.md present
  with chapter-table header rows.
- Phase 3 (per-chapter) → Phase 4 requires the last chapter
  row's full step-column set populated.
- Engine-specific fact-audit prerequisites (the engine layer
  reads `engine` from manifest.json to select the right rule):
  - **Fiction**: Stage 9 splits into 9a (chapter table) and
    9b (manuscript-wide). Stage 9a → Stage 9b requires the
    chapter table's per-chapter Verified column = Yes for all
    chapters. Stage 9b → Stage 13 requires `## Audits Passed`
    to contain `fact-audit-9b`.
  - **Non-Fiction**: Stage 9 is unified — no 9a/9b split.
    Stage 9 → Stage 13 requires `## Audits Passed` to contain
    `fact-audit` (singular).
- Stage 13 → Publication-Ready requires the engine's stage-9
  audit (`fact-audit-9b` fiction / `fact-audit` NF) in
  `## Audits Passed` AND any sampled-VERIFIED-recheck audit
  the engine has registered as a Stage 13 prereq.

A recommendation that names a target phase whose prereq-phase
artifacts are missing is REJECTED. The briefing's "Obstacles"
section must list which prereq is missing and what would
satisfy it.

### Requirement 4: Prerequisite-audit check

The recommendation names every audit the target phase requires
as a prereq, and verifies each appears in the reconciled
`## Audits Passed` ledger. The audit-prereq rules (engine-
aware — read `engine` from manifest.json):

- **Fiction**:
  - Stage 9a (or any pre-edit phase that depends on the
    bible being complete) requires `bible-coverage-audit`
    (when the project was imported via BYO-canon or similar
    extraction).
  - Stage 9b requires Stage 9a complete (chapter-table) AND
    pending-marker scan registered as passed (per
    `pending-marker-scan.sh` HARD GATE).
  - Stage 13 READY check requires `fact-audit-9b` AND any
    sampled-VERIFIED audits that ship with the active engine
    version.
- **Non-Fiction**:
  - Pre-edit phases that depend on the research bible being
    complete require `bible-coverage-audit` (when the project
    was imported via BYO-source or similar extraction; the
    NF bible-coverage-audit checks research-bible.md coverage,
    parallel to fiction's story-bible.md check).
  - Stage 9 (unified Fact Audit) requires no Stage 9a prereq
    — it runs directly after the per-chapter Verified ledger
    is complete. Pending-marker scan still applies as a
    Stage 9 prereq when the manuscript carries fact-pending
    markers.
  - Stage 13 READY check requires `fact-audit` AND any
    sampled-VERIFIED audits the active engine version ships.

A recommendation that depends on an audit not present in the
ledger is REJECTED. The briefing's "Obstacles" section names
the missing audit and instructs the user how to run it.

## Rejection and fallback

If a recommendation fails any of the four grounding requirements,
it is REJECTED. The Director attempts the next-best alternative
path:

1. If alternative paths are available, ground each in turn until
   one passes all four requirements.
2. If no alternative passes, emit the "no grounded recommendation
   possible" briefing:

```
═════════════════════════════════════════════════════════════════
DIRECTOR BRIEFING — {Project Title}
═════════════════════════════════════════════════════════════════

NO GROUNDED NEXT STEP

Current state (raw):
  Engine:                  {fiction|nonfiction}
  Phase:                   {phase}
  Audits passed:           {names}

Candidate recommendations were considered but none could be
grounded against the four requirements (checkpoint field +
filesystem evidence + prereq-phase + prereq-audit). The
specific obstacles per candidate:

  Candidate A: {action}
    Obstacle: {requirement-N failure description}

  Candidate B: {action}
    Obstacle: {requirement-N failure description}

To unblock:
  1. Resolve the obstacle(s) listed above (most commonly: run
     a missing prerequisite audit, or fix a state-divergence
     surfaced by producer-state-protocol).
  2. Re-invoke the Director.

If you believe the engine is wrong about a prerequisite, the
direct-flow invocation always remains available — invoke the
flow you intend explicitly (e.g. "run Stage 9b now"), and the
flow's own HARD GATEs will gate the action. The Director will
not ground a recommendation that bypasses a prereq, but it
will not block your direct command either.
═════════════════════════════════════════════════════════════════
```

The user resolves obstacles or proceeds via direct invocation.

## Output format compliance

Every briefing emitted by the Director must contain, for the
recommendation section, the four grounding pieces inline so a
human auditor can verify without re-running the protocol:

```
RECOMMENDED NEXT STEP
  → {recommended action}

  Why:
    [Requirement 1] Pipeline-checkpoint says {field} = {value}.
    [Requirement 2] Filesystem evidence: {file path} exists
      (last modified {iso8601}).
    [Requirement 3] Prerequisite phase: {prior_phase} is
      complete (artifact {path} present).
    [Requirement 4] Prerequisite audit: {audit_name} present
      in Audits Passed ledger ({iso}, {report_path}).
```

A briefing that lacks any of `[Requirement N]` annotations is
malformed and indicates the protocol was not applied. Spec lint
does not check briefing output (briefings are runtime artifacts,
not source files); the discipline is enforced by this spec being
the binding `director-protocol.md` Step 4 invokes.

## Failure modes prevented

- **Hallucinated phase advancement** — recommendation names a
  phase the engine's graph does not reach from current state.
  Requirement 3 catches this.
- **Prerequisite-audit skip** — recommendation depends on an
  audit not in the ledger. Requirement 4 catches this.
- **Fabricated state-claim grounding** — recommendation cites a
  pipeline-checkpoint field that does not exist or quotes a
  fabricated value. Requirement 1 + 2 together catch this:
  Requirement 1 demands the field name; Requirement 2 demands
  the value match what `producer-state-protocol.md` reconciled.
- **Plausible-sounding but ungrounded narrative** — the kind of
  smooth recommendation an unaudited orchestrator produces:
  "given where you are, the natural next step is X". Without
  the four grounding citations, the narrative is a success-
  claim without a verifiable effect — exactly the silent-
  failure shape this protocol exists to prevent.

## See also

- `silent-failure-audit.md` — catalog of drift-failure shapes;
  this protocol adds the `director-orchestration` binding
- `subagent-output-verification.md` — the parallel binding for
  file-writing subagents (this protocol is its read-only
  recommendation analogue)
- `director-protocol.md` — the consumer that invokes this protocol
  at Step 4
- `producer-state-protocol.md` — the state-reconciliation HARD
  GATE invoked before this one; produces the evidence set
  Requirements 1 and 2 reference
- `core-pipeline.md` — the source of phase-graph and audit-
  prereq rules Requirements 3 and 4 enforce
