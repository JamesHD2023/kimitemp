---
name: philosophy-popular
description: "Category plugin for popular philosophy non-fiction. stoicism, existentialism, ethics, political philosophy, eastern philosophy"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025 James Harvey Media. All rights reserved. -->

# Popular Philosophy. Category Plugin

## Metadata

| Field | Value |
|-------|-------|
| Category ID | philosophy-popular |
| Display Name | Popular Philosophy |
| Parent Group | Self-Help & Psychology |
| Typical Word Count | 55,000–75,000 |
| Default Structure | Dialectical. thesis, antithesis, synthesis per chapter with practical application |
| Citation Style | Endnotes with philosophical bibliography; in-text attribution for key thinkers |
| Audience Baseline | Thoughtful general reader; no formal philosophy training assumed |
| Comparable Titles | Alain de Botton, Massimo Pigliucci, Michael Sandel, Derren Brown, Julian Baggini |

## Subcategory Options

When the user selects Popular Philosophy, prompt for subcategory refinement:

| ID | Subcategory | Focus | Typical Structures |
|----|------------|-------|-------------------|
| stoicism-practical | Stoicism / Practical Philosophy | Stoic principles, practical wisdom, ancient philosophy for modern life, virtue ethics | Daily-practice chapters, ancient-modern parallels, principle-to-application |
| existentialism-meaning | Existentialism / Meaning | Meaning-making, freedom, authenticity, absurdity, death, purpose | Question-driven chapters, thinker profiles, lived-experience integration |
| ethics-moral | Ethics / Moral Philosophy | Trolley problems, moral intuitions, justice, rights, consequentialism, duty | Dilemma-based chapters, competing frameworks, real-world application |
| political-philosophy | Political Philosophy | Liberty, equality, justice, democracy, power, rights, social contract | Argument-based chapters, historical thinker profiles, contemporary application |
| eastern-philosophy | Eastern Philosophy | Buddhism, Taoism, Confucianism, Hindu philosophy, Zen, mindfulness traditions | Concept-centred chapters, practice integration, cross-cultural dialogue |

**Default:** If the user does not specify, use `stoicism-practical` conventions as baseline.

## Structural Architect Instructions

### Core Technique: Dialectical Structure

Popular philosophy builds understanding through **dialectic**. presenting a position,
challenging it with the strongest counterargument, and arriving at a richer synthesis.
Every chapter must take the reader through this movement. Philosophy that only affirms
one position is propaganda; philosophy that only questions is sophistry. The synthesis
is what makes it useful.

### Chapter Architecture Patterns

1. **The Question**. Open with a concrete situation, dilemma, or experience that
   raises a philosophical question. Never open with an abstract definition. "What
   should I do when..." is always stronger than "Justice is defined as..."
2. **The First Position**. Present the strongest version of one philosophical
   response. Name the thinkers. Give their arguments. Make the position genuinely
   appealing. the reader should think "yes, that makes sense."
3. **The Challenge**. Introduce the strongest objection or competing position.
   Again, make it genuinely compelling. The reader should think "wait, but this
   also makes sense." This tension is where philosophical understanding happens.
4. **The Synthesis**. Work toward a resolution or a deeper understanding that
   incorporates insights from both positions. This need not be a neat conclusion . 
   sometimes the synthesis is recognising genuine complexity.
5. **The Application**. Connect the philosophical insight to the reader's own life,
   to contemporary issues, or to practical decision-making. Philosophy that stays
   abstract fails the popular genre.

### Evidence Deployment

- **Primary philosophical texts:** Direct engagement with the thinkers' own words.
  Quote key passages and explain them clearly.
- **Historical context:** When and why did this thinker develop this idea? What
  problem were they responding to? Philosophy has a history.
- **Thought experiments:** The philosopher's laboratory. Trolley problems, experience
  machines, veils of ignorance. Use them to test intuitions.
- **Contemporary examples:** News events, cultural phenomena, personal dilemmas that
  show philosophical ideas at work in the modern world.
- **Competing interpretations:** Where scholars disagree about a thinker's meaning,
  note the debate.

### Brief Template Additions

For each chapter brief, the Architect MUST include:

- **Central Question:** The philosophical question driving the chapter.
- **Position A:** The first major philosophical response, with named thinkers.
- **Position B:** The strongest counter-position, with named thinkers.
- **Synthesis Direction:** How the chapter will resolve or deepen the tension.
- **Key Texts:** Specific philosophical works to reference or quote.
- **Thought Experiment:** A scenario that tests the chapter's ideas.
- **Contemporary Application:** A modern situation illuminated by the philosophy.
- **Practical Takeaway:** What the reader can do or think differently as a result.

## Content Writer Craft Rules

### Voice & Tone

- **Thoughtful, not pontificating.** The author is a thinking companion, not a sage
  dispensing wisdom. Write as someone working through ideas alongside the reader.
- **Clear, not dumbed-down.** Philosophical ideas deserve precision. Simplify the
  language, not the thought. "Accessible" does not mean "superficial."
- **Honest about difficulty.** Some philosophical problems are genuinely hard. Do not
  pretend they are simple. "This is where it gets tricky" is a valid and valuable
  sentence.
- **Engaged with life.** Popular philosophy must touch the ground. Every abstract
  idea should eventually connect to how we live, choose, and relate.

### Handling Thinkers

- **Introduce thinkers as people.** A sentence or two of biographical context before
  their ideas: "Epictetus was born a slave in the Roman Empire. and from that
  position of radical powerlessness, he developed a philosophy of inner freedom."
- **Quote directly, then translate.** Give the philosopher's own words, then
  immediately paraphrase in plain language: "Or to put it simply..."
- **Be fair.** Present each thinker's strongest arguments, not straw men. If you
  disagree, disagree with the best version of their position.
- **Use surnames after first introduction.** "Immanuel Kant argued..." then "Kant
  believed..." thereafter.

### Thought Experiments

- Present the scenario vividly. The reader must feel the dilemma, not just understand
  it abstractly.
- Invite the reader to form their own response before presenting philosophical
  analysis: "What would you do? Take a moment before reading on."
- Show how different philosophical traditions would respond differently to the same
  scenario.
- Acknowledge that intuitions vary. the reader's response is not wrong, but it can
  be examined.

### Philosophical Terminology

- **Define every technical term on first use.** "Epistemology. the study of knowledge:
  what we can know, and how we can know it."
- **Use the term if it is genuinely useful.** "Cognitive dissonance" is more precise
  than "feeling conflicted about your own contradictions."
- **Do not use jargon to impress.** If a plain word works as well, use the plain word.
  The purpose of terminology is precision, not display.

### Balancing Traditions

- Do not default to Western philosophy as "philosophy" and treat other traditions
  as exotic additions.
- When discussing a concept, note where multiple traditions have engaged with it:
  "The question of suffering has been central to Buddhist philosophy for 2,500 years
 . but it was also Nietzsche's core obsession."
- Represent each tradition on its own terms before drawing comparisons.

### Prose Rhythm Mapping

- **Chapter 1 opens with:** the question that will not let go. A concrete dilemma, a
  lived experience, a moment that raises a philosophical problem the reader recognises.
- **Sentence calibration:** Medium-long thoughtful sentences averaging 16–26 words.
  Philosophy requires syntactic room. ideas need space to unfold within the sentence.
- **Accessible but not dumbed-down:** The prose should feel intellectually engaging, not
  lecturing. Simplify the language, never the thought. The reader is a thinking
  companion, not a student.
- **Rhythm pattern:** Longer reflective sentences alternate with shorter, sharper ones
  that crystallise the insight. "And that is the paradox Camus could not resolve. He
  did not try." The long sentence explores; the short one lands.
- **Tension baseline:** Maintain narrative tension ≥4 throughout. In philosophy, tension
  is dialectical. two compelling positions that genuinely conflict. The reader should
  feel pulled in both directions.
- **Tension drivers:** The unresolved question. The moment one compelling argument meets
  an equally compelling objection. The gap between how we live and how we think we
  should live.
- **Quotation rhythm:** Quote the philosopher's own words, then immediately translate
  into plain language. The original gives authority; the translation gives understanding.
  This two-beat rhythm is the genre's signature move.
- **Dialectical pacing:** Present Position A with enough conviction that the reader
  accepts it. Then introduce Position B with enough force to unsettle that acceptance.
  The synthesis earns its place only after both sides have been genuinely felt.
- **Paragraph as thought-unit:** Each paragraph should complete one movement of thought.
  If the reader cannot summarise what a paragraph accomplished, it needs reshaping.
- **Thinker introductions:** A sentence or two of biographical context before the ideas.
  The human being grounds the philosophy. Epictetus the slave changes how we hear
  Epictetus the philosopher.
- **Read-aloud test:** The prose should sound like a thoughtful person working through
  an idea that matters to them. If it sounds like a textbook or a TED Talk, revise.

## Quality Check Criteria

The Quality Check agent MUST verify each chapter against:

| # | Criterion | Pass Standard |
|---|-----------|---------------|
| 1 | Central question | Chapter driven by a clear, engaging philosophical question |
| 2 | Dialectical structure | At least two genuinely competing positions presented and engaged |
| 3 | Thinker attribution | Named philosophers with biographical context and direct quotes |
| 4 | Fair representation | Each position presented in its strongest form, not as a straw man |
| 5 | Synthesis present | Chapter arrives at a resolution or deeper understanding |
| 6 | Contemporary application | Philosophical ideas connected to modern life or current events |
| 7 | Terminology handled | All philosophical terms defined on first use in plain language |
| 8 | Thought experiment | At least 1 thought experiment, dilemma, or scenario per chapter |
| 9 | Practical relevance | Reader can apply or think differently after reading |
| 10 | Voice consistency | Thoughtful, clear, engaged tone; no pontificating or condescension |

## Source Requirements

### Mandatory Source Types

- **Primary philosophical texts:** Direct engagement with the works of the thinkers
  discussed. Quote from translations that are both accurate and readable.
- **Secondary scholarship:** Peer-reviewed philosophy papers, Stanford Encyclopedia of
  Philosophy, Cambridge Companions. for interpretive context and debates.
- **Biographical sources:** For contextualising thinkers' lives and the conditions
  that shaped their thought.
- **Contemporary philosophy:** Living philosophers engaging with the traditions
  discussed. Philosophy is not just history. it is an ongoing conversation.

### Translation Protocol

- For non-English philosophical texts, use reputable modern translations.
- Note the translator for significant quotes, as translation affects meaning.
- Where translation is contested (Nietzsche's "Ubermensch," Heidegger's "Dasein"),
  note the interpretive choice.
- For Eastern philosophical texts, use translations by scholars recognised within
  the relevant tradition.

### Source Freshness

- **Classical texts:** Plato, Aristotle, Confucius, the Buddha. always current.
  Use the best available translation.
- **Interpretive scholarship:** Use recent secondary sources (last 10–15 years) for
  contemporary philosophical debates and reinterpretations.
- **Applied philosophy:** For ethics, political philosophy, and practical applications,
  engage with current thinkers and current issues.

## Category-Specific Guardrails

### MANDATORY. Logical Coherence

- Arguments must be logically valid. If the chapter claims A leads to B, the
  reasoning must hold.
- Identify and avoid common fallacies: appeals to authority, false dilemmas, slippery
  slopes, straw men, ad hominem.
- The Quality Check agent must trace the logical structure of each chapter's argument.
  If the logic fails, the chapter fails.

### MANDATORY. Competing Positions Fairly Represented

- No philosophical position may be presented as a straw man. that is, in a
  deliberately weakened form made easy to refute.
- The "principle of charity": present each position in the strongest form its
  proponents would recognise.
- Where the author disagrees with a position, the disagreement must engage with
  the position's actual arguments, not a caricature.
- Include counter-arguments the reader might raise and address them honestly.

### MANDATORY. No Oversimplification of Traditions

- Do not reduce a philosophical tradition to a slogan. Stoicism is not "just think
  positive." Buddhism is not "just let go." Existentialism is not "nothing matters."
- Represent the internal diversity of traditions. Stoicism contains Epictetus, Seneca,
  and Marcus Aurelius. who disagree on important points.
- Acknowledge that brief treatment necessarily simplifies, and direct the curious
  reader to deeper sources.
- Do not appropriate Eastern philosophical traditions as mere self-help techniques
  stripped of their cultural, religious, and historical context.

### Additional Guardrails

- Do not present philosophical opinions as facts. "Kant argued that..." not "The
  truth is that..."
- Distinguish between descriptive claims (how things are) and normative claims (how
  things should be). Philosophy works with both. the reader should know which is
  which.
- Do not present Western modernity's answers as the culmination of philosophical
  progress. Different traditions have different strengths, and "newer" does not mean
  "better" in philosophy.
- When discussing political philosophy, do not smuggle in partisan conclusions under
  the guise of philosophical argument. Present the philosophical reasoning; let the
  reader draw their own political conclusions.
- Be careful with "philosophy says" claims. Philosophy does not speak with one voice.
  Always attribute to specific thinkers or traditions.

## Cover Design Specifications

### Visual Language

- **Colour palette:** Sophisticated and contemplative. Deep navy, charcoal, muted
  teal, ivory, with selective accent colours (gold, oxblood, forest green). Avoid
  bright or busy palettes.
- **Typography:** Elegant serif or refined sans-serif. The title should suggest
  intelligence and depth without pretension. Subtitle in contrasting weight.
- **Imagery:** Minimal and symbolic. classical sculpture detail, abstract geometric
  forms, architectural elements, single symbolic objects. Less is more.
- **Mood:** Intelligent, calm, inviting. The cover should say: "Think with me."

### Subcategory Variations

| Subcategory | Visual Emphasis |
|-------------|----------------|
| Stoicism / Practical | Classical column or bust, marble texture, clean lines |
| Existentialism / Meaning | Abstract or surreal imagery, shadow/light contrast |
| Ethics / Moral | Balanced/symmetrical design, scales or fork-in-road motifs |
| Political Philosophy | Architectural elements, civic imagery, bold typography |
| Eastern Philosophy | Minimalist aesthetic, natural elements (water, stone, bamboo), negative space |

### Typography Rules

- Title: 40–60% of cover area. Philosophical titles tend toward the evocative:
  single words, questions, paradoxes.
- Subtitle: Essential for clarifying scope. "Ancient Wisdom for Modern Life" format
  for practical philosophy; "What [X] Means for How We Live" for applied.
- Author name: Prominent if an established public philosopher. Moderate otherwise.
- Academic credentials (Professor of Philosophy at X) may appear if they strengthen
  authority.

## KDP Category Mapping

### Primary Categories

| Subcategory | KDP Browse Path |
|-------------|----------------|
| Stoicism / Practical | Kindle Store > Kindle eBooks > Nonfiction > Philosophy > Greek & Roman |
| Existentialism / Meaning | Kindle Store > Kindle eBooks > Nonfiction > Philosophy > Movements > Existentialism |
| Ethics / Moral | Kindle Store > Kindle eBooks > Nonfiction > Philosophy > Ethics & Morality |
| Political Philosophy | Kindle Store > Kindle eBooks > Nonfiction > Philosophy > Political |
| Eastern Philosophy | Kindle Store > Kindle eBooks > Nonfiction > Philosophy > Eastern > General |

### Secondary Categories (choose based on content)

| Option | KDP Browse Path |
|--------|----------------|
| General Philosophy | Kindle Store > Kindle eBooks > Nonfiction > Philosophy > General |
| History of Philosophy | Kindle Store > Kindle eBooks > Nonfiction > Philosophy > History & Surveys |
| Social Philosophy | Kindle Store > Kindle eBooks > Nonfiction > Philosophy > Social Philosophy |

### Keyword Recommendations

- Include the specific philosophical tradition (Stoicism, existentialism, ethics, etc.)
- Include "philosophy" and "practical philosophy" or "popular philosophy"
- Include the names of major thinkers discussed (Marcus Aurelius, Nietzsche, etc.)
- Include the core question or theme the book addresses
- Include comparable author names for discoverability
- Consider "meaning of life," "how to live," or "wisdom" as crossover keywords
