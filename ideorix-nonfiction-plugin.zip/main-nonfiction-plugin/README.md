# Ideorix Non-Fiction — The Research & Writing Engine

AI-powered non-fiction research and writing, with editorial passes,
fact-checking, cover design, and marketing.

## Quick Start

Say "Ideorix Non-Fiction" or "Research a project" to begin.

Available skills (invoked via natural language triggers):
- `research-a-project` — Start a new non-fiction manuscript
- `continue-researching` — Resume an in-progress manuscript
- `edit-manuscript` — Run the editorial pipeline
- `design-cover` — Generate cover concepts
- `market-scout` — Live market intelligence

If Ideorix Fiction is also installed, the bare word "Ideorix" launches
the fiction engine. Use "Ideorix Non-Fiction" or "Non-Fiction" for
this engine specifically.

## What's Inside

- Extensive category library with category-specific evidence and craft rules
- Multi-phase research and writing pipeline with fact-checking
- Full editorial suite with 5-agent verification per chapter
- KDP-ready output with metadata, cover concepts, and marketing materials

## Requirements

- Claude Desktop
- Claude Pro, Team, or Enterprise subscription

© 2025 James Harvey Media. All rights reserved.
