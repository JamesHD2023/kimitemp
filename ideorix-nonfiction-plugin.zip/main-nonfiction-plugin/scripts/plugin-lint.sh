#!/bin/bash
# plugin-lint.sh — verify every backticked `*.md` reference resolves
# Run from the plugin repo root. Mirrors fiction's plugin-lint.sh
# (skills/ideorix/scripts/plugin-lint.sh and the top-level
# scripts/plugin-lint.sh in the fiction plugin) for parity, with
# NF-specific RUNTIME_FILES + CROSS_ENGINE_FILES + NEGATION_FILES
# additions per the Cowork v2.7.57 follow-up review findings.
set -euo pipefail

PLUGIN_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PLUGIN_ROOT"

# Files that are runtime-generated in the user's project folder (not plugin refs).
# Aligned with the fiction list, plus 4 NF-specific runtime output files referenced
# inside analyze-a-book.md (these are files the user PRODUCES via the analyze
# flow, not files the plugin SHIPS):
#   - genericized-template.md
#   - per-chapter-micro-analysis.md
#   - source-book-name.md
#   - structural-blueprint.md
RUNTIME_FILES="pipeline-checkpoint.md entity-canon.md running-banlist.md \
    market-pulse.md model-health.md project-config.md research-bible.md \
    outline.md sources.md run.log story-bible.md progress-dashboard.md \
    word-counts.md concept-seeds.md thesis-seeds.md protagonist.md \
    antagonist.md supporting-cast.md hook-positioning.md chapter-outline.md \
    ending.md tension-tracker.md key-figures.md genre-architecture.md \
    beat-structure.md entities.md project-mode.md trope-plan.md \
    style-guide.md screenplay-source.md import-errors.md \
    chapter-01.md chapter-02.md entry.md novel.md world-setting.md \
    ch01.md ch02.md ch01-draft.md \
    canon-absorbed.md content-writer.md sales-log.md series-bible.md \
    verification-ledger.md \
    chekhovs-guns-tracker.md authority-bible.md fact-checks.md \
    research-checkpoint.md citations.md \
    genericized-template.md per-chapter-micro-analysis.md \
    source-book-name.md structural-blueprint.md \
    read-verification-log.md web-fetch-log.md speculative-content-map.md"

# Cross-engine pointers — these resolve in the OTHER engine's plugin tree
# (documented intentional cross-references). The lint must not flag them as
# dead even though they don't exist locally. Mirrors the same list in the
# canonical repo-level scripts/spec-lint.sh.
CROSS_ENGINE_FILES="prose-protocol.md series-architect.md transportive-settings.md"

# Collect all backticked .md references from every SKILL.md and reference file.
# The `|| true` keeps the pipeline alive if no matches found; empty-file
# short-circuit below explicitly distinguishes "no refs to check" from a
# clean run. Same pattern as fiction's plugin-lint (v2.7.57).
#
# v2.7.60: switched from a fixed /tmp/plugin-lint-refs-nf.txt path to
# mktemp per the Cowork follow-up review (post-v2.7.59). The fixed path
# silently failed with "Permission denied" if a stale file from a prior
# session was owned by a different UID — write fails, but the script's
# `|| true` still let it proceed; downstream the empty-file check
# incorrectly reported PASS. mktemp gives a unique per-run path so the
# same-class silent-failure shape can't recur.
REFS_FILE=$(mktemp -t plugin-lint-refs-nf.XXXXXX) || {
    echo "ERROR: mktemp failed; cannot run plugin lint" >&2
    exit 1
}
trap 'rm -f "$REFS_FILE"' EXIT
( grep -roE '`[a-z][a-z0-9_-]*\.md`' skills/ 2>/dev/null \
    | sed 's/.*`\([^`]*\)`/\1/' \
    | sort -u > "$REFS_FILE" ) || true

if [ ! -s "$REFS_FILE" ]; then
    echo "Plugin lint: PASS — no backticked .md references to check"
    exit 0
fi

FAIL=0
while read -r ref; do
    # Skip runtime-generated files
    for rt in $RUNTIME_FILES; do
        [ "$ref" = "$rt" ] && continue 2
    done
    # Skip cross-engine pointers (live in the other engine's tree)
    for cx in $CROSS_ENGINE_FILES; do
        [ "$ref" = "$cx" ] && continue 2
    done
    # Check whether ref exists anywhere under skills/
    if ! find skills/ -name "$ref" -type f | grep -q .; then
        echo "DEAD REFERENCE: $ref"
        FAIL=1
    fi
done < "$REFS_FILE"

if [ "$FAIL" -eq 1 ]; then
    echo ""
    echo "Plugin lint: FAIL — dead references found"
    exit 1
else
    echo "Plugin lint: PASS — all references resolve"
    exit 0
fi
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
