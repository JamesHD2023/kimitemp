---
name: leitmotif-tracker-delta
description: "Per-chapter incremental delta of the leitmotif-tracker audit (engine-neutral Class B). Runs after each chapter as part of the per-chapter cycle: extracts the motif plan from the bible, identifies only NEW motif instances landed in the current chapter, and compares each new instance against the running prior-instance ledger for presence + evolution. Catches motif drift at write-time so the writer can fix one chapter instead of retro-revising. The full-manuscript leitmotif-tracker.md still runs at Phase 5 Stage 9.5 (Canon Validation Sweep) as the final-arc verification."
version: "2.7.61"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Leitmotif Tracker — Per-Chapter Delta

> **Paired spec:** this file is one half of a parent/delta pair with
> `leitmotif-tracker.md`. The two share the audit's semantic contract (what counts
> as a motif/injury, evolution rules, report vocabulary) — any change to
> that contract MUST be applied to both files in the same commit, or the
> per-chapter and capstone passes will disagree about what they are
> auditing. Scope differences (per-chapter vs full-manuscript) are the
> intended divergence; semantics are not.

A per-chapter incremental variant of `leitmotif-tracker.md`. Both
share the same audit semantics (presence + evolution checked against
the bible's declared motif plan); they differ in scope: the parent
spec scans the entire manuscript at end-of-pipeline, this spec scans
only the just-written chapter against a running ledger.

## Why per-chapter

Motif drift is cheap to fix the moment it lands and expensive to fix
after subsequent chapters are written around the drift. The
manuscript-scope leitmotif-tracker catches drift but only at Phase 5
— by which point five or ten dependent chapters may exist around the
broken motif beat. Running incrementally per chapter catches each
divergence the moment it happens.

The trade-off: per-chapter cannot verify the **complete arc** (a
motif's planned evolution arc spans multiple chapters by design;
only at end-of-manuscript can you confirm the whole arc landed).
The parent spec still runs at Phase 5 Stage 9.5 for full-arc
verification.

## When this audit runs

After each chapter completes its full per-chapter cycle (Architect →
Writer → Humaniser → Verification 6-agent suite), the Class B Delta
Pass dispatches this audit as part of the per-chapter discipline.
See `mandatory-pipeline-rules.md` Rule 1's "Class B Delta Pass" step.

## Class B dispatch

Same dispatch pattern as the parent spec. The bash dispatcher emits:

```
CLASS_B_AUDIT|leitmotif-tracker-delta|COHERENCE|references/leitmotif-tracker-delta.md|-
```

The engine layer reads the line, dispatches a subagent per the brief
below, applies the engine HARD GATE on return, merges the verdict
into the per-chapter Progress Dashboard.

## Subagent task brief

> **Task: Leitmotif Tracker — Per-Chapter Delta**
>
> **Background.** A motif works only if it (a) lands where promised
> AND (b) evolves across instances. You are scanning only the chapter
> just completed against a running motif-instance ledger from prior
> chapters.
>
> **Inputs.**
> - `engine-data/research-bible.md` (NF) or
>   `engine-data/story-bible.md` (fiction) — source of declared
>   motif plan
> - `engine-data/chapters/ch{NN}.md` — current chapter (the only one
>   you scan)
> - `engine-data/reports/leitmotif-ledger.md` — running ledger of
>   all motif instances landed in prior chapters (created if missing,
>   appended to on every per-chapter delta run)
>
> **Procedure.**
> 1. Extract the motif plan from the bible (same procedure as the
>    parent spec — look for explicit declarations).
> 2. Read the running ledger to load prior-instance history.
> 3. Scan ONLY the current chapter for new motif instances. For
>    each new instance found, record:
>    - Motif name
>    - Chapter:line citation
>    - One-clause instance description (physical detail + emotional
>      context + thematic association invoked)
> 4. For each new instance, evaluate two criteria:
>    - **Presence.** If the bible declared this chapter should carry
>      a specific motif and the current chapter has no instance of
>      it → PRESENCE-MISS finding (FAIL severity).
>    - **Evolution.** Compare each new instance against the most
>      recent prior instance of the same motif from the ledger.
>      Three-way identity threshold (same physical detail AND same
>      emotional context AND same thematic association) → flag as
>      EVOLUTION-FLAT (WARN severity).
> 5. Append the current chapter's new instances to the running
>    ledger using the bash-direct write protocol (Class 1 file;
>    see `mandatory-pipeline-rules.md` File Operation Policy).
> 6. Produce the structured return.
>
> **Return contract (mandatory).**
>
> ```
> ## Bible Motif Plan (extracted)
> | Motif | Function | This-chapter expectation |
> |---|---|---|
> [row per declared motif; "This-chapter expectation" =
>  "land here" / "absent here per plan" / "no plan for this
>  chapter"]
>
> ## New Instances This Chapter
> | Motif | Chapter:Line | Instance description |
> |---|---|---|
> [populated rows; or single row "(no new motif instances)"]
>
> ## Findings
> | Severity | Motif | Type | Detail |
> |---|---|---|---|
> [type ∈ {PRESENCE-MISS, EVOLUTION-FLAT}; or
>  "(no findings)"]
>
> ## Verdict
> One of: PASS | WARN | FAIL
> - PASS: every bible-promised motif for this chapter landed AND
>   every new instance evolves from its prior instance
> - WARN: one or more EVOLUTION-FLAT findings, no PRESENCE-MISS
> - FAIL: one or more PRESENCE-MISS findings
>
> ## One-Line Summary
> Format: "<verdict>: ch{NN} — <count> finding(s) — <top finding>"
> or "PASS: ch{NN} — N new instance(s), all evolve"
> or "PASS: ch{NN} — no motif activity this chapter (bible plan
>  doesn't promise any here)"
> ```
>
> **Discipline.**
> - Cite every instance with chapter:line.
> - Do NOT re-audit prior chapters — that is the full-manuscript
>   audit's scope. You read prior instances from the ledger as
>   read-only history.
> - Do NOT invent motifs the bible did not declare.
> - When uncertain about evolution-flat, downgrade WARN to PASS.

## Engine HARD GATE on return

Per `subagent-output-verification.md`. Same shape as the parent
spec: shape check, citation check, verdict consistency, hallucination
markers (chapter:line citations must point at lines that exist in
the current chapter).

After verification, the engine emits:

```
AUDIT|leitmotif-tracker-delta|COHERENCE|<verdict>|<one_line_summary>|<subagent_return_path>
```

The per-chapter verdict surfaces on the Progress Dashboard alongside
the 6-agent V-Score. A PRESENCE-MISS or EVOLUTION-FLAT finding does
NOT block chapter approval — the writer chooses whether to revise
now or carry the finding to the next chapter cycle.

## Running ledger format

`engine-data/reports/leitmotif-ledger.md` accumulates across the
manuscript. Format:

```markdown
# Leitmotif Instance Ledger

## Instances by motif

### {motif name}
| Chapter:Line | Instance description |
|---|---|
| ch01:42 | The watch on his wrist, stopped at 3:17, hand caught mid-tick |
| ch05:118 | ... |

### {motif name}
...
```

The ledger is appended to (never rewritten) on every delta run.
The full-manuscript leitmotif-tracker at Stage 9.5 uses it as a
prior-evidence corpus but re-scans the manuscript end-to-end for
the final verdict — the ledger is a per-chapter convenience, not
the source of truth.

## Category-aware default (v2.7.63)

The per-chapter delta is **on by default for narrative work** (all
fiction; narrative non-fiction such as memoir, biography, true
crime, literary journalism, narrative history, microhistory, travel
writing, nature writing, sports narrative) and **auto-skipped for
argumentative non-fiction** (self-help, business, economics-finance,
personal-finance, psychology-popular, philosophy-popular,
popular-science, health-wellness, fitness, how-to-guide, cooking,
education, parenting, technology, religion-spirituality).

Rationale: leitmotifs are a narrative-craft concern. Argumentative
non-fiction uses recurring concepts and frameworks rather than the
literal-or-metaphorical motif arcs this audit's present-AND-evolves
model is built to catch. Running it on a self-help or business book
typically returns "no motif plan in bible — audit not applicable" —
useful as catalog data but not a productive per-chapter check.

`class-b-delta-gate.sh` reads `engine-data/project-config.md` to
apply the default:

- `nf_shape: argumentative` → explicit auto-skip
- `nf_category: <argumentative slug>` → auto-skip via category lookup
- Otherwise (fiction, narrative NF, or no category) → audit runs

Both defaults are overridable:

- `class_b_delta_status: enable` — force the audit on (useful if the
  writer is intentionally using a recurring metaphor as a thesis-
  illustration device in an argumentative-NF project)
- `class_b_delta_status: skip` — force off regardless of category

## Failure modes prevented

- **Late-stage motif retrofit cost** — drift caught at Phase 5
  Stage 9.5 may require revising 10+ chapters; per-chapter delta
  catches at write-time, fix is one chapter.
- **Empty-leitmotif accumulation** — the per-chapter EVOLUTION-FLAT
  WARN surfaces the moment a second instance is too close to the
  first, preventing the writer from compounding the empty-recurrence
  pattern across three or four instances before noticing.
- **Audit-not-applicable noise** — pre-v2.7.63 the gate would FAIL
  on every argumentative-NF chapter even though the audit returned
  "no motif plan — audit not applicable" PASS. v2.7.63's category-
  aware default skips the audit invocation entirely for those
  categories, eliminating the noise.

## Relationship to parent spec

This spec is the per-chapter incremental check; `leitmotif-tracker.md`
is the manuscript-scope full audit. Both ship; both run; they cover
different scopes:

| Spec | When | Scope | Catches |
|---|---|---|---|
| `leitmotif-tracker-delta.md` (this spec) | Per chapter, Rule 1 Class B Delta Pass | Just-written chapter against running ledger | Drift at write-time |
| `leitmotif-tracker.md` (parent) | End of manuscript, Phase 5 Stage 9.5 Canon Validation Sweep | Full manuscript end-to-end | Complete-arc verification + final cross-check that delta runs didn't miss anything cumulative |

## See also

- `leitmotif-tracker.md` — manuscript-scope parent spec; runs at
  Stage 9.5
- `mandatory-pipeline-rules.md` Rule 1 — defines the per-chapter
  Class B Delta Pass that dispatches this audit
- `validate-dispatcher.md` — registers `leitmotif-tracker-delta`
  alongside the parent spec in the audit registry
- `injury-accumulation-delta.md` — companion per-chapter delta for
  the PHYSICS domain (same pattern)
- `subagent-output-verification.md` — HARD GATE applied to subagent
  returns
