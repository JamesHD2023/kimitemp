---
name: leitmotif-tracker
description: "Engine-neutral Class B binding/protocol. Subagent-dispatched semantic audit that extracts the manuscript's declared motif plan from the bible (research-bible NF, story-bible fiction), then scans every chapter to verify each declared motif (a) actually lands in the prose and (b) evolves rather than repeats unchanged across instances. Closes the fourth gap in the canon-validation Wave 4 sequence (v2.7.33; COHERENCE gap-analysis row 4). Invoked by /validate dispatcher via CLASS_B_AUDIT line; subagent return verified by subagent-output-verification HARD GATE before merge into briefing."
version: "2.7.33"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Leitmotif Tracker

> **Paired spec:** this file is one half of a parent/delta pair with
> `leitmotif-tracker-delta.md`. The two share the audit's semantic contract (what counts
> as a motif/injury, evolution rules, report vocabulary) — any change to
> that contract MUST be applied to both files in the same commit, or the
> per-chapter and capstone passes will disagree about what they are
> auditing. Scope differences (per-chapter vs full-manuscript) are the
> intended divergence; semantics are not.

A Class B binding/protocol spec for the COHERENCE domain (per
`canon-validation-taxonomy.md`). Closes the fourth gap in the
Wave 4 audit-additions sequence (gap-analysis row 4) — the
final remaining COHERENCE sub-gap. The same-function-consecutive
sub-gap was closed in v2.7.31 (`coherence-function-consecutive.md`);
with v2.7.33, the COHERENCE domain is fully COVERED.

This is the **second Class B audit** under the canon-validation
framework. It follows the v2.7.32 reference implementation
(`injury-accumulation.md`) — see that spec for the
canonical Class B structure.

## Why this exists

A leitmotif is a recurring symbolic motif that carries thematic
weight across a manuscript. In fiction: a particular flower, a
piece of music, a phrase, a recurring weather pattern, a ritual
gesture, an object that surfaces at every structural turn. In
non-fiction: a recurring metaphor or example used to illustrate
the central thesis (the chess master's intuition recurring
across an expertise book; the trolley problem recurring across
an ethics book).

A motif works in two ways at once. It must be **present** —
it actually appears in the prose where the bible promised it
would. And it must **evolve** — each appearance gains new
associations, new emotional weight, new thematic depth. A
motif that recurs unchanged is a refrain; a refrain CAN be
intentional (some manuscripts use exact repetition for
incantatory effect) but more often it signals empty
recurrence: the writer remembered to land the motif but
forgot to make it earn its return.

Two recognisable failure modes:

1. **Bible-promised-but-prose-absent.** The bible declares
   a motif (the broken pocket-watch as a recurring image of
   stalled time). Chapter 1 introduces it. Chapters 5, 11,
   and 18 are supposed to carry it (per the bible). The
   prose lands chapter 5 cleanly; misses chapter 11; lands
   chapter 18. The motif's structural function — three
   carefully-placed echoes carrying a thematic arc — is
   broken. The reader feels the structural absence even if
   they cannot name what's missing.
2. **Prose-recurs-but-doesn't-evolve.** The bible declares
   the same motif and the prose lands every promised
   instance. But each instance describes the watch
   identically: same physical detail, same emotional weight,
   same association. The motif has become a tag the writer
   applies to the chapter rather than a symbol that grows.
   The reader experiences echoing-without-meaning — the
   classic empty-leitmotif failure.

Both failures are COHERENCE-domain bugs. Single-chapter audits
cannot catch them; the divergence is between the bible's
declared plan and the manuscript's delivered prose, and
across all instances of each motif in sequence.

## Why Class B (subagent), not Class A (bash)

A bash audit cannot perform this check:

- **Extracting the motif plan from the bible** requires
  reading semi-structured prose (motif declarations vary
  widely: a dedicated "Motifs" section in the bible, scattered
  references in chapter outlines, an explicit motif-arc
  paragraph in the architectural overview).
- **Identifying motif instances in chapter prose** requires
  semantic recognition (the broken pocket-watch may surface
  literally as "the watch" in chapter 5 and metaphorically as
  "stalled time" in chapter 11; both are instances).
- **Judging evolution** requires comparing two prose passages
  for new association / new emotional weight / new thematic
  depth — a semantic similarity-and-difference judgment.
- **Tracking N motifs across M chapters** is stateful semantic
  reasoning over the manuscript timeline.

The mechanical-bash version would either miss most instances
(too literal) or false-positive on every recurring noun
(too loose). A subagent reading the bible + prose end-to-end
with explicit motif tracking is the right tool.

## How Class B audits are dispatched

Per `validate-dispatcher.md` Step 4b (Class B subagent
dispatch). The bash dispatcher emits:

```
CLASS_B_AUDIT|leitmotif-tracker|COHERENCE|references/leitmotif-tracker.md|-
```

The slash-command engine layer reads this line, dispatches a
subagent per the brief below, applies the engine HARD GATE
on the return, and merges the verdict into the Validation
Briefing. The bash dispatcher itself does NOT fire the
subagent — the two-phase split is canonical.

## Subagent task brief (for the leitmotif-tracker audit)

The slash-command engine constructs the following subagent
brief when this audit is dispatched. Customise only project-
specific paths.

> **Task: Leitmotif Tracker Audit**
>
> **Background.** This audit detects COHERENCE-domain
> failures in motif delivery. A motif works only if it (a)
> lands where promised AND (b) evolves across instances. You
> are scanning the full manuscript end-to-end with explicit
> motif tracking against the bible's declared plan.
>
> **Inputs.**
> - `engine-data/research-bible.md` (NF) or
>   `engine-data/story-bible.md` (fiction) — source of the
>   declared motif plan
> - `engine-data/chapters/ch*.md` — manuscript chapters in
>   chapter order
>
> **Procedure.**
> 1. Extract the motif plan from the bible. Look for explicit
>    motif declarations in any of these forms:
>    - A dedicated "Motifs" / "Recurring Symbols" / "Leitmotifs"
>      section
>    - Per-chapter outline entries naming a motif the chapter
>      should carry (e.g. "the broken pocket-watch returns
>      here, this time tied to the daughter's perspective")
>    - An architectural-overview paragraph that lists motifs
>      by name with their thematic function
>    - Inline tagging conventions (e.g. `[motif: watch]` in
>      the bible's chapter outlines)
>    For each motif found, record:
>    - Motif name (one short phrase: "broken pocket-watch")
>    - Thematic function declared by the bible (one clause)
>    - Planned chapter appearances (chapter numbers, if
>      explicitly listed; otherwise empty)
>    - Planned evolution arc (one clause; "introduced as
>      time-stalled image, returns as inherited grief, lands
>      finally as accepted-loss"; or empty if not stated)
> 2. If no motifs are declared in the bible, the audit
>    completes with verdict PASS and Findings table empty
>    (with note "no motif plan in bible — audit not
>    applicable").
> 3. For each declared motif, scan chapters in order to
>    identify every instance — both literal and metaphorical
>    references. Record per instance:
>    - Motif name
>    - Chapter:line citation
>    - One-clause description of how the motif appears in this
>      instance (the physical detail, the emotional context,
>      the thematic association invoked)
> 4. Per motif, evaluate two criteria:
>    - **Presence.** Compare the bible's planned chapter list
>      (if any) to the actual instance list. Bible-promised
>      chapters that have no instance in the prose → FAIL
>      finding (motif missed where structurally promised).
>      Prose instances in unplanned chapters → no finding
>      (writer's discretion to extend; not a bug).
>    - **Evolution.** Compare adjacent instances in chapter
>      order. If two consecutive instances describe the motif
>      with substantively the same physical detail, the same
>      emotional context, AND the same thematic association —
>      no new layer added — flag as WARN (motif recurring
>      without evolution; consider whether the second instance
>      earns its return). If the bible declared an explicit
>      evolution arc and the prose's actual evolution
>      diverges from that arc (skipped beats, reordered
>      arc), flag as FAIL.
> 5. Aggregate findings; produce per-motif summary; produce
>    the structured return.
>
> **Return contract (mandatory; subagent output is rejected
> by the engine if not conformant).** Return a structured
> response with the following sections, each populated even
> if empty:
>
> ```
> ## Motif Plan (from bible)
> | Motif | Function | Planned chapters | Planned evolution |
> |---|---|---|---|
> [populated rows; or single row "(no motif plan in bible)"]
>
> ## Motif Instance Ledger
> | Motif | Chapter:Line | Instance description |
> |---|---|---|
> [every instance found, in chapter order]
>
> ## Findings
> | Severity | Motif | Type | Detail |
> |---|---|---|---|
> [populated rows; or single row "(no findings)"; type ∈
> {PRESENCE-MISS, EVOLUTION-FLAT, EVOLUTION-DIVERGENT}]
>
> ## Verdict
> One of: PASS | WARN | FAIL
> - PASS: every planned motif present (or no plan); every
>   landed instance evolves (or evolution acceptably
>   matches bible plan)
> - WARN: one or more EVOLUTION-FLAT findings, no
>   PRESENCE-MISS or EVOLUTION-DIVERGENT findings
> - FAIL: one or more PRESENCE-MISS or EVOLUTION-DIVERGENT
>   findings
>
> ## One-Line Summary
> Single line for the briefing's per-audit summary. Format:
> "<verdict>: <count> finding(s) — <top finding motif +
> chapters>" or "PASS: <N> motif(s) tracked, all landed and
> evolving" or "PASS: no motif plan in bible — audit not
> applicable"
> ```
>
> **Discipline.**
> - Cite every claim with chapter:line. The engine HARD
>   GATE rejects findings without citations.
> - Do NOT invent motifs the bible did not declare. The audit
>   tracks declared motifs only; emergent motifs the writer
>   added without declaring them are out of scope (not bugs).
> - Do NOT flag every recurrence as evolution-flat. Some motifs
>   work via exact recurrence (refrain, ritual, incantation).
>   Flag evolution-flat only when adjacent instances are
>   substantively identical in physical detail AND emotional
>   context AND thematic association — three-way identity is
>   the threshold.
> - When in doubt about evolution-flat, downgrade WARN to PASS.
>   The audit's purpose is to surface clear failures, not to
>   second-guess craft choices.

## Engine HARD GATE on subagent return

Per `subagent-output-verification.md`:

1. **Shape check.** All five required sections present (Motif
   Plan, Motif Instance Ledger, Findings, Verdict, One-Line
   Summary). Missing section → reject; re-dispatch ONCE with
   amendment instruction; on second failure emit
   `AUDIT|leitmotif-tracker|COHERENCE|FAIL|subagent return non-conformant after retry|-`.
2. **Citation check.** Every Motif Instance Ledger row must
   contain a chapter:line citation. Every Findings row must
   reference a motif that appears in the Motif Plan or Motif
   Instance Ledger. Findings citing non-existent motifs are
   stripped; if all findings are stripped, downgrade verdict
   accordingly.
3. **Verdict consistency check.** Empty Findings → PASS; any
   PRESENCE-MISS or EVOLUTION-DIVERGENT → FAIL; only
   EVOLUTION-FLAT → WARN.
4. **Hallucination markers.** Reject any finding whose
   citation references a chapter or bible section that does
   not exist in the project (e.g. "ch15:42" when the
   manuscript has 12 chapters).
5. **No-motif-plan special case.** If the bible has no motif
   plan, the audit's PASS verdict is preserved as-is with
   the "audit not applicable" summary; no further checks
   required.

After verification, the engine emits:

```
AUDIT|leitmotif-tracker|COHERENCE|<verdict>|<one_line_summary>|<subagent_return_path>
```

...with the full subagent return saved at
`engine-data/reports/validate/leitmotif-tracker-subagent.md`.

## How writers should respond to FAILs

Three reasonable responses:

1. **Land the missed motif.** If the bible promised the
   broken pocket-watch returns in chapter 11 and chapter 11's
   prose has no instance, add an instance — even a brief one
   counts. The structural arc the bible designed depends on
   the chapter being a beat in the motif's progression.
2. **Update the bible to match the prose.** Sometimes the
   prose evolved away from the bible's plan for good reasons
   (the chapter found a stronger thematic move that
   superseded the planned motif). Update the bible's motif
   plan to remove the unfulfilled promise. The audit then
   reads as PASS.
3. **Earn the return.** For EVOLUTION-FLAT findings, revise
   the second-instance prose to add a new layer — a new
   physical detail, a new emotional association, a new
   thematic resonance. The motif now grows rather than
   echoes.

The audit does not block phase advancement. WARN findings
surface for the writer's consideration; FAIL findings
surface as clear gaps the writer almost certainly wants to
address.

## How to adopt the convention on existing projects

For projects whose bibles do not yet declare motifs
explicitly, the audit reports "no motif plan in bible —
audit not applicable" (PASS). This is correct: a manuscript
without a declared motif plan cannot be audited against
that plan. The audit becomes meaningful when the writer
adds a Motifs section to the bible.

Two adoption paths:

1. **Forward-only.** New projects declare motifs in the
   bible; audit reports against the plan from project
   inception.
2. **Backfill.** For an existing project, identify the
   motifs the manuscript already carries (often visible
   on a re-read), declare them in the bible retroactively
   with their actual prose-instance pattern, then run the
   audit to verify completeness + evolution.

## Engine-neutral applicability

Both fiction and narrative non-fiction (memoir, biography,
literary journalism) carry leitmotifs in the strict sense.
Argumentative non-fiction (business, self-help, reference)
typically uses recurring metaphors or examples that function
as the equivalent — the audit treats these as motifs.
Reference manuscripts without recurring symbolic / metaphorical
threads return "no motif plan" PASS and are unaffected.

## Failure modes prevented

Per `silent-failure-audit.md` row 29:

- **Bible-prose drift in motif delivery** — the bible
  declares a motif arc; prose lands some instances and
  misses others; the structural arc breaks. Caught at
  validate time when the cost of a fix is a brief revision
  + a chapter touch-up.
- **Empty-recurrence cascade** — motif lands every promised
  instance but each instance is identical to the last; the
  motif accumulates page-time without accumulating meaning;
  the reader experiences echoing-without-significance.
  Caught as EVOLUTION-FLAT WARN; writer chooses whether to
  earn the returns.
- **Validation-coverage misrepresentation** — without this
  audit, COHERENCE was COVERED only for same-function-
  consecutive (v2.7.31). With v2.7.33, COHERENCE is fully
  COVERED — both sub-gaps closed.
- **Subagent-hallucination cascade** — subagent fabricates a
  motif the bible never declared, or cites an instance at a
  non-existent chapter. Caught by the HARD GATE's
  hallucination-marker check.

## See also

- `canon-validation-taxonomy.md` — the 10-domain index;
  COHERENCE primary-domain table now lists this audit
  alongside same-function-consecutive
- `validate-dispatcher.md` Step 4b — the Class B Dispatch
  Protocol (two-phase flow); this audit is the second to use it
- `injury-accumulation.md` (v2.7.32) — first Class B audit;
  the reference implementation this spec follows
- `coherence-function-consecutive.md` (v2.7.31) — the other
  COHERENCE audit; complementary, not overlapping (function-
  consecutive checks structural function-uniqueness; this
  audit checks symbolic-motif delivery + evolution)
- `subagent-output-verification.md` — the HARD GATE applied
  to subagent returns
- `silent-failure-audit.md` — catalog of drift-failure shapes;
  this audit adds row 29
