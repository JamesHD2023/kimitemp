---
name: epic-fantasy-genre
description: Genre-specific instructions for epic fantasy fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [fantasy]
---

# Epic Fantasy. Genre Plugin

## Metadata
- id: epic-fantasy
- name: Epic Fantasy
- icon: ⚔️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Hero's Journey", "Dan Harmon Story Circle", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Classic Quest**. Chosen one, fellowship, dark lord, world-saving journey
- **Political Intrigue**. Court politics, succession, factions, alliances and betrayals
- **Military**. Large-scale warfare, strategy, armies, battlefield perspectives
- **Mythic**. Godly intervention, prophecy-driven, creation myths woven into plot
- **Grimdark**. Morally grey world, consequences are permanent, no chosen ones
- **Low Magic**. Magic is rare, costly, and feared; focus on human-scale conflict
- **High Magic**. Magic is pervasive and systematic; mages as power players

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Varied. action set pieces balanced with political manoeuvring and quiet character beats
- Must open with: Action, discovery, arrival, or consequence. never with geography lectures or creation myths

BEATS PER CHAPTER
1. World-in-Motion Beat. Show the world actively happening (politics shifting, seasons changing, armies moving) not just existing as backdrop
2. Character Agency Beat. The POV character makes a decision that matters and faces its consequences
3. Tension Escalation. Raise at least one stake from the previous chapter
4. Sensory Grounding. At least one passage that puts the reader physically inside this world through smell, texture, temperature, or sound
5. Thread Advancement. Advance at least one subplot or secondary plotline

EPIC FANTASY ARCHITECTURE
- Multiple POV characters (2-5 depending on length tier):
  - Novella: 2-3 POVs maximum
  - Standard: 3-4 POVs
  - Epic: 4-5 POVs
- POV rotation should follow a pattern but break it occasionally for dramatic effect
- Each POV character occupies a different geographic and social space in the world
- POV character storylines must INTERSECT at key structural moments (midpoint, climax)
- World-building delivered through character experience, NEVER through narrator exposition dumps

MAGIC SYSTEM REQUIREMENTS (CRITICAL)
- Establish rules BEFORE magic solves any problem
- Every magical ability has a COST (physical, emotional, moral, or material)
- Magic cannot solve the story's central conflict directly. it creates complications and tools, but human choice drives resolution
- Consistent internal logic: if fire magic can't work underwater in Chapter 3, it can't work underwater in Chapter 25
- The reader must understand enough about the magic to anticipate what IS and ISN'T possible
- If hard magic: rules on page by end of Act 1. If soft magic: limits demonstrated through failure
- Magical deus ex machina = AUTOMATIC FAIL

WORLD-BUILDING DELIVERY
- NEVER open a chapter with geography, history, or cosmology lectures
- World-building arrives through:
  - Characters interacting with their environment (market scenes, road travel, diplomatic meetings)
  - Cultural friction between characters from different regions/peoples
  - Objects, food, clothing, architecture that reveal the world's texture
  - Casual references to history/religion that characters take for granted
  - Arguments between characters about how the world works
- The "iceberg" rule: for every detail on the page, ten details exist below the surface, but the reader only sees what characters encounter
- New world-building terms: introduce no more than 3 new terms per chapter, always with immediate contextual clarity

SCALE MANAGEMENT
- Epic fantasy is BIG. multiple kingdoms, long distances, large casts
- But every scene must be INTIMATE. experienced through one character's senses
- Large-scale events (battles, coronations, magical catastrophes) shown through specific, ground-level experience
- Maps exist in the reader's mind through travel experience, not cartography lectures
- Time passage: if weeks/months pass, show the passage through physical and emotional change, not "three months later"

FORBIDDEN IN EPIC FANTASY
- Geography/history lectures in narration (deliver through character experience)
- Magic without established rules solving critical problems
- "Chosen one" prophecies that remove character agency (prophecy can exist but characters must CHOOSE their path)
- Flat evil villains with no coherent motivation
- Modern language, slang, or anachronisms in dialogue
- Convenient teleportation/travel when distance has been established
- Characters who know things they couldn't know (especially across POVs)
- Identical speech patterns across cultures and social classes
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (worldbuilding), Anticipation (quest stakes), Validation at hard-won victories, Revelation at lore reveals.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Third close past tense, rotating between POV characters
- Voice: Each POV character has a DISTINCT narrative voice. the prose itself changes texture when POV changes (a warrior notices tactical details, a scholar notices inscriptions, a diplomat notices body language)
- Tone: Grand in scope but intimate in execution. the fate of kingdoms matters because we care about the people in them
- Register: Elevated but not archaic. no "thee" and "thou" unless deliberately historical; avoid modern casual register

PROSE IMPERATIVES
- Physical grounding in every scene: weather, light, texture, temperature, smell. this world must feel real enough to walk through
- Dialogue serves politics: every conversation in epic fantasy is a negotiation, even between friends
- Battle scenes through specific physical experience (not bird's-eye tactical overview)
- Emotional stakes match physical stakes: the reader must care about who lives and dies before the battle
- Quiet scenes between action carry the real weight. characters processing loss, making plans, forging alliances

PROSE RHYTHM MAPPING
- Chapter 1 must balance scope + intimacy. the world is vast, but the reader enters through one pair of eyes
- Long flowing sentences for landscape and history: when describing the sweep of a mountain range, the weight of centuries, or the grandeur of a citadel, let sentences stretch (22-30 words), using subordinate clauses and layered imagery
- Short sentences for combat and tension: when steel meets steel or a political threat lands, compress to 8-14 words. Subject-verb-object. Impact.
- POV-voice differentiation is CRITICAL to rhythm: a scholar-POV uses longer, more complex sentence structures; a soldier-POV uses blunter, more direct rhythms; a diplomat-POV favours balanced, measured cadences
- Opening paragraphs of Chapter 1: establish the grand rhythm. a sense that this story will take time and space, that the world is deep. Medium-long sentences flowing into one genuinely long one
- Political dialogue scenes: medium rhythm (16-22 words), controlled and deliberate, reflecting the characters' careful word-choice
- Battle scenes shift rhythm dramatically: pre-battle tension uses long, slow sentences (the dread of waiting); contact uses short, brutal bursts; aftermath returns to long, exhausted prose
- Quiet character moments (the campfire, the corridor conversation): medium sentences with occasional long reflective ones. this is where the reader breathes
- Transitions between POVs should establish the new voice's rhythm within the first two sentences. the reader should FEEL the shift before consciously registering whose chapter this is
- Avoid uniform sentence length across a full paragraph. epic fantasy paragraphs should undulate: long-medium-short-long, or short-short-long-medium
- Tension baseline: ≥5 from the first page. Even a landscape description must carry the weight of what's coming. beauty undercut by political fragility or approaching war
- Paragraph length itself is a rhythm tool: short paragraphs punch during action; long paragraphs immerse during world-building
- The opening chapter's rhythm announces: "This is a story of weight and consequence, told at human scale"
- Ceremonial or ritual scenes: longer, more cadenced prose. the rhythm becomes almost incantatory
- End-of-chapter rhythm: accelerate sentence pace in the final paragraph to create a forward pull, regardless of whether the chapter ends on action or revelation
- Read battle passages aloud at speed. if you stumble, the sentences are too long for combat rhythm
- Read landscape passages aloud slowly. if they feel rushed, lengthen the vowel-heavy words and subordinate clauses
- The goal: prose that matches the genre's dual nature. intimate enough to break the reader's heart, vast enough to hold a world

POV DISCIPLINE (CRITICAL)
- STRICT POV separation: one POV per chapter, clearly identified
- The narrative lens must match the POV character's knowledge, vocabulary, and priorities
- A farmer-turned-soldier doesn't think in strategic abstractions
- A court diplomat doesn't notice sword technique
- A mage notices magical resonance that a non-mage wouldn't perceive
- NO slipping into another character's thoughts mid-chapter
- Information the POV character doesn't have CANNOT appear in their chapters
- When POV characters meet, the reader experiences the scene through ONE lens only

WORLD-BUILDING PROSE
- Invented terms are earned: use contextual clues, not definitions
  WRONG: "She wore a senjari, which was a traditional headdress worn by the warrior class."
  RIGHT: "She adjusted her senjari, checking that the steel pins were secure. The warrior braids underneath had taken an hour."
- Cultural details through action, not explanation:
  WRONG: "In Ketharan culture, the left hand was considered impure."
  RIGHT: "He reached for the bread with his left hand. Three people at the table stopped eating."
- Architecture and landscape through character interaction:
  WRONG: "The castle had been built three hundred years ago by King Aldric the Builder."
  RIGHT: "The steps were worn smooth in the centre, three centuries of boots grinding the stone to a dip she had to watch her footing on."

DIALOGUE FOR EPIC FANTASY
- Social register MUST vary by character station and culture
- Royalty speaks differently from soldiers, who speak differently from merchants
- Cultural speech patterns: one culture might be direct, another circular and metaphorical
- No modern idioms ("okay", "got it", "no way", "basically", "honestly")
- Suitable period-adjacent alternatives: "very well", "understood", "impossible", "in truth"
- Dialogue reveals power dynamics: who speaks first, who stays silent, who interrupts
- Formal address (titles, honorifics) in political scenes; familiar names in private
- Characters from different regions may misunderstand each other's idioms. this is a feature

BATTLE AND CONFLICT CRAFT
- Battles are experienced through ONE pair of eyes at a time
- Physical detail: pick the ONE sensation that dominates each moment of combat. Mid-swing, it's the grip. After a hit, it's the ringing. Don't catalogue. inhabit
- Fatigue and fear are realistic. characters tire, panic, make mistakes
- Strategy shown through character decisions in the moment, not narrator overview
- Aftermath matters as much as the battle: wounds, grief, political consequences
- Duration: major battles span multiple chapters; minor skirmishes are brief
- NOT every conflict is a sword fight. political manoeuvring, magical duels, siege endurance, moral confrontations
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

WORLD-BUILDING INTEGRATION (30% of total):
- World delivered through character experience, not exposition? (0-100)
- Magic system internally consistent with established rules? (0-100)
- Cultural details feel lived-in, not catalogued? (0-100)
- Sensory grounding in every scene? (0-100)

EPIC CRAFT (35% of total):
- POV discipline maintained (no head-hopping)? (0-100)
- Multiple plotlines advancing and intersecting? (0-100)
- Scale managed (intimate scenes within epic scope)? (0-100)
- Dialogue register appropriate for characters and cultures? (0-100)

PROSE QUALITY (35% of total):
- Show vs tell ratio (0-100)
- Dialogue differentiation across cultures and classes (0-100)
- Pacing appropriate (action/quiet balance)? (0-100)
- Sensory and physical detail quality (0-100)

AUTOMATIC FAILS (score = 0):
- Magic solves the central conflict without established rules (deus ex machina)
- Exposition dump longer than 2 paragraphs (world-building lectures)
- POV violation: revealing information the POV character cannot know
- Modern language or anachronisms in dialogue
- Flat villain with no coherent motivation
- Prophecy that removes character agency entirely
- Convenient travel that ignores established distances
```

## Continuity Rules

```
EPIC FANTASY CONTINUITY. WHAT TO TRACK

MAGIC SYSTEM CONSISTENCY (CRITICAL):
- Every established rule: what can be done, what cannot, what it costs
- Power levels of each magic user: what they've demonstrated, what they've failed at
- Magic limitations: distance, duration, material requirements, recovery time
- If a spell worked one way in Chapter 5, it works the same way in Chapter 30
- Magical objects: location, capabilities, who has them, who wants them

GEOGRAPHIC CONSISTENCY:
- Travel times between locations (days on horseback, weeks by ship)
- Terrain: if there's a mountain range between two cities, it's always there
- Seasons and climate: northern kingdoms are colder; desert regions are arid
- Maps in the reader's mind: maintain directional consistency (city A is east of city B)
- Don't teleport characters. travel takes time and should be felt

POLITICAL STATE:
- Which faction controls what territory at each point in the story
- Alliances: who is allied with whom, and when does it change
- Succession: who is heir to what, and how does that shift
- Treaties, agreements, debts. these are binding until broken
- War state: which armies are where, what resources are available

CHARACTER KNOWLEDGE BY POV:
- Each POV character has their OWN knowledge state
- Character A may know something Character B doesn't. and vice versa
- When POV characters share information in dialogue, BOTH knowledge states update
- Characters can be wrong. they may believe things that aren't true
- Cultural assumptions differ: what one character takes as fact, another may dispute

PHYSICAL CONTINUITY:
- Character injuries persist: a sword wound in Chapter 8 isn't healed by Chapter 9
- Scars, missing limbs, and disabilities are permanent
- Weather progresses with the season
- Objects have locations: if a sword was left in a battlefield, it's there until someone picks it up
- Character appearances: height, build, distinguishing features remain consistent
- Clothing and armour reflect character status and resources (a refugee doesn't have fine silk)

TIMELINE:
- Multiple POV threads may occur simultaneously. track parallel timelines
- When threads converge, ensure temporal consistency
- Seasonal markers must align across POV chapters happening at the same time
- Age of characters over long timespans if the story covers years
```

## Character Rules

```
EPIC FANTASY CHARACTER ARCHETYPES

POV CHARACTER REQUIREMENTS:
- Each POV character must have:
  - A UNIQUE voice in narration (how they observe the world)
  - A CLEAR personal goal that conflicts with their larger duty
  - A FLAW that creates real consequences (not a cute weakness)
  - A RELATIONSHIP that they're afraid of losing
  - A SPECIFIC skill set that determines what they notice and how they solve problems
- No duplicate functions: if one POV is the warrior, don't make another one the fighter

THE POWER PLAYERS:
- Kings, queens, lords. power is specific (military, economic, magical, political)
- No one holds all the power. competing factions create the political engine
- Rulers make decisions with imperfect information, just like everyone else
- Court advisors, spymasters, generals. each has their own agenda beneath their loyalty

THE COMMON FOLK:
- At least one POV or significant character from outside the power structure
- Their perspective grounds the epic scope in human reality
- The consequences of king-level decisions land hardest on regular people
- This character's arc often carries the story's moral centre

THE ANTAGONIST:
- NEVER a flat "dark lord" without comprehensible motivation
- The antagonist believes they are the hero of their own story
- Their plan must be internally logical and achievable
- They have genuine strengths, competence, and occasionally valid points
- The reader should understand WHY they do what they do, even while hoping they fail

CULTURES AND PEOPLES:
- Each culture has distinct: values, speech patterns, food, architecture, religion, social structure
- Cultural differences drive plot conflict (not just military opposition)
- No single culture is "the good guys" and no single culture is "the bad guys"
- Within every culture, individuals vary. avoid monolithic portrayals

VOICE DIFFERENTIATION REQUIREMENTS:
- Every named character identifiable by dialogue alone
- Social register: royalty vs soldiers vs merchants vs clergy
- Cultural markers: one culture's directness vs another's circumlocution
- Education level: a scholar uses different vocabulary from a blacksmith
- Emotional range: some characters are verbose when stressed, others go silent

RELATIONSHIP DYNAMICS:
- Track loyalty, debt, love, rivalry, and mentorship
- Relationships change under pressure. allies become enemies, enemies become allies
- Betrayal must be earned: build the trust before breaking it
- Mentor figures are NOT safe. they can fail, be wrong, or die
```

## Arc Rules

```
EPIC FANTASY STORY STRUCTURE

ACT 1: THE WORLD BEFORE (Chapters 1-5 for novella, 1-10 for standard, 1-14 for epic)
- Establish each POV character in their normal world (what they want, what they have to lose)
- The inciting incident disrupts the status quo for ALL characters (though they may not know it yet)
- Plant the seeds of the central conflict through POV-specific experiences
- Introduce the magic system's rules through demonstration, not lecture
- Establish 2-3 political factions and their tensions
- The world must feel like it existed BEFORE page one and will continue beyond the last page
- END OF ACT 1: Each POV character is committed to a path they cannot easily leave

ACT 2A: ESCALATION (to midpoint)
- POV threads diverge. characters in different locations facing different challenges
- Alliances form and are tested
- The scope of the threat becomes clearer (it's bigger than anyone initially thought)
- At least one major reversal per POV thread
- World-building deepens through character experience (new lands, new cultures, new magic)
- The antagonist's plan advances. they are winning
- MIDPOINT: A revelation that changes everything. the characters (and reader) see the true shape of the conflict

ACT 2B: COMPLICATION (midpoint to dark moment)
- The cost of the conflict becomes personal (death, betrayal, loss of home)
- Characters face moral dilemmas with no clean answers
- POV threads begin converging
- The magic system is tested to its limits. costs become severe
- At least one POV character fails catastrophically
- Political alliances shift as desperation changes calculations
- DARK MOMENT: The worst point for the protagonists. the plan has failed, allies are lost, the antagonist seems unstoppable

ACT 3: RESOLUTION (final 25%)
- Characters regroup with hard-earned wisdom
- Final alliances formed. unexpected, based on Act 2 relationships
- The climax uses EVERYTHING established in Acts 1-2 (magic rules, character skills, political leverage, geographic knowledge)
- POV threads converge for the climactic confrontation
- The resolution comes from CHARACTER CHOICE, not magical power
- Aftermath: the world is changed, and not everything is restored
- Loose threads for series can remain, but the central conflict of THIS book must resolve

MULTI-POV THREADING:
- POV rotation creates dramatic irony (reader knows what Character B doesn't)
- Cliffhanger one thread, cut to another. use the structure intentionally
- When threads converge, the chapter should acknowledge both characters' knowledge states
- Not every POV character needs equal chapter count. weight toward the most active storyline at each point

TENSION ARC:
- Epic fantasy has a LONG build. readers expect a slow burn that pays off massively
- Action set pieces at roughly 20%, 40%, 60%, 80%, and 95% through the story
- Quiet character moments between action (these are where readers fall in love)
- Political tension builds independently from physical/magical threat
- The climax should feel both surprising and inevitable
```

## Timeline Rules

```
EPIC FANTASY TIMELINE TRACKING

PARALLEL TIMELINES (CRITICAL):
- Multiple POV characters may be in different locations at the same time
- Track: where each POV character is, what day it is in their thread, what season
- When POV threads happen simultaneously, seasonal markers must match
  (if it's harvest season in the north, it's harvest in the south too. unless the world's climate is explicitly different)
- When characters receive news of events from other threads, account for travel time of the message

TRAVEL DURATION:
- Establish travel times between major locations early
- Maintain consistency: if City A to City B is 10 days by horse, it's always 10 days by horse (unless the road is blocked, weather intervenes, etc.)
- On foot vs horseback vs ship vs magical means. each has a different speed
- Terrain matters: mountains are slower, rivers are barriers, deserts require preparation
- Characters need to eat, sleep, and resupply during travel. this is world-building opportunity

SEASONAL PROGRESSION:
- If the story spans months: track the season and its effects
- Weather affects strategy, travel, food supply, and mood
- Agricultural societies mark time by planting and harvest
- Winter is a real constraint (armies can't march, ships can't sail, passes close)

POLITICAL TIMELINE:
- When did each political event occur (death of a king, declaration of war, signing of a treaty)?
- How long has each faction been in power?
- What is the timeline of the antagonist's plan? (they were doing things before the story started)
- News travels at realistic speed. a declaration of war in the south takes days/weeks to reach the north

MAGIC AND RECOVERY:
- If magic has a recovery cost (fatigue, injury, resource depletion), track recovery time
- A mage who exhausted themselves in Chapter 12 shouldn't be at full power in Chapter 13
- Magical events may have delayed consequences. track when they should manifest

CHARACTER AGING:
- If the story spans years, track ages
- Children grow, adults change, elderly characters decline
- Seasons of training matter: a novice in spring isn't a master by autumn
```

## Genre-Specific Craft Techniques

Epic fantasy is the genre of large-scale secondary-world
storytelling: kingdoms in conflict, magic systems with
internal architecture, multi-POV narrative spanning
years and continents, and the genre's signature
combination of personal-character-arc with world-
historical-stake. The canonical roster — J.R.R. Tolkien
(The Lord of the Rings, The Silmarillion), Robert Jordan
(the Wheel of Time), George R.R. Martin (A Song of Ice
and Fire), Brandon Sanderson (Mistborn, Stormlight
Archive), Robin Hobb (the Realm of the Elderlings),
Steven Erikson (Malazan Book of the Fallen), Patrick
Rothfuss (the Kingkiller Chronicle), Joe Abercrombie
(the First Law), Mark Lawrence, Tad Williams (the Memory
Sorrow and Thorn), Guy Gavriel Kay (Tigana, A Song for
Arbonne, the Sarantine Mosaic, Under Heaven, A Brightness
Long Ago) — established the form; the contemporary
masterclass roster — N.K. Jemisin (the Inheritance
trilogy, the Broken Earth, the Dreamblood, the Great
Cities), Tasha Suri (the Books of Ambha, the Burning
Kingdoms), Tamsyn Muir (the Locked Tomb), R.F. Kuang
(the Poppy War trilogy), Rebecca Roanhorse (Black Sun,
the Between Earth and Sky trilogy), S.A. Chakraborty
(the Daevabad trilogy), Tochi Onyebuchi (Riot Baby,
Goliath, War Girls), Suyi Davies Okungbowa (the
Nameless Republic), Ken Liu (the Dandelion Dynasty),
P. Djèlí Clark (the Master of Djinn), Anna Stephens
(Godblind), Devin Madson (the Reborn Empire), Olivie
Blake, Fonda Lee (the Green Bone Saga), Tasha Suri,
Aliette de Bodard, Marlon James (Black Leopard, Red
Wolf trilogy), Saara El-Arifi (the Ending Fire trilogy)
— has expanded the genre's range to include post-
colonial, queer, non-Western, and structurally
ambitious registers that the canonical roster
historically underweighted. The most common failure
modes in this register are: **Worldbuilding-as-
Exposition** (the world delivered through narrator-as-
historian, character-as-tour-guide, or appendix-driving
the prose; the genre's craft is in worldbuilding
through experience); **Magic-System-Drift** (the rules
of magic shift across the manuscript without
acknowledgement; powers that operated one way in book
1 quietly operate differently in book 3); **Battle-as-
Choreography** (epic battles rendered as omniscient
tactical-clear elegance rather than as the chaotic,
information-poor, character-specific reality the
genre's masterclass writers render); **Political-
Cardboard** (factions reduced to good-guys-vs-bad-
guys without the internal political texture, factional
disagreement, and morally complex motivation epic
fantasy at its best renders); **Tolkien-Pastiche** (the
manuscript that echoes Tolkien's specific worldbuilding
without earning its own distinctive setting; the dark
lord, the chosen hero, the magic ring, the elf-and-
dwarf alliance deployed as inheritance rather than as
genuine craft); **Scope-Without-Stakes** (the
manuscript that has scale but does not give the reader
specific characters whose fates matter); **POV-Drift**
(point-of-view discipline broken; head-hopping,
omniscient intrusion in close-POV chapters,
narrator-information that the POV character could not
know); **Travel-Time Erasure** (armies, messengers,
and characters traverse continental distances at the
speed the plot requires rather than at the speed the
established geography permits); **Cultural-Tourism
Worldbuilding** (sampling tropes from multiple real-
world cultures without specific committed research; the
generic "Eastern" / "African" / "Norse-inspired"
worldbuilding that flattens specific traditions); and
**Anachronistic-Sensibility** (the protagonist with
21st-century moral framework moving through a feudal
or pre-modern setting without the period's specific
constraints registering as material force on her
choices). The techniques below — three preserved
(World-Building Integration System, Magic System
Craft, Battle Scene Craft) and three added (Faction-
Internal-Texture Architecture, Travel-and-Logistics
Discipline, Sustained-POV Architecture) — are designed
to keep the genre's defining commitments live: world
delivered through experience, factions with internal
political life, and POV-discipline maintained at scale.

### World-Building Integration System

Every chapter must demonstrate the world through CHARACTER EXPERIENCE. The following system ensures world-building is delivered naturally:

**The 3-Channel Rule:**
Each chapter delivers world-building through exactly 3 channels (rotate across chapters):

| Channel | How It Works | Example |
|---------|------------|---------|
| **Material culture** | Objects, food, clothing, tools, architecture | A character adjusts unfamiliar armour from a foreign ally. the leather is cured differently, the buckles work backwards |
| **Social friction** | Characters from different cultures clash over norms | A northern diplomat insults a southern host by refusing to eat with their hands |
| **Casual assumption** | Characters reference things they take for granted | "We'll reach the ford by second moonrise". implies two moons without explaining |
| **Environmental storytelling** | The physical world tells the story of its history | Burn marks on city walls from a siege mentioned in the Story Bible |
| **Power dynamics** | Who defers to whom, who speaks first, who sits where | The general stands when the mage enters. magic outranks military here |
| **Economic reality** | What things cost, who can afford what, what's scarce | The army can't advance because the supply wagons are stuck in mountain mud |

**Invented Term Protocol:**
- Maximum 3 new terms per chapter
- Each term must be immediately understandable from context
- Never define a term in narration. demonstrate it
- Maintain a glossary in the Story Bible for the Continuity Guardian
- If a reader can't guess within 80% what a term means from context alone, rewrite the introduction

### Magic System Craft

**Hard Magic (rules on page):**
- Rules established in Act 1 through demonstration and failure
- The reader should be able to predict: "Can the mage do X?" before X is attempted
- Costs are physical and visible (nosebleeds, exhaustion, greying hair, shortened lifespan)
- When magic solves a problem, it creates a bigger one
- The climax uses magic within established rules in a CREATIVE way the reader didn't anticipate

**Soft Magic (limits demonstrated through mystery):**
- The reader never fully understands what magic can do. and neither do the characters
- Magic creates wonder and unease, not tactical advantage
- Limits shown through failure: a mage tries something and it doesn't work (or works wrong)
- The more powerful the magic, the less controllable it is
- Magic should feel like weather. forces of nature, not tools

### Battle Scene Craft

**The Ground-Level Rule:**
Every battle is experienced through ONE character's physical reality:

```
WRONG: The cavalry swept across the field in a pincer movement, while the
       archers on the hill provided covering fire. Three thousand soldiers
       clashed in the valley below.

RIGHT: Kael couldn't see past the man in front of him. Mud to his ankles,
       shield arm already burning. Someone was screaming. everyone was
       screaming. and then the line buckled and he was stumbling forward
       into space where there shouldn't have been space, because the men
       who'd been there were down.
```

**Battle Pacing:**
- Pre-battle: tension, preparation, fear (SLOW prose, long sentences)
- Contact: chaos, physical shock, short sentences, specific physical detail
- Mid-battle: rhythm of combat, fatigue, small victories and losses
- Aftermath: silence, cost, grief (return to SLOW prose)

### Epic Fantasy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the fate of kingdoms rested on their shoulders" | Show the specific political consequence |
| "war was coming. everyone could feel it" | Show the specific preparation or sign |
| "the throne room fell silent" | Show what caused the silence |
| "armies clashed on the fields of [place]" | Show the specific combatants' experience |
| "an alliance forged in fire" | Show the specific negotiation or shared ordeal |
| "the weight of the crown" | Show the specific decision and its cost |
| "honour demanded" | Show the specific code and the specific conflict it creates |
| "the dragon's roar shook the earth" | One specific physical consequence |
| "a quest that would change the world" | Show the specific goal and why it matters NOW |
| "blood and steel" | Show the specific wound or specific weapon |
| "the old magic was dying" | Show the specific failure. a spell that doesn't work, a creature that's disappeared |
| "a hero rose from unlikely beginnings" | Show the specific origin through action |
| "the kingdom was at war" | Name the specific kingdoms, the specific cause, the specific theatre |
| "ancient magic was awakening" | Show the specific named magic, the specific named source, the specific named manifestation |
| "the prophecy spoke of a chosen one" | Show the specific prophecy text and the specific named conditions |
| "the alliance hung by a thread" | Show the specific named factions and the specific named tension |
| "the world was changing" | Show ONE specific change through one character's specific perception |
| "they marched to war" | Show the specific marching detail (the named road, the named season, the specific supply state) |

### The Faction-Internal-Texture Architecture

The Political-Cardboard failure mode produces factions
reduced to good-guys-vs-bad-guys without the internal
political texture epic fantasy at its best demonstrates.
The Faction-Internal-Texture Architecture is the
requirement that every significant faction in the
manuscript be rendered with internal disagreement,
factional complexity, and morally textured motivation.

```
PRINCIPLE
Every significant faction must satisfy at least four of
the following five internal-texture criteria:
1. NAMED INTERNAL FACTIONS — the faction is not
   monolithic; specific named sub-factions disagree
   about strategy, philosophy, leadership, or goal
2. NAMED LEADERSHIP DYNAMICS — leadership is contested,
   contingent, and politically fragile; specific
   named figures hold specific named positions and
   face specific named challenges to those positions
3. NAMED INTERNAL CONFLICTS — the faction's history
   includes specific past conflicts, specific
   reformations, specific schisms, specific
   reconciliations; the present sits inside that
   history
4. NAMED ECONOMIC / RESOURCE BASE — the faction's
   power rests on specific named economic
   foundations (named land, named trade, named
   tribute, named alliance, named magical resource);
   when those foundations are threatened, the
   faction is materially threatened
5. NAMED INSTITUTIONAL CULTURE — the specific way
   the faction's bureaucracy, military, priesthood,
   merchant class, or court operates; the unwritten
   rules; the inherited traditions

CALIBRATION TEST
- Could the faction be reduced to "the bad guys" or
  "the good guys" without the manuscript losing
  political texture? If yes — rebuild.
- Are at least four of the five internal-texture
  criteria operative?
- Does the faction have characters who oppose its
  current direction without being traitors?
- Could a reader name the specific tensions
  internal to each major faction?
If any answer is no — rebuild for faction
specificity.

ANTI-PATTERN
- "The empire" as monolithic evil
- "The rebels" as monolithic righteous
- The court that is unified rather than internally
  factional
- The army with no internal disagreement about
  strategy or goal
- The religious institution rendered without
  internal theological dispute
```

### The Travel-and-Logistics Discipline

The Travel-Time Erasure failure mode produces
manuscripts where armies, messengers, and characters
traverse continental distances at narrative-convenient
speed. The Travel-and-Logistics Discipline is the
requirement that distances, supply chains, weather, and
communication delays operate as material constraint on
plot rather than as decorative texture.

```
PRINCIPLE
The manuscript must render travel and logistics through
at least four of the following five disciplines:
1. ESTABLISHED GEOGRAPHY — distances between named
   locations are established and consistent; the
   reader can build a mental map that the manuscript
   honours
2. PERIOD-APPROPRIATE TRAVEL TIMES — characters,
   armies, and messengers move at speeds the
   established geography and technology permit
   (foot 15-25 miles/day, horse 30-40 miles/day,
   cart 10-15 miles/day, sail variable by ship and
   wind, magical transport with rendered cost)
3. SUPPLY LOGISTICS — armies and expeditions need
   food, water, fodder, fuel, medical supplies;
   when these run out, plans change; specific named
   supply lines, specific named depots, specific
   named foraging
4. COMMUNICATION DELAYS — news travels at the speed
   of messenger; characters cannot know about events
   they could not have learned of yet; the gap
   between event and knowledge generates plot
5. SEASONAL / WEATHER CONSTRAINTS — campaigns happen
   in campaigning season; mountain passes close in
   winter; rivers flood in spring; storms close
   sea-lanes; the world's rhythms shape what is
   possible when

CALIBRATION TEST
- Could a reader chart the manuscript's geography
  and travel times on a single map without
  contradictions?
- Do armies, messengers, and characters move at
  established speeds rather than plot-convenient
  speeds?
- Are supply and communication constraints
  operative as material force?
- Do seasons and weather shape what is possible
  when?
If any answer is no — rebuild for travel-and-
logistics integrity.

ANTI-PATTERN
- The army that arrives wherever the plot requires
  whenever the plot requires
- The messenger who reaches the capital
  impossibly fast when the news must arrive
- The siege that is not constrained by supply
- The character who learns of distant events at
  the speed of plot rather than messenger
- The campaign that ignores season
```

### The Sustained-POV Architecture

The POV-Drift failure mode is epic fantasy's specific
risk because the genre's multi-POV architecture creates
constant temptation toward head-hopping, omniscient
intrusion, and information-leak. The Sustained-POV
Architecture is the requirement that each chapter's
POV discipline be held strictly, with the narrator's
voice matching the POV character's specific
consciousness.

```
PRINCIPLE
Every chapter must satisfy at least four of the
following five POV-discipline criteria:
1. SINGLE POV PER CHAPTER — each chapter is told
   from one POV character's consciousness; no
   head-hopping mid-scene, no omniscient
   intrusion, no narrator-knowledge the POV
   could not have
2. INFORMATION RESPECT — the POV character does not
   know things they could not have learned; the
   narrator does not reveal information the POV
   does not have; the reader is constrained by
   the POV's specific knowledge
3. VOICE-MATCHED NARRATION — the narrative voice
   in the chapter matches the POV character's
   education, culture, era, region, and
   psychology; a peasant POV chapter sounds
   different from a courtier POV chapter
4. PERCEPTION-FILTERED — what the chapter renders
   reflects what the POV would notice; a soldier
   notices weapons and terrain; a priest notices
   ritual and theology; a merchant notices
   prices and trade routes
5. EMOTIONAL CONTINUITY — the POV's emotional state
   carries forward from their last chapter; if
   they ended the previous chapter grieving, they
   open this chapter grieving (unless rendered
   passage of time changes that)

CALIBRATION TEST
- Could a reader identify the POV character of
  each chapter from the prose alone, without the
  chapter heading?
- Does the chapter respect the POV's information
  limits?
- Does the narrative voice match the POV's
  consciousness?
- Does emotional state carry forward across the
  POV's chapters?
If any answer is no — rebuild for POV discipline.

ANTI-PATTERN
- The chapter that switches POV mid-scene
- The "narrator knows what the POV doesn't" leak
- The peasant POV chapter that sounds like a
  courtier POV chapter
- The POV who notices what their character
  wouldn't notice
- The POV whose emotional state resets between
  chapters
```

## Genre-Specific Revision Rules

### Six-Pass Epic Fantasy Audit (Run FIRST in editorial pipeline)

The Epic Fantasy Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: World-Building Delivery Pass

Verify every world-building detail arrives through
character experience rather than narrator-as-historian
exposition. Flag any paragraph of pure exposition
longer than 3 sentences. Are invented terms introduced
with contextual clarity rather than glossary-style
explanation? Is "As you know, Bob" dialogue (characters
explaining things they both already know) absent? The
World-Building Integration System provides the spec —
the 3-Channel Rule, the Invented Term Protocol. The
Worldbuilding-as-Exposition failure mode is caught
here. if the chapter delivers world through narration
rather than through character-experience, rebuild.

#### Pass 2: Magic System Consistency Pass

List every use of magic in the chapter: what was done,
what it cost, who did it. Cross-reference against
established rules from earlier chapters. Flag any new
capability not previously established. Verify costs
are consistent (if fire magic causes exhaustion, it
always does). At the manuscript level, check the
climax: does it use magic within established rules in
a creative way the reader didn't anticipate, or does
it deploy new capabilities to resolve the plot? The
Magic-System-Drift failure mode is caught here. The
genre's signature satisfaction is the climax that
solves through established rules deployed creatively;
the climax that requires new magical capability
betrays the contract.

#### Pass 3: POV Integrity Pass

Verify each chapter has single POV only with no
information the POV character could not know. Does the
narrative voice match the POV character's education,
culture, era, and priorities? When two POV characters
meet, is the scene told from only one lens? The
Sustained-POV Architecture provides the spec — at
least four of the five POV-discipline criteria
(single POV / information respect / voice-matched
narration / perception-filtered / emotional
continuity) should be operative. The POV-Drift
failure mode is caught here.

#### Pass 4: Scale and Distance Pass

Verify travel times are consistent with established
geography. Do news and messages account for travel
time? Can armies appear without marching time? Do
seasons align across parallel POV timelines? The
Travel-and-Logistics Discipline provides the spec —
established geography, period-appropriate travel times,
supply logistics, communication delays, seasonal /
weather constraints. The Travel-Time Erasure failure
mode is caught here. if armies traverse continents at
plot-convenient speed, rebuild for logistics-as-
material-force.

#### Pass 5: Dialogue Register and Cultural Authenticity Pass

Verify no modern slang or anachronisms in dialogue.
Is social register appropriate to character station
(peasant speech vs courtier vs scholar vs cleric vs
soldier)? Are cultural speech patterns maintained
consistently across chapters? Do characters from
different cultures sound different from each other?
The Anachronistic-Sensibility failure mode is caught
here. characters from feudal or pre-modern settings
should not sound like 21st-century people in costume,
and the period's specific moral frameworks should
shape their dialogue. The Cultural-Tourism Worldbuilding
failure mode is also caught here. cultures borrowed
from real-world traditions should be researched
specifically rather than gestured at generically.

#### Pass 6: Faction-Internal-Texture + Travel-and-Logistics + Sustained-POV Integration

This pass is the epic fantasy integration check — it
ties the new techniques together and verifies the
manuscript honours the genre's defining commitments at
the manuscript level.

For FACTION-INTERNAL-TEXTURE: confirm every significant
faction is rendered with at least four of the five
internal-texture criteria (named internal factions /
named leadership dynamics / named internal conflicts /
named economic base / named institutional culture). The
Political-Cardboard failure mode is caught here. if any
faction is reduced to good-guys-vs-bad-guys without
internal political life, rebuild.

For TRAVEL-AND-LOGISTICS: confirm Pass 4's spec at the
manuscript level. could a reader chart the geography
on a single map and have travel-times consistent
throughout? Are supply, communication, and seasonal
constraints operative as material force?

For SUSTAINED-POV: confirm Pass 3's spec at the
manuscript level. Is each POV character's voice
distinctive? Does information-discipline hold across
the manuscript? At the political level, does the
manuscript honour the additional Political Logic
discipline — faction motivations internally
consistent, alliances and betrayals earned (not
convenient), power shifts with visible consequences,
resources tracked (armies, gold, food cannot be spent
beyond what was established)?

## Names & Patterns to Avoid

### Epic Fantasy Character Names. NEVER USE
- Overused "epic" names: Aldric, Theron, Aelindra, Elowen, Kael, Lyrian, Varek, Zarael
- "-iel" suffix cluster: Azriel, Sariel, Thariel, Zeriel (feels like a naming generator)
- "-ara" suffix cluster: Zara, Kara, Elara, Nyara, Solara
- "-wyn" suffix cluster: Bronwyn, Elowyn, Rowyn, Ashwyn
- Apostrophe names: K'thar, Dra'ven, Lor'an (apostrophes signal "fantasy cliché")
- Virtue/concept names: Shadow, Raven, Storm, Blade, Hawk, Wolf (as character names)
- Single-syllable "hard" names for warriors: Krag, Bron, Tharn, Grak

### Epic Fantasy Place Names. NEVER USE
- "[Dark Word] + [Geographic Feature]": Shadowmere, Darkhollow, Grimstone, Dreadmoor
- "[Precious Material] + [Structure]": Goldspire, Silverton, Ironhold, Crystalkeep
- "[Nature] + [Mystical]": Moonvale, Starfall, Sunfire, Stormhaven
- Generic kingdoms: Valdoria, Eldorath, Arthenia, Kaldoria

### Epic Fantasy Tropes. AVOID or SUBVERT
- The Chosen One (prophecy can exist but the character CHOOSES, not destiny)
- Dark Lord in a dark tower with evil armies (give the antagonist human motivation)
- Magic school with houses (too closely associated with existing IP)
- Ancient evil awakening after exactly 1,000 years
- The wise old mentor who dies to motivate the hero
- Orphan with hidden royal lineage
- "You're the last of your kind" as primary motivation
- Elves as wise immortals, dwarves as miners, orcs as evil. use original peoples

### Use Instead
- Names drawn from real-world linguistic roots. pick a language family for each culture:
  - Celtic roots for woodland peoples (Brennan, Carrig, Niall, Aisling)
  - Turkic/Persian roots for steppe cultures (Baris, Elif, Koray, Seren)
  - West African roots for trade civilisations (Adisa, Kojo, Abena, Yaw)
  - Slavic roots for northern kingdoms (Miroslav, Katya, Dragomir, Vesna)
- Place names that sound like places people actually live: Thornwall, Bridgemarket, Saltreach, High Fell, Ketterham
- Historical naming patterns: patronymics, place-based surnames, trade-based surnames

## Comp Titles

Epic-fantasy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Lord of the Rings* — J.R.R. Tolkien (1954-55): the modern epic-fantasy archetype.
- *The Wheel of Time* — Robert Jordan (1990-2013): the multi-volume epic-fantasy template.
- *A Game of Thrones* — George R.R. Martin (1996): the political-epic-fantasy benchmark.
- *The Way of Kings* — Brandon Sanderson (2010): contemporary hard-magic-system epic.

### Contemporary (current best-in-class)

- *The Fifth Season* — N.K. Jemisin (2015): the Broken Earth trilogy; literary epic-fantasy.
- *Senlin Ascends* — Josiah Bancroft (2013): literary tower-climbing epic fantasy.
- *The Poppy War* — R.F. Kuang (2018): the trilogy; non-Western military epic fantasy.
- *The Empire of Gold* — S.A. Chakraborty (2020): non-Western djinn-epic fantasy.
- *Black Sun* — Rebecca Roanhorse (2020): the Between Earth and Sky trilogy; Indigenous-rooted epic.
- *Jade City* — Fonda Lee (2017): the Green Bone Saga; modern East-Asian-rooted epic-crime.
- *The Stardust Thief* — Chelsea Abdullah (2022): Arabic-folkloric epic.
- *The Will of the Many* — James Islington (2023): Roman-empire-coded epic.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Movie poster aesthetic with dramatic lighting, sweeping landscapes, and a single focal figure or iconic element; this is the DOMINANT style for epic fantasy covers and signals the genre immediately to readers
- **Illustrated**. Painted or digitally illustrated covers with rich detail; often more stylized than photorealistic; popular for series and for conveying specific world elements (maps, magical effects, unique creatures)
- **Minimalist**. A single iconic symbol (a sword, a crown, a magical sigil) against a textured or gradient background; increasingly popular for epic fantasy, particularly in the literary end of the genre; clean and striking at thumbnail size
- **Typographic**. Title as the primary visual element with atmospheric colour and subtle texture; works for established authors or series where name recognition drives sales; less common for debut epic fantasy

### Genre Cover Aesthetics
- **Styles:** Sweeping landscapes with dramatic skies, silhouetted figures against vast backdrops, magical light effects (glows, energy, ethereal illumination), architectural grandeur (castles, citadels, ancient ruins), atmospheric depth and sense of scale, dark-to-light gradients suggesting epic journey
- **Colours:** Deep midnight blue and indigo (mystery, magic, night scenes), burnished gold and amber (power, royalty, firelight), crimson and blood-red (conflict, sacrifice, dragon-fire), forest green and deep teal (nature, elven, ancient), storm grey and silver (steel, destiny, mountains). the palette should feel vast, dramatic, and weighted with significance
- **Elements:** Swords, crowns, and thrones (power symbols), magical effects (glowing runes, energy swirls, ethereal light), vast landscapes (mountain ranges, ancient forests, endless plains), castles and citadels, cloaked or armoured figures, dragons or mythical creatures (if genre-appropriate), maps or compass roses as design elements, celestial bodies (moons, stars, eclipses)
- **Typography:** Bold, impactful serif or decorative fonts for titles; often metallic effects (gold foil, embossing, silver); title is large and authoritative; series branding prominent; author name can be large if established, smaller for debut; fantasy-appropriate decorative elements in lettering (sword through a letter, vine flourishes, runic accents)

### Subgenre Variations
- **Classic Quest**. Warmer palette, heroic figure, journey imagery, sunrise/sunset tones; inspiring rather than threatening
- **Political Intrigue**. Darker palette, throne/crown imagery, chess-piece symbolism, candlelit interiors, rich fabrics and gold accents
- **Military**. Armour, banners, battlefield landscapes, muted earth tones with red accents, multiple figures suggesting armies
- **Grimdark**. Desaturated palette, blood and mud, lone figure in hostile landscape, minimal colour (usually one accent colour against grey/black), gritty texture
- **Mythic**. Ethereal quality, celestial imagery, god-like figures, cosmic scale, rich purples and golds, luminous quality

### Market Positioning
Epic fantasy covers must convey SCALE and WEIGHT at Amazon thumbnail size. The cover should make the reader feel they're about to enter a vast, fully-realized world. Dark backgrounds with a bright focal element (a figure, a magical glow, a sunrise) create the strongest thumbnails. Series consistency is essential. matching colour palette, typography treatment, and visual style across all volumes. Covers should position against current market leaders (Sanderson, Abercrombie, Sapkowski, Kuang, Shannon) rather than imitating classic 1980s fantasy art. Modern epic fantasy covers lean cinematic and atmospheric rather than literal scene depiction.

### Cover Design DON'Ts
- No busy, overcrowded compositions. epic fantasy covers should feel vast, not cluttered
- No cartoonish or whimsical illustration. this signals middle grade or comedic fantasy, not epic
- No generic "warrior in front of castle" without atmosphere or emotional resonance
- No cheap-looking dragon illustrations. if using a dragon, it must be painted/rendered to a high standard or omit it entirely
- No bright, cheerful colour palettes. epic fantasy covers should feel weighty and dramatic
- No literal scene depiction with multiple characters posed together. this looks dated; modern covers use atmosphere and suggestion
- No small, delicate typography. the title must command attention and convey the story's scale
- No Tolkien/LOTR visual pastiche (specific green/gold palette, specific map style). it reads as derivative rather than inspired
