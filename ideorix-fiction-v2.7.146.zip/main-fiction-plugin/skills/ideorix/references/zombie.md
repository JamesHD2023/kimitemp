---
name: zombie-genre
description: "Genre-specific instructions for Zombie Fiction. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
parents: [horror, survival]
---

# Zombie Fiction. Genre Plugin

## Metadata
- **Genre ID:** zombie
- **Display Name:** Zombie Fiction
- **Category:** Horror & Gothic
- **Tier:** Core
- **Target Word Count:** 2,500–4,000 per chapter
- **Min Word Count:** 2,500
- **Recommended Beat Structures:** Horror Fear Arc, Thriller 12-Beat Structure, Seven-Point Structure, Three-Act Structure

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Safe House Siege | Survivors fortified, horde approaching | Claustrophobic tension; supply depletion clock; breach inevitable |
| Journey to Sanctuary | Travelling toward rumoured safe zone | Road-movie structure; daily encounters; destination hope vs. reality |
| Outbreak Beginning | Day one of civilisation collapse | Chaos, disbelief, rapid learning; freshest horror; society unravelling in real time |
| Slow Burn Collapse | Months/years into apocalypse | Resource archaeology; hardened survivors; moral degradation normalised |
| Infection Race | Character bitten, clock ticking | Countdown structure; denial-to-acceptance; mercy-kill question central |
| Community Building | Survivors attempting to rebuild | Political dynamics; agriculture-and-defence balance; hope vs. pragmatism |

## Architect Instructions

### Chapter Planning Requirements

**Structure:**
- Chapter length: 2,500–4,000 words
- Pacing: Relentless tension. constant threat, survival urgent, action frequent
- Must open with: Zombie threat, survival challenge, group conflict, or scarcity problem
- Must close with: Danger escalated, horde approaching, betrayal revealed, or resource crisis

**Beats Per Chapter:**
1. **Zombie threat**. Undead encounter, horde movement, infection risk, constant danger
2. **Survival challenge**. Food, water, shelter, ammunition scarcity, finding resources
3. **Group dynamics**. Trust issues, leadership conflict, moral choices, human threat
4. **Moral degradation**. What will you do to survive? Lines crossed, humanity questioned
5. **Action or tension**. Fight, flight, stealth, close calls, adrenaline, fear

### Genre-Specific Requirements
- Post-apocalyptic setting. civilisation collapsed, weeks to years after outbreak
- Zombie rules consistent. slow or fast, infection method, behaviour, vulnerabilities established early, maintained throughout
- Survival focus. food, water, shelter, ammunition, medicine scarce and critical
- Small group dynamics. survivors banding together, trust fragile, betrayal common
- Constant threat. zombies omnipresent, nowhere truly safe, vigilance required
- Resource scarcity. everything limited, hard choices, competition deadly
- Human antagonists. other survivors often more dangerous than zombies
- Moral questions. what will you do to survive? Humanity vs. survival
- Infection tension. bites, scratches, who's infected, hiding symptoms
- Hope vs. despair. finding meaning, reasons to survive, rebuilding or giving up
- Action frequent. fights, escapes, close calls, adrenaline, violence
- Nowhere safe. fortifications breached, safe zones fall, always moving

### Narrative Layers
- **Layer A (Survival/Action):** Zombie encounters, resource runs, fortification, travel, combat, escape
- **Layer B (Moral Degradation):** Internal cost of survival. lines crossed, guilt accumulated, humanity eroding
- **Layer C (Group Dynamics):** Trust, betrayal, leadership, romance, found family, faction politics

All three layers active in every chapter. Layer B carries the emotional core. the real horror is what survival does to people.

### Fractal Structure
- Novel level: Society collapsed → survival established → moral lines crossed → humanity questioned → resolution (hope or despair)
- Chapter level: Threat encountered → survival response → moral cost → shifted group dynamic
- Scene level: Danger → action → consequence → what it cost

### Forbidden in Planning
- Zombies behaving inconsistently. establish rules and maintain them
- Unlimited resources. ammunition, food, water must be scarce, rationed
- Easy survival. constant struggle, danger, exhaustion, injury
- Stupid decisions. characters must make realistic survival choices
- Comic relief tone. dark humour acceptable but stakes must remain serious
- Zombies as sole threat. humans often more dangerous, moral complexity required
- No consequences. bites infect, noise attracts, mistakes kill
- Magic cure. no easy solution, survival is an ongoing struggle
- Group harmony. conflict natural under stress, trust hard-won
- Superhero protagonist. survivors are people, scared, injured, exhausted

### Zombie Mythology Tracking
Establish early and maintain throughout:
- **Speed**. Slow shambling or fast running, consistent
- **Infection**. Bite only, bodily fluids, airborne, scratches
- **Behaviour**. Mindless or retain traces, pack hunting or solo
- **Senses**. Sight, sound, smell, how they detect prey
- **Vulnerabilities**. Head destruction, fire, other methods
- **Decomposition**. Rotting over time or preserved
- **Numbers**. Hordes, scattered, growing or stable population
- **Communication**. Moaning, screaming, silent, coordinating or not

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (survival horror), Anticipation (horde dread), Affection at companion bonds.

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Voice and Tone
- **POV:** 1st person (immediate survival) or close 3rd limited (group perspective)
- **Tense:** Present (immediacy, urgency) or past (survivor's account)
- **Voice:** Tense, survival-focused, dark, morally complex, exhausted
- **Reading level:** Adult. violence graphic, moral questions dark, survival brutal

### Prose Imperatives
- Zombie encounters visceral. rotting flesh, stench, gore, horror physical
- Survival exhaustion. hunger, thirst, pain, exhaustion constant reality
- Resource tracking. ammunition count, food portions, water rationing shown
- Moral complexity. what will you do? Lines crossed, humanity questioned
- Group tension. distrust, conflict, competing agendas, fragile alliances
- Sensory horror. smell of decay, moans, shambling, corpses everywhere
- Action clear. fight choreography, escape routes, tactical decisions
- Scarcity real. every bullet counts, meals meagre, supplies critical
- Constant vigilance. always watching, listening, nowhere safe
- Dark hope. finding meaning despite apocalypse, reasons to survive

### Prose Rhythm Mapping
- **CH 1 HOOK:** Normality shattering. Open with deliberately MUNDANE prose. medium sentences (15-20 words), domestic detail, routine. The reader should feel safe. Then break it. The shift in prose rhythm IS the inciting incident.
- **BEFORE RHYTHM:** Mundane, steady, comfortable. Medium-length sentences with domestic specificity. "She poured coffee. The radio played something forgettable. The neighbour's dog barked at nothing." Ordinary verbs. Ordinary nouns. The reader's guard drops.
- **AFTER RHYTHM:** Survival mode. Short. Urgent. No metaphor. No beauty. "Ran. Door locked. Window. Through the glass. Bleeding. Keep moving." Sentences stripped to bone. subject, verb, consequence. The prose has no time for anything that doesn't keep the character alive.
- **THE SHIFT:** The transition from BEFORE to AFTER prose should be abrupt and irreversible. One paragraph of normal prose, then a line break, then the world ends in five-word sentences. The reader should feel whiplash. That feeling IS the genre.
- **TENSION FLOOR:** Starts at 3-4 (mundane safety) and reaches 7+ by end of Ch 1. After the shift, tension never drops below 7 for the rest of the manuscript. There is no going back to BEFORE prose.
- **SENSORY PALETTE. AFTER:** Visceral, physical, immediate. No abstraction. No interiority beyond survival calculus. Sound of running feet. Smell of decay. Weight of a weapon in the hand. Wet sounds. The body's inventory: pain here, blood there, legs still working, keep moving.
- **ACTION RHYTHM:** Combat prose is the shortest. 3-6 word sentences. "Swung. Missed. Again. Bone cracked. It dropped." Every word costs breath. The reader should feel the exhaustion in the prose itself.
- **BREATHING ROOM:** Brief. a paragraph at most. Slightly longer sentences (10-15 words) while the character catches breath, counts ammunition, checks wounds. Then back to short. The breathing room shrinks chapter by chapter.
- **RHYTHM ACROSS THE MANUSCRIPT:** The ratio of calm-to-urgent prose shifts relentlessly. Ch 1: 60% mundane / 40% survival. Ch 5: 20/80. Ch 10+: survival rhythm dominates. Any return to longer sentences signals false safety. and the reader should distrust it.

### Prose Masterclass Examples

**The Visceral Encounter:**
Make zombie contact horrifying through specific sensory detail. The stench before the sight. The wet sound of a jaw working loose. The wrongness of a body that moves without life. not movie-zombie smooth but jerking, catching, a puppet operated by rot. Show the physical revulsion that never quite dulls no matter how many times you kill them.

> The thing that used to be a man lurched forward, jaw hanging loose, intestines trailing. The stench hit first. rot and shit and death. It moaned, reaching.

Not: "A zombie approached."

**The Kill That Costs:**
Zombie kills should never become routine on the page even when they become routine for characters. Each kill costs. physical effort, noise made, ammunition spent, psychological toll. The bat gets heavier. The machete sticks in bone. The gunshot brings more.

> I swung the bat. Skull cracked. It kept coming. Swung again. Bone fragments. Third hit, it dropped. Arms burning. Breath ragged. Three more behind it.

Not: "I killed the zombie with my bat."

**Survival Scarcity. Resource Consciousness:**
Make every resource a character. Bullets have names. Meals have portions. Water has a deadline.

> Three rounds left. Make them count.
> Half a can. Split three ways. Hasn't been enough in weeks.
> Two bottles. Maybe three days if we're careful. No rain in sight.
> Last antibiotic. Infection spreading. Choose who lives.

**Moral Complexity. Hard Choices Shown:**
The real horror is the choices. Write them without flinching, without easy answers, without the narrative endorsing or condemning.

> Abandoning wounded. "Can't carry him. Zombies coming. I'm sorry."
> Rationing. "Kid's hungry. Everyone's hungry. Not enough."
> Killing infected. "He's bit. Hour, maybe two. We know what happens."
> Theft. "Stole their supplies. They'll starve. So will we otherwise."
> Murder. "Killed him for his gun. Needed it more. God help me."

**Group Dynamics. Tension Constant:**
Trust is the rarest resource. Write it as currency. spent, earned, stolen, lost.

> Leadership. "You're not in charge." "Someone has to be."
> Trust. "Show me your arms. Everyone shows their arms."
> Conflict. "Your brother's dead weight." "He's my brother."
> Betrayal. "Thought we were friends. Then she took the supplies. Gone."
> Sacrifice. "I'll draw them off. Get the others out. Go!"

**Infection Paranoia. The Hidden Bite:**
The dread of infection is worse than the zombies. Every scratch, every fever, every moment of silence becomes suspect.

> Bite checking. "Show me. Now. Roll up your sleeve."
> Hiding wounds. "It's nothing. Just a scratch. Don't look at me like that."
> Fever symptoms. "You're burning up. When did it start?"
> Denial. "I'm fine. I'm FINE. Just tired."
> Mercy killing. "I won't turn. Please. Before I turn."

### Emotional Rhythm
- **Build:** Quiet moments of false safety. barricading, rationing, watch shifts, the illusion of routine
- **Sustain:** Tension that never fully releases. sounds outside, supply counts, trust gaps
- **Release:** Through violent action. breach, horde, fight, escape, the adrenaline dump
- **Recover:** Brief aftermath. counting survivors, treating wounds, grieving, the cost tallied

### Forbidden Words and Phrases
- "Undead" overused. vary terminology: zombies, walkers, biters, infected, rotters
- Explaining zombie rules through info-dump lectures. show through action
- Video game logic. headshots don't always drop them, struggles are real
- Clean kills. messy, exhausting, multiple hits often needed
- "He shot the zombie". specifics: "Put a round through its skull"
- Easy escapes. zombies numerous, persistent, dangerous
- Cheerful tone. dark humour acceptable but stakes deadly serious

## Quality Check Criteria

### Priority Ranking
1. **Zombie rules consistent**. Speed, infection method, behaviour, senses, vulnerabilities maintained throughout without convenient exceptions
2. **Resource scarcity real**. Ammunition counted, food depleting, water tracked, medicine limited, everything running out on realistic timelines
3. **Survival realistic**. Exhaustion, injuries, hunger, dehydration affecting capability, no superhuman endurance
4. **Group dynamics authentic**. Conflict natural under stress, trust fragile, betrayal possible, leadership contested
5. **Deaths meaningful**. Important characters die, plot armour absent, stakes genuinely real, anyone can fall

### Genre-Specific Checks
- Zombie consistency. speed, senses, behaviour, infection method maintained chapter to chapter
- Ammunition tracked. bullets counted per weapon, reloading shown, running out consequential
- Scarcity tangible. food, water, medicine limited, depleting, rationing shown with specific quantities
- Exhaustion shown. sleep deprivation, physical toll, capability declining visibly
- Injuries realistic. wounds don't vanish, infection risk present, pain affecting capability
- Group conflict. trust issues, moral disagreements, leadership struggles, resentments simmering
- Infection progression. bites lead to symptoms, turning, tragedy, timeline consistent with established rules
- Moral complexity. hard choices forced, lines crossed, guilt carried, humanity questioned
- Hope and despair balanced. reasons to survive present, not all dark or all easy
- Action choreography clear. fight positioning, weapon specifics, exhaustion, noise consequences

### Automatic Fails
- Zombie rules inconsistent. slow then suddenly fast, infection method changing between chapters
- Unlimited ammunition. shooting endlessly without reload or resupply from a limited weapon
- Magic supplies. food, water, medicine appearing conveniently, scarcity not real
- No exhaustion. fighting and running constantly, never tired, superhuman endurance
- Instant healing. wounds vanishing overnight, no infection risk, unrealistic recovery
- Plot armour. main characters never in real danger, only expendable characters die
- Group harmony. no conflict, everyone agrees, trust perfect under apocalyptic stress
- Comic relief tone. not taking stakes seriously, jokes undermining horror and tension
- Characters acting unrealistically stupid. decisions made solely to serve plot

### Acceptable Imperfections
- Some zombie appearance variations if core traits maintained
- Minor supply fluctuations if scarcity pattern consistent
- Accelerated timeline if acknowledged and not skipping critical resource depletion
- Lucky breaks if earned, rare, and not constant

## Continuity Rules

### Top 5 Continuity Priorities
1. **Zombie rules consistency**. Speed, infection method, behaviour, vulnerabilities maintained
2. **Resource tracking**. Ammunition, food, water, medicine depleting realistically
3. **Group composition**. Who's alive, who's dead, who's infected, who left
4. **Injury and infection**. Wounds tracked, infections spreading, symptoms progressing
5. **Location security**. Safe house status, breaches, fortification state, movement triggers

### Zombie Mythology Tracking
Establish and maintain:
- **Speed:** Slow shambling, jogging, sprinting. pick one, stay consistent
- **Infection vector:** Bite only, all bodily fluids, scratches, airborne
- **Incubation:** Hours to turn, days, varies by person. but consistent range
- **Behaviour:** Mindless or cunning, solitary or pack, aggressive or passive until stimulated
- **Senses:** Sight range, hearing acute, smell living, how they detect prey
- **Vulnerabilities:** Head destruction only, fire works, decapitation, spinal severing
- **Communication:** Moaning, screaming, silent, coordinating or not
- **Decomposition:** Rotting progressively, preserved, function despite decay

### Ammunition and Weapons Tracking
Critical for realism:
- **Specific firearms:** Glock 17, AR-15, Winchester shotgun. model affects ammo
- **Ammunition type:** 9mm, 5.56, 12-gauge. compatibility matters
- **Magazine capacity:** 17 rounds, 30 rounds, 6 shells. track per weapon
- **Rounds remaining:** After each use, count down, reloading when
- **Spare ammunition:** How many magazines, boxes, rounds total
- **Degradation:** Guns jam, ammunition gets wet, maintenance needed
- **Melee weapons:** Crowbar, machete, bat. condition, effectiveness, fatigue from use

### Supply Depletion Tracking
Scarcity realistic:
- **Food:** Specific. 3 cans of beans, half box of crackers, 2 granola bars
- **Water:** Bottles counted. 5 bottles, 2 gallons, pond nearby (risky)
- **Medicine:** Exact. one bottle of aspirin, 3 antibiotics left, bandages running out
- **Fuel:** If vehicles. gas tank level, finding fuel, running out
- **Batteries:** Flashlights, radios. tracking power, darkness when out
- **Sanitation:** Hygiene declining, disease risk increasing

### Group Member Tracking
For each survivor:
- **Name and role:** Leader, medic, scout, fighter, liability
- **Skills:** Shooting, medical, repair, foraging, combat
- **Injuries:** Current wounds, healing timeline, limitation from injury
- **Infection status:** Bitten, scratched, clean, hiding symptoms
- **Mental state:** Breaking, stable, leader, suicidal, paranoid
- **Relationships:** Trust, romance, hatred, rivalry, family
- **Equipment:** What carrying, weapon, supplies, pack contents
- **Status:** Alive, dead, turned, missing, left group

### Infection Progression Tracking
If bitten/infected:
- **Exposure:** When bitten, where on body, severity
- **Symptoms:** Fever within hours, sweating, delirium
- **Timeline:** Hours until turn. consistent with established mythology
- **Hiding:** Character concealing infection, suspicion from others
- **Revealing:** Others discovering, confrontation, mercy-kill question
- **Turning:** Transformation described, violence, tragedy
- **Post-turn:** Now zombie, group must handle, grief

### Location and Movement Tracking
Safe house security:
- **Current location:** House, store, warehouse, bunker. specific
- **Fortifications:** Barricades, walls, security, effort invested
- **Breaches:** When compromised, how, damage, repair or flee
- **Resources nearby:** Why here. pharmacy, food, water, strategic
- **Zombie density:** How many nearby, horde proximity, threat level
- **Movement triggers:** When leave, why, destination, journey dangers

### Critical. Never Allow
- Zombie speed wavering. if slow shambling established, don't suddenly sprint
- Infection method changing. bite, scratch, fluids. stays consistent
- Ammunition physics violated. can't fire 30 rounds from 6-shot revolver without reload
- Food appearing from nowhere. if starving, can't feast without explanation
- Water needs ignored. dehydration timeline realistic, 3–4 days without is deadly
- Dead stays dead (unless zombie). who's present tracked precisely
- Injuries vanishing. wounds don't heal overnight, pain ongoing
- Infection timeline broken. hours to turn consistent per established mythology
- Safe house security retroactive. once breached, stays compromised

### Acceptable Inconsistencies
- Minor zombie appearance variations if core characteristics maintained
- Slight supply quantity fluctuations if scarcity pattern consistent
- Background survivor details if not affecting main group

## Character Rules

### Top 5 Character Priorities
1. **Survival skills**. Combat, medical, repair, scavenging. what each character contributes
2. **Moral boundaries**. What will/won't do to survive, lines crossed or held
3. **Breaking points**. Psychological toll, trauma, who cracks when, how they're coping
4. **Physical condition**. Injuries, exhaustion, illness, starvation, capability affected
5. **Trust evolution**. Who trusts whom, betrayals, loyalty tested, bonds forming

### Character Tracking Checklist
- Pre-apocalypse background. former life, skills, losses, shaping current self
- Survival role. leader, fighter, medic, scavenger, dead weight, contribution
- Combat capability. can fight, freeze, strategic, reckless, improving or not
- Moral stance. what will/won't do, killing infected, abandoning weak, theft
- Psychological state. holding together, breaking, PTSD, depression, suicidal
- Physical condition. injuries, exhaustion, hunger, illness, capability
- Trust issues. paranoid, trusting, betrayed before, forming bonds or lone wolf
- Losses. who died, guilt, grief, hardening or breaking
- Hope level. reasons to survive, giving up, finding meaning, despair
- Relationships. romance, friendship, family, protecting, rivalry

### Survivor Types

**Reluctant Leader:**
- Didn't want responsibility. thrust into command by circumstance
- Making hard calls. who eats, who stays, who dies
- Guilt heavy. every death, every choice, weight crushing
- Others depend. can't break, can't show fear, exhausting
- Arc: Growing into role or breaking under pressure

**Combat Capable:**
- Pre-apocalypse military, police, fighter, or naturally prepared
- Protecting others. skilled, capable, group's weapon
- Desensitised. killing zombies easy, killing humans harder
- Moral questions. when does protector become killer?
- Arc: Maintaining humanity or becoming a monster

**Medic/Healer:**
- Medical knowledge. nurse, doctor, EMT, veterinarian
- Triage reality. can't save everyone, choosing who lives
- Supplies depleting. doing more with less, improvising
- Every death personal. exhaustion, burnout, guilt
- Arc: Continuing to care or giving up, hardening

**Dead Weight:**
- Can't fight. frozen, useless, liability to the group
- Burden. eating supplies, contributing nothing, resented
- Learning. or remaining helpless, eventual death or growth
- Moral question. group's responsibility or abandon?
- Arc: Becoming useful, dying, or being abandoned

**Sociopath Thriving:**
- Apocalypse as freedom. no laws, no consequences, true self emerging
- Manipulative. using group, hoarding, betraying
- Dangerous. threat from within, worse than zombies
- Unmasked. crisis revealing nature, group discovering
- Arc: Expelled, killed, or taking over, corrupting group

**Parent Protecting Child:**
- Fierce. will do anything, any line crossed for the child
- Moral flexibility. stealing, killing, no hesitation if child is threatened
- Exhaustion. constant vigilance, can't rest, approaching breaking point
- Teaching survival. child learning, innocence dying, necessary cruelty
- Arc: Child dies or survives, cost either way, guilt for what was done

**Hope Keeper:**
- Refusing despair. finding reasons, small joys, meaning
- Group morale. encouraging, believing sanctuary exists
- Naive or resilient. tested repeatedly by horror
- Breaking. if hope dies, devastation, or inspiring others regardless
- Arc: Hope rewarded, punished, or evolving to realistic resilience

### Psychological Breakdown Types
Under apocalyptic pressure:
- **Denial:** Ignoring danger, pretending normal, dangerous delusion
- **Paranoia:** Trusting no one, seeing threats everywhere, isolating, self-fulfilling prophecy
- **Depression:** Giving up, suicidal, burden, needing saving or dying
- **PTSD:** Flashbacks, triggers, freezing, hypervigilance, functional or not
- **Sociopathy emerging:** Moral boundaries eroding, enjoying violence, becoming the threat
- **Dissociation:** Emotional shutdown, going through motions, surviving not living

### Moral Degradation Tracking
What will you do to survive?
- **Initially:** Won't kill humans, won't steal, help everyone
- **Pressure:** Hard choices, abandoning injured, rationing harshly
- **Crossing lines:** Killing for supplies, theft, betrayal, necessary evils
- **Justification:** "Had to," "Them or us," "Survival". guilt or indifference
- **Point of no return:** Murder, cannibalism, slavery, becoming monster
- **Self-awareness:** Knowing what you're becoming, fighting it or accepting

### Relationship Dynamics

**Found Family:**
- Strangers bonding through survival, trust earned slowly
- Loyalty fierce, protecting each other, chosen bonds
- Loss devastating. grief intense, guilt for surviving
- Conflict inevitable. different values, working through or splitting
- Hope. reason to survive, caring for each other, humanity preserved

**Romance in Apocalypse:**
- Connection rare. finding intimacy, comfort, love amid horror
- Vulnerability scary. caring means potential loss
- Intimacy. rare privacy, stolen moments, life-affirming
- Conflict. jealousy, choosing partner over group, favouritism
- Loss. death, infection, heartbreak, surviving or giving up

**Rivalry/Conflict:**
- Leadership power struggles. competing philosophies, who decides
- Resources. rationing disputes, hoarding, theft
- Moral differences. what each is willing to do, judging each other
- Betrayal. trust broken, revenge, exile, or killing
- Resolution. working out, one leaving, or one dying

### Red Flags
- All survivors fitting the same personality type
- No one dying. plot armour destroying stakes
- Immediate trust between strangers in apocalypse
- Unlimited competence. every character a capable fighter
- No psychological toll from constant horror and violence
- Moral choices presented as easy. clear right and wrong
- Children treated as tiny adults with no age-appropriate fear

## Arc Rules

### Arc Types (Choose Based on Story)

**Safe House Siege:**
- Act I (Ch 1–10): FORTIFICATION. Establish group, location, rules, supplies; threats probed
- MIDPOINT (Ch ~15): BREACH. Walls compromised, major loss, must adapt or flee
- Act II (Ch 11–23): DETERIORATION. Supplies dwindle, group fractures, moral lines crossed
- Act III (Ch 24–30): FINAL STAND. Hold or escape, sacrifice, resolution

**Journey to Sanctuary:**
- Act I (Ch 1–10): DEPARTURE. Group forms, destination chosen, journey begins
- MIDPOINT (Ch ~15): REVELATION. Sanctuary may be false; major companion lost
- Act II (Ch 11–23): ROAD. Daily threats, group politics, moral degradation en route
- Act III (Ch 24–30): ARRIVAL. Sanctuary real or false, cost counted, hope or despair

**Outbreak Beginning:**
- Act I (Ch 1–10): CHAOS. Day one, infection spreading, society collapsing
- MIDPOINT (Ch ~15): NEW NORMAL. Civilisation gone, survival rules learned
- Act II (Ch 11–23): ADAPTATION. Forming group, finding shelter, learning to kill
- Act III (Ch 24–30): ESTABLISHMENT. Survival routine or death, world changed forever

**Infection Race:**
- Act I (Ch 1–5): BITE. Exposure, denial, hiding
- MIDPOINT (Ch ~8): REVELATION. Others discover, confrontation
- Act II (Ch 6–12): COUNTDOWN. Symptoms worsening, final wishes, time running out
- Act III (Ch 13–15): RESOLUTION. Mercy kill, turning, miracle, or sacrifice

### Required Checkpoints
- By Ch 3: Zombie rules established. speed, infection, behaviour shown through action
- By Ch 8: Group conflict. leadership, resources, moral choice causing tension
- By Ch 10: Crisis. safe house threatened or mission begun, stakes personal
- By Ch 15: Major loss. group member dies/turns or betrayal revealed, devastating
- By Ch 20: Moral degradation. lines crossed, necessary evils, guilt or justification
- By Ch 23: Darkest moment. surrounded, running out, infected, hope gone
- By Ch 28: Final stand. climactic battle, sacrifice, brutal, costly
- By Ch 30: Aftermath. survived or died, cost counted, hope or despair

### Genre Promise
Zombie Fiction readers expect:
- Post-apocalyptic horror. civilisation collapsed, survival struggle
- Constant zombie threat. undead omnipresent, nowhere safe, relentless
- Resource scarcity. food, water, ammunition limited, critical, depleting
- Group dynamics. small survivor band, trust fragile, conflict inevitable
- Moral questions. what will you do to survive? Humanity vs. survival
- Action frequent. fights, escapes, close calls, visceral violence
- Deaths. group members die, turn, are lost, grief and guilt
- Human antagonists. other survivors often worse than zombies
- Infection tension. bites, symptoms, hiding, turning, tragedy
- Hope vs. despair. reasons to continue, finding meaning, or giving up

## Timeline Rules

### Top 5 Timeline Priorities
1. **Survival urgency**. Every hour matters, decisions immediate, no waiting
2. **Resource depletion**. Food, water, ammunition running out on realistic timelines
3. **Infection progression**. Hours to turn once bitten, time limit deadly
4. **Exhaustion accumulation**. Days without sleep, running on empty, collapse imminent
5. **Time since outbreak**. Weeks, months, years affects supplies, hope, infrastructure

### Genre-Specific Temporal Rules
- Zombie threat constant. day and night, never safe, always moving or watching
- Watch shifts. someone always alert, sleep in shifts, vigilance essential
- Travel time. on foot mostly, slow, dangerous, miles take hours
- Fortification vs. time. hours to barricade, minutes to breach
- Starvation timeline. weeks without adequate food, weakness, death
- Dehydration timeline. 3–4 days without water kills, performance drops day 2

### Timeline Structures

**Single Day Survival:**
- Dawn to dusk. one day, constant action
- Hour by hour. escalating danger, decisions rapid
- Exhaustion mounting. no rest, adrenaline failing
- Nightfall. more dangerous, darkness terror
- Survival. making it to sunrise, barely

**Week of Hell:**
- Day 1: Safe house compromised, fleeing
- Day 2–3: Searching supplies, encountering survivors, conflict
- Day 4–5: Injuries, infection fear, desperation
- Day 6–7: Final stand or escape, losses, survival

**Infection Race:**
- Bite occurs. timer starts, hours to turn
- Denial. symptoms appearing, hiding, fear
- Revelation. others discover, confrontation
- Final hours. saying goodbye, mercy kill, or turning
- Aftermath. grief, guilt, moving on

**Horde Approaching:**
- Week warning. scouts see massive horde, days away
- Preparation. fortifying, gathering supplies, planning escape
- Days countdown. tension rising, horde approaching
- Hours remaining. final preparations, dread
- Arrival. chaos, breach, survival, losses

**Journey to Sanctuary:**
- Weeks travelling. on foot, slow, dangerous
- Daily threats. zombies, raiders, supplies running out
- Setbacks. injuries, wrong turns, detours, deaths
- Arrival. safe zone real or false hope?
- Resolution. sanctuary or keep moving

### Time Since Outbreak
Story position in apocalypse affects everything:
- **Weeks (early):** Chaos, fresh corpses, supplies abundant, hope high, infrastructure failing
- **Months (settling):** Scavenging, supply depletion, groups forming, infection understood, bodies rotting
- **Year+ (long-term):** Supplies scarce, survivors hardened, civilisation gone, nature reclaiming, new normal
- **Years (post-apocalyptic):** Children born after, supplies critical, communities established, zombies shambling, hope or despair

### Infection Timeline
Once bitten (establish and maintain):
- Hour 1: Bite wound, cleaning, denial beginning
- Hours 2–4: Fever starting, sweating, anxiety
- Hours 4–8: Fever high, delirium, symptoms obvious
- Hours 8–12: Severe symptoms, death approaching
- Death: Hours 12–24 typically, varies by mythology
- Reanimation: Minutes after death, turning, zombie

### Resource Depletion Timelines
Survival clocks:
- **Food:** 3 weeks without kills (starvation gradual), weakness after days
- **Water:** 3–4 days without kills (dehydration), performance drops day 2
- **Ammunition:** Depends on encounters, 20 rounds might last days or hours
- **Sleep:** 3–4 days without, hallucinations, collapse, death
- **Medicine:** Infection without antibiotics, days to death or recovery
- **Fuel:** Tank-dependent, gallon per 20 miles, finding more increasingly difficult

### Daily Survival Rhythm
If semi-stable:
- Dawn: Wake, check perimeter, assess threats
- Morning: Scavenging, repairs, cooking, planning
- Afternoon: Rest, rationing meal, maintenance
- Dusk: Fortify, prepare for night, extra vigilance
- Night: Watch shifts, 2–4 hour rotations, exhaustion
- Continuous: Always alert, never truly safe, wearing down

### Watch Shift Rotation
Group survival essential:
- Shift length: 2–4 hours each, depends on group size
- Overlap: Brief, pass information, status update
- Exhaustion: Days of shifts, microsleep danger, mistakes
- Fairness: Rotation, resentment if unequal, conflict
- Emergency: All wake if threat, sleep deprivation accumulates

### Travel Pacing
On foot primarily:
- Good conditions: 15–20 miles per day, exhausting
- Stealth required: 5–10 miles per day, slow, careful
- Encumbered: Carrying supplies, injured members, slower
- Zombie density: High density requires detours, miles become days
- Terrain: Urban rubble, forests, obstacles. all slow progress

## Genre-Specific Craft Techniques

Zombie fiction has, since the form's modern reformation
through Romero's *Night of the Living Dead* and its
descendants, never really been about the zombies. The genre's
deepest pleasures and most enduring books — *The Walking
Dead*, *World War Z* (Brooks), *The Stand* (King's pandemic-
zombie crossover), *Station Eleven* (Mandel on the literary
edge), *The Girl With All the Gifts* (Carey), *The Passage*
(Cronin), *Severance* (Ma), *Zone One* (Whitehead), *The
Reapers Are the Angels* (Bell), *Bird Box* (Malerman on the
adjacent register), *The Last of Us* in adaptation — are
about people under apocalyptic pressure, the moral physics of
collapse, and what survives in human beings when the
infrastructure of ordinary life is taken away. The zombies
are the pressure. The story is what people do under the
pressure. The techniques below are how the form delivers both
the visceral horror the reader has come for and the deeper
human reckoning the genre's strongest examples reach.

### The Visceral Encounter

Make zombie contact horrifying through specific sensory detail.
Sight alone isn't enough — layer smell (rot, decay, faeces, the
particular sweetness of late-stage decomposition), sound
(moaning, wet tearing, bone scraping, the click of teeth, the
sound of a body's last breath weeks after death), texture (cold
skin, breaking bone, slick fluids, the give of a skull that
has been compromised by months of weather). The wrongness of a
body that moves without life is the core horror — not movie-
zombie smooth but jerking, catching, a puppet operated by rot,
limbs that no longer remember how they were supposed to bend.

Key principle: Even hardened survivors should register physical
revulsion. The encounter can become routine in the character's
mind, but the prose must never let it become routine for the
reader. Vary the sensory focus — one encounter led by stench,
the next by sound, the next by the horrible familiarity of a
face you recognise. The genre's most-flagged failure is
encounter fatigue: by chapter twelve, the prose has stopped
treating zombies as horrifying and the reader has stopped
finding them so. The fix is calibration of register: the
fortieth encounter cannot be written with the same intensity
as the first, but it must still register as wrong. Where
encounters become routine, the prose should compensate by
finding the encounter's particular signature — this zombie
once worked in this building, the recognition of which makes
this kill different from the last.

### The Resource Clock

Create tension through depleting supplies made visceral on the
page. Don't just tell readers ammunition is low — show the
character counting rounds, choosing which weapon to carry,
weighing the noise cost of a gunshot against attracting more
shamblers, deciding whether the rabbit is worth the .22 round
it would take to kill it. Every resource is a character in
zombie fiction: the last antibiotic, the rusty can of beans,
the water filter that's failing, the half-tank of fuel, the
batteries that won't last another week, the pair of boots
beyond repair, the asthma inhaler with twelve doses left.

Key principle: Readers should feel the depletion. Use specific
numbers that decrease. "Fourteen rounds" in chapter three
becomes "nine rounds" in chapter seven becomes "three rounds"
in chapter twelve. The declining numbers create their own
tension without any zombie on screen. The technique extends to
non-numeric resources: the medication that runs out, the food
that finishes the last shelf-stable item, the season that
ends the local fruit harvest, the boots that develop a hole
that will not be repairable. Test the resource clock by listing
every depleting resource in chapter one and tracking each
across the book. Resources that don't decline (or that mysteriously
replenish without scavenging shown on the page) are the
failure mode the genre's strongest practitioners avoid.

### The Moral Slide

Track progressive line-crossing so readers feel the character's
humanity eroding. The first refusal to share food is agonising.
The third is practical. The seventh barely registers. This is
the genre's deepest horror — not the zombies but what survival
does to people who used to be decent. The form's central
ethical question is whether the protagonists, by the end of
the book, are still recognisably the people they were when the
outbreak began, and the answer is rarely a simple yes.

Key principle: Never skip a rung on the ladder. Show each new
moral compromise as slightly worse than the last, each
justification slightly more hollow. The character who couldn't
kill a zombie in chapter one is debating mercy-killing a
friend in chapter fifteen and stealing from children in
chapter twenty-five. Each step must be earned by the
escalating pressure: the writer who jumps to chapter-twenty-
five behaviour by chapter ten has lost the gradient that makes
the slide horrifying. Test the slide by listing every moral
compromise the protagonist makes, in chapter order, and
verifying each is one degree worse than the prior. The
strongest zombie novels run multiple parallel slides for
multiple characters, with the gradient differing per character
(the one who slides faster, the one who refuses to slide and
becomes a problem for the group, the one whose slide we
don't see until the reader realises it has happened off-
page).

### The Infection Paranoia

Build dread through the possibility of exposure. Every
scratch, every fever, every pause becomes suspect when
infection is fatal. The checking rituals — show me your arms,
show me your neck — are zombie fiction's equivalent of a
locked-room mystery. Someone's hiding something. Who? The
paranoia operates as both interpersonal mechanism (group
members watching each other for signs) and interior
mechanism (the protagonist tracking their own body for the
fever, the sluggishness, the wound that should not still be
warm).

Key principle: The paranoia itself is the threat, not just
the infection. Groups fracture over suspicion. Innocent fevers
cause standoffs. The infected character hiding a bite is a
ticking bomb, and every scene with them crackles because the
reader knows what the group doesn't. Stage the paranoia at
multiple levels: the protagonist's own body-monitoring; the
group's surveillance of each other; the new arrival whose
trustworthiness must be assessed; the silent member who has
been silent for a few days too long. The technique requires
that the writer commit to the genre's bleak math — the
infected character does, in the end, turn — and refuse the
sentimental rescue that would void the threat.

### The Horde Approach

Escalate mass threat through geography and time. A horde isn't
just "lots of zombies" — it's a natural disaster with intent.
Track it like weather: scouts report distance, estimated
numbers, rate of approach, terrain factors that will speed or
slow the wave. The slow mathematical certainty that they will
arrive creates dread no single zombie can match, and the
genre's signature set-piece is the prepared encampment under
escalating threat as the horde's eta closes in.

Key principle: Make the horde visible before it arrives. Dust
clouds. Distant moaning that grows louder over days. The smell
reaching the camp before the first shambler appears. The
preparation montage — boarding windows, counting ammunition,
choosing what to leave behind, the conversation about who
will be hardest to defend, the goodbye that won't be said
explicitly because nobody wants to say it. The preparation is
where the real drama lives. The technique requires temporal
specificity: how many days, how many hours, how many
minutes; the reader should feel the clock with the
characters. Generic "the horde was coming" is the failure mode;
"three days, perhaps four if the weather turns; eight hundred
of them at the last count, possibly more" is the technique.

### The Group as Microcosm

The surviving group functions as a society in miniature, and
the genre's strongest work treats it as one. Every group
contains a leadership question (who decides?), a resource
question (how is what we have allocated?), a justice question
(how do we treat the rule-breaker, the betrayer, the
infected, the new arrival?), a values question (what kind of
people will we be in the world after?), and an inclusion
question (who do we accept and who do we turn away?). These
questions are not abstract — they appear concretely in every
significant scene where the group makes a decision about
food, watch shifts, route, mercy, expansion, or another
person's life.

The technique requires that group members hold genuinely
different positions on these questions, and that the
positions be coherent (each member's stance follows from who
they were before the outbreak, what they have lost, and what
they fear). A group that votes unanimously on every difficult
question is not a microcosm; a group whose disagreements
follow predictable cardboard-cutout patterns ("the soldier
votes for force, the doctor votes for mercy") is also not. The
strongest zombie fiction stages the group's moral argument as
the book's deepest engine — the zombies arrive periodically
to threaten the body, but the group's internal physics drives
the plot. Test the microcosm: pick three significant group
decisions in the manuscript and ask, in each, whether the
positions taken were predictable from chapter one. If yes,
the group is plot mechanism; if the positions surprised the
reader and were earned by character, the microcosm is
operating.

The genre's contemporary leading practitioners (Robert
Kirkman in *The Walking Dead*'s middle seasons; Carey on the
small-group dynamics of *The Girl With All the Gifts*;
Whitehead on the bureaucratic-survival group of *Zone One*)
treat the group's internal pressure as more interesting than
the external threat — the zombies come and go in waves; the
group is together every day, and the slow accumulation of
decisions changes who they are.

### Zombie Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the world had ended" | Show the specific ruin through one detail — the school still in session signs, the fridge still displaying a child's drawing, the petrol pump showing yesterday's price |
| "survival was all that mattered" | Show the specific survival decision and its moral cost |
| "the horde descended" | Show the experience from one person's position with specific sensory detail |
| "supplies were running low" | Show the specific supply count and what runs out first |
| "trust was a luxury in the apocalypse" | Show the specific betrayal or trust test |
| "the stench of decay was everywhere" | Show the specific smell at the specific location with the specific source |
| "they were once human" | Show the specific recognisable human detail on one zombie — the wedding ring, the name tag, the half-finished knitting in the pocket |
| "the walls wouldn't hold" | Show the specific structural failure point and what each character does with the information |
| "a moment of humanity in the horror" | Show the specific humane act without authorial framing |
| "the real monsters were the living" | Show the specific human cruelty; the line itself is the genre's most-collapsed thesis |
| "another day survived" | Show the specific act that marked this day's survival |
| "she'd lost so much" | Show one specific loss and what its absence does in the present scene |
| "the city was a graveyard" | Show ONE specific feature of the abandoned city — the bird in the empty supermarket, the still-running advert on the broken billboard |
| "they had become something else" | Show what specifically they have become through behaviour, decision, or refusal |
| "death lurked around every corner" | Show the specific risk the characters are calculating in this specific corridor |
| "her humanity was slipping away" | Show the specific decision that marks the slip and the protagonist's specific awareness or denial of it |
| "the smell hit them" | Show the smell entering — through what door, in what weather, at what point of the protagonist's day |
| "civilisation was a memory" | Cut; show the specific contemporary item being repurposed (the office chair as defensive weapon; the schoolyard as fortified perimeter) |

## Genre-Specific Revision Rules

Six revision passes specific to zombie fiction, each with a
single question, run cover-to-cover before the next begins.
Zombie fiction has dual-discipline reader populations the
manuscript must satisfy: genre veterans who have read or
watched extensively in the form and detect mythology drift,
resource-tracking failures, and lazy choreography immediately;
and literary-fiction crossover readers who came for the
human-pressure register and detect cardboard characterisation
or unearned moral slides faster than the writer expected. The
passes below are ordered to surface mythology and resource
failures first (the genre veteran's territory), survival and
group-dynamics failures next (where character work
concentrates), action choreography after the rest is stable,
and the apocalyptic-logic audit last when the rest of the
book is sound enough to support the question of whether the
post-collapse world makes sense as a world.

### Pass 1: Zombie Consistency Audit

Verify the supernatural / pseudo-biological system follows its
own established rules throughout the manuscript. Zombie fiction
operates within multiple sub-conventions (slow shamblers; fast
runners; smart "feral"; viral; fungal; supernatural curse;
hybrid) and the chosen variant must be held throughout. Build
a zombie-rules ledger: every named characteristic of the
zombies in this world (speed, sensory range, infection
vector, gestation period, vulnerabilities, behavioural
patterns, decay timeline, group behaviour, intelligence floor
and ceiling, environmental factors), with the chapter and
page where each first appears. Read the manuscript against
the ledger. Flag every instance where convenience has
overridden consistency — typically the climactic chapter, where
a writer reaches for behaviour the rules have not allowed
(the slow shambler that suddenly sprints, the head-shot rule
that conveniently fails for the antagonist, the infection
that has a different timeline this time). Verify the infection
vector is identical in every depicted transmission, that
vulnerabilities remain constant (head destruction, fire,
brain-stem damage, whatever the rules have established), and
that the post-mortem behaviour of zombies follows the same
rules the writer set up early. The genre's reader has high
tolerance for any variant of zombie convention but no
tolerance for inconsistency within a single book.

### Pass 2: Resource Tracking Audit

Build a chapter-by-chapter resource ledger. For every
significant resource introduced in the manuscript — ammunition,
food (broken out by category: shelf-stable, perishable, fresh-
acquired), water (clean, untreated, requiring filtration),
fuel (vehicle, generator, cooking), medication (specific drugs
named, with quantity), batteries, weapons (with degradation
state), tools, vehicles, transport capacity, footwear, layered
clothing, ammunition by calibre, working radios, working
solar panels, working firearms by type — track the count or
state across every scene in which the resource appears or is
implied. Verify every supply gain is explained on the page
(scavenging shown in scene, trade negotiated, theft staged) and
every supply loss is accounted for (combat round-count,
consumption rate, item lost in flight). Verify weapons degrade,
jam, break, rust, lose accuracy — modern firearms in
particular do not function indefinitely without maintenance,
and the genre's failure mode is the AR-15 that fires perfectly
in chapter forty after months of mud, water, and neglect.
Where the manuscript depicts long-term sustainable supply (a
group with full food security after eighteen months), verify
the production system shown on the page can support what the
characters are eating: gardens of plausible size, livestock
in plausible numbers, scavenging routes whose viable yield is
shown.

### Pass 3: Survival Realism Check

Read the manuscript for survival-physics consistency.
Characters under apocalyptic pressure should show exhaustion,
hunger, dehydration, sleep deprivation, injury accumulation,
and the slow physical degradation of life on the road or
behind the wall. Verify that characters' bodies remember what
the plot has demanded of them: the protagonist who walked
forty miles in the previous chapter is in pain, hungry,
dehydrated, and limping in this chapter; the character who
spent the night on watch is groggy and slower the next day;
the wounded character does not heal on a Hollywood timeline
but takes weeks to regain function, with infection risks the
prose registers. Check that physical limitations affect
combat and travel capability — the malnourished group does
not run as fast as the well-fed group; the dehydrated
character makes worse decisions and the prose shows it.
Verify wounds are tracked across chapters with realistic
healing arcs, not magically resolved by the next set-piece.
The genre's signature pleasure includes its grinding
realism; manuscripts that allow characters to remain combat-
ready, well-rested, and uninjured across a full apocalyptic
narrative have lost the contract.

### Pass 4: Group Dynamics Integrity

Verify the surviving group's dynamics develop coherently across
the manuscript. Build a roster: who is alive at the end of
each chapter, who has joined the group when, who has left or
died when. The genre is unforgiving of roster errors (the
character who was killed in chapter ten reappearing in a
crowd scene in chapter twenty without explanation; the new
arrival whose introduction the writer has forgotten to write).
Verify group conflicts build naturally from resource pressure
and moral differences — see The Group as Microcosm technique
above. Check that trust levels are consistent with events:
betrayals remembered, bonds earned, alliances tested.
Characters who betrayed the group in chapter twelve do not
get treated as fully reintegrated by chapter thirteen; bonds
forged in shared catastrophe are not forgotten in shared
boredom. Verify character deaths have lasting emotional
impact on survivors — the group does not function the same
without each lost member, and the prose should register the
gap (the empty seat at the council, the meal that has too
much food now, the question that nobody is left to ask).
Test: pick three group conflicts and trace each one's
prefiguration in the chapters before it erupts. If the conflict
appears without prior tension, the dynamic is plot-driven
rather than group-driven.

### Pass 5: Action Choreography Review

Read every action sequence with diagrammatic specificity. Are
fight scenes spatially clear — positions, numbers, terrain,
escape routes, lines of sight, range to engagement? The
genre's most-flagged failure is the action scene that cannot
be visualised because the writer has not been clear about
where everyone is and what is between them. Verify ammunition
expenditure is tracked during combat sequences (every round
fired comes off the ledger; the sub-machine gun does not have
infinite ammunition). Verify kills require realistic effort:
zombies absorb multiple hits, even head shots are not
guaranteed at distance, hand-to-hand combat with a corpse
that has months of decay is structurally exhausting and
requires effort the prose should register. Verify noise from
combat attracts additional threats — the firefight in chapter
seven that brings a horde in chapter eight establishes a
rule the rest of the book must honour; protagonists who fire
twenty rounds in a wooded area without consequence have broken
the world. Test choreography clarity by re-reading each
significant action scene asking: could this be filmed from the
prose? If not, the choreography is gestural, and the reader's
investment in the outcome is shakier than it should be.

### Pass 6: The Apocalyptic Logic Audit

The post-collapse world has its own physics, and zombie
fiction's deepest craft failure is the unaudited apocalyptic
world — the petrol that still works fine after two years; the
satellite phones that have continuing global coverage; the
batteries that never die; the clothing that never wears out;
the survivors who have access to medications no functioning
pharmacy could still produce. Run a final pass on the
apocalyptic infrastructure:

- **Electricity** — the grid is down within weeks of mass
  worker absence; specific exceptions (hospitals with on-site
  generators that run only as long as fuel lasts; nuclear
  plants entering automated shutdown; hydro stations that may
  continue producing locally if the dams hold and the
  distribution lines don't fall) operate within real
  constraints.
- **Petrol and diesel** — gasoline degrades within a year
  without stabiliser; diesel lasts somewhat longer but still
  gels, oxidises, and grows microbial contamination; the
  vehicle that starts on year-old fuel is, at minimum,
  unreliable and possibly broken.
- **Communications** — cellular networks fail with grid power;
  internet is fragmented and largely unavailable; satellite
  phones require functioning satellites and ground stations
  whose maintenance has stopped; HAM radio works but requires
  power and skill; the working CB radio in the truck has range
  measured in tens of miles, not country-wide reach.
- **Water** — municipal water requires powered pumping; gravity
  systems may continue locally; well water requires a working
  pump or hand-pumping; surface water requires filtration and
  boiling that requires fuel.
- **Food production** — agriculture takes labour, seed, soil
  preparation, livestock care, and time the protagonists may
  not have if they are still mobile; the "we'll just garden"
  solution requires a settled location, climate-appropriate
  seed, soil knowledge, and at least a season's wait for
  harvest.
- **Medical supplies** — antibiotics, insulin, asthma
  inhalers, blood-pressure medication, anti-seizure
  medication, and most prescription drugs depend on
  pharmaceutical supply chains that have collapsed; the
  diabetic character without functioning insulin has months,
  not years.
- **Order and authority** — government, military, police,
  hospitals, courts, and the institutions of civilian order
  all have specific failure modes and timelines; the nominally-
  intact military unit five years after collapse is doing
  something specific that the prose should explain (where
  did the fuel come from; who is paying the soldiers; what
  is their food source; how is the chain of command
  maintained).

The pass is not asking the manuscript to be a survivalist
manual; it is asking the apocalyptic infrastructure to be
internally consistent and to acknowledge its own limits where
those limits matter to the plot. Test: pick three plot
points that depend on specific apocalyptic infrastructure
working (a working vehicle, a working communication, a working
medical supply) and verify each one is plausible given the
time elapsed since collapse and the conditions shown. If the
infrastructure is convenient where the plot needs it and
absent where it doesn't, the world has not been audited and
the genre's reader will detect the unevenness.

## Names & Patterns to Avoid

### Forbidden Patterns
- The scientist who conveniently knows everything about the virus
- Unlimited ammunition in pistols that never need reloading
- Characters making horror-movie stupid decisions to advance plot
- Zombies as background scenery rather than persistent threat
- Clean, well-fed survivors months into apocalypse
- The military that conveniently arrives at the last moment
- Infection rules that change whenever the plot needs them to
- Villain survivors who are evil for evil's sake. motivation needed
- Children who are either invulnerable plot armour or instant tragedy

### Cliche Setups to Avoid
- The government cover-up that caused the outbreak (unless deeply original take)
- The "one last mission" that's actually last
- The character who dies immediately after revealing personal information
- Safe zones that are always corrupt or fake
- The love triangle in the middle of the apocalypse that feels like a CW show
- Zombies that are intelligent only when the plot requires it
- The lone wolf who's conveniently skilled at everything

### Naming Considerations
- Names should feel real and varied. not everyone is Jake, Sarah, or Rick
- Cultural diversity in names reflects realistic survivor populations
- Nicknames earned through survival events feel authentic
- Avoid names too similar to iconic zombie fiction characters (Rick, Glenn, Daryl, etc.)

## Comp Titles

Zombie fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *I Am Legend* — Richard Matheson (1954): the proto-zombie / vampiric-pandemic novel.
- *Night of the Living Dead* — George A. Romero (1968, film): the modern zombie archetype.
- *World War Z* — Max Brooks (2006): the oral-history zombie-pandemic benchmark.
- *The Walking Dead* — Robert Kirkman (2003-, comic): mass-market zombie-survival template.

### Contemporary (current best-in-class)

- *The Girl with All the Gifts* — M.R. Carey (2014): literary zombie-pandemic.
- *Zone One* — Colson Whitehead (2011): literary zombie-fiction; post-apocalyptic urban survival.
- *The Reapers Are the Angels* — Alden Bell (2010): literary zombie-Western.
- *Severance* — Ling Ma (2018): zombie-pandemic-as-labour-critique literary novel.
- *Wanderers* — Chuck Wendig (2019): contemporary zombie-pandemic doorstop.
- *Feed* — Mira Grant (2010): the Newsflesh trilogy; political-blogosphere zombie-thriller.
- *The Living Dead* — George A. Romero & Daniel Kraus (2020): the genre's own founder's posthumous epic.

## Cover Design Specifications

### Visual Tone
- Dark, gritty, desolate
- Post-apocalyptic decay. civilisation crumbling, nature reclaiming
- Danger present but not gratuitously gory
- Isolation and survival as visual themes

### Key Visual Elements
- Silhouettes against ruined cityscapes or empty roads
- Abandoned infrastructure. overgrown buildings, broken highways
- Weapons and survival gear as visual shorthand
- Horde implied through shadows, shapes, or fog
- Single survivor or small group against vast desolation

### Typography
- Bold, distressed, or stencil fonts. military/survival feel
- Title dominant with large, impactful lettering
- Author name visible but secondary to imagery
- Genre signals clear through font choice and treatment

### Colour Palette
- Primary: Desaturated greys, browns, greens. decay palette
- Accent: Blood red or infection green for contrast
- Atmosphere: Fog, smoke, dust. limiting visibility
- Avoid: Bright, clean, or cheerful palettes
- High contrast between dark backgrounds and text

### Comp Titles (Cover Style Reference)
- *The Road* by Cormac McCarthy. desolate, literary, haunting
- *World War Z* by Max Brooks. documentary realism, global scale
- *The Girl with All the Gifts* by M.R. Carey. literary horror, emotional
- *Station Eleven* by Emily St. John Mandel. atmospheric, post-apocalyptic beauty
