---
name: paranormal-genre
description: Genre-specific instructions for paranormal fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [general]
---

# Paranormal. Genre Plugin

## Metadata
- id: paranormal
- name: Paranormal
- icon: 👻
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Dan Harmon Story Circle"]

## Subgenre Options
Present during setup:
- **Ghost Stories**. Hauntings, unfinished business, the boundary between living and dead; atmosphere and dread over action
- **Psychic/Medium**. Characters with paranormal abilities navigating a world that doesn't believe them; the gift-as-burden framework
- **Paranormal Investigation**. Teams or individuals who investigate supernatural events; procedural meets the unexplainable
- **Urban Paranormal**. Supernatural elements woven into modern city life; ghosts in the subway, spirits in old buildings, the hidden layer beneath the everyday
- **Historical Paranormal**. Supernatural events in a specific historical period; spiritualism, séances, plague hauntings, ancient curses
- **Paranormal Suspense**. Thriller structure with supernatural elements; the protagonist must solve a mystery where the rules of reality don't fully apply

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Slow build to crescendo. atmosphere accumulates, tension escalates, then the paranormal erupts
- Must open with: The normal world slightly OFF. something not quite right, noticed by the character or felt by the reader

BEATS PER CHAPTER
1. The Uncanny Beat. Something happens that can't quite be explained; the reader and character both feel the wrongness
2. Grounding Beat. The normal world reasserts itself; daily life, relationships, work. the contrast makes the paranormal more powerful
3. Investigation/Discovery Beat. The character seeks answers: research, questioning, exploring, testing
4. Escalation Beat. The paranormal presence grows stronger, more intrusive, harder to deny or rationalise
5. Emotional Cost Beat. The paranormal experience takes a toll: fear, isolation, doubt, obsession, grief

THE PARANORMAL ARCHITECTURE
- The paranormal is NOT the normal state. it intrudes upon the ordinary, and that contrast is the genre's engine
- The veil between worlds is thin, not absent: paranormal events happen at thresholds (doorways, mirrors, twilight, the moment between sleep and waking)
- The supernatural follows RULES. even if the characters don't know them yet; internal consistency is essential
- Atmosphere is everything: the reader should feel uneasy before anything explicitly paranormal occurs
- The paranormal is connected to EMOTION: grief, guilt, rage, love, fear. ghosts don't haunt houses, they haunt people
- Ambiguity is a tool (not a requirement): the reader may question what's real and what's imagined, but the author must KNOW
- POV: First person or tight third past (the intimacy of one person's experience is crucial)

THE NORMAL WORLD
- Must be fully realised: the protagonist has a job, relationships, habits, a life that the paranormal disrupts
- The more real the normal world, the more powerful the paranormal intrusion
- Small domestic details ground the story: making coffee, driving to work, paying bills
- These details become unsettling when the paranormal touches them (the coffee is always cold; the car radio plays a dead woman's favourite song)

THE PARANORMAL PRESENCE
- It has a logic: why here, why now, why this person
- It escalates: first subtle (a feeling, a temperature change), then undeniable (objects moving, voices, apparitions)
- It has a PURPOSE: communication, warning, revenge, connection, protection
- It is not random: the paranormal events form a pattern the protagonist must decode
- It can be terrifying AND sympathetic: the ghost is not always the villain

FORBIDDEN IN PARANORMAL
- Jump scares without build-up (the genre needs atmosphere, not cheap shocks)
- The paranormal as background decoration (if it doesn't drive the plot, it's wallpaper)
- "It was all a dream" / "they were crazy" resolutions (respect the genre's premise)
- Instant expertise (the protagonist shouldn't immediately understand what's happening)
- Ghosts/spirits with no logic or motivation (random haunting is boring)
- Ignoring the emotional core (paranormal fiction is about GRIEF, GUILT, LOVE, or FEAR. not just spooky events)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (encounter intensity), Captivation (otherworld atmosphere), Anticipation (next manifestation), Affection at companion bonds.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person or tight third past tense (the reader must be locked into one character's perception)
- Voice: Grounded, observant, slightly anxious. the voice of someone trying to make sense of the impossible
- Tone: Atmospheric dread punctuated by moments of wonder or sorrow; NOT horror-level terror (paranormal sits between thriller and horror)
- Register: Contemporary and accessible, but with heightened sensory awareness

PROSE IMPERATIVES
- ATMOSPHERE FIRST: build the mood before the event
  - Temperature changes, shadows that linger, silence that feels heavy, light that behaves oddly
  - The character's body reacts before their mind does: goosebumps, held breath, the urge to leave a room
- SENSORY SPECIFICITY: paranormal events engage senses in unexpected ways
  - A smell that shouldn't be there (flowers in winter, perfume of a dead person, burning when there's no fire)
  - Sound: whispers, footsteps, music, a child's laugh, the absence of sound
  - Touch: cold spots, the feeling of being watched, pressure on the skin, breath on the neck
  - Sight: peripheral movement, shadows that don't match, reflections that linger, lights that flicker with intent
- THE UNCANNY VALLEY: the most effective paranormal moments are things that are ALMOST normal
  - A door that was closed is now open. not dramatic, just wrong
  - A photograph that looks different from how you remember it
  - A message on a foggy mirror that could have been your own breath
- RESTRAINT: less is more. the reader's imagination is your best tool
  - Suggest rather than show (at first)
  - Delay the full reveal: partial glimpses are more unsettling than clear sightings
  - The protagonist trying to rationalise what they've experienced is more powerful than certainty

PROSE RHYTHM MAPPING
- Chapter 1 must establish the normal world + the first supernatural intrusion. grounded rhythm disrupted by something wrong
- The grounded baseline: medium sentences (14-20 words), calm, observant, domestic. The rhythm of ordinary life. making coffee, driving, opening a door. Comfortable. Lulling
- The supernatural disruption: when something wrong occurs, the rhythm BREAKS. A shorter sentence (6-12 words). A fragment. A pause. The prose stutters the way perception stutters when reality shifts
- The progression across the chapter: GROUNDED rhythm → subtle wrongness (one shorter sentence amid normal ones) → return to normal → slightly longer wrongness → rationalization → back to baseline. The pattern builds like a heartbeat developing an arrhythmia
- Opening paragraphs: pure grounded rhythm. Nothing wrong yet. The reader settles into the normal world's pace. medium sentences, domestic detail, calm observation. This calm is what makes the disruption powerful
- The uncanny moment: do NOT accelerate. Let the sentence that carries the wrong detail be the same LENGTH as surrounding sentences but carry a different charge. The rhythm doesn't announce the horror. the horror lives inside the normal rhythm
- Physical fear responses: short sentences (8-12 words). The body reacting before the mind catches up. Goosebumps. Held breath. The impulse to leave. Quick. Instinctive
- Rationalization passages: medium-long sentences (18-24 words) as the protagonist explains things away. The rhythm of someone deliberately calming themselves. measured, logical, slightly too controlled
- Investigation scenes: steady medium rhythm (14-18 words), building through accumulated details. Each sentence adds a piece. The rhythm of someone following a trail
- Tension baseline: ≥5 from the first page. Even in the "normal" world, the reader should feel a subtle undercurrent. the rhythm just slightly off-kilter, not quite as comfortable as it pretends to be
- Silence as rhythm tool: a paragraph break where a sound should be. White space on the page. The ABSENCE of the expected sentence creates more dread than any description
- Escalation across chapters: paranormal intrusions break the rhythm more severely as the story progresses. longer disruptions, more fragmented prose, the normal baseline harder to return to
- Temperature/atmosphere descriptions: slightly longer sentences (18-22 words) that slow the pace. the reader lingers in the room, feeling the cold, noticing the shadow
- End-of-chapter rhythm: one final sentence that is either perfectly normal (and therefore unsettling in what it doesn't say) or one degree wrong (the door that was open, the sound that stopped)
- Read the transition from normal to paranormal aloud. the rhythm shift should be felt before it's understood
- Dialogue rhythm: normal conversation (medium, natural) interrupted by ONE sentence that doesn't belong. the friend's pause, the question they don't ask, the phone that rings once and stops
- The goal: prose with a heartbeat. steady and calm until something makes it skip, then steady again, but the reader can never fully relax because they know the skip is coming

GROUNDING PROSE
- Ground every paranormal scene with physical reality:
  WRONG: "The ghost appeared before her, glowing with ethereal light, and spoke in a voice from beyond the grave."
  RIGHT: "The bedroom was cold. Not the cold of a window left open. she checked. but a cold that sat in the centre of the room like something solid. The lamp on the nightstand flickered, steadied, and then she smelled lavender. Her mother's lavender. Her dead mother's."
- Paranormal events should feel like they're happening TO a real person in a real place
- The character's emotional reaction is as important as the event itself

DIALOGUE CRAFT
- The protagonist talking about their experiences to non-believers: the frustration, the fear of being dismissed
- Paranormal communication: fragmented, symbolic, incomplete (spirits don't have PowerPoint)
- Other characters' scepticism: realistic, well-argued, challenging
- When the paranormal speaks: use restraint. single words, repeated phrases, fragments, NOT full speeches
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

PARANORMAL CRAFT (40% of total):
- Atmosphere builds effectively before paranormal events? (0-100)
- The paranormal follows internal logic/rules? (0-100)
- Normal world is fully realised (contrast with the paranormal)? (0-100)
- Emotional core (grief, guilt, love, fear) drives the haunting? (0-100)

STORY CRAFT (30% of total):
- The investigation/discovery arc is compelling? (0-100)
- Escalation is paced well (subtle → undeniable)? (0-100)
- The protagonist's emotional journey is central? (0-100)
- The resolution addresses both mystery and emotion? (0-100)

PROSE QUALITY (30% of total):
- Atmosphere is built through sensory detail, not stated? (0-100)
- Paranormal events are grounded in physical reality? (0-100)
- Restraint is used effectively (suggestion over exposition)? (0-100)
- The uncanny valley is achieved (almost-normal is more powerful than impossible)? (0-100)

AUTOMATIC FAILS (score = 0):
- Jump scares without atmospheric build-up
- "It was all in their head" dismissal of the paranormal premise
- Ghosts/spirits with no logic, purpose, or emotional connection
- Paranormal events that are purely decorative (spooky but pointless)
- Full-explanation dump that removes all mystery
- The protagonist immediately understands and controls the paranormal
```

## Continuity Rules

```
PARANORMAL CONTINUITY. WHAT TO TRACK

PARANORMAL STATE:
- What paranormal events have occurred, in what order, and their escalation level
- The pattern: what connects the events (location, time of day, emotional state, trigger)
- Rules established: what the paranormal can and cannot do (once shown, must be consistent)
- Communication: what the spirit/presence has conveyed and how
- Evidence: what physical traces remain (photographs, recordings, damage, objects moved)

INVESTIGATION STATE:
- What the protagonist knows (and when they learned it)
- Research conducted: historical records, interviews, expert consultations
- Theories formed and tested: what's been disproven, what remains plausible
- Other characters' knowledge: who believes, who doesn't, who has critical information
- Objects of significance: items connected to the haunting (heirlooms, photographs, locations)

EMOTIONAL STATE:
- The protagonist's psychological arc: scepticism → doubt → fear → understanding → resolution
- Grief/guilt/love progression: how the emotional core evolves
- Relationships under strain: who the protagonist can still trust, confide in, rely on
- Isolation level: as paranormal experiences increase, social isolation often follows
- Sleep, health, and daily functioning: paranormal stress has cumulative effects

LOCATION STATE:
- Which locations are active (paranormal events occurring)
- History of each location: who lived there, what happened, what residual energy remains
- Changes to locations: objects appearing/disappearing, temperature zones, electrical anomalies
- Safe spaces: where the protagonist can retreat (and when those spaces stop being safe)

TEMPORAL STATE:
- Time of day patterns: when events occur (3 AM, twilight, anniversaries)
- Historical timeline: the backstory that created the haunting
- Escalation timeline: events are getting closer together, more intense
- Deadlines: some paranormal narratives have a clock (an anniversary, a demolition date, a birth/death)
```

## Character Rules

```
PARANORMAL CHARACTER TYPES

THE PROTAGONIST (THE HAUNTED):
- An ordinary person thrust into extraordinary circumstances
- Has a REASON to be haunted: they moved into the house, they resemble someone, they have unresolved grief, they stumbled onto something
- Their everyday competence contrasts with their helplessness against the paranormal
- They must STRUGGLE to understand: investigation, research, trial and error
- Their emotional vulnerability is the story's heart: what are they grieving, fearing, or denying?
- They resist believing before they accept. and their acceptance costs them something

THE SCEPTIC:
- A friend, partner, or authority figure who doesn't believe
- NOT stupid or dismissive. their scepticism is reasonable and well-argued
- They provide the counterweight that makes the paranormal more powerful
- Their eventual belief (or stubborn denial) is a key plot point
- They ground the story in consensus reality

THE BELIEVER/GUIDE:
- Someone who has experience with the paranormal (a medium, a priest, a researcher, a local historian)
- They provide context but NOT complete answers
- They have their own scars from paranormal encounters
- They can help but cannot solve. the protagonist must face this themselves
- They may be unreliable: genuine or charlatan, wise or deluded

THE SPIRIT/PRESENCE:
- Has a HISTORY: they were a person with a life, relationships, and unfinished business
- Their behaviour follows their emotional state (rage manifests differently from grief)
- They communicate imperfectly: fragments, symbols, repetition, sensation
- They are NOT all-powerful: they have limitations, cycles, and vulnerabilities
- They may be sympathetic, terrifying, or both. the reader's relationship with the spirit should shift

THE WITNESS:
- A neighbour, colleague, or stranger who has also experienced something
- Validates the protagonist's experience (they're not alone, not crazy)
- Has their own interpretation of events (which may be wrong)
- Their experience may provide a crucial piece of the puzzle

VOICE DIFFERENTIATION:
- The haunted protagonist: observant, anxious, increasingly certain despite external doubt
- The sceptic: rational, concerned, explaining things away with decreasing confidence
- The guide: experienced, cautious, speaking from hard-won knowledge
- The spirit: fragmented, repetitive, emotionally charged, non-linear
```

## Arc Rules

```
PARANORMAL STORY STRUCTURE

ACT 1: THE DISTURBANCE (first 25%)
- Establish the protagonist's normal world: their life, relationships, routines
- The first paranormal event: subtle, deniable, easily rationalised
- The protagonist dismisses it. but the reader shouldn't
- A second event: slightly less deniable, unsettling
- The emotional seed is planted: what connects the protagonist to this haunting?
- END OF ACT 1: Something happens that cannot be dismissed. the protagonist begins to investigate

ACT 2A: THE INVESTIGATION (to midpoint)
- The protagonist seeks answers: research, interviews, exploration
- Paranormal events escalate: from subtle to visible, from rare to frequent
- The pattern begins to emerge: the haunting has a logic
- Other characters react: the sceptic dismisses, the believer validates
- The protagonist's normal life begins to suffer: work, relationships, sleep
- MIDPOINT: A major revelation. the backstory of the haunting is partially understood, and the emotional connection becomes clear

ACT 2B: THE HAUNTING DEEPENS (midpoint to dark moment)
- The paranormal presence becomes aggressive or desperate (escalation)
- The protagonist's understanding grows. but so does the danger
- The sceptic is confronted with evidence they can't explain
- The emotional core is fully exposed: the grief, guilt, or love at the heart of the story
- The protagonist's safe spaces are compromised (the haunting follows them)
- DARK MOMENT: Direct confrontation with the paranormal. terrifying, overwhelming, and clarifying

ACT 3: THE RESOLUTION (final 25%)
- The protagonist understands the haunting fully: who, why, and what's needed
- The emotional work: forgiveness, acceptance, release, or sacrifice
- The final confrontation is emotional, not just supernatural
- The haunting resolves. but the resolution is bittersweet (something is gained, something is lost)
- The normal world is restored. but the protagonist has changed
- The ending lingers: one final ambiguous detail, a last cool breeze, a photograph that might have changed

PARANORMAL PACING:
- SLOW BUILD: Act 1 is patient; atmosphere before event
- ACCELERATING: events become more frequent and intense through Act 2
- The quiet scenes become fewer and more precious as the story progresses
- The climax is both the scariest AND the most emotionally raw moment
- The resolution is QUIET: after the storm, stillness
```

## Timeline Rules

```
PARANORMAL TIMELINE

ESCALATION TIMELINE:
- Paranormal events follow a pattern of increasing frequency and intensity
- Track the intervals between events: they should be getting shorter
- The escalation should feel organic, not mechanical (the spirit is becoming more desperate/powerful)

HISTORICAL TIMELINE:
- The backstory of the haunting: when the death/trauma/event occurred
- Significant dates: anniversaries, birthdays, the date of death
- The historical period affects the story: a Victorian ghost behaves differently from a 1970s one
- How the backstory was discovered: each piece of history should be revealed at the right dramatic moment

DAILY TIMELINE:
- Time of day matters: paranormal events often cluster at specific times (3 AM, twilight, midnight)
- The protagonist's daily routine is disrupted progressively
- Sleep patterns: deteriorating as the haunting intensifies
- The contrast between daytime normalcy and nighttime terror

SEASONAL/WEATHER:
- Some paranormal stories are tied to seasons (winter isolation, autumn thinning of the veil)
- Weather as atmosphere: fog, storms, oppressive heat, unseasonable cold
- Environmental changes that might be paranormal or might not (temperature drops, electrical interference)
```

## Genre-Specific Craft Techniques

Paranormal fiction (distinct from paranormal romance,
which centres romantic-relationship architecture) is the
genre of supernatural intrusion into recognisable
contemporary or near-contemporary reality. The genre
operates by a contract: the everyday world must be
rendered with enough texture that the supernatural
intrusion lands with weight, the rules of the
supernatural element must be internally consistent, and
the protagonist's resistance and eventual acceptance
must be psychologically credible. The canonical roster
— Shirley Jackson (The Haunting of Hill House, We Have
Always Lived in the Castle, The Lottery), Henry James
(The Turn of the Screw), Susan Hill (The Woman in
Black), Sarah Waters (Affinity, The Little Stranger),
Daphne du Maurier (Don't Look Now), Stephen King (The
Shining, Pet Sematary, IT, the Gunslinger sequence in
its paranormal register), Anne Rice — established the
form; the contemporary masterclass roster — Carmen
Maria Machado (Her Body and Other Parties, In the
Dream House), Catriona Ward (The Last House on Needless
Street, Sundial), Silvia Moreno-Garcia (Mexican Gothic),
T. Kingfisher (What Moves the Dead, The Hollow Places),
Andrew Michael Hurley (The Loney, Devil's Day, Starve
Acre), Jennifer McMahon (The Winter People, The
Drowning Kind), Mariana Enríquez (Things We Lost in the
Fire, Our Share of Night), Helen Oyeyemi (White Is for
Witching), Stephen Graham Jones, Cassandra Khaw, Kelly
Link, Premee Mohamed, Lisa Tuttle — has expanded the
genre's range to queer, post-colonial, diasporic, and
working-class registers that the canonical roster
historically underweighted. The most common failure
modes in this register are: **Atmospheric-Without-
Stakes** (the manuscript renders mood and dread but
does not produce material consequence; the supernatural
is unsettling but does not actually threaten or
transform); **Rules-Drift** (the supernatural's
behaviour shifts to suit the plot; what worked in
chapter 7 stops working in chapter 17 without
explanation); **Over-Explanation** (the manuscript that
explains the supernatural too thoroughly, draining the
mystery; the genre often works through partial
disclosure and unfilled gaps); **Rational-Resistance
Skipped** (the protagonist accepts the supernatural too
easily; the genre's psychological credibility depends
on rationalisation as friction); **Emotional-Core
Absence** (the supernatural element disconnected from
the protagonist's specific emotional landscape; the
haunting that has nothing to say to the haunted);
**Generic-Ghost Architecture** (the supernatural
element treated as interchangeable haunt-template
rather than as specifically rendered presence with
specific origin, specific purpose, specific rules);
**Sceptic-or-Believer Binary** (the manuscript that
positions the protagonist as either sceptic or believer
without rendering the messy in-between where most
people actually live); **Mundane-Erasure** (the daily
world's texture so thin that the supernatural intrusion
has nothing to disrupt); **Finale-Reveal Over-Reach**
(the ending that explains everything definitively when
the genre's strongest endings often preserve some
ambiguity); and **Period or Cultural Anachronism** (the
supernatural framed through a period or culture's
lens that the manuscript has not researched). The
techniques below — three preserved (Slow Burn
Escalation, Grounding Anchor, Rational Resistance) and
three added (Specific-Origin Architecture, Emotional-
Core Linkage, Productive-Ambiguity Discipline) — are
designed to keep the genre's defining commitments
live: rules consistent and partial, supernatural with
specific origin, emotional core that connects haunt to
haunted.

### The Slow Burn Escalation

Paranormal events should follow a deliberate escalation pattern:

```
Level 1 (Ch 1-3): FEELING. Something is off, but nothing visible
  "She stood in the hallway and thought: I don't want to
  go upstairs. No reason. Just. not tonight."

Level 2 (Ch 3-5): SENSORY. A sense is engaged unexpectedly
  "The smell of pipe tobacco. No one in the house smoked.
  The windows were closed."

Level 3 (Ch 5-7): EVIDENCE. Physical trace that can't be denied
  "Three photographs on the mantelpiece. She'd arranged
  them that morning. Now they were face-down. All three."

Level 4 (Ch 7-9): ENCOUNTER. Direct experience
  "The shape at the end of the corridor. Standing. Not
  moving. Darker than the darkness around it."

Level 5 (Ch 9+): COMMUNICATION. The presence makes its purpose known
  "Her name. Written in the condensation on the bathroom
  mirror. In handwriting she recognised."
```

### The Grounding Anchor

Before every paranormal scene, anchor the reader in physical reality:

- The character is doing something mundane (cooking, reading, driving)
- The environment is described in specific, sensory detail
- The character's emotional state is established
- THEN the disruption occurs. and the contrast makes it powerful

### The Rational Resistance

The protagonist's attempts to explain away the paranormal are crucial:

- "It must have been the wind" (but there's no wind)
- "I'm just tired" (but they slept eight hours)
- "Old houses make noises" (but this is a new build)
- Each rationalisation fails more obviously than the last
- The reader should be ahead of the character in accepting the truth

### Paranormal Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the veil between worlds was thin" | Show the specific bleed-through event |
| "she could sense the spirits" | Show the specific sensation. cold, pressure, sound |
| "the supernatural was real" | Show the specific evidence that convinces |
| "powers beyond understanding" | Show the specific power through its specific effect |
| "the haunting intensified" | Show the specific escalation. what happens now that didn't before |
| "a gift. or a curse" | Show the specific advantage and specific cost |
| "the entity made its presence known" | Show the specific physical manifestation |
| "the investigation took a dark turn" | Show the specific discovery |
| "psychic energy filled the room" | Show the specific physical effect on people and objects |
| "the paranormal team had seen nothing like it" | Show the specific unprecedented event |
| "communication from beyond" | Show the specific message and specific medium |
| "an evil presence" | Show the specific presence (named, located, with specific origin) |
| "the spirit was restless" | Show the specific manifestation that demonstrates restlessness |
| "she sensed something watching" | Show the specific physical signal her body is responding to |
| "the temperature dropped" | Show the specific cold (where in the room, what visible change, the breath visible) |
| "a chill ran down her spine" | Cut cliché; show the specific physical response (the prickle at the nape, the held breath) |
| "ancient magic" | Cut "ancient"; show the specific origin (named tradition, named period, named source) |
| "the dead do not rest" | Show ONE specific evidence in this specific scene |

### The Specific-Origin Architecture

The Generic-Ghost Architecture failure mode produces
hauntings that could be anyone — interchangeable
haunt-templates without specific origin, specific
purpose, or specific rules. The Specific-Origin
Architecture is the requirement that every supernatural
presence in the manuscript have a specific identifiable
origin, a specific motivation, and specific operating
constraints.

```
PRINCIPLE
For every significant supernatural presence in the
manuscript, the writer must establish at least four of
the following five specifics:
1. NAMED HISTORICAL ORIGIN — the presence has a
   specific identifiable past (named historical person,
   named period, named event that produced the haunt;
   the presence is not just "a ghost" but the specific
   ghost of someone the writer knows the biography of)
2. SPECIFIC MOTIVATION — the presence wants something
   specific (revenge against named target, completion
   of named unfinished business, communication with
   named living person, escape from named bind); not
   "to scare" but specific named drive
3. SPECIFIC OPERATING CONSTRAINTS — the presence
   operates under specific rules (cannot cross
   specific barriers, manifests only in specific
   conditions, weakens at specific times,
   strengthens with specific triggers); the
   manuscript's reader can extract these rules
4. SPECIFIC PHYSICAL TEXTURE — the presence has
   specific sensory signatures (specific cold,
   specific smell, specific sound, specific visual
   manifestation, specific behaviour with specific
   objects)
5. SPECIFIC RESOLUTION CONDITIONS — the presence can
   be addressed (resolved, dismissed, satisfied,
   escaped, contained) under specific named
   conditions; the manuscript's craft is partly in
   what the protagonist must do to address the
   presence

CALIBRATION TEST
- Could the supernatural presence be replaced with a
  generic haunt-template without the manuscript
  losing anything specific? If yes — rebuild.
- Are the presence's origin, motivation, constraints,
  texture, and resolution-conditions specifically
  rendered or just implied?
- Does the reader understand the rules well enough
  to make predictions about what will and won't
  work against the presence?
If any answer is no — rebuild for origin specificity.

ANTI-PATTERN
- "A ghost" with no biography
- "An evil presence" with no specific evil
- "Old magic" with no specific tradition
- The haunt that operates by whatever rules the
  current scene requires
- The supernatural that resolves by external
  intervention rather than by the protagonist
  meeting specific conditions
```

### The Emotional-Core Linkage

The Emotional-Core Absence failure mode produces
hauntings disconnected from the protagonist's specific
emotional landscape. Paranormal fiction at its strongest
links the supernatural element thematically and
emotionally to what the protagonist is already
carrying — the haunting reveals something specific
about the haunted.

```
PRINCIPLE
The supernatural element must connect to the
protagonist's specific emotional landscape through at
least three of the following four linkages:
1. THEMATIC RESONANCE — the haunt's specific origin
   or motivation thematically resonates with the
   protagonist's specific situation (the grieving
   mother haunted by a child-presence; the
   compromised investigator haunted by a victim-
   presence; the ambitious rationalist haunted by
   someone who refused conventional explanation)
2. PSYCHOLOGICAL MIRRORING — the haunt mirrors
   something the protagonist has not faced; the
   supernatural confronts what the rational world
   has let them avoid
3. CHOICE PRESSURE — the haunt requires the
   protagonist to make specific choices that
   intersect with their existing psychological
   work; the supernatural is not a problem they
   can solve as someone they are not
4. CHARACTER REVELATION — what the protagonist
   does in response to the supernatural reveals
   something specific about who they are; the
   haunt is partly a character-revealing
   instrument

CALIBRATION TEST
- Could the protagonist's pre-haunting emotional
  landscape be replaced with another and the
  manuscript continue? If yes — the linkage is not
  established.
- Does the haunt have specific thematic resonance
  with the protagonist's specific situation?
- Does the haunt require psychological work the
  protagonist had previously avoided?
- Does the protagonist's response reveal character?
If any answer is no — rebuild for emotional linkage.

ANTI-PATTERN
- The haunt that could happen to anyone
- The protagonist whose response to the supernatural
  is interchangeable with another character's
- The haunting that runs in parallel to the
  protagonist's emotional arc without intersecting
- The supernatural element that resolves through
  research or ritual without character work
```

### The Productive-Ambiguity Discipline

The Over-Explanation and Finale-Reveal Over-Reach
failure modes produce manuscripts that drain the genre's
mystery through complete disclosure. Paranormal fiction
often works through partial disclosure — the reader
ends with some questions answered, some questions
sharpened, and some questions productive in their
unresolution. The Productive-Ambiguity Discipline is
the craft of knowing what to disclose and what to
leave open.

```
PRINCIPLE
The manuscript must leave at least two of the following
five categories productively ambiguous through to the
ending:
1. THE EXACT NATURE OF THE PRESENCE — the rational
   reader's option (psychological projection, mass
   hallucination, environmental effect) is preserved
   alongside the supernatural reading; the manuscript
   may finally lean one way but does not seal the
   other off
2. THE CAUSE OF SPECIFIC PHENOMENA — some of the
   manuscript's strange events resolve, others do
   not; the unresolved remain because the reader's
   imagination should keep working
3. THE SUPERNATURAL'S RELATIONSHIP TO LARGER
   COSMOLOGY — what kind of universe permits this
   haunting? Is it a one-off, or does the haunt
   imply a larger structure? The manuscript may
   imply but should not announce
4. THE PROTAGONIST'S RELIABILITY — does the reader
   trust the protagonist's account fully? The
   genre's strongest manuscripts often preserve a
   margin of unreliability
5. THE FATE OF THE PRESENCE — is the haunt
   resolved, contained, escaped, or merely paused?
   The "ending" that sews everything shut robs
   the manuscript of after-effect

CALIBRATION TEST
- Does the manuscript end with something
  productively unresolved?
- Are at least two of the five categories
  ambiguous?
- Does the ambiguity feel like craft (chosen,
  controlled) or like authorial confusion?
- Will the reader's imagination keep working
  after the manuscript ends?
If any answer is no — rebuild for productive
ambiguity.

ANTI-PATTERN
- The ending that explains everything
- The reveal that names the haunt and assigns
  cosmology
- The manuscript whose questions are all answered
  by the final chapter
- The "and they all moved on" coda that closes
  the haunting cleanly
- Productive ambiguity that reads as authorial
  failure (the manuscript that does not know its
  own answers)
```

## Genre-Specific Revision Rules

### Six-Pass Paranormal Audit (Run FIRST in editorial pipeline)

The Paranormal Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Atmosphere Pass

Verify mood is established BEFORE the paranormal event
occurs. The Mundane-Erasure failure mode is caught
here. is the daily world rendered with enough texture
that the supernatural intrusion has something to
disrupt? Are at least three senses engaged in building
atmosphere? Does the normal world feel real enough to
make the paranormal genuinely disruptive? The Grounding
Anchor technique is the load-bearing tool: every
paranormal scene should have a mundane anchor (cooking,
reading, driving, conversation) that establishes
specific reality before the disruption arrives. If the
chapter has no mundane anchor, the paranormal lands in
a vacuum and the genre's foundational craft is missing.

#### Pass 2: Escalation Pass

Verify paranormal events follow the Slow Burn
Escalation pattern (Feeling → Sensory → Evidence →
Encounter → Communication). Audit the chapter: are the
paranormal events more intense than in the previous
chapter? Is the pattern between events becoming
clearer? Has the protagonist's rationalisation become
harder to maintain? The Atmospheric-Without-Stakes
failure mode is caught here. if the manuscript
generates dread but does not produce material
consequence or escalation, the supernatural is
operating as wallpaper rather than as active force on
the protagonist's life.

#### Pass 3: Emotional Core Pass

Verify the supernatural element is connected to the
protagonist's specific emotional landscape. The
Emotional-Core Linkage discipline provides the spec —
thematic resonance / psychological mirroring / choice
pressure / character revelation. Audit the chapter: is
the emotional driver (grief, guilt, love, fear,
shame, hope) present? Does the paranormal event
connect specifically to that driver? Is the
protagonist's vulnerability visible? The Emotional-
Core Absence failure mode is caught here. if the
haunting is happening to a character whose emotional
landscape it does not touch, rebuild the linkage.

#### Pass 4: Logic / Rules Pass

Verify the paranormal behaviour matches previously
established rules. The Rules-Drift failure mode is
caught here. is any new paranormal ability introduced
consistently with the existing system? Can the reader
trust that the writer knows the rules even when the
characters don't? Does the supernatural's behaviour
this chapter remain coherent with how it has behaved
across the manuscript? The Specific-Origin
Architecture provides the load-bearing structure here:
named historical origin / specific motivation /
specific operating constraints / specific physical
texture / specific resolution conditions.

#### Pass 5: Restraint Pass

Verify the manuscript maintains restraint — more
suggested than shown, especially in early/middle
chapters. The Over-Explanation failure mode is caught
here. are there information gaps the reader's
imagination is invited to fill? Has the writer
resisted the urge to explain too much too soon? Is
the supernatural rendered through partial disclosure
rather than complete description? The Sceptic-or-
Believer Binary failure mode is caught here too. is
the protagonist's relationship to the supernatural
rendered as the messy in-between (rationalisation
under pressure, partial belief, oscillation) rather
than as clean position? The genre's craft is in
holding ambiguity productively.

#### Pass 6: Specific-Origin + Emotional-Core + Productive-Ambiguity Integration

This pass is the paranormal integration check — it
ties the new techniques together and verifies the
manuscript honours the genre's defining commitments at
the manuscript level.

For SPECIFIC-ORIGIN: confirm Pass 4's spec at the
manuscript level. is the supernatural presence
rendered with at least four of the five origin
specifics (named historical origin / specific
motivation / specific operating constraints / specific
physical texture / specific resolution conditions)?
The Generic-Ghost Architecture failure mode is caught
here. if the haunt could be replaced with another
without losing specificity, rebuild.

For EMOTIONAL-CORE: confirm Pass 3's spec at the
manuscript level. does the supernatural element
connect to the protagonist's specific emotional
landscape through thematic resonance, psychological
mirroring, choice pressure, and character revelation?
Is at least three of the four linkages operative?

For PRODUCTIVE-AMBIGUITY: at the ending level, audit
whether the manuscript leaves at least two of the
five categories productively ambiguous (exact nature
of the presence / cause of specific phenomena /
relationship to larger cosmology / protagonist's
reliability / fate of the presence). The Finale-
Reveal Over-Reach failure mode is caught here. if the
manuscript explains everything definitively, the
genre's mystery has been drained and must be rebuilt
to preserve productive ambiguity.

## Names & Patterns to Avoid

### Paranormal Character Names. NEVER USE
- Horror-movie names: Damien, Raven, Shadow, Salem, Morticia
- Obviously symbolic names: Faith, Hope, Grace, Patience (too on-the-nose)
- Names chosen for spooky sound rather than character: Lilith, Nyx, Grimshaw

### Paranormal Location Names. NEVER USE
- Horror clichés: Ravenshollow, Blackmoor, Dreadwood, Shadow Lane
- "The [Adjective] [Building]": The Old Mill, The Abandoned Hospital, The Haunted House
- Any name that tells the reader what to feel before the writing does it

### Use Instead
- Ordinary names for ordinary people in extraordinary situations
- Real-feeling place names that become unsettling through association
- The haunted house should have a boring address: 14 Maple Street is scarier than Ravenmoor Manor because it could be YOUR street

## Comp Titles

Paranormal fiction's comp-title set (distinct from
paranormal-romance) supports manuscript positioning:
market category placement, cover-design conversation,
reader-expectation calibration, similar-author
discovery, and editorial / agent submission framing.

### Canonical (foundational reference points)

- *The Haunting of Hill House* — Shirley Jackson (1959): the foundational paranormal-house novel.
- *The Turn of the Screw* — Henry James (1898): ambiguous-haunting literary paranormal.
- *Rebecca* — Daphne du Maurier (1938): paranormal-adjacent gothic.
- *The Shining* — Stephen King (1977): the modern paranormal-house benchmark.
- *Pet Sematary* — Stephen King (1983): paranormal-grief horror benchmark.

### Contemporary (current best-in-class)

- *Mexican Gothic* — Silvia Moreno-Garcia (2020): post-colonial paranormal benchmark.
- *The Last House on Needless Street* — Catriona Ward (2021): contemporary literary-paranormal.
- *In the Dream House* — Carmen Maria Machado (2019): memoir-paranormal hybrid.
- *Our Share of Night* — Mariana Enríquez (2019): Argentine paranormal epic.
- *White Is for Witching* — Helen Oyeyemi (2009): literary paranormal with house-as-narrator.
- *The Hollow Places* — T. Kingfisher (2020): contemporary paranormal-portal fiction.
- *The Drowning Kind* — Jennifer McMahon (2021): contemporary paranormal-drowning lineage.

## Cover Design Specifications

### Recommended Visual Styles
- **Atmospheric**. Fog-shrouded houses, empty corridors, figures glimpsed through rain-streaked windows; moody and suggestive rather than explicit
- **Minimalist**. A single unsettling image: a door ajar, a shadow that doesn't match its source, a mirror reflecting something wrong; elegant and restrained
- **Photographic**. Manipulated photography with an uncanny quality: slightly blurred, wrong exposure, double exposure; feels like found evidence
- **Typographic**. Clean typography over a subtly wrong image; the title IS the design; distressed or faded text treatments suggest age and decay

### Genre Cover Aesthetics
- **Styles:** Empty rooms with one wrong detail, windows with shapes behind curtains, staircases disappearing into shadow, landscapes with a single figure too far away to identify, mirrors and reflections, doors half-open, fog and mist obscuring details
- **Colours:** Muted, desaturated palettes: greys, washed-out blues, faded greens; cold whites and creams; touches of warm amber (gaslight, candles); one accent colour used sparingly (the red door, the warm light in one window); nothing bright or saturated
- **Elements:** Empty spaces (the horror of absence), architectural details (old houses, corridors, staircases), natural elements (fog, rain, bare trees, still water), mirrors and glass, single light sources creating deep shadows, photographs within the photograph
- **Typography:** Clean serif or slab serif fonts, possibly with subtle distressing; the title should be readable and restrained; avoid horror-style dripping or bloody fonts; position text to interact with the image (title partially obscured by fog, text arranged around negative space)

### Market Positioning
Paranormal covers signal "something is wrong here" through restraint, not excess. The genre sits between literary fiction and horror. covers should reflect that liminal position. Position against Egan, Jackson, Pulley, Sager, Jewell. Muted colour palettes and empty-space compositions distinguish paranormal from horror's darker aesthetics. At thumbnail size, a single unsettling element against negative space is more effective than busy compositions.

### Cover Design DON'Ts
- No explicit ghosts, spectres, or glowing figures (too literal, removes the mystery)
- No horror-genre blood, gore, or skull imagery
- No bright, saturated colours (paranormal is muted and atmospheric)
- No cartoon or comic-style illustration (too playful for the genre's tone)
- No generic "spooky house on a hill" without a distinctive angle
- No floating transparent figures. the viewer should ALMOST see something, not definitely see it
