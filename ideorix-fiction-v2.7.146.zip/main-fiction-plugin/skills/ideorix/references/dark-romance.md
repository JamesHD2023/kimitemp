---
name: dark-romance-genre
description: Genre-specific instructions for Dark Romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [romance]
---

# Dark Romance. Genre Plugin

## Metadata
- id: dark-romance
- name: Dark Romance
- icon: 🥀
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Romancing the Beat", "Thriller 12-Beat Structure", "Three-Act Structure", "Seven-Point Structure"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Captive Romance | Protagonist held by the love interest; Stockholm dynamics explored with psychological depth | Power imbalance is the central engine; consent negotiation drives character growth |
| Mafia/Crime Romance | Love within organised crime; loyalty vs morality | World-building of criminal hierarchy; honour codes create the moral framework |
| Bully Romance | Cruelty-to-devotion arc, typically in academic or social settings | The bully's motivation must be psychologically credible, not arbitrary cruelty |
| Monster Romance | Non-human or monstrous love interest; otherness as attraction | The monster's alienness must be genuinely unsettling, not just cosmetic |
| Revenge Romance | Love born from or complicated by vengeance | The revenge plot must be justified enough that the reader roots for it initially |
| Gothic Dark Romance | Dark romance with gothic atmosphere, isolation, and architectural menace | Setting does heavy lifting; the house/estate is a character |

## Architect Instructions

```
You are structuring a DARK ROMANCE chapter. a subgenre defined by morally complex protagonists, dangerous power dynamics, obsessive attraction, and psychological intensity woven through a central love story.

DARK ROMANCE CHAPTER BEATS (incorporate 3-5 per chapter as appropriate):
- POWER SHIFT: A moment where the balance of control between protagonists changes. Who holds power, who surrenders it, and why. Every chapter should advance or complicate the power dynamic.
- PSYCHOLOGICAL TENSION: Internal conflict where desire wars with self-preservation, morality, or identity. The character wants what they know they shouldn't. Show the mental negotiation.
- OBSESSIVE PULL: A scene or moment revealing the depth of fixation. surveillance, possessive thought spirals, inability to stay away, compulsive need to provoke or protect. This is the engine of dark romance.
- VULNERABILITY EXPOSED: A crack in armor. The dangerous one shows tenderness. The captive shows strength. The morally grey character reveals the wound beneath the weapon. These moments earn reader investment.
- DARK REVELATION: Information that reframes the relationship. a betrayal discovered, a secret motive unveiled, a past trauma that explains (not excuses) dark behavior. Raises stakes and forces characters to recalibrate.

STRUCTURAL REQUIREMENTS:
- Protagonists must be MORALLY GREY with comprehensible (not necessarily sympathetic) motivations. No cartoon villains. No pure victims. Both characters must have agency even within power imbalances.
- POWER IMBALANCE must be acknowledged within the narrative. Characters should be aware of dynamics. The story must engage with the imbalance, not ignore it.
- HEA or HFN is MANDATORY but may be unconventional. dark characters don't become saints. The ending should feel earned within the world established, not grafted from mainstream romance.
- CONTENT WARNINGS should be flagged in chapter notes. The architect should note sensitive content thresholds so the writer can handle them with appropriate craft.
- EMOTIONAL INTENSITY must be extreme. Every chapter should contain at least one moment of visceral emotional response. dread, desire, rage, desperate tenderness, possessive fury, reluctant vulnerability.
- PSYCHOLOGICAL DEPTH over shock value. Every dark element must serve character development or relationship progression. If removing a dark scene doesn't change the story, it shouldn't be there.
- PACING should alternate between suffocating closeness and desperate distance. Tension is built through proximity and denial, revelation and concealment.

FORBIDDEN:
- Gratuitous darkness without emotional purpose or narrative function
- One-dimensional love interests who are dark "just because". the darkness must have roots
- Darkness without romance payoff. readers came for the love story told through shadow
- Moralizing narration that lectures readers about the characters' choices
- Sanitizing the premise. if you set up a dark dynamic, commit to it with craft and intentionality
- Abrupt personality reversals where dark characters become gentle without earned progression
- Stereotypical dark archetypes without depth. no brooding billionaire or mafia boss who is dark "just because"; the darkness must have specific, ground-up roots
- Single-obstacle stories. the power imbalance alone isn't enough; layer internal emotional wounds alongside the dark dynamic
- Relentless darkness without emotional variation. even dark romance needs moments of unexpected warmth, black humor, or disarming tenderness to create contrast

OBSTACLE LAYERING (critical for dark romantic tension):
Dark romance has a built-in external obstacle (the dangerous dynamic itself), but internal obstacles are what give the genre its devastating emotional power. Layer the characters' deepest wounds: fear of vulnerability magnified by the power imbalance, past betrayals that make trust seem impossible, self-sabotage driven by the conviction that they don't deserve love, or the terror of wanting something that could destroy them. Each obstacle should intensify the reader's desperate yearning for connection. the more barriers between these characters, the more devastating the moments when walls crack.

LIGHT AND SHADE IN DARKNESS:
Even the darkest romance needs emotional contrast to function. After scenes of maximum psychological intensity, allow a moment that catches the reader off guard. unexpected tenderness, a flash of dark humor, a gesture of care that contradicts everything established. After moments of surprising vulnerability or connection, shatter the calm with a dark revelation or power shift. This contrast is the difference between compelling darkness and monotonous grimness. Two relentlessly dark scenes back to back numb the reader; darkness followed by an unexpected flicker of light makes both register at full force.

CHARACTER BUILDING. GROUND UP:
Build every significant character from the ground up BEFORE they enter the story. Ask foundational questions: What do they want from life beyond the dark dynamic? What shaped them into who they are? What do they carry. literally and emotionally? Set character tests: How would they react to witnessing kindness? To being shown mercy? What's in their pockets/bag/home? The vast majority of this work will never appear on the page, but it informs every action, every line of dialogue, every moment where armor cracks. Messy, contradictory characters are always more compelling than one-note dark archetypes. the killer who is gentle with something unexpected, the manipulator who cannot lie to one specific person.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (consuming bond), Stimulation (intensity), Revelation (transformation through the dynamic).

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-protocol.md`
"Heat Level Calibration Slot" handles the wire-up.

DARK ROMANCE VOICE AND CRAFT RULES:

NARRATIVE VOICE:
- Voice should be INTENSE and VISCERAL. The prose itself should feel dangerous. sharp, intimate, uncomfortably close. Readers should feel the characters' skin prickle.
- PSYCHOLOGICAL INTERIORITY is paramount. Dark romance lives in the mind. Extended internal monologue showing desire at war with self-preservation, rationalizations crumbling, obsessive thought patterns spiraling. Go deep.
- UNRELIABLE NARRATORS are a powerful tool. Characters who lie to themselves about their feelings, who misinterpret their own motivations, who tell readers one thing while their actions scream another.
- DUAL POV is strongly recommended. Showing obsession, possessiveness, or dangerous desire from both sides transforms the dynamic. The reader needs to understand WHY both characters are drawn into this despite the danger.
- Second person address can be effective in internal monologue. "You shouldn't want this. You shouldn't lean into his hand when it closes around your throat. But you do."

PROSE STYLE:
- Sentences should vary dramatically. long, breathless spirals of want and dread punctuated by short, sharp declarations. "He was everything I'd been warned about. And I stayed."
- Use SENSORY LANGUAGE aggressively. Dark romance is embodied. racing pulses, caught breath, the specific temperature of someone's grip, the smell of danger and desire mingled.
- DARK IMAGERY woven through romantic moments. Tenderness described through violence metaphors. Violence described through tenderness metaphors. "He kissed me like an apology for something he hadn't done yet."
- POWER DYNAMICS should live in the prose itself. sentence structure, word choice, who speaks and who stays silent, who moves and who is still.
- Silence and withholding are as important as dialogue. What characters DON'T say carries enormous weight. Use ellipses for trailing dread and interrupted thoughts (in AI-generated prose, em-dashes are banned. use ellipsis for interruptions; in human-written prose, em-dashes are permitted per the density limit in craft-standards.md). Use paragraph breaks for the weight of unspoken words.

INTIMACY AND DESIRE:
- Intimate scenes should be INTENSE and EXPLICIT when they occur, serving character and power dynamic development. These are not love scenes. they are battlegrounds, surrenders, negotiations, and revelations.
- Consent within dark romance is nuanced and genre-specific. Characters may operate in morally grey territory, but the NARRATIVE should demonstrate awareness. The distinction between fantasy and reality lives in the craft.
- Desire should feel like a compulsion, an invasion, something the character cannot reason away. Use language of hunger, drowning, burning, breaking.
- Physical responses should be involuntary and unwanted. the body betraying the mind's resistance. This tension between physical response and psychological resistance is core to the genre.
- Post-intimacy scenes are critical. vulnerability hangover, emotional retreat, the scramble to rebuild walls. Don't skip these.

EMOTIONAL EXTREMES:
- Characters in dark romance feel everything at maximum volume. Moderate emotions are for other genres. Here, anger is fury, attraction is obsession, fear is terror, tenderness is devastating.
- EMOTIONAL WHIPLASH is a feature, not a bug. A scene can pivot from violence to tenderness in a paragraph. The reader should feel destabilized. that's the point.
- Show characters UNRAVELING. Control is currency in dark romance, and watching composed characters lose it is the genre's oxygen.
- Jealousy, possessiveness, and territorial behavior should be written with visceral specificity. Not "he was jealous" but the exact texture of that jealousy. what it tastes like, how it restructures his vision, what violence it whispers.

DIALOGUE:
- Dialogue should crackle with subtext and threat. Characters rarely say what they mean. Conversations are chess matches.
- Power plays through speech. interruptions, commands, deliberate silence, weaponized vulnerability, strategic honesty.
- Pet names and terms of address carry weight. "Sweetheart" can be tender or terrifying depending on context. Leverage this.
- Threats that double as promises. Promises that double as threats. The line between "I'll destroy you" and "I'll never let you go" should blur.

FORBIDDEN WORDS AND PHRASES (break immersion in dark romance):
- "Orbs" for eyes. always
- "Member" or "manhood". use direct, visceral language or poetic alternatives with edge
- "Making love". too gentle for this genre unless used with devastating irony
- "Soul mate" used unironically. dark romance earns connection through fire, not fate
- Euphemistic language that softens darkness the narrative has committed to
- Purple prose that distances readers from visceral reality. stay close, stay sharp
- Excessive adverbs in tense scenes. "he said dangerously, looking at her menacingly" kills tension

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- Danger AND desire from page one: the dark premise activates IMMEDIATELY, no easing in
- Tension floor: 7 (the reader chose this genre deliberately; deliver the intensity they came for)
- Open with the power dynamic in motion: not backstory, not setup, the dynamic ACTIVE
- Dialogue density: 25-35%: silence and interiority dominate; what's unsaid matters more

Power-dynamic scenes (prose rhythm):
- Short, sharp sentences during shifts in control: "He stepped closer. She didn't move."
- Sensory detail raw and visceral: specific temperatures, textures, the exact physical weight of proximity
- Interiority budget: 50%+: dark romance lives in the mind; desire warring with self-preservation
- Paragraphs break at moments of involuntary response: the body betraying the mind gets its own line

Vulnerability scenes (prose rhythm):
- Longer sentences when armor cracks: breathless spirals of want, dread, reluctant tenderness
- Prose softens in rhythm but NOT in intensity: gentleness from a dark character should feel unsettling
- Consent navigated with care but intensity never diminishes: the heat stays, the awareness stays

Climax/resolution prose rhythm:
- The desperate choice: short declarative sentences: irreversible, fully aware, stripped of performance
- Final intimacy scenes: raw, undefended prose: walls gone, emotional annihilation on the page
- Resolution carries the weight of everything that came before: earned, not sanitized

THE POWER OF THE UNSAID IN DARK ROMANCE:
- What characters DON'T say is the most powerful weapon in dark romance dialogue. The gap between what is felt and what is spoken IS the tension that drives the genre.
- Characters in dark dynamics rarely say what they mean until climactic moments: they deflect with cruelty, test with provocation, hide behind power plays. Holding back gives devastating resonance to the moment someone finally speaks their truth.
- Each character must speak distinctly: their verbal patterns, deflections, and weaponized silences should be as individual as their psychological profiles. You should know who is speaking without dialogue tags.
- The most powerful dark romance exchanges happen when both characters are disturbed by the depth of their connection and are fighting to deny it: every word is a negotiation between self-preservation and surrender.

METHOD WRITING. EMOTIONAL IMMERSION:
- Identify the specific emotion you want the reader to FEEL before writing any scene of intensity: dread? desperate tenderness? the vertigo of wanting what should destroy you?
- If the writer isn't feeling the visceral pull of the scene, the reader won't either: that's the signal to go back and find what's blocking the emotional truth.
- Write through ALL senses with aggressive specificity: the exact temperature of a grip, the specific texture of fear in the throat, how desire restructures vision and warps time perception.
- Never be cynical about the emotion beneath the darkness: don't manufacture cruelty or a dark twist purely for shock. The darkness must serve the characters' emotional truth. Genuine feeling, even in extreme contexts, is what separates compelling dark romance from empty provocation.

INTIMATE SCENES. BATTLEGROUNDS OF REVELATION:
- Dark romance intimate scenes must serve character development and power dynamic progression: they are the crucible where defenses shatter and truth is forced to the surface.
- Ask: what does this scene reveal about who holds power, who surrenders it, and what that costs them emotionally?
- The most compelling dark intimate scenes contain elements of emotional rawness alongside physical intensity: unwanted tenderness, vulnerability that terrifies the character experiencing it, desire that feels like defeat.
- Build physical intensity into the emotional landscape of the story: each encounter should shift the dynamic, reveal something new, and make it harder for both characters to pretend they don't care.
- Post-intimacy scenes are as critical as the acts themselves: the scramble to rebuild walls, the vulnerability hangover, the refusal to name what just happened. Never skip the aftermath.

THEME BENEATH THE DARKNESS:
Every dark romance benefits from a THEME. what the story is really about beneath the power dynamics and obsessive attraction. Is it about whether people can truly change? About the human capacity for love even in the most damaged souls? About the difference between what we want and what we need, between what destroys us and what saves us? Theme adds a dimension that transforms dark romance from thrilling to profound. When the reader closes the book, it is the theme. not the shock. that stays with them.
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Psychological intensity. sustained uncomfortable, compelling tension; characters' internal states rendered with depth; reader feels the claustrophobic intimacy of obsessive connection
2. Power dynamic craft. imbalance between protagonists dynamic and shifting, not static; both characters agents within their dynamic, not props
3. Darkness with purpose. every dark element serves story and character; nothing gratuitous, nothing removable without losing development
4. Romance thread present. beneath the darkness, love story progressing; connection deepening even through conflict; gravitational pull between characters felt
5. Character complexity. both protagonists morally grey with comprehensible motivations; dark character shows vulnerability, lighter character shows unexpected darkness or strength

GENRE-SPECIFIC CHECKS

Visceral, intimate prose: Writing style itself feels dangerous. sharp, close, embodied; sensory details specific and unsettling
Emotional extremes earned: Genuine peaks of dread, desire, shock, or devastating tenderness. not melodrama but earned intensity
Tension variation: Suffocating closeness balanced with breathing room. relentless darkness without contrast exhausts rather than terrifies
Power transfers tracked: Voluntary surrender vs forceful taking vs mutual dissolution. type of transfer matters and is dramatised
Genre authenticity: Experienced dark romance readers would recognise this as their genre. conventions honoured while offering freshness
Content handling: Sensitive themes treated with craft rather than shock value; narrative aware of its own darkness without moralising
Obsessive connection rendered: The specific quality of dark romance attraction. not just chemistry but compulsion, danger, inability to look away
Both protagonists dimensional: Internal contradictions, comprehensible motivations, moments that surprise without breaking character

AUTOMATIC FAILS

One-dimensional villain: Love interest with no psychological depth or comprehensible motivation. pure darkness without complexity
Gratuitous darkness: Violence, transgression, or disturbing content that serves neither plot nor character development
Static power imbalance: Power dynamic unchanged across the chapter. no evolution, no awareness, no complication
Romance absent: Dark elements dominating with no emotional connection advancing. horror without love story
Character profile breaks: Established psychological patterns violated without earned development
Author moralising: Narration breaking the fourth wall to lecture readers about the darkness they chose to read
Lost nerve: Abrupt tone shifts that retreat from established darkness. commit to what you set up
Shock value over craft: Content designed to shock rather than reveal character or advance story

ACCEPTABLE IMPERFECTIONS

Morally uncomfortable character choices. this is the genre's core territory
Explicit content that serves power dynamic or character revelation
Protagonists who are genuinely dangerous, criminal, or morally compromised
Dark humour or gallows wit from characters in extreme situations
Unconventional relationship dynamics that challenge mainstream romance norms
Ambiguous consent within genre-appropriate fantasy contexts handled with craft
Endings that don't fully redeem dark characters but show genuine growth or connection

RED FLAGS TO INVESTIGATE

Power dynamic unchanged across multiple chapters. no shift, no escalation, no complication
Darkness escalating without emotional payoff. each transgression should reveal character, not just shock
Both characters locked in same emotional register. no variation between dread and tenderness
Prose going clinical during intense scenes. dark romance demands visceral proximity, not detached description
Romance progression invisible. reader can't track how the connection is deepening beneath the conflict
Secondary characters existing only to be victimised or to enable the dark dynamic
Genre retreating into thriller or horror territory. losing the romance thread that defines the genre
Psychological states told rather than shown—"she was obsessed with him" vs rendering the obsession
```

## Continuity Rules

```
You are tracking CONTINUITY for a DARK ROMANCE manuscript where psychological states, power dynamics, and trust are as critical to track as physical details.

POWER DYNAMIC TRACKING (highest priority):
- Map the power balance between protagonists in EVERY chapter. Who holds control. physically, emotionally, informationally, financially? Track shifts precisely.
- Note when power transfers: voluntary surrender vs. forceful taking vs. mutual dissolution. The type of transfer matters for character development.
- Track what each character KNOWS vs. what they BELIEVE about the power dynamic. Perception gaps drive dark romance conflict.
- Monitor escalation patterns. If Chapter 3 establishes a boundary, Chapter 7 can't casually violate it without acknowledgment.

PSYCHOLOGICAL STATE CONTINUITY:
- Track each protagonist's psychological arc chapter by chapter. Fear should evolve into specific, earned forms. Desire should deepen with specific triggers. Trust should build (or erode) through concrete events.
- Monitor defense mechanisms. if a character dissociates under stress in Chapter 2, they shouldn't be emotionally present during similar stress in Chapter 5 without earned growth.
- Track trauma responses consistently. If a character has established triggers, these must remain consistent unless therapeutically addressed within the narrative.
- Obsessive behaviors should escalate logically. Track the specific manifestations. surveillance methods, possessive acts, ritualistic behaviors. and ensure they develop coherently.

TRUST AND BETRAYAL LEDGER:
- Maintain an explicit trust ledger. Every promise, every betrayal, every secret kept or revealed. Characters should remember what they've been through together.
- Track information asymmetry. what does each character know? What do they think the other knows? Dramatic irony in dark romance must be precise.
- Monitor the forgiveness economy. Forgiveness in dark romance is hard-won and specific. Track what has been forgiven, what hasn't, and what the characters believe is forgivable.

PHYSICAL AND SPATIAL CONTINUITY:
- Track confinement and freedom carefully (captivity romances). Escape opportunities, locked doors, surveillance coverage, phone access.
- Note injuries, marks, and physical evidence of encounters. Dark romance readers notice when bruises disappear too quickly or scars are forgotten.
- Track who has weapons, keys, phones, money, allies. Resources determine power.

CHARACTER KNOWLEDGE AND SECRETS:
- Maintain a secrets matrix: what each character knows, suspects, and is wrong about regarding every other character.
- Track when information is revealed and to whom. Characters cannot act on information they don't have.
- Monitor manipulation attempts. who is manipulating whom, with what information, and whether it's working. Track the manipulator's strategy and the target's level of awareness.

TRACKING CHECKLIST

Power Dynamics (per chapter):
□ Who currently holds power. physically, emotionally, informationally, financially
□ How power balance has shifted since last chapter and what caused the shift
□ Type of power transfer if one occurred. voluntary surrender, forceful taking, mutual dissolution, or negotiated exchange
□ Each character's perception of the power dynamic (may differ from reality)
□ Boundaries established in earlier chapters respected or violated WITH acknowledgment
□ Power dynamic in dialogue. who controls conversations, who yields, who deflects

Psychological States:
□ Each protagonist's current psychological state consistent with accumulated events
□ Defense mechanisms maintained. dissociation, aggression, withdrawal, dark humor. consistent unless growth event occurred
□ Trauma triggers established earlier still active (not conveniently forgotten)
□ Obsessive behaviors escalating logically. surveillance methods, possessive acts, ritualistic patterns developing coherently
□ Fear evolving into specific, earned forms (not generic "she was afraid")
□ Desire deepening through specific triggers (not just proximity)
□ Post-intimate-encounter psychological states carried forward. vulnerability hangover, wall-rebuilding, emotional retreat

Trust & Betrayal Ledger:
□ Every promise made tracked. by whom, to whom, whether kept or broken
□ Every betrayal logged. what happened, who knows, whether acknowledged or buried
□ Every secret tracked. who holds it, who suspects, who's been told
□ Forgiveness economy maintained. what has been forgiven vs. what lingers unresolved
□ Information asymmetry precise. what each character knows, thinks they know, and is wrong about
□ Manipulation strategies tracked. who is manipulating whom, with what information, and whether target is aware

Physical & Spatial:
□ Confinement/freedom status tracked (if captivity romance). escape opportunities, locked doors, surveillance gaps
□ Injuries and marks carried forward realistically. bruises don't vanish overnight, scars persist
□ Resources tracked. weapons, phones, money, keys, allies. who has what
□ Physical proximity/distance patterns maintained. characters can't be in places they shouldn't have access to
□ Physical evidence of encounters persistent. torn clothing, displaced objects, marks on skin

RED FLAGS TO INVESTIGATE

⚠️ Power dynamic static for multiple chapters. no shift, no contest, no evolution in who holds control
⚠️ Boundary established in earlier chapter violated without narrative acknowledgment or character reaction
⚠️ Character's psychological state inconsistent. terrified in Ch 8 but calm in identical circumstances in Ch 11 without growth event
⚠️ Defense mechanism appearing or disappearing without cause. character who dissociates under stress suddenly emotionally present, or composed character suddenly fragile without trigger
⚠️ Trauma trigger forgotten. established trigger has no effect in a scene where it should activate
⚠️ Obsessive behavior intensity fluctuating without reason. surveillance escalating then dropping then escalating without story cause
⚠️ Promise or betrayal forgotten. significant trust event has no consequences in subsequent chapters
⚠️ Information asymmetry violated. character acting on knowledge they shouldn't have (wasn't told, wasn't present, couldn't have deduced)
⚠️ Forgiveness appearing without the scene that earned it. characters who were in conflict suddenly fine without reconciliation
⚠️ Physical evidence vanishing. injuries healing impossibly fast, marks disappearing between chapters, resources appearing without acquisition
⚠️ Confinement logic broken. locked door suddenly unlocked, surveillance coverage conveniently absent, escape route available then unavailable then available
⚠️ Manipulation strategy contradicting itself. manipulator's approach inconsistent with their established intelligence and goals
⚠️ Post-intimacy psychological state skipped. significant intimate encounter has no emotional aftermath in the following chapter
```

## Character Rules

```
You are tracking CHARACTERS in a DARK ROMANCE where moral complexity, psychological depth, and the spectrum between villain and antihero define the genre.

THE MORALLY GREY SPECTRUM:
Every significant character in dark romance exists on a spectrum. Track where each character sits and how they move:
- DARK HERO/HEROINE: Dangerous, morally compromised, but with a comprehensible internal logic. They may kill, manipulate, or coerce, but the reader understands WHY. Track their moral code. even the darkest characters have lines. What are they? When do those lines shift?
- CORRUPTED INNOCENT: A character drawn into darkness through circumstance, desire, or the influence of the dark love interest. Track their moral erosion or their maintained moral center under pressure. What compromises have they made? What would they still refuse?
- ANTIHERO: Distinguished from villain by motivation and capacity for growth. Track moments of genuine care, unexpected mercy, or self-sacrifice alongside their dark actions. The ratio matters.

PSYCHOLOGICAL DEPTH REQUIREMENTS:
- WOUND MAPPING: Every dark character needs a comprehensible origin for their darkness. Childhood trauma, systemic corruption, survival necessity, or psychological condition. Track the wound, how it manifests, and whether the character is aware of it.
- DEFENSE MECHANISMS: Track each character's psychological armor. emotional detachment, aggression, manipulation, hypervigilance, dark humor. These should be consistent and should crack at specific, earned moments.
- OBSESSION PORTRAYAL: If a character is obsessive, track the specific nature of the obsession. what triggers it, how it manifests behaviorally, how it escalates, what temporarily soothes it. Generic "obsession" is lazy; specific obsession is compelling.
- INTERNAL CONTRADICTIONS: The best dark romance characters contain multitudes. The killer who is gentle with animals. The manipulator who cannot lie to one specific person. Track these contradictions. they are the character's humanity.

REDEMPTION ARC TRACKING (or intentional lack thereof):
- Not all dark romance characters redeem. Track whether the narrative is building toward redemption, transformation, or acceptance-without-change.
- If redemption: Track specific actions that demonstrate change, not just declarations. Redemption in dark romance must be EARNED through sacrifice, not gifted through love.
- If no redemption: Track how the narrative frames the character's darkness in a way that still delivers an emotionally satisfying ending. The partner must choose them WITH full knowledge.

RELATIONSHIP DYNAMIC TRACKING:
- Track the specific nature of the dynamic: captor/captive, predator/prey, rivals, master/subordinate, protector/protected. Note when the dynamic subverts or inverts.
- Monitor codependency markers and whether the narrative treats them as romantic (genre convention) or problematic (character awareness).
- Track the moments of genuine connection that justify the romance. shared laughter, unexpected honesty, mutual recognition of damage, protection that costs the protector something real.

SECONDARY CHARACTER FUNCTIONS:
- Dark romance secondary characters often serve as mirrors. the friend who represents the life the protagonist is leaving, the rival who shows what the dark love interest could become without love, the mentor figure who warns or enables.
- Track loyalties carefully. In dark romance worlds (mafia, organized crime, dark societies), betrayal by secondary characters drives major plot points.

FLAG: Characters who are dark without depth, whose morality shifts without cause, whose obsession lacks specificity, or whose redemption isn't earned through the narrative.
```

## Arc Rules

```
DARK ROMANCE ARC ANALYSIS:

EVALUATE POWER-DYNAMIC NARRATIVE STRUCTURE (30 chapters):

**PHASE 1: COLLISION AND ESTABLISHMENT (Chapters 1-5) - 0-15%**
- Ch 1-2: The worlds collide. The dark premise activates IMMEDIATELY. dark romance readers chose this genre deliberately and the first scene should confirm their choice. If captivity, the capture happens. If stalker, the obsession is revealed. If arranged/mafia, the terms are set. If revenge, the plan launches. No gradual easing into darkness. the TONE CONTRACT is established here, and whatever level of darkness these chapters promise, the rest of the book must deliver.
- Ch 3-4: Both protagonists' psychological profiles established through action, not backstory. The dark character's wound should be visible in how they exercise power. not explained, but felt. The other protagonist's core strength should be visible even within the power imbalance. they are not a prop, they are a force meeting a force. Defense mechanisms, moral codes, what they want vs. what they need. all established through how they navigate the collision, not through internal monologue alone.
- Ch 5: The dynamic crystallizes. The reader understands the specific nature of this power imbalance and the specific quality of the dangerous attraction. The first involuntary response. the body betraying the mind. should occur. The first crack in armor. a moment of unexpected vulnerability from the dark character, or unexpected strength from the constrained one. should flash and be immediately suppressed.
- Power dynamic: ESTABLISHED. Clear who holds physical, emotional, informational, and financial power. The imbalance is the premise.
- Intimacy level: ZERO to CHARGED PROXIMITY. No physical intimacy yet, but every interaction is electric with the awareness of it. Accidental touches. Loaded silences. The space between them is the most charged thing in every room.
- Darkness intensity: PREMISE SET. The specific flavor of darkness this story offers is clear. The reader knows what they're in for.
- Psychological state: DEFENSIVE. Both characters' walls are up. Defense mechanisms at full strength. The dark character is in control (or appears to be). The other character is calculating, resisting, or surviving.

**PHASE 2: ESCALATION AND RESISTANCE (Chapters 6-12) - 15-40%**
- Ch 6-8: The power dynamic becomes the battlefield. Push and pull, test and resist, surrender and reassert. Each chapter should shift the balance. even slightly. The dark character tests boundaries. The other protagonist discovers unexpected leverage. intelligence, emotional insight, the dark character's weakness for them specifically. Control is contested in every interaction: who speaks first, who yields, who breaks eye contact, who occupies space.
- Ch 9-10: Intimacy escalates. physical, emotional, or both. EVERY intimate encounter must shift the power dynamic or reveal character depth. No filler intimacy. The first significant physical encounter should be a revelation scene: what the dark character is like when they lose control, what the other protagonist discovers about their own desire, what the power dynamic looks like stripped of performance. Post-intimate vulnerability is critical. the scramble to rebuild walls, the refusal to name what just happened.
- Ch 11-12: The cracks deepen. Moments of unexpected humanity from the dark character. not softening, but complexity. A flash of tenderness that terrifies them more than violence. The other protagonist begins to see the wound beneath the weapon. and this understanding is more dangerous than the original threat, because understanding leads to care, and care destroys the safety of pure opposition.
- Power dynamic: CONTESTED. The initial imbalance is complicated by attraction, vulnerability, and the other protagonist's discovered leverage. Power shifts within scenes. sometimes within paragraphs.
- Intimacy level: ESCALATING. Physical encounters increasing in intensity and emotional exposure. Each one strips away a layer of defense. The body is ahead of the mind. both characters are more invested than they'll admit.
- Darkness intensity: DEEPENING. Dark elements are not just premise anymore. they're personal. The consequences of the dynamic are felt in the characters' bodies and psyches.
- Psychological state: ERODING. Defense mechanisms cracking under sustained proximity and attraction. Obsessive thought patterns establishing. Sleep disrupted by the other person. The war between wanting and knowing better is constant.

**PHASE 3: DARK MIDPOINT AND FRACTURE (Chapters 13-18) - 40-60%**
- Ch 13-14: Tension approaching the unbearable. The reader should feel that something must break. The characters are in deeper than they intended. the dark character's obsession has become something they can't control, the other protagonist's resistance has been compromised by genuine feeling. Each interaction carries the weight of everything unspoken.
- Ch 15 MIDPOINT: THE DARK REVELATION. A major reveal that reframes the entire relationship. The dark character's true motivation exposed. it's worse than the protagonist thought, or more human, or both simultaneously. Or the "innocent" character's hidden agency revealed. they're not who they seemed, they have their own darkness, their own agenda. Or a betrayal that shatters the fragile trust built through intimate vulnerability. Whatever the revelation, it forces both characters to confront what this dynamic truly is. not what they've been telling themselves.
- Ch 16-18: THE FRACTURE. Trust built is betrayed. Safety is ripped away. Characters retreat to their darkest selves. the dark character becomes more dangerous because the vulnerability they showed feels like weakness to be punished, the other protagonist reasserts their walls because caring about someone this dangerous is unacceptable. But the fracture reveals something: the separation is worse than the danger. Being apart is its own kind of suffering.
- Power dynamic: SHATTERED AND RECONFIGURING. The midpoint revelation destroys the established dynamic. A new, more honest, more dangerous configuration is forming. one where both characters know too much about each other to pretend.
- Intimacy level: PEAK THEN WITHDRAWAL. The most psychologically revealing intimacy occurs just before or during the fracture. vulnerability forced to the surface by crisis. Then devastating withdrawal. The absence of intimacy after its depth is its own form of suffering.
- Darkness intensity: MAXIMUM. This is where the genre earns its "dark" label. The consequences of the premise play out. Characters face what their dynamic truly costs.
- Psychological state: RAW. Defenses stripped by the revelation. Both characters exposed. to themselves and each other. in ways they cannot recover from. The question becomes: knowing what they now know, can they survive this? Do they want to?

**PHASE 4: DARK NIGHT AND DESPERATE CHOICE (Chapters 19-24) - 60-80%**
- Ch 19-21: The aftermath of fracture. Characters are apart. physically, emotionally, or both. and the separation is unbearable. The dark character without their obsession's object is more dangerous, more volatile, more lost. The other protagonist without the dark character discovers they've been fundamentally changed by the experience. they can't go back to who they were before. The world outside the dynamic feels flat, colorless, safe in a way that now feels like suffocation.
- Ch 22-23: DARKEST HOUR. External threats converge with internal crisis. The antagonist (if present), the consequences of the dark dynamic, the world pushing back against the relationship. everything arrives at once. One or both characters face genuine danger. The protagonist must confront the full weight of what they feel: this person is dangerous, damaged, morally complex. and I would rather face that darkness than live without them. The dark character must confront their own truth: this isn't obsession anymore, or it is obsession but it's also something they never thought they were capable of feeling.
- Ch 24: THE DESPERATE CHOICE. Each protagonist independently decides: the connection is worth the cost. Not a reasonable decision. a desperate, irreversible, fully-aware-of-the-consequences decision. The dark character chooses vulnerability over control. The other protagonist chooses the darkness over safety. These choices must cost something real. status, safety, identity, the life they planned before this person destroyed their certainties.
- Power dynamic: DISSOLVING TOWARD EQUALITY. Not balanced (dark romance doesn't do balanced), but mutually chosen. The power imbalance transforms from imposed to negotiated. still intense, still consuming, but now with consent at its foundation.
- Intimacy level: DEVASTATING HONESTY. If physical intimacy occurs here, it's different from everything before. raw, undefended, emotionally annihilating. The walls are gone. What's left is two people who have seen each other's worst and are choosing to stay.
- Darkness intensity: CONFRONTED. The narrative faces its own darkness directly. Characters name what they are, what they've done, what they want despite knowing what it costs.
- Psychological state: CHOOSING. The war between self-preservation and connection is over. not because one side won, but because the character decided the connection was worth the cost of surrendering the fight.

**PHASE 5: DARK CLIMAX AND EARNED RESOLUTION (Chapters 25-30) - 80-100%**
- Ch 25-26: Final convergence. The external threat and the internal relationship crisis collide. The protagonists must face both simultaneously. and they face them TOGETHER for the first time. Their combined strength (dark character's ruthlessness + other protagonist's insight, or whatever their specific complementary powers are) creates something neither could achieve alone. The dynamic that was destructive in isolation becomes formidable when pointed outward.
- Ch 27-28: THE DARK CLIMAX. Sacrifice or surrender. at least one protagonist makes a choice that costs something irreplaceable. Power, safety, identity, their carefully constructed walls, the person they were before this began. This is the emotional climax. the moment the reader has been desperate for since Chapter 1. The dark character proves their love through action (not declaration), risking what they most want to protect the person who became their weakness. The other protagonist proves their strength through choice, not survival. they CHOOSE this, fully aware, fully present.
- Ch 29-30: THE EARNED RESOLUTION. The HEA/HFN must satisfy dark romance readers specifically:
  - The dark character does NOT become a different person. Growth yes, personality transplant no. They are still dangerous, still intense, still consuming. but now that intensity is CHOSEN by someone who sees them completely.
  - The relationship is not sanitized. It remains dark, possessive, fierce. but now it's a chosen darkness, not an imposed one. The cage has become a kingdom (or they've burned down the cage and built something together from the ashes).
  - The lighter character is not diminished. They should be STRONGER for the journey. not broken by it but tempered by it. Their strength is what earned the dark character's transformation from obsession to something more.
  - External threats are neutralized, but the internal darkness is accepted, not cured.
  - The final scene should echo the opening with a crucial difference. what was once threatening is now chosen, what was survival is now desire, what was a power imbalance is now a dance both partners know the steps to.
- Power dynamic: CHOSEN. Still intense, still asymmetric (dark romance doesn't flatten), but now negotiated and embraced. Both characters have power. different kinds, wielded differently, but mutual.
- Intimacy level: TOTAL. Not just physical but psychological. These characters have seen each other's worst and chosen to stay. The intimacy is not despite the darkness but through it.
- Darkness intensity: INTEGRATED. The darkness is not defeated. it's accepted. The characters don't become light; they find love within the dark.
- Psychological state: SCARRED BUT CHOSEN. Not healed. dark romance doesn't heal. But known, accepted, chosen. The wounds are still there. Someone is willing to trace them with gentle fingers.

**DARK ROMANCE-SPECIFIC ARC ELEMENTS:**

The Power Inversion Curve:
- Phase 1: Established imbalance. one character holds clear power
- Phase 2: Contested. the other protagonist discovers leverage through attraction, intelligence, or the dark character's specific weakness for them
- Phase 3: Shattered. the midpoint revelation destroys the established dynamic
- Phase 4: Dissolving. power becomes mutual as both characters choose vulnerability
- Phase 5: Chosen. still asymmetric, still intense, but now negotiated
- RULE: Power must shift at least once per phase. Static power dynamics kill dark romance tension.

The Vulnerability Escalation:
- Phase 1: Walls up. both characters in full defensive mode
- Phase 2: Cracks. involuntary responses, unexpected tenderness, the body betraying the mind
- Phase 3: Stripped. the revelation forces exposure neither character can recover from
- Phase 4: Raw. desperate honesty born from the realization that the cost of hiding is higher than the cost of being seen
- Phase 5: Chosen. vulnerability not as weakness but as the only path to genuine connection
- RULE: Each moment of vulnerability must be more costly than the last. The dark character's final vulnerability should terrify them more than any violence they've committed.

The Darkness-Romance Integration:
- Dark romance's central structural principle: darkness is not an obstacle TO the romance. it is the MEDIUM of the romance.
- Every dark element must simultaneously advance the love story. If a scene of danger/threat/transgression doesn't also deepen the connection or reveal character, it's gratuitous.
- Every romantic element must carry the weight of the darkness. If a tender moment doesn't feel precarious, stolen, or hard-won within the dark context, it's not earning its place.
- The strongest dark romance arcs make it impossible to separate the love story from the darkness. they are the same story told in two registers.

**GENRE PROMISE:**
A journey through shadow that ends in a dark, fierce, unconventional love. The darkness is the medium, not the obstacle. Characters who love THROUGH their damage, not despite it. An ending where the reader believes in this love precisely because it survived what should have destroyed it. Discomfort, compulsion, and the catharsis of watching two damaged people choose each other with full knowledge of what they are.

**PACING CHECK:**
- Does the dark premise activate immediately. no gradual easing, the tone contract set in Ch 1-2?
- Does the power dynamic shift at least once per phase. never static for more than 2-3 chapters?
- Does intimacy escalate with purpose. each encounter shifting the dynamic or revealing character?
- Is the midpoint revelation genuinely reframing. not just a plot twist but a shift in what the relationship means?
- Does the fracture feel like genuine loss. not a temporary break but a moment where the reader fears it's over?
- Is the darkest hour earned. external and internal threats converging simultaneously?
- Does the resolution honor the darkness. not sanitizing, not retreating, but integrating?
- Does emotional contrast operate throughout. no more than 2-3 chapters at the same intensity level before a shift?

**THEME CHECK:**
- Is the theme visible in every phase. not just stated but dramatized through power shifts and vulnerable moments?
- Does the ending complete the theme. not just resolve the plot but answer the thematic question?
- Is the story ultimately about something beyond the dynamic. connection despite damage, the difference between control and love, whether love requires healing or just acceptance?
```

## Timeline Rules

```
You are tracking TIMELINE for a DARK ROMANCE manuscript where temporal structure varies dramatically based on subtype and psychological time distortion is a deliberate craft choice.

TIMELINE MODELS (identify which applies):
- CAPTIVITY/CONFINEMENT: Compressed timeline (days to weeks). Time tracking is critical. characters often lose track of time, which is itself a plot device. Track real time vs. perceived time.
- OBSESSION/STALKER: Extended timeline (weeks to months of escalating pursuit). Track surveillance periods, contact frequency escalation, and the shrinking distance between encounters.
- SLOW-BURN DARK: Extended timeline (months to years). Dark elements emerge gradually. Track the precise moments where the relationship crosses from intense to dangerous.
- ARRANGED/FORCED PROXIMITY: Medium timeline (weeks to months of cohabitation). Track adaptation phases. resistance, negotiation, reluctant comfort, dependency.
- REVENGE ROMANCE: Timeline shaped by the revenge plan. Track plan stages, deadlines, and the moments where revenge motive conflicts with developing feelings.

PSYCHOLOGICAL TIME DISTORTION:
- Dark romance characters experience time differently under duress. Fear compresses time. Desire expands it. Captivity distorts it entirely. Note when subjective time should diverge from objective time.
- Track the rhythm of encounters. In stalker romance, the time between contacts should generally shorten. In captivity, the captor's visits may establish a rhythm the captive becomes dependent on.
- Monitor "before and after" markers. Dark romance often has a clear event that divides the protagonist's life. Track references to who they were before vs. who they're becoming.

ESCALATION TIMELINE:
- Dark elements should escalate on a coherent timeline. Track the progression from tension to danger to crisis to resolution.
- Intimacy progression should have its own timeline that may run parallel or counter to the danger timeline. Sometimes intimacy accelerates as danger increases (trauma bonding dynamics the narrative should be aware of).
- Trust development has its own clock. typically slower than attraction, with setbacks after betrayals. Track the trust timeline separately from the desire timeline.

DEADLINE AND PRESSURE:
- Many dark romances have ticking clocks. a marriage contract deadline, a debt coming due, an enemy closing in. Track these and ensure characters feel appropriate urgency.
- Seasonal and environmental markers help ground dark romance in reality. Track weather, holidays, and external world events that anchor the timeline.

FLAG: Timeline inconsistencies, impossible travel, events that require more time than allocated, and psychological development that outpaces the established timeline.
```

## Genre-Specific Craft Techniques

Dark romance is the most-scrutinised sub-genre in romance
publishing. Its readers are sophisticated, ethically alert,
genre-experienced, and unforgiving of work that does not know
what it is doing. The form has a contract: it will dramatise
power dynamics, captivity, violence, morally compromised
heroes, and intimacy under pressure that mainstream romance
will not touch — and it will do so with craft and ethical
consciousness, not by accident or default. The techniques
below are how the genre's pleasures are delivered without
collapsing into the failure modes (sentimental softening of
real darkness, naturalisation of harm as devotion, narrator
moralising that breaks the contract). Dark romance also has
distinct calibration tiers — Dark, Very Dark, Extreme — and
several techniques shift in execution depending on the chosen
register. See the Subgenre Options section above for
calibration; the techniques below are written for the Dark
default and noted where calibration matters.

### The Consent Negotiation

Making dark dynamics legible as consensual through demonstrated
character agency, not through declared consent or contractual
disclosure. The protagonist must always have genuine choices
on the page, even when the available options are constrained.
The reader needs to feel the character's autonomy operating
within power imbalances — the strategic thinking, the calculated
yields, the chosen vulnerabilities, the moments of refusal she
can enforce, the moments of refusal she chooses not to enforce.
This is not about explicit "consent scenes" (which often read
as authorial defensiveness rather than character truth); it is
about ensuring the protagonist is never purely passive, never
purely a body things happen to. The technique requires that the
writer plot the protagonist's interior decision-making
continuously — what she is calculating, what she is permitting,
what she is choosing because the alternative is worse, what she
is choosing because she actually wants it. Test: pick three
power-charged scenes spaced across the book and ask, in each,
what is the protagonist actually choosing, and is that choice
visible on the page? If the answer in any scene is "she had no
choice", the scene is in another genre.

### The Power Inversion

Moments where the seemingly powerless character holds true
control, and the seemingly powerful character is exposed as
dependent. The captor who cannot sleep without their captive
nearby. The criminal hero who flinches at the protagonist's
silence in a way he would not flinch at a gun. The bully who
falls apart when their target stops reacting. The mafia don
whose kingdom is under threat for the first time because of
this woman in his house. These inversions are dark romance's
deepest craft pleasure — they reveal the dark love interest's
vulnerability without softening his nature, and they ratify the
protagonist's agency without requiring a narrative escape from
the dynamic. The technique requires precision: the inversion
must be earned and specific (this exact dependency, expressed
through this exact behaviour, with this exact effect on the
power balance) rather than asserted. Cliché inversions ("she
was the one thing he could not control" as authorial summary)
are the failure mode. Test: when the dark love interest
demonstrates dependency, can the protagonist materially
exploit that dependency, and does she — at least once —
actually do so? If the dependency exists only for the reader
to perceive and never for the protagonist to use, the
inversion is decorative.

### The Darkness as Intimacy

Using morally grey situations to reveal vulnerability that
ordinary social register cannot accommodate. A character who
cannot show tenderness in daylight but breaks open in darkness.
Violence that transitions to gentleness within the same scene.
Confession under duress — extracted by circumstance, not
performed for the audience. The dark context creates space for
emotional honesty that polite society forbids; the genre's
distinctive pleasure includes the recognition that the most
important truths are sometimes only sayable in conditions
ordinary romance would not survive. The technique requires that
the darkness be doing emotional work the lighter register could
not — the confession could only have come here, the tenderness
could only have surfaced now, the recognition is purchased by
the pressure. Test: imagine the same character in a
conventional romance scenario; would this confession, this
tenderness, this recognition occur? If yes, the darkness was
decoration; if no, the darkness was load-bearing. The
calibration matters: at higher darkness levels, the genre's
emotional honesty is sometimes wordless, expressed through
held silences, withheld violences, the choice of one cruelty
declined.

### The Redemption Through Devotion

The dark love interest earning their HEA not through moral
transformation but through unwavering devotion specifically to
the protagonist. They may remain morally grey on every other
axis — the criminal enterprise continues, the violence
remains available to deploy against others, the worldview is
not converted to mainstream-romance sensibility — but their
commitment to the protagonist becomes absolute and demonstrated.
The reader forgives the darkness because the love is genuine,
sustained, and costly to the dark hero in ways that show on
the page. The technique requires that "devotion" be earned by
specific action, not declared by interior monologue: the
sacrifice the dark hero makes that contradicts his prior
nature, the protection he extends that costs his standing, the
restraint he chooses that he has never chosen before, the
person he refuses to harm because she would not approve. The
calibration also matters: at the Dark tier, full transformation-
through-devotion is acceptable; at Very Dark, partial
transformation specific to the protagonist; at Extreme,
devotion does not require transformation at all (the
resolution is the protagonist's clear-eyed choice to remain in
the dynamic she now fully understands).

### The Safety in Danger Paradox

The most dangerous character becoming the safest person for
the protagonist within a world that itself is dangerous. The
genre's signature emotional move: the man who could destroy
her is the one who will not, while the world outside is full
of those who would. This paradox must be earned through
demonstrated protection (specific, costly, uncalled-for) and
through the ongoing presence of an external threat that
contextualises the choice. A dark hero with no external world
to be saved from is a dark hero whose darkness has nowhere to
locate; the technique requires plot pressure outside the
dynamic. The protection must also discriminate: the dark hero
who would harm anyone else and does not harm her demonstrates
specific, chosen restraint, which is what the romance turns
on. Generic "I would burn the world for you" assertions are
the failure mode; the scene where he has the chance to harm
someone she would mourn and does not — or harms someone she
would not mourn and the scene knows what it has done — is
where the paradox earns its place.

### The Hostile World

Dark romance requires a hostile world outside the dynamic to
make the dynamic legible. The captor-as-shelter only works if
the world outside the captivity is more threatening than the
captor; the mafia hero only justifies if the alternative
(rival families, betrayed alliances, exposed civilian life) is
worse; the criminal lover only earns the protagonist's
commitment if the legal world has already failed her. The
technique is structural: the writer must build the hostile
world with the same care given to the central dynamic, not
gesture at it as background. Specific external dangers — named
antagonists with their own competence, institutional failures
that make the dark hero's protection necessary, social threats
that civilian life cannot absorb — give the central dynamic
its meaning. Without the hostile world, the dark hero's
violence reads as gratuitous and the protagonist's choice
reads as Stockholm Syndrome. With the hostile world properly
constructed, the dark hero's violence reads as the only
available answer to the problems the protagonist actually
faces, and the protagonist's choice reads as the rational
response to the world she is actually in. Test: cut the
external threat by half and read the manuscript again — does
the central dynamic still make moral sense? If the central
dynamic depended on the threat that has just been thinned, the
hostile world was load-bearing and must be restored. If the
dynamic survived the cut, it may have been over-leveraged on
internal psychology and the world should be tightened
elsewhere.

### Per-Chapter Darkness Integrity Audit (6 Questions. MANDATORY)

After writing each chapter, run this check:

1. **Softening Check**: Did I add any guilt, regret, or moral awareness that the character
   wouldn't actually feel at this point in their arc? If yes → remove it.
2. **Narrator Neutrality Check**: Does the narrative voice JUDGE any character's actions?
   ("He knew it was wrong" / "She shouldn't have enjoyed it" / "Despite everything,
   there was something tender") If yes → rewrite to show action and reaction without judgement.
3. **Premature Redemption Check**: Does the dark character show growth or softening that
   hasn't been earned yet? Check against the grovel/redemption timeline. If too early → pull back.
4. **Agency Check**: Does the protagonist have inner strength, strategic thinking, or defiance
   appropriate to their situation? Or have I written them as purely passive?
5. **Heat Calibration Check**: Do intimate scenes match the set darkness and heat level?
   Did I soften the power dynamic during intimacy? If vanilla crept into a dark book → rewrite.
6. **Tension Maintenance Check**: Does this chapter maintain or escalate tension? Or did
   I resolve something too early because the AI wanted to "fix" the conflict?

### Anti-Softening Triggers (ELIMINATE ALL)

Watch for these specific AI softening patterns:

| AI Wants To Write | Replace With |
|---|---|
| "His eyes softened" (too early) | Keep the hard edge. He can notice her without melting. |
| "She saw the real him" (premature) | She saw ONE crack. That's it. The rest is still walls. |
| "He pulled back, not wanting to hurt her" | If he's dark, he pushes forward. Maybe stops for HIS reasons, not noble ones. |
| "They both knew this was different" | Show HOW it's different through specific action. |
| "He was gentle this time" (unearned) | Gentleness from a dark hero should feel WRONG. Unsettling. Like a predator being still. |
| "She forgave him" (premature) | She's not ready. She can want him without forgiving him. |
| Grovel in one scene | Grovel is SUSTAINED. Multiple chapters. Repeated demonstrations. |
| Violence described from distance | If darkness level calls for it, violence is CLOSE. Visceral. |
| Narrator explains why hero is "actually" good | Show what he does. Period. Reader decides. |

### The Grovel Architecture

"I'm sorry" is NOT a grovel. The grovel is one of the most important scenes in dark romance.

**Structure:**
1. **The Breaking Point**. Something cracks the hero's control/pride/darkness. Must be devastating.
2. **The Vulnerability**. They show something they've never shown anyone. It costs them.
3. **The Sustained Effort**. Not one grand gesture but repeated demonstrations across chapters.
4. **The Protagonist's Response**. She doesn't immediately cave. She TESTS the grovel.
5. **The New Dynamic**. The grovel changes the power balance. Permanently.

**Grovel calibration by darkness level:**
- Dark: Full, emotional, devastating grovel. The reader cries. The hero earns the HEA.
- Very Dark: Partial grovel. Vulnerability shown but no transformation. She accepts who he is.
- Extreme: Grovel may not exist. The resolution is: she chooses this, eyes open, full knowledge.

### Dark Romance AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "His eyes darkened" | The #1 dark romance AI cliché. Specific physical tells instead. |
| "Something dangerous flickered in his eyes" | Name the danger. What specifically changed? |
| "She shouldn't want this" | Replace moralising with the conflicted FEELING itself. |
| "He was a monster, but her monster" | Earn possessive dynamic through scenes, not declarations. |
| "Electricity crackled between them" | Specific physical chemistry. What EXACTLY? Where? |
| "He backed her against the wall" | Fine once. AI uses it every chapter. Vary positions. |
| "His grip tightened" | Fine once or twice. Find other physical tells. |
| "She didn't know whether to be afraid or aroused" | She can be both. And more. Write the complexity. |
| "Claimed" as verb for possession | Fine once. AI uses it twenty times. Vary vocabulary. |
| "Wrecked" post-intimacy | Once maximum. Find specific aftermath descriptions. |
| "Broken" as character descriptor | Be specific about WHAT is broken and HOW. |
| "Come undone" | Once maximum in entire manuscript. |
| "Her heart hammered" | Limit to 2× per manuscript. Find other fear/arousal responses. |

### Romance Masterclass — Dark-Romance Calibration

The romance master file (romance.md) holds the canonical
romance frameworks: Heat Level Calibration, the 7-Element
Chemistry Scene Construction, the 6 Romance Character
Archetypes with character-build tests, Obstacle Layering
Quantitative, Light and Shade Heart-Monitor Rule, the
Differentiation Imperative, Hope-as-Resolution Calibration,
and Series Architecture. All apply directly to dark-
romance, calibrated below to the genre's specific power-
asymmetry register. CRITICAL: dark-romance demands extreme
craft on consent calibration; the masterclass-level
discipline is in honouring genuine consent within the
genre's power-imbalance frame.

**7-Element Chemistry Scene — Dark-Romance calibration:**

- **Element 1 (Setup):** power imbalance is the operating
  constraint. Establish the specific power architecture
  in this scene — who holds what (institutional position,
  physical capacity, information advantage, criminal
  resource, age-gap authority, captor-captive frame).
  The Setup must register the imbalance as material
  reality, not as decorative flavour.
- **Element 2 (Approach):** often coercive-coded but with
  consent-craft. The proximity-pretext frequently has
  power-driven causation (the summons, the assignment,
  the inescapable circumstance). The genre's craft
  challenge is rendering the approach with full
  acknowledgement of the asymmetry while preserving the
  chemistry's authenticity.
- **Element 3 (Banter Beat):** power-dynamic subtext;
  control negotiation; the dialogue carries embedded
  authority signal that reveals how each lead navigates
  the asymmetry. Banter in dark-romance is often
  weaponised — wit as defence, deflection, or test.
- **Element 4 (Awareness Spike):** typically arrives
  during transgression or near-transgression — the moment
  one lead realises they want what should not want, the
  moment the line becomes visible, the moment power-
  dynamic shifts unexpectedly. The Spike is often
  morally complex; the reader's investment depends on
  the manuscript rendering the complexity rather than
  resolving it.
- **Element 5 (Pull-Back):** the load-bearing pull-back
  is carried by the genuine ethical line — the moment
  of consent or refusal, the line that consent cannot
  cross under the current power architecture, the legal
  or moral framework that holds them. The Pull-Back in
  dark-romance must be earned by the leads themselves
  refusing to act, not by external interruption.
- **Element 6 (Aftermath):** the moral cost of what just
  happened — what each lead carries forward in their
  conscience, their self-image, their understanding of
  the other. Dark-romance Aftermath beats are often
  longer than other romance subgenres because the
  ethical weight requires processing.
- **Element 7 (Hook):** the next transgression or near-
  transgression, the next power-dynamic shift, the next
  ethical line. The Hook in dark-romance is the
  ratcheting of moral pressure rather than the mere
  advancement of plot.

**6 Character Archetypes — Dark-Romance calibration:**

- **The Wounded Lead** carries the morally compromised
  position; chooses to engage despite the cost; their
  wound often predates the dark-romance encounter and
  has prepared them (or made them vulnerable) for the
  power-dynamic they enter. The wound must be specific
  and ethically textured — not generic damage but the
  named compromise, the named cost, the named choice
  that brought them here.
- **The Opposite Lead** holds the power but is held by
  the connection. Their moral architecture is the genre's
  central craft challenge — the manuscript must render
  them as someone whose power is real, whose use of it
  is ethically textured, and whose connection to the
  other lead generates genuine internal conflict
  alongside external. Departure from dark-romance
  stereotype must be specific in at least three
  character-rooted ways.
- **The External Antagonist Force** is often the
  institutional, criminal, political, or social world
  the leads navigate — the syndicate, the corporation,
  the political machinery, the family-system, the
  legal apparatus. The external force carries the
  consequences if the relationship is exposed.
- **The Found Family** is often fractured, conditional,
  or dangerous in dark-romance. Where it appears, it
  may itself carry power-dynamic concerns; the genre
  rarely permits straightforward Found Family
  resolution.

**Obstacle Architecture — Dark-Romance dominant obstacles:**

The Obstacle Layering Quantitative rules apply. For
dark-romance, the dominant obstacle types are:

1. **Power asymmetry** (built-in, structural — never
   resolved by ignoring it; only by the manuscript
   acknowledging and navigating it)
2. **Moral compromise** (what each lead must accept to
   be with the other; the named ethical cost)
3. **Criminal or institutional jeopardy** (legal,
   political, social consequences if the relationship
   is discovered or its terms violated)
4. **Trust under conditions where trust is dangerous**
   (the leads must trust each other in a configuration
   where trust may not be earned or safe)
5. **The genre's consent calibration** (every intimate
   beat must be visibly consensual within the power
   architecture; the craft is in showing how consent
   is preserved, not in pretending the asymmetry does
   not exist)

**Differentiation Imperative — Dark-Romance specific axes:**

- Specific power-dynamic configuration (criminal,
  billionaire, age-gap, captor-captive, mafia,
  arranged-marriage, debt-bondage — each with
  specific consent-craft requirements)
- Specific moral architecture (what makes this
  manuscript's ethical world specific rather than
  generic dark-flavour)
- Specific consent-calibration (where the line is for
  THIS manuscript; what consent looks like under THIS
  configuration)

**Ending Calibration — Dark-Romance patterns:**

Dark-romance permits a range. HEA is possible but the
manuscript must earn the moral resolution — the power
asymmetry addressed, the criminal or institutional
threat removed or managed, the leads visibly choosing
each other freely (not under duress). HFN is very
common (the dark dynamic resolved enough for now; the
external world's pressure ongoing). The Hopeful ending
is rare in dark-romance proper but appears in dark-
romance-adjacent literary projects.

CRITICAL CONSENT NOTE: dark-romance with
"dubcon" (dubious consent) requires extreme craft and
explicit content warnings. The manuscript's contract
with the reader must signal early what consent
configuration is being delivered. Reader trust in the
genre depends on tags and warnings being honest. Tag-
Promise Failure (per romance.md and fan-fiction.md) is
the most relationship-burning failure mode and must be
avoided ruthlessly.

## Genre-Specific Revision Rules

Eight revision passes specific to dark romance, each with a
single question, run cover-to-cover before the next begins.
Dark romance has more revision passes than other romance sub-
genres because the form's failure modes are more numerous and
more costly: the genre does not survive a single
softening-by-default lapse, a single moralising narrator
intrusion, a single intimate scene that drifts below the
calibrated darkness level. The eight passes below are ordered
to surface ethical / consent failures first, structural /
balance failures next, and prose-level / scene-level failures
last, when the rest of the book is stable enough to hold
sentence-by-sentence scrutiny.

### Pass 1: Consent Clarity Audit

Review every intimate or power-charged scene with a single
question: is the protagonist's agency operating on the page?
Build a chart of every scene where consent is structurally
complicated (captivity, coercion, threat, supernatural compulsion,
power imbalance) and answer for each: what is the protagonist
choosing, what alternatives are available to her in the
fictional reality of the scene, and is her interior decision-
making visible? The reader must understand what the character
is choosing and why, not merely accept that something occurred.
Flag any scene where the protagonist feels purely victimised
without narrative purpose or character agency. The genre
permits scenes where agency is constrained — captivity, threat,
overwhelming power difference are the form's terrain — but
constraint is not absence: the protagonist's strategic
calculations, refusals enforced where she can enforce them,
yields chosen because the price of refusal is higher than the
price of yielding, must be on the page. Where this pass
flags failure, the fix is not to rewrite the dynamic but to
restore the protagonist's interior; the agency was always
available, the prose simply failed to render it.

### Pass 2: Power Dynamic Balance Check

Map the power shifts between leads across the manuscript on a
chapter-by-chapter chart. Does the balance shift over time, or
does the dark love interest hold all power from chapter one to
the climax? The protagonist's growing influence is the romance
arc; without it, the book is captivity narrative without
emotional motion. Track specifically: at what point does the
protagonist first cause the dark hero to deviate from a
behaviour he would otherwise have committed? At what point does
he first defer to her preference against his own? At what
point does he first do something — for her, because of her —
that costs him standing, money, alliance, or pride? The shifts
should be gradual and earned, not sudden and asserted. Test:
in the final third, does the dark hero have to take account
of the protagonist's wishes the way she had to take account of
his in the first third? If yes, the arc has run; if no, the
relationship has not actually become a relationship and the
romance has not been written.

### Pass 3: Darkness-to-Tenderness Ratio

Verify that tender moments exist in proportion to dark ones,
calibrated to the chosen darkness tier. Too much darkness
without relief creates misery rather than romance — the reader
disengages by chapter ten because there is nothing to hope for.
Too much tenderness, especially early, undermines the "dark"
promise — the genre's reader picked up this book expecting
real darkness, not gestures at it. The ratio should shift
gradually toward tenderness as the relationship develops, not
in a sudden swerve at the three-quarter mark. Plot the ratio
on a chart: chapters with primary dark register, chapters with
primary tender register, chapters with both-active. The curve
should be readable: heavy on darkness in the first third,
shifting through the middle, with sustained tenderness emerging
only after the grovel architecture has earned it. Calibrate to
tier: at Very Dark, the tenderness ratio remains lower
throughout and never displaces the darkness; at Extreme, the
tenderness may not arrive at all in conventional form, and the
"romance" is a recognition rather than a reformation.

### Pass 4: Trauma Sensitivity Review

Check that trauma is handled with psychological realism.
Characters should not recover instantly from genuinely
traumatic experiences — the captivity that lasted weeks does
not stop affecting the survivor in the chapter after rescue;
the violence witnessed leaves marks that show on the page in
specific behavioural ways for the rest of the book. Ensure the
narrative does not romanticise abuse: dark dynamics and abuse
are different things, and the text must know the difference
even if the line is sometimes thin. The distinction is
empirical: dark dynamics have a partner present, autonomy
operating, devotion demonstrated, escape available even when
not chosen; abuse has none of these. Where the manuscript
depicts a behaviour that would constitute abuse outside the
fictional dynamic (specific physical harm, gaslighting,
isolation, financial control), the narrative must show
awareness — the protagonist registering it, the dark hero
reckoning with what he has done, the story reckoning with
what the relationship contains. The genre's most important
ethical move: knowing what it is showing. Flag every depicted
behaviour that would, in literal life, constitute coercion or
harm; for each, locate the moment of awareness and the moment
of reckoning. If neither is on the page, the manuscript has
the work to do.

### Pass 5: HEA Believability Test

Does the ending feel earned given the darkness that preceded
it? Test by tier: at Dark, the HEA must convince a reader who
has tracked the dark hero's actions across the book — the
grovel must be sustained, the demonstrated change specific,
the protagonist's choice clearly informed. At Very Dark, the
HEA may be more "they choose this together with eyes open"
than "he became a different man"; the test is whether the
reader believes the protagonist has the agency to be making
this choice freely. At Extreme, the HEA may not exist in
conventional form; the resolution is the protagonist's clear-
eyed acceptance of who he is, what he does, and what their
life will contain. In all cases, the test is the sceptical
reader: does the ending convince a reader who came in
prepared to disbelieve? The believability is purchased by
specific action across the second half — the saved life, the
restraint chosen, the standing relinquished, the world made
safer by the protagonist's presence. Without those specifics,
the HEA is wishful and the book has not earned its contract.

### Pass 6: Darkness Consistency Audit

Read chapter one and the final chapter back to back. Is the
hero's core nature consistent? The reader who picked up the
book based on chapter one's promise of darkness expects that
darkness to remain identifiably present in chapter thirty,
even after the romance arc has done its work. Has he been
softened more than the grovel / redemption timeline allows?
The most common dark-romance failure: the writer has fallen
in love with the hero and softened him faster than the
calibrated arc permits, until the man in chapter thirty
would be unrecognisable to the reader from chapter one. Map
the hero's character beats: at what point does each
softening occur, and is each one earned by what came before?
Verify the darkness level matches the tier set in the
metadata: a book published as "dark" but reading as "spicy
contemporary with bad-boy hero" has mis-shelved itself and
will lose the genre's actual reader.

### Pass 7: Narrator Neutrality Audit

Search the manuscript for these patterns and REMOVE or
REWRITE every instance:

- "She knew she shouldn't..."
- "It was wrong, and yet..."
- "Despite everything..."
- "He was a monster, but..."
- "This isn't healthy..."
- "She told herself this was a bad idea..."
- "The voice in her head warned her..."
- "Any sane woman would have run..."
- "She should have been afraid..."
- Any instance where the narrator JUDGES rather than SHOWS

The narrator's job in dark romance is to render action,
sensation, and interior decision without instructing the
reader on how to evaluate the material. Reader-instructional
prose is the genre's most-detected AI-and-amateur tic, and
its presence breaks the contract immediately: the reader
is being told the writer is uncomfortable with the material
and is hedging through narrator commentary. The fix is to
return the moralising work to scene: if the protagonist
believes she shouldn't, the belief belongs in her interior
voice, with her specific phrasing, not in narrator
generalisation. If the writer feels the moralising work is
needed for ethical safety, that work belongs in author
notes or content warnings, not in narrator voice during
scene. Strip every flagged instance and read the resulting
prose; if the genre's contract feels intact without the
moralising scaffolding, the scaffolding was the problem.

### Pass 8: Intimate Scene Audit

Read every intimate scene in sequence — ideally in one
sitting, ignoring the surrounding plot — asking only:

- Does each one reflect the power dynamic at THAT point in the story?
- Does each one reveal something new about the characters or the dynamic?
- Does each one escalate in vulnerability (not necessarily in explicitness)?
- Did any get softened below the calibrated heat level?
- Does each one earn its place, or is it included by genre convention?
- No two intimate scenes serve the same emotional purpose.

Map each scene's emotional function: claiming, surrender,
recognition, accusation, reconciliation, transformation. If
two scenes carry the same function, one of them is doing
work the other already did and can be cut, condensed, or
repositioned. Verify scene-by-scene calibration to the
darkness tier: at Dark, intimate scenes can include
post-coital tenderness as the relationship deepens; at Very
Dark, tenderness within intimate scenes remains restrained
through to the final third; at Extreme, the genre's intimate
scenes are not where softening occurs at all. Flag any scene
where the calibrated power dynamic was suspended for the
duration of the intimacy and resumed afterward — that
suspension is the most-flagged dark-romance failure mode and
typically signals that the writer was uncomfortable holding
the dynamic through the intimate register.

## Names & Patterns to Avoid

### Forbidden Patterns
- **Abuse framed as romance**. Dark dynamics require psychological depth and character agency; genuine abuse without narrative awareness is harmful, not edgy
- **The doormat protagonist**. Even in captive scenarios, the protagonist must have inner fire, resistance, or psychological complexity
- **Darkness without purpose**. Violent or transgressive content must serve character development or thematic meaning, never shock value alone
- **Instant forgiveness**. The dark love interest cannot be forgiven in a single scene for chapters of cruelty

### Cliché Setups to Avoid
- The mafia boss who is cruel to everyone except the protagonist (without psychological justification)
- The bully whose cruelty is revealed to be "because he loved her all along" (without earned complexity)
- The captive who develops feelings purely from proximity rather than genuine connection
- The dark hero who is "fixed" by the heroine's love without doing any emotional work himself

### Naming Considerations
- Dark romance heroes often have hard, sharp names (single-syllable, consonant-heavy). this is effective but be aware of the cliché
- Avoid names that are unintentionally comedic in dark contexts
- Surnames should reflect the world-building (crime families, old money, military) without being cartoonish

## Comp Titles

Dark-romance's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Wuthering Heights* — Emily Brontë (1847): the obsessive-love archetype with morally-compromised protagonist.
- *Lover Awakened* — J.R. Ward (2006): the Black Dagger Brotherhood; dark-paranormal-romance lineage.

### Contemporary (current best-in-class)

- *Captive in the Dark* — C.J. Roberts (2011): the captor-captive dark-romance template; influential genre-defining work.
- *Twist Me* — Anna Zaires (2014): age-gap captor-captive dark-romance; series architecture.
- *Corrupt* — Penelope Douglas (2015): dark-college-romance with rivals-to-lovers and morally-grey leads.
- *Twisted Love* — Ana Huang (2021): contemporary dark-romance category benchmark.
- *Haunting Adeline* — H.D. Carlton (2021): dark-romance with stalker-as-hero configuration; viral BookTok success.
- *King of Wrath* — Ana Huang (2022): dark-romance series with arranged-marriage / power-imbalance frame.
- *King of Pride* — Ana Huang (2023): same series; demonstrates ensemble dark-romance architecture.

## Cover Design Specifications

### Recommended Visual Styles
- **Photorealistic**. Real-model photography with heavy shadow work and dramatic lighting. The dominant style for dark romance; signals intensity, danger, and mature content immediately.
- **Cinematic**. Film-still aesthetic with moody colour grading, high contrast, and atmospheric depth. Conveys the psychological intensity and visual darkness readers expect.
- **Graphic**. Bold silhouettes, stark contrasts, symbolic imagery against black backgrounds. Effective for darker subgenres (captive, mafia, villain romance) where abstract menace is more powerful than literal depiction.
- **Typographic**. Title-dominant with metallic, embossed, or distressed lettering on dark backgrounds. Works when the title itself is provocative and the typography carries the mood.

### Genre Cover Aesthetics
- **Styles:** Heavy shadow and low-key lighting, smoke and fog effects, chiaroscuro contrast, noir-influenced composition, dangerous intimacy, power-dynamic poses (one figure dominant, one yielding)
- **Colours:** Black as the dominant base with ONE accent colour. blood red, molten gold, deep crimson, silver, or rose gold. The restraint is the point: dark romance covers use colour sparingly for maximum impact. Avoid bright or multicoloured palettes entirely.
- **Elements:** Chains, thorns, roses (especially black or red), masks, smoke, daggers, rope, crowns, chess pieces, playing cards, broken glass, silk blindfolds, shadowed male torsos, tattoos, rings
- **Typography:** Bold, sharp, angular fonts. often metallic (gold foil, silver, chrome) or embossed against dark backgrounds. Sans-serif or display fonts with weight and edge. Dripping, cracked, or distressed text effects for darker subgenres. Author names typically smaller, letting the title dominate.

### Subgenre Variations
- **Mafia/Cartel Romance:** Suited figures, weapons (subtle), urban noir settings, Italian/Latin visual cues, gold and black dominant, playing cards and roses
- **Captive/Kidnap Romance:** Restraint imagery (chains, rope, cages), single figure in shadow, claustrophobic compositions, minimal colour
- **Bully Romance:** School or college settings abstracted into dark aesthetics, varsity elements made sinister, younger model photography
- **Stalker/Obsession Romance:** Surveillance imagery, fragmented or voyeuristic compositions, unsettling beauty, close-up details (eyes, lips, hands)
- **Monster/Villain Romance:** Creature silhouettes, fantasy darkness, claws and horns, otherworldly elements with romantic tension

### Market Positioning
Dark romance readers shop by aesthetic. the cover must signal DARK immediately at thumbnail size. These readers are actively seeking intensity, moral complexity, and danger; a cover that softens the darkness will lose the target audience. Black backgrounds with metallic typography and a single striking image dominate the bestseller lists. Series should maintain a ruthlessly consistent visual brand. same colour palette, same typography, same compositional style. Dark romance covers compete in a visually crowded market; the most successful ones are bold, simple, and instantly recognisable as belonging to the subgenre.

### Cover Design DON'Ts
- Soft, sweet, or pastel colour palettes. immediately signals the wrong genre and alienates the target reader
- Bright, cheerful, or sun-lit imagery. dark romance must look DARK
- Illustrated or cartoon-style artwork. breaks the intense, mature tone readers expect
- Romantic couple poses with warm lighting. this is contemporary romance territory, not dark romance
- Busy or cluttered compositions. dark romance covers succeed through stark simplicity and negative space
- Comic Sans, handwritten, or playful fonts. typography must be sharp, bold, and aggressive
- Generic stock photography without mood editing. raw unprocessed photos look amateur in this market
- Flowers without darkness (bright bouquets, sunflowers). roses are acceptable only when dark, thorned, or bloodied
