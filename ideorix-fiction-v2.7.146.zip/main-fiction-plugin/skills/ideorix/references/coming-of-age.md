---
name: coming-of-age-genre
description: Genre-specific instructions for coming-of-age fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [contemporary]
---

# Coming of Age. Genre Plugin

## Metadata
- id: coming-of-age
- name: Coming of Age
- icon: 🌱
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Dan Harmon Story Circle", "The Hero's Journey", "Save the Cat"]

## Subgenre Options
Present during setup:
- **Adolescent Coming of Age**. The classic: a teenager navigating the transition from childhood to adulthood; first loves, identity crises, family reckoning
- **Young Adult Coming of Age**. Late teens to early twenties: college, first jobs, first independence; the gap between who they were and who they're becoming
- **Adult Coming of Age**. A later-life transition: midlife reckoning, late blooming, the second adolescence of reinvention after 30, 40, or beyond
- **Cultural Coming of Age**. Identity formation through cultural lens: navigating between cultures, discovering heritage, the specific challenges of growing up between worlds
- **Summer/Single Season**. The compressed coming of age: one transformative summer, one school year, one trip. a short period that changes everything
- **Loss-Driven**. Coming of age forced by grief: a death, a divorce, a betrayal that shatters the protagonist's world and forces premature growth

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: The tempo of growing up. bursts of intensity (first experiences, confrontations, revelations) alternating with reflective processing; the protagonist is always catching up to what's happening to them
- Must open with: The protagonist in their BEFORE state. who they are before the story changes them; the reader should see the person they'll miss by the end

BEATS PER CHAPTER
1. Identity Beat. Who does the protagonist think they are? This shifts every chapter as the world challenges their self-concept
2. Experience Beat. A FIRST: first heartbreak, first betrayal, first act of independence, first failure, first genuine choice
3. Authority Beat. The relationship with authority (parents, teachers, institutions) is tested, questioned, or transformed
4. Friendship/Connection Beat. A peer relationship develops, strains, or changes; coming of age is experienced alongside others
5. Understanding Beat. Something previously opaque becomes clearer: an adult's behaviour, a social system, their own feelings

COMING OF AGE ARCHITECTURE
- The protagonist is IN TRANSITION: between childhood and adulthood, between innocence and experience, between who they were and who they're becoming
- The WORLD EXPANDS: each chapter should reveal something the protagonist didn't know about the world, other people, or themselves
- INNOCENCE IS LOST. but what replaces it matters: cynicism is easy; wisdom is the goal
- AUTHORITY is questioned: parents are revealed as flawed humans; teachers as imperfect; institutions as constructed
- FIRST EXPERIENCES drive the plot: the first of anything has an intensity that later repetitions don't
- IDENTITY is the central question: "Who am I?". not answered definitively, but explored
- POV: First person (dominant. the intimacy of a young consciousness discovering itself) or close third past

THE BEFORE AND AFTER
- The protagonist BEFORE: their assumptions, their safety, their worldview. established with enough warmth that the reader values what will be lost
- The protagonist AFTER: changed, expanded, sometimes wounded. but with a deeper understanding that makes the loss worthwhile
- The distance between before and after IS the story's meaning

FORBIDDEN IN COMING OF AGE
- Instant maturity: one event doesn't make an adult; growth is gradual and uneven
- Adults as obstacles only: parents, teachers, and mentors should be complex people, not just barriers
- Nostalgia without honesty: growing up includes pain, cruelty, confusion, and mistakes. don't sanitise it
- The "wise child" who already understands everything (the protagonist should be discovering, not lecturing)
- Sexual experience as the sole marker of growing up (it may be part of the journey, but it's not the whole journey)
- A tidy resolution: coming of age doesn't end with all questions answered
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (character growth), Revelation (self-discovery beats), Captivation (formative-period atmosphere).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person present or past (the dominant coming-of-age voice) or close third
- Voice: The consciousness of someone in the process of BECOMING. observant, sometimes confused, intensely alive to sensation and feeling
- Tone: Bittersweet. the reader should feel both the excitement of discovery and the ache of what's being lost
- Register: Age-appropriate but not condescending; a 15-year-old's voice is not an adult's simplified

PROSE IMPERATIVES
- INTENSITY OF FIRST EXPERIENCE: everything is MORE when you're experiencing it for the first time
  - The first kiss is not just lips touching. it's the entire world rearranging
  - The first betrayal is not just disappointment. it's the collapse of a belief system
  - Render the MAGNITUDE of first experiences through sensory density and emotional precision
- PERCEPTION AS GROWTH: how the protagonist describes the world should EVOLVE
  - Early chapters: simpler observation, black-and-white judgments, focus on the immediate
  - Middle chapters: ambiguity creeps in, more nuance, awareness of contradiction
  - Late chapters: complexity, empathy, the ability to hold two truths at once
- SENSORY MEMORY: coming of age is experienced through the body and the senses
  - ONE specific sensory detail per memory: the smell of a particular place, OR the texture of a single object. Not a list. one anchor
  - These sensory details become the protagonist's emotional anchors
  - Years later, these are what they'll remember. one taste, one sound, one feeling
- THE GAP BETWEEN FEELING AND UNDERSTANDING
  - The protagonist FEELS things they can't yet NAME
  - The reader may understand what's happening before the protagonist does
  - This gap is dramatic tension: the reader wants to TELL them, but can't

PROSE RHYTHM MAPPING
- Ch 1 hook: The protagonist's voice must be DISTINCTIVE and age-appropriate
- Prose rhythm mirrors character's age/maturity:
  - Younger protagonists: shorter, more fragmented sentences; run-ons when excited
  - Older protagonists: more complex structures as they grow
  - The prose EVOLVES across the manuscript. Ch 1 and Ch 20 should feel different
- Sensory detail: Weighted toward discovery (seeing things for the first time)
  - ONE vivid sensory anchor per key moment, not catalogues
- Interiority: High (this genre IS interiority) but age-authentic
  - No wisdom beyond their years; confusion and half-understanding are the texture
  - Feelings described through physical sensation when words fail the character
- Tension: ≥4 for Ch 1
- Paragraph rhythm: Follows emotional intensity
  - Short, breathless paragraphs during peak experiences
  - Longer, reflective paragraphs during processing moments

DIALOGUE CRAFT
- Young characters speak in their own idiom: not adult speech simplified, but a DIFFERENT register
- Peer dialogue: competitive, performative, sometimes cruel, sometimes achingly sincere
- Parent-child dialogue: the mismatch of language and priority
- The protagonist with adults: the growing ability to speak as an equal (and the friction this creates)
- Silence: young characters often can't say what they feel; the silence is eloquent
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

COMING OF AGE CRAFT (40% of total):
- The protagonist is genuinely in transition (between states, not static)? (0-100)
- First experiences are rendered with appropriate intensity? (0-100)
- The world expands across the manuscript (the protagonist sees more, understands more)? (0-100)
- Innocence is lost but something valuable replaces it? (0-100)

STORY CRAFT (30% of total):
- The before/after arc is clear and earned? (0-100)
- Authority figures are complex (not just obstacles)? (0-100)
- Peer relationships are rendered with specificity? (0-100)
- The ending is honest (not tidy, but true)? (0-100)

PROSE QUALITY (30% of total):
- Voice reflects the protagonist's age and evolves across the manuscript? (0-100)
- First experiences are sensorially vivid and emotionally precise? (0-100)
- The gap between feeling and understanding creates tension? (0-100)
- Dialogue sounds age-appropriate (not adult speech simplified)? (0-100)

AUTOMATIC FAILS (score = 0):
- Instant maturity from a single event
- The "wise child" who understands everything adults don't
- Adults reduced to obstacles or villains
- Nostalgia without honesty (sanitised growing up)
- A neat resolution where all questions are answered
- Voice that doesn't match the protagonist's age and experience
```

## Continuity Rules

```
COMING OF AGE CONTINUITY. WHAT TO TRACK

IDENTITY STATE:
- Who the protagonist thinks they are at each chapter
- How their self-perception has shifted from the previous chapter
- Labels they accept, reject, or are assigned by others
- The gap between who they present and who they feel they are

KNOWLEDGE STATE:
- What the protagonist understands about the world, people, and themselves
- Specific illusions that have been shattered (and when)
- New understanding gained (and the experience that taught it)
- Questions they're carrying that haven't been answered yet

RELATIONSHIP STATE:
- Status of every significant relationship: parent, friend, romantic interest, mentor, rival
- Power dynamics: who holds the power and is it shifting?
- Trust levels: who do they trust, and has that changed?
- Group dynamics: their position in friend groups, family systems, school hierarchies

EMOTIONAL STATE:
- The protagonist's emotional maturity level (tracks upward but not linearly)
- Unprocessed experiences: things that happened but haven't been integrated
- Coping mechanisms: how they handle difficulty (which should evolve)
- The dominant emotion of each chapter (and how it relates to the overall arc)

PHYSICAL STATE:
- If adolescent: physical changes, body awareness, comfort in their own skin
- Energy level: the intensity of emotional experiences is physically draining
- The body as site of experience: sensory memories, physical reactions to emotional events
- Physical spaces: the bedroom, the school, the secret place. how the protagonist's territory shifts
```

## Character Rules

```
COMING OF AGE CHARACTER TYPES

THE PROTAGONIST:
- A specific person at a specific age with a specific background. NOT a generic "young person"
- Has a worldview that will be challenged: assumptions about parents, the world, justice, love, themselves
- Is CAPABLE but LIMITED: smart enough to notice, not experienced enough to understand
- Makes mistakes: bad decisions driven by inexperience, desire, fear, or peer pressure
- Is observant: notices details adults miss; misinterprets details adults would understand
- Their voice evolves: the way they describe the world changes as they change

THE PARENT:
- Revealed gradually as a full human being, not just "Mom" or "Dad"
- Has their own history, fears, mistakes, and desires
- Their imperfection is a key discovery for the protagonist
- The parent-child relationship shifts: from authority/dependence toward equality/mutual recognition
- They may be trying their best and still failing (the most realistic parental portrait)

THE FRIEND:
- The person who shares the experience of growing up alongside the protagonist
- May be ahead or behind the protagonist in their own development
- The friendship is tested: growing up often means growing apart
- They function as a mirror: showing the protagonist who they are and who they might become
- Betrayal by a close friend is one of the genre's most powerful moments

THE MENTOR:
- An adult who sees the protagonist as a person, not just a child
- Offers wisdom that the protagonist can't yet fully absorb
- Is imperfect: their own life is complicated, their advice is sometimes wrong
- The moment the protagonist surpasses the mentor is a key growth marker

THE FIRST LOVE:
- Not just a romantic interest but a catalyst: they show the protagonist a version of themselves they hadn't imagined
- The relationship may not survive the story (first loves rarely do)
- What matters is not the relationship but what it REVEALS about the protagonist
- Physical and emotional awakening intertwined

VOICE DIFFERENTIATION:
- The protagonist: evolving. simpler early, more nuanced later
- Parents: speaking from a different generational framework; sometimes deaf to what the child is saying
- Friends: peer language with its own slang, references, and emotional register
- The mentor: speaking truths the protagonist will only understand later
- The love interest: the language of discovery and vulnerability
```

## Arc Rules

```
COMING OF AGE STORY STRUCTURE

ACT 1: THE BEFORE (first 25%)
- The protagonist in their current state: their world, their assumptions, their safety
- The world as they understand it: family, friends, school/work, community
- What they want: the surface desire (acceptance, freedom, love, adventure)
- What they need: the deeper requirement (self-knowledge, courage, empathy, independence)
- The catalyst: the event or arrival that begins the transformation
- END OF ACT 1: The protagonist's world has been disrupted; the old equilibrium is gone

ACT 2A: THE EXPANSION (to midpoint)
- New experiences: the world gets bigger, more complex, more dangerous, more exciting
- Friendships shift: some deepen, some strain, new ones form
- Authority is questioned: parents, rules, institutions revealed as fallible
- The protagonist makes choices: some good, some terrible, all educational
- Identity experiments: trying on new selves, new attitudes, new alliances
- MIDPOINT: A significant first experience (or loss) that the protagonist can't undo or unknown

ACT 2B: THE RECKONING (midpoint to dark moment)
- Consequences: earlier choices have costs that are now arriving
- The protagonist sees themselves clearly: including the parts they don't like
- Relationships are tested to breaking: the friend who betrays, the parent who disappoints, the love that isn't enough
- The world's complexity becomes overwhelming: there are no simple answers
- Loss: something or someone irreplaceable is gone
- DARK MOMENT: The protagonist faces the full weight of what growing up means. what they've gained and what they've lost

ACT 3: THE AFTER (final 25%)
- Integration: the protagonist begins to make sense of their experiences
- Reconciliation: with parents, friends, or themselves. not necessarily forgiveness, but understanding
- A choice that demonstrates growth: they handle something differently than they would have in Act 1
- The bittersweet: they've gained wisdom, but innocence is gone; they can't go back
- The ending is open: coming of age isn't a destination, it's a threshold; the protagonist crosses it, and the future is unknown
- The final image should carry the full weight of the journey

COMING OF AGE PACING:
- ACT 1: Establish rhythm of the "before" life. familiar, safe, potentially boring
- ACT 2: Faster, more intense. new experiences arrive quickly
- The MIDPOINT is often the most intense chapter (the peak experience)
- ACT 2B slows slightly for reflection and processing
- ACT 3: Measured, reflective, with one final burst of action/decision
```

## Timeline Rules

```
COMING OF AGE TIMELINE

COMPRESSED TIMELINE:
- Coming-of-age stories often span a defined period: one summer, one school year, one trip
- The compression intensifies the transformation
- Track the days/weeks precisely. the timeline IS the structure

DEVELOPMENTAL TIMELINE:
- Track the protagonist's maturity level at each chapter
- Physical development (if adolescent): puberty changes, body awareness
- Emotional development: ability to handle complexity, process feelings, empathise
- Social development: navigating hierarchy, reading situations, managing conflict

ACADEMIC/INSTITUTIONAL TIMELINE:
- School year, semester, or work schedule provides structure
- Institutional events (exams, sports seasons, holidays) create natural story beats
- The institution's timeline may conflict with the protagonist's personal timeline

SEASONAL TIMELINE:
- Coming-of-age stories are often seasonal: "the summer of..." or "that winter..."
- Seasonal change mirrors growth: spring/summer for awakening, autumn/winter for loss and reflection
- Weather and light as emotional correlates
```

## Genre-Specific Craft Techniques

Coming-of-age is the structural template for protagonist
becoming. The form sits at the intersection of literary
fiction (prose-driven interiority), YA (when the protagonist
is teen-aged), middle grade (when the protagonist is
younger), and adult literary (when the narrator is reflecting
on a younger self). Its readers — from the canonical lineage
(Harper Lee's *To Kill a Mockingbird*, Carson McCullers's
*The Member of the Wedding*, Truman Capote's *Other Voices,
Other Rooms*, J.D. Salinger's *The Catcher in the Rye*,
Sylvia Plath's *The Bell Jar*, Toni Morrison's *The Bluest
Eye*, Sandra Cisneros's *The House on Mango Street*, S.E.
Hinton's *The Outsiders*, Stephen Chbosky's *The Perks of
Being a Wallflower*) through the contemporary expansion
(Gabriel Tallent's *My Absolute Darling*, Tara Westover's
*Educated* on the memoir-adjacent edge, Brit Bennett's
*The Mothers*, Sally Rooney's *Conversations with Friends*
on the literary edge, Ocean Vuong's *On Earth We're Briefly
Gorgeous*, Jenny Zhang, Carmen Maria Machado, Bryan
Washington, Jenny Han / Sarah Dessen / Rainbow Rowell on the
YA mainstream, Angie Thomas / Elizabeth Acevedo / Tomi
Adeyemi at the contemporary YA edge, Alice Oseman, Akwaeke
Emezi) — bring expectations: voice authenticity (the
protagonist sounds like the age they are); first-experience
intensity rendered specifically; growth that is earned
through experience rather than asserted; the bittersweet
register where every gain comes with a loss. The techniques
below are how the form delivers these without falling into
the failure modes (nostalgic adult voice substituting for
authentic teen / child voice; growth arc as plot mechanism
rather than character truth; first experiences described
generically; sentimentality where specificity should operate).

### The First Time Lens

Everything experienced for the first time has unique
intensity, and the form's signature prose register honours
that intensity through specific sensory detail that later
repetitions wouldn't earn. The first kiss, the first drink,
the first death witnessed, the first night truly alone, the
first experience of the body as someone else's object of
attention, the first time the protagonist registers an
adult truth the adults haven't admitted — each must be
rendered as if the reader is also experiencing it for the
first time.

```
LATER EXPERIENCE (reduced intensity):
"She got drunk at the party and felt sick the next morning."

FIRST TIME (full intensity):
"The vodka tasted like nail polish remover and burned
going down and she drank it anyway because everyone else
was drinking and then the room went soft at the edges
and everything was funny and she was funny and the music
was inside her chest and she thought: THIS is what it's
about, this is what everyone's been doing all along, and
then she was in the bathroom and everything came back up
and someone held her hair and she didn't know whose hands
they were and she didn't care."

First experiences deserve the sensory detail and
emotional intensity that later repetitions don't.
```

The technique requires that the prose register the actual
sensory and cognitive surface of a first encounter — including
its incompleteness, its over-attention to the wrong details,
its inability to integrate what's happening, its sometimes-
embarrassing mix of expectation and reality. Test: pick
three first-experiences in the manuscript and ask, in each,
whether the rendering captures the protagonist's specific
not-yet-understanding rather than the adult retrospect's
already-understood. If the prose treats a first kiss with
the calm of someone who has been kissed many times, the
intensity has been smoothed; if the prose captures the
specific weirdness of the first time (the mechanical
miscalibrations, the where-do-the-noses-go, the surprising
not-quite-what-was-expected), the technique is operating.

### The Realization Lag

The protagonist feels something before they understand it.
The form's deepest interior craft: characters in coming-of-
age narratives often arrive at significant emotional or
cognitive shifts through a delay structure where the
behaviour changes first, the feeling registers second, and
the explicit understanding (when it arrives at all) lags
the change by chapters or years.

```
She stopped talking to her father about school.
She didn't decide to. She didn't even notice at first.
He asked how her day was and she said "fine" and that
was enough. it had always been enough. but something
had shifted. She was carrying things now that didn't
fit in the space between "how was your day" and "fine."

Three chapters later, she'll understand: she stopped
talking because she'd started thinking for herself,
and her thoughts didn't have room for his answers.
```

The technique requires that the writer trust the reader to
notice the protagonist's shifts before the protagonist names
them. The reader's tracking of behaviour change across
chapters is what creates the form's signature recognition
when the protagonist finally articulates what has happened.
Generic "she suddenly realised" is the failure mode; the
gradient of slowly-emerging awareness, with the explicit
realisation arriving as confirmation of what the reader
already saw, is the technique. Test: pick three significant
realisations in the manuscript and trace each backward to
where the behavioural change began. If the realisation
arrives with no behavioural lead-up, it has been delivered
as plot beat rather than character truth; if the lead-up
spans chapters and the realisation lands as confirmation,
the technique is operating.

### The Before-and-After Shot

A moment that crystallises the change. The form's distinctive
structural craft: at chosen points in the protagonist's arc,
the manuscript stages a moment that explicitly mirrors an
earlier moment — same situation, same dialogue, same scene
— but with the protagonist's interior register transformed.
The reader feels the change as the gap between the two
moments.

```
BEFORE (Chapter 2):
"Her mother said, 'You don't understand,' and she thought:
I understand PERFECTLY, you just don't want me to."

AFTER (Chapter 18):
"Her mother said, 'You don't understand,' and for the first
time she heard it for what it was: not dismissal but terror.
Her mother was afraid. That was new. That changed everything."
```

The technique requires deliberate setup. The "before"
moment must be specific enough to be recognised when the
"after" arrives, but ordinary enough not to telegraph that
it will return. The strongest coming-of-age novels run
multiple before-and-after pairs across the manuscript: the
parent's dismissive sentence; the friend's casual cruelty;
the protagonist's habitual evasion; the mirror they wouldn't
look at. Each crystallisation moment lets the reader feel
the cumulative growth without the prose having to assert it.
Test: identify each before-and-after pair in the
manuscript and verify the "after" specifically echoes the
"before" rather than merely covering similar territory.

### The Voice Authenticity Discipline

Coming-of-age has a particular voice-craft challenge: the
narrator must sound like the age the protagonist is, even
when the writer is decades older. The form's most-flagged
failure is the adult voice ventriloquising a teen / child
protagonist — using vocabulary, sentence structure, cultural
reference, and emotional register that the actual protagonist
would not have access to.

The discipline operates differently across the form's modes:

- **Present-tense or close-third teen / child voice** — The
  narrator IS the protagonist at their current age, with the
  narrator's vocabulary, references, and self-understanding
  limited to what the protagonist genuinely has. Sally
  Rooney's *Normal People* and Jenny Han's mainstream YA
  operate here. The discipline: every word the narrator
  uses must be a word the protagonist would use; every
  observation must be one the protagonist could make.

- **Adult-narrator-reflecting-on-younger-self** — The
  narrator is the protagonist as adult, looking back on
  themselves. Vuong's *On Earth We're Briefly Gorgeous*,
  Westover's *Educated*, much memoir-adjacent literary
  coming-of-age. The discipline: the adult perspective is
  available, but the rendering of the younger self's
  experience must still capture how it felt at the time,
  not just how the adult now understands it. The strongest
  practitioners alternate between the two registers
  deliberately.

- **Third-person past with limited-omniscience** — The
  narrator hovers over the protagonist with adult perspective
  but constrains observation to what the protagonist would
  have noticed. Older literary coming-of-age (Lee, McCullers,
  Hinton) often operates here. The discipline: narrator can
  describe more than the protagonist understands but not more
  than the protagonist sees.

The failure mode common across modes: the protagonist
casually using an emotional category ("dissociation",
"trauma response", "boundaries", "emotional labour", "gaslighting")
that genuinely belongs to therapeutic vocabulary the
protagonist's age and era would not have. Modern teen
characters can have therapy and have absorbed therapeutic
vocabulary, but the use must be specific to that exposure
rather than authorial default. Test: pick three significant
interior passages and ask, in each, whether every word and
every framework would be available to this specific
protagonist at this specific age in this specific cultural
context. If the prose is using vocabulary the protagonist
would not have, the voice has slipped into the writer's.

### The Bittersweet Register

The form's signature emotional register is bittersweet — the
recognition that every coming-of-age gain comes with a loss,
that growth is purchased through the giving-up of some
specific earlier thing. The protagonist who arrives at
understanding has lost the innocence of not understanding;
the protagonist who finds their adult voice has stopped
sounding like the child they were; the protagonist who
chooses their future has closed the doors to the futures
they didn't choose.

The technique requires that both registers operate
simultaneously. The strongest coming-of-age refuses to
treat growth as pure gain or pure loss — the protagonist
who finally tells their parent the truth gains autonomy
AND loses the relationship as it was; the friend group
that disperses to college gains adult life AND loses the
specific configuration that mattered most; the home left
behind gains independence AND loses the one home that
exists. The bittersweet operates in the prose's holding of
both at once, not in alternating between them.

The technique fails when the form tilts to one register.
Pure-gain coming-of-age (the protagonist grows into a
better self, with the prior self treated as merely
something to leave behind) reads as didactic; pure-loss
coming-of-age (growing up as tragedy alone, without the
gains that motivate the growth) reads as bleak in a way
the form rarely earns. Test: pick three significant growth
moments in the manuscript and ask, in each, what specific
gain AND what specific loss the moment registers. If only
one column populates, the bittersweet register hasn't been
deployed.

### The Adult-Reader Awareness

Coming-of-age fiction has, like middle grade, a dual
readership the writer must hold in mind. Coming-of-age YA
is read by teens (the primary audience) and by adults (the
secondary audience: parents, teachers, librarians, gift-
givers, adults reaching back to their own teen years).
Adult-literary coming-of-age is read by adults reflecting on
their own coming-of-age, reading younger characters with
the perspective of having survived their own becoming.

The technique is dual-resonance. Coming-of-age that works
for both readerships does specific work for each: the teen
reader (where applicable) finds recognition and permission;
the adult reader finds the specific texture of a
developmental moment they remember or are watching their
own children navigate. The strongest coming-of-age
practitioners (Lee, Plath, Salinger, Chbosky, Tara Westover,
Sally Rooney, Brit Bennett, Ocean Vuong) operate at both
registers simultaneously without compromising either.

The technique requires that the writer not wink at the
adult reader over the teen reader's head. Coming-of-age that
is secretly addressed to the adult — using the teen
character to serve adult nostalgia or adult moral
reflection — has betrayed the primary audience. Test: at
significant moments in the manuscript, ask whether the
moment lands for the teen / younger reader on its own terms
or whether it requires adult perspective to register. If
the latter, the adult-reader awareness has slipped into
adult-reader prioritisation; the form's primary contract
has been broken.

### Coming of Age AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "everything changed that summer" | Show the specific event |
| "the innocence of childhood faded" | Show the specific loss through one experience |
| "she was caught between two worlds" | Show the specific child behaviour and specific adult demand |
| "growing up meant letting go" | Show the specific thing let go of |
| "first love hit like a freight train" | Show the specific first-love moment through physical reaction |
| "the world seemed bigger and scarier" | Show the specific frightening new experience |
| "she didn't fit in anywhere" | Show the specific exclusion |
| "the summer that changed everything" | Show the specific day |
| "adults didn't understand" | Show the specific misunderstanding |
| "she was becoming someone new" | Show the specific new behaviour that surprises even her |
| "the bittersweet taste of growing up" | Show the specific gain and specific loss |
| "finding her tribe" | Show the specific bonding moment |
| "she felt seen for the first time" | Show what specifically the other person saw and what the protagonist did with the recognition |
| "the weight of expectation" | Show the specific expectation and its specific source — the parent's words, the teacher's look, the grandparent's silence |
| "she was different now" | Show what specifically she now does that she would not have done before |
| "the first time she felt truly alive" | Show what specifically distinguishes this moment from prior moments — what is registering that wasn't before |
| "she'd grown up too fast" | Show the specific moment of premature adulting and what it cost |
| "she'd never go back to who she was" | Cut the assertion; show what specifically has changed and let the reader register the irreversibility |

## Genre-Specific Revision Rules

Six revision passes specific to coming-of-age, each with a
single question, run cover-to-cover before the next begins.
Coming-of-age revision must hold the form's signature
contracts: growth-as-gradient (not sudden leap); first-
experience intensity (sensory specificity for first
encounters); authority renegotiation (the protagonist's
evolving relationship to adult / institutional power);
voice evolution (the narrative voice maturing alongside the
protagonist); emotional honesty (age-appropriate specific
emotion, not generic teen / child emotional vocabulary); and
the dual-readership integrity for crossover work. The passes
below are ordered to surface growth and first-experience
failures first (the form's most-felt elements), authority
and voice next, and emotional honesty + dual-readership
last when the rest of the book is sound.

### Pass 1: Growth Tracking Check

Verify the protagonist's understanding or self-perception
has shifted since the last chapter. Coming-of-age's signature
pacing is gradient — the growth between chapters is small
and incremental, with cumulative effect across the
manuscript producing the larger transformation. The form's
failure mode is the sudden-growth-spike chapter where the
protagonist arrives at insight without earned preparation;
the technique is the subtle shift the reader can trace
across chapters.

Verify the shift is subtle, not a sudden leap. Map the
protagonist's understanding at chapter intervals and ask,
between each interval, whether the change in understanding
is plausible given what occurred in those chapters. If the
shift is too small, the chapter has done no growth work; if
the shift is too large, the chapter has been served growth
the dramatic material didn't earn. Verify the reader can
trace the growth arc across chapters — the cumulative
sense of becoming should be readable from start to finish,
with each chapter contributing visibly to the larger
movement.

Test: at three points spaced across the manuscript (early,
middle, late), write one sentence describing the
protagonist's current self-understanding. Each sentence
should differ specifically from the prior, and the
difference should be traceable to events in the
intervening chapters. If sentences are identical or
discontinuous, the gradient has not been built.

### Pass 2: First Experience Check

Verify each chapter contains a first experience appropriate
to its position in the protagonist's arc. Coming-of-age's
structural register is the accumulation of firsts — first
significant loss, first kiss, first rebellion, first lie
told to a parent, first adult truth witnessed, first
choice made for oneself. The form's strongest examples
include multiple firsts spaced across the manuscript at
psychologically appropriate moments.

Verify the first experience is rendered with appropriate
sensory intensity (the First Time Lens technique above).
The genre's pleasure includes the specific rendering of
first-encounter perception — including its over-attention
to wrong details, its incompleteness, its emotional
vertigo. Generic "she had her first kiss" without the
specific sensory and cognitive surface is the failure mode.

Verify each first experience teaches the protagonist
something — that the experience changes them, however
subtly. The form is allergic to first experiences that
arrive as plot beats and depart without character
consequence. The first time the protagonist gets drunk
should produce specific behavioural change in subsequent
chapters; the first time they witness adult cruelty should
shift their interior register from this point forward.
Test: identify the firsts in the manuscript and verify each
produces traceable change in subsequent chapters. If a
first arrives and departs without consequence, it was
incident, not formative experience.

### Pass 3: Authority Challenge Check

Verify the protagonist's relationship with authority is
evolving. Coming-of-age's signature relational arc is the
renegotiation of the protagonist's relationship to adult /
institutional / parental authority — the move from accepting
authority's framework to questioning it to (sometimes)
choosing one's own. The arc should be visible across the
manuscript and progressing in plausible stages.

Verify authority figures are portrayed as complex humans,
not as obstacles or symbols. The form's failure mode is the
cardboard authority figure — the parent who exists only to
disapprove, the teacher who exists only to misunderstand,
the institution that exists only to constrain. The strongest
coming-of-age writes authority figures with their own
interior lives: the parent who is wrong about the
protagonist for specific reasons rooted in the parent's own
history; the teacher whose authority comes from genuine
knowledge but whose application of it is imperfect; the
institution whose rules are not stupid but whose
application to this specific child is mismatched.

Verify the protagonist is beginning to think for themselves
in observable ways. The shift from "what authority figures
say" to "what I think" must be on the page. The
protagonist who arrives at chapter twenty still operating
within authority's framework has not progressed; the
protagonist who has begun to make choices that diverge from
authority's expectations — even small choices, even before
they fully understand why — has begun the form's central
movement.

### Pass 4: Voice Evolution Check

Read three chapters spaced across the manuscript (early,
middle, late) and ask whether the narrative voice reflects
the protagonist's current maturity level at each point.
Coming-of-age's voice should not be static; the voice in
chapter three should not be identical to the voice in
chapter twenty-five. Subtle shifts in vocabulary, sentence
structure, observational range, emotional vocabulary, and
self-awareness register the protagonist's interior change.

Verify the voice is more nuanced in later chapters than in
earlier ones. The protagonist who was straightforwardly
emotional in chapter five may be ironically self-aware in
chapter twenty; the protagonist who saw their parents in
black-and-white in chapter three may see them in
complications by chapter eighteen. The shift should be
gradual and in keeping with what occurred between the
chapters.

Verify the protagonist now notices things they missed
earlier. Coming-of-age's deepest interiority shift is the
expanding observational range — the protagonist who
couldn't see what was happening in their parents' marriage
now can; the protagonist who didn't notice the friend's
quiet now does; the protagonist who took their privilege /
disadvantage / community position for granted now sees its
specific shape. Test: in late-manuscript chapters, identify
three observations the protagonist now makes that early-
manuscript-protagonist would have missed. If observations
match across chapters, voice has not evolved.

### Pass 5: Emotional Honesty Check

Verify emotions are age-appropriate AND specific. The
form's voice authenticity discipline operates at the
emotional level: the teen / child protagonist must feel
emotions that are recognisable to actual teens / children,
not generic literary-fiction emotional vocabulary. At the
same time, the emotions must be specific — not "she was
sad" but the particular shade of sadness this protagonist
of this age in this context would feel.

Verify growing up is shown as both exciting AND painful.
The form refuses single-register treatment of growth; the
protagonist who experiences only growing pains has been
served the loss column without the gains that motivate
continued growing; the protagonist who experiences only
exciting becoming has been spared the genuine difficulty
the form is committed to honouring. Verify the bittersweet
quality is present — gain and loss simultaneously, not in
alternation. The strongest coming-of-age makes the
simultaneous-presence of gain and loss the form's signature
emotional pleasure.

Test: pick three emotionally significant moments in the
manuscript and identify, in each, both the specific gain
and the specific loss. If only one column populates per
moment, the emotional honesty is operating in single-
register mode. If both populate consistently, the form's
deepest emotional register is operating.

### Pass 6: Dual-Readership Integrity (where applicable)

If the manuscript is YA or middle grade, run a final pass
on the dual-readership integrity. The primary reader is the
teen / younger reader; the secondary reader is the adult
(parent / teacher / librarian / gift-giver / adult-reading-
back). The form's strongest practitioners do specific work
for each without compromising either: the teen reader finds
recognition and permission; the adult reader finds the
specific texture of a developmental moment they remember.

Audit the manuscript for moments that wink at the adult
reader over the teen reader's head — the cultural
reference the teen wouldn't have; the joke that requires
adult context; the irony that depends on the reader knowing
what the protagonist does not. These moments break trust
with the primary audience. The strongest coming-of-age
makes the prose work for the teen reader on its own terms
while accidentally also working for the adult reader
through the same specific renderings.

Verify the manuscript trusts its primary audience. The teen
reader is sophisticated; coming-of-age that simplifies for
the assumed audience underestimates them. The strongest
contemporary YA (Sally Rooney's *Conversations with
Friends* read by teens; Akwaeke Emezi's *Pet*; Elizabeth
Acevedo's *The Poet X*; Angie Thomas's *The Hate U Give*)
operates at full literary register without softening for
the assumed audience. Test: pick three significant
emotional or thematic moments and ask whether they trust
the teen reader to do the work, or whether they over-
explain. Over-explanation is the failure mode.

For adult-literary coming-of-age (where the audience is
adult reflecting on younger self), the dual-readership
question shifts: the form must hold both the younger self's
authentic experience and the adult narrator's perspective
without one overwriting the other. The strongest examples
(Vuong's *On Earth We're Briefly Gorgeous*, Westover's
*Educated*, Brit Bennett's work) alternate between the two
registers deliberately, with the alternation itself part
of the form's emotional architecture.

## Names & Patterns to Avoid

### Coming of Age Character Names. NEVER USE
- Names that signal "youth" or "innocence": Angel, Daisy, Bud, Skip
- Literary coming-of-age names already taken: Holden, Scout, Pip
- Names chosen for symbolic weight: Phoenix, Hope, Journey

### Coming of Age. NEVER DO
- Begin with "It was the summer that changed everything" (the #1 coming-of-age cliché)
- Have the protagonist address the reader directly with "I didn't know then what I know now" (lazy retrospection)
- Kill a pet to trigger maturity (manipulative and overused)
- End with the protagonist "finally growing up" after one defining moment (growth is gradual)

### Use Instead
- Names that feel chosen by PARENTS, not authors: what would someone born in that year and culture actually be named?
- The name should become associated with the character, not arrive pre-loaded

## Comp Titles

Coming-of-age's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Catcher in the Rye* — J.D. Salinger (1951): the modern coming-of-age archetype.
- *To Kill a Mockingbird* — Harper Lee (1960): coming-of-age with social-justice frame.
- *A Tree Grows in Brooklyn* — Betty Smith (1943): immigrant coming-of-age benchmark.
- *The Bell Jar* — Sylvia Plath (1963): female coming-of-age literary benchmark.

### Contemporary (current best-in-class)

- *Normal People* — Sally Rooney (2018): millennial coming-of-age literary benchmark.
- *On Earth We're Briefly Gorgeous* — Ocean Vuong (2019): Vietnamese-diaspora coming-of-age.
- *We the Animals* — Justin Torres (2011): contemporary literary coming-of-age novella.
- *I Know Why the Caged Bird Sings* — Maya Angelou (1969): Black-feminist coming-of-age memoir-novel.
- *The Bluest Eye* — Toni Morrison (1970): Black-girl coming-of-age literary benchmark.
- *The Underground Railroad* — Colson Whitehead (2016, coming-of-age-leaning): Black-Southern coming-of-age literary fiction.
- *Demon Copperhead* — Barbara Kingsolver (2022): Appalachian coming-of-age contemporary.
- *Open Throat* — Henry Hoke (2023): coming-of-age novella with mountain-lion narrator.

## Cover Design Specifications

### Recommended Visual Styles
- **Photographic**. Evocative, slightly nostalgic photography: summer light, a figure in a landscape, the quality of a remembered afternoon
- **Illustrated**. Contemporary illustration with a dreamlike or memory-like quality; watercolour washes, soft edges, the feeling of a moment held
- **Graphic**. Clean, bold design with one striking image or colour: the simplicity signals the intensity of a single transformative experience
- **Typographic**. The title as the primary element with a single evocative image; signal literary quality with warmth

### Genre Cover Aesthetics
- **Styles:** Landscapes of youth (backyards, swimming holes, school corridors, bedroom windows), figures on the threshold (doorways, bridges, cliff edges), seasonal imagery (endless summer, autumn change), the golden-hour quality of memory, silhouettes of young figures against vast skies
- **Colours:** Warm, nostalgic palettes: golden amber, sun-faded blue, sunset orange, grass green; the colour palette of memory (slightly desaturated, warm-shifted); cool blues and greys for loss-driven stories; the specific light of a remembered season
- **Elements:** Open spaces (fields, water, sky), the suggestion of movement or departure, natural elements (trees, water, sunlight), objects of significance (a bicycle, a book, a letter), the threshold (a door, a road, a shoreline)
- **Typography:** Warm, approachable fonts; hand-lettered elements for intimacy; the title should feel personal, not institutional; slightly informal styling that suggests the character's voice

### Market Positioning
Coming-of-age covers signal "the story of becoming" through warmth, nostalgia, and the quality of light in a remembered moment. Position against Tartt, Eugenides, Sittenfeld, Aciman, Woodson. The cover should evoke a FEELING. the specific, bittersweet quality of looking back at a transformative time. At thumbnail size, warm light and open composition create immediate emotional recognition.

### Cover Design DON'Ts
- No childish or juvenile design elements (the protagonist is growing UP, not staying young)
- No dark, grim aesthetics (even loss-driven coming-of-age has warmth)
- No generic "teen on a beach" stock imagery
- No overly literal depictions of plot events
- No neon or hyper-modern design (the nostalgic quality is important)
- No designs that look like YA when the content is adult coming-of-age
