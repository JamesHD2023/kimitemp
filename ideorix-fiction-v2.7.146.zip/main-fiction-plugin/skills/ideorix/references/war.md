---
name: war-fiction-genre
description: Genre-specific instructions for war fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [historical]
---

# War Fiction. Genre Plugin

## Metadata
- id: war
- name: War Fiction
- icon: 🎖️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Five-Act Structure", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Front-Line Combat**. The experience of combat: soldiers in the field, the chaos, camaraderie, and horror of active warfare
- **Home Front**. War experienced by those who stay: families, communities, factories, hospitals; the war's impact on civilian life
- **POW/Captivity**. Imprisonment and survival: the psychology of captivity, resistance, and endurance
- **Espionage/Intelligence**. The war behind the war: codebreakers, spies, resistance networks; brains fighting where bodies can't
- **Anti-War**. War as tragedy: the futility, waste, and human cost; the genre that argues against its own subject
- **Historical War**. A specific conflict rendered with accuracy: WWI, WWII, Vietnam, Civil War, etc.; the particular horror of a particular war

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Alternates between the unbearable tension of waiting and the chaos of combat; the rhythm of war is boredom punctuated by terror
- Must open with: A specific sensory moment. not a history lesson, but a person experiencing war through their body: the sound, the smell, the cold, the fear

BEATS PER CHAPTER
1. Survival Beat. The physical reality of war: cold, hunger, exhaustion, injury, the constant work of staying alive
2. Comrade Beat. The relationships that form under fire: loyalty, dependence, friction, humour, and the unbearable weight of loss
3. Combat/Danger Beat. The threat: active fighting, bombardment, patrol, ambush; or the anticipation of it
4. Moral Beat. The war asks a moral question: killing, obedience, loyalty, sacrifice, the line between duty and atrocity
5. Humanity Beat. The human being beneath the soldier: memory, longing, tenderness, the small moments that keep a person sane

WAR FICTION ARCHITECTURE
- WAR is not adventure: it is chaos, waste, fear, and boredom; the genre takes this SERIOUSLY
- The BODY is central: war fiction is experienced through the physical. cold, hunger, pain, exhaustion, the adrenaline of combat
- COMRADESHIP is the emotional core: the bonds between soldiers (or civilians under fire) are the strongest in any genre
- MORAL COMPLEXITY: there are no clean hands in war; the protagonist will be asked to do terrible things
- The ENEMY is human: dehumanisation of the opposing side is a failure of the fiction
- SPECIFICITY of conflict: each war is different; the details of THIS war matter (weapons, terrain, tactics, culture)
- AFTERMATH matters: what war does to people AFTER the fighting is as important as the combat itself
- POV: First person past (the survivor's account) or tight third past (allows scope while maintaining intimacy)

THE EXPERIENCE OF COMBAT
- CHAOS: combat is NOT choreographed; it's confused, terrifying, and largely incomprehensible to those in it
- NOISE: the defining sense of combat is sound. explosions, gunfire, screaming, the silence after
- FEAR: the physical experience of fear in combat: shaking, vomiting, paralysis, loss of bladder control (real and documented)
- TIME DISTORTION: combat compresses and stretches time; a minute can last an hour; an hour can disappear
- PARTIAL VISION: the soldier sees their immediate surroundings; they DON'T have an overview

FORBIDDEN IN WAR FICTION
- Glorifying combat (war fiction that makes fighting look exciting is irresponsible)
- Bloodless violence (people who get shot, bombed, or bayoneted don't quietly fall down)
- The enemy as faceless evil (they're soldiers too, with families and fears)
- Hollywood heroism (one person does not win a battle)
- Ignoring the bodily realities (soldiers are hungry, cold, filthy, and terrified)
- Strategic overview from a ground-level character (soldiers don't understand the bigger picture)
- Clean moral positions (war is morally devastating to everyone involved)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (combat intensity), Captivation (theatre & comradeship), Affection (companion bonds), Validation at sacrifices honored.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person past (the classic: the survivor looking back) or tight third
- Voice: Raw, specific, sometimes detached. the voice of someone who has seen too much
- Tone: Honest to the point of brutality; moments of beauty and tenderness make the horror worse
- Register: The language of the common soldier, not the general; direct, often profane, emotionally compressed

PROSE IMPERATIVES
- THE BODY AT WAR: every chapter should ground the reader in physical experience
  - Cold: not "it was cold" but the specific cold. fingers that won't close, water in the boots that never dries
  - Hunger: what they eat (or don't), how food tastes when you haven't eaten in two days
  - Fatigue: the kind of tired that makes you sleep standing up, that makes you hallucinate
  - Pain: specific, located, functional ("the shrapnel in his thigh made walking a negotiation")
- COMBAT PROSE: the writing style changes in combat
  - Short, fragmented sentences: the mind under fire processes in bursts
  - Sensory overload: too much happening at once; the prose reflects the chaos
  - Temporal distortion: slow-motion during danger, time-skip during shock
  - After combat: numb, factual prose; the flatness of shock
- CAMARADERIE PROSE: the warmth between soldiers
  - Dark humour: the jokes that would horrify civilians but keep soldiers sane
  - Physical closeness: sharing warmth, sharing food, the comfort of another body nearby
  - Shorthand: the language of shared experience that outsiders can't decode
  - The eulogy: how soldiers remember their dead (not with speeches but with stories)
- RESTRAINT: the most powerful war writing often UNDERSTATES
  - "He didn't come back" can be more devastating than a graphic death scene
  - The flat recitation of facts can carry more horror than emotional language
  - Silence after violence is more powerful than description during it

DIALOGUE CRAFT
- Soldiers' dialogue: profane, direct, darkly humorous, coded
- Rank affects speech: officers vs. enlisted, the language of command vs. the language of compliance
- Under fire: fragmented, shouted, functional ("Move!" "Down!" "Medic!")
- Quiet moments: surprisingly tender, often about home, food, or the future
- What soldiers DON'T talk about: certain experiences are processed in silence
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. WAR FICTION

OPENING: Stakes + humanity under pressure. A specific sensory moment. not a history
lesson, but a body experiencing war. Establish BOTH the threat and the human being
beneath the uniform.

DUAL RHYTHM. both present in chapter 1:
- COMBAT: short, fragmented, visceral. 4-12 words. Fragments: "Dirt. Noise. Then
  nothing." Sensory overload through compression. Temporal distortion.
- HUMAN COST: longer, weighted. 18-30 words. The quiet moments given room. The
  flatness of shock in simple declarative prose. Letters, memories, shared cigarettes.

VOCABULARY: Soldier's language. direct, profane, emotionally compressed. Physical
specificity: "shrapnel in his thigh, three inches above the knee." Restraint is
power: "He didn't come back" > graphic description. Sound dominates the sensory
palette. Period-accurate military terminology.

TENSION FLOOR: ≥7. Death or maiming present or imminent. Tension in BOTH modes:
combat (will they survive?) and human (what is this costing?). Comradeship creates
stakes. fear for specific people. The moral dimension: what will they be asked to do?

RHYTHM: Open with one body in one sensory moment of war. Establish the unit through
small bonding details. Layer in the threat. Combat (if present) is SHORT and chaotic.
After-combat: flat prose of shock. Close with the human moment. a letter, a joke,
a silence carrying everything unsaid.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

WAR CRAFT (40% of total):
- Combat is chaotic, terrifying, and partial (not choreographed)? (0-100)
- The body at war is rendered with physical specificity? (0-100)
- Comradeship is felt (the emotional heart of the story)? (0-100)
- Moral complexity is present (no clean hands, no simple answers)? (0-100)

STORY CRAFT (30% of total):
- The specific conflict is rendered accurately? (0-100)
- The protagonist is changed by their experience? (0-100)
- The enemy is humanised? (0-100)
- The aftermath (physical and psychological) is addressed? (0-100)

PROSE QUALITY (30% of total):
- Prose shifts appropriately between combat and non-combat? (0-100)
- Physical detail is specific and accurate? (0-100)
- Restraint is used effectively (understatement as power)? (0-100)
- Dark humour and camaraderie feel authentic? (0-100)

AUTOMATIC FAILS (score = 0):
- Combat glorified or romanticised
- Bloodless violence
- The enemy as faceless evil
- One-person-wins-the-battle heroism
- Ignoring bodily reality (hunger, cold, fear, filth)
- Clean moral positions in a morally devastating context
```

## Continuity Rules

```
WAR FICTION CONTINUITY. WHAT TO TRACK

UNIT STATE:
- Who's alive, injured, dead, missing at each chapter
- Rank and role of each named character
- Morale: the unit's psychological state
- Equipment: what they have, what's been lost or destroyed
- Ammunition and supplies: finite and tracked

PHYSICAL STATE:
- Every character's injuries, accumulated fatigue, and health
- Days since last rest, food, medical attention
- Environmental exposure: cold, heat, wet, mud
- Psychological state: shell-shock, numbness, hypervigilance, breakdown

TACTICAL STATE:
- Position: where the unit is relative to the front, the enemy, and support
- Orders: what they've been told to do and how it conflicts with reality
- Enemy position and activity
- Terrain: the physical ground they're on and how it affects everything

HISTORICAL STATE:
- Date and location: accurate to the specific conflict
- What's happening in the wider war at this point
- Technology available: weapons, communications, transport, medical
- Weather and season: affects everything in war

EMOTIONAL STATE:
- Bonds: who is close to whom, who's withdrawing, who's breaking
- Grief: losses that haven't been processed (they accumulate)
- Letters and connections to home: who they're writing to, what they're saying (and not saying)
- The moral ledger: what the protagonist has done and how they feel about it
```

## Character Rules

```
WAR CHARACTER TYPES

THE PROTAGONIST (THE SOLDIER):
- An ordinary person in extraordinary circumstances. not a born warrior
- Their pre-war life MATTERS: it's what they're fighting to return to
- They're afraid: courage in war fiction is not the absence of fear but action despite it
- They grow hard: the softness of civilian life is stripped away; what remains is the question
- Their moral sense is tested: what they'll do under orders, under fire, under pressure
- They may not survive. and if they do, they're not the same person

THE COMRADE:
- The closest bond in any fiction genre: forged in shared danger
- Each comrade represents something: home, humour, competence, hope, conscience
- Their loss is the novel's most powerful weapon
- Characterised through small details: a habit, a phrase, a photograph they carry

THE OFFICER:
- The weight of command: their decisions get people killed
- The distance of rank: they must send men they care about into danger
- Their competence matters: a good officer saves lives; a bad one wastes them
- They may be heroic, incompetent, corrupt, or all three at different moments

THE ENEMY SOLDIER:
- Human: afraid, cold, hungry, missing home. just like the protagonist
- At least one scene should show the enemy as human (a captured soldier, a body with a photograph, a sound from the other trench)
- The moment of recognition. "that could be me". is essential to honest war fiction

THE CIVILIAN:
- Caught in the war: displaced, bombed, occupied, starving
- Their presence reminds the reader what war does to the world beyond the battlefield
- They may be allies, victims, or threats. the categories blur in war

VOICE DIFFERENTIATION:
- Officers: more formal, trained vocabulary, the burden of command in their speech
- Enlisted: colloquial, profane, direct, darkly funny
- Different ranks and roles: the medic talks about bodies differently from the rifleman
- Home voices (in letters/memory): softer, from a world the protagonist can barely remember
```

## Arc Rules

```
WAR FICTION STORY STRUCTURE

ACT 1: THE BEFORE (first 25%)
- The protagonist before combat: who they were, what they valued, what they believed
- The journey to war: training, transport, the first sight of the front
- The reality hits: this is not what they expected; the gap between ideology and experience
- First exposure to danger: not the big battle but the first taste. a bombardment, a patrol, a casualty
- END OF ACT 1: The protagonist is IN the war, and there's no going back

ACT 2A: THE EDUCATION (to midpoint)
- Learning to survive: the skills, the instincts, the numbness that keeps you functional
- Bonds form: the comrades who become family
- Combat experiences: escalating in intensity and moral complexity
- The protagonist changes: becoming harder, more capable, less recognisable
- MIDPOINT: A major battle or event that changes everything. significant losses, moral transgression, or the war's true nature revealed

ACT 2B: THE COST (midpoint to dark moment)
- The losses mount: friends die, the unit is degraded
- Moral injury: the protagonist does something (or witnesses something) that they can't reconcile
- The body fails: exhaustion, injury, illness. the physical toll
- The purpose is questioned: what are we fighting for? Is it worth this?
- DARK MOMENT: The worst moment. the battle that shouldn't have been fought, the death that didn't need to happen, the order that was wrong

ACT 3: THE AFTERMATH (final 25%)
- Survival or sacrifice: the protagonist's fate
- The reckoning: what the war has made them
- The return (if they survive): coming home to a world that can't understand
- The cost: what was lost. people, innocence, belief, the person they used to be
- The ending: honest, often unresolved. war doesn't end when the shooting stops

WAR FICTION PACING:
- WAITING then VIOLENCE: the rhythm of war is long stretches of tension and boredom punctuated by explosive action
- Combat scenes are SHORT and CHAOTIC (not extended set pieces)
- The quiet scenes between combat carry the emotional weight
- The pace accelerates toward the climactic battle, then SLOWS for the aftermath
```

## Timeline Rules

```
WAR FICTION TIMELINE

MILITARY TIMELINE:
- Track dates against the real conflict's timeline
- Orders, movements, and engagements should be historically plausible
- The pace of military operations: hurry-up-and-wait is real

PHYSICAL TIMELINE:
- Days without sleep, food, or shelter
- Injury recovery (limited by period-appropriate medical care)
- Seasonal effects: winter, mud season, summer heat

EMOTIONAL TIMELINE:
- Numbness develops over time (not instantly)
- Grief accumulates: each loss weighs more than the last
- The arc from fear to competence to exhaustion to numbness
```

## Genre-Specific Craft Techniques

War fiction is a genre with an unusually demanding ethical
contract: it must render war honestly without becoming
pornography of suffering, must honour the specific
historical or contemporary conflict it depicts without
collapsing into propaganda, and must hold humanity visible
amid the dehumanising machinery of organised violence. The
canonical roster — Erich Maria Remarque (All Quiet on the
Western Front), Joseph Heller (Catch-22), Tim O'Brien (The
Things They Carried, Going After Cacciato), Kurt Vonnegut
(Slaughterhouse-Five), Sebastian Faulks (Birdsong),
Pat Barker (the Regeneration trilogy, the Trojan books),
Karl Marlantes (Matterhorn, Deep River), Anthony Marra (A
Constellation of Vital Phenomena), Phil Klay (Redeployment,
Missionaries), Kevin Powers (The Yellow Birds), Hilary
Mantel — established the form across multiple eras and
fronts; the contemporary masterclass roster — Helon Habila
(Oil on Water), Yiyun Li (The Vagrants), Aminatta Forna
(The Memory of Love), Khaled Hosseini (The Kite Runner, A
Thousand Splendid Suns), Viet Thanh Nguyen (The Sympathizer),
Tochi Onyebuchi (War Girls), Omar El Akkad (American War,
What Strange Paradise), David Diop (At Night All Blood Is
Black), Adam Johnson (The Orphan Master's Son) — has
expanded the genre's range beyond Western-centric framings
to include African, Asian, post-colonial, child-soldier,
and refugee perspectives that the canonical roster
historically underweighted. The most common failure modes
in this register are: **Combat-as-Choreography** (war
violence rendered as elegant, balletic, tactically clear
when the genre's truth is that combat is chaotic, partial,
panicked, and morally complex); **Hero-Without-Cost** (the
protagonist who passes through war unmarked; the genre's
contract is that war marks everyone who survives);
**Enemy-Dehumanisation** (the opposing force rendered as
faceless, undifferentiated, monstrous when the genre's
ethical work is to render the enemy as also human);
**Glorification-Drift** (the manuscript that begins as
critique and drifts toward celebration of the violence
or the apparatus); **Trauma-Pornography** (suffering
rendered for shock without thematic purpose; the gaze on
violence that exceeds what the story requires);
**Propaganda-Capture** (the manuscript that serves a
specific national, ideological, or partisan position
rather than rendering war's complexity); **Sentimental-
Ending Reconciliation** (the war that ends with neat
moral resolution; the reconciliation between former
enemies that erases what was done); **Civilian-Erasure**
(war fiction that focuses entirely on combatants while
the civilian experience — the larger fact of any war —
goes unrendered); **Period-Anachronism** (the modern
moral framework imposed on historical combatants whose
moral universe operated under different conditions); and
**The Officer-Class Default** (war fiction that defaults
to the educated officer's perspective when the genre's
ethical work often demands the perspective of the
conscript, the civilian, the displaced, the colonised).
The techniques below — three preserved (Flatline
Technique, Small Detail, Before-and-After) and three
added (Bureaucratic Specificity, Civilian Layer
Discipline, Moral-Witness Architecture) — are designed
to keep the genre's defining commitments live: honest
violence without choreography, marked survivors,
humanised enemies, and civilian experience as
foundation rather than backdrop.

### The Flatline Technique

The most devastating war writing uses emotional flatness:

```
EMOTIONAL (less effective):
"When they told him Thompson was dead, he felt his
heart break. Tears streamed down his face as he
remembered all the good times they'd shared."

FLATLINE (devastating):
"Thompson was dead. He'd been dead since the
morning. Someone had covered him with a blanket.
Collins took Thompson's boots because they were
better than his own and Thompson didn't need them
anymore. They were a good fit."

The flatness IS the grief. The pragmatism IS the horror.
```

### The Small Detail

War's magnitude is captured through the specific, not the general:

```
NOT WAR FICTION:
"The battle was devastating. Many soldiers died
and the landscape was destroyed."

WAR FICTION:
"He found a photograph in the mud. A woman and
two children. The back said 'Always, Marie.'
He put it in his pocket because someone should
carry it home, and then the shelling started again."
```

### The Before-and-After

Show who the protagonist was before to make the cost visible:

```
BEFORE (Chapter 1):
"He was the kind of person who apologised to chairs
when he bumped into them."

AFTER (Chapter 20):
"He stepped over the body without looking down.
He was thinking about coffee."
```

### War Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the horrors of war" | Show ONE specific horror through one person's eyes |
| "brothers in arms" | Show the specific bond through one shared action |
| "the fog of war descended" | Show the specific confusion from one position |
| "sacrifice and honour" | Show the specific sacrifice |
| "the enemy was everywhere" | Show the specific encounter |
| "war changes a man" | Show the specific change through specific behaviour |
| "the sound of gunfire was constant" | Show the specific soundscape from the specific position |
| "waiting was the hardest part" | Show the specific waiting activity and specific fear |
| "the letter from home" | Show the specific contents |
| "no man's land" | Show the specific terrain |
| "the cost of victory" | Show the specific cost paid by specific people |
| "in the trenches" | Show the specific trench section, mud level, named neighbouring soldiers |
| "the sound of war" | Show one specific sound (the specific calibre, the specific distance, the specific echo) |
| "a soldier's duty" | Cut "duty"; show the specific order, the specific compliance, the specific cost |
| "the home front" | Show the specific home-front detail (named ration, named factory shift, named missing letter) |
| "courage under fire" | Show the specific moment of fear and the specific decision to act anyway |
| "the chaos of battle" | Show the specific chaos through one soldier's specific moment-by-moment confusion |
| "the price of freedom" | Cut slogan; show the specific price paid by specific named people |

### The Bureaucratic Specificity

War is run by paperwork, supply chains, requisitions,
orders, ranks, and procedures. The Bureaucratic
Specificity discipline is the requirement that this
texture — what makes war a vast organised undertaking
rather than just chaos — be rendered with specific
detail. The genre's authenticity often turns on
specific period bureaucratic detail (rank insignia,
form numbers, named units, supply procedures, letter
formats) that the writer has researched and rendered.

```
PRINCIPLE
The manuscript must render war's bureaucratic texture
through at least three of the following four axes:
1. UNIT / RANK SPECIFICITY — named units (the 442nd
   RCT, the Bismarck's gunnery crew, the 101st
   Airborne's Easy Company, the 2nd Bn Cheshire
   Regiment), named ranks with period-correct
   insignia, named officers and NCOs in the chain
   of command
2. SUPPLY / LOGISTICS — what arrives, what doesn't,
   what is rationed, what is bartered; the specific
   kit, the specific ration, the specific ammunition
   load; the specific complaint about what is
   missing
3. PAPERWORK / PROCEDURE — the specific order
   received, the specific form filled in, the
   specific report submitted; the bureaucratic
   evidence of decisions that send people to die
4. INSTITUTIONAL CULTURE — the specific way this
   army / navy / air force / militia / militia-
   adjacent force handles its people; the unwritten
   rules; the inherited traditions; the specific
   resentments between branches or units

CALIBRATION TEST
- Are unit names specific and period-correct?
- Are ranks correct for the period and country?
- Is supply / logistics rendered with specific detail
  rather than referenced abstractly?
- Does the institutional culture register feel
  researched (the specific army's specific texture)
  rather than generic-military?
If any answer is no — rebuild for bureaucratic
specificity.

ANTI-PATTERN
- "His unit," "his commanding officer," "the army"
  — abstract category-words instead of named
  specifics
- Generic ranks ("captain," "sergeant") without
  period-correct deployment in chain of command
- Supply / logistics treated as backdrop rather than
  as material force
- Institutional culture imported from one army to
  another without adjustment
```

### The Civilian Layer Discipline

The Civilian-Erasure failure mode produces war fiction
that registers the combatant experience while the
larger civilian experience — the displaced, the
occupied, the bereaved, the besieged, the home-front-
working, the refugee — goes unrendered. The Civilian
Layer Discipline is the requirement that civilian
experience be rendered as substantial layer of the
manuscript, not as backdrop or briefly-glimpsed
suffering.

```
PRINCIPLE
The manuscript must render civilian experience through
at least three of the following four layers:
1. THE OCCUPIED — civilian life under enemy or
   friendly-but-foreign occupation; the daily
   accommodation, the resistance choices, the
   collaboration question, the specific texture of
   foreign authority
2. THE DISPLACED — refugees, internally displaced
   persons, evacuees; the specific journey, the
   specific loss, the specific arrival in a place
   that may or may not welcome
3. THE HOME FRONT — the civilian world that supplies
   the war; the rationing, the missing men, the
   factory work, the news from elsewhere, the
   waiting; the specific relationship between
   home-front life and the conflict
4. THE BESIEGED — civilians under direct attack
   (bombing campaigns, siege warfare, occupied
   cities); the specific shelter routine, the
   specific hunger, the specific child's experience

CALIBRATION TEST
- Could the manuscript be told without civilians and
  still feel complete? If yes, the Civilian Layer
  has been treated as backdrop and must be rebuilt.
- Are at least three of the four civilian layers
  rendered somewhere in the manuscript?
- Is civilian experience given the same craft attention
  as combatant experience — same specificity, same
  emotional depth, same character work?
- Where civilian voices appear, are they specific
  named characters with their own arcs, or
  undifferentiated suffering masses?
If any answer is no — rebuild for civilian-layer depth.

ANTI-PATTERN
- The war novel set entirely in trenches / on patrol
  / in headquarters with civilians appearing only as
  briefly-glimpsed suffering
- Civilians as undifferentiated mass rather than
  specific characters
- The single civilian character (often the love
  interest's family back home) standing in for the
  entire civilian experience
- Civilian suffering rendered for emotional
  manipulation rather than for honest depiction
```

### The Moral-Witness Architecture

War fiction's deepest craft work is the moral-witness
architecture: the manuscript holds the reader as
witness to what war does, refuses to look away, refuses
to provide easy resolution, and refuses to let the
reader's discomfort be discharged through identification
with simple moral positions. The Moral-Witness
Architecture is the structural commitment to this
witnessing function.

```
PRINCIPLE
The manuscript must satisfy at least four of the
following five moral-witness criteria:
1. NO CLEAN HEROES — the protagonist participates in
   the war's moral compromises; even the protagonist
   "fighting for the right side" carries cost
2. NO CLEAN VILLAINS — the enemy is humanised; the
   reader sees enemy soldiers as also marked, also
   afraid, also conscripts of their own institutions
3. NO RECONCILIATION SHORT-CUT — the manuscript
   refuses the sentimental-ending where former
   enemies meet over coffee in retirement and
   forgive; the war's wounds persist
4. NO PROPAGANDA-CAPTURE — the manuscript does not
   serve a specific national, ideological, or
   partisan position; even when the war's larger
   moral framework is clear (Nazi defeat, anti-
   colonial liberation), the specific moral reality
   on the ground is rendered with complexity
5. NO COMFORT-RESOLUTION — the manuscript refuses to
   resolve in a way that lets the reader leave
   reassured; war's costs are visible at the end

CALIBRATION TEST
- Does the manuscript let the reader off the hook
  with clean moral positions? If yes — rebuild.
- Does the enemy register as also human?
- Are the protagonist's moral compromises specific
  and persistent rather than waved away?
- Does the ending refuse easy reconciliation?
If any answer is no — rebuild for moral-witness
integrity.

ANTI-PATTERN
- The war novel where one side is clearly good and
  one side is clearly evil
- The enemy as faceless mass
- The protagonist who emerges from war unmarked
- The "and they all became friends" coda
- The propaganda-capture that serves a specific
  national or ideological position
- The trauma-pornography that lingers on suffering
  beyond what the story requires
```

## Genre-Specific Revision Rules

### Six-Pass War Fiction Audit (Run FIRST in editorial pipeline)

The War Fiction Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Physical Reality Pass

Verify the body at war is present in every chapter. War
is a bodily phenomenon — cold, hunger, fatigue, fear,
injury, sleep deprivation, smell, sound, touch, taste.
Audit each chapter: are environmental conditions
affecting the characters? Are injuries persistent and
cumulative rather than reset? Is the body's specific
experience of this specific moment rendered through
sensory detail? The war novel that floats above the
body has lost the genre's foundational truth and must be
rebuilt for embodied specificity.

#### Pass 2: Combat Authenticity Pass

Verify combat is rendered as chaotic, partial, panicked
rather than choreographed. The Combat-as-Choreography
failure mode is the genre's most common lapse — the
elegant action sequence that erases the reality of
actual combat. Audit each combat scene: does the
protagonist have limited information during fighting?
Is the chaos rendered through their specific moment-
by-moment confusion? Are consequences of violence shown
honestly — the wounds, the deaths, the immediate
aftermath, the smell, the sound? Is the combat
character-specific (this fighter, with this training,
in this terrain, against this enemy) rather than
generic-action-sequence?

#### Pass 3: Humanity Pass

Verify the manuscript holds humanity visible amid the
dehumanising machinery of organised violence. The
Enemy-Dehumanisation failure mode is caught here. is the
enemy humanised somewhere in the manuscript — through
captured soldiers, civilian encounters, dead bodies that
register as people, recovered letters or photographs,
or direct narration from the other side? Is camaraderie
present and felt — specific bonds between specific
soldiers rather than generic-military-brotherhood? Are
there moments of tenderness, humour, or care amid the
horror? The Civilian-Erasure failure mode is also
caught here — civilians must register as full humans
with their own arcs, not as undifferentiated suffering
mass.

#### Pass 4: Moral Complexity Pass

Verify the protagonist faces genuinely difficult moral
questions. The Hero-Without-Cost and Glorification-
Drift failure modes are caught here. is the protagonist
making compromised choices — the order followed that
shouldn't have been, the civilian harmed in cross-fire,
the prisoner mistreated, the looted item kept, the lie
told to a comrade? Are there no clean moral positions
in the manuscript? Is the war's waste and futility
visible even when the larger cause is just? The
Propaganda-Capture failure mode is caught here too —
the manuscript that serves a specific national,
ideological, or partisan position rather than rendering
war's complexity must be rebuilt for moral integrity.

#### Pass 5: Restraint Pass

Verify understatement is used for the most powerful
moments. The Trauma-Pornography failure mode is the
genre's signature risk — suffering rendered for shock
without thematic purpose, the gaze on violence that
exceeds what the story requires. Audit each devastating
beat: is it rendered with the Flatline Technique
(emotional flatness as carrier of grief), or is the
prose telling the reader what to feel? Are the most
devastating moments more effective for their restraint
than they would be for melodrama? Does the writing
trust the reader to feel without being told what to
feel? The genre's craft is in the gap between what is
said and what the reader experiences; restraint is the
load-bearing technique.

#### Pass 6: Bureaucratic-Specificity + Civilian-Layer + Moral-Witness Integration

This pass is the war fiction integration check — it
ties the new techniques together and verifies the
manuscript honours the genre's defining commitments at
the manuscript level.

For BUREAUCRATIC-SPECIFICITY: confirm units, ranks,
supply / logistics, and institutional culture are
rendered with specific detail. The manuscript should
feel researched at the institutional level, not just
at the combat level.

For CIVILIAN-LAYER: confirm civilian experience is
rendered as substantial layer rather than as backdrop.
At least three of the four civilian layers (occupied /
displaced / home-front / besieged) should appear
somewhere in the manuscript with the same craft
attention given to combatants.

For MORAL-WITNESS: confirm the manuscript refuses
clean heroes, clean villains, reconciliation short-
cuts, propaganda capture, and comfort resolution. The
manuscript should hold the reader as witness to what
war does, with the war's costs visible at the end. The
ending that resolves war's wounds neatly has betrayed
the genre's contract; the ending that refuses easy
resolution honours it.

## Names & Patterns to Avoid

### War Fiction Character Names. NEVER USE
- Generic soldier names: Private Smith, Sarge, Ace
- Names from famous war films: Ryan, Joker, Kilgore
- Names chosen for symbolic weight: Victor, Armstrong

### War Fiction. NEVER DO
- Glorify combat or make killing look thrilling
- Give the protagonist knowledge of the bigger strategic picture
- Write extended action set-pieces like a movie (combat is short and chaotic)
- Ignore the enemy's humanity
- Skip the aftermath (what war does to people matters more than what happens in battle)

### Use Instead
- Period and culturally appropriate names from military records
- Surnames used professionally (as soldiers actually do)
- Nicknames that feel earned through shared experience

## Comp Titles

War fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *All Quiet on the Western Front* — Erich Maria Remarque (1929): the foundational anti-war novel.
- *Catch-22* — Joseph Heller (1961): satirical war-novel benchmark.
- *Slaughterhouse-Five* — Kurt Vonnegut (1969): meta-war-fiction.
- *The Things They Carried* — Tim O'Brien (1990): Vietnam-war literary benchmark.
- *Birdsong* — Sebastian Faulks (1993): WWI literary war-fiction.
- *Regeneration* — Pat Barker (1991): WWI psychological war-novel benchmark.

### Contemporary (current best-in-class)

- *The Yellow Birds* — Kevin Powers (2012): contemporary Iraq-war literary fiction.
- *Redeployment* — Phil Klay (2014): Iraq-war stories; National Book Award.
- *Matterhorn* — Karl Marlantes (2010): Vietnam-war literary doorstop.
- *The Sympathizer* — Viet Thanh Nguyen (2015): Vietnamese-American war-novel; Pulitzer.
- *At Night All Blood Is Black* — David Diop (2018, English 2020): African colonial WWI war-novel.
- *The Kite Runner* — Khaled Hosseini (2003): Afghanistan-war literary fiction benchmark.
- *American War* — Omar El Akkad (2017): future-civil-war fiction.
- *War Girls* — Tochi Onyebuchi (2019): YA-war Afrofuturist novel.

## Cover Design Specifications

### Recommended Visual Styles
- **Documentary**. Photographic or photo-realistic: the rawness of actual war imagery translated into cover design; nothing glamorous, nothing clean
- **Atmospheric**. The landscape of war: trenches, beaches, fields, ruins under dramatic skies; the environment as monument to what happened
- **Minimalist**. A single object: dog tags, a helmet, a letter, a poppy; the synecdoche of the whole through one detail
- **Typographic**. Bold, stark typography against a muted or dark background; the title as memorial

### Genre Cover Aesthetics
- **Styles:** Landscapes of conflict (battlefields, bombed cities, trenches), lone figures in military gear, military equipment rendered with documentary realism, period photographs or photo-realistic art, empty landscapes that suggest aftermath
- **Colours:** Muted, desaturated: mud browns, khaki greens, steel greys, smoke blacks; the red of poppies or blood as single accent; nothing bright or saturated. war drains colour from the world
- **Elements:** Military equipment (helmets, rifles, boots), letters and photographs from home, landscapes scarred by conflict, crosses and memorials, the single light source (a match, a flare, dawn) in overwhelming darkness
- **Typography:** Strong, serious, sans-serif or slab-serif; the title as monument or inscription; nothing decorative; the typography should feel carved in stone or stamped in metal

### Market Positioning
War fiction covers must signal "honest, devastating, and important" through restrained, documentary-quality design. Position against Remarque, Heller, O'Brien, Powers, Vuong. The cover should command respect. At thumbnail size, a single muted-palette image with strong typography creates immediate recognition. War fiction covers should look like they belong in a serious section of a bookshop.

### Cover Design DON'Ts
- No action-movie aesthetics (explosions, heroic poses)
- No bright or saturated colours
- No romanticised or glamourised military imagery
- No generic stock military photography
- No triumphalist design (flags, eagles, victory imagery)
- No cartoonish or stylised military illustration
