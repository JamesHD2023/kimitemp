---
name: billionaire-romance-genre
description: Genre-specific instructions for Billionaire Romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [romance, contemporary]
---

# Billionaire Romance. Genre Plugin

## Metadata
- id: billionaire-romance
- name: Billionaire Romance
- icon: 💎
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Romancing the Beat", "Three-Act Structure", "Save the Cat", "Seven-Point Structure"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| CEO / Corporate Billionaire | Fortune-500-style corporate leader; board, shareholders, employees create real-world business pressure | Wealth source is institutional; trust issues come from people leveraging proximity to power; relationships are strategic by default |
| Tech Mogul / Startup Billionaire | Founded a tech company that scaled fast; younger; rule-breaking; visionary | Recent wealth means they remember not having it; engineer-mindset treats people as problems to solve; imposter syndrome alongside arrogance |
| Old Money / Dynasty Billionaire | Inherited wealth across generations; family obligations; insular social world | Wealth feels inevitable, not earned; family approves or disapproves; class signalling drives social tension |
| Self-Made / Scrappy Entrepreneur | Built empire from nothing; chip on shoulder; loyalty to people who knew them when | Hustle mindset doesn't switch off; commodifies relationships; carries scarcity habits even at billion-dollar scale |
| Secret Billionaire | Hides wealth deliberately; love interest doesn't know at first; reveal becomes turning point | The lie is the foundation problem; reveal must be earned, not retconned; trust must be rebuilt after disclosure |
| Criminal / Morally Gray Billionaire | Wealth from organised crime, gray-market dealings, or ethically compromised business | Power is danger, not just money; love interest must knowingly choose despite risk; redemption arc is hard-won |
| Paranormal Billionaire | Vampire / werewolf / fae / supernatural with billion-dollar wealth across centuries or worlds | Adds immortality to wealth-and-power gap; supernatural mate-bond reframes consent and vulnerability |

## Architect Instructions

```
You are structuring a BILLIONAIRE ROMANCE chapter. a subgenre defined by extreme wealth differentials, power-imbalance navigation, and the romantic collision of two incompatible worlds — where money creates demonstrable structural power and the love story is the negotiation of agency, vulnerability, and mutual choice across that gap.

BILLIONAIRE ROMANCE CHAPTER BEATS (incorporate 3-5 per chapter as appropriate):
- POWER-DYNAMIC TICK: Every chapter shifts the power balance somewhere. Track where the wealth gap currently sits — financial control, decision authority, social position, privacy ownership, information access — and move at least one axis. Do not let chapters pass without the dynamic registering forward motion.
- GOLDEN-CAGE MOMENT: At least one luxury setting in the chapter contains a beat of restriction, isolation, or surveillance alongside the wish-fulfilment. The penthouse view that imprisons. The private jet that strips anonymity. The gala dress that performs ownership. Wealth must be felt as both alluring and suffocating.
- AGENCY ASSERTION: The non-billionaire takes a choice or refusal that's their own — pursuing their career, declining money, going to their friend's birthday despite paparazzi, keeping their apartment, refusing the credit card. They have a life that exists outside the billionaire's world and they protect it.
- BILLIONAIRE-AS-PERSON GLIMPSE: A specific, humanising detail that shows the billionaire isn't a fantasy object. A nervous tell during a board call. A pedestrian food preference. A trust-wound that surfaces when wealth alone can't soothe it. Money makes their life specific, not generic.
- WORLDS-COLLIDING SCENE: A moment where the two worlds physically or socially collide — her bar where he's overdressed, his gala where she's underdressed, his family's dinner where her career is invisible, her friends' irreverence about his wealth. The collision creates the tension; neither world fully fits.

STRUCTURAL REQUIREMENTS:
- WEALTH SOURCE must be SPECIFIC. "CEO of a pharmaceutical company under board pressure on a regulatory deadline" — not "wealthy businessman". The reader must know what the billionaire's empire actually does, what's at stake in it right now, and what business problem money alone cannot solve.
- POWER IMBALANCE must be ACKNOWLEDGED on the page. Characters notice it. The narrative engages with it. By the resolution, the dynamic must shift toward balance in the relationship — not parity in wealth (unrealistic), but mutual vulnerability and chosen agency.
- THE NON-BILLIONAIRE MUST HAVE AGENCY. A career or passion independent of the billionaire. At least one major refusal of money / opportunity / control. Connections to their original world that they consciously preserve. They solve at least one problem themselves rather than accepting a money solution.
- HEA OR HFN IS MANDATORY. The ending earns the resolution; the wealth gap doesn't disappear, but the relationship arrives at mutual choice and mutual vulnerability rather than absorption of one partner into the other's world.
- CONTENT WARNINGS appropriate to the heat level. Billionaire romance skews steamy by reader expectation; the architect should note where explicit scenes land and how they advance emotional intimacy alongside physical.
- EMOTIONAL DEPTH must accompany every wealth display. If a scene only shows luxury without psychological cost or texture, it's flat. Every opulent setting carries its specific complication.

FORBIDDEN:
- Generic or vague wealth ("he was very rich", "the wealthy CEO") — wealth source must be specific and visible
- Cartoonish wealth — every problem solved by spending; no realistic complications of money
- Insta-love because rich — the love interest cannot fall primarily because of wealth-as-attractant; attraction must build through seeing beneath the power
- Money solves everything — every protagonist crisis resolved by the billionaire's chequebook strips agency from the love interest
- Billionaire who has no real problems — board pressure, deal complications, family dynamics, ethical dilemmas must create genuine business friction
- The non-billionaire absorbed into the billionaire's world — abandoning career, friends, identity to be kept; this kills agency and the genre's emotional register
- The billionaire instantly opens up — no arc of growth; no earned trust; emotional walls come down without character work
- "Stockholm syndrome" wealth dynamics — the love interest impressed into compliance by luxury without resistance, awareness, or boundary-setting
- Wealth as catalog — listing brands, square footage, prices instead of letting the reader feel the gap through the POV character's emotional response
- Single-conversation resolutions — the wealth gap cannot be talked out in one heart-to-heart; the dynamic must arc across the full structure

OBSTACLE LAYERING (the genre's load-bearing tension):
Billionaire romance has a built-in external obstacle (the wealth gap and everything it brings — paparazzi, family, business pressure, social hierarchy), but internal obstacles are what give the genre its devastating emotional power. Layer the billionaire's specific trust wound (who left when, who used them, what they had to learn), the non-billionaire's specific dignity-edge (the line they won't cross for love or money, the work they refuse to abandon), and the world-mismatch that neither character can fully solve. Each obstacle should make the next chapter's progress harder. The more honest the obstacle, the more devastating the moments when something cracks open.

LIGHT AND SHADE — THE PRESSURE VALVE:
Billionaire romance that's relentlessly tense and angsty exhausts the reader. The non-billionaire's dry observations about absurd wealth — a bathroom bigger than their apartment, the casual confidence that money will solve a problem most people wrestle with for years — is the pressure valve that lets readers love the characters. Plan the humour beats: where the non-billionaire's observational wit lands, where the billionaire's cluelessness about pedestrian things creates affection, where awkward wealth-gap moments resolve into tenderness rather than pain. Two relentlessly heavy scenes back to back numb the reader; humour followed by a serious gap-moment makes the gravity register.

CHARACTER BUILDING. GROUND UP:
Build both leads from the ground up before they enter the story. For the billionaire: what is the SPECIFIC wound that drives the trust issues? (The ex who left when funds shifted; the mentor who exploited them; the family member who betrayed them for inheritance.) What does money NOT fix in their life? What pedestrian thing have they not done in years? For the non-billionaire: what is the work they refuse to abandon? Who are the friends and family the billionaire cannot replace? What is their specific dignity-edge — the line where money becomes unacceptable to them? The vast majority of this work will not appear on the page, but every line of dialogue and every choice carries it.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  {dopamine_ladder_diagnostic} slot, so every chapter you
  produce should have at least 4-5 of the 6 dopamine layers
  active simultaneously, and Affection plus Validation should
  carry double weight in this genre — the billionaire-romance
  reader is here for the relationship.

UNIVERSAL CRAFT FUNDAMENTALS
→ See `craft-fundamentals.md` for the universal mechanical
  craft fundamentals (sentence rhythm, sensory grounding,
  POV discipline, dialogue mechanics, paragraph variation,
  pacing). Every Billionaire Romance scene must conform.

THE 10 BILLIONAIRE-ROMANCE PROSE RULES (apply to every scene):

1. WEALTH IS SENSORY, NOT CATALOGED. Do not write billionaire romance like a luxury magazine. Don't list brands, prices, square footage. Make the reader FEEL the wealth gap through the POV character's sensory and emotional response. Wrong: "His penthouse had floor-to-ceiling windows, Italian marble, a Bösendorfer piano, and a Manhattan view." Right: "The elevator opened directly into his living room. No hallway, no lobby, no neighbours. Just space — more space than my entire apartment, filled with the kind of silence that money buys." The reader feels the gap through emotional response, not through a price tag.

2. THE NON-BILLIONAIRE'S INTERNAL MONOLOGUE IS THE ENGINE. The wealth gap lives inside the non-billionaire's head as constant, low-grade awareness of not belonging. This is reality processing, not insecurity. It sounds like: noticing things they can't afford while pretending not to; reflexively calculating the cost of the wine, the car, the flight; catching themselves enjoying luxury and feeling guilty; wondering if they'd be here if they weren't useful to the billionaire. It does NOT sound like: whining about being poor, constant self-pity, or "I'm not good enough" on repeat — that's insecurity, not gap awareness.

3. DIALOGUE SHOWS CLASS THROUGH ASSUMPTIONS. Don't write accent or vocabulary differences. Show class through what each character ASSUMES exists. The billionaire assumes: "I'll have my assistant handle that" / "We can take the jet" / "I know a place" — and proposes solutions whose cost is invisible to them. The non-billionaire assumes: "I'll figure it out" / suggests splitting the bill and then sees the total / proposes driving instead of flying. The funniest and most tension-filled moments come when these assumptions collide.

4. INTIMACY CARRIES THE GAP. Intimate scenes are where the power dynamic becomes most visible AND most vulnerable. The setting matters — the penthouse bedroom, the hotel suite, the yacht cabin make the gap visible even in vulnerable moments. The non-billionaire's awareness of the gap doesn't disappear during intimacy. Vulnerability is harder when one person has all the power; show the effort it takes to be open. At every heat level — closed-door to scorching — the wealth dynamic should bleed into the physical and emotional register of the scene.

5. HUMOUR IS THE PRESSURE VALVE. Relentlessly tense billionaire romance exhausts the reader. The non-billionaire's dry observations about absurd wealth — "A bathroom bigger than my apartment. Cool. Normal." — are what make the reader love the characters. The billionaire's cluelessness about pedestrian things (not knowing the price of milk, confused by public transit) creates affection. Awkward wealth-gap moments played for comedy before they become painful let the heavy beats land. Avoid: mean humour at the non-billionaire's expense (classist), buffoonish billionaire (undermines authenticity), slapstick that breaks the romantic tension.

6. THE BILLIONAIRE IS A PERSON, NOT A FANTASY. AI defaults to writing billionaires as fantasy objects: effortlessly powerful, devastatingly handsome, mysterious but ultimately safe. Real billionaire romance gives them specific, humanising details. A nervous habit money cannot fix (biting the inside of their cheek during board meetings). A pedestrian food preference (eating cereal for dinner because the startup years are still close). A genuine insecurity wealth amplifies ("everyone says yes to me, so I never know what's real"). Physical imperfection — not every billionaire is chiselled; some are soft from desk work, tired from 80-hour weeks. A complicated relationship with money — guilt, fear of losing it, shame about having more than others.

7. SCENE ARCHITECTURE — THREE LAYERS PER SCENE. Every scene operates on three simultaneous levels: (a) Surface — what's happening (a dinner, a meeting, a confrontation); (b) Romance — how the romantic tension is advancing or complicating; (c) Wealth Dynamic — how the gap is being felt, navigated, or challenged. A scene that only operates on one level is flat. A dinner scene should ALSO be a moment where the non-billionaire notices the bill AND a moment where the billionaire's vulnerability shows through.

8. CHAPTER ENDINGS PULL FORWARD. Don't end chapters with philosophical observations about wealth and love, tidy emotional wrap-ups, "and I knew everything had changed" mic-drops, or summary of what the character learned. End chapters with: an unresolved question, a decision the character hasn't made yet, a complication that just arrived, mid-scene with the next chapter picking up in the middle of action, or a line of dialogue that changes everything.

9. THE BUSINESS IS REAL. The billionaire's wealth source must feel authentic. Avoid vague "tech company" or "empire" language. Real business pressure looks like: a phone call interrupting a romantic moment because a deal is falling through; the billionaire compulsively checking markets; a board meeting where they're challenged and don't have a good answer; competitor moves requiring immediate strategic response; employees with problems they actually care about; financial complexity beyond "I'm rich" — money tied up in things that can't be liquidated. The business creates romantic conflict by demanding time, exposing the billionaire's ruthless side, and putting the non-billionaire in uncomfortable positions (galas, business dinners, press scrutiny).

10. AVOID BANNED PHRASES AND PLOT SHORTCUTS. Banned phrases: "His jaw clenched as he surveyed his empire" / "She was swept up in his world" / "Money couldn't buy what she had" / "He was used to getting what he wanted" / "His eyes darkened with desire" / "She felt like Cinderella at the ball" / "He bought her something expensive and she protested weakly" / "Their worlds collided" / "He opened up to her like he'd never opened up to anyone" / "She showed him what really mattered in life". Banned plot shortcuts: the billionaire buying the non-billionaire's way out of a problem; the non-billionaire's debt or financial crisis solved by the billionaire as a romantic gesture; a grand public gesture resolving all tension; the non-billionaire "proving" they don't care about money by rejecting one gift; a single conversation resolving the entire wealth-gap tension; the billionaire's family immediately loving the non-billionaire; a media scandal resolved in one chapter.

THE ROMANCE-MASTERCLASS LAYER (binding):
The romance master file (`romance.md`) holds the canonical romance frameworks: Heat Level Calibration, the 7-Element Chemistry Scene Construction, the 6 Romance Character Archetypes, Obstacle Layering Quantitative, Light-and-Shade Heart-Monitor Rule, the Differentiation Imperative, Hope-as-Resolution Calibration, and Series Architecture. All apply directly to billionaire romance, calibrated below to this subgenre's specific wealth-asymmetry register. CRITICAL: billionaire romance demands extreme craft on the wealth-gap negotiation; the masterclass-level discipline is in honouring genuine agency within the genre's structural-power frame.
```

## Quality Check Criteria

Every chapter must satisfy the following criteria before it ships out of the verification stage:

**Wealth Authenticity:**
- Wealth source is specific and visible (not vague "rich CEO")
- At least one current business pressure is referenced or active
- Wealth manifests in psychology, not just possessions (control needs, trust wounds, isolation)
- The billionaire's wealth has at least one realistic complication (privacy, family, paparazzi, board pressure, ethics)
- Wealth is rendered sensorially through emotional response, not catalog-style listings

**Power Dynamic:**
- Power balance is tracked across at least two of: financial control, decision authority, social position, privacy, information access
- The chapter advances or complicates at least one power axis
- Power imbalance is acknowledged on the page (characters notice it; narrative engages with it)
- The current power-dynamic tag (Billionaire dominant / Shifting / LI asserting / Crisis / Mutual vulnerability) is consistent with the chapter's position in the arc

**Agency:**
- The non-billionaire takes at least one autonomous action (not reactive)
- They can articulate their own motivations independently of the billionaire
- Their career, friends, family, or independent goals appear in the chapter
- Money does not silently solve their problem; if the billionaire offers, they refuse, negotiate, or accept on their own terms

**Golden Cage:**
- At least one luxury setting includes a beat of restriction, surveillance, or isolation
- The non-billionaire feels both alluring AND suffocating moments in the same scene
- Wealth creates at least one specific complication (lost anonymity, family scrutiny, dependence, paparazzi, expectation)

**Billionaire as Person:**
- At least one humanising detail surfaces (nervous habit, pedestrian preference, specific insecurity, physical imperfection)
- The billionaire's vulnerability is character-specific, not generic ("rough childhood" is insufficient)
- Their flaws extend beyond "works too hard" or "can't open up"
- Money does not appear to solve everything in their life either

**Scene Architecture:**
- Every scene operates on three layers: surface (what's happening), romance (relationship motion), wealth dynamic (gap navigation)
- No scene is purely one-dimensional
- Scenes have clear entry and exit hooks
- Chapter ending pulls forward (unresolved question, decision pending, complication arriving, mid-scene cut, or pivotal line)

**Heat Level:**
- Heat level matches the project's declared register (clean / moderate / steamy / scorching)
- Sexual content (where present) advances emotional intimacy alongside physical
- Power dynamics are visible in intimate scenes; gap awareness doesn't disappear
- Frequency and explicitness match billionaire-romance reader expectations for the declared heat level

**Forbidden Patterns:**
- Zero banned phrases (see Writer Craft Rules Rule 10)
- Zero banned plot shortcuts
- No insta-love-because-rich
- No money-solves-everything resolution
- No grand-public-gesture conflict resolution
- No single-conversation wealth-gap resolution
- No billionaire absorbing the non-billionaire into his world without the non-billionaire's resistance and chosen agency

## Continuity Rules

**Wealth Source Continuity:**
- The billionaire's wealth source (industry, role, company name, founding history) is locked in Phase 2 and cannot drift between chapters
- Net worth is established as a range, not a precise figure that changes (most billionaire romance heroes sit between $1B and $10B; specifics within that range can flex but the order of magnitude is locked)
- Current business position (active CEO / chairman / founder stepped back / inheritor) is consistent across the manuscript
- The specific business problem driving Act 1's pressure must remain visible across Act 2 unless it's resolved on-page

**Power Dynamic Tag Continuity:**
- Each chapter carries an internal power-dynamic tag: [Power: Billionaire dominant] / [Power: Shifting] / [Power: LI asserting] / [Power: Crisis] / [Power: Mutual vulnerability]
- Tags follow the Power Balance Arc Template (see Arc Rules below) — they cannot regress without an in-story trigger
- A "Mutual vulnerability" chapter cannot be followed by a "Billionaire dominant" chapter unless a documented betrayal or relapse triggers the regression

**Agency Ledger:**
- Maintain a per-chapter ledger of the non-billionaire's autonomous actions, refusals, and independent connections
- No chapter passes verification without at least one entry
- The ledger surfaces in the editorial pipeline as evidence the non-billionaire has not been absorbed into the billionaire's world

**Golden Cage Ledger:**
- Maintain a per-luxury-scene ledger of the cage-element activated (restriction, surveillance, isolation, expectation)
- Identical cage-elements cannot repeat in consecutive luxury scenes — the cage must rotate so the reader feels the gap from multiple angles

**Wealth Source Reveal Schedule (Secret Billionaire subgenre only):**
- The reveal moment is locked once placed — moving it post-Act-2-mid risks structural collapse
- Information leakage before the official reveal must be tracked: who knows, when they learned, what they know specifically
- Post-reveal trust-rebuilding beats follow a documented schedule, not improvised emotional progression

**Family Cast Continuity:**
- Billionaire family members (especially formidable matriarchs, business-rival siblings, prodigal children) introduced in Act 1 must reappear in Acts 2-3 if their introduction loaded a Chekhov gun
- Family disapproval beats track across the manuscript — disapproval at chapter 4 cannot vanish at chapter 12 without reconciliation work on the page

**Setting Pattern Continuity:**
- The penthouse, the office, the family estate, the love interest's apartment — each established setting carries a sensory profile that must remain consistent
- The penthouse view at chapter 3 is the same view at chapter 22; the love interest's apartment retains its specific texture across the manuscript

## Character Rules

**The Billionaire — Authenticity Requirements:**

- **Specific wealth source.** Industry (finance / tech / real estate / pharma / energy / entertainment / family conglomerate / etc.), role (active CEO / founder / inheritor / board chair), founding history (built it / inherited it / clawed up the ranks / acquired and consolidated). All specific. None vague.
- **Visible business responsibilities.** Daily decisions (personnel, strategy, financial, ethical). Reporting structure (who reports to them; who they report to — board, investors, family). Current pressure points (regulatory, competitive, internal, financial).
- **Specific trust wound.** Not "rough childhood." Not "it's hard at the top." Specific: the ex who left when funds shifted; the mentor who exploited them; the family member who betrayed them for inheritance; the friend from before-the-money who took the easy money and disappeared. The wound has a name, a year, a specific betrayal.
- **Money-related psychology.** Trust issues (who they actually trust and why those few). Control needs (what they need to control: schedule, environment, information about themselves). Isolation (what wealth has cost them: anonymity, casual friendships, normal experience). Strategic mindset (how relationships get approached strategically by default).
- **What money cannot fix in their life.** This is what the non-billionaire provides. Genuine love unmediated by transaction. Trust that doesn't depend on outcomes. Being seen as a person rather than an opportunity. Acceptance of their flaws and complications. Real friendship.
- **Humanising specificity.** A nervous habit money cannot solve. A pedestrian food preference. A physical imperfection. A complicated relationship with their own wealth (guilt, fear of loss, shame about excess). At least one of these surfaces per chapter.
- **Arc of growth.** The billionaire does not start trusting and vulnerable. They earn it. The growth from "I solve this with money" to "I cannot solve this with money and I have to be vulnerable" is the central character arc.

**The Non-Billionaire — Agency Requirements:**

- **Independent career or passion.** Not inherited from the billionaire. Not created by the billionaire's money. They had it before. They pursue it during. They will keep it after. The career has texture — they like specific things about it; they're frustrated by specific things; they have ambitions within it.
- **Pre-existing life.** Friends. Family. A home. A community. A neighbourhood. A regular bar. A favourite coffee shop. A weekly routine. None of these are abandoned to be with the billionaire; they're consciously preserved.
- **At least one major refusal.** The penthouse move. The credit card. The job offer at his company. The demand to distance from friends. The expectation to abandon their apartment. Somewhere in the manuscript, the non-billionaire says no — and holds the no.
- **Money-refusal moments.** They turn down at least one significant financial offer. Not because of pride but because accepting it would compromise their agency, identity, or relationship.
- **Articulable motivation.** They can say (in dialogue or internal monologue) why they choose this billionaire specifically — and the reason is character-specific, not generic. "Because he sees me in a way no one else does." "Because I'm building something meaningful with him." Not "because I love him."
- **Solves at least one problem themselves.** Their job loss, medical bill, housing crisis, or family emergency must NOT be solved by billionaire money as a romantic gesture. They find their own solution — possibly with billionaire support, but with their agency at the centre.
- **Specific dignity-edge.** The line where money becomes unacceptable to them. Stated explicitly somewhere in the manuscript. The billionaire learns where the line is. The line cannot be crossed without consequence.

**The Non-Billionaire — Archetypal Pairings That Work:**

- The Independent Career Woman — doctor, lawyer, business owner, artist, academic with meaningful work that grounds her outside his world
- The Working-Class / Service Industry Person — waitress, nurse, teacher, nanny, service worker with genuine financial constraint and integrity
- The Artist / Creative — writer, painter, musician, designer with a different value system (art > money)
- The Activist / Principled Person — nonprofit, environmental, social-justice work that creates ideological conflict with the billionaire's world
- The Girl-Next-Door / Ordinary Person — regular job, ordinary life, every-woman energy that grounds wish fulfilment in relatability
- The Smart / Intellectual — academic, researcher, intellectually rigorous love interest who matches his mind and respects ideas over status

Each archetype has specific market resonance. The choice should align with the billionaire subtype's psychology — a tech mogul + activist creates ideological friction; a corporate CEO + intellectual creates partnership-of-equals tension; an old-money inheritor + working-class lead surfaces class drama; etc.

**Supporting Cast Requirements:**

- The billionaire's inner circle (assistant, best friend, business rival, family matriarch) must be more than props. Each carries opinion about the love interest and at least one moment of consequence in the plot.
- The non-billionaire's inner circle (friends, family, work colleagues) cannot vanish when the billionaire arrives. They're sceptical. They have opinions. They notice the gap. They surface in Act 2 and 3 with their concerns.
- Series-potential characters (siblings, business partners, friend group, security team members) should be planted in Act 1 with enough texture to anchor a future book without crowding the current one.

## Arc Rules

**The Power Balance Arc Template:**

Billionaire romance follows a documented power-dynamic arc across the structural acts. Each chapter carries a power-dynamic tag matching its position in the arc; the editorial pipeline checks the tag against the chapter index.

**Act 1 — Billionaire Dominant (0-25% of manuscript):**
- Power Dynamic: Billionaire controls money, access, decisions, information, time, social position. Love interest lacks financial security, access, decision-making power, information.
- Billionaire's Mindset: I can have anyone. I solve problems with money. People want my power, not me. I don't need to be vulnerable.
- Love Interest's Mindset: He's intimidating. His world is foreign. I feel small. I can't compete with his power. I'm attracted but afraid.
- Key Scenes: Money imbalance is visible and uncomfortable. Billionaire makes unilateral decisions. Love interest is dazzled or resentful. First attraction is mixed with power anxiety.
- Tag: [Power: Billionaire dominant]

**Act 2a — Cracks Appear (25-50%):**
- Power Dynamic: Billionaire starts to feel vulnerable around love interest. Love interest begins to see billionaire's humanity beneath power. Small moments where love interest asserts agency. Billionaire realises money cannot buy what he needs.
- Billionaire's Mindset: What is this? I cannot control them with money. I don't want to. They see something real in me. I'm terrified of that.
- Love Interest's Mindset: He's not just power. There's someone real under all that. But I still can't compete with his world. I'm not sure I want to.
- Key Scenes: Billionaire does something vulnerable. Love interest refuses something (money, demand, control). Billionaire is shocked. They find common ground outside wealth. First genuine moments of connection.
- Tag: [Power: Shifting]

**Act 2b — Love Interest Asserts (50-75%):**
- Power Dynamic: Love interest makes a choice that goes against billionaire's preference or benefit. They establish a non-negotiable boundary. Billionaire must respect it or lose them. Billionaire becomes genuinely vulnerable.
- Billionaire's Mindset: I'm losing control. I don't know how to handle this. Do they actually want me, or do they want to escape? I have to let them choose.
- Love Interest's Mindset: I have power here. I can leave. He knows I can leave. That terrifies him. That makes me feel real for the first time.
- Key Scenes: Love interest refuses something major (the penthouse move, the job offer, the demand to distance from friends, the ask to be kept). Billionaire panics or attempts manipulation. Love interest holds firm. Billionaire has to actually earn trust through behaviour change, not money.
- Tag: [Power: LI asserting]

**Act 3 — Crisis of Control (75-90%):**
- Power Dynamic: Maximum tension. The billionaire either doubles down on control and loses the love interest, or releases control and becomes genuinely vulnerable. This is the crisis point.
- Billionaire's Mindset: I'm losing them. If I try to control this, they leave. If I let go, they might still leave. Everything is out of my control. I hate this.
- Love Interest's Mindset: I could leave. Part of me wants to. But staying means risking that they'll never fully let go of control. Or that I'll lose myself in their world anyway.
- Key Scenes: A moment where the billionaire's trust is tested and they fail (or nearly fail). Or a moment where external pressure (business crisis, paparazzi, family intervention) tries to break them apart. Billionaire must choose love over control. Love interest must choose to stay despite the power imbalance still existing.
- Tag: [Power: Crisis]

**Act 3b — Mutual Vulnerability (90-100%):**
- Power Dynamic: Not equality in wealth (unrealistic), but balance in the relationship. Billionaire is genuinely vulnerable and accepting of love interest's agency. Love interest has genuine choice and stays, knowing the complications don't disappear. Both have power and both are at risk.
- Billionaire's Mindset: I cannot control this. I don't want to control this anymore. They're choosing me knowing everything. That's love I can actually believe in.
- Love Interest's Mindset: I'm choosing this fully aware. I'm not being swept along. He's choosing me while releasing control. That's what makes it real.
- Key Scenes: Billionaire makes a concrete choice that shows vulnerability (divests from a business to have more time, tells the love interest something they've never told anyone, admits they were wrong, lets the love interest make a major decision without trying to manipulate). Love interest chooses to stay despite knowing the wealth imbalance won't disappear, because they're choosing the person, not the money.
- Tag: [Power: Mutual vulnerability] or [Power: Balanced]

**Arc Discipline:**
- Tags cannot regress without an in-story betrayal or relapse trigger
- The Power: Crisis chapter is the load-bearing structural climax — the entire manuscript turns on it
- The HEA / HFN must arrive at Mutual Vulnerability, not at parity in wealth
- Subgenre variants modify the arc: Secret Billionaire shifts the Act 2a moment to the reveal; Dark / Criminal Billionaire intensifies the Crisis with literal danger; Old Money introduces family approval as a parallel arc

**Chemistry Arc (the 7-Element scene structure applies in parallel):**
- Setup: power imbalance is the operating constraint of every chemistry scene
- Approach: often power-driven causation (the summons, the assignment, the inescapable circumstance)
- Banter Beat: power-dynamic subtext; class-assumption collisions; control negotiation
- Awareness Spike: typically arrives at a wealth-gap collision moment — the realisation of attraction despite or because of the gap
- Pull-Back: load-bearing pull-back is carried by genuine character resistance — the line the non-billionaire will not cross, the vulnerability the billionaire cannot yet allow
- Aftermath: the wealth-gap consequence of what just happened — what each lead carries forward
- Hook: the next collision, the next refusal, the next vulnerability test

## Timeline Rules

**Compressed-Time Discipline (typical for billionaire romance):**

Billionaire romance often telescopes time — the relationship moves fast because forced proximity (workplace, fake-relationship contract, business arrangement, paparazzi situation) keeps the leads in each other's orbit. The genre tolerates compressed time IF the emotional progression is earned within the compressed window. Common windows:

- **Single-month timeline:** popular for fake-relationship and business-deal setups. The contract has a deadline; the romance plays out within it.
- **Three-to-six-month timeline:** standard contemporary billionaire romance. Allows for seasonal markers, business-cycle pressure, and credible relationship development.
- **One-year timeline:** common for second-chance and slow-burn billionaire romance. Allows for full seasonal arc and major business cycles.
- **Multi-year timeline:** typical for inherited-wealth dynasty stories or paranormal billionaire (centuries) where the time-scale itself is part of the genre register.

**Business-Cycle Markers:**

Real billionaires move through business cycles that the manuscript should respect:
- Quarterly earnings (every three months — pressure spikes at quarter-end)
- Board meetings (monthly or quarterly)
- Annual shareholder meetings
- Industry conferences and conventions
- Deal-closing windows (often quarter-end or year-end)
- Tax-year considerations (year-end planning, April filings)
- Fiscal-year structure (varies by company; lock the structure for the billionaire's company in Phase 2)

These markers create natural pacing pressure. A romantic crisis arriving the night before a critical board vote is structurally stronger than a romantic crisis arriving on a calendar-neutral Tuesday.

**Paparazzi / Media Cycle:**

Public-facing billionaires live in a media cycle. The manuscript should track:
- When the relationship goes public (paparazzi photo, gossip column, social media leak)
- How the media cycle reacts (initial speculation, escalation, peak coverage, cooling)
- The non-billionaire's introduction to media exposure (first photo published, first article, first viral moment)
- Family / business reaction lag (the media cycle hits the billionaire's mother in days, not weeks)

**Relationship-Time Discipline:**

- Time spent together must reflect the billionaire's actual schedule (board meetings, travel, business obligations)
- The billionaire cannot vanish from work for the romance without consequence in their business arc
- Relationship progression markers (first kiss, first I-love-you, first major refusal, first family meeting) should land at structurally meaningful chapter positions, not arbitrarily

**Seasonal / Setting Discipline:**

- Establish the manuscript's season in Phase 2 and hold it consistent
- Holiday markers (Thanksgiving, Christmas, New Year) carry plot weight in billionaire romance — family gatherings, gala season, end-of-year deals
- Seasonal pressure (summer Hamptons, winter Aspen, spring shareholder season) can be load-bearing for setting

**Subgenre Time-Discipline Variants:**

- Secret Billionaire: pre-reveal time and post-reveal time have different texture; the manuscript should mark the shift
- Forced-Proximity / Snowed-In: extreme time compression is the genre register; calendar markers matter less than hour-by-hour progression
- Marriage-of-Convenience: the contract has a deadline; the timeline drives the emotional arc
- Series Setting: when planting series-potential characters, their timeline must remain consistent across the series, not retrofit chapter-by-chapter

## Genre-Specific Craft Techniques

### The Wealth-Is-Sensory Discipline

Billionaire romance lives or dies by its render of wealth. Catalog-style writing (brand names, square footage, prices) is the genre's most common AI failure mode. Replace catalog with sensory-emotional render at every scale.

**The render-test:**
- Could the wealth detail be removed without changing the POV character's emotional state? If yes, it's catalog.
- Does the reader feel the gap, or just see it? If just see it, it's catalog.
- Is the detail filtered through the POV character's awareness, history, and class position? If not, it's catalog.

**The replacement pattern:**
- Wrong: "The dress was a $12,000 Valentino gown, sequined and floor-length."
- Right: "The dress moved like water. I'd never worn anything that felt like an apology for existing — like the fabric was sorry it had to touch my skin because it was too good for me."

The right version contains zero brand names and zero prices, yet the gap is felt at full intensity.

### The Golden-Cage Discipline

Every luxury setting in the manuscript must do double duty: wish-fulfilment AND complication. A scene that's pure luxury without a cage-element is flat and reduces the genre to wish-fulfilment-as-product.

**The five canonical golden-cage scenarios:**

1. **The Penthouse Scene.** She's in his luxury apartment, 40 stories up, surrounded by expensive art she doesn't understand. Floor-to-ceiling windows face the city. It's gorgeous. It's also isolating — she can see the world below but cannot go out without paparazzi noticing. His staff is always present. She doesn't know where the light switches are. The space is designed for him, not for her. The view is incredible and imprisoning.

2. **The Private Jet.** She's in his plane, traveling to his vacation property. No one else. It should be romantic. Instead, she realises everyone on the ground knows what his plane looks like. Their relationship is public before they've decided what it is. She cannot get off and walk around. She's trapped in luxury at 30,000 feet.

3. **The Gala.** She's wearing a dress that cost more than her monthly rent. She looks stunning. She also feels watched, judged, expected to be ornamental. She cannot speak her mind without creating scandal. Every word might end up in a gossip column. She's on display. The wealth is visible, but so is her discomfort. Other women know she doesn't belong in this world.

4. **The Family Dinner.** The table is beautiful. The conversation is about assets, business moves, social positioning. Her career, her thoughts, her world are irrelevant. She realises his family will never see her as anything but a temporary distraction from serious wealth. Or worse, they'll see her as a gold-digger trying to access the fortune.

5. **The Neighbourhood Clash.** He wants to take her to an exclusive members-only club in his world. She wants to take him to her favourite neighbourhood bar where everyone knows her. His world makes her uncomfortable. Her world makes him uncomfortable (everyone staring because he's obviously rich, the drink prices amuse him, he's overly aware of being observed). Neither can fully inhabit the other's space.

**Per-scene checklist:**
- What is the glamorous element? (penthouse view, jet, club, gown, yacht, first-class travel, private staff, hidden location)
- What restriction or loss of freedom comes with it? (cannot go out unnoticed, everyone watching, dependent on billionaire's decisions, lost privacy, no anonymity, expected to perform, staff always present, cannot invite regular friends)
- What is the sensory detail that makes the cage feel real? (perfect view but cannot open the window, beautiful dress but it's too tight, exclusive club but she's the only one uncomfortable, everyone is beautiful and she feels judged)
- How does the love interest feel at the end of the scene? (dazzled but suffocated, grateful but trapped, impressed but diminished, loved but controlled)

### The Agency-Assertion Moment

Five canonical moments where the non-billionaire takes power and the billionaire has to respect or lose them. At least three of these should appear across the manuscript.

1. **Refusing the Penthouse.** He invites her to move in. It's beautiful, it's romantic, it solves her housing problem. They'd be together constantly. She says no. Not "not yet" or "let me think." No. She wants her apartment. She wants her space. She wants the ability to leave. Why it terrifies him: if she won't move in, won't fully integrate into his world, does she really want him? Or is she keeping an escape route because she doesn't trust the relationship? Consequence: he has to respect her boundary or lose her. He learns that love isn't absorption.

2. **Turning Down the Job.** His company is hiring. He offers her a perfect position, great salary, same building. It's a huge opportunity, and it comes with the implicit message: come into my world. She declines. Not because the job is bad, but because she's built something at her current workplace, or because she wants to be known for her own work, not as "the billionaire's girlfriend at his company." Consequence: he has to see her as a full professional with ambitions outside his world.

3. **Refusing to Isolate.** The paparazzi are getting attention. He suggests she stop going out with her friends (for privacy, for safety, to avoid rumours). She refuses. She's going to her friend's birthday dinner. She's not hiding. She's not letting his complicated life restrict her normal life. Consequence: he has to accept that his girlfriend is visible, that people will talk, that he cannot control everything about her life.

4. **Demanding Transparency.** She overhears something at a party (about his business, about her, about them). She knows he wouldn't want her to know. She tells him. Not because it benefits her or helps the relationship, but because she refuses to keep secrets or be kept in the dark. She demands transparency. Consequence: he has to be vulnerable and honest. He has to stop compartmentalising.

5. **Making a Unilateral Major Decision.** A job opportunity comes up in another city. It's perfect for her career. It would mean long distance, or her leaving. She considers it seriously. She makes her own choice (to go or stay), but she makes it because of her career and her growth, not because he convinced her or controlled the decision. Consequence: whether she goes or stays, the choice is hers. The dynamic shifts — she's not his to control or keep.

### The "Why Not Just Leave" Discipline

A specific question the manuscript must answer explicitly for both leads. Generic answers fail the genre.

**For the love interest** — why stay despite power imbalances that get uncomfortable?
- NOT generic: "because I love him", "because he's so handsome", "because I'm lonely", "because he changed for me"
- IS specific: "Because he sees me in a way no one else does and I'm terrified no one else ever will." "Because I'm building something meaningful with him, not just being swept along." "Because he actually listens, which no one in my life ever did." "Because walking away means admitting I cannot handle the complications, and I'm not a quitter."

**For the billionaire** — why let someone in despite deep trust issues?
- NOT generic: "because she's beautiful", "because I'm lonely", "because she's good"
- IS specific: "Because she's the only person who isn't impressed by my money, and that terrifies and intrigues me." "Because she challenges me in ways no one else dares to." "Because she makes me want to be better, and I've never wanted that before." "Because she doesn't want anything from me except honesty, and I've never had to give that."

The answers must surface in dialogue or internal monologue. Not implied. Said. Both characters must articulate their why-stay reason at least once. The reason must involve genuine sacrifice or risk from both sides.

### The Worlds-Colliding Framework

Billionaire romance is fundamentally about two very different worlds coming together. The collision creates the genre's tension.

**The billionaire's world:** high-end luxury aesthetic; formal, performative, watched social register; abstract economic register (billions look like trillions); strategic, careful, guarded emotional register; scheduled, valuable, productive time register; aggressively protected privacy.

**The non-billionaire's world:** functional, personal, varied aesthetic; casual, genuine, inclusive social register; concrete economic register (every dollar matters); genuine, open, expressive emotional register; flexible, abundant, precious time register; naturally available, openly shared privacy.

**Collision points that create tension:**
- Communication: he's formal/strategic, she's casual/blunt
- Money: she suggests splitting a bill, he's insulted; he casually spends what she makes in a year, she's uncomfortable
- Social Situations: her friends make fun of him; his friends judge her
- Time: he has scheduled "relationship time", she wants spontaneous moments
- Privacy: she wants to post about their relationship, he wants it secret
- Living Space: his world is beautiful and controlled, hers is messy and genuine
- Career: his world is acquisition and power, hers is contribution or passion

**Resolution approaches:**
- They create a third space (new home, new routine) that isn't fully his world or hers
- They each compromise (he learns to be spontaneous, she learns to dress up sometimes)
- They maintain separate worlds but navigate between them (she keeps her apartment, he joins her bar nights)
- One world becomes primary, the other secondary (she leaves her city, or he steps back from business)
- They blend elements (his resources + her authenticity create something new)

### The Billionaire-Subtype Calibration

Each billionaire subtype carries specific psychology that calibrates the romance's register. Lock the subtype in Phase 2 and hold it across the manuscript.

**CEO / Corporate Billionaire:** highly strategic; reads people for leverage; pressured by board; responsible for thousands; trust issues from people motivated by stock options; relationships approached strategically; wealth is abstract.

**Tech Mogul:** visionary but impatient; disruption-mindset; hyper-focused; younger; possibly socially awkward; arrested emotional development; engineer-mindset treats people as problems to solve; recent wealth means scarcity habits remain.

**Old Money:** sense of entitlement; family obligations; insulated from normal world; doesn't understand scarcity; formal in relationships; family has opinions; wealth feels inevitable, not earned.

**Self-Made:** obsessive and driven; chip on shoulder; doesn't respect inherited wealth; ruthless in business; keeps scarcity habits; loyal to people who knew them when; identity bound to business.

**Secret Billionaire:** deliberately hides wealth; paranoid or cautious; testing love interest; trauma may explain hiding; deception creates foundation problem when revealed.

**Criminal / Morally Gray:** ruthless and amoral or justifying means by ends; power from danger; surrounded by compromised people; loyalty paramount; redemption requires genuine moral awakening, not just love-interest-makes-him-better.

### Heat Level Calibration for Billionaire Romance

Billionaire romance skews higher heat than most romance subgenres. Reader expectation:

- **Sweet/Clean:** less common; readers choosing this subgenre expect some sensuality; closed-door scenes work IF emotional intimacy and sexual tension are heavily built
- **Moderate (fade-to-black, implied intimacy):** workable for romantic-comedy billionaire and older-reader-base projects; tension must be heavily built; payoff via implication
- **Steamy (open-door, explicit scenes):** the standard heat level for billionaire romance; expect 3-5 explicit scenes distributed through the manuscript; sexual content is integral, not supplementary
- **Scorching (very explicit, high frequency):** common in dark / criminal / paranormal billionaire variants; expect 5+ explicit scenes; sexuality shows character development and power exchanges

**Calibration discipline:** the project's declared heat level must be honoured. Underdelivering on heat is a documented reader-disappointment pattern in this subgenre. Overdelivering (heat that exceeds the marketed level) violates reader contract.

### Series Architecture

Billionaire romance has strong series potential. Plant threads in Act 1 for connected books:

- **Connected Billionaires:** best friends, siblings, business partners, rivals-turned-allies; each gets their own book; characters appear across the series
- **Inner Circle:** best friend, executive assistant, business rival, friendly ex, security team
- **Multi-Book Sequence:** Book 1 — CEO + working-class lead; Book 2 — his brother (tech mogul) + the activist; Book 3 — their business partner + the nanny; etc.

The current manuscript should be standalone-readable but plant at least two anchor characters with enough texture to carry their own future book without feeling like spin-off scaffolding.

## Genre-Specific Revision Rules

### Pass 1: Wealth Authenticity Audit

Read the manuscript with a single question: where is wealth doing nothing? Mark every paragraph where:
- Wealth is referenced but no character emotional response is registered
- Brand names, square footage, or prices are listed without filter
- The billionaire's business is referenced but lacks specific texture (industry, current pressure, role, deal context)
- The wealth source remains vague after Act 1 has closed

Replace catalog with sensory-emotional render. Add specific business pressure where wealth is treated as background. If a chapter contains multiple wealth references but zero emotional gap-feeling, the chapter fails the audit and must be rewritten.

### Pass 2: Agency Check

For each chapter, list the non-billionaire's autonomous actions, refusals, and independent connections. The list cannot be empty.

Red flags requiring rewrite:
- Love interest only acts in response to billionaire (no proactive choices)
- Love interest only makes choices that serve the billionaire or romance
- Love interest has no life independent of billionaire by the manuscript midpoint
- Love interest never refuses billionaire's money / demands / decisions
- Love interest's goals are all solved by billionaire action, not their own work

Confirm at least three canonical agency-assertion moments appear across the manuscript.

### Pass 3: Golden-Cage Verification

For every luxury scene, verify a cage-element is active. Use the per-scene checklist:
- What is the glamorous element?
- What restriction or loss of freedom comes with it?
- What is the sensory detail that makes the cage feel real?
- How does the love interest feel at the end of the scene?

Scenes that pass with pure luxury must be rewritten. Repeated cage-elements (penthouse-isolation appearing four times) must rotate to other cage variants.

### Pass 4: Power Dynamic Tracking

Confirm the power-dynamic tag for each chapter matches the Power Balance Arc Template:
- Chapters in 0-25% of manuscript carry [Power: Billionaire dominant]
- Chapters in 25-50% carry [Power: Shifting]
- Chapters in 50-75% carry [Power: LI asserting]
- Chapter at 75-90% carries [Power: Crisis]
- Final chapters carry [Power: Mutual vulnerability]

Tags cannot regress without a documented in-story trigger. The Crisis chapter is the structural climax — confirm it lands at the structurally correct position.

### Pass 5: Heat Level Calibration

Confirm the heat level matches the project's declared register:
- Sweet/Clean: zero explicit scenes; closed-door
- Moderate: fade-to-black; implied intimacy
- Steamy: 3-5 explicit scenes distributed across manuscript
- Scorching: 5+ explicit scenes; sexuality as character development

Underdelivery on heat is a reader-disappointment pattern. Overdelivery violates reader contract. Recalibrate scenes to match the declared level.

Confirm intimate scenes carry the wealth-gap awareness — the gap doesn't disappear during intimacy; it shifts register.

### Pass 6: Cliché Elimination

Search the manuscript for banned phrases:
- "His jaw clenched as he surveyed his empire"
- "She was swept up in his world"
- "Money couldn't buy what she had"
- "He was used to getting what he wanted"
- "His eyes darkened with desire"
- "She felt like Cinderella at the ball"
- "He bought her something expensive and she protested weakly"
- "Their worlds collided"
- "He opened up to her like he'd never opened up to anyone"
- "She showed him what really mattered in life"

Search for banned plot shortcuts:
- Billionaire buying the non-billionaire's way out of a problem
- Non-billionaire's debt or financial crisis solved by billionaire as romantic gesture
- Grand public gesture resolving all tension
- Non-billionaire "proving" they don't care about money by rejecting one gift
- Single conversation resolving the wealth-gap tension
- Billionaire's family immediately loving the non-billionaire
- Media scandal resolved in one chapter

Every match must be removed and replaced with character-specific text or plot logic.

### Pass 7: Worlds-Colliding Integration

Confirm the manuscript contains at least four worlds-colliding scenes distributed across the structure:
- One in Act 1 (initial collision; world-mismatch surfaces)
- Two in Act 2 (collision intensifies; characters navigate the mismatch)
- One in Act 3 (resolution approach: third space, mutual compromise, blended elements, or maintained separation)

Verify both worlds remain present in the manuscript. Neither world fully absorbs the other before the resolution.

### Pass 8: Series Potential Check

If series-potential is a project goal, verify at least two anchor characters are planted in Act 1 with enough texture to carry their own future book:
- Each anchor has a specific personality, role, and relationship to the current leads
- Each carries at least one moment of consequence in the current plot
- Each could be reasonably believed to spawn their own romance arc

If series-potential is not a project goal, this pass is skipped.

### Pass 9: Billionaire Authenticity Audit

For the billionaire, verify:
- Specific wealth source (industry, role, founding history)
- Specific trust wound (named, with year and betrayal)
- Visible business responsibilities that create plot pressure
- At least one humanising detail per chapter
- Money-related psychology (control, trust, isolation, strategic mindset) consistently rendered
- Character arc from "I solve this with money" to "I cannot solve this with money and I have to be vulnerable"

Generic billionaires fail the audit. Recalibrate to specificity.

### Pass 10: Romance-Masterclass Calibration

The romance master file (`romance.md`) frameworks apply:
- Heat Level Calibration: confirm heat level matches reader contract
- 7-Element Chemistry Scenes: confirm chemistry scenes follow the structure (Setup, Approach, Banter, Awareness Spike, Pull-Back, Aftermath, Hook)
- 6 Romance Character Archetypes: confirm both leads map to documented archetypes
- Obstacle Layering Quantitative: count obstacles per chapter; confirm density meets the masterclass threshold
- Light-and-Shade Heart-Monitor Rule: confirm humour and tenderness beats land between heavy beats
- Differentiation Imperative: confirm the manuscript has at least one distinct hook that differentiates from the comp set
- Hope-as-Resolution Calibration: confirm the HEA / HFN earns its hope through demonstrated character growth, not through external rescue
- Series Architecture: confirm series-potential characters meet the threshold (where applicable)

## Names & Patterns to Avoid

### Forbidden Patterns

**Billionaire male given names that have saturated the AI-generated billionaire-romance market:**
Grayson, Sterling, Stone, Hawk, Chase, Blake, Jax, Knox, Reid, Declan, Damian, Atticus, Landon, Aiden, Zane, Roman, Silas, Kai, Draco, Lucian, Constantine, Evander, Theron, Saxon, Rafe, Kade, Kieran, Caleb, Ethan, Bennett, Gavin, Axel, Ezra, Matthias, Dashiell, Maximilian.

**Billionaire-adjacent female given names that have saturated:**
Ava, Madison, Scarlett, Sienna, Olivia, Victoria, Alexandria, Ariana, Evangeline, Arabella, Seraphina, Penelope, Juliette, Octavia, Catalina, Juliana, Alessandra, Margot, Celeste, Delilah, Ravenna, Isolde.

**Billionaire surnames that have saturated:**
Blackwell, Sterling, Stone, Hawk, Kingsley, Ashford, Beaumont, Whitmore, Harrington, Huntington, Sinclair, Ravenswood, Marlowe, Ashton, Worthington, Thornton, Montgomery, Dalton, Garrison, Maverick, Wilde, Steele, Thorne, Knight, Archer, Winter, Drake, Wolf, Rourke, Savage, Cross, Dane.

**Generic AI billionaire-business-name patterns to avoid:**
Synergy Solutions, Global Dynamics, TechFlow Systems, Innovative Enterprises, Strategic Partners LLC, Advanced Solutions Inc., Premier Services Group, NextGen Technologies, Vertex Corporation, Pinnacle Industries, Apex Industries, Zenith Capital, Ascendant Group, Paramount Ventures, Summit Holdings, Titan Industries, Nexus Corporation, Quantum Dynamics, Elite Capital, Prestige Ventures.

**Generic AI tech-company patterns:**
ByteFlow, CodeStream, DataVault, CloudNine, NeoTech, PixelDrive, VisionLabs, FutureMind, InnovatePro, TechWave, AppGenesis, SystemCore, DigitalEdge, CyberNova, AlphaCode, TechVortex, Nexus AI, Quantum AI, SynapseX, CloudMinds.

**Generic AI tech-product patterns:**
AuraCore, SilverMind, NexusFlow, DataCrest, CloudShift, PixelMaster, SonicWave, VortexEngine, TitanOS, PhoenixAI.

### Cliché Setups to Avoid

- Billionaire-saves-her-from-debt opening
- Billionaire-owns-the-company-she-just-applied-to opening (without fresh angle)
- She-spills-coffee-on-his-thousand-dollar-suit meet-cute
- He-bids-on-her-at-a-charity-auction setup (overused without subversion)
- She-is-his-brother's-ex setup (clichéd)
- Penthouse-elevator-where-he-presses-her-against-the-wall first-meeting
- The-jaded-billionaire-who-just-needs-to-meet-the-right-girl framing
- The-Cinderella-makeover-montage where the love interest is "transformed" by his money

### Title-Pattern Clichés to Avoid

Common billionaire-romance title patterns that have saturated:
- [Money word] + [emotion word]
- [Name] + [possession word]
- [Power word] + [intimacy word]
- [Billion / Rich / Wealth] + [Person descriptor]
- [Action verb] + [relationship descriptor]

Generate titles that feel fresh and category-distinctive rather than replicating these patterns.

### Description-Pattern Clichés to Avoid

For billionaire settings:
Red brick building, white picket fence, wraparound porch, bay windows, hardwood floors, exposed brick walls, industrial loft, glass-walled conference room, marble countertops, crystal chandeliers, Italian leather, Persian rugs, modern minimalist, sprawling penthouse, mahogany desk, leather-bound books.

For vehicles:
Black sedan, silver SUV, red convertible, [generic luxury-brand list].

For pet names:
Buddy (dog), Max (dog), Bella (dog/cat), Charlie (dog), Whiskers (cat), Mittens (cat), Shadow (cat), Daisy (dog), Rex (dog), Lucy (cat).

### Naming Considerations

**For character names:**
- Use names from different cultural backgrounds (authentically researched, not stereotyped)
- Mix common first names with unusual surnames and vice versa
- Consider historical names with specific period resonance
- Use family-history-inspired surnames rather than market-saturated patterns
- Avoid names that match the saturation lists above

**For business names:**
- Reference specific industry verticals (pharma research, B2B SaaS, real-estate development) with concrete-sounding names that suggest the actual work
- Avoid abstract aspirational names (Apex / Zenith / Pinnacle / Summit / Titan / Vertex)
- Consider founder-name + descriptor structures (e.g. "[Founder-Surname] Capital" or "[Founder-Initials] Holdings")
- Make the company name carry a specific business story; the name is part of the wealth-source authenticity

**For product names (if relevant):**
- Avoid abstract two-word combinations (Aura+Core, Cloud+Shift, etc.)
- Reference the specific product function with concrete language

## Comp Titles

### Canonical Reference Categories (foundational archetypes)

Billionaire romance has crystallised into a small number of canonical archetypes that define reader expectations. Use these as reference points for category positioning, not as templates to replicate:

- **The Corporate Billionaire archetype** — Fortune-500-style hero, board-pressure plot mechanics, working-class or mid-career professional love interest, contemporary urban setting, steamy heat
- **The Tech Mogul archetype** — younger founder, disruption-mindset, rapid-wealth psychology, often paired with activist or principled love interest, contemporary setting, scorching heat
- **The Old Money / Dynasty archetype** — inherited-wealth hero, formidable family matriarch, class-collision plot mechanics, working-class or artist love interest, often country-estate or Manhattan setting, steamy heat
- **The Dark Billionaire archetype** — morally gray wealth source, possessive register, criminal or near-criminal world, scorching heat, often blends with mafia romance conventions
- **The Secret Billionaire archetype** — wealth-reveal as turning point, trust-rebuilding arc, smaller-town or normal-life setting before reveal, steamy heat
- **The Paranormal Billionaire archetype** — supernatural wealth across centuries or worlds, mate-bond complications, often blends with vampire or werewolf romance, scorching heat

### Contemporary Reference Categories (current best-in-class)

The contemporary billionaire-romance market is shaped by:

- **Workplace-billionaire convergence** — corporate-romance fluency from contemporary romance has merged into billionaire romance; readers expect the workplace texture to be authentic
- **Heroine-agency emphasis** — recent reader and review trends emphasise non-billionaire agency far more than the early-2010s era; passive-Cinderella positioning is now a market disadvantage
- **Wealth-as-complication realism** — contemporary readers increasingly want the realistic complications of extreme wealth, not pure fantasy
- **Series interconnection** — multi-book series with anchored friend groups, family conglomerates, or business partnerships dominate the bestseller lists
- **High-heat normalisation** — steamy-to-scorching is the contemporary norm; clean billionaire romance is now a small niche

### Comp Title Discipline

When a project requires comp titles for marketing positioning:
- Use the comp set the user provides; the engine does not generate specific comp titles
- Comp titles must be current (within 18-24 months of the manuscript's publication target)
- Comp titles must match the project's specific subgenre, heat level, and trope cluster
- Three to five comps is the standard market-positioning set
- Comps anchor the reader's expectation of what the manuscript will deliver

### Differentiation Imperative

The billionaire-romance market is saturated. The manuscript must have at least one specific differentiator from its comp set:
- A subgenre blend (billionaire + paranormal, billionaire + activist setting, billionaire + neurodivergent lead)
- A specific industry the comp set hasn't worked (pharma, agritech, renewable energy, biotech)
- A specific power-dynamic angle (role-reversal, age-gap with female-as-billionaire, multi-cultural class collision)
- A specific structural choice (dual-timeline, epistolary elements, multi-POV including supporting cast)
- A specific voice register that diverges from the dominant market voice

The differentiator should surface in Phase 2 outline and remain visible across the manuscript's structure.

## Cover Design Specifications

### Recommended Visual Styles

Billionaire-romance covers signal the genre through specific visual conventions. Effective covers communicate at the thumbnail level whether the project is contemporary, dark, paranormal, or older-billionaire-archetype.

**Contemporary Billionaire (steamy):**
- Hero in tailored suit (jacket open, sleeves rolled, tie loosened to suggest accessibility under power)
- Architectural elements signalling wealth (penthouse window, skyline backdrop, executive desk silhouette)
- Heroine in elegant attire (cocktail dress, work-appropriate but stylish, gala-formal as variant)
- Colour palette: deep blacks and golds, navy and silver, burgundy and cream, cool blues with warm accents
- Typography: serif elegant for title, sans-serif modern for author name; avoid decorative or fantasy fonts

**Dark Billionaire (scorching):**
- Hero shadowed or partial-face (signals the darker register; full-face reveal is for cleaner registers)
- Heroine in colour while hero is in black-and-white (visual contrast signalling power dynamic)
- Atmospheric darkness (rain, shadow, urban-night context)
- Colour palette: blacks, deep reds, smoky greys, occasional gold accents
- Typography: heavy serif or modern sans-serif; avoid decorative or fantasy fonts

**Old Money / Dynasty Billionaire:**
- Estate / mansion / country-house architectural elements
- Heroine in classic-elegant attire (riding dress, vintage-inspired cocktail, period-formal)
- Heritage-suggesting visual texture (wood panelling, oil paintings, gardens)
- Colour palette: forest greens, deep blues, burgundy, gold, rich browns
- Typography: traditional serif; classical-sounding name treatment

**Tech Mogul / Modern Startup:**
- Hero in casual-luxury (henley, tailored chinos, hoodie-and-tie hybrids)
- Modern-architecture context (glass office, modern penthouse, beach-house tech-bro aesthetic)
- Heroine in contemporary-professional or creative-casual attire
- Colour palette: cleaner brights, blues, whites with accent colours, less "old money" texture
- Typography: modern sans-serif emphasised; clean type hierarchy

**Paranormal Billionaire:**
- Add supernatural visual cues (eyes that shouldn't be human, fang-tip suggestion, predatory pose)
- Hybrid contemporary-and-supernatural environment (penthouse with magical undertone)
- Colour palette: depending on supernatural type — cool blues for vampire, earthy tones for shifter, jewel tones for fae
- Typography: serif with slight gothic or fantasy texture; avoid pure fantasy register

### Genre Cover Aesthetics

- **Person-on-cover convention:** dominant in billionaire romance; thumbnail readability requires recognisable human focal point
- **Architectural-element convention:** secondary register (penthouse, skyscraper, desk silhouette) without person; works for series consistency
- **Couple-on-cover convention:** very common; both leads visible, often in embrace or near-embrace pose
- **Hands-only convention:** elegant variant (his expensive watch, her delicate hand in his); works for traditional-romance crossover

### Subgenre Variations

- **Office / Workplace billionaire:** business setting prominent; suit + power pose
- **CEO romance:** executive setting; corner-office or boardroom backdrop
- **Fake relationship billionaire:** the visual cue often involves contrasting elegance (gala-formal couple looking magazine-perfect with ironic edge)
- **Forced proximity billionaire:** confined-space cue (jet, yacht, snowed-in cabin)
- **Sports / business hybrid:** elements of both worlds visible (field-and-suit hybrid)
- **Dark / criminal billionaire:** shadowed; weapon or wealth-of-violence cue (signet ring, shadowed figure with cigar, urban-night register)

### Market Positioning

- Billionaire romance covers must clearly signal the heat level: cleaner books use covered or suggested-only intimacy; steamy books use suggestive proximity; scorching books use explicit body-language cues
- The cover must position the manuscript within its specific subgenre niche (contemporary CEO vs paranormal vs dark vs old-money) — generic billionaire-romance covers underperform specific positioning
- Series consistency is essential: each book in a connected series should carry shared visual elements (colour palette, type treatment, design grid) for instant recognition
- Cover-by-thumbnail test: the cover must communicate genre, heat level, and subgenre niche at 200x300 pixels in a vertical scroll feed

### Cover Design DON'Ts

- Generic stock-photo couple in a generic setting (the saturated-cover problem)
- Background that has nothing to do with billionaire register (rural / cottage / generic settings reduce category recognition)
- Title typography that signals fantasy or thriller rather than romance
- Heroine alone without any wealth-context cue (the cover doesn't tell the reader this is billionaire romance)
- Text-heavy cover with multiple subtitles, taglines, and series-numbering competing for attention
- Misalignment with heat level (steamy-cover register on a clean-content book; clean-cover register on a scorching-content book)
- Replicating exactly the visual conventions of the saturation lists in the Names & Patterns section
- Generic "billionaire-romance template" stock vendors — the cover must feel specific to the manuscript's unique angle
