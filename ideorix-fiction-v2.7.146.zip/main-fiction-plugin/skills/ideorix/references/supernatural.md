---
name: supernatural-genre
description: Genre-specific instructions for supernatural fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [paranormal]
---

# Supernatural. Genre Plugin

## Metadata
- id: supernatural
- name: Supernatural
- icon: ✨
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Dan Harmon Story Circle"]

## Subgenre Options
Present during setup:
- **Supernatural Thriller**. Fast-paced, high-stakes: supernatural elements driving a thriller plot with mystery, danger, and revelation
- **Supernatural Drama**. Character-driven: supernatural elements illuminate human relationships, grief, identity, and transformation
- **Angels & Demons**. Celestial warfare, divine intervention, cosmic moral stakes; the battle between forces beyond human understanding
- **Witchcraft & Occult**. Practised magic, ritual, covens, grimoires; power that is LEARNED and EARNED, not innate
- **Supernatural Mystery**. Whodunit meets the impossible: crimes or events that can't be solved without acknowledging the supernatural
- **Dark Supernatural**. The supernatural as fundamentally hostile: malevolent entities, possession, curses, corruption; close to horror but with more agency for the protagonist

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Revelation rhythm. each chapter reveals more about the supernatural world, with momentum building as the protagonist gains understanding (and enemies)
- Must open with: The natural world with a crack in it. a moment where reality hiccups, something doesn't add up, or a character demonstrates awareness of the hidden layer

BEATS PER CHAPTER
1. The Veil Beat. The boundary between the ordinary and the supernatural is felt: a shimmer, a wrongness, a moment of awareness
2. The Power Beat. Supernatural ability or force is used, observed, or resisted; the reader sees the rules in action
3. The Cost Beat. Every supernatural act has a price: physical, emotional, moral, or relational
4. The Lore Beat. The rules of the supernatural world are revealed, demonstrated, or tested
5. The Stakes Beat. What's at risk becomes clearer: a soul, a life, a community, the balance between worlds

THE SUPERNATURAL ARCHITECTURE
- There are TWO WORLDS: the ordinary and the supernatural, and the tension between them drives the story
- The supernatural has RULES: consistent, discoverable, and consequential; not arbitrary magic
- POWER has a PRICE: every supernatural ability costs something (energy, sanity, years of life, relationships, humanity)
- The VEIL is variable: thin in some places/times, thick in others; this geography of access matters
- BELIEF matters: whether characters believe in the supernatural affects their vulnerability and their power
- The supernatural world has its own POLITICS: factions, hierarchies, alliances, and enemies
- SCALE: supernatural stories escalate from personal to cosmic (a haunting → a war → a reckoning)
- POV: Third person past (classic, allows scope) or first person (intimate, good for single-protagonist stories)

THE RULES SYSTEM
- Establish the rules EARLY through demonstration, not exposition
- Every rule has an EXCEPTION (and the exception drives the plot)
- Characters learn the rules at the same pace as the reader
- The protagonist's growth is measured in MASTERY of the rules
- Villains exploit the rules differently: they know loopholes the protagonist doesn't

THE TWO-WORLD STRUCTURE
- The ordinary world: fully realised, grounded, specific
- The supernatural world: has its own geography, inhabitants, and culture
- The threshold: how characters cross between worlds (ritual, location, time, emotional state, near-death)
- The cost of crossing: what it takes from you each time
- The bleed: supernatural elements leaking into the ordinary world (and vice versa)

FORBIDDEN IN SUPERNATURAL
- Rules-free magic (if anything can happen, nothing matters)
- The supernatural as window-dressing on an otherwise mundane story
- Power without cost (supernatural abilities must have a price)
- Instant mastery (the protagonist should struggle to learn and control their abilities)
- Explaining everything (some mystery should remain; the supernatural shouldn't be fully domesticated)
- Inconsistent rules (if iron hurts faeries in chapter 3, it hurts them in chapter 12)
- The supernatural as entirely benign or entirely malevolent (complexity is essential)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (encounter intensity), Captivation (atmosphere), Anticipation (next manifestation).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Third person past (allows the scope supernatural fiction needs) or first person past
- Voice: Alert, slightly heightened. the voice of someone who perceives a layer of reality most people don't
- Tone: Wonder and menace balanced; the supernatural is BOTH beautiful and dangerous
- Register: Contemporary and clear, with moments of elevated language when describing the supernatural

PROSE IMPERATIVES
- THE TWO-LAYER REALITY: prose should convey the double vision of a character who sees both worlds
  - The mundane surface: a park, a street, a building
  - The supernatural substrate: the energy, the presence, the thin place, the watching
  - The skill is rendering BOTH simultaneously without the prose becoming cluttered
- SENSORY DIFFERENTIATION: the supernatural feels different from the ordinary
  - Temperature: supernatural presence often manifests as cold, heat, or a tingling chill
  - Sound: frequencies at the edge of hearing, silence that presses, music from no source
  - Sight: auras, shadows that move wrong, lights that shouldn't be there, the double-image of seeing both worlds
  - Taste/Smell: ozone, copper, sweetness, decay. the supernatural has its own chemistry
- POWER PROSE: when supernatural abilities are used, the prose should convey the EXPERIENCE
  - It feels like something: heat in the chest, buzzing in the skull, the sensation of reaching with a limb you don't have
  - It costs something: the immediate physical price (exhaustion, nosebleed, pain) described in the moment
  - It looks like something: not just a vague glow, but a specific visual manifestation
- THRESHOLD PROSE: the moment of crossing between worlds is significant
  - The transition should be FELT: a sensation of falling, thinning, dissolution, compression
  - The other world has its own sensory palette (colours are different, gravity feels different, time moves differently)

PROSE RHYTHM MAPPING
- CH 1 HOOK: The natural world with one WRONG detail. Open with grounded, ordinary prose.
  then one sentence that doesn't belong. A detail the reader almost skips. Almost.
- GROUNDED RHYTHM: Normal prose runs at 15-20 word sentences. Clear. Specific. The world
  the reader recognises. coffee shops, streets, weather, routine. This is the baseline.
- SUPERNATURAL BEATS: 5-10 words, isolated, stark. Set apart. "The light moved." "The air
  tasted of iron." "Something watched." These sentences break the grounded rhythm like a stone
  through glass. No explanation. No elaboration. The wrongness stands alone.
- THE CONTRAST IS THE SCARE: The gap between normal-length prose and supernatural-short prose
  creates the uncanny. The wider the gap, the more unsettling the effect. A full paragraph
  of mundane detail, then: "The temperature dropped." That sentence does the work.
- TENSION FLOOR: Never below 6. Even fully grounded scenes carry one off-note. a word choice
  that doesn't quite fit, a sensory detail at the edge of perception, a sentence slightly
  shorter than the others. The reader feels it before they identify it.
- SENSORY INTRUSION: Supernatural presence registers through specific sensory disruption:
  - Temperature drops (sudden, localised, wrong)
  - Unexplained sounds (frequencies at hearing's edge, silence that presses)
  - Peripheral movement (gone when you look directly)
  - Taste/smell: ozone, copper, sweetness with no source
- ESCALATION THROUGH RHYTHM: Early chapters: one supernatural beat per scene, buried in normal
  prose. Midpoint: supernatural beats cluster, normal prose shrinks. Climax: the rhythms merge.
  every sentence carries both layers, the veil between normal and supernatural dissolved.
- THRESHOLD RHYTHM: When characters cross between worlds, the prose itself transitions.
  grounded sentence structure dissolving into something stranger. Syntax loosens. Sensory
  details shift register. The reader should feel the crossing in the prose before it is named.
- PARAGRAPH ARCHITECTURE: Ground the reader in a solid, normal-length paragraph. Then deliver
  the supernatural beat as a standalone line. The isolation of that line on the page IS the veil thinning.

SUPERNATURAL DESCRIPTION
- Describe the supernatural through its EFFECTS on the natural:
  WRONG: "She used her powers to scan the room for supernatural energy."
  RIGHT: "She let her awareness soften, and the room shifted. The walls were the same. peeling paint, water stain above the window. but now she could see the residue. Something had been here. Something that left the air tasting of iron and made the lightbulb in the hallway pulse like a heartbeat."
- The supernatural should feel INTRUSIVE: it doesn't belong in the natural world, and its presence creates friction
- Scale matters: a minor supernatural event is subtle (a flicker, a chill); a major one overwhelms (the room shakes, reality distorts)

DIALOGUE CRAFT
- Characters discussing the supernatural should sound like REAL PEOPLE trying to describe the indescribable
- Technical supernatural language: covens, practitioners, and scholars have terminology that feels earned, not invented
- Sceptics: their dialogue should be intelligent, not straw-man
- The supernatural voice: when entities speak, they should feel fundamentally different (older, stranger, operating from different values)
- Information exchange: characters teach each other (and the reader) through practical conversation, not lectures
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

SUPERNATURAL CRAFT (40% of total):
- The supernatural has consistent, discoverable rules? (0-100)
- Power has a genuine cost (physical, emotional, moral)? (0-100)
- The ordinary and supernatural worlds are both fully realised? (0-100)
- The veil/threshold between worlds is felt and consequential? (0-100)

STORY CRAFT (30% of total):
- The protagonist's growth is tied to mastering the supernatural? (0-100)
- Stakes escalate from personal to larger scope? (0-100)
- The supernatural world's politics/factions drive the plot? (0-100)
- The resolution uses the rules established throughout? (0-100)

PROSE QUALITY (30% of total):
- Two-layer reality is conveyed without clutter? (0-100)
- Supernatural events are described through sensory effects? (0-100)
- Power use is experiential (felt, not just described)? (0-100)
- Threshold moments are significant and immersive? (0-100)

AUTOMATIC FAILS (score = 0):
- Supernatural rules are inconsistent or absent
- Power has no cost (abilities are free and unlimited)
- The supernatural is purely decorative (the story works without it)
- Instant mastery (protagonist is immediately powerful)
- Everything is explained (no remaining mystery or wonder)
- The ordinary world is underdeveloped (no grounding for the supernatural)
```

## Continuity Rules

```
SUPERNATURAL CONTINUITY. WHAT TO TRACK

THE RULES SYSTEM:
- Every established rule: what the supernatural can do, what it can't, what it costs
- Exceptions: any rule-breaking, who did it, and what it cost
- New rules: when discovered, by whom, and how they relate to existing rules
- Violations: if rules are broken accidentally, track consequences

POWER STATE:
- Each character's supernatural abilities: what they can do, their skill level, their limits
- Power costs: what has been spent and what condition the character is in
- Growth: when abilities were learned, practised, and mastered
- Artefacts: supernatural objects, their properties, their location, their condition
- Rituals: components needed, steps required, timing constraints

THE TWO WORLDS:
- Veil thickness: which locations are thin places, when the veil is weakest
- Crossings: who has crossed, when, and what it cost them
- Bleed: supernatural effects in the ordinary world (and ordinary intrusions in the supernatural)
- Geography: the supernatural world's layout, landmarks, and territories

FACTION STATE:
- Supernatural factions: who they are, what they want, who leads them
- Alliances: who is allied with whom, and the terms
- Enemies: who opposes whom, and why
- The protagonist's position: which factions they're aligned with or targeted by
- Political shifts: how events have changed the balance of power

KNOWLEDGE STATE:
- What the protagonist knows about the supernatural (in order of discovery)
- What each faction knows (and what they're keeping secret)
- Lore: myths, histories, and prophecies. what's been revealed and what's still hidden
- Misconceptions: wrong beliefs that haven't been corrected yet

PHYSICAL STATE:
- Supernatural damage: injuries from power use, entity attacks, threshold crossing
- Accumulated cost: the long-term toll of supernatural involvement
- Marks or changes: physical manifestations of supernatural contact (scars, altered eyes, aging)
- Recovery: how characters heal from supernatural trauma (which may require supernatural means)
```

## Character Rules

```
SUPERNATURAL CHARACTER TYPES

THE PROTAGONIST (THE AWAKENED):
- Has recently become aware of the supernatural (or is being pulled back after trying to leave)
- Their primary ability is specific and limited (not a generalist. a medium, a seer, a warden, a healer)
- They learn through failure: each mistake teaches them a rule
- Their ordinary life is their anchor. and it's being eroded by their supernatural involvement
- The moral dimension: their power gives them responsibility they didn't ask for
- Their relationship with the supernatural evolves: fear → curiosity → ability → burden → acceptance

THE MENTOR:
- Has walked this path before and bears the scars
- Provides guidance but not complete answers (they have their own agenda or limitations)
- Their power is greater but their time/health may be limited
- They withhold information for reasons that are eventually revealed (protection, shame, strategy)
- The mentor's past failure is often connected to the current threat

THE ANTAGONIST (THE CORRUPTED / THE ANCIENT):
- Uses the same rules as the protagonist but has gone further (at greater cost)
- Their motivation is understandable: they want power, survival, revenge, love, or a world remade
- They represent what the protagonist COULD become if they go too far
- They know rules and shortcuts the protagonist hasn't discovered yet
- They may not be entirely wrong: their critique of the status quo may be valid

THE SCEPTIC (THE ANCHOR):
- A friend, partner, or ally who grounds the protagonist in the ordinary world
- Their scepticism is not stupidity. it's rational self-preservation
- They provide emotional ballast when the supernatural threatens to overwhelm
- If they witness the supernatural, their reaction is a key dramatic beat
- They may be at risk: the protagonist's enemies may target them

THE ENTITY:
- A non-human supernatural being (angel, demon, spirit, fae, elemental, etc.)
- Operates from non-human values: their morality is alien, not simply evil
- They are MORE than human in some ways and LESS in others
- Communication is imperfect: they think differently, perceive differently, prioritise differently
- Their interest in the protagonist is specific and potentially dangerous

VOICE DIFFERENTIATION:
- The protagonist: increasingly bilingual between ordinary and supernatural registers
- The mentor: authoritative, cautious, with the weight of experience
- The antagonist: seductive, logical, offering a coherent alternative worldview
- The sceptic: grounded, practical, sometimes frustratingly dismissive
- The entity: strange. syntax, priorities, and emotional register all slightly OFF
```

## Arc Rules

```
SUPERNATURAL STORY STRUCTURE

ACT 1: THE AWAKENING (first 25%)
- Establish the ordinary world: the protagonist's normal life, fully realised
- The first crack: a supernatural event that can almost be explained away
- The second event: undeniable, frightening, and personally relevant
- The mentor appears (or is sought out): context is provided, but not complete understanding
- The rules begin: the protagonist's first lesson in how the supernatural works
- END OF ACT 1: The protagonist accepts the supernatural is real and commits to engaging with it

ACT 2A: THE EDUCATION (to midpoint)
- The protagonist learns: abilities are developed, rules are discovered, alliances are formed
- The supernatural world opens up: its scope, its inhabitants, its beauty and danger
- Each lesson has a cost: physical, emotional, relational
- The ordinary world recedes: the protagonist's normal life is increasingly disrupted
- The antagonist's presence is felt: their agents, their effects, their power
- MIDPOINT: The protagonist's power reaches a threshold. and something goes wrong (unintended consequences, discovery by the antagonist, a rule they didn't know)

ACT 2B: THE RECKONING (midpoint to dark moment)
- The antagonist acts: directly, powerfully, targeting what the protagonist values
- The mentor fails or falls: the protagonist loses their guide
- The ordinary world is threatened: the bleed between worlds puts normal people at risk
- The protagonist must make moral choices: how much cost will they accept? Who will they sacrifice?
- Their own power is not enough: they need allies, knowledge, and sacrifice
- DARK MOMENT: The protagonist's power is turned against them, or the cost of their abilities is revealed to be far greater than they knew

ACT 3: THE CONFRONTATION (final 25%)
- The protagonist uses everything they've learned: rules, alliances, and hard-won understanding
- The final battle uses the supernatural system creatively: not just more power, but cleverer application
- The cost of victory is real: something is permanently sacrificed
- The balance between worlds is addressed: restored, changed, or deliberately broken
- The protagonist's place in the supernatural world is established
- The ordinary world: the protagonist returns to it changed, or the worlds have changed around them

SUPERNATURAL PACING:
- ACT 1: Discovery pace. each chapter introduces something new
- ACT 2A: Training pace. building competence with setbacks
- ACT 2B: Escalation pace. threats multiply, resources diminish
- ACT 3: Sprint. the climax uses EVERY rule and relationship established
```

## Timeline Rules

```
SUPERNATURAL TIMELINE

POWER DEVELOPMENT TIMELINE:
- Track the protagonist's ability growth: when each skill was learned, practised, and mastered
- Power costs accumulate: track the cumulative toll
- Abilities have cooldowns or limits: track usage and recovery
- Milestone moments: when the protagonist achieves something new

VEIL CALENDAR:
- Certain times are significant: solstices, equinoxes, full moons, specific dates
- The veil thins on a schedule: track when supernatural activity is stronger
- Ritual timing: some actions can only be performed at specific times
- Deadline: if there's a prophetic date or time-limited goal, track the countdown

FACTION TIMELINE:
- When factions learn about the protagonist
- When alliances shift or break
- When antagonist actions occur relative to protagonist actions
- Political manoeuvres: who contacted whom, when, with what offer

ORDINARY WORLD TIMELINE:
- The protagonist's mundane obligations: work, family, appointments
- How long they've been away from normal life
- When other characters last saw them acting normally
- The cover story: what explanation has been given for their absences
```

## Genre-Specific Craft Techniques

Supernatural fiction (distinct from paranormal, urban
fantasy, or horror) is the genre where supernatural
elements operate as established part of the protagonist's
world rather than as intrusion (paranormal) or genre
register (urban fantasy) or threat (horror). The
protagonist often has supernatural ability, knowledge, or
contact, and the genre's craft is in rendering the
double-layered reality (ordinary + supernatural) with
specific texture, internally consistent rules, and
visible cost. The canonical roster — Charles de Lint
(the Newford books), Neil Gaiman (American Gods,
Anansi Boys, Neverwhere), Susanna Clarke (Jonathan
Strange & Mr Norrell, The Ladies of Grace Adieu), Tim
Powers (Last Call, Declare), Charles Stross (the
Laundry Files, the Merchant Princes), Mike Carey (the
Felix Castor novels), Ben Aaronovitch (the Rivers of
London series), Lev Grossman (the Magicians trilogy) —
established the form; the contemporary masterclass
roster — V.E. Schwab (the Shades of Magic, the Cassidy
Blake / City of Ghosts, the Addie LaRue), N.K. Jemisin
(The City We Became, the Inheritance trilogy in
supernatural register), Cassandra Khaw, P. Djèlí Clark
(the Dead Djinn Universe), Akwaeke Emezi (Pet,
Freshwater, Bitter), Rivers Solomon, Tochi Onyebuchi,
Maria Dahvana Headley, Carmen Maria Machado, T.
Kingfisher, Rebecca Roanhorse, Suyi Davies Okungbowa,
Premee Mohamed, Kelly Link — has expanded the genre's
range to post-colonial, queer, diasporic, and folkloric
registers that the canonical roster historically
underweighted. The most common failure modes in this
register are: **Magic-as-Convenience** (supernatural
ability deployed as plot solution without consistent
cost or limitation; the protagonist gains powers when
the plot requires them); **Worldbuilding-as-Exposition**
(supernatural rules delivered through narrator-as-
historian or character-as-tour-guide rather than
through experience); **Two-World Imbalance** (either
the ordinary world erased so the supernatural is the
manuscript's only register, or the supernatural so
diluted by the ordinary that it has no specific
weight); **Generic-Magic Architecture** (supernatural
elements interchangeable with any other genre's magic
— not specifically named, located, sourced, or
constrained); **Power-Inflation** (the protagonist's
ability grows beyond what the manuscript can
narratively constrain; tension collapses as power
exceeds problem); **Cosmology-Drift** (the rules of
what supernatural beings exist, what they can do, who
governs them, shift across the manuscript without
acknowledgement); **Cultural-Tourism-Magic** (sampling
folkloric or mythological traditions across multiple
cultures without specific committed research); **Rules-
Without-Consequence** (rules announced but not
enforced; the cost ledger that does not actually cost
anything); **Sceptic-Erasure** (no character holds the
sceptical position; the supernatural is universally
accepted within the manuscript without the friction
that would make it interesting); and **Learning-Curve
Skip** (the protagonist gains supernatural knowledge or
ability faster than the manuscript has earned). The
techniques below — three preserved (Double Vision,
Cost Ledger, Rules Reveal) and three added (Specific-
Cosmology Architecture, Power-Limit Discipline, Cultural-
Source Specificity) — are designed to keep the genre's
defining commitments live: rules consistent and costed,
cosmology specific, learning earned through experience.

### The Double Vision

Supernatural characters see two layers of reality simultaneously:

```
The café was ordinary. Espresso machine hissing, a couple
arguing about parking, the barista wiping down the counter
with practiced boredom. All of that was true. But underneath
it. or behind it, or beside it. she could feel the ward
carved into the threshold. Old work. A generation old at least.
The espresso machine sat on a ley line intersection, which
explained why the coffee was so good and the owner was always
tired. The arguing couple had something between them. a
thread of light connecting their chests. that pulsed brighter
when they raised their voices. Love, she thought. Still love.
Just angry.

Layer 1: Ordinary reality (what anyone would see)
Layer 2: Supernatural substrate (what the protagonist perceives)
Both layers are TRUE. Both layers are SPECIFIC.
```

### The Cost Ledger

Every supernatural act should have a visible price:

| Power Used | Immediate Cost | Cumulative Cost |
|------------|---------------|-----------------|
| Seeing the hidden | Headache, nosebleed | Deteriorating eyesight |
| Healing | Exhaustion, felt pain | Shortened lifespan |
| Warding | Materials consumed, time | Constant vigilance |
| Combat magic | Physical damage mirror | Emotional numbing |
| Crossing the veil | Disorientation | Loosening grip on reality |

The reader should always know what the protagonist is spending.

### The Rules Reveal

Introduce supernatural rules through EXPERIENCE, not exposition:

```
WRONG (exposition):
"She explained that all supernatural entities are
vulnerable to iron, that wards must be drawn in salt
mixed with ash, and that the veil is thinnest at crossroads."

RIGHT (experience):
She swung the iron poker and the thing SCREAMED. a
sound like glass in a blender. and scrambled back,
leaving a smoking handprint on the floor. Iron. She
filed that away. Iron WORKED.
```

The protagonist learns by doing. The reader learns with them.

### Supernatural Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "forces beyond mortal comprehension" | Show the specific force through its specific effect |
| "the supernatural world lurked beneath the surface" | Show the specific beneath-the-surface detail |
| "chosen by forces greater than herself" | Show the specific selection event |
| "the battle between good and evil" | Show the specific confrontation between specific characters |
| "ancient prophecies coming true" | Show the specific prophecy line and the specific current event |
| "supernatural powers awakened" | Show the specific trigger and specific first manifestation |
| "the darkness was alive" | Show the specific movement or sound in the darkness |
| "a weapon against the supernatural" | Show the specific weapon and how it specifically works |
| "the price of supernatural power" | Show the specific cost. health, memory, relationships |
| "the chosen one" | Show why THIS person through their specific actions |
| "destiny awaited" | Show the specific event that forces action |
| "the magical community" | Name the specific community (named tradition, named region, named lineage) |
| "she felt the pull of the supernatural" | Show the specific physical sensation through specific named modality |
| "ancient wards weakened" | Show the specific ward, the specific weakness, the specific evidence |
| "magic flowed through her" | Show the specific physical sensation and specific named cost |
| "the spirits whispered warnings" | Cut "spirits"; show ONE specific entity, ONE specific warning, ONE specific medium |
| "the veil grew thin" | Show the specific evidence (specific phenomenon in this scene) |
| "she could feel the magic" | Show what specifically her body, mind, or sensorium registers |

### The Specific-Cosmology Architecture

The Generic-Magic Architecture and Cosmology-Drift
failure modes produce supernatural elements
interchangeable with any other genre's magic. The
Specific-Cosmology Architecture is the requirement that
the manuscript's supernatural framework be specifically
named, sourced, internally hierarchical, and consistent
across the manuscript.

```
PRINCIPLE
The cosmology must be rendered through at least four of
the following five specifics:
1. NAMED TRADITION OR SOURCE — the cosmology draws
   from a specifically named tradition (Yoruba Ifa,
   Norse seiðr, Celtic Otherworld, Vodun loa, Jewish
   Kabbalah, Slavic folk-belief, Catholic
   demonology, Hermetic alchemy, Theosophical
   architecture, Buddhist cosmology, Indigenous
   traditions named with specificity) or a writer-
   constructed cosmology with explicitly named
   logic
2. NAMED CATEGORIES OF BEINGS — the supernatural
   population is specifically classified (specific
   spirit categories, specific entity hierarchies,
   specific mortal-vs-other boundaries); not "spirits"
   but the specific named types
3. NAMED RULES OF GOVERNANCE — what authority operates
   in the supernatural world; named courts, councils,
   pantheons, hierarchies; what the rules of conduct
   are; what happens when rules are broken
4. NAMED RULES OF MAGIC — what magic costs, what
   magic cannot do, what the specific limits are;
   the cost ledger rendered with consistency across
   the manuscript
5. NAMED HISTORICAL POSITION — the cosmology has its
   own history; specific past events, specific
   conflicts, specific periods that produced the
   present configuration

CALIBRATION TEST
- Could the manuscript's cosmology be replaced with
  another generic supernatural framework without
  losing anything specific? If yes — rebuild.
- Are at least four of the five axes rendered through
  specific named detail?
- Does the cosmology shape character options
  materially across the manuscript?
- Is the cosmology consistent chapter to chapter?
If any answer is no — rebuild for cosmological
specificity.

ANTI-PATTERN
- "The supernatural world" as undifferentiated mass
- "Spirits" / "demons" / "ghosts" as generic
  categories without specific named subtypes
- The protagonist who can do whatever the plot
  requires because "magic"
- Rules announced but not enforced when inconvenient
- Cosmology drift (the rules in chapter 3 stop
  applying in chapter 17)
```

### The Power-Limit Discipline

The Power-Inflation failure mode is the genre's most
common late-manuscript collapse: the protagonist's
ability grows beyond what narrative tension can
constrain. The Power-Limit Discipline is the
requirement that supernatural ability operate within
specific named limits that the manuscript honours.

```
PRINCIPLE
For every supernatural ability the protagonist or
significant other characters possess, the manuscript
must specify at least three of the following four
limit categories:
1. SCOPE LIMITS — what the ability can and cannot do;
   specific named exclusions (cannot affect iron,
   cannot operate at distance, cannot read minds,
   cannot heal mortal wounds, cannot revive the
   dead)
2. ENERGY LIMITS — what the ability requires to
   operate; the cost in fatigue, blood, life-force,
   relationships, sanity, time; the specific
   recovery requirement
3. CONDITIONAL LIMITS — when the ability can operate
   (specific times, specific locations, specific
   states of mind, specific permissions, specific
   ritual requirements)
4. MORAL / EXISTENTIAL LIMITS — what the protagonist
   refuses to do with the ability even when capable
   (the line they hold, the cost they will not
   pay, the violation they will not commit)

CALIBRATION TEST
- For every supernatural ability deployed in the
  chapter, can the reader name its specific limits?
- Do limits actually constrain the protagonist
  rather than yielding when the plot requires?
- Does the protagonist's ability across the
  manuscript stay within established limits, or
  does power inflation occur?
- Does the protagonist sometimes refuse to use
  available ability because of moral limit?
If any answer is no — rebuild for limit
specificity.

ANTI-PATTERN
- The protagonist who gains new abilities exactly
  when the plot requires
- Limits announced in early chapters and quietly
  abandoned in late chapters
- The "I didn't know I could do that" reveal that
  produces convenient new capability
- Power that scales without compensating cost-
  scaling
- The protagonist who never refuses to use
  available ability
```

### The Cultural-Source Specificity

The Cultural-Tourism-Magic failure mode produces
supernatural cosmologies that sample tropes from
multiple cultures without specific committed research.
The Cultural-Source Specificity is the requirement
that any cosmology drawing from specific cultural or
folkloric traditions render those sources with
research-specific care, attribution where appropriate,
and refusal of generic-fantasy default.

```
PRINCIPLE
For every cultural or folkloric source the manuscript
draws from, the writer must satisfy at least three of
the following four specifics:
1. NAMED CULTURE / TRADITION — the source is
   specifically named (Yoruba, Igbo, Akan, Haitian
   Vodou, Mexican Curanderismo, Ashkenazi Jewish,
   specific Indigenous nation, specific Pagan
   tradition); the manuscript does not collapse
   distinct traditions into generic "African
   magic" or "Native American spirituality" or
   "Eastern mysticism"
2. RESEARCHED-SPECIFIC RENDERING — the manuscript
   renders specific named entities, specific named
   rituals, specific named cosmological features
   with detail that demonstrates the writer has
   engaged specific sources
3. CULTURAL POSITIONING — the writer's position
   relative to the tradition is appropriate; if
   drawing from a tradition the writer is not
   from, the manuscript demonstrates respectful
   engagement; if the tradition is endangered or
   contested, the manuscript handles it with
   particular care
4. AVOIDANCE OF EXOTICISM — the tradition is not
   rendered as exotic-other for the writer's
   protagonist's perspective; the tradition's
   internal logic is rendered as legitimate and
   coherent within itself, not as strange-from-
   outside

CALIBRATION TEST
- For every cultural source, is the named tradition
  specifically identifiable?
- Does the manuscript's rendering demonstrate
  research-specific engagement?
- Is cultural positioning handled appropriately?
- Does the manuscript avoid exoticism?
If any answer is no — rebuild for source specificity.

ANTI-PATTERN
- Generic "African magic" / "Eastern mysticism" /
  "Native American spirituality" as undifferentiated
  source categories
- Sampling tropes from multiple traditions
  interchangeably
- The protagonist who is the outsider-discoverer of
  a tradition the manuscript otherwise treats as
  decorative
- Rituals named but not specifically rendered
- The endangered or contested tradition treated
  with the same lightness as a fictional cosmology
```

## Genre-Specific Revision Rules

### Six-Pass Supernatural Audit (Run FIRST in editorial pipeline)

The Supernatural Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Rules Consistency Pass

Verify all supernatural events follow established rules,
and that any new rules introduced are consistent with
the existing system. The Cosmology-Drift failure mode
is caught here. has a rule been broken? If so, is
there a consequence rendered in the manuscript? Are
new abilities or beings introduced with proper grounding
in the established cosmology, or do they appear as
plot-convenience additions? The Specific-Cosmology
Architecture provides the load-bearing spec — at least
four of the five axes (named tradition / named beings
/ named governance / named rules / named history)
should be operative.

#### Pass 2: Cost Pass

Verify every use of supernatural power carries visible
cost per the Cost Ledger. The Magic-as-Convenience and
Rules-Without-Consequence failure modes are caught
here. is the cumulative toll tracking across chapters?
Is the protagonist's condition worsening appropriately
when ability is exercised at significant scale? The
Power-Limit Discipline provides additional spec — at
least three of the four limit categories (scope /
energy / conditional / moral) should constrain each
ability the protagonist or significant characters
possess. The Power-Inflation failure mode is also
caught here. if the protagonist's ability has grown
beyond what narrative tension can constrain, rebuild.

#### Pass 3: Two-World Balance Pass

Verify the ordinary world is still present and
relevant, and that the supernatural world is
specifically rendered. The Two-World Imbalance failure
mode is caught here. has the ordinary world been
erased so the supernatural is the manuscript's only
register? Or has the supernatural been so diluted by
the ordinary that it has no specific weight? The
Double Vision technique is the load-bearing tool: both
layers should be active and specific, with the
protagonist seeing both simultaneously and the reader
feeling the friction between them.

#### Pass 4: Learning Curve Pass

Verify the protagonist's knowledge is consistent with
what they've experienced. The Learning-Curve Skip
failure mode is caught here. has the protagonist
gained supernatural knowledge or ability faster than
the manuscript has earned? Is their skill level
appropriate for this point in the story (not too
powerful, not too weak)? Is the reader's understanding
keeping pace through experience-based reveals (Rules
Reveal) rather than exposition dumps?

#### Pass 5: Sensory Differentiation Pass

Verify the supernatural is rendered through specific
sensory effects rather than abstract claim. Are power
descriptions experiential (felt, not just narrated)?
Can the reader distinguish supernatural moments from
ordinary ones through specific sensory texture? Does
each supernatural manifestation have its own specific
signature (specific cold, specific smell, specific
sound, specific visual register, specific bodily
response)? Generic supernatural sensation must be
rebuilt for specificity.

#### Pass 6: Specific-Cosmology + Power-Limit + Cultural-Source Integration

This pass is the supernatural integration check — it
ties the new techniques together and verifies the
manuscript honours the genre's defining commitments at
the manuscript level.

For SPECIFIC-COSMOLOGY: confirm Pass 1's spec at the
manuscript level. Is the cosmology rendered with at
least four of the five axes? Is it consistent across
the manuscript with no drift?

For POWER-LIMIT: confirm Pass 2's spec at the
manuscript level. Are limits actually constraining the
protagonist across the manuscript? Has power inflation
been avoided? Does the protagonist sometimes refuse to
use available ability because of moral limit?

For CULTURAL-SOURCE: if the manuscript draws from
specific cultural or folkloric traditions, audit the
specificity. Are named cultures specifically rendered
with research-specific detail? Has cultural-tourism-
magic been avoided? Is the writer's position relative
to traditions handled appropriately, particularly for
endangered or contested traditions? The Sceptic-
Erasure failure mode is also caught here. if no
character holds the sceptical position, the manuscript
has lost the friction that makes supernatural fiction
interesting.

## Names & Patterns to Avoid

### Supernatural Character Names. NEVER USE
- Fantasy-coded names in a modern setting: Seraphiel, Nyx, Raven, Ember
- Names that telegraph supernatural status: Mr. Graves, Luna Nightshade, Damien Cross
- Urban fantasy cliché names: Dresden (taken), Constantine (taken)

### Supernatural Location Names. NEVER USE
- "The [Supernatural] [Building]": The Witch's Cottage, The Demon Bar, The Angel Archive
- Overly portentous place names: The Convergence, The Nexus, The Threshold
- Generic "hidden world" names: The Underworld, The Other Side, The Beyond

### Use Instead
- Ordinary names for extraordinary characters (the most powerful witch is named "Susan")
- Real-feeling place names: the supernatural bar is just called "Quinn's" but everyone in the know goes there
- Supernatural entities may have true names that are older, stranger, and harder to pronounce
- The supernatural world's locations should have names that feel NATIVE to that world, not translated for the reader

## Comp Titles

Supernatural fiction's comp-title set supports
manuscript positioning: market category placement,
cover-design conversation, reader-expectation
calibration, similar-author discovery, and editorial
/ agent submission framing.

### Canonical (foundational reference points)

- *Memory and Dream* — Charles de Lint (1994): the Newford books; modern supernatural-fiction template.
- *American Gods* — Neil Gaiman (2001): the genre-defining literary-supernatural benchmark.
- *The Anubis Gates* — Tim Powers (1983): occult-supernatural literary benchmark.
- *Last Call* — Tim Powers (1992): Las-Vegas-card-magic supernatural lineage.
- *Jonathan Strange & Mr Norrell* — Susanna Clarke (2004): atmospheric historical-supernatural benchmark.

### Contemporary (current best-in-class)

- *The Magicians* — Lev Grossman (2009): the trilogy; literary supernatural-fantasy crossover.
- *Rivers of London* — Ben Aaronovitch (2011): British supernatural-procedural benchmark.
- *The Atlas Six* — Olivie Blake (2020): dark-academia-supernatural crossover.
- *The Library at Mount Char* — Scott Hawkins (2015): cult-favourite literary supernatural.
- *Cassidy Blake / City of Ghosts* — Victoria Schwab (2018-): YA contemporary supernatural.
- *The Ten Thousand Doors of January* — Alix E. Harrow (2019): literary portal-supernatural.
- *The Invisible Life of Addie LaRue* — V.E. Schwab (2020): immortal-supernatural literary benchmark.
- *Pet* — Akwaeke Emezi (2019): YA supernatural with utopia-with-shadow.

## Cover Design Specifications

### Recommended Visual Styles
- **Layered**. The cover shows both worlds: the ordinary surface with the supernatural visible through or beneath it; a street scene with a pentagram in the shadows, a person with an aura visible
- **Symbolic**. A single powerful symbol: a hand with fire, an eye with two pupils, a doorway between worlds; clean, bold, mysterious
- **Atmospheric**. A liminal space: twilight, a threshold, a crossroads, the moment between; the cover captures the BETWEEN-ness of the supernatural
- **Dynamic**. Energy and motion: a figure mid-action with supernatural effects visible; the cover promises pace and power

### Genre Cover Aesthetics
- **Styles:** Double-exposure effects showing two layers of reality, figures with visible supernatural elements (auras, marks, emanations), liminal spaces (doorways, crossroads, mirrors), symbolic objects charged with power (books, weapons, keys), dramatic lighting effects suggesting energy beyond the natural, urban settings with hidden magical elements
- **Colours:** Deep purples and midnight blues (the supernatural frequency), silver and white (celestial, spiritual), amber and gold (power, warmth, arcane), black with colour accents (the ordinary world with supernatural highlights), teal and cyan (energy, wards, barriers), red as accent (blood, sacrifice, passion)
- **Elements:** Symbols (pentagrams, runes, sigils, mandalas), energy effects (glows, arcs, emanations), thresholds (doors, gates, circles), natural elements charged with meaning (fire, water, iron, salt, moonlight), dual imagery (the thing and its supernatural reflection), hands (reaching, casting, warding)
- **Typography:** Clean, modern fonts with supernatural accent effects (a glow, a shimmer, a shadow that isn't quite right); the title should look normal at first glance and then slightly OFF; not fantasy scripts but contemporary fonts with a twist

### Market Positioning
Supernatural covers signal "the hidden world is real and dangerous" through layered imagery and otherworldly colour accents. Position against Butcher, Harris, Aaronovitch, Bennett, Schwab. The genre spans from urban fantasy to literary supernatural. match the sub-tone. At thumbnail size, the combination of a recognisable real-world setting with one clearly supernatural element creates immediate genre identification.

### Cover Design DON'Ts
- No generic fantasy imagery (dragons, swords, castles). supernatural is modern and urban-coded
- No cheesy glowing hands or lightning bolts (1990s urban fantasy aesthetic)
- No overtly religious imagery unless the story specifically engages with it
- No cute or humorous supernatural elements (black cats, pointy hats) unless the tone is comedic
- No muddy, indistinct colour palettes. supernatural covers need one clear otherworldly colour
- No overcrowded symbol-soup (one or two supernatural elements, not a dozen)
