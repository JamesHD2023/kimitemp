---
name: noir-genre
description: Genre-specific instructions for noir fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [crime]
---

# Noir. Genre Plugin

## Metadata
- id: noir
- name: Noir
- icon: 🌑
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Fichtean Curve"]

## Subgenre Options
Present during setup:
- **Classic Noir**. The original: a doomed protagonist, a femme fatale, a corrupt world; Chandler, Hammett, Cain territory; the style that named the genre
- **Neo-Noir**. Modern settings, classic noir sensibility: moral corruption, existential dread, style over sentimentality; updated for contemporary darkness
- **Country Noir**. Rural settings, same moral landscape: meth labs, dead-end towns, desperate people making worse choices; Daniel Woodrell territory
- **Suburban Noir**. The darkness behind the manicured lawns: domestic crime, neighbourhood secrets, the violence hidden in ordinary life; Gillian Flynn territory
- **Tech Noir**. Technology as the corrupting force: surveillance, hacking, digital exploitation; noir's paranoia amplified by the information age
- **Historical Noir**. A specific era rendered through noir's lens: Prohibition, post-war, 1970s. the period's particular corruption and moral decay

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Relentless forward motion with a sense of inevitable doom; the pace accelerates as the trap closes; no scene exists without advancing the protagonist's downfall
- Must open with: The protagonist already in trouble. or about to be; noir starts with the first wrong turn, not with stability

BEATS PER CHAPTER
1. Temptation Beat. Something the protagonist wants badly enough to make a bad choice; desire is the engine of noir
2. Complication Beat. The bad choice creates consequences that were predictable in hindsight but felt unavoidable in the moment
3. Deception Beat. Someone is lying, and the protagonist may or may not know; trust is the scarcest commodity
4. Atmosphere Beat. The world rendered in noir's particular visual and emotional register: shadow, rain, smoke, neon, moral darkness made physical
5. Doom Beat. The net tightens; the protagonist's options narrow; the reader feels the trap closing

NOIR ARCHITECTURE
- The PROTAGONIST is complicit: they're not a victim of circumstance but an active participant in their own destruction; their choices drive the plot
- DESIRE is the engine: what the protagonist wants (money, a person, escape, revenge) pulls them into darkness; the desire must be understandable
- The WORLD is corrupt: institutions, individuals, systems. nothing is clean; the protagonist can't appeal to justice because justice doesn't exist
- FATE is the governing force: noir is deterministic; once the first wrong turn is taken, the ending is inevitable; the pleasure is in watching the mechanism
- STYLE defines the genre: noir is the most stylistically distinctive genre; the prose IS the experience
- MORAL AMBIGUITY is total: there are no heroes, only degrees of corruption; the protagonist may be the least bad option
- The FEMME FATALE (or homme fatal) is optional but iconic: someone who weaponises attraction; they may be villain, victim, or both
- POV: First person past (the classic. the doomed narrator looking back) or tight third past

THE NOIR TRAP
- The trap must be VISIBLE to the reader before the protagonist sees it
- Each chapter should close one escape route
- The protagonist's best qualities (loyalty, desire, ambition) are what doom them
- The irony is structural: the thing they want most is the thing that destroys them
- By the midpoint, the reader should feel "there's no way out". and be right

FORBIDDEN IN NOIR
- Happy endings (noir is tragedy; at best, the protagonist survives diminished)
- Righteous heroes (everyone's hands are dirty)
- Moral certainty (the moment anyone is clearly "right," it's not noir)
- The cavalry arriving (no one is coming to help; the institutions are compromised)
- Coincidences that save the protagonist (fate in noir only works against you)
- Sentimentality (noir is ruthless about emotion; tenderness exists only to be exploited)
- Exposition-heavy prose (noir's voice is lean, sharp, and moves like a knife)
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection with the morally compromised protagonist, Captivation, Anticipation, Revelation at the bitter truth.

VOICE & TONE
- POV: First person past (the classic noir voice. the survivor looking back at their destruction) or tight third past
- Voice: Sardonic, precise, lyrical in its darkness; the narrator sees everything clearly and can change nothing
- Tone: Fatalistic with flashes of dark beauty; the world is rotten but the prose is gorgeous
- Register: Hardboiled but not crude; literary but not pretentious; the sweet spot where street meets poetry

PROSE IMPERATIVES
- THE NOIR SENTENCE: short, punchy, rhythmic; the prose has a heartbeat
  - "She walked in and the trouble walked in with her." (Simple. Declarative. Loaded.)
  - The noir sentence does two things at once: describes AND judges, shows AND implies
  - Metaphor is the genre's currency: "The city sweated through the night like a guilty conscience"
  - Short sentences for action. Longer sentences for atmosphere. The rhythm alternates like breathing.
- ATMOSPHERE AS CONTENT: the physical world carries the emotional truth
  - Light and shadow are not decoration. they're the genre's visual grammar
  - Rain, smoke, neon, fog, darkness. these are emotional states made physical
  - Interiors tell character: a cheap office, a too-expensive apartment, a bar that's seen better decades
  - The city (or town, or suburb) is a character: corrupt, beautiful, indifferent, and dangerous
- THE VOICE OF THE DOOMED: the narrator knows what's coming
  - Retrospective irony: "I should have walked away. I didn't walk away."
  - Self-knowledge without self-help: the narrator sees their flaws but can't change them
  - Wry distance from their own pain: the noir narrator never asks for sympathy
  - The wiseguy register: deflecting emotion through wit, the joke that isn't funny
- ECONOMY AND PRECISION: every word earns its place
  - No filler. No throat-clearing. No scene that doesn't advance the doom.
  - Description is selective: one perfect detail replaces a paragraph of scene-setting
  - Dialogue is compressed: people in noir say less than they mean and mean less than they say

PROSE RHYTHM MAPPING (CRITICAL. noir IS the prose)

Noir is the most prose-dependent genre. Remove the voice and you have
a crime story. The voice IS the genre. The sentences must carry cynical
cadence, retrospective irony, and dark beauty in their very rhythm.

Chapter 1 prose rhythm:
- Sentence average: 18-28 words. Medium-long, with a cynical cadence
  that curls at the end. the sentence arrives at a destination the
  reader didn't expect but immediately recognises as inevitable.
- Metaphor density: high. 1 original metaphor per 150-200 words. But
  ORIGINAL, never cliched. "The city sweated through the night like a
  guilty conscience" earns its place. "The rain fell like tears" does
  not. If the metaphor has been written before, kill it.
- First-person voice: the narrator makes the reader complicit. "I
  should have walked away" implicates the reader who keeps reading.
  The retrospective voice knows how this ends. the reader feels the
  doom in the rhythm before they understand the plot.
- Short/long alternation: the noir heartbeat. A long atmospheric
  sentence, then a short declarative punch. The rhythm breathes like
  someone trying to stay calm and failing. "She said her name was
  Laura. I believed her because I wanted to."
- Dialogue compression: 25-35% by word count. People in noir speak in
  fragments, implications, and loaded silence. Every line does double
  duty. surface meaning and subtext. Dialogue tags are sparse.
- Tension floor: ≥5. In noir, tension is existential. the sense that
  every choice narrows the protagonist's options. The prose carries
  this as a constant undertow, even in quiet scenes.

DIALOGUE CRAFT
- Subtext over text: what people say in noir is rarely what they mean
- The verbal feint: flirtation as negotiation, small talk as surveillance
- Tough talk without parody: "I don't like being lied to" works; "Listen here, sweetheart" doesn't (unless the era demands it)
- The confession: when a noir character finally tells the truth, it should hit like a physical blow
- Silence: sometimes the most powerful noir dialogue is the thing that goes unsaid
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

NOIR CRAFT (40% of total):
- The protagonist is complicit in their own destruction? (0-100)
- The trap is visible and inevitable (structural irony)? (0-100)
- Moral ambiguity is total (no heroes, no clear right answers)? (0-100)
- Atmosphere is rendered through physical detail (not just stated)? (0-100)

STORY CRAFT (30% of total):
- Desire drives the plot (the want is clear and dangerous)? (0-100)
- The world is corrupt (institutions, individuals, systems)? (0-100)
- The ending is earned (inevitable in hindsight, devastating in the moment)? (0-100)
- Deception operates on multiple levels (characters lie, the plot lies)? (0-100)

PROSE QUALITY (30% of total):
- The noir voice is distinctive and sustained? (0-100)
- Metaphor and rhythm are used with precision (not excess)? (0-100)
- Economy: every scene advances the doom, no filler? (0-100)
- Atmosphere is tangible (the reader feels the world)? (0-100)

AUTOMATIC FAILS (score = 0):
- Happy ending where the protagonist escapes unscathed
- A righteous hero who makes only good choices
- The cavalry arrives (institutions save the day)
- Moral certainty (clear right and wrong)
- Sentimental resolution (love conquers all, justice prevails)
- Flat prose without noir's distinctive rhythm and style
- The protagonist is a passive victim (not an active agent of their own doom)
```

## Continuity Rules

```
NOIR CONTINUITY. WHAT TO TRACK

THE TRAP:
- What escape routes remain at each chapter (should narrow steadily)
- What the protagonist knows vs. what the reader knows (dramatic irony)
- Promises and debts: who owes whom, what deals are outstanding
- The lies: who has lied about what, and who knows the truth at each point
- The money (or MacGuffin): where is it, who wants it, who thinks they have it

MORAL LEDGER:
- Every compromise the protagonist has made: what they've done, what it cost them
- Alliances: who the protagonist trusts (and whether they should)
- Betrayals: who has betrayed whom, whether the betrayed party knows
- The body count: deaths and their consequences (guilt, exposure risk, escalation)

ATMOSPHERE STATE:
- Time of day and weather: noir lives in its atmosphere; track it
- Location: where scenes take place, the geography of the protagonist's world
- The protagonist's physical state: injuries, exhaustion, intoxication, paranoia
- What the protagonist is wearing, carrying, driving. physical details that ground the voice

RELATIONSHIP STATE:
- The central relationship (often the fatal one): trust level, desire level, suspicion level at each point
- The antagonist's knowledge: what they know about the protagonist's actions
- Secondary characters: who is alive, who is compromised, who might talk
- Law enforcement: how close they are to the protagonist's trail

TIMELINE:
- When key events occurred (often compressed. noir stories move fast)
- What happened before the story began (backstory that drives present action)
- Deadlines: when money is due, when someone will talk, when the law closes in
```

## Character Rules

```
NOIR CHARACTER TYPES

THE PROTAGONIST:
- Not a hero: an ordinary person (or a flawed professional) who makes one bad decision that cascades
- Their DESIRE is their weakness: money, sex, revenge, escape. the specific want that pulls them into the trap
- Self-aware but not self-correcting: they see their mistakes and make them anyway
- Competent in their world but outmatched by the situation: a good poker player at a rigged table
- Their best quality is their worst: loyalty makes them exploitable, cleverness makes them arrogant, desire makes them blind
- They are the narrator of their own tragedy, and they know it

THE FEMME FATALE / HOMME FATAL:
- Not simply "evil". their own desperation, ambition, or survival drives them
- They use attraction as a weapon, but they may also genuinely feel what they weaponise
- The best noir tempters are ambiguous: are they using the protagonist, or are they also trapped?
- Their motivation should be as understandable as the protagonist's. they want something badly enough to betray
- They are not decoration: they are a fully realised character whose needs conflict with the protagonist's survival

THE POWER FIGURE:
- The person or institution that owns the world the protagonist moves through
- Corrupt, comfortable, insulated from consequences. the rules don't apply to them
- They don't need to be a villain in a moustache-twirling sense. their corruption is systemic and casual
- They represent the world noir is about: a rigged game where power protects itself

THE FALL GUY:
- Someone who takes the consequences the protagonist escapes (for now)
- Their fate is a preview of the protagonist's future
- They may be innocent, partly guilty, or simply less powerful
- Their destruction should disturb the protagonist (and the reader) even as it temporarily saves them

VOICE DIFFERENTIATION:
- The protagonist/narrator: sardonic, self-aware, lyrical in their darkness
- The tempter: alluring, ambiguous, saying exactly what the protagonist wants to hear
- The power figure: calm, controlled, the voice of someone who never has to raise it
- The desperate: raw, unfiltered, the voice of someone with nothing left to lose
```

## Arc Rules

```
NOIR STORY STRUCTURE

ACT 1: THE WRONG TURN (first 25%)
- The protagonist's world before the fall: not happy, but stable enough. a status quo that's about to shatter
- The temptation arrives: a proposition, a person, an opportunity that's too good to be true (and they know it)
- The first bad decision: the protagonist chooses desire over safety, and the trap begins to close
- The world of the story established: atmosphere, corruption, the rules of this particular darkness
- END OF ACT 1: The protagonist is committed. they can't go back to who they were

ACT 2A: THE DESCENT (to midpoint)
- Consequences compound: the first bad choice requires a second, which requires a third
- The trap becomes visible: the reader (and sometimes the protagonist) can see the walls closing in
- Relationships deepen and complicate: trust is given and exploited, desire intensifies
- The protagonist's competence is shown. they're not stupid, just doomed
- MIDPOINT: The first major betrayal. someone the protagonist trusted reveals their true position; OR the protagonist discovers the game is bigger than they thought; the stakes jump

ACT 2B: THE TIGHTENING (midpoint to dark moment)
- Escape routes close one by one: each attempt to get out makes things worse
- The protagonist is forced to do something they wouldn't have considered at the start (moral descent)
- Alliances shatter: the people who could help won't, can't, or are dead
- The irony crystallises: the thing the protagonist wanted most is the thing that's destroying them
- DARK MOMENT: The protagonist sees the full shape of the trap. and knows they're inside it

ACT 3: THE RECKONING (final 25%)
- The protagonist makes their last play: one final gambit to escape, survive, or at least choose how it ends
- The betrayals complete: the final deception is revealed
- The confrontation: not always physical. sometimes the reckoning is simply understanding
- The cost: the protagonist pays for their choices (death, imprisonment, survival at the cost of everything that mattered)
- The ending: devastating, ironic, inevitable; the best noir endings make the reader re-evaluate everything they've read

NOIR PACING:
- Fast and relentless: noir doesn't pause for breath
- Every scene does two things: advances the plot AND tightens the trap
- The pace ACCELERATES. each chapter should feel faster than the last
- Brief moments of stillness (a drink, a drive, a quiet conversation) create contrast that makes the speed more terrifying
- The ending should feel like falling
```

## Timeline Rules

```
NOIR TIMELINE

COMPRESSION:
- Noir stories are typically SHORT in duration: days to weeks, rarely months
- The compression creates urgency: deadlines, debts due, pursuers closing in
- Time of day matters: noir lives in the night, in the hours when bad decisions feel like good ones
- The clock is always running: someone is always about to find out, arrive, or die

THE NOIR CLOCK:
- Track deadlines: when money is owed, when someone will talk, when the law arrives
- Track discovery: when will the protagonist's actions be found out?
- Track physical state: injuries, sleeplessness, intoxication accumulate
- Track weather and light: the atmospheric clock that creates the genre's visual rhythm

BEFORE THE STORY:
- Most noir has significant backstory: what happened before page one matters
- The past reaches into the present: old debts, old loves, old crimes
- Track what the reader learns about the past vs. what actually happened (the narrator may be unreliable)
```

## Genre-Specific Craft Techniques

Noir is the aesthetic-and-moral register of crime fiction's
darkest tradition, sitting adjacent to crime (broader
register, often more procedural) and hardboiled (often
overlapping but with the noir register specifically committed
to bleakness as worldview rather than to detective competence
as form). The cluster includes classic noir (1930s-50s
American urban crime fiction), neo-noir (post-1960s
extensions), Tartan noir / Scandi noir / Mediterranean noir
(regional adaptations), domestic noir (suburban-dread
register), and the broader literary-noir crossover. Comp
authors span the canonical lineage (Dashiell Hammett's *The
Maltese Falcon* and *Red Harvest*, Raymond Chandler's
Marlowe novels, James M. Cain's *Double Indemnity* and *The
Postman Always Rings Twice*, Cornell Woolrich, David Goodis,
Jim Thompson's *The Killer Inside Me* and *Pop. 1280*,
Patricia Highsmith's *Strangers on a Train* and the Ripley
novels, Chester Himes's Harlem cycle) through the
contemporary expansion (James Ellroy's LA Quartet, James
Lee Burke's Robicheaux, Walter Mosley's Easy Rawlins, Dennis
Lehane's Boston work, Pete Dexter, Megan Abbott's
contemporary noir, Sara Gran, Steph Cha, Lou Berney, S.A.
Cosby's Southern noir, Attica Locke, Liz Moore, Ottessa
Moshfegh at the literary edge, Eva Dolan, Denise Mina, Ian
Rankin's Rebus on the Tartan-noir register, Kjell Eriksson,
Karin Fossum, Henning Mankell, Stieg Larsson, Jo Nesbø on
the Scandi register, Donna Leon's Brunetti on the
Mediterranean register, Andrea Camilleri's Montalbano,
Massimo Carlotto, Dominique Manotti). The techniques below
are how the form delivers its core pleasures while avoiding
the failure modes (hardboiled-pastiche register signalling
movie-noir rather than literary noir; bleakness-without-
beauty losing the form's aesthetic register; sentimentality
that the form specifically excludes; moral-clarity register
the form has long since complicated).

### The Retrospective Knife

The narrator who knows what's coming but tells it anyway:

```
"She said her name was Laura and I believed her
because I wanted to, the way you believe a
forecast that says sunshine when you can see
the clouds rolling in.

Her name wasn't Laura. But that came later.
Everything came later. By then I was already
in the car and the car was already moving and
the road only went one direction."

The narrator's foreknowledge creates dread.
The reader knows the end is bad. They read
to find out HOW bad.
```

### The Double-Meaning Detail

Every object, gesture, and line of dialogue means two things:

```
"She handed me the glass. 'You look like you
need this.'

I needed it. I needed it the way a man falling
needs a rope, without thinking too hard about
what's tied to the other end."

The drink is a drink. It's also the beginning
of the trap. The protagonist sees the double
meaning and drinks anyway.
```

### The Atmosphere-as-Judgement

The physical world comments on the moral world:

```
NOT NOIR:
"He felt guilty about what he'd done."

NOIR:
"The rain started as I left her apartment. It
fell on the just and the unjust alike, which
is the only kind of justice this city has ever
managed."

The weather IS the moral commentary. The
narrator doesn't need to state emotions
when the world states them for him.
```

### Noir AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the city never sleeps" | Show the specific nighttime detail |
| "she walked in and trouble followed" | Show what she actually does |
| "the dame had legs that went all the way up" | Describe through character-filtered observation, not catalogue |
| "in this town, everybody's got an angle" | Show the specific angle |
| "the whiskey burned going down" | Show what the drink does to the character's state |
| "the rain-soaked streets reflected neon" | Pick ONE detail, filtered through mood |
| "I should have known better" | Show the specific miscalculation |
| "the night was young and so was the body" | Show the specific scene |
| "some things you can't unsee" | Show the specific image that haunts |
| "the world was painted in shades of grey" | Show the specific moral ambiguity through action |
| "a femme fatale with a secret" | Name the secret; show the danger through behaviour |
| "the city was a jungle" | Cut; show ONE specific predatory detail at this specific intersection |
| "everyone has their price" | Show the specific transaction in the specific scene |
| "the truth was buried deep" | Show what specifically is buried — by whom, why, what would cost to dig up |
| "she was trouble in heels" | Cut "trouble in heels" entirely; show specific trouble through specific behaviour |
| "the case had hooked him" | Show the specific hook — the photograph, the case detail he can't stop returning to, the wound the case is opening |
| "doing what had to be done" | Cut; show what specifically the protagonist did and how they live with it |
| "the underworld had its own rules" | Cut "underworld" as cliche; name the specific organisation with its specific operating logic |

### The Doomed Trajectory

Noir's signature structural pressure: the protagonist is on
a path that ends badly, and the form's tension comes not
from whether they will fail but from how, when, and at what
cost. The doomed trajectory is the form's distinguishing
feature from crime / mystery / hardboiled — those forms
permit (and often require) the protagonist's eventual
victory; noir's tradition specifically permits — and
typically expects — the protagonist's specific defeat,
compromise, or moral collapse.

The architecture requires:

- **Early indicators of doom** — the protagonist's first
  significant choice is already a mistake the reader can
  see coming. Not a mistake of incompetence; a mistake of
  desire, of chosen direction, of the wrong person trusted
  for the right-feeling reason. The form's signature
  opening is the protagonist who knew better and did it
  anyway.
- **Narrowing options** — across the manuscript, the
  protagonist's available choices contract. What was a
  three-option decision in chapter four is a two-option
  decision in chapter twelve and a one-option decision (or
  no-option non-decision) by the climax. The reader feels
  the corridor closing.
- **The unchosen escape** — at intervals, the form's
  strongest practitioners stage moments where the
  protagonist could exit the doomed trajectory if they
  chose to. The form's signature emotional weight comes
  from the protagonist's specific refusal to take the
  exit — sometimes from genuine misunderstanding, sometimes
  from desire, sometimes from accumulated complicity that
  has made the exit feel impossible.
- **The cost made specific** — by the climax, the
  protagonist has specifically lost something or specifically
  become something. The strongest noir refuses the tidy
  resolution; the protagonist who survives is not the
  protagonist who started, and the prose tracks specifically
  what was paid.

The architecture fails when doom arrives unmotivated (the
protagonist who is destroyed by external force without their
own complicity has been in adjacent forms, not noir) OR
when doom is averted at the climax (the rescue, the
redemption, the second chance). Both lose the form's
distinctive contract. Test: at the manuscript's close, can
the writer specify what the protagonist has paid and how
they live with it? If no payment registers, the doomed
trajectory has not been deployed.

### The Period and Place Specificity

Noir is unusually place-rooted: the form's classic register
is inseparable from specific cities (1940s Los Angeles for
Chandler; 1930s San Francisco for Hammett; postwar New York
for Woolrich; postwar Harlem for Himes; contemporary
Glasgow for Mina; contemporary Edinburgh for Rankin;
contemporary Naples / Sicily / Venice for the Italian
register; contemporary Stockholm / Oslo / Reykjavik for the
Scandi register), and the regional voice variants (Tartan
noir's specific cadence; Scandi noir's specific landscape
register; Mediterranean noir's specific institutional
texture) are themselves form-defining.

The discipline:

- **Period-specific texture** — material culture, language,
  political context, social fabric of the chosen period
  rendered specifically. The 1940s Los Angeles of *The
  Big Sleep* operates in different register than the 1990s
  Los Angeles of Walter Mosley or James Ellroy or the
  contemporary LA of Steph Cha; the differences should
  register on the page.
- **Place-specific texture** — the specific neighbourhood,
  the specific kind of bar, the specific architecture, the
  specific weather, the specific institutional landscape
  (police, criminal organisations, political machinery)
  of the chosen city. Generic-noir-city is the failure
  mode; specific named place with specific operating logic
  is the technique.
- **Regional voice variants** — if writing Tartan noir, the
  specific Scottish cadence operates; if writing Scandi
  noir, the specific Nordic restraint operates; if writing
  Mediterranean noir, the specific institutional fatalism
  operates. Generic-American-noir voice applied to non-
  American settings is the failure mode.

The technique requires research and immersion. The
strongest noir practitioners ground their fiction in specific
researched and inhabited place-knowledge; the form's
failure mode is the writer who imagines noir from movies
rather than researching the actual specifics.

Test: pick three significant location passages and ask, in
each, whether the rendered place could be lifted to another
city without altering the prose. If yes, the place
specificity is decorative; if no, the technique is
operating.

## Genre-Specific Revision Rules

Six revision passes specific to noir, each with a focused
question, run cover-to-cover before the next begins. Noir
revision must hold the form's signature contracts:
complicity (the protagonist's active complicity in their
own doom); style (the noir voice sustained without slipping
into pastiche); moral ambiguity (no one clearly right; the
world corrupt at institutional level); trap architecture
(the corridor narrowing across the manuscript); tone
(sentimentality absent, distinctive prose rhythm
maintained); and the doomed-trajectory + period-and-place
audits that distinguish craft noir from movie-noir
imitation. The passes below are ordered to surface
complicity and style failures first (the form's most-felt
by genre readers), moral and trap audits next, tone and
specificity last.

### Pass 1: Complicity Check

Verify the protagonist is making active choices, not merely
acted upon. Noir's structural truth is that the doom comes
from what the protagonist DOES, not from what happens to
them. The protagonist who is destroyed by external forces
without their own choices contributing has been written in
adjacent forms; the protagonist whose specific decisions
generate the trap they end up in is operating within the
form.

Verify their choices are driven by desire, not stupidity.
The form's protagonists are not idiots; their choices feel
right at the moment of choosing because of specific desire
— for the woman, the money, the answer, the freedom, the
recognition, the chance to undo something earlier. The
desire is not always reasonable; the protagonist's specific
form of unreasonable desire is character work.

Verify the trap is tightening because of what the
protagonist does, not just what happens to them. At each
significant chapter, identify the protagonist's specific
contributing choice and trace its specific consequence in
the trap's narrowing. Generic "things were getting worse"
without specific protagonist agency is the failure mode;
specific named choice with specific named consequence is
the technique.

### Pass 2: Style Check

Verify the noir voice is sustained — sardonic, rhythmic,
precise. Read the manuscript aloud and listen for register
slippage. The form's voice register is unusually narrow:
sentences typically alternate short and long; metaphors are
specific and earned; observations are precise; the narrator's
sardonic self-awareness operates throughout without
becoming repetitive.

Verify metaphors are specific and earned, not generic
hardboiled pastiche. The form's most-flagged style failure
is the cliché-noir-metaphor register ("she had legs that
went on for days"; "his face was a road map of bad
decisions"; "the city was an old whore"). Each generic
metaphor is the form pretending to itself. The strongest
noir practitioners write metaphors that are specifically
this narrator's specific observation, with specific
particularity that no other noir narrator would have.

Verify economy is maintained. The form is unusually unfilled;
no scenes that don't advance the doom; no descriptions that
don't carry weight; no dialogue that doesn't either move
the trap or reveal the moral terrain. Generic atmospheric
description divorced from the form's central pressure is
the failure mode; every paragraph contributing to the
trajectory is the technique.

Verify atmosphere comes through physical detail, not
adjectives. "The air was oppressive" is the failure mode;
the specific detail (the specific kind of stale-cigarette-
and-old-coffee smell of the specific kind of office; the
specific quality of the specific kind of late-afternoon
light through the specific kind of dirty window) is the
technique. Test: pick three atmospheric passages and verify
each operates through specific physical detail rather than
through generalised adjective.

### Pass 3: Moral Ambiguity Check

Verify no one is clearly "right". Noir's moral terrain is
specifically compromised — every character has compromises,
moral debts, specific complicities. The protagonist who is
the only honest person in a corrupt world has been written
in the wrong genre; the protagonist who is the somewhat-
less-corrupt person navigating a thoroughly corrupt world is
operating within noir.

Verify the protagonist's moral ledger is getting worse, not
better. The form's character arc is typically descent —
specific moral compromises accumulating across the
manuscript, the protagonist becoming someone they would
have refused to become at the start. Manuscripts where the
protagonist ends morally cleaner than they began have
slipped into adjacent register; the form's actual contract
is the descent the protagonist may or may not be aware of.

Verify the antagonists are understandable, not cartoons.
The form's antagonists operate by their own coherent logic
— the corrupt cop whose corruption has specific reasons; the
femme fatale whose manipulation comes from specific
constraints; the mob boss whose violence operates by
specific operational rules. Cartoon villains are the form's
most-flagged antagonist failure; understandable antagonists
whose worldview the protagonist could (under different
circumstances) have shared are the technique.

Verify the world is corrupt at the institutional level, not
just bad individuals. Noir's signature thematic register is
that the system itself is the problem — police corruption is
not a few bad apples but a structural feature; political
corruption is not aberrant but systemic; criminal
organisations are not anomalies but parallel institutions
operating by their own legitimating logic. Generic
"individual bad people" treatment is the failure mode;
specific institutional corruption rendered with operational
specificity is the technique.

### Pass 4: Trap Architecture Check

Map the protagonist's available options across the
manuscript. Have escape routes narrowed since the last
chapter? At each chapter, identify the specific options
the protagonist has and verify the count is contracting.
The form's structural pressure depends on the corridor
closing.

Verify dramatic irony is operating. The reader should see
the trap before the protagonist sees it, with the gap
between reader-understanding and protagonist-understanding
generating the form's signature dread. The reader notices
the inconsistency in the woman's story; the protagonist
does not. The reader sees the cop's specific lie; the
protagonist accepts it. The strongest noir maintains this
dramatic irony for substantial portions of the manuscript,
with the protagonist's eventual recognition arriving as
confirmation of what the reader has been seeing for
chapters.

Verify the protagonist's desire is still the engine driving
them deeper. The form's protagonist is not pushed into the
trap by external force; they are pulled by their own
specific desire (for the woman, the money, the answer, the
freedom, the redemption). Each chapter should identify the
specific desire still operating and the specific way it's
making the protagonist refuse the available exit.

Verify chapters end with fewer options than they started
with. The form's pacing rhythm: each chapter further
constrains the protagonist's available choices. Manuscripts
where chapters end with the same options that opened them
have not deployed the trap architecture; manuscripts where
each chapter's close registers the specific lost option are
operating in the form.

### Pass 5: Tone Check

Verify sentimentality is absent. Noir's emotional contract
specifically excludes sentimentality — tenderness exists in
the form, but only to be exploited or to be revealed as
illusion. The protagonist's affection for the woman is
genuine; her affection for the protagonist is calculated.
The protagonist's loyalty to the partner is real; the
partner's loyalty is conditional. The form's strongest
practitioners permit tenderness while showing its specific
exploitability; sentimental noir is a contradiction in
terms.

Verify the narrator's self-awareness is present. The form's
narrator typically sees their own mistakes — the protagonist
who narrates "I should have known" with specific knowledge
of why they didn't know is operating within the form. The
narrator without self-awareness is in adjacent register
(typically procedural); noir's narrator carries a specific
relationship to their own complicity that the prose registers.

Verify the darkness is honest, not performative or
gratuitous. Noir's darkness comes from specific causes —
specific institutional corruption, specific accumulating
moral cost, specific desire's specific consequence. Generic
"the world is dark" treatment is the failure mode;
specific darkness with specific operational logic is the
technique. Verify the prose has noir's distinctive rhythm —
short / long alternation, specific cadence, the
characteristic noir sentence shape that the form has
developed across its tradition.

### Pass 6: Period-and-Place + Doomed-Trajectory Integration Audit

Run a final integrative pass on the manuscript's specificity
and structural close. Two related sub-audits:

**Period-and-place specificity.** Noir is unusually place-
rooted; the form's classic register is inseparable from
specific cities and specific periods. Audit the manuscript:
does the chosen city and period operate with specific
researched texture? Are material culture, language, political
context, social fabric, regional voice variants all rendered
specifically? Generic-noir-city treatment is the failure
mode; specific named place with specific operating logic
across all axes is the technique.

**Doomed-trajectory closure.** Noir's signature structural
contract permits — and typically expects — the protagonist's
specific defeat, compromise, or moral collapse. Audit the
manuscript's close: has the protagonist specifically lost
something or specifically become something? Is the cost
named and tracked? The form's strongest practitioners
refuse the tidy resolution; the protagonist who survives
is not the protagonist who started, and the prose tracks
specifically what was paid.

The pass also checks for the related failure modes:

- **Rescue ending** — the protagonist is saved by external
  force, undoing the trajectory. Common in adjacent
  registers; specifically excluded from the form's classic
  contract.
- **Redemption ending** — the protagonist makes good on
  their accumulated moral debts and exits the descent.
  Permitted in some noir registers but typically signals
  the manuscript has slipped toward crime / hardboiled /
  literary-crime register and may be more accurately
  classified there.
- **Second-chance ending** — the protagonist is given an
  exit they specifically didn't earn. The form's signature
  failure mode at the climax; manuscripts that arrive at
  noir register through twenty-five chapters and then
  pull back at the close have lost the form's distinctive
  contract.

Test: at the manuscript's final pages, can the writer
specify what the protagonist paid, what they became, and
how they now live with it? Each answer should be specific
and traceable to events on the page. If answers are
generic, the doomed-trajectory work has not been deployed
and the form's deepest emotional register has been
forfeited.

## Names & Patterns to Avoid

### Noir Character Names. NEVER USE
- Parody names: Jake Steele, Rocco Danger, Veronica Dark
- Names from famous noir films unless deliberately homaging: Marlowe, Spade, Neff
- Names that telegraph role: Faith (temptress), Victor (power figure)

### Noir. NEVER DO
- Give the protagonist a happy ending (survival is the best noir offers, and it costs everything)
- Write moral certainty (the moment anyone is clearly right, the noir is broken)
- Send the cavalry (no institutions save the protagonist; the institutions are compromised)
- Make the femme/homme fatal simply evil (their desperation is as real as the protagonist's)
- Write pastiche (the Chandler impression without Chandler's substance)
- Let sentimentality survive (tenderness in noir exists to be weaponised)

### Use Instead
- Names that feel real and grounded: ordinary names for extraordinary trouble
- Names appropriate to the setting's era and geography
- The protagonist's surname used by most characters (distance and formality are noir's register)

## Comp Titles

Noir's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Maltese Falcon* — Dashiell Hammett (1930): the noir-PI template.
- *The Big Sleep* — Raymond Chandler (1939): the noir-voice canon.
- *Double Indemnity* — James M. Cain (1943): the femme-fatale-noir template.
- *Devil in a Blue Dress* — Walter Mosley (1990): post-war Black-LA noir; Easy Rawlins series.

### Contemporary (current best-in-class)

- *L.A. Confidential* — James Ellroy (1990): retro-noir benchmark; influential modern register.
- *Mystic River* — Dennis Lehane (2001): literary-noir with neighbourhood specificity.
- *The Black Dahlia* — James Ellroy (1987): the historical-noir template.
- *Bluebird, Bluebird* — Attica Locke (2017): contemporary noir with race-place specificity.
- *Razorblade Tears* — S.A. Cosby (2021): rural-noir with father-grief and Black-Southern specificity.
- *Velvet Was the Night* — Silvia Moreno-Garcia (2021): post-colonial noir; 1970s Mexico City.
- *Don't Look for Me* — Wendy Walker (2020): contemporary domestic-noir.

## Cover Design Specifications

### Recommended Visual Styles
- **Chiaroscuro**. Extreme light and shadow: a face half-lit, a figure in a doorway, neon reflected in wet pavement; the visual grammar of moral ambiguity
- **Silhouette**. Bold graphic shapes: a figure against venetian blinds, a woman in a doorframe, a car's headlights in fog; iconic noir imagery
- **Typographic**. The title dominates: bold, angular, bleeding off the edge; minimal imagery, maximum style; the design is the statement
- **Photographic**. Grainy, high-contrast, cinematic: the cover looks like a still from a film that was too honest to get made

### Genre Cover Aesthetics
- **Styles:** High contrast between light and shadow, venetian blind patterns, rain-slicked streets, neon signs reflected in wet surfaces, silhouettes in doorways, the geometry of urban night, cigarette smoke, vintage cars, empty bars
- **Colours:** Extremely limited palette: black, white, one accent colour (blood red, neon blue, amber, or toxic green); desaturated unless the accent colour demands attention; the palette of 3 AM
- **Elements:** Shadows more prominent than subjects, venetian blinds, rain, neon, smoke, mirrors, silhouettes, guns shown as objects not in action, lipstick, whiskey glasses, letters and photographs, money
- **Typography:** Angular, bold, often tilted or fragmented; the title should feel like a warning or a confession; red, white, or neon against black; distressed or rough textures; the font itself should feel dangerous

### Market Positioning
Noir covers must signal "doomed, stylish, and morally corrupt" through extreme contrast and limited palette. Position against Ellroy, Thompson, Megan Abbott, James M. Cain. The cover should feel like the last thing you see before making a terrible decision. At thumbnail size, high contrast between black and one accent colour creates instant genre recognition.

### Cover Design DON'Ts
- No full-colour imagery (noir's palette is restricted by definition)
- No action poses or violence depicted (noir's violence is implied, not shown)
- No romantic or hopeful imagery
- No busy compositions (noir is about isolation and shadow)
- No bright colours or cheerful accents
- No designs that look like mystery or thriller (noir is its own visual language)
