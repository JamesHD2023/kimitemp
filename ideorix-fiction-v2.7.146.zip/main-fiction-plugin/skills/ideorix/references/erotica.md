---
name: erotica-genre
description: "Genre-specific instructions for Erotica. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
parents: [romance]
---

# Erotica. Genre Plugin

## Metadata
- **Genre ID:** erotica
- **Display Name:** Erotica
- **Category:** Romance
- **Tier:** Core
- **Target Word Count:** 4,000–4,500 per chapter
- **Min Word Count:** 3,500
- **Recommended Beat Structures:** Romancing the Beat, Story Circle, Three-Act Structure

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Contemporary Erotica | Modern-day settings, realistic relationships | Grounded emotional dynamics; career/life balance tension |
| BDSM/Kink | Power exchange, negotiated dynamics | Requires explicit consent negotiation; safe word protocols; aftercare |
| Romantic Erotica | Love story with explicit intimacy | Emotional arc as important as physical; HEA expected |
| Dark Erotica | Morally complex, edgy dynamics | Power imbalances explored with critique; consequences shown |
| Queer Erotica | LGBTQ+ relationships and desire | Authentic identity exploration; avoid fetishisation |
| Historical Erotica | Period settings with explicit content | Period-appropriate language and attitudes; constraints heighten tension |

## Architect Instructions

### Chapter Planning Requirements

**Structure:**
- Chapter length: 2,000–4,000 words
- Pacing: Steady escalation. build tension, deliver payoff, reset with new tension
- Must open with: Sexual tension, desire established, or intimate moment in progress
- Must close with: Satisfaction delivered OR heightened anticipation for next encounter

**Beats Per Chapter:**
1. **Desire Established:** Sexual tension, attraction, or arousal shown (internal or external)
2. **Escalation:** Physical proximity increases, boundaries tested, intimacy deepens
3. **Consent Negotiated:** Explicit or implicit communication of wants, boundaries, enthusiasm
4. **Intimate Scene:** Sexual encounter with sensory detail, emotional connection, pleasure focus
5. **Aftermath:** Emotional processing, relationship shift, or setup for next escalation

### Genre-Specific Requirements
- Sex scenes central to plot. not gratuitous but integral to character/relationship arc
- Consent explicit and enthusiastic. no dubious consent normalised
- Multiple intimate scenes throughout. minimum one per 2–3 chapters
- Sexual tension maintained between encounters. anticipation, memory, desire
- Character agency in sexuality. active desire, not just responsive
- Sensory detail rich. sight, sound, touch, taste, scent in intimate moments
- Pleasure mutual focus. both/all partners' enjoyment shown
- Emotional authenticity. sex affects characters, not mechanical
- Heat level consistent. establish intensity early, maintain or escalate
- Variety in encounters. different settings, positions, dynamics, emotional tones

### Forbidden in Planning
- Non-consensual encounters presented as romantic or erotic
- Coercion or manipulation normalised without critique
- Pain without consent or presented as universal turn-on
- Sex as punishment or solely for one partner's pleasure
- Virginity fetishisation without examining the trope
- Consent violation treated casually
- Intimate scenes that don't advance character or relationship

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (primary engine — sensory and physical), Affection (relational charge), Captivation (scene atmosphere).

### Heat Level Calibration


Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-protocol.md`
"Heat Level Calibration Slot" handles the wire-up.

### Voice and Tone
- **POV:** 1st person (intimate access to desire) or 3rd close (multiple perspectives on chemistry)
- **Tense:** Past or present (present for immediacy in intimate scenes)
- **Voice:** Sensual, embodied, desire-aware, emotionally honest, specific to character
- **Reading level:** Adult. sophisticated vocabulary, anatomically accurate, emotionally nuanced

### Prose Imperatives
- Sensory immersion. all five senses engaged in intimate scenes
- Specific body language. how arousal manifests physically, individually
- Internal sensation described. what pleasure feels like from inside
- Consent shown through enthusiastic participation, verbal check-ins, or clear body language
- Emotional state tracked. how sex affects characters beyond physical
- Character voice maintained. vocabulary and perspective consistent in intimate moments
- Variety in description. avoid repetitive phrases for anatomy or actions
- Build and release tension. pacing within scenes mirrors arousal curve
- Agency visible. characters actively pursue and communicate desires
- Aftermath matters. emotional and relationship impact shown

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- Ch 1 must establish desire + character + stakes. The reader must
  WANT these characters before any intimacy begins. Tension ≥5.
- Opening: sensory immersion in the POV character's world. ground
  the reader in a body, not a backstory.
- First chemistry beat by Ch 1 end: physical awareness, charged
  dialogue, or the proximity ladder's first rung.
- Dialogue density: 30-40%. Character voice establishes the erotic
  register before any intimacy.

Anticipation scenes (pre-intimacy prose rhythm):
- Medium sentences (16-22 words) that LINGER on sensory detail.
  The prose should feel like holding your breath.
- Interiority: high (70-90 words per beat). what the character
  WANTS, is afraid of, notices about the other person.
- Sensory detail: one SPECIFIC physical observation per 150 words
  (the way they move, a scent, the sound of their voice).
- Paragraph breaks at charged moments. white space = anticipation.

Intimate scenes (prose rhythm mirrors arousal curve):
- BUILD: sentences lengthen (20-30 words), rolling, breathless,
  sensation accumulating. Interiority fades as physical sensation
  dominates.
- PEAK: sentences shorten dramatically (3-8 words). Fragments.
  Pure sensation. Minimal thought.
- AFTERMATH: sentences return to medium (15-20 words). Interiority
  returns. Emotional processing. The character lands.
- Heat-level variation:
  - Tender: shorter sentences throughout, more internal thought
  - Passionate: longer rolling → short peak, less thought
  - Playful: rhythm breaks for humour, imperfection, laughter
  - Intense: alternating long/short throughout, internal monologue
    breaking through sensation

Emotional-stakes scenes (non-intimate prose rhythm):
- Clean medium sentences (14-20 words). Dialogue-driven.
- Vulnerability: sentences get shorter and simpler as walls drop.
- The declaration or emotional turning point: direct, unadorned,
  unmistakable.

### The Anticipation Architecture

The scenes BEFORE intimacy are often more powerful than the scenes during. Master anticipation:

**Proximity Escalation:**
- Scene 1: Eye contact across a room. awareness established
- Scene 2: Incidental touch. the brush of a hand, electricity noted
- Scene 3: Deliberate proximity. standing too close, breathing shared air
- Scene 4: The almost-kiss. desire stated through action, then interrupted
- Scene 5: First real contact. earned, explosive because of the wait

**Techniques for building sexual tension in NON-sexual scenes:**
- Sensory awareness: protagonist notices partner's specific scent, the way they move
- Charged dialogue: conversation about something mundane carrying a second, heated layer
- Physical restraint: characters choosing NOT to touch when the reader desperately wants them to
- Interruption: the moment shattered by external intrusion. delayed gratification

### Writing Different Heat Levels

| Register | Tone | Technique | Focus |
|----------|------|-----------|-------|
| Tender | Slow, careful, vulnerable | Shorter sentences, more internal thought, checking in | What it MEANS |
| Passionate | Urgent, overwhelming, hungry | Longer rolling sentences, less thought, more sensation | Mutual NEED |
| Playful | Light, teasing, joyful | Humour, laughter, imperfection | EASE between partners |
| Intense | Raw, emotional, boundary-pushing | Alternating long/short sentences, internal monologue breaking through | What's being GIVEN |

### Character Voice During Intimacy

Characters shouldn't lose their personality during sex scenes:
- The articulate person who goes nonverbal. words failing as sensation takes over
- The controlled person whose control slips. the crack in composure more intimate than nudity
- The humorous person whose jokes finally stop. silence as seriousness, vulnerability
- The guarded person who finally asks for what they want. the request more intimate than the act

### Emotional Vulnerability as the Real Intimacy

Physical description alone creates pornography. Emotional truth creates erotica:
- The moment of self-consciousness: seeing yourself through another's admiring eyes
- The fear before vulnerability: wanting this, being terrified of wanting this
- The trust required to ask: saying out loud what you want, risking rejection
- The aftermath: the rawness of being seen, the tenderness or the panic
- Characters who are emotionally changed by sex. not just physically satisfied

### Forbidden Words and Phrases
- Clinical detachment in intimate scenes (unless character voice)
- Purple prose clichés ("throbbing member," "love button")
- Euphemisms that infantilise ("down there," "private parts")
- Pain romanticised without consent negotiation
- Orgasms described identically every time
- "Ravish" or non-consent euphemisms presented positively
- Body shaming or appearance-based worth

### Sensory Detail Framework
- **Touch:** Texture, temperature, pressure, movement
- **Sight:** Body language, expressions, physical responses
- **Sound:** Breath, words, vocalisation, ambient noise
- **Scent:** Personal scent, arousal, environment
- **Taste:** When relevant to encounter
- **Internal sensation:** How pleasure/arousal feels from inside

## Quality Check Criteria

### Priority Ranking
1. **Enthusiastic consent**. All intimate activity clearly consensual, enthusiastic, communicated
2. **Mutual pleasure**. Both/all partners' satisfaction prioritised and shown
3. **Sensory authenticity**. Intimate scenes rich in physical sensation and emotional response
4. **Character agency**. All participants actively desire and pursue intimacy
5. **Emotional honesty**. Sex affects characters realistically. vulnerability, bonding, conflict

### Genre-Specific Checks
- Consent explicit: verbal agreement, enthusiastic participation, or clear body language
- Boundaries respected: "no" or hesitation honoured immediately without pressure
- Agency visible: characters actively want sex, not coerced or manipulated
- Pleasure mutual: all partners' satisfaction matters
- Sensory detail: all five senses engaged in intimate scenes
- Variety in scenes: different settings, dynamics, emotional tones
- Emotional impact: sex changes characters, reveals vulnerability
- Communication present: partners discuss wants, check in, express desires
- Physical realism: bodies respond believably, stamina realistic
- Heat level consistent: intensity established early and maintained

### Automatic Fails
- Non-consensual acts romanticised without critique
- Dubious consent normalised (intoxication, power imbalance, pressure ignored)
- Pain without consent presented as universal turn-on
- Female pleasure absent in heterosexual encounters
- Boundaries violated casually with no consequences
- Coercion as seduction: pressure, manipulation, or stalking presented as romantic
- Virginity fetishised problematically
- Body shaming: worth tied to appearance
- Safe word ignored
- Orgasm as obligation: pleasure weaponised or withheld as punishment

### Acceptable Imperfections
- Some idealisation of bodies or stamina (genre convention)
- Slightly unrealistic recovery time if clearly fantasy element
- All partners orgasm simultaneously (rare but genre expectation)
- Some encounters more detailed than others (pacing variation)

### Consent Verification Checklist (Per Scene)
- [ ] Enthusiastic participation from all parties
- [ ] No pressure, coercion, or manipulation present
- [ ] Hesitation or "no" respected immediately
- [ ] Communication about wants, boundaries, or check-ins included
- [ ] Power dynamics acknowledged and navigated ethically
- [ ] Intoxication absent or consent addressed appropriately
- [ ] Safe word or signal respected if established

## Continuity Rules

### Top 5 Continuity Priorities
1. **Consent boundaries:** What each character has agreed to, limits established, safe words/signals
2. **Sexual preferences:** What turns each character on/off remains consistent unless evolution shown
3. **Physical details:** Bodies described consistently. anatomy, scars, modifications, responses
4. **Relationship dynamic:** Power balance, emotional intimacy level, exclusivity status tracked
5. **Sexual history:** Experience levels, past partners/trauma, comfort zones established

### Physical Consistency Tracking
- Body descriptions: anatomy, scars, tattoos, modifications consistent chapter to chapter
- Physical responses: how each character experiences arousal and pleasure (unique patterns maintained)
- Stamina and recovery: realistic energy, refractory periods, soreness tracked
- Protection/contraception: safer sex practices addressed consistently when relevant
- Injuries or sensitivity: any physical limitation from previous encounters carried forward
- Erogenous specifics: individual turn-on zones and responses don't shift without reason

### Emotional and Relationship State Tracking
- Trust level: current depth of emotional intimacy tracked per chapter
- Vulnerability progression: what each character has revealed, what remains guarded
- Relationship status: exclusive/open, expectations, feelings development consistent
- Emotional wounds: past trauma, insecurities, triggers maintained unless healing shown
- Communication patterns: verbal explicitness, body language reading, check-in habits
- Post-encounter emotional state: how characters feel after intimacy

### Red Flags (Investigate Immediately)
- Consent boundary shifts without on-page negotiation
- Character's stated limits violated without consequence
- Physical capabilities unrealistic (marathon sessions without fatigue)
- Contraception present in one scene, absent in identical context without explanation
- Relationship agreement violated without story addressing it
- Comfort level jumps arbitrarily
- Trauma response present early, disappears without healing arc
- Safe word established but never referenced when relevant
- Physical descriptions contradict earlier chapters
- Partner suddenly knows technique never communicated on-page

## Character Rules

### Character Consistency Priorities
1. **Sexual agency:** Characters actively desire, pursue, and communicate wants. not passive
2. **Consent communication:** How each character expresses boundaries, desires, agreement
3. **Desire specificity:** What specifically turns each character on. individual preferences
4. **Vulnerability patterns:** How character opens emotionally during intimacy
5. **Sexual confidence:** Experience level and comfort zones consistent unless growth shown

### Genre-Specific Character Elements
- Active desire: characters want sex for own pleasure, not just partner's
- Communication style: how they express wants. verbal, physical cues, negotiation
- Boundaries clear: what they will/won't do, and how they communicate limits
- Turn-ons specific: particular to character's psychology and experience, not generic
- Emotional needs: what intimacy provides beyond physical. connection, validation, escape, power
- Sexual confidence arc: growth from inexperience or trauma to comfort and agency
- Body relationship: how character feels about own body affects sexual expression

### Desire and Agency
- Both/all partners actively want intimacy. not one pursuing reluctant other
- Desire shown through thought, action, and communication
- Sexual initiative shared. not always same person initiating
- Pleasure-seeking is legitimate motivation. not needing "excuse" for sex
- "No" or "not now" respected without punishment or pressure
- Characters advocate for own pleasure and boundaries

### Emotional Authenticity
- Sex affects emotions. creates vulnerability, connection, or reveals wounds
- Intimacy brings characters closer or exposes incompatibilities
- Post-sex feelings realistic. bonding, anxiety, satisfaction, regret all possible
- Trauma responses handled with care, not gratuitously
- Love and lust distinguished. can coexist but aren't identical
- Relationship conflicts affect and are affected by sexual dynamic

## Arc Rules

### Five-Phase Erotica Arc (30 Chapters)

**Phase 1. Attraction and Anticipation (Ch 1–6)**
- Ch 1: Sexual tension established. attraction immediate, chemistry undeniable
- Ch 2: Proximity increases. circumstances force closeness, banter carries charged subtext
- Ch 3: Near-miss. almost-touch, interrupted moment, anticipation ratchets upward
- Ch 4: Tension becomes unbearable. characters deliberately seek proximity
- Ch 5: Consent negotiated. mutual desire communicated
- Ch 6: First intimate encounter. sensory detail rich, not most intense but most charged because of the wait

**Phase 2. Exploration and Trust-Building (Ch 7–13)**
- Ch 7: Aftermath. emotional processing, vulnerability acknowledged
- Ch 8: Second encounter. different tone from first
- Ch 9: Emotional deepening. non-sexual intimacy scene
- Ch 10: Encounter exploring preferences. characters communicate specific desires
- Ch 11: Relationship dynamic clarified. exclusivity, expectations, feelings
- Ch 12: Encounter with new dimension. different setting, dynamic, or emotional register
- Ch 13: Complication introduced. external obstacle or emotional wound surfaces

**Phase 3. Emotional Deepening and Conflict (Ch 14–20)**
- Ch 14: Emotional intensity peaks. vulnerability is the eroticism
- Ch 15 (MIDPOINT): The encounter that changes everything. "I love you," major revelation, or trust so deep it terrifies
- Ch 16: Aftermath. characters process what was said/felt
- Ch 17: Conflict surfaces. emotional wound, external obstacle, fear of commitment
- Ch 18: Encounter affected by conflict. desperate, angry, healing, or absent
- Ch 19: Distance or intensity. characters pull apart or cling together
- Ch 20: Reconnection attempt. encounter that tries to bridge emotional gap

**Phase 4. Crisis and Longing (Ch 21–25)**
- Ch 21: Separation. physical or emotional distance; longing through memory
- Ch 22: Emotional reckoning. confronting fears and wounds
- Ch 23: Crisis point. what will be lost if gap isn't bridged
- Ch 24: Movement toward reconciliation. honest communication, admission of fear
- Ch 25: Reunion encounter. earned through emotional work, most meaningful yet

**Phase 5. Integration and Fulfilment (Ch 26–30)**
- Ch 26: New equilibrium. deeper understanding, trust complete
- Ch 27: Climactic encounter. emotional and physical peak of entire story
- Ch 28: Aftermath. vulnerability of being fully seen and accepted
- Ch 29: Commitment expressed. future discussed, security established
- Ch 30: Resolution. sexually and emotionally fulfilled; ongoing intimacy implied

### Genre-Specific Arc Elements

**Anticipation-Release Cycle:**
- Phase 1: Extended anticipation (5–6 chapters of tension before first encounter)
- Phase 2: Multiple releases with rebuilding tension between encounters
- Phase 3: Emotional anticipation overtakes physical
- Phase 4: Absence creates the most powerful anticipation. longing
- Phase 5: Final release integrates all accumulated desire

**Vulnerability Escalation Arc:**
- Phase 1: Physical vulnerability only. bodies exposed, emotions guarded
- Phase 2: Emotional cracks appear. characters reveal preferences, fears
- Phase 3: Full emotional exposure. deepest wounds shown, terror of being known
- Phase 4: Vulnerability tested by separation
- Phase 5: Vulnerability accepted. being fully seen becomes safety, not threat

## Timeline Rules

### Time Scale
- Total story duration: Days to weeks (intense chemistry builds quickly)
- Chapter time span: Hours to days. balance encounters with relationship development
- Time progression: Linear, allowing chemistry and sexual tension to escalate

### Genre-Specific Temporal Rules
- Sexual chemistry can ignite quickly but emotional intimacy takes time
- Multiple encounters throughout. spacing allows anticipation to rebuild
- Recovery and refractory periods realistic. bodies need rest
- Emotional processing between encounters. sex affects characters
- Relationship progression alongside sexual: trust, vulnerability, commitment develop
- Anticipation building. time between encounters creates desire and tension

### Realistic Intimate Timing
- First encounter: Nervous, exploratory, shorter duration often
- Established intimacy: More confident, longer, more adventurous
- Refractory period: Varies by individual; recovery time needed
- Arousal build: Takes time. not instant
- Multiple encounters in short time: Stamina and energy considerations
- Emotional intimacy parallels physical: vulnerability builds over multiple encounters

### Pacing for Tension
- Space encounters to allow anticipation to rebuild
- Interrupted or delayed encounters increase tension
- Variety in encounter types prevents monotony
- Emotional intimacy scenes between physical ones
- Build to bigger, more emotionally significant encounters
- Final climactic scene aligns emotional and physical peak

## Genre-Specific Craft Techniques

Erotica is the literary form in which explicit sexual
content is the primary purpose, not the romantic-arc payoff.
The contract differs from romance and romantasy: erotica's
reader has come for the encounters themselves, rendered with
craft and specificity, and the surrounding narrative serves
to make the encounters land rather than the encounters
serving to deliver the relationship. The form spans
literary erotica (Anaïs Nin, Pauline Réage, Erica Jong, more
recently Mira Jacob, Carmen Maria Machado, Garth Greenwell),
the genre-erotica register (the mass-market and digital-
publishing landscape from Ellora's Cave through Sylvia Day,
Sarah MacLean's heat-end work, Skye Warren, Lauren
Rowe), and the specifically-curated sub-genres (BDSM-focused
work where the dynamic is the subject; queer erotica from
Roxane Gay's edited collections through Carmen Maria
Machado's *Her Body and Other Parties*; specific-fetish
work calibrated to particular reader interests). The
techniques below are how the form sustains craft across
encounters at scale — most erotica novels carry many more
intimate scenes than a romance, and each must be
distinctive, character-specific, and consequential. Generic
encounters at high frequency are the genre's most-detected
craft failure; every encounter must do work.

### The Proximity Ladder

A systematic escalation of physical closeness that builds
unbearable tension. The technique converts the reader's
anticipation into the encounter's actual erotic charge: by
the time the rung of full contact arrives, the prior rungs
have invested the moment with weight no first-encounter
could otherwise carry. Each rung must feel like a major
escalation in its own right; skipping rungs collapses the
investment.

1. **Awareness:** Characters notice each other across
   distance — the look across the room, the gravitational
   pull of attention, the specific quality of their attention
   to each other in a crowd.
2. **Incidental contact:** Accidental touch — hand brushing,
   shoulder contact, the moment passing in a hallway when
   they had to choose whether to step back or didn't.
3. **Shared space:** Deliberate proximity — standing too
   close, sharing a seat, the body's choice to remain in the
   smaller-than-necessary radius.
4. **Almost-moment:** The near-kiss, the hand that stops
   just short, the line of dialogue that didn't quite arrive,
   the breath drawn before the word that wasn't said.
5. **First deliberate touch:** Fingers on skin with intent
   — the line crossed knowingly, both characters aware that
   what just happened cannot be unhappened.
6. **Full contact:** The earned first encounter, weighted by
   every prior rung the prose has invested in.

**Key rule:** Each rung of the ladder should feel like a
major escalation. Don't skip rungs. The technique fails when
the writer rushes through awareness and incidental contact
to reach the explicit content faster — the rushed approach
delivers the encounter at full mechanical detail but with
zero investment, and the reader registers the absence of
charge. The ladder operates differently across heat tiers
(in a high-heat book the ladder may extend over the first
quarter; in a hotter, faster-paced book the ladder
compresses into early chapters but still cannot be skipped),
but it cannot be elided. Test: identify each rung's
specific moment in the manuscript. Are all six present, in
sequence, with each given enough page time to register? If
any rung is missing or rushed, the foundation for the first
full encounter has been weakened.

### The Charged Mundane

Ordinary activities carrying erotic weight through context
and character awareness. The technique is fundamental to the
genre's distinctive register — explicit content alone is
pornography; explicit content woven through specifically
charged mundane life is erotica. The mundane scene must
register as both mundane (the activity is real, the dialogue
is plausible, nothing on its surface is sexual) and charged
(the prose's sensory grammar, character interiority, and
selection of detail register the desire underneath).

Examples of charged mundane work:
- Cooking together where every reach and brush is electric
- A conversation about work where the subtext is entirely
  about desire
- Helping with a physical task (moving furniture, fixing
  something) where proximity is the point
- The moment of helping someone with a coat, a zipper, a
  necklace clasp
- The drive home from somewhere where they did not touch
- The dance class taken for a wedding that neither of them
  is attending together
- The grocery shopping that becomes an inventory of his
  preferences she did not previously know

The technique requires that the mundane scene's surface
remain plausible — a reader who feels the writer is forcing
charge onto an activity that doesn't sustain it loses
immersion. The strongest charged-mundane scenes are
indistinguishable from non-erotic everyday life on their
surface; the charge is entirely in the interior register
and the sensory specificity. Test: read each charged-
mundane scene aloud and ask whether the dialogue could
appear in a non-erotic novel without alteration. If yes, the
surface is plausible. If the prose is forcing charge into
unsubtle places ("his hand grazed hers and she felt the
heat radiate through her body like wildfire"), the technique
has slipped into operating on the nose.

### The Aftermath as Revelation

What happens after intimacy reveals more than the act
itself. The genre's deeper craft pleasure: the moments
between encounters often carry more emotional weight than
the encounters themselves, because the characters'
reactions to what just happened expose interior they could
not expose during the encounter. The aftermath is where
character work concentrates.

Aftermath possibilities:
- The character who immediately needs space versus the one
  who wants to stay
- The conversation that becomes possible only after physical
  barriers have fallen
- The vulnerability hangover — the morning-after fear of
  having been too open, the regret that is not really
  regret but exposure
- The small domestic gesture (making coffee, pulling up
  blankets, finding the discarded earring) that says more
  than words
- The unexpected laughter that releases the previous
  scene's intensity
- The disagreement immediately following — the irritation
  that has nothing to do with the encounter and everything
  to do with the proximity it produced
- The text message twelve hours later that reads
  differently than it would have read yesterday

The technique requires that aftermath scenes do specific,
character-true work — not just generic post-coital tenderness
or cliché awkwardness, but the specific aftermath this
specific pair would have. Test: pick three aftermath scenes
and ask, in each, whether the aftermath could have been
written for any other couple in the manuscript. If yes, the
aftermath is generic; if the aftermath is specifically
characteristic of these two people, the technique is
operating.

### Emotional Undressing

The moment a character reveals something emotionally during
physical intimacy that makes them more vulnerable than
nudity ever could. This is the genre's deepest technique —
the moment where the explicit register opens into emotional
exposure that the rest of the book has not been able to
reach. The technique distinguishes craft erotica from
mechanical erotica: in mechanical erotica, the bodies are
exposed; in craft erotica, the interiors are.

Emotional undressing occurs through:
- Admitting a fear mid-encounter
- Asking for something specific (the request harder than the
  act)
- Saying something they've never told anyone
- Crying during or after — not from sadness but from release
- The specific compliment that names something the partner
  didn't know was visible
- The honesty about prior relationships, prior pain, prior
  not-being-loved
- The recognition spoken aloud that this is different,
  without the protective irony that would mask it

The technique requires earned timing. Emotional undressing
cannot be deployed in the first encounter — the characters
have not yet built the trust the moment requires; the
revelation reads as the writer reaching for depth the
relationship has not earned. The strongest erotica places
emotional undressing at structural turning points: the
encounter where the relationship's nature actually changes,
the encounter that recontextualises everything before, the
encounter that the rest of the book has been preparing
without the reader knowing.

### The Encounter Variety Discipline

Erotica novels typically contain many more intimate scenes
than romance — sometimes a dozen or more across a 350-page
book — and the genre's craft challenge is making each one
distinctive. The technique requires that each encounter
serve a specific narrative function (claiming, exploration,
reconciliation, surrender, recognition, accusation,
transformation, parting) and have a specific sensory
signature (location, time of day, what each character
brings to the scene, what was said before, what is not
being said). Encounters that share emotional purpose with a
prior encounter must do something the prior encounter did
not — a different vulnerability exposed, a different power
dynamic, a different sensory grammar — or one of them is
redundant.

Map each encounter in the manuscript on a grid: emotional
function (one column), sensory signature (another), location
and time (another), what was said before (another), the
specific power dynamic at this point in the relationship
(another). Encounters that occupy the same grid coordinates
are doing the same work. Test: cover the dialogue and
sensory specifics of each scene and ask whether the reader
could distinguish the scenes from each other on emotional
function alone. If the scenes blur, the variety discipline
has slipped.

The technique extends to physical-detail variety: the body
remains the same body, but the prose's attention should
land differently each time — the focus on hands in this
scene, on breath in the next, on temperature in the third,
on sound in the fourth. Mechanical repetition (the same
body parts described in the same order with the same
adjectives across multiple encounters) is the genre's
clearest signal of craft fatigue and the most-detected by
genre-experienced readers.

### The Genre Contract Calibration

Erotica's contract with its reader varies significantly
across sub-genres, and the manuscript must commit to a
specific contract and hold it. Calibration questions:

- **Plot-to-content ratio.** Some erotica sub-genres
  prioritise narrative architecture (literary erotica,
  romance-erotica crossover), with explicit content
  distributed across a substantive plot. Others prioritise
  encounter density (genre erotica, especially digital-first
  publishing), with plot serving primarily to frame
  encounters. The chosen ratio must be visible from the
  opening chapter and held throughout.
- **Heat level commitment.** The form operates across heat
  tiers from explicit-but-restrained through full-explicit
  to extreme. The chosen tier must be calibrated and
  sustained. A book that operates at one tier through the
  first half and shifts to another in the second half has
  lost calibration; readers select for specific tiers and
  feel betrayed by drift.
- **Sub-genre conventions.** BDSM erotica, queer erotica,
  ménage, fetish-specific work, and erotic-romance crossover
  each have their own conventions, vocabularies, and reader
  expectations. The manuscript must understand and observe
  the conventions of its declared sub-genre or signal
  deliberately when departing from them.
- **Consent register.** Contemporary genre standards have
  evolved sharply over the past decade; explicit, ongoing,
  enthusiastic consent is the current expectation, with the
  consent legible in the prose without breaking the
  register. Older genre conventions (the surprising-
  yielding, the "she didn't know she wanted it") that read
  as standard in 1990s erotica read as harm in 2025 reading;
  contemporary erotica handles this through clear in-scene
  signalling and post-scene check-ins that integrate rather
  than interrupt.
- **Character continuity.** Even in encounter-dense erotica,
  characters must remain consistent — the same desires,
  preferences, refusals, kinks, and emotional patterns
  across encounters. Inconsistency reads as the writer
  reaching for variety the characters haven't earned.

Test: write a one-paragraph genre-contract statement for the
manuscript: what tier is this book at, what sub-genre
conventions does it observe, what plot-to-content ratio
does it commit to, what consent register does it operate
in? Then read the manuscript against the statement; flag
any chapter that drifts from the contract.

### Erotica AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "waves of pleasure crashed over her" | Show the specific physical sensation |
| "their bodies moved in perfect rhythm" | Show the specific physical detail |
| "electricity sparked wherever they touched" | Show the specific touch and specific reaction |
| "she surrendered to the sensation" | Show the specific moment of letting go |
| "the room was thick with desire" | Show ONE specific sensory detail (scent, temperature, sound) |
| "his touch set her on fire" | Show the specific touch and specific physical response |
| "they explored each other's bodies" | Show the specific exploration — one touch, one reaction |
| "the anticipation was almost unbearable" | Show the specific almost-moment and what delays it |
| "release washed over them" | Show the specific physical experience |
| "their chemistry was combustible" | Show the specific interaction that demonstrates it |
| "skin against skin" | Show whose skin, where, and what it feels like |
| "she lost herself in the moment" | Show what specifically she stopped being aware of and what she was aware of instead |
| "every nerve was on fire" | Show one specific nerve, one specific point on the body, one specific response |
| "his eyes drank her in" | Show what he is specifically looking at and what registers about it |
| "she'd never felt anything like it" | Show what specifically distinguishes this moment from prior moments |
| "their souls connected" | Cut; show the specific exchange that constitutes the connection |
| "he was everything she'd ever wanted" | Show the specific quality and the specific moment she registers it |
| "she came undone" / "he came apart" | Show the specific experience through specific sensation |

## Genre-Specific Revision Rules

Six revision passes specific to erotica, each with a single
question, run cover-to-cover before the next begins. Erotica
revision must hold the form's ethical surface (consent),
sensory specificity (the scenes' working register), character
integrity (people, not bodies in costumes), emotional
architecture (the encounters as character work), heat
calibration (commitment to the chosen tier), and contract
consistency (the genre-positioning question) — each
distinct, each requiring its own attention. The passes below
are ordered to surface ethical / consent failures first
(non-negotiable in contemporary genre standards), craft and
character failures next, structural and contractual failures
last when the rest of the book is sound.

### Pass 1: Consent Audit

Verify every intimate scene operates with clear, ongoing,
enthusiastic consent legible in the prose without breaking
the register. Build a consent ledger: every intimate scene,
with notes on how consent was established (verbal, behavioural,
prior negotiated agreement, in-scene check-in), how it was
maintained (continued cues, partner attentiveness, the moment
of pause that could have become a refusal), and how it would
operate if circumstances changed (the established safe word,
the partner's awareness of the shift, the willingness to
stop). Check that every "no" or hesitation is respected
immediately — not "respected after one more push", not
"respected after the partner made the case", not "respected
after the protagonist convinced themselves they wanted to
continue". Confirm power dynamics are acknowledged and
navigated ethically: where the relationship is
asymmetrical (employer/employee, established/new, dominant/
submissive within negotiated dynamic, or any other power
gradient), the asymmetry is visible in the prose and the
consent operates against it rather than as if it didn't
exist. Flag any scene where consent could be read as dubious
— the moment the reader, on careful reading, would have
questions about whether what occurred was wanted by both
parties. Erotica's contemporary standard is unambiguous;
where the manuscript inherits older conventions
(surprising-yielding, "she didn't know she wanted it", the
ravishment scene that 1980s genre convention permitted),
those scenes must be revised toward current standards or
explicitly framed within the negotiated-dynamic
sub-conventions that contemporary readers recognise as
intentional.

### Pass 2: Sensory Richness Audit

Audit each intimate scene for sensory range. Erotica's
working register requires that scenes engage the body
fully — not only sight (the form's most-default sense) but
also touch (specific surfaces, temperatures, pressures,
textures), sound (breath, voice, ambient sound, the body's
own sounds), scent (skin, hair, sweat, perfume, the room),
taste (where applicable), and the often-neglected
proprioceptive senses (balance, position, the body's
awareness of its own state). Check that internal sensation
is described — not only what the body is doing externally
but what it is feeling internally (the heat distribution,
the tightness, the heaviness, the specific quality of
sensation in this moment that is different from the same
sensation in another moment). Verify variety in descriptive
language: erotica accumulates many encounters, and lazy
revision deploys the same vocabulary (the same "moan", the
same "shudder", the same "ache") across them. Build a
descriptor frequency count for the manuscript and flag terms
appearing more than three times across encounters; each
deserves a fresh rendering. Confirm emotional state is
tracked alongside physical state — the body's response is
not separate from what the character is feeling, and the
prose should integrate the two registers rather than
alternating between them.

### Pass 3: Character Voice Integrity

Read each character's intimate moments in isolation, with
attribution stripped. Is the character's voice distinct,
recognisable, consistent with how they speak and think
outside intimate scenes? The genre's most-flagged failure is
the character whose personality vanishes during sex scenes
— the witty heroine becomes a generic body-receiving
expressions of pleasure; the reserved hero becomes a generic
body delivering them. Verify personality persists through
intimacy: the witty character is witty during sex, with the
specific dryness or sharpness or sweetness of their wit
shaping how they respond; the reserved character is
reserved, with the rare exception of opening becoming the
encounter's emotional weight. Check that desire specifics
are character-appropriate — what each character wants, asks
for, refuses, or surprises themselves by enjoying must
follow from who they are outside the bedroom. Confirm
agency is visible for all participants — the prose tracks
each character's interior decision-making (what they choose,
what they enjoy, what they decide to allow, what they
require). Test: read the dialogue from three intimate
scenes with names removed. Can the reader identify each
speaker by voice alone? If not, the voices are blurring
during intimacy and the characters are becoming bodies.

### Pass 4: Emotional Arc

Track the vulnerability escalation across the full manuscript.
Erotica's encounters cumulatively form an emotional arc — the
first encounter establishes baseline, each subsequent
encounter should expose a new layer or shift the relationship
in a new direction, and the climactic encounter (typically
the deepest emotional moment, not necessarily the most
explicit) should be the most emotionally meaningful. Map the
emotional trajectory: at what scene does each character
expose what aspect of themselves? At what scene does each
character ask for what previously unasked thing? At what
scene does each character refuse what they had previously
permitted, or permit what they had previously refused? The
arc should be readable as character work, not just as
encounter sequence.

Verify each encounter reveals something new about character
or relationship. Encounters that occupy the same emotional
function are redundant; one of them should be cut,
condensed, or repositioned. Verify emotional aftermath is
shown rather than skipped. The scene that ends with climax
and skips to the next morning erases the genre's deepest
register; the aftermath beats, even compressed, must register.
Confirm the climactic encounter is the most emotionally
meaningful — not the most acrobatic, not the most graphic,
not the longest, but the one that requires the most of the
characters and reveals the most. Test: at the climactic
encounter, can the reader identify what specifically about
this moment makes it different from every prior encounter?
If not, the arc has not landed.

### Pass 5: Heat Level Consistency

Track intensity across all encounters. Verify the manuscript
escalates appropriately or varies intentionally — random
intensity drops without narrative reason are the failure
mode that signals the writer's discomfort with maintaining
heat. Build an intensity chart: each encounter scored on a
1–5 scale for explicitness, and the pattern of scores
across the book examined for coherence. The pattern should
follow the emotional arc — early encounters at lower
intensity to establish the relationship; mid-book peak; the
climactic encounter at maximum (typically 5) but with
emotional weight that distinguishes it from earlier high-
intensity scenes. Check that anticipation scenes carry
erotic charge proportional to the encounters they set up; an
anticipation scene that runs flat undermines the encounter
that follows.

Verify variety in encounter types — tone (tender, urgent,
playful, intense, reverent, raw), setting (location matters
for charge), dynamic (who is initiating, who is leading,
who is more vulnerable in this scene). Six encounters that
are tonally identical fail the variety discipline; six
encounters that are tonally varied build a richer cumulative
experience. Confirm no arbitrary intensity drops without
narrative reason. If the explicit content drops in chapter
twelve, the prose must register why — emotional rupture,
external interruption, deliberate choice — rather than
allowing the reader to feel the writer pulled back without
explanation.

### Pass 6: Genre Contract Audit

Run a final pass on the manuscript's calibrated contract
with its reader. Erotica's sub-genres differ significantly,
and the book must commit to a specific point on the
spectrum and hold it. Audit:

- **Plot-to-content ratio.** What ratio did the manuscript
  declare in its opening chapter (heavy plot with distributed
  encounters; encounter-dense with frame plot; balanced)?
  Is that ratio sustained? Drift toward more plot or more
  content midway through reads as the writer losing
  confidence in their original choice.
- **Heat tier consistency.** The chosen tier (explicit-but-
  restrained / full-explicit / extreme) operating across all
  encounters. The book that operates at full-explicit through
  the first ten encounters and shifts to extreme in the last
  three has not calibrated; the book that operates at
  extreme throughout and pulls back in the climactic encounter
  has lost trust in its own register at the worst possible
  moment.
- **Sub-genre observance.** If the manuscript is BDSM
  erotica, queer erotica, ménage, specific-fetish, or
  another sub-genre with established conventions, has it
  observed the conventions or signalled deliberately when
  departing? Sub-genre readers select for specific
  conventions and detect both unintentional violations and
  intentional subversions.
- **Consent register.** Contemporary expectations are
  unambiguous, ongoing, enthusiastic. Has the manuscript
  consistently held this register? Older conventions handled
  unintentionally read as harm; older conventions handled
  intentionally within negotiated-dynamic sub-conventions
  read as the genre's signature pleasure. The difference is
  the prose's awareness of what it is doing.
- **Character continuity through encounters.** Even at high
  encounter density, characters retain the same desires,
  preferences, refusals, kinks, and emotional patterns. The
  preference declared in encounter three appears (or is
  specifically refused) in encounter ten; the refusal in
  encounter five is remembered in encounter twelve. Test
  by listing each character's stated and demonstrated
  preferences across the book — the list should be coherent
  and progressive, not contradictory or random.

The pass is not asking the manuscript to be more cautious;
it is asking the manuscript to know what it is. Erotica's
contract is specific, and the form's strongest practitioners
hold their contract with the reader the way other genres
hold theirs.

## Names & Patterns to Avoid

### Forbidden Prose Patterns
- "Throbbing member," "love button," "manhood," "womanhood". purple prose clichés
- "Down there," "private parts," "nether regions". infantilising euphemisms
- "He ravished her". non-consent euphemisms presented positively
- "She couldn't resist". removal of agency disguised as passion
- "Their bodies became one". vague abstraction replacing specific sensation
- Orgasms described with identical language every time
- "He/she was so beautiful that...". worth tied to appearance
- "Despite herself, she wanted...". desire presented as shameful

### Cliché Setups to Avoid
- The billionaire who "claims" the innocent protagonist
- The "ravishment" framed as romantic destiny
- Women who never initiate and only respond
- Pain presented as inherently erotic without negotiation
- The first time being perfect and simultaneous
- The partner who "just knows" without communication
- Virginity as the ultimate gift to be bestowed

### Names to Avoid
- Character names that sound like romance novel generators (Blaze, Storm, etc.) unless deliberately parodic
- Names that are themselves innuendo

## Comp Titles

Erotica's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Lady Chatterley's Lover* — D.H. Lawrence (1928): the literary-erotic lineage.
- *Story of O* — Pauline Réage (1954): the BDSM-erotica template.
- *Delta of Venus* — Anaïs Nin (1977): literary erotica anchor.
- *The Sleeping Beauty Trilogy* — Anne Rice writing as A.N. Roquelaure (1983-1985): genre-defining BDSM-fantasy erotica.

### Contemporary (current best-in-class)

- *Fifty Shades of Grey* — E.L. James (2011): mass-market BDSM-erotica benchmark; defined modern category.
- *Bared to You* — Sylvia Day (2012): contemporary BDSM-erotica with full romance arc.
- *Beautiful Bastard* — Christina Lauren (2013): contemporary erotic-romance.
- *Slow Heat* — various m/m erotica 2019-2023: queer-erotica market category.
- *Priest* — Sierra Simone (2015): controversial / forbidden-frame erotic romance.
- *Kingdom of the Wicked* — Kerri Maniscalco (2020): paranormal-erotica crossover into romantasy.

## Cover Design Specifications

### Visual Tone
- Sensual and tasteful. suggestive rather than explicit
- High-quality photography or artistic illustration
- Skin tones warm and inviting
- Atmosphere of intimacy and desire

### Key Visual Elements
- Partial bodies. shoulders, hands, torsos suggesting closeness
- Intimate proximity between figures without explicit content
- Luxurious textures. silk, skin, shadow
- Warm, low lighting atmospherics

### Typography
- Elegant script or serif fonts for title
- Author name prominent (erotica is often author-brand driven)
- Subtitle or series name if applicable
- Font colour coordinated with warm palette

### Colour Palette
- Primary: Deep reds, burgundy, warm golds, dark navy
- Accent: Rose gold, champagne, deep purple
- Avoid: Clinical whites, cold blues, neon colours
- Shadows and gradients to create mood and mystery

### Comp Titles (Cover Style Reference)
- *Bared to You* by Sylvia Day. intimate close-up, dark palette, elegant type
- *The Flame and the Flower* by Kathleen Woodiwiss. romantic embrace, period detail
- *Sierra Simone* covers. artistic, moody, sophisticated
- *Tiffany Reisz* covers. dark, suggestive, literary feel
