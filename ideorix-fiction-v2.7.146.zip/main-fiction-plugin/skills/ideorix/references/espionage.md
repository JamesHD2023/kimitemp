---
name: espionage-genre
description: Genre-specific instructions for espionage/spy thriller fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [thriller]
---

# Espionage. Genre Plugin

## Metadata
- id: espionage
- name: Espionage / Spy Thriller
- icon: 🔐
- category: Fiction
- minWords: 3000
- targetWords: "3,000-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Hero's Journey", "Thriller Beats"]

## Subgenre Options
Present during setup:
- **Literary Espionage**. Cerebral, morally complex, institutional rot (le Carre, Mick Herron). Emphasis on character psychology, bureaucratic infighting, and the personal cost of secrets. Slower burn, denser prose, ambiguous endings.
- **Action Espionage**. Globe-trotting, set-piece driven, higher body count (Fleming, Daniel Silva, Vince Flynn). Emphasis on tradecraft sequences, physical danger, and momentum. Cleaner moral lines, more decisive protagonists.
- **Cold War**. Historical setting (1945-1991), Berlin Wall geography, ideological stakes. Divided cities, defections, nuclear anxiety. The enemy is a mirror image. Research-intensive period detail required.
- **Modern / Cyber**. Post-9/11, surveillance state, cyber warfare, drone strikes, asymmetric threats. SIGINT vs HUMINT tension. Technology as both tool and theme. Privacy, mass surveillance, and algorithmic intelligence as plot engines.
- **Historical**. Pre-Cold War espionage (WWI, WWII, Elizabethan, Napoleonic). Period-accurate tradecraft, slower communication, courier networks, code-breaking. The birth of intelligence services as institutions.

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-4,500 words
- Pacing: Tension ratchets. alternates between slow-burn surveillance/analysis
  and sudden violent action. Long quiet stretches make the violence hit harder.
- Must open with: An operative in motion (surveillance, meeting, border crossing),
  an intelligence report that changes the equation, or a scene establishing cover identity.

BEATS PER CHAPTER
1. Intelligence Beat. New information acquired, analysed, or acted upon
   (intercept, debrief, surveillance take, asset meeting, document review)
2. Tradecraft Sequence. At least one operational detail per chapter
   (dead drop, SDR, brush pass, safe house protocol, comms procedure, cover maintenance)
3. Trust/Betrayal Moment. Someone lies, withholds, tests loyalty, or reveals allegiance
4. Geopolitical Grounding. Brief anchor to the larger political stakes
   (news report, diplomatic context, agency directive, political pressure)
5. Personal Cost Beat. The toll on the operative's humanity, relationships, or identity

INTELLIGENCE OPERATION ARCHITECTURE
- The central operation must be established by Chapter 2 (the mission, the target, the stakes)
- The opposition must be credible. professional, resourceful, with their own logic
- Minimum 3 layers of deception operating simultaneously:
  - Layer 1: The surface operation (what most characters believe is happening)
  - Layer 2: The real operation (what the protagonist's service is actually doing)
  - Layer 3: The hidden game (what someone is concealing from everyone)
- At least one major revelation per act that reframes everything before it
- The mole/traitor (if present) must be one of 3-5 plausible candidates
- Resolution must feel inevitable in hindsight. every clue was there

OPERATIONAL PLANNING REQUIREMENTS
- Every operation has a plausible objective, timeline, and risk assessment
- Cover stories must be detailed enough to withstand scrutiny
- Safe houses, dead drops, and meeting sites must be geographically specific
- Communication protocols must be established and consistently followed
- Extraction plans must exist (even if they fail)

DUAL NARRATIVE STRUCTURE (COMMON)
- Handler/Controller perspective (Whitehall, Langley, Yasenevo). strategic, political
- Field operative perspective. immediate, visceral, isolated
- The gap between what HQ believes and what the field knows IS the story
- If using multiple POVs across factions, each must have internally consistent logic

CHAPTER ENDING REQUIREMENTS
- Every chapter ends with: a piece of intelligence that changes the picture,
  a trust fracture, an operational complication, or a quiet dread
- Use: intercepted communication, failed dead drop, cover nearly blown,
  asset going dark, political pressure shifting the mission parameters
- NEVER use: action-movie cliffhangers divorced from intelligence logic,
  "he didn't know he was being watched" without establishing the watcher's POV,
  cheap misdirection that cheats the reader

FORBIDDEN IN ESPIONAGE FICTION
- Omniscient protagonists who anticipate every move (spies make mistakes)
- Technology that doesn't exist in the story's era
- Intelligence agencies portrayed as either all-knowing or entirely incompetent
- Cartoonish villains without credible motivation
- Torture scenes played for excitement rather than moral weight
- Romance that overrides operational logic (an operative who blows cover
  for a love interest without consequences is fantasy, not espionage)
- Perfect operations (something ALWAYS goes wrong)
- Explaining tradecraft to the reader through clumsy exposition
  (show it in action, let the reader infer)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (tradecraft tension), Captivation (atmosphere of secrecy), Revelation at intel reveals.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Third close past tense (standard) OR first person past tense (for literary espionage)
- Multiple POV permitted and encouraged. operatives, handlers, opposition, assets
- Voice: Precise, controlled, observant. The prose mirrors the operative's discipline.
  Emotion is conveyed through what is NOT said, through small physical details,
  through the gap between professional composure and interior turmoil.
- Tone: Controlled tension. Even quiet scenes carry the weight of what could go wrong.
  The reader should feel the operative's hyperawareness. every stranger is a potential
  threat, every phone call might be monitored, every friendship might be a recruitment.

LITERARY ESPIONAGE MODE (le Carre / Herron):
- Prose is denser, more reflective, with longer sentences and subordinate clauses
- Interior monologue is rich. operatives think in layers
- Irony is structural (the system betrays those who serve it most faithfully)
- Dialogue is indirect. characters talk around what they mean
- Bureaucratic language as a weapon (memos, minutes, institutional euphemism)
- Physical action is brief, ugly, and unglamorous
- The most important scenes happen in shabby offices and anonymous cafes

ACTION ESPIONAGE MODE (Fleming / Silva):
- Prose is leaner, more kinetic, with shorter paragraphs during action
- Sensory detail emphasises the exotic. locations, food, clothing, vehicles
- Dialogue is sharper, with more direct confrontation
- Action sequences are choreographed with spatial precision
- The operative is more physically capable but still vulnerable
- Set pieces drive the narrative (chase, infiltration, assassination, escape)
- Tradecraft is visible and tactile (gadgets, weapons, vehicles)

DIALECT CONSISTENCY (IMPORTANT. MULTI-NATIONAL AWARENESS)
- Establish the PRIMARY dialect in the Story Bible (British English, American English, etc.)
- Maintain 100% consistency in narration throughout
- Common British/American traps to watch:
  - autumn / fall
  - colour / color
  - pavement / sidewalk
  - boot (of car) / trunk
  - torch / flashlight
  - flat / apartment
  - "have got" / "gotten"
  - mobile / cell phone
  - post / mail
- Espionage-specific dialect traps:
  - SIS / CIA (British = SIS or MI6; American = CIA)
  - operative / agent (in British intelligence, "agent" = recruited asset, NOT the
    officer; the officer is the "handler" or "case officer")
  - station / field office (terminology varies by service)
  - boot / trunk (vehicles. critical in surveillance/chase scenes)
  - petrol / gas (vehicles)
  - number plate / license plate
- If British English: NEVER use "fall" for autumn, "gotten", "apartment" for "flat",
  or "cell phone" for "mobile"
- CHARACTER DIALOGUE may use their OWN national dialect (an American CIA officer
  speaks American English even in a British-narrated novel). but the NARRATION
  must remain consistent in the primary dialect
- The Prose Craft Improver should scan for dialect inconsistencies during its pass

PROSE IMPERATIVES
- Tradecraft shown in action, NEVER explained in lecture mode
  BAD: "A dead drop is a secret location where..."
  GOOD: "He wedged the magnetic container behind the drainpipe, checked
         his six, and kept walking."
- Physical environments rendered with surveillance-trained precision
  (exits, sight lines, crowd density, camera positions, ambient noise)
- Time rendered precisely. operatives think in minutes, not vague stretches
- Weather and light as operational factors, not decoration
  (rain affects surveillance, darkness enables movement, snow preserves tracks)
- Foreign languages handled with light touch (a phrase, a sentence).
  never full paragraphs untranslated, never phonetic accents
- Alcohol and exhaustion as recurring textures (spies drink, spies don't sleep)

PROSE RHYTHM MAPPING (CRITICAL. tradecraft + stakes in the sentence)

Espionage prose operates in two registers that alternate like breathing:
the precise, clinical mode of operations, and the longer, analytical
mode of planning and reflection. The reader should feel the operative's
discipline in the prose itself. controlled, watchful, economical.

Chapter 1 prose rhythm:
- Operational prose: 10-15 words per sentence. Clipped, precise,
  present-tense feeling even in past tense. Verbs dominate. The
  operative acts, observes, assesses. No decoration. "He checked his
  six. Clean. He crossed." The brevity IS the tradecraft.
- Analytical/planning prose: 18-25 words per sentence. The operative's
  mind working through scenarios, weighing probabilities, assessing
  assets and threats. These passages breathe. subordinate clauses,
  conditional thinking, layered assessment.
- Dual-world rhythm: alternate between professional calm and personal
  cost. The operative completes a dead drop in clinical prose. then a
  sentence about the daughter's birthday missed, rendered in a
  different register. The contrast is the genre's emotional engine.
- Dialogue density: coded, spare, subtext-heavy. 25-35% by word count.
  Operatives say less than they know. The real conversation happens
  beneath the surface. Debriefing scenes: clipped Q&A rhythm. Social
  cover scenes: warmer but always with an operative's watchfulness.
- Tension floor: ≥6. Espionage tension is ambient paranoia. the
  operative's hyperawareness that any stranger could be surveillance,
  any phone could be monitored, any ally could be turned. The prose
  carries this as a constant hum beneath every scene.

TRADECRAFT IN PROSE (CRITICAL)
- Surveillance Detection Routes (SDRs): Show the operative walking, doubling back,
  using reflective surfaces, changing pace. make the reader FEEL the paranoia
  without explaining it. The character's behaviour tells the reader what's happening.
- Dead drops: Describe the physical action precisely. The placement, the signal,
  the timing. Make it tactile.
- Brush passes: Quick, precise, almost invisible. Render in a single fluid paragraph.
  The reader should almost miss it, like a bystander would.
- Cover identity: Show the effort of maintaining a false life. the rehearsed
  biography, the fake family photos, the accent that slips when tired.
- Interrogation: Not Hollywood shouting. Real interrogation is patience, rapport-building,
  finding the psychological lever. Or silence. Long, terrible silence.

DIALOGUE FOR ESPIONAGE
- Operatives speak in careful, edited sentences. trained to reveal nothing
- Subtext carries the real conversation (what they're NOT saying matters most)
- Intelligence jargon used naturally, never glossed:
  "blown," "legend," "pocket litter," "sheep-dipped," "walk-in," "dangle,"
  "honey trap," "cut-out," "back-channel," "burned," "exfiltrated," "rolled up"
- Different agencies have different verbal cultures:
  MI6: understatement, euphemism, class markers
  CIA: corporate jargon mixed with military directness
  SVR/KGB: formal, hierarchical, ideological undertones
  Mossad: blunt, pragmatic, fatalistic humour
- Assets and civilians speak differently from trained officers.
  more emotional, less controlled, prone to dangerous honesty
- Debriefing scenes: Question-and-answer rhythm, with the debriefer
  controlling pace and direction. Information extracted, not volunteered.

THE MORAL REGISTER (CRITICAL)
- "Our" side does terrible things. show this without excuse or hand-wringing
- Operatives rationalise: "It's necessary." The prose should let the reader
  decide whether to believe them.
- The human cost of intelligence work is never abstract. it has a face,
  a name, a family left behind
- Betrayal of an asset is the genre's original sin. when the service
  abandons someone who trusted them, the reader must feel the weight
- No clean hands. No pure heroes. The best operatives are the ones
  who still feel the damage they do.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

INTELLIGENCE CRAFT (35% of total):
- Tradecraft authenticity: Do operations follow plausible intelligence procedures? (0-100)
- Operational logic: Do plans, contingencies, and failures make sense? (0-100)
- Information control: Is knowledge compartmentalised believably? (0-100)
- Deception layers: Are multiple levels of deception maintained consistently? (0-100)

TENSION & PARANOIA (25% of total):
- Atmosphere of distrust: Does the reader feel that anyone could be compromised? (0-100)
- Pacing: Do quiet surveillance scenes build tension rather than drag? (0-100)
- Stakes escalation: Do consequences compound across the narrative? (0-100)
- Operational suspense: Does the reader worry about blown covers and failed ops? (0-100)

MORAL COMPLEXITY (20% of total):
- Moral ambiguity: Are "our" side's actions shown without whitewashing? (0-100)
- Human cost: Is the personal toll of espionage rendered concretely? (0-100)
- Antagonist credibility: Does the opposition have comprehensible motivations? (0-100)
- Institutional critique: Is the intelligence bureaucracy shown honestly? (0-100)

PROSE QUALITY (20% of total):
- Show vs tell ratio (tradecraft shown in action, not explained) (0-100)
- Dialogue differentiation (agency culture, rank, nationality) (0-100)
- Environmental precision (surveillance-trained observation) (0-100)
- Subtext quality (conversations carrying hidden meanings) (0-100)

AUTOMATIC FAILS (score = 0):
- Omniscient protagonist who never makes mistakes or is surprised
- Technology anachronisms (tools that don't exist in the story's time period)
- Torture portrayed as reliable intelligence-gathering (it isn't)
- Intelligence agencies as monolithic good/evil organisations with no internal dissent
- TRADECRAFT DRIFT: Operations that ignore basic security protocols without consequence
- TONE DRIFT: Action-movie quipping during life-threatening situations (unless Action subgenre)
- MOTIVATION DRIFT: Antagonists who are evil for evil's sake with no political/personal logic
- Cover identities that are never tested or strained
- The protagonist solves everything through violence alone
- Espionage jargon used incorrectly or inconsistently
```

## Continuity Rules

```
ESPIONAGE CONTINUITY. WHAT TO TRACK

OPERATIONAL STATE (CRITICAL):
- What is the current mission objective? Has it changed? Who authorised changes?
- Which assets are active, dormant, burned, or dead?
- What intelligence has been confirmed vs suspected vs planted (disinformation)?
- Which covers are intact, strained, or blown?
- What does each faction BELIEVE is happening vs what IS happening?
- Who has been turned, doubled, or is under suspicion of being turned?

KNOWLEDGE COMPARTMENTALISATION:
- What does each character know, and HOW did they learn it?
- Who has need-to-know for which operations?
- What has been shared between agencies/services? What's being withheld?
- Track information flow: if Character A tells Character B in Chapter 4,
  Character C should NOT know in Chapter 5 unless a path exists
- What has been intercepted by the opposition?

COVER IDENTITY TRACKING:
- For each operative under cover: alias name, legend (backstory), documentation
- What has the cover identity done that can be verified or disproven?
- Who has the operative interacted with under cover? What was said?
- Any near-misses or strains on the cover story. track and escalate
- Cover behaviour must be consistent (if the cover is a businessman,
  he must occasionally do business things)

PHYSICAL/GEOGRAPHICAL CONTINUITY:
- Travel times between locations must be plausible
- Time zones must be tracked when operating across countries
- Safe house locations established and maintained
- Dead drop sites described consistently
- Embassy/station geography consistent
- Border crossing procedures appropriate to era and location

RELATIONSHIP TRACKING:
- Handler-asset relationships: trust level, leverage, payment/motivation
- Internal agency alliances and rivalries
- Which characters have met face-to-face vs only know each other by cryptonym?
- Romantic or personal entanglements and their operational implications
- Who owes whom favours? Who holds grudges?

TECHNOLOGY STATE (era-dependent):
- What communication methods are available and established?
- What surveillance capabilities exist on each side?
- Encryption/cipher status. what can each side read?
- Track any technology introduced and ensure consistent capability
```

## Character Rules

```
ESPIONAGE CHARACTER ARCHETYPES

THE PROTAGONIST OPERATIVE:
- Trained professional. competent but NOT superhuman
- Has a specific skillset (languages, surveillance, recruitment, analysis, forgery)
  and recognisable gaps in others
- Maintains cover identity with visible effort. the mask sometimes slips
- Interior life at odds with professional persona (loneliness, doubt, guilt)
- Drinks too much, sleeps badly, keeps odd hours. the lifestyle costs are real
- Loyalty is complicated: to the service, to assets, to country, to personal ethics
 . and these loyalties conflict
- LITERARY MODE: More introspective, more damaged, more aware of the irony
- ACTION MODE: More physically capable, more decisive, but still morally aware

THE HANDLER/CONTROLLER:
- Desk officer who runs agents from a distance. strategic thinker
- Sees operatives partly as people, partly as assets to be deployed
- Carries the guilt of sending people into danger from a safe office
- Political operator. navigates agency bureaucracy as a survival skill
- May genuinely care about the operative, but will sacrifice them if ordered
- Withholds information "for operational security" (and sometimes for self-protection)

THE ASSET (recruited agent):
- A civilian or foreign national providing intelligence. NOT a professional spy
- Motivated by: ideology, money, coercion, ego, or revenge (the classic MICE framework)
- Vulnerable. depends on the handler for protection
- Lives in constant fear of discovery
- May not fully understand what they're part of
- Their betrayal by the service is the genre's deepest wound

THE OPPOSITION:
- Professional intelligence officers from the other side
- Mirror image of the protagonist. same skills, same sacrifices, different flag
- Must have coherent motivations beyond "they're the enemy"
- Competent and dangerous. catching them requires skill, not luck
- At least one opposition figure should be personally compelling

THE MOLE (if present):
- One of the trusted inner circle. the betrayal must be devastating
- Motivation must be established retroactively but convincingly
  (ideology, blackmail, disillusionment, money)
- Behaviour throughout must be INDISTINGUISHABLE from loyal colleagues
  until the narrative specifically plants clues
- When revealed, the reader should be able to trace the signs backward

THE POLITICAL MASTER:
- Minister, director, senator, committee chair. the civilian authority
- Uses intelligence for political ends (not always aligned with national security)
- May be ignorant of operational realities, dangerously so
- The gap between political masters and field operatives drives key conflicts
- Can shut down operations, redirect resources, leak to press, or sacrifice operatives

THE INSTITUTIONAL BUREAUCRAT:
- Middle management within the intelligence service
- Concerned with budgets, jurisdiction, turf wars, career advancement
- May obstruct good operations for bureaucratic reasons
- Comic potential (especially in Literary Espionage) but never merely comic
- Represents the institutional inertia that grinds against operational necessity

MOLE SUSPECT BALANCE (Writer-Level Enforcement. MOLE HUNT plots ONLY):
When the plot involves a mole hunt, apply the SAME equal-treatment rules as
mystery fiction. This is the espionage equivalent of suspect balance:
- Track MENTIONS per suspect per chapter (named references + pronoun references)
- Track SUSPICION BEATS per suspect (moments that make them look guilty)
- Track EXONERATION BEATS per suspect (moments that make them look innocent)
- BALANCE RULE: No single suspect should receive more than 1.5× the average
  mentions across any 3-chapter window. If they do, redistribute.
- SUSPICION DISTRIBUTION: Each suspect must receive at least 2 suspicion beats
  and 2 exoneration beats before the midpoint. The reader must be able to argue
  for ANY suspect being the mole.
- The actual mole must receive NO MORE suspicion beats than the most-suspected
  innocent suspect. If the mole is the most suspicious, the mystery fails.
- FALSE TRAIL: At least one suspect must be MORE suspicious than the real mole
  at the midpoint.

OPPOSITION PRESENCE BALANCE (ALL espionage plots):
The opposition must maintain consistent narrative pressure:
- Per-chapter minimum: At least ONE beat where the opposition's presence, actions,
  or consequences are felt
- No more than 2 consecutive chapters without DIRECT opposition presence
- Opposition competence must be demonstrated in EVERY act. they are professionals
- The Character Tracker will flag chapters where opposition presence drops below threshold

VOICE DIFFERENTIATION REQUIREMENTS:
- Operatives: controlled, precise, layered subtext
- Assets: emotional, frightened, prone to dangerous candour
- Handlers: measured, slightly detached, comfortable with ambiguity
- Political figures: performative, agenda-driven, uncomfortable with operational detail
- Analysts: data-focused, qualified statements, hedging language
- Military/paramilitary: direct, hierarchical, action-oriented
- Each nationality has verbal patterns WITHOUT caricature or phonetic accents

VOICE DIFFERENTIATION. QUANTITATIVE CHECK:
For each PAIR of major characters, identify at least 3 distinguishing dialogue features.
If any two characters share >2 features, one must be revised before proceeding.

Espionage fiction has the highest risk of voice convergence because multiple characters
are trained professionals who speak carefully. Ensure different:
- Sentence construction (one clipped/military, one measured/diplomatic, one verbose/academic)
- Professional register (operative: field-practical; handler: strategic; analyst: data-heavy;
  political: performative; asset: civilian)
- Emotional leakage (one is controlled, one cracks under pressure, one hides emotion
  behind wit, one is dangerously candid)
- Information management (one volunteers nothing, one uses information as currency,
  one speaks in half-truths, one is blunt to a fault)
- National verbal patterns (without caricature. an American uses "I guess" where
  a Brit uses "I suppose"; a Russian may omit articles in English dialogue)

The Character Tracker verification agent will flag voice convergence between
any two major characters. If flagged, the Writer must differentiate before proceeding.
```

## Arc Rules

```
ESPIONAGE STORY STRUCTURE

ACT 1: THE BRIEFING (Chapters 1-5 for standard, 1-3 for novella)
- Establish the operative in their world (cover life, service life, or both)
- The inciting intelligence: an intercept, a walk-in, a defector, an anomaly
- The mission assigned or discovered. what must be done and why
- Introduce the key players: handler, asset(s), opposition, political authority
- Establish the first layer of deception (what appears to be happening)
- Set the geopolitical context (stakes beyond the personal)
- Plant the first trust fracture (small, deniable, but the reader notices)

ACT 2A: THE OPERATION (Chapters 6-12 for standard, 4-7 for novella)
- The operation in motion. tradecraft sequences, meetings, surveillance
- Each chapter deepens the operative's immersion and isolation
- Asset management: recruitment, handling, or protection
- The opposition becomes active. counter-surveillance, blown contacts, threats
- Cover identity under increasing strain
- Intelligence picture develops. but is it real or disinformation?
- Midpoint revelation: The second layer of deception revealed
  (what's ACTUALLY happening is different from what was briefed)
- The operative must decide: follow orders or follow the truth?

ACT 2B: THE WILDERNESS OF MIRRORS (Chapters 13-18 for standard, 8-10 for novella)
- Trust collapses. who is working for whom?
- The mole hunt intensifies (if applicable). suspicion falls on multiple candidates
- Personal cost escalates: relationships destroyed, cover crumbling, asset endangered
- The opposition closes in. the operative is running out of time and allies
- Dark night of the soul: The operative questions everything
  (the mission, the service, their own moral compass)
- Third layer of deception revealed or suspected
- An asset or colleague is sacrificed (willingly or otherwise)

ACT 3: COMING IN FROM THE COLD (Chapters 19-24 for standard, 11-14 for novella)
- The final play. the operative acts on what they now understand
- The mole/traitor revealed (if applicable). through evidence, not confession
- Confrontation: operational, not necessarily violent
  (the most devastating weapon in espionage is information)
- The political aftermath. who claims credit, who is sacrificed
- The moral reckoning: Was it worth it? The answer is never simply "yes"
- Resolution: The operative survives but is changed
  LITERARY MODE: Ambiguous ending, institutional betrayal, personal isolation
  ACTION MODE: Clearer resolution, but with visible scars and lingering questions

THE CLIMAX SEQUENCE. THE FINAL PLAY:
The espionage climax is an OPERATION. but one where the stakes are
personal as well as geopolitical. Structure across 3-4 chapters:

Chapter N-3 (THE BRIEFING / THE DECISION):
- The operative now knows the full truth (the mole, the real mission,
  the betrayal within the service). They must decide: follow orders
  (which may mean sacrificing an asset) or follow conscience.
- Final operational planning: the meeting, the exchange, the trap.
  Show tradecraft details with precision. this is the payoff for
  all the procedural groundwork laid in Acts 1-2.
- A personal beat: the operative contacts someone from their real life
  (or chooses not to). The distance between cover identity and true
  self has never been wider.

Chapter N-2 (THE OPERATION):
- The plan in motion. Tradecraft sequences at their most intense:
  SDR running, signals, timing, coordination across locations.
- The first complication: the opposition is closer than expected,
  or an ally doesn't appear, or the asset panics.
- LITERARY MODE: The complication is moral (doing the right thing
  will blow the operation; doing the operational thing is morally wrong).
- ACTION MODE: The complication is tactical (the op is compromised;
  improvisation under fire required).
- Time compression: Show precise timestamps. Minutes matter.

Chapter N-1 (THE REVEAL / THE CONFRONTATION):
- The mole revealed (if applicable). through accumulated evidence
  converging in a single moment. NOT through confession.
- Confrontation: quiet, devastating, professional. Two intelligence
  officers who know exactly what the other knows. Subtext heavier
  than text. The most important things are left unsaid.
- OR: The operative completes the mission. extracts the asset,
  delivers the intelligence, neutralises the threat. but sees
  the full cost of what the service required.
- The political machinery begins: who gets credit, who gets blamed,
  who gets erased from the record.

Chapter N (THE DEBRIEF):
- The operative sits in a room and tells the story (or doesn't).
- What they say vs what they withhold defines who they've become.
- The service offers something: a promotion, a posting, retirement,
  a new assignment. The offer reveals the service's values.
- The operative's choice reveals theirs.
- Final image: the operative alone. The world continues. The cost
  is carried quietly. In espionage, there is no parade.

TENSION ARC:
- Starts with professional competence (controlled, methodical)
- Builds through accumulating uncertainty (each chapter adds a new doubt)
- Paranoia escalates as trust erodes (the operative's world contracts)
- Peak at the wilderness of mirrors (nothing is reliable, including the protagonist's judgment)
- Brief operational clarity before the final play
- Resolution carries weight. victory in espionage always tastes of ash

THE MOLE HUNT ARC (if applicable):
- Suspicion introduced gradually. an anomaly, a failed operation, a leak
- 3-5 plausible candidates, each with circumstantial evidence
- Investigation must be covert (the mole is watching the investigation)
- Each candidate gets equal narrative treatment (same rule as mystery. see below)
- Red herring suspects eliminated through operational logic, not convenience
- The reveal recontextualises earlier scenes. the reader should think
  "That's why that happened in Chapter 6"
- The mole's motivation must be humanly comprehensible
```

## Timeline Rules

```
ESPIONAGE TIMELINE TRACKING

OPERATIONAL TIMELINE:
- When was the operation authorised? What is the deadline?
- Track the real-time duration of the story (days, weeks, months)
- Each chapter should cover a clear time period with precise timestamps
- Night operations, surveillance shifts, and meeting times must be exact
- Jet lag is real. an operative arriving from a 10-hour flight is not fresh

TRAVEL AND GEOGRAPHY:
- Flight times between locations must be accurate for the era
- Time zone differences must be tracked and referenced
  (when it's 3 AM in London, it's 10 PM in Washington, 6 AM in Moscow)
- Passport control, customs, border crossings take time and carry risk
- Driving times, train schedules, and local transit must be plausible
- An operative cannot be in Berlin at 2 PM and Moscow at 5 PM

COMMUNICATION TIMING:
- Intelligence takes time to reach its audience:
  Dead drop → retrieval → transport → decryption → analysis → briefing
- Encrypted radio, satellite phone, coded message. each has a delay
- The gap between when something happens and when HQ knows about it
  is a crucial source of dramatic tension
- In Cold War settings: diplomatic pouch timelines, one-time pad delays
- In modern settings: real-time capability exists but is not universal

GEOPOLITICAL TIMELINE:
- Real-world events referenced must be accurately dated (if historical)
- Political contexts (elections, summits, crises) progress at real-world speed
- Diplomatic schedules (embassy receptions, UN sessions) create operational windows
- Seasonal factors: when does the sun set? How long are the nights?
  (This matters enormously for covert operations)

SURVEILLANCE AND COUNTER-SURVEILLANCE:
- Track which characters are under surveillance, by whom, and since when
- Note when surveillance is detected, evaded, or suspected
- Mobile surveillance teams need shift changes. track fatigue
- Static surveillance posts need line of sight. verify against described geography
- Electronic surveillance has range and interception limitations

ASSET MEETING SCHEDULE:
- Regular meetings with assets follow patterns (and patterns are dangerous)
- Track meeting locations, durations, and security protocols
- Emergency contact procedures must be established BEFORE they're needed
- If an asset misses a meeting, the consequences must be addressed
```

## Genre-Specific Craft Techniques

Espionage at the level of John le Carré, Frederick Forsyth,
Robert Ludlum, Ian Fleming, Daniel Silva, Vince Flynn,
Mick Herron, Jason Matthews, Terry Hayes, Lauren Wilkinson,
Charles Cumming, Olen Steinhauer, Joseph Kanon, Charles
McCarry, Alan Furst, Eric Ambler, Graham Greene, and
Patricia Highsmith earns its genre-defining authority
through tradecraft authenticity, institutional honesty,
and the moral weight of the form's signature betrayals.
The professional reader of espionage fiction includes
practitioners and serious followers of intelligence
services; tradecraft mistakes break the spell faster than
character or plot mistakes because they signal the writer
doesn't know the world. The form is uniquely vulnerable to
a cluster of failure modes that AI-generated drafts hit
with predictable frequency: **Tradecraft-by-Movie**
(operational detail sourced from films and other thrillers
rather than from actual service / period / jurisdiction
research — the genre's single most-flagged failure);
**Tradecraft Drift** (operations that ignore basic security
protocols without consequence, breaking the form's
discipline contract); **Omniscient-Protagonist Failure**
(operatives who anticipate every move and never make
mistakes — real spies make mistakes, and competence is
demonstrated through recovery, not infallibility);
**Anachronism Drift** (technology, equipment, or procedures
that don't exist in the story's era, instantly losing the
period reader); **Torture-as-Reliable-Intelligence**
(torture portrayed as effective intelligence-gathering
when in fact it produces unreliable information — the
genre's professional contract requires this be rendered
honestly); **Monolithic-Agency Caricature** (intelligence
services portrayed as either all-knowing or entirely
incompetent, with no internal dissent, factions, or
bureaucratic friction); **Cartoon-Antagonist** (opposition
without coherent motivation beyond "they're the enemy" —
the strongest espionage practitioners render adversaries
as mirror-image professionals with their own logic);
**Quipping-Tone-Drift** (action-movie quipping during
life-threatening situations, voiding the form's controlled-
discipline contract); **Romance-Overrides-Operational-
Logic** (an operative who blows cover for a love interest
without consequences — that is fantasy, not espionage);
**Bond-Villain-Speech** (the antagonist explains their
plan in monologue, voiding dramatic irony); **Cover-
Without-Strain** (cover identities that are never tested
or pressured, voiding the form's dual-life-tension
contract); and **Mole-Telegraphed** (the mole receives
narrative attention that betrays their identity to the
reader well before the reveal, voiding the equal-treatment
contract). The five canonical technique clusters below —
Tradecraft Mechanics (with six subtechniques), The Mole
Hunt Structure (with six iron rules), Geopolitical
Worldbuilding, Cover Identity Management, and Intelligence
Agency Culture (with five service-specific cultures) —
are how the form defends against these failure modes
through specificity, professional discipline, and
institutional honesty.

### Tradecraft Mechanics

Tradecraft is the skeleton of espionage fiction. It must be rendered precisely,
never explained didactically, and always serve both plot and atmosphere.

**Surveillance Detection Routes (SDRs):**
The operative walks a predetermined route designed to reveal surveillance.
Show this through behaviour. doubling back, sudden stops, entering a shop
and leaving by the back, using reflective surfaces, boarding a train and
stepping off at the last second. The reader should feel the paranoia and
discipline without being told "she was running an SDR."

**Dead Drops:**
A location where material is left for later retrieval. Details matter:
the magnetic container, the chalk mark signalling a loaded drop, the specific
bench or drainpipe or loose brick. The signal that says "drop loaded" must
differ from "drop cleared." Show the physical action. the placement, the
concealment, the casual walk away. A dead drop scene should have the tension
of a heist.

**Brush Passes:**
The momentary physical contact that transfers material. Two people pass in a
crowd, and something changes hands. a film canister, a USB drive, a folded
newspaper. Write it in a single paragraph, quick and precise. The beauty is
in its invisibility. If the reader almost misses it, you've done it right.

**Legends and Cover Identities:**
A legend is a complete false biography. Show the operative rehearsing it.
the childhood in a town they've never visited, the university degree they
never earned, the family photos of actors. Show the pocket litter: receipts,
loyalty cards, the worn photo in the wallet. Show what happens when someone
asks a question the legend doesn't cover.

**Safe Houses:**
Not glamorous. anonymous flats with thin walls and bad heating. Show the
security protocols: approach routes, signals that the house is safe or
compromised, the emergency exit, the clean phone, the go-bag. A safe house
scene should feel temporary and precarious, never comfortable.

**Recruitment and Turning:**
The most psychologically complex tradecraft. Recruitment is manipulation.
finding someone's vulnerability (greed, ideology, ego, grievance, loneliness)
and exploiting it. Show the handler building rapport, offering sympathy,
creating dependency. The moral weight should be palpable: this is a human
being whose life is being redirected, often toward danger.

### The Mole Hunt Structure

The mole hunt is espionage fiction's equivalent of the locked-room mystery.
Someone in the inner circle is a traitor. Apply the same discipline as
mystery plotting:

**6 Iron Rules for Mole Hunts:**

**Rule 1: Equal Treatment of Suspects**
The mole receives NO special narrative attention until the plot specifically
calls for a clue. Same page time, same depth of characterisation, same
narrative register. If the narrative "lingers" on the mole more than others,
the reader will guess.

**Rule 2: Operational Logic, Not Intuition**
The mole is identified through operational analysis. which operations failed,
who had access to the compromised intelligence, whose career anomalies don't
add up. Not through "a feeling" or "something about his eyes."

**Rule 3: The Investigation Must Be Covert**
The mole is watching. If the investigation becomes known, the mole will adapt,
flee, or accelerate damage. This creates a second layer of tension: the
investigator cannot use normal channels.

**Rule 4: Multiple Plausible Candidates**
Each suspect must have: opportunity (access to compromised material), possible
motive (financial stress, ideological sympathy, personal grievance), and at
least one piece of circumstantial evidence pointing toward them.

**Rule 5: Red Herrings Are Operational**
False trails arise from the same operational evidence that reveals the real
mole. A suspect's unexplained meeting has an innocent explanation; a financial
anomaly is a gambling debt, not a payment. Debunking feels like real
intelligence analysis.

**Rule 6: The Reveal Recontextualises**
When the mole is identified, earlier scenes acquire new meaning. The reader
should be able to flip back and see the signs they missed. The mole's
behaviour was always consistent with betrayal. but also consistent with
innocence, which is why it wasn't caught.

### Geopolitical Worldbuilding

The geopolitical context is not background. it is the engine that drives operations.

**For historical settings:**
- Research the actual political situation of the era and location
- Real events (summits, crises, coups, treaties) create operational deadlines
- Ideological context must be rendered from INSIDE the characters' worldview
  (a 1960s KGB officer believes in the Soviet project; a CIA officer believes
  in containment. don't impose 21st-century judgment)

**For contemporary settings:**
- Geopolitical tensions should be plausible extensions of real dynamics
- Name fictional countries or leaders if attributing specific villainy
- Cyber operations, drone warfare, and mass surveillance are current realities
- Non-state actors (terrorist cells, private intelligence firms, hackers)
  complicate the traditional state-vs-state model

**For all settings:**
- Intelligence services serve political masters, not abstract justice
- Operations are approved, modified, or cancelled for political reasons
- The gap between what an operation achieves and what politicians claim
  is a rich source of dramatic irony
- Alliances shift. today's partner service is tomorrow's adversary

### Cover Identity Management

The spy's dual life is a source of both operational tension and personal tragedy.

- Show the daily discipline of maintaining cover: the commute to a fake job,
  the social engagements with people who don't know your real name, the lies
  to a spouse or lover
- Cover strain should escalate across the narrative. small cracks first,
  then larger fractures
- The moment when someone from the operative's real life almost crosses
  into their cover life is pure dread
- Loss of identity is a theme: "I've been pretending so long I don't know
  which one is real anymore"
- Cover identities require maintenance. payments, social media presence (modern),
  visible routines, plausible explanations for absences

### Intelligence Agency Culture

Each service has its own culture, and that culture shapes how characters behave.

**MI6 (SIS):**
Class-conscious, literary, self-deprecating. Euphemism as art form ("a difficulty"
means a catastrophe). Clubbable, old-school-tie networks. The Circus (le Carre)
as a fading empire staffed by brilliant, exhausted people.

**CIA:**
Larger, more corporate, more militarised. Directorate rivalries (Operations vs
Analysis vs Science & Technology). Post-9/11 trauma and expansion. Contractor
culture. More diverse than its British counterpart, but with its own institutional
blind spots.

**SVR/FSB (formerly KGB):**
Hierarchical, paranoid, ideologically flexible. Post-Soviet identity crisis:
the old ideologues vs the new pragmatists. Institutional memory of purges
creates endemic distrust. Professional respect for the adversary.

**Mossad:**
Small, aggressive, existentially motivated. "By way of deception" as doctrine.
Kidon (assassination) units. The Holocaust as institutional memory. Willingness
to operate anywhere, diplomatic consequences be damned.

**Show these cultures through:**
- How characters address superiors (first name? Title? Surname?)
- Office furniture, dress codes, canteen food
- What's said in meetings vs what's said in corridors
- Institutional humour (dark, self-aware, culture-specific)
- How failure is treated (scapegoating, inquiry, quiet burial)

### Espionage AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "trust no one" | Show the specific betrayal risk |
| "the shadows had eyes" | Show the specific surveillance detail |
| "in this game, everyone plays both sides" | Show the specific double allegiance |
| "the intelligence was compromised" | Show how it was compromised and by whom |
| "a ghost from the past" | Name the person and their specific history |
| "the handler's voice was ice" | Show the specific words and tone |
| "the dead drop was empty" | Show the specific operational failure and its consequence |
| "layers within layers of deception" | Show ONE specific deception clearly |
| "the agency doesn't forget" | Show the specific institutional action |
| "cover blown" | Show the specific moment of exposure |
| "the extraction window was closing" | Show the specific time constraint and physical obstacle |
| "the asset went dark" | Show the specific missed signal — the chalk mark not made, the dead drop unloaded, the scheduled call that didn't come |
| "she had a feeling she was being followed" | Show the specific surveillance tell — the same coat at two locations, the reflection in the shop window, the footstep cadence |
| "the operation was compromised" | Show the specific breach indicator and the precise sequence of decisions that follow |
| "his cover was paper-thin" | Show the specific gap in the legend — the school he can't name, the second cousin he forgot, the language his accent betrays |
| "the handler had a feeling something was off" | Show the specific operational anomaly — the report that arrived late, the asset whose handwriting changed, the meeting note that didn't sound like her |
| "they were closing in" | Show what specifically — the surveillance team rotated, the safe house lease queried, the friendly police inspector suddenly transferred |
| "trust was a luxury he couldn't afford" | Show the specific moment trust is withheld and the specific operational reason it must be |

## Genre-Specific Revision Rules

### Six-Pass Espionage Audit (Run FIRST in editorial pipeline)

The Espionage Audit runs every chapter through six named
passes. Run them in order — each builds on the last.

#### Pass 1: Intelligence State + Compartmentalisation

The Intelligence State and Compartmentalisation pass
enforces the form's information-architecture contract. List
what each faction knows at chapter start and verify no
character acts on information they haven't received.
Check that the intelligence picture matches the operational
timeline (the gap between when something happens and when
HQ knows about it is a crucial source of dramatic tension
— it must be tracked, not collapsed for narrative
convenience). Confirm that compartmentalisation is
maintained throughout: need-to-know respected, information
flow paths verified (if Character A tells Character B in
Chapter 4, Character C should NOT know in Chapter 5 unless
a path exists), and any cross-agency or cross-service
information sharing tracked explicitly. The pass also
verifies that the three-layer deception architecture is
operating: the surface operation (what most characters
believe), the real operation (what the protagonist's
service is actually doing), and the hidden game (what
someone is concealing from everyone) — each layer must
be internally consistent and trackable across the
manuscript. Information-control failure is the form's
single most common structural collapse; this pass is the
first defence.

#### Pass 2: Tradecraft Authenticity + Exposition

The Tradecraft Authenticity and Exposition pass enforces
the form's professional-reader contract against
Tradecraft-by-Movie and Tradecraft Drift. Verify
operational procedures are consistent with the era and
service depicted (1960s KGB tradecraft is not 2020s SVR
tradecraft; SIS tradecraft is not CIA tradecraft;
specific service practices must be researched, not
generalised). Verify communication protocols established
earlier still apply — if dead-drop signal protocols were
defined in Chapter 4, they must operate identically in
Chapter 14 unless deliberately changed on-page. Verify
safe houses, dead drops, and meeting sites are
geographically plausible (the reader can locate them on
a map of the actual city). Verify the operative follows
their own security protocols, or has an explicit reason
for the deviation that the manuscript renders. The
critical exposition test: is tradecraft SHOWN or
EXPLAINED? Explained = rewrite. Show the SDR through the
operative's behaviour (doubling back, reflective surfaces,
boarding-and-dropping the train), never through narrator
gloss. Show the dead drop as physical action (the
magnetic container, the chalk mark, the casual walk
away), never through "she ran her dead drop." Verify
technology plausibility: capabilities must be consistent
with the era, with no anachronisms (smartphones in
Cold War narratives, modern encryption in 1970s
operations, drone capabilities in pre-2001 settings).

#### Pass 3: Cover Identity Integrity

The Cover Identity Integrity pass enforces the form's
dual-life-tension contract against Cover-Without-Strain.
Verify each operative's cover story is internally
consistent across all on-page interactions: the legend's
biographical details (childhood location, education, work
history), the pocket litter (receipts, loyalty cards,
photos), the maintained social presence (in modern
settings, the social-media legend), and the rehearsed
explanations for absences. Verify the cover has been
strained at least once per act, with the strain tracked
and escalated — small cracks first, then larger fractures
— never simply repeated at the same intensity. Verify
interactions under cover are consistent with the legend
(the businessman cover must occasionally do business
things; the journalist cover must produce journalism;
the academic cover must teach or publish). Verify the
operative maintains appropriate behaviour for the cover
role even under pressure, with any near-misses tracked
and used to escalate cover-failure tension. The pass
closes by confirming the form's dual-life-cost contract:
the moment when someone from the operative's real life
almost crosses into their cover life, the loss-of-
identity register, the discipline cost of maintaining a
false biography for months or years.

#### Pass 4: Deception Layers + Mole Hunt Fairness

The Deception Layers and Mole Hunt Fairness pass enforces
the form's reveal-architecture contract. Track all active
deceptions across the manuscript: who is deceiving whom
about what, and which deceptions are nested within others.
Verify each deception layer is internally consistent (the
deceiver's behaviour must match their secret knowledge,
not what they pretend to know). Check that revelations
genuinely reframe earlier events rather than merely
surprising — the test of a strong espionage reveal is
that earlier scenes acquire new meaning, with the reader
able to flip back and locate the signs they missed.
Confirm the reader has access to enough information to
suspect (if not solve) the deception by the climax. For
Mole Hunt Fairness (when applicable), compare narrative
treatment of all suspects: equal page time, equal tonal
register, equal depth of characterisation. Flag if the
mole receives different narrative attention — more
sinister phrasing, more lingering description, more "off"
reactions, more close-up on their facial expressions
during meetings. Verify each suspect has plausible
circumstantial evidence (opportunity / motive / one piece
of incriminating coincidence); verify red herrings are
debunked through operational logic rather than authorial
convenience. The mole must receive NO MORE suspicion
beats than the most-suspected innocent suspect — if the
mole is the most suspicious, the mystery has failed.

#### Pass 5: Geopolitical + Agency Culture + Opposition

The Geopolitical, Agency Culture, and Opposition pass
enforces the form's institutional-and-political-honesty
contract. Verify political contexts are consistent across
chapters; that real-world events referenced match real-
world chronology (a 1962 setting cannot reference a 1963
event); that diplomatic protocols are plausible for the
setting (diplomatic pouch timelines, embassy security
levels, treaty obligations all tracked); and that
political pressure on operations evolves logically (a
mission greenlit in Chapter 2 cannot survive unchanged
through a political crisis in Chapter 12 without explicit
political defence). Verify agency culture is rendered
specifically: characters from different services sound and
behave differently — MI6 class-conscious euphemism, CIA
corporate-military directness, SVR/FSB hierarchical
paranoia, Mossad blunt fatalism — with named cultural
markers (how superiors are addressed, what's said in
meetings vs. corridors, how failure is treated, what
institutional humour sounds like). Verify the opposition
maintains professional competence: at least one direct
opposition appearance per two chapters; opposition
demonstrated as adversaries who could plausibly win; the
opposition's plan internally coherent and what a
competent foreign service would actually do. Generic
"the Russians" or "the agency" without specific
institutional reality is the failure mode; specific
researched cultural texture is the technique.

#### Pass 6: Tone, Subtext, and Moral Weight

The Tone, Subtext, and Moral Weight pass is the form's
defence against Quipping-Tone-Drift, Romance-Overrides-
Operational-Logic, and the genre's broader tendency
toward action-movie register. Verify violence is ugly and
consequential, never glamorised — in literary mode
always ugly; in action mode choreographed but never
trivialised; never quipped through, never disconnected
from the operative's interior cost. Verify the narrative
acknowledges the human cost of operations: every asset
sacrificed has a face and a name and a family left
behind; every operation completed leaves the operative
diminished in some specific way; the moral register is
never abstract. Verify subtext quality: conversations
must carry hidden meanings, with the most important
things left unsaid — espionage dialogue lives in what is
NOT said. Verify the paranoia atmosphere: the reader
feels that surveillance, betrayal, and compromise are
ever-present possibilities, with the operative's
hyperawareness rendered as a constant hum beneath every
scene. Verify operational realism: operations have
logistics (funding, personnel, equipment, time
constraints) rather than resources appearing from
nowhere. Verify the political dimension: tension between
political masters and field operatives drives key
conflicts, and the gap between what an operation
achieves and what politicians claim is rendered as a
source of dramatic irony. The pass closes by confirming
the genre's signature contract: no clean hands, no pure
heroes, the best operatives are the ones who still feel
the damage they do — and the manuscript honours that
moral architecture rather than collapsing it for action-
movie clarity.

## Names & Patterns to Avoid

### Espionage-Specific Character Names. NEVER USE
- Protagonist names: Jack Stone, Alex Hunter, Jason Steele, Cole Blackwood
  (generic "action hero" names that signal fantasy, not realism)
- Female operative names: Natasha, Svetlana, Katya (unless actually Russian, and
  even then avoid the Bond-girl association by giving them ordinary surnames)
- Villain names: Viktor, Dmitri, Yuri (when used as shorthand for "sinister Russian"
  without characterisation. fine if the character is genuinely Russian with depth)
- Handler names: "M," "Control," "Mother" (le Carre owns these; find your own)
- Cryptonyms: NIGHTHAWK, DARKSTAR, SHADOWFALL (too cinematic. real cryptonyms
  are random: GTBEARD, HTLINGUAL, STROLLER)

### Espionage-Specific Organisation Names. NEVER USE
- "The Agency" without specifying which (lazy shorthand)
- "The Organisation" or "The Syndicate" (vague thriller cliches)
- "Department X" or "Section 9" (unless you're writing manga)
- Fictional agencies that are transparent CIA/MI6 clones with different acronyms

### Espionage-Specific Plot Patterns. AVOID
- The rogue agent who single-handedly outfights an entire intelligence service
- The beautiful enemy agent who switches sides for love (without operational logic)
- The "one last mission" retired operative who is pulled back in
  (unless you deliberately subvert the trope)
- The omniscient villain who has anticipated every move
- The ticking-bomb scenario used to justify torture
- The car chase through European city streets (unless it genuinely advances the plot
  and has operational consequences)
- The scene where the protagonist breaks into an embassy/government building alone
  (these places have serious security)
- Perfect disguises that fool close associates
- The friendly CIA officer who casually shares classified intelligence with
  foreign nationals because they're "the good guys"
- Resolution through a single climactic gunfight (espionage ends with
  information, leverage, and political manoeuvring. not shootouts)

### Use Instead
- Real, unremarkable names drawn from the operative's nationality
  (British: David Hartley, Sarah Penrose, James Aldridge.
   American: Mark Delaney, Carol Novak, Thomas Brennan.
   Russian: Sergei Volkov, Irina Kuznetsova, Pavel Morozov.)
- Cryptonyms that sound bureaucratically random (GTVALISE, STPIVOT, HTCANDLE)
- Plot structures driven by institutional logic, political pressure, and
  the slow accumulation of intelligence. not action set pieces alone
- Opposition characters who are as competent and human as the protagonist
- Moral dilemmas that don't have clean answers
- Operations that go wrong in plausible, cascading ways
- The mundane reality of intelligence work: paperwork, waiting, meetings,
  filing reports, arguing over budgets

## Comp Titles

Espionage's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Spy Who Came in from the Cold* — John le Carré (1963): the literary-espionage template; tradecraft benchmark.
- *Tinker Tailor Soldier Spy* — John le Carré (1974): the Cold War espionage masterpiece.
- *The Day of the Jackal* — Frederick Forsyth (1971): procedural-espionage / assassination-thriller.
- *The Bourne Identity* — Robert Ludlum (1980): action-espionage benchmark.

### Contemporary (current best-in-class)

- *Red Sparrow* — Jason Matthews (2013): contemporary tradecraft-heavy espionage.
- *I Am Pilgrim* — Terry Hayes (2013): contemporary international-espionage thriller.
- *American Spy* — Lauren Wilkinson (2019): post-Cold-War espionage with Black-female-protagonist register.
- *The Cellist* — Daniel Silva (2021): the Gabriel Allon series; contemporary art-restorer-spy benchmark.
- *Slow Horses* — Mick Herron (2010): the Slough House series; modern British espionage register.
- *The Last Time He Told Me* — Laura Dave / similar 2020s contemporary espionage-adjacent thriller.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. The primary style for espionage fiction. Wide compositions suggesting international scope, dramatic lighting, film-noir influence. The cover should feel like a still from a le Carre or Bourne adaptation. moody, atmospheric, geographically specific.
- **Photorealistic**. High-quality photography of urban environments at night, surveillance-style imagery, silhouettes against foreign cityscapes. Heavy post-processing for mood: desaturated, blue-shifted, shadow-heavy.
- **Typographic**. Strong title treatment with minimal imagery, often incorporating redacted-text aesthetics (blacked-out words, classified stamps, dossier formatting). Effective for literary espionage where the mood is cerebral rather than action-driven.
- **Minimalist**. A single evocative symbol (a redacted document, a passport, a dead drop marker, a wire) on a dark field. Signals sophistication and restraint. ideal for le Carre-influenced literary espionage.

### Genre Cover Aesthetics
- **Styles:** Shadowy and clandestine, surveillance aesthetics, noir-influenced international imagery, Cold War geometry (Berlin Wall, checkpoint architecture), dossier/classified document motifs, city-at-night atmospherics
- **Colours:** Cold blues (steel, midnight, ice), deep blacks, metallic silvers and greys, muted golds (for period/Cold War settings). The palette should feel nocturnal, institutional, and cold. Accent colours used sparingly: a red classified stamp, an amber streetlight, the green glow of a surveillance screen. Avoid warm, inviting tones entirely.
- **Elements:** City silhouettes at night (London, Berlin, Moscow, Vienna), lone figures on rain-slicked bridges, surveillance cameras and monitors, redacted documents and classified stamps, passport pages, coded messages, dead drop locations, embassy gates, checkpoint barriers, radio equipment, binoculars, the Berlin Wall (Cold War), satellite imagery
- **Typography:** Clean, authoritative typefaces. serif for literary espionage (echoing official documents and Cold War-era print), sans-serif for modern/action espionage. Stencil or monospaced fonts can work for classified-document aesthetics. Title treatments often incorporate intelligence-community visual language: redaction bars, classification stamps, dossier formatting. The type should feel institutional and precise, never casual or decorative.

### Subgenre Variations
- **Literary Espionage (le Carre style)**. Restrained, atmospheric, character-driven covers. Misty cityscapes, solitary figures, institutional architecture rendered with melancholy. Muted, grey-dominant palettes. The cover should feel like a Cold War photograph found in an archive.
- **Action Espionage (Silva / Flynn style)**. More dynamic compositions with stronger contrast. International landmarks, operatives in motion, weapons or tactical imagery. Higher contrast, bolder colours (reds and blacks alongside blues). The cover should feel like a movie poster.
- **Cold War**. Period-specific imagery: the Berlin Wall, checkpoint architecture, Soviet-era typography, vintage colour grading (slightly washed, grain-textured). Propaganda-poster influences can work if handled with sophistication. The cover should feel like a declassified document.
- **Modern / Cyber**. Digital aesthetics: data streams, code fragments, satellite imagery, screen glows, surveillance interfaces. Cyan and green accents against black. Circuit-board textures. The cover should feel like a briefing screen.
- **Historical**. Period-appropriate design sensibilities: WWII-era typography, aged paper textures, sepia or muted colour palettes, wartime imagery (Bletchley Park, occupied cities, military communications). The cover should feel archival.

### Market Positioning
Espionage covers must signal SOPHISTICATION and INTERNATIONAL SCOPE. The genre spans a wide tonal range. from le Carre's literary intelligence fiction to Daniel Silva's globe-trotting action. and the cover must position accurately within it. At thumbnail size, the cover should read as "spy fiction" through visual shorthand: dark palettes, urban night imagery, classified-document aesthetics, or lone-figure-in-foreign-city compositions. Espionage readers are typically well-read and visually discerning; cheap-looking covers are immediately rejected. Distinguish from general thrillers (which are more action-focused) and from military fiction (which features hardware and uniforms). The best espionage covers promise the reader a world of secrets, not a world of explosions.

### Cover Design DON'Ts
- Do NOT use cartoonish or cliched spy imagery. no magnifying glasses, trench coat silhouettes in fedoras, or oversized fingerprints. These signal parody, not serious espionage fiction.
- Do NOT use bright, cheerful colours. espionage fiction is nocturnal and cold by convention. Bright greens, oranges, or yellows will be misread as comedy or cozy mystery.
- Do NOT use generic action-thriller imagery (explosions, gunfights, car chases) unless the book is firmly in the action-espionage subgenre. and even then, use restraint.
- Do NOT use overly busy compositions with multiple competing elements. espionage covers should feel controlled and deliberate, like a well-planned operation.
- Do NOT use James Bond visual clichés (gun barrels, tuxedos, martini glasses, femme fatale silhouettes) unless deliberately channelling that tone. they signal fantasy spy fiction, not realistic espionage.
- Do NOT use horror or supernatural elements. espionage fiction is grounded in institutional and geopolitical reality.
- Do NOT use Comic Sans, papyrus, or any informal font. the typography must feel institutional, precise, and authoritative.
- Do NOT use flags as primary design elements unless treated with sophistication. a flag draped across the cover reads as political non-fiction, not espionage fiction.
