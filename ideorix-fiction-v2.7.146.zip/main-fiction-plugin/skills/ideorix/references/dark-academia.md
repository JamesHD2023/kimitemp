---
name: dark-academia-genre
description: "Genre-specific instructions for Dark Academia. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
parents: [literary, thriller]
---

# Dark Academia. Genre Plugin

## Metadata
- **Genre ID:** dark-academia
- **Display Name:** Dark Academia
- **Category:** Literary & Contemporary
- **Tier:** Hybrid/Crossover
- **Target Word Count:** 3,000–5,000 per chapter
- **Min Word Count:** 3,500
- **Recommended Beat Structures:** Freytag's Pyramid, Three-Act Structure, Story Circle, Hero's Journey, Seven-Point Structure

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Classic Dark Academia | Elite university, classics/philosophy obsession, moral decay | The Secret History template; clique dynamics central |
| Gothic Academic | Supernatural or occult elements in academic setting | Haunted campuses, cursed knowledge, eldritch libraries |
| Academic Thriller | Mystery or crime within institutional walls | Whodunit structure layered with academic politics |
| Queer Dark Academia | LGBTQ+ identity within intense academic bonds | Desire and identity as additional layers of secrecy and risk |
| Light Academia | Intellectual setting without full darkness. gentler stakes | Still atmospheric but hopeful; growth without ruin |
| Institutional Horror | The institution itself as antagonist | Systemic abuse, complicity, whistleblowing arcs |

## Architect Instructions

### Chapter Planning Requirements

**Structure:**
- Chapter length: 2,500–4,500 words
- Pacing: Slow-burn tension with regular micro-tension (unease, subtext) every few pages
- Momentum source: Secrets, shifting group dynamics, creeping dread. not car chases
- Must open with: Concrete moment in academic world (lecture, library, dorm, ritual) or aftermath hinting at tragedy
- Must close with: Unsettling information, relationship shift, moral compromise, or foreshadowed wrongness

### Genre Promise

Dark Academia stories combine:
- An enclosed academic setting (school, university, cloistered institution)
- Intense intellectual and/or artistic obsession
- A tight-knit clique or inner circle
- Moral decay, transgression, and eventual ruin (social, moral, or literal)
- A lingering sense of melancholy, aesthetic beauty, and doom

### Beats Per Chapter (Plan 3–5)

- **Academic Frame:** Class, tutorial, reading group, rehearsal, exam panic. Use to reveal ideas, theme, and hierarchy.
- **Clique Dynamics:** Who's in/out? How has power shifted since last chapter? What subtle social cruelty or loyalty is displayed?
- **Mystery / Unease:** Strange remark, rumour, missing file, locked room, odd faculty behaviour. Deepen "there's more."
- **Obsession Move:** Protagonist sacrificing sleep, friendships, health, ethics, or common sense.
- **Moral Drift:** Small compromise (cheating, lying, covering for a friend, hazing, cruelty) that feels justified in the moment.
- **Atmosphere Set Piece:** 1–2 scenes per chapter leaning hard into atmosphere: night walks, candlelit study, dust motes in the library.
- **Foreshadowing:** Visual or spoken image that points to eventual ruin.

### Genre-Specific Requirements
- Setting is a character: the institution feels alive, layered with history, rumour, and unspoken rules
- Intellect is weapon and drug: classes and debates reveal worldview, power, and seduction
- Group > individual: clique dynamic is central tension
- At least one meaningful micro-shift per chapter in power, trust, status, or moral line

### Forbidden in Planning
- Plot hinging purely on external action with no intellectual/emotional consequence
- Chapters with no movement in clique dynamics, moral drift, or mystery
- Random set pieces disconnected from academic or institutional life
- Convenient revelations without groundwork or foreshadowing

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (atmosphere & ritual), Anticipation (mystery & dread accumulation), Revelation (transgression / consequence).

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Voice and Tone
- **POV:** 1st person past/reflective or very close 3rd person with tight interiority
- **Tense:** Past (traditional) with reflective stance. often narrated from AFTER the ruin
- **Voice:** Melancholic, introspective, cerebral. beautiful but controlled
- **Tone:** Aestheticised but not purple. atmosphere in service of emotion and theme

### Prose Imperatives

1. **Atmosphere Is a Primary Tool**. Use setting as emotional weather. Light, season, architecture, texture, and sound echo the protagonist's inner state. Make each location feel specific, storied, and haunted by memory.

2. **Interiority Over Spectacle**. The real drama is what characters think, repress, and rationalise. Show guilt, envy, devotion, and intellectual intoxication on the page.

3. **Dialogue as Intellectual Sparring**. Conversations are duels, seductions, or performances. Subtext: who's trying to impress whom? Who's hiding ignorance? Who's testing loyalty?

4. **Linger Where It Hurts**. Take time in moments of humiliation, awe, betrayal, complicity. Shorten transitions; expand key moral turning points.

5. **Repetition and Motifs**. Reuse images, lines from poems or plays, sounds (bells, clocks), spaces (the same bench, hallway). Each recurrence should feel more loaded with meaning.

### Prose Rhythm Mapping
- Ch 1 hook: Intellectual seduction + atmosphere of privilege and danger
- Prose rhythm: Slightly elevated vocabulary (not pretentious, but the narrator READS)
- Sentence length: Medium-long (18-28 words) with embedded references
  - Winding reflective sentences for interiority and atmosphere
  - Short, cutting sentences for moments of social cruelty or revelation
- The campus IS a character. describe it with the same attention as people
- Sensory palette: Old stone, lamp-lit libraries, the smell of old books and ambition
  - Texture dominates: paper, ink, dust, candlewax, cold, damp, wood
- Interiority: Deep. obsession, envy, guilt, adoration rendered through thought
- Tension: ≥6 for Ch 1 (atmosphere of dread from page 1)
- Paragraph rhythm: Long paragraphs for atmospheric immersion
  - Short paragraphs for social violence and cutting observations
  - The rhythm should feel like late-night study: sustained focus with sudden breaks

### Style Guidelines
- **Sentence length:** Mix long, winding reflective sentences with shorter, cutting ones for impact
- **Diction:** Slightly elevated but not impenetrable. Occasional Latin/Greek/academic terms explained via context
- **Sensory detail:** Focus on texture: paper, ink, stone, cold, damp, wood, dust, candlewax, old fabric, coffee, ink stains

### Chapter-Level Targets
Each chapter should:
- Contain at least one strong atmospheric passage
- Advance clique dynamics or moral descent
- Hint (even lightly) at the coming disaster
- Give the reader a line, image, or feeling they want to underline

### Forbidden Craft Habits
- Action thriller pacing with no room for thought
- Slang-heavy voice that doesn't fit the institution (unless intentional contrast)
- Excessive name-dropping without emotional or thematic relevance
- Flat, generic description of campus ("nice old building," "big library") without specificity

## Quality Check Criteria

### Priority Ranking
1. **Atmospheric immersion**. Institution vivid and specific; setting feels like a character with history, mood, and sensory weight
2. **Psychological interiority**. Protagonist's insecurity, obsession, or unease rendered through shown thoughts and rationalisations
3. **Clique dynamics in motion**. Every chapter shifts power, allegiance, or intimacy within the group
4. **Thematic depth**. Class, privilege, art, genius, or institutional power woven into scene rather than stated
5. **Creeping moral cost**. Choices accumulate consequences; lines blur gradually; reader feels the erosion

### Genre-Specific Checks
- Narrative voice consistent (melancholic, cerebral, reflective)
- Institutional specificity: campus has its own traditions, scandals, architecture, weather
- Sensory grounding: stone, leather, candlelight, old paper, autumn rain, dust motes
- Intellectual content earned: philosophy/literature referenced because characters genuinely care
- Social hierarchy visible: who's inside, peripheral, excluded
- Retrospective awareness: sense of looming consequence
- Slow-burn tension sustained even in beautiful moments
- Prose quality: clear and evocative, striking images worth underlining

### Automatic Fails
- Generic campus with no specific feel or atmosphere
- Modern sitcom voice with no awareness of genre's intellectual, measured tone
- Name-dropping without connecting to character emotion or plot
- Static clique dynamics. no shift in power, trust, or allegiance
- No psychological depth. protagonist's inner life absent or stated flatly
- Moral stakes absent. no ethical tension, no creeping compromise

### Acceptable Imperfections
- Slow pacing if serving atmospheric depth and psychological complexity
- Intellectual references readers may not all recognise (genre expects some erudition)
- Ambiguous morality at chapter end (genre thrives on moral uncertainty)
- Limited action if tension sustained through social dynamics and interiority
- Sustained darkness without "light moments" (genre permits this)

## Continuity Rules

### Top 5 Continuity Priorities
1. **Academic Calendar and Time:** Terms, holidays, exam periods, essay deadlines; seasonal progression consistent
2. **Institution Rules and History:** Curfews, restricted areas, faculty expectations; famous scandals, traditions, societies
3. **Clique Membership and Status:** Who's inside the core group, peripheral, fallen out; power and intimacy shifts tracked
4. **Moral Lines:** Which lines the protagonist promised never to cross; when crossed; lies told and who knows what
5. **Physical and Psychological Wear:** Sleep deprivation, substance use, injuries, stress; anxiety, guilt, paranoia. must accumulate, not vanish

### Genre-Specific Tracking
- Repeated locations: who has been where, when, and why
- Secret spaces (tunnels, archives, attics, locked rooms)
- Artefacts (books, letters, notebooks, photos, recordings)
- Faculty behaviour consistency: attitudes, availability, opinions

### Knowledge and Secrets Tracking
- Who knows the central secret/transgression. documented per chapter
- Who suspects but doesn't know
- What the faculty knows vs. what they choose to ignore
- What the institution knows vs. what it acknowledges publicly
- Lies told by protagonist: who was told what, when, potential contradictions
- Artefacts and evidence: who has them, where they are

### Red Flags (Investigate Immediately)
- Academic calendar impossible (finals during orientation, holidays at wrong time)
- Clique member suddenly in/out of inner circle without precipitating event
- Protagonist's moral state resetting. acting as if transgression didn't happen
- Physical deterioration vanishing. well-rested after established sleep deprivation
- Secret known by character who had no way of learning it
- Lies contradicting each other without the inconsistency being tracked
- Faculty member behaving inconsistently without reason

## Character Rules

### Top 5 Character Priorities
1. **Protagonist as Outsider Looking In:** Must WANT something the clique has. belonging, intellectual validation, beauty, escape
2. **Clique as Constellation:** Each member distinct. different intellectual domains, relationships to privilege, roles in group
3. **Moral Drift Tracked:** Ethical boundaries shift over time; track exactly where lines are at each phase
4. **Insecurity as Wound:** Protagonist's deepest insecurity (class, intellect, belonging) is what the clique exploits
5. **Psychological Realism:** Guilt, obsession, envy, adoration, disillusionment build logically and leave marks

### The Protagonist

**Core Architecture:**
- Gifted or intensely driven
- Outsider status (scholarship student, late arrival, wrong background)
- Deep insecurity about class, intellect, or belonging
- Desire for transcendence. wants to escape ordinary life
- Susceptible to intellectual, aesthetic, or social seduction

**The Wound (Establish Early):**
- Class shame (scholarship kid among legacies)
- Intellectual insecurity (smart but not sure they belong)
- Social awkwardness (never fit in, finally a place that seems right)
- Hunger for beauty/meaning (ordinary life felt insufficient)
- Family escape (running from something back home)

**Protagonist's Arc:**
1. Seduction: Awe, desperate to belong, willing to sacrifice
2. Obsession: Sleep deprivation, outside relationships atrophy, clique becomes entire world
3. Transgression: The line crossed. may not feel momentous at the time
4. Reckoning: Consequences arriving, guilt, clique loyalty tested
5. Aftermath: Whatever survives. expulsion, exile, or living with knowledge

### The Clique

Each member must have:
- Distinct intellectual or artistic identity (classicist, poet, philosopher, artist)
- Different relationship to privilege (old money, new money, scholarship, faculty kid)
- Clear role in group dynamic (leader, provocateur, conscience, beauty, victim)
- Their own secrets and vulnerabilities
- Individual reason to be in this group

**Power Structures:**
- The charismatic leader (often from privilege)
- The true believer (buys the philosophy completely)
- The sceptic (stays for other reasons, may eventually break)
- The beauty (admired, perhaps more perceptive than assumed)
- The vulnerable one (most likely to crack or be destroyed)

### The Faculty Mentor/Antagonist
- The professor who enables, encourages, or embodies the dark path
- May be seducer (intellectually or actually), warning (ignored), or complicit
- Track: philosophy, what they know vs. suspect, relationship to each clique member, their own history

### The Institution as Character
- Has its own character: traditions, architecture, unspoken rules
- Protects itself and its privileged students
- Will sacrifice expendable outsiders to maintain reputation
- The beauty is real but paid for by someone

### Psychological Architecture

Track and show these emotions:
- **Guilt:** Physical manifestations (insomnia, nausea, hypervigilance); mental patterns (intrusive thoughts, rationalisation)
- **Obsession:** Single-minded focus; physical neglect; loss of perspective
- **Envy:** Constant comparing; wanting what others have; resentment alongside admiration
- **Adoration:** Idealisation of leader/institution; blindness to flaws; willingness to sacrifice
- **Disillusionment:** The beautiful thing revealed as corrupt; can't unsee the truth; grief for what they thought they had

## Arc Rules

### Five-Phase Dark Academia Arc (30 Chapters)

**Phase 1. Arrival and Awe (Ch 1–5, 0–15%)**
- Ch 1–2: Protagonist arrives. Institution hits like revelation. old stone, vaulted ceilings, the smell of centuries. Outsider status established immediately.
- Ch 3–4: First encounters with clique. A glimpse. Someone brilliant in a seminar. An invitation that feels both casual and curated.
- Ch 5: The threshold. invitation deeper. A rule bent, a confidence shared, a loyalty tested.
- Atmosphere: Autumn. Golden light. Possibility.
- Obsession level: AMBIENT. Healthy ambition shading into intense focus.
- Moral state: INTACT. Boundaries clear.
- Clique dynamic: COURTSHIP. Protagonist being evaluated.

**Phase 2. Seduction and Immersion (Ch 6–12, 15–40%)**
- Ch 6–8: Full immersion. Inner world revealed: private rituals, shared texts, exclusive gatherings.
- Ch 9–10: Academic and clique worlds merge. Faculty emerge as enablers or warnings. Sacrifices begin: sleep, outside friendships, contact with home.
- Ch 11–12: First cracks in golden surface. A moment of cruelty laughed off. A rumour. First small moral compromise.
- Atmosphere: Late autumn into winter. Darkening early. Candles in dorm rooms.
- Obsession level: ESCALATING. Sleep deprivation beginning.
- Moral state: SOFTENING. First boundaries crossed. "Everyone does this."
- Clique dynamic: BELONGING. But belonging means enmeshment.

**Phase 3. Transgression and Complicity (Ch 13–18, 40–60%)**
- Ch 13–14: Approach to point of no return. Something planned or demanded that goes beyond previous compromises.
- Ch 15 (MIDPOINT): THE TRANSGRESSION. The act that cannot be undone. May not feel momentous when it happens.
- Ch 16–18: Living in aftermath. Group draws tighter. shared guilt as bond. Paranoia, guilt manifesting physically. Cracks in clique.
- Atmosphere: Deep winter. Snow muffling the world. Hothouse intensity.
- Obsession level: ALL-CONSUMING. Health deteriorating visibly.
- Moral state: COMPROMISED. The line crossed. Rationalisation increasingly desperate.
- Clique dynamic: PRESSURE COOKER. Shared guilt creates fault lines.

**Phase 4. Unravelling and Dread (Ch 19–24, 60–80%)**
- Ch 19–21: Consequences approach. Rumours. A peripheral character asking questions. Clique fracturing.
- Ch 22–23: DARKEST HOUR. Protagonist faces full weight of what they've done. Clique turning on itself.
- Ch 24: The pivot. from passive dread to active choice. Whatever they choose costs everything.
- Atmosphere: Spring. The thaw. things buried under snow becoming visible.
- Obsession level: SHATTERED. Beautiful obsession revealed as destructive.
- Moral state: CRISIS. Full awareness.
- Clique dynamic: FRACTURING. Trust gone. Alliances shifting toward survival.

**Phase 5. Ruin and Aftermath (Ch 25–30, 80–100%)**
- Ch 25–26: Scandal breaks. Institution's response reveals true priorities. Beautiful facade shatters.
- Ch 27–28: THE RECKONING. Consequences according to privilege. legacy's family makes calls, scholarship kid expelled.
- Ch 29–30: AFTERMATH. What survives. The protagonist emerges carrying the weight. The institution endures. Next year there will be new students.
- Atmosphere: Late spring into summer. Institution beautiful and indifferent.
- Obsession level: EXTINGUISHED. What remains is memory and understanding.
- Moral state: SCARRED. Not redeemed. scarred.
- Clique dynamic: DESTROYED. Whatever survives is forever marked.

### Genre-Specific Arc Elements

**The Seduction Curve:**
- Phase 1: Awe > Phase 2: Belonging > Phase 3: Entrapment > Phase 4: Disillusionment > Phase 5: Devastation
- RULE: The seduction must be genuinely seductive. If the reader doesn't understand why the protagonist fell, the ruin has no power.

**The Moral Drift:**
- Phase 1: Boundaries clear > Phase 2: Small compromises rationalised > Phase 3: The line crossed > Phase 4: Living with transgression > Phase 5: Full accounting
- RULE: Each drift must feel like a small, reasonable step from the previous. The ruin should feel both shocking and inevitable.

**The Institutional Complicity:**
- During seduction: encouraging. During transgression: ignoring. During ruin: self-protecting.
- The institution's indifference to individual suffering while maintaining its beautiful facade is the macro-level version of the clique's dynamic.

## Timeline Rules

### Top 5 Timeline Priorities
1. **Academic Calendar as Spine:** Orientation, midterms, finals, holidays, thesis deadlines. the skeleton of your story
2. **Obsession Escalation:** Descent over TIME: healthy ambition → intense focus → obsession → neglect
3. **Seasonal Atmosphere:** Seasons as emotional weather. first frost and moral chill, spring renewal and false hope
4. **The Transgression Timeline:** Point of no return placed correctly in academic calendar. often midway
5. **Clique Formation and Fracture:** When protagonist meets group, is accepted, sees cracks, witnesses break

### The Academic Calendar Structure

**First Term (Act I. Seduction):**
- Orientation/arrival → First weeks (clique encountered) → Midterms (obsession seeds) → Before break (first hints of darkness)

**Second Term (Act II. Obsession and Transgression):**
- Return from break (changed relationships) → Midpoint transgression → Exam period (cracks appear) → End of year (reckoning approaches)

**Final Period (Act III. Ruin and Aftermath):**
- Finals (maximum pressure) → Scandal breaks → Reckoning → Reflection from after

### Seasonal Atmosphere Tracking
- **Autumn (Beginning):** Golden light, new beginnings, romantic academia. Moral state: still innocent.
- **Winter (Deepening):** Dark early, isolation, hothouse intimacy. Moral state: lines beginning to blur.
- **Spring (Unravelling):** Thaw, but things buried becoming visible. Moral state: consequences visible.
- **Summer (Aftermath):** Break from institution, but consequences follow. Moral state: living with what happened.

### Obsession Timeline
Track descent: first sacrifice of sleep → first skipped meals → first lie to family → first ethics compromise → first participation in something dark → first cover for clique → realisation they can't go back.

Each step should be spaced. obsession grows, doesn't appear fully formed.

## Genre-Specific Craft Techniques

Dark academia is a genre with an unusually defined
canonical text — Donna Tartt's The Secret History — and
this is both the genre's strength and its most common
failure mode. The genre's masterclass writers have
worked through Tartt's frame to reach distinct
contemporary positions: M.L. Rio (If We Were Villains)
adapting the template to theatre; R.F. Kuang (Babel: An
Arcane History) bending it to anti-colonial polemic;
Mona Awad (Bunny, Rouge) bending it to body horror and
gendered violence; Susie Yang (White Ivy) bending it to
class-focused immigrant narrative; Elisabeth Thomas
(Catherine House) bending it to gothic-institutional
horror; Leigh Bardugo (Ninth House) bending it to
secret societies and occult; Olivie Blake (The Atlas
Six) bending it to dark-academia-meets-fantasy; Katy
Hays (The Cloisters) bending it to art-historical
mystery; Tara Isabella Burton (Social Creature) bending
it to friendship-obsession; Tana French (The Likeness)
bending it to procedural; Hari Kunzru and Jean Hanff
Korelitz (The Latecomer, The Plot) bending it to
literary suspense; Hannah Marin (Disorientation), Eva
Jurczyk, Eliza Smith, Caitlin Mullen continuing the
expansion. The most common failure modes in this
register are: **Tartt-Pastiche** (The Secret History
cosplay rather than fresh dark academia — the brilliant
classics professor, the wealthy clique with the
murdered outsider, the bacchanalian transgression
deployed as quotation rather than as freshly imagined
material); **Aesthetic-Without-Stakes** (the candlelit-
library-and-tweed visual register deployed as Pinterest-
board atmosphere without genuine moral or institutional
jeopardy); **Pretension-Without-Substance** (the
philosophical, literary, or artistic references name-
dropped without connecting to character or theme;
erudition as decoration rather than as character-
revealing intellectual life); **Privilege-as-Wallpaper**
(class difference mentioned once and then forgotten;
the scholarship student who is supposedly an outsider
but moves through the institution with no rendered
friction, no moments of material visibility, no costs);
**Transgression-Without-Drift** (the moral compromise
that arrives without the gradual erosion the genre
requires — the climax-act delivered without the slow
accumulation of small compromises that should have made
it possible); **Static-Clique** (the inner circle that
does not shift in power, allegiance, or intimacy across
chapters — group dynamics as wallpaper rather than as
the genre's primary engine); **Dead-Faculty Mentor**
(the professor as decorative authority figure rather
than as active enabler, seducer, warning-issuer, or
complicit participant in the protagonist's drift);
**Light-Academia-Mistaken-as-Dark** (atmosphere
preserved but the genre's dark contract abandoned — no
moral ruin, no institutional complicity, no creeping
consequence; what reads as dark academia is actually
light academia in costume); **Retrospective-Distance
Failure** (the "I was young and foolish" framing that
distances reader from the protagonist's experience
rather than implicating them in the seduction); and
**Institution-Without-History** (the elite university
rendered with no specific scandals, traditions,
architectural history, named societies, or institutional
weight beyond generic "old college" markers). The
techniques below — five preserved (Reflected Lecture,
Institutional Echo, Privilege Reveal, Beautiful
Rationalisation, Motif Return) and three added
(Erudition-as-Character Discipline, Class-Friction
Architecture, Slow-Drift Calibration) — are designed to
keep the genre's defining commitments live: erudition
that reveals character rather than decorating it, class
friction as live constant pressure rather than wallpaper,
and moral drift paced so the transgression feels both
inevitable and shocking when it arrives.

### The Reflected Lecture

Academic content mirrors the protagonist's internal conflict:
- A philosophy seminar on free will when the protagonist feels trapped
- A literature class discussing tragedy when the clique is heading toward one
- An art history lecture on beauty and decay as the beautiful world crumbles
- The protagonist recognises the parallel but cannot act on the knowledge

### The Institutional Echo

The institution's history foreshadows the present:
- A scandal from decades ago that mirrors what's happening now
- A portrait of a former student who came to a similar end
- A tradition whose origins are darker than anyone admits
- The corridor where something happened that no one discusses

### The Privilege Reveal

Moments where class difference becomes visible and weaponised:
- The casual mention of a summer house that costs more than the protagonist's childhood home
- The faculty member who treats the legacy student differently without acknowledging it
- The moment when consequences arrive and protection flows to those who already have it
- The protagonist's awareness that their expendability is their defining characteristic

### The Beautiful Rationalisation

Characters explaining away moral compromise in eloquent, intellectually sophisticated language:
- Classical or philosophical frameworks used to justify transgression
- The group developing a shared vocabulary for what they're doing that sanitises it
- The protagonist's internal voice becoming more elaborate as the justifications become more desperate
- The moment when the rationalisation finally fails and raw truth is exposed

### The Motif Return

Recurring images that accrue meaning through repetition:
- A specific time of day (always 4pm, always dusk, always the hour between)
- A physical location revisited at different emotional states
- A line of poetry or philosophy that changes meaning each time it appears
- A sensory detail (a specific smell, sound, quality of light) that marks transitions

### Dark Academia AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "knowledge is a dangerous thing" | Show the specific dangerous knowledge |
| "the hallowed halls held dark secrets" | Show ONE specific architectural detail with history |
| "the pursuit of excellence had a price" | Show the specific price paid by a specific student |
| "brilliance and madness were two sides of the same coin" | Show the specific behaviour that could be read as either |
| "the professor's words cut deeper than any blade" | Show the specific words |
| "secrets whispered in the library stacks" | Show the specific secret exchanged in the specific location |
| "the ivy-covered walls concealed" | Show the specific hidden thing |
| "a beautiful, terrible obsession" | Show the specific obsessive behaviour |
| "the weight of tradition" | Show the specific tradition and its specific burden |
| "the line between dedication and destruction" | Show the specific moment of crossing |
| "the academy was a world unto itself" | Show the specific insular detail |
| "the smell of old books and ambition" | Cut Tartt-pastiche cliché; show the specific room and what specifically distinguishes it |
| "as though the past were watching" | Cut anthropomorphism; show the specific historical artefact (the portrait, the foundation date, the tradition-marker) |
| "the academy was a different world" | Cut; show the specific marker that proves the difference |
| "their Latin / Greek / philosophy was effortless" | Cut "effortless"; show the specific demonstration |
| "the leader's eyes held a peculiar intensity" | Cut character-through-eyes cliché; show the specific tell or behaviour |
| "she had never belonged" | Show the specific moment she felt the difference today |
| "the clique moved as one" | Cut hive-mind cliché; show the specific coordination through one specific gesture |

### The Erudition-as-Character Discipline

The genre's intellectual content — the philosophical,
literary, artistic, classical, or theoretical material
the characters care about — must be specifically
chosen and specifically rendered as character-revealing
rather than as ornament. The Pretension-Without-
Substance failure mode collapses when the manuscript
deploys references that could have been any references,
that the characters cannot quote with specificity, and
that the protagonist's relationship to them does not
deepen across chapters. The Erudition-as-Character
Discipline is the requirement that what each character
studies, reads, teaches, and quotes function as a
specific window into who they are.

```
PRINCIPLE
For every named intellectual / artistic / theoretical
reference in the manuscript, the manuscript must satisfy
at least three of the following four criteria:
1. CHARACTER-CHOSEN — the reference is specifically
   chosen for THIS character's intellectual identity
   (not a generic "classics" gesture but THIS
   character's specific attachment to Catullus, or
   Sappho, or Tacitus, or a particular Plato dialogue;
   the philosophy student's specific affinity for
   Heidegger over Levinas; the art student's specific
   Manet over Degas)
2. SPECIFICALLY-DEPLOYED — the reference appears with
   specificity (the actual passage, the actual line,
   the actual painting, the actual argument) rather
   than as decorative name-drop
3. THEMATICALLY-RESONANT — the reference's content
   resonates with the character's situation,
   compromise, or arc; it is not random erudition but
   specific intellectual material that carries
   thematic weight
4. PROGRESSIVELY-REVEALED — the character's
   relationship to the reference deepens, complicates,
   or shifts across the manuscript; what the reference
   means to her in chapter 3 is not what it means in
   chapter 28

CALIBRATION TEST
- For each named author, work, theory, or tradition,
  could the reference be replaced with another and
  the manuscript continue unchanged? If yes, the
  reference is decorative.
- Does the manuscript quote with specificity (actual
  passages, actual arguments) or only allude in the
  abstract?
- Does the protagonist's intellectual life genuinely
  deepen across the manuscript, with specific
  evidence of what she has been reading, thinking,
  arguing about?
- Does each clique member have a distinct
  intellectual identity that could not be confused
  with another's?
If any answer is no — rebuild for character-specific
erudition.

ANTI-PATTERN
- "She loved the Greeks" without specifying which
  Greeks
- The clique who all read "philosophy" interchangeably
- The professor who lectures on "literature"
- Latin tags deployed without context, character
  motivation, or thematic resonance
- The character whose erudition is described
  rather than demonstrated
- The reference that appears once and is never
  returned to
```

### The Class-Friction Architecture

The Privilege-as-Wallpaper failure mode is one of the
genre's most common collapses: class difference is
mentioned in chapter 2 (the protagonist is a
scholarship student, the others come from old money)
and then never functions as material force on the
manuscript's chapters. The Class-Friction Architecture
is the requirement that class function as live, constant,
specific friction rendered through specific moments
across the manuscript.

```
PRINCIPLE
The protagonist's class position must produce specific
friction in at least four of the following six axes
across the manuscript:
1. ECONOMIC — the specific cost the protagonist cannot
   absorb (the dinner she cannot reciprocate, the
   summer house she cannot visit, the textbook she
   cannot afford, the trip she cannot join, the gift
   she cannot match, the bottle she cannot bring)
2. SARTORIAL / EMBODIED — the specific way her body or
   wardrobe marks her (the wrong shoes, the wrong
   coat, the wrong haircut, the wrong dialect, the
   wrong table manners, the wrong cultural reference
   set)
3. INSTITUTIONAL — the specific way the institution
   treats her differently (the faculty member who
   addresses her differently, the financial-aid
   office, the work-study job that conflicts with
   the seminar, the dorm assignment that places her
   among other scholarship students)
4. RELATIONAL — the specific way her relationships
   with the clique are coloured by class (the things
   she cannot ask for, the secrets she cannot share,
   the assumption-gaps that surprise her)
5. KNOWLEDGE / CULTURAL CAPITAL — the specific gap in
   what she knows that they take for granted (the
   restaurant she has not heard of, the family name
   she does not recognise, the holiday she has not
   taken, the language she does not speak, the
   musical or literary touchstone she has missed)
6. CONSEQUENCE / EXPENDABILITY — the specific moment
   when consequences arrive and protection flows to
   those with privilege; her expendability is
   rendered as institutional fact, not just felt
   anxiety

CALIBRATION TEST
- Across the manuscript, can a reader name SPECIFIC
  scenes (chapter, page) where the protagonist's
  class position produced specific friction in each
  of at least four axes?
- Does the protagonist's class position function as a
  live constant rather than a chapter-2 disclosure
  that's never returned to?
- Does the manuscript's ending render the specific
  way her class position determined her fate (the
  legacy student protected, the scholarship kid
  expelled)?
- Are the privileged characters rendered with class
  specificity too — not generic "wealthy" but
  specific old-money / new-money / faculty-kid /
  trust-fund / inherited-real-estate configurations?
If any answer is no — rebuild for class-friction
specificity.

ANTI-PATTERN
- The scholarship-student detail mentioned once and
  forgotten
- Class as backdrop without specific present-tense
  cost
- The protagonist whose financial precarity
  vanishes when narratively inconvenient
- The clique whose privilege is ambient rather than
  specific (no named summer houses, no named
  schools, no named family connections)
- The institution that treats all students
  identically across class lines
- The ending where consequences fall equally on
  privileged and non-privileged characters
```

### The Slow-Drift Calibration

The genre's signature is moral drift. the protagonist
slides from intact ethical standing in Phase 1 to
participation in transgression at the midpoint to
living-with-knowledge in Phase 5. The Transgression-
Without-Drift failure mode is when the manuscript
delivers the climactic act without the chapter-by-
chapter accumulation of small compromises that should
have made it psychologically possible. The Slow-Drift
Calibration is the discipline of pacing each
compromise across the manuscript so that the
transgression, when it arrives, is both inevitable
and shocking.

```
PRINCIPLE
The moral drift must be paced across the manuscript so
that:
1. PHASE 1 (Ch 1-5, 0-15%): boundaries are intact;
   the protagonist may notice ethically uncomfortable
   moments in the clique but does not yet participate
2. PHASE 2 (Ch 6-12, 15-40%): small first
   compromises — the lie told to family, the missed
   class to attend a clique gathering, the loyalty
   protected by silence, the cruelty laughed off, the
   small cheat, the small theft, the small lie of
   omission; each rationalised in the moment
3. PHASE 3 (Ch 13-18, 40-60%): the line crossed at
   midpoint; participation in something that, in
   chapter 1, the protagonist would have refused; at
   the moment of crossing, the protagonist's
   rationalisation should sound coherent; the
   reader recognises the act as transgression but
   the protagonist may not fully
4. PHASE 4 (Ch 19-24, 60-80%): living in the
   aftermath; the rationalisation increasingly
   strained; physical and psychological symptoms
   accumulating; the clique's bond either tightens
   around shared guilt or fractures
5. PHASE 5 (Ch 25-30, 80-100%): full accounting;
   consequences according to privilege; the
   protagonist understands what she has become

REQUIREMENTS
- Each compromise must be SPECIFIC (named act, named
  context, named justification)
- Each compromise must be CONNECTED to the previous
  (the writer should be able to articulate why
  compromise B was made possible by compromise A)
- The total number of compromises before the
  transgression should be at least 5-7 (smaller
  numbers feel too fast; the genre demands
  accumulation)
- The protagonist's rationalisation language should
  evolve. early compromises rationalised through
  belonging-language ("everyone does this"); mid
  compromises through philosophical-language
  (Beautiful Rationalisation); late compromises
  through survival-language ("there was nothing else
  I could do")

CALIBRATION TEST
- After the transgression, can a reader trace the
  specific chain of compromises from the protagonist's
  intact chapter-1 self to the transgressive midpoint
  self?
- Is each compromise connected to the next, with the
  writer able to articulate the specific reason each
  step was psychologically possible after the
  previous?
- Does the rationalisation language evolve, with the
  prose tracking the protagonist's increasingly
  desperate verbal architecture?
- Is the transgression both INEVITABLE (the chain
  led here) and SHOCKING (the reader had not
  understood the protagonist could do this) at
  the moment of crossing?
If any answer is no — rebuild for drift specificity.

ANTI-PATTERN
- The transgression that arrives without prior
  compromises
- The protagonist who is morally intact in chapter
  14 and morally compromised in chapter 15 with no
  bridge
- Compromises that are listed without connection to
  each other
- Rationalisation language that does not evolve
- The "I should have known then" framing that
  collapses the drift into hindsight
```

## Genre-Specific Revision Rules

### Six-Pass Dark Academia Audit (Run FIRST in editorial pipeline)

The Dark Academia Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Atmospheric Pass

Verify every chapter contains at least one strong
atmospheric passage. The Aesthetic-Without-Stakes
failure mode is at risk of inverting if atmosphere
disappears entirely; the genre's contract is that
atmosphere is constant. Audit the chapter: is the
institution specific and alive — named buildings,
named traditions, specific architectural details, named
societies — rather than a generic "old university"? Is
the season tracked across the manuscript and used as
emotional weather (autumn arrival → winter intensity →
spring unravelling → summer aftermath)? Is sensory
detail present and specific (stone, paper, dust,
candlewax, cold, damp, leather, ink, woodsmoke, autumn
rain, library silence)? The Institution-Without-History
failure mode is caught here. if the campus could be
any campus, rebuild for institutional specificity.

#### Pass 2: Clique Dynamics Pass

Verify every chapter shifts power, allegiance, or
intimacy within the group. The Static-Clique failure
mode is the single most common dark-academia failure.
For every chapter, audit: what has shifted in the
clique configuration since the previous chapter? Has
power moved between members? Has trust grown or
eroded between specific pairs? Has someone moved closer
to the centre or further toward the periphery? Are all
clique members distinct (intellectual domain, privilege
position, role in group)? Is the protagonist's specific
wound — class shame, intellectual insecurity, social
awkwardness, hunger for beauty, family escape — being
pressed on by the clique throughout? Does the reader
understand the clique's genuine appeal (the seduction
must be genuinely seductive, or the ruin has no
power)? If a chapter could be removed without losing
clique-dynamic progression, the genre's primary engine
has stalled.

#### Pass 3: Moral Drift Pass

Verify the moral drift is specifically traceable across
the manuscript. The Slow-Drift Calibration provides the
spec. each compromise must be SPECIFIC, CONNECTED to
the previous, and rationalised through evolving
language. Audit the chapter: what new compromise (or
deepening of an existing one) has occurred? Does the
step feel like a reasonable escalation from the
previous (in the moment, with the protagonist's
rationalisation coherent)? Is the transgression
(midpoint) placed correctly in the arc — chapters
14-16 in a 30-chapter structure? Do consequences
accumulate rather than vanish (the lie told in chapter
8 is still operative in chapter 22)? The
Transgression-Without-Drift failure mode is caught
here. if the manuscript leaps from intact morality to
participation in transgression without the chapter-by-
chapter chain, restructure.

#### Pass 4: Psychological Depth Pass

Verify the protagonist's psychological reality is being
rendered through behaviour and interior architecture,
not stated. Audit the chapter: is guilt shown through
specific behaviour (insomnia, nausea, hypervigilance,
intrusive thoughts, increasingly elaborate
rationalisation) rather than told? Does obsession
manifest physically (sleep deprivation, missed meals,
neglected outside relationships, deteriorating health)?
Is the protagonist's interiority rich — thoughts,
rationalisations, repressions, contradictions —
rendered with the specificity literary fiction would
demand? Does disillusionment build gradually across
the manuscript rather than arriving as a single
revelation? The Retrospective-Distance Failure is
caught here. if the narration distances the reader
from the experience ("I was young and foolish then"),
rewrite to implicate the reader in the seduction.

#### Pass 5: Institutional Complicity Pass

Verify the institution responds in character — self-
protecting, hierarchical, indifferent to individual
suffering while maintaining its beautiful facade. The
Light-Academia-Mistaken-as-Dark failure mode is caught
here. if the institution is genuinely benevolent,
genuinely interested in students' welfare, genuinely
willing to investigate and respond appropriately, the
genre's dark contract has not been honoured. Audit:
is class / privilege visible in who is protected and
who is sacrificed? Does the institution's beauty
coexist with its corruption? Does the ending show the
institution enduring, indifferent to individual ruin
(next year there will be new students, the legacy
families' names remain on the buildings)? The Dead-
Faculty Mentor failure mode is caught here too. is
the professor an active agent in the protagonist's
drift (enabler / seducer / warning-issuer / complicit
participant) rather than a decorative authority figure?

#### Pass 6: Erudition-as-Character + Class-Friction + Slow-Drift Integration

This pass is the dark academia integration check — it
ties the new techniques together and verifies the
genre's structural commitments are honoured chapter by
chapter.

For ERUDITION-AS-CHARACTER: identify the chapter's
intellectual content (what is being studied, taught,
read, quoted, argued about). For each named reference,
verify it is character-chosen, specifically deployed,
thematically resonant, and progressively revealed.
The Pretension-Without-Substance failure mode is
caught here. if the references are interchangeable
decoration, rebuild. The genre's intellectual life
must be specific and character-revealing, not generic
"smart kids reading hard books".

For CLASS-FRICTION: identify the chapter's rendering
of class. Does the protagonist's class position
produce specific friction in this chapter (economic /
sartorial / institutional / relational / cultural-
capital / consequence)? Across the manuscript, are at
least four of the six axes operative? The Privilege-
as-Wallpaper failure mode is caught here. if class
was disclosed in chapter 2 and never returned to,
rebuild for live-constant class friction.

For SLOW-DRIFT: confirm Pass 3's spec has been met.
Across the manuscript, can a reader trace at least
5-7 specific compromises connecting the protagonist's
intact chapter-1 self to the transgressive midpoint
self? Is each compromise specific, connected, and
rationalised through evolving language? Is the
transgression both inevitable (the chain led here)
and shocking (the reader had not understood the
protagonist could do this)? If the manuscript's drift
collapses into hindsight or skips steps, restructure.

## Names & Patterns to Avoid

### Forbidden Dark Academia Patterns
- "I should have known then" used more than twice (retrospective narration becomes crutch)
- Listing philosophical references without connecting them to character emotion
- The protagonist who is completely passive. observing but never choosing
- "He/she was brilliant" stated rather than demonstrated through scene
- Generic campus description: "old building," "big library," "nice quad"
- Evil clique leader who is simply sociopathic from chapter 1 (seduction requires genuine charisma)
- Transgression that comes from nowhere. no moral drift leading to it

### Cliché Setups to Avoid
- The instant best-friend group who accept the protagonist without testing
- The professor who is entirely good or entirely evil
- The institution with no specific traditions, scandals, or history
- Class difference mentioned once and never again affecting the story
- The ruin resolved happily without real consequences
- The "I was young and foolish" framing that distances reader from experience

### Names to Avoid
- Names that telegraph character role (Professor Stern, the clique leader called Rex/King)
- Generic names that don't reflect the institution's cultural milieu
- Matching first letters for clique members (confusing when reading quickly)

## Comp Titles

Dark-academia's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Secret History* — Donna Tartt (1992): the genre's canonical text; classics-clique-murder template.
- *If We Were Villains* — M.L. Rio (2017): theatre-set dark-academia; Tartt-tradition.
- *Special Topics in Calamity Physics* — Marisha Pessl (2006): dark-academia literary-mystery.

### Contemporary (current best-in-class)

- *Babel* — R.F. Kuang (2022): dark-academia-fantasy with anti-colonial polemic.
- *Bunny* — Mona Awad (2019): horror-tinged dark-academia.
- *Catherine House* — Elisabeth Thomas (2020): cult-college dark-academia.
- *The Atlas Six* — Olivie Blake (2020): dark-academia-fantasy crossover; viral online-serialised success.
- *Ninth House* — Leigh Bardugo (2019): occult-Yale dark-academia.
- *White Ivy* — Susie Yang (2020): class-immigrant dark-academia.
- *The Cloisters* — Katy Hays (2022): art-historical dark-academia.
- *Yellowface* — R.F. Kuang (2023): publishing-industry dark-academia-adjacent.

## Cover Design Specifications

### Visual Tone
- Dark, atmospheric, literary
- Classical aesthetic with Gothic undertones
- Moody lighting: candlelight, twilight, autumn gold
- Institutional architecture prominent

### Key Visual Elements
- Gothic arches, library spines, stone corridors
- Classical art motifs (skulls, laurels, ravens, candles)
- Dark foliage: ivy, autumn leaves, bare branches
- Objects: old books, fountain pens, pocket watches, keys

### Typography
- Elegant serif fonts. Garamond, Baskerville, or similar
- Title prominent with classical lettering
- Author name in clean, secondary position
- Gold or cream text on dark backgrounds

### Colour Palette
- Primary: Deep navy, forest green, burgundy, espresso brown
- Accent: Antique gold, cream, ivory
- Avoid: Bright colours, pastels, neon accents
- Shadows and moodiness essential. covers should feel like they belong in the library

### Comp Titles (Cover Style Reference)
- *The Secret History* by Donna Tartt. classical, dark, literary
- *If We Were Villains* by M.L. Rio. theatrical, atmospheric, character-focused
- *Babel* by R.F. Kuang. institutional, dark, intellectually imposing
- *Catherine House* by Elisabeth Thomas. moody, mysterious, claustrophobic
