---
name: cozy-mystery-genre
description: Genre-specific instructions for cozy mystery fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [mystery]
---

# Cozy Mystery. Genre Plugin

## Metadata
- id: cozy-mystery
- name: Cozy Mystery
- icon: 🔎
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Cozy Mystery Beats"]

## Subgenre Options
Present during setup:
- **Traditional**. Classic whodunit, amateur sleuth, small community
- **Culinary**. Food/baking central to story and clue discovery
- **Craft**. Knitting, quilting, bookshop, etc. as setting/theme
- **Pet**. Animal companion as key character (cat, dog, etc.)
- **Paranormal**. Ghost, psychic abilities, or supernatural elements
- **Holiday**. Seasonal setting (Christmas, Halloween, etc.)

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Gentle, puzzle-focused. methodical investigation with social scenes
- Must open with: Discovery, clue, or social interaction advancing investigation

BEATS PER CHAPTER
1. Investigation Beat. Active sleuthing (questioning, observing, discovering)
2. Social Interaction. Community scene revealing character or suspect info
3. Clue or Red Herring. One concrete puzzle piece per chapter (scheduled)
4. Complication. Something that blocks progress or raises stakes
5. Reflection. Brief moment where sleuth processes what she's learned

MYSTERY ARCHITECTURE
- Body discovered by Chapter 2-3 (never later)
- 4-6 suspects with distinct motives and alibis
- Minimum 5 real clues, planted across acts:
  - Act 1 (setup): 1-2 clues (subtle, reader may not notice)
  - Act 2 (investigation): 2-3 clues (progressively clearer)
  - Act 3 (resolution): Final connecting clue before reveal
- Minimum 3 red herrings (must be genuinely convincing)
- Sleuth connects dots in penultimate chapter
- Reveal chapter uses ONLY previously established evidence

FORBIDDEN IN COZY MYSTERY
- On-page violence (death discovered, never witnessed)
- Graphic descriptions of the body
- Serial killers or psychopaths
- Professional law enforcement as protagonist
- Cynical or dark tone
- Explicit sexual content
- Profanity beyond mild expressions
- Sophisticated forensic technology
- Urban settings (small town/village ONLY)
- Guns as primary threat (poison, blunt objects, "accidents" preferred)

COZY ATMOSPHERE REQUIREMENTS
- Comfort elements every 2-3 chapters (food, tea, community, pets)
- Seasonal/weather details grounding each chapter
- At least one warm community moment per act
- The setting should feel like somewhere readers want to visit

CHAPTER ENDING REQUIREMENTS
- Every chapter ends with forward momentum
- Use: new question raised, clue discovered, suspect behaviour shift, personal stakes raised
- NEVER use: manufactured cliffhangers, cheap shock, "little did she know"
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (puzzle progression), Affection (community), Validation at justice served.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person present tense OR third close past tense
- Voice: Warm, witty, observant, inviting, gently humorous
- Tone: Cozy atmosphere with genuine mystery tension underneath
- Reader relationship: Like gossiping with a smart friend over tea

PROSE IMPERATIVES
- Clues delivered clearly (reader must be able to notice them on first read)
- Sensory details create cozy atmosphere (smells of baking, warmth of fire, etc.)
- Humour is gentle and character-based (never cruel or sarcastic about vulnerability)
- Physical descriptions of food/craft/setting should engage all five senses
- Mystery tension maintained even during comfort scenes

PROSE RHYTHM MAPPING (CRITICAL. warmth with wrongness)

Cozy mystery prose must make the reader feel SAFE while being INTRIGUED.
The rhythm is warm and accessible. like a conversation with a clever
friend over tea. but threaded with wrongness the reader senses before
they can name it.

Chapter 1 prose rhythm:
- Sentence average: 14-20 words. Warm, accessible, never clinical. The
  prose invites rather than interrogates.
- Gossip-pacing dialogue: frequent, chatty, information-carrying. Ch 1
  should be 40-50% dialogue. Conversations overlap, interrupt, circle
  back. the rhythm of real community talk where clues hide in chatter.
- Comfort-detail density: 1 cozy detail per 200 words (the tea, the
  cat, the shop bell, the scent of baking, the rain on the window).
  These are genre-contract beats. the reader expects and needs them.
- Investigation rhythm: dialogue-driven, not procedural. The sleuth
  learns through asking, listening, and noticing. not through forensic
  process or database searches. The prose reflects this: observation
  sentences are woven into social scenes, not separated from them.
- Wrongness signal: at least one moment per chapter where the warm
  rhythm stutters. a shorter sentence, a detail that doesn't fit, a
  pause in conversation. The reader should feel it before they think it.
- Tension floor: ≥4 even in the cosiest scenes. Tension lives in what
  people aren't saying, in the thing the sleuth notices but files away,
  in the comfort that feels one degree off.

COZY SCALE & TECHNOLOGY BOUNDARIES (CRITICAL)
- Small village or town setting. NOT cities
- NO sophisticated surveillance systems, CCTV, traffic cameras
- NO forensic technology (DNA analysis, fingerprint databases, etc.)
- NO hacking, phone tracking, or digital surveillance
- NO police procedural methods (the sleuth is an amateur)
- Communication: Phone calls, face-to-face conversations, maybe text messages
- Investigation methods: Observation, conversation, intuition, local knowledge
- If the sleuth needs information, she asks someone or notices something
- Police may REFERENCE forensic results but never explain methodology
  ("They found traces of digitalis" is acceptable; describing the mass spectrometry is not)
- "The forensic team" can be mentioned as an entity but never shown working on-page
- CCTV: Only mention if the story explicitly explains why it ISN'T available
  (small village, camera broken, no coverage in that area). this reinforces the
  cozy scale rather than introducing thriller-level technology

DIALECT CONSISTENCY (IMPORTANT)
- Establish the dialect in the Story Bible (British English, American English, etc.)
- Maintain 100% consistency throughout. a single "fall" in a British novel is jarring
- Common British/American traps to watch:
  - autumn / fall
  - colour / color
  - pavement / sidewalk
  - boot (of car) / trunk
  - biscuit / cookie
  - torch / flashlight
  - flat / apartment
  - "have got" / "gotten"
  - mobile / cell phone
  - post / mail
- If British English: NEVER use "fall" for autumn, "gotten", "apartment" for "flat",
  or "cell phone" for "mobile"
- The Prose Craft Improver should scan for dialect inconsistencies during its pass

MYSTERY CRAFT. EQUAL SUSPECT TREATMENT (CRITICAL)
- Use the SAME narrative register for ALL suspects including the killer
- The killer receives NO more page time, suspicious description, or "off" reactions
  than any other suspect until the outline specifically escalates them
- If the sleuth "notices" something about a character, she must notice things
  about other characters with equal frequency and detail
- Never write "something about [killer's name] felt wrong" unless the outline
  specifically calls for a clue moment involving that character
- Red herrings get the SAME narrative conviction and weight as real clues

SUSPECT BALANCE METRICS (enforced by Character Tracker verification agent):
- Per chapter: No suspect should receive >2x the mentions of any other active suspect
- Per act: Cumulative mentions per suspect should be within 1.5x of each other
- "Something about [name]" constructions: If used for one suspect, use for ALL
  active suspects within the same act (or use for none)
- Internal observations about suspects: Equal frequency AND equal depth. the
  sleuth should notice clothing, behaviour, and tone for ALL suspects, not just
  the killer
- If the Architect brief focuses a chapter on one suspect for investigation,
  other suspects should still appear in social/community scenes to maintain
  overall balance across the act
- The Architect brief should include a SUSPECT BALANCE NOTE for each chapter:
  "Primary suspect focus: [Name]. Balance appearances: [Names who need screen time]"

FAIR-PLAY PROSE
- When the sleuth notices a clue, describe it clearly enough for the reader to notice too
- No hidden observations ("She noticed something but couldn't place it". BANNED)
- Clues can be subtle but must be ON-PAGE and FINDABLE on re-read
- The reader should be able to solve the mystery before the reveal chapter
  if they're paying close attention

DIALOGUE FOR COZY MYSTERY
- Each character has distinct speech patterns (vocabulary, rhythm, verbal tics)
- Gossip and social conversation is a legitimate investigation tool
- Local knowledge and community relationships drive information gathering
- The sleuth's internal monologue can note contradictions without announcing them
- Suspects deflect, redirect, and reveal through what they DON'T say
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

MYSTERY CRAFT (40% of total):
- Clue visibility: Are clues on-page and findable? (0-100)
- Fair play: Could an attentive reader solve it? (0-100)
- Suspect balance: Are all suspects treated equally? (0-100)
- Red herring quality: Are false trails genuinely convincing? (0-100)

COZY ATMOSPHERE (30% of total):
- Comfort elements present and organic? (0-100)
- Setting feels inviting? (0-100)
- Tone warm without being saccharine? (0-100)
- Community feels lived-in? (0-100)

PROSE QUALITY (30% of total):
- Show vs tell ratio (0-100)
- Dialogue differentiation (0-100)
- Pacing appropriate for cozy? (0-100)
- Sensory detail quality (0-100)

AUTOMATIC FAILS (score = 0):
- Graphic violence or on-page death
- Unfair clues (solution depends on information not given to reader)
- Serial killer or psychopath as antagonist
- Professional detective as protagonist
- TECHNOLOGY DRIFT: Sophisticated surveillance, forensics, digital tracking
- SCALE DRIFT: Urban elements, city settings, corporate environments
- TONE DRIFT: Cynical, dark, nihilistic, or gratuitously violent moments
- Explicit sexual content or graphic profanity
```

## Continuity Rules

```
COZY MYSTERY CONTINUITY. WHAT TO TRACK

CHARACTER KNOWLEDGE STATE (CRITICAL):
- What has the sleuth CONFIRMED vs SUSPECTED vs BEEN TOLD?
- Which suspects has she interviewed? What alibis has she heard?
- What clues has she found? When and where?
- What red herrings has she followed? Has she discarded any?
- What is she WRONG about at this point in the story?

SUSPECT STATUS:
- For each suspect: current alibi status, motive knowledge, last interaction
- Which suspects has the sleuth NOT yet spoken to?
- Have any suspects been partially eliminated? On what grounds?

PHYSICAL CONTINUITY:
- Weather and season (must be consistent across chapters)
- Time of day progression (no jumps without acknowledgment)
- Location details (if the bakery has a blue awning in Ch 2, it's blue in Ch 12)
- Character physical descriptions (hair colour, clothing mentioned, injuries)

RELATIONSHIP TRACKING:
- Who knows what about whom
- Alliances and tensions between suspects
- Community dynamics (who's friends, who's feuding)
- Romance subplot progression (if applicable)

PET/FAMILIAR TRACKING (if present):
- Animal behaviour consistency
- Where the pet is during each scene
- Pet personality traits established vs maintained
```

## Character Rules

```
COZY MYSTERY CHARACTER ARCHETYPES

THE SLEUTH:
- Amateur. curiosity-driven, NOT justice-obsessed
- Connected to community (through business, family, or long residence)
- Has a skill or profession that aids investigation (observation, people skills)
- Flawed but likeable. readers should want to spend time with her
- Gradually builds confidence as investigator across the story/series
- NEVER reckless with personal safety (always has a reason for risk)

THE VICTIM:
- Must be someone whose death MATTERS to the community
- Should have connections to multiple suspects (motivates investigation)
- Reveal enough about the victim's life to make suspects plausible

THE SUSPECTS:
- 4-6 with distinct personalities, motives, and relationships to victim
- Each has a realistic alibi with AT LEAST one weakness
- None should be cartoonishly evil (cozy villains are people with reasons)
- At least one suspect should be genuinely sympathetic

THE KILLER:
- Motivation must be understandable (even if not forgivable)
- Behaviour throughout must be INDISTINGUISHABLE from innocent suspects
- When revealed, reader should think "I should have seen it" not "that came from nowhere"

THE COMMUNITY:
- 3-5 recurring community members (not suspects) who provide texture
- At least one confidant for the sleuth
- Local authority figure (constable, sheriff). competent but stretched thin
- Community dynamics should feel organic, not created for the mystery

VOICE DIFFERENTIATION REQUIREMENTS:
- Every named character identifiable by dialogue alone
- Vocabulary, sentence length, verbal tics, topics they gravitate toward
- How they respond under pressure (deflect, confront, joke, withdraw)

VOICE DIFFERENTIATION. QUANTITATIVE CHECK:
For each PAIR of suspects, identify at least 3 distinguishing dialogue features.
If any two suspects share >2 features, one must be revised before proceeding.

Male suspects are especially prone to voice convergence. Ensure different:
- Sentence length patterns (one terse, one verbose, one mid-range)
- Vocabulary level (one educated/professional, one colloquial, one technical)
- Response to pressure (one deflects, one confronts, one jokes, one withdraws)
- Topic gravity (one talks about concrete things, one about people, one about feelings)
- Verbal tic (one repeats a phrase, one clears throat, one changes subject)

The Character Tracker verification agent will flag voice convergence between
any two suspects. If flagged, the Writer must differentiate before proceeding.
```

## Arc Rules

```
COZY MYSTERY STORY STRUCTURE

ACT 1: SETUP (Chapters 1-4 for novella, 1-8 for novel)
- Establish sleuth in her normal world (community, relationships, routine)
- Introduce victim as a living character (even if briefly)
- Discovery of the body (chapter 2-3)
- Sleuth's reason for investigating (personal connection, circumstance, being a suspect)
- Introduce all suspects naturally
- Plant first 1-2 clues (subtle)

ACT 2: INVESTIGATION (Chapters 5-12 for novella, 9-24 for novel)
- Methodical investigation through conversation and observation
- Each suspect gets focus chapters (interview, observation, alibi checking)
- Red herrings deployed and some debunked
- Romantic subplot develops (if applicable)
- Comfort scenes interspersed with investigation
- Midpoint revelation that changes the investigation direction
- Dark moment: Sleuth threatened, suspect dies, or evidence disappears
- Stakes raise: It becomes personal for the sleuth

ACT 3: RESOLUTION (Chapters 13-16 for novella, 25-30 for novel)
- Final clue discovered
- Sleuth connects the dots (penultimate chapter. see below)
- Confrontation with the killer (with safety measures. she's not stupid)
- Resolution: Justice, community healing, personal growth
- Final chapter: Return to comfort (the world is right again, but changed)

THE PENULTIMATE CHAPTER. CONNECTING THE DOTS (CRITICAL):
- The sleuth's eureka moment MUST occur in a SINGLE penultimate chapter, NOT spread
  across 2-3 chapters. This is the moment the reader has been waiting for.
- Structure of the penultimate chapter:
  1. Evidence review. sleuth revisits key clues (brief, not exhaustive)
  2. The connecting insight. ONE specific realization that links everything
  3. The logical chain. each step references a specific earlier scene/chapter
  4. Decision to act. the chapter ends with the sleuth preparing for confrontation
- Case-BUILDING (gathering evidence, following threads) can span earlier chapters
  in Act 3, but the CONNECTING MOMENT. where it all clicks. is singular and
  occurs in exactly one chapter
- The reader should experience the same "aha" as the sleuth in this chapter
- Every piece of the solution must trace to previously established evidence
  (the Drift Corrector will verify this)

TENSION ARC:
- Starts warm, introduces unease
- Builds through investigation (each chapter slightly higher tension)
- Peak at dark moment (75% through)
- Brief relief, then rapid escalation to confrontation
- Resolution brings warmth back
```

## Timeline Rules

```
COZY MYSTERY TIMELINE TRACKING

MURDER WINDOW:
- Exact time of death (or range) must be established and maintained
- All suspect alibis reference this window
- Track hour-by-hour for the murder day

INVESTIGATION TIMELINE:
- How many days does the investigation span?
- Typical cozy: 1-2 weeks (novella) or 2-4 weeks (novel)
- Each chapter should cover a clear time period
- Note: Small towns have rhythms. shop hours, church days, market days

ALIBI VERIFICATION:
- For each suspect's alibi: who can verify, when was it checked?
- Track which alibis have been confirmed, weakened, or broken
- Alibi breakdowns should happen progressively (not all at once)

SEASONAL CONSISTENCY:
- If it's autumn in Chapter 1, leaves don't bloom in Chapter 8
- Weather should progress naturally
- Seasonal events (festivals, holidays) must be internally consistent

SMALL TOWN RHYTHM:
- Shops open and close at consistent times
- Characters have routines (morning coffee, evening walk)
- Community events (church, market, festival) on consistent days
- Everyone knows everyone's schedule. this aids and complicates investigation
```

## Genre-Specific Craft Techniques

Cozy mystery is the most rule-bound sub-genre in commercial
crime fiction. Its readers — frequently long-running readers
of the form, frequently genre-experienced enough to have
internalised Knox's Decalogue, the Detection Club rules, and
the conventions established by Christie, Sayers, Allingham, and
their generation of successors — expect a contract that the
contemporary form has barely loosened: low-stakes violence
held off-page or rendered with restraint, an amateur sleuth
whose investigation is plausible within their non-professional
life, a community whose social fabric is the investigation's
toolkit, comfort elements (food, pets, hobbies, seasonal
atmosphere) integrated into scene architecture rather than
sprinkled as decoration, and a puzzle the reader can solve if
they pay attention. The techniques below are how that contract
is delivered without slipping into the genre's failure modes
(unfair clue placement, narrative tells that betray the
killer, comfort elements as wallpaper, amateur-sleuth
investigation that violates plausibility, recurring-cast
inertia in series).

### The Outline Adherence System (CRITICAL FOR MYSTERIES)

This is the most important quality system for mystery writing.
Apply during EVERY chapter of writing.

**6 Iron Rules:**

**Rule 1: Chapter-Locked Writing**
Each chapter is written ONLY from information available at that narrative point.
Before writing each chapter, answer:
- What facts has the sleuth confirmed?
- What suspects identified and what's known about each?
- What clues found?
- What red herrings encountered?
- What doesn't she know yet?
- What is she wrong about?

**Rule 2: Equal Suspect Treatment**
The killer receives NO special narrative treatment until the outline specifically
calls for escalation. Check every passage mentioning the killer:
- Same amount of physical description as other suspects?
- Same frequency of "noticing" things about them?
- No "something felt off about [killer]" unless ALL suspects get similar treatment?
- Dialogue treated with same level of analysis as other suspects?

**Rule 3: No Backward Writing**
After writing each chapter, apply the Backward Writing Test:
"If I didn't know who the killer was, would I have written this chapter differently?"
If yes. REWRITE. Specific checks:
- Would the sleuth really notice that detail about the killer at this point?
- Is the killer's dialogue suspiciously loaded with double meanings?
- Does the narrative linger on the killer more than other suspects?
- Are there phrases that work as ironic foreshadowing but feel forced?

**Rule 4: Clue Planting by Schedule**
Clues appear EXACTLY when the outline specifies. Not earlier, not later.
- No "bonus" clues (they dilute the planned mystery)
- No missing clues (they break fair play)
- Each clue must be: on-page, findable, and connected to the solution

**Rule 5: Red Herrings Get Real Investment**
Every red herring is written with the SAME narrative conviction as real clues:
- The sleuth should genuinely consider the false trail
- Red herring clues should have apparent logic
- When debunked, the explanation should be satisfying (not dismissive)

**Rule 6: The Reveal Earns Its Moment**
The reveal chapter:
- Uses ONLY previously established information
- No new evidence introduced in the reveal
- The sleuth's reasoning traces a path the reader can follow
- Each logical step references a specific earlier chapter/scene
- The killer's reaction confirms rather than explains

### Comfort Element Integration

Comfort elements are not decoration; they serve the mystery
structurally and the reader emotionally, and the genre's
contract requires both functions to operate simultaneously. The
strongest cozy mysteries treat comfort as a working tool of
investigation, not as scenery the writer must remember to
include. Five integration patterns:

- **Food scenes** = interrogation over shared meals. The
  conversation that would feel forensic in a coffee shop
  becomes natural over the village fete bake-off; the
  defensive suspect drops their guard when they're praising
  the lemon drizzle. The food itself is rarely the clue, but
  the scene around it is where the clue often surfaces.
- **Craft / hobby scenes** = processing clues while hands are
  busy. The knitting circle, the gardening club, the watercolour
  group, the pottery wheel: hands occupied with familiar work
  free the sleuth's mind to make the connection that has been
  hovering. The pattern of stitches becomes the pattern of
  alibis; the rose garden's order becomes the disordered
  weekend it must explain.
- **Pet scenes** = the familiar notices things the sleuth
  misses. The cat who refuses to sit on a particular chair, the
  dog who reacts strangely to one neighbour, the parrot who has
  picked up a phrase from an unknown source. The pet's
  observations operate at the genre's signature angle —
  beneath human social register — and surface evidence the
  human characters cannot reach.
- **Community gatherings** = information exchange disguised as
  socialising. The vicar's tea, the parish council, the
  Christmas market, the village pub on quiz night. The genre's
  toolkit replaces police interview with social attendance, and
  the sleuth's social position (postmistress, librarian,
  baker) gives them access patterns a detective could not
  manufacture.
- **Seasonal atmosphere** = ticking clock. The festival
  approaching, the harvest in two weeks, the snow that will
  block the road by tomorrow, the wedding everyone is invited
  to. Cozy mystery uses the calendar where police procedural
  uses the body count — the deadline that gives the
  investigation urgency without requiring violence to escalate.

The technique fails when comfort elements appear without
serving any of these functions: the tea drunk because the
writer remembered to include tea, the pet petted because the
reader expects pets, the village hall described because the
reader expects village halls. Test each comfort beat with the
question: what would this scene lose if this comfort element
were cut?

### The Familiar as Full Character (If Familiar Present)

A talking animal familiar — common in contemporary cozy
mystery, especially the paranormal-cozy and witch-mystery
sub-segments — must be a full character with their own
interior life, not comic relief or convenience plot device:

- **Consistent personality and an agenda of their own** —
  opinions that don't always align with the sleuth's
  priorities, preferences the human respects (or fails to and
  pays for), commitments to other animals or other humans
  that compete with helping with the case. The familiar is a
  character, not a tool.
- **Animal-filtered mystery information** — clues
  communicated in unhelpful, species-perspective ways. "The
  man who smells like copper" needs decoding into "the man
  with blood on his hands"; "the cold woman" into "the woman
  whose anger is suppressed". The translation gap is the
  technique's signature pleasure and the source of much of
  the sub-genre's humour.
- **Species-accurate behaviour** — a hedgehog curls up when
  startled even mid-conversation; a ferret steals shiny
  objects regardless of whether they are evidence; a cat
  ignores the sleuth precisely when needed; a dog refuses to
  enter rooms where they sense something the human cannot.
  The animal still acts like its species even when it can
  talk; if the cat behaves like a small human, the technique
  has collapsed into puppet theatre.
- **Humour from clash, not from punchline** — comedy comes
  from the gap between animal perspective and human concerns,
  not from the familiar functioning as a joke-delivery system.
  The cat's contempt for human social ritual is funnier than
  the cat's quip about it.
- **At least one purely animal moment every four chapters** —
  doing something their species does regardless of the plot
  (grooming, napping, hunting a moth, marking territory, being
  aloof). These moments anchor the character; without them,
  the familiar drifts into being the writer's mouthpiece in
  fur.

### Comfort Elements as Scene Architecture

Comfort elements are genre-contract essentials, but they must
be integrated into scene architecture, not bolted on as
reminders that this is a cozy. Bolted-on comfort elements
tell the reader the writer was checking a box; integrated
comfort elements show the reader the sleuth lives in this
world and is making sense of it through this world's
materials. The difference is visible at sentence level:

```
BAD: "I sipped my chamomile tea. It was warm and comforting."
GOOD: "The tea had gone cold while I was reading the coroner's notes. I wrapped
       my hands around the mug anyway. Outside, rain turned the garden into a
       watercolor version of itself."
```

The integrated version does three things at once: places the
sleuth in the cozy material world (chamomile, garden, mug),
advances the investigation (the coroner's notes), and
communicates emotional state (the tea forgotten and grown cold,
hands wrapped around it for comfort that has stopped working).
Every comfort beat in a strong cozy mystery does double or
triple duty: ground the reader in the cozy register, reflect
the sleuth's interior, advance the scene's investigative or
relational purpose.

**Comfort integration frequency:** at least one comfort element
every 3-chapter stretch — food, drink, weather, cozy space,
community warmth, sensory detail of the town. A cozy that goes
five chapters without a comfort beat has slipped genre even if
the puzzle remains intact; the reader's emotional contract is
as binding as the puzzle's logical one.

### The Amateur Sleuth's Authority

The cozy sleuth is, almost always, not law enforcement: a
baker, a librarian, a florist, a postmistress, a vicar, a
schoolteacher, a retired schoolteacher, a B&B owner, a knitting-
shop proprietor, a cat-cafe owner. The genre's continuing
problem — and its continuing pleasure when handled — is
making this sleuth's investigation plausible. Why is she
asking these questions? Why are people answering? Why hasn't
she been told to stop interfering? Why isn't the official
investigation enough? The technique is to give the amateur
sleuth specific, repeated, plot-consistent reasons to be
present in the situations where investigation occurs:

- **Social position** — her job, role, or standing in the
  community gives her access patterns that strangers (and
  often the police) lack. The vicar's wife is invited
  everywhere; the postmistress sees who sends what to whom;
  the baker hears the village's confidences over the counter;
  the librarian knows what each person has been reading and
  what they were reading the week before they died.
- **Prior connection** — to the victim, the suspects, the
  scene. The body in the village hall is the body of a man
  she had been in the choir with for fifteen years; the
  suspect is her sister-in-law's nephew; the scene is the
  garden she helped plant. The connection earns her concern
  and licenses her presence at moments outsiders could not
  be.
- **Specific competence** — knitting reveals the alibi; baking
  identifies the poison; gardening recognises the planting
  that should not be there at this season; postmistressing
  notices the address in the wrong handwriting. The amateur's
  professional life is the amateur's investigative
  qualification; if her hobbies and trade do not contribute,
  she is a generic sleuth in a costume.
- **Police competence calibrated to allow her** — the genre's
  finest practitioners give the police real competence, and
  let the amateur contribute what the police cannot rather
  than what they have failed to do. Inspector Slack misses
  the village's tone but gets the forensics right; Miss
  Marple supplies the social context. The amateur whose
  contribution is "the police are idiots" mis-shelves the
  book.

Test: in a paragraph, name the sleuth's professional / social
identity, the prior connection that draws her in, and the
specific competence she brings. If any of the three is generic
("she'd always been curious"), the authority has not been
constructed and the sub-genre's plausibility-engine has not
started.

### The Recurring-Cast Continuity

Cozy mystery is, structurally, a series form. Single-title
cozies exist but are rare in commercial publishing; the form's
commercial life is the long series — Christie's St Mary Mead
(twelve novels, two short-story collections), Beaton's Hamish
Macbeth (35+ novels), Beaton's Agatha Raisin (35+ novels),
Joanne Fluke's Hannah Swensen (28+ novels), Diane Mott
Davidson's Goldy Schulz (17 novels), Cleo Coyle's Coffeehouse
(20+ novels). The recurring cast — the sleuth, her chosen
family, her professional / social network, her romantic
interest, her pet, her village or neighbourhood — is the
genre's deepest pleasure and its most-mishandled craft
problem. Two failure modes dominate: characters frozen in book-
one configuration (the love interest still tentative twelve
books later, the best friend still annoying in the same way,
the village still recovering from book three's wedding) and
characters discontinuous between books (the cat's name
changes, the bakery moved, the sleuth's mother is suddenly
deceased without explanation). The technique requires that
each book in a series advance at least one ongoing personal
arc (the romance progresses, the new business launches, a
parent ages, a child starts school, the cousin returns) while
preserving continuity bibles for everything established. Test
in series-revision: can a reader picking up book seven place
where each major recurring character is in their personal life
without book seven re-explaining their entire backstory? If
not, the continuity has been mishandled in either direction —
either too much repetition (the reader feels the book seven
hasn't trusted them) or too much drift (the reader feels they
have stepped into a different cast).

### Cozy Mystery AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the air of someone who..." | Describe the actual behaviour |
| "the expression of someone who..." | Describe the actual expression |
| "a sound that suggested..." | Describe the actual sound |
| "something about [noun] suggested..." | Show the specific detail |
| "it was clear that..." | If it's clear, just show it |
| "found herself [verb]-ing" | She's doing it. own it |
| "couldn't help but..." | Removes character agency |
| "seemed to" / "appeared to" (over 5 total) | Weakens every sentence. commit |
| "I noticed his shoes were muddy, which was suspicious" | Show the detail; let reader draw the conclusion |
| "I had a feeling" / "my instincts told me" | What SPECIFIC observation triggers the instinct? |
| "Something was off about [suspect]" | Name what's off. The detail IS the clue. |

## Genre-Specific Revision Rules

Six revision passes specific to cozy mystery, each with a single
question, run cover-to-cover before the next begins. Cozy
mystery has the genre family's strictest puzzle-fairness
discipline (the killer cannot be revealed by evidence the
reader did not have access to) and the genre family's most
particular tonal contract (no cynicism, no gratuitous darkness,
no register-breaking by the writer's contemporary sensibility).
The passes below are ordered to surface puzzle-integrity
failures first (Pass 1, the genre's most-policed standard),
procedural and tonal failures next, and series-craft failures
last for writers working in a recurring-cast cozy.

### Pass 1: Outline Adherence Audit (Run FIRST in editorial pipeline)

For EVERY chapter, verify:

1. **Knowledge State Verification**
   - List what the sleuth knows at chapter start
   - Verify she doesn't reference future knowledge
   - Check that her emotional state matches her current understanding

2. **Suspect Treatment Scan**
   - Compare narrative language used for each suspect
   - Flag if killer gets different treatment (more description, more "off" feelings)
   - Measure relative page time per suspect vs their plot importance

3. **Clue Timing Check**
   - Verify every clue appears in its scheduled chapter
   - Check no unscheduled clues were added
   - Verify clue clarity (is it on-page and findable?)

4. **Red Herring Quality Check**
   - Each red herring written with conviction?
   - Debunking feels earned, not dismissed?
   - Reader would genuinely consider the false trail?

5. **Backward Writing Scan**
   - Search for ironic foreshadowing that only works if you know the ending
   - Search for the killer being treated differently in narration
   - Search for "hints" that are really tells

6. **Reveal Integrity Check**
   - Does the reveal introduce ANY new evidence? (If yes: FAIL)
   - Does every logical step trace to an earlier scene?
   - Could the reader have solved it? (Check against clue schedule)

### Pass 2: Procedural and Plausibility Audit

Cozy mystery's amateur-sleuth contract requires that the
investigation operate within the constraints of someone whose
day job is bakery, library, or vicarage. Run a dedicated
procedural pass with the following questions:

- **Chain of custody.** Is evidence handling plausible for an
  amateur? The cozy sleuth who pockets the murder weapon, picks
  up the bloodied note from the scene, or wipes a fingerprint
  has compromised the case in ways the genre's reader will
  notice. The genre permits the sleuth to observe, photograph,
  remember, and report; it does not permit her to handle
  evidence in ways that would taint a legal proceeding. Where
  she does handle something, the prose must register the
  awareness — she knows this is wrong, she does it anyway, and
  the consequences (often a friction with the police) follow.
- **Law enforcement competence.** The police should be
  competent but resource-limited, not incompetent. Inspector-
  who-misses-the-obvious is the genre's most-tired failure mode
  and was already a cliché in the 1930s. Let the police get
  the forensics right, the alibis checked, the timeline
  established — and let the amateur contribute what they
  cannot: social context, longstanding knowledge of the
  community, the conversation the suspect would never have with
  a uniformed officer.
- **Legal plausibility.** Would the resolution hold up? If the
  sleuth's accusation rests on evidence inadmissible in court,
  on coerced confession, or on the killer obligingly delivering
  a monologue, the puzzle has been solved by the writer rather
  than by the case. Strong cozies plot a path to legal
  resolution: the evidence the police can re-examine with the
  new lens the sleuth provides, the witness who can now be
  re-interviewed, the warrant that the new theory licenses.
- **Confrontation safety.** The cozy sleuth is not a tactical
  professional; she should not be alone with a confirmed killer
  in a remote location with no plan and no exit. Where she is
  (and the genre sometimes requires the climactic isolation),
  the prose must register the calculation — the friend told,
  the phone left on, the route planned, the timing arranged so
  the police arrive at the right moment. The reckless cozy
  sleuth who walks into the killer's house alone with no
  preparation is the failure mode the genre has spent decades
  trying to retire.
- **Technology boundaries.** Cozy mystery typically operates
  with light-touch technology: the smartphone for emergency
  calls and the occasional discreet photograph, not surveillance
  feeds, criminal-database access, GPS tracking, or forensic
  software. Where contemporary cozies use technology, it must
  remain calibrated to the amateur context. The sleuth who
  hacks into the suspect's email is in a different sub-genre.

### Pass 3: Cozy Tone Consistency Check

Read the manuscript for tonal consistency, asking only whether
the cozy register holds without lapsing into genre-adjacent
darker tones (procedural, thriller, noir). The cozy register
permits warmth, gentle humour, community attention, named
seasonal pleasures, real but non-gratuitous emotional stakes,
death handled with restraint. It does not permit cynicism, on-
page graphic violence, gratuitous darkness, the writer's
contemporary frustrations bleeding through into the village's
sensibility, or the bleak modern register that characterises
much contemporary literary fiction. Check specifically for
tonal slips: the bitter aside that belongs in noir, the
cinematic violence that belongs in thriller, the
sociological cynicism about small-town life that belongs in
literary contemporary. The cozy reader has come to this book
to spend time in this world; protect the world from the
writer's other registers. Where contemporary cozies tackle
real social material (rural decline, generational change,
loneliness, dementia, the cost-of-living squeeze on village
shops), the material is welcome but must be handled in the
genre's register: with attention, gentleness, and the
recognition that the reader is here to be in good company,
not to be lectured.

### Pass 4: Comfort Element Integration Check

Verify that comfort elements are integrated into scene
architecture rather than bolted on. Read the manuscript with a
margin-tick on every comfort beat (food, drink, weather, cozy
space, community warmth, pet presence, hobby / craft / garden,
seasonal atmosphere) and ask, for each: does this beat do
double or triple duty (ground the reader in the cozy world AND
reflect the sleuth's interior AND advance scene purpose)? Or
is it sitting on the page as decorative reminder that this is
a cozy? Check frequency: at least one comfort element every
three-chapter stretch. Check distribution: comfort elements
should not cluster in the early chapters and disappear by the
investigation's middle (the failure mode where the writer
remembered to set the cozy world up and then got busy with the
mystery). Check sensory specificity: the comfort beat needs
the precise sensory detail (the particular tea, the particular
pastry, the particular weather, the particular room) that
makes the cozy world inhabitable. Generic comfort references
(she had tea; the village was charming; it was a lovely
afternoon) are placeholders the revision must replace with
specifics.

### Pass 5: Recurring Cast and Series Continuity Check

If the book is part of a series (or is positioned to launch
one), run a continuity pass on the recurring cast. Build a
continuity ledger: every named recurring character's age, job,
family situation, romantic status, prior plot involvement, key
relationships, and ongoing personal arc as established at the
end of the previous book. Read the manuscript against the
ledger and flag any inconsistency. Check ongoing-arc movement:
each book should advance at least one personal arc (the
romance progresses, the new business launches, a parent ages,
a child enters school, the cousin returns, the cat acquires a
companion). A book in a long-running series that leaves every
character exactly as it found them is the failure mode that
makes long-running cozy series feel inert; a book that
overhauls multiple characters without earning the changes is
the opposite failure mode that loses the reader who came for
continuity. Test: a reader picking up this book without having
read the prior — can they place each major recurring
character within a paragraph of their first appearance,
without the book having to re-explain everything? And: a
reader who has read the prior book — does this book feel
like a continuation rather than a repetition?

### Pass 6: The Cozy Reader's Contract Audit

Cozy mystery's reader has a specific emotional contract that
distinguishes the form from neighbouring sub-genres. The cozy
reader has come to this book for: a puzzle they can engage
with (Pass 1's territory); a community they want to spend time
in (Passes 3 and 4's territory); an amateur sleuth they like
and want to keep visiting (Pass 5's territory); and — crucially
— the experience of justice arrived at without the personal
cost the harder mystery sub-genres extract. Run a final pass
asking: at the end of this book, is the village (or
neighbourhood, or community) intact? Has the resolution
restored order rather than upending it? Has the sleuth been
changed by the case in ways consistent with the genre's
register (a friendship strengthened, a rival reconsidered, a
small skill acquired) rather than ways that belong in literary
fiction (a worldview shattered, a marriage ended, a moral
compromise that will haunt her)? The genre permits — and is
strengthened by — emotional weight, but the weight must
resolve toward continuity. The reader closes the book and
wants to come back to this world, not flee it. If the ending
leaves the reader feeling they have witnessed too much harm
or too much disruption to want to return, the contract has
been broken.
- **Scale maintained:** Small town throughout, no urban drift

## Names & Patterns to Avoid

### Cozy-Specific Character Names. NEVER USE
- Sleuth names: Poppy, Clover, Wren, Sage, Ivy, Hazel, Cinnamon
- Victim names: Any name that sounds "villainous" (Cruella, Malvina, etc.)
- Cat familiar names: Shadow, Midnight, Luna, Mystic, Whisper
- Dog names: Biscuit, Muffin, Cookie (unless the story is genuinely culinary)

### Cozy-Specific Business Names. NEVER USE
- "The Cozy [Noun]" (The Cozy Cup, The Cozy Corner, The Cozy Kettle)
- "[Cute Animal] & [Cute Object]" (Whiskers & Wands, Paws & Pages)
- "The Enchanted [Noun]" (The Enchanted Oven, The Enchanted Thread)
- "[Herb/Spice] [Establishment]" (Rosemary's Cafe, The Sage Bookshop)

### Cozy-Specific Plot Patterns. AVOID
- Sleuth discovers body while baking/crafting/walking pet (overused opener)
- The "everyone gathers in the parlour" reveal (unless deliberately homaging Agatha Christie)
- Pet literally leads sleuth to crucial evidence
- Killer confesses everything unprompted during reveal
- Love interest is the prime suspect who turns out to be innocent (overused)

### Use Instead
- Real small-town names (Bellingham, Millbrook, Denton, Prescott)
- Real business patterns (Thompson's Bakery, Main Street Books, The Flour Mill)
- Real pet names for the era (Buddy, Max, Charlie, Bella, Molly)
- Human names from census data (Patricia, Diane, Frank, Gerald, Robert)

## Comp Titles

Cozy-mystery's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Murder of Roger Ackroyd* — Agatha Christie (1926): the village-mystery template; Christie's structural masterclass.
- *Murder on the Orient Express* — Agatha Christie (1934): Poirot-mystery benchmark.
- *The Body in the Library* — Agatha Christie (1942): Miss Marple village-mystery.
- *Death on the Nile* — Agatha Christie (1937): closed-circle cozy-leaning mystery.

### Contemporary (current best-in-class)

- *The Thursday Murder Club* — Richard Osman (2020): contemporary cozy-mystery; commercial benchmark.
- *The Man Who Died Twice* — Richard Osman (2021): same series; demonstrates cozy-series architecture.
- *The Maid* — Nita Prose (2022): contemporary cozy-leaning mystery with neurodivergent protagonist.
- *Vera Wong's Unsolicited Advice for Murderers* — Jesse Q. Sutanto (2023): contemporary cozy-mystery with cross-cultural specificity.
- *The Marlow Murder Club* — Robert Thorogood (2021): village cozy-mystery benchmark.
- *The Appeal* — Janice Hallett (2021): epistolary cozy-mystery.
- *Killers of a Certain Age* — Deanna Raybourn (2022): older-woman cozy-mystery with assassin-twist.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. The DOMINANT style for cozy mystery; charming, detailed illustrations signal the genre instantly and are expected by readers; warm, inviting, and slightly whimsical without being childish
- **Graphic**. Flat, stylized graphic design with bold shapes and clean lines; a modern alternative to traditional illustration that still feels warm and approachable; works well for contemporary cozy series
- **Vintage**. Retro-inspired illustration with mid-century or classic mystery aesthetics; suits period cozy mysteries and series with nostalgic appeal; hand-lettered typography enhances the effect
- **Minimalist**. Clean design with a single iconic element (a teacup, a cat, a key) against a warm background; less common but effective for standing out in a crowded market while still signalling cozy

### Genre Cover Aesthetics
- **Styles:** Charming illustrated scenes with warm lighting, bird's-eye or angled views of cozy settings, whimsical details hidden in the illustration (clue objects, suspects in background), inviting compositions that make readers want to step into the scene, slightly cartoonish proportions that signal "fun, not frightening"
- **Colours:** Warm yellows and buttery golds (warmth, comfort, baked goods), gentle greens and sage (gardens, villages, nature), sky blue and soft teal (cheerfulness, open air), cozy orange and terracotta (autumn, firelight, baking), soft berry and plum as accents (mystery depth without darkness). the palette should feel like a sunny afternoon in a charming village
- **Elements:** Village scenes (cottages, high streets, cobblestone paths), tea shops, bakeries, and bookshops, cats and dogs (often prominent), gardens and flower boxes, quirky details (magnifying glass, footprints, mysterious shadows), seasonal elements (falling leaves, snow, spring flowers), food and baking imagery, craft supplies (yarn, books, paintbrushes), bicycles, park benches, and lampposts
- **Typography:** Playful but readable fonts. often the LARGEST element on the cover; hand-lettered or display serif fonts with personality; title frequently integrated into the illustration itself; bright, contrasting colours for text; series branding consistent across volumes; author name clear but secondary to title

### Subgenre Variations
- **Culinary Cozy**. Food imagery prominent (cakes, pies, cooking scenes); bakery or kitchen settings; warmer, more appetizing colour palette; recipe-card visual elements
- **Craft Cozy**. Relevant craft supplies visible (yarn balls, knitting needles, fabric, paint); craft shop or studio settings; slightly more textured, handmade aesthetic
- **Pet Cozy**. Animal companion featured prominently (often centre-cover); the pet's personality visible in the illustration; animal-themed decorative elements
- **Paranormal Cozy**. Slightly more mystical elements (crystal balls, potion bottles, ghostly wisps); purple and midnight blue accents added to the warm palette; still charming, never dark
- **Holiday Cozy**. Seasonal theming dominant (Christmas decorations, Halloween pumpkins, spring flowers); seasonal colour palette; festive atmosphere
- **Bookshop Cozy**. Library or bookshop interiors, towering shelves, reading nooks; richer, warmer interior lighting; literary decorative elements

### Market Positioning
Cozy mystery covers must instantly signal "charming, warm, and safe to read" on Amazon thumbnails. The illustrated style is a GENRE REQUIREMENT. photorealistic covers are almost never used for cozy mystery and will cause readers to skip past. At thumbnail size, bright colours, clear illustration, and large readable typography are essential. The title is often the most prominent element, even larger than the illustration. Readers browse cozy mystery by visual warmth first, then read the title. Series consistency is critical. matching illustration style, colour palette, and typography across all volumes builds a recognisable brand. Covers should make readers feel like they are being invited into a world they want to visit, not warned about a world that might frighten them.

### Cover Design DON'Ts
- No dark, gritty, or noir imagery. cozy mystery is warm and inviting, never threatening or bleak
- No realistic violence, weapons, blood, or crime scene imagery. death is discovered off-page; the cover should reflect that restraint
- No photorealistic style. this is almost NEVER used for cozy mystery and signals the wrong genre to readers; illustrated is the market standard
- No urban noir or city settings. the cover should feel small-town, village, or rural
- No cold, clinical, or sterile design. no stark whites, surgical blues, or forensic aesthetics
- No overly sophisticated or "serious literary" design. cozy mystery covers should be approachable and fun, not intimidating
- No tiny, elegant typography. the title must be LARGE, readable at thumbnail size, and personality-rich; understated typography signals literary fiction, not cozy mystery
- No dark or muted colour palettes. the warmth and brightness of the cover is a genre promise to the reader
