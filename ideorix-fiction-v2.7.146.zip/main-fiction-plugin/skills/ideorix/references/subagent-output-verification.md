---
name: subagent-output-verification
description: "Subagent Output Verification HARD GATE. When the engine dispatches a subagent for evidence-bearing tasks (audit, verification, fact-check, integrity scan, conformance check), the subagent's narrative claim of 'I checked / verified / confirmed' is insufficient — the engine MUST require evidence in the return (file path, line number, sha256, exact extracted text, command output, byte count). Without evidence-bearing return contracts, subagents can hallucinate completion and the main agent treats stub responses as canonical. This spec defines what counts as evidence, the HARD GATE on missing evidence, and integration with the existing 'Subagent dispatch FORBIDDEN for file-writing' rule. Engine-agnostic; mirrored across fiction and nonfiction engines."
version: "2.7.7"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Subagent Output Verification Protocol (MANDATORY for any subagent dispatch where the subagent's output drives downstream decisions)

## Purpose

Ensure that subagent dispatch returns evidence the main agent
can verify, not just narrative claims. The existing File-Write
Hygiene binding forbids subagent dispatch for file-writing
steps. This spec extends the discipline to evidence-bearing
tasks: audit, verification, fact-check, integrity scan,
conformance check, content extraction, search.

## The failure mode

Subagent dispatch is convenient for parallel work and context
isolation. But subagents can return claims that look complete
without doing the work:

- **Hallucinated audit:** subagent returns "I scanned all 12
  chapters and found 3 forbidden words" without having actually
  Read any chapter file.
- **Stub completion:** subagent returns "✓ verification passed"
  with no detail; the actual check was either skipped or done
  superficially.
- **Scope drift:** subagent was asked to audit chapters 1-12;
  actually checked only chapter 1 and extrapolated.
- **Confident wrong answer:** subagent returns a specific claim
  ("found violation on line 247") that turns out to be
  fabricated when the main agent goes to look.
- **Acknowledgement-as-completion:** subagent returns "Yes, I
  understand the task" or "I'll do that now" instead of the
  actual result.

The main agent has no way to distinguish a real audit from a
hallucinated one unless the subagent's return contains
verifiable evidence.

## The fix — evidence-bearing return contracts

For any subagent dispatch where the subagent's output drives
downstream decisions, the dispatch prompt MUST require evidence
in the return AND the main agent MUST verify the evidence
before acting on it.

### What counts as evidence

| Task type | Required evidence |
|-----------|-------------------|
| File audit (forbidden words, formatting check, etc.) | List of (file path, line number, exact matched text) for each violation; exit code from the gate script if applicable |
| Multi-chapter scan | Per-chapter result (filename, sha256, count, status); aggregate count |
| Fact verification (cross-checking a specific) | (source URL or file path, exact quoted text, byte offset or line number) |
| Outline conformance | (chapter file path, beat label, expected text, actual text, match/miss verdict) |
| Continuity audit | (file paths checked, entities scanned, drift instances with surrounding context) |
| Content extraction | (source file path + line range, exact extracted text, character count) |
| Integrity check | (file paths checked, byte counts, sha256 hashes, comparison verdict per file) |
| Search / grep | (search pattern, file paths matched, line numbers, exact matched text) |

The main agent's dispatch prompt MUST specify which evidence
items are required for the task. Generic dispatches like
"audit the manuscript" without specifying expected evidence
format are FORBIDDEN — they invite hallucinated returns.

### What does NOT count as evidence

- "I checked X and it looks good" (no file path, no line, no
  extracted text)
- "Verification passed" with no per-item detail
- "Found 3 issues" with no list of which issues where
- "Looks consistent" without sha256 or byte counts
- "I'll proceed with that" (acknowledgement, not result)
- "Confirmed" without a quote of what was confirmed
- A summary that names file paths but no line numbers or
  extracted text

### HARD GATE — the main agent verifies

After receiving the subagent's return, the main agent MUST
spot-check the evidence before treating the result as
authoritative:

1. **Evidence-presence check.** Does the return contain the
   evidence types specified in the dispatch prompt? If not,
   FAILED_DISPATCH — re-run with explicit evidence
   requirements OR halt and surface to user.

2. **Evidence-validity check (sample).** Pick at least one
   evidence item from the return and verify it against the
   actual file/source. If the subagent claimed "violation on
   line 247 of ch03.md", the main agent Reads ch03.md line
   247 and confirms the claim matches. Discrepancy is
   FAILED_DISPATCH.

3. **Scope-completeness check.** Does the return cover the
   full scope requested? If the dispatch asked for chapters
   1-12 and the return mentions only chapters 1-3, scope is
   incomplete — FAILED_DISPATCH.

If any check fails, the main agent MUST NOT use the subagent's
output as basis for downstream decisions. The agent either
re-dispatches with stricter evidence requirements OR performs
the task itself OR surfaces the failure to the user.

## When the protocol applies

Every subagent dispatch in the engine where the subagent's
output drives downstream decisions MUST apply this protocol.
Specifically:

| Flow | Spec | Subagent role |
|------|------|---------------|
| Step 12 — Verification suite | quality-gate.md (fiction) / accuracy-gate.md (NF) | Per-chapter verification agents (fiction: the 6-agent suite — Continuity Guardian, Quality Guardian, Timeline Keeper, Character Tracker, Arc Analyst, Dialogue Guardian; NF: the Accuracy-Gate Five — Source Guardian, Evidence Auditor, Citation Keeper, Expert Tracker, Argument Analyst) |
| Phase 4 — Canon Validator | canon-validator.md | Per-chapter post-write canon-drift audit |
| Phase 5 Stage 1 — Genre Audit | editorial-suite.md | Genre-specific revision rules subagent |
| Phase 5 Stage 2-4 — Editorial agents | editorial-suite.md | Proofreader, Copy Editor, Developmental Editor |
| Phase 5 Stage 5-6 — Reader agents | editorial-suite.md | Alpha Reader, Beta Reader |
| Phase 5 Stage 9 — Continuity Audit | editorial-suite.md (fiction) / fact-audit.md (NF) | Full-manuscript audit subagent |
| Phase 5 Stage 10 — Multi-POV / Bias-Balance | editorial-suite.md | Multi-pass consistency subagent |
| Outline Conformance Agent | outline-conformance.md | Per-chapter beat-conformance audit |
| Manuscript Clinic six-axis analysis | manuscript-clinic.md | Six analysis subagents |

(Not exhaustive. Any new spec that dispatches a subagent for
audit / verification / extraction / search MUST cite this
binding.)

## Existing rule (extended): Subagent dispatch FORBIDDEN for file-writing

The File-Write Hygiene binding (`core-pipeline.md`) already
forbids subagent dispatch for file-writing steps:

> "Subagent dispatch is FORBIDDEN for any step that ends in
> a write to a critical-path file."

This spec extends the rule:

> "Subagent dispatch is FORBIDDEN for any step that ends in a
> write to a critical-path file. Subagent dispatch for any
> evidence-bearing step (audit, verification, fact-check,
> integrity scan, conformance check, content extraction,
> search) MUST require evidence in the return contract AND
> the main agent MUST verify the evidence before treating
> the subagent's output as authoritative."

## Dispatch prompt requirements

When dispatching a subagent for evidence-bearing tasks, the
prompt MUST include:

1. **Explicit task scope** — exact file paths, exact stages,
   exact items to check.
2. **Required evidence format** — what fields the return must
   contain (file path, line number, sha256, extracted text,
   etc.).
3. **Failure-mode acknowledgement** — instruct the subagent
   to return `FAILED_TASK` with reason if it cannot complete
   (e.g., file not found, content unreadable) rather than
   silently inventing a result.
4. **Evidence-bearing template** — provide a structured output
   template the subagent fills in, not free-form prose.

Example dispatch prompt structure:

```
Task: Audit chapters 1-3 of {project} for forbidden-word violations.

Files to audit:
  - ~/Documents/Ideorix-Projects/{Title}/engine-data/chapters/ch01.md
  - ~/Documents/Ideorix-Projects/{Title}/engine-data/chapters/ch02.md
  - ~/Documents/Ideorix-Projects/{Title}/engine-data/chapters/ch03.md

Forbidden words list: forbidden-words.md (Tier 1, Tier 2, Tier 3)

Return EVERY violation in this format:

  ## Violations

  | Chapter | Line | Tier | Word | Surrounding text (±20 chars) |
  |---------|------|------|------|------------------------------|
  | ch01.md | 47 | 1 | "delve" | "...we will delve into the topic..." |
  | ...

  ## Aggregate
  Total Tier 1 violations: N
  Total Tier 2 violations: N
  Total Tier 3 violations: N

If you cannot Read any chapter file, return FAILED_TASK with
the filename and reason. Do NOT proceed without all chapters
Read.

Do NOT estimate, paraphrase, or summarize — list every
violation explicitly with file + line + exact text.
```

## What the protocol does NOT do

- It does **not** prevent subagent dispatch in general — only
  requires evidence-bearing return contracts for tasks where
  the output drives downstream decisions.
- It does **not** apply to subagents whose output is purely
  narrative / consultative (e.g., a subagent asked "what genre
  conventions apply to this story idea?" — there's no
  verifiable evidence, only the model's recommendation).
- It does **not** validate the subagent's reasoning quality —
  only that the claimed work was actually done. A subagent
  that completes the task but gives bad recommendations is a
  separate quality concern.
- It does **not** apply to the existing File-Write Hygiene
  rule's forbidden-dispatch territory (file-writing) —
  that's covered by the parent binding.

## Logging

The main agent records each subagent dispatch in the project's
session log:

```
~/Documents/Ideorix-Projects/[Title]/engine-data/run.log
```

Per-dispatch entry:

```
[YYYY-MM-DDTHH-MM] SUBAGENT_DISPATCH
  Task: {task_summary}
  Scope: {file_paths_or_scope}
  Required evidence: {evidence_types}
  Result: PASS | FAILED_TASK | FAILED_DISPATCH (evidence missing/invalid)
  Spot-check: {evidence item verified} → match | discrepancy
```

## Anti-patterns this protocol prevents

- **Hallucinated audit completion** — subagent returns "audit
  passed" without having read any file.
- **Stub completion** — generic "✓ done" with no per-item
  detail driving downstream decisions.
- **Scope-drift extrapolation** — subagent checks first item
  and extrapolates to the rest.
- **Confident-wrong specifics** — subagent invents a "violation
  on line 247" that doesn't exist when the main agent looks.
- **Acknowledgement-as-completion** — subagent returns "I'll
  do that" treated as "I did that".

## Cross-cutting binding

This protocol is the **seventh cross-cutting binding**. The
canonical catalog of all bindings and audited primitives is
`silent-failure-audit.md`. This binding addresses primitive
#11 (Subagent dispatch — evidence-bearing) in that catalog.

Parallel bindings —
parallel to:

1. Architect Mode binding
2. Verification Discipline binding
3. File-Write Hygiene binding (already includes "Subagent
   dispatch FORBIDDEN for file-writing")
4. Edit-Tool Typographic Fidelity binding
5. Read-Verification binding
6. Web-Content Verification binding
7. **Subagent Output Verification binding (this spec)**

Every spec that dispatches a subagent for evidence-bearing
work invokes this binding at the dispatch step.

## Enforcement model (honest)

This is an orchestrator-invoked discipline binding, not a
tool-intercepting hook. No script gate can dispatch subagents
or inspect their returns — only the LLM driving the pipeline
can. The `validate-dispatcher.sh` script makes this explicit:
it emits the audit work-list but cannot itself dispatch, so
the evidence-bearing return contract is enforced by the
orchestrator reading this spec and rejecting (FAILED_DISPATCH)
any subagent return that lacks evidence. The "MANDATORY /
HARD GATE" framing means *the contract is non-negotiable* —
the main agent must refuse a stub return — not that a hook
structurally blocks it. This is the same enforcement model as
the other cross-cutting bindings (read-verification,
web-content-verification): deterministic where a script can
check (the dispatcher's work-list, the downstream gate
artifacts), LLM-contract where only the orchestrator can act.
