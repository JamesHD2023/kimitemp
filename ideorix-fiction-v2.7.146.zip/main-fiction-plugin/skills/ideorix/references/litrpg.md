---
name: litrpg-genre
description: "Genre-specific instructions for LitRPG / Progression Fantasy. pair with the Ideorix Engine"
version: "1.0"
user-invocable: false
parents: [fantasy, science-fiction]
---

# LitRPG / Progression Fantasy. Genre Plugin

## Metadata
- **Genre ID:** litrpg
- **Display Name:** LitRPG / Progression Fantasy
- **Category:** Fantasy & Sci-Fi
- **Tier:** Core
- **Target Word Count:** 3,000–5,000 per chapter
- **Min Word Count:** 3,500
- **Recommended Beat Structures:** Hero's Journey, Story Circle, Epic Fantasy Arc, Three-Act Structure, Worldbuilding Beats, Seven-Point Structure

## Subgenre Options
| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| GameLit / VR | Characters inside a virtual game world | Dual-world tracking (real/game); logout requirements; time dilation |
| Isekai / Portal | Transported to a game-like world | No logout option; real stakes (permadeath); culture shock |
| System Apocalypse | Real world gains game mechanics | Survival focus; society collapse; everyone levels, not just MC |
| Cultivation | Eastern-influenced power progression | Qi/mana cultivation; breakthrough stages; sect politics |
| Dungeon Core | MC IS the dungeon | Base-building focus; wave defense; minion management |
| Tower Climbing | Ascending floors with escalating difficulty | Floor-by-floor structure; clear milestones; boss per floor |

## Architect Instructions

### Chapter Planning Requirements

**Structure:**
- Chapter length: 3,500–5,000 words
- Pacing: Progression-driven with clear challenge → reward loops
- Must open with: System interaction, challenge setup, or aftermath of previous encounter
- Must close with: Progression milestone, cliffhanger, or setup for next challenge

**Genre Promise:** Deliver a story where character growth is explicitly tracked (levels, skills, stats) and emotionally meaningful. The reader should feel both the dopamine hit of progression AND the emotional stakes of the journey.

### Genre DNA
- Explicit game or system mechanics (levels, XP, skills, classes, stats)
- Clear progression loop (challenge → gain → new challenge)
- Powers/abilities that evolve logically
- Stakes that grow with the character's power
- Choices that matter: builds, paths, party dynamics, morality

### Core Structural Elements

1. **System Awakening / Entry**. Protagonist gains access to system; first stat screen moment; initial limitations and starting build
2. **First Quest / Tutorial Arc**. Low-risk challenge demonstrating core mechanics; reader learns rules through action; first level-up
3. **Progression Loop Established**. Clear pattern: take on content → risk → reward → growth; system feedback; early build decisions
4. **Party / Faction / Social Dynamics**. Allies, rivals, mentors, guilds, factions; social choices affect power and risk
5. **Mid-Game Reveal**. Hidden rule, exploit, or punishment in the system; stakes become existential
6. **Late-Game Content**. High-level dungeons, raids, bosses; protagonist build tested under pressure
7. **Endgame & Legacy**. Final confrontation validating MC's build, growth, and choices; system status resolved

### Beats Per Chapter

Every chapter MUST advance either:
- Levels, skills, gear, or quests. AND/OR
- Emotional relationships, stakes, or world understanding

Show at least one of:
- Stat change, skill use, or system notification
- Progress on a quest/objective
- Decision about build, path, or party composition

### Story Turns (Every 4–6 Pages)
- System notification that changes the tactical picture
- New enemy ability revealed mid-combat, forcing adaptation
- Party member's hidden agenda surfacing at worst moment
- Loot drop or level-up creating a dilemma
- NPC or rival player disrupting a solid plan
- System rule exception discovered through desperation

Turns should hit both mechanical and emotional registers. A new skill isn't just +10 damage. it changes what the character can DO and FEEL.

### Narrative Layers (A/B/C Stories)
- **A-story:** MC's progression. levelling, building, conquering content
- **B-story:** Relationships and party dynamics. trust, rivalry, shared goals, hidden motivations
- **C-story:** System mystery or world-level threat. why does this system exist? Who controls it?

When storylines converge, the best moments happen: a party betrayal during a boss fight that also reveals a system secret.

### Forbidden in Planning
- Long stat-dumps without emotional or tactical relevance
- Progress with no risk (must feel earned)
- Arbitrary power spikes that break system logic
- Inconsistent rules (system must feel coherent)

## Writer Craft Rules

### Engagement Framework

→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (progression hits — level-ups, loot, skill unlocks), Anticipation (next-tier challenge), Validation at hard-earned tier crossings.

### Heat Calibration

→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

### Voice and Tone
- **POV:** 1st person or close 3rd. tactical awareness essential
- **Tense:** Past or present. present adds immediacy to combat
- **Voice:** Clear, energetic, tactically-minded
- **Tone:** Balance crunch (stats, skills, mechanics) with feel (excitement, fear, awe, frustration, triumph)

### Reader Fantasy
- "I am getting stronger."
- "My choices matter."
- "I understand the system and can predict how it behaves."

### The 10 LitRPG Craft Commandments

1. **Show the System Through Action**. Explain rules via combat, quests, and problem-solving. Minimise pure exposition.
2. **Make Stats Emotionally Meaningful**. A new skill should change what the character can DO and FEEL.
3. **Progression Must Feel Earned**. Rewards after risk and effort. Grinding should feel purposeful, not dull.
4. **Maintain System Consistency**. Rules must be stable. If broken, explicit narrative justification required.
5. **Tactical Clarity in Combat**. Readers understand what abilities are used, why chosen, what trade-offs exist.
6. **Avoid Pure Number Spam**. Stats and notifications attached to tension, strategy, or big decisions.
7. **Progression Loop Variety**. Don't repeat the same dungeon/quest pattern endlessly. Change enemies, environment, goals.
8. **Character First, System Second**. MC's internal conflict, values, relationships still matter. Power without humanity is boring.
9. **Escalate Both Power and Stakes**. More power brings more responsibility, danger, and moral complexity.
10. **Pay Off Builds and Choices**. Early build decisions echo later. Synergies and unique combos reward planning.

### UI / System Text Style
- Use concise, consistent formatting for system messages, level-up notifications, quest prompts
- Keep readable, not overwhelming
- Notifications should serve tactical or emotional purpose

### Word Choice
- Prefer short, punchy words for action: "hit" not "struck with force," "gut" not "abdomen"
- System terminology can be Latinate (genre convention) but narrative prose should be concrete and physical
- Every description should do double duty: atmosphere + game feel, or character state + tactical information
- Combat prose: short sentences, strong verbs, spatial clarity

PROSE RHYTHM MAPPING
- Chapter 1 must establish system + character + stakes. the game mechanics and the human within them arrive together
- Clean prose for narrative: sentences average 12-20 words. Direct, energetic, clear. the reader should never struggle to parse what's happening
- Distinct formatting for game-mechanics: system notifications, stat screens, and UI text are visually separated from narrative prose. They punctuate the rhythm rather than sustaining it
- Combat rhythm: short sentences (6-14 words), strong verbs, spatial clarity. "He dodged left. The blade missed by inches. Stamina bar: critical." The prose drives like a game in real-time
- Opening paragraphs: establish the dual-layer immediately. narrative prose that reads clean and modern, with the first system notification arriving as a rhythmic disruption that signals the genre
- System notifications as rhythm beats: they land BETWEEN narrative sentences like punctuation marks. creating a staccato break in the flow that mirrors the protagonist's split attention
- Exploration and discovery: medium sentences (14-20 words) with curiosity driving forward momentum. The prose moves with purpose. always toward the next thing to learn or find
- Character/emotional moments: slightly longer sentences (16-22 words) that slow the pace just enough for the reader to connect with the person behind the stats
- Tactical analysis (MC thinking through a fight): medium-short sentences (12-16 words) with clear logical progression. "The boss had a two-second recovery. That was his window. Two seconds or nothing."
- Grinding sections: VARY the rhythm. Same-length sentences repeated create monotony that mirrors boring gameplay. Instead, punctuate grinding with unexpected rhythm shifts. a sudden short sentence of danger, a longer sentence of discovery
- Tension baseline: ≥5 from the first page. LitRPG readers expect engagement immediately. the system, the challenge, or the stakes must be active from paragraph one
- Level-up moments: the rhythm should feel like a reward. A beat of tension (short sentences during the final push), then a system notification (formatted differently), then a slightly longer sentence of satisfaction or wonder at the new capability
- Party banter: quick exchanges, short sentences, overlapping voices. The rhythm of a group under pressure. no one monologues in a dungeon
- Paragraph length: medium-short. LitRPG paragraphs move quickly. 3-5 sentences, then forward. The genre rewards momentum
- End-of-chapter rhythm: either a system notification that reframes everything (the formatted text doing the work) or a sharp narrative sentence that drives into the next challenge
- Read combat passages as if calling out game actions. if the rhythm doesn't match real-time decision-making pace, it's too slow
- The goal: prose that feels like playing a game where you're fully immersed. clean enough to disappear into, paced to deliver the dopamine of progression, and human enough to make the numbers matter

### Emotional Rhythm
- Combat oscillates between dread and exhilaration
- Grinding needs peaks and valleys: boredom → discovery → danger → mastery → complacency → surprise
- System reveals combine wonder and anxiety
- After every major victory, plant the seed of the next challenge

### Forbidden Craft Patterns
- Walls of stat text with no emotional hook
- Deus ex machina system "gifts" with no risk or cost

## Quality Check Criteria

### Priority Ranking
1. **System clarity and consistency**. Mechanics understandable, rules stable, notifications readable
2. **Progression impact**. Meaningful growth that changes what MC can do and feel
3. **Risk vs. reward balance**. Rewards earned through credible risk, not gifted
4. **Tactical combat clarity**. Abilities used logically, trade-offs visible, action followable
5. **Character and emotional depth**. MC reacts to gains, losses, challenges; relationships advance alongside numbers
6. **Pacing balance**. Action, system information, and character moments in healthy proportion

### Genre-Specific Checks
- Stats and notifications attached to tension, strategy, or decisions. not pure dumps
- Progression changes capability, not just numbers
- System rules consistent within chapter and with established mechanics
- Combat spatially clear
- Build decisions have real trade-offs
- Emotional stakes rising with mechanical stakes
- Party dynamics advancing through shared combat/progression

### Automatic Fails
- Walls of stat text with no emotional or tactical hook
- Deus ex machina system gifts without risk, cost, or setup
- Inconsistent system rules
- Progress without credible risk
- Pure grind with no character development

### Red Flags
- Skills used that haven't been acquired
- Stats referenced inconsistently within scene
- Power spikes that break system logic
- Combat outcomes contradicting established power levels
- Inventory items appearing that were never obtained
- Build inconsistency. glass cannon facetanking, healer soloing DPS

## Continuity Rules

### Top 5 Continuity Priorities
1. **Character Stats and Levels**. Levels never decrease unless system explicitly allows; HP/MP track logically; attribute totals plausible
2. **Skills and Abilities**. Only used if previously acquired; cooldowns and costs respected; evolution matches system rules
3. **Gear and Inventory**. Weapons, armour, accessories, consumables tracked; items can't appear/disappear without explanation
4. **Quests and Objectives**. Quest states consistent; rewards granted only once unless repeatable
5. **Party Composition**. Who's in the party, where they are, what they know; injuries/deaths/betrayals tracked

### Narrative Layer Tracking
- A-story (Progression): MC's current level, active build path, next milestone, current dungeon/quest
- B-story (Relationships): Party trust levels, active conflicts, unresolved tensions, NPC bonds
- C-story (System mystery): Clues gathered, theories formed, revelations approaching
- Flag when any storyline goes 3+ chapters without advancement

### Story Turn Log
- Track last significant turn per storyline per chapter
- Ensure turns escalate. early turns surprising, later turns devastating
- Flag chapters without mechanical OR emotional turns
- Boss encounters should contain multiple turns

### Economic & Resource Tracking
- Currency: current gold/resources tracked. income and expenses should be roughly traceable
- Shop/vendor prices: once established, consistent unless market events shown on-page
- Crafting material inventory: rare materials tracked by name, common materials by category
- Repair and maintenance costs: gear degradation tracked if the system includes durability
- Quest reward economy: rewards granted only once unless repeatable quest established
- Consumable supply: potions, scrolls, food. quantities matter before dungeon runs

### Acceptable Flexibility
- Minor numeric handwaving if core logic holds
- Abstracted grind sections with justified big gains
- Approximate currency totals if general financial status is clear

## Character Rules

### Character Consistency Priorities
1. **Build integrity:** MC's decisions reflect chosen build. glass cannon doesn't facetank
2. **System knowledge compliance:** Characters use known mechanics, don't ignore inconvenient rules
3. **Stat-appropriate behaviour:** Level 5 doesn't challenge level 50; power gaps respected
4. **Emotional growth parallel:** Mindset evolves alongside stats. power changes personality
5. **Consequence tracking:** Death penalties, cursed items, lost levels persist

### Genre-Specific Character Elements
- Build identity: glass cannon, tank, summoner, support, hybrid. shapes all combat decisions
- Starting stats: clear baseline to track progression against
- Emotional motivation: WHY they pursue power (survival, revenge, freedom, mastery, protection, escape)
- Gamer knowledge: how much meta-knowledge (min-maxer or casual?)
- Risk tolerance: aggressive pusher or careful planner?
- Resource management: hoarder or spender?
- Solo vs. party preference and why
- Real-world identity (if VR): who are they outside the game?

### Track for MC
- Current level, class, and subclass
- Key skills with levels/ranks and cooldowns
- Core stats and allocation
- Equipment loadout and notable items
- Build theme and combat strategy
- Death count and persistent penalties
- Faction reputation
- Resources: gold, materials, consumables, special currencies
- Quest log: active quests, progress, deadlines

### Party Members (Track Each)
- Role: tank, DPS, healer, controller, crafter, support
- Level relative to MC
- Signature skills and combat identity
- Relationship with MC: trust level, history, potential conflicts
- Personal motivation and own goals
- Weaknesses and vulnerabilities

### Antagonists
- System-level: Admin AI, game devs, gods, world rules. abstract threats
- Personal: Rival players, guild leaders, boss monsters, PKers. direct threats
- Power level relative to MC
- Resources and advantages beyond raw stats
- Motivation for opposing MC

## Arc Rules

### Core Progression Arc (9 Checkpoints)

1. **System Awakening / Entry**. Protagonist gains access; first stat screen
2. **First Level-Up / Tutorial Dungeon**. Mechanics demonstrated through action
3. **Early Build Commitment**. Choices with future consequences
4. **First Major Defeat or Harsh Penalty**. Stakes proven real
5. **Mid-Game Breakthrough**. Exploit, synergy, new class, or hidden mechanic
6. **System or World Revelation**. Rules are not what they seemed
7. **High-Level Challenge**. MC's unique build truly tested
8. **Endgame Confrontation**. Boss, admin, god, tournament, final dungeon
9. **Resolution of System Relationship**. Mastery, escape, alliance, or rebellion

### Required Checkpoints
- Chapter 3: System fully introduced, first level-up achieved
- Chapter 8: Party forming, first serious challenge faced
- Chapter 15: Mid-game content begins, hidden mechanics hinted
- Chapter 22: Major system revelation, stakes escalate
- Chapter 28: Endgame push begins
- Final Chapter: Build and choices validated, system relationship resolved

### Emotional Alternation
- Every progression arc alternates triumph and setback
- Within combat: oscillate between "we're winning" and "everything's falling apart" at least twice per major encounter
- Grinding sections need emotional texture
- After every major victory, next chapter opens with a new problem
- Overall trajectory: wonder → confidence → humbling → adaptation → mastery → questioning → transcendence

### Fractal Structure
Progression patterns repeat at every scale:
- **Scene level:** Challenge → attempt → failure/adaptation → success/cost (mirrors a dungeon run)
- **Chapter level:** Goal set → obstacles → progression → new ceiling (mirrors a quest chain)
- **Act level:** Weak → growing → tested → transformed (mirrors the entire power journey)

Each boss fight should echo the full story arc in miniature.

### Narrative Layer Convergence
- Act I: A, B, and C stories established separately
- Midpoint: B-story crisis forces A-story choice
- Act II climax: All three converge. system reveal changes what progression means
- Resolution: Personal growth, relationship resolution, and system understanding resolve together

## Timeline Rules

### Time Scale
- Total story duration: Weeks to months
- Chapter time span: Hours to days. compressed during grinding, expanded during encounters
- Time progression: Linear with time skips for training montages

### Genre-Specific Temporal Rules
- Level-ups earned through time investment. can't gain 50 levels in one day without consequences
- Training and grinding take real time
- Cooldowns and recovery matter
- Quest timers create urgency
- Dungeon runs have duration
- Crafting and gathering take time
- Sleep/rest requirements exist
- Event timing on schedules

### Progression Pacing
- **Early game:** Levels come quickly, establishing power baseline (days)
- **Mid game:** Progression slows, each level more meaningful (weeks)
- **Late game:** Major levels rare, quality over quantity (weeks to months)
- Time skips acceptable: "Two weeks of grinding later" covers repetitive advancement
- Bottlenecks: class evolution, rank-up quests require preparation time

### VR/Dual-World Timing
- Real-world time matters. job, family, physical health
- In-game time ratio tracked if different
- Logout requirements: eating, sleeping, real obligations
- Time dilation effects: consistent rules if present
- Real-world stakes intersecting game time

## Genre-Specific Craft Techniques

LitRPG is a relatively young commercial form (the term itself
emerged in the early 2010s, codified in the Russian
litRPG-as-genre convention before crossing into English-
language commercial publishing through Andrew Rowe, Will
Wight, Aleron Kong, Travis Bagwell, Dakota Krout, Matt
Dinniman, He Who Fights With Monsters by Shirtaloon, and
others) operating at the intersection of fantasy, science
fiction, and gaming culture. Its readers are deeply genre-
literate — many are tabletop RPG players, MMO veterans,
JRPG enthusiasts, or readers of the broader progression-
fantasy adjacent (Sanderson's Cosmere, the Cradle series, He
Who Fights With Monsters, Beware of Chicken). The reader
arrives expecting specific pleasures: legible game mechanics,
character progression with stakes, build optimisation, the
satisfaction of stat-block clarity, and the genre's signature
combination of analytical engagement (working out the
optimal build) and narrative satisfaction (the character
becoming who they were always meant to be). The techniques
below are how the form sustains these dual pleasures across
typically long-form work — many litrpg novels run 200,000+
words, and the form's commercial life is heavily series-
driven (multi-volume progressions of 7–15+ books are
common). The form's failure modes: stat dumps without
narrative weight; level-ups without consequence; combat that
reads as DPS checks rather than tactical puzzles; power creep
that renders prior stakes meaningless; and the genre's
characteristic "grinding fatigue" when training sequences are
written without emotional or strategic interest.

### The Meaningful Level-Up

Every level-up should be a narrative event, not just a number
change. The genre's signature pleasure — the moment of
character growth marked by visible mechanical progression —
collapses into wallpaper if the writer treats level-ups as
bookkeeping. A level-up at chapter ten should land
differently from a level-up at chapter twenty-five; a level-
up earned through a costly fight should land differently
from a level-up earned through grinding; a level-up that
opens new tactical options should land differently from a
level-up that confirms existing direction. The technique
requires that each level-up event include all four
components below.

1. **Context:** What challenge was just overcome? What did it cost?
2. **Choice:** What skill/stat allocation decision faces the MC? What are the trade-offs?
3. **Capability:** What can the MC now do that they couldn't before? How does this change their approach?
4. **Consequence:** How does this power change the MC's place in the world? Who notices? What new dangers appear?

The four-part structure is the technique's discipline. Skip
the Context, and the level-up arrives without the cost that
makes it land. Skip the Choice, and the reader's analytical
engagement with the build collapses into spectator mode. Skip
the Capability, and the new power has no specific application
the reader can track. Skip the Consequence, and the genre's
escalation engine — that growing power attracts growing threat
— stalls. Test: pick three level-up events spaced across the
manuscript and verify each one carries all four components.
If any is missing, the level-up has been treated as
bookkeeping, and one of the genre's primary pleasures has
been forfeited.

### The System Notification as Dramatic Beat

System text should function as story beats, not as appendix
content padding the page count. The form's signature visual
element — the system message, often rendered in box,
different font, or italic to mark its difference from the
narrative voice — must do specific dramatic work each time it
appears. The strongest litrpg writers treat the system as a
character: an entity with its own personality (often
indifferent, sometimes ironic, occasionally menacing), its
own voice, and its own pacing within the narrative.

Four functional categories of dramatic notification:

- **Tension notification:** "WARNING: HP Critical. Potion cooldown: 47 seconds." — Creates countdown drama
- **Revelation notification:** "Hidden Achievement Unlocked: First to discover [REDACTED]." — Hooks curiosity
- **Emotional notification:** "Party Member [Name] has left your group." — Mechanical delivery of emotional blow
- **Ironic notification:** "Quest Complete: Protect the Village. Reward: 50 XP. Village Status: Destroyed." — System indifference as dark humour

Notifications that serve none of these functions (the level-
up confirmation that simply repeats the level number; the
inventory update that does no narrative work; the stat tick
that the reader does not need to track) are noise. The
discipline is calibration: a litrpg novel can sustain
roughly 6–10 substantive system notifications per chapter
without fatigue; beyond that, the reader's eye begins to
skip notification blocks, and the form's signature visual
element loses its effect. Test: for every notification in a
sample chapter, name which of the four functions it serves.
If a notification serves none, cut or rewrite it.

### The Build Payoff Architecture

Early build decisions must pay off spectacularly in later
chapters. The form's deeper pleasure is the long-arc
strategic recognition: the moment the reader realises the
"useless" skill chosen in chapter five was the key all
along, that the unconventional build the protagonist took
heat for was correct, that the early choice has just paid
off in a way no straightforward build could have produced.
This is the genre's specific equivalent of Chekhov's gun —
the build itself is the gun on the wall.

- **Chapter 5:** MC chooses an unusual skill everyone calls useless
- **Chapter 12:** Skill has a minor unexpected application
- **Chapter 20:** Skill synergises with a late-game discovery
- **Chapter 28:** The "useless" skill becomes the key to defeating the final boss

The architecture requires patience and planning. The early
choice must be visible enough to register (the reader
remembers it) but not so prominent that it telegraphs the
payoff (the reader sees the trick coming). The middle
appearances must reinforce the skill's existence without
prematurely revealing its full potential. The final payoff
must use the skill in a way that makes structural sense (it
solves the climactic problem because it solves the
climactic problem, not because the writer needed it to). The
strongest litrpg series run multiple build-payoff
architectures simultaneously — the unusual skill, the
collected resource, the named relationship, the class
combination — paying off across hundreds of pages with the
careful reader rewarded multiple times.

### The Tactical Puzzle Fight

Combat as intellectual engagement, not as raw damage
exchange. The form's combat scenes work when the reader is
solving the problem alongside the protagonist — analysing
the enemy's abilities, weighing available options, watching
strategy adapt mid-encounter. They fail when combat reads as
DPS exchange (number versus number, with the bigger number
winning), as deus-ex-skill (the protagonist conveniently
acquires the perfect ability mid-fight), or as cinematic
action without mechanical legibility (the fight is exciting
but the reader cannot reconstruct what just happened or why
the protagonist won).

- Present the enemy's abilities clearly (the reader needs
  enough information to engage with the puzzle)
- Show the MC analysing options (not just reacting; the
  protagonist's interior shows them weighing tactical
  alternatives)
- Include at least one mid-fight adaptation (initial
  strategy fails, requiring revised approach with the
  available toolkit)
- Resolution comes from clever application of established
  abilities (no new abilities discovered mid-fight; the
  victory uses what the reader already knew the protagonist
  had)
- Victory should feel like the reader could have figured it
  out too (the genre's deepest combat pleasure: the reader
  solving the puzzle alongside the character)

The technique requires careful authorial restraint. The
writer who knows the solution must show the protagonist
working toward it without telegraphing; the protagonist who
sees the answer too quickly leaves the reader behind, and
the protagonist who sees it too slowly frustrates. Calibration
is per-fight: not every fight needs to be a tactical puzzle
(some can be quick clears showing competence; some can be
desperate survival with no clean solution), but the major
encounters — the ones the reader will remember — must
operate as solvable puzzles the reader engaged with.

### Dungeon Design & Exploration

Dungeons are LitRPG's signature set pieces. Each one must be a distinct narrative experience, not a reskinned corridor:

**Every Dungeon Needs Its Own Identity:**
- **A theme** that affects everything. environment, monsters, puzzles, loot. A fire dungeon doesn't just have fire enemies; the heat warps metal equipment, potions evaporate, ice-based skills gain a hidden bonus.
- **A unique mechanic**. something THIS dungeon does that no other dungeon does. Gravity shifts between rooms. Sound becomes solid and blockable. Emotions become visible auras that attract specific monsters. Time loops in certain chambers.
- **Environmental storytelling**. the dungeon tells a story through what the party finds. Ancient carvings, abandoned adventurer camps, ecological patterns between monster species, architecture that suggests the dungeon's original purpose.
- **A puzzle that requires the PARTY**. not just the MC's build, but different party members contributing different abilities. The tank holds a pressure plate while the mage deciphers runes and the rogue disarms traps simultaneously.
- **A boss that's a puzzle, not a DPS check**. defeating it requires figuring something out, not just hitting harder. The boss's weakness is environmental, or it can only be damaged during a specific phase, or its mechanics punish the MC's usual strategy.

**Dungeon Pacing:**
- Exploration and discovery scenes take at least as much page time as combat. The reader should feel the dungeon as a PLACE, not a combat queue.
- Resource attrition drives tension. potions dwindling, mana depleting, fatigue accumulating. The decision to push deeper or retreat is one of LitRPG's most compelling moments.
- Rest moments inside the dungeon. sharing rations, making camp, tending wounds, banter about the last encounter. These scenes deepen party dynamics under pressure.
- Loot is meaningful and specific. not just gold, but items that connect to the MC's build, the world's lore, or create interesting tactical dilemmas (the sword is stronger but cursed; the armour is weaker but grants a utility skill).
- Backtracking and farming should feel different each time. new spawns, environmental changes, the MC's growing competence making familiar challenges trivial (which itself is satisfying progression).

**Dungeon Progression Across the Manuscript:**
- Early dungeons: tutorial spaces where mechanics are learned through exploration
- Mid-game dungeons: multi-floor challenges requiring preparation, resource management, and party coordination
- Late-game dungeons: raid-level content where every room tests the MC's build decisions and party synergies
- Each dungeon should teach the MC (and reader) something about the system that becomes relevant later

### Crafting Systems & Scene Architecture

Crafting is a progression system in its own right. A crafting scene needs the same narrative structure as a dungeon encounter:

**The Crafting Mini-Arc (required for every crafting scene):**
1. **Goal**. a specific item to create, not "she spent the afternoon crafting"
2. **Obstacle**. missing ingredient, unfamiliar technique, equipment limitation, time pressure, competing crafter
3. **Process**. the reader follows the steps, understands the logic, feels the concentration required
4. **Stakes**. wasted rare materials, an explosion that damages the workshop, a client waiting, a deadline
5. **Result**. success (earned through prior failure) or instructive failure that teaches something specific

**Crafting as Character Development:**
- A crafter's progression fantasy is becoming a master of their craft. this arc is as compelling as any combat progression
- Recipe discovery through experimentation, not just quest rewards. the crafter who combines two unlikely ingredients and discovers a new formula
- Material gathering as adventure. the rare herb grows in a dangerous location, the ore requires mining in a monster-infested cave, the ingredient is only available during a specific in-game event
- Crafting failures have real consequences: wasted materials the MC spent chapters gathering, damaged equipment, reputation loss with clients
- Crafted items should feel different from looted gear. personalised, tailored to specific needs, carrying the story of their creation

**Crafting and Combat Integration:**
- Items crafted in downtime should prove crucial in the next dungeon
- Field crafting under pressure (improvising a potion mid-fight, repairing armour between dungeon floors)
- The crafter's understanding of how items work gives them unique tactical insight ("That boss's armour has the same crystalline structure as the material I work with. it's brittle at the joints")

### Loot & Gear Progression

Loot is LitRPG's reward currency. Every drop should create a moment:

**Rarity Tiers and Narrative Weight:**
- Common/uncommon drops: mentioned briefly, used for crafting materials or sold
- Rare drops: a scene. the MC examines it, considers how it fits their build, the party discusses who needs it most
- Epic/legendary drops: a chapter event. the item has history, unique properties, and changes the MC's tactical options fundamentally

**The Loot Dilemma (use frequently):**
- Sidegrade vs. upgrade: the new sword hits harder but the old one has a utility skill the MC relies on
- Party allocation: two members need the same drop. this is a relationship scene disguised as a loot scene
- Cursed or unknown items: the stats look incredible but there's a hidden penalty, or the item's true nature only reveals after equipping
- Sell vs. keep: the item is worth enough gold to solve a pressing problem, but its combat value might be irreplaceable

**Gear Progression Pacing:**
- Early game: frequent upgrades, each one noticeable. the MC's first real weapon should feel momentous
- Mid game: upgrades rarer but more impactful. each piece starts defining the build identity
- Late game: gear becomes legendary, with names and histories. the MC is known for their equipment
- Signature items should be introduced early and upgraded/evolved throughout the story, not replaced

### Economy & Resource Management

The LitRPG economy creates its own tension and progression:

**Financial Tracking Rules:**
- If a rare ingredient costs 50 gold in Chapter 4, it costs 50 gold in Chapter 10 (unless market events change prices on-page)
- The MC's financial situation tracks logically. broke until money is earned on-page, wealthy only through shown income
- Quest rewards, shop income, loot sales, and expenses should make rough sense
- Currency has weight. the MC should feel the difference between having 10 gold and 10,000 gold in what they can do

**Resource Management as Tension:**
- Potion supply running low before a boss fight
- Not enough gold to buy the equipment needed for the next dungeon
- Crafting materials that require a dangerous gathering expedition
- Repair costs accumulating after repeated dungeon runs
- The choice between investing in gear now vs. saving for a bigger upgrade later

**Economic Progression:**
- Early game: scraping by, every coin matters, repairing vs. replacing is a real dilemma
- Mid game: comfortable but not wealthy, able to invest in specific upgrades
- Late game: wealth creates new problems. guild taxes, property maintenance, attracting thieves/rivals, the responsibility of funding a party

### The Failure Requirement

Every significant skill improvement must be preceded by at least one on-page failure:

**What Good Failure Looks Like:**
- The MC attempts something specific with a clear goal
- They fail for a reason the reader can understand (wrong approach, insufficient stats, bad timing, unknown mechanic)
- There's a real consequence. wasted resources, injury, embarrassment, a setback in the quest
- They learn something specific from the failure
- Later success feels like a direct result of what they learned

**What Bad Failure Looks Like:**
- "He practiced for days but nothing worked" (telling, not showing)
- A failure immediately overcome in the next scene (no breathing room)
- A failure played purely for comedy with no real stakes
- The MC fails at something unrelated to their actual growth path

**The Golden Rule of Progression:**
The reader should be able to close the book and explain HOW the MC got strong. Not "they grinded". they should name specific scenes: "Remember when the fire spell backfired because he overcharged it? That's why he knew to throttle the mana flow against the ice boss." Growth that can't be traced to specific on-page moments isn't earned.

### PvP & Competition

Player-vs-player combat and competitive systems create unique tension:

**Arena & Tournament Structure:**
- Bracket systems provide natural escalation. each round harder, stakes higher
- The audience creates pressure. reputation, ranking, and public perception at stake
- Rivals who have studied the MC's build and prepared counters force adaptation
- Tournament arcs compress the progression loop beautifully: fight → analyse → adapt → fight again

**Skill-Based vs. Stat-Based Competition:**
- Pure stat advantages feel unfair (useful for underdog narratives)
- Skill expression that overcomes stat gaps is deeply satisfying to readers
- The MC who wins through clever build synergy rather than raw power fulfils the reader fantasy

**Rivalry as Character Development:**
- Named rivals with their own builds, philosophies, and motivations
- Grudge matches that carry chapters of history
- Respect earned through competition. the rival who becomes an ally after a well-fought loss
- The MC's build identity sharpened by how it contrasts with their rival's approach

**Guild Wars & Large-Scale PvP:**
- Tactical command decisions alongside personal combat
- The MC's role in larger strategic context. are they the spearhead, the support, the wildcard?
- Logistics and preparation as story content. assembling the raid, assigning roles, the strategy meeting before the assault
- Betrayal and espionage within competitive faction dynamics

### Progression Pacing Calibration

**Growth Rate Guidelines (30-chapter novel):**

| Phase | Chapters | MC Skill Level | Reader Experience |
|---|---|---|---|
| Novice | 1–6 | System new, fumbling with basics | Learning rules alongside MC, frequent small gains, many failures |
| Developing | 7–14 | Getting competent, still inconsistent | Good days and bad days, build identity forming, meaningful choices appearing |
| Competent | 15–22 | Solid practitioner, can handle standard content | Reliable skills, creative applications, respected by peers, harder content unlocked |
| Advanced | 23–28 | Genuinely impressive, pushing system boundaries | Novel solutions, unique synergies, earned reputation, high-stakes content |
| Mastery Moment | 29–30 | Peak for this book (not absolute mastery) | A definitive demonstration of how far they've come. the build pays off |

**Pacing Rules:**
- Level-ups space out as the story progresses. frequent early, rare late, each one more impactful
- The MC should struggle with challenges appropriate to their current level. if they breezed through the last dungeon, the next one challenges them DIFFERENTLY (not just harder numbers. new mechanics, environments that neutralise their best skill, party members who need to carry different weight)
- Time skips for grinding are acceptable ("Two weeks of farming the wolf den") but must be followed by a scene showing the specific new capability
- Plateau moments before breakthroughs create anticipation. the reader should feel the wall before the MC breaks through it

### System Notification Frequency Calibration

Stat screens and system messages must be rationed for maximum impact:

**Frequency Limits:**
- Novella (~16 chapters): 3–5 stat screen appearances maximum
- Novel (~30 chapters): 6–10 stat screen appearances maximum
- System notifications (quest updates, warnings, achievements): more frequent but always attached to tension or decision

**When to Show a Stat Screen:**
- After a major milestone (class evolution, significant level threshold, new skill tree unlocked)
- When the MC must make a build decision and the reader needs to see the options
- During inventory management before a critical dungeon (preparation creates anticipation)
- When a dramatic contrast is needed (comparing current stats to Chapter 1 baseline)

**When NOT to Show a Stat Screen:**
- After routine level-ups. summarise in narration instead
- During combat flow. stat text breaks action pacing
- When the information doesn't affect an immediate decision
- Back-to-back screens in consecutive chapters

**The Rule:** When a system notification appears, it should punctuate a moment the reader already witnessed. The MC just DID something impressive, and the system confirmation lands like an exclamation point. not a substitute for the scene.

### The Power Creep Calibration

LitRPG's commercial life is heavily series-driven — multi-
volume progressions of 7–15+ books are common — and the
form's deepest structural challenge is sustaining stakes
across long progression arcs. The genre's defining failure
mode is power creep: by book five or seven or ten, the
protagonist has become so powerful that prior threats are
trivial, prior locations are unmemorable, prior abilities are
obsolete, and the reader's accumulated investment in the
character's growth has nowhere to land because nothing in the
book's world can credibly threaten or even meaningfully
engage the protagonist anymore.

The technique is calibration across multiple axes
simultaneously:

- **Threat scaling.** As the protagonist grows, the world
  must grow proportionally — but not by simple stat
  inflation. The level-100 boss who matters in book ten
  cannot just be a level-50 boss with double the numbers;
  it must operate by different rules, exploit weaknesses
  the protagonist hasn't developed defences for, or pose
  threats that mechanical power cannot solve. The strongest
  long-running litrpg series introduce new categories of
  threat at major thresholds: physical at first, then
  magical, then political, then existential, then
  metaphysical.
- **Stakes recalibration.** Early-book stakes (survive the
  dungeon, save the village, escape the slavers) become
  trivially solvable as the protagonist grows. The series
  must escalate the kind of stakes, not just the magnitude:
  from personal survival, to small-group safety, to
  factional conflict, to political/regional war, to
  cosmological intervention, to questions of identity and
  meaning that mechanical power cannot resolve. The
  protagonist who can solve any problem with sufficient
  damage output has stopped being a protagonist in any
  meaningful sense.
- **Relative position.** The protagonist's growth must be
  felt against a world that grows around them. The mentor
  figure who was overpowering in book one is a peer in book
  five and a junior partner in book ten. The named
  antagonists from the early books either die, ascend
  alongside the protagonist, or are lost in the rearview
  mirror — and each treatment carries different emotional
  weight. The long-running series that handles relative
  position well makes each book's antagonists scale with
  the protagonist's current standing.
- **Power as character architecture.** Mechanical power
  must reflect and shape the protagonist's identity. The
  protagonist who started as a struggling beginner and now
  commands armies should think differently, feel
  differently, relate to others differently. Power that is
  purely mechanical — number going up — is the failure
  mode; power that has remade the protagonist into a
  different person whose decisions in book ten could not
  have been made in book one is the technique.
- **Power's costs.** Every escalation should carry costs
  that scale with it. The protagonist at maximum power is
  also at maximum visibility, maximum accountability,
  maximum loneliness (peers are scarce), and maximum
  responsibility. The strongest series treat power as
  bearing weight, not merely as bestowing freedom.

The genre's leading practitioners handle power creep
distinctly. Will Wight's *Cradle* series (12 books)
recalibrates threats across "iron, jade, gold, lord, herald,
sage, monarch" tiers, with each tier operating on different
rules and the protagonist's relative position constantly
shifting. He Who Fights With Monsters by Shirtaloon (10+
books) externalises the power-creep problem into the
narrative itself, with the protagonist's growth registering
as alarming to other characters. Sanderson's broader Cosmere
work (cousin to litrpg in progression-fantasy register)
deploys magic-system sub-tier-shifts to keep stakes
recalibrating. The pattern across these is that power is
never just "more"; it is structurally different, and the
narrative's emotional weight scales with the structural
shift.

Test the calibration: read three threat encounters from
spaced points in the series (book one chapter twenty, book
five chapter twenty, book ten chapter twenty). Are they
operating on the same mechanical logic, or has the logic
itself shifted across the series? If the encounters differ
only in numbers, power creep has not been managed. If they
operate by genuinely different rules and require genuinely
different responses, the calibration is operating.

### LitRPG AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "a notification appeared: [stat increase]" | Show the character's emotional/physical reaction to the change |
| "he leveled up again" | Show the specific new capability and how it feels |
| "the system was more complex than he'd imagined" | Show the specific rule he discovers |
| "grinding through the dungeon" | Show the specific encounter and what makes THIS one different |
| "his stats were impressive" | Show one stat in action through physical performance |
| "a rare drop" | Show the specific item and why it matters for THIS character's build |
| "the boss battle awaited" | Show the specific preparation and specific fear |
| "health points critical" | Show the specific wound and specific pain |
| "a quest appeared" | Show the specific objective and why the character cares |
| "the game world felt real" | Show the specific sensory detail that blurs the line |
| "min-maxing his build" | Show the specific trade-off decision |
| "respawn mechanics" | Show the specific fear or relief of death/return |
| "the system acknowledged my growth" | Show growth through what the character can now DO |
| "I could feel my skills improving" | Show the improvement through a specific action that previously failed |
| "power surged through my veins" | What does it actually feel like? Warmth? Static? An itch behind the eyes? |
| "the dungeon stretched out before him" | Show ONE specific feature of THIS dungeon that distinguishes it |
| "his party watched in awe" | Show the specific reaction of a named party member with their specific words or expression |
| "the loot was incredible" | Show the specific item, its specific properties, and why this character at this build cares |

## Genre-Specific Revision Rules

Eight revision passes specific to litrpg, each with a single
question, run cover-to-cover before the next begins. LitRPG
revision must hold an unusually wide set of disciplines: game-
mechanics consistency (the system reader's territory),
progression satisfaction (the genre's commercial engine),
combat clarity (where the form's tactical pleasure
concentrates), emotional texture (where character work lives
through grinding sequences that other genres would not
tolerate), number hygiene (the form's signature visual
discipline), dungeon and exploration quality (the genre's
signature locations), crafting and economy authenticity
(where the form's economic-simulation pleasure lives), and
failure-and-progression pacing (the deepest curve question).
The eight passes below are ordered to surface mechanical-
consistency failures first (the genre veteran's territory),
narrative-craft failures next (where the form risks slipping
into mechanical recitation), and the structural pacing audit
last when the rest of the book is sound.

### Pass 1: System Integrity Audit

Verify the system mechanics operate consistently across the
manuscript. Build a system-mechanics ledger: every named
stat, skill, ability, item, currency, status effect,
cooldown, resource cost, system rule, and edge case appearing
anywhere in the manuscript, with the chapter and page where
each first appears. Read the manuscript against the ledger.
Verify all stats referenced are consistent with the
character's current level and gear (the protagonist whose
strength stat was 47 in chapter ten cannot suddenly be 52 in
chapter eleven without an on-page level-up or equipment
change). Check that no skills are used that haven't been
acquired (the fireball cast in chapter fifteen must trace to
the moment the protagonist learned fireball, in scene). Confirm
system rules applied consistently across all chapters: if
"healing potions take three seconds to activate" was the rule
in chapter two, the rule holds in chapter twenty unless an
on-page mechanic change occurred. Verify inventory tracking:
items don't appear from nowhere, items don't disappear without
use or trade, the protagonist's inventory at chapter end
should be reconstructable from chapter beginning plus the
events of the chapter. The litrpg reader's tolerance for
system inconsistency is nil; this pass is the form's most
heavily policed.

### Pass 2: Progression Satisfaction Audit

Map every level-up, skill acquisition, attribute increase,
and class evolution across the manuscript. Are they spaced
for maximum impact, or are they clustered in ways that
overload some chapters and starve others? The form's reader
expects regular progression rewards — typically every 2–4
chapters in the early game, with major thresholds at the
classic structural points (mid-book pivot, three-quarters
mark, climactic arrival). Check that each progression moment
has emotional weight, not just number change — the four-part
Meaningful Level-Up structure (Context / Choice / Capability
/ Consequence) operating in each. Verify builds pay off:
early choices remain relevant in later chapters (the build-
payoff architecture operating across the book). Confirm
escalation: stakes rise with power. The protagonist who can
defeat the early-game boss at chapter ten must face a
chapter-twenty threat that genuinely engages their chapter-
twenty capabilities; if the protagonist reaches the climax
with abilities the climax does not require, the progression
has outpaced the threat curve.

Test the satisfaction: pick three progression moments spaced
across the book and ask, in each, whether the moment landed
emotionally as well as mechanically. If the level-up was
just a number, the genre's signature pleasure has been
forfeited.

### Pass 3: Combat Clarity Audit

Read each fight scene for spatial and mechanical clarity.
Can the reader track positioning — who is where, what is
between them, what the terrain enables or restricts? Check
tactical logic: abilities are used for valid reasons that
trace to the encounter's specific challenges; the
protagonist who casts fireball into a confined space the
group is also in has done something the prose must register
as a mistake. Verify damage and healing are consistent with
established stats — the combat numbers must follow the
ledger. Confirm at least one mid-fight adaptation per major
encounter: the initial strategy must fail in some way,
forcing revised approach with the available toolkit. The
fight that goes exactly as planned is the failure mode; the
fight in which the protagonist genuinely had to think is the
form's signature pleasure.

Verify combat scenes do not become opaque to the reader
through complexity. The genre's failure mode at scale is the
combat scene that has too many simultaneously active
abilities, status effects, party members, and enemy moves
for the reader to track; the strongest combat scenes in
litrpg are mechanically dense but readable, with clear
focalisation on what the protagonist is doing and tracking
of the most important enemy actions. Test: re-read each
major combat scene asking whether the reader could
diagram what happened. If not, the choreography needs work.

### Pass 4: Emotional Texture Audit

LitRPG's reader-tolerance for grinding (training sequences,
repetitive dungeon runs, skill-development montages) is
higher than other genres permit, but tolerance is not
unlimited. Check that grinding sections have emotional
variety. The training sequence that runs flat on character
work for ten thousand words is the form's distinctive
failure mode, and the genre's strongest practitioners use
grinding chapters specifically for character development —
the conversations between training partners, the protagonist's
shifting relationship to their own discipline, the small
realisations that level-ups by themselves do not deliver.
Verify party dynamics advance through shared combat: the
team that emerges from a difficult dungeon should be
different from the team that entered, with specific shifts
the prose has tracked. Confirm the protagonist's emotional
growth parallels their power growth: the protagonist who is
mechanically a god by book three but emotionally identical to
chapter one is the genre's "power without humanity" trap.
Check for that trap specifically — the protagonist who is
just a stat block in a costume is not yet a character.

The pass should also check that grinding chapters
contribute to the larger narrative arc. A series of dungeon
runs that all do the same emotional work is repetition;
runs that each shift something specific (a relationship, a
fear addressed, a strategic option opened) are accumulation.

### Pass 5: Number Hygiene Audit

Remove any stat dumps that serve no tactical or emotional
purpose. The form's signature visual discipline — the system
notification, the inventory display, the character sheet —
is most powerful when used sparingly and at moments of
genuine decision or revelation. Verify system notifications
earn their space in the narrative: each one should be doing
the dramatic work the System Notification as Dramatic Beat
technique above describes. Notifications that simply confirm
what just happened, repeat already-known information, or
show numerical changes that the reader does not need to
track are noise.

Check for consistency in all referenced numbers across the
manuscript. A stat referenced in chapter five must match
the stat referenced in chapter twelve, accounting for level-
ups in between. Confirm cooldowns and resource costs are
tracked: the protagonist who uses a 30-second-cooldown
ability in scene one cannot use it again two scenes later
unless the timing accounts. Verify resource depletion (mana,
stamina, potion stocks, ammunition where applicable)
operates consistently — the protagonist who entered the
dungeon with 8 healing potions and used 5 has 3 remaining,
not 6. The genre's reader will catch arithmetic errors that
non-genre readers wouldn't notice.

### Pass 6: Dungeon and Exploration Quality Audit

Each dungeon in the manuscript should have a distinct
identity — a specific theme, a unique mechanic that
differentiates it from prior dungeons, environmental
storytelling that gives the location history and meaning,
and a memorable signature that the reader can name after
finishing the book. Generic dungeons (corridor / room /
boss / loot) are the failure mode; specific dungeons (the
flooded tomb where the water level rises with every
encounter; the time-locked sanctum where each room operates
in a different decade; the library whose books physically
attack readers who quote them aloud) are the technique.

Check exploration gets at least as much page time as combat
within dungeon chapters. The form's reader includes
explorers — gamers whose primary pleasure is map-discovery
and environment-decoding — and dungeon chapters that skip
exploration to deliver more combat lose this audience.
Verify boss encounters are puzzle-fights, not pure DPS
checks. The DPS-check boss (the boss whose only solution is
to do enough damage before the boss does enough damage
back) is the form's most-flagged combat failure. Verify
resource attrition (potions, mana, fatigue, ammunition) is
tracked through dungeon runs — the dungeon that the
protagonist enters at full resources and exits at full
resources has not used the resource clock the genre
provides. Verify rest moments inside dungeons are used for
party dynamics — the camp scene between the second and
third floors is where character work concentrates in
exploration-heavy litrpg.

### Pass 7: Crafting and Economy Authenticity Audit

Every crafting scene in the manuscript should operate as a
mini-arc: a goal (what the protagonist is trying to make), an
obstacle (what stands between them and success), a process
(the steps the work takes, with specifics), stakes (what
the success or failure costs), and a result (what the
manuscript does with the outcome). Crafting that operates as
a list of materials and a confirmation of completion is the
failure mode; crafting that operates as a scene with
tension is the technique. Verify crafting failures are
shown on-page before major crafting successes — the reader
who has only seen the protagonist succeed at crafting cannot
register success as achievement. The genre's strongest
practitioners (Krout, Bagwell, Will Wight on the broader
progression-fantasy register) write crafting failures with
specific, character-developing stakes (the wasted rare
material; the sword that came out warped; the potion that
exploded in the workshop and set back the project by a
week).

Currency and resource tracking should be consistent across
the book — no items or coin appearing from nowhere, no
expenses not deducted from the running total. Prices should
be consistent throughout the manuscript unless market events
(famine, war, dungeon collapse, royal decree) are shown
explicitly affecting them. Crafted items should prove useful
in subsequent chapters (Chekhov's Potion: the item crafted
on-page in chapter six should fire in chapter twenty, in
ways the reader will recognise as planted). The crafting
that produces items the protagonist never uses again is
filler; the crafting that produces tools the protagonist
needs at climax is architecture.

### Pass 8: Failure and Progression Pacing Audit

Map the protagonist's skill level chapter by chapter — no
sudden jumps without earned progression. The protagonist who
is competent at chapter ten and master at chapter fifteen
must have done specific work in chapters eleven through
fourteen that the prose has shown; the unmotivated growth
spike is the genre's most-flagged pacing failure. Every
significant skill improvement should be preceded by on-page
failure — the failure is what makes the improvement
believable and emotionally consequential. The protagonist
who succeeds at every challenge has not been through the
genre's signature pressure-cooker; the protagonist whose
failures are shown specifically and whose subsequent
successes carry the weight of the failure is operating
within the form.

Verify growth rate follows a recognisable calibration table
— novice → developing → competent → advanced → mastery —
with each tier earning its arrival. System notification
frequency stays within calibration limits (6–10 stat-screen
appearances for a novel, 3–5 for a novella; substantive
notifications at chapter rate of approximately one major per
chapter). The reader should be able to trace HOW the
protagonist got strong through specific scenes — to point
at the chapter where the protagonist learned this skill,
the chapter where they failed at this challenge before
succeeding, the chapter where the build choice was made
that paid off here. If the protagonist's strength at chapter
thirty cannot be traced through specific intermediate
scenes, the progression has been gestural and the genre's
deepest pleasure — earned growth visible across hundreds of
pages — has not been delivered.

## Names & Patterns to Avoid

### Forbidden LitRPG Patterns
- Pages of stat screens with no context or stakes
- "Congratulations! You have levelled up!" without emotional texture
- The MC who is secretly the Chosen One with a unique class (unless earned through story)
- Power fantasy without consequence. everything works, nothing costs
- Grinding montages that read like shopping lists
- System messages in comic sans or excessive formatting that breaks immersion
- Skills named with twelve words and excessive capitalisation

### Cliché Setups to Avoid
- MC gains a "unique" or "legendary" class in chapter 1 without earning it
- Harem party that exists solely to admire the MC
- The wise mentor who explains every system rule through dialogue
- Monsters that exist solely as XP bags with no personality or threat
- VR game with zero consequences that suddenly has real consequences
- The guild that's evil for no reason other than to oppose the MC

### Names to Avoid
- Generic game names (Shadowblade, DarkKnight, xXx_Slayer_xXx) for serious characters
- Unpronounceable skill names
- System names that don't fit the world's aesthetic

## Comp Titles

LitRPG's comp-title set supports manuscript positioning:
market category placement, cover-design conversation,
reader-expectation calibration, similar-author discovery,
and editorial / agent submission framing.

### Canonical (foundational reference points)

- *Sword Art Online* — Reki Kawahara (2009-, light novel): the genre-defining game-as-trap LitRPG template.
- *Ready Player One* — Ernest Cline (2011): mainstream-LitRPG-adjacent benchmark.
- *Ender's Game* — Orson Scott Card (1985): proto-LitRPG with simulation-as-reality.

### Contemporary (current best-in-class)

- *Dungeon Crawler Carl* — Matt Dinniman (2020): contemporary LitRPG with dungeon-survival frame; viral commercial success.
- *He Who Fights with Monsters* — Shirtaloon (Travis Deverell) (2019-): web-novel-to-print LitRPG epic series.
- *The Wandering Inn* — pirateaba (2017-, web): web-serialised LitRPG benchmark.
- *Mother of Learning* — nobody103 (2011-2020, web): time-loop LitRPG progression-fantasy.
- *Cradle* — Will Wight (2016-2023): cultivation-progression-fantasy LitRPG-adjacent.
- *Beware of Chicken* — Casualfarmer (2021-): cozy LitRPG cultivation crossover.
- *The Land* — Aleron Kong (2015-): the Chaos Seeds series; LitRPG market category benchmark.

## Cover Design Specifications

### Visual Tone
- Dynamic, action-oriented imagery
- Game UI elements integrated tastefully (health bars, skill icons, stat windows)
- Vibrant colour palette suggesting game worlds
- Epic scale mixed with intimate character focus

### Key Visual Elements
- Protagonist with visible gear/weapons suggesting their build
- System UI overlay elements (subtle, not overwhelming)
- Dungeon/world environment establishing setting
- Sense of progression or power (auras, effects, scale)

### Typography
- Bold, impactful fonts for title. slightly game-influenced without being cartoonish
- Series number prominent (LitRPG readers are series-focused)
- Author name visible but secondary
- Subgenre indicators helpful (Progression Fantasy, GameLit, etc.)

### Colour Palette
- Primary: Rich purples, electric blues, golden accents (XP/loot colours)
- Accent: Glowing effects, particle systems, magical auras
- Avoid: Dull, muted palettes. LitRPG covers should feel energetic
- High contrast for readability at thumbnail size (crucial for web serial format)

### Comp Titles (Cover Style Reference)
- *Defiance of the Fall* by TheFirstDefier. dynamic action, system elements, epic scale
- *Dungeon Crawler Carl* by Matt Dinniman. bold, character-focused, humorous tone
- *Cradle* by Will Wight. clean, atmospheric, progression suggested through imagery
- *He Who Fights with Monsters* by Shirtaloon. character + world + system aesthetic
