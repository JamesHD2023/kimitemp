---
name: literary-fiction-genre
description: Genre-specific instructions for literary fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [general]
---

# Literary Fiction. Genre Plugin

## Metadata
- id: literary
- name: Literary Fiction
- icon: 🪶
- category: Fiction
- minWords: 2500
- targetWords: "2,500-5,000"
- recommendedBeatStructures: ["Three-Act Structure", "Five-Act Structure", "Fichtean Curve"]

## Subgenre Options
Present during setup:
- **Realist Literary**. The tradition of close observation: human behaviour rendered with precision and compassion; Chekhov, Munro, Trevor territory
- **Experimental/Innovative**. Structural play, fragmented narrative, unreliable narration, non-linear time; the form IS the content
- **Autobiographical/Autofiction**. The territory between memoir and fiction: a narrator who resembles the author navigating recognisable reality with fictional license
- **Quiet Literary**. Interior, meditative, small-canvas: the drama of consciousness, perception, and the examined life
- **Socially Engaged**. Literature that grapples with the world: race, class, gender, politics, justice. rendered through story, not polemic
- **Maximalist**. Big, ambitious, sprawling: multiple timelines, large casts, encyclopaedic scope; the novel as attempt to capture everything

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-5,000 words (literary fiction allows longer chapters for depth)
- Pacing: Internal rhythm. pacing follows the story's emotional logic, not commercial convention; scenes expand and compress based on significance, not action
- Must open with: A VOICE. the first paragraph establishes a consciousness the reader wants to inhabit; the quality of the prose is the hook

BEATS PER CHAPTER
1. Consciousness Beat. The reader is inside a specific mind: perceiving, processing, connecting, remembering
2. Observation Beat. The world is rendered with precision: a detail noticed, a moment captured, reality made vivid
3. Relational Beat. A relationship is tested, illuminated, or complicated; human connection is the genre's subject
4. Tension Beat. Something resists: internal conflict, interpersonal friction, the gap between desire and reality
5. Resonance Beat. An image, phrase, or moment connects to the larger pattern; the theme vibrates

LITERARY FICTION ARCHITECTURE
- PROSE IS PRIMARY: the quality of sentence-by-sentence writing is not decorative, it IS the experience
- INTERIORITY is the medium: literary fiction lives inside consciousness. perception, memory, reflection, association
- AMBIGUITY is a value: literary fiction resists easy answers; characters, situations, and endings are complex, not resolved
- THE SENTENCE is the unit of construction: each sentence should reward attention
- THEME is EMBEDDED, not stated: the meaning of the work emerges from pattern, image, and event. never from authorial commentary
- STRUCTURE serves meaning: the shape of the narrative (chronological, fragmented, circular, episodic) reflects its content
- POV: Any. literary fiction exploits the full range; the choice of POV is a thematic decision

CONSCIOUSNESS AND PERCEPTION
- The protagonist's mind is the territory the reader explores
- Memory, association, and perception blend: past and present coexist in consciousness
- Physical sensation triggers thought; thought triggers memory; memory triggers emotion
- The inner life is rendered with the same precision as the outer world
- Stream of consciousness is a technique, not a mandate: use it when it serves the moment

THE OBSERVED WORLD
- Literary fiction earns its reputation through OBSERVATION: seeing what's there with fresh eyes
- The ordinary is made extraordinary through attention: a peeled orange, a child's shoe, a window's light
- Physical details carry emotional weight without being forced into symbolism
- The world is SPECIFIC: not a generic town but THIS town, THIS street, THIS sky at THIS time of day

FORBIDDEN IN LITERARY FICTION
- Telling the reader what to think or feel (the work should CREATE feeling, not instruct it)
- Plot mechanics that override character truth (events should emerge from character, not be imposed on them)
- Sentimentality: emotion without earned complexity
- Cleverness for its own sake: stylistic pyrotechnics that don't serve the story
- Simplistic moral conclusions: good/bad, right/wrong. literary fiction lives in the grey
- Characters as thesis statements (people, not positions)
- Prose that calls attention to the author rather than the experience
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection and Revelation (primary engines), Captivation through interiority.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the literary cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  literary cues below apply directly.VOICE & TONE
- POV: Whatever serves the story's deepest purpose; the choice IS meaning
- Voice: Distinctive, textured, alive. every literary novel creates its own voice; there is no default
- Tone: Complex. literary fiction can hold contradictory tones (comic and tragic, tender and ironic) simultaneously
- Register: Varies. but the CONTROL of register is essential; the prose should feel intentional at every point

PROSE IMPERATIVES
- THE SENTENCE AS ART: every sentence should have rhythm, precision, and purpose
  - Vary sentence length deliberately: a long, complex sentence can be followed by a short one for impact
  - Sound matters: read the prose aloud; literary fiction is closer to music than to information
  - Economy: every word earns its place; if a word can be cut without loss, cut it
  - Surprise: the reader should encounter at least one sentence per page that they didn't expect
- METAPHOR AND IMAGE: literary fiction thinks in images
  - Metaphors should be ORIGINAL: if you've heard it before, don't use it
  - Extended metaphors can structure whole sections: a comparison that deepens as the prose develops
  - Image patterns: recurring images that accumulate meaning across the manuscript (water, light, doors, hands)
  - The image should feel DISCOVERED, not invented: as if the writer found the perfect comparison, not manufactured it
- INTERIORITY: rendering consciousness on the page
  - Thought is not always articulate: fragments, images, sensory flashes
  - Memory intrudes: past tense within present action, triggered by association
  - Perception is filtered: the character's psychology shapes WHAT they notice and HOW they describe it
  - The gap between what a character thinks and what's true IS the drama
- PRECISION OVER BEAUTY: literary prose should be accurate, not pretty
  - The right word is more important than the beautiful word
  - Clarity is not simplicity: clear prose can describe complex states
  - Overwriting is a greater sin than underwriting in literary fiction

PROSE RHYTHM MAPPING
- Ch 1 hook: Voice IS the hook. the reader falls in love with SENTENCES, not plot
- Sentence length: Varied and deliberate. every length is a choice
  - Short sentences for emotional weight
  - Long sentences for immersive observation
  - Average: 15-25 words with deliberate variation
- Metaphor density: 1 per 200-300 words (highest of any genre)
- Interiority: Deep and specific. 80-100 words per beat
  - This genre lives inside characters; consciousness is the medium
- Dialogue: Sparse but every line carries subtext
- Tension: ≥4 for Ch 1 (literary tension is character-driven, not plot-driven)
- Paragraph rhythm: Varied
  - Some single-sentence paragraphs for impact
  - Some 6-8 sentence paragraphs for immersion
  - The variation itself is expressive. rhythm mirrors content

DESCRIPTION CRAFT
- Literary fiction describes the world as filtered through consciousness:
  WRONG: "The beach was beautiful. The waves crashed on the shore and the sunset painted the sky orange."
  RIGHT: "The beach had the emptied-out quality of a place that had been full of people an hour ago: plastic wrappers snagged in the dune grass, the sand still holding the shapes of bodies. The light was going. She watched the water and thought of nothing, which was harder than it sounded."
- The description should tell us as much about the observer as the observed
- Avoid beautiful descriptions that any character would produce; the description must be THIS character's

DIALOGUE CRAFT
- Literary dialogue should sound like ACTUAL human speech: hesitant, indirect, repetitive, surprising
- People talk past each other: they answer questions that weren't asked and avoid the ones that were
- The important thing is usually NOT said directly
- Silence and non-verbal communication are dialogue: a shrug, a look away, a hand withdrawn
- Dialogue is a PERFORMANCE: characters construct themselves through speech, and the reader should sense the construction
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

PROSE CRAFT (40% of total):
- Sentence-level writing rewards attention (rhythm, precision, surprise)? (0-100)
- Metaphor and image are original and resonant? (0-100)
- The voice is distinctive and sustained? (0-100)
- Prose is precise rather than merely beautiful? (0-100)

DEPTH (30% of total):
- Interiority is rich and specific (consciousness rendered)? (0-100)
- Ambiguity is present (resists easy interpretation)? (0-100)
- Theme emerges from pattern, not statement? (0-100)
- Characters are complex (contradictory, surprising, human)? (0-100)

STORY CRAFT (30% of total):
- Events emerge from character (not imposed by plot)? (0-100)
- Relationships are rendered with precision and complexity? (0-100)
- Structure serves the story's meaning? (0-100)
- The ending is earned (surprising yet inevitable)? (0-100)

AUTOMATIC FAILS (score = 0):
- Telling the reader what to feel or think
- Cliché metaphors or descriptions
- Characters as thesis statements (positions, not people)
- Sentimentality (unearned emotion)
- Plot mechanics overriding character truth
- Prose that prioritises showing off over serving the story
```

## Continuity Rules

```
LITERARY FICTION CONTINUITY. WHAT TO TRACK

CONSCIOUSNESS STATE:
- The protagonist's psychological arc: what they believe, perceive, and understand at each point
- Memory triggers: what sensory details have been established as triggering specific memories
- Emotional evolution: the subtle shifts in how the character relates to their situation
- Perception changes: what the character notices and how they describe it should evolve

IMAGE PATTERNS:
- Recurring images and their evolving meaning (water, light, doors, seasons, hands, etc.)
- When each image was introduced and how its significance has shifted
- Connections between images: when two patterns intersect, the reader should feel the resonance
- Image density: are patterns appearing too frequently (heavy-handed) or too rarely (lost)?

RELATIONSHIP STATE:
- The exact state of every significant relationship: nuance matters
- What has been said and not said between characters
- Physical distance and proximity: who is close to whom, literally and figuratively
- Power dynamics: who depends on whom, who is owed what, who is afraid of whom

THEMATIC STATE:
- Which thematic threads have been activated in which chapters
- How the theme has been complicated or deepened (not just repeated)
- Counter-themes: arguments against the main theme that give it texture
- Resolution level: which thematic questions have been answered and which remain open

TEMPORAL STATE:
- If non-linear: which events have been shown and which are still to come
- Memory vs. present: the relationship between past and present events
- Duration: how time is expanded (significant moments) or compressed (transitions)
- Time markers: seasonal, cultural, personal (birthdays, anniversaries)
```

## Character Rules

```
LITERARY FICTION CHARACTER CONSTRUCTION

THE PROTAGONIST:
- A consciousness worth inhabiting: not necessarily likeable, but INTERESTING. perceptive, complicated, alive
- Their interiority IS the novel: the way they think, perceive, remember, and interpret
- They are not fully self-aware: the reader should understand them better than they understand themselves
- Their flaws are not plot devices but PERSONALITY: they are who they are, and it costs them
- Change is subtle: literary protagonists don't have epiphanies that solve everything; they shift by degrees
- They surprise: the reader should discover things about them gradually, as in a real relationship

SUPPORTING CHARACTERS:
- Each is a FULL PERSON: they have their own inner life, their own concerns, their own blindspots
- They challenge the protagonist's worldview simply by existing differently
- They are described with the same precision as the protagonist (in fewer words)
- Their dialogue reveals them: speech patterns, assumptions, obsessions, evasions

RELATIONSHIPS:
- Literary fiction's primary subject: how people relate to each other
- Relationships are dynamic: they change from scene to scene, sometimes within a scene
- The UNSAID is as important as the said: what characters won't discuss defines them
- Power, desire, fear, love, resentment. the full emotional spectrum, often simultaneously
- No relationship is simple: parent-child, lovers, friends. each is a complex negotiation

VOICE CRAFT:
- The protagonist's inner voice is MORE complex than their spoken voice
- Thought is non-linear: associations, corrections, contradictions, tangents
- Each character's spoken voice is unique: diction, rhythm, what they notice, what they avoid
- Characters perform themselves: they are aware (partly) that they're constructing an identity through speech
```

## Arc Rules

```
LITERARY FICTION STORY STRUCTURE

NOTE: Literary fiction's structure is the MOST flexible of any genre. The following is a framework, not a formula.

THE OPENING:
- Establish the voice and consciousness that will carry the novel
- Create the world through perception: the reader enters the character's way of seeing
- The situation: what is the character's life, and what is its tension?
- The question: what is unresolved, unexplored, or threatening to surface?

THE DEVELOPMENT:
- The situation deepens: complications, revelations, and pressures
- The character's inner and outer worlds interact: events trigger reflection; reflection shapes action
- Relationships evolve: through conflict, intimacy, distance, and surprise
- The theme develops: through pattern, repetition-with-variation, and image
- The pace follows emotional logic: significant moments expand; transitions compress

THE CRISIS:
- The central tension reaches its peak: the avoided conversation happens, the truth surfaces, the situation becomes unsustainable
- The character must confront what they've been avoiding: about themselves, their relationships, or their world
- This confrontation may be quiet: a dinner scene, a walk, a letter. literary climaxes don't require explosions

THE RESOLUTION:
- Ambiguous or open-ended: literary fiction often ends with a question, not an answer
- The change is internal: the character sees differently, understands differently, or chooses differently
- Something is gained and something is lost: the resolution is bittersweet, complex, or deliberately unresolved
- The final image or sentence should RESONATE: carrying the novel's meaning in a single moment

ALTERNATIVE STRUCTURES:
- Episodic: linked stories or episodes that accumulate meaning
- Circular: ending where it began, but the meaning has changed
- Fragmented: non-linear pieces that the reader assembles
- Dual timeline: past and present in dialogue
- Seasonal: structured around the year's progression
- Single day: Woolf/Joyce tradition, the world contained in hours
```

## Timeline Rules

```
LITERARY FICTION TIMELINE

TIME AS TECHNIQUE:
- Literary fiction treats time as malleable: expand significant moments, compress insignificant ones
- A single afternoon can take three chapters; a year can pass in a paragraph
- The CHOICE of what to expand and compress IS the authorial argument about what matters

MEMORY AND TIME:
- Past and present coexist in consciousness: memory is not flashback but a LAYER of the present
- Track memory triggers: specific sensory details that open the past
- The relationship between past and present events IS the theme

NON-LINEAR TIME:
- If the structure is non-linear, every temporal leap must be clear to the reader
- The REASON for the non-linearity should be meaningful (not just stylistic)
- Track what the reader knows at each point vs. what the characters know

DURATION:
- Literary fiction spans any length: an afternoon to a century
- The duration should match the story's scope: an intimate story doesn't need decades; a generational saga does
- Track aging, seasonal change, and historical context across the timeline
```

## Genre-Specific Craft Techniques

Literary fiction is the foundational register of prose-driven
fiction and the parent of an extensive cluster (upmarket,
contemporary, drama, family saga, autofiction, literary
historical, literary speculative, quiet fiction at one edge,
metafiction at the other). Its readers — from the canonical
mid-century lineage (Woolf, Bellow, Updike, Morrison, Munro,
Roth, Didion, McEwan, Marilynne Robinson, Penelope
Fitzgerald) through the contemporary expansion (George
Saunders, Colson Whitehead, Jhumpa Lahiri, Zadie Smith, Ali
Smith, Kazuo Ishiguro, Rachel Cusk, Sigrid Nunez, Jenny
Offill, Ocean Vuong, Tessa Hadley, Tom Crewe, Hernan Diaz,
Anne Enright, Sally Rooney, Garth Greenwell, Lorrie Moore,
Yiyun Li, Brandon Taylor, Bryan Washington, Lauren Groff,
Hanya Yanagihara, Mohsin Hamid, Yaa Gyasi, Akwaeke Emezi,
Tomasz Jędrowski, Patricia Lockwood) — bring sophisticated
expectations: prose that operates at the level of the line;
character interiority rendered with specificity rather than
asserted; structural ambition (the form of the novel doing
work alongside its content); and the form's specific market
positioning (literary readers select for prose voice, theme,
and emotional intelligence in ways genre readers may not).
The techniques below are how the form delivers its core
pleasures while avoiding the failure modes (decorative prose
that sounds beautiful but says nothing; sentimentality
substituting for earned emotion; thematic statement
substituting for thematic dramatisation; "literary" as
performance of literariness rather than as register choice).

### The Resonant Image

Literary fiction builds meaning through recurring images that
accrete significance across the novel. The technique converts
a particular detail — a peeled orange, a green light at the
end of a dock, a watch, a bird, a recipe, a folded letter —
into a structural element whose significance the reader feels
accumulating across chapters even before the writer makes the
connection explicit.

```
Chapter 1: "She peeled the orange in one long spiral,
the way her mother had taught her."
(Introduced: the orange, the mother, the teaching)

Chapter 7: "The kitchen smelled of oranges. She
hadn't bought any."
(The image returns: now associated with absence and haunting)

Chapter 15: "She taught her daughter to peel an orange.
One long spiral. She didn't mention her mother. She
didn't have to."
(The image completes: inheritance, silence, love persisting)
```

Three mentions. Three chapters apart. An entire family
history in an orange. The technique requires that the image
be specific enough to be memorable but ordinary enough to
recur naturally; over-marked images (the eagle that appears
ten times, the colour symbolism the writer is leaning on)
become heavy-handed, while under-marked images (the detail
mentioned once and never returned to) are decoration. The
strongest literary practitioners run multiple resonant
images simultaneously across a novel, layered so that the
careful reader feels the patterns reinforcing each other
without the writer pointing at them.

Test: identify the resonant images in the manuscript. For
each, does the image return at least three times across the
novel, in contexts that progressively change the reader's
understanding of what it means? If an image appears once,
it's a detail; if it appears five times in unchanging
significance, it's wallpaper; the resonance lives in the
accumulation.

### The Precision Principle

Choose the exact word, not the beautiful word. Literary
fiction's prose-level discipline is the inverse of how it is
sometimes parodied: the strongest literary writers prefer the
specific to the lyrical, the precise to the metaphorically
elaborate, the noticed to the asserted. Decorative prose —
prose that sounds beautiful but does not describe anything
specific — is the genre's most-flagged sentence-level failure.

```
BEAUTIFUL BUT IMPRECISE:
"Her heart was a cathedral of sorrow."

PRECISE AND TRUE:
"She felt the sadness the way you feel a draft. constant,
low-level, noticed only when she tried to be warm."

The second is less "poetic" and infinitely better.
It describes an actual feeling. The first describes
a feeling no one has ever actually had.
```

The principle extends to every register. Description should
be specific to this scene rather than generically literary.
Emotional rendering should use language that names the
specific shape of the feeling rather than reaching for the
nearest dramatic vocabulary. Dialogue should sound like
this character at this moment rather than like literary-
fiction characters in the abstract. Test: read the manuscript
out loud and listen for sentences that sound impressive
without saying anything specific. Where the eye sees
"beautiful prose", the ear hears decoration. Strip the
decoration; the precise sentence underneath is the literary
fiction's actual register.

### The Subtext Engine

Literary dialogue says one thing and means another. The form's
deepest dialogue craft: the words on the page are the surface;
the meaning lives in what was not said, what was redirected,
what was almost said before being changed, the punctuation
itself.

```
"How's your mother?" he asked.
"She's fine. She sends her love."
"Does she."
"She does."

Five words of dialogue. A decade of family history.
The period after "Does she" instead of a question mark
tells you everything about the relationship.
```

The technique requires that the writer trust the reader.
Subtextual dialogue does not work if the prose immediately
explains what was meant; the trust between writer and reader
is what allows the silence between the lines to contain the
meaning. Where the writer cannot resist explaining ("he
meant: I know your mother no longer asks about me"), the
subtext has been collapsed into surface text. Cut the
explanation; the dialogue is doing its work without it.

Test: pick three significant dialogue exchanges and ask, in
each, what is being said beneath the surface words. If the
prose around the exchange has explained the subtext, cut the
explanation. If the exchange has no subtext, the dialogue is
information-delivery rather than literary dialogue, and the
form's signature pleasure has not been deployed.

### The Structural Ambition

Literary fiction permits — and is often deepened by —
structural choices that genre fiction does not make. The
fragmented timeline (Cusk's *Outline*, Cusk's *Aftermath*);
the multi-perspective novel that reveals through
juxtaposition (Whitehead's *The Underground Railroad*,
Mandel's *Station Eleven*, Diaz's *Trust*); the second-person
or first-person-plural voice (Egan's *A Visit from the Goon
Squad*'s "Out of Body" chapter; Lockwood's *No One Is
Talking About This*); the unreliable narrator whose
unreliability is the novel's deepest argument (Ishiguro's
*The Remains of the Day*; Yanagihara's *A Little Life*);
the constraint-driven novel (Saunders's *Lincoln in the
Bardo* with its 166 narrators); the epistolary or
documentary novel.

The technique is not deploying structural complexity for its
own sake but recognising when the novel's content benefits
from formal investigation. The strongest literary novels
match form to subject: a novel about memory and erosion may
deploy fragmented timeline because the subject IS fragmented
memory; a novel about collective grief may deploy multi-
voice because grief is inherited by communities, not just
individuals; a novel about self-deception may use unreliable
narration because self-deception cannot be rendered
straightforwardly.

The discipline is that the structural choice must be earned
by what it makes possible. Structural ambition deployed for
its own sake — fragmentation that serves no thematic purpose;
multiple POVs that don't reveal anything additional;
unreliability that is not load-bearing — is the genre's
most-flagged formal failure. Test: identify the manuscript's
structural choices and ask, in each, what the choice makes
possible that a more conventional structure would not. If
the answer is "nothing specific", the structural ambition
is decorative rather than load-bearing.

### The Theme as Question

Literary fiction's relationship to theme is distinctive: the
novel poses a question rather than delivers an answer. The
strongest literary novels sustain a thematic question across
their length without resolving it tidily — what does it cost
to belong? what survives when love does not? what does
ordinary life mean? what is the relationship between memory
and self? — and the reader leaves the book carrying the
question with them, not feeling it has been settled.

The technique requires that theme not be stated. The novel
about regret should not contain the sentence "regret is the
foundational emotion of human experience"; the theme must be
present through specific dramatised material that
accumulates into thematic weight without being named. The
most-flagged failure mode is the theme-stating paragraph —
the moment the prose pauses to articulate what the novel is
about, often in the protagonist's interior voice or in
narrator commentary at a chapter end.

The technique also requires complication. Literary novels
that pose a question and answer it tidily within the same
book have not engaged with the question's actual difficulty;
literary novels that pose a question and complicate it
across hundreds of pages without settling it have done the
form's deepest work. Test: write a one-sentence statement of
the manuscript's central thematic question. Does the novel
visibly complicate that question across its chapters, or
does it argue toward a fixed answer? Both can succeed —
some great literary novels argue specific positions — but
the choice must be deliberate and the writer must know which
they are doing.

### The Earned Emotion

Literary fiction's emotional contract: every emotional moment
must be earned through specific rendered experience, not
imposed by authorial assertion. Sentimentality — emotion
shortcut without the work that would make the reader feel it
— is the form's most-flagged emotional failure. The reader
should arrive at the emotion themselves, recognising what is
happening, rather than being told what to feel.

The discipline operates at every emotional register. Grief
must be rendered through specific behavioural and sensory
detail (the half-empty wardrobe; the question that no one
will now answer; the meal made for two and eaten alone) not
through abstraction ("she felt overwhelming grief"). Joy
must be rendered through specific sensation (the breath
released after long held; the easy laugh that arrives
without warning) not through statement ("she had never been
so happy"). Anger, fear, longing, shame, recognition —
each must be rendered through the body, the gesture, the
specific thought, the precise observation, rather than
through emotional vocabulary that asks the reader to fill in
the experience.

Test: pick three emotionally significant moments in the
manuscript. For each, ask whether the emotion is rendered or
asserted. If the prose tells the reader what the character
is feeling, the emotion has been imposed. If the prose
shows specific detail and trusts the reader to recognise the
emotion, the technique is operating.

### Literary Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the weight of unspoken words hung between them" | Show the specific silence through action |
| "she searched for meaning in the mundane" | Show the specific mundane detail and what it triggers |
| "the passage of time had changed everything and nothing" | Show the specific change and specific constant |
| "memory is a treacherous thing" | Show the specific false or fragmentary memory |
| "the human condition" | Delete. Show ONE person's specific condition |
| "in the end, we are all" + philosophical generalisation | Delete the generalisation. End on concrete detail |
| "the quiet desperation of ordinary life" | Show the specific desperate moment in specific daily routine |
| "she realised that" + thematic statement | Show the realisation through action, not narration |
| "the landscape mirrored her inner turmoil" | Show the landscape. Show the turmoil. Let the reader connect them |
| "and perhaps that was enough" | End on the specific thing that is or isn't enough |
| "the silence spoke volumes" | Show what fills the silence — a clock, breathing, traffic |
| "some things are too complex for words" | Then show them through image, not this statement |
| "her thoughts drifted to" | Stop using this transition; render the thought directly |
| "she had always known that" + abstraction | Show the specific moment she came to know it |
| "in that moment, she understood" | Show what specifically clicked into place — the sentence she finally heard, the gesture she finally registered |
| "the room held its breath" | Cut personification of rooms; show what the people in the room were doing |
| "the fragility of life" | Show ONE specific fragile moment |
| "she felt seen for the first time" | Show what specifically the other person saw and what the protagonist did with the recognition |

## Genre-Specific Revision Rules

Six revision passes specific to literary fiction, each with a
single question, run cover-to-cover before the next begins.
Literary revision must hold the form's prose-level discipline
(every sentence purposeful), interiority specificity
(character consciousness rendered, not asserted), image
pattern coherence (recurring resonance accumulating across
chapters), thematic restraint (questions posed without being
answered tidily), earned emotion (no sentimentality), and
structural integrity (the form's choices serving the novel's
content). The passes below are ordered to surface sentence-
level failures first (the most-felt by literary readers),
character and image craft next, theme and emotion audits
after, and the structural / formal audit last when the rest
of the book is sound enough to hold the question of whether
the novel's architecture is doing its work.

### Pass 1: Sentence-Level Audit

Read five randomly-selected sentences from each chapter
aloud. Is each precise, rhythmic, and purposeful — or is the
sentence reaching for "literary" register without the
specificity that earns it? Flag every cliché metaphor,
generic emotional description, or decorative-prose moment
where the writer reached for sound over sense. Verify the
prose rewards re-reading: literary readers re-read sentences,
and the strongest literary prose rewards the second pass with
something the first pass missed (a syntactic structure that
mirrors the meaning; an image that connects to one earlier;
a precision of word choice the reader registers more deeply
on second reading).

Specific checks:
- **Cliché audit.** Build a list of the manuscript's metaphors
  and similes. Flag any that fall into well-worn categories
  (heart-as-X, eyes-as-Y, time-as-Z) and replace with
  specifics earned by the scene.
- **Adverb audit.** Adverbs in literary fiction are usually
  the writer's tell that the verb wasn't strong enough.
  "She walked angrily" should become "She walked"
  (with the action revealing the anger) or a different
  verb that carries the emotional charge.
- **Filter-word audit.** "She saw the leaves falling" filters
  the experience through the seer; "Leaves were falling"
  puts the reader in the scene directly. Strip filter words
  (saw, heard, felt, noticed, watched, realised) where the
  prose works without them.
- **Sentence-rhythm audit.** Read aloud and listen for
  passages where every sentence has the same length or shape.
  Vary deliberately; rhythm is meaning.

Test: does the prose reward re-reading? Pick three paragraphs
and read each twice. The second read should reveal something
the first didn't. If not, the prose may be working at surface
level only.

### Pass 2: Interiority Check

Verify the protagonist's inner life is present and specific
across the manuscript. Literary fiction's distinctive register
is the rendering of consciousness — and consciousness rendered
specifically is what distinguishes literary from genre
fiction's typically more action-oriented register. Check that
perception is filtered through this character's particular
consciousness: what they notice, what they overlook, what
they connect things to, what they remember when, what their
mind reaches for under specific pressures.

Verify thought is rendered as it actually works — non-linear,
associative, interrupted, distractable. Real thought is not
the orderly progression of conclusions the prose may default
to; real thought is the half-formed observation that gets
interrupted by the irrelevant memory that triggers the
unrelated regret that returns to the original observation
changed. The protagonist whose interior life consists of
chronological rational thought is not a literary character;
they are a character in a novel that hasn't done the
interior work the form requires.

Verify the interior is specific to this character. The strong
test: read three sample chapters and ask whether the
protagonist's interior could be transplanted into another
character without alteration. If yes, the interiority is
generic literary-character-thinking; if no, the interiority
is operating. The strongest literary novels make the
protagonist's interior so specifically theirs that the prose
register itself is recognisable as belonging to them — a
signature you would recognise in another scene without
attribution.

### Pass 3: Image Pattern Check

Track recurring images across the manuscript. Are they
present, and do they advance? Each significant image should
return at least three times in contexts that progressively
change the reader's understanding of what it means. Build an
image ledger: each recurring image, the chapter and page of
each appearance, the meaning the image carries at each
appearance.

Verify no image has become heavy-handed (too frequent, too
obvious, too marked). The genre's failure mode is the image
that the writer is leaning on so heavily the reader registers
it as a trick. The strongest literary novels run their image
patterns lightly — the careful reader notices the pattern;
the casual reader feels the pattern's effect without quite
naming it.

Check that the manuscript introduces or develops at least one
image thread per chapter. A chapter that contains no resonant
image is operating at narrative-only level, which literary
fiction permits but rarely sustains across an entire
manuscript. Verify also that images are not overcrowded — too
many distinct image patterns running simultaneously fragments
the reader's tracking. Three to five major image threads is
typical for a literary novel; more than that becomes
compositional fog.

Test: write down the manuscript's three most prominent
recurring images and trace each across all its appearances.
Does each image's significance evolve? If an image appears
five times in unchanging significance, it's wallpaper rather
than resonance. If an image appears once with significance
the prose flags but never returns to develop, it's a one-
note device.

### Pass 4: Theme Check

Verify the manuscript's theme is present without being
stated. Literary fiction's deepest contract is that theme
emerges from rendered material rather than from authorial
assertion. The strongest literary novels can be read by
readers who could not articulate the theme in one sentence
but who feel it operating across the prose; the readers who
can articulate the theme do so by reasoning from the
specific rendered material rather than by quoting a thematic
statement the writer placed.

Scan specifically for theme-stating moments — paragraphs
where the prose pauses to articulate what the novel is
about, often in protagonist interior monologue or in
narrator commentary. These usually arrive at chapter ends
or in moments of narrative quiet. Each is the writer
breaking trust with the reader; the reader was capable of
reaching the theme themselves and is being told what to
think. Cut the theme-stating; the prose typically works
better without it.

Verify the manuscript complicates or deepens the thematic
question across its chapters. If the theme is fully
articulable in chapter one and the rest of the book argues
toward the same answer, the novel has not engaged with the
question's difficulty. The form's strongest practice is to
sustain a question across the manuscript's length without
resolving it tidily — the reader leaves the book carrying
the question, not feeling it has been settled.

Test: write the manuscript's central thematic question in
one sentence. Read the novel against the sentence: does the
manuscript argue a fixed position, or does it complicate
the question across its length? Both are legitimate; the
writer must know which they are doing. If you can state the
theme in one sentence, ask whether the novel is doing more
than that sentence — adding nuance, complication,
counter-evidence, contradiction — or whether the novel is
the sentence elaborated. The latter is thinness.

### Pass 5: Earned Emotion Check

Verify every emotional moment is earned through specific,
rendered experience. Sentimentality — emotion shortcut
without the work that would make the reader feel it — is
the form's most-flagged emotional failure. The reader
should arrive at the emotion themselves, recognising what
is happening, rather than being told what to feel.

Audit the manuscript for the genre's specific sentimentality
patterns:
- **The grief shortcut** — protagonist feels grief; the
  prose tells us they feel grief; we read the word "grief"
  but never feel it because no specific behavioural or
  sensory detail rendered the experience.
- **The epiphany shortcut** — protagonist suddenly
  understands something the prose has not staged.
  Realisation should be triggered by specific dramatic
  material; the realisation that arrives by authorial fiat
  is unearned.
- **The redemption shortcut** — character changes because
  the writer needed them to change; the change has not been
  earned by the dramatic material.
- **The reconciliation shortcut** — relationships heal
  because the manuscript needs to end; the healing has not
  been worked for in scene.

Verify the emotional register is calibrated to the novel's
overall key. Literary fiction permits enormous emotional
range — from quiet (Robinson, Hadley, Cusk's restraint) to
intense (Yanagihara, Vuong, Greenwell's emotional density)
— but each manuscript should hold its register consistently.
A novel that operates quietly through 250 pages and reaches
for high-melodrama emotion at the climax has broken its
calibration; a novel that operates at maximum emotional
density throughout exhausts the reader.

Test: pick three emotionally significant moments and ask, in
each, whether the emotion is shown through specific
behaviour, sensation, or observation, or whether it is
asserted in emotional vocabulary. If asserted, the moment is
sentimental; if rendered, the moment is operating within the
form.

### Pass 6: Structural and Formal Audit

If the manuscript employs structural ambition — fragmented
timeline, multi-POV, non-linear chronology, second-person or
unusual narration, constraint-based structure, hybrid form
with documentary or epistolary elements — verify the choice
is doing work. Run the structural audit:

- **What does the chosen structure make possible that a more
  conventional structure would not?** The answer should be
  specific: the fragmented timeline allows the reader to
  experience memory's actual operation; the multi-POV allows
  the novel to render collective experience that no single
  consciousness could render; the second-person voice
  positions the reader inside the protagonist's specific
  alienation.
- **Does the structure earn its difficulty?** Structural
  ambition asks the reader to work harder; the work must be
  rewarded. A fragmented timeline that exists for its own
  sake without illuminating anything specific is decoration;
  a fragmented timeline that resolves the reader's confusion
  with cumulative meaning at the end is technique.
- **Is the structure consistent?** A novel that opens with
  formal ambition and abandons it midway has not committed;
  a novel that opens conventionally and shifts into formal
  ambition without preparation has not earned the shift.

Where the manuscript employs conventional structure, verify
the conventional structure is operating with literary
discipline — the chapters do specific work, the pacing
calibrates literary rather than genre rhythms (longer beats,
slower revelations, deeper interiority), the ending resolves
in the literary register (often ambiguous, often quieter
than genre fiction would permit, often returning to early
material with new significance).

Test: write a one-sentence description of the manuscript's
structural shape. Does the description identify a deliberate
formal choice, or does it describe something accidental? If
accidental, the structural ambition has not been deployed —
which may be correct for this manuscript, or may be a
missed opportunity. The choice must be deliberate either
way.

## Names & Patterns to Avoid

### Literary Fiction Character Names. NEVER USE
- Overtly symbolic names: Hope, Grace, Faith, Justice, Stone, Sorrow
- "Literary" names that signal intelligence: Atticus, Scout, Holden (too associated)
- Names chosen for aesthetic rather than character

### Literary Fiction. NEVER DO
- Open with weather (unless the weather IS the subject)
- End with a character gazing at the horizon
- Use "epiphany" as a plot device (the sudden realisation that changes everything. this is sentimentality disguised as profundity)
- Write a thinly veiled version of the author's life without the self-awareness to make it art

### Use Instead
- Names appropriate to the character's age, background, region, and culture
- Names that feel like names, not choices: the character was NAMED this by their parents, not selected by an author
- The name should disappear into the character: after two chapters, the reader shouldn't think about the name at all

## Comp Titles

Literary fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Beloved* — Toni Morrison (1987): post-slavery literary masterpiece.
- *The Remains of the Day* — Kazuo Ishiguro (1989): literary unreliable-narrator benchmark.
- *Disgrace* — J.M. Coetzee (1999): literary-novel post-apartheid benchmark.
- *Olive Kitteridge* — Elizabeth Strout (2008): literary-linked-stories form.
- *A Little Life* — Hanya Yanagihara (2015): contemporary literary epic.

### Contemporary (current best-in-class)

- *The Vanishing Half* — Brit Bennett (2020): literary fiction with passing-narrative architecture.
- *Hamnet* — Maggie O'Farrell (2020): literary historical fiction; Shakespeare-family register.
- *The Lincoln Highway* — Amor Towles (2021): literary American-roadtrip novel.
- *Tomorrow, and Tomorrow, and Tomorrow* — Gabrielle Zevin (2022): literary friendship novel.
- *Trust* — Hernan Diaz (2022): literary metafictional Pulitzer-winner.
- *Demon Copperhead* — Barbara Kingsolver (2022): contemporary Appalachian literary epic.
- *North Woods* — Daniel Mason (2023): multi-generation literary house-novel.
- *Open Throat* — Henry Hoke (2023): literary novella with mountain-lion narrator.

## Cover Design Specifications

### Recommended Visual Styles
- **Typographic**. Beautiful, confident typography as the primary design; minimal or no imagery; signals literary quality and awards-level ambition
- **Art-Forward**. Original artwork, often abstract or impressionistic; the cover is itself a work of art; signals sophistication and cultural aspiration
- **Photographic**. A single, striking photograph: evocative, ambiguous, carefully composed; the image suggests rather than depicts
- **Minimalist**. Maximum white space, one element, perfect typography; the cover whispers rather than shouts

### Genre Cover Aesthetics
- **Styles:** Restrained, intelligent design that signals literary quality; abstract or impressionistic imagery; single evocative photographs; bold typography with minimal imagery; art reproductions or original artwork; designs that could hang on a gallery wall
- **Colours:** Sophisticated palettes: muted earth tones, deep navy and cream, sage and charcoal, burnt orange and ivory; single bold colour against white; monochromatic with texture; nothing garish, nothing neon
- **Elements:** Typography as the dominant element, negative space used boldly, single symbolic objects, abstract textures, painterly effects, hand-lettered titles, small, perfect images in large fields of colour or white
- **Typography:** Refined serif fonts (literary tradition) or elegant sans-serif (contemporary literary); the font choice IS the design; author name and title in careful hierarchy; kerning and spacing are immaculate

### Market Positioning
Literary fiction covers signal "this is art" through restraint, sophistication, and design confidence. Position against Cusk, Offill, Saunders, Ferrante, Hamid, Yanagihara. The cover should look like it was designed, not illustrated. White space is confidence. Simple is harder (and more effective) than complex. At thumbnail size, a single strong typographic choice or one striking colour is more effective than detail.

### Cover Design DON'Ts
- No genre imagery (swords, hearts, blood, spaceships)
- No stock photography
- No busy, cluttered designs
- No fonts that signal genre fiction (script fonts, horror fonts, fantasy fonts)
- No literal scene depiction (the cover is a DESIGN, not an illustration)
- No dark, moody palettes unless the novel specifically demands it
