---
name: satire-genre
description: Genre-specific instructions for satirical fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [literary, comedy]
---

# Satire. Genre Plugin

## Metadata
- id: satire
- name: Satire
- icon: 🎪
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Fichtean Curve", "Story Circle"]

## Subgenre Options
Present during setup:
- **Social Satire**. Society's absurdities dissected: class, manners, institutions, the gap between what people say and what they do; Austen, Wolfe, Toole territory
- **Political Satire**. Power mocked: government, ideology, bureaucracy, the machinery of politics rendered absurd; Orwell, Heller, Vonnegut territory
- **Corporate/Workplace Satire**. The modern institution skewered: office culture, startup delusion, corporate speak, the comedy of professional life
- **Media Satire**. The information ecosystem dissected: journalism, social media, celebrity, the machinery that shapes public opinion
- **Academic Satire**. The university as comedy: tenure politics, intellectual pretension, the gap between the life of the mind and the pettiness of the department
- **Dark Satire/Black Comedy**. Satire that goes further: violence, death, taboo rendered comic; the laughter that catches in the throat; the comedy of the truly terrible

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: Brisk, escalating absurdity. each chapter should push the situation further toward its logical (and ridiculous) conclusion; satire accelerates toward catastrophe
- Must open with: Something that seems normal but contains the seed of absurdity; the reader should laugh on the second reading when they see what was already wrong

BEATS PER CHAPTER
1. Absurdity Beat. The world's logic (or illogic) is demonstrated: a rule, a convention, a behaviour that is accepted as normal but is clearly insane when examined
2. Escalation Beat. The absurdity deepens: the logical consequence of the flawed premise plays out; things get worse because the system works exactly as designed
3. Recognition Beat. The reader recognises their own world: the satire connects to something real; the laughter comes from "I know someone who does that"
4. Character Beat. Despite the satire, the characters are human: their desires, fears, and compromises are genuine even in an absurd world
5. Consequence Beat. The absurdity has a cost: someone suffers, something is lost, the joke has teeth

SATIRE ARCHITECTURE
- The TARGET must be specific: satire that aims at everything hits nothing; identify what you're satirising and commit
- The MECHANISM of absurdity must be internally logical: the satirical world has rules, and those rules, when followed to their conclusion, produce the comedy
- ESCALATION is the engine: each chapter pushes further; the absurdity compounds; what seemed extreme in chapter 1 is normal by chapter 10
- The COMEDY must have TEETH: if no one is uncomfortable, it's not satire; if it's only mean, it's not comedy; the balance is essential
- The REAL WORLD should be visible through the distortion: the reader should see their own institutions, leaders, neighbours, or selves in the satirical mirror
- CHARACTER survives the satire: even in the most absurd world, the protagonist must feel human; their desires and frustrations ground the comedy
- The SATIRIST'S POSITION should be invisible: the author doesn't lecture; the absurdity speaks for itself
- POV: First person (the bewildered participant) or third person (the observing eye, often with narrative irony)

THE ENGINE OF ESCALATION
- Start with a premise that's only slightly exaggerated from reality
- Follow the premise's logic: if X is true, then Y follows, then Z, then catastrophe
- Each escalation should feel both surprising AND inevitable
- The protagonist's attempts to be reasonable in an unreasonable world CREATE the escalation
- The system never recognises its own absurdity. that's the point

THE SATIRICAL TARGET
- Identify the SPECIFIC thing being satirised: not "society" but "the corporate wellness industry" or "the college admissions process" or "political media cycles"
- Research the target: satire only works when the satirist understands the subject deeply; you can't mock what you don't know
- Find the GAP: the difference between what the institution/person/system claims to be and what it actually is. that gap is the comedy
- The target should be POWERFUL enough to deserve satire: punching up, not down

FORBIDDEN IN SATIRE
- Punching down (mocking the powerless is cruelty, not satire)
- Losing the humanity of characters (satirical figures must still be recognisably human)
- Becoming what you satirise (if the writing is as pretentious as what it mocks, it's failed)
- Lecturing (the moment the author's moral position is stated directly, the satire dies)
- Cruelty without comedy (darkness without humour is just darkness)
- Comedy without teeth (amusement without critique is just entertainment)
- Static absurdity (the situation must escalate; if it stays the same, it's a sketch, not a novel)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (cleverness & wit), Revelation (criticism landed), Anticipation (escalation of absurdity).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person (the bemused participant trapped in the absurdity. Heller, Toole) or third person with narrative irony (the observant eye. Waugh, Austen)
- Voice: Intelligent, precise, deceptively controlled; the voice should sound reasonable even when describing the unreasonable; the comedy comes from the gap
- Tone: Controlled absurdity; the narrator reports the insane as if it were normal, or the normal as if it were insane. either way, the reader sees the truth
- Register: Varies by target. corporate satire uses corporate language; academic satire uses academic language; the satire speaks in its target's voice

PROSE IMPERATIVES
- THE DEADPAN: the most powerful satirical voice reports absurdity without comment
  - "The committee voted unanimously to table the discussion of whether meetings were productive, scheduling a follow-up meeting to discuss scheduling a meeting to address the issue."
  - The prose doesn't wink; it doesn't nudge; it trusts the reader to see what's wrong
  - The gap between the calm voice and the insane content IS the comedy
- PRECISION IS COMEDY: the more specific the detail, the funnier the satire
  - Generic: "The office was full of meaningless motivational posters." (Not funny.)
  - Specific: "Above the coffee machine, a poster showed a dolphin mid-leap with the caption 'SYNERGY: Because Alone We Are Just Fish.' It had been there so long the corners had yellowed and no one, including the person who ordered it, could remember what it was supposed to mean." (Funny.)
  - The detail does the work; the author stays invisible
- ESCALATION IN PROSE: the language itself should escalate with the absurdity
  - Early chapters: reasonable prose, minor oddities
  - Middle chapters: the language strains, the reasonable voice struggles to describe increasingly unreasonable events
  - Late chapters: the prose has either become complicit in the absurdity (normalising the insane) or is desperately trying to maintain sanity (and failing)
- THE TARGET'S LANGUAGE: satire speaks in the voice of what it mocks
  - Corporate satire uses corporate jargon. weaponised sincerely
  - Academic satire uses academic prose. inflated until it pops
  - Political satire uses political rhetoric. exposed through its own emptiness
  - The language of the target, used precisely, is the genre's sharpest tool

DIALOGUE CRAFT
- Characters speak in the language of their world. and that language reveals the absurdity
- The reasonable voice: one character (often the protagonist) who speaks normally; their normalcy highlights the surrounding madness
- The true believer: a character who has fully internalised the absurd logic; their sincerity is the comedy
- The speech: the set-piece satirical monologue where a character explains something insane with complete conviction
- Jargon as comedy: specialised language used to disguise or elevate what's actually being said
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. SATIRE

OPENING: The VOICE is the hook. sharp, precise, slightly elevated, unmistakably
intelligent. Something seems normal but contains the seed of absurdity. Irony
visible in sentence construction from line 1. The satirist's position is INVISIBLE:
no lecturing, no winking. The prose trusts the reader.

SENTENCES: Medium, 14-22 words. controlled, precise, deceptively reasonable.
Deadpan: calm prose describing absurd content (the gap IS the comedy). Longer
(24-35) for bureaucratic spirals: clauses compounding until absurdity is self-evident.
Short (4-10) for the devastating aside that punctures everything.

VOCABULARY: The target's language IS the weapon. corporate jargon for corporate
satire, academic prose for academic satire. Precision creates comedy: the SPECIFIC
detail, the named thing. Slightly elevated register for ironic distance. No comedic
vocabulary ("hilarity," "absurd," "ironic"). prose is straight; reader laughs.

TENSION FLOOR: ≥4. The slightly-wrong world: something off, no one else notices.
Protagonist's reasonableness vs. system's unreason creates friction. Specific target
visible from chapter 1. Stakes seeded: someone will suffer (comedy has teeth).

RHYTHM: Open with something almost normal. First oddity within 2-3 paragraphs.
deadpan, without comment. Target's language describes itself. A precise detail
delivers the first laugh. Close on escalation: absurdity one step further,
protagonist inside it. Reader feels amused AND uneasy.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

SATIRE CRAFT (40% of total):
- Target is specific and deserving (punching up, not down)? (0-100)
- Absurdity escalates logically (each chapter pushes further)? (0-100)
- The real world is visible through the distortion (recognition)? (0-100)
- Comedy has teeth (uncomfortable truths, not just amusement)? (0-100)

STORY CRAFT (30% of total):
- Characters are human despite the absurdity? (0-100)
- The plot follows the premise's logic to its conclusion? (0-100)
- Consequences are felt (the joke has cost)? (0-100)
- The satirist's position is invisible (show, don't lecture)? (0-100)

PROSE QUALITY (30% of total):
- The deadpan voice is sustained (no winking at the reader)? (0-100)
- Precision creates comedy (specific detail, not generic observation)? (0-100)
- The target's language is used as the weapon? (0-100)
- The prose escalates with the absurdity? (0-100)

AUTOMATIC FAILS (score = 0):
- Punching down (mocking the powerless)
- Lecturing (the author states their moral position directly)
- Characters without humanity (satirical figures must still be people)
- Static absurdity (no escalation, no consequence)
- Cruelty without comedy or comedy without critique
- Becoming what it satirises (the writing as pretentious as its target)
- Generic targets ("society is bad". be specific)
```

## Continuity Rules

```
SATIRE CONTINUITY. WHAT TO TRACK

THE ABSURDITY BASELINE:
- What is considered "normal" in this world at each point (it shifts as things escalate)
- Rules and conventions: what the satirical world accepts as logical (track for consistency)
- When the baseline shifted: each escalation creates a new normal
- The protagonist's awareness: do they see the absurdity? (Their awareness may diminish as they're absorbed)

ESCALATION STATE:
- How far the situation has escalated at each chapter
- Each new escalation: what triggered it, what it changed, what new normal it created
- The logical chain: A caused B caused C. the escalation must be traceable
- The stakes: what's being risked or lost at each level (escalation without stakes is just silliness)

CHARACTER STATE:
- The protagonist's sanity: how are they coping with the absurdity?
- Allies and adversaries: who sees the absurdity and who's a true believer?
- The true believers: how deeply they've internalised the system's logic
- Physical and emotional toll: the absurdity should have real effects

INSTITUTIONAL STATE:
- The institution or system being satirised: its rules, hierarchy, language, and self-image
- How the institution responds to crisis (usually by doubling down on what caused the crisis)
- The institution's public face vs. its reality (the gap widens)
- Power dynamics: who benefits from the absurdity and who suffers

THE REAL-WORLD MIRROR:
- What real-world phenomenon each satirical element corresponds to
- Whether the satire has stayed consistent (or shifted targets mid-story)
- The specificity of the target at each point
```

## Character Rules

```
SATIRE CHARACTER TYPES

THE BEWILDERED PROTAGONIST:
- A reasonable person in an unreasonable world: their normalcy IS the comedy
- They try to use logic in a system that runs on absurdity. and logic keeps failing
- They may slowly be absorbed into the absurdity (the most terrifying satirical arc)
- OR they remain stubbornly sane, which makes them the system's enemy
- Their desires are genuine: they want something real (love, dignity, freedom) in a world that makes the real impossible

THE TRUE BELIEVER:
- Someone who has fully internalised the absurd system: they don't see what's wrong; they see what's "right"
- Sincere, enthusiastic, often kind. their sincerity is what makes them funny and frightening
- They speak the system's language fluently and without irony
- The comedy: they're doing exactly what they've been told, and it's producing exactly the wrong result
- They may be the most dangerous character: true believers enforce the system with genuine conviction

THE CYNIC:
- Someone who sees the absurdity clearly but profits from it. or is too tired to fight it
- They offer the protagonist insights and then do nothing: understanding without action
- Their resignation is both funny and devastating
- They represent what the protagonist might become if they stop caring

THE BUREAUCRAT:
- The system incarnate: they follow rules not because the rules make sense but because they're rules
- Process is more important than outcome; procedure outranks reality
- They're not evil. they're procedural; the horror is in their reasonableness
- They represent the genre's core insight: systems don't need villains to produce victims

THE IDEALIST:
- Someone who believes the system can be reformed: they write reports, file complaints, organise committees
- Their optimism is either inspiring or delusional (often both)
- They provide the emotional stakes: if even the idealist can't fix this, the system is truly broken

VOICE DIFFERENTIATION:
- Protagonist: plain, direct, increasingly bewildered
- True believer: the system's jargon spoken with absolute sincerity
- Cynic: wry, knowing, the joke they've heard before
- Bureaucrat: procedural, passive voice, the language of forms and regulations
- Idealist: earnest, hopeful, using the system's language to argue against the system
```

## Arc Rules

```
SATIRE STORY STRUCTURE

ACT 1: THE SLIGHTLY WRONG WORLD (first 25%)
- The world as it appears: only slightly exaggerated, almost normal. the reader might not realise it's satire yet
- The protagonist enters the system: a new job, a new community, a new situation; they notice small oddities
- The first absurdity: something is clearly wrong, but everyone else treats it as normal
- The protagonist's first attempt to address the problem through reasonable means: it fails in an absurd way
- END OF ACT 1: The protagonist realises the system is fundamentally flawed. but they're now inside it

ACT 2A: THE ESCALATION (to midpoint)
- Each chapter introduces a new level of absurdity, each following logically from the last
- The protagonist's attempts to be reasonable make things worse (the system punishes sanity)
- Allies reveal themselves: other people who see the absurdity (but may be unable or unwilling to act)
- The institution responds to problems by creating more of what caused the problems
- MIDPOINT: A catastrophic escalation. the logical conclusion of the system's absurdity produces a crisis; the protagonist is now deeply entangled

ACT 2B: THE ABSORPTION (midpoint to dark moment)
- The protagonist begins to speak the system's language (horror or comedy. often both)
- The absurdity has become normal: what was shocking in chapter 1 is routine by chapter 15
- The human cost becomes visible: someone suffers because of the system (the teeth in the satire)
- The protagonist faces a choice: join the system or fight it (both options are absurd)
- DARK MOMENT: The system has won. the protagonist has either been absorbed or defeated; the reasonable voice is silenced

ACT 3: THE RECKONING (final 25%)
- The protagonist makes their final stand: against the system, or as a warning to the reader
- The system reaches its ultimate absurd conclusion: the logical endpoint of its flawed premise
- The comedy and the tragedy merge: the funniest moment should also be the most devastating
- The resolution: the system may survive (satire is often pessimistic); the protagonist may escape, be crushed, or achieve a small, pyrrhic victory
- The mirror: the reader looks up from the page and sees their own world slightly differently

SATIRE PACING:
- Starts slow (almost normal), accelerates relentlessly
- Each chapter should be slightly more absurd than the last (the escalation curve)
- Comic set-pieces punctuate the escalation (the scene that makes the reader laugh and think simultaneously)
- The climax is both hilarious and devastating
- The ending is often quiet: after the absurdity peaks, a moment of stillness that lets the truth land
```

## Timeline Rules

```
SATIRE TIMELINE

ESCALATION CLOCK:
- Track how much time has passed since the protagonist entered the system
- The pace of absurdity: slow at first, accelerating as the system's logic compounds
- Deadlines create comedy: bureaucratic deadlines, institutional timelines, the clock running out on reason

INSTITUTIONAL TIMELINE:
- The institution's calendar: meetings, reviews, reports, reorganisations
- How the institution responds to crisis over time (usually slowly, badly, and in the wrong direction)
- The cycle: problem → meeting → report → reorganisation → new problem (caused by the reorganisation)

CHARACTER TIMELINE:
- The protagonist's absorption rate: how quickly they normalise the absurdity
- When allies were found and when they were lost (to the system, to exhaustion, to co-option)
- Physical and emotional toll over time: the absurdity wears people down
```

## Genre-Specific Craft Techniques

Satire is the comedic register that uses humour as a tool of
critical analysis rather than as the primary pleasure of the
form. Sitting adjacent to comedy (where laughter is the
contract) and literary fiction (which can absorb satirical
elements without committing to satire's primary register),
satire is its own form: a sustained committed engagement
with a specific target — institution, system, ideology,
class, profession, social pattern — through a register that
makes the target visible by exaggerating, miming, or
reporting it with deliberately misplaced sincerity. The
cluster includes political satire, social satire,
institutional satire (corporate, academic, governmental),
literary satire (the form's literary tradition: Swift,
Austen at her sharpest, Dickens, Twain), absurdist satire,
and the broader speculative-satire range. Comp authors span
the canonical lineage (Jonathan Swift's *Modest Proposal*
and *Gulliver's Travels*, Voltaire's *Candide*, Mark Twain's
*Connecticut Yankee*, Evelyn Waugh's *Vile Bodies* and
*Decline and Fall*, Joseph Heller's *Catch-22*, Kurt
Vonnegut's *Slaughterhouse-Five* and *Cat's Cradle*, Don
DeLillo's *White Noise*, Christopher Buckley's political
satire, P.G. Wodehouse on the gentler edge) through the
contemporary expansion (Tom Perrotta's *Election* and *Mrs
Fletcher*, Jonathan Coe's English political satire, Jonathan
Franzen at his sharpest, Jonathan Lethem, Sam Lipsyte's
*The Ask*, Paul Beatty's *The Sellout*, George Saunders's
short-fiction satire and *Lincoln in the Bardo*'s satirical
elements, Lauren Groff at the literary edge, Yiyun Li, Ling
Ma's *Severance*, Patricia Lockwood's *No One Is Talking
About This*, Ottessa Moshfegh's *My Year of Rest and
Relaxation*, Mohsin Hamid's *How to Get Filthy Rich in Rising
Asia*, Helen DeWitt's *Lightning Rods*, Gary Shteyngart, Joshua
Cohen, Halle Butler, Vauhini Vara, Mateo Askaripour's *Black
Buck*, Caleb Azumah Nelson, Patrick deWitt, Jenny Offill).
The techniques below are how the form delivers its
critical-comic register while avoiding the failure modes
(hectoring polemic that abandons the comic register;
target-too-broad satire ("everything is bad") that fails to
land; punching-down satire that becomes the cruelty it
should be exposing; deadpan that slips into authorial wink
or sincere-narrator commentary).

### The Deadpan Report

The most absurd event described as if it's perfectly normal:

```
"The quarterly review determined that the
department's primary obstacle to efficiency was
the existence of the department itself. A task
force was assembled to study the findings. The
task force requested additional funding, which
was approved, bringing the department's budget
to three times what it had been before the
efficiency review recommended its dissolution.

No one involved saw a contradiction. The
minutes of the meeting were filed correctly."

The narrator doesn't comment. The reader does.
```

### The Reasonable Request

The protagonist asks for something simple, and the system makes it impossible:

```
"'I'd like to change my desk lamp,' I said.

The form required three signatures, a risk
assessment, a carbon footprint estimate, and
a letter from my line manager explaining why
the current lamp was inadequate. The lamp
replacement committee met on alternate Tuesdays.
My line manager was on sabbatical until March.
The risk assessment required a qualified
assessor, and the last qualified assessor had
been made redundant in the efficiency review
that had also, it turned out, eliminated the
committee that approved lamp replacements.

I worked in the dark. It was easier."
```

### The Sincere Speech

A true believer explains the absurd system with genuine conviction:

```
"'You don't understand,' Henderson said, and
his eyes were bright with something that
looked terrifyingly like love. 'The system
WORKS. Look at the numbers. We've increased
our output of reports about increasing output
by four hundred percent. That's FOUR HUNDRED
PERCENT. Are you going to stand there and tell
me four hundred percent isn't impressive?'

I opened my mouth to point out that none of the
reports had resulted in any actual change.

Henderson was already printing graphs."

The true believer's sincerity is the scariest
thing in satire.
```

### Satire AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the irony was not lost on them" | Let the irony speak for itself through the scene |
| "a biting commentary on society" | Show the specific social absurdity through action |
| "the absurdity of modern life" | Show the specific absurd situation |
| "a thinly veiled critique" | Make the fictional scenario vivid; the reader makes the connection |
| "the hypocrisy was staggering" | Show the specific hypocritical action |
| "a world gone mad" | Show the specific madness through one institution |
| "satire writes itself" | Delete. Write the satire. |
| "the emperor had no clothes" | Show the specific nakedness through one person noticing |
| "a cautionary tale" | Show the specific consequence |
| "the system was beyond parody" | Show the specific system failure that reads as comedy |
| "the elites were out of touch" | Cut "elites"; show the specific person doing the specific out-of-touch thing |
| "society had become a circus" | Cut the metaphor; show ONE specific circus moment in the specific place |
| "common sense was uncommon" | Show what specifically the common-sense response would have been and why it didn't happen |
| "the rich got richer" | Show the specific transaction that produced the specific increase |
| "no one in charge knew what they were doing" | Show the specific decision made by the specific person who specifically didn't know |
| "the masses were fed lies" | Show ONE specific lie being delivered to ONE specific person and that person's specific reception |
| "the kingdom was rotting from within" | Cut "rotting"; show ONE specific institutional dysfunction in scene |

### The Specificity-as-Weapon

Satire fails when generic. The form's most-flagged failure
mode is satire that targets categories — "corporations are
greedy", "politicians are corrupt", "academia is broken" —
without rendering specific instances of the pattern. The
strongest satire targets specific behaviours, specific
language, specific institutional logic, with the
specificity itself becoming the satirical weapon: the
exact phrase the target actually uses; the specific
procedural step that the target actually takes; the
specific euphemism that the target deploys to make the
indefensible defensible.

The technique requires research. The corporate satire that
captures specific corporate-language ("circling back",
"action items", "right-sizing", "transitioning out") with
deadpan accuracy lands harder than the corporate satire
that gestures at corporate-speak generically. The political
satire that uses the specific phrasing of specific political
moments (without naming the figures directly) lands harder
than the political satire that gestures at "political
hypocrisy". The strongest satire's specificity makes the
target identify themselves: anyone who has worked in the
target system recognises the specific behaviour being
rendered.

The technique extends to language. Satirists are unusually
attentive to their target's specific vocabulary. Bureaucratic
satire requires knowing the specific bureaucratic register;
academic satire requires the specific academic register;
political satire requires the specific political-class
register. Generic mocking-the-target language is the failure
mode; the target's own language deployed with deadpan
accuracy is the technique.

Test: pick three significant satirical moments and ask, in
each, whether the target is specific (this exact behaviour /
this exact phrase / this exact procedural step) or generic
(corporations / politicians / academia / etc. as categories).
If generic, the specificity weapon has not been deployed.

### The Punching Calibration

Satire's ethical surface is the question of who pays for
the laugh. The form's contemporary mainstream consensus is
that satire works best when punching up — toward power,
pretension, hypocrisy, the institutionally-protected — and
ages badly when punching down — toward the marginal, the
already-mocked, the institutionally-vulnerable. The
strongest satirists are deliberate about this calibration;
the form's most-flagged failure mode is satire that
mistakes who is powerful and who is vulnerable in the
specific situation it depicts.

The calibration operates on multiple axes:

- **Direction** — is the satire targeting the powerful
  (executives, politicians, institutions, established
  professionals, inherited wealth) or the powerless
  (workers, the marginalised, the institutionally-
  excluded)? Punching up ages well; punching down ages
  badly even when the laughs land at publication.
- **Specificity** — is the target specific (named or
  identifiable behaviours of identifiable institutions)
  or categorical (whole groups of people whose specifics
  the satire has flattened)? Specific targets read as
  observation; categorical targets read as bigotry, even
  when the writer's intent was the opposite.
- **The protagonist's complicity** — the strongest satire
  often includes the protagonist's own complicity in the
  target system. The narrator who is mocking corporate
  culture while sending corporate emails; the
  protagonist who is mocking academic pretension while
  pursuing tenure; the satirist who is mocking media-
  culture from inside media-culture. The form's strongest
  voices acknowledge their own position rather than
  claiming external moral high ground.

The technique requires deliberation. Satire that mocks the
secretary while protecting the executive has
miscalibrated; satire that mocks the working-class while
treating the executive class with sympathy has done the
opposite of its intended work. The form's strongest
practitioners (Saunders, Beatty, Vonnegut at his best,
contemporary practitioners listed above) hold their
calibration consciously across hundreds of pages, with the
direction of every joke deliberate.

Test: pick three of the manuscript's hardest-laughing
satirical sequences and ask, in each, who pays for the
laugh. If the answer is the powerful, the pretentious, the
hypocritical, the institutionally-protected, the
calibration is sound. If the answer is the marginal, the
working, the institutionally-vulnerable — even
inadvertently — the calibration needs revision.

### The Despair-Comedy Equilibrium

Satire's deepest emotional craft: the form holds despair
about its target alongside the comic energy that makes the
satire work. The strongest satire is funny AND troubling
simultaneously — the reader laughs and feels worse for
laughing. Satire that loses the despair becomes light comedy
with social subject matter; satire that loses the comedy
becomes hectoring polemic. The equilibrium is where the
form lives.

The technique requires that the writer hold the target's
genuine wrongness AND the target's genuine ridiculousness
at once. The corporate satire that finds corporate culture
genuinely harmful AND genuinely absurd; the political satire
that takes the political failure seriously AND finds it
specifically comic; the bureaucratic satire that
acknowledges what the bureaucracy specifically costs people
AND renders it as comedy. The two registers are not in
tension; they are the same register operating at different
levels of attention.

The technique fails in two directions:

- **Pure-comedy slippage** — the satire becomes light comedy,
  losing its critical weight. The reader laughs but doesn't
  feel the target was significantly engaged. The form has
  slipped into adjacent register.
- **Pure-despair slippage** — the satire abandons the comic
  register and becomes polemic. The reader is being
  lectured rather than experiencing the form's distinctive
  laughter-while-uneasy. The form has slipped into adjacent
  register on the opposite side.

The strongest satire holds the equilibrium consistently.
*Catch-22* is funny AND about the genuine horror of war.
*Slaughterhouse-Five* is comic AND about the genuine
trauma of survival. *The Sellout* is hilarious AND about
the genuine ongoing reality of American racism. *White
Noise* is funny AND about the genuine atomisation of
contemporary American life. The form's signature emotional
weight requires both registers operating simultaneously.

Test: pick three significant satirical sequences and ask, in
each, whether the reader would laugh AND feel uneasy. If
the sequences operate at one register only, the equilibrium
has tilted; if they operate at both, the form is operating
within its deepest register.

## Genre-Specific Revision Rules

Six revision passes specific to satire, each with a focused
question, run cover-to-cover before the next begins. Satire
revision must hold the form's signature contracts: target
clarity (specific identifiable target); escalation (absurdity
increasing); humanity (characters remaining people despite
the absurdity); deadpan (narrative voice maintaining
register); comedy-teeth balance (funny AND uncomfortable);
and the punching-direction + despair-equilibrium audits that
distinguish craft satire from light social comedy or
polemical lecture. The passes below are ordered to surface
target and escalation failures first (the form's most-felt by
genre readers), humanity and deadpan audits next, comedy-
balance and punching-calibration last as integrative final
checks.

### Pass 1: Target Clarity Check

Verify the satirical target is clear and specific.
Manuscripts that target categories ("corporations are
greedy", "politicians are corrupt", "academia is broken")
without rendering specific instances of the pattern are
operating at gestural level. The form's strongest practice
targets specific behaviours, specific language, specific
institutional logic. Read the manuscript and at each
satirical beat ask: what specifically is being satirised?
If the answer is generic ("corporate culture", "modern
politics", "social media"), the target needs sharpening.

Verify the satire is punching up, not down. The Punching
Calibration technique provides the audit framework:
direction (toward the powerful or the powerless?),
specificity (specific identifiable target or categorical
flattening?), protagonist's complicity (acknowledging
position or claiming external high ground?). Run the audit
on the manuscript's hardest-laughing sequences and ask, in
each, who pays for the laugh.

Verify the real-world parallel is visible without being
stated. The form's deepest pleasure includes the reader's
recognition of what the satire is targeting. If the
manuscript explicitly names its real-world target ("this is
clearly a satire of [specific institution]"), the form has
broken trust with the reader by doing the recognition work
the prose should have left for the reader to do. The
strongest satire is identifiable through accumulated
specific detail rather than through narrator commentary.

Test: identify the manuscript's primary satirical target and
verify the manuscript renders it through specific behaviour,
specific language, and specific institutional logic rather
than through narrator-stated identification. If the target
requires explicit naming to be recognised, the specificity
has not been deployed.

### Pass 2: Escalation Check

Verify the absurdity has increased since the last chapter.
Satire's structural pressure is escalation; the manuscript
that begins with absurd premises and stays at the same level
of absurdity through twenty chapters has not done the form's
work. Build an absurdity ledger: each chapter's absurd
premises, with verification that the level rises across the
manuscript.

Verify escalation follows logically from the established
premise. The form's signature pleasure is the reader's
recognition that "of course" the system would do this next
absurd thing — the absurdity is the logical extension of
the system's actual logic. Generic escalation (the absurdity
gets bigger without specific reason) is the failure mode;
extension-of-the-system's-own-logic is the technique.

Verify there is a new normal that would have been
unacceptable two chapters ago. The form's strongest pacing
device: each chapter normalises something the prior chapter
introduced as shocking. The reader's accumulating sense of
"this is just how things work now" reproduces the actual
psychological mechanism the form is critiquing — the way
real institutional absurdity becomes invisible through
familiarity. Test: identify the new normalisations across
the manuscript and verify each was introduced as
shocking before becoming routine.

### Pass 3: Humanity Check

Verify characters remain human despite the absurdity.
Satire's central craft challenge is keeping characters as
people while rendering the absurdity around them. The
strongest satire renders characters whose specific human
dimensions — fears, desires, complicities, small kindnesses,
specific failures — operate alongside the satirical
material. Characters who exist only as positions on the
satirical chart are the failure mode; characters whose
specific humanity makes the absurdity around them sting is
the technique.

Verify the protagonist still wants something genuine.
Satire's plot pressure depends on the protagonist's
specific desire — whatever it is, however compromised —
operating against the system the satire targets. The
protagonist who has no genuine desire has been written as
satirical position rather than character; the protagonist
whose specific wanting drives the plot through the system's
absurdity is the form's signature.

Verify someone is suffering — the comedy has cost. Satire
that is funny without anyone paying is light comedy; satire
where the absurdity costs someone (the protagonist, a
secondary character, the reader's surrogate within the
text) is operating within the form. The strongest satire
makes the cost specific and on-page; the worker who lost
their job in the efficiency review; the patient who died
waiting for the form to be processed; the constituent
whose case file was lost in the political reshuffle.

### Pass 4: Deadpan Check

Verify the narrative voice maintains the deadpan — no
winking, no lecturing. The Deadpan Report technique is the
form's signature voice register; the revision pass checks
whether the technique holds across the manuscript. Read the
manuscript and flag any place where the narrator
editorialises (commenting on the absurdity rather than
reporting it), winks at the reader (signalling
"isn't this absurd?"), or lectures (explaining what the
satire means rather than letting the reader register it).

Verify the target's language is being used as the weapon.
The Specificity-as-Weapon technique requires that the prose
deploy the target's specific vocabulary — the corporate
"circling back" and "right-sizing"; the academic "problematic"
and "interrogating"; the political "moving forward" and
"protecting our values"; the bureaucratic "expedited
processing" and "stakeholder consultation". The narrator who
mocks this language by paraphrasing it has lost the form's
distinctive weapon; the narrator who reports it deadpan is
operating within the form.

Verify the prose trusts the reader to see what's wrong.
The form's deepest contract is the reader's active
recognition of the satire's target. Manuscripts that
explain what's wrong in narrator voice ("of course, this
was clearly absurd") have broken the contract; manuscripts
that report and let the reader register the wrongness have
honoured it.

Test: pick three significant satirical passages and verify
each operates without narrator commentary, winking, or
lecturing. If the narrator's voice steps outside deadpan
register, flag for revision toward the form's signature
discipline.

### Pass 5: Comedy-Teeth Balance Check

Verify the chapter is funny — not just clever. Satire that
is intellectually clever without producing laughter has
slipped toward essay; satire that produces laughter without
intellectual weight has slipped toward light comedy. The
form requires both: the reader should both laugh AND
register the target. Read the manuscript and mark the
laughs — at the specific lines / specific moments where
the reader is intended to laugh out loud, smile in
recognition, or wince at the precision of the observation.

Verify the comedy reveals something uncomfortable. The
form's distinctive emotional weight comes from the laugh
that is also a recognition of something genuinely wrong.
Generic "isn't this funny?" laughter without the underlying
wrongness is the failure mode; specific funny moments that
also crystallise specific institutional or social wrongs is
the technique.

Verify the reader would both laugh AND feel uneasy.
Satire's deepest emotional contract is laughter-while-
uneasy; the reader's discomfort during their own laughter
is the form's signature emotional register. Pure comedy
without unease has slipped to adjacent register; pure
unease without comedy has slipped to polemic. The form's
strongest practitioners hold both registers in the same
sentences.

Test: mark the manuscript's intended laughs and ask, in
each, whether the laugh is also a recognition of something
uncomfortable. If laughs land without unease, the comedy-
teeth balance has tilted toward light comedy; if unease
arrives without laughter, the balance has tilted toward
polemic.

### Pass 6: Punching-Calibration + Despair-Equilibrium Audit

Run a final integrative pass on the manuscript's ethical
surface and emotional register. Two related sub-audits:

**Punching calibration.** The form's contemporary mainstream
consensus is that satire ages well when punching up
(toward power, pretension, hypocrisy, the institutionally-
protected) and ages badly when punching down (toward the
marginal, the already-mocked, the institutionally-
vulnerable). Audit the manuscript's hardest-laughing
sequences and verify the direction. Where the manuscript
mocks the powerful while treating the powerless with
sympathy, the calibration is sound. Where the manuscript
mocks the powerless or treats the powerful with sympathy,
the calibration needs revision.

The audit also checks specificity: are targets specific
identifiable behaviours of identifiable institutions, or
categorical groups whose specifics the satire has
flattened? Specific targets read as observation;
categorical targets read as bigotry. The strongest
contemporary satirists (Beatty, Saunders, the contemporary
diverse-perspective movement) hold their calibration with
deliberate awareness; the form's failure mode is the
satirist who mistakes who is powerful and who is
vulnerable in the specific situation depicted.

**Despair equilibrium.** Satire holds despair about its
target alongside the comic energy that makes the satire
work. Audit the manuscript's tonal register: does it hold
the target's genuine wrongness AND the target's genuine
ridiculousness simultaneously? The pure-comedy slippage
loses critical weight; the pure-despair slippage abandons
the comic register and becomes polemic. The strongest
satire (Heller's *Catch-22*, Vonnegut's *Slaughterhouse-
Five*, Beatty's *The Sellout*, DeLillo's *White Noise*)
holds both registers across hundreds of pages.

Test: read three significant satirical passages and ask, in
each, whether they operate at both registers (funny AND
about something genuinely wrong) or have tilted to one. If
passages have tilted, the equilibrium needs adjustment in
that direction; if they hold both, the form's deepest
register is operating.

## Names & Patterns to Avoid

### Satire Character Names. NEVER USE
- Obvious allegory names: Mr. Greedman, Senator Truthless, Dr. Clueless
- Names so absurd they break the deadpan (the names should be normal; the world should be absurd)
- Real names of living public figures (legal risk and lazy satire)

### Satire. NEVER DO
- Punch down (the powerless are not legitimate satirical targets)
- Lecture the reader on what's wrong (if you have to explain the satire, it's failed)
- Lose the humanity of characters (even satirical figures need genuine desires and fears)
- Write static absurdity (the situation must escalate or it's a sketch)
- Become the target (if the writing is as pretentious/bureaucratic/empty as what it mocks, the satire has failed)
- Sacrifice story for commentary (satire must also be a narrative with character and stakes)

### Use Instead
- Ordinary names for characters in extraordinary situations
- Names that sound institutional or professional (the normalcy heightens the absurdity)
- Names that work in the deadpan register. unremarkable

## Comp Titles

Satire's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Animal Farm* — George Orwell (1945): the political-allegory satire archetype.
- *Catch-22* — Joseph Heller (1961): military-bureaucracy satire benchmark.
- *Slaughterhouse-Five* — Kurt Vonnegut (1969): meta-satire with anti-war frame.
- *A Modest Proposal* — Jonathan Swift (1729, essay): foundational satirical-essay model.

### Contemporary (current best-in-class)

- *American Psycho* — Bret Easton Ellis (1991): consumerist-violence satire.
- *White Noise* — Don DeLillo (1985): postmodern-academic satire.
- *Yellowface* — R.F. Kuang (2023): publishing-industry contemporary satire.
- *The Sympathizer* — Viet Thanh Nguyen (2015): post-colonial satire benchmark.
- *Open Throat* — Henry Hoke (2023): satirical novella with mountain-lion narrator.
- *The Plot* — Jean Hanff Korelitz (2021): publishing-industry satire-thriller hybrid.
- *Dr. No* — Percival Everett (2022): contemporary literary satire.
- *Trust* — Hernan Diaz (2022): financial-industry literary satire.

## Cover Design Specifications

### Recommended Visual Styles
- **Graphic**. Bold, graphic imagery: flat colours, clean lines, a single striking image that captures the absurdity; the visual equivalent of the deadpan
- **Typographic**. The title IS the joke: bold, clever typography with minimal imagery; the design itself is satirical
- **Illustrated**. Witty, detailed illustration: the kind of image that rewards close looking; hidden details and visual jokes
- **Surreal**. Reality slightly wrong: a normal scene with one impossible element; the visual version of the slightly-wrong world

### Genre Cover Aesthetics
- **Styles:** Bold graphic design, witty illustration, clean lines, flat colours, visual puns, the aesthetic of editorial illustration or political cartoon elevated to book design, mid-century modern influenced design
- **Colours:** Bold, confident palettes: primary colours, high contrast, or the strategic use of one colour against white/black; the palette should feel deliberately chosen and slightly unnatural
- **Elements:** Objects from the target's world rendered with slight distortion (an office desk that extends to infinity, a committee meeting in an absurd location, institutional symbols made strange), visual metaphors, impossible architecture
- **Typography:** Bold, often playful; may be the dominant design element; the font choice itself should carry satirical weight (corporate sans-serif for corporate satire, academic serif for academic satire); clever placement and interaction with imagery

### Market Positioning
Satire covers must signal "funny, smart, and cutting" through bold graphic design and witty visual concepts. Position against Vonnegut, Heller, Toole, Dunne, Coupland. The cover should make the reader smile AND think. At thumbnail size, a bold colour palette and strong graphic concept create immediate shelf recognition.

### Cover Design DON'Ts
- No subtle or muted designs (satire's cover should be as bold as its content)
- No realistic photography (too literal for a genre that distorts reality)
- No designs that look like literary fiction (satire has its own visual language)
- No busy or cluttered compositions (one strong concept, cleanly executed)
- No caricatures of real people (legal risk and lazy design)
- No designs that look angry or polemical (satire wears a smile)
