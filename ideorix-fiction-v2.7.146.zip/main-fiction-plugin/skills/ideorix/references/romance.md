---
name: romance-genre
description: Genre-specific instructions for Romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [general]
---

# Romance. Genre Plugin

## Metadata
- id: romance
- name: Romance
- icon: 💗
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Romancing the Beat", "Story Circle", "Three-Act Structure", "Save the Cat"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| **Second Chance Romance** | Former lovers or estranged partners reconnect after time apart, confronting the wounds that separated them whilst discovering whether the feelings that drew them together still burn. | Relies on shared history and backstory rather than a meet-cute. The central tension is whether past mistakes can be forgiven. Requires careful handling of the original relationship's collapse. the reader must believe both the breakup and the reunion. Nostalgia and regret are primary emotional engines. |
| **Enemies to Lovers** | Protagonists begin in genuine opposition. rivalry, antagonism, or mutual dislike. and are forced by circumstances to see past their hostility to the person beneath. | The shift from hatred to attraction must be gradual and earned. Early banter carries genuine edge rather than playful teasing. Requires a believable reason for the initial animosity and a catalysing moment where perception shifts. The reader's pleasure comes from dramatic irony. seeing the attraction before the characters acknowledge it. |
| **Forced Proximity** | External circumstances trap the protagonists in close quarters. a snowbound cabin, a shared flat, a work assignment, a road trip. accelerating intimacy through unavoidable contact. | Timeline compression is acceptable and expected. Physical awareness is heightened by constant proximity. The confined setting becomes a character in itself. Tension builds through inability to escape attraction rather than pursuit of it. Works especially well combined with other subgenres (enemies + forced proximity is a perennial favourite). |
| **Friends to Lovers** | Long-standing friends gradually realise their relationship has deepened into romantic love, risking a treasured friendship for the possibility of something more. | The central obstacle is fear of losing the friendship. Chemistry must be shown simmering beneath established comfort. Requires a catalysing event that shifts perception. a moment of jealousy, an accidental touch, a confession under duress. The reader must feel both the safety of friendship and the electricity of emerging desire. |
| **Forbidden Romance** | Social, cultural, professional, or personal barriers make the relationship transgressive. boss/employee, rival families, class divide, age gap, or cultural taboo. | The forbidden element must create genuine stakes, not merely inconvenience. External pressure intensifies internal desire. Secrecy and stolen moments drive tension. The resolution must address the barrier honestly rather than hand-waving it away. Works best when the forbidden aspect forces both characters to examine what they truly value. |
| **Marriage of Convenience** | Protagonists enter a contractual or practical marriage. for inheritance, immigration, social standing, or mutual benefit. and must navigate developing real feelings within a framework that was never meant to involve love. | The formal structure of marriage creates forced proximity and enforced intimacy. Tension arises from the gap between the public performance of coupledom and the private reality. Domestic details (shared meals, sleeping arrangements, meeting families) become charged with unspoken feeling. The moment the arrangement stops feeling like an arrangement is the emotional fulcrum of the story. |

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Tension and release rhythm: attraction builds, obstacles separate, connection deepens
- Must open with: Meet-cute, attraction moment, relationship tension, or emotional connection
- Must close with: Longing intensified, conflict introduced, intimacy deepened, or separation threatened

BEATS PER CHAPTER
1. Attraction Moment: Chemistry shown. banter, physical awareness, emotional connection
2. Obstacle or Conflict: Internal (fear, past wounds) or external (circumstances, rivals, misunderstanding)
3. Intimacy Building: Vulnerability shared, trust deepened, physical or emotional closeness
4. Tension Escalation: Want vs. fear, longing vs. barriers, together vs. apart
5. Emotional Truth: Feeling acknowledged or revealed. to self, partner, or reader

GENRE-SPECIFIC REQUIREMENTS
- Happily Ever After (HEA) or Happy For Now (HFN): romance MUST end with couple together
- Both protagonists' POVs: dual perspective shows both falling in love
- Chemistry essential: sexual and emotional tension palpable
- Obstacles believable: why they can't be together must be genuine
- Communication matters: misunderstandings resolved through talking
- Consent explicit: all intimate activity clearly consensual
- Emotional arc primary: romance is relationship, not just plot events
- Declaration of love: feelings expressed clearly before end
- Grand gesture optional: but commitment must be clear
- Epilogue common: showing couple thriving together

OBSTACLE LAYERING (critical for sustaining tension)

A love story lives and dies by its obstacles. You cannot rely on a single barrier. you need MULTIPLE obstacles layered simultaneously. Internal obstacles (fear of vulnerability, past wounds, self-sabotage, commitment phobia) are the engine of modern romance. External obstacles (circumstances, geography, careers, family opposition, rivals) provide the framework. Each new obstacle should make the reader YEARN more intensely for the couple to find each other. The more obstacles you load in, the greater the reader's emotional investment and the more satisfying the eventual resolution.

Example obstacle layering:
- Obstacle 1: She has trust issues from past betrayal
- Obstacle 2: He has a career opportunity that requires relocation
- Obstacle 3: Her family disapproves
- Obstacle 4: A misunderstanding rooted in both their wounds

LIGHT AND SHADE

Every story needs emotional contrast. If one scene is devastating, the next should offer unexpected warmth. humor, a small kindness, a moment of connection. If the couple has just shared a blissful scene together, follow it with a complication that crashes their hopes. This contrast amplifies both joy and heartbreak. Two sad scenes back to back either overwhelm or cancel each other out. Alternate the emotional register chapter by chapter. chart the highs and lows like a heart monitor.

ANTI-STEREOTYPE IMPERATIVE

The great joy of writing romance is taking flawed, unconventional people who shouldn't be together, who mess things up when they get close, but whom readers genuinely believe in and root for. You don't need a stereotypical hero or heroine. Avoid the default tall-dark-handsome man and the fluttering woman. they're boring and frankly, stereotypes get in the way. Your characters can be ordinary, prickly, awkward, loud, quiet, funny, or fierce. What matters is that they are SPECIFIC and REAL, with the kind of messy human complexity that makes readers recognize themselves.

FORBIDDEN
- Tragedy ending: one dying or couple not together violates genre promise
- Cheating glorified: infidelity without consequences or presented as romantic
- Miscommunication as only conflict: must have deeper obstacles
- Insta-love without chemistry: attraction immediate, love develops
- Abuse romanticized: controlling behavior, stalking, coercion not romantic
- Love triangle unresolved: must choose, not polyamory unless explicitly that subgenre
- Third act breakup without good reason: forced conflict
- Heroes without growth: both must change/heal
- All tell, no show: must see chemistry, not just told they're attracted
- Stereotypical characters: no cookie-cutter heroes/heroines without individual complexity
- Single-obstacle stories: one barrier is never enough to sustain a full romance arc
- Relentless tone: romance needs light and shade, humor alongside heartbreak
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (primary engine — readers come for character bond), Captivation, Anticipation, Revelation at HEA / HFN.

VOICE & TONE
- POV: Dual 3rd limited (both protagonists) or alternating 1st person
- Tense: Past (traditional) or present (immediacy for intimacy)
- Voice: Emotionally immediate, sensual, hopeful, intimate
- Reading level: Accessible adult: emotional sophistication, intimate content

PROSE IMPERATIVES
- Chemistry shown through body language, dialogue, internal reaction
- Attraction physical and emotional: both brain and body respond
- Sensory details: how partner smells, sounds, feels, tastes
- Internal monologue reveals feelings: character aware of growing attachment
- Banter sparkles: wit, teasing, verbal foreplay
- Vulnerability visible: walls lowering, fears shared, truth told
- Tension sustained: want vs. obstacle, longing vs. fear
- Consent shown: enthusiastic participation, checking in, boundaries respected
- Emotional beats land: feelings expressed or realized with weight
- Hope present: even in darkness, relationship offers light

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- Ch 1 must establish BOTH leads with enough specificity that the
  reader is invested before the first chemistry beat. Tension ≥5.
- Opening: ground the POV character in a specific, vivid moment.
  not backstory, not reflection. Action or sensory immersion.
- The meet-cute or first awareness must land by Ch 1 end. The reader
  must feel the spark, not just be told about it.
- Dialogue density: 35-45% in Ch 1. Romance readers bond through
  how characters TALK to each other.

Chemistry scenes (prose rhythm):
- Sentences SHORTEN when attraction spikes. nervous characters
  think in fragments (8-12 words). Confident characters think in
  longer, breathier sentences (20-25 words).
- Paragraph breaks increase during high-chemistry beats. white
  space creates anticipation.
- Interiority is the genre's engine: 60-80 words per internal beat
  is fine (higher than thriller). But each internal beat must
  ADVANCE the feeling, not restate it.
- Sensory detail: one SPECIFIC physical detail per chemistry beat
  (the freckle, the laugh, the way they hold a glass). not a
  catalogue of features.

Tension scenes (obstacle/conflict prose rhythm):
- Sentences LENGTHEN when the character is processing pain or doubt
  (20-30 words. the weight of the feeling).
- Short sentences for revelations or realisations ("He'd lied."
  "She already knew.").
- Dialogue becomes clipped, defensive, incomplete. mirroring the
  emotional withdrawal.

Climax/declaration prose rhythm:
- Return to short, clear, emotionally direct sentences. No hiding
  behind metaphor. The declaration must land clean.
- The reader should be able to HEAR the character's voice in the
  declaration. it should sound like THEM, not like a greeting card.

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-protocol.md`
"Heat Level Calibration Slot" handles the wire-up. Romance projects
get the full block; non-romance projects with `romance_subplot:
yes` get the same block (same calibration logic applies wherever
romance content appears).

Genre-specific layered cues — how romance subgenre tropes interact
with the calibration (e.g. how forced-proximity in a sweet/clean
context shapes the proximity-cue choices) — live below, in the
GENRE-SPECIFIC STYLE and CHEMISTRY DEMONSTRATION sections. They
SUPPLEMENT, never override, the universal heat calibration.

GENRE-SPECIFIC STYLE
- Meet-cute memorable: first meeting distinctive, chemistry immediate
- Forced proximity common: circumstances push together
- Banter as foreplay: verbal sparring shows chemistry
- Body language detailed: awareness of partner's presence, movement, touch
- Internal longing: character wants what fears/can't have
- Misunderstandings addressed: communication eventually happens
- Grand gestures earned: actions proving love after words spoken
- Sex scenes (if present) emotionally connected: not just physical
- Declarations clear: "I love you" said explicitly
- Epilogue sweet: showing couple's future happiness

FORBIDDEN WORDS/PHRASES

→ See `heat-calibration.md` "Cliche blocklist" for the canonical
   list — both the high-spice cliches (apply at all heat levels)
   and the 13 sweet/clean cliches (especially flag at Spice 0-1).

The blocklist is genre-agnostic (it applies wherever romance
content shows up — including non-romance genres with
`romance_subplot: yes`) and lives in the universal calibration
file so it stays consistent across all heat-affected projects.
Genre-specific FORBIDDEN entries (if any surface that don't
generalise) would be listed here below; none currently.

CHEMISTRY DEMONSTRATION
Show attraction through:
- Physical awareness: Noticing details: freckle on shoulder, way they laugh
- Internal reaction: Racing heart, dry mouth, distraction, hyperawareness
- Banter: Wit, teasing, verbal dance, subtext
- Touch: Accidental contact, deliberate reaching out, magnetic pull
- Jealousy: Irrational possessiveness when others show interest
- Distraction: Can't focus on anything else, constantly thinking of partner
- Sensory details: Scent recognition, voice causing shivers, craving touch

EMOTIONAL ARC LANGUAGE
- Attraction: Physical pull, fascination, wanting to know more
- Connection: Understanding, shared values, comfort together
- Longing: Separation painful, constantly missing partner
- Fear: Vulnerability terrifying, past wounds activated
- Trust: Walls lowering, secrets shared, reliance building
- Love: Conscious recognition of depth of feeling
- Commitment: Choosing partner despite fears, obstacles

INTIMATE SCENES (if present)
- Consent clear: enthusiastic participation, checking in
- Emotionally connected: feelings matter as much as sensations
- Sensory rich: touch, taste, smell, sound, sight engaged
- Character voice maintained: how THIS person experiences intimacy
- Vulnerability shown: emotional openness during physical
- Variety: different locations, moods, dynamics
- Consequences considered: emotions after, relationship impact
- Sex scenes should illustrate something about BOTH characters and their relationship: not exist for titillation alone
- Ask: what does this scene reveal about the couple's dynamic? What shifts in the power balance, the trust, the emotional landscape?
- Awkwardness and imperfection make intimacy far more authentic than choreographed perfection: the best intimate scenes have humor, nervousness, or emotional rawness alongside desire
- Build physical intimacy into the emotional landscape of the story: it should feel like a natural culmination of accumulated tension, not an isolated set piece
- Terminology matters: strike a balance between clinical detachment and purple excess. Write through sensory experience rather than anatomy

DIALOGUE. THE CRAFT OF THE UNSAID

- What characters DON'T say carries enormous weight: the gap between what is felt and what is spoken IS the tension
- In the early stages, characters should express attraction through everything EXCEPT direct declaration: banter, teasing, deflection, over-attentiveness, deliberate avoidance
- Holding back gives far more resonance to the moment feelings are finally spoken: the reader should feel the accumulated pressure of chapters of restraint
- Each character must speak distinctly: you should be able to tell who is talking even without dialogue tags
- Conversations should function as a verbal dance: push and pull, advance and retreat, what's risked and what's withheld
- Characters should sometimes make things WORSE when trying to make them better, or hide things when the listener can sense it anyway
- The most powerful romantic exchanges happen when both characters are disturbed by the depth of their feelings and cannot quite articulate it

METHOD WRITING. EMOTIONAL IMMERSION

- Identify what you want the reader to FEEL before writing any key scene. longing? joy? heartbreak? nervous anticipation?. then build every detail toward that emotional target
- Write through the senses to put the reader in the character's shoes: what does the love interest's proximity do to the protagonist's breathing? What is the exact sensation of accidental contact?
- If you aren't feeling the emotion as you write it, the reader won't feel it either: that is the signal to go back and find what's blocking the feeling
- When writing climactic emotional scenes, lean INTO the feeling fully: if the declaration of love doesn't make the writer's throat tighten, it won't move the reader
- Never be cynical about emotion: don't manufacture a crisis or a breakup purely to provoke tears. Genuine emotion earned through character investment is what creates readers who laugh and cry with your characters

THEME BENEATH THE LOVE STORY

Every strong romance has a THEME. what the book is really about beneath the surface of the relationship. Love is vast and takes many forms: romantic love, friendship, family, self-love. Identify the deeper question your romance is exploring. What makes life worth sharing? How do we trust again after betrayal? What does it mean to choose someone despite fear? Theme feeds into voice and plot, adds a dimension that stays with the reader long after the HEA. Pin the theme somewhere visible and return to it when the story drifts.
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. HEA/HFN delivered. couple together at end, genre promise kept
2. Dual protagonist equality. both characters fully developed, both POVs present
3. Chemistry authentic. physical and emotional attraction shown, not just stated
4. Consent explicit. all intimacy clearly consensual, boundaries respected
5. Obstacles genuine. conflict believable, not contrived, resolved meaningfully

GENRE-SPECIFIC CHECKS

Ending is HEA/HFN. couple together, committed, future clear
Both POVs present. reader in both protagonists' heads
Chemistry shown. attraction demonstrated through action, reaction, internal response
Consent clear. all physical intimacy enthusiastically consensual
Communication happens. misunderstandings resolved through talking
Both grow. each character changes, heals, becomes better through relationship
Obstacles resolved. conflict addressed, not forgotten or dropped
"I love you" said—feelings declared explicitly before end
Intimacy progresses. physical and emotional closeness builds logically
No abuse romanticized. controlling, stalking, coercion not portrayed as love

AUTOMATIC FAILS

Tragic ending. one dies or couple not together, violates genre promise
One POV only. hero-centric with love interest as accessory rather than co-protagonist
Insta-love without chemistry—"love at first sight" without showing attraction building
Non-consensual intimacy—coercion, ignoring "no," drunk sex presented as romantic
Abuse as romance. controlling, stalking, possessive behavior glorified
Miscommunication only. all conflict from not talking, no deeper obstacles
Unresolved love triangle. must choose one (unless polyamory is the explicit premise)
Third act breakup without cause. contrived conflict manufactured to fill pages
No growth. characters unchanged, same at end as beginning
All tell, no show. told they're attracted, never shown chemistry in action

ACCEPTABLE IMPERFECTIONS

Mild purple prose in intimate scenes if emotional truth preserved
Slight timeline compression for forced proximity scenarios
One POV slightly more chapters if both perspectives present
Some genre tropes (meet-cute, forced proximity) if well-executed with fresh details

RED FLAGS TO INVESTIGATE

Chemistry stated rather than demonstrated—"they had amazing chemistry" instead of showing it
One protagonist more developed than the other. love interest feels like accessory to hero's story
Obstacles introduced then forgotten. conflict vanishes without resolution or acknowledgment
Physical intimacy escalating without emotional intimacy keeping pace. or vice versa
Banter that reads as hostile rather than flirtatious. cruelty disguised as wit
Wounds mentioned but never affecting behavior. backstory that doesn't influence choices
Grand gesture coming from nowhere. resolution not seeded in earlier chapters
Dialogue where both characters sound identical. no distinct voices in conversation
Internal monologue contradicting shown behavior without narrative awareness
Consent ambiguous in intimate scenes. enthusiastic participation unclear
Third act breakup feeling manufactured. conflict that serves plot structure rather than character truth
Emotional register stuck on one note. multiple consecutive chapters all blissful or all agonizing without contrast
"I love you" landing without weight—declaration not earned through accumulated vulnerability and trust
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Relationship progression: Emotional intimacy deepens logically. attraction to love tracked
2. Conflict consistency: Obstacles don't vanish arbitrarily. must be resolved meaningfully
3. Character wounds: Past traumas/fears that block love maintained until healed
4. Physical intimacy level: What couple has done tracked. first kiss, first time, etc.
5. Promises and declarations: What said to each other remembered and honored

GENRE-SPECIFIC TRACKING
- Relationship milestones: First meeting, first kiss, first "I love you," first intimacy
- Conflict sources: What keeps them apart: external circumstances, internal fears
- Emotional wounds: Past relationships, trauma, fears that block vulnerability
- Physical progression: What intimacy achieved when: hand-holding to more
- Declarations made: Promises, confessions, commitments spoken
- Third parties: Exes, rivals, family opinions that affect relationship
- Communication breakthroughs: When truths shared, walls lowered
- Both POVs feelings: Each character's emotional state toward other

ACCEPTABLE INCONSISTENCIES
- Minor date night details if relationship progression clear
- Exact wording of sweet nothings if sentiment consistent
- Background character relationship statuses if not plot-critical

CRITICAL CONSISTENCY
- First kiss only happens once: subsequent kisses are "kisses" not "first"
- Past wounds don't vanish: healing shown through actions, therapy, time
- "I love you" first said is special: not repeated as if first time
- Conflict resolution sticks: same fight can't recur without regression explanation
- Physical intimacy progression: can't go backward without reason
- Character's relationship stance: if commitment-phobic, doesn't become eager without growth
- Ex-partner details: name, circumstances, wounds inflicted stay consistent
- Family dynamics: controlling mother stays controlling unless arc shows change
- Sexual history: if virgin stated, stays virgin until scene shown
- What characters have SAID vs. NOT SAID: track the unsaid accumulating across chapters; the gap between felt and spoken is the engine of romantic tension
- Obstacle progression: each obstacle introduced must be resolved meaningfully or acknowledged; obstacles cannot vanish for convenience
- Emotional register alternation: track chapter-by-chapter emotional highs and lows to ensure light and shade; flag sequences of same-tone chapters
- Character consistency: characters built through ground-up backstory must walk a true line throughout; no sudden personality shifts without earned development
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Dual protagonists equal: Both characters fully developed. not hero's story with love interest
2. Wounds that block love: Past trauma, fears, walls that prevent vulnerability consistent
3. Growth through love: Each character heals, changes, becomes better version through relationship
4. Chemistry authentic: Physical and emotional attraction visible, believable, maintained
5. Consent and agency: Both choose relationship, neither coerced or manipulated

CHARACTER BUILDING. GROUND UP

Before characters can meet on the page with sparks, they must be fully alive in the writer's mind. Build each protagonist from the ground up:
- Background questions: What do they want out of life? What's stopping them? What were their formative relationships? What do they carry emotionally?
- Character tests: What's in their bag/fridge? (This reveals volumes about a person.) How do they react when they witness cruelty? When someone lets them down? When they're caught in a lie?
- The vast majority of this backstory never appears on the page, but it informs every reaction, every line of dialogue, and every choice in a relationship
- Messy, flawed characters are ALWAYS more interesting than perfect ones: flaws create the potential for growth, and growth is the beating heart of romance
- A flawed character can grow, learn, redeem themselves. A perfect character has nowhere to go.

GENRE-SPECIFIC CHARACTER ELEMENTS
- Both POVs developed: Romance requires two protagonists, both falling in love
- Complementary wounds: Baggage that relationship helps heal
- Chemistry immediate: Physical attraction obvious from start: but love develops through earned intimacy, not instant declaration
- Emotional availability arc: Walls up initially, lowered through trust
- Individual goals: Each has life beyond romance: career, family, passions
- Supporting cast: Friends, family, exes that enrich or complicate romance
- Consent explicit: All intimacy clearly consensual, boundaries respected
- Growth needed: Both must change: relationship transforms them
- NO stereotypes: Avoid default character types (the brooding CEO, the clumsy ingenue). Give each protagonist specific, individual qualities that make them feel like real people rather than archetypes

CHARACTER ARCS MUST
- Show vulnerability increasing: walls lowering, truth shared
- Demonstrate fear of intimacy: what makes love terrifying for this person
- Reveal past wounds: betrayal, abandonment, trauma that blocks trust
- Prove through action: love shown in deeds, not just words
- Overcome obstacles: internal growth and external circumstances addressed
- Choose partner: active decision to commit despite fears
- Change meaningfully: better person by end because of relationship
- Remain TRUE to established character: cannot suddenly act out of character because the plot requires it. If commitment-phobic, they don't become eager without earned growth. Characters must walk a consistent line.

TRACK
- Each character's wound/fear that blocks love
- Moments of vulnerability: when walls lower
- Growth progression: how each changes through relationship
- Chemistry moments: physical attraction, banter, longing
- First times: first kiss, first intimacy, first "I love you"
- Supporting relationships: friends, family, exes who affect romance
- Individual goals: career, family, dreams beyond romance
- Consent moments: checking in, boundaries respected

ROMANCE CHARACTER ARCHETYPES

The Architect must build a minimum of 4 and a maximum of 6
characters from the ground up before drafting begins. Each
character draws on but is not limited by one of the archetypes
below. Every archetype is a starting frame, never a stereotype —
the character must depart from the frame in at least 3 specific,
character-rooted ways the Architect names in the Story Bible.

THE WOUNDED LEAD (one of the two protagonists):
- Carries a specific, psychologically real wound that blocks
  love. Not generic "trust issues" — name the inciting event
  ("she walked in on him with her sister at her own engagement
  party" / "he was the one who found his mother after the
  overdose, aged 11"). The wound must be specific enough that
  the Writer can reach for it scene by scene.
- Has a life pre-dating the love interest with skills, a job,
  friends, ambitions. They want something from life beyond
  this relationship and must keep wanting it through the book.
- Has a clear answer to "what would they do if they witnessed
  cruelty to a stranger?" — the answer reveals their moral
  spine.
- Has a clear answer to "what's in their fridge / their bag /
  on their bedside table?" — the answer reveals how they live
  when no one is watching.
- Their flaw is specific and consequential: not endearing
  clumsiness or being "bad at relationships," but a flaw that
  costs them something in the story. They self-sabotage in
  ways the reader recognises.
- They are NEVER passive for more than two consecutive
  chapters. Even when wounded, they choose how to react.

THE OPPOSITE LEAD (the other protagonist):
- Built from the ground up the same way as The Wounded Lead.
  Both protagonists must be fully developed; this is not a
  hero's story with a love interest accessory.
- Their wound is COMPLEMENTARY but NOT identical. Two characters
  with the same wound have nothing to teach each other.
  Complementary means: where one is closed, the other is open;
  where one runs, the other stays; where one over-shares, the
  other withholds. The friction between their coping styles IS
  the engine.
- They want something that cannot be reconciled with the other
  lead's want without one of them changing. Identify this
  irreconcilable tension at outline time and seed it from
  Chapter 1.
- They are SPECIFIC, not stereotypical. Forbidden default
  framings: the brooding billionaire CEO, the clumsy ingenue,
  the tall-dark-handsome man without specific quality, the
  fluttering woman, the "not like other girls" heroine, the
  alpha male without vulnerability, the sassy best friend
  archetype as romantic lead.
- Has the same battery of specifics as The Wounded Lead
  (witnessed-cruelty answer, fridge / bag / bedside answer,
  pre-dating life, specific flaw).

THE WISE BEST FRIEND / CONFIDANT:
- Provides the protagonist with someone to talk to — the
  vehicle for showing the protagonist's interiority through
  dialogue rather than monologue.
- Has their own life, problems, and storyline. They are not
  a sounding board with no agenda. If they have nothing of
  their own going on, cut them.
- Often delivers the line the protagonist needs to hear and
  cannot say to themselves. Used sparingly — once or twice
  per book, not every chapter.
- Distinct voice from the protagonist: when they speak,
  there should be no need for a dialogue tag for the reader
  to know who is talking.

THE ANTAGONISTIC EX / RIVAL:
- Not a cartoon. Has their own logic for being in the story.
  Their continued presence must be plausibly motivated (shared
  business, shared family, professional rivalry, unresolved
  emotional stake) — not a contrivance to manufacture jealousy.
- Provides external pressure. The reader sees them as a
  threat to the central relationship without the writer
  having to argue that they are.
- May get at least one moment of sympathetic specificity —
  a beat that shows they are a person, not a function.
  Antagonistic Exes who are 100% villain are less effective
  than ones who carry one human flicker.
- Their defeat or dismissal is hard-won by the protagonists,
  not delivered by an off-page event.

THE FOUND FAMILY:
- The protagonists' chosen circle (siblings, work-friends,
  small-town network, online community, fellow members of
  some non-romantic affiliation). Used to anchor the
  protagonists in a life that pre-dates and will outlast the
  romance.
- Each named member must serve at least one structural
  function (wisdom, comic relief, conflict source, plot
  catalyst, mirror for the protagonist's growth). Members
  serving no function should be cut.
- Provides the reader with someone to root for at every
  scale: the central romance AND the network around it.
- Their reaction to the romance is part of the romance's
  texture — they may approve, disapprove, lobby, intervene.

THE EXTERNAL ANTAGONIST FORCE (when present):
- Not always a person. May be a circumstance: a deadline, a
  job offer in another city, a family obligation, a cultural
  expectation, a custody arrangement, an immigration status.
- Treat with the same psychological specificity as a human
  antagonist: what does it want, why, what does it cost the
  protagonists to face it?
- For Forbidden Romance subgenre, this archetype carries
  most of the obstacle weight. For Friends-to-Lovers, it may
  be entirely internal. Calibrate emphasis to subgenre.

CHARACTER-BUILD TESTS (apply to every named character before
drafting)

Run each character through this battery before they appear on
the page. Most answers never appear in the prose, but every
answer informs how the character reacts in any scene.

1. Background: What did their parents do? Where did they grow
   up? What were their formative relationships? What did they
   carry into adulthood emotionally?
2. Want: What do they want from life? What is stopping them?
   What have they tried already and given up on?
3. The Bag/Fridge/Bedside test: What's in their bag, their
   fridge, on their bedside table? Each answer reveals
   something specific about how they live when no one is
   watching. Wallets full of receipts. Half a bottle of gin
   and a wilted lemon. A book they've been meaning to read for
   four months.
4. The Witnessed-Cruelty test: What do they do when they see
   someone being cruel to a stranger? Intervene? Run away?
   Document and report? Freeze? The answer reveals their
   moral spine.
5. The Caught-In-A-Lie test: What do they do when caught in a
   small social lie? Double down? Confess immediately? Make a
   joke? The answer reveals their relationship to truth and
   shame.
6. The Witness-Letdown test: How do they react when someone
   they love lets them down? Withdraw? Confront? Make excuses
   for the other person? The answer reveals their attachment
   pattern.

The answers go in the Story Bible. Cross-check every scene
against them: does this character's reaction match their
established battery? If yes, the line walks true. If no,
either the line is wrong or the character build is.

LOVE INTEREST PRESENCE BALANCE (Writer-Level Enforcement)

A romance lives or dies by the chemistry between the two leads.
The Writer must maintain consistent on-page presence of both
leads in any romance project. Quantitative tracking per chapter:

DIRECT PRESENCE: Scenes where both leads appear together on-page
INDIRECT PRESENCE: Scenes where the absent lead is felt through
  the present POV's thoughts, references, the consequences of
  earlier interactions, or external mentions

Per-chapter minimum: At least ONE of direct or indirect
presence in every chapter. A romance chapter where the love
interest is entirely absent (no on-page appearance, no thought,
no reference, no consequence) is almost always a structural
error — the central relationship has gone dormant for the
length of the chapter.

CHEMISTRY BEAT DENSITY (escalation across acts):

  Act 1 (Chapters 1 - ~25%): At least 1 chemistry beat per 2
                              chapters. Direct presence in
                              50%+ of chapters.
  Act 2A (~25-50%): At least 1 chemistry beat per chapter.
                    Direct presence in 65%+ of chapters.
  Act 2B (~50-75%): At least 1 chemistry beat per chapter,
                    rising in intensity. Direct presence in
                    75%+ of chapters. The "almost moments"
                    architecture engages here.
  Act 3 (~75-100%): Chemistry beats every chapter, escalating
                    toward declaration / climax. Direct
                    presence in 85%+ of chapters except the
                    deliberate separation chapter (third-act
                    breakup) where indirect presence carries
                    via the protagonist's thoughts of the
                    absent lead.

Where present, a "chemistry beat" is any of: a charged piece of
banter, an almost-moment, a vulnerability exchange, a touch
(deliberate or accidental), a moment of being seen / understood
/ recognised, a flash of jealousy or possessiveness, a moment of
parting that costs more than expected.

The Character Tracker verification agent will flag chapters that
fall below the per-act floor. The Writer must add direct or
indirect presence beats before proceeding.

VOICE DIFFERENTIATION (Quantitative Check)

For each PAIR of major characters, identify at least 3
distinguishing dialogue features. If any two characters share
> 2 features, one must be revised before proceeding.

Romance is especially prone to "two leads sound the same"
convergence — both witty, both sensitive, both observant. The
reader stops being able to tell who's speaking and the chemistry
collapses. Ensure different:

- Sentence length patterns (one terse, one expansive; or one
  measured, one over-shares under pressure)
- Vocabulary domain (one rooted in their profession, one in
  their interests; e.g. one speaks like a paramedic, one like
  a primary-school teacher)
- Response to vulnerability (one deflects with humour, one
  goes silent, one over-explains, one changes the subject)
- Response to attraction (one over-talks when nervous, one
  goes quiet, one teases, one becomes formal)
- Verbal tics (a phrase one of them uses; a grammatical
  preference; a habit of trailing off; a habit of asking
  rhetorical questions)
- Physical business during dialogue (one fidgets, one goes
  still, one mirrors, one creates physical distance)

The protagonist's interior monologue style must also be
distinguishable from the love interest's interior monologue
style if dual-POV. Two interiors that read identically signal
voice-collapse and the reader will lose the second protagonist
within 50 pages.

The Character Tracker verification agent will flag voice
convergence between any two major characters. If flagged, the
Writer must differentiate before proceeding.
```

## Arc Rules

```
ACT I (Chapters 1-10): Meeting and Attraction
- Ch 1: Meet-cute: memorable first encounter, immediate chemistry
- Ch 2-3: Getting to know: dates, forced proximity, banter, attraction building
- Ch 4-5: Vulnerability glimpses: hints of wounds, why love is scary
- Ch 6-8: Intimacy increasing: emotional or physical closeness deepening
- Ch 9-10: First major milestone: kiss, confession, or sleeping together
- Purpose: Characters meet, chemistry evident, obstacles introduced
- Ends with: First kiss or major intimacy milestone, conflict escalating

MIDPOINT (Chapter 15): Declaration or Major Obstacle
- "I love you" spoken, or biggest obstacle threatens relationship
- Commitment deepening or crisis forcing separation
- Tonal shift: From falling to fighting for love, or doubt to certainty

ACT II (Chapters 11-23): Deepening and Conflict
- Ch 11-14: Falling deeper: spending time together, intimacy increasing
- Ch 15: MIDPOINT: "I love you" or major conflict erupts
- Ch 16-18: External conflict: circumstances, exes, distance threaten relationship
- Ch 19-21: Internal conflict: wounds activated, fears surface, walls go up
- Ch 22-23: Black moment: breakup, separation, seems over
- Purpose: Love develops, obstacles threaten, wounds activated
- Ends with: Black moment: relationship seems doomed, separation occurs

ACT III (Chapters 24-30): Resolution and HEA
- Ch 24-25: Realization: what really matters, willing to risk everything
- Ch 26-28: Grand gesture or honest conversation: fighting for love
- Ch 29: HEA: commitment, proposal, or clear future together
- Ch 30: Epilogue: months/years later, couple thriving
- Purpose: Grand gesture, communication breakthrough, commitment
- Ends with: Couple together, future committed, epilogue showing HEA

GENRE PROMISE
- HEA or HFN: couple together at end
- Dual POV: both protagonists' perspectives, both falling in love
- Chemistry: sexual and emotional tension throughout
- Obstacles overcome: conflict resolved, not forgotten
- Communication: misunderstandings cleared up
- Consent: all intimacy clearly consensual
- Emotionally satisfying: feelings explored deeply
- Declaration: "I love you" said explicitly
- Commitment: future together clear
- Hopeful tone: even in conflict, relationship worth fighting for

REQUIRED CHECKPOINTS
- Ch 3: Chemistry undeniable: both aware of attraction
- Ch 8: Vulnerability shared: wounds hinted or revealed
- Ch 10: First major intimacy: kiss, sleeping together, or "I love you"
- Ch 15: Deepest intimacy or biggest obstacle introduced
- Ch 20: Wounds activated: fears threaten relationship
- Ch 23: Black moment: separation, seems over
- Ch 28: Communication breakthrough or grand gesture
- Ch 30: HEA confirmed: together, committed, hopeful future

LIGHT AND SHADE IN ARC STRUCTURE

Chart the emotional arc like a heart monitor. never flat, always oscillating. After the bliss of a romantic milestone (Ch 10), immediately introduce a complication. After the devastation of the black moment (Ch 23), allow a scene of quiet reflection or unexpected humor before the grand resolution. Lure the reader into a false sense of security, then crash their hopes. and vice versa. Each emotional extreme amplifies the one that follows.

EARNED ENDINGS

The HEA must be TRUE to the characters built throughout the story. The ending should feel like the inevitable destination of these specific people, not a generic happy conclusion bolted on. Seed the resolution early—plant clues to how the obstacles will be overcome so the ending feels earned, not convenient. The reader should think "of course—it HAD to end this way." Forced resolutions, deus ex machina reunions, and personality transplants in the final chapters are the surest way to lose reader trust.

THEME AS THROUGH-LINE

The strongest romance arcs are unified by a theme that runs beneath every chapter. what the story is REALLY about beyond the love story. Is it about trust after betrayal? The courage to be vulnerable? The difference between what we want and what we need? Theme gives the arc unity and ensures that when the reader closes the book, something lingers beyond the warm glow of the HEA.
```

## Timeline Rules

```
TIME SCALE
- Total story duration: Weeks to months (occasionally single day or years)
- Chapter time span: Days to week: balance time together with anticipation
- Time progression: Linear with growing intimacy: rushing or dragging both problematic

GENRE-SPECIFIC TEMPORAL RULES
- Love takes time: attraction instant, love develops over weeks/months
- Physical progression paced: first kiss to intimacy has believable timeline
- Forced proximity compressed: if stuck together, faster progression acceptable
- Long-distance stretches: separation after intimacy tests relationship
- Time apart hurts: once attached, missing partner is physical
- Healing requires time: past wounds don't vanish overnight
- Grand gestures need setup: can't come from nowhere
- Epilogue jumps forward: months or years showing HEA sustained

TRACK CAREFULLY
- Days since first meeting: relationship timeline from start
- Time between relationship milestones: attraction, first kiss, first intimacy, "I love you"
- Date progression: how many dates before certain revelations or intimacy
- Forced proximity duration: how long stuck together in confined space
- Time apart: separations that test relationship or create longing
- Healing timeline: working through past trauma, therapy, growth
- Obstacle duration: how long conflict keeps them apart before resolution
- Pregnancy timeline if relevant: conception to birth realistic

FLEXIBLE
- Exact times of day unless romantic moment depends on it (sunset, midnight)
- Minor daily routines between key relationship scenes
- Background couple timelines if not affecting main romance
```

## Genre-Specific Craft Techniques

### The Slow Burn Engine
Building tension through delayed gratification. the almost-kiss, the interrupted confession, the accidental touch that lingers. Each near-miss must advance the emotional stakes. The reader should be desperate for the characters to connect, not frustrated by contrivance.

### The Banter Architecture
Dialogue that reveals character whilst building attraction. Great romantic banter is never just witty. it's combative, flirtatious, and revealing simultaneously. The subtext carries as much weight as the text. Each exchange should shift the power dynamic, even slightly.

### The Vulnerability Exchange
Moments where emotional walls drop. the hero's confession in the dark, the heroine's admission of fear. These scenes require earned trust between characters. Vulnerability that comes too easily reads as weakness; vulnerability that never comes reads as emotional constipation.

### The Grand Gesture Earned
The climactic romantic moment only works because of what preceded it. The public declaration, the chase to the airport, the midnight knock. these tropes succeed when the entire book has been building toward them. The gesture must cost the character something and must address the specific wound established earlier.

### The HEA/HFN Promise
Structuring the ending to satisfy the genre contract. The Happily Ever After or Happy For Now must feel both surprising and inevitable. The obstacles must be genuinely threatening without making the resolution feel forced. The final union should demonstrate character growth, not just desire.

### Chemistry Scene Construction (CRITICAL — 7-element framework)

A Chemistry Scene is any major scene in which the central
relationship advances — the meet-cute, the first real
conversation, the almost-kiss, the first kiss, the vulnerability
exchange, the third-act breakup, the declaration, the grand
gesture. Every Chemistry Scene must be PLANNED, not improvised.

The 7 Elements of a Chemistry Scene:

**Element 1: The Setup**
Establish the emotional arena before the chemistry begins. The
reader needs to know what the leads each carry into the scene —
what they want, what they fear, what they're hiding from each
other in this moment.
- What is each lead's emotional state coming in?
- What did the previous scene leave unresolved between them?
- What do they each think the other is thinking? (Often wrong.)
- What's the physical setting and how does it constrain or
  pressure them? (A wedding makes some things sayable that a
  workplace doesn't, and vice versa.)

**Element 2: The Approach**
The leads come into proximity. This is where physical and
emotional space starts compressing.
- Who initiates? Why now?
- What is the surface pretext for their being close (work
  conversation, shared task, accidental encounter)?
- What does the body language reveal that the dialogue does
  not? (One mirrors, one creates distance; one leans in, one
  steps back; one reaches and stops.)
- The Approach is small. A held look, a shared glance across a
  room, a hand offered to help with a coat. Save the bigger
  beats for elements 4 and 5.

**Element 3: The Banter Beat**
A piece of dialogue that does double duty: it advances the
relationship AND reveals character. Banter is verbal foreplay
in higher-heat books and verbal courtship in lower-heat books,
but in any case it carries subtext.
- What is each lead really saying beneath the surface?
- Does the exchange shift the power dynamic, even slightly?
- Does it earn its sparkle from character-rooted wit (their
  specific intelligence, their specific shared reference,
  their specific pattern) rather than generic snappy
  comeback?
- Banter must be consequential. If you cut it, would the
  scene's emotional arc collapse? If no, rewrite or cut.

**Element 4: The Awareness Spike**
The moment one or both leads register the other anew — sees
something they didn't see, feels something they didn't feel,
realises the depth of what's between them. This is the scene's
emotional pivot.
- Sentence rhythm shortens here. The model should write in
  shorter beats than at the Setup.
- The Awareness Spike is INTERIOR even when the prose is
  exterior. The reader should feel the lead's perception
  shift, even if the body language gives nothing away.
- The Spike should be character-rooted, not generic. What
  THIS lead notices about THIS other lead in THIS moment.
- One Awareness Spike per Chemistry Scene is enough. More
  than one and the scene loses its centre of gravity.

**Element 5: The Pull-Back**
The leads cannot or will not act on what just happened. The
Pull-Back is the load-bearing beat of romance scene craft —
it generates the yearning that makes the reader turn pages.
- Why don't they act? Internal obstacle (their wound), external
  obstacle (someone walks in, the phone rings, the moment is
  wrong), or chosen restraint (the timing isn't right; one of
  them isn't ready)?
- The Pull-Back must FEEL inevitable in retrospect. If the
  reader thinks "they could have just kissed there," the
  Pull-Back has failed.
- In Sweet/Clean and Mild Spice books, Pull-Backs do most of
  the chemistry work. In Open Door books, Pull-Backs are
  reserved for early acts; Act 2B and Act 3 trade Pull-Back
  for consummation.

**Element 6: The Aftermath**
The scene does not end at the Pull-Back. The Aftermath is
where the scene's consequence lives — what the leads carry
out of it.
- What does each lead think AFTER they part? The scene's
  significance is established here.
- What changes in their behaviour because of what happened?
  (Even if neither acknowledges the change.)
- The Aftermath is brief — a paragraph, sometimes a line.
  But it's the difference between a Chemistry Scene that
  reverberates and one that disappears.

**Element 7: The Hook**
The Chemistry Scene connects to what comes next. What does
this scene set up that the next scene must pay off (or
deepen)?
- A new question opened (Captivation re-engaged)
- A new obstacle revealed
- A new awareness the lead now carries forward
- A new shared knowledge the leads have but no one else does

The Hook can be small. The reader should turn the page wanting
to see what these two do next.

**Pacing rule:** Chemistry Scenes structurally pace the
manuscript. Aim for at least one major Chemistry Scene per act
boundary, and one minor Chemistry Scene every 3-4 chapters
between boundaries. The "almost moments" in Act 2B should
escalate in stakes — what gets pulled back from in Ch 18 must
matter more than what got pulled back from in Ch 9.

### Dialogue as Verbal Dance

Romantic dialogue lives on what is NOT said. The gap between
what the lead feels and what the lead can articulate IS the
tension. Every charged conversation between the leads is a
dance of advance and retreat, what's risked and what's
withheld.

Working principles:

- **Holding back gives resonance.** Characters should express
  attraction through everything EXCEPT direct declaration in
  Acts 1 and most of 2: banter, deflection, teasing,
  over-attentiveness, deliberate avoidance. The reader should
  feel the accumulated pressure of chapters of restraint
  before the words are finally spoken.

- **Each character speaks distinctly** — the reader should
  identify who is talking without dialogue tags. Voice
  Differentiation (in Character Rules) enforces this
  quantitatively.

- **Conversations are verbal dances**, not exchanges of
  information. Push and pull, advance and retreat, what's
  risked and what's withheld.

- **Characters sometimes make things WORSE when trying to
  make them better.** They hide things when the listener can
  sense it anyway. They explain when silence would have
  been kinder. The most powerful exchanges happen when both
  leads are disturbed by the depth of their feelings and
  cannot quite articulate it.

- **The unsaid carries weight.** A dialogue beat ending on a
  half-finished sentence, an answered question that wasn't
  asked, a deflected return — these are the load-bearing
  moves of romantic dialogue.

- **Beat-by-beat power shifts.** Each exchange should shift
  the dynamic between the leads, even slightly. If a long
  dialogue stretch leaves the leads in the same emotional
  position they started in, cut or rewrite.

### Method Writing Emotional Target Protocol

Identify what you want the reader to FEEL before writing any
key scene. The emotion is the destination; everything else is
the route.

The protocol:

1. **Name the target emotion before writing.** Longing? Joy?
   Heartbreak? Recognition? Nervous anticipation? Quiet
   gratitude? Be specific. "Sad" is not enough; "the specific
   sad of realising you've outgrown the version of yourself
   you used to love" is.

2. **Build every detail toward that emotional target.**
   Sensory choices, sentence rhythm, dialogue beats, what
   the POV character notices and what they don't —
   everything in the scene either serves the target or
   should be cut.

3. **Write through the senses.** Put the reader in the
   POV's shoes. What is the love interest's proximity doing
   to the POV's breathing? What is the exact sensation of
   accidental contact? What does the room smell like
   precisely now? Sensory specificity is what carries
   emotional truth.

4. **If you can't feel it as you write it, the reader
   won't either.** This is the diagnostic. If a key
   emotional scene doesn't move the writer, something is
   blocking the feeling — usually the prose has gone
   abstract (concept-words instead of sensory detail), or
   the character build is not specific enough yet, or the
   target emotion was never named.

5. **Lean INTO emotion fully.** When writing a climactic
   declaration, let the prose break a little. Let it
   become heightened. The clean, controlled rhythm of
   ordinary scenes does not serve the moment when something
   that has been held back for 300 pages finally comes out.

6. **Never be cynical.** Don't manufacture a crisis or a
   breakup purely to provoke tears. Don't kill someone off
   to manipulate the reader. Genuine emotion earned through
   character investment is what creates readers who laugh
   and cry with the story; cynicism reads on the page and
   the reader withdraws.

### Sex Scene Craft (Open Door — Spice 3-5 only)

For projects rated Spice:0-2, this section does not apply (see
heat-calibration.md for the calibration that does). For Spice:
3-5 projects, every sex scene must do narrative work, not
exist for titillation alone.

Working principles:

- **The scene must reveal something about the couple's
  dynamic.** What shifts in the power balance, the trust,
  the emotional landscape? If the answer is "nothing," cut
  or rewrite. Sex scenes that are emotionally inert are
  scaffolding, not story.

- **Ask before writing: what is the scene saying about
  THIS couple at THIS point in their arc?** Not "is this
  hot." Hot follows from emotional truth; emotional truth
  does not follow from hot.

- **Write through sensory experience, not anatomy.**
  Touch, taste, smell, sound, sight — engage all of them.
  Anatomical naming pulls the reader out of the narrative;
  pure euphemism reads as porn-adjacent purple. Strike a
  balance between clinical detachment and purple excess.

- **Awkwardness > choreographed perfection.** The best
  intimate scenes have humour, nervousness, or emotional
  rawness alongside desire. Real intimacy is imperfect.
  The leads' specific selves — their wounds, their
  vulnerabilities, their voice differentiation — must be
  visible during the scene as they would be during any
  other scene.

- **Build into the emotional landscape.** Sex scenes
  should feel like a natural culmination of accumulated
  tension, not isolated set pieces. The lead-in beats
  earn the scene; the after-shot beats give it
  consequence.

- **Consequences considered.** Emotions after, relationship
  impact, what one of them thinks the next morning — the
  scene continues past the act itself.

- **Consent must be enthusiastically and unambiguously
  shown** — checking in, boundaries respected, both
  participating actively. Coercion-coded power dynamics,
  ignoring resistance, drunk consent, ambiguous "yes" all
  fail the genre's contract with the reader.

### Obstacle Layering (Quantitative)

Romance lives or dies by its obstacles. A single obstacle is
never enough to sustain a full novel. Quantitative working
minimums:

  Act 1: At least 2 obstacles introduced and active by
         Chapter 5. At least one MUST be internal (a wound,
         a fear, a self-sabotage pattern). At least one MUST
         be external or societal.

  Act 2: At least 3 obstacles active simultaneously by the
         midpoint. Each new obstacle must intensify the
         reader's yearning, not merely add complication.
         Obstacles introduced and then forgotten count
         against the manuscript and must be either resolved
         on-page or visibly carried forward.

  Act 3: All major obstacles addressed by climax — no
         hand-waving. Each resolution must be character-
         driven (the leads earn it through growth) rather
         than circumstantial (an off-page event removes the
         obstacle for them).

Obstacle taxonomy:

  **Internal** — fear of vulnerability, past wound, self-
    sabotage pattern, commitment phobia, shame, internalised
    family pattern. The engine of modern romance.

  **External** — geography, careers, family opposition,
    rivals, financial pressures, custody arrangements,
    immigration status. Provides the plot framework.

  **Societal** — class, faith, cultural expectation, period-
    appropriate constraint, professional ethics rules. Does
    less work in contemporary settings; more in historical,
    forbidden, and small-town subgenres.

Every active obstacle gets at least one mention every 4
chapters. Obstacles that go silent for longer have effectively
been forgotten and the reader stops believing them.

### Light and Shade (Heart-Monitor Rule)

Two scenes of the same emotional register in a row either
overwhelm the reader or cancel each other out. Alternate the
emotional register chapter by chapter — chart the highs and
lows like a heart monitor.

Working rules:

- After a devastating scene, the next scene offers
  unexpected warmth — humour, a small kindness, a moment
  of connection (need not involve the love interest).
- After a blissful couple scene, the next scene introduces
  a complication that crashes the leads' hopes.
- Two devastating scenes back-to-back: the reader becomes
  numb. Cut, condense, or insert a contrasting beat
  between them.
- Two blissful scenes back-to-back: the reader becomes
  bored. Same fix.
- Black humour is a powerful tool in heavy material.
  Characters in dire situations often deploy humour as a
  coping mechanism — let them. The contrast amplifies both
  the heaviness and the lightness.
- Even within a single chapter, register can shift. A
  funny opening to a chapter that ends in heartbreak hits
  harder than a chapter that is heartbreak from start to
  finish.

The heart-monitor pattern applies to the manuscript as a
whole AND to act-level rhythm. Plot a chapter-by-chapter
emotional register graph during outlining and flag any
stretch of 3+ same-register chapters for revision.

### The Differentiation Imperative

The romance market is dense and the trope ground is well-
walked. Every romance manuscript has to answer ONE question
before it earns a reader's commitment: what makes THIS love
story different from the thousands already on the shelf?

The differentiator is not the trope (enemies-to-lovers,
fake-dating, second-chance, marriage-of-convenience). The
trope is the room. The differentiator is what specifically
lives in this room that does not live in the others.

Six axes of differentiation:

1. SETTING SPECIFICITY — not "small town" but THIS specific
   small town with this specific industry, weather, racial
   composition, generational story; not "London" but THIS
   specific neighbourhood at THIS specific moment in its
   history
2. CENTRAL DILEMMA — not "they can't be together" but the
   specific named dilemma (her job depends on his
   company's collapse; his daughter is dying; her religious
   community would shun her)
3. CHARACTER CONFIGURATION — not the typical pairing for
   the trope but a specific deviation (the second-chance
   romance where she's now his employer; the fake-dating
   romance where one is a widow and one is a widower; the
   enemies-to-lovers romance where one is the lawyer
   prosecuting the other)
4. STRUCTURAL DEVICE — dual timeline, epistolary,
   mockumentary, retrospective, multi-POV with one POV
   delayed; the formal architecture itself reframing the
   tropes
5. THEMATIC AXIS — the love story examines something
   specific the trope does not usually examine (grief,
   long-term illness, neurodivergent intimacy, immigrant
   identity, post-imperial reckoning, climate anxiety)
6. VOICE — the narrative voice itself so distinctive that
   the book is unmistakable from sentence one (the
   confessional first-person, the wry omniscient, the
   close-third with a specific dialect inflection)

CALIBRATION TEST
Before drafting, the writer must be able to complete this
sentence in two-to-three specific sentences: "This love
story is different from the others in [trope] because
___." If the answer is generic ("it has heart") or vague
("the characters are well-developed"), the manuscript has
not earned its differentiation and the idea must marinade
further.

ANTI-PATTERNS
- Pure trope replication (the manuscript is identifiable
  only by its trope)
- Differentiation announced but not delivered (the pitch
  promises the new angle, the prose does not render it)
- Differentiation in setting only without character or
  dilemma differentiation
- The "different" that turns out to be the same with a
  surface change (small-town romance in a trendy
  location without specifically rendering that location)
- The pitch that takes more than three sentences (the
  difference is not yet sharp enough)

### Hope-as-Resolution Calibration (Expanding HEA/HFN)

The genre's defining promise is HEA (Happily Ever After) or
HFN (Happy For Now). Most romance projects must deliver one
of these. But masterclass romance writing recognises a
third position the genre permits in specific circumstances:
the HOPEFUL ending.

The HOPEFUL ending is when the central romance does NOT
resolve in conventional union — a lead dies, leaves, or
chooses something other than the relationship — but the
manuscript ends in a place of genuine, earned hope for the
surviving lead's life, identity, or future capacity to
love. This ending is rare, controversial, and reserved for
projects whose contract with the reader is explicitly
larger than HEA/HFN.

When the Hopeful Ending is APPROPRIATE:
- When the romance is in service of a larger thematic
  question that demands a non-conventional resolution (a
  story about grief, terminal illness, impossible
  circumstance, irreconcilable identity)
- When the central conflict is structurally irreconcilable
  in any way that satisfies the reader's intelligence
- When the manuscript signals from the early chapters that
  the genre's typical resolution is not on the table

When the Hopeful Ending is INAPPROPRIATE:
- For category romance, romcom, romantasy, sweet/clean
  romance, or any sub-genre where HEA/HFN is the genre's
  enforceable contract
- As a cop-out for an obstacle the manuscript could have
  earned its way past
- As a "literary" gesture grafted onto a genre romance
  framework whose readers expect HEA/HFN

The Hopeful Ending must satisfy three requirements:
1. EARNED — the impossibility of the conventional ending
   must be established, not announced; the reader must
   understand WHY the romance cannot resolve in union
2. SPECIFIC — the hope at the end must be SPECIFIC for the
   surviving lead (a named choice, a named direction, a
   named recovery); generic "she would be okay" is not
   enough
3. RESONANT — the ending must feel inevitable in
   retrospect; if the reader thinks "they could have just
   resolved this," the ending has failed

ANTI-PATTERNS
- The "literary" hopeful ending grafted onto category
  romance (genre-contract violation; reader rebellion)
- The hopeful ending that arrives without earning its
  impossibility (reader feels betrayed)
- The hopeful ending that is actually a sad ending in
  disguise (ending without hope is not hopeful — it is
  sad; the genre permits hope, not sorrow)
- The hopeful ending where the survivor's specific future
  is left vague (the genre demands specificity in the
  hope, not just the survival)

For projects committed to HEA/HFN, this section's primary
service is one of CONTRAST: the conventional ending must
be earned with the same specificity and inevitability the
hopeful ending demands. Both endings ride the same craft
discipline: the resolution must feel both surprising and
inevitable, must demonstrate character growth, and must
satisfy the genre's promise on its specific terms.

### Series Architecture (Multi-Book Romance)

A romance series is not the same as a romance novel. Each
book in a series must satisfy the genre's contract on its
own terms, but the series itself requires architectural
discipline beyond what a single novel demands.

THE THREE PATTERNS:

1. NEW-COUPLE-PER-BOOK (the most common)
   - Each book features a different central couple within
     the same fictional world
   - The world (small town, found family, billionaire
     dynasty, sports league, supernatural community)
     carries continuity
   - Previous-book couples appear as supporting characters
     in subsequent books
   - Standard for contemporary romance series, romcom
     series, romantic suspense series, paranormal-romance
     series
   - Architectural requirement: the world must be
     established with enough texture in book 1 that it can
     sustain 5-10+ books without the world feeling
     exhausted

2. SAME-COUPLE-NEW-OBSTACLE
   - The same central couple across multiple books
   - Each book introduces a new obstacle architecture (a
     pregnancy crisis; a career relocation; a betrayal; a
     long-buried secret returning; a child's illness)
   - Standard for celebrity-romance series, marriage-in-
     crisis series, dual-timeline series
   - Architectural requirement: each new obstacle must be
     SPECIFIC and STRUCTURAL — not "they fight, they make
     up, they fight, they make up"; each obstacle must
     reframe the relationship in a way book 1 did not
   - Risk: false-conflict (obstacle invented to fill space
     rather than to test the relationship in a new way)

3. SAME-COUPLE-DEEPENING-WOUND
   - The same central couple (or single protagonist with a
     romance arc) across multiple books
   - Each book reveals a deeper layer of the wound
     established in book 1; the relationship is the same,
     but the reader's understanding of it transforms
   - Standard for literary-leaning series, character-
     interior series (book 1: meeting and loss; book 2:
     grief; book 3: reconstruction of identity beyond the
     loss)
   - Architectural requirement: the wound established in
     book 1 must be deep enough that each subsequent book
     reveals a layer, not the same layer twice
   - Risk: stagnation (the same emotional ground re-
     trodden without progression)

CALIBRATION QUESTIONS

Before committing to a series:
- Is the central character growing or remaining static
  across the books? (Series can sustain either, but the
  decision is foundational and cannot drift mid-series)
- What is the series-level question the books are
  collectively asking? (The thread that makes the books
  belong together rather than just share a world)
- What is the series ending shape? (How many books, what
  is the final resolution, when is the contract complete)
- Does each individual book deliver HEA/HFN/Hopeful on
  its own, or does the series-as-whole deliver one
  ending? (Reader expectation must be set early and
  honoured throughout)

ANTI-PATTERNS
- The series that is not actually a series (each book is
  a standalone with no shared world or thread)
- The series where the same obstacle resolves in book 1
  and is then re-deployed unchanged in book 2
- The series with no clear ending in sight (the
  manuscript drifts; the writer's commitment becomes
  obvious to the reader; the reader's investment
  collapses)
- The series-by-publisher-demand without authorial
  commitment to the architecture (cynical continuation;
  the prose loses the energy of book 1; the reader
  feels the thinning)
- The standalone novel retro-fitted to series (the
  ending of book 1 was earned-and-final; the sequel must
  un-earn it to create new conflict; the reader feels
  betrayed by the un-earning)

### Romance AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "electricity coursed through her at his touch" | Show the specific physical reaction without the cliché |
| "her heart skipped a beat" | Show the specific physical disruption. breath caught, step faltered |
| "their eyes locked across the room" | Show what specifically draws her attention |
| "butterflies erupted in her stomach" | Show the specific nervous behaviour |
| "she couldn't deny the attraction" | Show the specific moment of weakness or surrender |
| "his voice sent shivers down her spine" | What about his voice? Pitch, cadence, specific words? |
| "the tension between them was palpable" | Show the specific charged moment. proximity, almost-touch |
| "she tried to ignore the way he made her feel" | Show the specific avoidance behaviour |
| "their chemistry was undeniable" | Show the specific interaction that creates chemistry |
| "he was unlike anyone she'd ever met" | Show the specific trait that surprises her |
| "her walls came crumbling down" | Show the specific moment she lets someone in |
| "he looked at her like she was the only person in the room" | Show the specific focus through his behaviour |

## Genre-Specific Revision Rules

### Pass 1: Chemistry Audit
Read every scene between the leads aloud. Does the tension escalate? Does each encounter advance the relationship? Flag any scene where the leads interact without emotional stakes shifting. Check that physical attraction is grounded in specific, character-consistent details rather than generic beauty descriptions.

### Pass 2: Emotional Arc Consistency
Map the emotional journey beat by beat. Verify the internal conflict deepens before it resolves. Check that emotional breakthroughs don't regress without cause. Ensure each character's wounds are consistently referenced and gradually healed through the relationship.

### Pass 3: Conflict Authenticity Check
Examine every obstacle keeping the couple apart. Is it genuine or manufactured? Would a five-minute honest conversation resolve it? If so, rewrite. The conflict must be rooted in character psychology, values, or external circumstances. never in simple miscommunication alone.

### Pass 4: Intimacy Pacing Review
Chart the physical and emotional intimacy progression. Verify it escalates naturally without jarring leaps or plateaux. Check that intimate scenes (at whatever heat level) reveal character and advance the relationship rather than existing as set pieces.

### Pass 5: HEA/HFN Satisfaction Test
Read the final three chapters in isolation. Does the resolution feel earned? Does it address the central conflict established in Act One? Would a romance reader close the book satisfied that these characters will stay together? The ending must deliver on the promise the opening made.

### Pass 6: Differentiation + Earned-Hope + Series Integration

This pass is the romance integration check at the
manuscript level — it ties the differentiation, ending
calibration, and series architecture together and verifies
the manuscript honours its specific commitments.

For DIFFERENTIATION: at the manuscript level, audit the
two-to-three sentence answer to "what makes this love
story different?". Is it specific (named axes — setting /
dilemma / character configuration / structural device /
theme / voice)? Is it delivered in the prose, not just
the pitch? Could a reader complete the differentiation
sentence after finishing the manuscript with the same
content the writer intended? If no — the differentiation
is in the writer's head but not on the page, and must be
rebuilt across whichever scenes have been carrying
generic-trope weight rather than specific-rendering
weight.

For EARNED-HOPE: at the ending level, audit which ending
shape the manuscript is delivering (HEA / HFN / Hopeful).
For HEA/HFN, is the ending earned through specific
character growth and obstacle resolution, or is it
delivered by an off-page event or hand-waved through? For
the Hopeful ending, is the impossibility of the
conventional ending established and specific, and is the
surviving lead's hope specific and resonant? If the
ending shape was promised to the reader through the
genre's contract, has the manuscript honoured it? If a
different shape is being delivered, has the manuscript
earned the deviation through its full architecture, not
just through a final-chapter pivot?

For SERIES (if applicable): if the manuscript is the
first in a planned series, has the world / wound / arc
been established with enough texture to sustain
subsequent books without exhaustion? If the manuscript
is book 2 or later, is the new obstacle architecture
genuinely structural rather than re-treading book 1's
ground? Has the series-level question been visibly
advanced, not just the book-level plot? Is the series
ending shape on track to resolve within the planned
arc? The series-by-drift failure mode is caught here —
if the writer cannot articulate where the series ends
and what the final resolution looks like, the series
may have lost its architectural commitment and must be
reset.

## Names & Patterns to Avoid

### Forbidden Patterns
- **Instalove without buildup**. Attraction at first sight is fine; declarations of undying love by chapter three without earned emotional foundation is not
- **Miscommunication as sole conflict**. If the entire plot would collapse with one honest conversation, the conflict is too weak to sustain a novel
- **The perfect love interest**. Characters without flaws, contradictions, or genuine obstacles create flat romantic dynamics
- **The makeover revelation**. "She took off her glasses and he suddenly noticed she was beautiful". lazy, reductive, and dated
- **Love triangle as delay tactic**. If the third party exists solely to create jealousy rather than genuinely challenging the protagonist's desires, cut them

### Cliché Setups to Refresh or Avoid
- The billionaire who's emotionally unavailable (without genuine psychological depth)
- The "not like other girls" heroine who is exactly like every other romance heroine
- The rival love interest who is cartoonishly unsuitable
- The best friend who's been secretly in love (without any prior textual evidence)
- The "I can fix him" dynamic without genuine character agency

### Naming Considerations
- Avoid names that are too similar between leads (Jake and Jane, Mason and Macon)
- Avoid surnames that signal ethnicity inconsistent with the character's established background
- Hero names should feel distinct from heroine names in rhythm and sound. the reader should never confuse who is speaking
- Avoid trendy names that will date the book within five years unless the contemporary setting demands it

British English spelling throughout.

## Comp Titles

Romance's comp-title set supports manuscript positioning:
market category placement, cover-design conversation,
reader-expectation calibration, similar-author discovery,
and editorial / agent submission framing.

### Canonical (foundational reference points)

- *Pride and Prejudice* — Jane Austen (1813): the foundational marriage-plot novel; modern romance's structural ancestor.
- *Wuthering Heights* — Emily Brontë (1847): obsessive love and class friction; the dark-romance lineage's origin.
- *Outlander* — Diana Gabaldon (1991): time-travel historical romance with full HEA architecture; bridges historical and contemporary.
- *The Notebook* — Nicholas Sparks (1996): the contemporary-classic romance; sad-but-hopeful ending; cross-demographic appeal.
- *Me Before You* — Jojo Moyes (2012): the masterclass example of romance with non-conventional ending; HEA / HFN / Hopeful calibration in practice.

### Contemporary (current best-in-class)

- *The Hating Game* — Sally Thorne (2016): enemies-to-lovers contemporary romcom; modern category-romance template.
- *The Wedding Date* — Jasmine Guillory (2018): contemporary romance with strong voice and cross-cultural specificity.
- *Red, White & Royal Blue* — Casey McQuiston (2019): LGBTQ+ romance crossover hit; political-stakes integration.
- *Beach Read* — Emily Henry (2020): contemporary romance with literary-adjacent voice; the new commercial standard.
- *People We Meet on Vacation* — Emily Henry (2021): friends-to-lovers contemporary; voice-led modern romance.
- *Carrie Soto Is Back* — Taylor Jenkins Reid (2022): commercial fiction with romance arc; Reid's literary-commercial sweet spot.
- *Book Lovers* — Emily Henry (2022): meta-romance with publishing-industry framing.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. Dominates the BookTok era; hand-drawn or digital illustration of couple in romantic pose. Works across all contemporary romance subgenres and is currently the strongest-selling cover style.
- **Photorealistic**. Real-model photography with soft lighting and warm tones. Best for steamy contemporary romance where heat level is a selling point. Signals mature content.
- **Typographic**. Title-dominant design with decorative or script fonts, minimal imagery. Works for established authors or when the title itself is the hook. Clean, professional, bookshop-friendly.
- **Minimalist**. Simple iconography or symbolic single image with strong typography. Effective for literary romance or upmarket crossover titles where the cover needs to signal "not just genre fiction."

### Genre Cover Aesthetics
- **Styles:** Warm and inviting compositions, soft-focus backgrounds, intimate couple poses, dreamy lighting, cozy settings (coffee shops, autumn streets, beach sunsets)
- **Colours:** Blush pink, warm gold, soft lavender, dusty rose, champagne. warm tones that signal emotional warmth and romantic intimacy. Avoid cold blues or harsh neons.
- **Elements:** Couples embracing or in close proximity, flowers (especially peonies and roses), hearts (subtle, not childish), seasonal motifs (autumn leaves, fairy lights, cherry blossoms), cozy interiors
- **Typography:** Script and handwritten fonts for titles are genre-standard. Serif fonts for author names. The font style is a PRIMARY genre signal. romance readers identify covers by typography before imagery. Swashes, ligatures, and decorative flourishes are expected.

### Subgenre Variations
- **Steamy/Erotic Romance:** Skin-forward photorealistic covers, shirtless torsos, bolder colour palettes (deeper reds, golds), larger author names
- **Sweet/Clean Romance:** Illustrated or minimalist, softer colours, no skin, more scenery and symbolic imagery, wholesome compositions
- **Small Town Romance:** Illustrated style with charming town settings, warm autumn/winter palettes, cozy elements (porches, dogs, pickup trucks)
- **Billionaire/CEO Romance:** Photorealistic, urban sophistication, dark suits, city skylines, metallic accents (silver, gold), sleek typography
- **Second Chance Romance:** Nostalgic tones, sepia-tinged warmth, dual-timeline visual cues, emotional compositions

### Market Positioning
Romance is the largest genre on Amazon and the most visually competitive. Covers must instantly communicate subgenre, heat level, and tone at thumbnail size. Illustrated covers currently outperform photorealistic for discoverability on social media (BookTok, Bookstagram). Typography must be readable at thumbnail. title and author name legible at the smallest display size. Series branding through consistent colour palettes and layout is critical for building readership. The cover must answer the reader's question in under two seconds: "Is this the kind of romance I'm looking for?"

### Cover Design DON'Ts
- Dark, gritty, or horror-adjacent aesthetics. signals wrong genre entirely
- Cold clinical design with harsh whites and sterile compositions
- Overly busy compositions that obscure title and author at thumbnail
- Childish or cartoonish hearts and cupids (unless specifically targeting a playful rom-com market)
- Stock photography that looks generic or dated. readers recognise overused images instantly
- Neon or electric colour palettes. these signal sci-fi, thriller, or YA, not romance
- Tiny, illegible typography. romance readers browse by cover and the title must pop
- Male gaze compositions that objectify without emotional context. romance covers sell connection, not just bodies
