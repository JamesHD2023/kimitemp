---
name: mandatory-pipeline-rules
description: "Ideorix Fiction mandatory pipeline rules (NON-NEGOTIABLE). File Operation Policy + Rules 1-10. Extracted from SKILL.md in v2.7.53 to slim the eager-load surface; loaded as a Tier-1 reference at session start. These rules override speed, momentum, and user impatience; violations caused real damage in production."
version: "2.7.53"
user-invocable: false
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix** — The Manuscript & Screen Engine
> *© James Harvey Media. All rights reserved.*


# MANDATORY PIPELINE RULES — Ideorix Fiction (NON-NEGOTIABLE)

These rules override ALL other considerations including speed, momentum,
and user impatience. They exist because violations caused real damage in
production.

## File Operation Policy (MANDATORY — self-contained, does NOT depend on core-pipeline.md)

> **Kept in sync with `core-pipeline.md` § File Operation Policy** (the
> full authoritative version). Any change there MUST be applied to this
> extract in the same commit — the duplication is deliberate resilience,
> drift between the copies is not.

**THE WRITE TOOL IS NOT RELIABLE FOR FILE PERSISTENCE.**

First documented April 2026 (last verified May 2026): the Claude Desktop
virtiofs mount silently drops Write tool calls to subdirectory paths.
The Write tool reports success but files do not reach the user's disk.
If this is no longer reproducible in your environment, see the v2.7.42
File Operation Policy split for the current contract — bash side-file
+ mv-swap remains REQUIRED for Class 1 (new file creation) regardless.
This policy is self-contained — it does NOT reference core-pipeline.md
because core-pipeline.md may not be loaded at runtime.

**Critical-path files (this protocol applies to ALL of these):**
- `engine-data/pipeline-checkpoint.md`
- `engine-data/reports/ch{NN}-verification.md`
- `engine-data/reports/ch{NN}-outline-conformance.md`
- `engine-data/reports/ch{NN}-humaniser-notes.md`
- `engine-data/reports/batch-{N}-edit.md`
- `engine-data/market-pulse.md`
- `engine-data/story-bible.md`
- `engine-data/chapter-briefs/ch{NN}-brief.md`
- `engine-data/chapters/ch{NN}.md`
- `engine-data/summaries/ch{NN}-summary.md`
- `engine-data/entity-canon.md`
- `engine-data/running-banlist.md`
- `engine-data/model-health.md`
- `engine-data/run.log`

**Write protocol for critical-path files (MANDATORY):**

```bash
# 1. Set the target path explicitly so it can be reused for the temp path.
TARGET={target-path}

# 2. Write content to a TEMPORARY file in the SAME FILESYSTEM as the
#    target. Cross-device mv (e.g., /tmp → workspace mount) is non-atomic —
#    copy+unlink falls back when the filesystems differ, and in some
#    sandboxes (Cowork: /tmp vs. /sessions/.../mnt/) the unlink step is
#    denied with "Operation not permitted". Net result: silent overwrite-
#    failure where the source lands in /tmp but the target is unchanged,
#    AND step 6's `stat -c %s` returns the OLD size on overwrite-failure
#    (a fresh operator can read it as success if not vigilant about mv's
#    exit code). Same-FS rename is POSIX-atomic and works everywhere.
TMP="${TARGET}.tmp.$$"
cat > "$TMP" << 'PAYLOAD_EOF'
{content}
PAYLOAD_EOF

# 3. Move atomically (within the same filesystem — replaces inode,
#    bypasses virtiofs caching).
mv "$TMP" "$TARGET"

# 4. Force filesystem sync.
sync

# 5. Verify existence.
ls -la "$TARGET"

# 6. Verify byte count (catches zero-byte ghosts and truncation).
ACTUAL=$(stat -c %s "$TARGET")
if [ -z "$ACTUAL" ] || [ "$ACTUAL" = "0" ]; then
    echo "ERROR: write failed for $TARGET (actual bytes: '$ACTUAL')"
    exit 1
fi
```

If step 4 or 5 fails, the write did not persist. Re-run from step 1.
Only after byte-count verification passes, update the pipeline
checkpoint field to Yes. The checkpoint update ITSELF is a critical-
path write — apply the same protocol to it.

**Do NOT use the Write tool for any critical-path file.**
**Do NOT use the Edit tool for any critical-path file.**
**Do NOT use the Read tool to verify existence** (it loads content
and pins to Sources panel — use Bash ls instead).
**Do NOT dispatch to a subagent for any step that writes a critical-
path file** (subagent writes may not propagate to the user's
filesystem).

Write tool is permitted ONLY for non-critical transient files (scratch
notes, temporary working files not referenced by the checkpoint).

**These rules summarize and extend `core-pipeline.md`.** If any conflict
exists between a rule here and the detailed specification in
`core-pipeline.md`, this file's version takes precedence because it is
guaranteed to be loaded at runtime (Tier-1 always-load).

**Stale bash-mount troubleshooting (occasional; harness-level):**

In some sandboxed environments the bash workspace's view of the user's
Documents folder can become stale relative to the harness's view —
Edit/Write tool calls reach disk through the harness, but the bash
mount sometimes doesn't invalidate its cache. Symptom: `Read` tool
shows the chapter at (say) 3,785 words; `wc -w` from bash on the same
file shows 2,407 words. The two disagree because bash is reading a
snapshot.

**Diagnostic — one command tells you the answer:**

```bash
# Compare bash word count against the harness-reported size.
echo "bash sees: $(wc -w < {chapter-path}) words"
# If this is dramatically lower than what the Read tool just showed,
# the bash mount is stale.
```

**Workaround (works without restart):**

1. Write the live chapter content to a fresh path under `/tmp/` or
   under a different subdirectory of the project — somewhere the stale
   bash cache hasn't pinned. The harness writes through; bash reads
   cleanly from the new path.
2. Run audits / exports / mechanical checks against the fresh path.
3. The canonical chapter file at the original path is still correct
   (harness wrote through; it's just bash's *view* that was stale).
   The Read-tool verification you've already done is sufficient
   evidence.

**Or restart the session.** Restart is safe — files on disk persist
through the harness; restarting only flushes the cached bash view.
Nothing on disk is lost (chapter file, .docx, project-config,
checkpoint, all persist). After restart, `wc -w` should match what
`Read` shows.

**Why this matters for the pipeline:** while the mount is stale, any
bash-based audit (`word-count-check.sh`, `formatting-check.sh`,
`manuscript-audit.sh`, the orchestrator, the Pre-Flight gate) will
read the stale view and may report false-FAIL — "below 90% target",
"file truncated", "missing terminal punctuation" — on a chapter that
is in fact complete. If a chapter passes a Read-tool word-count
sanity check but fails a bash audit with a much-lower count, suspect
a stale mount before suspecting the chapter.

## Rule 1: 6-Agent Verification Suite After EVERY Chapter

After writing each chapter, you MUST run ALL 6 verification agents:
Continuity Guardian, Quality Guardian, Timeline Keeper, Character
Tracker, Arc Analyst, Dialogue Guardian. This is the 6-AGENT
VERIFICATION SUITE — it is NOT the same as the post-writing checks
(word count, placeholders, em-dashes, AI-isms). Series projects add a
7th agent (Series Continuity Guardian). Canon Validator runs separately
as a gate (pass/fail, not scored).

**Typography normalization (MANDATORY — runs FIRST, before the agents).**
Freshly-generated prose routinely contains ASCII straight quotes, `--`, and
`...` (the model's default output), which would otherwise only be caught at
export by the pre-export typography gate. Do NOT rely on the model having
typed curly typography, and do NOT hand-write a converter. Immediately after
the chapter's final prose write (Writer → Humaniser → optional Craft
Improver), deterministically normalize it:

```bash
python3 scripts/typography-fix.py "engine-data/chapters/ch{NN}.md"
```

It converts straight→curly quotes (directional open/close, apostrophes and
elisions), `--`→em-dash, `...`→ellipsis, skipping YAML frontmatter, fenced
code blocks, and scene-break lines, and writes via a temp + atomic rename.
**Skip this step ONLY** when the project sets `typography_target: ascii` or
`typography_status: skip | legacy` in `project-config.md`. With this step,
chapters are curly from the moment they are written — the pre-export
typography gate becomes a confirmation that passes, not a fix to scramble for.

**Agent names and scoring are LOCKED (DO NOT SUBSTITUTE):**

| Agent | Score Range |
|---|---|
| Continuity Guardian | 0–100 |
| Quality Guardian | 0–100 |
| Timeline Keeper | 0–100 |
| Character Tracker | 0–100 |
| Arc Analyst | 0–100 |
| Dialogue Guardian | 0–100 |

Scoring is NUMERIC (0–100), not PASS/FAIL. V-Score is the weighted
average.

**V-Score formula:**
```
Standard (6):  Cont×0.20 + Qual×0.15 + Time×0.15 + Char×0.20 + Arc×0.15 + Dial×0.15
Series (7):    Cont×0.15 + Qual×0.15 + Time×0.10 + Char×0.15 + Arc×0.10 + Dial×0.15 + Series×0.20
```

**Formula Selection (MANDATORY):**

Read `engine-data/project-config.md` field `series_position`:

- `series_position: standalone` → use **Standard (6-agent)** formula
- `series_position: starter` or `series_position: continuation` or
  any non-standalone value → use **Series (7-agent)** formula; the
  7th agent is the Series Continuity Guardian, loaded from
  `series-conventions.md`

If `project-config.md` is missing the field, treat as standalone and
log a warning: "series_position not set in project-config; defaulting
to standalone". The user must set this explicitly for series projects.

Canon Validator is a GATE (pass/fail), not a scored agent. It can block
the chapter but does not contribute to V-Score. Show its verdict on the
dashboard as a separate line: "Canon: PASS / FAIL".

**Post-writing checks (word count, formatting) ≠ Verification (6-agent suite).**
Completing post-writing checks does NOT satisfy the verification requirement.

**Mechanical audit scripts (MANDATORY — run BEFORE the 6 agents):**

After post-writing checks and before the 6 creative agents, run the
mechanical audit suite:
```bash
bash scripts/ideorix-audit.sh {chapter-file} {project-path} {target-words}
```
Append the script output to `engine-data/reports/ch{NN}-verification.md`.
The mechanical audit catches objective violations (forbidden words,
em-dash counts, pattern frequency, word count, entity canon drift) that
the model agents approximate. The 6 creative agents receive the script
output as given facts and focus on semantic judgement only.

After all 6 agents run:
1. Calculate the weighted V-Score using the formula above
2. Save the report (including mechanical audit output) to
   `engine-data/reports/ch{NN}-verification.md` using the bash-direct
   write protocol from the File Operation Policy
3. Verify with `ls -la` + `stat -c %s` (existence + non-zero bytes)
4. Display the Progress Dashboard with ALL 6 numeric scores, the
   mechanical audit summary, Canon Validator verdict, running V-Score
   average, word count, and progress bar
5. Update the pipeline checkpoint
   Overall: {N}/100 | Running avg: {N}/100
   ```
6. Update the pipeline checkpoint (Bash ls verified before marking Yes).
7. Present the approval gate. Do NOT auto-display the full chapter prose
   after the dashboard — the user already saw it during the Humaniser
   pass. Offer "Read chapter in full" as an approval-gate option.

**If you skip this step, errors compound across chapters.** In
production, skipping verification caused timestamp contradictions,
character count errors, and repeated chapter endings that required
retroactive fixes across 6 chapters.

## Rule 1b: Class B Delta Pass (Per-Chapter, runs after 6-Agent Verification Suite)

After the 6-Agent Verification Suite + mechanical audit complete
and BEFORE the Progress Dashboard renders, run the per-chapter
Class B Delta Pass via the validate dispatcher in delta mode:

```bash
bash scripts/validate-dispatcher.sh --delta --chapter {NN} "{project-root}"
```

This dispatches the two per-chapter Class B subagent audits:

- **`leitmotif-tracker-delta`** (COHERENCE domain) — scans this
  chapter for new motif instances, compares against the running
  `engine-data/reports/leitmotif-ledger.md`, flags PRESENCE-MISS
  or EVOLUTION-FLAT findings.
- **`injury-accumulation-delta`** (PHYSICS domain) — scans this
  chapter for new injuries / recoveries / actions, compares
  against the running `engine-data/reports/injury-ledger.md`,
  flags CAPABILITY-VIOLATION or RECOVERY-IMPLAUSIBLE findings.

Both audits use the v2.7.32 Class B dispatch protocol (CLASS_B_AUDIT
marker line → engine layer dispatches subagent → HARD GATE on
return → merge verdict). See `leitmotif-tracker-delta.md` and
`injury-accumulation-delta.md` for the audit specs.

**Why per-chapter, not end-of-manuscript:** motif drift and injury
continuity violations are cheap to fix at write-time and expensive
to retro-revise after subsequent chapters depend on the broken
state. Per-chapter delta catches each divergence the moment it
lands; the full-manuscript versions still run at Phase 5 Stage 9.5
(Canon Validation Sweep) for final-arc verification.

**Verdict handling.** Findings surface on the Progress Dashboard
alongside the V-Score but do NOT block chapter approval — the
writer chooses whether to revise now or carry forward. Two other
Class B audits (humanity-gate, intent-preservation) do NOT run
per-chapter because they need manuscript-scope evidence; they run
once at Stage 9.5 only.

**Cost discipline.** Two extra subagent dispatches per chapter
(~30 dispatches for a 30-chapter epic + 4 at Stage 9.5 = ~64 total
vs the pre-v2.7.61 pattern of 4 at Stage 9.5 only). The catch-cheap
trade-off justifies the cost; if a project needs to opt out, append
`class_b_delta_status: skip` to `engine-data/project-config.md` (the
dispatcher honours the declaration and skips per-chapter delta runs;
Stage 9.5 still runs as the safety net).

## Rule 2: Pre-Flight Check Before Every New Chapter

Before starting the Architect for Chapter N+1:
1. Read `engine-data/pipeline-checkpoint.md`
2. Confirm the previous chapter has ALL fields completed (Brief, Written,
   Saved, Verified, Humanised, Report Saved, V-Score, Summary)
3. If ANY field is missing: STOP and complete it before proceeding

**Pre-Flight file reconciliation (MANDATORY — do NOT skip):**

Before trusting checkpoint fields, reconcile each "Yes" against disk:
```bash
ls -la {file referenced by that field}
stat -c %s {file referenced by that field}
```
If the file is missing or zero bytes: flip the checkpoint field back
to "No", log to `engine-data/run.log`, alert the user, and re-run the
failed step before allowing Chapter N+1 to start.

- If `OC Location: separate`, also verify
  `engine-data/reports/ch{N-1}-oc-detail.md` exists with non-zero
  bytes. If missing, treat the checkpoint as unreliable and STOP.

Pre-Flight passes ONLY when every field is "Yes" AND every referenced
file passes existence + non-zero-byte checks on the actual filesystem.

**Gate enforcement (MANDATORY):**

Before generating Chapter N, run:

```bash
bash scripts/pre-flight-gate.sh "{project-root}" {chapter-N}
```

The gate checks: Story Bible exists, pipeline-checkpoint.md exists,
prior-chapter summary or "Chapter N-1: complete" marker present (when
N > 1), and (warning only) entity-canon.md present after chapter 3.
If the gate exits non-zero, STOP. Resolve the missing prerequisite
(complete the prior chapter, write the summary, append the checkpoint
line, etc.) and re-run the gate. Only when the gate exits zero may
the Architect begin Chapter N. See `pre-flight-gate.sh` for the
exact checklist.

**Legacy opt-out:** for manuscripts that pre-date Cowork Phase 3 and
whose chapters were written without the pre-flight checklist existing,
append to `engine-data/project-config.md`:

```
pre_flight_status: legacy
pre_flight_legacy_through: <highest legacy chapter>   # optional cap
```

The gate honors the declaration and passes. Without
`pre_flight_legacy_through`, all chapters pass; with the cap, only
chapters ≤ N pass under the legacy banner — chapter N+1 onward must
satisfy the real checklist.

## Rule 3: Progress Dashboard + Agent Scores After Every Chapter

The user MUST see a formatted dashboard with:
- **ALL 6 individual agent scores** (Continuity, Quality, Timeline,
  Character, Arc, Dialogue — numeric 0-100, not PASS/FAIL)
- **Canon Validator verdict** (PASS/FAIL — separate from V-Score)
- **Mechanical audit summary** (from bash scripts — forbidden words,
  em-dashes, pattern counts, word count)
- **Running average V-Score** across all completed chapters
- Word count (actual vs target, with deviation %)
- Issue counts (critical / moderate / minor)
- Beat delivery status
- Progress bar ({N}/{total} chapters)
- Outline Conformance verdict
- Canon Drift status

If the user does not see individual agent scores AND a running average,
the dashboard is incomplete and verification has FAILED regardless of
what happened internally. A dashboard with only a total score and no
per-agent breakdown is a failure. This is the user's primary evidence
that quality is being tracked across the manuscript.

## Rule 4: Never Offer to Skip Verification

Do NOT offer "skip future reviews" or suggest batching verification.
Do NOT treat post-writing checks as verification. The 6-agent suite
runs per-chapter, automatically, without the user needing to request it.

## Rule 5: Voice Profile Loaded for ALL Manuscripts

Load the POV Voice Profile from Story Bible Section 3 for EVERY chapter
— single-POV and multi-POV alike. The Architect, Writer, and Quality
Guardian all need it. Single-POV manuscripts need voice profiles to
prevent drift across 30+ chapters.

**Gate enforcement (MANDATORY, v2.7.65+):**

The POV Voice Profile from Story Bible Section 3 is the LLM-contract
piece. The artifact-level piece is `engine-data/voice-profile.md` —
the calibration corpus the audit pipeline measures against. Before
any chapter is generated, the voice-profile-preload-gate (invoked
as Check 6 of pre-flight-gate.sh) verifies the file exists and
contains the required fields:

```bash
bash scripts/voice-profile-preload-gate.sh "{project-root}"
```

This blocks chapter generation if `voice-profile.md` is missing,
empty, or skeleton-only (no `fp_target:`, no
`voice_calibration_exemplar:`, no `voice_prose_description:`). See
`references/voice-profile.md` for the canonical template.

**Why this is gated, not just a contract:** voice drift in long-form
fiction is a well-documented failure mode — close-third gradually
widens into omniscient, first-person slips into summary, period
register flattens into generic literary prose. v2.7.64 and earlier
enforced voice loading purely as an LLM contract; the user's
parallel non-fiction series diagnostic showed catastrophic drift
even under that contract. The artifact-level gate makes the
calibration corpus a verifiable precondition, and the new
`voice-metrics-audit.sh` + `voice-trend-audit.sh` modules (run
automatically as Modules 8-9 of `ideorix-audit.sh`) measure the
chapters against it so drift gets caught at write-time, not at
publication.

**Documented opt-outs:** append to `engine-data/project-config.md`:

```
voice_profile_status: legacy   # manuscript pre-dates v2.7.65
voice_profile_status: skip     # voice-consistency not a deliverable
voice_trend_status: skip       # disable cross-chapter drift audit
voice_trend_status: legacy     # pre-v2.7.65 voice-metrics data
```

The gates honor the declaration and pass.

**Restoration workflow (v2.7.66+):** when the trend audit FAILs and a
chapter needs rewriting, the user can invoke the Voice Restoration
Brief — a per-chapter Class B diagnostic that produces a structured
rewrite plan (paragraph classification, target-voice exemplar
quotes, rewrite hints, risk callouts). The brief never rewrites
prose; the writer rewrites by hand using it as the guide. Trigger:

```bash
bash scripts/validate-dispatcher.sh "{project-root}" restore {N}
```

See `references/voice-restoration-brief.md` for the full audit
contract.

**Higher-fidelity drift signal (v2.7.67+):** the v2.7.65 fp_ratio is
a syntactic proxy ("paragraphs containing first-person pronouns /
total paragraphs"). It catches catastrophic drift but produces
false-INFO/WARN on chapters with legitimately recessed narrator-
voice (extended quoted dialogue, exposition-heavy passages). The
paragraph-classifier audit produces a per-paragraph semantic
classification (ANCHOR-NARRATIVE / ANALYTICAL-AUTHOR /
EXPOSITORY-THIRDPARTY / DIALOGUE / META-STRUCTURAL); voice-metrics-
audit reads the classifier artifact when present and emits a
semantic_fp_ratio (FP-presence within narrator-voice paragraphs
only) alongside the existing fp_ratio. The trend audit prefers
semantic when ≥3 of the window's chapters have it. Trigger:

```bash
bash scripts/validate-dispatcher.sh "{project-root}" classify {N}
```

Run once per chapter (typically before invoking the restoration
brief, so the brief can use the pre-computed classification as a
starting point). The artifact persists at
`engine-data/reports/validate/paragraph-classifier-ch{NN}-subagent.md`
and is automatically picked up by voice-metrics-audit's next run.
See `references/paragraph-classifier.md` for the full audit contract.

Phase 5 Stage 14 (auto-rewrite when drift is detected) is deferred
to v2.7.68 or beyond — auto-rewrite touches prose and is held until
the brief workflow has been used in practice and rewrite patterns
are well-understood.

## Rule 6: Batch Deep Edit Every 5 Chapters (MANDATORY)

After completing Chapter 5, 10, 15, 20, 25 (and the final chapter),
you MUST run the Batch Editor (see `batch-editor.md`) across the last
5 chapters BEFORE starting the next chapter. This is not optional. It
catches:
- Cross-chapter voice drift
- Accumulating AI-isms the per-chapter humaniser missed
- Pacing flatlines across the batch
- Prose quality degradation
- Continuity drift between chapters

The Batch Editor produces a Batch Health Report. This report MUST be
displayed to the user and saved to
`engine-data/reports/batch-{N}-edit.md` (Bash ls verified).

**Trigger logic:** The Batch Edit Gate at step 18 of `core-pipeline.md`
checks whether the current chapter is divisible by 5 OR is the final
chapter. If yes, the Progress Dashboard CANNOT display until the batch
edit completes. This is a fail-closed gate — the engine cannot skip
it.

**Gate enforcement (MANDATORY):**

Before rendering the Progress Dashboard for any chapter, run:

```bash
bash scripts/batch-edit-gate.sh "{project-root}" {chapter-N} {total-chapters}
```

If the gate exits non-zero, STOP. Do not render the dashboard. Run
the batch editor per `batch-editor.md`, append
`Batch Edit {N}: complete ({timestamp})` to
`engine-data/pipeline-checkpoint.md` using the bash-direct write
protocol, then re-run the gate. Only when the gate exits zero may the
dashboard render.

This replaces the prior honor-system instruction with a concrete
exit-code check the engine cannot silently bypass.

Do NOT say "Would you like me to run the batch edit?" or "I can run a
batch review if you'd like." Just run it. The batch edit is as
mandatory as the Humaniser or verification agents.

## Rule 7: Full Manuscript Editorial Pass After Final Chapter

After the FINAL chapter is written, verified, and batch-edited, you
MUST run the full Phase 5 Editorial Pipeline (see `editorial-suite.md`).
This is the complete 14-stage manuscript-wide editorial pass
(stage numbering and order are canonical per `editorial-suite.md`):

0. Voice Profile → 1. Genre Audit → 2. Proofreader → 3. Copy Editor →
4. Dev Editor → 4.5 Repetition Sweep (conditional, ≥40K words) →
5. Alpha Reader → 6. Beta Reader → 7. Conflict Resolution →
8. Apply Top Fixes (surgical) → 9. Continuity Audit → 9.5 Canon
Validation Sweep (post-fix re-verification gate) → 10. Multi-POV Pass
(if applicable) → 11. Intimate Scene Review (if applicable) →
12. Revision Loop (if scores below threshold) → Publication Readiness
Assessment

This is NOT the same as per-chapter verification. Per-chapter checks
each chapter individually. The editorial pass reviews the ENTIRE
manuscript as a whole — catching issues that only become visible at
manuscript scale (arc completeness, thematic throughline, overall
pacing, cross-chapter voice consistency, unresolved plot threads, gun
payoff verification).

Do NOT proceed to Phase 6 (Delivery) without completing the editorial
pass. Do NOT offer to skip it. The editorial pass is the difference
between a draft and a publishable manuscript.

**Phase 6 gate sweep (MANDATORY — v2.7.68+):**

Phase 6 covers cover design, marketing pack, KDP metadata, and
launch sequencing. v2.7.67 and earlier enforced these as
LLM-contract rules — Claude was supposed to follow the
cover-designer / marketing-expert / publishing-formats specs,
but nothing verified at the artifact level. The result (from a
parallel non-fiction user report): covers generated as 3D product
renders instead of book covers; marketing briefs that omitted the
cover-image section entirely; KDP metadata uploaded with
half-completed fields.

v2.7.68 closes this with five new gates:

```bash
bash scripts/cover-brief-gate.sh           "{project-root}"  # cover concept structured per cover-designer.md
bash scripts/marketing-pack-gate.sh        "{project-root}"  # marketing-brief.docx + 5 core sections + cover dependency
bash scripts/kdp-metadata-gate.sh          "{project-root}"  # KDP file present + 7 keywords + 3 BISACs + comps + pricing
bash scripts/pre-export-typography-gate.sh "{project-root}"  # source typography clean (pairs with v2.7.64 post-write DOCX gate)
bash scripts/launch-readiness-gate.sh      "{project-root}"  # composite meta-gate: all four + manuscript export
```

Each gate fails closed when its precondition is unmet and prints
a specific diagnostic + ACTION. The launch readiness gate is the
single command for "is this project ready to ship?" — it chains
the four constituent gates plus a manuscript-export check.

**Documented opt-outs:** append to `engine-data/project-config.md`:

```
cover_status: legacy | skip                 # cover design out of scope
marketing_status: legacy | skip             # marketing pack out of scope
kdp_status: legacy | skip                   # KDP submission out of scope
typography_status: legacy | skip            # bypass typography sweep
typography_target: ascii                    # project deliberately uses ASCII typography
launch_readiness_status: legacy | skip      # bypass the composite meta-check
```

The gates honor each declaration and pass. Use sparingly —
each opt-out is a documented decision that voice / cover /
marketing / KDP isn't a deliverable for this specific project.

## Rule 8: ALWAYS Run Market Scout Before Story Bible (MANDATORY)

Before generating the Story Bible, ALWAYS run Market Scout to assess
the current marketplace — bestsellers, gaps, reader demand, trending
tropes, comparable titles, and positioning opportunities. Save the
report to `engine-data/market-pulse.md` and present key findings to
the user BEFORE Story Bible generation begins.

If the Outline Builder already ran Market Scout during its process,
skip this step (the report already exists). If the user provided their
own outline, run Market Scout NOW — do NOT skip it because the user
"already has an outline."

**Offline fallback:** If web search is unavailable (restricted network,
offline mode, or web search returns errors), write a minimal
`engine-data/market-pulse.md` with:
```
STATUS: offline — market scout skipped (no web access)
Date: {iso8601}
```
Then use AskUserQuestion to confirm: "Market Scout requires web access,
which is currently unavailable. Continue without market intelligence?"
This keeps the file existing (satisfies downstream `ls` checks) and
makes the skip auditable. The Story Bible proceeds without market data.

**Record the status in the project config (MANDATORY):**

After creating the offline stub, append these lines to
`engine-data/project-config.md` using the bash-direct write protocol:
```
market_intelligence_status: offline
market_intelligence_last_attempt: {ISO-8601 timestamp}
```

**Retry path:** At any later point, the user can say "re-run Market
Scout" to re-attempt. If successful, overwrite `market-pulse.md` and
update `market_intelligence_status: live` +
`market_intelligence_last_run: {timestamp}` in `project-config.md`.

**Dashboard flag:** While `market_intelligence_status` is `offline`,
every Progress Dashboard must include a visible line:
`Market intelligence: OFFLINE — retry when online`.

**Why:** Market intelligence informs the Story Bible, trope
integration, and strategic positioning. Without it, the manuscript is
built blind to what's currently selling and what gaps exist.

**Gate enforcement (MANDATORY):**

Before any downstream action that depends on market intelligence
(cover design, marketing pack, KDP prep, launch sequencing), run:

```bash
bash scripts/market-scout-gate.sh "{project-root}" [staleness-days]
```

Default staleness cap is 180 days. If the gate exits non-zero
(`market-pulse.md` missing or older than the cap), STOP. Re-run Market
Scout to refresh `engine-data/market-pulse.md`, then re-run the gate.
Only when the gate exits zero may the downstream action proceed. See
`market-scout-gate.sh` for the exact check.

**Documented opt-out:** if web search is unavailable, the project
pre-dates Rule 8, or the staleness is acknowledged and won't be
refreshed before launch, append one of these lines to
`engine-data/project-config.md`:

```
market_intelligence_status: offline   # web search unavailable
market_intelligence_status: stale     # last live run > cap, no refresh planned
market_intelligence_status: legacy    # project pre-dates Rule 8
```

The gate honors the declaration and passes. This matches the v2.3.5
Market Scout opt-out convention used elsewhere in the engine (offline
fallback, retry path, dashboard flag).

## Rule 9: ONE Chapter at a Time — User Approval Required (MANDATORY)

**Write chapters sequentially, ONE at a time.** After each chapter
completes its full cycle (Architect → Writer → Humaniser →
Verification → Dashboard), present the completed chapter to the user
and WAIT for approval before starting the next chapter.

**Do NOT:**
- Offer to write multiple chapters at once ("Shall I write chapters 3-5?")
- Auto-continue to the next chapter without user approval
- Batch-generate chapters to "save time"
- Skip the approval step between chapters for any reason

**Each chapter must complete this cycle before the next begins:**
1. Architect generates the chapter brief → user approves
2. Writer generates prose → user reviews
3. Prose Humaniser runs
4. 6-agent verification runs → scores displayed
5. User approves the chapter OR requests revision
6. Pipeline checkpoint updated
7. WAIT for user to say "continue" / "next chapter" / equivalent

**Why:** Chapter-by-chapter approval ensures the user maintains
creative control. Batch generation removes the user from the loop and
produces chapters that compound errors without correction.

## Rule 10: Outline Conformance Report MUST Exist Before Brief is Shown (MANDATORY)

The Outline Conformance Agent (see `outline-conformance.md`) is the
engine's ONLY brief-time verifier — it runs at Phase 3 step 5a, BEFORE
the chapter brief is presented to the user at the User Review Gate
(step 6).

**The rule:** You MAY NOT present any chapter brief to the user until
`engine-data/reports/ch{NN}-outline-conformance.md` has been written
to disk AND verified with Bash `ls` per the File Operation Policy in
core-pipeline.md.

**Do NOT:**
- Skip step 5a because the brief "looks obviously aligned with Section 12"
- Narrate the conformance check and proceed to step 6 without actually
  running the agent
- Present the brief and the conformance report in the same message
  while silently skipping the agent run (a hallucinated report is a
  worse failure than a missing one)
- Treat a clean-looking brief as evidence that the check can be skipped

**Required execution order for EVERY chapter:**
1. Architect generates the draft brief (step 5)
2. Outline Conformance Agent runs against the draft (step 5a)
3. Audit footer appended to the brief at `engine-data/chapter-briefs/ch{NN}-brief.md`
   (or separate report file at `engine-data/reports/ch{NN}-oc-detail.md`
   on FAIL overflow — see `outline-conformance.md` for the
   consolidation v1 IDEORIX:AUDIT footer protocol)
4. Update the pipeline checkpoint: OC Report = Yes, OC Verdict = PASS/WARN/FAIL
5. ONLY THEN present the brief + the verdict to the user (step 6)

Do NOT Read the brief file or report file back to "confirm it exists"
(see File Operation Policy — Trust the Write Tool in `core-pipeline.md`).
The checkpoint's `OC Report = Yes` row is the cross-chapter source of
truth that step 5a completed; do not re-verify via Read-back.

**Why this rule exists:** In production, the Outline Conformance Agent
was specified as "MANDATORY, BLOCKING" at step 5a but was skipped on a
Chapter 12 brief. The skipped check would have caught a Story Bible
Mythology Discipline violation (a new bloodline-resonance mechanism
that contradicted the Bible's explicit "the connection is implied,
never explained" rule). The user caught the violation manually, but
the whole point of the OC Agent is that users should NOT have to catch
drift themselves. The check must actually run, every time, before the
brief is shown — and its verdict must flow through the pipeline
checkpoint to the post-chapter Progress Dashboard so the user has
visible confirmation that it ran.

**Enforcement:** The pre-flight check before starting Chapter N+1 reads
the pipeline checkpoint and refuses to start a new chapter if Chapter
N shows `OC Report: No` or `OC Verdict: -`. See `core-pipeline.md`
Pre-flight Check protocol.

**Gate enforcement (MANDATORY):**

After Chapter N is complete and before advancing to Chapter N+1, run:

```bash
bash scripts/outline-conformance-gate.sh "{project-root}" {chapter-N}
```

The gate passes when either
`engine-data/reports/outline-conformance-{N}.md` exists and contains
`Status: PASS`, OR `engine-data/pipeline-checkpoint.md` contains a
line of the form `Outline Conformance {N}: complete`. If the gate
exits non-zero, STOP. Run the Outline Conformance verifier on chapter
N (or append the checkpoint marker if the verifier already ran), then
re-run the gate. Only when the gate exits zero may Chapter N+1 begin.
See `outline-conformance-gate.sh` for the exact check.

**Legacy opt-out:** Rule 10 was added to catch drift between the
Architect's chapter brief and the manuscript outline at *brief
generation time*. For manuscripts that were written before Rule 10
existed, retrospective OC reports catch nothing — the chapters are
already written, fact-checked, and humanised. Append to
`engine-data/project-config.md`:

```
outline_conformance_status: legacy
outline_conformance_legacy_through: <highest legacy chapter>   # optional cap
```

The gate honors the declaration and passes. With
`outline_conformance_legacy_through: 21`, chapters 1-21 pass under
the legacy banner; chapter 22 onward must produce a real OC report.
