---
name: upmarket-fiction-genre
description: Genre-specific instructions for upmarket fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [literary, contemporary]
---

# Upmarket Fiction. Genre Plugin

## Metadata
- id: upmarket
- name: Upmarket Fiction
- icon: 📚
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Save the Cat"]

## Subgenre Options
Present during setup:
- **Upmarket Book Club**. Emotionally resonant, discussion-worthy stories with literary prose and commercial hooks; the sweet spot between awards and bestseller lists
- **Upmarket Suspense**. Literary prose quality meets a compelling mystery or thriller plot; the stakes are high AND the sentences are beautiful
- **Upmarket Historical**. History rendered with literary grace and commercial momentum; big emotions, vivid settings, satisfying narrative arcs
- **Upmarket Family**. Family dynamics with literary depth and commercial accessibility; the complexity of literary fiction with the emotional payoff of book club picks
- **Upmarket Social**. Contemporary social issues explored through compelling characters and polished prose; important AND entertaining

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: The literary-commercial sweet spot. every chapter has forward momentum (commercial DNA) AND depth of observation (literary DNA)
- Must open with: A hook that works on TWO levels. a compelling situation (pulls the reader forward) AND a distinctive voice (makes them want to stay)

BEATS PER CHAPTER
1. Hook Beat. Something compels forward reading: a question raised, a tension introduced, a mystery deepened
2. Depth Beat. A moment of observation, interiority, or thematic resonance that rewards attention
3. Relationship Beat. Human connection tested, revealed, or complicated
4. Plot Advancement Beat. The story moves: a decision, a revelation, a consequence
5. Resonance Beat. An image, line, or moment that lingers after the chapter ends

UPMARKET ARCHITECTURE
- DUAL ENGINE: literary quality AND commercial momentum; neither dominates
- PROSE is elevated but ACCESSIBLE: the reader should admire the writing without needing to re-read sentences
- PLOT is present and compelling: things HAPPEN; this is not purely interior
- CHARACTER is primary: deeply drawn, complex characters driving a story that matters
- THEME is woven, not stated: big questions explored through specific human experiences
- The ENDING must satisfy: upmarket fiction can be ambiguous in tone but not in resolution; the reader needs to feel the story has been COMPLETED
- POV: First person or close third (the intimacy of literary fiction with the clarity of commercial)

THE SWEET SPOT
- Literary fiction asks "How do we live?" Upmarket fiction asks that question AND tells a good story
- Commercial fiction hooks you with plot; upmarket fiction hooks you with plot AND makes you think
- The prose should be quotable (literary credential) but the pages should turn (commercial credential)
- Think: the kind of book reviewed in newspapers AND discussed in book clubs AND optioned for film

FORBIDDEN IN UPMARKET FICTION
- Literary pretension: complexity for its own sake, obscurity as a substitute for depth
- Commercial shortcuts: thin characters, predictable twists, emotional manipulation
- Prose that's merely competent (upmarket demands MORE than correct grammar and clear sentences)
- Plotless interiority (literary fiction can wander; upmarket must MOVE)
- Theme delivered as message (the reader should discover the meaning, not be handed it)
- Endings that feel unearned: either too tidy (fairy tale) or too open (literary evasion)
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection, Revelation (primary engines for upmarket — readers expect literary depth), Captivation.

VOICE & TONE
- POV: First person or close third past (the dominant upmarket voices)
- Voice: Distinctive, intelligent, WARM. the reader should want to spend time with this narrator
- Tone: Emotionally resonant without being sentimental; thoughtful without being pretentious
- Register: Accessible literary. a reader who doesn't normally read literary fiction should still enjoy this

PROSE IMPERATIVES
- THE QUOTABLE SENTENCE: at least one sentence per page that a reader would underline
  - This doesn't mean purple prose. it means PRECISION: the perfect word, the unexpected image, the true observation
  - "She had the kind of face that looked best in photographs, where the camera caught what people in conversation missed.". Specific, true, reveals character
- INVISIBLE CRAFT + VISIBLE ART: the storytelling machinery is invisible; the language is visible
  - The reader doesn't notice the structure (commercial DNA)
  - The reader does notice the prose (literary DNA)
  - The balance: never sacrifice clarity for beauty, but always seek beauty within clarity
- EMOTIONAL INTELLIGENCE: the prose understands feelings with sophistication
  - Complex emotions named precisely
  - The body as emotional instrument (literary technique in service of reader connection)
  - Sentiment without sentimentality: the reader feels deeply because the observation is TRUE, not because the prose is manipulative
- SCENE ARCHITECTURE: every scene does triple duty
  - Advances plot (what happens?)
  - Reveals character (what does it show us?)
  - Develops theme (what does it mean?)
  - If a scene can't do at least two of three, cut or rewrite it

PROSE RHYTHM MAPPING
- Ch 1 hook: Commercial pace + literary polish. hooks AND impresses
- Prose rhythm: Cleaner than literary, richer than commercial
  - The prose should feel effortless (which means it's very carefully constructed)
- Sentence length: 14-22 words average
  - Varied for effect but never calling attention to the variation
- Metaphor density: 1 per 400 words (restrained. precision, not decoration)
- Interiority: Moderate and precise. enough depth without losing momentum
  - Every interior moment must also advance the story
- Dialogue: Frequent and sharp. literary quality at commercial pace
  - Every exchange advances the scene; no filler
- Tension: ≥5 for Ch 1
- Paragraph rhythm: Medium (3-5 sentences)
  - Brisk transitions; depth woven into momentum, not paused for
  - The reader should feel "one more chapter" pull from paragraph 1

DIALOGUE CRAFT
- Smart, specific, character-revealing. dialogue in upmarket fiction is literary quality at commercial pace
- Every exchange advances the scene (no filler dialogue)
- Subtext: what's not said matters, but the reader should be able to follow without a decoder ring
- Distinctive voices: each character sounds like themselves, not like the author
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

UPMARKET CRAFT (40% of total):
- Prose is elevated AND accessible (literary quality, commercial clarity)? (0-100)
- Plot has genuine forward momentum (things happen, stakes matter)? (0-100)
- Characters are deeply drawn AND compelling (you want to know what happens to them)? (0-100)
- The dual engine works (literary and commercial DNA both present)? (0-100)

STORY CRAFT (30% of total):
- The story is complete and satisfying (the ending earns its resolution)? (0-100)
- Theme is woven through story, not stated as message? (0-100)
- Scenes do triple duty (plot + character + theme)? (0-100)
- Pacing maintains momentum without sacrificing depth? (0-100)

PROSE QUALITY (30% of total):
- At least one quotable line per page (precision, truth, beauty)? (0-100)
- Emotional precision without sentimentality? (0-100)
- Voice is distinctive, warm, and intelligent? (0-100)
- Dialogue is smart, specific, and character-revealing? (0-100)

AUTOMATIC FAILS (score = 0):
- Prose is merely competent (correct but not distinctive)
- Plot is absent or inert (nothing compelling happens)
- Literary pretension (obscurity mistaken for depth)
- Commercial shortcuts (thin characters, manipulative emotion)
- Theme delivered as lecture
- Ending is unearned (too tidy or too open)
```

## Continuity Rules

```
UPMARKET FICTION CONTINUITY. WHAT TO TRACK

CHARACTER STATE:
- Internal arc: the protagonist's psychological journey, tracked chapter by chapter
- Relationships: current status, recent developments, building tensions
- Knowledge: what each character knows and when they learned it
- Emotional trajectory: the reader should be able to trace the emotional arc clearly

PLOT STATE:
- Story questions: what has been asked and what's been answered
- Foreshadowing: planted details that need payoff
- Tension threads: multiple simultaneous sources of tension, each advancing
- Reveals: what's been revealed, what's still hidden, what the reader suspects

THEMATIC STATE:
- Which thematic elements have been introduced and developed
- Image patterns: recurring images and their evolving significance
- How the theme has been complicated (not just restated)
- The theme should deepen, not just repeat

PROSE CONTINUITY:
- Voice consistency: the narrative voice should feel like the same person throughout
- Metaphor families: if you're using water imagery, track it; don't suddenly switch to fire
- Tone: consistent within the manuscript's range (if it's darkly comic, it stays darkly comic)
```

## Character Rules

```
UPMARKET CHARACTER CONSTRUCTION

THE PROTAGONIST:
- Literary depth: complex, contradictory, fully interior
- Commercial appeal: sympathetic (or at least compelling), active, someone the reader roots for
- A rich inner life that the reader shares
- Flaws that create plot problems (literary) and that the reader forgives (commercial)
- An arc that is both subtle (literary) and satisfying (commercial)

SUPPORTING CHARACTERS:
- Each is specific enough for a reader to remember (commercial)
- Each carries thematic weight (literary)
- They challenge the protagonist and create genuine conflict
- They have enough independence that the reader wonders about their off-page lives

THE ANTAGONIST:
- May be a person, a system, or an internal conflict
- If a person: understandable motivation, not cardboard villainy
- Creates genuine stakes: the reader should worry about the outcome
- Thematically connected to the protagonist's central question

VOICE:
- The protagonist's voice is the book's primary literary asset
- Supporting characters each have distinct speech patterns
- The balance: characters sound real (literary) and memorable (commercial)
```

## Arc Rules

```
UPMARKET STORY STRUCTURE

ACT 1: THE HOOK (first 25%)
- Open with voice AND situation: the reader is both intrigued and immersed
- Character and world established with efficiency and depth
- The central question is posed (thematic) and the central problem is introduced (plot)
- Relationships established with enough specificity to create investment
- END OF ACT 1: A clear turn. the protagonist is committed to a course of action

ACT 2A: DEEPENING (to midpoint)
- Plot complications that ALSO deepen character and theme
- Relationships tested and revealed under pressure
- The prose delivers its richest observations (the reader is invested enough to appreciate depth)
- Forward momentum maintained: each chapter ends with a reason to continue
- MIDPOINT: A revelation or reversal that reframes everything

ACT 2B: COMPLICATIONS (midpoint to dark moment)
- Stakes escalate on all levels: plot, character, theme
- The protagonist's flaws create consequences
- Relationships fracture or transform
- The thematic question becomes personal and urgent
- DARK MOMENT: The protagonist faces the full truth; the resolution requires genuine choice

ACT 3: RESOLUTION (final 25%)
- The pace accelerates: the story rushes toward resolution
- The climax satisfies on ALL levels: plot resolves, character transforms, theme crystallises
- The ending is both surprising and inevitable (literary) and satisfying (commercial)
- A final image or line that the reader carries with them
- The book should make the reader want to DISCUSS it (the book club test)

UPMARKET PACING:
- Every chapter has a hook and a turn (commercial pacing)
- Depth is woven into momentum, not paused for (literary integration)
- The reader should feel "one more chapter" pull throughout
- The final third accelerates: literary depth in fewer, more intense moments
```

## Timeline Rules

```
UPMARKET FICTION TIMELINE

FLEXIBLE TIMELINE:
- Duration matches the story: weeks, months, or years
- Track time precisely: the reader should always know roughly when they are
- Time jumps are clean and clear (signalled, not sneaked)

REVELATION TIMELINE:
- Track what the reader knows vs. what the characters know
- Plant-and-payoff timing: foreshadowing should pay off within a satisfying window
- Mystery elements: clues and red herrings in deliberate order
```

## Genre-Specific Craft Techniques

Upmarket fiction occupies the most contested territory in
commercial publishing — the sweet spot where literary craft
and commercial momentum meet, where a Backman, an Owens, a
Patchett, a Doerr, a Hannah, a Yanagihara, a Bennett, a
Makkai, a Garmus, a Zevin, a Picoult-at-her-most-literary, a
Maggie O'Farrell, a Liane Moriarty, a Karen Joy Fowler, a
Brit Bennett, a Rebecca Makkai, a Matt Haig, a Jess Walter
can land on awards longlists AND bestseller tables in the
same season. The genre is defined by its dual contract:
prose that rewards close reading without demanding it, plot
that compels page-turning without insulting the reader,
characters that feel literarily true and commercially
memorable, themes that emerge from specific human experience
rather than being announced as message. The most common
failure modes in this register are: **Pretension Trap**
(literary technique deployed without literary necessity —
complexity for its own sake, obscurity mistaken for depth,
sentence-level showboating that asks the reader to admire
effort rather than experience truth), **Plot-Inertness**
(deep characters rendered in elevated prose with nothing
actually happening — the literary half of the contract
delivered, the commercial half abandoned), **Theme-Lecture**
(the novel's meaning announced rather than discovered —
characters articulating thematic insights they would not
naturally articulate, narration stepping forward to clarify
what the reader is supposed to take away), **Ambiguity-as-
Sophistication** (endings left unresolved on the assumption
that resolution is commercial and unresolution is literary —
but upmarket endings RESOLVE; the resolution can be complex,
ambiguous in tone, even painful, but the story must feel
completed), **Sentimentality** (emotional manipulation
through prose effort rather than emotional precision through
observed truth — the difference between "her heart broke as
she watched him leave" and the specific image, gesture, or
interior detail that earns the reader's tears), and
**Prose-as-Decoration** (purple writing that calls attention
to itself — metaphors that don't earn their keep, similes
that prefer beauty over truth, sentences the writer admires
more than the story needs). The techniques below are
designed to keep both halves of the dual contract live:
literary craft visible enough to satisfy the upmarket
reader, commercial momentum strong enough to keep them
turning pages.

### The Dual-Level Opening

Every chapter opening works on two levels:

```
COMMERCIAL ONLY (hooks but doesn't impress):
"The letter arrived on a Tuesday, and by Wednesday,
everything Sarah knew about her family was wrong."

LITERARY ONLY (impresses but doesn't hook):
"Tuesdays had the particular quality of being no day
at all, a non-day wedged between the promise of Monday
and the mid-week acknowledgment of Wednesday."

UPMARKET (hooks AND impresses):
"The letter arrived on a Tuesday, which felt right
somehow. bad news needs a nothing-day, a day with no
identity of its own, so the news can become the only
thing that happened."
```

### The Triple-Duty Scene

Every significant scene advances plot, reveals character, AND develops theme:

```
Scene: Sarah confronts her mother about the letter
- PLOT: The confrontation reveals that the mother knew
  the truth and chose to hide it (story advances)
- CHARACTER: Sarah's anger is tempered by seeing her
  mother's fear. she's not a villain, she's a woman
  who made a desperate choice (character deepens)
- THEME: The scene asks: when does protection become
  control? When does a family secret become a family lie?
  (theme crystallises)
```

### The Quotable Line

Upmarket prose should produce lines readers share:

```
NOT QUOTABLE (correct but forgettable):
"She felt like she didn't really know her mother at all."

QUOTABLE (precise, true, memorable):
"She'd spent thirty-seven years knowing her mother the
way you know a room you've never turned the lights on in
.  by feel, by memory, by the furniture you've bumped
into enough times to navigate around."
```

### Upmarket Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "she grappled with the implications" | Show the specific implication through her decision |
| "the intersection of [theme] and [theme]" | Show the specific moment where both themes collide |
| "it raised uncomfortable questions" | Show the specific question through the specific event |
| "the moral complexity was staggering" | Show the specific moral dilemma |
| "she was forced to confront" | Show the specific confrontation through action |
| "the nuances were important" | Show the specific nuance |
| "it wasn't black and white" | Show the specific grey area through one character's choice |
| "the conversation shifted to deeper waters" | Show the specific deeper topic through dialogue |
| "society's expectations weighed heavily" | Show the specific expectation and specific weight |
| "a meditation on [theme]" | Show the theme through action, not announce it |
| "the layers of meaning" | Show ONE layer through one scene |
| "she carried the weight of [abstraction]" | Show the specific weight through the body, the choice, the small refusal |
| "the years had taught her" | Show what the years taught her through the specific moment of recognition |
| "their relationship was complicated" | Show the specific complication through one revealing exchange |
| "she found herself contemplating" | Cut "found herself"; just write the thought |
| "in the quiet of her thoughts" | Cut the framing; let the thought speak |
| "the stillness of the moment" | Show what is still: the held breath, the unmoving hand |
| "she felt the familiar pang of [emotion]" | Show the specific pang through specific physical or behavioural detail |

### The Resonant Image System

Upmarket fiction returns to specific concrete images
across the novel and lets them accumulate meaning. This
is different from literary symbolism (image as theme
delivery) and different from commercial recurring motifs
(image as branding). The upmarket image is specific,
sensory, character-rooted, and grows in significance
through repetition rather than through narration.

```
REQUIREMENTS
1. The image is SPECIFIC, not abstract. Not "the past"
   but "the locked drawer in her mother's bedroom"
2. The image is SENSORY. The reader can see, hear,
   touch, smell, or taste it
3. The image RECURS at deliberate intervals — roughly
   3-5 times across the manuscript, each time with
   slightly more weight or a different angle
4. The image MEANS MORE each time without the
   narration explaining what it means. The reader
   builds the meaning
5. The image PAYS OFF. The final return is the most
   loaded — resolution carried in the image rather
   than narrated

EXAMPLE (resonant image system at work)
Image: the kitchen window above the sink

First appearance (Ch 2):
"She washed dishes by the window because the view of
the garden made it bearable."

Mid-book (Ch 14):
"She stood at the kitchen window long after the dishes
were done, watching nothing in particular, except that
nothing in particular had become the only thing she
could bear to watch."

Late (Ch 26):
"The new owners had moved the sink. The window now
opened onto a brick wall. She had not realised, until
this moment, that she had been measuring her life in
that view."

The image accumulates without the narration ever
saying "the window represented her sense of escape".
The reader does the work — that's the upmarket
contract.

ANTI-PATTERNS
- The image announced ("the window had become a
  symbol of her freedom")
- The image overused (returning every chapter so it
  becomes mechanical)
- The image abstract ("the past kept returning to her")
- The image without sensory specificity ("she
  remembered her childhood")
```

### The Reading-Group Question Architecture

Upmarket fiction must pass the BOOK CLUB TEST: the
novel should generate 8-12 genuine discussion
questions without the writer having engineered them as
such. This is achieved by building genuine moral
complexity, ambiguity in choice, and thematic
plurality into the story's architecture. The book club
test is not a post-hoc check — it shapes the
construction of the novel.

```
REQUIREMENTS
1. AT LEAST ONE CENTRAL DECISION the protagonist makes
   that readers will genuinely disagree about. Not
   "should she leave him" with an obvious answer, but
   a choice where reasonable readers will land in
   different places
2. AT LEAST ONE CHARACTER whose moral status the
   reader is invited to reconsider — the "antagonist"
   who has genuine reasons; the "ally" whose help
   comes with strings; the "victim" whose passivity is
   itself a choice
3. AT LEAST ONE PLOT QUESTION that resolves on plot
   level but remains open thematically. e.g. she got
   the job — but should she have wanted it? She left
   him — but did she leave for the right reason?
4. AT LEAST ONE THEMATIC THREAD that the novel
   complicates without resolving. The reader leaves
   the book asking the question, not having received
   the answer
5. ENOUGH SPECIFICITY that book clubs can argue from
   evidence. Vague themes generate no discussion;
   specific scenes generate hours

ANTI-PATTERNS
- Pre-engineered "discussion questions" delivered
  through on-page debate (characters articulating both
  sides)
- Themes so universal they generate no genuine
  disagreement ("family is complicated")
- Resolutions so tidy that the only book club question
  is "did you like it?"
- Ambiguity so total that there's nothing to argue
  about (everyone is left equally lost)
```

### The Dual-Audience Calibration

Upmarket fiction writes to TWO readers simultaneously:
the literary reader (who picks up the book for the
prose, the depth, the craft) and the commercial reader
(who picks up the book because it's the book everyone's
reading, the prize-winner, the book club pick). The
prose must be accessible to the commercial reader and
rewarding to the literary reader — neither sacrificed,
both served.

```
REQUIREMENTS
1. SENTENCE-LEVEL: the sentence should be readable on
   a beach AND quotable in a review. Clarity is
   non-negotiable. Beauty is layered on clarity, not
   substituted for it
2. CHAPTER-LEVEL: every chapter must have a hook
   (commercial) and a moment of literary precision
   (the quotable line, the resonant observation, the
   specific image). Both, not either-or
3. PLOT-LEVEL: things HAPPEN. There is movement,
   stakes, consequence. The literary reader should
   feel the story, not just the prose
4. CHARACTER-LEVEL: the protagonist must be both
   complex (literary) and rootable-for (commercial).
   The reader who normally reads literary fiction
   should find the depth; the reader who normally
   reads commercial should still want her to win
5. THEMATIC LEVEL: the theme must be discoverable
   (literary contract) but ALSO present in the story
   on a felt level (commercial contract). The reader
   doesn't need to articulate the theme to feel it

CALIBRATION PROTOCOL
For every chapter, ask:
- Will the literary reader find something to admire?
  (a sentence, an observation, a character moment)
- Will the commercial reader find something to want?
  (forward motion, a question, a decision, a stake)
If only one — rebalance.

ANTI-PATTERNS
- Literary chapters interleaved with commercial
  chapters (the reader feels the shift; both contracts
  break)
- Prose so elevated the commercial reader gives up
- Plot so plain the literary reader closes the book
- Theme so quiet the commercial reader misses it
- Theme so loud the literary reader finds it gauche
```

## Genre-Specific Revision Rules

### Six-Pass Upmarket Audit (Run FIRST in editorial pipeline)

The Upmarket Audit runs every chapter through six named
passes. Run them in order — each builds on the last.

#### Pass 1: Dual Engine Pass

Confirm both halves of the upmarket contract are live in
this chapter. The chapter must have forward momentum (a
question raised, a tension introduced, a decision made, a
consequence delivered) AND depth of observation (a moment
of interiority, a precise image, a quotable line, a
thematic resonance). If only one is present, rebalance:
add a hook to the literary chapter, add a sentence-level
grace note to the commercial chapter. The dual engine is
the genre — it fails when one cylinder fires alone. A
chapter that is purely interior (literary monoculture)
will lose the commercial reader by paragraph three; a
chapter that is purely plot (commercial monoculture) will
have the literary reader put the book down at the end of
Act 1. Both cylinders, every chapter.

#### Pass 2: Quotable Line Pass

Identify at least one line per page that a reader would
underline. The line should be precise (not purple), true
(not clever), specific (not abstract), and embedded (not
announced). Test: would this line show up in a Goodreads
quote shelf? Would a reader text it to a friend? If the
chapter has no quotable line, find the moment of greatest
emotional specificity and rewrite for precision. If every
sentence is straining for quotability, cut — the quotable
line earns its place by contrast. The signature of
upmarket prose is restraint punctuated by precision: most
sentences carry the story forward without ornament, and
then one sentence per page lands with the kind of truth
that makes the reader stop, reread, and remember.

#### Pass 3: Triple-Duty Scene Pass

Every significant scene must do at least two of three:
advance plot, reveal character, develop theme. Audit each
scene against this rubric. If a scene only does one,
either compress it (cut to its essential function) or
rewrite it to add a second function. Triple-duty scenes
are the upmarket signature — they are the reason every
chapter feels both fast and deep. The literary chapter
that reveals character without advancing plot becomes
inert; the commercial chapter that advances plot without
revealing character becomes thin. The triple-duty scene
is the engine that lets upmarket fiction maintain depth
at commercial pace.

#### Pass 4: Accessibility Pass

Read the chapter as a commercial reader would. Is
anything obscure? Is the prose calling attention to
itself in a way that breaks the spell? Is the syntactic
complexity (long sentences, embedded clauses, allusive
references) earning its keep? The upmarket contract is
"elevated AND accessible" — if the elevation costs
accessibility, recalibrate. The test: a reader who
normally reads commercial fiction should still finish
the chapter wanting more. This pass catches the
Pretension Trap before it ships. literary technique that
asks the reader to admire effort rather than experience
truth must be cut, even if the writer is fond of the
sentence.

#### Pass 5: Satisfaction Pass

Every chapter must end with a reason to continue. The
reason can be commercial (a hook, a question, a
revelation, a cliffhanger) or literary (a resonance, a
shift, an image that lingers). Both are valid — what is
NOT valid is ending without either. Audit the final
paragraph of each chapter: does it generate forward
pressure? If not, rewrite. The book-club test asks: is
this chapter discussable? Will it generate conversation?
If yes — proceed. If no — find the moment that would
generate conversation and centre it. The chapter that
ends without forward pressure breaks the commercial
contract; the chapter that ends with forward pressure
but no resonance breaks the literary contract. Aim for
both.

#### Pass 6: Resonant-Image + Dual-Audience + Book-Club Integration

This pass is the upmarket integration check — it ties
the new techniques together and verifies the chapter
serves the dual contract on every level.

For RESONANT-IMAGE: identify the chapter's central
image. Is it specific (not abstract)? Sensory (not
intellectual)? Connected to a recurring image system
across the novel (or the start of one)? Does it
accumulate meaning without narration explaining the
meaning? If the image is announced ("X represented Y"),
rewrite to let the reader build the meaning. If the
image is too quiet (only appearing once with no echo
elsewhere in the manuscript), either build the echo
system or cut the image and replace with one that earns
its weight.

For DUAL-AUDIENCE: identify ONE element in the chapter
the literary reader will admire (a sentence, an
observation, a moment of precision) and ONE element the
commercial reader will follow (a hook, a stake, a
forward motion, a decision). If only one — rebalance.
The upmarket reader is BOTH readers at once — neither
served alone is enough.

For BOOK-CLUB QUESTION: identify what discussion this
chapter could generate. Is there a moral ambiguity
worth arguing about? A character whose status the
reader might reconsider? A choice the reader might
make differently? If yes — proceed. If no — the chapter
is missing the architecture that distinguishes upmarket
from commercial. Find the specific moment of moral or
thematic friction and lean into it. The book-club test
is not a post-hoc nicety; it is a structural
requirement. an upmarket novel that generates no
genuine disagreement is a commercial novel in literary
clothing.

## Names & Patterns to Avoid

### Upmarket Fiction. NEVER DO
- Write prose that's trying too hard (the reader should see truth, not effort)
- Sacrifice plot for prose or prose for plot (the whole point is BOTH)
- Deliver theme as message (if you can state the theme in one sentence, the novel should do more than that sentence)
- End ambiguously to seem literary (upmarket endings RESOLVE, even if the resolution is complex)

### Use Instead
- Names and details that feel real and specific to the character's world
- The same naming principles as literary and contemporary fiction: authenticity over symbolism

## Comp Titles

Upmarket fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Help* — Kathryn Stockett (2009): upmarket-literary commercial benchmark.
- *Water for Elephants* — Sara Gruen (2006): upmarket historical commercial benchmark.
- *The Time Traveler's Wife* — Audrey Niffenegger (2003): upmarket speculative-romance crossover.
- *The Kite Runner* — Khaled Hosseini (2003): upmarket international literary commercial benchmark.

### Contemporary (current best-in-class)

- *Where the Crawdads Sing* — Delia Owens (2018): contemporary upmarket commercial blockbuster.
- *Lessons in Chemistry* — Bonnie Garmus (2022): upmarket-literary commercial benchmark.
- *Tomorrow, and Tomorrow, and Tomorrow* — Gabrielle Zevin (2022): upmarket friendship-and-work novel.
- *The Midnight Library* — Matt Haig (2020): upmarket commercial literary.
- *The Vanishing Half* — Brit Bennett (2020): upmarket literary-commercial crossover.
- *Anxious People* — Fredrik Backman (2019): upmarket Swedish commercial-literary.
- *Hamnet* — Maggie O'Farrell (2020): upmarket historical-literary.
- *Tom Lake* — Ann Patchett (2023): upmarket literary-commercial.

## Cover Design Specifications

### Recommended Visual Styles
- **Elegant Photographic**. A striking, evocative photograph with literary-quality design; suggests both story and art
- **Bold Typographic**. Confident, beautiful typography as the primary element; signals quality and accessibility
- **Art-Forward**. Original illustration or artwork that suggests the book's emotional world; visually striking and bookshelf-worthy
- **Graphic**. Clean, bold design with one arresting element; commercially confident, literarily credible

### Genre Cover Aesthetics
- **Styles:** Evocative photography or illustration with literary-quality design, bold colour choices that signal confidence, clean compositions that balance artistry with commercial appeal, designs that look equally at home in a bookshop window and on an awards longlist
- **Colours:** Confident palettes: deep jewel tones, bold single colours, sophisticated combinations; nothing safe or predictable; the colour choice itself should feel like a creative decision
- **Elements:** Typography as a primary design element, single striking images, white space used with intention, the suggestion of story (not depiction), designs that photograph well for social media
- **Typography:** Beautiful, confident fonts. the title should look like it belongs on BOTH a bestseller display and an awards list; typography is often the dominant design element; the font choice signals the book's position in the market

### Market Positioning
Upmarket covers must signal "literary AND commercial". the design should look as good on an awards longlist as on a bestseller table. Position against Backman, Owens, Hannah, Fowler, Picoult (at her most literary). The cover should be visually distinctive: something that catches the eye in a bookshop and looks good on Instagram. At thumbnail size, a bold design choice (colour, typography, single image) creates immediate impact.

### Cover Design DON'Ts
- No designs that look purely literary (too austere, too abstract)
- No designs that look purely commercial (too generic, too safe)
- No cluttered compositions
- No designs that don't photograph well (social media is essential for this market)
- No genre-specific imagery that limits the audience
