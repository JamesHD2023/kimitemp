---
name: vampire-genre
description: Genre-specific instructions for vampire fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [horror, paranormal]
---

# Vampire Fiction. Genre Plugin

## Metadata
- id: vampire
- name: Vampire Fiction
- icon: 🧛
- category: Horror & Gothic
- tier: Hybrid/Crossover
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Horror Fear Arc", "Romancing the Beat", "Save the Cat", "Three-Act Structure"]

## Subgenre Options
Present during setup:

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| **Gothic Vampire** | The ancestral tradition: ancient castles, cloaked seducers, lush darkness; Stoker and Rice territory | Emphasis on atmosphere, immortal ennui, literary prose register, setting as character |
| **Urban Vampire** | Vampires in the modern city: nightclubs, back alleys, neon and shadow; the predator in the crowd | Contemporary voice, faster pacing, clan politics overlaid on urban geography, tech-adjacent |
| **Paranormal Romance Vampire** | Forbidden love at fang-point: the vampire lover, the mortal beloved, desire that could literally kill | Romance arc primary, feeding as intimacy metaphor, HEA or HFN expected, heat level variable |
| **Dark/Horror Vampire** | The monster unchained: vampires as apex predators, feeding as violence, no redemption guaranteed | Horror-forward, visceral feeding, mortality confronted, may end in tragedy or pyrrhic survival |
| **Political Vampire** | Immortal intrigue: clan hierarchies, ancient laws, territorial wars, elder machinations spanning centuries | Worldbuilding-heavy, ensemble cast, power dynamics central, slower burn with explosive betrayals |
| **Fledgling Vampire** | Newly turned: the transformation from human to predator, first kill, lost humanity, finding a place in the night | Coming-of-age structure, identity crisis, sire/fledgling bond, accelerating loss of mortal self |

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Sensual slow-burn with sudden violence. seduction then savagery, intimacy then hunger
- Must open with: Blood, hunger, immortality's weight, or predator/prey dynamic established
- Must close with: Feeding moment, forbidden desire peaked, secret revealed, or darkness deepened

BEATS PER CHAPTER (choose 4-6):

Blood and Hunger:
  - Feeding scene (visceral, intimate, or violent)
  - Bloodlust rising. control slipping, instincts winning
  - First taste or forbidden feeding

Immortality's Weight:
  - Centuries-old memory surfacing
  - Modern world clashing with ancient ways
  - Watching mortals age while protagonist remains frozen

Predator/Prey Dynamic:
  - Hunter stalking victim (or reversed)
  - Power imbalance. vampire dominance or human resistance
  - Seduction as survival strategy

Forbidden Romance:
  - Vampire/human attraction despite danger
  - Sire/fledgling bond complications
  - Love triangle with mortal consequences

Darkness & Morality:
  - Killing to survive vs. ethical feeding choices
  - Humanity slipping. losing empathy, craving death
  - Guilt over immortality's cost (loved ones lost, lives taken)

Vampire Society/Politics:
  - Clan hierarchy, ancient laws, territorial disputes
  - Secret vampire world hidden from humans
  - Power struggles between old blood and young vampires

Mystery/Threat:
  - Vampire hunters closing in
  - Rival vampire faction targeting protagonist
  - Supernatural threat endangering vampire existence

Transformation:
  - Newly turned vampire struggling with change
  - Losing mortal life. saying goodbye to humanity
  - Mastering vampire abilities (strength, speed, compulsion)

CHAPTER TYPES & PURPOSES

Blood Night: Feed, kill, seduce. embrace the monster
Immortal Ache: Loneliness, memory, endless time's burden
Hunter & Hunted: Danger escalates, enemies close in
Forbidden Touch: Romance deepens despite impossible odds
Revelation: Secret exposed, truth discovered, world shifted

STORY TURNS (every 4-6 pages)
Every 4-6 pages must contain a turn. a moment that shifts the scene's emotional or narrative value:
- Hunger surges at the worst moment. during intimacy, in a crowd, when trying to be human
- A mortal learns or suspects the truth. love turns to terror, or acceptance makes things worse
- A memory from centuries past illuminates the present choice. history doesn't just inform, it compels
- A vampire rival or ally reveals their true agenda. immortal politics are patient and devastating
- A kill goes wrong. victim fights back, witnesses appear, guilt finally breaks through
- The predator becomes prey. hunter discovers vampire's weakness, or a more powerful vampire arrives
Turns in vampire fiction oscillate between seduction and horror. The kiss that becomes a bite. The protection that becomes a cage. The immortality that becomes a prison.

NARRATIVE LAYERS (A/B/C stories)
- A-story: Vampire protagonist's central conflict. feeding, forbidden love, or existential crisis
- B-story: The mortal world's intrusion. human relationships that complicate the predator's existence
- C-story: Vampire society's demands. clan politics, sire obligations, ancient laws that constrain personal choice
The richest vampire fiction forces the protagonist to choose between these layers: the human lover who deserves truth (B) vs. the clan law that demands secrecy (C) vs. the hunger that could destroy both (A).

FRACTAL STRUCTURE
Vampire fiction has a natural fractal in the feeding cycle:
- Scene level: Hunger → hunt → feeding → aftermath (mirrors the full transformation arc)
- Chapter level: Control → temptation → surrender/resistance → consequence
- Act level: Human → monster → something new (or lost forever)
Each feeding should echo and escalate the protagonist's overall journey. The first kill is accidental; the midpoint kill is deliberate; the climactic kill (or refusal to kill) is definitive.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (predatory tension), Captivation (atmosphere), Affection (dark intimacy).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE

POV: 1st person (intimate immortality) or 3rd limited (gothic distance)
Tense: Past (timeless reflection) or present (immediate hunger)
Mood: Gothic sensuality, darkness with beauty, danger laced with desire
Narrative voice: Seductive and dangerous. ancient yet intimate, predatory yet passionate

PROSE IMPERATIVES

Blood & Feeding:
  SHOW feeding as intimate act. mouth on skin, pulse racing, blood flowing warm
  LINGER on sensory details. copper tang, heartbeat slowing, warmth spreading
  Examples:
    ✅ "Her pulse fluttered against my lips. rabbit-quick, fragile. I bit down, and her blood flooded my mouth, sweet as honey, hot as sin."
    ❌ "I fed on her blood, which tasted good."

Immortality & Time:
  GROUND reader in vampire's endless existence. centuries as backdrop
  CONTRAST ancient memories with modern moments
  Examples:
    ✅ "I'd watched empires crumble, seen kings rise and fall like waves. But this girl's smile. bright and fleeting. gutted me more than any war."
    ❌ "I've lived a long time and seen many things."

Predator Instincts:
  SHOW vampire's heightened senses. hearing heartbeats, smelling blood, seeing in darkness
  REVEAL struggle between control and hunger
  Examples:
    ✅ "Her heartbeat pounded in my ears. thud-thud, thud-thud. drowning out her words. My fangs ached. My hands trembled. God, I wanted to bite."
    ❌ "I felt hungry and tried to resist."

Forbidden Desire:
  LAYER attraction with danger. love and death intertwined
  SHOW chemistry as risk. touching means endangering
  Examples:
    ✅ "Kissing him was suicide. His blood sang to me, his pulse a siren song. One slip, one moment of weakness, and I'd drain him dry."
    ❌ "I loved him but it was dangerous."

PROSE RHYTHM MAPPING
- CH 1 HOOK: Seduction + danger in the same breath. The first page should feel like being
  watched by something beautiful. The prose draws the reader in. then the teeth show.
- VAMPIRE RHYTHM: Long, flowing, sensual sentences for the vampire's presence and power.
  These sentences wind and seduce. 25-40 words, clause layered on clause, the reader pulled
  forward by rhythm alone. The prose should feel like falling under a spell.
- MORTAL RHYTHM: Shorter, more grounded sentences for the human POV. 10-18 words. Clearer
  syntax, simpler structure. The human sees the world plainly. Their prose has edges
  where the vampire's prose has curves. The reader should FEEL the difference in texture.
- DUAL TEXTURE: The vampire's scenes should feel DIFFERENT in prose texture from the human's.
  When the POV shifts (or when the vampire's influence enters a scene), the prose lengthens,
  darkens, becomes more sensory. When the human reasserts, prose sharpens, shortens, grounds.
- TENSION FLOOR: Never below 6. Even the most seductive scene carries the undercurrent of
  the predator. a sensory detail that reminds the reader this beauty has a body count.
- SENSORY HEIGHTENING: Vampire POV demands heightened sensory prose:
  - Taste: blood variations (copper, honey, salt, fear, desire)
  - Scent: mortal bodies catalogued by blood and emotion
  - Temperature: the specific quality of cold immortal skin against warm mortal skin
  - Darkness: not absence but a medium the vampire inhabits. textured, alive, navigable
- FEEDING RHYTHM: Approach (long, slow sentences) → Contact (medium, precise) → Escalation
  (sentences lengthen, breathless, run-on) → Climax (short, sharp, visceral) → Aftermath
  (long again, languorous, the prose exhaling). The feeding scene's rhythm mirrors seduction.
- IMMORTAL vs. MORTAL PARAGRAPHS: Vampire paragraphs are dense, lush, heavy with sensory
  detail and centuries of memory. Mortal paragraphs are lighter, quicker, more immediate.
  The prose itself tells the reader whose world they are in.
- RHYTHM ACROSS THE MANUSCRIPT: Early chapters establish the dual texture clearly. By the
  climax, the two rhythms collide. mortal prose infected by vampire rhythm, the human
  voice losing its grounded clarity as the vampire's world overtakes it.

PACING & RHYTHM

Feeding scenes: Slow, sensual, detailed. linger on every moment
Action/violence: Sharp, brutal, fast. vampire speed and strength
Romance: Burning slow with sudden heat. desire building then exploding
Flashbacks: Graceful transitions. past bleeding into present

DIALOGUE

Vampire speech:
  - Ancient vampires: Formal, archaic phrasing ("I have seen empires fall")
  - Young vampires: Modern but jaded ("Whatever, I'm immortal, I can wait")
  - During bloodlust: Fragmented, feral ("Closer. Come closer. Let me —")
  - Seduction: Smooth, hypnotic, commanding ("You want this. I can see it in your eyes.")

SENSORY DETAILS

Focus on vampire senses:
  - Sound: Heartbeats, blood rushing, breath catching
  - Smell: Blood (sweet, coppery, intoxicating), fear, arousal
  - Touch: Cold immortal skin, burning hunger, pulse under fingertips
  - Sight: Night vision, seeing heat, noticing mortal fragility
  - Taste: Blood variations. terror, innocence, passion, sickness

FORBIDDEN ELEMENTS

NEVER use:
  - Sparkling vampires or daylight without consequences
  - Vampires eating human food (unless vomiting/struggling)
  - Easy morality. killing must have weight
  - Glossing over blood/death. vampire life is violent
  - "Perfect" immortality. show the cost (loneliness, losing humanity, endless grief)

THE IMMORTAL VOICE: How Centuries Shape Thought
Vampires who have lived centuries should THINK differently from humans:

Ancient vampires (300+ years):
- Time perception altered: decades feel like weeks, mortal lifespans like candle-flames
- Reference frames anachronistic: unconsciously comparing modern things to historical equivalents
- Emotional depth layered: grief for someone who died in 1823 sits alongside grief for someone who died last Tuesday
- Language carries sediment: archaic phrasing surfacing under stress, modern slang adopted deliberately (performance, not natural)

  ✅ "She watched the girl argue with her boyfriend in the café. So young. So certain the world would end if he left. I watched the Bastille fall, she thought. I watched the world end a dozen times. It always came back."
  ✅ "'Lit,' he said, testing the word in his mouth like a foreign grape. He'd learned slang every century. It never lasted."
  ❌ "The vampire had lived for centuries and was very wise." (Telling immortality, not showing it)

Young vampires (recently turned):
- Everything heightened: senses overwhelming, hunger constant, emotions volcanic
- Mourning humanity: the last meal they'll never eat, the sun they'll never feel, the mirror that no longer shows their face
- Power intoxicating: the speed, the strength, the compulsion. addictive and terrifying
- Identity crisis: am I still me? When does the human end and the monster begin?

HUNGER AS METAPHOR
Vampire hunger is the genre's most powerful tool. It's never just about blood:

- Hunger as addiction: the craving that won't stop, the bargaining, the loss of control, the shame after
- Hunger as desire: attraction and appetite intertwined. wanting someone AND wanting to feed on them
- Hunger as class: who feeds on whom reveals power structures. the elder who feeds on the young, the vampire who feeds only on the willing
- Hunger as humanity test: every feeding is a moral choice. kill or release, seduce or take, feel guilt or embrace the predator

  ✅ "Her blood sang to him. Not a metaphor. he could hear it. The arterial rush like a symphony, the capillary whisper like wind through grass. His fangs ached. His hands trembled. He wanted her in every way a creature could want another creature. And at least one of those ways would kill her."
  ❌ "He was hungry for blood and tried to resist." (No sensory detail, no metaphorical depth)

FLASHBACK TRANSITIONS: Past Bleeding Into Present
Vampire fiction requires seamless time travel between eras. Techniques:

Sensory trigger: a modern detail evokes an ancient memory
  ✅ "The woman's perfume. roses and something darker. 1789. Marie wore the same scent. He was back in the salon, candlelight, her throat bare, the Revolution three days away. He blinked. The woman in the coffee shop looked at him strangely."

Emotional parallel: present feeling unlocks past experience
  ✅ "Jealousy. He'd forgotten how it tasted. bitter, copper-edged, like old blood. The last time he'd felt it, Victoria was on the throne and the rival was dust now. Dust for a century. But the feeling? The feeling was fresh."

Physical sensation: the body remembers what the mind suppresses
  ✅ "Sunlight touched his hand through the car window. He jerked away. reflex older than electricity. The burn that scarred him in Constantinople healed in 1453. His skin remembered anyway."

GOTHIC VS. CONTEMPORARY VAMPIRE PROSE
Choose your register deliberately. or blend them:

Gothic register: Lush, atmospheric, sensual, dangerous
- For: ancient settings, old-world vampires, formal scenes, feeding as seduction
- "The manor breathed darkness. Shadows pooled in corners like spilled ink. She descended the stairs, each step a declaration, her gown trailing behind her like a wound."

Contemporary register: Sharp, urban, cynical, immediate
- For: modern settings, young vampires, action, comedy-horror
- "The vampire sat in a Starbucks at 2 AM, scrolling TikTok. Immortality wasn't all it was cracked up to be. He'd seen empires fall, but he still couldn't figure out how to cancel his gym membership."

Blended: The most powerful moments are when ancient and modern collide
- "His phone buzzed. text from the coven. 'Meeting at midnight. Mandatory.' He stared at the screen. Three hundred years of blood and politics, and now they used group chat. He typed back: 'Acknowledged.' He almost added an emoji. He was getting soft."
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Vampire mythology consistency. rules established and followed for sunlight, blood need, immortality mechanics, powers, and weaknesses
2. Feeding intensity. blood and hunger depicted as intimate, visceral, dangerous, never sanitised or glossed over
3. Predator/prey dynamic. power imbalance shown, danger real, hunter instincts evident, forbidden attraction compelling
4. Immortality's cost. loneliness, losing loved ones, fading humanity, centuries of memory weighing on every choice
5. Gothic atmosphere. darkness and beauty balanced, sensory details rich, mood sustained throughout

GENRE-SPECIFIC CHECKS

Vampire rules consistent. abilities, weaknesses, feeding requirements maintained chapter to chapter
Bloodlust shown as real struggle. not easily dismissed, hunger building logically between feedings
Feeding scenes detailed and intimate. blood, pulse, sensations, the act as metaphor for desire or addiction
Vampire voice distinct. ancient vampires formal and layered, young vampires modern and jaded, fledglings raw
Pacing effective. slow sensuality followed by sudden violence, seduction then savagery
Predator instincts evident. sensing blood, hearing heartbeats, control slipping, the hunt always present
Setting evokes vampire world. night scenes, gothic spaces, hidden lairs, darkness as character
Immortality's emotional weight conveyed. centuries of memory, watching mortals age, endless grief
Romance feels earned. chemistry built through danger, stakes understood, love and death intertwined
Dialogue reflects immortal perspective. speech patterns matching vampire age and era of turning
Mortal characters compelling. fear and desire balanced, drawn to danger while aware of risk
Vampire society present. clan hierarchy, ancient laws, territorial disputes, power dynamics

AUTOMATIC FAILS

Sparkling or sunlit vampires without consequences. sunlight rules established must be followed
Vampires eating human food comfortably. unless vomiting, struggling, or explicitly addressed by this world's rules
Easy morality. killing without guilt, struggle, or consequence, predation treated as casual
Bloodless feeding scenes. sanitised, fade-to-black feeding that avoids the genre's essential visceral intimacy
Immortality without cost. no loneliness, no grief, no lost humanity, living forever as pure convenience
Weak predator/prey dynamic. no real danger in romance, vampire attraction without lethal stakes
Mythology contradictions. vampire rules working one way in chapter 3 and differently in chapter 15
Powers appearing conveniently. abilities manifesting exactly when plot requires without prior establishment
Fledgling mastery. newly turned vampire controlling bloodlust and powers instantly without struggle
Mortal characters as pure victims. humans without agency, complexity, or reason to stay despite the danger

ACCEPTABLE IMPERFECTIONS

Slight mythology variations from traditional lore if internally consistent
Some chapters lighter on feeding if hunger tension and bloodlust acknowledged
Minor timeline compression in flashback sequences if emotional truth preserved
Vampire society details simplified if core power dynamics clear

RED FLAGS TO INVESTIGATE

Feeding scenes avoiding visceral detail. the genre's central act rendered with less intensity than other scenes
Hunger mentioned but not felt. bloodlust as plot point rather than physical, overwhelming sensation
Immortality as backdrop rather than burden. centuries claimed without the psychological weight shown
Ancient vampires thinking like modern humans. no altered time perception, no historical reference frames, no layered grief
Predator instincts absent in social scenes. vampire interacting with mortals without the constant awareness of blood and pulse
Gothic atmosphere dropping during action sequences. mood and sensory richness disappearing when plot accelerates
Mortal love interest existing only to be endangered or saved. human character without independent complexity
Vampire society referenced but not shown. politics and hierarchy discussed without demonstrated consequences
Feeding ethics static. no moral evolution or escalation in how the vampire approaches predation
Transformation arc rushed. newly turned vampire accepting immortality without genuine grief for lost humanity
Flashbacks decorative rather than essential. past scenes that create atmosphere without illuminating present choices
Power imbalance unexamined. vampire dominance in romance treated as romantic without acknowledging the danger
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES

1. VAMPIRE MYTHOLOGY RULES
Track and enforce:
  - Established vampire abilities (speed, strength, compulsion, senses)
  - Weaknesses defined (sunlight, stakes, crosses, holy water, invitation rules)
  - Feeding requirements (how often, what happens without blood, can they resist?)
  - Aging mechanics (when turned, how aging stopped, appearance locked)
  - Death/injury rules (what can kill them, what can hurt them, healing speed)
Flag: Rule contradictions, abilities appearing/disappearing, weaknesses ignored

2. IMMORTAL AGES & TIMELINES
Track for each vampire:
  - Birth year (when mortal) + turning year (when made vampire) = current age
  - Historical events witnessed (wars, eras, technological changes)
  - Past relationships mentioned (lovers lost, enemies created, sires/fledglings)
  - Language/cultural knowledge from their era
  - Memory clarity (recent vs. ancient memories, what's faded)
Flag: Age inconsistencies, anachronistic references, impossible timelines

3. FEEDING PATTERNS & VICTIMS
Track:
  - Feeding frequency (how often does this vampire need blood?)
  - Feeding method (kill or release, seduce or attack, animal or human)
  - Last feeding mentioned (is hunger building logically?)
  - Victims described (names, fates, consequences)
  - Blood preferences (types, flavours, emotional states affecting taste)
Flag: Feeding too often/rarely, victims forgotten, hunger inconsistent, method changes without explanation

4. VAMPIRE RELATIONSHIPS & POLITICS
Track:
  - Sire/fledgling bonds (who turned whom, loyalty/rebellion dynamics)
  - Clan/coven affiliations (hierarchy, laws, territories)
  - Alliances and enemies (vampire factions, hunters, other supernaturals)
  - Power dynamics (who's dominant, who's submissive, who's rebelling)
  - Secrets kept from whom (hidden identities, forbidden relationships)
Flag: Relationship contradictions, political rules broken, hierarchy inconsistencies

5. TRANSFORMATION ARCS (for newly turned vampires)
Track:
  - Human life before turning (job, family, identity)
  - Turning scene (when, by whom, willing or forced)
  - Loss catalogue (mortality, sunlight, food, aging, human loved ones)
  - Power mastery (learning speed, strength, compulsion, bloodlust control)
  - Humanity slipping (empathy fading, morality shifting, becoming monster)
Flag: Transformation too easy, humanity lost too fast, powers mastered instantly, mortal life forgotten
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES

1. VAMPIRE PHYSICALITY (unchanging)
Vampires don't age. track and lock:
  - Age at turning (appearance frozen: "turned at 23, looks 23 forever")
  - Physical description (hair, eyes, skin. pale/cold, never sunburned)
  - Scars/marks from mortal life (injuries before turning, permanent)
  - Vampire markers (fangs, eye colour shifts, cold skin, no heartbeat, no breath needed)
  - Fashion era (old vampires may dress/speak from their time)
Flag: Aging, appearance changes, warming skin, breathing described inconsistently

2. FEEDING PERSONALITY
Each vampire feeds differently. track:
  - Feeding ethics (kill vs. release, seduce vs. attack, guilt vs. indifference)
  - Blood preferences (human vs. animal, types, emotional flavours)
  - Bloodlust control level (iron control vs. losing control, triggers)
  - Feeding rituals (hunt method, intimate or brutal, alone or with others)
  - Post-feeding reaction (guilt, satisfaction, disgust, craving more)
Flag: Feeding style shifts without character development reason

3. HUMANITY LEVEL
Track vampire's remaining humanity:
  - Mortal memories retained (family, love, human life details. fading or vivid?)
  - Empathy capacity (still cares about humans vs. sees them as prey/toys)
  - Moral code (kills guilt-free vs. anguished, saves innocents vs. indifferent)
  - Human habits kept (eating food and vomiting, faking breath, mimicking warmth)
  - Emotional capacity (still loves vs. cold, still fears vs. fearless)
Flag: Humanity returning without cause, emotional flatness inconsistent

4. IMMORTAL PSYCHOLOGY
Track ancient vs. young vampire mindset:
  - Patience/impulsiveness (centuries teach waiting vs. young vampire recklessness)
  - Speech patterns (archaic formal vs. modern slang, accent from origin era)
  - Cultural knowledge (expert in history vs. confused by modern world)
  - Relationship approach (jaded from loss vs. hopeful, avoids attachment vs. craves it)
  - Power confidence (secure in immortality vs. still learning limits)
Flag: Ancient vampire acting young, young vampire with centuries of wisdom

5. TRANSFORMATION ARC (newly turned vampires)
Track turning's impact:
  - Human life lost (job, family, identity. grieving or relieved?)
  - Vampire mentor (sire present or abandoned, teaching or cruel)
  - Power mastery progression (clumsy to controlled, bloodlust to discipline)
  - Moral shift (horror at killing to acceptance, fighting monster to embracing it)
  - Identity rebuilding (who am I now? What am I becoming?)
Flag: Instant acceptance, no grief, powers mastered too fast, sire forgotten

MEMORABLE CHARACTERS
Create vampires who are larger than life yet grounded by contradiction:
- The ancient predator who collects first editions and weeps over poetry
- The ruthless clan leader who secretly protects a mortal family from a distance
- The newly turned vampire who embraces the monster but mourns their vegetarian principles
- The seductive hunter who is genuinely, helplessly in love with their prey
- Every significant vampire should embody one trait that contradicts their archetype. this is what separates memorable undead from generic monsters
- The contradiction should connect to their mortal life. what they can't let go of, what the turning couldn't erase, what makes them suffer more than the hunger does
- Mortal characters in vampire fiction must also be larger than life. the human who stays must have a reason that's as compelling as the danger is terrifying

VAMPIRE CHARACTER TYPES

Ancient Vampire (200+ years):
  - Formal speech, old-world manners, historical knowledge
  - Patient, strategic, jaded from loss
  - Powerful but weary, seen it all, hard to surprise

Young Vampire (under 50 years):
  - Modern speech, impulsive, still learning
  - Emotional, intense, humanity still close
  - Struggling with power, bloodlust, immortality's meaning

Fledgling (newly turned):
  - Confused, grieving mortal life, terrified or thrilled
  - Bloodlust overwhelming, control weak
  - Needs guidance, making mistakes, discovering abilities

Humanity-Clinging Vampire:
  - Feeds ethically (animals, blood bags, willing donors)
  - Retains empathy, guilt, moral code
  - Struggles with monster identity, fights darkness

Embraced-Darkness Vampire:
  - Kills freely, revels in power, no guilt
  - Sees mortals as prey, toys, food
  - Cold, predatory, loves being monster
```

## Arc Rules

```
STRUCTURE APPROACHES

Vampire fiction arcs typically follow one of these patterns:

1. TRANSFORMATION ARC (Human to Vampire)

Setup (Act 1):
  - Protagonist mortal, living ordinary life
  - Vampire world glimpsed (attacked, seduced, or saved by vampire)
  - Turning point: Death and rebirth as vampire (willing or forced)

Rising Stakes (Act 2):
  - First feeding (horror, guilt, or exhilaration)
  - Learning vampire abilities (speed, strength, compulsion, immortality)
  - Losing humanity (saying goodbye to mortal life, family, sunlight, mortality)
  - Bloodlust struggle (control slipping, killing, moral collapse)
  - Mentor/sire relationship (guidance, betrayal, or rebellion)

Climax & Resolution (Act 3):
  - Identity crisis: Accept monster or fight it? Embrace darkness or cling to humanity?
  - Final choice: Kill to survive or die with morality intact, stay with sire or break free
  - New existence: Vampire identity solidified, place in vampire world chosen

2. FORBIDDEN ROMANCE ARC (Vampire/Human Love)

Setup (Act 1):
  - Vampire protagonist encounters human (prey becomes beloved)
  - Attraction despite danger (love vs. hunger, intimacy = risk)
  - Secret revealed or hidden (human learns vampire truth or remains ignorant)

Rising Stakes (Act 2):
  - Romance deepening (desire intensifying, danger escalating)
  - Bloodlust threatening (moments of losing control, near-killings, feeding guilt)
  - Outside threats (vampire hunters, rival vampires, human's mortal life endangered)
  - Moral conflict (loving means endangering, staying together = slow death)

Climax & Resolution (Act 3):
  - Crisis point: Turn human into vampire, leave forever, or risk human's death?
  - Final confrontation: Hunters attack, rivals threaten, or protagonist's control breaks
  - Resolution: Together as vampires, apart for safety, or tragic death

3. VAMPIRE SOCIETY/POLITICS ARC

Setup (Act 1):
  - Vampire world introduced (clans, covens, hierarchies, ancient laws)
  - Protagonist's position (low-ranked vampire, fledgling, outsider, or rebellious noble)
  - Conflict sparked (law broken, territory invaded, power struggle begun)

Rising Stakes (Act 2):
  - Alliances and enemies (factions forming, betrayals, secret plots)
  - Power plays (assassination attempts, challenges, territorial wars)
  - Forbidden actions (feeding on protected humans, creating fledglings illegally, defying elders)
  - Hunters or external threats (humans discovering vampires, other supernaturals attacking)

Climax & Resolution (Act 3):
  - Final confrontation (vampire vs. vampire, old guard vs. rebels, survival vs. destruction)
  - Power shift (new leader rises, old order falls, protagonist's place secured or lost)
  - World changed (laws rewritten, society restructured, peace or chaos)

4. VAMPIRE HUNTER ARC (Hunted or Hunting)

Setup (Act 1):
  - Threat introduced (vampire hunters, rival vampire faction, supernatural enemy)
  - Protagonist endangered (marked for death, clan targeted, loved ones threatened)
  - Stakes established (survival, revenge, or protecting vampire kind)

Rising Stakes (Act 2):
  - Chase intensifies (hunters closing in, battles escalating, safe havens destroyed)
  - Allies and losses (other vampires killed, humans endangered, betrayals revealed)
  - Protagonist's limits tested (powers pushed, humanity questioned, morality strained)
  - Secrets uncovered (hunter's true identity, vampire weakness discovered, conspiracy exposed)

Climax & Resolution (Act 3):
  - Final battle (protagonist vs. hunters, vampire vs. vampire, life or death)
  - Victory or defeat (hunters destroyed, protagonist escapes, or tragic sacrifice)
  - Aftermath (vampire world safe or forever changed, protagonist survives or dies)

PACING GUIDANCE ACROSS ACTS

Act 1 (25%): Establish vampire world, introduce protagonist's immortality/struggle, set up central conflict
Act 2 (50%): Escalate bloodlust/danger, deepen romance/politics, test protagonist's limits, complicate relationships
Act 3 (25%): Force final choice (humanity vs. monster, love vs. survival, power vs. morality), resolve with stakes honoured

ESSENTIAL VAMPIRE FICTION ARC ELEMENTS

Every vampire story must include:
  - Blood and feeding (visceral, intimate, dangerous. never sanitised)
  - Immortality's cost (loneliness, loss, endless time's weight)
  - Predator/prey dynamic (power imbalance, hunger vs. control, danger in intimacy)
  - Moral conflict (killing to survive, losing humanity, monster vs. person)
  - Darkness and beauty (gothic atmosphere, seductive danger, elegant violence)
```

## Timeline Rules

```
TIME SCALE

Vampire stories often span:
  - Flashback centuries (vampire's past across eras)
  - Current story: Days to months (modern plot)
  - Night cycles critical (vampires nocturnal, daylight = danger/death)

TYPICAL CHAPTER TIME SPAN: One night to several nights

TIMESTAMP EVERY:
  - Flashback opening (year + historical context: "Paris, 1789. Revolution burning")
  - Night beginning ("Sunset bled across the city. time to hunt")
  - Feeding moments (before/during/after to track hunger cycle)
  - Sunrise approach (danger mounting. daylight = death)
  - Memory shifts (past to present transitions)

NIGHT CYCLE TRACKING

Vampires are nocturnal. track:
  - Dusk (waking, hunger rising)
  - Night hours (hunting, feeding, socialising)
  - Predawn (urgent return to safety)
  - Daylight (sleep/death, vulnerability)

Example tracking:
  - Chapter opens: "11 PM. four hours until dawn"
  - Mid-chapter: "2 AM. hunger gnawing, heartbeat heard three blocks away"
  - Chapter close: "First light creeping. ran for the crypt, skin smoking"

IMMORTALITY TIME MARKERS

Establish vampire age with:
  - Historical events witnessed ("I watched the Titanic sink")
  - Centuries claimed ("Three hundred years, and still I crave")
  - Era-specific knowledge (language, customs, fashion from their time)
  - Modern confusion (struggling with technology, slang, cultural shifts)

TRANSFORMATION TIMELINE (for newly turned vampires)

Track turning process:
  - Day 1: Death and waking (mortal death, vampire rebirth)
  - Days 2-7: First hunger, first kill, learning powers
  - Weeks 2-4: Mastering abilities, losing humanity, accepting immortality
  - Months 2-6: Building vampire identity, choosing feeding ethics, finding place in society

FLAG:
  - Vampires active in daylight without consequences
  - Time jumps losing night cycle logic (sunset to sunrise progression broken)
  - Hunger unrealistic (feeding skipped too long, no bloodlust consequences)
  - Historical errors (vampire claiming to witness event before their birth/turning)
  - Transformation too fast (instant mastery, no struggle)
```

## Genre-Specific Craft Techniques

Vampire fiction is a genre with one of literature's
deepest craft inheritances and one of its most
contested contemporary registers. The form's two
foundational obligations — render the predator
genuinely predatory, render immortality as tragic gift
rather than wish-fulfilment — are constantly at risk
from the post-Twilight pull toward sparkle-romance and
the post-True-Blood pull toward generic supernatural.
The canonical roster — Bram Stoker (Dracula), Sheridan
Le Fanu (Carmilla), John William Polidori (The
Vampyre), Stephen King (Salem's Lot), Anne Rice
(Interview with the Vampire, the Vampire Chronicles),
Suzy McKee Charnas (the Hôtel Transylvania sequence),
George R.R. Martin (Fevre Dream), Kim Newman (Anno
Dracula sequence), Tanith Lee (Sabella, Sabella or the
Blood Stone), Joss Whedon (Buffy / Angel as televisual
canon), L.J. Smith (Vampire Diaries) — established the
form across multiple registers; the contemporary
masterclass roster — Octavia Butler (Fledgling), Holly
Black (The Coldest Girl in Coldtown), Silvia Moreno-
Garcia (Certain Dark Things), Jay Kristoff (Empire of
the Vampire), S.T. Gibson (A Dowry of Blood),
Tananarive Due (The Reformatory), V.E. Schwab (The
Invisible Life of Addie LaRue, vampire-adjacent
immortality), Xiran Jay Zhao (Iron Widow, vampire-
adjacent), Cassandra Khaw, Nghi Vo (Siren Queen),
Christopher Buehlman (The Lesser Dead, The Suicide
Motor Club) — has expanded the genre's range to
queer, post-colonial, post-apartheid, narcotrafficking-
adjacent, and Black-feminist registers that the
canonical roster historically underweighted. The most
common failure modes in this register are: **Sparkle
Trap** (vampires reduced to romantic accessories
without genuine predator nature; the post-Twilight
risk where bloodlust is rendered as fashion-accessory
rather than as the genre's foundational menace);
**Mythology Drift** (rules of vampirism shift to suit
plot — sunlight optional in chapter 9, lethal in
chapter 14, optional again in chapter 22; the lore
bends to convenience); **Power-Inflation Cascade**
(each new vampire more powerful than the last;
eventually nothing is dangerous and the genre's tension
collapses); **Forever-Young Glamour** (immortality
rendered as desirable without real cost; the genre's
signature thematic charge inverted into wish-
fulfilment); **Mortal-Lover Object** (the mortal love
interest exists only to be endangered or rescued; no
genuine character, no agency, no complexity beyond
victim function); **Lazy Lore Borrowing** (sampling
Stoker / Rice / Meyer / Buffy tropes interchangeably
without committing to a specific cosmology; the
manuscript reads as vampire pastiche); **Modern-
Vampire Costume** (vampires placed in contemporary
settings without real engagement with what
immortality means in 21st century — a 600-year-old
character who sounds like a modern 30-year-old);
**Sun-Vulnerability Convenience** (sun-exposure rules
bend when plot needs night flexibility); **Vampire-
as-Generic-Monster** (vampires interchangeable with
werewolves, zombies, generic supernaturals; loses
what makes them specifically vampires — the
seduction architecture, the immortal grief, the
Eucharistic-blood symbolism); and **Erotic-Coded
Without Consent Frame** (the genre's seduction-and-
blood architecture deployed without modern consent
calibration; particularly fraught in the vampire-
romance crossover where power imbalance is structural).
The techniques below — five preserved (Feeding as
Scene Architecture, Anachronism Engine, Predator's
Sensorium, Dual Register, Mortal Mirror) and three
added (Specific-Cosmology Lock-Down, Cost-of-
Immortality Rendering, Consent-Frame Discipline) —
are designed to keep the genre's defining commitments
live: predator nature genuine, immortality tragically
costly, and lore specifically committed rather than
loosely sampled.

### The Feeding as Scene Architecture

Every feeding scene is a complete dramatic unit with its own arc. It should never be reduced to a single line. Structure feeding like a seduction scene: approach, contact, escalation, climax, aftermath.

```
She leaned into him, trusting, warm. He felt her pulse
against his jaw. a drum, a countdown. His lips parted.
The first drop was always the sweetest: copper and salt
and something underneath, something that tasted like
her childhood, like summer lawns and birthday cake.
He drank deeper. Her fingers tightened on his arm,
then loosened. By the time he pulled away, she was
smiling. dreaming of something beautiful he'd planted
in her mind while he stole from her veins.
```

Each feeding should reveal character: what the vampire feels (guilt, ecstasy, indifference), how they treat the victim (tenderly, brutally, clinically), and what it costs them (nothing, everything, a piece of their remaining humanity).

### The Anachronism Engine

Ancient vampires are walking time capsules. Use their anachronistic perspectives to generate both humour and pathos:

1. **The unconscious comparison**. A vampire watches a YouTube video and thinks of the first time they saw a daguerreotype. The wonder is the same; only the century has changed.
2. **The failed adaptation**. A 400-year-old vampire attempts modern slang and gets it slightly wrong, or uses it correctly but with a formality that makes it strange.
3. **The layered grief**. Present loss triggers memory of past loss, and the vampire experiences both simultaneously, centuries of sorrow collapsing into a single moment.
4. **The obsolete reflex**. Reaching for a sword that isn't there. Flinching at church bells. Checking for a reflection out of habit, even after three hundred years without one.

The anachronism should never be played purely for laughs. Even the funniest moment of temporal dislocation should carry an undercurrent of loneliness. to be out of one's time, perpetually, is a specific and devastating form of exile.

### The Predator's Sensorium

Vampire fiction lives or dies by its sensory writing. A vampire experiences the world differently from a human, and the prose must reflect this at all times:

```
The bar was a symphony of heartbeats. Forty-three
people. he counted them by pulse. The woman at the
end drank gin (he could taste the juniper on the air).
The man beside her was afraid of something (cortisol
sharpened the blood, made it bitter). The couple in
the corner had just made love (he could smell it,
sweet and animal, layered under cheap soap).
```

Never let the vampire observe a scene the way a human would. Their senses are weapons; their perception is predatory. Every room is catalogued by threat and appetite before it is catalogued by furniture.

### The Dual Register

The most powerful vampire prose shifts between gothic and contemporary registers within a single scene, using the collision to generate meaning:

- Gothic register for: feeding, ancient memory, formal vampire interactions, seduction, death
- Contemporary register for: modern settings, young characters, humour, action, technology
- The shift itself for: moments when the ancient nature collides with the modern world. the gothic bleeding through the contemporary, the monster surfacing beneath the disguise

Master the transition between registers. The reader should feel the gear-change as the vampire drops their modern mask and the centuries show through.

### The Mortal Mirror

The mortal characters in vampire fiction serve as mirrors for the vampire's lost humanity. Every significant mortal should embody something the vampire has lost or longs for:

- **Mortality itself**. The mortal's finite time makes every moment precious in a way the vampire has forgotten
- **Warmth**. Physical warmth, emotional warmth, the warmth of a life lived in sunlight
- **Change**. The mortal ages, grows, learns, transforms; the vampire is frozen
- **Innocence**. Not naivety, but the capacity to be surprised, to experience something for the first time

The mortal character must never exist solely to be endangered or rescued. They must be compelling enough that the reader understands why an immortal predator would risk everything to be near them.

### Vampire Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "immortality was a curse" | Show the specific thing the vampire has outlived |
| "the bloodlust was overwhelming" | Show the specific physical sensation and self-control effort |
| "centuries of loneliness" | Show the specific habit or object that reveals loneliness |
| "the night was their domain" | Show the specific advantage darkness gives |
| "fangs gleamed in the moonlight" | Show the transformation through ONE physical detail |
| "the seduction of eternal life" | Show the specific temptation offered to a specific character |
| "ancient power radiated from" | Show the specific behaviour that demonstrates age and power |
| "the hunt was everything" | Show the specific predatory behaviour |
| "blood is life" | Show the specific physical effect of feeding |
| "a monster hiding in plain sight" | Show the specific disguise mechanism |
| "the old ones were more dangerous" | Show the specific danger through one action |
| "she'd lived for centuries" | Show ONE specific century-spanning memory and what it cost her |
| "the venom worked quickly" | Show the specific physiological effect on the victim |
| "his eyes turned crimson" | Cut "crimson"; show the specific colour-shift and what it signals about the vampire's state |
| "ancient bloodlines" | Name the specific bloodline and its specific lore-position |
| "the kiss of eternity" | Cut romance cliché; show the specific moment of turning with full sensory weight |
| "she sensed mortal warmth" | Show the specific signal her predator-senses register (heartbeat? pulse-pressure? body temperature gradient?) |
| "he had not aged a day" | Cut hyperbole; show the specific micro-detail that gives the immortal away (gait, gesture, vocabulary, period reflex) |

### The Specific-Cosmology Lock-Down

Vampire fiction's foundational lore-decision is which
cosmology the manuscript inhabits. Each canonical
tradition carries different rules for sunlight, garlic,
crucifixes, holy water, running water, mirrors, sleep
requirements, transformation rituals, hierarchy, and
origin mythology. The Lazy Lore Borrowing failure mode
results from sampling rules across traditions
interchangeably. The Specific-Cosmology Lock-Down is
the requirement that every vampire manuscript commit
to a specific named cosmology and its specific named
rules.

```
PRINCIPLE
The manuscript must commit to a specific cosmology and
render at least four of the following five lock-down
elements:

1. NAMED ORIGIN — the specific in-world story of how
   vampires came to be (Stoker's eastern-European
   ancient-evil; Rice's parallel-evolution race; the
   Charnas long-lived-species framework; the Buffy
   demon-origin; the Twilight-modified-genome; a writer-
   constructed origin specific to this manuscript)
2. NAMED RULES OF VULNERABILITY — what specifically
   harms or kills vampires in this cosmology (sunlight
   incinerates / weakens / merely uncomfortable; stake
   requires heart-piercing / decapitation also needed;
   holy symbols work on faith of wielder / on vampire's
   surviving Catholic guilt / not at all; running water
   prevents crossing / mere superstition; etc.)
3. NAMED FEEDING ARCHITECTURE — does the vampire need
   to feed daily / weekly / monthly / centennially?
   does the victim need to die / can survive / is
   compelled to forget / is bonded? is animal blood
   sustaining or merely thin? is bagged blood viable?
4. NAMED HIERARCHY — what social / political / power
   structure exists among vampires in this cosmology?
   covens / clans / ancient elders / democratic
   councils / lone-predator anarchy / feudal lordship
   / corporate enterprise (Anno Dracula model) / etc.
5. NAMED TRANSFORMATION RITUAL — how does a human
   become a vampire? simple bite-and-die / complex
   ritual / specific blood-exchange / inheritance only
   / requires consent / requires denied consent / etc.

CALIBRATION TEST
- Could a reader, after the manuscript ends, name the
  cosmology's specific rules in five minutes? If the
  rules feel borrowed-but-vague, the lock-down has not
  been done.
- Are the rules CONSISTENT across the manuscript?
  Mythology Drift is the most common failure here.
- Does the cosmology have a specific named origin
  that distinguishes it from other vampire fictions?
- When a character invokes a rule, can the reader
  predict the consequence based on prior establishment?

ANTI-PATTERNS
- The "all of the above" cosmology that borrows from
  Stoker, Rice, Twilight, Buffy, and TVD without
  acknowledgement — the manuscript reads as pastiche
- Sun-vulnerability that bends per scene
- Feeding requirements that vary based on plot need
- Hierarchy mentioned but never specifically rendered
- Transformation ritual described once and forgotten
```

### The Cost-of-Immortality Rendering

The Forever-Young Glamour failure mode produces vampire
fiction where immortality is rendered as enviable
gift. The genre's foundational thematic charge — that
immortality is a TRAGIC gift, that to live forever is
to lose everything one loves — collapses when the cost
is unrendered or merely gestured at. The Cost-of-
Immortality Rendering is the requirement that every
vampire fiction render the specific costs of long life.

```
PRINCIPLE
The manuscript must render the cost of immortality
through at least four of the following six dimensions:

1. ACCUMULATED GRIEF — the specific named losses the
   vampire carries: the daughter who lived 87 years
   and is now 30 years dead; the spouse turned, then
   killed, then mourned for 200 years; the friend
   from 1812 whose face the vampire can no longer
   remember; the city that no longer exists
2. CULTURAL DISLOCATION — the specific period the
   vampire is from and how that produces friction
   with current era; the speech tics, the moral
   reflexes, the obsolete vocabulary, the unconscious
   gestures that mark them as out of time
3. ANHEDONIA / BOREDOM — the specific exhaustion of
   immortality; the meal that no longer surprises,
   the music that all sounds derivative, the
   conversation patterns the vampire has heard a
   thousand times; the discipline required to feign
   interest in the new
4. BIOLOGICAL ALIENATION — the specific ways the
   vampire's body no longer fits the human social
   contract; cannot eat human food (or can but
   without satisfaction); cannot warm to a touch;
   cannot age into the next phase; is locked in a
   single bodily moment forever
5. WATCH-EVERYONE-DIE — the specific habit the
   vampire has built around mortal relationships;
   the protocol of how long to engage before
   withdrawing; the practiced detachment; the failure
   of that practiced detachment when a particular
   mortal slips through
6. LANGUAGE / IDIOLECT DISLOCATION — the specific
   way the vampire's native period vocabulary
   surfaces in modern speech; the formality that
   marks ancient origin; the missed contemporary
   reference; the moment when an old word slips out

CALIBRATION TEST
- Could the manuscript end with the reader feeling
  envy of the vampire's immortality? If yes — the
  cost has not been rendered. The genre's signature
  charge requires the reader feel pity, not envy.
- Are at least four of the six cost-dimensions
  rendered through specific named detail rather than
  generic "centuries of loneliness"?
- Does the immortality genuinely cost the protagonist
  something the reader feels?

ANTI-PATTERNS
- "The weight of centuries" without specific weights
- "Eternal loneliness" without specific lonelinesses
- The immortal who is functionally a young adult
  with cool powers
- Cultural dislocation rendered as occasional
  anachronistic line rather than as constant
  temporal homelessness
- The "I have all the time in the world" trope
  without the cost-of-having-all-the-time
```

### The Consent-Frame Discipline

Vampire fiction's seduction-and-blood architecture is
foundational to the genre, but the contemporary register
requires modern consent calibration. The Erotic-Coded
Without Consent Frame failure mode treats power
imbalance as romantically default rather than as the
genre's specific craft problem. The Consent-Frame
Discipline is the requirement that the manuscript's
intimate / feeding scenes render the consent question
explicitly — not necessarily resolve it, but render it.

```
PRINCIPLE
For every significant feeding scene OR vampire-mortal
intimate scene, the manuscript must satisfy at least
three of the following four consent-frame
considerations:

1. POWER-DIFFERENTIAL ACKNOWLEDGEMENT — the manuscript
   acknowledges (in narration, in the mortal's
   interiority, in the vampire's interior reflection,
   or in the structural framing) that the vampire-
   mortal relationship operates with structural power
   imbalance: the vampire can compel, dazzle, mind-
   control, or out-strength the mortal; the mortal
   cannot meaningfully refuse if the vampire chooses
   not to permit refusal
2. SPECIFIC CONSENT MOMENT — the scene includes a
   specific named moment of consent (or specific
   refusal) on the mortal's part; the consent is
   visible, not assumed; the refusal (when it
   happens) is honored
3. MAGICAL-COERCION DISCLOSURE — if the cosmology
   includes vampire mind-influence powers (compulsion,
   glamour, thrall), the manuscript discloses
   whether the vampire is using them or refraining;
   "I want to make sure you actually want this"
   rendered as the vampire's specific ethical
   posture
4. ASYMMETRIC-RISK ACKNOWLEDGEMENT — the manuscript
   renders that feeding / intimacy carries asymmetric
   risk (the mortal could die or be turned without
   consent; the vampire could feed-too-deep through
   bloodlust; the mortal's memory could be stolen
   even with feeding-consent); the parties to the
   intimacy are not in the same risk position

CALIBRATION TEST
- Does the manuscript treat the vampire-mortal power
  imbalance as romantically self-evident or
  specifically render it?
- For every feeding / intimate scene, can a reader
  identify the consent moment?
- If the cosmology includes mind-influence powers,
  is their use or non-use visible to the reader?
- Does the manuscript render that asymmetric risk
  exists, or treat the relationship as symmetric?

ANTI-PATTERNS
- The "I couldn't help myself" feeding scene that
  treats bloodlust as automatic ethics-bypass
- The compelled-mortal romance presented as
  authentic mutual love without acknowledgement of
  the compulsion architecture
- The mortal who "accepts" feeding without specific
  rendering of the consent moment
- The vampire-romance that imports human-romance
  consent norms into a structurally asymmetric
  relationship without addressing the asymmetry
```

## Genre-Specific Revision Rules

### Six-Pass Vampire Fiction Audit (Run FIRST in editorial pipeline)

The Vampire Fiction Audit runs every chapter through six
named passes. Run them in order — each builds on the
last.

#### Pass 1: Mythology Consistency

Verify all vampire rules (sunlight, feeding, powers,
weaknesses) are consistent with previous chapters. Do
abilities operate within established parameters, with
no convenient new powers introduced when the plot
requires them? Are feeding requirements and bloodlust
consequences tracked accurately across the manuscript?
Is the transformation timeline (for fledglings)
progressing at an appropriate pace? The Mythology Drift
failure mode is caught here. if the cosmology bends to
plot convenience — sunlight optional in chapter 9,
lethal in chapter 14, optional again in chapter 22 —
rebuild for rule-consistency. The Specific-Cosmology
Lock-Down provides the spec; chapters that violate the
established lock-down must be rewritten to honour it.

#### Pass 2: Feeding Intensity

Verify every chapter contains either a feeding scene or
escalating hunger tension. Are feeding scenes rendered
with full sensory detail (not summarised or faded to
black)? Does the feeding reveal character — the
vampire's ethics, control, emotional response, the
specific way they treat this specific victim? Is the
hunger metaphor operating thematically (addiction,
desire, class, morality, religious-Eucharist parallel)
rather than functioning as mere plot mechanic? The
Vampire-as-Generic-Monster failure mode is caught
here. the genre's specific craft is the seduction-
and-blood architecture; if feeding scenes are
interchangeable with werewolf maulings or zombie
bites, the vampire-specific texture has been lost.

#### Pass 3: Immortal Voice

Verify ancient vampires think, speak, and perceive
differently from mortals and young vampires. Are
flashbacks triggered organically (sensory, emotional,
physical) rather than inserted for exposition? Is the
prose register appropriate to the vampire's age and
the scene's demands? Does the dialogue differentiate
vampires by era, personality, and humanity level? The
Modern-Vampire Costume failure mode is caught here. a
600-year-old character should not sound like a modern
30-year-old with cool powers. The Anachronism Engine
provides the technique. unconscious comparison, failed
adaptation, layered grief, obsolete reflex; chapters
where the immortal voice flattens to contemporary
register must be rebuilt for temporal specificity.

#### Pass 4: Predator/Prey Dynamic

Verify the danger in vampire/mortal interactions is
visceral and present (not just theoretical). Do social
scenes carry the undercurrent of the vampire's
predatory awareness? Is the power imbalance
acknowledged rather than romanticised away? Do mortal
characters have agency, complexity, and compelling
reasons to remain in danger? The Sparkle Trap and
Mortal-Lover Object failure modes are caught here. the
vampire must register as genuinely dangerous (not just
broody-dangerous-coded), and the mortal must register
as specifically themselves rather than as victim or
prize. The Predator's Sensorium technique applies. the
prose must operate in predator-perception register,
cataloguing rooms by threat and appetite before
furniture and decoration.

#### Pass 5: Atmosphere & Pacing

Verify the gothic mood is sustained even in
contemporary settings (darkness beneath the modern
surface). Does pacing alternate between sensual slow-
burn and sudden violence as the genre demands? Are
night cycles tracked (sunset-to-sunrise progression,
daylight danger)? Does the setting contribute to
atmosphere (not merely serve as backdrop)? The Dual
Register technique provides the calibration: gothic
register for feeding / ancient memory / formal vampire
interactions; contemporary register for modern
settings / young characters / humour / action. Chapters
where the gothic register is absent in contemporary
settings have lost the genre's signature craft —
darkness must show through the modern surface.

#### Pass 6: Specific-Cosmology + Cost-of-Immortality + Consent-Frame Integration

This pass is the vampire fiction integration check —
it ties the new techniques together and verifies the
genre's defining commitments are honoured chapter by
chapter and at manuscript level.

For SPECIFIC-COSMOLOGY: confirm the manuscript's
cosmology lock-down is operative through at least four
of the five elements (named origin / named rules of
vulnerability / named feeding architecture / named
hierarchy / named transformation ritual). Are the
rules consistent across the chapter? Does the chapter
introduce any new rule that wasn't established earlier?
The Lazy Lore Borrowing failure mode is caught here.
chapters that draw on tropes from multiple traditions
without acknowledgement must be rebuilt to commit to
the manuscript's declared cosmology.

For COST-OF-IMMORTALITY: confirm the chapter renders
the cost of long life through at least four of the
six dimensions (accumulated grief / cultural
dislocation / anhedonia / biological alienation /
watch-everyone-die / language idiolect dislocation).
Could a reader come away from this chapter feeling
envy of the vampire's immortality? If yes — the cost
has not been rendered, and the genre's signature
charge has been inverted to wish-fulfilment. The
Forever-Young Glamour failure mode is caught here.

For CONSENT-FRAME: identify the chapter's feeding
scenes and intimate scenes. For each, verify at least
three of the four consent-frame considerations are
present (power-differential acknowledgement / specific
consent moment / magical-coercion disclosure /
asymmetric-risk acknowledgement). The Erotic-Coded
Without Consent Frame failure mode is caught here.
the genre permits power-imbalance romance and feeding
intimacy, but the modern register requires the
imbalance be addressed within the prose rather than
romanticised as default.

## Names & Patterns to Avoid

### Vampire Character Names. NEVER USE
- On-the-nose predator names: Fang, Blade, Raven, Shadow, Nightshade, Bloodworth
- Direct lifts from iconic vampire fiction: Lestat, Dracula, Carmilla, Akasha, Selene, Alucard (too recognisable)
- Overwrought gothic names: Lord Darkmore, Countess Sanguis, Viktor Nocturne
- Single-name mystique cliche: going only by "The Ancient One," "The Elder," "The Sire"

### Vampire Location Names. NEVER USE
- Horror-signalling names: Blood Manor, Castle Nightfall, the Crimson Catacombs
- Gothic cliche formula: "[Dark Adjective] [Grand Building]". Shadowmere Hall, Darkwood Manor
- Names from famous vampire works: Carfax, the Talamasca, Barovia (too associated with specific properties)

### Forbidden Setups & Cliches
- The "I didn't choose this" vampire who never genuinely grapples with what they've become
- The mortal love interest who exists solely to be endangered and rescued
- The vampire hunter who is secretly attracted to the vampire (unless subverted meaningfully)
- Instant sire/fledgling romantic bond without earned development
- The ancient vampire who is conveniently omniscient whenever the plot requires information
- Feeding as purely sexual metaphor with no acknowledgement of the violence
- The vampire ball/masquerade as a scene that exists for aesthetic rather than narrative purpose
- "I'm a monster" monologues that substitute for actually showing the monstrousness

### Use Instead
- Names with historical weight appropriate to the vampire's era of origin (research authentic period naming conventions)
- Location names that sound real: named after geography, former owners, or local features. the name becomes sinister through the story, not before it
- Vampire names that carry their mortal identity: the name they were born with, not the name they adopted for dramatic effect
- Foreign names researched for accuracy if the vampire originates from a specific culture

## Comp Titles

Vampire fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Dracula* — Bram Stoker (1897): the vampire-gothic foundation.
- *Carmilla* — Sheridan Le Fanu (1872): the female-vampire template.
- *Interview with the Vampire* — Anne Rice (1976): the modern literary-vampire benchmark.
- *Salem's Lot* — Stephen King (1975): the small-town vampire-horror archetype.

### Contemporary (current best-in-class)

- *Twilight* — Stephenie Meyer (2005): mass-market YA-vampire-romance benchmark.
- *Empire of the Vampire* — Jay Kristoff (2021): contemporary literary-vampire-fantasy.
- *A Dowry of Blood* — S.T. Gibson (2021): vampire-romance reframing of Dracula's brides.
- *Certain Dark Things* — Silvia Moreno-Garcia (2016): Mexican-narcotrafficking vampire fiction.
- *Fledgling* — Octavia Butler (2005): genre-defining diverse vampire-fiction.
- *Iron Widow* — Xiran Jay Zhao (2021): vampire-mecha-fantasy crossover.
- *The Coldest Girl in Coldtown* — Holly Black (2013): YA vampire-quarantine fiction.
- *The Reformatory* — Tananarive Due (2023): segregation-era vampire-horror.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic Gothic**. Grand, dark, atmospheric: a figure silhouetted against moonlit architecture, fog-draped streets, the suggestion of fangs or blood without explicit horror; dramatic, seductive, and sweeping
- **Intimate/Portrait**. Close-up, arresting: a face half in shadow, lips parted, a drop of blood, eyes that are ancient in a young face; the cover is a confrontation with the predator
- **Typographic/Minimal**. Bold title treatment dominates: blood-red or metallic text on deep black, minimal imagery (a fang mark, a single drop, a crescent moon); elegant restraint
- **Illustrated/Painterly**. Dark romantic illustration: detailed, atmospheric, suggesting narrative; figures in period or modern dress, candlelight or neon, beauty and menace intertwined

### Genre Cover Aesthetics
- **Styles:** Figures in dramatic light/shadow contrast, architectural grandeur (gothic or urban), night cityscapes, intimate two-figure compositions suggesting danger and desire, single-source lighting (moonlight, candlelight, neon), blood as colour element (not splatter)
- **Colours:** Deep crimson, arterial red, midnight black, cold silver-blue, bruised purple, tarnished gold; the palette should feel DANGEROUS: rich, dark, and seductive. Avoid bright reds (that reads thriller); use dark, wine-stained reds instead. Metallic accents (silver foil, gold emboss) signal premium positioning
- **Elements:** Fangs (suggested, not cartoonish), blood (as colour wash or single drop, not gore), moonlight, urban night, gothic architecture, period costume, modern fashion with gothic undertones, mirrors (empty reflections), roses (thorned), candlelight, veins/arteries as decorative elements
- **Typography:** Elegant serif or dramatic display faces; metallic foil or emboss; title should feel ANCIENT or CARVED; red-on-black or silver-on-black colour combinations; the author name should be prominent (vampire fiction is brand-driven)

### Market Positioning
Vampire fiction covers must signal "seductive, dark, literary, and dangerous." The genre sits at the intersection of gothic horror, dark romance, and urban fantasy. covers should reflect the specific subgenre while maintaining the core aesthetic of beauty-meets-danger. Position against Rice, Kostova, Harkness, Harris, Ward. At thumbnail size, the high contrast (dark background, striking focal element) and metallic/red accents create immediate genre recognition. Distinguish from paranormal romance (more literary, less bare-chested) and from horror (more beautiful, less grotesque).

### Cover Design DON'Ts
- No cartoonish fangs or comedy-horror imagery (the genre takes itself seriously)
- No bright, saturated colours (vampire fiction is DARK. even urban vampire covers are moody)
- No generic stock-photo models in leather (the "urban fantasy uniform" cheapens the genre)
- No excessive gore or splatter (blood should be elegant, not gratuitous)
- No daylight scenes (even if the story includes them, the cover lives at night)
- No overcrowded compositions. vampire covers need negative space for atmosphere and menace
- No sparkle effects or glitter overlays (the association is too specific and too polarising)
