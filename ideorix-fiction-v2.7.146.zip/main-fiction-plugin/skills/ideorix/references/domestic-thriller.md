---
name: domestic-thriller-genre
description: Genre-specific instructions for domestic thriller fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [thriller, drama]
---

# Domestic Thriller. Genre Plugin

## Metadata
- id: domestic-thriller
- name: Domestic Thriller
- icon: 🏠
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,000"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Seven-Point Story Structure", "The Story Circle"]

## Subgenre Options
Present during setup:
- **Marriage Thriller**. The danger is the spouse. Behind the perfect marriage lies manipulation, control, secrets, or violence. The protagonist must navigate a relationship that has become a trap (B.A. Paris, Shari Lapena, T.M. Logan)
- **Neighbourhood Thriller**. The threat comes from the community: a neighbour, a parents' group, a homeowners' association, or the dark dynamics of a seemingly perfect street. Surveillance, gossip, and social pressure as weapons (Lisa Jewell, Liane Moriarty)
- **Family Secrets**. Generational lies, hidden histories, and family dynamics that turn toxic. The protagonist uncovers something about their own family that changes everything (Lisa Jewell, Greer Hendricks)
- **Nanny / Caregiver**. An outsider enters the domestic space and destabilises it. The help, the au pair, the home nurse. someone with intimate access and unclear motives (Freida McFadden, Leila Slimani)
- **Maternal Thriller**. Pregnancy, new motherhood, or child safety as the pressure point. Hormonal vulnerability, isolation of early parenthood, and the terror of threats to a child (Shari Lapena, Lisa Jewell)
- **Cohabitation**. Flatmates, lodgers, or cohabiting strangers. The shared domestic space as a pressure cooker where privacy is impossible and boundaries are violated (Ruth Ware)

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,000 words
- Pacing: SLOW BURN with mounting domestic pressure. tension comes from the
  ordinary turned sinister, not from action sequences
- Must end with: A domestic detail that carries threat. something overheard,
  something found, something that doesn't add up in the household routine
- Must open with: The protagonist in their domestic world. show the "normal"
  surface before the cracks appear

BEATS PER CHAPTER
1. Domestic Beat. The protagonist in their home/family/relationship environment.
   Show routine, obligation, the texture of daily life.
2. Fissure Beat. Something is wrong. A detail in the domestic routine that doesn't
   fit, a partner's unexplained absence, a child's odd comment, a drawer that was
   locked and now isn't.
3. Performance Beat. The protagonist maintains the facade. Smiles at neighbours,
   cooks dinner, attends the school run. while internally processing the fissure.
4. Investigation Beat. The protagonist takes a small step toward the truth: checks
   a phone, opens an email, asks a careful question, drives past an address.
5. Consequence Beat. The investigation has a cost: the antagonist notices, a secret
   is nearly exposed, the protagonist's cover story frays, or they learn something
   they can't un-know.

THE DOMESTIC CAGE ARCHITECTURE (CRITICAL)
- The protagonist is TRAPPED, but the cage is invisible to outsiders.
- The bars are made of: children, finances, social standing, fear, love, denial,
  immigration status, religious community, family pressure, or the protagonist's
  own complicity.
- Establish WHY the protagonist can't simply leave in the first three chapters.
  The reason must be psychologically real and specific to this character.
- The cage tightens across the manuscript: options that existed in Chapter 1
  are closed off by Chapter 10. Escape routes are blocked one by one.
- At the midpoint, the protagonist realises the cage exists. before this,
  they were rationalising it as "normal" or "love" or "how marriages work."
- In Act 3, the protagonist finds or creates a gap in the cage. not easily,
  and not without cost.

THE FACADE SYSTEM
- Layer 1. Public Face: What the neighbours, school parents, colleagues see.
  Perfect couple, lovely home, happy family.
- Layer 2. Private Reality: What happens behind closed doors. Control, silence,
  fear, manipulation, or hidden lives.
- Layer 3. Secret Truth: What even the protagonist doesn't fully know yet.
  The buried history, the hidden account, the second phone, the previous wife.
- The gap between layers IS the story. Each chapter widens the gap until the
  facade can no longer hold.
- Other characters exist at different layers of knowledge: the best friend who
  suspects, the neighbour who saw something, the colleague who knows a secret.

ESCALATION THROUGH DOMESTIC DETAIL
- Weapons in this genre are not guns. they are:
  - Financial control (cancelled credit cards, drained accounts, undisclosed debts)
  - Social manipulation (turned friends against the protagonist, controlled the narrative)
  - Gaslighting (moved objects, denied conversations, fabricated evidence)
  - Children as leverage ("I'll get custody," using the children as messengers or spies)
  - Isolation (moving to a remote area, cutting off family, monitoring communications)
  - Legal threats (restraining orders used offensively, weaponised institutions)
  - Emotional withdrawal/flooding (love-bombing then ice, unpredictable affection)
- Escalation is DOMESTIC: the threat level rises through household events, not
  chase scenes. A locked phone becomes a locked room becomes a locked life.

DUAL TIMELINE STRUCTURE (STANDARD FOR THIS GENRE)
- THEN chapters: How it began. The courtship, the early relationship, the move,
  the wedding. Show how the cage was built, one bar at a time.
- NOW chapters: The present crisis. The protagonist discovers something,
  begins to see the pattern, starts to plan.
- The timelines converge at the climax: what happened THEN is finally revealed
  and directly causes what happens NOW.
- Alternate chapters: THEN / NOW / THEN / NOW (or every 2-3 chapters)
- THEN chapters move forward in time; NOW chapters may cover only days.
- The reader sees the trap being built (THEN) while watching the protagonist
  try to escape it (NOW).

CHAPTER ENDING REQUIREMENTS
- Every chapter must end with the reader needing to know what happens next.
- Domestic thriller hooks are NOT action cliffhangers. They are:
  - A found object (the receipt, the photo, the key, the phone)
  - An overheard conversation (partial, ambiguous, alarming)
  - A child's innocent revelation ("Daddy's friend comes when you're at work")
  - A closed door / locked room / hidden space discovered
  - A lie caught (the partner said they were at work; the protagonist drove past the office)
  - A kindness that feels like a threat ("I've taken care of everything, darling")
  - A message or call that shouldn't exist

FORBIDDEN IN DOMESTIC THRILLER
- Action sequences that belong in a different genre (car chases, gunfights, explosions)
- The protagonist having unlimited resources, wealth, or connections to escape easily
- Children used solely as props without interiority or psychological impact
- Domestic violence depicted without emotional weight or consequence (not entertainment)
- The "twist" that the protagonist was the abuser all along (unless the ENTIRE book
  is structured for this. extremely difficult to do ethically)
- Neighbours/friends who conveniently never notice anything (explain their blindness)
- Police who immediately believe the protagonist and solve everything
  (institutions often fail domestic abuse victims. depict this honestly)
- The antagonist having no charm or social competence (they MUST be convincing
  to others; that's how they get away with it)
- Escaping abuse depicted as simple or straightforward (it never is)
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation + Anticipation (sustained tension), Affection with the trapped protagonist, Revelation at the controlled-explosion climax.

VOICE & TONE
- POV: First person present tense (primary, creates immediacy and claustrophobia)
  OR first person past tense (allows reflection and the voice of someone who survived)
  OR alternating first person (dual POV: protagonist and antagonist, or two timelines)
- Voice: Domestic, intimate, particular. The narrator notices the specific textures
  of their world: the brand of coffee, the pattern of the wallpaper, the exact
  sound of a key in the lock. This specificity grounds the reader in the home
  and makes its violation feel personal.
- Tone: Surface calm over deep unease. The prose mirrors the protagonist's
  performance of normalcy. measured, controlled, coping. until it fractures
  under pressure.

THE PHASE-GATED VOICE SYSTEM (CRITICAL)
The narrator's voice CHANGES across the manuscript as their understanding shifts.
This is not accidental. it is architectural.

Phase 1. COMPLIANT (Act 1):
- Sentence structure: Measured, accommodating, self-minimising
- Internal monologue: Excuses, rationalisations, self-blame
- Vocabulary: "It's fine." "He didn't mean it." "I should have."
  "I'm probably overreacting." "It's my fault."
- Observations: The narrator notices beauty, order, comfort. filtering out
  the darkness. They describe their home as lovely. Their partner as caring.
- Reader effect: The reader may not immediately see anything wrong.
  or may see warning signs the narrator is minimising.

Phase 2. QUESTIONING (Early Act 2):
- Sentence structure: Questions start appearing. "Was that normal?" "Had he always...?"
- Internal monologue: Doubt creeps in. The rationalisations still come but arrive
  slower, with less conviction.
- Vocabulary: "Something felt wrong." "I couldn't explain why." "I noticed. but
  then I told myself—"
- Observations: The narrator begins to see the domestic space differently.
  The lovely kitchen is also a place where the knives are kept.
- Reader effect: The reader's suspicions are confirmed. They root for the
  protagonist to see what they're seeing.

Phase 3. ASSERTIVE (Late Act 2):
- Sentence structure: Shorter. More declarative. Less hedging.
- Internal monologue: "I knew." "This was wrong." "He was lying."
  The self-blame fades. Clarity replaces confusion.
- Vocabulary: Active verbs replace passive. "I decided." "I searched."
  "I called." The protagonist is ACTING, not reacting.
- Observations: The narrator sees the domestic space as it is. a controlled
  environment. The beauty is a set. The comfort is a cage.
- Reader effect: Satisfaction. The protagonist is waking up. But also dread.
  the antagonist will notice.

Phase 4. TRANSFORMED (Act 3):
- Sentence structure: The narrator's true voice emerges. stronger, clearer, angular.
- Internal monologue: Strategic. Planning. No longer explaining or excusing.
- Vocabulary: Direct, economical, decisive. The narrator says what they mean.
- Observations: The domestic space is now a tactical environment. exits, evidence,
  timing, witnesses.
- Reader effect: The protagonist is a different person from Chapter 1. The
  transformation is earned through every intervening chapter.

DIALECT CONSISTENCY (IMPORTANT)
- Establish the dialect in the Story Bible (British English, American English, etc.)
- Maintain 100% consistency throughout. a single "fall" in a British novel is jarring
- Common British/American traps to watch:
  - autumn / fall
  - colour / color
  - pavement / sidewalk
  - boot (of car) / trunk
  - torch / flashlight
  - flat / apartment
  - "have got" / "gotten"
  - mobile / cell phone
  - post / mail
  - curtains / drapes
  - wardrobe / closet
  - hob / stovetop
  - cot / crib (for babies)
  - nappy / diaper
- If British English: NEVER use "fall" for autumn, "gotten", "apartment" for "flat",
  "cell phone" for "mobile", "diaper" for "nappy", or "closet" for "wardrobe"
- Domestic thrillers are especially vulnerable to dialect slips because the vocabulary
  of home life differs significantly between British and American English
- The Prose Craft Improver should scan for dialect inconsistencies during its pass

PROSE IMPERATIVES
- THE DOMESTIC SENSORIUM: Domestic thrillers live in sensory detail specific to
  the home. The smell of a particular cleaning product. The sound of a garage
  door opening at an unexpected time. The exact weight of silence at the dinner table.
  These details are the language of this genre.
- THE ORDINARY AS THREAT: Make everyday actions carry menace. Cooking dinner when
  you're not sure what your partner knows. Checking the mail when you're waiting for
  a letter that could expose everything. Putting the children to bed when the argument
  hasn't finished. The mundane IS the battlefield.
- PHYSICAL SPACE AS CHARACTER: The house is not a setting. it's a participant.
  Describe rooms in terms of what they permit and what they prevent. Where can you
  be overheard? Which drawers lock? Where is the only phone charger? How far is
  it from the bedroom to the front door?
- BODY LANGUAGE OVER DIALOGUE: In domestic thrillers, what characters DO with their
  hands, eyes, posture, and proximity reveals more than what they say. A partner who
  stands between the protagonist and the exit. A friend who won't make eye contact.
  A child who flinches.
- SILENCE AS DIALOGUE: The domestic thriller's most powerful scenes are often silent.
  Two people in a kitchen not speaking. The things that are understood without words
  in a long relationship. used now as weapons or shields.

DIALOGUE FOR DOMESTIC THRILLER
- Everyday conversation with subterranean currents: "How was your day?" means
  "Where were you really?" "Fine" means "I'm not telling you."
- The language of domestic control:
  - "I'm only saying this because I love you"
  - "You always twist things"
  - "I've already taken care of it"
  - "We agreed not to discuss this"
  - "Are you sure that happened?"
- Arguments that never reach resolution. interrupted by children, by doorbells,
  by the arrival of guests. The unfinished fight is more terrifying than the eruption.

CHAPTER 1 PAGE-TURNER RHYTHM (domestic thriller adaptation)

Domestic thrillers are slow burn. but Chapter 1 still must hook. The
hook is UNEASE, not action. By Ch 1 end, the reader must feel that
something is wrong in this house, even if they can't name it.

- Prose rhythm: medium sentences (15-20 words) with occasional short
  punches (5-8 words) when the narrator registers a micro-wrongness.
  The shortening IS the tell. the reader feels the narrator flinch.
- Sensory detail: weighted toward DOMESTIC specificity in the first
  half (grounding the reader in the home); weighted toward WRONG
  details in the second half (something out of place, a smell that
  shouldn't be there, a door that's usually open now closed).
- Interiority: permitted in Ch 1 (this genre lives inside the
  narrator's head) but must include at least ONE self-correction
  ("It's nothing. Of course it's nothing.") that signals to the
  reader: it IS something.
- Dialogue: at least one exchange where the subtext contradicts the
  surface. The reader should be able to hear what ISN'T being said.
- Chapter hook: not "new threat". rather "the question the narrator
  can't stop asking." The reader turns the page to find the answer.
- Tension slider: ≥6 for Ch 1 (lower baseline than action thriller
  but still well above neutral). The tension is atmospheric, not
  physical. but it must be PRESENT, not deferred to Ch 2.
- Performative dialogue: How the couple speaks in front of others vs. alone.
  The shift between public warmth and private ice.
- Children's dialogue: Innocent observations that carry devastating information.
  Kids repeat what they've seen and heard without understanding the significance.
- The protagonist's dialogue evolves with the voice phases:
  Phase 1: Accommodating, deflecting, agreeing
  Phase 2: Tentative questions, careful challenges
  Phase 3: Direct confrontation, demands for truth
  Phase 4: Strategic, controlled, says only what serves the plan

PACING FOR DOMESTIC THRILLER
- Tension comes from ROUTINE DISRUPTED, not action sequences.
- The "pressure cooker" technique: Each chapter adds one more element to an
  already unbearable situation. Financial stress + a partner's lie + a child's
  illness + a suspicious phone call + a locked room + an unexplained absence.
  The combination is suffocating.
- Domestic time moves in specific rhythms: school runs, meal times, bedtime routines,
  weekend obligations. Use these rhythms as a structural spine. and disrupt them
  to signal escalation.
- The "held breath" technique: Scenes where the protagonist is doing something
  forbidden (searching a partner's belongings, making a secret phone call, meeting
  someone in secret) while the threat of being caught is imminent. These scenes
  create unbearable tension from domestic risk, not physical danger.
- Never more than one chapter of pure investigation without returning to the
  domestic pressure. The reader must feel the protagonist's double life:
  secret investigation AND maintained facade.
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

DOMESTIC TENSION (40% of total):
- Domestic atmosphere: Does every chapter feel like the home is a pressure cooker? (0-100)
- Facade management: Is the gap between public and private life palpable? (0-100)
- Escalation through detail: Do domestic discoveries (found objects, overheard
  conversations, financial revelations) drive the plot? (0-100)
- Trapped protagonist: Is the protagonist's inability to leave psychologically
  convincing? (0-100)
- Routine disruption: Are the rhythms of domestic life used structurally to
  create and release tension? (0-100)

VOICE & CHARACTER (30% of total):
- Voice evolution: Does the narrator's voice demonstrably change across the
  four phases (Compliant → Questioning → Assertive → Transformed)? (0-100)
- Interiority: Is the reader fully immersed in the protagonist's domestic world
  and psychological state? (0-100)
- Antagonist plausibility: Is the antagonist charming in public, controlling in
  private, and psychologically specific? (0-100)
- Relationship authenticity: Does the relationship feel like a real relationship
  (with history, texture, intimacy) rather than a genre construct? (0-100)
- Supporting cast: Do neighbours, friends, family, and children feel real and
  serve the story structurally? (0-100)

PLOT & REVELATION (30% of total):
- Dual timeline (if used): Do THEN and NOW illuminate each other progressively? (0-100)
- Clue planting: Are discoveries embedded in domestic detail, not dropped
  artificially? (0-100)
- Twist quality: Does the final revelation reframe the domestic reality? (0-100)
- Resolution authenticity: Does the ending reflect the real difficulty of escaping
  domestic danger? (0-100)
- Stakes: Are the stakes domestic (children, home, financial security, social standing)
  rather than abstract? (0-100)

AUTOMATIC FAILS (score = 0):
- EASY ESCAPE: Protagonist could obviously leave but doesn't for no psychological reason
- CARTOON VILLAIN: Antagonist has no charm, no public persona, no psychological depth.
  just "bad person is bad"
- DOMESTIC VIOLENCE AS ENTERTAINMENT: Abuse depicted graphically without emotional
  weight, consequence, or the protagonist's psychological response
- PASSIVE PROTAGONIST: Narrator never takes any action toward escape, truth, or agency
  across the entire manuscript
- CHILDREN AS PROPS: Children present in the story but with no interiority, no realistic
  behaviour, and used only as plot devices
- FACADE COLLAPSE WITHOUT CONSEQUENCE: The public facade breaks but nothing changes.
  no social repercussions, no antagonist escalation
- INSTITUTIONAL CONVENIENCE: Police, lawyers, or social services immediately believe
  the protagonist and solve the problem (doesn't reflect real institutional failures)
- VOICE STASIS: The narrator's voice is identical in Chapter 1 and Chapter 20.
  no evolution despite revelations and crisis
- GENRE CROSSOVER: Extended action sequences, chase scenes, or thriller-style
  physical confrontations that belong in a different genre
```

## Continuity Rules

```
DOMESTIC THRILLER CONTINUITY. WHAT TO TRACK

HOUSEHOLD STATE (CRITICAL):
- Layout of the home: rooms, locked/unlocked doors, storage areas, hiding spots
- Who has keys/access codes/passwords to what?
- Where are important objects? (The hidden phone, the locked box, the will,
  the passports, the children's medical records)
- What has been moved, changed, or discovered. and does the other party know?
- Financial state: bank accounts, credit cards, cash reserves, debts, who controls what
- Vehicle access: whose name is on the car, who has the keys
- Technology: shared vs. private devices, monitored email, GPS tracking,
  smart home surveillance, shared cloud accounts

RELATIONSHIP POWER DYNAMICS (TRACK CHAPTER BY CHAPTER):
- Who has the power in THIS scene? (Power shifts constantly in domestic thrillers)
- What leverage does each party hold? (Secrets, money, children, reputation, evidence)
- What does the protagonist currently believe about the relationship?
- What does the antagonist believe the protagonist knows?
- When was the last "good" moment? (Domestic thrillers need moments of genuine
  tenderness or apparent normalcy to make the horror register)
- Escalation markers: What has the antagonist done that they haven't done before?
  (First raised voice → first threat → first physical action → each escalation
  must be tracked)

CHILDREN'S STATE (if children present):
- Ages, school schedules, activities, routines
- What have the children witnessed?
- What have the children said that carries inadvertent significance?
- Who is the primary caregiver? How is this used as leverage?
- Children's emotional state: Are they sleeping? Acting out? Withdrawing?
- Custody implications: What would happen to the children if the protagonist left?
- Childcare logistics: Who watches the children when the protagonist investigates?

SOCIAL NETWORK MAP:
- Who are the protagonist's friends? How close? How much do they know?
- Who are the antagonist's allies (conscious or unconscious)?
- Which social connections has the antagonist damaged or cut off?
- Who has the protagonist confided in? What was revealed?
- Who is genuinely supportive vs. who reports back to the antagonist?
- The protagonist's family: distance, involvement, awareness of the situation
- Professional contacts: does the protagonist work? Who at work might help?

INVESTIGATION STATE:
- What evidence has the protagonist gathered?
- Where is the evidence stored? (Is it safe from discovery?)
- What digital trails has the investigation left? (Browser history, phone calls,
  bank withdrawals for a private investigator, etc.)
- What has the protagonist learned vs. what they suspect vs. what they've concluded?
- Has the antagonist discovered any of the protagonist's investigation? When?
- What's the protagonist's escape plan? How complete is it?

THEN-TIMELINE TRACKING (if using dual timeline):
- Chronological list of events in the past timeline
- Which events have been revealed to the reader, and in which chapter?
- Which past events are still unrevealed (upcoming revelations)?
- How does each THEN chapter connect to the NOW chapter it's paired with?
- Key dates: when they met, when they moved in, when the first warning sign appeared,
  when a specific incident happened
- What the protagonist believed at each past moment vs. what actually occurred

FACADE STATUS:
- Current state of the public facade: intact / cracking / crumbled
- Who suspects something? What do they suspect?
- What social events or obligations are upcoming? (These force the performance)
- Has anyone confronted the protagonist about the relationship?
- Has anyone confronted the antagonist?
- What would happen if the truth became public? (Social, legal, financial consequences)

PHYSICAL AND EMOTIONAL STATE:
- Protagonist's sleep, eating, physical symptoms of stress
- Medication or substance use (especially if used to cope)
- Emotional state: denial / awareness / planning / crisis
- Physical marks or evidence of conflict (bruises, damage, repairs)
- Protagonist's internal timeline: when did they first suspect? When did they know?
```

## Character Rules

```
DOMESTIC THRILLER CHARACTER ARCHETYPES

THE TRAPPED PROTAGONIST:
- Intelligent but constrained. their cage is circumstantial, not intellectual
- Has a specific, psychologically real reason for staying:
  - Children (most common and most powerful)
  - Financial dependence (no access to money, no separate income)
  - Immigration status tied to the partner
  - Religious or cultural community that would shun them
  - Genuine love for the person the antagonist sometimes still pretends to be
  - Fear (of violence, of losing custody, of not being believed)
  - Shame (not wanting others to know, self-blame)
- Had a life before the relationship. skills, friends, identity. that has been
  systematically eroded. Reclaiming pieces of this former self is part of the arc.
- Makes mistakes. Gets caught investigating. Trusts the wrong person. Returns to
  the antagonist when they shouldn't. This is REALISTIC, not weak.
- Their growth is measured in clarity: at the start, they can't see the cage.
  By the end, they can describe every bar. and know which one is weakest.
- NEVER passive for more than two consecutive chapters. Even trapped characters
  make choices: to investigate, to confide, to plan, to pretend.

THE DOMESTIC ANTAGONIST:
- Publicly admirable. Charming, successful, well-liked. The neighbours adore them.
  "You're so lucky" is something the protagonist hears constantly.
- Privately controlling. Their control is SPECIFIC. not generic "bad partner."
  Define their toolkit:
  - Financial controller: Monitors spending, restricts access, creates dependence
  - Social engineer: Manages the protagonist's friendships, poisons relationships
  - Gaslighter: Denies events, reframes reality, makes the protagonist doubt themselves
  - Emotional manipulator: Love-bombing → withdrawal → rage → reconciliation cycle
  - Information hoarder: Has secrets, accesses the protagonist's communications
- Their motivation is psychologically SPECIFIC:
  - Fear of abandonment driving need for control
  - Narcissistic injury (the protagonist saw something they weren't supposed to)
  - Protection of a secret that would destroy their public persona
  - Genuine belief that their control is love/protection
  - Pathological need for power rooted in their own history
- They ADAPT. When the protagonist pushes back, the antagonist changes tactics.
  Escalation is not linear. they may return to charm when force fails.
- They have moments of genuine humanity. this is what makes them terrifying.
  If they were monsters 100% of the time, the protagonist would leave. The
  intermittent reinforcement (cruelty → tenderness → cruelty) is the trap.

THE OUTSIDE WITNESS:
- A character who sees something the protagonist can't or won't.
- Often a neighbour, colleague, friend, or family member of the protagonist.
- Their perspective provides the reader with external confirmation that the
  domestic situation is abnormal.
- They may try to help. and be rebuffed by a protagonist still in denial.
- They may be silenced by the antagonist. warned off, discredited, charmed.
- Their role intensifies in Act 2: they become either an ally or a lost opportunity.
- If they are a child (observing parents), their observations are devastating
  precisely because they're delivered without adult interpretation.

THE CHILD (if present):
- Not a plot device. A person with their own experience of the domestic situation.
- Age-appropriate awareness: a 4-year-old parrots phrases without understanding;
  a 12-year-old understands more than they show.
- Their behaviour reflects the home environment: hypervigilance, people-pleasing,
  acting out, silence, bedwetting, regression.
- They can be the protagonist's motivation for both staying AND leaving.
- Their dialogue carries information they don't understand but the reader does.
- NEVER put a child in physical danger for cheap tension. If a child is at risk,
  the threat must be handled with proportionate gravity.

THE PROFESSIONAL:
- Therapist, lawyer, police officer, teacher, doctor. someone in a professional
  role who could help.
- Domestic thrillers are HONEST about how institutions often fail:
  - Therapist who is fooled by the antagonist's charm in couples therapy
  - Police who don't act without visible injuries
  - Lawyer who explains how custody law may not protect the protagonist
  - Teacher who files a report that goes nowhere
- These characters are not villains. they're systemic limitations given a face.
- When one of these characters DOES help, it should feel hard-won, not automatic.

ANTAGONIST PRESENCE BALANCE (Writer-Level Enforcement):
In domestic thrillers, the antagonist is ALWAYS present. even when off-page.
Quantitative tracking per chapter:
- DIRECT PRESENCE: Scenes where the antagonist appears, speaks, or acts on-page
- SHADOW PRESENCE: Scenes where the antagonist's control is felt through its effects
  (rules the protagonist follows, spaces arranged by the antagonist, habits imposed
  by the relationship, the protagonist's hypervigilance)
- Per-chapter minimum: EVERY chapter must contain at least one direct or shadow presence
  beat. The domestic antagonist is inescapable. that's the point.
- CRITICAL RATIO: In Acts 1-2, the antagonist should appear in approximately:
  - 70-80% of chapters (direct). they live in the same house
  - 100% of chapters (direct + shadow combined). their influence is everywhere
- ABSENCE AS WEAPON: When the antagonist IS absent from a chapter (at work, away),
  the protagonist's experience of that absence is itself a form of presence (relief,
  anxiety about what they'll find, using the time to investigate).
- The Character Tracker will flag any chapter where neither direct nor shadow
  antagonist presence is detected. This is almost always an error in domestic thriller.

VOICE DIFFERENTIATION:
- Protagonist: Evolves across four phases (see Voice System above).
  Interior monologue is the reader's primary window.
- Antagonist: Publicly warm, articulate, self-deprecating. Privately precise,
  cold, strategic. The shift between registers is chilling.
- Children: Fragmented observations, emotional honesty, no filters.
  "Why does Mummy cry in the bathroom?" "Daddy said we can't tell anyone."
- Outside witness: Concerned but uncertain. They ask questions rather than
  make accusations. "Is everything okay? You'd tell me, wouldn't you?"
- Professionals: Procedural language, measured tones. They've seen this before
  but are bound by rules.

VOICE DIFFERENTIATION. QUANTITATIVE CHECK:
For each PAIR of major characters, identify at least 3 distinguishing dialogue features.
If any two characters share >2 features, one must be revised before proceeding.

Domestic thrillers with confined casts are especially vulnerable to voice convergence
between the protagonist's inner circle. Ensure different:
- Sentence length patterns (protagonist evolves across 4 phases; others are stable)
- Vocabulary domain (one domestic, one professional, one emotional, one controlling)
- Response to confrontation (one placates, one escalates, one deflects, one withdraws)
- What they talk about when uncomfortable (one changes subject, one makes jokes,
  one asks questions, one goes silent)
- Physical behaviour during dialogue (one maintains eye contact, one looks away,
  one touches the other person, one creates physical distance)

The Character Tracker verification agent will flag voice convergence between
any two major characters. If flagged, the Writer must differentiate before proceeding.
```

## Arc Rules

```
DOMESTIC THRILLER STORY STRUCTURE

ACT 1: THE SURFACE (Chapters 1-5 for novella, 1-8 for novel)
- Chapter 1: Establish the domestic world. Show the home, the relationship, the
  routine. The reader sees what the neighbours see. a functioning household.
  But plant the FIRST fissure: one detail that isn't quite right.
- Chapters 2-4: Deepen the domestic reality. Introduce the relationship dynamics,
  the children (if present), the social network, the antagonist's public persona.
  Show the protagonist's daily life with enough specificity that the reader
  feels at home in this house.
- The THEN timeline (if using): begins with the origin of the relationship.
  Show what drew the protagonist in. The early charm. The first concession.
  The first time the protagonist adjusted their behaviour to accommodate.
- Inciting discovery: The protagonist finds, sees, or overhears something that
  cracks the surface. A phone buzzing with a strange message. A receipt for
  something unexplained. A locked drawer where there was no lock before.
- End of Act 1: The protagonist has a question they can't stop asking.
  The domestic routine continues but the protagonist is watching differently.
  The reader knows something is wrong. The protagonist is beginning to suspect.

ACT 2A: THE CRACKS (Chapters 6-10 for novella, 9-16 for novel)
- The protagonist begins investigating. carefully, fearfully, in stolen moments.
- Each chapter reveals a new domestic fissure: financial, sexual, social, historical.
- The THEN timeline reveals how the cage was built: the move that isolated them,
  the financial arrangement that created dependence, the friend who was driven away.
- The antagonist's public persona remains intact. the protagonist can't make
  anyone see what they're seeing.
- An ally appears (friend, neighbour, professional). but helping is complicated.
- The protagonist's voice shifts from Compliant to Questioning.
- False conclusion: The protagonist thinks they understand the secret. but they've
  only found the surface layer.
- Midpoint: A MAJOR discovery that shatters the protagonist's remaining denial.
  This is not a plot twist. it's the moment the protagonist SEES the cage clearly
  for the first time. The comfortable lie of "it's not that bad" is destroyed.

MIDPOINT CRISIS:
- The protagonist confronts the reality of their situation: they are trapped
  and the person they live with is dangerous.
- This may involve:
  - Discovering financial devastation (the accounts are empty, the debt is enormous)
  - Finding evidence of a previous victim (the ex-wife, the former partner)
  - Being directly threatened for the first time
  - A child saying something that makes the danger undeniable
- The protagonist must CHOOSE: maintain the facade and survive day-to-day,
  or begin planning to escape/expose the truth.
- They choose to act. and this choice immediately raises the stakes.

ACT 2B: THE ESCAPE PLAN (Chapters 11-16 for novella, 17-24 for novel)
- The protagonist is now actively working toward freedom. but in secret.
- They must maintain the domestic facade while building their case/plan.
- The double life creates unbearable tension: smiling at dinner while evidence
  is hidden in the car. Making love while planning to run.
- The antagonist senses the shift. their control tightens.
- Escalation: The antagonist does something they haven't done before
  (a new level of threat, surveillance, manipulation, or violence).
- An ally is compromised: the friend is charmed by the antagonist,
  the lawyer says the case is weak, the evidence is discovered and destroyed.
- The THEN timeline reveals the worst of the past. the event that the
  protagonist has been burying, the original sin of the relationship.
- Dark night: The escape plan fails or is nearly exposed. The protagonist
  is at their most vulnerable. The cage has never felt more inescapable.
- Voice has shifted to Assertive. the protagonist is determined even in despair.
- End of Act 2B: The protagonist has one remaining option. It's risky,
  it's costly, but it's their last chance.

ACT 3: BREAKING FREE (Chapters 17-20 for novella, 25-32 for novel)
- The protagonist executes their plan. not perfectly, because domestic
  escapes are never clean.
- The facade cracks publicly: other characters see the truth, or the
  antagonist's mask slips in front of witnesses.
- Confrontation with the antagonist: verbal, psychological, emotional.
  This is about TRUTH, not violence. The protagonist names what was done to them.
  The antagonist's response reveals their true nature.
  (Physical danger is acceptable but should feel domestic, not cinematic.
  a locked door, a blocked exit, a threatening advance. not a knife fight.)
- The THEN and NOW timelines converge: the past event and the present crisis
  connect, and the full picture is finally visible.
- The protagonist's voice reaches Phase 4: Transformed.
- The antagonist loses control. of the narrative, the protagonist, or both.
  How they respond to losing control is their true character.

THE CLIMAX SEQUENCE. THE UNMASKING:
The domestic thriller climax is NOT an action set piece. It is a moment of TRUTH.
Structure it across 3-4 chapters:

Chapter N-3 (THE LAST PREPARATION):
- The protagonist's escape plan is in its final stage. Everything is hidden:
  the bag, the documents, the evidence, the phone. Show the physical details
  of leaving a life (what fits in one bag? what gets left behind?).
- The antagonist is suspicious but doesn't yet know what's coming.
- A quiet domestic scene that the reader knows is the last of its kind:
  the last dinner, the last bedtime, the last morning routine.

Chapter N-2 (THE TRIGGER):
- Something forces the timeline forward. The antagonist discovers a piece
  of the plan, or an outside event (the ally calls, the lawyer moves, a
  child says the wrong thing) makes waiting impossible.
- The protagonist must act NOW. not on their timeline, but under pressure.
- The facade begins to crack. Micro-confrontations escalate.

Chapter N-1 (THE CONFRONTATION):
- The full truth is spoken. by the protagonist, to the antagonist's face.
  This is the scene the entire novel has been building toward.
- The antagonist's response cycle: denial → charm → threat → rage.
  Show each phase. The masks come off in sequence.
- Other characters may witness this. the first time the private reality
  becomes public. The shame and liberation of being SEEN.
- Physical danger may be present but the REAL climax is verbal/psychological.

Chapter N (THE DOOR):
- The protagonist leaves. Show the physical act of crossing the threshold.
- The antagonist's final attempt at control (a plea, a threat, a promise).
- The protagonist does not look back. or does, and sees clearly for the
  first time. Either choice is powerful.
- First breath of freedom: specific, sensory, earned.

RESOLUTION:
- Brief. 1-2 chapters maximum.
- Show the immediate aftermath: Where does the protagonist go? What happens
  to the children? What does the social network now know?
- The protagonist is free but changed. Freedom is not clean. There is grief
  (for the relationship they thought they had), trauma, logistical chaos.
- Do NOT wrap everything up neatly. Some things remain broken: friendships that
  didn't survive, the children's trust, the protagonist's sense of safety.
- If the protagonist is safe, show the first moment of genuine peace.
  earned, fragile, and specific (a meal alone that they chose, a door they
  can lock from the inside, their own name on a lease).
- The final page should feel like a held breath released.

POST-CLIMAX INSTITUTIONAL COUNTERPRESSURE (MANDATORY):
- The resolution MUST include at least one beat showing the system's reflex
  response to the protagonist's climax action. The system does not accept
  disruption passively. it pushes back.
- This beat must appear BEFORE the final moment of peace. The protagonist
  earns that peace by facing the counterpressure, not by avoiding it.
- Examples of counterpressure beats:
  - A solicitor's letter or legal threat (defamation, breach of confidence)
  - A quiet professional reprisal (a meeting requested, a role questioned)
  - Social consequence (a neighbour's coldness, a WhatsApp group going silent)
  - Data suppression attempt (records altered, access revoked, evidence contested)
  - Institutional deflection (an inquiry announced that will "take months",
    a statement expressing "concern" that changes nothing)
  - A phone call from someone powerful who is "disappointed"
- The counterpressure beat does NOT need to be resolved. It can hang.
  showing the reader that the system is still the system, even after the
  protagonist's victory. This is what makes domestic thrillers feel real
  rather than triumphant.
- Without this beat, the resolution feels consequence-free and the
  antagonist system feels weaker than it was built to be across the novel.

TENSION ARC:
- Starts beneath the surface (unease the protagonist won't name)
- Builds through domestic discovery (each chapter adds a piece of the puzzle)
- Spikes at the midpoint (denial becomes impossible)
- Sustained high through Act 2B (the double life of facade + escape plan)
- Peak at the confrontation (truth vs. control, protagonist vs. antagonist)
- Resolution: not relief but transformation. a new, harder, realer life
```

## Timeline Rules

```
DOMESTIC THRILLER TIMELINE TRACKING

DOMESTIC ROUTINE AS STRUCTURE:
- Map the household's weekly routine: school schedules, work hours, meal times,
  activity nights, regular social commitments
- When is the protagonist alone in the house? (These are investigation windows)
- When does the antagonist arrive and leave? (Predictable? Unpredictable?)
- When are the children present? (Limits what can happen)
- What day of the week are social obligations? (Facade must be maintained)
- Track disruptions to the routine. these signal escalation

NOW-TIMELINE MANAGEMENT:
- Day-by-day or hour-by-hour tracking of the present narrative
- Most domestic thrillers cover days to weeks, rarely longer
- Track the protagonist's investigation activities by day and time
- Note when the protagonist had opportunities to investigate vs. when they
  were observed
- What evidence was gathered on which day?
- When did the protagonist sleep? (Sleep deprivation affects judgment and is
  a common consequence of domestic crisis)
- When did key conversations happen? (Arguments, revelations, lies)

THEN-TIMELINE MANAGEMENT (if using dual timeline):
- Chronological list of the relationship's key events:
  - First meeting
  - Early signs of control (often misread as devotion)
  - The move that isolated the protagonist
  - Financial changes that created dependence
  - The first time something felt wrong
  - The incident(s) that the protagonist buried or rationalised
  - The event that connects directly to the present crisis
- Track which THEN events have been revealed in which chapters
- Ensure THEN chapters are paced for maximum dramatic impact
  (not simply chronological. the worst is saved for late Act 2)
- Each THEN chapter should recontextualise the most recent NOW chapter

DUAL TIMELINE CONVERGENCE:
- Early chapters: THEN and NOW are years or months apart
- Middle chapters: The gap narrows. THEN approaches a critical event
- Late chapters: THEN and NOW are close enough to touch
- Climax: The past event and the present crisis connect directly
  The reader finally sees the complete picture across both timelines

FINANCIAL TIMELINE (CRITICAL FOR DOMESTIC THRILLERS):
- When did the protagonist last have financial autonomy?
- When were accounts consolidated or access restricted?
- When did debts or expenditures occur that the protagonist wasn't told about?
- Current state: How much money does the protagonist have access to RIGHT NOW?
- Secret funds: Has the protagonist hidden money? Where? How much?
- Financial evidence: Bank statements, receipts, transfers that prove the truth

COMMUNICATION TIMELINE:
- Phone records: calls, texts, deleted messages (reconstructed or discovered)
- Email access: whose accounts can the protagonist access?
- Social media: public posts vs. private messages, dating apps discovered
- Monitored communications: is the antagonist reading the protagonist's messages?
- The protagonist's secret communication: burner phone, friend's email, letters
- When was each piece of communication evidence discovered?

LEGAL/INSTITUTIONAL TIMELINE (if involving authorities):
- When did the protagonist first contact a lawyer, police, or support service?
- What was advised? What action was taken?
- What evidence has been submitted to authorities?
- What is the current legal status? (Restraining order, custody filing, etc.)
- What deadlines exist? (Court dates, filing deadlines, school enrollment)

SEASONAL AND DOMESTIC MARKERS:
- Season, weather, and its effect on the domestic routine
- Upcoming events that affect the plot: school holidays (children at home full-time),
  Christmas (extended family visits), summer (neighbours away, isolation increases)
- Anniversary dates that carry emotional weight
- The passing of time should be FELT in domestic rhythms, not just stated
```

## Genre-Specific Craft Techniques

Domestic thriller at the level of Daphne du Maurier, Lionel
Shriver, William Landay, Gillian Flynn, Lisa Jewell, B.A.
Paris, Shari Lapena, Liane Moriarty, Greer Hendricks, Liv
Constantine, Freida McFadden, Leila Slimani, Ruth Ware,
T.M. Logan, Laura Dave, and Rebecca Makkai earns its
power through specificity of the domestic cage, the
psychological reality of the trapped protagonist, and the
honesty of its institutional depictions. The form is
uniquely vulnerable to a cluster of failure modes that AI-
generated drafts hit with predictable frequency: **Easy-
Escape Failure** (the protagonist could obviously leave but
doesn't, with no psychologically real reason); **Cartoon-
Antagonist** (no charm, no public persona, no depth — just
"bad person is bad," which voids the genre's central
mechanism); **Domestic-Violence-as-Entertainment** (abuse
depicted graphically without emotional weight, consequence,
or the protagonist's psychological response); **Passive-
Protagonist-Drift** (the narrator never takes any action
toward escape, truth, or agency across the entire
manuscript); **Children-as-Props** (children present in the
story but with no interiority, no realistic behaviour, used
only as plot devices); **Facade-Collapse-Without-
Consequence** (the public facade breaks but nothing changes
— no social repercussions, no antagonist escalation);
**Institutional-Convenience** (police, lawyers, or social
services immediately believe the protagonist and solve the
problem, ignoring documented institutional failures);
**Voice-Stasis** (the narrator's voice is identical in
Chapter 1 and Chapter 20 despite revelation and crisis);
**Genre-Crossover** (extended action sequences, chase
scenes, or thriller-style physical confrontations that
belong in a different genre); **Slow-Burn-Without-Burn**
(atmospheric tedium that mistakes mood for escalation, with
no actual ratchet between chapters); and **Twist-That-
Punishes-the-Victim** (the protagonist was the abuser all
along, executed cheaply rather than as deliberate
structural commitment). The seven canonical techniques
below — Domestic Cage Construction, Found Object Reveal
System, Neighbour's Window, Controlled Explosion, Intimate
Violence Spectrum, Information Control System, Protagonist
Intelligence Management — are how the form defends against
these failure modes through specificity, psychological
realism, and institutional honesty.

### The Domestic Cage Construction

**The Five Bars of the Cage:**
Every domestic thriller protagonist is trapped by a specific combination of barriers. Identify and establish these in Act 1:

1. **Financial Bar**. The protagonist has no independent income, no savings access, no financial literacy about the household's true state. Establish this through specific detail: a credit card that's been cancelled, a bank statement the protagonist has never seen, a joint account they can't access online.

2. **Social Bar**. The protagonist's support network has been systematically weakened. Friends have been alienated ("She's so controlling of your time"), family has been distanced ("Your mother is toxic"), colleagues have been charmed. Show this through the protagonist's contact list: who can they actually call?

3. **Children Bar**. If children are present, they are the most powerful bar. The protagonist stays because leaving means a custody fight they might lose, or taking the children from the only home they know, or the antagonist's threat: "I'll get full custody and you'll never see them."

4. **Psychological Bar**. Self-doubt, gaslighting residue, trauma bonding, shame. The protagonist has been taught to doubt their own perceptions. "Maybe I am overreacting." This bar is invisible but the strongest.

5. **Practical Bar**. Where would they go? How would they get there? The protagonist has no car in their name, no savings, no family nearby, no plan. The logistics of leaving are as daunting as the emotional cost.

**Architecture rule:** Remove bars one at a time across the manuscript. Each bar removed is a victory. By the climax, enough bars are gone for the protagonist to act. but the remaining ones make it costly.

### The "Found Object" Reveal System

Domestic thrillers trade in found objects. physical evidence discovered in the home that advances the plot. Each found object should:

1. **Be domestic in nature**. a receipt, a key, a phone, a letter, a pill, a photograph, a diary entry, a browser history, a hidden garment, a locked box
2. **Raise more questions than it answers**. early found objects should deepen mystery, not solve it
3. **Be discoverable in a plausible way**. the protagonist wasn't snooping (at first); they were doing laundry, cleaning, looking for something else
4. **Require the protagonist to make a choice**. confront the partner? Investigate further? Tell someone? Put it back and pretend they never saw it?
5. **Escalate in significance**. early: a mysterious receipt. Middle: a locked phone with a second number. Late: evidence of a previous victim, a forged document, a hidden identity.

**Pacing rule:** One found object every 2-3 chapters. Never more than one per chapter. The spaces between discoveries are where the tension lives.

### The Neighbour's Window Technique

The most effective domestic thrillers include an external perspective. someone who sees the household from outside. This character serves multiple functions:

- **Reality anchor**. Confirms for the reader that something is genuinely wrong (not just the protagonist's perception)
- **Dramatic irony**. The neighbour sees something the protagonist doesn't, or vice versa
- **Social commentary**. What does it mean that the neighbours see but don't act? What systems protect abusers?
- **Plot catalyst**. The neighbour's information, delivered at the right moment, can crack the case open
- **Mirror**. What the neighbour sees (the public face) vs. what the protagonist experiences (the private reality) IS the central tension

### The Controlled Explosion Technique

In domestic thrillers, the climax is rarely a chase or a fight. It's the moment the truth goes public. the controlled explosion of the facade. Build toward it:

1. **Pre-detonation**. Evidence gathered, escape plan ready, witnesses positioned
2. **The trigger**. The protagonist creates the conditions (invites the right people, produces the evidence, makes the call) OR the antagonist's control slips at the worst possible moment
3. **The explosion**. The truth is visible. The antagonist's mask falls in front of people who matter. The protagonist speaks their truth clearly for the first time.
4. **The fallout**. Nothing is clean. The protagonist is free but the wreckage is real. Show the cost alongside the victory.

### The Intimate Violence Spectrum

Domestic thrillers depict harm that exists on a spectrum, mostly below the threshold of what outsiders would recognise as "abuse." This is deliberate and essential to the genre:

- **Microaggressions**. "You're wearing that?" A sigh. A corrected word. Individually nothing. Cumulatively devastating.
- **Control disguised as care**. "I'll drive you." "Let me handle the money." "You don't need to work." "I worry when you go out."
- **Information weaponisation**. Knowing things the protagonist didn't share. Checking up disguised as concern. Having answers before questions are asked.
- **Emotional volatility**. Unpredictable moods that keep the protagonist in a state of constant vigilance. The walking-on-eggshells feeling.
- **Escalation**. The line moves gradually. What was a sharp word becomes a raised voice becomes a blocked doorway becomes a grabbed wrist. Each escalation normalises the previous level.

**Craft rule:** Show the spectrum building. The reader should recognise each step as an escalation even if the protagonist doesn't. yet.

### Information Control System (from Tension Architecture)

Every chapter has an information budget. a strict accounting of what the reader knows.

**Per-chapter information tracking:**
1. **Confirmed Facts**: Things the reader now knows to be true (from evidence, not assumption)
2. **Planted Questions**: Things the reader is now wondering about
3. **False Beliefs**: Things the reader believes that aren't true (misdirection active)
4. **Hidden Facts**: Things deliberately withheld
5. **Clue Seeds**: Information that will matter later but doesn't seem significant now

**The Iron Rule:** The outline's information release schedule is absolute. If the
protagonist learns about the hidden account in Chapter 9, it does NOT appear as a
"passing mention" in Chapter 6. No early reveals. No loaded descriptions of the
antagonist before the reveal point. No "something about them felt wrong" before
the outline calls for suspicion.

**Misdirection management:**
- False leads must be CONVINCING. write them as if they ARE the truth
- False leads must have satisfying real explanations when debunked
- The protagonist must COMMIT time to wrong theories. dead ends cost chapters, not paragraphs

### Protagonist Intelligence Management

AI makes protagonists too smart because it knows the answer. The protagonist must:
- Draw at least 2 wrong conclusions before the right one (logical given available evidence)
- Hit dead ends that cost chapters, not paragraphs
- Miss things the reader catches (dramatic irony = tension)
- Connect things the reader missed (reader respect)
- Have a blind spot established in Act 1, exploited in Act 2, overcome in Act 3
- Earn breakthroughs through character (their specific expertise, their personal
  connection, their blind spot clearing). NOT through convenient evidence appearing

### Domestic Thriller AI Crutch Phrases (ELIMINATE ALL)

These patterns are specific to AI-generated thriller prose. catch and replace:

| AI Pattern | Fix |
|---|---|
| "A chill ran down my spine" | Show the specific physical reaction |
| "Something felt off" | Name the specific thing that's wrong |
| "I couldn't shake the feeling" | Show the behaviour the feeling causes |
| "My blood ran cold" | What does the character actually feel physically? |
| "I knew in that moment" | Show the realisation through action or thought |
| "Little did I know" | Delete. No meta-narration. |
| "The truth would shatter everything" | Show the specific consequence |
| "Nothing could have prepared me for..." | Just show the thing |
| "The walls felt like they were closing in" | Ground claustrophobia in spatial detail |
| "Everything I thought I knew was a lie" | Name the specific false belief and specific truth |
| "I could feel their eyes on me" | What makes the protagonist think they're watched? |
| "[Antagonist] smiled, but it didn't reach their eyes" | Find a specific, fresh description |
| "The silence was deafening" | What IS the character hearing? |
| "Time seemed to slow" | Describe the specific perceptual shift |
| "My heart hammered" (over 4× in manuscript) | Vary the physical manifestations |
| "He wasn't the man I married" | Show the specific behaviour the narrator now reads differently — the look across the dinner table, the missed text, the exact thing he said about her sister |
| "I had to get out" | Show the specific moment, specific trigger, specific object that made staying intolerable in this particular hour |
| "The house felt different now" | Render the specific changed detail — the new smell, the moved object, the sound that wasn't there yesterday |

## Genre-Specific Revision Rules

### Six-Pass Domestic Thriller Audit (Run FIRST in editorial pipeline)

The Domestic Thriller Audit runs every chapter through six
named passes. Run them in order — each builds on the last.

#### Pass 1: Cage Integrity + Voice Phase

The Cage Integrity and Voice Phase pass tests the form's
two foundational architectural disciplines simultaneously,
because they operate on the same character and either
failure voids the manuscript. For Cage Integrity, verify
the bars of the protagonist's cage are clearly established
and psychologically plausible for this specific character
and situation, that at least one bar has been tested,
weakened, or removed by the end of the manuscript, and
that a reader could articulate WHY the protagonist doesn't
just leave. The cage must be specific (financial / social /
children / psychological / practical) and rendered
concretely; generic "trapped in a bad marriage" is the
failure mode. For Voice Phase Verification, map each
chapter to its voice phase (Compliant / Questioning /
Assertive / Transformed) and verify the progression is
gradual — no sudden jumps from Phase 1 to Phase 3 — and
that the prose style actually changes across phases
(vocabulary, sentence structure, internal monologue
patterns). The decisive test: read the first and last
chapters back-to-back — the voice should be recognisably
the same person but fundamentally different in posture and
clarity. Voice stasis across the manuscript is one of the
form's most-flagged failure modes; the narrator must be
audibly transformed by what they have lived through.

#### Pass 2: Facade Management + Domestic Detail

The Facade Management and Domestic Detail pass tests the
form's two surface contracts. For Facade Management, track
across the manuscript where the public facade is intact,
strained, or broken; verify that facade cracks have
consequences (social, relational, or from the antagonist
— never consequence-free); ensure the performance of
normalcy creates tension rather than tedium; and check
that the gap between public and private widens across the
manuscript, with each chapter's gap-widening tracked
explicitly. For Domestic Detail, verify the home is
rendered with enough specificity that the reader could
draw a floor plan; that domestic routines are used
structurally (creating investigation windows, forcing
performance, marking escalation through disruption); that
found objects are plausible and paced correctly (one every
2-3 chapters per the system, never more than one per
chapter); and that the physical space evolves as the
situation changes — the rooms themselves carry the story.
The pass closes by confirming the domestic sensorium is
deployed (the smell of a cleaning product, the sound of a
garage door at unexpected time, the exact weight of
silence at the dinner table) rather than substituted with
generic atmosphere.

#### Pass 3: Antagonist Plausibility + Power Dynamics

The Antagonist Plausibility and Power Dynamics pass
enforces the form's antagonist-coherence contract. For
Antagonist Plausibility, verify other characters would
genuinely like this person (the public persona must be
authentic, not telegraphed-hollow); that the antagonist's
control methods are specific, consistent, and escalating
(name the specific toolkit — financial controller, social
engineer, gaslighter, emotional manipulator, information
hoarder); that the antagonist has moments of apparent
humanity or charm that explain the bond (intermittent
reinforcement is the trap); that their behaviour changes
when threatened (escalation, not repetition — they adapt
when force fails by returning to charm, then escalating
differently); and that their motivation is psychologically
specific, not generic "evil for evil's sake." For Power
Dynamics, map the power balance in every scene (who has
it, how is it expressed); verify power shifts across the
manuscript (antagonist dominant early → contested middle
→ protagonist reclaims late); check that power is
expressed through DOMESTIC means (money, children, social
capital, information, emotional leverage) rather than
physical domination alone; and ensure the protagonist's
reclamation of power is earned through specific actions
and revelations, not sudden courage or external rescue.

#### Pass 4: Information Control + Tension + Hook

The Information Control, Tension, and Hook pass enforces
the form's slow-burn-with-mounting-pressure contract. For
Information Control, verify per-chapter that the
information budget matches the outline (no early reveals,
no skipped plants, no unscheduled clues); that misdirection
is active and convincing where planned; that the iron rule
holds — if the protagonist learns about the hidden account
in Chapter 9, it does NOT appear as a passing mention in
Chapter 6; and that loaded descriptions of the antagonist
do not precede the reveal point. For Tension Escalation,
chart tension 1-10 per chapter and verify the ratchet
pattern: rising baseline with brief dips, never flatlining,
no extended drops; relief valves (low-tension scenes)
always plant a seed for later use. For Chapter Hook, verify
every chapter ends on a hook, question, revelation, or
dread beat — never on resolution, reflection, calm, or
summary; and that domestic-thriller-specific hook types
(found object, overheard conversation, child's revelation,
caught lie, kindness-as-threat, message-that-shouldn't-
exist) rotate rather than repeat.

#### Pass 5: Protagonist Competence + Dual Timeline

The Protagonist Competence and Dual Timeline pass enforces
the form's protagonist-agency contract. For Protagonist
Competence, verify the protagonist draws at least 2 wrong
conclusions before the right one (logical given available
evidence); hits dead ends that cost chapters, not
paragraphs; misses things the reader catches (dramatic
irony) and connects things the reader missed (reader
respect); has a blind spot established in Act 1, exploited
in Act 2, overcome in Act 3; and earns breakthroughs
through their specific expertise, personal connection, or
blind-spot-clearing — never through convenient evidence
appearing. The reader should sometimes be ahead and
sometimes behind, never perfectly synced. For Dual Timeline
(if used), verify THEN chapters are paced for revelation
impact, not chronological order; that each THEN chapter
illuminates the immediately preceding NOW chapter; that
the timelines converge satisfyingly at the climax; that
the relationship between THEN and NOW is clear without
being heavy-handed; and that there are enough timeline
anchors (dates, seasons, children's ages) for the reader
to track both threads. The THEN timeline must reveal how
the cage was built; the NOW timeline must show the
protagonist working through it.

#### Pass 6: Institutional Reality + Resolution Honesty

The Institutional Reality and Resolution Honesty pass is
the form's defence against Institutional Convenience and
the trauma-tourism failure mode. If police, courts,
lawyers, or social services appear in the manuscript,
verify they are depicted realistically with systemic
limitations and biases — institutions often fail domestic
abuse victims, and the genre's contract is honesty about
this. The protagonist must face plausible institutional
barriers; if an institution helps, the help must be hard-
won and partial, never automatic. Domestic abuse dynamics
must be portrayed with accuracy and empathy: the
intermittent reinforcement, the trauma bonding, the
gaslighting residue, the realistic difficulty of leaving.
The difficulty of proving coercive control must be
acknowledged. The pass also verifies the mandatory
post-climax institutional counterpressure beat — the
system's reflex response to the protagonist's climax
action (a solicitor's letter, a quiet professional
reprisal, social consequence, data suppression attempt,
institutional deflection, a phone call from someone
powerful who is "disappointed"). This beat must appear
before the final moment of peace; without it, the
resolution feels consequence-free and the antagonist
system feels weaker than the manuscript built it to be.
The resolution must show grief alongside freedom,
logistical chaos alongside relief, and at least one thread
of unresolved fallout (a friendship that didn't survive,
the children's trust, the protagonist's sense of safety)
— the genre's contract is that recovery is messy, slow,
and incomplete.

## Names & Patterns to Avoid

### Domestic Thriller Character Names. NEVER USE
- Protagonist names that signal fragility or innocence exclusively
  (diversify. protagonists can be named anything)
- Antagonist names that sound sinister (the whole point is they sound trustworthy)
- "The perfect" naming: everyone in the neighbourhood with aspirational names
  that telegraph "too good to be true" (subtle is better than symbolic)

### Domestic Thriller Plot Patterns. AVOID
- The protagonist discovers a locked room and immediately understands everything
  (the discovery should raise questions, not provide answers)
- The antagonist confesses their entire scheme when confronted
  (real manipulators deny, deflect, counter-accuse, and charm)
- "She should have just left" framing. the narrative should make
  WHY SHE COULDN'T leave viscerally clear
- The police arrive and believe everything immediately
  (undercuts the entire genre's power)
- The protagonist had a secret all along that makes them equally culpable
  (a twist that punishes the victim. handle with extreme care or avoid)
- The nanny/au pair is evil for no reason beyond "outsider is threatening"
  (give them real psychology)
- The ending resolves everything cleanly: new house, new man, happy children
  (real recovery is messy, slow, and incomplete)
- All the protagonist's friends and family rally perfectly at the end
  (some relationships don't survive; some people side with the abuser)
- The child saves the day (children should not bear the weight of adult crises)
- The twist is simply "the husband did it" with no deeper layer
  (the WHAT matters less than the WHY and the HOW)

### Domestic Thriller Title Patterns. AVOID
- "The [Adjective] [Female Role]" (The Perfect Wife, The Good Mother. done)
- "The [Noun] Next Door" (exhausted format)
- "Behind the [Domestic Object]" (Behind Closed Doors was the original; stop)
- Single words that describe domestic states (Trapped, Silent, Hidden, Broken)

### Use Instead
- Titles that reference specific domestic details from the story
- Titles that carry double meaning (innocent surface, sinister depth)
- Names that feel real. drawn from census data for the character's background,
  age, and region
- Antagonists with warm, trustworthy, socially successful names
  (the name should make the reader's skin crawl only on rereading)
- Plot twists rooted in specific relationship dynamics, not generic betrayal
- Endings that honour the difficulty and incompleteness of recovery
- Institutional depictions that reflect documented failures and systemic bias
- Children portrayed with age-appropriate behaviour, not adult wisdom or convenient obliviousness

## Comp Titles

Domestic-thriller's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Rebecca* — Daphne du Maurier (1938): the marriage-domestic-thriller archetype.
- *We Need to Talk About Kevin* — Lionel Shriver (2003): family-domestic-thriller benchmark.
- *Defending Jacob* — William Landay (2012): family-and-justice domestic-thriller.

### Contemporary (current best-in-class)

- *Gone Girl* — Gillian Flynn (2012): the modern domestic-thriller benchmark; redefined category voice.
- *The Couple Next Door* — Shari Lapeña (2016): contemporary couple-in-jeopardy domestic-thriller.
- *Behind Closed Doors* — B.A. Paris (2016): contemporary marriage-domestic-thriller.
- *The Wife Between Us* — Greer Hendricks & Sarah Pekkanen (2018): twist-led domestic-thriller.
- *The Last Mrs. Parrish* — Liv Constantine (2017): class-friction domestic-thriller.
- *Big Little Lies* — Liane Moriarty (2014): domestic-thriller-with-women's-fiction crossover.
- *The Last Thing He Told Me* — Laura Dave (2021): contemporary domestic-thriller with single-mother frame.
- *I Have Some Questions for You* — Rebecca Makkai (2023): literary domestic-thriller with podcast frame.

## Cover Design Specifications

### Recommended Visual Styles
- **Minimalist**. The strongest style for domestic thrillers. A single domestic object or architectural element, isolated and made sinister through colour grading and negative space. Less is more. the menace is in what's NOT shown.
- **Typographic**. Bold title treatment with minimal or no imagery. The title itself carries the threat. Works exceptionally well for high-concept premises where the title is the hook (e.g., "Behind Closed Doors," "The Woman in the Window").
- **Photorealistic**. Domestic settings photographed with unsettling post-processing: a house at dusk, a window with a figure behind curtains, a door left ajar. The ordinary made ominous through lighting and colour.
- **Cinematic**. Voyeuristic angles, shallow depth of field, suburban settings shot like surveillance footage. Effective for neighbourhood thrillers and nanny/caregiver subgenres.

### Genre Cover Aesthetics
- **Styles:** Suburban menace, voyeuristic framing, domestic objects made sinister, washed-out or desaturated realism, negative space as threat, "something is wrong with this picture" compositions
- **Colours:** Muted, washed-out palettes. faded teals, dusty blues, bruised purples, sickly yellows, overcast greys. A single accent colour (red door, lit window) against desaturation. Avoid bold, saturated colours. domestic thrillers feel drained, not vivid.
- **Elements:** Houses (especially at twilight or in rain), windows with silhouettes or light behind curtains, doors (open, closed, locked), suburban streets, kitchen objects made ominous (a knife, a glass of wine, a set of keys), blurred or partially obscured figures, security cameras, children's toys in unsettling contexts
- **Typography:** Clean sans-serif or modern serif typefaces. Often oversized, sometimes filling the entire cover. The type should feel controlled and deliberate. mirroring the controlled surface of the domestic facade. Avoid decorative or playful fonts.

### Subgenre Variations
- **Marriage Thriller**. Focus on duality: two faces, a wedding ring, a house split in shadow and light. Paired objects that suggest two-ness and division. Muted, cold palettes.
- **Neighbourhood Thriller**. Rows of identical houses, a perfect street with one wrong detail, a window where someone is watching. Wider compositions showing community-as-cage.
- **Family Secrets**. Layered imagery (old photographs beneath modern scenes), partially hidden faces, locked boxes or sealed envelopes. Vintage-tinted colour grading.
- **Nanny / Caregiver**. A figure at a threshold (doorway, garden gate), a child's room with an adult shadow, domestic space with an outsider's perspective. Warmer tones that feel deceptively comfortable.
- **Maternal Thriller**. Nursery objects, empty cots, a mother's silhouette, baby monitors. Soft, washed-out palettes that feel clinical rather than cosy.

### Market Positioning
Domestic thrillers compete in the same Amazon categories as psychological thrillers and must differentiate through DOMESTIC specificity. The cover should immediately signal "the danger is inside the house." Thumbnails must be clean and legible. busy covers fail at small sizes. The most successful domestic thriller covers use a single architectural or domestic element with strong typography. Readers in this subgenre are predominantly women aged 25-55; covers should feel intelligent and unsettling, not exploitative or sensationalist. Position between the Freida McFadden end (bold, high-contrast, typographic) and the Lisa Jewell end (softer, more atmospheric, slightly literary) based on tone.

### Cover Design DON'Ts
- Do NOT use action-movie aesthetics (explosions, weapons, car chases). domestic thrillers are about quiet menace, not spectacle
- Do NOT use urban noir imagery (city skylines, dark alleys, rain-slicked neon). the setting is suburban/domestic, not metropolitan
- Do NOT use bright, cheerful domestic imagery without subversion. a happy house cover signals women's fiction, not thriller
- Do NOT show explicit violence or blood. domestic thrillers deal in psychological threat, not graphic harm
- Do NOT use overly masculine design language (military fonts, metallic textures, gun imagery). it signals the wrong readership
- Do NOT use cluttered compositions with multiple competing elements. the power of a domestic thriller cover is in restraint
- Do NOT use generic stock photos of women looking over their shoulders. this trope is exhausted and signals low-quality self-publishing
- Do NOT use bright saturated colours. domestic thrillers are muted, drained, and overcast by convention
