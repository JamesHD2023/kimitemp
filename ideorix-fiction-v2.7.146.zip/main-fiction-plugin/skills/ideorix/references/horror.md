---
name: horror-genre
description: Genre-specific instructions for horror fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [general]
---

# Horror. Genre Plugin

## Metadata
- id: horror
- name: Horror
- icon: 🩸
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Five-Act Structure"]

## Subgenre Options
Present during setup:
- **Psychological Horror**. The terror is internal: unreliable perception, paranoia, disintegrating sanity, the horror of the mind turning against itself
- **Body Horror**. The human body as a site of terror: transformation, decay, parasitism, the loss of bodily autonomy
- **Cosmic Horror**. Lovecraftian territory: the universe is vast, indifferent, and incomprehensible; human insignificance as the ultimate horror
- **Survival Horror**. Isolated, resourceless, hunted; the stripped-down fight to stay alive against something that won't stop
- **Slasher/Stalker**. A human (or nearly human) predator pursuing victims; cat-and-mouse tension, survival intelligence, the final confrontation
- **Folk Horror**. Rural settings, ancient traditions, pagan undercurrents; the horror of isolation, community, and old beliefs that never died
- **Quiet Horror**. Subtle, literary, atmospheric; dread that accumulates in the spaces between sentences; what's NOT said is scarier than what is

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Controlled tension. slow build punctuated by shocks, with breathing room that makes the next escalation worse
- Must open with: Something WRONG. not necessarily the horror itself, but the wrongness that precedes it; unease before event

BEATS PER CHAPTER
1. Dread Beat. Tension built through atmosphere, anticipation, and the character's growing awareness that something is wrong
2. Normal-World Anchor. A moment of ordinary life or human connection that the reader wants to protect (and fears losing)
3. Horror Event. The threat manifests: viscerally, psychologically, or both; this is the scare, and it must ESCALATE from the last one
4. Aftermath Beat. The character's response: physical, emotional, psychological; horror is in the CONSEQUENCE, not just the event
5. Trap-Tightening Beat. Options narrow, resources diminish, escape routes close; the protagonist is more trapped than before

THE HORROR ARCHITECTURE
- Horror is about VULNERABILITY: the protagonist must be mortal, limited, and in genuine danger
- The threat has a LOGIC that the protagonist must discover (even if the logic is alien or irrational from a human perspective)
- Isolation is a tool: physical isolation (remote location), social isolation (no one believes them), or psychological isolation (they can't trust their own perception)
- The unknown is scarier than the known: delay full revelation; what the reader imagines is worse than what you describe
- Body response: horror is PHYSICAL. nausea, cold sweat, trembling, the inability to move, the desperate need to run
- The mundane becomes threatening: familiar objects, places, and people turn wrong
- POV: First person or tight third (the reader must be trapped in the protagonist's limited, terrified perspective)

HORROR ESCALATION
- Each chapter must be MORE frightening than the last; horror that plateaus becomes comedy
- Escalation axes: frequency (more often), proximity (closer), intensity (more violent/disturbing), cost (higher stakes)
- The escalation should feel INEVITABLE: the protagonist is moving toward the source, not running from it
- Safe spaces erode: what was safe in chapter 3 should feel threatened by chapter 7

THE THREAT
- It has RULES (even if the characters don't know them)
- It has a SOURCE (a place, a person, a history, an object, an idea)
- It has a MOTIVATION (hunger, revenge, reproduction, territorial defence, or sheer alien purpose)
- It is NOT all-powerful: constraints make the threat more frightening (it can only come at night, it can only take you if you're alone, it has to be invited)
- It can be DEFEATED (or survived, or endured). but the victory costs something

FORBIDDEN IN HORROR
- Torture porn: extended suffering without narrative purpose (violence must serve the story)
- Jump scares with no build-up (cheap shocks without atmospheric investment)
- Protagonists who make obviously stupid decisions to serve the plot ("let's split up")
- The threat with no logic or rules (random horror is not scary, it's frustrating)
- Horror that relies entirely on disgust rather than dread (gross ≠ scary)
- Invincible protagonists (if they can't be hurt, there's no horror)
- "It was all a dream" or "they were crazy the whole time" (disrespects the genre and the reader)
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation + Anticipation (primary — dread is the engine), Captivation through unknowns, Validation at scares.

VOICE & TONE
- POV: First person present (maximum immediacy) or tight third past (classic horror voice)
- Voice: Controlled but increasingly strained; the protagonist's composure erodes across the manuscript
- Tone: Dread. the anticipation of something terrible, punctuated by moments of terror and the numb aftermath
- Register: Grounded, specific, precise. horror is most effective when the prose is CLEAR, not purple

PROSE IMPERATIVES
- BODY-FIRST WRITING: the character's body reacts before their mind processes
  - "Her stomach dropped. Her hands were shaking. She looked up and—"
  - Physical reactions: cold sweat, nausea, hyperventilation, tunnel vision, the freeze response
  - The reader should feel the fear PHYSICALLY through the prose
- SENSORY ASSAULT: horror engages senses in unpleasant ways
  - Smell: rot, copper (blood), chemical wrongness, sweetness that shouldn't be there
  - Sound: scratching, breathing, wet sounds, silence where there should be noise
  - Touch: cold, wet, sticky, the feeling of something brushing skin
  - Sight: what's in the corner, what's in the mirror, what's behind you
- RESTRAINT AND RELEASE: alternate between what you show and what you withhold
  - Early chapters: more restraint, more suggestion, more off-screen
  - Later chapters: more explicit, more visceral, more inescapable
  - The reveal is earned by the build-up
- PACING THROUGH PROSE: sentence structure controls fear
  - Short sentences during fear: "She ran. The door was locked. She turned."
  - Long, breathless sentences during panic: "She was running down the corridor and the lights were flickering and she could hear it behind her, getting closer, and the exit was fifty feet away, forty, thirty—"
  - Sentence fragments for shock: "The hand. Under the bed. Moving."

PROSE RHYTHM MAPPING
- CH 1 HOOK: Something WRONG from the first page. not the horror itself, but the wrongness that precedes it
- DREAD RHYTHM: Long, layered sentences building atmospheric unease. the reader sinks into detail,
  clause after clause tightening. then SHORT sharp sentence when the wrongness lands. Five words. Maybe fewer.
- FEAR SCENES: Sentences fragment under pressure (5-8 words max). "She turned. It was there. She ran."
  No complex syntax. No subordinate clauses. The prose panics with the character.
- CALM-BEFORE-STORM: Deliberately normal-length prose (15-20 words) that the reader distrusts.
  The steadier the prose sounds, the more the reader braces. Weaponise normality.
- TENSION FLOOR: Never below 7. Even quiet scenes carry wrongness. a detail out of place,
  a sound that lingers, a sentence that ends one beat too soon.
- SENSORY WEIGHTING: Bias toward WRONG sensory input:
  - Sound that shouldn't be there (scratching behind a wall that has no space behind it)
  - Smell of decay where everything looks clean
  - Cold where there should be warmth, warmth where there should be cold
  - The sense that fires first is the sense that's WRONG. lead with it
- INTERIORITY RULE: Fear manifests as PHYSICAL SENSATION, not named emotion.
  Never "she felt afraid." Always "her throat closed. Her hands went cold. Her body knew before she did."
- PARAGRAPH ARCHITECTURE: Build dread in long paragraphs (8-12 lines of layered unease),
  then break to a single-line paragraph for the horror beat. The white space IS the gasp.
- RHYTHM SHIFT = ESCALATION: Each chapter's prose rhythm should be slightly more fractured
  than the last. Ch 1 has long calm stretches. By the climax, calm prose barely survives a paragraph.

HORROR DESCRIPTION
- Describe the horrifying through SPECIFIC DETAIL, not adjectives:
  WRONG: "A horrifying creature emerged from the darkness, terrifying and monstrous."
  RIGHT: "It came through the doorway sideways, because it was too wide to fit through any other way. Its skin was the grey-white of something that had been underwater for too long, and it left a wet streak on the doorframe."
- One precise detail is worth ten vague adjectives
- The WRONGNESS of familiar things: a smile with too many teeth, a voice at the wrong pitch, a body that moves at the wrong speed

DIALOGUE CRAFT
- Fear makes people inarticulate: stuttering, repetition, inability to finish sentences
- Denial as dialogue: "That's not— It can't be— I didn't see—"
- Bargaining with the threat: pleading, offering, promising
- The last words before something terrible: mundane, interrupted, wrong
- Silence is dialogue: the moment when no one speaks because they're all listening
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

HORROR CRAFT (40% of total):
- Dread is built through atmosphere before the horror event? (0-100)
- The threat has internal logic and consistent rules? (0-100)
- Escalation across chapters (each chapter scarier than the last)? (0-100)
- Body-first writing (physical fear responses drive the prose)? (0-100)

STORY CRAFT (30% of total):
- The protagonist is vulnerable, mortal, and in genuine danger? (0-100)
- Stakes are personal and meaningful (the reader cares what happens)? (0-100)
- The trap tightens progressively (options narrow, resources diminish)? (0-100)
- The resolution is earned and costly (survival has a price)? (0-100)

PROSE QUALITY (30% of total):
- Sensory detail is specific and unpleasant (reader feels the horror)? (0-100)
- Restraint is used effectively (suggestion before revelation)? (0-100)
- Pacing uses sentence structure to control tension? (0-100)
- Description uses specific detail over adjective stacking? (0-100)

AUTOMATIC FAILS (score = 0):
- Extended suffering with no narrative purpose (torture porn)
- Jump scares without atmospheric investment
- Protagonist makes idiotic decisions to serve the plot
- The threat has no rules or logic (random horror)
- Horror that relies entirely on disgust with no dread
- "It was all a dream" / protagonist was insane (genre betrayal)
```

## Continuity Rules

```
HORROR CONTINUITY. WHAT TO TRACK

THREAT STATE:
- What the threat has done, when, and to whom
- Rules established: when it appears, what triggers it, what it can/cannot do
- Escalation level: how powerful/aggressive it is at this point in the story
- Knowledge: what the protagonist knows about the threat (and what they don't)
- Vulnerability: any weaknesses discovered and whether they've been tested

SURVIVAL STATE:
- Resources: weapons, light sources, communication devices, food/water, batteries
- Escape routes: which exits are available, which have been blocked or compromised
- Allies: who is alive, who is injured, who has been lost, who can be trusted
- Physical condition: injuries, exhaustion, hunger, dehydration, blood loss
- Psychological condition: shock, denial, hypervigilance, breakdown, dissociation

LOCATION STATE:
- Safe spaces: which areas have been cleared, which are compromised
- Dangerous zones: where the threat has been encountered or is likely to appear
- Layout: the protagonist's understanding of the space (which grows over time)
- Environmental hazards: darkness, flooding, structural instability, locked doors
- Changes: things that have moved, appeared, or disappeared

INFORMATION STATE:
- What the protagonist has learned about the threat (in order of discovery)
- Theories: what they think is happening (and whether they're right)
- Warnings: signs they noticed or missed, advice they received or ignored
- Backstory: the history behind the horror (revealed gradually)
- Foreshadowing: planted details that should pay off later

BODY STATE:
- Injuries: location, severity, and impact on function
- Adrenaline: the body cycles through fight/flight/freeze. track the crashes
- Sensory impairment: darkness affects sight, injuries affect mobility, shock affects cognition
- Substances: medication, alcohol, or drugs that affect perception and response
```

## Character Rules

```
HORROR CHARACTER TYPES

THE PROTAGONIST (THE SURVIVOR):
- An ordinary person: not a soldier, not a trained killer, not supernaturally gifted
- Has specific skills that become relevant (a nurse's medical knowledge, a mechanic's tool skills)
- Their fear is REAL: they shake, cry, vomit, freeze, panic. and THEN they act
- Intelligence under pressure: they make smart decisions that the reader would make
- A moral line: what they won't do to survive, and what eventually pushes them past it
- Their pre-horror life matters: what they have to live for drives their survival instinct

THE THREAT (THE MONSTER):
- Has an origin: it came from somewhere, and understanding that origin is part of the plot
- Has rules: it hunts in specific ways, appears under specific conditions, has specific weaknesses
- Has a presence: the reader should feel it even when it's off-page (tracks, sounds, aftermath)
- May be sympathetic: the best horror threats have a tragic dimension
- Is NOT omnipotent: it has limitations that create the possibility of survival

THE SACRIFICE (THE FIRST VICTIM):
- Establishes the stakes: their death proves the threat is real and deadly
- The reader should care about them: give them enough humanity that their loss matters
- Their death reveals information: how the threat kills, what it looks like, where it strikes

THE DISBELIEVER:
- Refuses to accept the danger until it's too late
- Their scepticism is REASONABLE (not stupid). they have good reasons to doubt
- Their arc: denial → irritation → fear → acceptance → (often) death
- They serve the story by delaying group action and creating interpersonal tension

THE HELPER:
- Has knowledge or skills the protagonist needs
- May be flawed: cowardly, selfish, or unreliable under pressure
- Their loyalty is tested: will they sacrifice themselves, or will they sacrifice others?
- They provide the social connection that isolation horror threatens

VOICE DIFFERENTIATION:
- The protagonist: increasingly terse, body-focused, present-tense thinking under stress
- The disbeliever: confident, dismissive, then increasingly shrill
- The helper: practical, direct, sometimes gallows humour
- The threat (if it speaks): wrong. the cadence, the word choice, the emotional register is OFF
```

## Arc Rules

```
HORROR STORY STRUCTURE

ACT 1: THE SET-UP (first 25%)
- Establish the normal world and the protagonist's stakes (what they have to lose)
- Introduce the setting and its vulnerabilities (isolation, darkness, history)
- First sign of the threat: subtle, ambiguous, easily dismissed
- The protagonist ignores or rationalises the warning
- The inciting event: something that locks the protagonist into the situation
- END OF ACT 1: First death, first undeniable encounter, or first irrevocable commitment

ACT 2A: THE DESCENT (to midpoint)
- The threat is real and active: it has killed, appeared, or fundamentally changed the situation
- The protagonist reacts: investigation, fortification, attempted escape
- Each attempt to resolve the situation fails or makes it worse
- The threat escalates: more frequent, closer, more dangerous
- Allies are lost or compromised
- MIDPOINT: A revelation about the threat's nature that changes the protagonist's approach

ACT 2B: THE SIEGE (midpoint to dark moment)
- Resources are depleted: light, weapons, allies, hope
- The threat is at its most active and aggressive
- The protagonist must confront their own limitations: cowardice, selfishness, weakness
- Moral compromises: survival requires choices that cost humanity
- Safe spaces are breached: nowhere is safe
- DARK MOMENT: The protagonist is alone, injured, out of options, and face-to-face with the threat

ACT 3: THE RECKONING (final 25%)
- The protagonist uses everything they've learned (about the threat AND about themselves)
- The final confrontation is physical AND psychological
- Victory (if it comes) costs something irreplaceable
- The threat is defeated, survived, or escaped. but the world is changed
- The protagonist is changed: scarred, stronger, or broken
- The ending disturbs: a final image, sound, or revelation that lingers

HORROR PACING:
- TENSION RATCHET: each chapter tighter than the last
- Breathing room between scares (but the breathing room shrinks)
- The longest quiet stretch is in Act 1; by Act 3, there is no quiet
- The climax is sustained intensity, not a single moment
- The final chapter is the quietest. and the most unsettling
```

## Timeline Rules

```
HORROR TIMELINE

COMPRESSED TIMELINE:
- Most horror stories span hours to days (not weeks or months)
- The shorter the timeline, the more intense the horror
- Track time precisely: horror protagonists often lose track of time, but the AUTHOR must not
- Day/night cycle: darkness is the threat's ally. track when the sun sets and rises

THREAT TIMELINE:
- When the threat first appeared (in the backstory)
- When the protagonist first encountered it
- The pattern of escalation: increasing frequency and intensity
- Any cyclical pattern: does it appear at specific times, intervals, or triggers?

SURVIVAL TIMELINE:
- How long since the protagonist last ate, slept, or rested
- Injury timeline: when injuries were sustained and how they're deteriorating
- Resource depletion: batteries last X hours, water runs out at Y, ammunition is Z rounds
- Ally loss: when each person was lost and the impact on the group

ENVIRONMENTAL TIMELINE:
- Weather and light: track natural light (crucial when the power is out)
- Structural deterioration: buildings, vehicles, barriers breaking down over time
- Temperature: cold kills slowly; heat dehydrates; both affect cognition
```

## Genre-Specific Craft Techniques

Horror is the foundational genre of the dread-fiction
catalogue and the parent of an extensive sub-genre cluster
(gothic horror, cosmic horror, body horror, folk horror,
psychological horror, supernatural horror, slasher,
splatterpunk, weird fiction, quiet horror, post-apocalyptic
horror). Its readers — from the canonical lineage (Shirley
Jackson, Henry James, M.R. James, Robert Aickman, Daphne du
Maurier, Stephen King, Peter Straub, Clive Barker, Ramsey
Campbell, Anne Rice in the gothic-horror register) through
the contemporary expansion (Paul Tremblay, Stephen Graham
Jones, Carmen Maria Machado, Silvia Moreno-Garcia, Cassandra
Khaw, Eric LaRocca, T. Kingfisher, Catriona Ward, Camilla
Sten, Gretchen Felker-Martin, V. Castro, Adam Nevill, Sarah
Pinborough on the thriller-edge) — bring sophisticated
expectations of the form's craft. The genre's deepest
pleasure is not shock but unease — the sustained recognition
that the world contains more than the protagonist can see
or comprehend, and that what cannot be seen is closing in.
The techniques below are how the form achieves that unease
without slipping into the failure modes (cheap jump-scare
prose, gratuitous violence as substitute for atmosphere,
explanatory prose that converts dread into mere information,
characters who exist only to be killed).

### The Wrongness Technique

The most effective horror doesn't describe something horrible
— it describes something WRONG. The technique converts the
reader's pattern-recognition apparatus into the horror's
delivery mechanism: the prose presents an ordinary scene
with one element that does not belong, and the reader's
brain supplies the dread the prose has refused to name.

```
NOT HORROR: "A terrifying monster stood in the hallway."

HORROR: "A man stood in the hallway. He was smiling. He
had been smiling when she left for work eight hours ago.
He hadn't moved. He was still smiling."

The wrongness is: everything is normal except ONE thing.
The reader's brain supplies the horror.
```

The technique requires restraint. The wrongness must be
specific (a single named element), unexplained (the prose
does not pause to interpret), and embedded in otherwise
ordinary detail (the scene around the wrongness reads as
mundane, which is what makes the wrongness register). The
genre's strongest practitioners run wrongness across many
scales: the wrong word in the family member's voice; the
wrong number of stairs in the house the protagonist has
lived in for years; the wrong shadow from a familiar object;
the photograph in which everyone is smiling except the
person in the back row whose face has changed slightly. Test:
read three significant atmospheric scenes and identify the
single wrong element in each. If the writer is reaching for
multiple wrong things to amplify dread, the technique has
collapsed into spectacle; if the writer has placed exactly
one wrong thing and trusted the reader, the technique is
operating.

### The Sensory Denial

Remove one sense to heighten the others. Horror's signature
sensory mode is partial — what the protagonist cannot quite
see, hear, or feel becomes more terrifying than what is
fully presented. The technique converts the missing sense
into the channel through which the threat enters the prose.

- **Darkness** — hearing becomes excruciating; every sound
  is a potential threat; the protagonist's eyes adjust
  imperfectly and what they think they're seeing may not be
  there
- **Silence** — the absence of expected sound (birdsong,
  traffic, breathing, the building's normal hum) is more
  terrifying than noise; the moment of recognising the
  silence is itself a horror beat
- **Cold** — numbness means you can't feel what's touching
  you; the body's normal proprioceptive signals fail
- **Fog / smoke** — sight is limited; shapes are ambiguous;
  distance is impossible to judge; the protagonist may be
  closer to or further from the threat than they realise
- **Confined space** — touch and sound become amplified;
  movement is restricted; the body's escape options are
  pre-foreclosed
- **Drug or fever** — the protagonist's perception is
  unreliable; they cannot trust what they're seeing or
  hearing or remembering, and the prose cannot fully
  trust them either

The technique requires deliberate use of which sense is
denied at which moment. A book that maintains darkness as its
sole sensory-denial mode through 200 pages exhausts the
register; rotation between denial modes (the dark corridor
in chapter five; the silent house in chapter twelve; the
fogged road in chapter eighteen; the fever-confused interior
in chapter twenty-five) keeps the technique fresh.

### The Body Clock

Horror characters are physical beings, and the genre's
distinctive structural pressure — the grinding accumulation
of fear and exhaustion across a sustained ordeal — must be
felt in the body. The protagonist who is functioning at
chapter ten the same way they functioned at chapter one has
not been through the genre's pressure cooker. Track the
body's deterioration explicitly:

```
Hour 1: Alert, capable, rational
Hour 8: Tired, making small mistakes, temper fraying
Hour 16: Exhausted, reaction time slow, judgement impaired
Hour 24: Hallucinating, paranoid, barely functional
Hour 36+: Dangerous to themselves and others
```

The clock applies to compressed-timeframe horror (single-
night home invasion; weekend at the haunted house; 48-hour
isolation event) most precisely; longer-timeframe horror
(the slow-burn dread that builds across months; the haunted
relationship; the inherited curse) operates on different
clocks (the sleep deprivation that compounds across weeks;
the appetite that stops returning; the relationship that
hollows out by degrees). The technique requires that the
prose register the deterioration through specific behavioural
shifts: the protagonist who starts checking locks compulsively;
who stops bothering to lock at all; who hears their own
voice as a stranger's; who responds to ordinary stimuli
with disproportionate reaction or fails to respond at all.

The strongest horror tracks multiple bodies on different
clocks. The protagonist's deterioration alongside the spouse
who is deteriorating differently, the friend who is holding
up too well, the child whose body is responding in ways the
adults aren't yet seeing. Test: pick three points spaced
across the manuscript and verify each named character's
embodied state has shifted from prior appearance in
specific, traceable ways.

### The Exit Problem

Every horror scenario needs a clear, convincing reason why
the protagonist CAN'T just leave. The genre's most-flagged
craft failure is the moment the reader thinks "why don't
they just go?" — a failure that breaks the spell instantly
and is rarely recoverable.

The exit blocks fall into three categories:

- **Physical** — snowed in; flooded roads; no working
  vehicle; locked in; the only road out is the road the
  threat is on; the storm is closing the airport; the
  bridge is out; the keys are missing; the phone has no
  signal
- **Social** — no one believes them; the threat follows
  wherever they go; someone they love is still inside; the
  authorities are compromised; their disclosure would
  destroy a relationship; their disclosure would expose a
  prior secret; leaving means abandoning someone
- **Psychological** — they need to understand; they need to
  save someone; they're compelled by curiosity or duty or
  guilt or unfinished personal business; the threat has
  given them a task; they cannot leave without confronting
  what is here

The reason must be CONVINCING. The reader is sitting on the
sceptical side of the question — they would leave if they
were the protagonist, and the prose must build the constraint
that makes leaving genuinely not an option. Layered
constraints (physical AND social AND psychological all
operating together) read as more credible than single
constraints; "the road is snowed in" alone is the failure
mode; "the road is snowed in, the protagonist's daughter is
still in the house, and the protagonist suspects the
threat may move with her if she does manage to leave" is the
technique. Test: at the moment the reader is most likely to
think "just leave" (typically chapter ten through fifteen of
a thirty-chapter horror), name three specific reasons the
protagonist cannot leave. If only one is operating, the
exit is too thin.

### The Threat Withholding Discipline

Horror's signature pacing structure: the threat is most
terrifying when it is most withheld. The shape glimpsed
peripherally; the sound that recurs but is never identified;
the figure whose face is never clearly seen; the entity
whose nature is never fully named. The technique converts
the prose's restraint into the reader's unease — the gap
between what is shown and what could be shown is where
horror lives. Once the threat is fully revealed (described,
named, comprehended), much of its dread evaporates.

The discipline applies across multiple scales:
- **Sentence level** — fragments, ellipses, cut-off
  descriptions, the sentence that ends before the noun
  arrives
- **Scene level** — the threat that approaches, almost
  arrives, and is interrupted before contact
- **Chapter level** — the chapter that ends with the
  protagonist hearing the door open, with the next chapter
  picking up safely after the danger has passed
- **Book level** — the threat that is never fully
  comprehended even by the climax; the explanation that
  remains partial; the survivor who cannot quite say what
  it was

The reveal is structural choice, not default end state. Some
horror sub-genres (cosmic horror after Lovecraft; folk horror
in the Wicker Man tradition; quiet horror in the Aickman
register) make non-revelation the form's deepest pleasure.
Other sub-genres (creature feature, slasher, splatterpunk)
permit fuller revelation but still benefit from delay. The
technique requires choosing how much to reveal and when, with
the reveal calibrated to the sub-genre's expectations and
held against the genre's general principle that less is
more.

Test: at the climactic confrontation, can the writer specify
how much the protagonist understands about the threat, and
is the reader's understanding kept in proportion? If the
prose has explained the threat in chapter twelve, the
climactic confrontation has no remaining mystery; if the
prose has refused all explanation, the reader may feel the
investment has not paid off. Calibrate per sub-genre and
hold the calibration.

### The Aftermath Gravity

Horror's deepest pleasure includes the genre's specific
treatment of survival and its costs. The protagonist who
emerges from the ordeal physically intact and emotionally
unchanged has not been through horror — they have been
through an action sequence that happened to involve
frightening elements. The genre's strongest practitioners
treat survival as a transformation that the prose registers
across the post-climax chapters and, often, into the book's
final pages.

The technique requires that the aftermath get adequate page
time. The horror book that resolves the threat in chapter
twenty-eight and ends in chapter twenty-nine has skipped the
genre's signature register; the book that gives chapter
twenty-eight to the climax and chapters twenty-nine through
thirty-two to the survivors' aftermath has trusted the
reader to want what the genre offers. The aftermath
registers through specific shifts: the protagonist's
relationship to ordinary life (the inability to return to
the prior job, the changed reaction to ordinary stimuli);
the relationships changed by what occurred (the friend who
was lost, the friend who was not lost but who saw something
the protagonist did, the family who cannot quite be told);
the protagonist's relationship to themselves (what they did
to survive, what they cannot stop thinking about, what they
will not say aloud).

The aftermath also extends to whether survival is delivered
at all. Horror permits — and is often deepened by — endings
that do not deliver clean survival: the protagonist who
survives but is no longer themselves; the protagonist who
survives at the cost of someone they could not save; the
protagonist who survives but only by becoming what they
fought; the unambiguous death that the genre permits where
romance and most other forms do not. The choice between
survived-and-changed vs survived-as-self vs not-survived is
structural; whichever the manuscript chooses must be earned
by what came before.

### Horror AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "a chill ran down her spine" | Show the specific physical reaction (gooseflesh, hair rising, gut dropping) |
| "something was watching from the darkness" | Show the specific sensory clue (a sound, a smell, a shape) |
| "the house seemed alive" | Show the specific structural sound or movement |
| "an unspeakable evil" | Show the specific evil through its effects |
| "terror gripped her heart" | Show the specific behaviour terror causes |
| "the darkness was absolute" | Show what she uses OTHER senses to detect |
| "a blood-curdling scream" | Show the specific quality of the scream and its source |
| "the walls seemed to close in" | Show the specific claustrophobic detail |
| "something wasn't right" | Name the specific wrong thing |
| "she knew she should run but couldn't move" | Show the specific paralysis through body detail |
| "the nightmare was real" | Show the specific nightmarish detail in waking reality |
| "the horror of what she saw" | Describe what she sees; let the reader feel the horror |
| "the air grew cold" | Show ONE specific cold detail (breath visible, the radiator that should have been working, the goosebumps on her arms) |
| "a sound like nothing she'd ever heard" | Make the specific approximation; "like nothing she'd ever heard" tells the reader the writer wouldn't commit |
| "the figure was wrong somehow" | Name the specific wrongness |
| "the basement door creaked open by itself" | Show the door's specific movement, what light comes through, whether anything immediately follows |
| "her blood ran cold" | Show the specific physical sensation (fingers numb, the centre of the chest cold, the inability to swallow) |
| "she felt eyes on her" | Show what specifically alerts her — the change in the room's sound, the temperature shift, the bird that stopped singing |

## Genre-Specific Revision Rules

Six revision passes specific to horror, each with a single
question, run cover-to-cover before the next begins. Horror
revision must hold the form's signature dread register
across long stretches without exhausting the reader's
attention — and must catch the failure modes (escalation
plateau, embodiment thinness, threat-logic drift, protagonist
intelligence failure, atmosphere-action imbalance, aftermath
gravity absence) that erode the genre's contract chapter by
chapter. The passes below are ordered to surface escalation
and embodiment failures first (the most-detected and most-
felt by readers), threat-logic and protagonist-intelligence
failures next (where the genre's craft sits), and the
atmosphere-pacing and aftermath audits last when the rest
of the book is sound enough to hold structural scrutiny.

### Pass 1: Escalation Check

Read the manuscript chapter by chapter, scoring each on a
1–5 scale for horror intensity, and chart the curve. Is this
chapter scarier than the previous one? Has the threat
become more dangerous, more present, or more understood
(in directions the reader has not yet absorbed)? Are the
protagonist's options fewer than they were? The escalation
curve should ascend across the book — Act II should be
scarier than Act I, the climactic sequence should be the
most terrifying material in the book — but with deliberate
relief points (quieter chapters that allow the reader to
feel the pressure accumulating) so that the curve operates
as a tide rather than a flat march.

The genre's most-flagged structural failure is the mid-book
plateau: the writer reaches peak horror too early (typically
chapters seven through ten of a thirty-chapter book) and
runs out of escalation room before the climax. The fix is
restraint at the early threshold and reservation of the
deepest dread for the third act. Verify also that the
protagonist's options narrow consistently — the genre's
structural pressure is the closing of escape routes, and a
book in which the protagonist has the same options at
chapter twenty as at chapter five has not constructed the
trap the form requires. Test: at chapter ten, fifteen,
twenty, twenty-five, list the protagonist's available
options. The list should shorten across the points, with
each lost option earned by something that occurred.

### Pass 2: Body Response Check

Verify the protagonist experiences fear PHYSICALLY across
the manuscript. Horror's signature embodiment is what
distinguishes the form from psychological thriller: in
horror, the body knows before the mind, and the prose
registers the body's intelligence before the conscious
mind catches up. Check that body reactions are specific (not
just "she was scared" or "she was terrified"). Specific
embodied fear includes: the particular kind of cold (the
chest cold, the fingers numb, the back-of-the-neck cold);
the involuntary body sounds (the breath that catches, the
swallow that doesn't go down); the muscle locks (the
specific freeze in the legs, the hand that won't open, the
jaw that won't unclench); the gastrointestinal responses
(the specific kind of nausea, the bladder pressure, the
appetite gone); the visual disruptions (the tunnel vision,
the floaters, the inability to focus).

Verify the body responds BEFORE the mind processes. The
protagonist who reads a threatening note and then becomes
afraid has interpreted before feeling; the protagonist whose
hands are shaking before they consciously register why is
operating in the genre's signature embodiment. The fix where
this is reversed is to track the body's response first and
let the conscious recognition follow.

Test: pick three significant fear scenes and read each one
asking whether the body's response is specific, located, and
ahead of the mind. If any scene tells rather than embodies,
the body-response check has flagged it.

### Pass 3: Threat Logic Check

Build a threat-rules ledger: every named characteristic of
the threat (capabilities, limitations, conditions of
appearance, vulnerabilities, behavioural patterns,
relationships to time / space / objects / people) with the
chapter and page where each first appears. Read the
manuscript against the ledger. Does the threat behave
consistently with established rules? The genre's reader
notices threat-logic violations immediately — the ghost that
required invitation in chapter four cannot freely enter in
chapter twenty without explanation; the entity that could
not cross water in chapter eight cannot suddenly cross
water in chapter twenty-five.

Verify any new information about the threat is earned
through the protagonist's actions — investigating, observing,
suffering. Information that arrives by authorial fiat (the
exposition character who explains everything; the
convenient research that surfaces facts the threat had
been hiding) is the failure mode; information earned by
what the protagonist does is the technique. Verify the
threat's behaviour makes sense given its motivation. Even
non-rational threats (the supernatural force, the
incomprehensible entity) operate by some logic — the haunt
is bound to the place, the curse follows specific rules,
the entity's presence has a pattern. Where the threat
behaves randomly, the prose has lost its logic and the
horror has slipped into chaos that the reader cannot
engage with.

### Pass 4: Protagonist Intelligence Check

Read the manuscript with sole attention to the protagonist's
decisions. Does the protagonist make decisions the reader
would make in the same situation, with the same available
information? The genre's most-flagged character-craft failure
is the protagonist who walks toward the strange noise alone,
splits up the group for no reason, opens the basement door
late at night with no light, returns to the abandoned
location for no compelling reason. These choices break the
spell because the reader is no longer trapped with the
protagonist; they are watching a fool make foolish decisions.

When the protagonist makes mistakes, are the mistakes
understandable in context — stress, exhaustion, misinformation,
emotional pressure, conflicting loyalties? Mistakes earned by
specific, named pressures are the genre's signature character
work; mistakes deployed for plot convenience are the failure
mode. Verify the protagonist is TRYING to survive: actively
problem-solving, gathering information, attempting escape,
adapting to new threats, not passively waiting for rescue or
playing scenes for the reader's anxiety rather than the
character's survival.

Test: pick three significant decisions the protagonist makes
that, in retrospect, made the situation worse. In each, can
the writer identify the specific pressure or misinformation
that made the decision plausible at the moment? If any of
the three decisions makes no sense to the reader, the
protagonist's intelligence has been sacrificed to plot
mechanism.

### Pass 5: Atmosphere vs Action Balance

Verify dread is built before each major horror event. The
genre's pacing is dread-then-event-then-aftermath, with the
dread-build often longer than the event itself. A horror
event arriving without dread-build feels like spectacle, not
horror; an event that arrives after twenty pages of carefully
accumulated dread carries the weight the dread invested.
Check that there is aftermath after each horror event — not
just jumping to the next scene of dread-build. The reader
needs space to process what occurred; the protagonist needs
embodied response to register; the prose needs to feel the
silence the event has left behind.

Check the breathing-room calibration. Horror requires relief
points (the quieter chapter, the moment of warmth, the
relationship beat that occurs when the threat seems
distant) so that the dread-and-event sequences register; a
book that operates at maximum dread continuously exhausts
the reader and the dread loses its grip. But the relief
points must shorten across the book — the breathing room
in chapter five may run a full chapter; by chapter twenty
the breathing room may be a single scene; by chapter
twenty-eight the breathing room may be one paragraph before
the next event lands. Test: chart the dread-to-relief ratio
across the manuscript. Is the curve calibrated for genre
contract, or is the manuscript stuck at one register
throughout?

### Pass 6: The Aftermath Gravity Audit

Run a final pass on the manuscript's post-climax pages.
Does the survivor (or survivors) emerge changed by what
occurred, with the change visible in the prose's specific
treatment of their post-event life? Or has the manuscript
delivered the climax and exited without registering the
gravity?

Check specifically for:
- The protagonist's relationship to ordinary life altered
  in tracked ways (the locked door checked compulsively,
  the inability to be alone in the dark, the changed
  reaction to ordinary stimuli that previously did not
  register)
- The relationships changed by what occurred (the friend
  who was lost; the friend who was not lost but who saw
  something the protagonist did; the family who cannot
  quite be told)
- The protagonist's relationship to themselves (what they
  did to survive, what they cannot stop thinking about,
  what they will not say aloud)
- The threat's continuing presence (where the genre's
  contract permits — and many sub-genres encourage —
  endings in which the threat is not fully resolved, has
  moved elsewhere, or has marked the survivor in ways that
  promise return)

Verify the manuscript has chosen its survival outcome
deliberately. The four available outcomes — survived-and-
changed, survived-as-self, survived-but-marked, not-survived
— each carry different genre conventions. The strongest
horror practitioners hold their chosen outcome through the
final chapter without softening at the close. A horror
manuscript that delivers a difficult journey and ends in
unearned safety has betrayed the form; a manuscript that
delivers an unambiguous bleak ending must have earned the
bleakness through what occurred. Test: read the final
chapter as the ending it is, and ask whether the world the
book has constructed permits the ending the writer chose.
If the ending is gentler than the world has earned, the
final pages need revision; if the ending is bleaker than
the journey has earned, the bleakness needs preparation
earlier in the book.

## Names & Patterns to Avoid

### Horror Character Names. NEVER USE
- Horror-cliché names: Damien, Raven, Salem, Carmilla, Mortimer
- Names that telegraph their role: Dr. Graves, Mr. Slaughter, the Keeper
- Names chosen for spooky sound rather than character

### Horror Location Names. NEVER USE
- "The [Adjective] [Building]": The Abandoned Asylum, The Forgotten Church, The Silent House
- Names with built-in horror: Blackhollow, Deadman's Creek, Slaughter Lane
- "Camp [Nature Word]": Camp Crystal, Camp Pinewood, Camp Lakeview (slasher cliché)

### Use Instead
- Ordinary names for the protagonist and allies (they're ordinary people)
- Location names that are mundane and become sinister through association
- The hospital isn't called "Ravenhurst". it's called "St. Helen's" and the horror makes it terrible
- Name the threat last: withhold its name until the protagonist earns it through understanding

## Comp Titles

Horror's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Shining* — Stephen King (1977): the modern haunted-place horror benchmark.
- *Pet Sematary* — Stephen King (1983): horror-grief; the genre's emotional foundation.
- *The Haunting of Hill House* — Shirley Jackson (1959): literary haunted-house template.
- *The Exorcist* — William Peter Blatty (1971): possession-horror benchmark.
- *Hell House* — Richard Matheson (1971): haunted-house horror lineage.

### Contemporary (current best-in-class)

- *The Last House on Needless Street* — Catriona Ward (2021): contemporary literary horror.
- *Mexican Gothic* — Silvia Moreno-Garcia (2020): post-colonial horror benchmark.
- *My Heart Is a Chainsaw* — Stephen Graham Jones (2021): meta-slasher horror; literary-genre crossover.
- *The Only Good Indians* — Stephen Graham Jones (2020): Indigenous-rooted horror.
- *Nothing But Blackened Teeth* — Cassandra Khaw (2021): horror novella; folkloric Japanese setting.
- *Our Share of Night* — Mariana Enríquez (2019, English 2023): Argentine literary horror epic.
- *The Hacienda* — Isabel Cañas (2022): post-colonial gothic-horror.
- *We Have Always Lived in the Castle* — Shirley Jackson (1962, classic): persistent contemporary touchstone.

## Cover Design Specifications

### Recommended Visual Styles
- **Atmospheric**. Dark, moody imagery with a single source of light; silhouettes, shadows, fog; the viewer feels watched
- **Minimalist**. A single disturbing element on a dark background: a door, a shadow, a stain, a shape; what ISN'T shown matters
- **Visceral**. Textural close-ups: skin, bark, rust, wet surfaces; the cover should feel unpleasant to touch
- **Typographic**. Bold, stark typography on a dark background; the title IS the horror; distressed, cracked, or stained lettering

### Genre Cover Aesthetics
- **Styles:** Dark compositions with limited light sources, empty spaces that feel occupied, architectural interiors (corridors, staircases, doorways), natural environments that feel hostile (forests, water, fog), close-up textures that feel wrong, lone figures in vast or confined spaces
- **Colours:** Near-black backgrounds, deep crimson (blood, viscera), sickly yellows and greens (decay, infection), cold blue-whites (moonlight, clinical), rust and brown (aged, stained); MINIMAL colour. most horror covers are predominantly dark with one accent
- **Elements:** Shadows that suggest but don't reveal, single light sources (flashlight beam, distant window, candle), natural textures that feel threatening (bare branches, rough stone, still water), architectural details (keyholes, cracks, peeling wallpaper), absence (empty chairs, open doors, untouched meals)
- **Typography:** Bold, simple fonts that read clearly on dark backgrounds; distressing, cracking, or staining effects; sometimes the typography IS the main design element; position low or centred with vast dark space above

### Market Positioning
Horror covers signal danger through darkness, restraint, and one precisely chosen unsettling element. Position against King, Hill, Tremblay, Katsu, Hendrix. The genre has two visual camps. subtle/literary and visceral/genre. and the subgenre determines which approach. At thumbnail size, dark covers with one light element or colour accent create immediate recognition. Avoid competing with thriller covers (too polished) or paranormal (too muted).

### Cover Design DON'Ts
- No explicit gore or mutilation on the cover (saves the visceral impact for inside)
- No cheesy horror imagery: dripping blood fonts, screaming faces, glowing eyes
- No bright or saturated colours (horror is dark, muted, desaturated)
- No B-movie monster poses (unless deliberately retro/homage)
- No generic "dark figure in the woods" without a distinguishing element
- No red as the dominant colour. it should be an accent, not the palette
