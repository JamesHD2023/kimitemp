---
name: horror-romance-genre
description: Genre-specific instructions for horror romance fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [romance, horror]
---

# Horror Romance. Genre Plugin

## Metadata

- id: horror-romance
- name: Horror Romance
- icon: 🖤
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Horror Fear Arc", "Romancing the Beat", "Three-Act Structure", "Save the Cat"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Survival Horror Romance | Love forged through shared survival against horrific threats | External horror drives the couple together; the romance provides hope against despair |
| Monster Lover Romance | The love interest IS the monster. alien, creature, or transformed being | The monstrous body is not an obstacle to overcome but a source of fascination and desire |
| Haunted Romance | Ghosts, hauntings, or supernatural entities complicate or enable the love story | The haunting parallels unresolved emotional history; exorcism mirrors healing |
| Slasher Romance | Romance within or around slasher-horror scenarios | High body count creates urgency; survival together bonds the couple |
| Cosmic Horror Romance | Love against Lovecraftian or existential horror backdrops | The romance asserts human meaning against cosmic indifference |
| Psychological Horror Romance | The horror is internal. madness, obsession, or perception itself is unreliable | The reader questions whether the romance is real, imagined, or manufactured |

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-5,000 words
- Pacing: Horror tension cycles interwoven with romance slow-burn: dread builds, intimacy provides relief, then safety shatters again
- Must open with: Atmospheric unease WITH romantic tension, supernatural wrongness near attraction, or danger forcing proximity
- Must close with: Dread deepened while connection strengthened, safety violated after vulnerable moment, or horror revelation affecting relationship

BEATS PER CHAPTER
1. Dread/Atmosphere: Sensory wrongness, environmental menace, creeping unease. horror is always present
2. Romantic Connection: Chemistry, vulnerability, emotional intimacy. fear strips pretense, attraction intensifies
3. Horror Escalation: Threat advances, safe spaces compromised, supernatural rules revealed or broken
4. Intimacy Under Duress: Shared danger creates trust, physical closeness born of necessity, vulnerability amid terror
5. Dual Stakes: Both survival AND relationship endangered. horror threatens to destroy love, love threatens to distract from survival

GENRE-SPECIFIC REQUIREMENTS
- Horror MUST be genuinely frightening: not diluted by romance, not metaphorical-only, real dread and real danger
- Romance MUST be central: not subplot, not afterthought, the emotional engine alongside the horror engine
- HEA/HFN required: couple survives together, but victory must be costly, scarred, hard-won
- Fear heightens desire: danger strips social masks, proximity under threat creates raw intimacy
- The monster/threat affects the relationship: supernatural forces test, corrupt, or bind the lovers
- Both genres resolve: horror confronted AND love declared, neither plot abandoned
- Consent despite extremity: even in life-or-death situations, intimacy remains chosen
- Atmospheric dread sustained: romance scenes still carry undertone of menace
- Love interest may BE the monster: or connected to the horror, but love must be genuine, not Stockholm syndrome
- Safe spaces violated: nowhere is truly safe, including romantic sanctuaries
- Psychological and physical horror balanced with emotional and physical intimacy
- Isolation forces intimacy: cut off from help, characters must rely on each other

FORBIDDEN
- Horror without romance substance: cannot be horror novel with a love interest tacked on
- Romance without genuine scares: cannot be romance with spooky aesthetics
- Torture porn: gore must serve emotional stakes, not spectacle
- Trauma bonding presented as healthy love: characters must choose each other beyond survival instinct
- Cheap jump scares interrupting romance: every scare earned through buildup
- Love conquers horror with no strategy: survival requires intelligence and sacrifice, not just devotion
- Horror entity rules changing to serve romance convenience
- Abuse by love interest excused as "the darkness inside them": accountability required
- Comedy relief destroying sustained dread: humor must be gallows humor, not tension-breaking
- Stereotypical characters: no helpless screamer paired with fearless protector; both leads need complexity, agency, and specific flaws
- Single-obstacle stories: layer internal emotional barriers alongside the supernatural threat; the horror is the external obstacle, the characters' wounds are the internal ones
- Relentless terror without emotional variation: even in horror romance, you need light and shade; a moment of black humor, unexpected tenderness, or absurd normalcy after a terrifying sequence amplifies both the horror and the romance

LIGHT AND SHADE IN HORROR ROMANCE

Emotional contrast is your most powerful tool. After a scene of devastating terror, allow a moment of surprising warmth. dark humor between lovers huddled together, tenderness in wound-tending, an absurd observation about their impossible situation. After a scene of genuine intimacy and safety, shatter it with the return of menace. This alternation is what makes horror romance work: the reader relaxes into connection only to have the floor pulled away, and recoils from fear only to find unexpected comfort. Two terrifying scenes back to back exhaust; terror followed by tenderness creates an emotional whiplash that hooks readers permanently.

OBSTACLE LAYERING

Horror romance has a built-in external obstacle (the supernatural threat), but this alone isn't enough for the romance. Layer INTERNAL obstacles that the horror illuminates: past traumas that the entity echoes, trust issues that danger exposes, fears of vulnerability that survival strips bare. The horror should test the relationship itself, not just threaten physical safety. The more obstacles between the couple. supernatural AND emotional. the more the reader yearns for their connection.

STORY TURNS (every 4-6 pages)
Every 4-6 pages must contain a turn. a moment where EITHER the horror stakes OR the romantic stakes shift (ideally both):
- Horror escalation that tests the bond: safe space breached while lovers are vulnerable, entity targeting one partner, supernatural contamination spreading
- Romantic breakthrough forced by terror: confession under mortal threat, first physical contact born of desperate comfort, emotional walls shattered by fear
- Trust tested by horror: one character's connection to the entity revealed, a secret kept for protection now endangering the other, choosing survival vs. protecting the partner
- Intimacy interrupted by menace: tender moment shattered by entity's return, romantic sanctuary violated, post-horror vulnerability exposed to new threat
- Sacrifice demanded: horror forces a choice between self-preservation and protecting the one you love, between survival and love's integrity
- Knowledge gained at cost: learning the entity's rules requires danger that changes the relationship, horror discovery that reframes the love interest
Turns in horror romance should intertwine BOTH genres. the best turns advance the horror AND the romance simultaneously.

NARRATIVE LAYERS (A/B/C stories)
- A-story: Survival: couple vs. the horror entity (can they survive the night, the haunting, the curse?)
- B-story: The romance: attraction building through shared terror, trust earned through vulnerability, love declared in the face of death
- C-story: The mystery beneath: what IS the entity, why does it target THIS couple, what connection exists between the horror and the love story?
Weave layers through dual-genre scenes: hiding together (A) creates physical proximity that breaks emotional barriers (B) while discovering the entity hunts couples specifically (C). A romantic breakthrough (B) is interrupted by an attack (A) that reveals the entity feeds on love itself (C).

FRACTAL STRUCTURE
Horror romance patterns repeat at every scale:
- Scene level: Dread building → romantic connection amid fear → horror strikes → consequence deepens both terror and bond (4-6 pages)
- Chapter level: Atmospheric menace → intimacy under duress → horror escalation → relationship transformed by shared ordeal
- Act level: Meeting in darkness → love forged in terror → surviving together, scarred but bound
Each scene should be a miniature of the whole. a moment where fear and desire are inseparable, where the horror makes the love more desperate and the love makes the horror more devastating.
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (trauma-bond), Stimulation (dread), Captivation (atmosphere).

HEAT LEVEL CALIBRATION

Heat level (Setup Q4: Sweet/Clean / Mild Spice / Open Door, plus
the Architect's per-chapter Spice 0-5 rating) calibrates EVERY
chemistry / intimacy / banter cue in this file. The Writer must
apply heat calibration before any other prose rule below — default
romance cues lean steamy, and at low heat that vocabulary collapses
to Hallmark/KU cliches.

→ See `heat-calibration.md` for the full universal calibration
   block (engine-agnostic, genre-agnostic):

   - The three calibrated bands (Sweet/Clean Spice 0-1, Mild Spice
     Spice 2, Open Door Spice 3-5)
   - Five concrete substitutes for body-cue chemistry vocabulary
     at low heat (interior architecture, non-body sensory channels,
     slow-burn architecture, external stakes, sentence rhythm)
   - The 13-entry sweet-romance cliche AVOID list
   - The five-question Calibration Self-Check
   - The Spice:0 worked example (cliche-driven vs calibrated, with
     annotations)

The calibration block is loaded into the Writer prompt's
`{heat_level_calibration}` slot automatically — `prose-protocol.md`
"Heat Level Calibration Slot" handles the wire-up.

VOICE & TONE
- POV: 1st person (intimate terror and desire) or close 3rd limited (dread through restricted knowledge)
- Tense: Past or present: present tense heightens immediacy of both fear and attraction
- Voice: Dread-soaked yet yearning, claustrophobic yet tender, visceral horror layered with raw emotional vulnerability
- Reading level: Adult: sophisticated psychological horror, mature romantic content, unflinching intimacy in extreme circumstances

PROSE IMPERATIVES
- Sensory wrongness bleeds into attraction: the lover's touch warm against skin gone cold with fear
- Physical fear responses mirror arousal: racing heart, flushed skin, inability to breathe, hypersensitivity
- Atmosphere never fully lifts: even romantic scenes carry undercurrent of menace (shadows in peripheral vision, distant sounds)
- Horror described through specific sensory detail: smells of decay, sounds without source, wrongness in familiar spaces
- Intimacy rendered with same visceral precision as horror: bodies described with equal attention in fear and desire
- Withhold full reveals: both the monster's true form AND the depth of feeling glimpsed before shown
- Isolation language emphasizes shared vulnerability: "only us," "no one coming," "just each other"
- Dread builds through accumulation: small wrongnesses layering into overwhelming terror
- Consent explicit in context of danger: choosing closeness despite fear, not because of it
- Psychological deterioration tracked alongside emotional deepening: trust grows as sanity frays
- Silence used for both horror and intimacy: pregnant pauses carry menace AND longing

PROSE RHYTHM MAPPING (translates pacing into execution)

Chapter 1. Hook delivery:
- Dread AND desire from page one: the horror is present, the attraction is undertow
- Tension floor: 7 (horror dominates the opening; the romance should feel DANGEROUS, not safe)
- Open with wrongness: something is off, something is watching, something is about to happen: and then the other person
- Dialogue density: 20-30%: atmosphere and interiority dominate; silence carries both menace and longing

Horror scenes (prose rhythm):
- Short fear-sentences during active dread: fragments when terror peaks
- Atmospheric dread: longer sentences building through accumulation of small wrongnesses
- Sensory detail visceral and uncomfortable: specific smells of decay, sounds without source, cold that shouldn't be there
- Interiority budget: 40%: the deterioration of certainty, the fraying of what's real

Romance scenes within horror (prose rhythm):
- Tenderness rendered with the same visceral precision as the horror: bodies tended, warmth against cold
- Romance never fully escapes the atmosphere: even intimate moments carry undercurrent of menace
- Sentences warm but awareness remains: shadows in peripheral vision, distant sounds, temporary safety
- The romance should feel like defiance: choosing connection despite the encroaching dark

Climax/resolution prose rhythm:
- Horror climax: prose fragments, sensory overload, the entity at full force: SHORT, sharp, overwhelming
- Love as survival weapon: sentences shift from fear-fragments to something fiercer: together against the dark
- Resolution: scarred but bound: prose carries both the cost of what was survived and the warmth of what was saved

GENRE-SPECIFIC STYLE
- Gothic settings as romantic backdrop: decaying mansions, fog-shrouded moors, haunted houses where lovers shelter
- Monster as mirror: the horror reflects or tests the relationship's deepest fears (abandonment, loss, betrayal)
- Wounds tended as intimacy: binding injuries, cleaning blood, the tenderness of caring for damaged bodies
- Survival sex vs. love: distinguish between adrenaline-fueled desperation and genuine emotional connection
- Haunted spaces as shared experience: exploring cursed locations together creates unique bond
- Body horror and body intimacy: awareness of flesh in both its vulnerability and its desire
- Darkness as intimacy: when you can't see, other senses heighten for both horror and attraction
- Love interest's supernatural nature (if applicable) both terrifying and alluring: fangs, cold skin, inhuman strength
- Danger as aphrodisiac handled carefully: attraction heightened by survival, not by the violence itself
- Domestic horror meets domestic intimacy: the home as both shelter and trap, comfort and threat
- Post-horror vulnerability: after terror, emotional walls crumble, creating space for genuine connection
- Shared secrets: knowing the truth of the horror bonds characters more deeply than ordinary experience

FORBIDDEN WORDS/PHRASES
- "Orbs" for eyes: just say eyes, gaze, or specific color
- "Suddenly" without atmospheric buildup: earn every scare
- "It was terrifying/scary": show the specific terror through sensory detail
- "They had chemistry": demonstrate attraction through action and reaction
- Purple prose during critical horror moments: clarity and visceral impact over elegance
- Jump scare punctuation (excessive exclamation points!!!)
- Clinical anatomy in intimate scenes: poetic precision over medical terminology
- "Dark and stormy night" cliches: make atmospheric dread specific and fresh
- Telling fear or desire: show both through physical response and internal reaction

WORD CHOICE
Horror romance demands vocabulary that serves BOTH registers simultaneously:
- Body words work double duty: "pulse," "flush," "trembling," "breathless": fear and desire share a lexicon
- Darkness vocabulary: "shadow," "whisper," "chill," "hunger": words that carry both menace and intimacy
- Proximity language: "close," "pressed," "skin," "warmth against cold": forced closeness for survival AND attraction
- Silence vocabulary: "held breath," "listening," "stillness": pregnant pauses carry BOTH dread and longing
- Never use "suddenly" without buildup; never use "orbs" for eyes; never tell "they had chemistry": show everything

EMOTIONAL RHYTHM
Horror romance alternates between dread and desire, with each intensifying the other:
- After terror: vulnerability creates intimacy: walls crumble, bodies seek comfort, confession comes easier when death was just close enough to touch
- After intimacy: horror strikes harder: the reader (and characters) let their guard down, making the next scare devastating
- Quiet domestic moments between horrors. tending wounds, sharing food, keeping watch. where the real romance lives
- The overall chapter rhythm: atmospheric dread → romantic connection amid fear → horror strikes → consequence deepens both terror and bond
- Light and shade: two terrifying scenes back-to-back exhaust; terror followed by tenderness creates emotional whiplash that hooks readers permanently

HORROR ROMANCE PROSE MASTERCLASS
The difference between great horror romance and two genres awkwardly sharing pages is SIMULTANEITY. fear and desire existing in the same moment:

Dread and Desire in One Breath. the body doesn't distinguish between fear and attraction:
  ✅ "His hand found hers in the dark, and she flinched—from his touch or from the sound that had just come from the hallway, she couldn't tell. His fingers were warm. The hallway was not. She held on. Something scraped behind the wall, patient and rhythmic, and he pulled her closer, one arm across her shoulders, his mouth near her ear. 'Don't move,' he whispered, and she didn't know if her heart was hammering because of the thing on the other side of the plaster or because she could feel his heartbeat against her back, just as fast as hers."
  ❌ "She was scared of the ghost but also attracted to him. Her heart was beating fast from both fear and desire. He held her hand protectively."

Intimacy Earned Through Horror. tenderness that only means THIS MUCH because of what surrounds it:
  ✅ "She cleaned the wound with shaking hands—three parallel gashes across his ribs where the thing had raked him, deep enough to see the white flash of bone. He hissed through his teeth and she said 'sorry, sorry' and he said 'don't stop' in a voice that had nothing to do with the wound. She pressed the gauze against his skin. His hand came up to cover hers. Outside, something moved across the porch with slow, deliberate steps. Neither of them let go."
  ❌ "She bandaged his wounds from the monster attack. It was a tender moment. They could hear the creature outside but focused on each other."

Horror That Devastates BECAUSE of Love. the stakes are higher when you have something to lose:
  ✅ "The thing wearing Sarah's face smiled at him from across the kitchen, and that was the worst part—it used her smile, the specific one she gave him over morning coffee, private and slightly crooked. 'Come here,' it said in her voice, and his body took a step forward before his mind screamed stop. He could still smell her shampoo. He could see her freckles. But her eyes were wrong—too dark, too still, like windows with no one behind them."
  ❌ "The monster had taken over Sarah's body. He could tell it wasn't really her even though it looked like her. He was scared but also sad because he loved her."

HORROR-ROMANCE TENSION
- Fear strips pretense: Terror forces characters past social masks to raw emotional honesty
- Shared survival creates trust: Fighting together against supernatural threat builds bond faster than ordinary courtship
- Monster threatens love: The horror doesn't just endanger bodies: it threatens the relationship itself (possession, corruption, forced separation)
- Vulnerability in danger: Admitting attraction when death is near carries more weight than ordinary confession
- Physical proximity forced: Hiding together, sharing warmth, barricading doors: horror creates physical closeness
- The body in both registers: Same skin that crawls with fear shivers at a touch; same heart that pounds in terror races with desire
- Adrenaline aftermath: Post-danger collapse creates windows for tenderness and confession
- Horror as crucible: The relationship that survives genuine terror is forged stronger than ordinary love

INTIMACY IN HORROR CONTEXT
- Romantic scenes carry menace: the door might open, the darkness might move, safety is temporary
- Physical intimacy as defiance: choosing pleasure and connection in the face of death and horror
- Tenderness amplified by surrounding brutality: gentleness means more when the world is violent
- Bodies mapped in fear and desire: scars from the horror touched with love, bruises kissed
- Post-horror intimacy: after surviving terror together, emotional and physical barriers dissolve
- Supernatural interference in intimacy: entity watching, cursed spaces, possession threatening during vulnerable moments
- Love scenes grounded in survival: not escapist fantasy, but fierce assertion of life against encroaching death
- Aftercare as horror recovery: comfort, reassurance, and physical care after both terror and intimacy

INTIMATE SCENES. CHARACTER REVELATION THROUGH EXTREMITY

- Sex scenes in horror romance must serve the relationship and character development, not merely titillate or shock
- Ask: what does this intimate moment reveal about the characters' emotional state, their trust level, their relationship to fear and desire?
- The best intimate scenes in horror romance contain emotional rawness: awkwardness, desperation, grief, fierce gratitude for being alive
- Build physical intimacy into the emotional landscape of the story; it should feel like a natural response to the accumulated pressure of shared survival
- Sensory writing is essential: the specific textures and temperatures of bodies seeking comfort in a threatening environment
- The horror should remain present even in intimate moments: distant sounds, awareness that safety is temporary, the knowledge that the world outside is dangerous

METHOD WRITING. EMOTIONAL TRUTH

- Identify what you want the reader to FEEL before writing any key scene: terror? desperate tenderness? the ache of wanting someone when death is near?
- If the writer isn't feeling the emotion while writing, the reader won't feel it while reading: that's the signal to go back and find what's blocking the feeling
- Write through all five senses to put the reader INTO the scene: what does fear smell like in this space? What is the exact sensation of a lover's warmth against skin gone cold with dread?
- Never be cynical about emotion: don't kill a character or deliver a horror set-piece purely for shock value. Genuine emotion, earned through character investment, is what makes readers both scream and weep

DIALOGUE. THE UNSAID IN EXTREMITY

- Characters in mortal danger rarely say what they mean about their feelings: they deflect with dark humor, practical focus, or silence
- This restraint gives ENORMOUS resonance to the moments when characters finally confess what they feel: a declaration of love in the face of death carries more weight than any safe-space confession
- Each character should speak distinctly even under duress: their verbal patterns, deflections, and the way they handle fear should be as individual as fingerprints
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)
1. Dual genre satisfaction: Both genuinely frightening AND romantically compelling. neither genre merely decorative
2. HEA/HFN delivered: Couple together at end, love earned through surviving horror. but victory costly, scarred
3. Horror authentically terrifying: Sustained dread, escalating threat, real danger. not just gothic aesthetics
4. Romance emotionally resonant: Chemistry demonstrated, vulnerability shown, connection earned. not just proximity
5. Both plots resolved: Horror confronted AND relationship committed. neither abandoned for the other

GENRE-SPECIFIC CHECKS
- Genuine scares present: Atmosphere of dread sustained, specific terror moments that unsettle
- Romance central: Relationship drives emotional core, not subplot to horror plot
- Fear and desire intertwined: Horror amplifies romantic tension, intimacy creates horror vulnerability
- Monster/threat affects relationship: Supernatural force tests, threatens, or transforms the love story
- Consent maintained: Even in extreme danger, intimacy chosen, not coerced by circumstances
- Both POVs shown: Each romantic lead's fear AND attraction demonstrated
- Horror rules consistent: Entity/threat has established powers and limitations maintained throughout
- Romantic progression earned: Attraction to trust to vulnerability to love: not instant, not forced
- Atmosphere in romance scenes: Even tender moments carry undercurrent of menace, dread doesn't vanish
- Survival and love both at stake: Losing the battle means losing each other, not just dying

AUTOMATIC FAILS
- No genuine horror: Gothic aesthetics without actual dread, scares, or danger
- No real romance: Horror with attraction subplot, couple not central emotional engine
- Tragic ending without HEA/HFN: Both leads dead, separated, or romance destroyed: violates genre promise
- Torture porn: Gratuitous gore without emotional purpose or romantic stakes
- Trauma bonding as love: Relationship built solely on shared terror without genuine emotional connection
- Horror evaporates for romance: Dread disappears during intimate scenes with no atmospheric continuity
- Love fixes horror: Devotion alone defeats monster without strategy, sacrifice, or cost
- Abuse as dark romance: Love interest's violence, control, or cruelty excused as supernatural nature
- Monster rules inconsistent: Entity's powers change arbitrarily to serve romance or horror convenience
- One genre abandoned: Horror resolved but romance dropped, or romance concluded but horror plot forgotten

ACCEPTABLE IMPERFECTIONS
- More horror than romance chapters (or vice versa) if both genres substantial and satisfying
- Heat level varies: some horror romance explicit, some closed door, some fade-to-black
- Horror ambiguity in ending if romance resolved: couple together even if threat not fully vanquished
- Gothic atmosphere occasionally dominant over active horror if romance tension sustains engagement

RED FLAGS TO INVESTIGATE

⚠️ Horror and romance operating on separate tracks. scares in horror scenes, chemistry in romance scenes, never intersecting
⚠️ One genre vanishing for extended stretches. 3+ chapters of pure horror without romantic progression, or vice versa
⚠️ Dread dropping completely during intimate scenes. even tender moments should carry menace in the background
⚠️ Trauma from horror absent in romance scenes. character terrorized in one scene, emotionally available with no residue in the next
⚠️ Entity rules changing to enable romantic plot convenience. if the monster can't enter the bedroom, that's a safe space; if it suddenly can, that needs escalation logic
⚠️ Attraction based solely on danger. no specific chemistry beyond shared survival; adrenaline alone isn't love
⚠️ Only one character with agency. protector/protected dynamic without both leads making meaningful choices about survival AND relationship
⚠️ Horror escalation that ignores the romance's progress. attacks should target the bond, not just bodies
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Horror entity rules: Supernatural threat's powers, limitations, and vulnerabilities consistent. never changed for romance convenience
2. Relationship progression: Emotional intimacy deepens logically through shared horror experiences. trust earned, not assumed
3. Horror escalation: Threat intensity increases steadily. small disturbances to direct encounters to overwhelming danger
4. Trauma accumulation: Physical injuries and psychological damage persist. characters carry scars from horror AND emotional wounds from relationship
5. Safe space erosion: Previously secure locations progressively compromised. sanctuaries violated, hiding places discovered

GENRE-SPECIFIC TRACKING
- Romance milestones: First meeting, first moment of trust, first physical contact, first kiss, declaration, commitment: each tied to horror context
- Horror escalation stages: Unease, investigation, first encounter, casualties, point of no return, final confrontation
- Entity rules: What the threat can/cannot do, when it's active, what weakens it: established early, maintained throughout
- Shared knowledge: What each character knows about the horror, when they learned it, what they've told each other
- Injury and trauma status: Physical wounds, psychological damage, PTSD responses: tracked across chapters
- Safe spaces: Which locations have been compromised, which remain (temporarily) secure
- Isolation level: Communication status, distance from help, available resources, ally count
- Supernatural contamination: If horror corrupts people/places, track progression of corruption
- Romantic vulnerability: What each character has revealed emotionally, secrets still held, trust level
- Monster-relationship intersection: How the entity specifically targets or exploits the romantic bond
- Character beliefs: Skepticism vs. acceptance of supernatural: track when each character believes

ACCEPTABLE INCONSISTENCIES
- Minor atmospheric details if overall dread maintained (exact shadow positions, ambient sounds)
- Slight variation in entity behavior if core rules intact (different manifestations of same power)
- Emotional oscillation natural in extreme circumstances: fear and attraction may ebb and flow

CRITICAL CONSISTENCY
- Entity rules don't break for romance: if the monster can't enter consecrated ground, love scenes there are safe, love scenes elsewhere are not
- Trauma doesn't vanish: if a character was terrorized, they carry the psychological damage into romantic scenes
- Dead characters stay dead: no miraculous returns unless established by supernatural rules
- Relationship intimacy level: first kiss happens once, trust once broken must be rebuilt
- Horror knowledge: once characters know the entity's weakness, they remember it
- Injury timeline: wounds heal realistically (or supernaturally if rules established)
- Isolation maintained: if phones don't work in chapter 5, they don't suddenly work in chapter 12
- Supernatural contamination progression: corruption advances, doesn't reverse without cost
- Romantic promises: declarations and commitments remembered and honored
- Geography of horror: haunted rooms, dangerous areas, safe zones consistent in physical layout

NARRATIVE LAYER TRACKING
- A-story (Survival): Couple vs. entity: current threat level, safe spaces remaining, knowledge of entity's rules, plan status
- B-story (Romance): Relationship progression: current intimacy level, trust status, emotional barriers remaining, recent breakthrough or setback
- C-story (Mystery): What is the entity, why this couple, what connects the horror to the love: knowledge accumulating
- Track intersections: when the horror directly targets the romantic bond (A meets B), when a romantic revelation changes understanding of the threat (B meets C)
- Flag when either genre is absent for 2+ chapters: horror romance demands BOTH engines running simultaneously

STORY TURN LOG
- Track each chapter's significant shift in BOTH horror and romance: what changed in the threat level AND what changed in the relationship?
- Turns should intertwine genres: a horror discovery that reframes the romance, an intimate moment that reveals vulnerability the entity exploits
- Ensure turns escalate: early turns shift comfort, middle turns test trust, late turns demand sacrifice
- Flag chapters with a turn in only one genre: the best horror romance chapters advance BOTH simultaneously
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Dual protagonists as co-survivors: Both romantic leads fully developed with distinct fear responses, coping mechanisms, and reasons for staying despite danger
2. Courage and vulnerability balanced: Characters brave enough to face horror, vulnerable enough for genuine romance. neither fearless nor helpless
3. Trauma responses consistent: Each character's psychological reactions to horror maintained. flinching, nightmares, hypervigilance carry through
4. Attraction amid terror authentic: Chemistry demonstrated through specific, earned moments. not generic, not forced by proximity alone
5. Agency preserved: Both characters make meaningful choices about survival AND relationship. neither purely rescued nor purely rescuer

CHARACTER BUILDING. GROUND UP FOR HORROR ROMANCE

Build each protagonist from the ground up BEFORE they face the horror. The character must exist fully independent of the supernatural threat:
- Background questions: What do they want from life? What are they running from emotionally? What is their relationship history? What do they carry?
- Character tests: How would they react to witnessing cruelty in ordinary circumstances? What's in their bag/pockets? What do they reach for when afraid: humor, action, withdrawal?
- These details inform everything: how they respond to terror, how they express attraction under duress, what specific vulnerabilities the horror can exploit
- Messy, flawed characters create richer horror romance: a character with a fear of abandonment experiences supernatural isolation differently than one who fears loss of control

ANTI-STEREOTYPE IMPERATIVE

Avoid default horror romance archetypes: no helpless victim paired with fearless protector; no damsel rescued by dark supernatural savior without agency of her own. Both protagonists need specific, individual complexity. The most compelling horror romance characters are ordinary, flawed people placed in extraordinary circumstances. their individual weaknesses and strengths should be what makes this particular love story unique. Stereotypes flatten both the horror and the romance.

GENRE-SPECIFIC CHARACTER ELEMENTS
- Fear responses individualized: Each character has distinct reaction to horror. fight, flight, freeze, fawn. and it's consistent
- Romantic attraction specific: What draws them together beyond shared danger: personality, competence, tenderness, humor under pressure
- Supernatural connection (if applicable): One or both may have ties to the horror: psychic sensitivity, family curse, past encounter
- Skeptic vs. believer dynamic: Characters may have different acceptance rates of the supernatural: creates productive tension
- Competence under pressure: Characters must be capable enough to survive: horror romance requires protagonists who act, not just react
- Emotional armor: Each character has defenses (humor, stoicism, denial) that horror and romance both work to strip away
- Backstory wounds: Past trauma that horror echoes and romance heals: abandonment, loss, betrayal given new context
- Monster affinity (if love interest is supernatural): The inhuman qualities that both terrify and attract: cold touch, predatory grace, impossible strength
- Moral complexity: Characters may make ugly survival choices. lying, sacrificing others, embracing darkness. that romance must reckon with
- Physical vulnerability: Characters bleed, tire, break: bodies are mortal (or formerly mortal) and horror exploits this
- Protective instincts: Desire to shield the other from horror creates tension between partnership and smothering
- Characters must walk a TRUE LINE: cannot suddenly act out of character for plot convenience; a character established as brave doesn't cower without earned regression, and a character built as guarded doesn't open up without earned trust

CHARACTER ARCS MUST
- Show fear arc: initial courage/denial through genuine terror to hard-won bravery earned by facing horror
- Demonstrate romance arc: attraction through trust through vulnerability to love and commitment
- Navigate horror's effect on relationship: entity/threat testing, corrupting, or forcing choices about the bond
- Confront personal demons alongside literal ones: backstory wounds opened by horror, healed by love
- Earn survival: not through luck or rescue but through courage, intelligence, sacrifice, and partnership
- Choose love despite cost: knowing the horror makes loving dangerous, choosing to love anyway
- Transform through shared ordeal: characters at end fundamentally changed by both terror and intimacy
- Maintain agency: both characters make choices that affect survival AND relationship, not passive victims

TRACK
- Fear responses: what triggers each character, how they react, whether responses evolve
- Trust level: between characters, built and tested by horror events
- Physical condition: injuries, exhaustion, malnutrition accumulating through story
- Psychological state: sanity, trauma responses, nightmare frequency, hypervigilance level
- Romantic milestone reached: where in the attraction-to-love progression each character sits
- Supernatural sensitivity: who perceives the entity, how, and whether it's growing
- Secrets held: from each other and about the horror, when revealed and how
- Coping mechanisms: how each character manages fear and whether romance provides alternative coping
- Competencies: what each character can do that aids survival (knowledge, physical ability, supernatural gift)
- Moral compromises: what each has done to survive and whether the other knows

RED FLAGS TO INVESTIGATE

⚠️ One character consistently protected while other does all the surviving. both leads need agency in horror AND romance
⚠️ Fear response inconsistent. a character who freezes in Ch 5 shouldn't be a fearless warrior in Ch 12 without earned growth
⚠️ Trauma absent from romance scenes. if a character was terrorized, the psychological residue should be visible in intimate moments
⚠️ Attraction based purely on proximity and adrenaline. no specific chemistry, no individual qualities drawing them together beyond shared danger
⚠️ Emotional walls down too easily. if a character is built as guarded, trust should be earned through specific actions, not just time together
⚠️ Horror making one character passive. extreme fear should change behavior, not eliminate agency
⚠️ Love interest's monstrous nature presented without complexity. if they're dangerous, the romantic lead should grapple with that honestly

ACCEPTABLE VARIATIONS (Won't Break Immersion)

Fear response shifting once under extraordinary circumstances (the freezer who fights to protect their lover)
Emotional availability fluctuating between scenes. sometimes terror makes characters more open, sometimes it makes them withdraw; both are realistic
One character being more horror-competent than the other if the imbalance is acknowledged and the less-competent character contributes differently
Brief moments of gallows humor between characters as coping mechanism (not comedy relief. dark humor that makes the dread worse)
Romantic progression occasionally leaping forward after a major shared horror event. danger DOES accelerate intimacy, if the emotional foundation exists
```

## Arc Rules

```
ACT I (Chapters 1-10): Meeting in the Haunted Place
- Ch 1: Arrival at horror setting OR normalcy with subtle wrongness: AND romantic lead introduced with immediate chemistry
- Ch 2-3: Environment explored, unease established: characters drawn together by circumstance, attraction noted but secondary to growing dread
- Ch 4-5: First supernatural event: characters experience horror together, shared fear creates forced intimacy and trust accelerates
- Ch 6-8: Horror escalating. evidence accumulates, skepticism crumbles. meanwhile attraction deepens through vulnerability exposed by fear
- Ch 9-10: First major horror encounter. undeniable proof of threat, first death or serious injury. characters commit to facing danger together, protective instincts and romantic tension intertwined
- Purpose: Establish BOTH horror atmosphere and romantic chemistry as co-equal forces: neither decorative
- Ends with: Horror undeniable, characters bound together by shared knowledge and growing attraction

MIDPOINT (Chapter 15): Terror and Intimacy Collide
- Entity's full power revealed OR major character dies AND first significant intimacy (physical or deep emotional)
- The horror directly threatens the relationship: possession, corruption, forced separation, or revelation about love interest's connection to the evil
- Tonal shift: From "what is happening to us?" to "can we survive this AND each other?"

ACT II (Chapters 11-23): Love in the Mouth of Hell
- Ch 11-14: Romance deepening through shared survival: tending wounds, keeping watch, confiding fears, bodies pressed together in hiding
- Ch 15: MIDPOINT: major horror escalation AND first deep intimacy intertwined, entity targeting the bond
- Ch 16-18: Casualties and consequences: allies lost, safe spaces breached, horror threatens to corrupt one lover or destroy what they're building
- Ch 19-21: Desperate research or resistance: learning entity's rules while relationship faces horror-born obstacles (is love interest part of the horror? can you trust someone under supernatural influence?)
- Ch 22-23: Black moment: horror at maximum, relationship shattered or tested to breaking point (possession of lover, sacrifice demanded, truth about supernatural connection revealed)
- Purpose: Romance intensifies BECAUSE horror escalates: each genre fueling the other's stakes
- Ends with: Darkest hour: separated by horror or by betrayal/revelation, both survival and love seem impossible

ACT III (Chapters 24-30): Love Survives the Night
- Ch 24-25: Choosing each other despite the horror's cost: love declared or reaffirmed in the face of death, plan formed using horror knowledge AND trust built through relationship
- Ch 26-28: Final confrontation: couple faces entity together, combining their strengths, romance powering courage but strategy and sacrifice defeating the horror
- Ch 29: Aftermath: horror defeated or escaped (possibly ambiguously), couple reunited, scars acknowledged, commitment made
- Ch 30: Earned HEA/HFN. couple together, permanently marked by horror but choosing love and life. tender final scene acknowledging both what they survived and what they found
- Purpose: Resolve horror threat AND cement romantic commitment: love earned through fire, not gifted
- Ends with: HEA/HFN: couple together, horror survived, scars as testament to what they endured together

GENRE PROMISE
Horror Romance readers expect:
- Genuine fear: dread sustained, scares earned, danger real
- Central romance: not subplot, the emotional spine of the story
- HEA/HFN: couple together despite horror, love hard-won
- Fear heightening desire: danger strips pretense, survival creates intimacy
- Both genres respected: real horror craft AND real romance craft
- Monster may be love interest, but love must be genuine, not captivity
- Costly victory: scars, trauma, loss alongside love and survival
- Atmospheric dread in romantic moments: safety is temporary
- Intimacy as defiance: choosing love in the face of death

REQUIRED CHECKPOINTS
- Ch 3: Horror atmosphere established AND romantic chemistry undeniable
- Ch 5: First supernatural event experienced together: shared fear bonds characters
- Ch 10: Horror undeniable, characters committed to survival AND to each other
- Ch 15: Major terror AND major intimacy collide: entity targets the relationship
- Ch 20: Horror threatens to destroy love: possession, corruption, forced separation, or dark revelation
- Ch 23: Black moment: both survival and romance at breaking point
- Ch 25: Love declared or reaffirmed in face of death: choosing each other despite cost
- Ch 28: Couple confronts horror together, combining strengths forged through relationship
- Ch 30: HEA/HFN: scarred, changed, together, choosing life and love after surviving the night

EMOTIONAL CONTRAST IN ARC STRUCTURE

Chart the emotional arc as alternating peaks and valleys of terror and tenderness. After every major horror escalation, provide a breathing space where the couple connects. even briefly. After every moment of genuine intimacy or safety, shatter it with the return of threat. This rhythm is what makes horror romance addictive: readers are simultaneously craving comfort and bracing for the next scare. Two consecutive horror set-pieces exhaust; horror followed by tenderness creates the emotional whiplash that defines the genre.

EARNED ENDINGS

The HEA/HFN must be earned through everything the characters have endured. The couple's survival should require intelligence, sacrifice, and the specific strengths their relationship has forged. not just devotion or luck. The ending should feel like the inevitable destination of THESE specific characters who were built from the ground up. Seed the resolution early: if the couple defeats the horror through their combined knowledge, plant those capabilities in earlier chapters so the victory feels earned, not convenient. A horror romance ending can be bittersweet. scarred, changed, haunted. but it must carry hope. The reader should close the book believing this love was worth the nightmare.

THEME BENEATH THE HORROR

Every horror romance benefits from a THEME running beneath the surface. what the story is really about beyond the scares and the love story. Is it about how love survives the worst circumstances? About confronting the darkness within ourselves to connect with another person? About choosing life in the face of death? Theme adds a dimension that makes horror romance literary rather than merely thrilling.

PACING CHECKPOINTS

Act I: Dual establishment. horror atmosphere and romantic chemistry must BOTH be undeniable by Ch 5; neither genre can wait for the other
Midpoint: Convergence. maximum terror and maximum intimacy collide in the same scene or adjacent scenes; the entity targets the bond
Act II: Alternating peaks. horror escalation and romantic deepening trade off, each feeding the other's intensity
Act III: Simultaneous resolution. horror confronted and love committed in the same climactic sequence; couple fights together
Overall rhythm: Dread → tender moment stolen from fear → horror shatters safety → connection deepens through survival → repeat with escalating intensity
Every 2-3 chapters: Either a major scare or a major romantic milestone. ideally both woven into the same scene
```

## Timeline Rules

```
TOP 5 TIMELINE PRIORITIES (Ranked by Impact)

1. HORROR COMPRESSES ROMANCE: Danger accelerates emotional vulnerability. weeks of courtship happen in days of terror; shared survival creates intimacy faster than ordinary life, and this accelerated timeline must feel earned, not forced
2. NIGHT/DAY CYCLE: Track when the entity is active. many supernatural threats strengthen in darkness; nightfall raises both horror stakes and romantic proximity; dawn offers fragile breathing room
3. EXHAUSTION AND DEPRIVATION: Sleep debt, missed meals, and untreated wounds affect both fear response and emotional regulation. characters become more vulnerable to BOTH terror and intimacy as the body fails
4. ENTITY PATTERN: The horror follows a cycle. every midnight, every third night, waxing moon, triggered by specific actions; track this pattern and show characters learning it
5. COUNTDOWN PRESSURE: Deadline to ritual, anniversary of original horror, entity reaching full power. urgency compresses both survival planning and romantic confession

TIME SCALE
- Total story duration: Days to weeks (horror compresses time: extended terror is unsustainable)
- Chapter time span: Hours to days: horror demands urgency, romance needs breathing room between terrors
- Time progression: Mostly linear with possible flashbacks revealing backstory or origin of horror

GENRE-SPECIFIC TEMPORAL RULES
- Time distortion near entity: supernatural influence may warp perception; hours feel like minutes during terror, minutes like hours waiting for dawn
- Romance needs breathing room: cannot sustain maximum terror constantly; intimate moments create pacing valleys where the relationship deepens
- Post-horror recovery time: after major terror events, characters need time to process before romantic progression can happen authentically
- Injury healing timeline: wounds sustained in horror scenes don't vanish for romance scenes
- Seasonal/celestial timing: full moons, solstices, anniversaries may trigger supernatural events
- How long characters have known each other vs. intensity of bond: track this carefully; accelerated intimacy needs horror justification

CHAPTER-BY-CHAPTER PACING GUIDE

Act I (Ch 1-10): Meeting in Darkness
- First days: normalcy with creeping wrongness; romance timeline begins with meeting and attraction
- Horror compresses courtship: first supernatural event together creates days' worth of trust in hours
- By end of Act I: characters have known each other days but shared more intensity than years of ordinary life

Midpoint (Ch 11-15): Terror and Intimacy Collide
- Horror timeline accelerating: entity attacks more frequently, safe periods shrinking
- Romance timeline reaching critical moment: first deep intimacy coincides with peak danger
- Night becomes the crucible: most important scenes happen in darkness where both genres intensify

Act II (Ch 16-22): Love in the Mouth of Hell
- Hours between attacks shrinking: entity's pattern escalating
- Sleep debt critical: 36-48+ hours awake, characters making mistakes from exhaustion
- Intimate moments stolen between horrors: time pressure makes tenderness more desperate and precious
- Countdown visible: deadline approaching, hours/days remaining

Act III (Ch 23-30): Surviving the Night
- Real-time pacing during final confrontation: every minute counts
- Post-horror: immediate aftermath brief and shell-shocked, then earned HEA/HFN breathing room
- Final scene should feel like the first true exhale: safety tentative, love certain

RED FLAGS TO INVESTIGATE

⚠️ Romance deepening without horror justification. if characters have been safe and comfortable, the accelerated timeline feels false
⚠️ Entity pattern inconsistent. if it attacks every midnight, it should attack every midnight (unless disrupted for established reasons)
⚠️ Characters fully functional after 48+ hours without sleep
⚠️ Injuries from horror scenes absent during subsequent romance scenes
⚠️ Countdown deadline forgotten or inconsistently tracked
⚠️ Post-horror recovery too quick. character terrorized one scene, emotionally available the next with no transition

FLEXIBLE
- Exact hours during sustained terror (adrenaline distorts time perception)
- Minor scheduling details between horror events
- Background world timeline if story is isolated/contained
```

## Genre-Specific Craft Techniques

Horror romance is the most ethically demanding hybrid in
romance publishing. It asks the reader to find desire in the
direction of what should be feared and to find love in proximity
to what could kill. Done well, it dramatises a real psychic
truth — that intimacy itself involves surrender, that being
known is being exposed, that loving anyone is loving someone
who could destroy you — and gives that truth its full
imaginative force. Done badly, it instrumentalises fear as a
substitute for chemistry and uses horror props as decoration on
a generic romance. The techniques below are how the integration
is achieved without either softening the horror to fit the
romance or weaponising the horror at the romance's expense.

### The Fear-to-Desire Bridge

Horror tension amplifies romantic tension because the body
cannot reliably distinguish them. The racing heart from fear is
indistinguishable in physical signature from the racing heart of
attraction; adrenaline sharpens desire; pupils dilate, breath
shortens, skin sensitises in both registers. The characters
cannot reliably tell the difference, and neither can the
reader, and the prose holds this ambiguity deliberately. Scenes
that employ this technique layer sensory details that serve
both genres simultaneously: the warmth of a body pressed close
in a dark corridor, the quickened breath that could be panic
or want, the involuntary grip that could be reassurance or
restraint, the smell of fear and the smell of arousal sharing
chemistry the prose can describe in the same sentence. The
technique requires honesty: the bridge is real, but it is also
dangerous. Writers should not pretend the ambiguity is
unproblematic — it is part of what the genre exists to
explore — and the strongest horror romances eventually require
the characters to disambiguate, in clear-headed moments, what
they actually want. The bridge is a starting point, not an
ending; if attraction never resolves into chosen, conscious
want, the romance has not been written.

### The Monstrous Tenderness

The frightening love interest's moments of unexpected
gentleness. The clawed hand that cradles rather than tears. The
predator who guards sleep. The shape that should not have
fingers nevertheless arranging the protagonist's hair from her
face. These moments are powerful precisely because they
contrast with established danger — the reader has been shown
what this entity can do, and now sees what it chooses not to
do. The tenderness must feel involuntary on the monster's
part: surprise at its own capacity for care, the discovery of
a register the entity did not know it possessed. Writers must
earn these beats through prior scenes of genuine menace; if the
monster has not been frightening, its tenderness is sentimental
rather than transcendent. The craft test: cover the dialogue and
read the gesture alone. Does the gesture itself — the specific
movement of the inhuman body — carry the full weight of the
care, or does the prose require dialogue to interpret it? If
the gesture cannot stand alone, the body has not been written
specifically enough.

### The Shared Survival Bond

Trauma-bonding through horror creating genuine intimacy.
Characters who have faced death together share something
civilians cannot understand — a private vocabulary of what they
saw, what they did to survive, what they will never tell anyone
who was not there. This bond must be distinguished from mere
adrenaline addiction (the couple who only feel close when they
are in danger and have nothing to share when the threat
passes). The connection should deepen in quiet moments, not
only during crises: the silent meal after surviving the
attack, the night they cannot sleep apart, the conversation
about what they will do tomorrow that takes the protagonist by
surprise because tomorrow has become a category that exists
again. The strongest horror romances show the couple choosing
each other after the danger passes — once survival is no
longer the question, what remains? The technique requires that
the writer plot at least one substantial post-horror interlude
in which the characters must function in normal life and find
that the bond holds (or, more interestingly, requires
renegotiation). A romance that ends at the moment of survival
has not tested whether the love can outlive the trauma.

### The Body Horror as Vulnerability

Physical transformation revealing emotional truth. The monster's
form changes in response to emotional states — the wings that
emerge under stress, the eyes that go dark when threatened, the
voice that drops into a register the human ear cannot quite
process. The human protagonist's body bears the marks of their
encounters: the scar that will not fully heal, the night sweat
that returns, the hand that no longer closes the way it used
to, the particular quality of attention that survival has
trained into them. The physical and the emotional are
inseparable in this genre — every wound is also a confession,
every transformation also a self-disclosure. The technique
works best when transformation is gradual, allowing the reader
to track emotional shifts through physical ones (the partner's
form less monstrous in safety, more so in fear). It also works
when the body horror is mutual: the human partner changes too,
across the book, in ways the reader and the partner can both
register. The trap to avoid: body horror used as titillation
without emotional content, or as climactic shock without the
emotional preparation that would make it land.

### The Dark Shelter

The most dangerous entity becoming the only source of safety.
When the world is populated with horrors — other monsters, the
authorities, the cult, the fellow human beings the protagonist
once trusted — the monster who chooses to protect rather than
consume becomes the safest harbour available. This paradox
drives the romance: safety found in the most unlikely place,
where the protagonist's instinct says flee but the protagonist's
calculation says stay. The tension lies in the knowledge that
the shelter could become the threat at any moment, and the
protagonist's continuing decision to stay regardless. The
technique requires that the alternative dangers be real and
named: the dark shelter is the genre's "lesser evil" structure,
and the lesser evil only works if the greater evil is on the
page. A monster-protector with no external threat to
contextualise the choice reads as relationship apologia; a
monster-protector framed against specific, equally-credible
external dangers reads as the choice the protagonist had to
make.

### The Horror Logic Rules

Horror romance inherits horror's structural discipline: the
monster must obey rules, the protagonist must learn them, and
the climax must turn on the rules being correctly applied. The
genre's particular twist is that the rules govern intimacy as
well as threat — what protects from the supernatural also
governs how the lovers can touch, when the bond can be
consummated, what cost the protagonist pays for choosing love.
The vampire who cannot enter without invitation makes
invitation a romantic act; the entity bound by the iron in the
threshold makes crossing it a romantic decision. Establish the
rules early (typically by chapter four, no later than the
midpoint), and ensure they apply equally to threat and
intimacy. Test: at the climax, is the resolution determined by
the rules the book has been teaching the reader, or by an
exception the writer invents in the moment? Horror romance
that breaks its own rules at the climax breaks its contract
with both genres. The discipline is what makes the love feel
earned: when the protagonist chooses the monster despite
knowing exactly what the monster is, the choice has weight the
soft-rule version cannot match.

### Horror Romance AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "love and terror made strange bedfellows" | Show the specific moment where both emotions collide in the same body and the same beat |
| "the monster was also the lover" | Show the specific dual nature through one scene where both registers are simultaneously present |
| "attraction to the thing that could destroy her" | Show the specific draw (what the monster does, says, or is that the protagonist cannot look away from) and the specific danger (what the monster could do that she has just witnessed) |
| "darkness made their love sweeter" | Show the specific contrast — the named horror followed by the named tenderness — without authorial comparison |
| "she loved what she should have feared" | Show the specific moment of choosing, with the protagonist clear-eyed about both the love and the should-have-been-fear |
| "the horror of loving a monster" | Show the specific sacrifice or compromise the love has cost — what the protagonist has given up, who has been lost, what cannot be undone |
| "beauty in the grotesque" | Show the specific beautiful detail in the frightening context — the precise visual that holds both registers |
| "their bond survived the nightmare" | Show the specific test the bond underwent and the specific behaviour that proved its survival |
| "passion burned even in the darkness" | Show the specific intimate moment amid horror, with the horror present in the scene's sensory grammar |
| "the line between pleasure and pain" | Show the specific sensation, located, named, and chosen |
| "his predatory eyes tracked her every move" | Show the specific tracking behaviour and her specific awareness of being seen |
| "she was drawn to the danger" | Show what specifically draws her — name the trait, the action, the moment that hooks her — without "danger" doing all the work |
| "the monster within him stirred" | Show the specific physical sign — temperature, scent, vocal change, the involuntary movement — and who notices |
| "an alpha predator's instincts" | Replace with specific behavioural detail; "predator" and "alpha" together do nothing the reader cannot fill in with cliche |
| "the safe word was their only protection" | Stage the safe-word as scene if you use it; declared but un-staged power-dynamic devices read as decoration |
| "she had never felt so alive" | Show what specifically signals the aliveness — the senses heightened, the appetite returned, the attention narrowed |
| "their love was forbidden by his very nature" | Show the specific prohibition (the rule, the consequence already paid by another, the threshold neither has crossed yet) |
| "the bite was both wound and kiss" | Pick the register the specific moment requires; both-at-once is the genre's most-collapsed line |

### Romance Masterclass — Horror-Romance Calibration

The romance master file (romance.md) holds the canonical
romance frameworks: Heat Level Calibration, the 7-Element
Chemistry Scene Construction, the 6 Romance Character
Archetypes with character-build tests, Obstacle Layering
Quantitative, Light and Shade Heart-Monitor Rule, the
Differentiation Imperative, Hope-as-Resolution Calibration,
and Series Architecture. All apply directly to horror-
romance, calibrated below to the genre's specific
desire-and-danger register.

**7-Element Chemistry Scene — Horror-Romance calibration:**

- **Element 1 (Setup):** mortal danger establishes the
  stakes; the horror atmosphere is operational. Establish
  the specific threat each lead faces in this moment —
  the entity, the curse, the predator, the thing in the
  walls — and the proximity of mortality in this scene.
- **Element 2 (Approach):** often during shared survival,
  shared exposure to horror, or shared response to threat.
  The proximity-pretext is frequently the threat itself
  (hiding together, fleeing together, fighting together,
  the one moment of safety between threats).
- **Element 3 (Banter Beat):** gallows humour; survival-
  coded register. The dialogue often carries embedded
  threat-acknowledgment ("if we live through this, I'm
  going to") and reveals character through how each lead
  copes with proximity to death.
- **Element 4 (Awareness Spike):** typically arrives
  during shared survival or shared exposure — the moment
  one lead realises they would die for the other, the
  moment one realises the other has been protecting them,
  the moment shared trauma becomes shared knowledge. The
  Spike is often violent or near-violent in its
  emotional pivot.
- **Element 5 (Pull-Back):** the load-bearing pull-back
  is carried by legitimate fear of what the other carries
  — the contagion, the curse, the demonic mark, the
  capacity to harm. The leads cannot act because to act
  is to consent to the danger, and the genre's tension
  lives in the gap between desire and that danger.
- **Element 6 (Aftermath):** the horror's residue on
  both characters — the visible mark, the haunted gaze,
  the damaged body, the changed sensitivity. The horror
  has cost something in this scene that carries forward.
- **Element 7 (Hook):** the next horror beat, near-
  survival moment, or escalation of the threat. The Hook
  in horror-romance is the next confrontation that the
  leads cannot avoid.

**6 Character Archetypes — Horror-Romance calibration:**

- **The Wounded Lead** is scarred by survival, possesses
  or carries dangerous knowledge, or has been marked by
  the horror in a way that creates legitimate threat to
  others. The wound is often supernatural-physical (a
  curse-mark, a partial transformation, a contagion
  carried) layered with psychological survival-scarring.
- **The Opposite Lead** configurations: the one who
  recognises the danger and chooses to stay (the most
  common horror-romance pairing); the one who IS the
  danger but is held by genuine connection (vampire,
  monster-with-sentience, possessed lead); the survivor
  with parallel scarring. The choice to stay is the
  genre's load-bearing character moment.
- **The External Antagonist Force** is the horror itself
  — the entity, the curse, the predator, the institution
  that summons or protects the horror, the cult, the
  haunted location.
- **The Found Family** in horror-romance is often
  fragile or broken — small (one or two trusted others),
  scarred (other survivors), or temporary (the hunting
  party that fragments).

**Obstacle Architecture — Horror-Romance dominant obstacles:**

The Obstacle Layering Quantitative rules apply. For
horror-romance, the dominant obstacle types are:

1. **Literal mortality** (one or both leads in
   immediate danger of death; the threat is real and
   active)
2. **Supernatural threat** (the entity, the possession,
   the curse, the haunting that will not stop)
3. **Power that could destroy** (one or both leads
   carry capacity to harm the other; consent under that
   condition is the genre's central craft challenge)
4. **The horror itself** (entity-with-agenda, curse-
   structure, possession-mechanism — operating as
   external antagonist)
5. **Trust under pressure** (what each lead carries
   that could destroy the other; trust as load-bearing
   stake)

**Differentiation Imperative — Horror-Romance specific axes:**

- Specific horror register (cosmic, body, psychological,
  possession, slasher-adjacent, monster-romance, ghost-
  romance)
- Specific source of threat (named entity, named
  location, named curse, named mechanism)
- Specific tension architecture between desire and
  danger (the line where attraction becomes peril)

**Ending Calibration — Horror-Romance patterns:**

Horror-romance permits a wider ending range than most
romance subgenres. HEA is possible but typically costs
more than other subgenres (the horror defeated, but at
named price — scarring, loss, ongoing vigilance). HFN
with continued horror residue is very common (the threat
managed but not eliminated; the leads together but
forever altered). The Hopeful ending is more permitted
here than in most romance subgenres — the horror cannot
always be fully defeated, and the genre permits the
relationship to continue or end with hope rather than
demanding conventional resolution. Where the manuscript
delivers Hopeful, it must satisfy romance.md's three
requirements (earned, specific, resonant).

## Genre-Specific Revision Rules

Six revision passes specific to horror romance, each with a
single question, run cover-to-cover before the next begins.
Horror romance has the genre family's most ethically charged
revision question — does the manuscript handle desire-under-
threat with the seriousness the form requires? — and the pass
on consent runs separately from the structural and character
passes precisely because it cannot be carried alongside them.
The six passes below are ordered to expose structural failures
first, character failures next, and ethical failures last,
when the rest of the book is stable enough to hold the
question.

### Pass 1: Horror-Romance Balance Audit

Map horror content and romantic content across all chapters in
a single chart, marking each chapter's primary register
(horror / romance / both-active). Neither genre should
disappear for more than one chapter; both should be present in
nearly every chapter. Verify that horror scenes advance the
romance (revealing something about the lovers, deepening or
threatening their bond) and romantic scenes maintain
atmospheric dread (the awareness that intimacy is occurring in
a world that contains the threat). The two genres must be
woven, not alternated. Flag any chapter that reads as pure
horror without the lovers' relationship registering, or as
pure romance without the horror's continuing pressure. The
braided structure is the genre; a chapter that reads as
straight horror with a romantic subplot, or straight romance
with horror dressing, has not been written for this hybrid.

### Pass 2: Fear Escalation Consistency

Chart horror intensity across the manuscript. Does it escalate
appropriately, or does it plateau in the middle (the genre's
characteristic structural failure: the horror writer reaches
peak menace too early and loses the curve)? Check that threats
remain credible throughout — horror that becomes routine loses
its power, and a reader who has stopped flinching has stopped
reading the genre. Ensure the most terrifying moments coincide
with the most emotionally vulnerable romantic beats; the
genre's pleasure peaks when fear and intimacy are at maximum
simultaneously. Resist the temptation to soften scares for the
sake of comfort: a horror romance that pulls its punches in
the third act because the reader has come to like the monster
has betrayed both genres. Test: would a horror reader who came
only for the horror feel the curve has been honoured? Would
they feel the menace was real, or that it was always going to
be defused by love? The latter is the failure mode.

### Pass 3: Monster / Love Interest Characterisation

Review the non-human or monstrous love interest as a character
independent of the romance. Is the monstrousness genuine and
unsettling, or has it been softened into cosmetic threat
(black eyes that mean nothing, fangs that never break skin,
appetites that conveniently lapse around the protagonist)?
Does the character have desires, fears, and motivations beyond
the romance — a history before the protagonist arrived, a
relationship to their own monstrousness that does not depend
on the human partner's response, a stake in events that would
exist if the romance did not? The monster must be a fully
realised character, not a human in a monster suit and not a
projection screen for the protagonist's desires. Check that
alien or horrifying qualities are consistently portrayed and
not conveniently forgotten during intimate scenes — if the
entity has claws, the claws are present in every embrace; if
the body temperature is wrong, the wrongness registers. Test:
can the writer name three things the monster wants that have
nothing to do with the human protagonist? If not, the monster
is a romantic instrument rather than a person.

### Pass 4: Consent in Horror Context Check

Examine every intimate scene for consent clarity. Horror
contexts create power imbalances (human / immortal; prey /
predator; one being who can kill the other with a thought) that
the genre must handle with care, not flatten with romance
convention. Ensure the protagonist has genuine agency even when
facing supernatural or overwhelming forces — agency means
informed choice with available alternatives, not capitulation
to inevitability. Fear should not substitute for consent: a
scene in which the protagonist agrees because the alternative
is death, or because the supernatural compulsion has overridden
their choice, is not a scene of romantic intimacy and the
prose must not present it as one. Where power dynamics are
inherently unequal, the text must demonstrate the protagonist's
autonomous choice in conditions the reader can recognise as
genuine — moments away from danger, alternatives genuinely
available, the option of refusal genuinely safe to exercise.
The strongest horror romances build in scenes specifically for
this purpose: the protagonist alone, the choice made
deliberately, the conditions structured so the choice is
real. Flag every intimate scene where the consent could be
read as compelled by horror rather than chosen despite it.

### Pass 5: Body and Transformation Specificity

Read the manuscript for the specific physicality of the
monstrous body. Is it consistent — the same in chapter twenty-
five as it was in chapter five — or has the body softened by
the third act because the writer wanted to write conventional
intimate scenes? The genre's contract requires that the
inhuman remain inhuman through the love story; convenient
human-passing in the climactic scenes voids the work the
monstrousness was doing. Track every transformation event:
what triggers it, how it manifests, what it costs, what
remains afterward. Check that intimate scenes engage with the
body as it actually is — the partner who has wings does not
suddenly not have them in bed; the entity whose touch causes
frostbite does not warm by authorial fiat in the moment of
sex. Where the body changes during intimacy (transforms more
human, transforms more monstrous), the change must be
consistent with the rules established earlier. Flag any scene
where the body becomes whatever the writer needs in this
moment.

### Pass 6: The Ethical Posture Audit

Horror romance has a particular ethical exposure: the genre can,
if handled carelessly, naturalise possessiveness as devotion,
violence as desire, abduction as fated love, the disappearance
of agency as the recognition of soulmate-hood. The genre's
finest practitioners handle this by being specific about what
they are doing and what they are not — staging the
problematic dynamics consciously, naming the protagonist's
discomfort, allowing the protagonist to push back, building in
moments where the relationship's troubling features are
recognised within the text rather than smoothed over. Run a
final pass asking: where the manuscript depicts behaviours
that, in literal life, would constitute coercion or harm, has
the manuscript shown awareness of that fact? Has the
protagonist had the chance to name the wrongness? Has the
monstrous partner been required to reckon with what they have
done, made amends specific to the harm, accepted the
protagonist's right to refuse? The pass is not asking the
manuscript to defang the genre — horror romance's pleasures
include its dangers — it is asking the manuscript to know
what it is doing. The flag is the unnamed problem: the
behaviour the book asks the reader to read as romantic without
acknowledging that, in another register, it would be
recognised as harm. Naming makes the genre's pleasures
defensible; un-naming makes them complicit.

## Names & Patterns to Avoid

### Forbidden Patterns
- **Horror as obstacle to overcome**. The horror should not be something the couple "gets past" to have a normal relationship; the horror is part of their love story
- **The monster tamed by love**. The love interest should not lose their monstrous nature through romance; domestication kills the genre
- **Horror without consequence**. Characters should bear physical and psychological marks from their encounters with horror
- **The helpless victim love interest**. Both characters need agency; horror romance is not rescue fantasy
- **Sanitised monstrousness**. If the monster is never genuinely frightening, the horror half of the genre contract is broken

### Cliché Setups to Avoid
- The vampire who has sworn off human blood until meeting the protagonist (without genuine struggle)
- The werewolf whose transformation is merely inconvenient rather than genuinely horrifying
- The ghost who is conventionally attractive and barely ghostly
- The "chosen one" whose specialness protects them from all horror
- The dark entity who immediately recognises the protagonist as their "mate" without earning the connection
- The haunted house that produces jump scares but no lasting psychological impact

### Naming Considerations
- Monster characters benefit from names that feel ancient, alien, or slightly uncomfortable in the mouth
- Human protagonists should have grounded, ordinary names that contrast with the extraordinary circumstances
- Avoid naming conventions that undercut the horror (cute diminutives for terrifying entities)
- Place names should carry atmosphere. the setting's name is the reader's first encounter with dread

## Comp Titles

Horror-romance's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Wuthering Heights* — Emily Brontë (1847): obsessive love and gothic dread; the genre's literary ancestor.
- *Phantom of the Opera* — Gaston Leroux (1910): the obsession-romance-with-monster archetype.
- *The Vampire Lestat* — Anne Rice (1985): vampire-horror-romance; sympathetic-monster register.

### Contemporary (current best-in-class)

- *These Violent Delights* — Chloe Gong (2020): horror-adjacent romance with body-horror and political-stakes integration.
- *Slewfoot* — Brom (2021): folk-horror romance; pact-with-the-other architecture.
- *A Dowry of Blood* — S.T. Gibson (2021): vampire-horror-romance reframing of Dracula's brides.
- *The Hacienda* — Isabel Cañas (2022): post-colonial horror-romance; Mexican setting; haunting integrated with marriage plot.
- *Within These Walls of Sorrow* — Amanda Stevens / similar 2023-era horror-romance: the gothic-horror-romance hybrid.
- *Nothing But Blackened Teeth* — Cassandra Khaw (2021): horror-romance-adjacent novella.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Dark, dramatic compositions with film-quality lighting; the dominant style for horror romance that takes itself seriously; conveys both beauty and menace
- **Illustrated**. Gothic-influenced illustration with rich detail; works beautifully for paranormal romance, vampire stories, and fairy-tale-dark horror romance; allows for hauntingly beautiful imagery impossible in photography
- **Graphic**. High-contrast, stylized design with bold visual elements; suits horror romance with a modern edge; stark silhouettes, negative space, and symbolic imagery
- **Vintage**. Gothic Victorian aesthetic with aged textures, ornate borders, and classic horror typography; ideal for period horror romance and stories with literary gothic sensibility

### Genre Cover Aesthetics
- **Styles:** Dark beauty and macabre elegance, gothic romanticism with horror undertones, hauntingly beautiful compositions where something is slightly wrong, dramatic chiaroscuro lighting, figures emerging from or dissolving into darkness, decaying grandeur made sensual
- **Colours:** Blood red and crimson (passion and danger), midnight black and deep charcoal (darkness, the unknown), bone white and ivory (death, vulnerability), poisonous green and absinthe (corruption, supernatural), deep violet and bruised purple (gothic romance, twilight). the palette should feel darkly luxurious, never cheerful
- **Elements:** Roses with thorns or wilting petals, crumbling gothic architecture (mansions, cathedrals, graveyards), beautiful figures with something subtly wrong (too-pale skin, dark eyes, shadowed features), mist and fog, moonlight, thorned vines, ravens or dark birds, candelabras and flickering light, ornate mirrors, blood drops on pale surfaces
- **Typography:** Elegant but unsettling fonts. ornate serifs with sharp terminals, gothic blackletter used sparingly, script fonts that feel beautiful and slightly threatening; title treatment often includes texture (blood, cracks, thorns); metallic foil effects (silver, dark gold) add luxury

### Subgenre Variations
- **Vampire/Paranormal Romance**. More illustrated options; fangs, pale skin, red accents; gothic architecture; moonlit scenes; can lean more romantic with dark edges
- **Haunted House/Ghost Romance**. Architectural focus; crumbling mansions, foggy landscapes, spectral figures; more atmospheric and environmental; cooler colour palette with warm romantic accents
- **Monster Romance**. More graphic and illustrated styles; creature silhouettes; beauty-and-beast visual contrast; bolder, less traditional compositions
- **Dark Gothic Romance**. Full Victorian gothic aesthetic; ornate borders, aged textures, candlelit scenes; vintage typography; the most traditional and literary-feeling covers
- **Body Horror Romance**. More graphic style; unsettling beauty, anatomical motifs made artistic; stark contrast; modern and edgy design

### Market Positioning
Horror romance covers must signal "beautiful darkness". love in the shadow of something terrifying. The cover should be visually striking and darkly gorgeous, not merely scary. At Amazon thumbnail size, the dark palette and gothic/horror elements must be immediately distinguishable from standard dark romance (which lacks genuine horror elements) and from pure horror (which lacks romantic beauty). The key differentiator is aesthetic beauty paired with genuine unease. something lovely that makes you slightly uncomfortable. Foil effects, textured finishes, and rich colour work help horror romance stand out in a crowded market. Series should maintain a consistent dark visual identity.

### Cover Design DON'Ts
- No cheerful, bright, or warm colour palettes. horror romance lives in shadow, moonlight, and firelight, never sunshine
- No cute or whimsical illustrations. this is not cozy paranormal; the horror must feel real and the romance must feel dangerous
- No rom-com aesthetics. playful fonts, pastel colours, and lighthearted design belong to a different genre entirely
- No over-the-top gore, splatter, or graphic body horror on the cover. the aesthetic is beautiful horror, not shock horror; suggest menace, don't display carnage
- No generic dark romance couple without horror signifiers. without gothic architecture, supernatural elements, or macabre imagery, it reads as dark contemporary romance
- No cheap Halloween imagery (cartoon bats, jack-o-lanterns, clip-art skulls). the horror elements must feel elegant and genuinely unsettling
- No bright red blood splatter as the primary design element. blood should be used with restraint and elegance (a single drop, dark pooling, roses the colour of blood)
- No mismatched tone between typography and imagery. if the image is darkly elegant, the font cannot be playful or modern-casual
