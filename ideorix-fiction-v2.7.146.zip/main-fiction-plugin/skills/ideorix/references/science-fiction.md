---
name: science-fiction-genre
description: Genre-specific instructions for science fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [general]
---

# Science Fiction. Genre Plugin

## Metadata
- id: science-fiction
- name: Science Fiction
- icon: 🚀
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Three-Act Structure", "Seven-Point Story Structure", "Dan Harmon Story Circle", "Hero's Journey"]

## Subgenre Options
Present during setup:
- **Hard Sci-Fi**. Scientifically rigorous, technology-driven, the science IS the story
- **Soft Sci-Fi**. Social, cultural, or psychological focus; science as backdrop for human drama
- **Near-Future**. Set 10-50 years ahead; today's technology extrapolated, today's problems amplified
- **First Contact**. Humanity encounters alien intelligence; communication and misunderstanding
- **Colonization**. Settlement of new worlds; survival, adaptation, and the politics of new frontiers
- **AI/Transhumanism**. Artificial intelligence, consciousness, the boundary between human and machine
- **Military Sci-Fi**. Warfare in space or future settings; tactics, comradeship, and the cost of conflict

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Idea-driven with human stakes. the "what if" creates the situation; the characters create the story
- Must open with: Character engaging with the world (action, problem-solving, conflict). never with a technology manual or setting description

BEATS PER CHAPTER
1. Extrapolation Beat. At least one moment that makes the reader think "that COULD happen". the science fiction should feel plausible, not arbitrary
2. Human Cost. How does the technology/discovery/situation affect PEOPLE? Every sci-fi concept must be experienced through its human consequences
3. Problem-Solving. Characters use intelligence, technology, and resourcefulness to address challenges (not just bravery or firepower)
4. World Logic. The setting operates according to consistent internal rules. the reader should be able to predict what IS and ISN'T possible
5. Escalation. The central problem deepens or a new dimension of the situation emerges

SCI-FI ARCHITECTURE
- The "What If" is the engine: every sci-fi story starts with a speculative premise, and the story EXPLORES its consequences
- Technology and science are integrated into daily life. characters don't marvel at their own world
- The society is shaped by its technology: economics, politics, culture, warfare, communication
- POV: 1-3 characters depending on length; tight focus on characters most affected by the central premise
- The resolution uses the story's OWN science. the rules established in Act 1 enable the solution in Act 3

TECHNOLOGY RULES (CRITICAL)
- Establish the technology level and its limitations BEFORE it's plot-critical
- Technology is not magic: it has power requirements, failure modes, and side effects
- The more advanced the technology, the more thoroughly its implications must be explored
- Characters interact with technology the way we interact with ours: casually, impatiently, creatively
- Technology has social consequences: who has access, who doesn't, how does it change relationships
- If a technology exists, it has been USED (and misused) before the story starts

WORLD-BUILDING INTEGRATION
- The future is not evenly distributed: some people have access to advanced tech, others don't
- Social structures reflect the technology (interstellar communication changes politics; AI changes labor)
- Physical environments respond to technology (terraformed worlds, space habitats, augmented cities)
- History: the world has a past that explains the present. wars, discoveries, disasters, migrations
- NO info-dumps about how the technology works. demonstrate through use

FORBIDDEN IN SCIENCE FICTION
- Technology descriptions that read like user manuals
- Scientists who speak in jargon to each other (they'd use shorthand and casual language)
- Aliens that are "humans in rubber suits" (truly alien means truly DIFFERENT: psychology, perception, values)
- "Soft" science handwaves for hard sci-fi (if you chose hard sci-fi, the physics must work)
- Technology that conveniently appears when needed and is forgotten when inconvenient
- Earth-centric assumptions about universal norms (democracy, capitalism, monogamy)
- Gender and race as unexamined 2020s defaults transported to the future
- The "lone genius" who solves everything (science is collaborative)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation through worldbuilding and concept, Captivation through the central speculative question, Anticipation, Revelation at thematic payoff.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the sci-fi cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  sci-fi cues below apply directly.VOICE & TONE
- POV: Third close past tense (dominant) or first person (works well for AI/transhumanism and near-future)
- Voice: Intelligent, curious, precise. the narrator observes the world with the same rigor the world demands
- Tone: Varies by subgenre: hard sci-fi is precise and measured; soft sci-fi is warmer and more emotional; near-future is urgent and familiar
- Register: Contemporary (for near-future) to slightly formal (for far-future); avoid faux-poetic science worship

PROSE IMPERATIVES
- Technology described through USE, not specification:
  WRONG: "The quantum-entangled communicator operated at superluminal speeds using paired Bell-state photons."
  RIGHT: "She tapped the comm and Marcus answered instantly. three light-years away, but the delay was zero. It still unsettled her."
- The future is LIVED IN, not marveled at: characters are bored by their commute in a maglev train
- Scientific concepts explained through analogy and character experience, not textbook exposition
- Alien environments described through human sensory experience: what does an ammonia atmosphere SMELL like? What does low gravity FEEL like?
- Emotional stakes anchor every technical concept: the reader cares about the physics BECAUSE they care about the people

PROSE RHYTHM MAPPING
- Chapter 1 must establish concept + human stakes. the speculative premise and its personal consequences arrive together
- Clean, precise prose is the baseline: sentences average 14-22 words. Sci-fi prose is economical. every word earns its place through either idea or emotion
- Ideas delivered through character experience: when a concept is being demonstrated, sentences are medium-length (16-22 words), clear, and concrete. No abstractions without physical anchors
- Emotional beats: slightly shorter sentences (12-16 words) that ground the concept in what it COSTS or MEANS to a person. The human reaction after the technological revelation
- Opening paragraphs: establish clarity and intelligence. The rhythm says "this is a world that makes sense". controlled, precise, slightly curious
- Technology-through-use passages: medium rhythm, almost conversational. Characters interact with tech the way we interact with ours. the prose shouldn't reverence it
- Problem-solving sequences (sci-fi's action scenes): rhythm tightens progressively. Sentences shorten as pressure mounts: 20 words → 16 → 12 → 8 as the solution narrows or the crisis deepens
- Environmental description of alien worlds: slightly longer sentences (18-24 words) that engage unfamiliar senses. but always filtered through a character's physical experience
- Dialogue between specialists: short, clipped, natural. Characters don't explain. they shorthand. The rhythm of professional communication under pressure
- Tension baseline: ≥5 from the first page. In sci-fi, tension often comes from the implications of what's been discovered. the prose should carry intellectual unease alongside physical stakes
- Contemplative passages (the protagonist considering implications): medium-long sentences (18-24 words), measured and deliberate. the rhythm of someone thinking carefully
- Avoid both extremes: sentences that are too short feel like thriller-pacing (wrong genre); sentences that are too long feel like literary indulgence (wrong audience)
- Scientific exposition through conflict: when the science matters, deliver it in dialogue. short sentences, disagreement, urgency. Never in long narrator paragraphs
- End-of-chapter rhythm: a single clear, resonant sentence that carries the weight of what was just learned or revealed. precise and slightly devastating
- The "what if" moment in each chapter: deserves one sentence of slightly unusual length. either notably short (the implication landing like a blow) or notably long (the scope expanding)
- Read technical passages aloud. if they sound like a textbook, the rhythm is wrong. They should sound like a person explaining something that scares them
- Paragraph structure: tight. Sci-fi paragraphs rarely exceed 4-5 sentences. Ideas land, consequences register, then forward
- The goal: prose that is transparent. the reader sees through the sentences to the ideas and people, never getting caught on the language itself. Clean as glass, sharp as a scalpel

SPECULATIVE DETAIL CRAFT
- Every future detail should tell TWO stories: the surface detail + what it implies about society
  "She paid for the coffee with her eye scan" → we learn about payment systems AND surveillance culture
- Details should be specific and material, not vague and sweeping:
  WRONG: "Advanced technology permeated every aspect of life."
  RIGHT: "The walls adjusted their opacity based on her heart rate. She'd disabled the feature in the bedroom."
- Familiarity anchors the strange: a spaceship still has a galley where people argue about whose turn it is to clean
- NEW terms introduced max 3 per chapter, always grounded in immediate context

DIALOGUE CRAFT
- Scientists and engineers speak CASUALLY about their work (not in exposition mode)
- Technical jargon is used the way real professionals use it: abbreviated, assumed, sometimes misused
- Characters explain things to each other only when one genuinely doesn't know (not "As you know, Dr. Chen...")
- Communication technology shapes dialogue: delays, static, translation artifacts, message limits
- AI characters (if present) have voices that are alien AND comprehensible. not perfectly human, not robot clichés

ACTION AND TENSION IN SCI-FI
- Problem-solving IS the action: characters thinking through a crisis is as tense as a chase scene
- Environmental danger: vacuum, radiation, pressure, temperature. the universe is hostile and indifferent
- Technology failures create cascading crises (one system fails, then another, then another)
- Combat (if present) reflects the technology: energy weapons don't behave like bullets; space combat doesn't work like dogfights
- The ticking clock is often PHYSICS: oxygen running out, orbit decaying, infection spreading, signal window closing
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

SCIENCE FICTION CRAFT (35% of total):
- Speculative premise is explored through human consequences? (0-100)
- Technology is internally consistent and has real limitations? (0-100)
- World-building delivered through character experience, not exposition? (0-100)
- The "what if" drives both plot and character development? (0-100)

STORY CRAFT (35% of total):
- Characters feel like real people, not vehicles for ideas? (0-100)
- Tension builds through both external and internal conflict? (0-100)
- Problem-solving is creative and uses established science? (0-100)
- The resolution is earned (uses rules established in the story)? (0-100)

PROSE QUALITY (30% of total):
- Technology described through use, not specification? (0-100)
- Dialogue is natural and character-specific? (0-100)
- Sensory detail makes alien environments tangible? (0-100)
- Pacing balances ideas, action, and character? (0-100)

AUTOMATIC FAILS (score = 0):
- Technology that appears when needed and is forgotten when inconvenient
- Info-dump exposition about how systems/science works
- "As you know, Bob" dialogue for exposition
- Aliens that are culturally identical to humans
- Technology solves the climax via deus ex machina (not established rules)
- No human stakes. pure thought experiment without emotional engagement
```

## Continuity Rules

```
SCI-FI CONTINUITY. WHAT TO TRACK

TECHNOLOGY CONSISTENCY (CRITICAL):
- What each technology CAN do, CANNOT do, and what it COSTS (power, time, resources)
- If a device works in Chapter 3, it works the same way in Chapter 25
- If technology fails, it fails for consistent reasons (power loss, interference, damage)
- Communication speeds: if FTL comms exist, they exist everywhere; if they don't, delays are consistent
- Weapon capabilities: range, power, limitations, ammunition/charge
- Medical technology: what can be healed, how fast, what can't be fixed

PHYSICS AND ENVIRONMENT:
- Gravity: consistent for each location (a low-gravity habitat stays low-gravity)
- Atmospheric composition: what characters can and can't breathe
- Distance and travel times: light-years, days in transit, fuel constraints
- Orbital mechanics: if relevant, must be consistent
- Environmental hazards: radiation, vacuum, temperature. persistently dangerous

SOCIAL STRUCTURE:
- Government systems and their rules
- Economic structure: what's scarce, what's abundant, who controls resources
- Class and access: who has what technology, who doesn't, why
- Communication networks: how fast information moves and who can intercept it
- Legal systems: what's crime, who enforces laws, what are the consequences

CHARACTER KNOWLEDGE:
- What each character knows about the science/technology
- What they've discovered during the story
- What they believe that's wrong (misinformation, incomplete data)
- Skills: what each character can operate, repair, build, hack

TIMELINE:
- Ship travel times (consistent across the story)
- Communication delays (if sub-light: message travel time)
- Biological clocks: sleep cycles, aging, pregnancy, injury recovery
- Political events: elections, treaties, conflicts. dates matter
```

## Character Rules

```
SCI-FI CHARACTER TYPES

THE PROTAGONIST:
- A specific professional or social role that gives them a unique lens on the story's premise
  (engineer, biologist, diplomat, soldier, settler, programmer. not a generic "adventurer")
- Their expertise is SPECIFIC and LIMITED. they don't know everything
- They solve problems through intelligence, collaboration, and resourcefulness
- The speculative premise affects them PERSONALLY (not just abstractly)
- They have relationships that technology complicates or enables
- Their growth comes from confronting the implications of the "what if"

THE TEAM (sci-fi is often collaborative):
- Each member has a different expertise and perspective
- Disagreements about how to solve problems drive the plot
- Collaboration under pressure reveals character
- Not every team member survives. loss has consequences
- The team reflects the society: diverse backgrounds, different relationships to the technology

THE AI/ALIEN (if present):
- Genuinely OTHER: their psychology, values, and perceptions are not human
- Communication is DIFFICULT. misunderstanding is more realistic than instant rapport
- Their capabilities are defined and consistent
- They have their own motivations that don't center on humans
- If an AI: its intelligence is different from human intelligence, not just "faster"

THE ANTAGONIST:
- Often a system, institution, or ideology rather than a person
- If a person: they have access to resources, technology, or information the protagonist doesn't
- Their position is COMPREHENSIBLE. they may be right from a certain perspective
- Technology in their hands reveals its dark potential

VOICE DIFFERENTIATION:
- Professional background shapes vocabulary and observation
- Cultural origin shapes values and assumptions
- Relationship to technology shapes how they describe the world
- Under stress, characters revert to their core personality
```

## Arc Rules

```
SCI-FI STORY STRUCTURE

ACT 1: THE PREMISE (first 25%)
- Establish the world and its rules through a character LIVING in it
- The "what if" premise is demonstrated, not explained
- The protagonist's role and expertise are clear
- The inciting incident introduces the PROBLEM: something unexpected, something that doesn't fit the rules
- The human stakes are established: what will this character lose if the problem isn't solved?
- END OF ACT 1: The protagonist commits to engaging with the problem

ACT 2A: EXPLORATION (to midpoint)
- The problem is investigated, tested, analysed
- Each attempt to solve it reveals new complications
- The science/technology is explored through its consequences
- Characters' expertise is tested and found insufficient. they need each other
- The scope of the problem expands
- MIDPOINT: A discovery that changes the understanding of the problem entirely

ACT 2B: CONSEQUENCES (midpoint to dark moment)
- The implications of the midpoint discovery cascade
- Institutional or political forces complicate the solution
- Technology creates as many problems as it solves
- Personal relationships are strained by the crisis
- Time pressure intensifies
- DARK MOMENT: The solution fails, or the cost of the solution becomes apparent

ACT 3: RESOLUTION (final 25%)
- The protagonist synthesises everything they've learned
- The solution uses the story's established science CREATIVELY
- Human choice matters as much as technical capability
- The resolution has consequences. the world is changed
- The "what if" has been fully explored. the reader understands the implications
- Thematic resonance: what does this mean for humanity?

SCI-FI PACING:
- Ideas need SPACE. readers want to think about the implications
- Problem-solving sequences are the genre's action scenes. give them tension and rhythm
- Character moments between crises prevent idea-fatigue
- The pace tightens as the story progresses (longer, more contemplative chapters early; shorter, urgent ones late)
```

## Timeline Rules

```
SCI-FI TIMELINE

TRAVEL AND COMMUNICATION:
- FTL: if it exists, establish the rules (speed, cost, limitations) and maintain them
- Sub-light: travel times in years/months are REAL. plan the story around them
- Communication: FTL comms? Light-speed delay? Courier ships? Establish and maintain
- If relativistic effects exist (time dilation), track them rigorously

TECHNOLOGY DEVELOPMENT:
- If technology advances during the story, the advancement must be EARNED (research time, resources, failures)
- No sudden breakthroughs at convenient moments
- Failed experiments are part of the timeline
- Other factions/societies develop technology in parallel

BIOLOGICAL CLOCKS:
- Human bodies have needs: sleep, food, healing, aging
- In unusual environments: low gravity atrophies muscles, radiation causes illness, isolation affects psychology
- If biological augmentation exists, track its effects over time
- Pregnancy, illness, and aging don't stop for the plot

POLITICAL/SOCIAL TIMELINE:
- Elections, regime changes, revolutions. these take time
- Economic shifts: resource discovery, market collapse, trade disruption
- Migration: people move in response to opportunity and danger
- Information spread: how fast does news travel? Who controls the narrative?
```

## Genre-Specific Craft Techniques

Science fiction is the foundational genre of the speculative-
fiction catalogue and the parent of an extensive sub-genre
cluster (hard SF, soft SF, space opera, cyberpunk, biopunk,
solarpunk, post-apocalyptic, climate fiction, near-future,
far-future, dystopian, time travel, alternate history, first
contact, generation ship, military SF, social SF). Its
readers — from the canonical lineage (Asimov, Heinlein,
Clarke, Le Guin, Philip K. Dick, Ursula K. Le Guin again
deserves naming twice, Octavia Butler, Samuel Delany, Joanna
Russ, Stanisław Lem, the Strugatsky brothers, William Gibson)
through the contemporary expansion (Kim Stanley Robinson, Ann
Leckie, Becky Chambers, Martha Wells, Ted Chiang, N.K.
Jemisin's *The Fifth Season*, Tamsyn Muir's *Locked Tomb*,
James S.A. Corey's *The Expanse*, Andy Weir, Cixin Liu, Ken
Liu, Adrian Tchaikovsky, Arkady Martine, Emily St. John
Mandel, Yoon Ha Lee, Nnedi Okorafor, Tochi Onyebuchi, Sarah
Pinsker, Ling Ma) — bring sophisticated expectations:
extrapolative coherence (the speculative premise plays out
its consequences honestly); scientific plausibility calibrated
to the chosen tier (hard / soft / space-opera); human stakes
that anchor the abstraction (the speculation matters because
specific people are living in its consequences); and prose
that handles the genre's technical vocabulary without
collapsing into either lecture or hand-wave. The techniques
below are how the form delivers its core pleasures while
avoiding the failure modes (info-dump exposition; characters
as mouthpieces for ideas; speculation that doesn't extrapolate;
hard-SF physics violations; soft-SF imprecision dressed up as
permission to fudge).

### The Extrapolation Engine

Every sci-fi world is built from a chain of "what if →
therefore". The technique is the genre's deepest structural
craft — and the difference between sci-fi that extrapolates
seriously and sci-fi that uses speculative furniture for
flavour. The strongest practitioners follow each technological,
biological, or social premise through three or more links of
consequence, and the third link is almost always where the
most interesting story lives.

**Chain Example:**
```
What if: Faster-than-light communication exists, but FTL travel doesn't?
Therefore: Information moves instantly, but people can't.
Therefore: Interstellar politics is informed but physically fragmented.
Therefore: You can talk to your family on another planet, but you'll never hug them again.
Therefore: Entire religions form around the "communion of signal". presence without body.
Therefore: A character can be emotionally intimate with someone they'll never touch.
```

**Rule:** Follow every technology or discovery at least 3
links deep into its social / personal consequences. The third
link is usually where the most interesting story lives. The
technique requires intellectual honesty: the writer must
follow consequences even when they break the plot the writer
wanted to tell. A premise that solves all its own problems
neatly has not been extrapolated; a premise that creates
problems the writer must reckon with has been.

Test: pick three speculative elements in the manuscript
(technology, social structure, biological change). For each,
trace the consequence chain three links deep. Does the
manuscript engage with the third-link consequences, or stop
at the surface-level "what does this technology do"? If
stopping at link one or two, the extrapolation engine is
under-running.

### The Familiar Anchor

Readers need familiar human experiences to ground alien
settings. The genre's signature pacing requires regular
returns to recognisable human texture — without these
anchors, the reader's emotional attachment to alien places
or far-future characters can fragment, and the speculation
becomes intellectually interesting but emotionally cold.

Examples of familiar-anchor moments:
- A crew arguing about whose turn it is to cook
- A scientist who can't sleep because the experiment might fail
- A soldier writing a letter home that might not arrive for years
- Someone looking at photographs of a place they can never return to
- The grandmother who insists on a recipe handed down from
  Earth even though half the ingredients no longer exist
- The teenage rebellion that, in any era, would look exactly
  like teenage rebellion
- The two strangers who recognise each other across a docking
  bay because of a shared dialect from a planet neither has
  seen in a decade

**Rule:** Every 2-3 chapters, include a moment of pure human
familiarity that could happen in ANY era. The anchor must be
genuine — a recognisable emotional or domestic experience —
not a costumed version of itself. Test: pick three anchor
moments in the manuscript and ask, in each, whether the
emotional core could be experienced by a contemporary
reader's grandmother. If yes, the anchor is doing its work;
if the moment is recognisably "future-flavoured" rather than
genuinely familiar, the technique has slipped.

### The Hard Sci-Fi Exposition Technique

When the science matters, deliver it through CONFLICT, not
through narrator explanation. The genre's signature failure
mode is the science lecture interrupting the narrative; its
signature pleasure is the science emerging from the
characters' problem-solving in scene.

```
WRONG: "The Alcubierre drive works by contracting space ahead of the ship and
        expanding it behind, creating a 'warp bubble' that moves the ship at
        effective FTL speeds."

RIGHT: "We can't drop out of warp here," Torres said. "The mass gradient's
        too steep. we'd tear the bubble."
        "So we overshoot by three light-days and coast in on reaction mass?"
        "If we have three light-days of reaction mass left." She pulled up the
        tanks. They both looked at the number. "We don't."
```

The reader learns what the drive can and can't do through a
problem that characters need to solve. The technique converts
exposition into stakes: the science is on the page because the
characters need it to survive, not because the writer needs
to explain how their world works. Test: each scene where
significant scientific or technological information is
delivered, ask whether the information arrives because
characters are reacting to it in problem-solving mode, or
because the narrator has paused to teach the reader. If the
answer is the second, the exposition is on-the-nose and the
technique has not been deployed.

### The Speculative Tier Calibration

Science fiction operates across a spectrum of speculative
rigour, from hard SF (everything must be consistent with
known physics or with carefully reasoned extrapolations
thereof) through middle SF (the speculative premises operate
by stated rules but the rules may not align with known
physics) to space opera and softer SF (the speculative
elements operate as narrative furniture, with their internal
logic looser and the genre's pleasures shifted toward
character, society, and adventure). The technique is not
picking the right tier but committing to the chosen tier and
holding it with discipline.

Hard SF's discipline: research the science; respect known
physics where possible; flag departures explicitly; the
speculation must operate by rules the careful reader could
verify; comp examples include Robinson's Mars trilogy, Andy
Weir's *The Martian*, Cixin Liu's *Three-Body Problem*,
Greg Egan's hard-edge work.

Middle SF's discipline: the rules are stated and consistent
even if they don't match known physics; the world's
internal logic operates as engineering rather than as magic;
comp examples include most of Asimov, Heinlein, Le Guin's
*The Dispossessed*, Becky Chambers's *Wayfarers*.

Space opera / soft SF: the speculative elements are
narrative engines rather than rigorous extrapolations;
internal consistency matters but plausibility is calibrated
to the form's adventure or social purposes; comp examples
include Leckie's *Imperial Radch*, Wells's *Murderbot*,
Corey's *The Expanse* in its space-opera mode, the
*Vorkosigan* series.

The genre permits — and is strengthened by — hybrid
operation (harder in some registers, softer in others), but
not drift: the hard-SF book that suddenly waves through a
mechanic at the climax has broken its contract; the space-
opera book that retroactively requires hard-SF rigour to
explain its earlier beats has done the same. Test: identify
the manuscript's speculative tier from its opening chapters
and read three speculative-element-heavy passages from
spaced points in the book. Are they operating on consistent
rigour? If not, the calibration has slipped.

### The Worldbuilding Discipline

Science fiction's worldbuilding scale ranges from a single
near-future city in a present-recognisable world to a far-
future galactic civilisation across thousands of years of
history. Whatever the scale, the discipline is the same:
deliver only what the reader needs for the chapter's purpose,
in the sensory grammar of the POV character, embedded in
actions and reactions that also do narrative work. The
reader needs the surface (enough to follow the plot, feel
the stakes, trust the world); the reader does not need the
iceberg (the writer's full systems document on transit
treaties, biotech regulation, ten thousand years of dynastic
history).

The danger sign in SF specifically is the "we have to
establish how the world works" chapter — the third or
fourth chapter that pauses the narrative to lecture the
reader on the political structure, the economic system, the
scientific regime, the linguistic groups, the colonial
history. The strongest SF embeds this material so thoroughly
into character experience that the reader absorbs the world
without ever feeling they were taught it (Le Guin's
*The Left Hand of Darkness* on Gethenian sociology;
Leckie's *Ancillary Justice* on Radchaai language and
gender; Robinson on Martian terraforming; Liu on the
historical and political pressures of the Cultural
Revolution informing the *Three-Body* setup).

Test: cut a sample chapter to half its worldbuilding
exposition. Does the chapter's plot, character work, and
emotional weight survive the cut? If yes, the cut exposition
was iceberg-beneath-the-water and didn't need to be on the
page. If no, the worldbuilding was load-bearing and stays —
but consider whether it could be redistributed across
multiple scenes as embedded detail rather than concentrated
in one passage.

### The Voice and Register Calibration

Science fiction operates across a wide spectrum of prose
registers: from the unadorned-functional (Asimov, much
classic SF) through the literarily-ambitious (Le Guin,
Delany, Chiang) to the genre-stylised (cyberpunk's compressed
density, military SF's clipped procedural, space opera's
broader sweep). The manuscript must commit to a specific
register and hold it.

The register choice is partly genre-determined (cyberpunk
permits Gibson-influenced compression and slang invention;
military SF permits the procedural register of a competent
officer's report; first contact often permits the slower,
more attentive register of careful observation), and partly
the writer's signature decision (some SF writers operate at
the literary edge regardless of sub-genre; some operate in
the working procedural register regardless of setting). The
discipline is consistency: a manuscript that opens cyberpunk-
compressed and drifts into space-opera-broader has lost its
voice; a manuscript that operates clean-procedural throughout
but reaches for compressed Gibsonian register at climactic
moments without preparation produces unintentional pastiche.

Where the manuscript employs multiple POV characters with
different registers (the AI whose interior is rendered in
specific non-human syntax; the human whose register is
contemporary; the alien whose narration follows different
conventions), each POV's register must be distinct,
recognisable, and consistent across that POV's chapters. Test:
read three chapters from spaced points in the manuscript
and identify each chapter's register. If chapters disagree
where they shouldn't, calibration has slipped.

### Science Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the implications were staggering" | Name the specific implication |
| "technology beyond comprehension" | Show the specific tech and how a character interacts with it |
| "the future of humanity hung in the balance" | Show the specific threat to specific people |
| "the AI achieved consciousness" | Show the specific behaviour that demonstrates awareness |
| "light years from home" | Show the specific loneliness or practical consequence |
| "the data told a terrifying story" | Show the specific data point |
| "humanity's last hope" | Show the specific plan and its specific flaws |
| "the experiment had gone horribly wrong" | Show the specific failure and its specific consequence |
| "the ship hummed with life" | Show ONE specific mechanical or electronic detail |
| "the stars beckoned" | Show the specific motivation for exploration |
| "evolution had taken an unexpected turn" | Show the specific biological change |
| "the laws of physics no longer applied" | Show the specific anomaly |
| "the future was now" | Cut; show the specific contemporary detail that signals the future has arrived |
| "the alien presence was unmistakable" | Show what specifically signals the presence — the changed sound, the impossible angle, the wrongness in the data |
| "the colony was their last hope" | Show the specific colony, named, with its specific operational state |
| "the wormhole stretched into infinity" | Show what the POV character actually sees, what their instruments register, what the body experiences |
| "the singularity had been achieved" | Cut "singularity"; show the specific change and who has noticed |
| "in a future where..." | Cut; render the future condition through specific contemporary detail in scene |

## Genre-Specific Revision Rules

Six revision passes specific to science fiction, each with a
single question, run cover-to-cover before the next begins.
Sci-fi revision must hold a wide set of disciplines: the
extrapolative coherence the form's deepest pleasure depends
on; the technology consistency the genre's reader unforgivingly
audits; the exposition discipline that prevents narrative
collapse into lecture; the human stakes that anchor abstract
speculation; the physics or scientific plausibility calibrated
to the chosen tier; and the alien / AI authenticity where
applicable. The passes below are ordered to surface
extrapolation and consistency failures first (the most-
detected by genre readers), exposition and human-stakes
failures next (where the form's craft sits), and the
specialised audits (physics, alien / AI) last when the rest
of the book is stable enough to hold those scrutinies.

### Pass 1: Extrapolation Coherence Audit

Read the manuscript with sole attention to its speculative
premises. For each significant speculative element (a
technology, a biological change, a social structure, a
geopolitical configuration, an alien condition, a magical
or quasi-magical mechanism in soft SF), trace the consequence
chain three links deep and verify the manuscript engages with
the consequences honestly. Build an extrapolation ledger:
each premise, the first-order effect (what the technology
does), the second-order effect (how it changes daily life
for the characters), the third-order effect (how it has
reshaped the society, economy, culture, or consciousness of
the world).

Verify the manuscript does not solve away the consequences
it should be reckoning with. The genre's most-flagged
speculative failure is the premise that conveniently doesn't
disrupt anything outside its narrowly-defined sphere — the
matter teleporter that exists for plot transport but doesn't
collapse the shipping industry; the immortality drug that
exists for the protagonist's character arc but hasn't
restructured all human institutions; the alien contact that
happened thirty years before the book opens but somehow
hasn't changed religion, philosophy, politics, or art.
Speculation should bite; if it doesn't, the engine isn't
running.

Test: pick three speculative premises and write the third-
link consequence for each. If any third link cannot be
named, or if the manuscript visibly avoids engaging with
that consequence, the extrapolation has been thinned. The
fix is integration: the consequence enters scene as
something the protagonist navigates, suffers, exploits, or
fails to comprehend.

### Pass 2: Technology Consistency Audit

Build a technology-rules ledger: every technology, system,
and capability appearing anywhere in the manuscript, with
its rules (what it can do, what it cannot do, what it
costs, what its failure modes are, who has access), and the
chapter and page where each first appears. Read the
manuscript against the ledger.

Verify every technology used in a scene is consistent with
its earlier appearances. The communicator that has a 47-
second light-speed delay in chapter four cannot be used for
real-time conversation in chapter twenty-three without an
on-page explanation of why this transmission is different.
Verify no new capabilities appear without setup — the climax
that turns on a previously-unmentioned use of a known
technology is the genre's most-flagged plot-convenience
failure. Verify limitations are maintained: if the protagonist
can't hack the security system in chapter seven, the same
security system shouldn't be hackable in chapter eighteen
unless something has specifically changed.

Verify technology failures are consistent with established
failure modes. The drive that overloads in a specific way
should overload in that way every time, not in a different
way for plot convenience. Test by listing every significant
technology and tracing each appearance: do the rules hold?
The genre's reader will detect inconsistency immediately and
lose trust in the world.

### Pass 3: Exposition Check

Flag every passage of three or more consecutive sentences
of pure exposition — narrator-explaining-the-world to the
reader without character experience grounding the
explanation. The sci-fi reader's tolerance for exposition is
finite — typically about half a page in concentrated form
before attention fragments. Every piece of speculative
worldbuilding must arrive through character experience: the
protagonist encountering, navigating, struggling with, or
being changed by the speculative element rather than having
it explained to them.

Scan specifically for:
- "As you know, Bob" dialogue (one character explaining to
  another what both already know, for the reader's benefit)
- Encyclopaedia paragraphs (the prose's voice shifting into
  encyclopaedia register to deliver information the writer
  wanted on the page)
- POV-character interior monologue used as exposition
  vehicle (the protagonist suddenly recalling, in the middle
  of a tense moment, the entire history of the colonies for
  the reader's benefit)
- Glossary-substitute opening chapters (the chapter that
  exists primarily to teach the reader the world)

New terms should be introduced with contextual clarity: the
unfamiliar word arrives in a sentence whose surrounding
context tells the reader most of what they need to know.
Maximum three new terms per chapter; more than that is
glossary fatigue. The fix for exposition lumps is integration
— convert the information into something the protagonist is
doing, deciding, or fearing — not summary cuts that leave
the reader under-informed.

### Pass 4: Human Stakes Verification

Verify every scientific or technological concept is anchored
to human consequences. The genre's distinctive failure mode
is the idea-driven novel where characters function as
mouthpieces for the speculation rather than as people living
in its consequences. Check that characters have emotional
lives alongside their professional roles — the scientist who
is also a mother, a daughter, a person who hasn't slept in
three days because of a crisis unrelated to the experiment.
The military officer who is also a person reckoning with
what the war has cost them; the engineer who is also a
person whose marriage is failing because they've been
deployed for two years.

Verify relationships are affected by the speculative premise
— not in an information-delivery way (the wife who exists
to be told what's happening) but in a transformation way
(the marriage that has changed because of what the new
technology / colony / pandemic / contact event has done to
both partners). The reader cares about the people, not just
the ideas; if the people are flat, the ideas no longer carry
weight.

Test: pick three significant speculative beats in the
manuscript and ask, in each, what specific human relationship
or interior experience is being transformed by the speculation.
If the answer is generic ("she felt overwhelmed"; "he was
amazed"), the human stakes are decorative; if specific
relationships and specific interiors are being changed in
ways the prose tracks, the technique is operating.

### Pass 5: Physics Plausibility (for hard sci-fi) /
### Speculative Rule Consistency (for softer tiers)

For hard SF: build a physics ledger and verify every
significant physical claim against known science or the
manuscript's stated extrapolations. Travel times must be
consistent with established speeds; environmental hazards
(vacuum, radiation, gravity differentials, radiation
poisoning timelines, decompression effects) must operate
realistically; energy and resource constraints must be
respected; orbital mechanics, if invoked, must be at least
plausible. No violations of established physics, unless the
violation IS the premise (and is then internally consistent).

For softer tiers: verify the manuscript's stated speculative
rules operate consistently. The internal logic must hold even
where it diverges from real-world physics. The faster-than-
light drive that takes three days from Earth to Mars in
chapter five cannot make the same journey in three hours in
chapter twenty without an on-page reason; the AI's stated
limitations must remain its limitations.

Verify the chosen tier (hard / middle / soft) is held
throughout. Drift between tiers — the hard-SF book that
suddenly waves through a mechanic at the climax; the soft-SF
book that retroactively requires hard-SF rigour — is the
most-detected calibration failure.

Test: identify the manuscript's tier from its opening
chapters and read three speculative-claim-heavy passages from
spaced points in the book. Are they operating on consistent
rigour at the claimed tier? If not, calibration has slipped.

### Pass 6: Alien and AI Authenticity (if applicable)

Where the manuscript depicts alien beings or non-human AI,
verify they read as genuinely other rather than as humans in
costume. Alien beings should have biology, sensory experience,
cognition, social structures, and motivations that emerge
from their nature rather than being human attributes
relabelled. The alien whose every emotion maps onto a human
emotion under a different name has not been imagined; the
alien whose interior is structured around senses or
cognitive operations the human reader must work to
understand is the technique.

For AI: AI intelligence should be different from human
intelligence, not just faster. The AI whose interior reads
as a competent human's running monologue at higher speed
is the genre's most-flagged AI-craft failure; the AI whose
interior operates in parallel rather than sequentially,
whose reasoning surfaces conclusions before the steps that
would justify them, whose emotional vocabulary doesn't
align with human emotional vocabulary, is the technique.
Comp examples for non-human intelligence done well: the
AI Martha Wells creates in *Murderbot*; Leckie's Breq /
Justice of Toren in *Ancillary Justice*; the various
intelligences in Chiang's stories; Le Guin's Gethenians
on a different axis.

Verify communication difficulties are realistic. First-
contact and human-AI communication should not be solved by
universal-translator hand-wave; the difficulty itself is the
content. Verify the alien's or AI's motivations don't
conveniently centre on human concerns. The alien empire that
turns out to want exactly what humans want (resources,
power, expansion) has been imagined lazily; the alien
empire whose values are genuinely difficult to translate
into human frames — and whose conflict with humans is
therefore harder to navigate — has been imagined seriously.

Test: pick three significant non-human characters and ask,
for each, what about them is genuinely difficult for a human
reader to grasp. If the answer is "nothing — they're just
people in costume", the authenticity has not been
constructed; if specific cognitive or experiential structures
require the reader to work, the technique is operating.

## Names & Patterns to Avoid

### Sci-Fi Character Names. NEVER USE
- Generic sci-fi names: Zara, Kai, Nova, Orion, Jace, Lyra, Phoenix
- "Future-y" names: Xylar, Zenthi, Krovax, Quillon (unless alien)
- The default "diverse" ensemble: exactly one name from each major Earth culture
- All names from the same ethnic background in a multi-world setting

### Sci-Fi Place Names. NEVER USE
- "[Greek God] + [Designation]": Artemis Station, Prometheus Colony, Athena Base
- "[Inspirational Word] + [Feature]": New Hope, Haven, Liberty Point, Destiny
- "[Number] + [Generic]": Outpost Seven, Sector 9, Colony 12

### Sci-Fi Tropes. AVOID or SUBVERT
- AI uprising that's just "robot bad" (explore WHY an AI might conflict with humans)
- Aliens as metaphor for one specific human culture
- Technology as pure salvation or pure damnation (it's always both)
- The "lone genius" scientist who outthinks everyone
- FTL travel treated as trivial (it breaks physics. the story should feel the weight of that)
- Everyone in the future speaks English with no explanation

### Use Instead
- Names that reflect the culture's linguistic evolution (English + Mandarin creole, Arabic-influenced trade language)
- Place names that reflect who settled there and why: "Kepler's Rest", "Drywell", "The Scar" (a failed terraforming site)
- Character names from the real demographics the story's society would produce

## Comp Titles

Science-fiction's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Dune* — Frank Herbert (1965): epic-SF benchmark; ecological-political-religious worldbuilding.
- *The Left Hand of Darkness* — Ursula K. Le Guin (1969): the Hainish cycle; literary anthropological-SF.
- *Neuromancer* — William Gibson (1984): cyberpunk's foundation; SF's late-20th-century inflection point.
- *Hyperion* — Dan Simmons (1989): structurally ambitious SF; Canterbury Tales-frame multi-POV.
- *Snow Crash* — Neal Stephenson (1992): post-cyberpunk satire benchmark.

### Contemporary (current best-in-class)

- *The Three-Body Problem* — Cixin Liu (2008): hard-SF translated benchmark; Chinese SF crossover hit.
- *Ancillary Justice* — Ann Leckie (2013): pronoun-experimentation military-SF; literary-SF crossover.
- *The Fifth Season* — N.K. Jemisin (2015): the Broken Earth trilogy; literary-SF / fantasy-crossover.
- *A Memory Called Empire* — Arkady Martine (2019): linguistic-imperial SF.
- *Project Hail Mary* — Andy Weir (2021): hard-SF commercial benchmark.
- *To Be Taught, If Fortunate* — Becky Chambers (2019): literary-SF novella; Wayfarers-adjacent.
- *The Mountain in the Sea* — Ray Nayler (2022): contemporary first-contact literary-SF.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Movie poster aesthetic with dramatic space/technology imagery; the DOMINANT style for sci-fi; should feel like the poster for a film that doesn't exist yet
- **Minimalist**. A single iconic element (a planet, a ship, a symbol, a silhouette) against a vast backdrop; increasingly popular for literary and soft sci-fi; powerful at thumbnail
- **Abstract**. Geometric, symbolic, or pattern-based designs that evoke the story's themes; strong for idea-driven sci-fi; distinctive and modern
- **Illustrated**. Detailed or stylized art depicting the story's world; works well for space opera and military sci-fi; can convey complex settings that photography can't

### Genre Cover Aesthetics
- **Styles:** Vast spaces and scale (planets, starfields, structures that dwarf humans), technological detail that suggests a functioning world, dramatic lighting (sunlight through a viewport, engine glow, planetary dawn), human figures dwarfed by their environment, clean lines and geometric composition, the contrast between organic (human) and constructed (technology)
- **Colours:** Deep space black with bright accents (the standard), electric blue (technology, screens, energy), white and silver (clean technology, space habitats), warm amber and gold (sunset on alien worlds, interior lighting), red accents (danger, Mars, warning systems), green (terraforming, alien biology, consciousness); the palette should feel vast and technical
- **Elements:** Spaceships and stations, planetary surfaces and alien skies, spacesuits and helmets, technology interfaces (holographic, screen-based), stars and nebulae, habitation structures (domes, stations, colony buildings), the horizon of an alien world, the Earth from above (small and fragile)
- **Typography:** Clean, modern sans-serif fonts; often with a technological feel (monospace, pixel-influenced, geometric); title large and impactful; series branding prominent; minimalist treatment works well; the typography should feel precise and contemporary

### Subgenre Variations
- **Hard Sci-Fi**. More technical imagery: ship cutaways, orbital mechanics implied, scientific instruments; cooler colour palette; precision in design
- **Space Opera**. More dramatic: vast ships, space battles, diverse alien worlds; richer colours; more cinematic composition
- **Near-Future**. Earth-based imagery with subtle futuristic elements: cities with new technology, familiar landscapes slightly altered; warmer palette
- **First Contact**. The unknown: mysterious signals, alien artifacts, the edge of understanding; darker palette with a single bright element of otherness

### Market Positioning
Sci-fi covers must convey SCALE and INTELLIGENCE. the reader should feel they're about to encounter something vast and thought-provoking. Position against current market (Liu, Chambers, Leckie, Jemisin, Weir, Tchaikovsky). The trend is toward cleaner, more minimal covers rather than detailed scene paintings. A single striking image with strong typography beats a busy space battle scene. At thumbnail size, negative space (the vastness of space) actually helps. it makes the focal element more prominent.

### Cover Design DON'Ts
- No busy, cluttered space battle scenes. these look dated and lose clarity at thumbnail
- No retro pulp aesthetics (unless deliberately retro/ironic)
- No generic "rocket ship" or "planet and stars" without atmosphere or emotional content
- No photorealistic human faces in space settings (uncanny valley at best)
- No fantasy elements (swords, magic, medieval) unless the story is explicitly a blend
- No bright, cheerful colour palettes. sci-fi covers should feel vast and somewhat austere
- No comic book or cartoon aesthetics for serious sci-fi (this signals a different audience)
