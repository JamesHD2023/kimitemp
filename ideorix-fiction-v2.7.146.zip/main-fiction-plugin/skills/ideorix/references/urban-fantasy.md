---
name: urban-fantasy-genre
description: Genre-specific instructions for urban fantasy fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [fantasy, contemporary]
---

# Urban Fantasy. Genre Plugin

## Metadata
- id: urban-fantasy
- name: Urban Fantasy
- icon: 🌃
- category: Fiction
- minWords: 2000
- targetWords: "2,000-3,500"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Noir Urban Fantasy**. Hardboiled detective meets supernatural; gritty, morally grey, rain-slicked streets
- **Action Urban Fantasy**. Fast-paced supernatural combat in a modern city; Dresden Files territory
- **Hidden World**. Secret magical society existing alongside the mundane (masquerade/veil)
- **Contemporary Mythic**. Old gods and ancient powers walking modern streets
- **Paranormal Investigation**. Supernatural cases, magical PI or law enforcement
- **Urban Fae**. Faerie courts operating in a modern city, glamour and politics

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,000-3,500 words
- Pacing: Propulsive. urban fantasy reads fast; action and revelation alternate with brief character beats
- Must open with: Action, discovery, or the immediate aftermath of a supernatural event. never with the protagonist's morning routine

BEATS PER CHAPTER
1. Mundane/Magic Collision. At least one moment where the supernatural intersects with ordinary life in a way that creates tension, humour, or unease
2. Investigation or Pursuit. The plot advances through active seeking (chasing leads, confronting suspects, tracking magical signatures)
3. Character Cost. Something is lost, risked, or strained (relationship, health, secret, resource)
4. World-Layer Reveal. The reader learns something new about how the hidden world works in THIS city
5. Escalation Hook. The chapter ends with raised stakes or a new complication

URBAN FANTASY ARCHITECTURE
- Single POV (first person or tight third). urban fantasy is almost always intimate POV
- The city is a CHARACTER. named streets, specific neighborhoods, real-feeling geography
- The supernatural world has RULES that mirror or subvert modern institutions:
  - Magical governance (councils, courts, territories)
  - Supernatural economy (what's traded, what's valued)
  - Information networks (how news travels in the hidden world)
  - Law enforcement equivalents (who polices the supernatural)
- The mundane world operates normally around the magic. day jobs, rent, traffic

MASQUERADE/VEIL RULES (if Hidden World subgenre)
- Define early: who knows, who doesn't, what happens if the secret breaks
- The masquerade creates TENSION. the protagonist must navigate both worlds
- Close calls where mundane people almost see the truth
- The social cost of keeping the secret (lying to loved ones, isolation)
- If the masquerade is institutional, explain WHO enforces it and WHY

MAGIC SYSTEM IN A MODERN CONTEXT
- Magic and technology interact. does magic fry electronics? Enhance them? Ignore them?
- Define the relationship clearly in Act 1 and maintain consistency
- Magical combat in modern settings: property damage, witnesses, police response
- Magical creatures in urban spaces: where they hide, how they feed, who notices
- Modern tools + magic = creative problem-solving (GPS tracking + scrying, etc.)

FORBIDDEN IN URBAN FANTASY
- Magic without cost or consequences
- The city as generic backdrop (must be a SPECIFIC, named, real-feeling city)
- Protagonist who is the most powerful being in the setting (they need to be outmatched)
- Mundane world that conveniently ignores impossible events
- Supernatural creatures that are purely monstrous with no culture or society
- "Special snowflake" protagonist who is unique in five different ways
- Love interests who exist only to be rescued
- Exposition dumps about supernatural history (deliver through character discovery)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (action), Captivation (urban-magic worldbuilding), Anticipation (case stakes).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person present OR first person past tense (genre default); tight third acceptable
- Voice: Sharp, witty, self-aware. urban fantasy protagonists tend toward dry humour as a coping mechanism
- Tone: Modern and grounded, even when describing impossible things. treat the supernatural with the same matter-of-factness as the bus schedule
- Register: Contemporary, natural dialogue. characters speak like real modern people

PROSE IMPERATIVES
- The city must be SPECIFIC: real street names (or convincingly real ones), specific neighborhoods, local businesses, transit systems, weather patterns
- Supernatural elements described through PHYSICAL sensation, not mystical abstraction:
  WRONG: "She sensed a dark presence approaching."
  RIGHT: "The temperature dropped ten degrees. Her fillings ached. Something was coming up the stairs."
- Action scenes in real locations: the fight in the subway car, the chase through the warehouse district, the standoff in the parking garage
- Magic has TEXTURE. what does it smell like, taste like, feel like against the skin?
- Humor as survival mechanism: the protagonist cracks wise BECAUSE the situation is terrifying, not because it's trivial

PROSE RHYTHM MAPPING
- Chapter 1 must establish modern voice + magical intrusion. the rhythm is contemporary, snappy, and alive
- Snappy, contemporary rhythm dominates: 12-18 words per sentence as the baseline. Urban fantasy reads FAST. the prose should feel like the city itself: quick, alert, always moving
- Action sequences: even shorter. 6-12 words. Fragments permitted. The fight happens in bursts. No time to elaborate
- Magic described through SENSATION, not mechanics: when the supernatural intrudes, sentences stay short but become more sensory-dense. The reader FEELS the magic physically
- Opening paragraphs: establish the voice immediately. sharp, modern, slightly self-aware. The rhythm announces: "This is a story told at city speed"
- Dialogue: rapid-fire. Short sentences, quick exchanges, banter that doesn't pause for breath. Characters interrupt each other. Conversations overlap
- The mundane-magic collision moment: rhythm shifts subtly. the normal-paced city sentences suddenly hit something that doesn't fit, and the prose stutters or slows for one beat before accelerating again
- Internal monologue: quick, wry, 10-16 words. The narrator thinks the way they talk. no extended philosophical musing
- World-building through observation: brief, punchy details embedded in action sentences. Never stop the rhythm to describe
- Investigation scenes: medium rhythm (14-18 words), building through accumulated detail. Each sentence adds a piece. Momentum maintained
- Tension baseline: ≥6 from the first page. Urban fantasy opens with energy. something is already wrong, already in motion
- The humor rhythm: set-up in one sentence, payoff in the next. Keep it tight. Jokes that take too long die in this genre
- Post-fight recovery: the only place the rhythm can slow. 16-20 word sentences as the protagonist catches breath. Brief. Then back to pace
- Single-sentence paragraphs are a tool: for emphasis, for humor, for the moment the supernatural makes itself undeniable
- Avoid languorous description. if a sentence stretches past 22 words in urban fantasy, it had better be delivering critical world-building or a devastating emotional beat
- End-of-chapter rhythm: accelerate. The final 2-3 sentences should be the shortest in the chapter. punching the reader forward into the next
- Read action scenes aloud at a fast walk's pace. if you can't keep up, the sentences are too long
- The goal: prose that moves like a cab through traffic. weaving, quick, occasionally braking hard, but always in motion

MUNDANE/MAGIC INTEGRATION
- The best urban fantasy makes the reader believe magic could be hiding in THEIR city
- Anchor every supernatural scene with mundane detail:
  "The demon perched on the fire escape. Below, someone was arguing about a parking spot."
- The protagonist has REAL LIFE problems alongside supernatural ones (rent, family, health)
- Day jobs, commutes, and errands don't stop because a werewolf pack is in town
- Food is specific and local. the protagonist eats at named restaurants, buys groceries at specific shops

DIALOGUE CRAFT
- Modern, natural speech. contractions, slang appropriate to the city/character
- Characters from the supernatural world may speak with anachronistic formality (the fae, ancient vampires, old spirits). this CONTRAST with modern speech is a tool
- Gallows humour in dangerous situations is genre-appropriate and expected
- Information delivered through argument, not lecture: characters disagree about how magic works
- Phone calls, texts, and digital communication are part of the dialogue landscape

ACTION SCENE CRAFT
- Urban fantasy action happens in SPECIFIC locations: the parking structure on 5th Street, the bridge over the river, the abandoned warehouse on the east side
- Collateral damage is REAL: windows shatter, cars get dented, buildings catch fire
- The protagonist takes DAMAGE: broken ribs heal slowly, magical exhaustion is debilitating
- Weapons are specific: a .45 loaded with cold iron rounds, a baseball bat with runes scratched into the handle, bare knuckles and a binding spell
- Post-fight consequences: police attention, property damage bills, injuries that affect the next scene
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

URBAN INTEGRATION (30% of total):
- City feels specific, named, and real? (0-100)
- Mundane life operates around the supernatural convincingly? (0-100)
- Magic has physical texture and sensory detail? (0-100)
- Supernatural rules are consistent within the modern setting? (0-100)

GENRE CRAFT (35% of total):
- Pacing is propulsive with brief character beats? (0-100)
- Voice is sharp, modern, and distinctive? (0-100)
- Magic system has clear costs and rules? (0-100)
- Mundane/magic collision creates genuine tension? (0-100)

PROSE QUALITY (35% of total):
- Show vs tell ratio (0-100)
- Dialogue feels natural and modern? (0-100)
- Action scenes are physical and grounded? (0-100)
- Sensory detail quality (0-100)

AUTOMATIC FAILS (score = 0):
- Generic, unnamed city with no specific geography
- Magic without cost solving critical problems
- Exposition dumps about supernatural history/lore
- Protagonist who is the most powerful being in every scene
- No mundane-life grounding (protagonist has no job, home, relationships outside magic)
- Love interest with no agency or personality beyond attractiveness
- Supernatural creatures with no culture, society, or motivation
```

## Continuity Rules

```
URBAN FANTASY CONTINUITY. WHAT TO TRACK

MAGIC SYSTEM RULES:
- What the protagonist can do, what it costs them, recovery time
- Tech/magic interaction: does magic fry phones? Do wards block WiFi?
- What other magical beings can do. establish before they use it in a critical moment
- Magical objects: where they are, who has them, what they do, what they cost to use
- If the protagonist learns a new ability, what triggered the learning and what's the limitation?

CITY GEOGRAPHY:
- Named streets, neighborhoods, landmarks must stay consistent
- Travel times: how long to get from the protagonist's apartment to the supernatural bar
- The city's supernatural geography: which areas are claimed by which faction
- Time of day matters for traffic, crowds, visibility. a chase at 2 AM is different from rush hour
- If a building is destroyed/damaged in Chapter 5, it's still damaged in Chapter 15

MASQUERADE STATUS (if applicable):
- Who knows about the supernatural world?
- Who almost found out and when?
- What close calls have occurred?
- Is the masquerade weakening across the story? Track the progression

CHARACTER RELATIONSHIPS:
- Mundane relationships: who knows the protagonist's secret? Who's being lied to?
- Supernatural alliances: who owes whom, what debts are outstanding
- Romantic status: where the relationship is at each point (urban fantasy romance builds slowly through banter and shared danger)
- Professional relationships: with contacts, informants, supernatural authorities

PHYSICAL STATE:
- Protagonist injuries carry chapter to chapter. ribs broken in Ch 4 still hurt in Ch 6
- Magical exhaustion: if they depleted themselves, they need recovery time
- Resources: money, weapons, magical supplies. don't replenish without sourcing
- Collateral damage: if a safehouse was compromised, it stays compromised
```

## Character Rules

```
URBAN FANTASY CHARACTER ARCHETYPES

THE PROTAGONIST:
- Has a SPECIFIC magical ability or role. not a grab-bag of powers
- Is outmatched by at least 2-3 beings in the setting (creates tension)
- Has a DAY LIFE: apartment, maybe a job, maybe a cat, definitely bills
- Copes with the supernatural through humor, stubbornness, or both
- Has a TRAGIC ELEMENT in their backstory that connects to the current conflict
- Personal code: lines they won't cross (until the story pushes them to the edge)
- Flawed in ways that create real consequences (too stubborn, too reckless, too isolated)

THE HUMAN ANCHOR:
- At least one significant mundane character who doesn't know (or shouldn't know) about magic
- This character grounds the story in reality and raises the masquerade stakes
- They have their own life, problems, and personality. not just a plot device
- The protagonist's relationship with them is complicated by the secret

THE SUPERNATURAL MENTOR/CONTACT:
- Not a wise sage. flawed, agenda-driven, and potentially unreliable
- Provides information at a cost (favors, debts, obligations)
- Their loyalties are to the supernatural community first, the protagonist second
- They know more than they're telling. information is currency

THE ANTAGONIST:
- Has a COMPREHENSIBLE motivation (territory, survival, revenge, ideology)
- Is more powerful than the protagonist in at least one dimension
- Has their own code and logic. they're not randomly evil
- Connected to the city: they're here for a reason, and they have resources

THE CITY:
- The city itself functions as a character with moods, rhythms, and personality
- Different neighborhoods have different supernatural affiliations
- The city has its own magical history. places of power, old bargains, buried secrets
- Weather, seasons, and time of day affect the supernatural landscape
```

## Arc Rules

```
URBAN FANTASY STORY STRUCTURE

ACT 1: THE CASE (Chapters 1-4 for novella, 1-8 for standard, 1-12 for epic)
- Establish the protagonist's normal: their job, their apartment, their mundane and magical lives
- An INCITING SUPERNATURAL EVENT disrupts the status quo (murder, disappearance, power surge, territory violation)
- The protagonist is drawn in through personal connection, professional obligation, or being in the wrong place
- Introduce the city's supernatural landscape through the protagonist's navigation of it
- Establish the magic system's rules through immediate use (not explanation)
- Plant the first hints that this problem is bigger than it appears
- END OF ACT 1: The protagonist commits to the case/conflict despite personal cost

ACT 2A: INVESTIGATION AND ESCALATION (to midpoint)
- The protagonist works contacts, follows leads, and gets into trouble
- Each step forward reveals the problem is deeper than expected
- Alliances form: reluctant, debt-based, or forced by circumstance
- The mundane world intrudes: the protagonist's day life suffers because of the supernatural crisis
- At least one major action set piece in a specific city location
- MIDPOINT: A revelation that reframes everything. the real threat becomes clear

ACT 2B: THE SQUEEZE (midpoint to dark moment)
- The antagonist responds to the protagonist's investigation (counter-moves, threats, attacks)
- Personal costs escalate: relationships strained, safehouse compromised, ally endangered
- The masquerade is under pressure (if applicable): close calls, suspicious questions
- The protagonist's flaw creates a real setback
- Allies are lost or proven unreliable
- DARK MOMENT: The protagonist loses their leverage, their safety, or an important relationship

ACT 3: THE CONFRONTATION (final 25%)
- The protagonist assembles what they've learned and what they have left
- The solution uses the city itself: locations, people, magical geography
- The final confrontation happens in a location with significance (established earlier)
- Resolution through CLEVERNESS and CHARACTER, not raw power (the protagonist is outmatched, remember)
- Personal cost of victory: something permanent changes (relationship, ability, status in supernatural community)
- The city continues: life goes on, the bus still runs, tomorrow is another day

URBAN FANTASY PACING:
- FAST. Urban fantasy is propulsive. the reader should feel breathless
- Chapters are shorter than epic fantasy (2,000-3,000 words)
- Every chapter ends with a pull: new information, new danger, new question
- Quiet beats are BRIEF. a page of the protagonist bandaging wounds and thinking, then back to it
- The book should be "un-put-downable" by design
```

## Timeline Rules

```
URBAN FANTASY TIMELINE

COMPRESSED TIMELINE:
- Most urban fantasy stories span days to weeks, not months
- Novella: 3-7 days
- Standard: 1-3 weeks
- Epic: 1-2 months maximum (unless the structure demands more)
- The ticking clock creates urgency: a ritual on the solstice, a power vacuum someone will fill, a disease that's spreading

DAY/NIGHT CYCLE (CRITICAL):
- Time of day matters MORE in urban fantasy than most genres
- Supernatural activity often peaks at night. but daytime has its own tensions (hiding in plain sight, mundane obligations conflicting with supernatural crises)
- Track: when the protagonist sleeps (they often don't get enough), when they eat, when the city is busy vs quiet
- A 48-hour stretch without sleep has consequences: impaired judgment, missed details, vulnerability

CITY RHYTHMS:
- Rush hour, business hours, bar closing time. these affect the story
- The supernatural calendar may overlap with the mundane one (full moon, equinox, All Hallows' Eve) or have its own schedule
- Specific dates if given must be consistent
- If it's Tuesday in Chapter 3, track when Wednesday arrives

INJURY AND RECOVERY:
- Mundane injuries heal at realistic rates (broken bones = weeks)
- Magical healing should be defined: how fast, how complete, what it costs
- The protagonist should NOT be fully recovered between fights unless enough time has passed
- Cumulative damage across the story: the protagonist gets more battered as the stakes rise
```

## Genre-Specific Craft Techniques

Urban fantasy is the fantasy-cluster sibling that places
magical elements within recognisable contemporary urban
settings, distinct from fantasy parent (typically secondary-
world) and ya-fantasy (audience-specific) by its central
contract: contemporary city + magical reality operating
beneath / alongside / within mundane infrastructure, with
the form's plot pressure typically generated by the
protagonist navigating both worlds simultaneously. The
cluster includes traditional urban fantasy (Anita Blake-era
register), paranormal investigation, occult-detective work,
contemporary witch fiction, vampire-and-werewolf urban
fiction, fae-in-modern-city register, magical-realism cross
(distinct enough to remain in adjacent register), and the
contemporary diverse-perspective expansion. Comp authors
span the canonical lineage (Charles de Lint's foundational
work in the form, Emma Bull's *War for the Oaks*, Mercedes
Lackey, Jim Butcher's *Dresden Files* — the form's longest-
running commercial property, Kim Harrison's *Hollows*, Patricia
Briggs's *Mercy Thompson*, Ilona Andrews's *Kate Daniels*,
Laurell K. Hamilton's *Anita Blake* — foundational to
genre's commercial success, Charlaine Harris's *Sookie
Stackhouse*, Carrie Vaughn's *Kitty Norville*, Kelley
Armstrong, Kevin Hearne, Benedict Jacka's *Alex Verus*) through
contemporary expansion (Ben Aaronovitch's *Rivers of London*,
Lauren Beukes's *Zoo City*, Genevieve Cogman's *Invisible
Library*, P. Djèlí Clark's Cairo novellas at the historical-
crossover edge, Charlie Jane Anders's *All the Birds in the
Sky*, Daniel José Older's *Bone Street Rumba*, N.K. Jemisin's
*The Killing Moon* duology and *The Great Cities*, Tochi
Onyebuchi, Akwaeke Emezi, Cassandra Khaw at the horror
edge, V.E. Schwab's *Shades of Magic* operating in adjacent
register, Hailey Piper, Cherie Priest's contemporary fantasy
work). The techniques below are how the form delivers its
core pleasures while avoiding the failure modes (generic-
urban setting where the city is interchangeable; magic
operating without consequences for the contemporary world;
voice register that drifts into epic-fantasy formal mode;
mundane characters operating as oblivious props rather than
as real people).

### The City-As-Character System

Every chapter must make the reader feel the CITY:

**The 5 City Senses (rotate at least 3 per chapter):**
- **Sound:** Traffic, sirens, music from a bar, the specific rattle of an elevated train, wind between buildings
- **Smell:** Exhaust, street food, garbage day, rain on hot asphalt, the underground smell of a subway station
- **Texture:** Wet cobblestone, rough brick, the sticky vinyl of a diner booth, cold metal of a fire escape
- **Light:** Neon signs reflecting in puddles, the orange glow of sodium streetlights, the aggressive fluorescence of a 24-hour bodega, dawn through skyscraper canyons
- **Rhythm:** The city's pulse. quiet at 4 AM, frantic at 8 AM, thrumming at midnight on a Friday

### Mundane/Magic Integration Technique

**The Juxtaposition Rule:**
Every supernatural scene must include at least ONE mundane detail that grounds it:
- "The vampire's territory started past the Starbucks on Maple."
- "He drew the summoning circle with chalk from the elementary school supply closet."
- "The werewolf packed its change of clothes in a gym bag from Target."

This contrast IS the genre. The more matter-of-fact the mundane detail, the more real the magic feels.

### First-Person Voice Craft

Urban fantasy first person is DISTINCTIVE:
- The narrator has OPINIONS about everything (the weather, the traffic, the demon)
- Internal monologue is wry, self-deprecating, and occasionally wrong
- The narrator WITHHOLDS information from the reader when it serves tension (but never unfairly)
- Physical sensations are immediate: "My wards flared. My teeth buzzed. That meant something big."
- The narrator talks to themselves under stress: "Great. Wonderful. A troll under the 405 overpass."

### Urban Fantasy AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "magic hidden in plain sight" | Show the specific magical element disguised as mundane |
| "the supernatural underworld" | Name the specific place, faction, or person |
| "she straddled two worlds" | Show the specific conflict between mundane and magical obligations |
| "the wards flickered" | Show the specific magical failure and its physical consequence |
| "ancient creatures walked among us" | Show one creature and how it specifically blends in |
| "the veil between worlds was thinning" | Show the specific bleed-through event |
| "magic and technology clashed" | Show the specific interaction. a spell disrupting a phone, a computer detecting magic |
| "the city had a pulse of its own" | Show the specific magical signature of a real place |
| "her powers were growing beyond her control" | Show the specific incident |
| "a secret society pulling the strings" | Show the specific action and its specific consequence |
| "the fae courts were restless" | Show the specific political action |
| "she could feel the magic in the air" | Cut "magic in the air"; show the specific physical sensation in the specific body part with specific intensity |
| "he was a creature of the night" | Specific attributes operating in specific behaviour, not category-flavour |
| "the bargain was struck" | Show the specific terms exchanged through specific dialogue |
| "her gift had a price" | Show the specific cost paid through specific consequence |
| "the gateway between worlds opened" | Show ONE specific feature of the gateway and what it does to the surrounding contemporary space |
| "magic was older than the city" | Show the specific old-magic feature operating in this specific contemporary moment |
| "she was the chosen one" | Cut the trope-name; show what specifically she has that no one else does and how the specific people who recognise it specifically respond |

### The Genre-Convention Awareness

Urban fantasy has an unusually thick genre history; the
form's contemporary practitioners typically write within a
tradition that includes specific tropes the reader has seen
many times: the mage-detective; the werewolf-pack with
specific social dynamics; the vampire court with specific
political structures; the fae-court with specific
diplomatic complexity; the chosen-one-who-didn't-want-to-
be-chosen; the masquerade (the ordinary world doesn't know
about magic). The form's strongest practice is genre-
convention-aware — using these tropes intentionally,
subverting them deliberately, or refreshing them with
specific particularity that distinguishes this manuscript's
deployment from the dozens of other manuscripts deploying
the same convention.

The technique requires conscious engagement with the form's
inherited material:

- **Trope inventory** — the manuscript should know which
  tropes it's deploying. The lone-wolf protagonist; the
  reluctant-mentor figure; the love-triangle-with-vampire-
  AND-werewolf; the ancient-evil-rising plot; the cop-
  partner-who-doesn't-know-magic-exists; the
  alphabet-soup-government-agency that handles the
  supernatural; the supernatural-hierarchy-with-specific-
  rankings.
- **Trope deployment intentionality** — using a trope is
  fine; using it as default is the failure mode. The
  strongest urban fantasy makes deliberate choices about
  which tropes to honour, which to subvert, which to
  refresh, and which to skip. The manuscript that has the
  reluctant-mentor figure should be able to articulate why
  this specific reluctant-mentor figure justifies the
  trope's reuse.
- **Subversion specificity** — when subverting tropes,
  the subversion should be specific. Generic "the chosen
  one was actually a fraud" subversion is itself now a
  trope; specific deployment of trope-subversion that
  generates specific narrative consequences is the
  technique.
- **Convention-fatigue awareness** — certain tropes have
  exhausted their commercial life through over-deployment.
  The cynical-detective-protagonist with specific cynical
  voice has been run hard; the chosen-one-narrative has
  been run harder; the alphabet-agency has been run
  hardest. The form's strongest current practice either
  brings specific freshness to overworked tropes or
  selects different structural elements.

The technique also extends to genre-convention awareness
about diversity. Urban fantasy's classic register operated
predominantly through a specific demographic profile (white
American urban setting; predominantly white protagonists;
predominantly white-coded supernatural communities);
contemporary practice has substantially diversified, with
specific authors bringing specific cultural traditions to
the form (P. Djèlí Clark's Cairo settings; Daniel José
Older's Brooklyn-Caribbean register; N.K. Jemisin's
specifically-Black-American urban fantasy; Tochi Onyebuchi).
The manuscript's choices about whose city is rendered, whose
magic operates, whose communities are visible should be
deliberate.

Test: identify three significant trope deployments in the
manuscript and ask, in each, whether the deployment is
intentional (the writer knows they're using the trope,
knows what they're doing with it, has chosen to honour /
subvert / refresh it specifically) or default (the trope
is operating as inherited convention without specific
engagement). If default, the genre-convention awareness has
not been deployed.

### The Magic-Politics Architecture

Urban fantasy operates with the form's signature political
weight: the magical communities are not just collections of
individuals but specific political entities with specific
operating logic. Vampire courts have specific hierarchies
with specific resource conflicts; werewolf packs have
specific social structures with specific authority
dynamics; fae courts have specific diplomatic conventions
with specific failure modes; mage councils have specific
governance structures with specific factional disagreements.
The form's strongest practice renders these political
realities with specific operational detail.

The architecture requires:

- **Specific institutional structure** — the supernatural
  community is not amorphous; it has specific governance,
  specific membership rules, specific resource-allocation
  logic, specific conflict-resolution procedures. Generic
  "the vampire court ruled" is the failure mode; specific
  governance structure with specific operating logic is
  the technique.
- **Specific factional disagreement** — political
  communities argue. The vampire court has factions with
  specific competing interests; the werewolf pack has
  internal power dynamics with specific contestation;
  the mage council has specific philosophical
  disagreements with specific institutional consequences.
  Manuscripts where supernatural communities operate as
  monolithic blocks have produced cardboard politics.
- **Specific power dynamics with the mundane world** — the
  supernatural community has a specific relationship to
  contemporary political structures. Are they hidden? Why?
  At what cost? What happens when concealment fails? Do
  they have specific arrangements with specific
  governments? Specific economic involvement in specific
  industries? The form's strongest practice renders this
  relationship specifically.
- **Specific historical baggage** — supernatural
  communities have histories. The vampire family from the
  twelfth century has specific historical baggage; the
  werewolf pack established in the Reconstruction era
  carries specific historical weight; the fae court that
  predates human colonisation operates by specific
  ancient logic. Generic "they had been around for
  centuries" is the failure mode; specific historical
  baggage with specific operating logic is the technique.
- **Specific rules of magic AND politics** — both magic
  and political organisation operate by rules the reader
  can map. Magic that does whatever the plot needs is the
  failure mode; magic with specific limits, costs, and
  prohibitions is the technique. Politics that resolve
  by authorial fiat is the failure mode; politics that
  operate by specific institutional logic is the
  technique.

Test: pick three significant supernatural-political beats
and verify each operates with specific institutional logic.
If institutional dynamics are gestural, the architecture
has not been deployed.

### The Reader-as-Adept Calibration

Urban fantasy's reader is typically genre-experienced.
Many readers have read 50+ urban fantasy novels; they bring
specific expectations and detect specific failures
immediately. The form's strongest practice calibrates to
this experienced reader without becoming inaccessible to
newcomers. The discipline is layered competence: the
manuscript should reward genre-experienced readers with
specific reference, specific subversion, specific
sophistication while remaining navigable for first-time
readers of the form.

The technique requires:

- **Genre-vocabulary fluency** — the form's specific
  vocabulary (warding, summoning, glamours, geas, sigils,
  thresholds, sanctums, masquerade, mundanes / muggles /
  norms) operates without explicit explanation. The
  experienced reader recognises; the new reader absorbs
  through context.
- **Magical-system specificity** — the form's experienced
  reader notices when magic operates without internal
  logic; the form's strongest practice operates with
  specific consistent rules even when the manuscript
  doesn't explicitly articulate them.
- **Specific subgenre register awareness** — urban fantasy's
  subgenres (paranormal investigation, monster-hunter
  procedural, witch fiction, vampire society, werewolf
  pack drama) operate by specific conventions. The
  manuscript should know which subgenre register it's
  operating in and deploy that subgenre's specific
  conventions.
- **Trope-aware self-positioning** — the manuscript's
  protagonist often has specific awareness of the genre's
  conventions, even when those conventions are real in
  their world. The Dresden Files protagonist knows he's a
  wizard with a noir-detective voice; the genre-aware
  metafictional gesture has its own register.

The technique also extends to pacing. Urban fantasy
readers expect propulsive pacing; literary-fantasy register
that operates at slower pace can succeed in the form but
must do so deliberately rather than by default. Generic
literary-fantasy slowness applied to urban-fantasy plot
pressure is the failure mode; sustained propulsion through
the form's signature pacing rhythm is the technique.

Test: identify three moments where the manuscript engages
with genre conventions (deploying / subverting /
refreshing them). Verify each engagement is intentional and
specific. If engagement is default, the calibration has not
been deployed.

## Genre-Specific Revision Rules

Six revision passes specific to urban fantasy, each with a
focused question, run cover-to-cover before the next begins.
Urban fantasy revision must hold the form's signature
contracts: city specificity (the city as named character);
magic system consistency (rules the reader can engage with);
mundane grounding (the contemporary world remaining real);
pacing (propulsive forward drive); voice consistency (the
form's distinctive voice register sustained); and the
genre-convention-awareness + magic-politics audits that
distinguish craft urban fantasy from generic urban-fantasy
deployment. The passes below are ordered to surface city and
magic-consistency failures first (the form's most-felt by
genre readers), mundane-grounding and pacing audits next,
voice and integrative audits last.

### Pass 1: City Specificity Check

Verify the city is named or clearly real-feeling. Generic
"the city" treatment is the failure mode for urban fantasy;
the form requires a specific named place (real or
fictionalised) with specific operating logic. Manuscripts
that operate in interchangeable urban setting have lost the
form's signature relationship to place.

Verify the reader can draw a rough mental map from the text.
The form's strongest practice gives the reader specific
geography — specific neighbourhoods, specific landmarks,
specific transit, specific terrain — that operates
consistently across the manuscript. The protagonist who
goes from the Bronx apartment to the Manhattan office to
the Brooklyn vampire court should travel between specifically-
rendered locations the reader can place in mental space.

Verify specific locations, streets, and landmarks are
referenced. Generic "she walked downtown" is the failure
mode; specific named streets, intersections, businesses,
neighbourhoods, transit lines, landmarks is the technique.
The strongest urban fantasy makes the city's specificity a
character itself, with the reader leaving with a specific
sense of the chosen city's specific texture.

Verify the city has personality beyond backdrop. The
City-As-Character System technique requires that the city
operate with specific personality traits: specific noises,
specific rhythms, specific moods, specific relationships
to its supernatural communities. Generic "the city was
indifferent" is the failure mode; specific city-personality
that operates consistently is the technique.

### Pass 2: Magic System Consistency Check

Verify costs are consistent. The same spell at the same
power level should consistently cost the same: same
exhaustion, same physical consequence, same reagent
consumption, same time-recovery. Build a magic-cost ledger
during revision and verify each significant magical event
operates by the consistent cost.

Verify tech/magic interaction is consistent throughout.
Urban fantasy's distinctive feature is the relationship
between contemporary technology and magical reality. Does
magic disrupt phones? Cause computers to malfunction?
Affect electrical infrastructure? Operate independently of
technology? The relationship should be specific and
consistent across the manuscript. Manuscripts where
technology and magic interact differently in different
scenes have lost the form's signature technical
discipline.

Verify no new abilities appear without setup or learning.
The form's most-flagged failure mode is the climactic
ability that nobody mentioned before chapter twenty-eight.
Where the climax requires a capability not previously
demonstrated, either the capability must be foreshadowed
(the protagonist has reasons to suspect they could do
this) or its introduction must be the climactic surprise
the prose has been preparing.

Verify the protagonist is appropriately limited — not too
powerful. Power-creep urban fantasy is a recurring genre
failure; the protagonist who handles every supernatural
challenge effortlessly has been written as wish-
fulfilment. The strongest urban fantasy maintains specific
limits on the protagonist's capability across the
manuscript, with growth tracked through specific
visible learning rather than through arbitrary power-
boosts.

### Pass 3: Mundane Grounding Check

Verify the protagonist has a life outside the supernatural
crisis. Urban fantasy's distinctive structural pressure is
the protagonist navigating both worlds; the protagonist
who exists only as supernatural-investigator without a
recognisable contemporary life has lost the form's
mundane-grounding. Ordinary obligations — work, family,
finances, relationships, neighbours, pets, the gym, the
laundry — should appear and operate alongside the
supernatural plot.

Verify mundane details are present in supernatural scenes.
The Mundane/Magic Integration Technique requires
juxtaposition of the magical and the ordinary. Generic
supernatural scenes operating in pure-magical register lose
the form's signature texture; specific mundane detail
within supernatural scenes (the Starbucks territory marker;
the Target gym bag; the elementary-school chalk) grounds
the magic.

Verify the mundane world reacts to supernatural events
plausibly. When magic operates publicly, what do ordinary
people do? Do they call 911? Post on social media? Look
away? Rationalise? Each manuscript should establish its
mundane-world response logic and apply it consistently.
Generic "no one noticed" is the failure mode unless the
manuscript has specifically established that no one ever
notices and rendered the mechanism (memory-charms,
rationalisation, deliberate looking-away).

Verify human characters are treated as real people, not
oblivious props. The form's failure mode is the
supernatural cast of characters with mundane characters as
backdrop scenery. The strongest urban fantasy renders the
ordinary characters with the same specific interiority and
agency as the supernatural cast: the protagonist's mundane
co-worker has their own arc; the partner-cop-who-doesn't-
know has specific reasoning processes; the family members
who don't know about magic have specific relationships
that the magic specifically threatens.

### Pass 4: Pacing Audit

Verify every chapter ending is a pull. Urban fantasy's
pacing inheritance includes specific cliffhanger expectations
— the reader closes a chapter and is propelled into the
next. The Cliffhanger Rotation technique from thriller (the
form shares some structural conventions with thriller)
applies here: variety in cliffhanger types, with deliberate
rotation across the manuscript.

Verify quiet beats are brief. Urban fantasy's reader
expects propulsive pacing; quiet chapters or scenes that
extend beyond a page or two of breathing room have
slipped to literary-fantasy register. The form permits
quiet beats but typically constrains them to scene-level
rather than chapter-level.

Verify the plot advances in every chapter. Generic "no
stalling" check: each chapter should add specific new
information, develop specific relationships, or resolve
specific tension. Chapters that operate as pure character
beat or pure scenery have slipped to adjacent register.

Verify the overall pace is propulsive. The form's signature
pacing rhythm is action-rest-action-rest with the action
predominating; manuscripts where rest predominates have
slipped to literary register. Test: chart the pacing
profile of three sections spaced across the manuscript and
verify the action density matches the form's expected
rhythm.

### Pass 5: Voice Consistency Check

Verify the narrator's voice is consistent — wit, self-
awareness, opinions. Urban fantasy's signature first-
person register has specific characteristics: wry self-
awareness, specific opinions, pop-culture reference,
internal monologue that leans toward humour even under
pressure. The First-Person Voice Craft technique provides
the framework. Verify this voice register holds across the
manuscript without slipping into other registers.

Verify the voice stays in-character under stress. The
form's strongest practice maintains the protagonist's
specific voice through the highest-pressure scenes. The
narrator under threat doesn't suddenly shift to formal
literary register; their wit may darken, their self-
awareness may sharpen, but the specific voice persists.

Verify dialogue is modern and natural. Urban fantasy's
dialogue register is contemporary; period-formal or epic-
fantasy register dialogue from contemporary characters is
the failure mode. Even supernatural characters typically
speak in versions of contemporary register (with specific
exceptions where ancient supernatural characters
deliberately maintain archaic registers — but those
choices should be specific and consistent).

Verify no tonal shifts into epic fantasy register unless
warranted. The form's distinctive voice register
specifically excludes epic-fantasy formal mode. The fae-
queen who speaks in elevated register can do so as a
character choice; the protagonist's narration cannot
shift into elevated register without breaking the form's
voice contract. Test: read three first-person passages
spaced across the manuscript and verify each operates in
consistent contemporary register without slippage to
formal-fantasy mode.

### Pass 6: Genre-Convention + Magic-Politics Integration Audit

Run a final integrative pass on the manuscript's genre
self-awareness and political worldbuilding. Two related
sub-audits:

**Genre-convention awareness.** The Genre-Convention
Awareness technique requires that the manuscript engage
intentionally with the form's inherited tropes (mage-
detective; werewolf-pack; vampire-court; fae-court; chosen-
one; cop-partner-who-doesn't-know; alphabet-soup-government-
agency; supernatural-hierarchy-with-specific-rankings).
Audit the manuscript: which tropes does it deploy? Is each
deployment intentional or default? Does the writer have a
specific reason for using this specific trope, or is the
trope operating as inherited convention?

The pass also checks for diversity awareness. Urban fantasy's
classic register operated through a predominantly white-
American demographic; contemporary practice has substantially
diversified. Comp examples for contemporary diverse
practice: P. Djèlí Clark's Cairo register, Daniel José
Older's Brooklyn-Caribbean register, N.K. Jemisin's Black-
American urban fantasy, Tochi Onyebuchi. Manuscripts that
operate within classic-urban-fantasy default
(predominantly white-American urban setting; predominantly
white-coded supernatural communities) have chosen, by
absence, to render the inherited register; the choice
should be deliberate, not default.

**Magic-politics architecture.** The Magic-Politics
Architecture technique requires that supernatural communities
operate with specific institutional structure, specific
factional disagreement, specific power dynamics with the
mundane world, specific historical baggage. Audit the
manuscript's supernatural-political beats: do they operate
with specific institutional logic the reader can map, or
do they resolve by authorial fiat? Generic monolithic
supernatural-community treatment is the failure mode;
specific factional politics with specific operational
logic is the technique.

Test: identify three demographic / political / trope choices
in the manuscript and ask, for each, whether the choice
was deliberate and whether the rendering operates with
depth or with default. If choices are default and
renderings are stereotypical, the inherited-default register
is operating; if choices are deliberate and renderings are
specific, the form's contemporary practice is being
honoured.

## Names & Patterns to Avoid

### Urban Fantasy Character Names. NEVER USE
- Overused UF protagonist names: Dante, Raven, Blade, Drake, Gage, Jace, Zane
- Supernatural cliché names: Lilith, Lucian, Selene, Nero, Wraith
- "Badass" surname cliché: Blackwood, Nightshade, Cross, Graves, Darkholme

### Urban Fantasy Place Names. NEVER USE
- "The [Supernatural Adjective] [Mundane Noun]": The Crimson Lounge, The Shadow Market, The Midnight Café
- Supernatural bars called: "The Afterlife", "Limbo", "The Cauldron", "Pandemonium"
- Use REAL-feeling business names: "McGill's", "The Lamplighter", "Brennan's on 5th", "The 42nd Street Tap"

### Urban Fantasy Tropes. AVOID or SUBVERT
- The protagonist who is a half-vampire, half-werewolf, part-fae, descended from angels (pick ONE thing)
- The love triangle between a vampire and a werewolf
- Secret magical bloodline that makes the protagonist "special"
- The wisecracking protagonist who is never genuinely afraid
- The supernatural community that's a thinly veiled metaphor for one specific real-world minority
- Ancient prophecy about the protagonist specifically

### Use Instead
- Ordinary names for extraordinary characters: Mike, Sarah, Janet, Derek, Carmen
- Specific real-world cultural names that reflect the city's demographics
- Business names that sound like real businesses: owner's name, street address, literal description
- Character whose power comes from training, sacrifice, and cleverness. not birthright

## Comp Titles

Urban-fantasy's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *War for the Oaks* — Emma Bull (1987): the modern urban-fantasy founding text.
- *Storm Front* — Jim Butcher (2000): the Dresden Files; PI-urban-fantasy template.
- *Dead Until Dark* — Charlaine Harris (2001): the Sookie Stackhouse series; rural-Southern urban-fantasy.
- *Moon Called* — Patricia Briggs (2006): the Mercy Thompson series; contemporary urban-fantasy benchmark.

### Contemporary (current best-in-class)

- *Rivers of London* — Ben Aaronovitch (2011): the Peter Grant series; British urban-fantasy procedural.
- *Zoo City* — Lauren Beukes (2010): post-apartheid African urban-fantasy.
- *The City We Became* — N.K. Jemisin (2020): NYC urban-fantasy; cosmic-civic register.
- *Ring Shout* — P. Djèlí Clark (2020): urban-fantasy alt-1922 South.
- *Pet* — Akwaeke Emezi (2019): YA-urban-fantasy with utopia-with-shadow.
- *The Library at Mount Char* — Scott Hawkins (2015): dark-urban-fantasy literary cult-favourite.
- *The Atlas Six* — Olivie Blake (2020): dark-academia-urban-fantasy crossover.

## Cover Design Specifications

### Recommended Visual Styles
- **Cinematic**. Dark cityscapes with supernatural elements (glowing eyes, magical energy, otherworldly light sources); the DOMINANT style for urban fantasy; moody, atmospheric, and immediately genre-recognizable
- **Graphic**. Bold, stylized designs with strong lines and limited colour palette; increasingly popular for urban fantasy series; clean, modern, eye-catching at thumbnail
- **Photorealistic**. A figure (often with back turned) in a city setting with subtle supernatural overlay (a glow, a symbol, unusual eyes); common for the detective/PI end of the genre
- **Minimalist**. A single iconic element (a weapon, a sigil, a city skyline silhouette with something wrong about it) against a dark background; works well for series branding

### Genre Cover Aesthetics
- **Styles:** Dark city skylines with supernatural illumination, lone figure on rain-slicked streets, magical effects overlaid on urban architecture, moody noir-influenced composition, dramatic lighting (neon, magical glow, streetlight), urban textures (brick, concrete, metal) with magical intrusion
- **Colours:** Deep black and charcoal (the city at night), electric blue or purple (magical energy), amber and gold (streetlight, whiskey, firelight), blood red accents (danger, supernatural), silver and moonlight grey, neon accents (green, pink, orange) for modern edge
- **Elements:** City skylines and buildings, weapons (guns, swords, magical implements), magical symbols and effects, leather jackets and urban clothing, rain and wet streets, supernatural creatures in urban settings, magical tattoos or markings, the contrast between modern and ancient
- **Typography:** Bold, modern sans-serif or distressed fonts; often with a supernatural treatment (glowing effect, cracked texture, magical symbols); title must be LARGE and readable at thumbnail; series branding consistent and prominent; urban/gritty feel to lettering

### Subgenre Variations
- **Noir UF**. Stronger noir influence: trenchcoat silhouettes, rain, shadow, muted palette with one accent colour; feels like a detective novel that happens to have magic
- **Action UF**. More dynamic composition: weapons prominent, magical energy effects, sense of motion; brighter supernatural colours against dark background
- **Hidden World**. Dual-layer imagery: normal city with magical world bleeding through (cracks, portals, overlapping realities); visually clever compositions
- **Paranormal Investigation**. More grounded: investigation tools + supernatural elements; badge or gun alongside magical implements; procedural feel

### Market Positioning
Urban fantasy covers must signal "modern, dark, and magical" at thumbnail size. A dark background (city at night) with a bright focal element (magical glow, a figure, a weapon) is the standard formula because it WORKS. Covers should position against current market leaders (Butcher, Ilona Andrews, Gilman, Cornell, McGuire). The cover should make clear this is a MODERN story with supernatural elements. anything that looks like epic fantasy or paranormal romance is a genre mismatch that will attract the wrong readers.

### Cover Design DON'Ts
- No pastoral or countryside imagery. urban fantasy is URBAN; the city is the genre
- No romance-cover poses (embracing couples, shirtless figures). this signals paranormal romance, not urban fantasy
- No medieval elements (castles, chainmail, heraldry) unless the story specifically blends eras
- No cute, whimsical, or cartoon illustrations. urban fantasy is dark and edgy
- No bright, cheerful palettes. the genre is nocturnal and moody
- No overly literal monster depictions (a detailed werewolf portrait). suggestion and atmosphere are stronger
- No dated 2000s-era "leather pants and tribal tattoo" aesthetics. the genre has evolved
