---
name: family-saga-genre
description: Genre-specific instructions for family saga fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [drama]
---

# Family Saga. Genre Plugin

## Metadata
- id: family-saga
- name: Family Saga
- icon: 🌳
- category: Fiction
- minWords: 3000
- targetWords: "3,000-5,000"
- recommendedBeatStructures: ["Three-Act Structure", "Five-Act Structure", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Multi-Generational Epic**. Three or more generations: the arc of a family across decades or centuries, showing how patterns repeat, transform, and persist
- **Contemporary Family Drama**. One generation, one crisis: a family in the present day facing an event that fractures and reveals them (a death, a secret, a reunion)
- **Immigrant/Diaspora Family**. The family story shaped by migration: what was left behind, what was carried, what was built, and what was lost between cultures
- **Dynasty**. Wealth, power, and legacy: a family defined by what they've built and what it costs to maintain; empire and inheritance
- **Matriarchal Saga**. The women's story: mothers and daughters across time, the female line as the spine of family history
- **Secrets-and-Revelations**. A family defined by what it hides: buried truths that surface across decades, reshaping identity and loyalty

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-5,000 words (family sagas need room for multiple characters and timelines)
- Pacing: Generational rhythm. the pace of a family: seasons of closeness and distance, crisis and stability, growth and decline
- Must open with: A gathering or a disruption. the family together (or failing to be) in a moment that sets the story's central question

BEATS PER CHAPTER
1. Family Dynamic Beat. The power structure is felt: who leads, who follows, who rebels, who keeps the peace
2. Generational Echo Beat. A pattern repeats (or breaks): a child does what the parent did; a choice mirrors or defies a predecessor's
3. Secret/Truth Beat. Something hidden makes itself felt: a reaction that doesn't fit, a silence, a lie maintained
4. Individual vs. Family Beat. A character's personal desire conflicts with family expectation or obligation
5. Legacy Beat. What's being passed down (knowingly or unknowingly): values, trauma, property, talent, dysfunction

FAMILY SAGA ARCHITECTURE
- The FAMILY is the protagonist: individual characters serve the larger family story
- PATTERNS repeat across generations: the same mistakes, the same gifts, the same conflicts. the question is whether the pattern can be broken
- SECRETS drive the plot: every family has them; their burial and excavation create the narrative tension
- TIME is a character: decades pass, children become parents become grandparents; the passage of time transforms meaning
- The HOUSE/PLACE anchors the story: a family home, a business, a piece of land. the physical constant across changing generations
- INHERITANCE is both literal and metaphorical: property, trauma, talent, dysfunction, love. all are passed down
- POV: Multiple third person (essential for multi-generational) or alternating first person

THE GENERATIONAL STRUCTURE
- Each generation has its own chapter cluster or section
- Transitions between generations should be THEMATIC (not just chronological): end one generation on a note that the next generation picks up
- The reader should see what characters CAN'T: the pattern they're repeating, the legacy they're inheriting
- By the final generation, the reader has the FULL picture; the characters have only their piece

FORBIDDEN IN FAMILY SAGA
- Every family member being either hero or villain (families are MORE complex than that)
- Secrets that are trivial (if the buried truth isn't genuinely consequential, it's not worth the build-up)
- Generations that feel interchangeable (each era must have its own texture, voice, and social reality)
- The family as either purely dysfunctional or purely loving (most families are both)
- Explaining the pattern explicitly ("She was becoming her mother". show it, don't state it)
- Resolution that "fixes" the family (families don't get fixed; they evolve, adapt, and endure)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Affection (generational bonds), Anticipation (lineage stakes across time), Captivation (era atmosphere).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: Multiple third person (the family saga standard. allows scope and dramatic irony) or alternating first person
- Voice: Should shift with each generation/character. period, class, personality, and age all affect voice
- Tone: Sweeping but intimate. the big canvas of decades AND the small details of a single conversation
- Register: Varies by era and character. a 1940s grandmother speaks differently from her 2020s granddaughter

PROSE IMPERATIVES
- THE LONG VIEW AND THE CLOSE-UP: family sagas oscillate between sweeping passages (decades in a paragraph) and intimate scenes (a single conversation in full)
  - The transition between scales is a key skill: from "The years passed" to "She picked up the phone"
  - Time compression: "Three years later" must land the reader precisely in the new moment
  - Time expansion: the significant conversation, meal, or event rendered in full
- GENERATIONAL VOICE: each era has its own prose texture
  - 1950s sections feel different from 1990s sections: vocabulary, rhythm, cultural reference
  - The historical period affects not just WHAT characters think but HOW they think
  - Technology, social norms, and language evolve across the saga
- THE ECHO: the same image, phrase, or gesture appearing across generations
  - A grandmother's recipe. A way of saying goodbye. A gesture of anger.
  - The echo gains meaning through repetition: by the third appearance, the reader feels the weight of inheritance
  - Subtle, not labelled: the reader should FEEL the echo, not have it pointed out
- DOMESTIC DETAIL AS HISTORY: the family's story is told through its objects, meals, rooms, and rituals
  - What's on the table tells you the decade, the economic status, and the cultural identity
  - Rooms change across generations: a nursery becomes a study becomes an empty room
  - Objects carry meaning: the ring that passes down, the photograph that gets hidden, the recipe that gets lost

PROSE RHYTHM MAPPING
- Ch 1 hook: The family's WORLD must feel instantly specific and lived-in
- Prose rhythm: Multigenerational voice shifts
  - Different prose textures for different eras/characters
  - 1950s sections feel different from 1990s sections in vocabulary and cadence
- Sentence length: Medium-long (18-25 words) carrying the weight of history
  - Sentences that hold multiple generations in a single clause
  - Compressed time in long sentences; expanded moments in short ones
- Sensory detail: Domestic specificity
  - The kitchen, the table, the inheritance. the physical world of family life
  - Objects as carriers of generational meaning
- Dialogue: Voices immediately distinguishable across generations
  - Family shorthand, recycled arguments, inherited phrases
- Tension: ≥4 for Ch 1
- Paragraph rhythm: Generous paragraphs (4-7 sentences) for establishing eras
  - Shorter paragraphs during family conflict and confrontation

DIALOGUE CRAFT
- Family dialogue has HISTORY: characters reference shared experiences, use family shorthand, repeat patterns
- Generational communication gaps: the things a parent can't say to a child (and vice versa)
- Family arguments recycle: the same fight reoccurs across decades with different participants
- The family mythology: stories told and retold, each telling slightly different
- Meals as dialogue scenes: the family table is the genre's primary stage
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

FAMILY SAGA CRAFT (40% of total):
- Generational patterns are visible (repeating, evolving, or breaking)? (0-100)
- Secrets drive narrative tension and are consequential? (0-100)
- The family's place/property anchors the story across time? (0-100)
- Each generation has distinct texture (voice, era, social context)? (0-100)

STORY CRAFT (30% of total):
- The family-as-protagonist works (individual stories serve the whole)? (0-100)
- Time transitions are handled skillfully (compression and expansion)? (0-100)
- The reader sees patterns the characters can't (dramatic irony)? (0-100)
- The ending addresses the family's central question without "fixing" it? (0-100)

PROSE QUALITY (30% of total):
- Voice shifts appropriately between generations/characters? (0-100)
- Echoes (repeated images/phrases) accumulate meaning? (0-100)
- Domestic detail carries historical and emotional weight? (0-100)
- The long view and close-up are balanced effectively? (0-100)

AUTOMATIC FAILS (score = 0):
- Generations feel interchangeable (no distinct era texture)
- Secrets are trivial (not worth the narrative investment)
- The pattern is stated explicitly instead of shown
- Family members are all heroes or all villains
- The saga "resolves" by fixing the family
- Chronological confusion (the reader loses track of who/when)
```

## Continuity Rules

```
FAMILY SAGA CONTINUITY. WHAT TO TRACK

FAMILY TREE:
- Every family member: name, birth year, death year (if applicable), key relationships
- Marriages, divorces, births, deaths. in chronological order
- Who knows whom and what their relationship is at each point in the timeline
- Physical resemblances: "She has her grandmother's eyes" must be consistent

GENERATIONAL PATTERNS:
- The recurring behaviour: which pattern each generation repeats or breaks
- When the pattern was established (the original incident)
- How each generation's version differs from the last
- Who breaks the pattern and what it costs them

SECRET STATE:
- What each secret is, when it was created, and who knows about it at each point
- How the secret has been maintained (who lies, who evades, who genuinely doesn't know)
- When each character learns the truth (if they do)
- The consequences of revelation: immediate and long-term

THE HOUSE/PLACE:
- Physical description: rooms, garden, views. must be consistent
- Changes over time: renovations, decay, additions, losses
- Who occupies which rooms across generations
- The condition of the house as metaphor for the family's state

HISTORICAL CONTEXT:
- What's happening in the wider world during each section (wars, economic events, cultural shifts)
- How history affects the family specifically (not just background, but IMPACT)
- Technology available at each period
- Social norms and expectations of each era

OBJECT TRACKING:
- Significant objects: where they are, who has them, what they mean
- Objects that pass between generations: the inheritance chain
- Objects that are lost, hidden, destroyed, or discovered
- The changing meaning of an object across time
```

## Character Rules

```
FAMILY SAGA CHARACTER TYPES

THE PATRIARCH/MATRIARCH:
- The founding figure whose choices set the family's trajectory
- Their strength is also their flaw: the same quality that built the family damages it
- Their story is told through their descendants as much as through their own actions
- Their legend (the family version) differs from their reality

THE REBEL:
- The family member who refuses to follow the pattern
- Their rebellion has a cost: isolation, disinheritance, family rupture
- They may be vindicated by later generations (or may not)
- Their story asks: can you leave a family without losing yourself?

THE KEEPER:
- The family member who maintains the home, the traditions, the connections
- They know the most: family history, secrets, where the bodies are buried
- Their sacrifice is often invisible: the work of keeping a family together
- They may resent their role (or find meaning in it, or both)

THE OUTSIDER:
- The spouse, adopted child, or newcomer who sees the family from outside
- They provide the reader's perspective: "This isn't normal"
- They may be absorbed by the family, change it, or be rejected
- Their observations reveal what insiders can't see

THE ECHO CHARACTER:
- A character in a later generation who mirrors an earlier one
- They share traits, face similar choices, or repeat patterns
- The reader sees the echo; the character may or may not
- Their story is enriched by the reader's knowledge of their predecessor

VOICE DIFFERENTIATION:
- Each generation speaks in its era's idiom
- Each character within a generation has a personal voice
- The family vocabulary: words, phrases, and stories that belong to THIS family
- Letters, diaries, and documents provide historical voice across decades
```

## Arc Rules

```
FAMILY SAGA STORY STRUCTURE

GENERATION 1: THE FOUNDING (or equivalent first section)
- Establish the patriarch/matriarch and their defining choice
- The family's values, flaws, and patterns are seeded
- The house/place is established as the family's anchor
- The first secret is created (or the first pattern is set)
- END: A crisis that determines the family's trajectory for decades

GENERATION 2: THE INHERITANCE
- The children of the founders navigate their inheritance (literal and metaphorical)
- The pattern repeats: the same flaws, the same strengths, in new form
- The secret is maintained or grows more complex
- A rebel appears: someone who questions the family mythology
- The historical context shifts: war, social change, economic shift
- END: A crisis that echoes the first but produces different results

GENERATION 3: THE RECKONING (or final section)
- The pattern comes to full visibility: the reader sees the whole shape
- The secret surfaces (or the consequences of its burial become undeniable)
- The rebel's path is vindicated, complicated, or shown to have its own costs
- The family must decide: continue the pattern or break it
- The house/place faces its own reckoning: sold, renovated, destroyed, or reclaimed
- END: Not "fixed" but TRANSFORMED. the family goes on, changed by understanding

ALTERNATIVE STRUCTURES:
- REVERSE CHRONOLOGICAL: start with the present, work backward to the origin
- BRAIDED: alternate between generations chapter by chapter
- SINGLE CRISIS: one event (a funeral, a wedding, a sale) with flashbacks across generations
- SEASONAL: a year in the family's life with embedded history

FAMILY SAGA PACING:
- Generational sections have their own internal arc (beginning, middle, end)
- Transitions between generations are MOMENTS: a birth, a death, a departure
- The pace accelerates in the final generation as revelations compound
- The ending is both a conclusion and a continuation: the family goes on
```

## Timeline Rules

```
FAMILY SAGA TIMELINE

MULTI-GENERATIONAL TIMELINE:
- Create a master timeline: every birth, death, marriage, key event, and historical marker
- Each generation spans 25-35 years of active story time
- Track ages precisely: if the grandmother was born in 1935, she's 65 in 2000
- Historical events should be accurate for the period

ERA-SPECIFIC DETAILS:
- Technology available at each point
- Social norms: what was acceptable, what was scandalous, what was invisible
- Economic conditions: prosperity, depression, inflation. how they affect this family
- Cultural context: music, fashion, language, entertainment. era texture

OBJECT TIMELINE:
- When significant objects appear, change hands, or disappear
- The condition of long-held objects (they age, they break, they're repaired)
- Documents: letters, photographs, wills. when they're written and when they're found

SECRET TIMELINE:
- When each secret is created, maintained, threatened, and revealed
- Who knows what at each point in time
- The consequences of revelation: track the ripple effects
```

## Genre-Specific Craft Techniques

Family saga is the multigenerational drama register, extending
the drama framework to longer time scales. The form spans
decades or generations, follows multiple protagonists across
eras, and traces patterns of inheritance, rupture, and
transmission across a family unit. Its readers — from the
canonical lineage (Tolstoy's *Anna Karenina*, Mann's
*Buddenbrooks*, García Márquez's *One Hundred Years of
Solitude*, Tan's *The Joy Luck Club*, Allende's *The House of
the Spirits*, Erdrich's *Love Medicine*, Jhumpa Lahiri's *The
Namesake*) through contemporary expansion (Yaa Gyasi's
*Homegoing*, Min Jin Lee's *Pachinko*, Brit Bennett's *The
Vanishing Half*, Tayari Jones's *An American Marriage*, Ann
Patchett's *Commonwealth*, Maggie O'Farrell's *Hamnet* and
*This Must Be the Place*, Hisham Matar's *The Return*, Ocean
Vuong, Imbolo Mbue, Akwaeke Emezi, Naoise Dolan, Zia Haider
Rahman, Kawai Strong Washburn) — bring expectations:
generational pattern recognition (the reader sees what the
characters often cannot); period-specific texture for each
era (mid-century kitchens are not 2020s kitchens); shifting
POV across generations rendered with each generation's
authentic voice; the family as both subject and structure;
and the form's signature thematic question — what is
inherited, what is rejected, what is transmitted despite
intention. The techniques below are how the form delivers
its core pleasures while avoiding the failure modes
(generations rendered as costume changes rather than
distinct interiorities; patterns asserted rather than
shown; family-saga as long-domestic-novel without the
multi-era structural pressure; sentimentality about
"family" abstracted from specific relational texture).

### The Generational Echo

The same moment, three generations apart. The form's
signature structural craft: a specific scene, gesture, or
configuration recurs across generations with the reader
tracking maintenance, repetition, and breaking across the
family arc. The pattern itself is the form's deepest
character — the family is what it does across time, and the
form's power is in the reader's accumulating recognition.

```
1952: "She stood in the kitchen and thought: I will not
cry in front of my children. She turned to the sink.
The water was very hot. She kept her hands in it anyway."

1988: "She stood in the kitchen and thought: I sound
exactly like my mother. The realisation made her hands
shake. She turned to the sink."

2024: "She stood in the kitchen. She knew the story:
her grandmother at the sink, her mother at the sink.
She did not turn to the sink. She sat down at the table
and cried, and her daughter. seven years old, confused,
brave. brought her a tissue."

Three generations. One kitchen. The pattern: maintained,
repeated, broken. The breaking is the story.
```

The technique requires that the echo be specific. Generic
"the women in this family struggled with their feelings" is
the failure mode; the specific gesture (the sink, the kept
silence, the held breath) recurring across eras with each
generation's specific variation is the technique. The
strongest family saga runs multiple echoes simultaneously:
the kitchen pattern; the inheritance dispute; the leaving
the family home; the marriage that mirrors the parents'
marriage; the silence around the named-but-not-discussed
event. Each echo accumulates significance across the book,
with the reader rewarded for tracking the patterns.

Test: identify the manuscript's primary generational echoes.
For each, can the writer trace at least three iterations
across the book's eras? If yes, the echo is doing structural
work; if any echo has only one or two iterations, it has
been gestured at rather than developed. Verify also that
each iteration adds something — the echo evolves rather
than merely repeating.

### The Object as Chronicle

A single object carries the family's history. The technique
provides a concrete spine for the reader's tracking: a
specific physical thing — ring, watch, photograph, recipe,
house, piece of furniture, journal, language word — appears
across multiple eras with shifting meaning. The object's
presence in different generations becomes the reader's tool
for measuring distance and continuity.

- **1940:** The ring is purchased. a soldier's promise before deployment
- **1962:** The ring is worn daily. a widow's memory
- **1985:** The ring is hidden. a daughter's rejection of tradition
- **2010:** The ring is found. a granddaughter's discovery in a drawer
- **2024:** The ring is worn differently. on a chain, not a finger; honour without repetition

The technique requires that the object's significance evolve
across appearances. Generic "the ring meant a lot to her" is
the failure mode; the specific shift in significance from
era to era — the ring's literal physical state, its
relationship to the wearer's emotional state, its meaning in
the wider family narrative — is what makes the object work
as chronicle. The object should also be specific enough to
be memorable: not "a piece of jewellery" but the specific
ring with specific stones with specific damage from a
specific incident.

The technique extends to multiple chronicling objects
running simultaneously. The strongest family saga (Allende
on the green-bound notebook in *The House of the Spirits*;
Lee on the rice-bowl in *Pachinko*) runs object-chronicles
in parallel, with the reader holding several objects across
the book and tracking each one's evolution. Test: identify
the manuscript's chronicling objects and verify each has at
least three appearances across eras with significance
shifting at each.

### The Absent Character

A family member who isn't there shapes the story through
their absence. The form's distinctive structural pressure:
some of the most important characters in family saga are
never on the page in the present moment, yet their gravity
shapes everything that occurs. The grandfather who died
before the protagonist was born. The aunt who left and
never came back. The child who didn't survive. The sibling
who emigrated. The first wife. The disappeared.

```
No one mentioned Uncle David at Christmas. The seat where
he used to sit had been pushed against the wall in 1998
and had stayed there for twenty-six years, slowly
accumulating newspapers and shopping bags, as if the
family had decided that his place at the table was now
storage. His name came up only in the negatives: "We
don't do it like David did." "That's a David thing to
say." He had become a warning, not a person.
```

The technique requires the absence to be specific and
load-bearing. Generic "we don't talk about Aunt Margaret"
is the failure mode; the specific shape of the absence (the
chair pushed against the wall; the photograph turned face-
down in the album; the name only spoken as a comparison;
the holiday everyone leaves the house for so they don't
have to remember) is the technique. The absent character's
specific gravity — what they would have been; what their
presence would have changed; what their absence has cost —
must be on the page even though the character is not.

The technique often resolves with the absent character
returning, being remembered, being explained, or being
finally acknowledged. The strongest family saga lets the
return — when it occurs at all — carry the cumulative weight
of the prior chapters' absence. Test: identify the absent
characters in the manuscript and verify each has specific
behavioural traces in the present-day chapters (the chair,
the silence, the negative-comparison reference, the holiday
abandoned). If the absent character is merely mentioned in
backstory exposition without ongoing pressure on present
chapters, the technique is decorative.

### The Period Texture Discipline

Family saga moves across eras, and each era must feel
specifically itself rather than as costume on top of generic
domesticity. The 1952 kitchen has specific appliances,
specific food, specific cooking methods, specific gendered
labour patterns, specific economic constraints, specific
broadcast media playing in the background; the 1988 kitchen
is recognisably different in every category; the 2024
kitchen is different again. The form's strongest practitioners
deliver each era as inhabited rather than visited.

The discipline operates on multiple axes:

- **Material culture** — appliances, fabrics, foods, cars,
  household objects, fashion specific to the era. Generic
  "she made dinner" without era-specific texture is the
  failure mode.
- **Linguistic register** — characters in 1952 don't sound
  like characters in 2024. The vocabulary, the idiom, the
  conversational topics, the assumed common reference all
  differ across eras.
- **Social fabric** — what's possible for a woman / a
  worker / a parent / a child differs by era. The 1952
  daughter's options differ from the 1988 daughter's
  options differ from the 2024 daughter's. The form
  honours these differences rather than retrofitting
  contemporary sensibility onto earlier eras.
- **Economic reality** — how money worked, what things cost,
  what jobs existed, what class meant differs by era. The
  1962 widow's economic position is shaped by what was and
  wasn't available to her then.
- **Political context** — wars, civil rights movements,
  technological shifts, policy changes that shaped the era's
  daily life and characters' available choices.

The discipline fails in two directions. **Costume drama
register** (every era is dressed-up generic-domesticity,
distinguished only by superficial detail) loses the form's
deep pleasure. **Anachronistic-sensibility register**
(historical characters somehow share contemporary moral and
emotional vocabulary) loses authenticity for that era.
Verify the manuscript holds each era at appropriate
specificity. Test: pick three scenes from three different
eras and ask whether the era is felt in the prose's texture,
or merely stated by chapter heading.

### The Multi-POV Voice Distinction

When family saga deploys multiple POV characters across
generations, each POV must have a distinguishable voice
specific to that generation, that character, and that era.
The grandmother's POV in 1952 should not sound the same as
the granddaughter's POV in 2024 even when both are
ostensibly the same family-resemblance interior. Voice is
the form's structural identifier of generational shift; if
the voices blur, the saga's distinct-eras contract has been
broken.

The discipline requires:

- **Generation-specific vocabulary** — words available to
  this character in this era; words not yet in common use;
  words this character's age and education would specifically
  use.
- **Generation-specific concerns** — what each protagonist's
  interior is preoccupied with reflects what their era and
  their position made important. The 1952 grandmother
  doesn't worry about the things the 2024 granddaughter
  worries about and vice versa.
- **Generation-specific emotional vocabulary** — therapeutic
  language is a contemporary import; the 1952 grandmother
  experiences emotions in her era's available vocabulary
  (the language of duty, propriety, sin, virtue, sacrifice
  rather than boundaries / triggers / processing).
- **Character-specific signature** within each
  generation's voice — even within the same era, two
  siblings should sound recognisably different. The
  brother's interior shouldn't be interchangeable with the
  sister's.

Test: read three POV passages from three different
characters in the manuscript without attribution. Can the
reader identify which character (and which era) each
passage belongs to from voice alone? If voices blur, the
distinction has not been built.

### The Inheritance Calibration

Family saga's signature thematic question: what is
inherited, what is rejected, what is transmitted despite
intention? The technique requires deliberate work on what
each generation receives from the prior, what they
consciously refuse, and what they unwittingly carry forward
even as they believe themselves free of it. The form's
deepest pleasure is the recognition that the daughter who
swore she would not be like her mother is exactly like her
mother in a way she has not yet seen — and that the
granddaughter, watching, may or may not break the pattern.

The technique calibrates inheritance across multiple axes:

- **Behavioural inheritance** — how characters behave under
  stress; what they do automatically; the gestures and
  routines they have absorbed without choosing.
- **Emotional inheritance** — what they fear, what they
  desire, what they are unable to feel. Often the things
  they are most blind to are the most directly inherited.
- **Material inheritance** — money, property, debts,
  business interests, the literal objects that pass down.
- **Trauma inheritance** — the specific fears, prohibitions,
  hyper-vigilances that pass from a survivor to descendants
  who have no direct experience of the originating event.
- **Wisdom inheritance** — the things that DO transmit well:
  a recipe, a song, a story, a way of seeing, a particular
  capacity for tenderness or steadiness or courage.

The calibration's failure mode: family saga that is
unrelentingly bleak (only trauma transmits) or
unrelentingly warm (only wisdom transmits) loses the
form's signature complexity. The strongest family saga
holds both registers: the daughter inherits her grandmother's
specific cruelty AND her specific generosity; the family
transmits its specific wound AND its specific resilience.

Test: at three points in the manuscript, identify what
specifically a character has inherited from the prior
generation. The list should include both desirable and
undesirable transmissions, both conscious and unconscious
inheritances. If only one register populates, the
calibration has tilted.

### Family Saga AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "generations of secrets" | Show the specific secret passed down or buried |
| "blood is thicker than water. or is it?" | Show the specific family loyalty test |
| "the patriarch/matriarch ruled with an iron fist" | Show the specific control mechanism |
| "family legacy weighed heavily" | Show the specific expectation on the specific heir |
| "the sins of the father" | Show the specific inherited consequence |
| "rifts that spanned decades" | Show the specific original offence and its current echo |
| "the family home held memories" | Show ONE specific room and ONE specific memory |
| "keeping up appearances" | Show the specific gap between public face and private reality |
| "the next generation would do things differently" | Show the specific rebellion |
| "holiday gatherings brought everyone together. and every wound" | Show the specific wound reopened at the specific gathering |
| "the family business was everything" | Show the specific business decision with family consequence |
| "the bonds of family were strong" | Show the specific bond through one specific act |
| "she had inherited her mother's [trait]" | Show the specific trait operating in this character — what they do, not what they are |
| "the family had its share of skeletons" | Name the specific skeleton |
| "history has a way of repeating itself" | Show the specific repetition through specific scene |
| "they were all just trying to survive" | Show ONE family member's specific survival strategy |
| "the past wasn't really past" | Show the specific past element still operating in the present |
| "blood will tell" | Cut; show the specific moment of inherited recognition through specific behaviour |

## Genre-Specific Revision Rules

Six revision passes specific to family saga, each with a single
question, run cover-to-cover before the next begins. Family
saga revision must hold the form's signature contracts:
generational clarity (the reader is never lost in time);
pattern tracking (the echoes accumulating across eras);
secret progression (the things being held back from the
reader and / or the characters); family dynamic (the
power structures and their evolution); continuity (the
multi-era timeline holding together); and inheritance
calibration (what each generation receives, refuses, and
transmits despite intention). The passes below are ordered
to surface clarity and pattern failures first (the form's
most-detected by genre readers), secret and dynamic
failures next, continuity audits after, and the inheritance
calibration last as the integrative final check.

### Pass 1: Generational Clarity Check

Verify the reader is clear about WHEN every chapter takes
place. Family saga's structural challenge is the reader's
multi-era tracking; the form fails when the reader has to
pause and work out which era they're in. The strongest
family saga uses chapter headings or section breaks to
establish era unambiguously, and within each chapter the
prose's specific texture (period material culture, period
language, period technology, period concerns) reinforces the
era without requiring the heading to do the work alone.

Verify the character's age is consistent with the timeline.
Build an age ledger: each character's birth year, current
age in each chapter, age at significant events. A character
who is described as 32 in a 1985 chapter cannot be 36 in a
1986 chapter unless explicit time has passed. Verify era-
specific details are accurate and present. The 1952 kitchen
should contain specific 1952 elements (the radio playing,
the specific brands, the specific food preparation patterns,
the absent dishwasher); generic kitchen detail is the
failure mode.

Test: at three points spaced across the manuscript, can the
reader identify the era from prose detail within the first
page of the chapter, even without the chapter heading? If
the era only becomes clear through explicit dating, the
period texture is decorative; if the period is felt through
specific detail, the technique is operating.

### Pass 2: Pattern Tracking Check

Verify a generational pattern is visible (or being seeded)
in every chapter. The form's deepest structural craft is the
generational echo (see GCRF technique). The revision pass
checks whether the patterns are operating across the full
manuscript or concentrated in a few set-pieces. Build a
pattern ledger: each significant generational pattern, the
chapters and eras in which it appears, the form of each
appearance.

Verify each pattern advances: repeating, evolving, or
breaking. Patterns that simply repeat across eras without
variation are wallpaper; patterns that evolve (the same
tendency manifesting in era-appropriate forms) or break
(the generation that finally refuses the pattern, or the
generation that consciously chooses it) are the technique.
Verify the echo is shown, not stated. The narrator who
pauses to say "the women in this family have always
struggled with their feelings" has broken trust with the
reader; the prose that shows the specific gestures across
generations and lets the reader notice the pattern has
done the form's work.

Test: identify the manuscript's primary patterns and trace
each across all its appearances. Does the pattern evolve or
break by the final generation, or merely repeat? If only
repetition is occurring, the pattern is decorative; if the
pattern is doing structural work, the form's signature
power is operating.

### Pass 3: Secret Progression Check

Verify the family saga's central secret (or secrets) is
present in every chapter, even as subtext. The form's
sustained tension structure depends on the secret's
ongoing pressure: the thing not being said, the topic
deflected from, the person who appears in nobody's
conversation, the absent character whose absence is the
shape the present generations live around. Generic family
saga without a secret-engine is at risk of becoming
multigenerational anecdote; the secret is what gives the
form its structural pull.

Verify the reader has learned something new about the
secret in each chapter, or been given a clue, or been led
to misunderstand it in a productive way. The form rewards
the careful reader: the small detail in chapter four that
recontextualises in chapter twenty; the conversation that
seemed innocent at the time but reads differently after the
revelation. Verify secrecy-maintenance behaviour is visible
— the specific things characters do to keep the secret
buried (the photograph turned face down; the conversation
redirected; the holiday spent away; the family member
specifically not invited). These behaviours register the
secret's pressure even when the secret itself is not on
the page.

Test: identify the manuscript's central secret and trace
its presence across the chapters. Verify each chapter
contains at least one secret-related element (a clue, a
deflection, an absence, a misdirected conversation, a held
glance, an unasked question). If chapters routinely lack
secret-related elements, the secret is decorative rather
than structural.

### Pass 4: Family Dynamic Check

Verify the power structure of the family is felt. Family
saga's dynamic register is multi-axis: financial power,
emotional power, social standing, parental favour, sibling
rivalry, in-law tension, generational deference,
caretaking obligation. Each axis operates in this specific
family in this specific way; the form's strongest examples
make the dynamics visible without explaining them.

Verify at least one relationship advances or strains in
every chapter. Family saga's pacing is interpersonal even
when the surface plot is business / war / migration / loss;
the form's actual movement is the shifting weight of
relationships across the family network. Static
relationships across multiple chapters are the form's
quietest failure — chapters pass and the family is the
same as it was. Each chapter should register a small
shift in at least one relationship, with the shifts
accumulating across the book.

Verify the individual-vs-family tension is present. The
form's signature thematic question — what does the
individual owe the family and what can the individual claim
for themselves — should be operating in nearly every
chapter, manifested in specific decisions and specific
moments where individual and family interests diverge. Test:
identify three significant decisions in the manuscript made
by individuals against family expectation. In each, what
specifically did the family expect, what did the individual
choose, and what did the choice cost both?

### Pass 5: Continuity Check

Build a continuity ledger for the manuscript. Family saga's
multi-era structure makes continuity unusually demanding:
ages, relationships, physical descriptions, locations,
objects, events all need to track consistently across the
book. Verify ages, relationships, and physical descriptions
are consistent. The character who is described as having
red hair in 1952 is not described as blonde in 1965 unless
the prose registers the change.

Verify objects are in the right place at the right time. The
chronicle-objects (rings, watches, photographs, letters,
furniture) move through the family across decades, and the
manuscript must track each object's location and condition
in each era. The ring purchased in 1940, worn 1962-1985,
hidden 1985-2010, found 2010, worn-on-chain 2024 — the
manuscript must hold this trajectory consistently.

Verify the house / setting reflects the correct era and
condition at each appearance. The family home in 1952 is
not the family home in 2024 — the specific changes (the
extension built; the room repurposed; the furniture
replaced; the wallpaper updated; the property's economic
status shifted) should be visible across appearances.
Verify also that historical context is accurate: dates of
events, period economic conditions, era-specific cultural
markers.

Test: pick three continuity claims in the manuscript (a
character's age in a specific year, an object's location in
a specific era, an event's date) and verify each against
the rest of the book. If any contradict, continuity has
slipped and the manuscript needs a continuity pass.

### Pass 6: Inheritance Calibration Audit

Run a final pass on what each generation has inherited from
the prior. Family saga's deepest thematic work is the
calibration of inheritance — the conscious refusal that
nevertheless transmits; the wisdom that passes through
specific behaviour; the trauma that re-emerges in the third
generation; the resilience that surfaces unexpectedly in
the granddaughter who never met the grandmother who shaped
it. Build an inheritance ledger: for each generation, what
they consciously received from prior generations, what they
consciously refused, what they unwittingly transmitted, and
what they specifically broke.

Verify both desirable and undesirable inheritances are
operating. Family saga that transmits only trauma reads as
unrelentingly bleak; family saga that transmits only wisdom
reads as sentimental. The strongest family saga holds both:
the daughter inherits her grandmother's specific cruelty AND
her specific generosity; the family transmits its specific
wound AND its specific resilience; the granddaughter who
breaks one inherited pattern often inherits another she has
not yet recognised.

Verify the form's central thematic question is being
operated rather than asserted. If the prose contains
sentences of the form "patterns persist across generations"
or "the family's history shaped them all", these are
theme-statement that breaks trust with the reader. The
strongest family saga lets the reader see the inheritance
operating without telling them what to think about it.

Test: for the manuscript's primary protagonists across
generations, write one paragraph each describing what they
inherited, what they refused, what they transmitted despite
intention, and what they broke. If the paragraphs can be
written from the prose's specific rendered material, the
calibration is operating; if the paragraphs require
generalisation beyond what the prose shows, the inheritance
work has been done in the writer's notes rather than on
the page.

## Names & Patterns to Avoid

### Family Saga Character Names. NEVER USE
- Confusingly similar names across generations (John, Jon, Johnny. unless the repetition is deliberate and carefully managed)
- Names that signal their generation too obviously
- The same first name for too many characters (even if realistic, it confuses readers)

### Family Saga. NEVER DO
- Start with a family tree that's so complex the reader needs a chart (introduce characters through story, not genealogy)
- Jump between generations without clear signalling (date stamps, section breaks, or contextual anchors)
- Give every generation the same narrative weight (some generations need a chapter, others need a section)
- Resolve generational trauma in one conversation (it doesn't work that way)

### Use Instead
- Names appropriate to each generation's era and cultural context
- Distinctive names that help the reader track characters across decades
- Family naming traditions that carry meaning (a name passed down, a name refused)

## Comp Titles

Family-saga's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *The Forsyte Saga* — John Galsworthy (1906-1921): the family-saga archetype.
- *The Thorn Birds* — Colleen McCullough (1977): multi-generation Australian saga benchmark.
- *Roots* — Alex Haley (1976): generational African-American saga.
- *East of Eden* — John Steinbeck (1952): family-saga literary masterpiece.
- *One Hundred Years of Solitude* — Gabriel García Márquez (1967): magical-realist family-saga.

### Contemporary (current best-in-class)

- *Pachinko* — Min Jin Lee (2017): Korean-Japanese multi-generation saga benchmark.
- *Homegoing* — Yaa Gyasi (2016): Ghana-to-America generational saga.
- *The Vanishing Half* — Brit Bennett (2020): contemporary family-saga with passing-narrative.
- *The Lincoln Highway* — Amor Towles (2021): contemporary American sibling-saga.
- *Hamnet* — Maggie O'Farrell (2020): historical family-saga.
- *Crossroads* — Jonathan Franzen (2021): contemporary American family-saga; first of trilogy.
- *Trust* — Hernan Diaz (2022): metafictional family-saga.
- *The Old Drift* — Namwali Serpell (2019): Zambian generational saga.

## Cover Design Specifications

### Recommended Visual Styles
- **Atmospheric**. The family home or landscape across seasons/eras: a house that suggests decades of habitation; the passage of time visible in the image
- **Layered**. Multiple images or textures overlaid: representing different generations, eras, or perspectives; the visual equivalent of the story's structure
- **Object-Focused**. A significant family object against a textured background: a ring, a photograph, a key, a recipe card; the object carries the weight of the saga
- **Typographic**. Elegant, sweeping typography that suggests scope and time: the title is the primary element

### Genre Cover Aesthetics
- **Styles:** Houses and landscapes that show the passage of time, family photographs or vintage imagery, layered compositions suggesting depth and history, seasonal progressions, architectural details that anchor a sense of place and time
- **Colours:** Rich, warm palettes suggesting history: sepia, burgundy, forest green, aged gold; cool blues and greys for more literary treatment; the colour palette should feel like MEMORY. warm-shifted, slightly faded, rich
- **Elements:** The family home (partial view, suggesting more than is shown), trees (growth, roots, branches as metaphor), photographs and documents, generational objects (jewelry, furniture, land), seasonal markers, architectural details
- **Typography:** Elegant serif faces that suggest scope and tradition; the family name (if the title) should feel authoritative; generous letter-spacing; gold or embossed effects for commercial appeal; the typography should feel like an inscription. permanent, weighted

### Market Positioning
Family saga covers must signal "generations of story" through depth, warmth, and the suggestion of time's passage. Position against Allende, Steinbeck, Ng, Otsuka, Kingsolver, Hannah. The cover should feel SUBSTANTIAL: this is a big story, and the design should match. At thumbnail size, warm colours and a single strong image (house, tree, landscape) create immediate genre recognition. Commercial family sagas lean warmer; literary ones lean cooler.

### Cover Design DON'Ts
- No single-character portraits (the family is the protagonist, not one person)
- No bright, trendy palettes (the story spans decades; the design should feel timeless)
- No cluttered compositions with too many elements
- No modern photography that reads as contemporary fiction (the sense of TIME is essential)
- No generic "big house" imagery without distinctive character
- No genealogy charts or family tree diagrams on the cover (save those for the interior)
