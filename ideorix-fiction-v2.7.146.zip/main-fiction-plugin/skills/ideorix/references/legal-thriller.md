---
name: legal-thriller-genre
description: Genre-specific instructions for legal thriller fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [thriller, crime]
---

# Legal Thriller. Genre Plugin

## Metadata
- id: legal-thriller
- name: Legal Thriller
- icon: ⚖️
- category: Fiction
- minWords: 3000
- targetWords: "3,000-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Save the Cat", "Legal Thriller Beats"]

## Subgenre Options
Present during setup:
- **Courtroom Drama**. Trial-centric narrative, examination and cross-examination as set pieces, verdict as climax
- **Legal Conspiracy**. Institutional corruption, powerful adversaries, the protagonist uncovers a system-wide scheme
- **Wrongful Conviction**. Race against time to exonerate an innocent client, buried evidence, procedural injustice
- **Corporate Legal**. Big-firm politics, hostile takeovers, whistleblowers, white-collar crime hidden behind NDAs
- **Political Legal**. Government corruption, constitutional stakes, high-profile cases with national consequences

## Architect Instructions

```
STRUCTURE
- Chapter length: 3,000-4,500 words
- Pacing: Dual-track tension. courtroom strategy sequences alternate with external threat escalation
- Must open with: A case development, legal crisis, courtroom moment, or threat that raises stakes

BEATS PER CHAPTER
1. Case Beat. Active legal work (research, deposition, courtroom scene, client meeting, evidence review)
2. Threat Beat. External danger escalates (intimidation, surveillance, missing witness, cover-up discovered)
3. Strategy Shift. New information forces the protagonist to adapt their legal approach
4. Character Pressure. Ethical dilemma, personal cost, relationship strain, or moral compromise
5. Cliffhanger or Revelation. Chapter ends with a discovery, setback, or escalation that demands the next chapter

LEGAL THRILLER ARCHITECTURE
- The inciting case arrives by Chapter 1-2 (client walks in, assignment drops, discovery of injustice)
- Stakes established early: What does the client lose? What does the protagonist risk?
- Dual-track tension maintained throughout:
  - TRACK A (Courtroom): Building the case, procedural milestones, trial scenes
  - TRACK B (Thriller): Physical danger, institutional pushback, personal threats
- Evidence discovery paced across the narrative:
  - Act 1 (setup): Initial case assessment, first hint something is bigger than it appears
  - Act 2 (escalation): Key evidence surfaces, is challenged, disappears, or is manipulated
  - Act 3 (trial/climax): Smoking-gun revelation, courtroom confrontation, final gambit
- Minimum 3 legal procedure milestones (e.g., discovery, deposition, motion hearing, voir dire, trial day)
- At least 2 major courtroom scenes (examination, cross-examination, or closing argument)
- The "smoking gun" evidence: foreshadowed early, its significance revealed late
- Resolution must be legally plausible. no deus ex machina acquittals

MANDATORY ELEMENTS
- At least one cross-examination scene written as a thriller set piece
- At least one scene where the protagonist faces an ethical line (privilege, duty to court, conflict of interest)
- The antagonist (opposing counsel, corrupt institution, or hidden power) must be competent and formidable
- A deadline that creates urgency (trial date, statute of limitations, sentencing hearing, filing deadline)

FORBIDDEN IN LEGAL THRILLER
- Lawyers who win through superhuman oratory alone (strategy and evidence must drive outcomes)
- Judges who are mere props (judges have opinions, biases, and procedural authority)
- Trials resolved by surprise witnesses with no prior setup
- Evidence that appears from nowhere in the final act
- Legal procedure played entirely for spectacle with no accuracy
- Courtroom outbursts that would result in contempt but somehow don't
- The protagonist single-handedly defeating a conspiracy with no help or cost
- Cases won purely on emotion with no evidentiary basis

CHAPTER ENDING REQUIREMENTS
- Every chapter ends with forward momentum or raised stakes
- Use: evidence discovered or destroyed, witness flips, ruling goes wrong, threat escalates,
  ethical line crossed, case theory shattered, deadline tightens
- NEVER use: vague sense of unease with no concrete cause, "something about this case
  didn't add up" without specifics, manufactured cliffhangers disconnected from the case
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Anticipation (procedural progression), Revelation (twist), Validation at courtroom resolution.

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person past tense OR third close past tense (legal thrillers favour tight POV)
- Voice: Sharp, precise, controlled. reflecting a legal mind under pressure
- Tone: Tension-laced professionalism that cracks under escalating stakes
- Reader relationship: Like sitting second chair. you see what the lawyer sees, feel the pressure

DIALECT CONSISTENCY (IMPORTANT. JURISDICTION-AWARE)
- Establish the dialect in the Story Bible (British English, American English, etc.)
- Maintain 100% consistency throughout. a single "fall" in a British novel is jarring
- Common British/American traps to watch:
  - autumn / fall
  - colour / color
  - pavement / sidewalk
  - boot (of car) / trunk
  - torch / flashlight
  - flat / apartment
  - "have got" / "gotten"
  - mobile / cell phone
  - post / mail
- Legal-specific dialect traps (CRITICAL. legal terminology differs by jurisdiction):
  - barrister / attorney (UK = barrister/solicitor; US = attorney/lawyer)
  - solicitor / lawyer (UK solicitor ≠ US solicitor)
  - court of appeal / appellate court
  - claimant / plaintiff (UK shifted to "claimant" in civil cases)
  - dock / defendant's table (UK defendants sit in the dock; US at counsel table)
  - QC/KC /. (no US equivalent of King's/Queen's Counsel)
  - magistrate / judge (UK magistrates ≠ US judges)
  - Crown Court / Superior Court (different court hierarchies)
  - CPS / DA's office (Crown Prosecution Service vs District Attorney)
- If British setting: Use British legal terminology consistently. A barrister does NOT
  "take the case". a solicitor instructs a barrister. The accused sits in the dock.
- If American setting: Use American legal terminology. "Sustained" and "overruled"
  (not "upheld" and "dismissed"). The defendant sits at counsel table.
- The Prose Craft Improver should scan for dialect and legal terminology inconsistencies

PROSE IMPERATIVES
- Legal jargon used for authenticity but ALWAYS made accessible through context
  (the reader should understand the stakes without a law degree)
- Courtroom scenes written with cinematic precision. beats of dialogue, pauses, reactions
- Cross-examination rendered as intellectual combat (thrust, parry, trap, revelation)
- Internal monologue reveals strategy. the reader sees the lawyer think three moves ahead
- Physical environment of courtrooms rendered through the POV character's focus. what they fixate on in that moment, not a full inventory of the room
- Tension in stillness: the pause before a verdict, the silence after an objection, the wait
  for a judge's ruling

PROSE RHYTHM MAPPING (CRITICAL. argument-rhythm architecture)

Legal thriller prose follows argument-rhythm: build, evidence, turn,
revelation. The reader should feel the lawyer's mind constructing a
case. each sentence a brick, each paragraph a wall, each chapter a
closing argument. The prose IS persuasion.

Chapter 1 prose rhythm:
- Sentence average: 14-22 words. Sharp and controlled, reflecting a
  legal mind under pressure. Sentences shorten during courtroom
  confrontation; lengthen during case analysis and strategic planning.
- Courtroom scenes: dialogue-dominated. 70%+ by word count. Short,
  rapid exchanges. Question-answer-objection-ruling. The rhythm of
  examination is the rhythm of combat: thrust, parry, trap, reveal.
  Prose between dialogue is minimal. a reaction, a gesture, a
  strategic thought. Let the dialogue carry the scene.
- Investigation/preparation scenes: medium analytical prose, 30-40%
  dialogue. The protagonist reads depositions, reviews evidence, plans
  strategy. Sentences build logically. "If the witness confirms X,
  then Y collapses, which means Z is the only remaining theory."
- Argument-rhythm in paragraphs: build (establish the premise),
  evidence (the supporting detail), turn (the complication or
  contradiction), revelation (the insight that changes the case).
  This four-beat rhythm echoes legal argument structure and gives the
  prose its distinctive forward momentum.
- Tension floor: ≥6. Dual-track tension at all times: the courtroom
  case and the external threat. Even quiet preparation scenes carry
  the weight of what's at stake. the client's freedom, the
  protagonist's career, the lurking danger outside the courtroom.

LEGAL AUTHENTICITY BOUNDARIES (CRITICAL)
- Procedures must be recognisably accurate (not perfect, but never absurd)
- Correct terminology: "sustained" / "overruled," "discovery" not "investigation,"
  "deposition" not "interview," "motion to suppress" not "request to remove"
- Judges address lawyers properly; lawyers address the court properly
- Objections have legal basis (hearsay, relevance, leading, foundation). not just "Objection!"
- Evidence rules matter: chain of custody, authentication, privilege
- Trial preparation is shown as gruelling, detailed work. not a montage
- Sidebar conferences, chambers meetings, and procedural wrangling are valid dramatic scenes
- Juries deliberate. they don't just announce verdicts
- EXCEPTION: Pacing may compress timelines (a real trial takes weeks; a thriller condenses)

DUAL-TRACK PROSE
- Courtroom scenes: Controlled, precise, strategic. the protagonist is performing
- Thriller scenes: Visceral, urgent, adrenaline-driven. the protagonist is surviving
- Transition between tracks should feel like shifting gears, not switching genres
- Both tracks inform each other: what happens outside the courtroom affects what happens inside

DIALOGUE FOR LEGAL THRILLER
- Courtroom dialogue follows examination structure (question-answer, with objections and rulings)
- Cross-examination dialogue is adversarial. leading questions, traps, controlled revelation
- Attorney-client conversations reveal character through what the client hides
- Opposing counsel dialogue establishes them as a worthy adversary, not a cartoon villain
- Witness testimony reveals character. how people behave under oath
- Informal legal conversations (hallway deals, bar association gatherings, chambers)
  show the human side of the profession
- EVERY line of courtroom dialogue must serve a strategic purpose. no filler questions

CROSS-EXAMINATION AS THRILLER SET PIECE
- Build cross-examination scenes like action sequences:
  1. Setup: Establish what the lawyer needs from this witness and what can go wrong
  2. Opening: Easy questions that establish rhythm and lull the witness
  3. Escalation: Questions narrow, the trap begins to form
  4. The turn: The witness realises where this is going (or doesn't. which is worse)
  5. The kill shot: The question that destroys the testimony or reveals the truth
  6. Aftermath: The courtroom's reaction, the jury's shift, the opposing counsel's scramble
- The reader should feel the tension of each question before the answer comes
- Failed cross-examinations are as dramatic as successful ones (the protagonist isn't infallible)
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

LEGAL CRAFT (35% of total):
- Procedural accuracy: Are legal procedures recognisably correct? (0-100)
- Courtroom authenticity: Do trial scenes feel real and strategically driven? (0-100)
- Evidence logic: Is the case built on evidence, not coincidence or emotion? (0-100)
- Jargon balance: Legal terminology used for authenticity without alienating readers? (0-100)

THRILLER TENSION (35% of total):
- Dual-track maintenance: Both courtroom and external threat tracks sustained? (0-100)
- Stakes escalation: Do stakes genuinely increase across chapters? (0-100)
- Pacing: Does the narrative maintain urgency appropriate to a thriller? (0-100)
- Antagonist competence: Is the opposition genuinely formidable? (0-100)

PROSE & CHARACTER (30% of total):
- Show vs tell ratio (0-100)
- Dialogue differentiation: Characters identifiable by speech patterns? (0-100)
- Ethical complexity: Does the protagonist face genuine moral dilemmas? (0-100)
- Sensory detail in courtroom and legal settings? (0-100)

AUTOMATIC FAILS (score = 0):
- Legally absurd procedures with no narrative justification
- Surprise witnesses or evidence introduced in the final act with no prior setup
- Courtroom scenes that are pure spectacle with no strategic logic
- The protagonist wins through oratory alone with no evidentiary basis
- Opposing counsel is incompetent or cartoonishly evil with no depth
- ACCURACY DRIFT: Legal terms consistently misused, procedures invented
- TONE DRIFT: Shifts into romance, comedy, or procedural police drama without genre justification
- STAKES COLLAPSE: External threat track abandoned, or courtroom track becomes background
- Deus ex machina resolution (unexpected confession, sudden new evidence, judge intervention)
```

## Continuity Rules

```
LEGAL THRILLER CONTINUITY. WHAT TO TRACK

CASE KNOWLEDGE STATE (CRITICAL):
- What evidence has been formally DISCOVERED (entered into the record)?
- What evidence does the protagonist KNOW about but cannot yet USE (privilege, inadmissibility)?
- What does opposing counsel know? What has been disclosed during discovery?
- What motions have been filed? What has the judge ruled on?
- What does the jury know (if trial has begun)?
- What is the protagonist WRONG about at this point in the case?

WITNESS STATUS:
- For each witness: deposed or not, testimony given or pending, cooperation level
- Which witnesses have been subpoenaed? Which have been contacted informally?
- Witness credibility: Has it been established, challenged, or destroyed?
- Hostile witnesses: What leverage exists? What risks do they pose?
- Missing or threatened witnesses: Last known status, impact on the case

EVIDENCE CHAIN:
- Every piece of evidence: when discovered, by whom, chain of custody status
- Admissibility status: Has it been challenged? Has the judge ruled?
- Physical evidence location (evidence locker, counsel's possession, missing)
- Documentary evidence: What documents have been produced in discovery?
- Evidence the protagonist suspects exists but hasn't found yet

PROCEDURAL TIMELINE:
- Filing deadlines met or approaching
- Discovery completion status
- Motions pending and resolved
- Pre-trial conference dates
- Trial schedule (which day, which witness)
- Jury selection status (if applicable)

THREAT ESCALATION TRACKING:
- What threats has the protagonist received? In what form?
- What has the protagonist done about external threats (reported, ignored, investigated)?
- Which allies and resources remain intact?
- What has been lost (evidence, witnesses, safety, relationships)?

RELATIONSHIP TRACKING:
- Attorney-client trust level (has the client lied? has the lawyer discovered something?)
- Relationship with opposing counsel (professional, hostile, respectful, personal history?)
- Relationship with the judge (prior appearances, known biases?)
- Personal relationships strained by the case (spouse, children, friends, colleagues)
- Allies within the legal system (clerks, investigators, fellow attorneys)
```

## Character Rules

```
LEGAL THRILLER CHARACTER ARCHETYPES

THE PROTAGONIST (LAWYER/LEGAL PROFESSIONAL):
- Brilliant but flawed. intelligence is the primary weapon, but judgment is tested
- Has a specific legal specialty or reputation that makes them credible for THIS case
- Morally tested throughout. the easy path and the right path rarely align
- Personal stakes tied to the case (career, reputation, safety, guilt, redemption)
- Competent in the courtroom but human outside it (marriage problems, addiction,
  past failures, financial pressure)
- Strategic thinker who can be outmanoeuvred (not infallible)
- MUST have a credible reason for taking or staying on this case despite the risk

THE CLIENT:
- Not fully honest. clients withhold information (this is realistic and creates tension)
- Sympathetic enough to justify the protagonist's commitment
- Has a secret that complicates the case when revealed
- The protagonist's relationship with the client evolves (trust built or broken)
- The client's fate is the emotional core of the courtroom track

THE ANTAGONIST (OPPOSING COUNSEL / CORRUPT POWER):
- Competent, resourceful, and motivated. not a cardboard villain
- Has a coherent legal strategy that genuinely threatens the protagonist's case
- If institutional: the system's power is the threat (resources, connections, authority)
- If individual: a worthy intellectual adversary with their own code
- May believe they are in the right (the most dangerous opponents do)

THE JUDGE:
- NOT a neutral prop. judges have temperaments, biases, and judicial philosophies
- Reacts to courtroom conduct, enforces decorum, makes consequential rulings
- Can be an obstacle or an unexpected ally, but always within judicial bounds
- Prior history with the attorneys should inform dynamics

KEY WITNESSES:
- Each witness has a reason to tell the truth AND a reason to lie
- Witness behaviour under examination reveals character (nervous, defiant, evasive, rehearsed)
- At least one witness whose testimony could go either way (genuine uncertainty)
- Expert witnesses should have credentials and opinions that can be challenged

THE SUPPORT TEAM:
- Paralegal, investigator, or junior associate who does the unglamorous groundwork
- A mentor figure or colleague who provides perspective (and sometimes bad advice)
- A personal connection (spouse, friend, family) who grounds the protagonist outside the law

ANTAGONIST PRESENCE BALANCE (Writer-Level Enforcement):
Legal thrillers run on DUAL TRACKS. courtroom opposition + external threat.
Both must maintain consistent pressure. Quantitative tracking per chapter:
- COURTROOM OPPOSITION: Scenes where opposing counsel acts against the protagonist's
  case (motions, examinations, objections, strategy)
- EXTERNAL THREAT: Scenes where the thriller-track antagonist creates danger
  (threats, witness tampering, surveillance, intimidation)
- Per-chapter minimum: At least ONE of the two opposition types must be present
- DUAL-TRACK BALANCE: Neither track should go dormant for >2 consecutive chapters
  - If 2 consecutive courtroom-only chapters, the next MUST include external threat
  - If 2 consecutive thriller-only chapters, the next MUST include courtroom opposition
- ESCALATION: Both tracks should intensify across acts:
  Act 1: Courtroom ~60% / External ~40% (case dominates, threats emerging)
  Act 2: Courtroom ~50% / External ~50% (tracks converge)
  Act 3: Courtroom ~60% / External ~40% (climax in court, threats resolved)
- The Character Tracker will flag chapters where either track drops below threshold
  or where the dual-track balance becomes lopsided.

VOICE DIFFERENTIATION REQUIREMENTS:
- Courtroom professionals speak differently than civilians (precision, formality, strategy)
- Opposing counsel's style should contrast with the protagonist's (aggressive vs methodical,
  folksy vs technical, theatrical vs understated)
- Witnesses from different backgrounds speak accordingly (education level, region, profession)
- The judge's voice carries authority. measured, decisive, occasionally sharp
- The client's voice shifts as trust develops or fractures

VOICE DIFFERENTIATION. QUANTITATIVE CHECK:
For each PAIR of major characters, identify at least 3 distinguishing dialogue features.
If any two characters share >2 features, one must be revised before proceeding.

Legal thrillers risk voice convergence between legal professionals who all speak
with similar precision and formality. Ensure different:
- Courtroom vs casual register (some characters are formal everywhere; others shift
  dramatically between courtroom and corridor)
- Legal vocabulary level (opposing counsel may use more technical language; the
  protagonist may be more accessible; witnesses use lay terms)
- Arguing style (one builds logically, one uses emotion, one uses authority,
  one uses precedent, one uses narrative)
- Response under judicial pressure (one defers, one pushes back, one redirects,
  one becomes more precise)
- Non-legal dialogue (how lawyers sound outside the courtroom. revealing the
  person behind the profession)

The Character Tracker verification agent will flag voice convergence between
any two major characters. If flagged, the Writer must differentiate before proceeding.
```

## Arc Rules

```
LEGAL THRILLER STORY STRUCTURE

ACT 1: THE CASE (Chapters 1-6 for novella, 1-10 for novel)
- Establish the protagonist in their legal world (firm, practice, reputation, daily reality)
- The inciting case arrives: client walks in, assignment drops, injustice discovered
- Initial case assessment: What's the charge? What's the evidence? What's the defence?
- First sign this case is bigger/more dangerous than it appears
- Establish the opposition (opposing counsel, corrupt institution, powerful adversary)
- Plant seeds of the "smoking gun" evidence (its existence hinted, significance unknown)
- Protagonist commits to the case despite early warnings
- Dual-track tension initiated: courtroom preparation begins AND first external threat materialises
- Personal stakes established (why this case matters to the protagonist beyond professional duty)

ACT 2: THE TRIAL (Chapters 7-16 for novella, 11-28 for novel)
- Case preparation intensifies: discovery, depositions, motions, witness preparation
- Evidence complications: key evidence challenged, suppressed, or missing
- Major courtroom scenes: examination, cross-examination, expert testimony
- The antagonist demonstrates their power (legal manoeuvres, external pressure, witness tampering)
- Midpoint revelation: A discovery that fundamentally changes the case (the client lied, the
  conspiracy is deeper, the real perpetrator is someone unexpected)
- Protagonist faces ethical crisis: What they must do to win vs what the law allows
- External threat peaks: witness disappears, protagonist threatened, evidence destroyed
- Dark moment: The case appears unwinnable. the protagonist considers quitting
- A crucial ally provides a lead, a new angle, or a piece of missing evidence
- The protagonist makes a decision that risks everything (career, safety, relationships)

ACT 3: THE VERDICT (Chapters 17-22 for novella, 29-36 for novel)
- Final trial push: The protagonist's strategy crystalises
- Smoking-gun evidence deployed (its significance finally clear to the reader and jury)
- Climactic courtroom scene: The cross-examination or closing argument that turns the case
- The antagonist's counter-move (last-ditch legal manoeuvre, desperate action)
- Verdict or resolution (not always an acquittal. justice takes many forms)
- External threat resolved (may overlap with courtroom resolution)
- Aftermath: Professional and personal consequences of the case
- Final chapter: The protagonist changed. harder, wiser, more committed, or disillusioned
  but enduring

THE CLIMAX SEQUENCE. THE COURTROOM CRESCENDO:
The legal thriller climax happens in TWO ARENAS simultaneously: the
courtroom and the external threat. Structure across 3-4 chapters:

Chapter N-3 (THE NIGHT BEFORE):
- The protagonist prepares for the decisive day of trial. Review evidence,
  rehearse questions, plan the order of witnesses.
- The external threat reaches its peak: a final warning, a witness goes
  missing, evidence is tampered with. The protagonist must decide whether
  to inform the court or handle it themselves.
- An ethical decision: the protagonist discovers something that could win
  the case but requires crossing a line (using improperly obtained evidence,
  revealing a confidence, bending a rule). What they choose defines them.
- Personal beat: the cost of the case made visible (the missed event, the
  strained relationship, the exhaustion).

Chapter N-2 (THE EXAMINATION):
- The climactic courtroom scene. This is the set piece the novel has been
  building toward. the cross-examination that breaks open the case, OR
  the direct examination that delivers the smoking gun.
- Write with all 5 layers active (physical space, strategic context,
  dialogue as combat, reactions/subtext, internal strategy).
- The opposing counsel fights back. A strong objection, a redirect,
  an unexpected answer. the protagonist must improvise.
- The jury reacts. The judge intervenes. The gallery murmurs.
- The moment turns: the truth emerges. Not through confession.
  through the logic of evidence and the skill of the questioner.

Chapter N-1 (THE CLOSING / THE CRISIS):
- Closing arguments: the protagonist weaves the evidence into a narrative.
  This is not a speech. it's a story told to the jury using everything
  the trial has established.
- The external threat converges with the trial: a revelation from outside
  the courtroom affects what happens inside (or vice versa).
- The antagonist's final move: a mistrial motion, a surprise witness,
  a procedural challenge. The protagonist must respond in real time.
- The case goes to the jury (or the judge rules, or a settlement is
  offered that tests the protagonist's principles).

Chapter N (THE VERDICT AND AFTER):
- The wait. Show the specific physical hell of waiting for a verdict
  (the empty courtroom, the corridor pacing, the phone that doesn't ring).
- The verdict arrives. Whether guilty, not guilty, or something more
  complex. the protagonist's reaction reveals what the case meant to them.
- External threat resolved: the connection between the courtroom outcome
  and the personal danger is made explicit.
- The protagonist's professional and personal aftermath: what was won,
  what was lost, and what was learned about the law they serve.

TENSION ARC:
- Opens with professional urgency (a case that demands attention)
- Builds through dual tracks (courtroom complexity + personal danger)
- Midpoint: Ground shifts under the protagonist (everything they assumed is wrong)
- Escalation: Both tracks converge (what happens in court affects what happens outside, and vice versa)
- Peak: The courtroom climax (the moment everything is on the line)
- Resolution: Not just the verdict. the human cost and what comes after
```

## Timeline Rules

```
LEGAL THRILLER TIMELINE TRACKING

CASE CALENDAR (CRITICAL):
- Filing dates, discovery deadlines, motion hearing dates
- Deposition schedule (who, when, where)
- Pre-trial conference dates
- Trial start date (the ultimate deadline)
- Statute of limitations (if applicable. a ticking clock)
- Sentencing date (if post-conviction narrative)
- EVERY legal deadline must be tracked and consistent

TRIAL SCHEDULE:
- Which day of trial is each chapter set during?
- Witness order (prosecution/plaintiff presents first, then defence)
- Which witnesses have testified? Which remain?
- How many days has the trial lasted? (Trials have rhythm. morning sessions, lunch
  recesses, afternoon sessions, evening preparation)
- Jury fatigue and attention (long trials wear on jurors. this affects strategy)

EVIDENCE DISCOVERY TIMELINE:
- When each piece of evidence was discovered, by whom
- When evidence was disclosed to opposing counsel (discovery obligations)
- When evidence was entered into the record vs when it was challenged
- Chain of custody timestamps
- When the "smoking gun" first appears vs when its significance becomes clear

EXTERNAL THREAT TIMELINE:
- When each threat occurred and how the protagonist responded
- Escalation pattern (threats should intensify, not plateau)
- Timeline alignment: Do external threats coincide with critical case moments?
  (This creates suspicion of coordination)
- When the protagonist first suspects the threats are connected to the case

WORK-LIFE TIMELINE:
- How many hours per day is the protagonist working? (Legal thrillers should show
  the grinding reality of case preparation)
- When do personal scenes occur? (Evenings, weekends, stolen moments)
- Sleep deprivation accumulation (realistic for trial attorneys)
- How long since the protagonist had a normal day?

PROCEDURAL CONSISTENCY:
- Court is in session at consistent times (9 AM to 5 PM with breaks)
- Judges maintain consistent courtroom rules
- Legal filings take realistic time to process
- Travel between locations is consistent
- Time zones matter if the case spans jurisdictions
```

## Genre-Specific Craft Techniques

Legal thriller at the level of Scott Turow, John Grisham,
Robert Traver, William Landay, Michael Connelly, Sarah
Vaughan, and Steve Cavanagh earns its genre-defining
authority through procedural accuracy, dual-track tension,
and the moral weight of the form's signature ethical
dilemmas. The professional reader of legal thriller
includes lawyers, paralegals, and serious court watchers;
procedural mistakes break the spell faster than character
or plot mistakes because they signal the writer doesn't
know the world. The form is uniquely vulnerable to a
cluster of failure modes that AI-generated drafts hit
with predictable frequency: **Oratorical-Win Failure**
(lawyers winning through superhuman oratory alone, with
strategy and evidence treated as decoration); **Surprise-
Witness Resolution** (a witness who arrives in the final
act with no prior setup and resolves the case);
**Evidence-from-Nowhere** (a smoking-gun document or
piece of evidence appearing in Act 3 with no foreshadowing
the reader can locate); **Procedure-as-Spectacle**
(courtroom scenes played for theatrical drama without
any actual procedural accuracy underneath); **Contempt-
Free Outbursts** (courtroom outbursts that would result
in real contempt sanctions but somehow never do, voiding
the form's institutional-realism contract); **Lone-Hero
Triumph** (the protagonist single-handedly defeating an
entire conspiracy with no help, no cost, no support team);
**Emotion-Over-Evidence Resolution** (cases won purely on
emotion with no evidentiary basis the reader can name);
**Cartoonish Opposing Counsel** (the opposition rendered
as incompetent or theatrically evil rather than as a
worthy intellectual adversary); **Accuracy Drift** (legal
terms consistently misused — sustained vs. upheld,
discovery vs. investigation, deposition vs. interview —
or procedures invented from movie exposure); **Tone
Drift** (the manuscript shifting into romance, comedy, or
police procedural without genre justification);
**Lecture-Mode Procedure** (legal procedure explained to
the reader through clumsy exposition rather than shown in
action through character behaviour); **Judge-as-Prop**
(judges treated as neutral mechanism rather than as
characters with temperaments, biases, and judicial
philosophies); and **Deus Ex Machina Resolution** (the
unexpected confession, the sudden new evidence, the
judge's intervention that resolves the case without
earning the resolution). The four canonical technique
clusters below — Courtroom Scene Construction (with five
layers), Legal Procedure Accuracy (with seven core
procedures), Cross-Examination as Thriller Set Piece
(with three structural phases), and Case-Building as
Narrative Architecture (with the six-step smoking-gun
framework) — are how the form defends against these
failure modes through procedural specificity, intellectual
combat, and earned resolution.

### Courtroom Scene Construction

Courtroom scenes are the set pieces of legal thriller fiction. They must be constructed with the precision of action sequences and the tension of psychological warfare.

**The 5-Layer Courtroom Scene:**

**Layer 1: Physical Space**
Ground every courtroom scene in sensory reality. Pick ONE or TWO physical details that the POV character fixates on in that moment. The distance to the witness box. The jury's silence. Let the reader feel the room through the character's nerves, not through a set-dressing checklist.

**Layer 2: Strategic Context**
Before any examination begins, the reader must understand:
- What does the examining attorney NEED from this witness?
- What could go wrong?
- What's the trap being set (or avoided)?
- What are the stakes of this specific witness for the overall case?

**Layer 3: Dialogue as Combat**
Courtroom dialogue is not conversation. It is controlled, strategic, and adversarial.
- Direct examination: Guide the witness to deliver testimony that supports your narrative.
  Questions are open-ended, witness does the talking. The lawyer is a conductor.
- Cross-examination: Control the witness with leading questions. The lawyer does the talking.
  The witness is cornered into yes-or-no answers. Every question is a step in a trap.
- Re-direct: Damage control or emphasis. Short, precise, purposeful.
- Objections: Must have legal basis. "Objection, hearsay." "Objection, leading." "Objection,
  assumes facts not in evidence." The judge's ruling changes the scene's direction.

**Layer 4: Reactions and Subtext**
The silent actors in a courtroom scene carry enormous weight:
- The jury's body language (shifting, leaning forward, frowning, nodding)
- Opposing counsel's reaction (calm confidence, barely concealed alarm, furious note-passing)
- The client's behaviour (hope, despair, the involuntary flinch at a damaging answer)
- The judge's demeanour (patience wearing thin, interest piqued, suspicion aroused)
- The gallery (media, family, spectators. their reactions telegraph impact)

**Layer 5: Internal Strategy**
The protagonist's thoughts during courtroom scenes reveal the chess game:
- "If she answers yes, I pivot to exhibit 14. If she hedges, I impeach with the deposition."
- Real-time adaptation when testimony doesn't go as planned
- The moment the lawyer realises they've won a point. or lost one
- Calculating whether to push a dangerous line of questioning or retreat

### Legal Procedure Accuracy

Legal procedure is the skeleton of a legal thriller. Get it wrong and the reader's trust collapses. Get it right and the procedure itself becomes a source of tension.

**Key Procedures to Render Accurately:**

- **Discovery:** The exchange of evidence between parties. Fights over what must be disclosed.
  Motions to compel. The discovery of the document that changes everything.
- **Depositions:** Out-of-court sworn testimony. Less formal than trial but equally strategic.
  Lawyers probe for weaknesses. Witnesses reveal more than they intend.
- **Motions:** Motions to suppress evidence, motions to dismiss, motions in limine (pre-trial
  evidentiary rulings). Each is a mini-battle with real consequences.
- **Voir Dire:** Jury selection. Both sides trying to seat jurors sympathetic to their narrative.
  Strategic strikes. The juror who might swing the verdict.
- **Opening Statements:** Not evidence. a roadmap. The prosecution/plaintiff tells the jury
  what they'll prove. The defence tells them why they shouldn't believe it.
- **Closing Arguments:** The narrative culmination. Weave the evidence into a story the jury
  can follow. The prosecution argues certainty. The defence argues doubt.
- **Sidebar Conferences:** Attorney arguments at the bench, outside the jury's hearing. Where
  the real legal battles happen. procedural fights, admissibility rulings, sanctions threats.

**Accuracy Principle:** Be accurate enough that a lawyer reading your novel nods along.
Be accessible enough that a non-lawyer never feels lost. When in doubt, have a character
explain the procedure to another character who needs to understand it (the client, a junior
associate, a journalist).

### Cross-Examination as Thriller Set Piece

The cross-examination is to legal thrillers what the car chase is to action thrillers. Build them like action sequences:

**Pre-Examination Setup:**
- Show the preparation: the protagonist reviewing deposition transcripts, rehearsing questions,
  identifying the witness's weaknesses
- Establish the stakes: what happens if this cross fails?
- Reveal the strategy: what is the protagonist trying to prove or destroy?

**The Examination Itself:**
- Start with easy, establishing questions (lull the witness into a rhythm)
- Gradually narrow the questions (the witness begins to sense danger)
- Deploy the trap: use the witness's own prior statements against them
- The "kill shot" question: the one that destroys credibility or reveals the truth
- The aftermath: the courtroom's reaction, the shift in momentum

**Failed Examinations:**
- Not every cross succeeds. A skilled witness, a timely objection, or an unexpected answer
  can derail the best preparation
- Failed cross-examinations are dramatically powerful. the protagonist must adapt
- The reader should feel the protagonist's stomach drop when a question backfires

### Case-Building as Narrative Architecture

In a legal thriller, building the case IS building the story. The evidence structure mirrors the narrative structure:

**Evidence as Plot Points:**
- Each key piece of evidence is a plot point that shifts the case
- Evidence discovery drives both the courtroom and thriller tracks
- The order in which evidence appears determines the reader's understanding
- Withheld evidence creates suspense; revealed evidence creates turning points

**The Smoking-Gun Framework:**
1. Early mention: The object, document, or testimony exists but its significance is unclear
2. Mid-story connection: The protagonist begins to suspect its importance
3. Obstacle: The evidence is challenged, hidden, stolen, or ruled inadmissible
4. Recovery: Through legal skill or personal risk, the evidence is secured
5. Deployment: In the climactic courtroom scene, the evidence lands with full impact
6. Reader satisfaction: On reflection, the setup was fair. the reader could have seen it coming

### Legal Thriller AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the courtroom fell silent" | Show what caused the silence. the specific moment |
| "the evidence was damning" | Show the specific evidence and its implications |
| "justice would prevail" | Show the specific legal strategy |
| "a case that could make or break her career" | Show the specific professional stakes |
| "the witness was hiding something" | Show the specific tell in their testimony |
| "the law is a blunt instrument" | Show the specific legal limitation |
| "behind closed doors" | Show the specific meeting and what's discussed |
| "a smoking gun that changed everything" | Name the document/evidence and show its impact |
| "the jury's eyes told the story" | Show specific juror reactions |
| "precedent-setting case" | Show the specific legal principle at stake |
| "the opposing counsel smiled. never a good sign" | Show the specific tactical move |
| "her opening statement captivated the courtroom" | Render the actual opening — at least three sentences of the protagonist's narrative the reader can hear and assess |
| "the cross-examination left the witness shaken" | Show the specific question that broke the testimony, the witness's specific physical response, the moment the jury registered the shift |
| "she objected on every ground she could think of" | Name the specific objections (hearsay, relevance, leading, foundation, speculation) and the judge's specific rulings |
| "the judge wasn't having it" | Show the specific judicial language — the warning, the sustained-with-edge ruling, the threat of sanctions |
| "the verdict shocked everyone" | Render the specific moment of the foreman's voice, the specific reactions in the room, the protagonist's specific physical response |
| "she had to think on her feet" | Show the specific real-time strategic recalibration — the question abandoned mid-sentence, the new direction chosen, the witness's tell that prompted the pivot |
| "every motion had been a battle" | Render at least one specific motion battle with named procedural posture and specific opposing argument |

## Genre-Specific Revision Rules

### Six-Pass Legal Thriller Audit (Run FIRST in editorial pipeline)

The Legal Thriller Audit runs every chapter through six
named passes. Run them in order — each builds on the last.

#### Pass 1: Procedural Accuracy + Terminology

The Procedural Accuracy and Terminology pass enforces the
form's professional-reader contract against Accuracy
Drift and Lecture-Mode Procedure. Verify all legal
procedures are named correctly (discovery, deposition,
motion to suppress, motion in limine, voir dire, sidebar
conference, sustained vs. overruled — the precise
terminology must match the depicted jurisdiction).
Verify courtroom scenes follow proper examination
structure (direct examination uses open-ended questions
that let the witness deliver testimony; cross-examination
uses leading questions that control the witness; re-direct
is short and targeted). Verify objections are legally
grounded with named legal basis (hearsay, relevance,
leading, foundation, assumes facts not in evidence,
speculation, calls for a legal conclusion) — never just
"Objection!" Verify the judge behaves within judicial
norms — addresses lawyers properly, enforces decorum,
makes rulings that follow legal reasoning. Verify filing
deadlines and procedural timelines are consistent
across the manuscript. Verify courtroom decorum: lawyers
rise when the judge enters, approach the bench only when
instructed, address the court as "Your Honor" (US) or "My
Lord/Lady" (UK Crown Court depending on level). Verify
jargon accessibility — legal terms explained through
context that flows naturally from character action and
dialogue, never through narrator footnote-mode exposition.

#### Pass 2: Evidence Logic + Smoking-Gun Architecture

The Evidence Logic and Smoking-Gun Architecture pass
enforces the form's evidence-as-plot-points contract
against Evidence-from-Nowhere and Surprise-Witness
Resolution. Track every piece of evidence across the
manuscript: when it was introduced, when it was
challenged, when it was admitted (or excluded), and how
it was used. Verify chain of custody is maintained or
its breach is plot-relevant (a chain-of-custody break is
a story element, not an authorial oversight). Confirm
no evidence appears ex nihilo in the final act — every
climactic piece of evidence must be traceable to earlier
seeds the reader can locate on a re-read. Check that the
smoking-gun was properly foreshadowed through the six-
step framework: early mention (the object exists),
mid-story connection (the protagonist begins to suspect
its importance), obstacle (the evidence is challenged,
hidden, ruled inadmissible), recovery (through legal skill
or personal risk), deployment (the evidence lands in the
climactic scene with full impact), reader satisfaction
(on reflection, the setup was fair). Verify discovery
obligations are respected, or their violation is
intentional and consequential. Verify the order in which
evidence appears determines the reader's understanding —
withheld evidence creates suspense, revealed evidence
creates turning points, and both must be deployed
deliberately rather than accidentally.

#### Pass 3: Courtroom Scene Integrity + Examination Combat

The Courtroom Scene Integrity and Examination Combat pass
enforces the form's strategic-dialogue contract against
Procedure-as-Spectacle. For courtroom scene integrity,
verify every examination question serves a strategic
purpose (no filler questions; if a question doesn't move
the case forward or set up a later trap, it is cut).
Verify objections have legal basis and are ruled on
consistently — the judge's rulings follow from legal
reasoning, not plot convenience. Verify jury presence is
tracked (the jury is in the room for the scene, or the
scene is properly framed as occurring with the jury
absent). Verify sidebar conferences are used when
attorneys discuss matters outside the jury's hearing
(admissibility arguments, sanctions threats, procedural
fights). For examination combat, verify cross-examination
scenes follow the set-piece structure: setup (what does
the lawyer need from this witness, what can go wrong),
opening (easy questions that establish rhythm), escalation
(questions narrow, the trap forms), the turn (the witness
realises where this is going), the kill shot (the question
that destroys testimony or reveals truth), aftermath (the
courtroom's reaction, the jury's shift, opposing counsel's
scramble). Verify the protagonist's internal strategy is
rendered — the chess game made visible through interior
monologue, with real-time adaptation when testimony
doesn't go as planned. The pass also confirms failed
cross-examinations exist alongside successful ones —
the protagonist is not infallible, and a question that
backfires is dramatically powerful.

#### Pass 4: Dual-Track Balance

The Dual-Track Balance pass enforces the form's signature
contract — courtroom track plus external-threat track,
both maintained without either going dormant. Verify both
tracks are present across the manuscript: TRACK A
(Courtroom — building the case, procedural milestones,
trial scenes) and TRACK B (Thriller — physical danger,
institutional pushback, personal threats). Verify neither
track goes dormant for more than 2 consecutive chapters —
if 2 consecutive courtroom-only chapters, the next must
include external threat; if 2 consecutive thriller-only
chapters, the next must include courtroom opposition.
Verify the tracks inform each other: external events
affect courtroom strategy, and courtroom developments
provoke external response. Verify the thriller track is
more than window dressing — the external threat must be
proportional to the case's stakes and create real
operational pressure on the protagonist. Verify the
escalation balance across acts: Act 1 ~60% courtroom /
~40% external (case dominates, threats emerging); Act 2
~50% / ~50% (tracks converge); Act 3 ~60% courtroom /
~40% external (climax in court, threats resolved
contemporaneously). The pass also verifies the external
threat track has its own escalation pattern — threats
intensify rather than plateau, with at least one
escalation point per act.

#### Pass 5: Ethical Complexity + Antagonist Coherence

The Ethical Complexity and Antagonist Coherence pass
enforces the form's moral-weight contract against
Cartoonish Opposing Counsel and ethical decoration. Verify
the protagonist faces at least one genuine ethical
dilemma during the manuscript — and that the ethical
stakes are specific to the legal profession (privilege,
duty of candour, conflict of interest, work-product
doctrine, perjury obligations) rather than generic
right-vs-wrong. Verify the resolution of the ethical
dilemma is earned through specific reasoning and specific
cost rather than hand-waved. Verify attorney-client
privilege, duty of candour, and conflict-of-interest
rules are respected, or their violation is deliberate
and consequential within the narrative. For antagonist
coherence, verify the opposition (opposing counsel,
corrupt institution, hidden power) has a defensible
position at least legally — generic villainy fails the
form's contract. Verify opposing counsel is competent and
formidable: must win some procedural battles, must be a
worthy intellectual adversary with their own legal
strategy and own theory of the case. Verify the
antagonist's strategy genuinely threatens the
protagonist's case rather than functioning as a punching
bag for the protagonist's victories. Verify the
opposition may believe they are in the right (the most
dangerous opponents do). The pass also confirms the
form's institutional contract: flawed institutions with
some good people inside them, never monolithic
good-vs-evil.

#### Pass 6: Resolution Integrity + Trial Compression

The Resolution Integrity and Trial Compression pass
enforces the form's earned-verdict contract against Deus
Ex Machina Resolution. Verify the verdict or outcome is
supported by the evidence presented at trial — the jury's
decision must be defensible from the evidentiary record
the manuscript has rendered. Verify the climactic
courtroom scene uses only previously established
evidence, with no last-act revelations the manuscript
hasn't earned. Verify the resolution is legally plausible
even when the timeline is compressed. Verify the personal
and professional consequences of the case are addressed
in the final chapters: what the case cost the protagonist
in career, in relationships, in safety, in their relationship
to the law itself. Verify the external threat resolution
connects logically to the courtroom outcome — the two
tracks must converge, with the resolution of one informing
the resolution of the other. For trial compression, verify
the timeline is compressed for pacing but not absurdly:
a real murder trial spans weeks, and a thriller may
compress to days, but a murder trial that resolves in two
days fails the form's verisimilitude contract. Verify at
least one ticking clock is maintained throughout (filing
deadline, trial date, statute of limitations, sentencing
date, witness availability) and that the clock advances
at a rate the reader can track. The pass closes by
confirming the genre's signature: the protagonist is
changed by the case — harder, wiser, more committed, or
disillusioned but enduring — and the manuscript renders
that change rather than restoring the protagonist to
pre-case equilibrium.

## Names & Patterns to Avoid

### Legal Thriller Character Names. NEVER USE
- Protagonist names: Justice, Chase, Lawson, Judge (as surname), Scales
- Antagonist names: Shark, Wolf, any name that telegraphs villainy
- Law firm names: Dewey, Cheatem & Howe or any comedic firm name
- Judge names: Judge Justice, Judge Stern, Judge Solomon (too on-the-nose)

### Legal Thriller Firm/Setting Names. NEVER USE
- "[Prestigious Surname] & [Prestigious Surname]" with no personality (make firms feel real)
- "The Department of [Vague Government Agency]" (be specific)
- Courthouses named after fictional presidents or Supreme Court justices
- Law schools named "Prestige University Law" or "Elite Law School"

### Legal Thriller Plot Patterns. AVOID
- The brilliant closing argument that makes the jury weep and delivers an instant verdict (juries deliberate)
- The protagonist breaks into an office/home to steal evidence (then uses it in court with no consequences)
- Opposing counsel is revealed to be personally committing crimes in the final chapter with no setup
- The judge is "in on it" with no prior indication
- Client confesses to the lawyer at the last moment, resolving the case (too convenient)
- The love interest is the opposing counsel (overused)
- The protagonist quits the firm dramatically in Act 1 and starts a solo practice overnight
  (opening a practice takes capital, clients, and time)
- All government lawyers are corrupt; all defence lawyers are noble (or vice versa)

### Use Instead
- Real-sounding law firm names (Hartwell & Associates, Morrison Crane LLP, Kendrick Bauer)
- Real courthouse patterns (County Superior Court, US District Court for the [District])
- Real legal job titles (Assistant District Attorney, Associate, Partner, Of Counsel, Public Defender)
- Human names from census data (Michael, Patricia, James, Margaret, Robert, Sarah)
- Flawed institutions with some good people inside them (realistic, not monolithic)
- Specific jurisdictions that matter to procedure (state vs federal, which circuit, which state's rules)

## Comp Titles

Legal-thriller's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Presumed Innocent* — Scott Turow (1987): the modern legal-thriller template.
- *A Time to Kill* — John Grisham (1989): the Grisham legal-thriller foundation.
- *The Firm* — John Grisham (1991): legal-thriller-with-criminal-conspiracy template.
- *Anatomy of a Murder* — Robert Traver (1958): courtroom-procedural legal-fiction lineage.

### Contemporary (current best-in-class)

- *The Reckoning* — John Grisham (2018): contemporary legal-thriller with historical depth.
- *Defending Jacob* — William Landay (2012): family-and-justice legal-thriller.
- *The Whistler* — John Grisham (2016): judicial-corruption legal-thriller.
- *The Pelican Brief* — John Grisham (1992): conspiracy legal-thriller benchmark.
- *Reversible Errors* — Scott Turow (2002): legal-procedural with character-depth.
- *The Lincoln Lawyer* — Michael Connelly (2005): contemporary defence-attorney legal-thriller series.
- *Anatomy of a Scandal* — Sarah Vaughan (2018): contemporary courtroom-political legal-thriller.

## Cover Design Specifications

### Recommended Visual Styles
- **Typographic**. The dominant style for legal thrillers. Bold, authoritative title treatment with minimal imagery. The typography itself conveys power, professionalism, and tension. Works especially well for established authors and high-concept premises.
- **Cinematic**. Courthouse exteriors and interiors shot with dramatic lighting, empty courtrooms at night, a lone figure on courthouse steps. Film-quality composition that promises gravitas and drama.
- **Photorealistic**. High-quality photography of legal objects and settings: a gavel, scales of justice, legal documents with redacted text, a briefcase, a courthouse facade. Processed for mood. desaturated, high-contrast, shadowed.
- **Minimalist**. A single legal symbol (scales, gavel, blindfolded justice) rendered with stark simplicity against a dark background. Effective for literary legal thrillers that emphasise moral complexity over action.

### Genre Cover Aesthetics
- **Styles:** Professional and authoritative, restrained tension, institutional gravitas, dark wood and marble textures, the weight of the law made visual, dramatic chiaroscuro lighting on architectural elements
- **Colours:** Deep navy blues, charcoal blacks, dark mahogany/wood tones, gold accents (foil or metallic effects), parchment/cream for document imagery. The palette should feel like a high-end law office or a federal courtroom. expensive, serious, and slightly ominous. Red used sparingly as a danger accent.
- **Elements:** Courthouse columns and facades, gavels, scales of justice, legal documents and case files, redacted or stamped text, judge's bench, empty jury box, a single lit window in a dark building, sharp suits and briefcases in silhouette, courtroom interiors
- **Typography:** Serif typefaces convey tradition and authority (Garamond, Caslon, or modern serifs). Sans-serif typefaces convey modernity and sharpness (for more contemporary legal thrillers). Gold or metallic title treatments are genre-standard and signal premium positioning. Author name often in a contrasting weight or style. The type should feel like it belongs on a law firm's letterhead. impeccable and commanding.

### Subgenre Variations
- **Courtroom Drama**. The courtroom itself as the setting: the bench, the witness stand, dramatic lighting through high windows. Compositions that feel like a stage. Gold and dark wood dominate.
- **Legal Conspiracy**. Institutional imagery: government buildings, corporate towers, shadowy corridors of power. Documents, redacted files, surveillance footage. Darker, more thriller-adjacent aesthetics with blues and blacks.
- **Wrongful Conviction**. Prison imagery (bars, visiting rooms, barbed wire) contrasted with legal symbols. A clock or calendar suggesting time running out. More emotionally charged imagery than other legal subgenres.
- **Corporate Legal**. Glass-and-steel architecture, boardrooms, skyline views from corner offices. Sleek, modern design with metallic accents. The cover should feel expensive and corporate.
- **Political Legal**. Capitol buildings, flags, seals of office, podiums. National symbols rendered with menace. Red, white, and blue desaturated to feel threatening rather than patriotic.

### Market Positioning
Legal thriller covers must signal AUTHORITY and INTELLIGENCE. The genre's readers expect sophistication. they are looking for John Grisham, Scott Turow, or Steve Cavanagh, not generic suspense. At thumbnail size, the cover must read as "serious legal drama," distinct from police procedurals (badge imagery), general thrillers (action imagery), or courtroom romance. Gold foil or metallic effects on typography are a strong genre signal and perform well in Amazon thumbnails. The best legal thriller covers are restrained. they promise the reader a chess match, not a fistfight. Position toward the professional end of the thriller spectrum: more Grisham than Clancy.

### Cover Design DON'Ts
- Do NOT use action-scene imagery (explosions, car chases, gunfights). legal thrillers derive tension from intellect and procedure, not physical combat
- Do NOT use supernatural or fantastical elements. the law is the framework, and it must feel grounded and real
- Do NOT use casual or informal design language (handwritten fonts, playful illustrations, bright colours). this genre demands gravitas
- Do NOT use generic thriller imagery (shadowy figures in alleys, rain-soaked streets) without legal context. the cover must signal LEGAL thriller, not just thriller
- Do NOT use clip-art-quality legal symbols (cheap gavels, basic scales of justice). the imagery must feel premium and specific
- Do NOT use overly busy compositions. legal thriller covers should feel ordered and deliberate, reflecting the precision of legal work
- Do NOT use horror or true-crime aesthetics (crime scene tape, blood spatter, mugshots). legal thrillers are about the courtroom response to crime, not the crime itself
- Do NOT make the cover look like a textbook or non-fiction legal guide. it must feel like a thriller first and a legal story second
