---
name: middle-grade-genre
description: Genre-specific instructions for middle grade fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [general]
---

# Middle Grade. Genre Plugin

## Metadata
- id: middle-grade
- name: Middle Grade
- icon: 📚
- category: Fiction
- minWords: 1200
- targetWords: "1,500-3,000"
- recommendedBeatStructures: ["Middle Grade 7-Beat Arc", "Three-Act Structure", "Freytag's Pyramid", "Story Circle"]

## Subgenre Options

| Subgenre | Description | Key Differences |
|----------|-------------|-----------------|
| Middle-Grade Fantasy | Magic, quests, and secondary worlds for 8-12 readers | World-building must be immediately graspable; the magical rules should feel fair and learnable |
| Middle-Grade Mystery | Puzzles and investigations solved by young protagonists | Clues must be genuinely solvable by young readers; danger is real but never graphic |
| Middle-Grade Adventure | Action-driven stories of exploration, survival, and discovery | Pacing is paramount; every chapter should end with forward momentum |
| Middle-Grade Contemporary | Realistic fiction dealing with school, family, friendship, and identity | Emotional truth is the priority; problems must feel enormous from a child's perspective |
| Middle-Grade Sci-Fi | Science fiction with technology, space, or future settings accessible to young readers | Scientific concepts explained through character experience, not exposition |
| Middle-Grade Humour | Comedy-driven stories where laughs are the primary engine | Humour must be age-appropriate but never condescending; children have sophisticated comic instincts |

## Architect Instructions

```
STRUCTURE
- Chapter length: 1,500-3,000 words
- Pacing: Brisk with frequent small wins: kids need momentum
- Must open with: Kid protagonist in action OR problem that matters to them OR friendship moment
- Must close with: Mini-cliffhanger, question, or emotional beat that propels to next chapter

BEATS PER CHAPTER
1. Kid Agency: Protagonist makes choice, takes action, solves problem. not passive observer
2. Age-Appropriate Challenge: Obstacle scaled to kid's world. school, family, friends, neighborhood
3. Emotional Moment: Friendship, family, fear, excitement, disappointment. kids feel deeply
4. Growth Opportunity: Small lesson or realization without being preachy
5. Forward Movement: Plot or relationship advances. something changes or new question emerges

GENRE-SPECIFIC REQUIREMENTS
- Protagonist aged 8-12: reader identifies with character at or slightly above their age
- Kid agency central: children solve problems, not rescued by adults
- Problems kid-sized: bullying, friendship conflicts, school challenges, family issues kids can affect
- Adults present but flawed: supportive but don't fix everything
- Emotional safety maintained: scary/sad okay, but hopeful underlying tone
- Clear good/bad guidance: moral compass without preaching
- Friendship central: peer relationships matter enormously
- Humor and heart balanced: funny moments lighten serious themes
- Adventure or discovery: kids explore, investigate, create, build
- Hopefulness: even with challenges, optimism for future

★★★ THE CHILD'S SMALL WORLD ★★★

A child's world is tiny. a few households, a school, a handful of friends. but EVERYTHING that happens within it feels enormous:
- Losing a toy feels like the end of the world. Being thrown out of school is the end of life as we know it. Major events happen almost every day
- This sense of scale is the engine of middle grade fiction. What seems small to an adult is seismic to a child. Respect that proportion
- Draw on this: the smaller the world, the bigger the events feel within it. A single school, a single neighbourhood, a single building: contained settings amplify stakes
- Think back to what scared YOU as a child. A child's fears are different from adult fears: and often more primal. Dinosaurs behind a door. Shadows in a hallway. A weird neighbour. These are the fears that power children's stories

★★★ OPPOSING FORCES. TWO IDEAS COLLIDING ★★★

One idea might not be enough to power a whole book:
- The best children's stories come from two ideas smashing into each other. A sweet old granny who is also an international jewel thief. A story about escaping a care home that's also about memory loss. A coming-of-age drama that's also a story about supernatural powers
- One idea alone might be thin: a story about a sweet granny, or a story about a jewel thief. Combining them creates the energy, the comedy, and the surprise
- Serious themes combined with funny situations work powerfully. Real life is often serious and funny at the same time: your stories should be too
- The serious element can inform the comedy. Memory loss makes a grandfather believe he's back in wartime: his confusion drives both the humour and the heart

★★★ OBSTACLES AS FUEL ★★★

Without obstacles, your story follows a straight line. and that's not interesting:
- The main obstacle is usually your villain, but obstacles come in many forms: a teacher giving detention moments before the hero needs to save the world, a policeman stopping the getaway vehicle, the worst possible person appearing at the worst possible moment
- Comic characters can be obstacles too. Not villains: just people who create problems at inconvenient moments
- When your hero encounters an obstacle, find INTERESTING ways to overcome it. If they're locked in a room, finding a key immediately is too easy. What if the window is locked too? Each obstacle should require ingenuity
- The more obstacles you pile on, the more satisfying the eventual success. Make readers think it's impossible: then show how the hero finds a way

CHAPTER ENDINGS. THE CLIFFHANGER IMPERATIVE:
- Every chapter should end with a question mark for the reader. There should be no sense that the story is finished until the very end
- When a child begs to read one more chapter, it's because they know something exciting is coming. Those are the books children love
- End on revelation, danger, discovery, or an unanswered question. Never end on resolution: resolution belongs at the end of the book
- Think of each chapter ending as a hook: what will make a tired child say "just one more chapter"?

FORBIDDEN
- Adult problems children can't affect (parent unemployment, divorce details, war politics)
- Graphic violence or death (threat okay, not graphic)
- Romance as main plot (crushes fine, not central focus)
- Hopeless endings: kids need to believe they can affect world
- Talking down: respect reader intelligence
- Parent death as cheap emotion (orphan trope overused)
- Sexual content (age-inappropriate)
- Excessive swearing (mild okay if authentic to character)
- Kids solving adult-level problems unrealistically (hacking Pentagon, etc.)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation (world & adventure), Stimulation (set-piece beats), Affection (friendship arc).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: 3rd limited (close to protagonist) or 1st person (immediate kid voice)
- Tense: Past (traditional) or present (immediacy for action)
- Voice: Kid-authentic: observant, honest, funny, sometimes confused
- Reading level: Grades 4-6 (Flesch-Kincaid 4.0-6.0): accessible but not simplistic

PROSE IMPERATIVES
- Clear, direct prose: readers follow story easily without stumbling
- Sentence variety: mix short punchy and longer flowing for rhythm
- Active voice dominant: kids doing things, not things happening to them
- Concrete details: specific over abstract (show anxious stomach, not "she felt anxious")
- Dialogue sounds like real kids: incomplete sentences, interruptions, slang
- Humor natural: kids notice funny details, make jokes
- Emotion through action/body language: show shaking hands, not "she was nervous"
- Vocabulary appropriate: challenging words okay in context, not vocabulary lessons
- Chapter hooks: end with question or moment that pulls reader forward
- Respect reader: no talking down or over-explaining

GENRE-SPECIFIC STYLE
- Kid logic visible: how 10-year-old reasons through problems
- Sensory details kids notice: smells, sounds, physical sensations
- Peer relationships detailed: what friends say/do matters enormously
- School world vivid: classroom, cafeteria, playground real and specific
- Family dynamics shown: siblings, parents, extended family through kid's eyes
- Fears age-appropriate: monsters in closet vs. existential dread
- Excitement over small things: birthday party, field trip, new pet huge events
- Physical comedy: kids bump into things, spill stuff, make messes

RESEARCH YOUR CHILDHOOD. THE SECRET WEAPON:
- As a children's author you are trying to see the world through the eyes of a child. Think back to when you were five, ten or thirteen. What did you care about? What made you laugh? What scared you? What made you sad?
- The sights, sounds and SMELLS of childhood are powerful: boiled cabbage at a grandparent's house, the particular smell of a school corridor, playground dust. These sensory details bring authenticity
- Think about relationships: siblings who got all the attention, the peculiar teacher with the odd hat, the neighbourhood with its urban myths about what was really in the food at that restaurant
- Your childhood provides a treasure trove. Dig out old photographs. Ask family members what you were like. Revisit those feelings: even the silly ones. What you remember will fire your imagination
- Think like a child: "What if there were dinosaurs behind that door?" Children's ideas are often the most exciting because they're uncomplicated and primal

FINDING THE FUNNY:
Comedy is probably your greatest asset in children's books. Much of it is based on surprise. something unexpected happening:
- The classic joke structure works brilliantly: set up an expectation, then subvert it. "He told his dad all the names the other kids called him at school. 'And that's just the teachers!'"
- THE RULE OF THREE: Use two examples that establish a pattern, then a third that breaks it. Two ordinary dinner guests, then an outlandish third. Two failures, then a surprising success on the third attempt. This structure is gold for both jokes and narrative
- FUNNY LISTS: Lists are a powerful device for generating joke after joke after joke. A mock menu of terrible food, a catalogue of awful habits, a series of escalating absurdities. Children love lists
- ASIDES: Inject comedy through side-comments that don't advance the plot but add humour: a strange detail about a character, an absurd image, a throwaway observation
- SURREALISM: Take something ordinary and make it extraordinary. But use it carefully: too much surrealism can undermine the reality of your story
- TIMING: A joke might be slight, but used at the right moment. especially during a serious scene. it can have a wonderful effect. Humour in a serious moment highlights the absurdity and keeps children engaged
- TOILET HUMOUR: Children love it. Use it with wit and invention. Give bodily functions ridiculous names. Make the surreal consequences escalate absurdly. The key is to be inventive, not crude

SMUGGLING THEMES. SHOW, DON'T LECTURE:
- Pick themes that mean something to you, but DON'T be overly didactic. Show, don't tell. Use your story to illuminate the point without turning it into a lesson
- Avoid using adult terminology for complex subjects. Instead of naming the condition, describe what it does: the grandfather is "confused" and believes he's back in wartime, rather than explaining dementia
- Smuggle your theme INTO the story. If it's about homelessness, make it about a smelly, loveable vagrant whom a child befriends. If it's about being different, make it about something concrete a child can understand. The subject is there, but the story comes first
- Think about what children are ACTUALLY interested in. animals, food, friendship, adventure, the slightly forbidden. and embed your theme within those interests
- Consider flipping expectations: instead of rags-to-riches, try riches-to-rags. Instead of revenge, try justice. Take adult concepts and turn them slightly to work for children

TIMELESSNESS CRAFT:
- Making your story timeless means avoiding specific references that would date it. If you must reference current culture, create your own fictional version
- Think about whether your story could be set in the past, present, or future without losing its power. The best children's books exist outside time: readers decades later believe they were recently written
- If setting your story in a specific period, DO YOUR RESEARCH: visit relevant places, talk to people who lived through it, pick up authentic details. But don't be slavish to facts; adapt real events for your story
- Future settings don't have to be shiny and high-tech. We currently live with modern technology alongside the historical. Your future world can include old cars, outdated technology, and familiar objects alongside the new

FORBIDDEN WORDS/PHRASES
- Condescending narration: "as any child knows..."
- Vocabulary lessons disguised as story: "She felt melancholy, which means sad"
- Adult perspective intruding: observations kid wouldn't make
- Excessive profanity (mild okay if authentic)
- Abstract emotions named without showing: "depressed," "anxious" without symptoms
- Purple prose: overly flowery language
- Complex sentence structures kids can't follow
- British terms if American setting (or vice versa) without reason

DIALOGUE CRAFT
- Kids interrupt, talk over each other
- Incomplete sentences, fragments common
- Slang and kid expressions (current or timeless)
- Avoid adult-speak: kids don't say "Perhaps we should reconsider"
- Banter, teasing, inside jokes between friends
- Adults sound like adults: differentiate from kid voices
- Arguments escalate quickly: kids less filtered

SENTENCE STRUCTURE
- Short sentences for action/tension: "She ran. The door slammed. He was gone."
- Medium sentences for description: "The cafeteria smelled like pizza and sweaty gym clothes."
- Occasional longer for rhythm: "Mom always said I worried too much, but she didn't understand what it was like when everyone was watching and waiting for you to mess up."
- Average 12-18 words per sentence
- Paragraph breaks frequent: white space helps pacing

EMOTIONAL TRUTH
- Kids feel things deeply: don't minimize
- Fear is real: dark, abandonment, embarrassment, failure
- Friendship loss devastating: not trivial
- Injustice enrages: unfairness matters deeply
- Joy unfiltered: excitement huge and physical
- Embarrassment crushing: social mistakes feel enormous
```

## Prose Rhythm Mapping

```
CHAPTER 1 PROSE RHYTHM. MIDDLE GRADE

OPENING: Voice + stakes + accessibility from sentence 1. The protagonist's
personality audible immediately. Something must MATTER to the kid NOW. grab the
child reader before they can put the book down.

SENTENCES: Short-medium, 10-16 words average. Short punchy (4-8) for action,
surprise, comedy. Medium (12-18) for description and emotion. Occasional longer
(19-24) only when meaning is crystal clear. Paragraphs short (2-4 sentences);
white space helps young readers breathe. High-energy pacing throughout.

VOCABULARY: Age-appropriate, NEVER condescending (FK 4.0-6.0). Concrete over
abstract: "stomach twisted" not "felt anxious." Kid-logic: how a 10-year-old
would describe their world. Sensory details kids notice: cafeteria smells, hallway
sounds, physical feelings.

TENSION FLOOR: ≥4. Kid-scaled stakes that feel ENORMOUS: embarrassment, exclusion,
unfairness. Something at risk from page 1. The child's small world amplifies
everything. Questions planted early: Will they get caught? Will the friend find out?

RHYTHM: Open with protagonist in action (not waking up). Establish kid's world in
3-5 sensory sentences. Hook within page 1: something wrong, exciting, or weird.
At least one humour moment early. Dialogue arrives quickly. kids interrupting,
joking. End on a question or mini-cliffhanger that demands the next page. Pacing
feels like a kid telling you something exciting: breathless, specific, urgent.
```

## Quality Check Criteria

```
QUALITY PRIORITIES (ranked)

1. Kid agency: 8-12 protagonist drives story, solves problems
2. Age-appropriate content: Challenges match 8-12 reader maturity
3. Reading level: FK 4.0-6.0, sentences averaging 12-18 words
4. Peer relationships: Friendship and social dynamics central
5. Tone: Humor and hope balance challenges
6. Emotional honesty: Real feelings without graphic content
7. Growth through experience: Learning not lectures
8. Adults present but not rescuing: Support without solving kid's problems

★★★ READING LEVEL VERIFICATION (Critical for Middle Grade) ★★★

SENTENCE LENGTH ANALYSIS:
- Count approximate words per sentence in a representative sample (5-10 sentences)
- Target average: 12-18 words per sentence
- Maximum: No sentence should exceed 25 words without a very good reason
- Minimum: Short sentences (3-8 words) should appear regularly for punch and pacing
- If average exceeds 20 words: Flag as "reading level too high"
- If average below 8 words: Flag as "reading level too low: choppy, not engaging"

VOCABULARY ASSESSMENT:
- Most words should be in a 4th-6th grade vocabulary (common, concrete, everyday)
- Advanced words (3+ syllables, abstract, Latinate) should appear sparingly
- When an advanced word appears, it should either:
  a) Be defined naturally through context ("The labyrinth—a maze of twisting passages—stretched before them")
  b) Be a word kids encounter in school (hypothesis, ecosystem, algorithm)
  c) Be used for comedic or dramatic effect ("She felt discombobulated, which was exactly as confusing as it sounded")
- Flag these as TOO ADVANCED for MG without context: melancholy, juxtaposition, ephemeral, surreptitious, acquiesce, reticent, ambivalent, dichotomy
- Flag these as FINE for MG: disgusting, incredible, terrified, suspicious, investigate, catastrophe, ridiculous

PARAGRAPH LENGTH CHECK:
- Average paragraph: 3-5 sentences
- Maximum: 6 sentences before a break
- Dialogue paragraphs: 1-2 sentences typical
- White space is essential: frequent paragraph breaks help young readers

READING FLOW TEST:
- Could a 10-year-old read this aloud without stumbling?
- Are there run-on sentences that would lose a young reader mid-thought?
- Is the syntax straightforward (subject-verb-object dominant)?
- Are subordinate clauses used sparingly and clearly?

GENRE-SPECIFIC CHECKS

PROTAGONIST AND AGENCY:
- Protagonist aged 8-12, driving story actively: not waiting for adults
- Kid makes decisions, takes action, faces consequences
- Problems are kid-scaled (even if the stakes feel huge to the character)
- Skills and abilities are realistic for age

RELATIONSHIPS AND DYNAMICS:
- Peer relationships driving plot: friendships, rivalries, alliances
- At least one significant friendship shown in depth
- Adult characters present but not solving the main problem
- Bullying or conflict handled with nuance, not caricature

TONE AND VOICE:
- Humor present: at least 2-3 genuinely funny moments per chapter
- Hope and possibility maintained even during scary or sad scenes
- Voice authentic to age: kid logic, kid observations, kid priorities
- Not talking down to readers or over-explaining

EMOTIONAL AUTHENTICITY:
- Feelings shown through body and action, not just named
- Kid-appropriate fears (embarrassment, rejection, failure, monsters, unfairness)
- Joy and excitement portrayed as big, physical, unfiltered
- Sadness or fear resolved with hope: never left in despair

THE CHILD'S WORLD SCALE:
- Small events feel enormous to the character (losing a toy = catastrophe)
- The setting is contained (school, neighbourhood, single building) amplifying stakes
- The child's perspective governs the narrative: adult concerns filtered through kid understanding
- Everyday details (cafeteria food, homework, playground politics) feel vivid and specific

HUMOR QUALITY CHECK:
- Humour is inventive, not crude (toilet humour acceptable if clever)
- Rule of Three used effectively (two establish pattern, third subverts)
- Comedy balances serious moments: timing matters
- Character-driven humour (funny BECAUSE of who this kid is, not generic jokes)

VILLAIN/OBSTACLE QUALITY:
- Obstacles require ingenuity to overcome: not solved too easily
- Villain (if present) is memorable, scary, and/or funny: ideally both
- Multiple obstacles pile up before eventual success
- Solutions come from the child's resourcefulness, not coincidence

AUTOMATIC FAILS

- Adult rescues kid or solves main problem for them
- Adult problems as focus (divorce proceedings, unemployment stress, mortgage)
- Graphic violence, death described in detail, or sexual content
- Romance as primary plot driver (crushes fine, not central focus)
- Hopeless or cynical ending: kids need to believe they can affect the world
- Condescending tone: talking down to readers or over-explaining
- Protagonist consistently acting like a mini-adult (therapist-speak, adult reasoning)
- Reading level consistently above FK 7.0 (too hard) or below FK 3.0 (too simple)

ACCEPTABLE IMPERFECTIONS

- Some longer sentences (20-25 words) if context clear and they serve rhythm
- Slightly advanced vocabulary if naturally contextualised
- Brief scary/sad moments if resolved with hope
- Adult guidance if kid still ultimately solves problem
- Some suspension of disbelief in kid capabilities (genre convention: kids are slightly more capable than real life)

RED FLAGS TO INVESTIGATE

- Protagonist passive, waiting for adults to act
- Adult character solves central problem
- Romance subplot dominating story focus
- Dark tone without redemption or hope
- Vocabulary consistently above grade 6 level throughout
- Sentences averaging over 20 words across multiple paragraphs
- Talking down or over-explaining (treating reader as younger than 8)
- Stakes too adult (financial ruin, romantic betrayal, political intrigue)
- No humor or lightness anywhere in the chapter
- Themes lectured rather than smuggled through story
- Dialogue sounds adult: kids using words like "consequently," "nevertheless," "regarding"
- No physical comedy, no sensory details kids would notice, no fun
```

## Continuity Rules

```
TOP 5 CONTINUITY PRIORITIES
1. Friendship dynamics: Who's friends with whom, conflicts and reconciliations tracked
2. Kid capabilities: What 8-12 year old can realistically do. skills don't appear arbitrarily
3. School/home details: Grade level, teachers, family structure, house/apartment described consistently
4. Emotional logic: Fear, excitement, anger progress believably for child psychology
5. Small promises kept: If kid says "I'll do it," either they do or there's reason they don't

GENRE-SPECIFIC TRACKING
- Friendship status: Best friends, frenemies, bullies, crushes: relationships shift but logically
- School details: Grade, teacher names, classroom setup, subjects
- Family structure: Parents, siblings, pets: who lives where
- Neighborhood geography: School proximity, hangout spots, boundary kids can reach alone
- Abilities and knowledge: What kid knows how to do: bike riding, swimming, reading level
- Possessions: Special objects (skateboard, journal, pet) important to kid
- Fears and worries: Specific anxieties don't vanish overnight
- Physical details: Height, appearance as relevant to plot (taller than friend, wears glasses)

ACCEPTABLE INCONSISTENCIES
- Minor background details about peripheral characters
- Exact classroom layout if not plot-critical
- Weather or season if not driving story

CRITICAL CONSISTENCY
- Friend group composition: who's in/out, why
- Character's grade level and age (8-12 range)
- What kid can/can't do unsupervised based on parental rules
- Family situation: parents together, divorced, single parent established early
- School name, neighborhood, general setting
- Pet names and characteristics if present
- Sibling ages and relationships
- Character's main fear or worry
- Promises made: kid either keeps or story addresses breaking them
```

## Character Rules

```
CHARACTER CONSISTENCY PRIORITIES
1. Age-appropriate psychology: Thinks, feels, reasons like 8-12 year old. not mini-adult
2. Agency and competence: Solves own problems, has skills, takes action
3. Relatable flaws: Makes mistakes, gets scared, acts selfishly sometimes. still likable
4. Growth through experience: Learns without being preached at
5. Friendship capacity: Peer relationships central. how kid relates to other kids

GENRE-SPECIFIC CHARACTER ELEMENTS
- Age 8-12: Reader relates to protagonist at or slightly above their age
- Active problem-solver: Doesn't wait for adults: makes plans, takes action
- Realistic capabilities: Can do kid things well (bike, investigate, build, create)
- Social awareness: Peer relationships, popularity, fitting in matter enormously
- Family relationships: Parents/siblings present, imperfect, important
- Specific fears: Dark, being left out, embarrassment, failure: kid-scaled
- Humor sense: Notices funny things, makes jokes, uses humor to cope
- Passion/interest: Something kid cares deeply about: science, art, sports, animals

★★★ CHARACTER FROM REAL PEOPLE ★★★

Look for your characters everywhere, in real people:
- The key is that someone makes an impression on you: sticks in your mind. Then start creating an imaginary life for them. What if this person had a secret? What if their strangest habit was taken to an extreme?
- A brief encounter can spark a whole character. Someone's voice, their appearance, their odd habit: these fragments become starting points. Embellish them, combine traits from different people, invent backstories
- Listen to friends' stories and anecdotes. Something said in passing, or years ago, might contain the seed of a character. A friend's childhood memory about giving a lift to a smelly stranger becomes the starting point for an entire book
- Be observant everywhere: on buses, park benches, in shops. Watch how people walk, how they speak, how they read a newspaper. All of these small details help you form characters. You're not starting from scratch because you already have a real starting point
- THE CARTOON TRICK: Ask yourself: would this person work as a cartoon character? Characters need a definite look, sound, and memorable traits. If you can imagine them being drawn with instantly recognisable features, they'll be memorable on the page too
- Combine: take the defining qualities from two or three real observations and combine them into a completely new character. Real life mixed with your imagination creates something memorable

★★★ THE HERO'S HEALING JOURNEY ★★★

Your hero should be relatable but NOT bland. find something interesting about them:
- Include something in your hero's life that needs healing. A break in the family. Difficulty making friends. Being bullied or picked on. Craving a parent's love. This simple emotional objective powers the story and drives it to a satisfying conclusion
- Heroes often have straightforward names: simple, memorable, ordinary. The hero should be an everyman character readers can imagine being, while living in circumstances that are extraordinary or specific enough to be interesting
- THE PARENT PROBLEM: Many children's authors remove one or both parents to free the child for adventure. Without parental safety nets, the child must act on their own. Consider: staying with relatives, parents away, a disconnect from the family that opens the door to adventure
- If removing parents, do it quickly, early, and without dwelling on it. An absurd method (trampled by a zoo escape, swallowed by a sausage machine) is less upsetting than a realistic one. There's no emotional attachment to lose if the departure happens on page one
- Keep one special relationship. a grandparent, an uncle, a mentor figure. who provides warmth but doesn't solve the hero's problem for them
- MULTIPLE HEROES: Your hero need not be singular. A gang of children stuck together, or a child-and-adult double act, creates natural dynamics: they can argue, reconcile, wind each other up, and make each other laugh. If you choose to lose one of them later in the story, it will hit hard

★★★ VILLAIN CRAFT ★★★

Villains are super important. Villains POWER the story:
- Think about it: a hero or heroine is only really reacting to what the villain is doing. Without a worthy villain, your hero is just having a nice day
- Think about what your villain WANTS and make it something children find appalling. Turning puppies into a fur coat. Eating children's pets. Stealing their teeth. Make it simple, relatable, and horrifying to a child
- SCARY PLUS FUNNY: Villains should be scary, but add humour too. A teacher who picks up children by their pigtails and throws them out the window is terrifying AND hilarious. If harm is coming to children in the story, find something comic or surreal to soften it
- CHILDREN SEEING THROUGH ADULTS: Think about the moment as a child when you realised grown-ups could be hypocritical and deceitful. A villain who is seen as wonderful by all the adults. a pillar of the community. but the CHILDREN can see through them? That's exciting. Only the children can bring this person to justice
- NAMING YOUR VILLAIN: The name should hint at villainy without giving the game away. Combine words: truncheon and bull. Use a thesaurus for synonyms of "rotten" or "evil." Something a bit off, something memorable, something that belongs uniquely to your character
- LEVELS OF VILLAINS: Consider multiple villains at different levels. A main villain with comic henchmen creates variety and relief. The henchmen provide comic moments while the main villain maintains real menace
- ESTABLISH VILLAIN CREDENTIALS EARLY: Let the villain do something truly villainous at the start. This establishes their threat and makes the reader fear for the hero throughout

CHARACTER ARCS MUST
- Show growth through experience: trying, failing, trying differently
- Demonstrate learning empathy, courage, responsibility without preaching
- Maintain kid perspective throughout: not suddenly thinking like adult
- Face consequences for choices: actions have results
- Build relationships through shared experiences
- Overcome fears through gradual exposure and support
- Make mistakes and recover: failure teaches

TRACK
- Protagonist age (8-12) and grade level
- Special skills or talents: what kid is good at
- Main fear or worry: public speaking, dark, being alone
- Best friend(s): names, personalities, relationship history
- Family structure: who lives with whom
- What kid wants most: acceptance, adventure, understanding
- Specific interest or passion: drives motivation
- Growth areas: what kid needs to learn (confidence, kindness, courage)
```

## Arc Rules

```
ACT I (Chapters 1-10): Ordinary World and Inciting Incident

START LATE, START STRONG:
- Start your story as late into the action as possible. There is no need to set things up in great detail: trust your reader
- You don't need to see a character entering a shop, walking to the counter and saying hello. Overwriting the opening is the fastest way to lose a child reader
- If you have an amazing action scene planned for chapter three, consider making it chapter one. Fill in backstory later, once the reader is hooked
- Children have a million other things they could be doing. Grab them immediately

THE INCITING INCIDENT:
- An inciting incident is an event at the beginning that gets the engine running: an arresting image that draws readers in
- Don't overload the start with backstory. Instead, begin with a discovery, a shocking image, an unexpected event. A biscuit tin full of priceless jewels. A grandfather on a church roof believing he's in wartime. These are images that make a reader need to know more
- Feed backstory in AFTER the hook, gradually, as the story progresses

- Ch 1: Hook: protagonist in action showing personality and problem. Arresting image or incident that demands attention
- Ch 2-3: Ordinary world: school, home, friends, routines established (revealed through story, not exposition)
- Ch 4-5: Inciting incident: problem appears or adventure opportunity
- Ch 6-8: Initial attempts: kid tries to handle problem, complications arise
- Ch 9-10: Commitment: protagonist decides to tackle problem despite fears
- Purpose: Introduce kid protagonist, their world, friends, and problem that starts adventure
- Ends with: Commitment to solving problem or embarking on adventure

MIDPOINT (Chapter 15): False Victory or Major Setback
- Situation changes dramatically: seems solved but isn't, or gets much worse
- Friendship tested, plan seems to work then fails, or new information changes everything
- Tonal shift: From "I can do this" to "this is harder than I thought"

ACT II (Chapters 11-23): Rising Complications and Growth
- Ch 11-14: Pursuing solution: kid takes action, some success
- Ch 15: MIDPOINT: major development shifts situation
- Ch 16-18: Complications increase: more obstacles, friendship tensions
- Ch 19-21: Things worsen: plans fail, mistakes made, consequences mount
- Ch 22-23: THE "ALL IS LOST" MOMENT—comes about two-thirds through the story. Make the reader think it's all over—the hero cannot come through. This is vital because without it, the story chugs along without enough tension. Take the ground away from the reader—they will be intrigued and want to read on
- Purpose: Obstacles multiply, friendships tested, kid learns lessons through trying
- Ends with: Lowest point: failure, friendship break, or major setback. It looks impossible

ACT III (Chapters 24-30): Climax and Resolution
- Ch 24-25: New approach: using what learned, different strategy
- Ch 26-28: Climax: confronting problem/bully/challenge with courage
- Ch 29: Resolution: problem solved through kid's agency and growth
- Ch 30: New normal: friendship repaired, confidence gained, hint of next adventure
- Purpose: Kid uses lessons learned to solve problem, repair friendships, grow
- Ends with: Success (possibly bittersweet), growth clear, hope for future

THE BIG FINISH. TYING THREADS TOGETHER:
- The most satisfying stories link together as many threads as possible at the end. Everything should be resolved
- If the hero insulted someone in chapter two, include a moment of apology near the end. If the opening line establishes a problem ("Dennis was different"), the closing line should show how the journey has changed things ("The world felt different")
- Consider the ELEMENT OF SURPRISE right to the end. Maybe you kill off a character no one expected. At a moment of high drama, add unexpected comedy. Keep surprising the reader: surprises make your story memorable

GENRE PROMISE
- Kid protagonist (8-12) with agency solving own problems
- Age-appropriate challenges: school, family, friends, neighborhood
- Friendship central to story
- Adults present but not rescuing kids
- Humor and heart balanced
- Adventure or discovery elements
- Emotional honesty: fears, excitement, disappointment real
- Growth without preaching: lessons through experience
- Hopeful ending: kid empowered, future bright
- Safe but not sanitized: real problems, appropriate solutions

REQUIRED CHECKPOINTS
- Ch 3: Protagonist's ordinary world, friends, problem previewed
- Ch 8: Inciting incident clear: what kid needs to solve/achieve
- Ch 10: Protagonist commits despite fears or obstacles
- Ch 15: Major development: seems solved but isn't, or gets worse
- Ch 20: Friendship at stake or tested significantly
- Ch 23: Lowest point: biggest failure or setback
- Ch 28: Climax: kid confronts challenge using growth
- Ch 30: Hopeful resolution: growth evident, friendships solid

PACING CHECKPOINTS
- Act I: Brisk setup, problem clear quickly
- Act II: Obstacles escalate but small victories along the way
- Act III: Fast-paced climax, satisfying resolution
- Chapter endings: Mini-cliffhangers or questions keep pages turning
- Humor beats: Regular lighter moments relieve tension
- Emotional beats: Allow processing fear, excitement, disappointment
- Action beats: Something happening most chapters: movement, discovery, conversation
- Friendship beats: Peer interaction every few chapters minimum
```

## Timeline Rules

```
TIME SCALE
- Total story duration: Weeks to school year (2-9 months typical)
- Chapter time span: Days to week: keeps momentum while allowing emotional processing
- Time progression: Linear: straightforward chronology suits young readers

GENRE-SPECIFIC TEMPORAL RULES
- School calendar structures time: semesters, breaks, summer vacation natural markers
- Kid schedules matter: school days differ from weekends
- Seasons create variety: winter holidays, spring break, summer freedom
- Friendship conflicts resolve faster than adult relationships: days to weeks
- Projects and problems kid-scaled in time: science fair weeks away, not months
- Bedtimes, school hours, meals create daily rhythm
- Major events anticipated: birthday, field trip, performance loom large
- Kid time perception: waiting one week feels eternal

TRACK CAREFULLY
- Day of week: school day vs. weekend affects what's possible
- Time until anticipated event: countdown creates excitement/dread
- Season and weather: affects outdoor activities kids can do
- School calendar: when breaks occur, how long
- Time since friendship fight or other emotional event
- Age-appropriate sleep/activity patterns: 8-12 year olds need 9-11 hours sleep
- After-school activities: sports, lessons on specific days

FLEXIBLE
- Exact dates unless birthday or specific holiday
- Minor daily routine timing
- Background character schedules
```

## Genre-Specific Craft Techniques

Middle-grade fiction has the most demanding voice problem in
the catalogue: the prose must be readable by a strong eight-
year-old and engaging to a twelve-year-old, while remaining
emotionally honest enough that the adult buyers (parents,
teachers, librarians, gift-givers) recognise the writer as
trustworthy with the reader. The genre's craft is about
calibration rather than simplification — what the reader can
process at this age, what they need permission to feel, what
they can carry alone, what the book holds for them. The
techniques below are the line-level decisions that distinguish
middle-grade that earns the shelf from middle-grade that sounds
like an adult writing down to a child.

### The Child's-Eye Camera

Writing from a perspective that sees the world as a child
genuinely does — where adults are mysterious creatures whose
priorities make no sense, school politics are existential,
small injustices feel monumental, the unfair allocation of dessert
is genuine moral injury, and a Wednesday afternoon contains
more weather than a year of adult Tuesdays. This is not about
dumbing down; it is about emotional accuracy. The child's
perspective is not limited — it is differently prioritised.
The middle-grade narrator notices what an adult narrator
overlooks (the smell of the school corridor, the precise
location of the crack in the playground asphalt, the exact
distribution of who sits where at lunch) and overlooks what
adult narrators foreground (mortgage rates, marital subtext,
career stakes, geopolitical news). The technique requires that
the writer trust the camera: do not have an adult narrator
intervene to explain what the child sees, do not have the
narrator step outside the child's frame to wink at the adult
buyer. Test: pick a paragraph at random and ask whether the
sensory selection, emotional register, and concerns belong to
this specific child of this specific age. If the paragraph
could have been written from anyone's perspective, the camera
has not been engaged.

### The Found Competence Arc

The protagonist discovering abilities they did not know they
had — not through magical gifts or sudden destiny but through
courage, cleverness, persistence, and the small daily decisions
that, accumulated, transform what they can do. Middle-grade
readers need to see characters who start uncertain and become
capable through effort, because they are themselves at the age
where they are first noticing this is how capability actually
forms. The competence must be earned, not bestowed: the
narrative must show the practice, the failures, the second
attempts, the moment of realising that what was hard last week
is now manageable. Even in fantasy or speculative settings
where a magical talent is the inciting incident, the talent's
mastery should follow the same earned arc — the gift opens the
door, but stepping through it requires the work the reader has
been watching the protagonist do. The technique fails when
competence arrives at a moment of plot need without preparation
(the chosen-one-knows-now reveal, the power-awakened-by-love
shortcut, the crisis-trigger sudden ability). The reader at
this age is unforgiving of unearned capacity; they sense
shortcuts because they themselves are not allowed to take them.

### The Best Friend Dynamic

Friendship as the primary relationship engine. The best friend
in middle-grade fiction serves the role that the love interest
serves in adult fiction — emotional anchor, mirror, source of
both comfort and conflict. The friendship is the relationship
the book is about, even when the plot is about something else
(the missing artefact, the haunted house, the family crisis,
the magical academy). Friendship betrayal and reconciliation
can be as powerful as any adult romance, and the genre's most
durable books turn on a friendship's near-loss and recovery.
The dynamic must be specific: this exact friend, with this
exact history, with these exact running references and
rivalries and shared enthusiasms. Generic best-friend characters
(the supportive sidekick whose function is encouragement, the
comic-relief whose role is to make the protagonist look
serious) are the failure mode. Test: can the writer write a
chapter from the best friend's perspective and have it sound
like a different person, not the protagonist with a different
name? The friendship's evolution is also structural: friends
who were close at chapter one should be different by chapter
twenty, in ways the book has earned through specific events.
The arc may end in deeper closeness, productive distance, or
the recognition that this particular friendship is moving into
a new shape; what cannot happen is for the friendship to be
exactly what it was at the start.

### The Adult Obstacle

Adults who create problems through misunderstanding, rigidity,
distraction, or absence — without being villainous. Middle-
grade fiction requires that children solve their own problems,
which means adults must be imperfect allies at best: the
parent whose attention is partly elsewhere, the teacher whose
rules are correct in general but wrong in this case, the
grandparent whose love is real but whose understanding is a
generation off, the older sibling whose advice was right
yesterday but is wrong today. The trick is making adult
characters sympathetic even when they are obstacles — readers
of this age have parents, teachers, grandparents, and older
siblings, and they recognise oversimplification immediately.
The cartoon-bad parent and the saintly mentor are equally
inauthentic to the reader's actual experience. The strongest
middle-grade adults have visible interior lives the
protagonist partially registers: the protagonist sees that the
parent is tired, that the teacher is dealing with something the
classroom does not know about, that the grandparent has been
having a hard week. These observations, partially understood,
are the genre's signature emotional layer — the reader is
beginning to see adults as people, and the prose honours that
discovery without making it the protagonist's burden to manage.

### The Emotional Vocabulary Builder

Using narrative to help young readers name and understand
complex emotions — jealousy, grief, moral ambiguity, divided
loyalty, the particular shame of having been wrong, the
specific dread of having to apologise — without being
didactic. The character experiences the feeling first; the
understanding follows. Show the sensation in the body (the
chest that has gone tight, the appetite that has disappeared,
the sound of the world that has dimmed), the thought in the
mind (the protagonist's specific phrasing of what is wrong,
typically inaccurate), and then let the character — and the
reader — find the word, sometimes through a third party, more
often through the experience itself. The technique calibrates
the reader's language for their own interior life. The trap
is the explanation: a narrator who steps in to define
"jealousy" or to teach the reader what they are reading about
breaks the trust the technique builds. Trust the reader to
find it. Test: read the manuscript's most emotionally complex
scenes and ask whether the prose has named the feeling for the
reader or has shown the feeling in detail clear enough that
the reader will name it themselves. The latter is the genre.

### The Hope Discipline

Middle-grade fiction has a structural ethical requirement
distinct from any other genre in the adult catalogue: hope
must be present, even in dark material. The genre handles
death, divorce, bullying, illness, abandonment, family
violence, identity formation, and the slow recognition that
the world is not as one was told it would be — and it must
handle these honestly, without softening the truth, while
ensuring that the reader closes the book with somewhere to
stand. This is not the same as a happy ending; many of the
genre's strongest books end in loss, change, departure, or
the new equilibrium that follows what cannot be undone. The
hope discipline is more specific: the protagonist arrives at
the ending with agency, perspective, and a future they can
imagine themselves into, even if that future is harder than
the past. The reader at this age is encountering many of these
themes for the first time in literature, and the writer's
ethical task is to be honest about what hurts while leaving
the reader equipped to keep reading, keep hoping, keep
showing up for their own life. Test the ending: does the
protagonist have something to do tomorrow? Some sense of who
they are becoming? Some named relationship to the world that
the book has changed, in the protagonist's recognition,
irrespective of the plot's outcome? If the answers are yes,
the discipline has been observed. If the ending leaves the
protagonist without standing — and the reader without it —
the book has not yet earned its shelf.

### Middle Grade AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the adventure was just beginning" | Show the specific first adventure moment — what changes in the room, what the protagonist understands now that they did not five minutes ago |
| "she'd never felt so brave" | Show the specific brave action and the specific physical experience of acting despite fear |
| "the friends stuck together" | Show the specific loyalty test the friendship has just survived |
| "a mystery that only kids could solve" | Show the specific advantage kids have — what they noticed, where they could go, what adults dismissed |
| "the bully was mean" | Show the specific bullying action; "mean" is a word the genre has lost the right to use as summary |
| "grown-ups just didn't understand" | Show the specific misunderstanding through dialogue or action |
| "she found strength she didn't know she had" | Show the specific strength in action, named in the body, with the protagonist's surprise registered |
| "the magical world was amazing" | Show ONE specific amazing detail through the protagonist's particular eye |
| "a lesson was learned" | Show the lesson through the final action, not as a statement; the genre cannot afford this line |
| "the power of friendship" | Show the specific act of friendship — what was done, by whom, at what cost |
| "it was the best day ever" | Show what makes it the best through specific moments and the protagonist's specific awareness |
| "her heart was racing" | Show what the racing feels like in the specific body — the throat, the hands, the shortness of breath |
| "the grown-ups exchanged a look" | Show the specific look and what the protagonist correctly or incorrectly interprets from it |
| "she had a bad feeling" | Show what specifically signals the wrongness — the change in the room, the parent's silence, the door that was not closed before |
| "they laughed and laughed" | Show what they were laughing at and what the laughter does to the room |
| "his eyes lit up" | Show the specific change in the face — the way his shoulders moved, what he did with his hands, what he said next |
| "she was wise beyond her years" | Cut the line; if she is, show it in action; "beyond her years" is the genre's most condescending phrase |
| "the truth would set them free" | Cut; show what the truth changes specifically, in this scene, for these characters |

## Genre-Specific Revision Rules

Six revision passes specific to middle-grade fiction, each with
a single question, run cover-to-cover before the next begins.
Middle-grade has the strictest revision discipline of any
fiction category: the prose is being read by readers learning
to read with sophistication, evaluated by parents and
teachers, recommended by librarians whose recommendations form
careers, and (often) read aloud by adults to younger
siblings. A single tonal slip — the condescending line, the
adult joke, the violence that exceeded the registered audience
— costs more than the same slip in adult fiction. The passes
below are ordered to surface the highest-stakes failures first
(age-appropriateness, voice) before the relational and
structural questions.

### Pass 1: Age-Appropriateness Audit

Review all content for age-appropriateness for the registered
audience (typically 8–12, with a narrower window for the
younger or older end of MG). Check language complexity,
thematic intensity, and emotional content against the genre's
norms. Violence should be present only with purpose and
without graphic detail; consequences may be implied or described
in restrained terms but the prose should not linger on bodily
harm. Romantic content should be limited to crushes, first
awareness of attraction, and the embarrassment of being seen
as one of the kids who likes someone — physical intimacy
beyond hand-holding does not belong in this register. Death
can be addressed (and is, in many of the genre's best books)
but should be handled with care, on-the-page consequences for
the survivors, and continuity of hope. Substance use, sexual
content, swearing beyond the mild register, and explicit
trauma depiction belong to YA, not MG. Build a flag-list of
moments where the manuscript pushes the boundary, and either
revise toward the centre or document the choice — published
MG occasionally pushes the upper edge, but the choice should
be deliberate and specific to what the book requires.

### Pass 2: Voice Authenticity Check

Read all dialogue and internal monologue aloud. Does the
protagonist sound like a real child of the registered age,
not a miniature adult and not a sentimentalised version of
childhood? Check vocabulary level: the protagonist should not
deploy words they would not actually know (the eight-year-old
who uses "subterfuge" without authorial flag), but should not
be artificially restricted to a vocabulary smaller than real
children possess. Check thought-pattern: real children make
specific, often surprising connections (this smells like the
hallway at the dentist; this person sounds like Aunt Beverly
when she is about to lie); their interior is concrete, sensory,
and digressive in ways adult interiority typically is not.
Verify that adult characters do not explain things children
already know for the reader's benefit — exposition of school
mechanics, family relationships, basic vocabulary — that
hand-holding is the failure mode the second-read reader
notices first. Test: pick three internal-monologue paragraphs
spaced across the book; could they have come from this
specific child, or could they come from any child in any
middle-grade book? If the latter, voice has not been earned.

### Pass 3: Pacing for Young Readers

Chart chapter lengths and cliffhanger placement. Middle-grade
chapters should be shorter than adult chapters — typically
8–15 pages, occasionally up to 20 for older MG, occasionally
down to 4–6 for early MG or chapter-book crossover. Every
chapter should end with a reason to turn the page: a question
unanswered, an event in motion, a discovery just made, a
decision pending. Check scene-level pacing: no individual
scene should linger past the protagonist's actual emotional
beat. Adult fiction can hold a moment for a paragraph past its
peak; middle-grade has approximately one beat of grace before
the reader's attention has moved on. Verify the structural
beats are placed where young readers expect them: an inciting
incident in the first chapter (no later than the second),
escalating stakes by the quarter mark, mid-book reversal,
darkest moment around three-quarters, climax with both
external and internal resolution. Where these are absent or
misplaced, the book will read as drifting to a young reader
even if the prose is otherwise strong.

### Pass 4: Emotional Complexity Balance

Verify that the manuscript respects young readers' intelligence
while remaining emotionally safe. Complex themes — death,
divorce, bullying, identity, illness, family rupture, the
loss of a friendship, the discovery that a beloved adult is
fallible — should be explored honestly, with the understanding
that the reader may be encountering these ideas for the first
time in literature, but the prose must not retreat into
abstraction the moment the material gets hard. Specificity is
the standard: the grief is specific (this child, this person
who has died, this gap in this house), the bullying is
specific (this exact behaviour, on this specific Tuesday, in
this specific corridor), the family change is specific (these
two parents, this house, the practical question of where the
school bag will live now). Hope must be present, even in dark
moments — see the Hope Discipline technique above. Test the
ending against the difficulty of the middle: if the manuscript
has gone to a hard place, the ending must give the reader
somewhere to stand without erasing what occurred.

### Pass 5: Didacticism Detection

Scan for moments where the narrative teaches a lesson rather
than telling a story. Middle-grade fiction should illuminate
moral questions without answering them on behalf of the
reader. If any character delivers a speech that sounds like a
parent's lecture (the adult who explains kindness, the
narrator who instructs the reader on inclusion, the wise
mentor who summarises the theme), rewrite it as lived
experience instead. The tell is paragraph rhythm: didactic
passages tend to slow into measured, sentence-equal weight
that does not sound like the surrounding voice. The fix is to
return the meaning to action, demonstration, and consequence
— the kindness shown rather than asserted, the inclusion
practised rather than discussed. Modern MG readers — and the
parents and teachers reading alongside them — are vocal in
their detection of message-fiction; the genre's reputation in
recent years has improved precisely because the best
practitioners trust their readers to draw the lesson themselves.
Flag every paragraph that could be removed without changing
plot, character, or scene atmosphere: those paragraphs are
typically the didactic ones the prose has not yet noticed it
is carrying.

### Pass 6: The Adult-Reader Audit

Middle-grade fiction has a dual readership the writer must
not forget: the child reading the book, and the adult who
selected, purchased, recommended, or read it aloud. The genre's
strongest books work simultaneously for both — the child finds
the surface story, the adult finds the literary craft and the
emotional honesty that makes the book worth their time as
well. Run a final pass with the adult reader specifically in
mind: are there layers of meaning, allusion, observation, or
craft that reward the adult attention without condescending
to the child reader? Conversely, are there moments where the
prose seems to wink at the adult over the child's head — the
reference the child cannot get, the joke that requires adult
context, the irony that depends on the reader knowing what the
character does not? The wink-over-the-head moves are the
genre's most-flagged adult-author tic, and they break trust
with the primary reader. The best MG writers (Kate DiCamillo,
Christopher Paul Curtis, Jacqueline Wilson, Katherine Rundell,
Jason Reynolds) achieve dual-readership by writing well, not
by smuggling in adult content — the adult reader is rewarded
by the same craft and emotional truth the child receives. Test:
mark every line that depends on adult context to land. Does
the line work for the child reader independently? If yes, it
can stay. If it requires the adult to "get" it, the line is
working against the book.

## Names & Patterns to Avoid

### Forbidden Patterns
- **Talking down to the reader**. Middle-grade readers are perceptive, passionate, and intolerant of condescension; respect their intelligence
- **The precocious child**. Characters who speak and think like adults in children's bodies are wish fulfilment for adults, not authentic for children
- **Adults who conveniently disappear**. Parents and teachers must have credible reasons for being absent or unhelpful; "they just didn't listen" is lazy
- **Consequence-free adventure**. Actions must have proportionate consequences; characters who face danger without cost teach the wrong lessons

### Cliché Setups to Avoid
- The orphan who discovers they are secretly special (unless the specialness is genuinely earned)
- The school bully who is one-dimensionally cruel (give them a reason, even if it does not excuse their behaviour)
- The wise mentor who provides all the answers (mentors should guide, not solve)
- The "chosen one" narrative that removes agency from the protagonist

### Naming Considerations
- Names should be easy to read aloud. many middle-grade books are read by parents to children
- Avoid names that require pronunciation guides unless the difficulty is part of the character's story
- Character names should be distinct from each other in sound and length to help young readers track the cast
- Consider diversity in naming. the readership is diverse and names should reflect the world young readers actually live in

## Comp Titles

Middle-grade's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Charlotte's Web* — E.B. White (1952): the literary-MG foundation.
- *A Wrinkle in Time* — Madeleine L'Engle (1962): MG-fantasy benchmark.
- *Bridge to Terabithia* — Katherine Paterson (1977): MG-emotional-truth benchmark.
- *Holes* — Louis Sachar (1998): MG literary commercial benchmark.

### Contemporary (current best-in-class)

- *Wonder* — R.J. Palacio (2012): contemporary MG benchmark; broad commercial-literary appeal.
- *The One and Only Ivan* — Katherine Applegate (2012): MG novel-in-verse with animal-narrator.
- *El Deafo* — Cece Bell (2014): MG graphic novel; Newbery Honor.
- *New Kid* — Jerry Craft (2019): MG graphic novel; Newbery Medal.
- *Front Desk* — Kelly Yang (2018): contemporary MG with immigrant-experience.
- *Fish in a Tree* — Lynda Mullaly Hunt (2015): MG with neurodivergent protagonist.
- *Aru Shah and the End of Time* — Roshani Chokshi (2018): Hindu-mythology MG-fantasy.
- *Tristan Strong Punches a Hole in the Sky* — Kwame Mbalia (2019): West-African-mythology MG.

## Cover Design Specifications

### Recommended Visual Styles
- **Illustrated**. ESSENTIAL for middle grade; dynamic, professional illustration is the genre standard and a non-negotiable expectation from readers, parents, and retailers; the style ranges from painterly to graphic depending on tone
- **Graphic**. Bold, stylized graphic illustration with clean lines and strong shapes; suits contemporary and humour-driven MG; slightly older-skewing than painterly illustration
- **Cinematic**. Dramatic illustrated compositions with film-poster energy; suits epic fantasy, adventure, and action-driven MG; dynamic angles, dramatic lighting, rich environments
- **Minimalist**. Clean design with a single bold illustrated element against a vivid background; less common but can stand out; suits quirky, voice-driven MG with a strong concept

### Genre Cover Aesthetics
- **Styles:** Dynamic compositions with characters in action or mid-discovery, dramatic angles (looking up at something towering, peering into something mysterious), rich environmental storytelling in the background, characters with expressive faces and body language, sense of movement and energy, worlds that extend beyond the frame inviting exploration
- **Colours:** Bright, bold primary colours for younger MG (vivid blues, reds, yellows), slightly muted and sophisticated palettes for older MG (teals, deep purples, burnt oranges), magical golds and glowing effects for fantasy, earthy and natural tones for realistic fiction. the palette should feel energetic and adventurous, never drab or muted to the point of looking adult
- **Elements:** Protagonist(s) aged 10-13 front and centre, magical or mysterious objects (keys, maps, glowing artefacts), adventure settings (forests, castles, underground tunnels, strange buildings), animals and creatures, friendship groups in action together, portals or doorways suggesting hidden worlds, school settings made extraordinary, weather and environmental drama (storms, snow, starlight)
- **Typography:** Bold, fun, and often integrated into the illustration; title frequently the LARGEST element; custom lettering that reflects the story's tone (dripping letters for horror, glowing for fantasy, cracked for adventure); 3D effects, textures, and colours that match the illustration; author name clear but secondary; the font itself should feel like part of the story's world

### Subgenre Variations
- **MG Fantasy/Adventure**. Rich, detailed painted illustrations; magical lighting effects; epic scale; characters dwarfed by or confronting something larger than themselves; darker, more dramatic palette acceptable
- **MG Contemporary/Realistic**. Slightly more graphic illustration style; relatable everyday settings made vivid; characters in recognisable modern clothing; warmer, friendlier palette
- **MG Humour**. More cartoonish proportions; exaggerated expressions; bold, flat colours; physical comedy visible in the illustration; typography doing heavy comedic lifting
- **MG Horror/Spooky**. Darker palette with strategic bright accents; creepy-but-not-traumatising imagery; shadows and mystery; green and purple accents; characters looking scared but brave
- **MG Mystery**. Magnifying glasses, footprints, shadowy figures; slightly moodier lighting; puzzle elements in the design; characters investigating or discovering
- **MG Science Fiction**. Futuristic elements, space imagery, technology; bolder, more graphic style; neon accents against darker backgrounds; sense of wonder and discovery

### Market Positioning
Middle grade covers must appeal to TWO audiences simultaneously: the child reader (aged 8-12) who will be attracted by the illustration, and the adult buyer (parent, teacher, librarian) who will assess quality and age-appropriateness. The illustration must look professional and dynamic. children want to read "up" and will reject covers that look too young or too simple. At Amazon thumbnail size, the character(s), a sense of the story's world, and bold readable typography must all register. The title is often the single most prominent element. Series covers must be instantly recognisable as a set through consistent illustration style, typography treatment, and design framework while each volume feels distinct. The cover should make a child think "that looks like an ADVENTURE". not "that looks like a lesson."

### Cover Design DON'Ts
- No photorealistic imagery or adult photography. illustrated covers are a non-negotiable genre standard for middle grade; photorealistic covers signal YA or adult fiction
- No dark, horror-heavy, or violent imagery. spooky is acceptable, genuinely frightening or gory is not; the cover should excite, not traumatise
- No romance imagery (couples, hearts, kissing). romance is not central to MG and romantic covers will alienate the target audience
- No overly simple or childish illustration. children aged 8-12 want to read "up"; a cover that looks designed for 5-year-olds will be rejected; the illustration should feel aspirational
- No tiny, sophisticated, or minimalist typography. the title must be BOLD, large, and fun; adult literary-fiction typography signals the wrong audience entirely
- No adult characters as the primary cover figures. the protagonist should look 10-13 and be the visual focus; adult figures should be secondary or absent
- No drab, muted, or corporate colour palettes. middle grade covers need energy and vibrancy; grays, beiges, and muted tones feel like textbooks, not adventures
- No cluttered compositions without a clear focal point. children scan quickly; the cover needs one strong central image (character, object, scene) that tells them instantly what kind of story this is
