---
name: crime-fiction-genre
description: Genre-specific instructions for crime fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [mystery]
---

# Crime Fiction. Genre Plugin

## Metadata
- id: crime
- name: Crime Fiction
- icon: 🔍
- category: Fiction
- minWords: 3500
- targetWords: "4,000-4,500"
- recommendedBeatStructures: ["Thriller 12-Beat Structure", "Three-Act Structure", "Seven-Point Structure"]

## Subgenre Options
Present during setup:
- **Police Procedural**. The investigation through official channels: forensics, interviews, warrants, chain of custody; the system as both tool and obstacle
- **Organised Crime**. The criminal world from inside: hierarchies, codes, betrayals, the business of crime; the Cosa Nostra, cartels, gangs as institutions
- **Heist/Caper**. The plan, the team, the execution, the complication; crime as craft, ingenuity against security, the elegant theft
- **Courtroom Crime**. The trial as arena: evidence, testimony, legal strategy; justice weighed in the balance of procedure and persuasion
- **True Crime Style**. Fiction that reads like documentary: meticulous research, journalistic voice, the anatomy of a real-seeming crime
- **Criminal POV**. The story from the other side: the criminal's logic, their world, their rationalisation; crime as the protagonist's profession

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Steady, procedural. balance investigation momentum with character depth; the rhythm of legwork, dead ends, and breakthroughs
- Must open with: Crime scene detail, investigative breakthrough, or character under pressure. the crime has happened or is about to; the reader enters the machinery of investigation or the psychology of crime

BEATS PER CHAPTER
1. Investigation Progress. Evidence gathered, witness interviewed, or forensic detail revealed; the case moves
2. Procedural Reality. Police work, legal constraints, institutional politics shown; the system as character
3. Complication. Dead end, conflicting evidence, or new crime/threat emerges; the case resists easy answers
4. Character Pressure. Personal cost of investigation, moral dilemma, or professional conflict; the job extracts its price
5. Forward Momentum. Clear next step or revelation that propels investigation; the reader knows where things are heading next

CRIME FICTION ARCHITECTURE
- PROCEDURAL ACCURACY is non-negotiable: police work, forensics, legal process must be realistic (hierarchy, jurisdiction, warrants, evidence chain)
- The CRIME is central and detailed: murder, heist, organised crime, corruption examined thoroughly. not backdrop but engine
- MORAL COMPLEXITY defines the genre: no pure heroes or villains; shades of grey in motivation, justice, and method
- INSTITUTIONAL REALISM: bureaucracy, politics, media pressure, budget constraints, union issues affect the investigation
- PROFESSIONAL INVESTIGATORS: police, detectives, FBI, private investigators with appropriate skills earned through experience
- EVIDENCE-BASED DEDUCTION: forensics, witness statements, documentation drive conclusions. not hunches
- SOCIAL CONTEXT: poverty, addiction, racism, corruption as context for crime. crime doesn't exist in a vacuum
- POV: Third person limited (single or multiple investigators) or first person (detective's voice)

★ CRIMINAL PSYCHOLOGY ★

THE CRIMINAL IS THE HERO WHO TOOK A WRONG TURN:
- No one is the villain in their own story. criminals rationalise their actions completely
- If one thing had gone differently, they might be on the other side
- The best criminals are sympathetic AND condemnable. we understand but don't excuse
- Show the logic behind their choices, even twisted logic, even broken logic

ORDINARY CRIMINALS ARE MORE UNSETTLING:
- The killer who loves their children, pays their bills, remembers birthdays
- Mundane concerns interspersed with criminal acts create authentic dread
- The most effective criminals aren't monsters. they're people who made monstrous choices
- What makes them frightening is how close they are to everyone else

THE THIN LINE:
- Show how circumstances, desperation, or rationalisation leads to crime
- Your detective should sometimes see themselves in the criminal
- The difference between cop and criminal isn't always as clear as society pretends
- Moral complexity means the line keeps blurring

★ VICTIM CRAFT ★

THE VICTIM MUST MATTER:
- The more passionately alive the victim, the more urgently the reader needs the killer unmasked
- A victim who was vigorous, complicated, almost larger-than-life creates more investment than a forgettable nonentity
- Even if the victim is already dead when the story begins, build their portrait through testimony, flashback, and accumulated perspectives
- The victim's character often holds the key to motive. who they were determines who wanted them dead

★ METHOD & MURDER WEAPON ★

SPECIALISED KNOWLEDGE AS PLOT ENGINE:
- The method of killing should be specific and researched, not generic
- Use the method to establish alibis and complications
- Research matters. readers who are experts will catch errors
- There must be a convincing way for the criminal to cover up AND a logical way for the detective to uncover it

FORBIDDEN IN CRIME FICTION
- Amateur sleuths with unrealistic access or skills (this is not cozy mystery)
- Ignoring legal procedures or evidence rules without acknowledgment
- Convenient coincidences that solve cases without legwork
- Cardboard criminals. antagonists must be dimensional
- Police work without institutional realism (lone wolf cop with no oversight)
- Sanitised crime scenes. show reality of violence without gratuitous detail
- Cartoon villains who are evil for evil's sake
- Instant forensics (DNA in hours, toxicology overnight)
- "Cop instinct" as substitute for actual detective work
```

## Writer Craft Rules

```

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Captivation through the crime puzzle, Anticipation, Validation at procedural beats, Revelation at the solution.

VOICE & TONE
- POV: Third person limited (single or multiple investigators) or first person (detective's voice)
- Tense: Past (traditional)
- Voice: Gritty, observant, world-weary but engaged, morally complex, institutionally savvy
- Register: Adult. sophisticated vocabulary, procedural detail, the language of professionals at work

PROSE IMPERATIVES
- PROCEDURAL PRECISION: the language of investigation rendered with authority
  - Correct terminology for police work, forensics, legal process
  - Evidence chain documented. how information was discovered and verified matters
  - Institutional reality tangible. hierarchy, politics, budget constraints visible in prose
  - Crime scenes described with professional detachment. realistic but not gratuitous
- DIALOGUE AS INVESTIGATION: conversation is the detective's primary tool
  - Professional relationships reflected. rank, experience, institutional culture
  - Witness testimony rendered with psychological realism (memory is imperfect, people lie)
  - Interrogation as craft. strategy, psychology, the art of making people talk
  - What's NOT said as important as what is
- MORAL COMPLEXITY IN NARRATION: the prose refuses simple framing
  - Avoid simplistic good/evil framing
  - Character expertise shown through competent action, not explained
  - The social context visible. crime embedded in economic, racial, systemic realities
  - The narrator's own uncertainty about justice reflected in the prose
- THE BODY OF EVIDENCE: physical detail that builds the case
  - Crime scenes rendered with the detective's professional eye
  - Forensic detail specific enough to matter, not so dense it becomes textbook
  - The emotional weight of evidence. a photograph, a weapon, a victim's personal effects

PROSE RHYTHM MAPPING (CRITICAL. gritty, street-level, muscular)

Crime fiction prose is lean and hard. Sentences hit like fists. The
rhythm is the rhythm of the street, the precinct, the interrogation
room. direct, unadorned, propulsive. Crime protagonists ACT. The
prose reflects this: minimal interiority, maximum forward motion.

Chapter 1 prose rhythm:
- Sentence average: 10-18 words. Short and muscular. No literary
  flourishes during crime scenes or action. Longer analytical sentences
  permitted during investigation downtime, but even these stay under 25
  words.
- Dialogue density: 45%+ by word count. heavy, constant, the primary
  vehicle for information and character. Crime fiction lives in what
  people say to each other. Vernacular-authentic: cops sound like cops,
  criminals sound like criminals, witnesses sound scared or evasive.
- Interiority: minimal. Crime protagonists process through action and
  dialogue, not reflection. When internal thought appears, it is brief,
  tactical, professional. "The alibi didn't hold. He knew it. She
  knew he knew it." Not paragraphs of emotional processing.
- Procedural prose: the language of investigation rendered with
  authority. Evidence, warrants, chain of custody, forensic timelines
 . stated with professional precision, never explained to the reader.
- Tension floor: ≥6. Crime fiction opens hot and stays hot. Even
  procedural scenes carry urgency. the 48-hour clock, the brass
  breathing down necks, the next body that might drop.
- Physical grounding: every scene anchored in tactile reality. the
  weight of a service weapon, the smell of a crime scene, the sound
  of holding-cell doors. The reader is THERE, not observing from above.

SUSPECT & CLUE CRAFT
- EQUAL SUSPECT TREATMENT: the actual perpetrator receives the SAME narrative register as every other suspect. no subtly loaded descriptions that telegraph guilt
- CLUE PLANTING: hide real clues in plain sight. embed them in scenes about something else, sandwich between more dramatic moments, bury in sensory description
- RED HERRING CONVICTION: write each false lead with FULL belief it's the real answer; when debunked, provide a SPECIFIC, SATISFYING explanation
- BACKWARD WRITING PREVENTION: write each chapter as if future chapters don't exist; the investigator notices things because they're professionally relevant NOW

EVIDENCE IN DESCRIPTION
- Bury crucial evidence among mundane details. an inventory should contain the one significant item alongside a dozen unremarkable ones, presented with equal weight
- Be specific enough that details matter later. "an empty coffee cup on the left side of the desk" creates a clue; "a coffee cup" creates nothing
- Physical facts don't lie even when witnesses do. forensic details, properly described, allow the reader to draw conclusions alongside the investigator

DIALOGUE CRAFT
- Cop vernacular authentic to setting and era
- Rank affects speech: the language of command vs. the language of compliance
- Witness interviews: strategy disguised as conversation
- Gallows humour: the coping mechanism that says more about the job than any monologue
- The silence after a confession: sometimes the most powerful dialogue is none
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

CRIME CRAFT (40% of total):
- Procedural accuracy: police work, forensics, legal process realistic? (0-100)
- Moral complexity: characters flawed, justice ambiguous, no simplistic framing? (0-100)
- Evidence-based resolution: case solved through detective work, not coincidence? (0-100)
- Dimensional criminals: antagonists have comprehensible motivations? (0-100)

STORY CRAFT (30% of total):
- Institutional authenticity: bureaucracy, politics, hierarchy shown realistically? (0-100)
- The victim matters: built as a real person whose death demands investigation? (0-100)
- Personal cost: investigation extracts a visible price from the investigator? (0-100)
- Social context: crime embedded in economic, racial, systemic realities? (0-100)

PROSE QUALITY (30% of total):
- Professional detail specific and authoritative? (0-100)
- Dialogue reflects institutional relationships and rank? (0-100)
- Evidence planted fairly (reader can spot clues on re-read)? (0-100)
- Moral complexity reflected in prose (not just plot)? (0-100)

AUTOMATIC FAILS (score = 0):
- Amateur investigator with unrealistic access (not cozy mystery)
- Instant forensics without justification (DNA in hours, toxicology overnight)
- Evidence obtained illegally and used without addressing inadmissibility
- Lone wolf cop with no institutional oversight or consequence
- Cartoon villains: pure evil without comprehensible motivation
- Convenient coincidences that solve the case without legwork
- Sanitised violence in a genre that demands honest physical reality
- Simplistic morality: cops all good, criminals all bad
```

## Continuity Rules

```
CRIME FICTION CONTINUITY. WHAT TO TRACK

★ CRITICAL: DO NOT FLAG AS CONTINUITY ERRORS ★
The following are EXPECTED genre techniques:
- Suspects lying to investigators (criminals lie. that's the plot)
- Witness statements that contradict each other (conflicting testimony = clue)
- Alibis that don't hold up under scrutiny (false alibis are plot devices)
- Characters changing their story when confronted with evidence
- "Inconsistent" behaviour that reveals guilt or hidden involvement
- Evidence that points in multiple directions (red herrings are intentional)
Only flag issues where the AUTHOR made a mistake vs. characters being deceptive.

EVIDENCE STATE:
- Physical evidence: what collected, when, by whom, chain of custody, lab submission status
- Forensic results: what submitted, when expected, what returned, what still pending
- Documentary evidence: financial records, phone records, digital forensics. subpoena status
- Murder weapon/method: details consistent across all references (autopsy, scene, testimony)
- Evidence that will convict: must have been legally obtained (warrant, consent, valid exception)

WITNESS & SUSPECT STATE:
- Interview log: who interviewed when, who was present (lawyer?), what was stated
- Witness credibility: prior relationship to victim/suspect, motive to lie, corroboration status
- Suspect alibis: documented with verification status (confirmed, unverified, broken)
- Miranda warnings: given before custodial interrogation (or violation noted as deliberate plot point)
- Holding times: within legal limits (24-48 hours before charge/release)

INVESTIGATOR & INSTITUTIONAL STATE:
- Rank and authority: consistent. detectives can only do what their position allows
- Chain of command: who reports to whom, maintained across chapters
- Jurisdictional boundaries: maintained or inter-agency conflict shown when crossed
- Institutional pressure: escalating proportionally with time since crime
- Partner dynamics: trust levels, communication patterns, conflict history tracked

LEGAL & PROCEDURAL STATE:
- Warrants: what they authorise, when obtained, from which judge. each legal search traceable
- Procedural violations: who committed them, whether consequences followed
- Legal timeline: arrest → booking → arraignment → bail hearing in correct sequence
- Defence attorney involvement: realistic (suspects lawyering up at appropriate moments)

FORENSIC PROCESSING TIMES (Reference):
- Autopsy preliminary: 24-48 hours / Full report: 1-2 weeks / Toxicology: 2-4 weeks
- DNA rushed: 3-7 days / Normal: 2-4 weeks / Backlogged: months
- Ballistics: 1-3 days / Fingerprints: hours to days / Digital forensics: days to weeks
- Financial records: days (subpoena required) / Phone records: days to weeks
```

## Character Rules

```
CRIME FICTION CHARACTER TYPES

THE INVESTIGATOR:
- Professional identity: department, specialisation, rank, jurisdiction, years on the job
- Institutional reality: solve-rate pressure, budget constraints, political interference, media scrutiny
- Partner dynamics: trust built over years, tested under pressure; partnership is the genre's key relationship
- The cost of the job: divorce, addiction, PTSD, cynicism, physical toll, isolation. these are not clichés if earned
- Moral complexity: cutting corners to catch bad guys, letting small crimes slide for bigger ones, protecting partners who cross lines
- Pattern recognition from years of cases, controlled paranoia, emotional compartmentalisation, gallows humour

THE CRIMINAL:
- The Ordinary Monster: loves their children, pays bills, commits monstrous acts, returns to mundane life. frightening because of humanity, not otherness
- The Desperate: crime as perceived only option. economic desperation, protection of loved ones, survival
- The Professional: career criminal with institutional knowledge, codes, hierarchy; knows how cops work
- The True Believer: ideological motivation, believes their violence is righteous, most dangerous because of certainty
- Criminal competence: skilled within their sphere, mistakes that catch them plausible not convenient
- Internal logic that makes sense to them. may genuinely believe they're justified

THE VICTIM:
- Not just a body. a person with contradictions: ruthless but good-tempered, selfish but charismatic
- Built through testimony, flashback, accumulated perspectives. each witness reveals a different facet
- Their character holds the key to motive. who they were determines who wanted them dead
- Readers who care about the victim demand justice more passionately

SUPPORTING CAST:
- Witnesses: each with their own agenda, fear, loyalty; memory unreliable; reluctance to cooperate realistic
- Informants: complex motivations (revenge, money, deals); relationships with handlers fraught
- Institutional players: DA/prosecutors, defence attorneys, medical examiners, lab techs, uniformed officers
- Victim's family: grief manifest differently; may obstruct investigation protecting victim's secrets

VOICE DIFFERENTIATION:
- Investigators: professional, institutionally shaped, rank visible in speech
- Criminals: their own logic, their own world's language
- Witnesses: filtered through fear, loyalty, self-interest
- Institutional players: the language of their specific role (legal, medical, bureaucratic)
```

## Arc Rules

```
CRIME FICTION STORY STRUCTURE

ACT 1: THE CRIME AND FIRST RESPONSE (first 15%)
- Crime discovered: scene processed, first response, jurisdiction established
- The crime scene tells a story through physical evidence and professional observation
- Victim background emerges through witness testimony and family interviews
- Investigation direction established, initial theory forms based on early evidence
- The 48-hour clock is ticking. urgency is real
- END OF ACT 1: The investigator has an initial theory and a direction (which will be complicated)

ACT 2A: BUILDING THE CASE (15-40%)
- Systematic investigation: witness interviews, forensic results returning in realistic sequence
- Multiple suspects emerge through investigation's natural progression
- First lead hardens: warrants obtained, deeper searches authorised, surveillance considered
- The case deepens: second round of interviews, expert testimony introduces complexity
- The victim's hidden life emerges. a secret that opens new angles
- MIDPOINT: The case pivots. prime theory collapses, OR case appears solved but something's wrong, OR a second connected crime changes scope

ACT 2B: PRESSURE AND CONVERGENCE (40-85%)
- Maximum institutional pressure: media scrutiny, brass demanding resolution, investigator's personal life cracking
- Evidence accelerates: major forensic results, alibis verified or broken
- The investigator goes back through everything. the truth was in the evidence all along
- The criminal's motive becomes comprehensible: desperation, greed, protection, ideology
- Moral complexity deepens: the investigator crosses a line or faces a choice with consequences
- The case crystallises: who, how, and critically WHY
- DARK MOMENT: Before the arrest. a moment of doubt, exhaustion, moral reckoning

ACT 3: CONFRONTATION AND AFTERMATH (final 15%)
- The arrest and interrogation: intellectual and psychological encounter, not action sequence
- Miranda given, every procedural detail correct, the criminal's humanity visible
- The legal handoff: arraignment, charging, case passing from investigation to prosecution
- The aftermath: personal cost tallied, victim's family gets answers that don't undo loss
- The next case lands: crime fiction ends with continuation, not closure
- The person who investigated is not the same person who started

CRIME FICTION PACING:
- Steady procedural momentum, not thriller velocity
- Investigation scenes carry the narrative weight. interviews, evidence analysis, deduction
- Action is brief and consequential (real confrontations are fast)
- The quiet moments between action carry the emotional truth
- Institutional pressure creates a background hum of urgency that accelerates through Act 2
```

## Timeline Rules

```
CRIME FICTION TIMELINE

INVESTIGATION TIMELINE:
- Total story duration: 1-4 weeks (realistic investigation with urgency)
- Chapter time span: 1-3 days per chapter
- Time progression: linear with flashbacks to crime/victim's last days
- The 48-hour rule: first 48 hours critical. evidence decays, witnesses forget, trails cool
- Days since crime = mounting pressure from media, brass, families

FORENSIC PROCESSING TIMES:
- Autopsy: preliminary 24-48 hours / full report 1-2 weeks / toxicology 2-4 weeks
- DNA: rushed priority 3-7 days / normal 2-4 weeks / backlogged months / CODIS match days if in system
- Ballistics comparison: 1-3 days
- Fingerprint database: hours to days (quality dependent)
- Digital forensics: days to weeks (device complexity)
- Financial records: days (subpoena required)
- Phone records: days to weeks (carrier cooperation)

LEGAL TIMELINES:
- Warrant approval: hours to days (judge availability, probable cause)
- Suspect holding: 24-48 hours before charge/release
- Arraignment: within 48-72 hours of arrest
- Bail hearing: at arraignment or shortly after
- Trial prep: months (if story extends)

INVESTIGATOR TIME:
- Individual investigators work shifts (even if case runs 24/7)
- Witness interviews must be scheduled (people have jobs, lawyers)
- Travel between locations takes time
- Dead ends consume days that can't be recovered
- Court appearances, reports, and institutional obligations compete with investigation time
```

## Genre-Specific Craft Techniques

Crime fiction is the broader register from which cozy-mystery,
police procedural, hardboiled, noir, domestic thriller, legal
thriller, and literary crime all descend. Its readers — from
the procedural tradition (Ed McBain's 87th Precinct, Joseph
Wambaugh, Michael Connelly's Bosch series, Tana French's
Dublin Murder Squad, Jane Harper, Don Winslow on the cartel
register, Liz Moore on the literary edge) through the
hardboiled lineage (Chandler, Hammett, Sara Paretsky, James
Ellroy, Walter Mosley, Dennis Lehane, Megan Abbott on
contemporary expansion) into noir and literary crime (James
Lee Burke, Pete Dexter, Cormac McCarthy on the western edge,
Denis Johnson, Attica Locke, S.A. Cosby) — bring sophisticated
expectations: that the procedure be plausible, that the
characters be people rather than archetypes, that the moral
complexity be genuine rather than performed, and that the
crime itself reveal something about the world the reader
recognises as true. The techniques below are how the form
holds these standards across registers as different as cozy
and noir.

### The Equal-Weight Inventory

The most important evidence should be buried in a list of
equal-weight details. Crime fiction's puzzle contract
requires that clues be on the page in a way the reader
*could* solve — but that the reader's eye slides past them
in the moment because the prose has presented them as
unremarkable. The technique converts the writer's
omniscient knowledge of which detail matters into the
reader's eventual recognition that the detail was always
there.

```
"The victim's desk held the usual: a laptop (screen
cracked), three pens, a coffee mug from the Outer
Banks, an invoice from Henderson's Auto dated
November 3rd, reading glasses, a roll of antacids,
and a framed photograph of a woman the detective
didn't recognise."

Fifteen chapters later, the invoice date proves
the victim was alive two days after the supposed
murder. which means the medical examiner's
timeline is wrong, which means the alibi that
cleared the prime suspect doesn't hold.

The clue was item four in a list of seven.
The reader's eye slid right over it.
```

The technique requires equal-weight presentation. Each item
in the inventory must register as no more or less important
than the others; the prose's rhythm must not pause on the
significant item, the syntax must not foreground it, the
character's attention must not light on it longer than on
the rest. The strongest crime fiction runs multiple equal-
weight inventories across a book, with different items
turning out to matter for different revelations. Test:
return to the inventory after the reveal and ask whether
the writer cheated — was item four marked subtly so the
careful reader could have caught it, but not so heavily
that the average reader did?

### The Thin Line Moment

The investigator sees themselves in the criminal. This is
the genre's signature emotional move — the recognition that
the line between who commits the crime and who solves it is
thinner than the institutional registers (cop / criminal,
moral / immoral, civilised / brutal) suggest. The thin-line
moment is what distinguishes serious crime fiction from
procedural-as-puzzle.

```
NOT CRIME FICTION:
"Detective Harris couldn't understand why anyone
would commit such a terrible crime."

CRIME FICTION:
"Harris looked at the photographs. Brennan had
three kids, same as him. Coached Little League,
same as him. Went to church on Sundays. Then on
a Tuesday in November he'd put two rounds into
his business partner because the alternative was
losing everything he'd spent twenty years building.

Harris thought about his mortgage. About his
kids' college fund. About what 'everything'
meant when it was yours.

He put the photographs away."
```

The technique requires that the recognition be specific —
this exact circumstance, this exact pressure, this exact
calculation — rather than abstract ("we're all capable of
terrible things"). The investigator must register the
proximity in concrete detail: the same age, the same
mortgage size, the same daughter's school, the same way of
losing patience at the end of a long week. Where the prose
generalises ("Harris understood why people do what they
do"), the technique has not been deployed; where it
particularises ("Harris had thought about his mortgage too,
and about what 'everything' meant"), the technique is
operating.

### The Procedural as Character

The system itself reveals the story. Crime fiction's
distinctive contribution to the broader literary catalogue
is its sustained engagement with institutions: police
departments, prosecutors' offices, courts, prison systems,
forensic laboratories, parole boards, news organisations,
political offices, churches, families. The procedural is
not background — it is character, and the system's
specific failures and victories shape what the investigator
can and cannot do.

```
"The warrant came back at 4:17 PM on a Friday,
which meant Judge Okafor had signed it, which
meant the probable cause affidavit was strong,
which meant Forensics had found something in
the financial records that Harris hadn't seen
yet, because the lab didn't brief Homicide
before the DA's office on Fridays, because
Lieutenant Chen had made that rule after the
Vasquez case leaked to the press, because in
this department everything was a consequence
of something that went wrong before."

The procedure IS the story. The institution
IS a character.
```

The technique requires institutional knowledge specific to
the setting. Generic "police bureaucracy" is the failure
mode; the specific failure modes of this particular
department, this particular prosecutor's office, this
particular court system, are the technique. Strong
procedurals research the actual operations they depict —
McBain rode with the NYPD; Connelly was a crime reporter;
French has cited Garda Síochána procedure specifically — and
the institutional verisimilitude is what reader trust
rests on. Test: pick three procedural beats in the
manuscript and ask, in each, whether the beat reveals
something specific about the system that a generic crime
novel could not have shown.

### The Detective's Wound

Crime fiction's protagonist is rarely an unmarked person.
The genre's signature character is the investigator carrying
specific damage — the case that broke them; the partner
killed; the child lost; the marriage ended; the addiction
managed or unmanaged; the body that has stopped being
reliable; the institutional betrayal that taught them what
the system actually is. The wound shapes how they read
cases, what they notice, what they cannot afford to feel,
what they take personally that no professional should. In
the genre's strongest examples, the wound and the case
intersect: the investigator solves cases the way they do
*because* of the wound, and the case under investigation
exposes the wound to fresh air.

The technique requires that the wound be specific (this
exact loss, this exact moment, this exact aftermath) rather
than generic (the dead-partner trope without the dead
partner's name). It also requires that the wound operate in
the present, not as backstory recited in chapter one and
forgotten. The investigator with the dead daughter from
fifteen years ago should still be reading the case through
that loss in chapter twenty — not in a way that breaks
their professionalism, but in a way that the reader can
trace. Test: at three significant decision points in the
investigation, can the writer trace the decision back to
the wound's specific shape? If the wound is decoration
rather than structural pressure, the technique has not been
deployed.

The genre's reigning practitioners run this technique
deeply: Connelly's Bosch shaped by the unsolved Vietnam-era
homicides and the institutional contempt for lower-priority
cases; Atkinson's Jackson Brodie carrying the murdered
sister; French's Cassie Maddox holding the disappeared
childhood friend; Penny's Gamache carrying the institutional
betrayal that nearly killed his team; Burke's Robicheaux
holding combat memory and recovering alcoholism continuously.
The wound is the genre's deepest character architecture and
the most-mishandled when reduced to backstory.

### The Victim's Specificity

The body in chapter one is not a plot device — it is a
person. Crime fiction's ethical surface and its emotional
weight both depend on the victim being rendered as a real
human whose loss matters in particulars. The most-flagged
genre failure is the corpse-as-McGuffin: the victim
described in the opening chapter only to be forgotten as the
investigation moves past them, leaving the reader uncertain
why anyone was supposed to care.

The technique requires that the victim acquire dimension
across the investigation: the photograph on the desk, the
half-finished knitting, the booking confirmation for next
month, the name in someone else's address book under a
nickname only one person used, the playlist they had
queued for tomorrow's commute, the unsent text in their
drafts. Each detail particularises the loss; cumulatively,
the victim becomes a person the reader can grieve, and the
grief is what gives the investigation its weight. The
technique extends to victims not directly central to the
plot — the secondary murders, the cold cases referenced,
the historical victims whose unsolved cases shape the
investigator. Each must be rendered with at least one
particularising detail.

Test: at the climax, can the reader name three things about
the victim that have nothing to do with how they died? If
not, the body has not become a person, and the investigation
has not earned the reader's emotional investment. The genre
permits — and is strengthened by — investigators who refuse
to forget the victim's name, who carry the photograph past
the closure of the case, who say the victim's name in
preference to the suspect's at moments where institutional
language would erase it.

### The Closed Case Lie

Crime fiction's central revelation pattern is not "who
done it" but "what really happened" — and what really
happened is almost always different from what the official
record says, what the institutional narrative permits, or
what the protagonists believed at the start. The technique
is structural: the investigation begins with a story (the
police theory, the family's belief, the court's verdict, the
historical record, the closed file) and progresses by
revealing that story to be a lie — partial, motivated,
politically convenient, or self-protective.

The lie can take many forms: the conviction that put the
wrong person away; the suicide that was a murder; the
accident that was no accident; the closed case quietly
buried because solving it would expose institutional
complicity; the family secret rewritten in the official
record; the historical event whose accepted narrative
serves the powerful. The genre's strongest examples place
the lie at the centre of the investigation — solving the
crime requires unlearning what the protagonist (and often
the reader) had been told.

The technique requires that the lie be load-bearing: the
manuscript's revelation cannot collapse if the reader
removes the lie. Generic "the official story was wrong"
treatment is the failure mode; specific lies tied to
specific institutional or personal motivations are the
technique. Test: at the climax, can the writer name what
the lie was, who told it, why it was told, and what the
truth costs to expose? Each answer must be specific. If any
is generic, the lie has not been constructed; the
investigation has been gestural.

### Crime Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the streets told their own story" | Show the specific detail the character observes |
| "in this line of work, you learn to read people" | Show the specific read |
| "the underbelly of the city" | Name the specific place, person, or system |
| "justice isn't always clean" | Show the specific moral compromise |
| "the case was getting personal" | Show the specific personal stake |
| "a trail of blood and money" | Show the specific financial or physical evidence |
| "everyone has a price" | Show the specific transaction |
| "trust is a luxury" | Show who betrayed whom and how |
| "the system was broken" | Show the specific failure |
| "he'd seen too much to be surprised" | Show the specific reaction instead |
| "the clock was ticking" | Show the specific deadline and consequence |
| "his gut told him something was off" | Show the specific observation that triggered the feeling |
| "the body was found" | Show who found it, in what state, with what specific surrounding detail |
| "another long night at the precinct" | Show ONE specific thing about this particular night that is not all the others |
| "the perp had a record" | Show the specific prior offences and their relevance to this case |
| "the case had haunted him for years" | Show the specific way the case visits him in the present |
| "off the record" | Stop writing this; show the specific off-record exchange |
| "the suspect lawyered up" | Show the specific moment, who said what, what the lawyer said when they arrived |

## Genre-Specific Revision Rules

Six revision passes specific to crime fiction, each with a
single question, run cover-to-cover before the next begins.
Crime fiction's reader is genre-experienced, often
professionally adjacent (working or retired police, lawyers,
prosecutors, journalists, academics in criminology), and
holds writers to a high standard of procedural authenticity
and moral seriousness. The passes below are ordered to
surface procedural and evidentiary failures first (the
genre's most-detected lapses), moral and institutional
failures next (where the form's deeper craft sits), and
voice/register calibration last when the rest of the book is
stable enough for tonal scrutiny.

### Pass 1: Procedural Accuracy Check

Verify every police procedure depicted in the manuscript is
correct for the setting. Build a procedure ledger: every
investigative action shown (interviews, searches, arrests,
warrants, Mirandas, evidence collection, interrogations,
chain of custody, lineups, photo arrays, surveillance,
informant handling, plea offers, charging decisions) with a
plausibility note for each. Verify procedures correct for
the specific jurisdiction depicted: US police procedure
varies significantly by state and city; British procedure
operates under different rules; Continental European systems
are different again; the depiction must reflect the actual
jurisdiction, not a TV-amalgamated generic. Verify forensic
timelines are realistic — no instant DNA results (typical
turnaround days to weeks; expedited cases hours but with
specific authorisation); no overnight toxicology (typical
turnaround weeks to months; some compounds longer); no
instant facial recognition matches without specific database
access; ballistic comparison takes days, not minutes.
Verify jurisdictional boundaries are respected, or if
violations occur, the violations carry consequences that
the prose registers (the FBI agent who works a case outside
their jurisdiction does so with someone's permission, or
faces consequences). Verify rank and hierarchy function
correctly — detectives do not order captains, lieutenants do
not bypass chiefs, civilian consultants do not have
unrestricted access. The genre's reader notices procedural
errors immediately and loses confidence in the whole book.

### Pass 2: Evidence Chain Check

Build an evidence ledger for the manuscript. Every piece of
physical evidence introduced must have: a discovery
location, a discoverer, a collection method, a chain-of-
custody record (who possessed it, when, for what purpose),
and a final disposition (lab, evidence locker, court
exhibit). Verify chain of custody is maintained — evidence
that vanishes from the ledger and reappears later, evidence
handled by someone who shouldn't have, evidence that
unaccountably lacks a documented trail. Verify all
evidence was legally obtained: warrants in scope, consent
documented, valid exception explicitly available (exigent
circumstances, plain view, search incident to arrest,
inventory, automobile exception in US contexts). Where
evidence was illegally obtained, the prose must register
the consequence (suppression motion, fruit-of-the-poisonous-
tree doctrine, the case that won't survive a competent
defence attorney). Verify forensic results return at
realistic pace: a DNA result that arrives in chapter three
when the case opened in chapter one is unrealistic unless
the prose explicitly shows the lab work was expedited and
explains why. The genre's procedural reader is unforgiving
of evidence handled magically; the cumulative effect of
multiple lapses is to break the case the manuscript has
been building.

### Pass 3: Moral Complexity Check

Crime fiction's contract with serious readers requires
moral complexity, not moral cosplay. Verify the investigator
faces genuine ethical questions where both available
choices have costs. The investigator who agonises about
whether to do the obvious right thing is performing
complexity; the investigator weighing two genuine costs (to
the case, to the suspect, to the witnesses, to the wider
community, to themselves, to the institution) is operating
within it. Check that the criminal's motivation is
comprehensible — not justifiable, but legible to the reader
as the kind of pressure that produces this kind of
behaviour in this kind of person. The cartoon villain who
kills for the pleasure of killing is a genre archetype
present in some crime sub-genres but heavily flagged in
serious crime fiction; the killer whose motivation traces
back to specific pressures and specific choices is the
genre's deeper standard. Verify there are no clean moral
positions: cops are flawed, criminals are human, victims
are particular people with particular complications,
families are complicated, institutions are ambivalent.
Verify justice is shown as imperfect and costly — the
arrest that costs the family that cooperated, the
conviction that doesn't restore the loss, the closure that
isn't, the unanswered question the official record cannot
contain. Where the manuscript delivers tidy moral closure,
the failure mode is the procedural that pretends to be
serious crime fiction while operating on TV-cop comfort
rules.

### Pass 4: Institutional Reality Check

Verify institutional pressure is present and escalating
across the investigation. Crime fiction's distinctive
register includes the constant interference of institutional
factors: media attention shaping which cases get worked,
political pressure determining which suspects can be
charged, budget constraints determining which evidence gets
processed, bureaucratic deadlines determining which leads
get followed, family and victim-advocate pressure shaping
public messaging, departmental politics determining who
runs which case. Verify partner and team dynamics are
visible and specific — the investigator with no team
context drifts toward TV-detective archetype; the
investigator embedded in a specific squad with specific
relationships, specific rivalries, specific shared history
operates within the form. Verify budget, politics, and
bureaucracy affect the investigation — the case that has
to be cleared by Friday because the chief is briefing the
mayor on Monday; the witness who can't be flown out
because there's no money for the flight; the warrant that
can't be served until the prosecutor's office signs off,
which they won't do until after the holidays. The
investigator should work within (or visibly against)
institutional constraints — the maverick detective with
infinite resources is the genre's most-flagged TV-cop
inheritance. Test: pick three significant decisions in the
investigation and trace each to the institutional pressure
that shaped it. If any decision occurs in an institutional
vacuum, the manuscript has lost a register the genre
requires.

### Pass 5: Victim Dignity Check

Read the manuscript with sole attention to the victim
(or victims, in books with multiple). Is each victim
built as a real person with a particularising history, not
just a body in chapter one? Does the investigation reveal
who they were — contradictions, secrets, relationships,
specific work, specific friendships, specific hopes — in
ways that exceed the requirements of the puzzle? Does the
reader care about the victim enough to demand justice
beyond intellectual interest in solving the case?

The pass also addresses victim handling at scene level: the
description of bodies must engage the body as having
recently been a person, not as the puzzle-piece the
investigator works on. The autopsy scene is not a forensic
data dump but a moment where the body's specific dignity
is observed by the medical examiner and recorded by the
prose. Family interviews are not exposition — they are
encounters between investigators and people in the worst
period of their lives, and the prose should register the
ethical weight of what is being asked. Where the
manuscript treats victims as plot mechanisms or as bodies
to be processed, the genre's deeper contract has been
broken; serious crime fiction's reader is here for the
victim's name to mean something at the end. Test: at the
final chapter, can the writer name three particular things
about the victim — beyond their relationship to the case —
that the investigation revealed? If not, the dignity check
has not been observed.

### Pass 6: Voice and Register Calibration

Crime fiction operates across a spectrum of registers
(cozy on one end; police procedural; hardboiled; noir;
literary crime; legal thriller; domestic thriller; true-
crime-style fiction at the other end), and the manuscript
must commit to a specific point on the spectrum and hold
that register throughout. Read the manuscript for tonal
consistency and ask: where does this book live, and does
it stay there?

The registers differ in specifics:
- **Cozy** permits warmth and humour, prohibits graphic
  violence and on-page brutality, foregrounds community.
- **Police procedural** centres the institutional process,
  permits moderate violence, holds a working register that
  is neither comic nor noir.
- **Hardboiled** uses first-person voice (typically),
  carries verbal economy and dry register, tolerates more
  explicit violence and moral ambiguity.
- **Noir** commits to bleakness as worldview, refuses
  redemption arcs, treats the world as actively unjust.
- **Literary crime** operates with broader prose ambition,
  greater interiority, slower pacing, often a literary-
  fiction reader audience as much as a crime audience.
- **Legal / domestic thriller** foregrounds specific
  institutional or interpersonal terrain, holds a polished
  register that emphasises plot mechanism over voice.

A manuscript that drifts between registers (the cozy that
suddenly turns graphic in chapter twelve; the noir that
swerves to an unearned redemption in the final chapter; the
police procedural that becomes hardboiled when the writer
gets bored of procedure) loses the reader who came for the
register the book originally established. Run a tonal
audit: read three sample chapters spaced across the
manuscript and identify the register each operates in. If
the chapters disagree, the calibration has slipped, and
the fix is structural rather than line-level — the
manuscript needs to choose which register it is and
revise toward consistency. The genre permits — and
sometimes requires — deliberate register shifts, but those
shifts must be earned by the structural beats and
recognisable as choices rather than as drift.

## Names & Patterns to Avoid

### Crime Fiction Character Names. NEVER USE
- TV cop cliché names: Sarge, Chief, Ace, Hawk
- Names that signal role: Detective Sharp, Officer Trueheart
- Identical-sounding suspect names (readers track suspects by name. differentiate)

### Crime Fiction. NEVER DO
- Solve the case through coincidence or "cop instinct" alone
- Give the investigator unrealistic access without institutional backing
- Skip the procedural reality (warrants, chain of custody, processing times)
- Make the criminal a cartoon villain without comprehensible motivation
- Romanticise police work without showing its cost
- Use "enhance that image" or other TV forensics magic
- Write bloodless violence in a genre that demands honest physical reality

### Use Instead
- Names appropriate to the setting's department, region, and era
- Surnames used professionally (as law enforcement actually does)
- Rank-appropriate forms of address (Detective, Sergeant, Lieutenant)

## Comp Titles

Crime's comp-title set supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *In Cold Blood* — Truman Capote (1966): the literary true-crime template.
- *The Godfather* — Mario Puzo (1969): the organised-crime saga benchmark.
- *Red Harvest* — Dashiell Hammett (1929): the hardboiled-crime template.
- *The Killer Inside Me* — Jim Thompson (1952): unreliable-narrator crime; psychological-crime lineage.

### Contemporary (current best-in-class)

- *Mystic River* — Dennis Lehane (2001): literary-crime with neighbourhood-as-text architecture.
- *Bluebird, Bluebird* — Attica Locke (2017): contemporary crime with race-place specificity; East Texas setting.
- *Razorblade Tears* — S.A. Cosby (2021): rural-crime with father-grief central; literary-commercial crossover.
- *Blacktop Wasteland* — S.A. Cosby (2020): rural-crime with class-friction architecture.
- *The Searcher* — Tana French (2020): contemporary literary-crime with rural-Ireland setting.
- *Thunder Bay* — Douglas Skelton or similar 2020s: regional crime category benchmark.
- *Eight Detectives* — Alex Pavesi (2020): meta-crime with story-within-story structure.

## Cover Design Specifications

### Recommended Visual Styles
- **Noir-Lit**. Dark, atmospheric compositions: city streets, rain-slicked pavement, a figure in shadow; the visual language of crime's moral ambiguity
- **Evidence**. A single piece of evidence as design centrepiece: a case file, a photograph, a weapon in an evidence bag; the object that tells the story
- **Institutional**. The world of investigation: precinct corridors, interview rooms, evidence boards; the visual language of procedure
- **Typographic**. Bold, confident typography with minimal imagery; the title as case file heading; the author name as brand

### Genre Cover Aesthetics
- **Styles:** Urban night scenes, evidence close-ups, institutional interiors, figures in shadow, the visual tension between order (investigation) and chaos (crime), crime scene tape as graphic element, rain and reflective surfaces
- **Colours:** Dark, sophisticated palettes: midnight blue, gunmetal grey, deep red as accent; noir lighting. pools of light in surrounding darkness; the muted tones of institutional spaces with one stark accent
- **Elements:** Evidence bags, case files, city skylines at night, badge silhouettes, fingerprints, crime scene details suggested but not shown, the geometry of urban spaces, institutional typography (CLASSIFIED, EVIDENCE, CASE NO.)
- **Typography:** Bold, authoritative, often sans-serif; the title should feel stamped or filed; red or white accents against dark backgrounds; the author name prominent (crime readers follow authors)

### Market Positioning
Crime fiction covers must signal "procedural, morally complex, and authentic" through dark urban imagery and institutional design language. Position against Connelly, Lehane, Nesbo, French, Rankin. The cover should promise both intellectual rigour and emotional stakes. At thumbnail size, dark palettes with one striking accent element and bold typography create immediate genre recognition.

### Cover Design DON'Ts
- No action-movie aesthetics (explosions, car chases, gun-pointing poses)
- No bright or cheerful colours
- No cartoonish or stylised imagery
- No romanticised crime (glamorous criminals, sexy investigators)
- No generic stock photography of police tape or handcuffs
- No designs that look like cozy mystery (different audience, different visual language)
