---
name: gothic-genre
description: Genre-specific instructions for gothic fiction. pair with the Ideorix Engine
version: "1.0"
user-invocable: false
parents: [horror]
---

# Gothic. Genre Plugin

## Metadata
- id: gothic
- name: Gothic
- icon: 🏚️
- category: Fiction
- minWords: 2500
- targetWords: "2,500-4,500"
- recommendedBeatStructures: ["Three-Act Structure", "Five-Act Structure", "Seven-Point Story Structure"]

## Subgenre Options
Present during setup:
- **Classic Gothic**. Ruined estates, family secrets, atmospheric dread, the Brontë/du Maurier territory of grand houses and oppressive histories
- **Southern Gothic**. American South: decay, grotesquerie, social rot, the beautiful and the terrible intertwined; Faulkner, O'Connor, McCullers territory
- **Modern Gothic**. Contemporary settings with gothic architecture of feeling: claustrophobic relationships, inherited trauma, houses that reflect their inhabitants' psychology
- **Domestic Gothic**. The home as prison: marriages, families, and households that conceal something terrible; the door locked from inside
- **Gothic Suspense**. Thriller pacing with gothic atmosphere: the protagonist trapped in an opulent, suffocating setting with a secret that wants to remain buried
- **Neo-Gothic**. Self-aware, literary, playing with gothic conventions while still deploying them; the genre examining itself

## Architect Instructions

```
STRUCTURE
- Chapter length: 2,500-4,500 words
- Pacing: Oppressive and building. the walls are closing in, the air is getting heavier, the truth is getting closer
- Must open with: The setting asserting itself. the house, the landscape, the atmosphere; gothic fiction begins with PLACE

BEATS PER CHAPTER
1. The House Beat. The setting (house, estate, institution) exerts its personality: architecture, weather, light, decay, beauty
2. The Secret Beat. The buried truth makes itself felt: a locked room, a forbidden topic, a reaction that doesn't match, a document that contradicts
3. The Entrapment Beat. The protagonist's freedom narrows: social obligation, emotional manipulation, physical isolation, economic dependence
4. The Gothic Sublime. A moment of terrible beauty: moonlight on ruins, a storm over moors, the decayed elegance of a once-grand room
5. The Double Beat. Something has two faces: a person, a place, a relationship that is not what it seems

THE GOTHIC ARCHITECTURE
- The HOUSE is a character: it has a personality, a history, moods, and secrets; it reflects and amplifies the psychological state of its inhabitants
- The PAST haunts the present: family history, trauma, secrets, and crimes cast long shadows; the gothic is about what was buried and what refuses to stay buried
- ENTRAPMENT is the engine: the protagonist cannot easily leave (social obligation, marriage, inheritance, employment, emotional bond, physical isolation)
- DOUBLING pervades: the beautiful house is also a prison; the charming host is also the threat; the protagonist sees herself reflected in a predecessor
- The SUBLIME is central: beauty and terror coexist. the gorgeous landscape, the magnificent house, and the dreadful thing inside it
- DECAY is aesthetic: peeling wallpaper, tarnished silver, overgrown gardens, faded portraits. the beautiful thing in the process of dying
- POV: First person past (the retrospective confession is the classic gothic voice) or tight third past

THE SETTING
- The house/estate must be described with the attention you'd give a major character
- It has history: who built it, who lived there, what happened, what remains
- It has moods: the morning light that makes it welcoming, the evening shadows that make it threatening
- It has secrets: rooms that are locked, wings that are disused, spaces that are forbidden
- The landscape participates: moors, cliffs, forests, fog, storms, the sea. nature as emotional landscape
- Seasonal progression: gothic stories often track the darkening of the year (autumn into winter)

FORBIDDEN IN GOTHIC
- Bright, cheerful settings with no atmospheric weight
- Protagonists who can simply leave (the entrapment must be convincing)
- Secrets that are mundane (the buried truth must be genuinely terrible)
- Gothic aesthetics without psychological depth (pretty ruins are not enough)
- The setting as mere backdrop (if you could move the story to a modern apartment without losing anything, it's not gothic)
- Instant revelation of secrets (the gothic is about SLOW uncovering)
- Villains who are simply evil (gothic antagonists are complex, often sympathetic, always human)
```

## Writer Craft Rules

```
ENGAGEMENT FRAMEWORK
→ The universal six-level Dopamine Ladder (Stimulation,
  Captivation, Anticipation, Validation, Affection, Revelation)
  applies to every scene in this project. See
  `dopamine-ladder.md` for the full framework and per-scene
  self-check. It loads into the Writer prompt's
  `{dopamine_ladder_diagnostic}` slot automatically. Genre
  emphasis: Stimulation (atmosphere as physical sensation), Captivation (place as character), Anticipation (dread accumulation).

HEAT CALIBRATION
→ When `romance_subplot: yes` is selected at Setup Q3, see
  `heat-calibration.md` for the universal calibration block.
  It loads into the Writer prompt's `{heat_level_calibration}`
  slot and applies before the genre cues below — at Spice 0-1
  the calibration overrides default chemistry-demonstration
  cues (replace body-cue vocabulary with interior architecture,
  non-body sensory channels, character-rooted specificity).
  When no romance subplot, calibration does not apply and the
  genre cues below apply directly.

VOICE & TONE
- POV: First person past tense (the retrospective narrator is the gothic standard) or tight third past
- Voice: Literate, observant, atmospheric. The narrator fixates on ONE telling detail per moment rather than cataloguing every sense
- Tone: Oppressive beauty. the reader should feel simultaneously drawn in and suffocated
- Register: Elevated but not purple; the language should match the setting's grandeur without becoming overwrought

PROSE IMPERATIVES
- THE HOUSE AS PROSE: descriptions of the setting should function as psychological portraiture
  - A peeling wall reflects a relationship coming apart
  - A locked door mirrors a secret kept
  - An overgrown garden parallels untended grief
  - The temperature of a room tells you about its occupant's emotional state
- LIGHT AND SHADOW: gothic prose tracks light obsessively
  - Candlelight: warm, intimate, creates deep shadows, unreliable
  - Moonlight: cold, silver, reveals and transforms, makes the familiar strange
  - Firelight: flickering, alive, throws moving shadows
  - Gaslight: warm but sickly, creates a jaundiced quality
  - Absence of light: what the character CANNOT see is more powerful than what they can
- SENSORY WEIGHT: gothic prose is heavy with physical sensation
  - The weight of air in a closed room; the chill of a stone floor; the texture of old fabric
  - Smell is crucial: mildew, damp stone, old perfume, wood smoke, decay, flowers past their prime
  - Sound carries: footsteps in empty corridors, the house settling, wind in the eaves, silence that presses
- CONTROLLED PACE: gothic prose moves deliberately
  - Long sentences for atmosphere and tension
  - Short sentences for revelation and shock
  - The paragraph builds like a wave: approach, crest, break

PROSE RHYTHM MAPPING
- CH 1 HOOK: Atmosphere IS the hook. The first paragraph should feel like entering a room
  you shouldn't be in. the prose itself oppresses before anything happens.
- THE GOTHIC SENTENCE: Long, architecturally complex sentences (20-30 words) with embedded clauses
  that mirror the setting. A crumbling house = crumbling syntax. Subordinate clauses nest inside
  each other like rooms within rooms, each revealing another layer of unease.
- DECLARATION RHYTHM: Medium-long atmospheric sentences punctuated by stark SHORT declarations
  when truth surfaces. "The door was locked." "She had been here before." "He was lying."
  The short sentence is the crack in the facade. everything ornate falls away.
- SENSORY PALETTE: Dark, damp, ancient, decayed. Every sensory detail should feel like it has
  weight and age. The smell of stone that has been wet for centuries. The sound of a house
  that breathes when the wind finds gaps it shouldn't. Dust that tastes of time.
- TENSION FLOOR: Never below 6. Even the most beautiful descriptive passage carries undertow.
  a word choice that unsettles, a clause that turns, a detail that doesn't belong.
- PROSE-AS-ARCHITECTURE: The prose itself should feel like walking through a house you shouldn't be in.
  Sentences wind like corridors. Paragraphs open like rooms. The reader should feel slightly lost,
  slightly claustrophobic, slightly unable to find the way back to the beginning of the sentence.
- PARAGRAPH SHAPE: Long, heavy paragraphs for atmospheric immersion (the reader sinks in),
  then a single short paragraph. one sentence, maybe two. for the moment the truth shows through.
- RHYTHM ACROSS CHAPTERS: Act 1 prose is the most ornate and controlled. By Act 3, the gothic
  sentence structure cracks. shorter, more desperate, the architectural elegance collapsing
  as the house (and the story) reveals what it has been hiding.

DESCRIPTION CRAFT
- The setting is described EMOTIONALLY, not just physically:
  WRONG: "The house had twenty rooms, grey stone walls, and a slate roof."
  RIGHT: "The house was beautiful the way a bruise is beautiful. all those soft colours of decay, the grey stone going silver where the rain had touched it for two hundred years, and every window reflecting the sky like a blinded eye."
- Objects carry history: a portrait is not just a painting but a representation of someone who lived, breathed, and did something terrible
- Rooms have atmosphere: the drawing room feels different from the bedroom, the kitchen from the study. each space has its own emotional register

DIALOGUE CRAFT
- Subtext is everything: gothic characters rarely say what they mean
- The host's gracious invitation that is also a command
- The warning disguised as casual conversation
- The confession that sounds like a story about someone else
- Silences: what is NOT said is often more important than what is
- Period-appropriate if historical; in modern gothic, the formality comes from the social situation, not the era
```

## Quality Check Criteria

```
SCORING RUBRIC (0-100 per dimension)

GOTHIC CRAFT (40% of total):
- The setting functions as a character (personality, moods, secrets)? (0-100)
- The past haunts the present (buried history driving current events)? (0-100)
- Entrapment is convincing (the protagonist cannot simply leave)? (0-100)
- Beauty and terror coexist (the gothic sublime is present)? (0-100)

STORY CRAFT (30% of total):
- The secret is genuinely terrible and worth the build-up? (0-100)
- The protagonist's investigation/discovery arc is compelling? (0-100)
- The antagonist is complex (not simply evil)? (0-100)
- The resolution addresses both the secret and the emotional core? (0-100)

PROSE QUALITY (30% of total):
- Setting descriptions function as psychological portraiture? (0-100)
- Light and shadow are used deliberately and effectively? (0-100)
- Sensory weight creates atmosphere (the reader feels the house)? (0-100)
- Dialogue operates on subtext (characters rarely say what they mean)? (0-100)

AUTOMATIC FAILS (score = 0):
- The setting is interchangeable with any other location
- The protagonist can obviously leave but chooses not to for no good reason
- Secrets revealed quickly with no atmospheric build-up
- Gothic aesthetics without psychological substance
- Purple prose that sacrifices clarity for ornamentation
- The antagonist is a cartoon villain with no complexity
```

## Continuity Rules

```
GOTHIC CONTINUITY. WHAT TO TRACK

THE HOUSE/SETTING:
- Room-by-room knowledge: which rooms the protagonist has accessed and when
- Locked/forbidden areas: track what's been opened, what remains sealed
- The house's condition: specific decay details mentioned must remain consistent
- Weather and season: track progression (autumn deepens, storms build, winter closes in)
- Changes: anything that's moved, appeared, deteriorated, or been discovered

THE SECRET:
- What has been revealed, to whom, and when
- Evidence discovered: documents, objects, testimonies, observations
- What the protagonist THINKS the secret is (which may evolve)
- What other characters know and when they learned it
- Red herrings: false trails planted and where the protagonist is with each

SOCIAL STATE:
- The protagonist's relationships with all other characters
- Power dynamics: who controls what, who depends on whom
- Trust levels: who the protagonist trusts and why (should erode)
- Obligations: social debts, promises made, expectations created
- Reputation: how the protagonist is perceived by others in the household/community

PSYCHOLOGICAL STATE:
- The protagonist's mental arc: curiosity → unease → obsession → fear → resolution
- Dreams and nightmares: track recurring images and their evolution
- Physical symptoms of psychological stress: insomnia, loss of appetite, hypervigilance
- The doubling: when does the protagonist see herself reflected in the house's history?

TEMPORAL STATE:
- Dual timeline: the PRESENT investigation and the PAST events being uncovered
- Track discoveries chronologically: when each piece of the past is revealed
- Seasonal markers: the changing landscape/weather should track across the manuscript
- Duration of stay: how long the protagonist has been in the house/situation
```

## Character Rules

```
GOTHIC CHARACTER TYPES

THE PROTAGONIST (THE NEWCOMER):
- Arrives at the gothic setting from outside: a new wife, an employee, an heir, an investigator, a visitor
- Observant and intelligent: they notice things others have learned to ignore
- Trapped by circumstance: marriage, employment, inheritance, obligation, fascination
- Has a personal connection to the secret (even if they don't know it yet)
- Their psychological journey mirrors the house: as they uncover the setting's secrets, they uncover their own
- Often echoes a predecessor: the first wife, the previous governess, the original builder's vision

THE HOST/ANTAGONIST:
- Charming, complex, possibly sympathetic. NEVER simply villainous
- Keeper of the secret: they maintain the house, the family, the story, and the lie
- Their love (for the protagonist, for the house, for the family legacy) is genuine AND destructive
- They have their own entrapment: the secret imprisons them too
- Their arc: the mask slips gradually, revealing the person beneath

THE HOUSE ITSELF:
- A character with agency: it reveals and conceals, invites and traps
- Its physical state reflects the emotional state of the story
- It has a history that parallels or shadows the current events
- Rooms have personalities: the warm kitchen, the cold bedroom, the locked study
- It changes (or seems to): doors that were open are closed, rooms feel different at night

THE PREDECESSOR:
- The person whose story parallels the protagonist's: the first wife, the previous tenant, the dead child
- Present through traces: a portrait, a diary, a locked room, other characters' silences
- Their story is the key to the present mystery
- The protagonist discovers their story in fragments, gradually building the full picture
- The predecessor's fate is a WARNING of what could happen to the protagonist

THE CONFIDANT:
- A servant, neighbour, or visitor who offers the protagonist a window into the truth
- They know more than they initially reveal
- Their loyalty is divided: they care about the protagonist but fear the antagonist or the house
- They provide crucial information at a narratively significant moment

VOICE DIFFERENTIATION:
- The protagonist: observant, questioning, increasingly anxious, with a literary eye for detail
- The host/antagonist: charming, controlled, with subtle tells when topics get close to the truth
- The confidant: cautious, indirect, speaking in hints and half-stories
- The house: described in language that personifies it. the house "watches," "breathes," "holds"
```

## Arc Rules

```
GOTHIC STORY STRUCTURE

ACT 1: THE ARRIVAL (first 25%)
- The protagonist arrives at the setting: describe the first impression with full sensory weight
- The house/setting is immediately compelling: beautiful, strange, slightly wrong
- The host receives them: charming, attentive, with something held back
- The protagonist settles in: explores, observes, begins to find the rhythm of the place
- First signs of the secret: a locked door, a forbidden topic, a reaction that doesn't fit, a detail that contradicts
- END OF ACT 1: The protagonist becomes aware that something is hidden and begins to look

ACT 2A: THE INVESTIGATION (to midpoint)
- The protagonist explores deeper: the house, the history, the relationships
- Fragments of the secret emerge: a diary entry, a servant's slip, a hidden room, a photograph
- The entrapment deepens: emotional attachment, social obligation, practical impossibility of leaving
- The setting becomes more oppressive: weather worsens, rooms feel smaller, the protagonist is less comfortable
- The doubling emerges: the protagonist sees parallels between herself and the predecessor
- MIDPOINT: A major revelation. a piece of the secret that reframes everything the protagonist has experienced

ACT 2B: THE ENTRAPMENT (midpoint to dark moment)
- The protagonist now understands the DANGER but cannot easily leave
- The host/antagonist's mask begins to slip: moments of control, anger, or desperation
- The house reveals its darker aspects: previously hidden spaces, disturbing discoveries
- Other characters' loyalty is tested: allies become uncertain, enemies become clearer
- The protagonist's psychological state deteriorates: paranoia, insomnia, obsessive investigation
- DARK MOMENT: The full truth (or nearly) is revealed. and it's worse than imagined; the protagonist is in immediate danger

ACT 3: THE RECKONING (final 25%)
- The protagonist must confront the secret and the antagonist
- The house plays its final role: the climactic scene happens IN the significant space (the locked room, the attic, the cellar, the grounds)
- The confrontation is emotional as much as physical: truth-telling, confession, accusation
- The resolution of the secret: exposure, destruction, sacrifice, or acceptance
- The protagonist escapes, stays, or transforms. but the relationship with the house/setting is changed forever
- The house's fate: burned, sold, abandoned, inherited, restored. its ending reflects the story's meaning

GOTHIC PACING:
- ACT 1 is the slowest: immerse the reader in the setting
- Chapters alternate: exploration scenes (slow, atmospheric) and revelation scenes (tense, propulsive)
- The pace increases through Act 2: discoveries come faster, the atmosphere tightens
- Act 3 is the fastest: the gothic dam breaks and everything rushes out
- The final chapter returns to atmospheric pace: quiet, reflective, haunting
```

## Timeline Rules

```
GOTHIC TIMELINE

DUAL TIMELINE:
- PRESENT: The protagonist's time in the house (days to months)
- PAST: The events that created the secret (may be decades or centuries ago)
- The past is revealed in fragments that create dramatic irony in the present
- Track: what the protagonist knows about the past at each point in the story

SEASONAL TIMELINE:
- Gothic stories often align with darkening seasons (late summer → autumn → winter)
- Track weather: storms, fog, frost, rain. each creates different atmosphere
- The house changes with seasons: different light, different sounds, different temperatures
- Garden and grounds: blooming → fading → bare → dead (mirrors the story's arc)

DOMESTIC TIMELINE:
- The rhythms of the house: meals, visitors, staff schedules, the host's routine
- Track the protagonist's growing familiarity with (and departure from) these routines
- When routines are broken, it signals plot shifts
- Night sequences: insomnia, wandering the house, nocturnal discoveries

INVESTIGATION TIMELINE:
- Track discovery order: when each piece of the puzzle was found
- Where the protagonist is in their understanding (may be ahead of or behind the reader)
- When suspicion shifts: who the protagonist suspects and when they change their mind
```

## Genre-Specific Craft Techniques

Gothic fiction (distinct from gothic horror) operates
in the register where the dread is primarily
psychological, architectural, and social rather than
supernatural — the brontëan tradition, the du Maurier
tradition, the Wilkie Collins sensation novel, the
Henry James turn-of-the-screw ambiguity, the
contemporary literary gothic, the gothic mystery, and
the gothic suspense register where the secret is
terrible without necessarily being monstrous. The
canonical comp roster — Charlotte Brontë (Jane Eyre,
Villette, The Professor), Emily Brontë (Wuthering
Heights), Daphne du Maurier (Rebecca, My Cousin
Rachel, Jamaica Inn, The House on the Strand), Wilkie
Collins (The Woman in White, The Moonstone, No Name),
Ann Radcliffe, Henry James (The Turn of the Screw, The
Aspern Papers, The Portrait of a Lady), Edith Wharton
(Ethan Frome, Summer), Mary Wilkins Freeman, Susan
Hill (The Woman in Black), William Faulkner (Absalom
Absalom, Sanctuary), Flannery O'Connor, Carson
McCullers, Eudora Welty, Truman Capote (Other Voices,
Other Rooms) — established the form across its English
country-house and Southern Gothic registers; the
contemporary masterclass roster — Sarah Waters
(Affinity, Fingersmith, The Little Stranger, Tipping
the Velvet, The Paying Guests), Donna Tartt (The
Secret History, The Little Friend), Diane Setterfield
(The Thirteenth Tale, Bellman & Black, Once Upon a
River), Sarah Perry (The Essex Serpent, Melmoth,
Enlightenment), Ruth Ware (In a Dark, Dark Wood, The
Turn of the Key, The Lying Game), Laura Purcell (The
Silent Companions, Bone China, The Shape of Darkness),
Kate Morton (The House at Riverton, The Forgotten
Garden, The Lake House), Jessie Burton (The
Miniaturist, The Confession), Susanna Clarke
(Piranesi, Jonathan Strange & Mr Norrell), Tana French
(the Dublin Murder Squad), Eleanor Catton (The
Luminaries), Sophie Hannah, Jane Harris (The
Observations, Gillespie and I), Michelle Paver (Dark
Matter, Wakenhyrst) — has expanded the genre's range
to include literary gothic, gothic mystery, modern
domestic gothic, and gothic suspense, each preserving
the architectural commitments while extending the
register to contemporary anxieties about marriage,
class, sexuality, race, and inherited wealth. The most
common failure modes in this register are: **Aesthetic-
Without-Substance** (gothic atmosphere as wallpaper —
candles, ivy, peeling paint, locked doors — without
psychological, political, or institutional weight on
the protagonist's actual situation); **Tourist-
Protagonist** (the visitor with no skin in the game,
who could leave but doesn't, with no convincing
material weight to her staying — gothic requires the
protagonist to be implicated through marriage,
employment, inheritance, kinship, debt, or pursuit of
specific concrete information); **Mundane-Secret** (the
buried truth that is not actually terrible enough to
justify the build-up — a long-ago affair, an unworthy
suitor, a minor financial irregularity that could not
in any case destroy lives; the gothic contract is that
the secret is genuinely terrible and would have
genuinely-terrible present consequences if revealed);
**Slow-Reveal-Without-Forward-Motion** (atmosphere
accumulating without plot progression; the gothic
dragging into stasis as the writer mistakes "slow
build" for "no events"); **Manderley Pastiche** (du
Maurier or Brontë cosplay rather than fresh gothic;
recognisable quotes and tropes — the second wife, the
locked east wing, the housekeeper who knows, the
husband with the dead first love — deployed as quotation
without genuine craft transformation); **Modern-Voice
Slip** (anachronistic register breaking through period
prose; contemporary contractions, internet idiom, or
2026-era social vocabulary that breaks the gothic
spell); **Resolution-Too-Tidy** (the gothic ending
that ties up cleanly without the genre's signature
ambiguity, residue, or transformation; the survivor
who returns to ordinary life unchanged, the secret
exposed without ongoing consequence); **Antagonist-
as-Pure-Villain** (the host, husband, brother, or
family figure rendered as cardboard villain rather
than as complex, sympathetic, tragically self-trapped
figure the genre demands — gothic antagonists are
keepers of secrets that imprison them too); and
**Doubling-Without-Resonance** (the predecessor /
portrait / first-wife / dead-twin device deployed as
period decoration rather than as live thematic mirror
to the protagonist's specific situation, with the
predecessor's fate functioning as prophecy or
warning). The techniques below — three preserved
(House-as-Mirror, Gothic Sentence, Forbidden Door
Technique) and three added (Buried-Truth Architecture,
Doubling Calibration Discipline, Investigation-Pace
Calibration) — are designed to keep the genre's
defining commitments live: the house as character, the
secret as genuinely worth its weight, doublings as
live thematic resonance, and the investigation pacing
as both atmospheric and forward-driving.

### The House-as-Mirror

The setting should reflect the protagonist's internal state:

```
When she arrived: "The house stood in autumn sunlight,
its windows catching the gold. Beautiful. A place where
a person might be happy."

After the first revelation: "The house was the same, she
told herself. The same stone, the same windows. But the
light had changed, or she had. The shadows seemed longer
than they should be at midday."

At the dark moment: "The house had always been this. She
saw it now. the beautiful façade was exactly that: a face
over a skull. Every gracious room built on the bones of
what had happened in the cellar."
```

### The Gothic Sentence

Gothic prose uses sentence structure to create atmosphere:

- **The long, layered sentence**. accumulates details, each adding weight, each tightening the atmosphere. Used sparingly and deliberately, never as a default mode
- **The short, sharp sentence**. breaks through. The truth.
- **The fragment**. what she found. In the locked room. What had been hidden.

### The Forbidden Door Technique

Every gothic novel needs spaces of graduated access:

1. **Public spaces**. Where the protagonist is welcome (drawing room, garden, library)
2. **Private spaces**. Where access requires permission (the host's bedroom, the study)
3. **Restricted spaces**. Where the protagonist is discouraged from going ("That wing is unused")
4. **Forbidden spaces**. Where the protagonist is actively prevented from entering (the locked room, the cellar, the attic)
5. **The secret space**. What's behind the forbidden door: the revelation

Each level's breaching represents escalation in the story.

### Gothic Fiction AI Crutch Phrases (ELIMINATE ALL)

| AI Pattern | Fix |
|---|---|
| "the atmosphere was oppressive" | Show the specific sensory detail that oppresses |
| "darkness within and without" | Show the specific internal struggle through external action |
| "the boundary between the living and the dead" | Show the specific liminal moment |
| "a brooding presence" | Show the specific behaviour that constitutes brooding |
| "the past refused to stay buried" | Show the specific resurfacing. a letter, a face, a smell |
| "decadence masked despair" | Show the specific decadent detail alongside the specific despair |
| "the walls were steeped in history" | Show ONE specific historical mark on the wall |
| "an atmosphere thick with foreboding" | Show ONE detail that creates foreboding |
| "the darkness called to her" | Show the specific attraction. curiosity, fascination, compulsion |
| "secrets older than memory" | Show the specific secret and how it surfaces |
| "the Gothic sensibility" | Delete. Show it through the prose, don't name it |
| "the silence was deafening" | Cut cliché; show the specific quality of silence (no clock ticking, no servants, no birds) |
| "her blood ran cold" | Cut cliché; show the specific bodily response (the prickle at the nape, the dropped utensil, the held breath) |
| "shadows seemed to whisper" | Cut anthropomorphism; show the specific shadow and what specifically alerts the protagonist |
| "the air grew heavy" | Cut "grew heavy"; show the specific pressure (the closed door, the listening servant, the loaded silence) |
| "wrapped in mystery" | Cut metaphor; show the specific concealment (the closed shutter, the off-limits letter, the deflected question) |
| "the threshold of madness" | Cut psychiatric cliché; show the specific moment where the protagonist's perception destabilises |
| "whispers from the past" | Cut cliché; show the specific past artefact intruding (the diary entry, the marginal note, the photograph) |

### The Buried-Truth Architecture

The gothic novel's slow uncovering must be earned by a
secret genuinely worth uncovering. The Mundane-Secret
failure mode collapses the genre. when the buried
truth turns out to be a long-ago affair, an unworthy
suitor, or a minor financial irregularity, the
manuscript's atmosphere collapses retroactively because
the prose has been doing dread-work for a payoff that
cannot bear its weight. The Buried-Truth Architecture
is the requirement that the secret at the gothic's
core be specifically terrible, materially consequential,
and revelatory of character / family / institution.

```
PRINCIPLE
The buried truth must satisfy at least four of the
following five criteria:
1. SPECIFICALLY TERRIBLE — the truth is named and
   concrete (not "something happened" but the specific
   crime, the specific death, the specific betrayal,
   the specific theft, the specific marriage, the
   specific pact, the specific concealed identity)
2. MATERIALLY CONSEQUENTIAL — exposure would have
   real present-day impact (legal jeopardy, financial
   ruin, social destruction, criminal prosecution,
   loss of inheritance, broken marriages, custody
   loss, ruined reputation)
3. CHARACTER-REVELATORY — the truth recontextualises
   characters the protagonist (and reader) thought
   they understood; the antagonist's behaviour, the
   ally's silence, the protagonist's own situation
   are reframed by the revelation
4. INSTITUTION-REVELATORY — the truth implicates a
   larger institution (the family, the firm, the
   estate, the church, the marriage, the medical
   establishment, the colonial enterprise); the
   gothic secret is rarely just personal
5. UNCONTAINABLE — the truth cannot be re-buried; once
   it surfaces, the world has changed and the
   manuscript's events flow inexorably from the
   surfacing

CALIBRATION TEST
- If the secret were revealed in chapter 1, would the
  reader still want to read the rest of the novel?
  (If yes, the secret is interesting; if no, the
  secret is decoration.)
- Could a reader, after the manuscript ends, name in
  one sentence what the buried truth was, and would
  that sentence justify the atmospheric build-up that
  preceded it?
- Does the truth have material consequence in the
  manuscript's present (legal / financial / social /
  bodily) rather than only emotional consequence?
- Does the revelation reframe characters and
  institutions in a way the reader feels in their
  understanding of earlier scenes?
If any answer is no — rebuild for substance.

ANTI-PATTERN
- The secret turns out to be a long-ago affair with no
  present consequence
- The secret turns out to be that the host was once
  in love with someone else
- The secret turns out to be a minor financial
  irregularity easily resolved
- The secret turns out to be a misunderstanding
- The secret turns out to be already widely known by
  everyone except the protagonist
- The secret turns out to be the same secret as in
  the comp novel the manuscript is pastiching
- The secret is too vague to summarise in one
  sentence even after the manuscript ends
```

### The Doubling Calibration Discipline

Gothic fiction's signature device is the double: the
predecessor whose story parallels the protagonist's,
the portrait that watches, the first wife whose
presence permeates the marriage, the dead twin, the
locked-room occupant, the shadow that mirrors. The
Doubling-Without-Resonance failure mode reduces this
device to period decoration. the portrait is just a
portrait, the dead first wife is just a name dropped
in conversation, the predecessor is mentioned but
their fate carries no live thematic weight on the
protagonist's situation. The Doubling Calibration
Discipline is the requirement that any double deployed
in the manuscript function as live thematic mirror,
with the double's fate functioning as prophecy,
warning, or alternative path.

```
PRINCIPLE
Any double deployed in the manuscript must satisfy at
least three of the following four criteria:
1. SPECIFIC PARALLEL — the double's situation
   parallels the protagonist's in specific
   identifiable ways (same age at arrival, same
   marriage circumstances, same arrival from
   outside, same reading of the household, same
   intelligence, same observational acuity)
2. PROPHETIC FATE — the double's fate is a
   foreshadowing of the protagonist's possible
   future; what happened to the predecessor is what
   may happen to the protagonist if she does not
   change course
3. PROGRESSIVE DISCLOSURE — the protagonist learns
   about the double in fragments across the
   manuscript, with each fragment recontextualising
   her own situation; the double's biography is
   revealed at the gothic's slow pace
4. DECISIVE REVELATION — the truth about what
   actually happened to the double is the manuscript's
   central revelation (or one of two central
   revelations); the double's fate is the gothic's
   buried truth

CALIBRATION TEST
- Does the double appear in the manuscript only as
  decoration (a portrait, a name, a tale told once),
  or does the double's presence build across
  chapters?
- Does the protagonist's understanding of the
  double's fate change her understanding of her
  own situation?
- Does the double's fate constitute a warning the
  protagonist must heed (or a prophecy she may not
  escape)?
- Could the manuscript function with the double
  removed entirely? If yes, the doubling is
  decorative and the technique has not been
  genuinely deployed.
If any answer is no — rebuild the doubling for live
thematic resonance.

ANTI-PATTERN
- The portrait that hangs on the wall and is never
  meaningfully returned to
- The first wife mentioned in chapter 2 and never
  again
- The predecessor whose biography is delivered in
  one paragraph of exposition and never extended
- The double whose fate is unconnected to the
  protagonist's situation
- The double introduced in late chapters as
  revelation device without prior planting
```

### The Investigation-Pace Calibration

The gothic novel's pacing problem is that "atmospheric
slow build" is easily mistaken for "stasis". The genre
demands slow uncovering, but the slow uncovering must
still constitute forward motion. each chapter must
deliver a new piece of the puzzle, must accumulate
atmospheric weight, must tighten the protagonist's
entrapment, and must deepen the reader's compulsion to
continue. The Investigation-Pace Calibration is the
discipline that prevents atmosphere from becoming
inertia.

```
PRINCIPLE
Every chapter must deliver at least three of the
following five forward-motion elements:
1. NEW INFORMATION — the protagonist learns
   something specific (a document found, a
   conversation overheard, a room entered, a
   mystery deepened, a contradiction noticed)
2. ATMOSPHERIC ACCUMULATION — the gothic atmosphere
   advances by at least one element (the season
   darkens, the weather worsens, the house feels
   smaller, the light shifts, a new detail of
   decay surfaces)
3. ENTRAPMENT TIGHTENING — the protagonist's
   ability to leave narrows in some specific way
   (a new social obligation, a new emotional
   bond, a new financial dependence, a new piece
   of physical isolation)
4. RELATIONSHIP SHIFT — the protagonist's
   relationship with at least one other character
   changes (trust shifts, suspicion shifts, an
   alliance forms or breaks, the host's mask
   slips a fraction)
5. INTERNAL ARC PROGRESSION — the protagonist's
   psychological arc moves at least one step
   along the curiosity → unease → obsession →
   fear → resolution trajectory

CALIBRATION TEST
- Read each chapter in isolation: did three of five
  forward-motion elements occur?
- Read consecutive chapters: is there discernible
  movement in the puzzle, the atmosphere, the
  entrapment, the relationships, and the
  protagonist's internal state?
- If you skipped this chapter, would the manuscript
  break? If no, the chapter has not done its
  forward-motion work and must be rebuilt or cut.
- Is the slow build genuinely a slow build, or is
  it stasis dressed as atmosphere?
If any answer is no — restructure for forward motion.

ANTI-PATTERN
- The chapter where the protagonist walks the
  garden, observes the house, and learns nothing
- The chapter where the same revelation is reached
  for the third time without progression
- The chapter where the atmospheric description
  carries the entire weight without any
  investigative or relational advance
- The chapter that exists to maintain mood without
  contributing to plot, character, or theme
- The "breath-catching" chapter that is just
  filler in pretty prose
```

## Genre-Specific Revision Rules

### Six-Pass Gothic Audit (Run FIRST in editorial pipeline)

The Gothic Audit runs every chapter through six named
passes. Run them in order — each builds on the last.

#### Pass 1: Setting-as-Character Pass

Verify the house / estate / institution has presence in
each chapter — not as backdrop but as agent. Audit
the chapter for the house's contribution: does it
exert personality (architecture, weather, light,
decay, mood)? Does the description function as
psychological portraiture rather than as physical
catalogue (the peeling wall reflecting the relationship
coming apart, the locked door mirroring the secret
kept, the overgrown garden paralleling untended
grief)? Does the setting reflect or contrast with the
chapter's emotional content in a way the reader feels?
If a chapter could be transplanted to a generic
location with no loss, the Setting-as-Character
contract has not been honoured and must be rebuilt.
The genre's first commitment is that the house is a
character; chapters where the house is invisible
collapse the genre.

#### Pass 2: Entrapment Pass

Verify the protagonist is still convincingly trapped.
The Tourist-Protagonist failure mode is the most
common genre-collapsing failure in gothic fiction.
For every chapter, audit: what specifically prevents
the protagonist from leaving today? Marriage,
employment, inheritance, kinship obligation, financial
dependence, social ruin, emotional attachment, pursuit
of specific concrete information, physical isolation
(snowed in, no road, no transport)? Has any escape
route opened in this chapter? If yes, has it been
closed before the chapter ends? Does the entrapment
deepen in some specific way (a new obligation, a new
attachment, a new piece of physical isolation, a new
piece of information that must be pursued)? If the
protagonist could leave at the end of the chapter as
easily as at the start, the gothic clock has not
moved and the entrapment must be tightened.

#### Pass 3: Secret Progression Pass

Verify the protagonist has learned something new or
been deliberately misdirected in each chapter. The
gothic novel is built on the slow uncovering of the
buried truth, which means each chapter must contribute
to that uncovering — through a document found, a
conversation overheard, a room entered, a contradiction
noticed, a question raised, a deflection registered.
Audit the chapter: what new piece of the puzzle has
arrived? Is the revelation paced properly (not too
fast — the secret should not unravel in three
chapters; not stalling — three chapters in a row
without a new fragment is too long)? Does each piece
of information create new questions rather than
closing the question set? If a chapter contains no
forward motion on the secret, restructure or cut. The
gothic's contract is that the secret deepens chapter
by chapter; chapters that maintain the secret without
progressing it are filler.

#### Pass 4: Atmosphere Pass

Verify the prose creates the feeling of oppressive
beauty in each chapter. The gothic's signature is the
sublime — beauty and terror coexisting — and the prose
must deliver this through specific sensory craft. Audit
the chapter for atmospheric integrity: are light,
weather, and sensory details present and deliberate
(not generic atmosphere words like "eerie" or
"ominous")? Does the prose track illumination
obsessively (candlelight, moonlight, firelight,
gaslight, the absence of light)? Is sensory weight
present (the weight of air, the chill of stone, the
texture of old fabric, the smell of mildew or old
perfume or wood smoke)? Is there at least one moment
of the gothic sublime — the terrible beauty, the
beautiful decay, the magnificent house with the
dreadful thing inside? If the chapter is competent
prose without atmospheric weight, the genre has
flattened to its plot architecture and must be rebuilt
for sensory craft.

#### Pass 5: Subtext Pass

Verify dialogue operates through implication rather
than exposition. The gothic's contract is that
characters rarely say what they mean — the host's
gracious invitation that is also a command, the
warning disguised as casual conversation, the
confession that sounds like a story about someone
else, the silence that is the most loaded line in the
exchange. Audit each dialogue scene: what is NOT said,
and is it as important as what is said? Does each
exchange operate on at least two levels (surface
conversation + hidden meaning)? Are characters
communicating through tells, deflections, and
pregnant pauses rather than through statements? If
the dialogue reads as flat exposition or as
characters articulating their feelings directly, the
gothic register has slipped. The genre demands
indirection.

#### Pass 6: Buried-Truth + Doubling-Calibration + Investigation-Pace Integration

This pass is the gothic integration check — it ties
the new techniques together and verifies the genre's
structural commitments are honoured chapter by
chapter.

For BURIED-TRUTH: at any point in the manuscript,
audit whether the buried truth — when revealed — will
satisfy at least four of the five Buried-Truth
Architecture criteria (specifically terrible /
materially consequential / character-revelatory /
institution-revelatory / uncontainable). If the
manuscript's secret is being revealed in the audited
chapter (or has just been revealed), confirm the
revelation lands with weight. If the secret is still
ahead, confirm the chapter is planting evidence
toward a secret that will satisfy the spec. The
Mundane-Secret failure mode is caught here — if the
buried truth, when finally exposed, will not justify
the atmospheric build-up, the secret itself must be
deepened or replaced.

For DOUBLING-CALIBRATION: identify the chapter's
deployment of doubling devices (predecessor,
portrait, first wife, dead twin, locked-room
occupant, parallel character). For each, verify the
double is functioning as live thematic mirror rather
than as period decoration. Are at least three of the
four doubling criteria active across the manuscript
(specific parallel / prophetic fate / progressive
disclosure / decisive revelation)? If a double has
been introduced and not returned to, either build the
echo or cut the introduction. The Doubling-Without-
Resonance failure mode is caught here.

For INVESTIGATION-PACE: confirm the chapter delivers
at least three of the five forward-motion elements
(new information / atmospheric accumulation /
entrapment tightening / relationship shift / internal
arc progression). If the chapter delivers fewer, the
gothic clock has stopped and the chapter must be
restructured or cut. The Slow-Reveal-Without-
Forward-Motion failure mode is caught here. atmosphere
without forward motion is stasis dressed as gothic.

## Names & Patterns to Avoid

### Gothic Character Names. NEVER USE
- Melodramatic names: Ravencroft, Darkmoor, Blackwood, Nightingale, Thornfield
- Names from famous gothic novels without transformation: Rochester, de Winter, Heathcliff
- Names that telegraph mystery: Shadow, Silence, Enigma, Grey

### Gothic Location Names. NEVER USE
- "[Adjective] [Estate]": Blackwood Hall, Ravencroft Manor, Darkholm Abbey
- Names with built-in atmosphere: Thornfield (taken), Wuthering (taken), Manderly (taken)
- Any name that sounds like a theme park: "Gothic Towers", "The Mysterious Estate"

### Use Instead
- English country house names: Aldbury Park, Kellfield, Amberstone
- Names that reveal history: named after the family, the geography, or the estate's original purpose
- Foreign settings with authentic naming: Italian palazzo, French château. research the naming conventions
- The name should become sinister through the story, not arrive sinister

## Comp Titles

Gothic's comp-title set (distinct from gothic-horror,
which centres supernatural threat) supports manuscript
positioning: market category placement, cover-design
conversation, reader-expectation calibration, similar-
author discovery, and editorial / agent submission
framing.

### Canonical (foundational reference points)

- *Jane Eyre* — Charlotte Brontë (1847): the gothic archetype.
- *Wuthering Heights* — Emily Brontë (1847): obsessive-love gothic.
- *Rebecca* — Daphne du Maurier (1938): the marriage-gothic template.
- *The Woman in White* — Wilkie Collins (1859): sensation-gothic; mystery-gothic foundation.
- *Turn of the Screw* — Henry James (1898): ambiguous-gothic literary benchmark.

### Contemporary (current best-in-class)

- *Affinity* — Sarah Waters (1999): Victorian-gothic literary benchmark.
- *The Little Stranger* — Sarah Waters (2009): post-war class-gothic.
- *Fingersmith* — Sarah Waters (2002): queer Victorian-gothic; sensation-gothic revival.
- *The Thirteenth Tale* — Diane Setterfield (2006): meta-gothic literary novel.
- *The Essex Serpent* — Sarah Perry (2016): contemporary literary-gothic.
- *Melmoth* — Sarah Perry (2018): contemporary atmospheric gothic.
- *The Silent Companions* — Laura Purcell (2017): Victorian-gothic with haunted-doll architecture.
- *Piranesi* — Susanna Clarke (2020): minimalist atmospheric literary-gothic.
- *In a Dark, Dark Wood* — Ruth Ware (2015): contemporary gothic-suspense.

## Cover Design Specifications

### Recommended Visual Styles
- **Atmospheric**. The house in its landscape: fog, dusk light, a single lit window; the cover should feel like the opening paragraph of the novel
- **Silhouette**. The figure approaching (or trapped within) the architectural outline of the house; stark and evocative
- **Textural**. Close-up details that suggest the house: wallpaper patterns, cracked plaster, old fabric, tarnished metal; tactile and unsettling
- **Typographic**. Elegant typography in a serif face, positioned over a muted or partially obscured image; the restraint IS the aesthetic

### Genre Cover Aesthetics
- **Styles:** Grand houses in atmospheric conditions (fog, twilight, storm), single figures dwarfed by architecture, interior spaces with dramatic light (a candle in a dark hallway, light through a keyhole), overgrown gardens and weathered stone, mirrors and portraits, stairways ascending into darkness
- **Colours:** Deep, muted palette: charcoal, slate, midnight blue, deep burgundy; oxidised greens and tarnished golds; washed-out creams and greys for fog; occasional warmth from a single light source (amber candle, golden window); nothing bright, nothing cheerful
- **Elements:** Architecture (windows, doorways, staircases, rooflines), weather (fog, clouds, rain, snow), vegetation (ivy, bare trees, overgrown paths), light sources (candles, gaslight, moonlight, a single lit window), mirrors and portraits, keys and locked doors, silhouetted figures
- **Typography:** Elegant serif fonts (Garamond, Baskerville, or similar); gold or silver foil effects; the title should feel like an engraving on a tombstone or a nameplate on a door; restrained, refined, and quietly commanding

### Market Positioning
Gothic covers signal "beautiful, oppressive, full of secrets" through atmospheric composition and muted palettes. Position against du Maurier, Moreno-Garcia, Ware, Purcell, Collins. The key is RESTRAINT. one house, one figure, one light source, one mood. Gothic covers are closer to literary fiction than horror in their visual approach. At thumbnail size, the silhouette of a grand house or a single glowing window against darkness is immediately recognisable.

### Cover Design DON'Ts
- No horror imagery (blood, skulls, monsters). gothic is atmospheric, not visceral
- No bright colours or cheerful palettes
- No modern, minimalist graphic design (too clean for gothic)
- No cartoonish or illustrated characters (undermines the tone)
- No generic "woman in a gown running from a house" (the original gothic paperback cliché)
- No over-designed compositions. gothic covers need space for atmosphere
