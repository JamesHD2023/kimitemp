---
name: injury-accumulation
description: "Engine-neutral Class B binding/protocol. Subagent-dispatched semantic audit that scans the manuscript for injury markers, tracks recovery timeline per character, and flags chapters where a character performs an action inconsistent with their then-current injury status. First Class B audit shipped under the canon-validation framework (v2.7.32). Closes the third gap in the Wave 4 sequence (PHYSICS gap-analysis row 3). Invoked by the /validate dispatcher via CLASS_B_AUDIT line emission; the engine layer dispatches a subagent per this spec, applies subagent-output-verification HARD GATE on the return, and merges the verdict into the Validation Briefing."
version: "2.7.37"
---
<!-- The Ideorix writing, editing, and publishing system is copyright (c) 2025-2026 James Harvey Media. All rights reserved. Proprietary software — see LICENSE.txt -->

> **Powered by Ideorix**
> *© James Harvey Media. All rights reserved.*

# Injury-Accumulation Tracker

> **Paired spec:** this file is one half of a parent/delta pair with
> `injury-accumulation-delta.md`. The two share the audit's semantic contract (what counts
> as a motif/injury, evolution rules, report vocabulary) — any change to
> that contract MUST be applied to both files in the same commit, or the
> per-chapter and capstone passes will disagree about what they are
> auditing. Scope differences (per-chapter vs full-manuscript) are the
> intended divergence; semantics are not.

A Class B binding/protocol spec for the PHYSICS domain (per
`canon-validation-taxonomy.md`). Closes the third gap in the
Wave 4 audit-additions sequence (gap-analysis row 3) and is
the **first Class B audit** shipped under the canon-validation
framework — the reference implementation for subsequent
Class B audits (v2.7.33-v2.7.35).

## Why this exists

In chapter 5, a character takes a serious injury — a broken
leg, a concussion, a deep cut, a dislocated shoulder. The
injury constrains their physical capability for some plausible
recovery time: days for a gash, weeks for a fracture, months
for serious orthopaedic work. By chapter 7, they may still be
limping, in a sling, sleeping awkwardly, taking stairs slowly.

The failure mode: by chapter 7, the manuscript has them
sprinting up flights of stairs, throwing punches, scaling
walls — as if chapter 5 never happened. The injury existed
for the chapter that needed it (drama, jeopardy, character
beat) and then quietly evaporated when it became inconvenient.
Readers notice. The trust contract — the writer is paying
attention to the body — collapses.

This is a recognisable PHYSICS-domain failure: the manuscript's
internal physical reality drifts. Single-chapter audits cannot
catch it; the divergence is BETWEEN chapters, in the gap
between the injury and the contradicting action. A semantic
multi-chapter scan with character-state tracking is required.

**Engine-neutral examples.** The audit applies to both fiction
and narrative non-fiction. The fiction example: a protagonist
takes a broken leg in chapter 5 and is sprinting in chapter 7.
The non-fiction example (memoir or biography): the narrator
dislocates a shoulder in chapter 5, and by chapter 7 they're
chopping wood with apparent ease — and there's been no
recovery beat. The structural failure shape is identical; only
the genre framing differs. Analytical NF without character
physical state (reference, self-help, business) returns the
no-injuries-detected PASS automatically.

## Why Class B (subagent), not Class A (bash)

A bash audit cannot perform this check:

- **Detecting "X is injured"** requires reading prose
  semantically (injury markers vary widely: "fell hard against
  the railing", "favoured her right leg", "the cut along his
  forearm needed stitches", "the doctor warned six weeks").
- **Estimating recovery time** requires medical / physical
  plausibility reasoning (a sprained ankle is days; a
  fractured tibia is months; a concussion has its own
  timeline).
- **Detecting "Y action contradicts injury Z"** requires
  matching action semantics to injury impairment (running on
  a broken leg, lifting weights with a dislocated shoulder).
- **Tracking character state across N chapters** is stateful
  reasoning over the manuscript timeline.

The mechanical-bash version would have unacceptable false-
positive rates and miss most real cases. A subagent reading
the prose end-to-end with explicit character-injury tracking
is the right tool.

## How Class B audits are dispatched (v2.7.32 framework)

Class B audits work via a two-phase flow:

**Phase 1 — bash dispatcher emits a marker line.** The
`scripts/validate-dispatcher.sh` orchestrator's
`class_b_audits_for_domain()` registry maps each domain to its
applicable Class B audits. For every Class B audit in scope at
the current `/validate` invocation, the dispatcher emits:

```
CLASS_B_AUDIT|<audit_name>|<domain>|<spec_path>|<severity_cap>
```

The bash dispatcher does NOT itself dispatch the subagent —
bash cannot invoke Claude subagents.

**Phase 2 — engine layer dispatches subagents per spec.** The
slash-command engine (Claude driving `/validate`) reads the
dispatcher's output line by line. For each `CLASS_B_AUDIT`
line, the engine:

1. Reads the linked spec (this file, for the injury-
   accumulation audit) to retrieve the subagent task brief
   and the evidence-bearing return contract.
2. Constructs the Agent tool invocation per the brief.
3. Dispatches the subagent.
4. Receives the subagent's structured return.
5. Applies the `subagent-output-verification.md` HARD GATE on
   the returned evidence (verifies citation shape, presence
   of required fields, absence of hallucination markers).
6. Translates the verified return into a `AUDIT|<audit_name>|
   <domain>|<verdict>|<summary>|-` line equivalent and merges
   it into the final Validation Briefing.

The user sees a unified briefing with Class A and Class B
verdicts side by side; the two-phase mechanics are invisible
unless they fail.

## Subagent task brief (for the injury-accumulation audit)

The slash-command engine constructs the following subagent
brief when this audit is dispatched. Customise only the
project-specific paths; all other content is canonical.

> **Task: Injury-Accumulation Audit**
>
> **Background.** This audit detects PHYSICS-domain failures
> where a character's injury status and subsequent actions
> contradict each other across chapters. You are scanning the
> full manuscript end-to-end with explicit character-state
> tracking.
>
> **Inputs.**
> - `engine-data/chapters/ch*.md` — the manuscript chapters
>   in chapter order
> - `engine-data/research-bible.md` (NF) or
>   `engine-data/story-bible.md` (fiction) — character roster
>   and any pre-existing health conditions
>
> **Procedure.**
> 1. Build a per-character injury ledger by scanning chapters
>    in order. For every chapter, identify any injury event
>    (acute injury, chronic flare-up, surgery, illness onset)
>    and record:
>    - Character name
>    - Chapter and line number of the injury event
>    - Injury description (one short clause)
>    - Estimated recovery duration in chapters (use plausible
>      ranges: bruise 1, sprain 1-2, fracture 6-12, concussion
>      2-4, deep cut 1-3, gunshot 8-16, etc. — round
>      conservatively, prefer longer recovery)
>    - Severity tier: minor (does not constrain action), moderate
>      (constrains heavy exertion), severe (constrains most
>      activity)
> 2. For each injury, project the constrained-window: chapters
>    [injury_chapter, injury_chapter + recovery_estimate].
> 3. Within each constrained window, scan for actions by the
>    same character that are inconsistent with the injury's
>    severity tier (e.g. severe leg injury → no running,
>    sprinting, climbing, kicking; severe arm injury → no
>    lifting, throwing, climbing; concussion → no driving,
>    no fine motor work, no high-stimulus environments
>    described as untroubled).
> 4. For every inconsistency found, record a finding with:
>    - Character name
>    - Injury-source citation (chapter:line)
>    - Contradicting-action citation (chapter:line)
>    - One-clause description of the inconsistency
>    - Severity: WARN (mild stretch — character is exerting
>      but it could be plausible) or FAIL (clear contradiction —
>      the action is incompatible with the injury)
> 5. If the manuscript explicitly addresses the recovery (the
>    character is shown limping, the doctor confirms healing,
>    a time-skip with explicit duration is narrated), note this
>    as a mitigation against findings within that window.
>
> **Return contract (mandatory; subagent output is rejected
> by the engine if not conformant).** Return a structured
> response with the following sections, each populated even
> if empty:
>
> ```
> ## Injury Ledger
> | Character | Chapter:Line | Injury | Severity | Recovery (chapters) |
> |---|---|---|---|---|
> [populated rows; or single row "(no injuries detected)" if none]
>
> ## Findings
> | Severity | Character | Injury Source | Contradicting Action | Inconsistency |
> |---|---|---|---|---|
> [populated rows; or single row "(no inconsistencies detected)" if none]
>
> ## Mitigations Observed
> [bulleted list of explicit recovery / time-skip narrations
> that mitigated otherwise-flaggable windows; or "(none)"]
>
> ## Verdict
> One of: PASS | WARN | FAIL
> - PASS: no findings, or all findings have mitigations
> - WARN: one or more WARN-severity findings, no FAIL findings
> - FAIL: one or more FAIL-severity findings
>
> ## One-Line Summary
> A single line suitable for the Validation Briefing's per-audit
> summary. Format: "<verdict>: <count> finding(s) — <top
> finding character + chapters>" or "PASS: no
> injury-action contradictions detected"
> ```
>
> **Discipline.**
> - Cite every claim with chapter:line. The engine HARD GATE
>   rejects findings without citations.
> - Do NOT speculate beyond what the prose says. If the
>   manuscript is silent on whether the character recovered,
>   project conservatively and flag actions in the constrained
>   window — if the recovery happened off-page, the writer
>   should narrate it on-page.
> - Do NOT flag exertion-as-character-trait (a stoic character
>   pushing through pain) unless the action is physically
>   impossible (broken leg + sprinting). Pushing-through-pain
>   is a craft choice; impossibility is a continuity error.

## Engine HARD GATE on subagent return

Per `subagent-output-verification.md`, the engine applies the
following verification on the subagent's return BEFORE merging
its verdict into the briefing:

1. **Shape check.** All five required sections present
   (Injury Ledger, Findings, Mitigations Observed, Verdict,
   One-Line Summary). Missing section → reject; re-dispatch
   subagent with a "your output was missing section X — please
   re-run" amendment. Maximum 1 retry; if second attempt also
   incomplete, emit `AUDIT|injury-accumulation|PHYSICS|FAIL|
   subagent return non-conformant after retry|-`.
2. **Citation check.** Every row in the Findings table must
   contain a chapter:line citation in BOTH "Injury Source"
   and "Contradicting Action" columns. Findings without
   citations are stripped from the merged result; if all
   findings are stripped and the verdict claimed FAIL, the
   verdict is downgraded to WARN with reason "subagent
   findings lacked citations".
3. **Verdict consistency check.** If Findings table is empty
   but verdict is FAIL/WARN, downgrade to PASS with reason
   "verdict claimed but no findings table populated". If
   Findings has rows but verdict is PASS, upgrade to WARN
   with reason "findings present but verdict claimed PASS".
4. **Hallucination markers.** Reject any finding whose
   Injury Source citation references a chapter that does not
   exist in `engine-data/chapters/` (e.g. "chapter 47" when
   the manuscript has 12 chapters). The subagent has
   fabricated a citation; reject the finding entirely and
   downgrade verdict.
5. **No-injuries-detected special case.** If the Injury
   Ledger contains only the placeholder row "(no injuries
   detected)", the audit's PASS verdict is preserved with
   the empty-ledger summary; no further checks required.
   Manuscripts without injuries (analytical NF, character-
   light fiction) are correctly handled by this branch.

After verification, the engine emits:

```
AUDIT|injury-accumulation|PHYSICS|<verdict>|<one_line_summary>|<subagent_return_path>
```

...where `<subagent_return_path>` is the path to the
subagent's full return saved at
`engine-data/reports/validate/injury-accumulation-subagent.md`
for user inspection.

## How writers should respond to FAILs

Three reasonable responses:

1. **Add explicit recovery narration.** If the action is
   plausible because the character had time to recover off-
   page, narrate it on-page. A single sentence of "two weeks
   later, the cast was off" eliminates the contradiction.
2. **Adjust the action.** If the recovery hasn't happened,
   the action is the bug. Constrain the character to what
   their injury allows.
3. **Adjust the injury.** If the action is structurally
   essential to the chapter, downgrade the original injury
   to something the character can recover from in time.

The audit does not block phase advancement. WARN findings
surface for the writer to consider; FAIL findings surface as
errors the writer almost certainly wants to address but the
final call is theirs.

## Engine-neutral applicability

Both fiction and narrative non-fiction (memoir, biography)
have characters / subjects with bodies that take damage and
recover. Analytical non-fiction (business, self-help, reference)
typically has no character physical state to track; the
subagent runs cleanly on such manuscripts (no injuries
detected → empty ledger → PASS) and is harmless.

## Failure modes prevented

Per `silent-failure-audit.md` row 28:

- **Injury-evaporation cascade** — an injury used for one
  chapter's drama silently disappears for the next chapter's
  action sequence. Caught at validate time when the cost of a
  fix is one paragraph of recovery narration.
- **Validation-coverage misrepresentation** — without this
  audit, the PHYSICS domain has only temporal-verify and
  number-7-bias (both Class A bash, both shallow). With this
  Class B audit, PHYSICS reports COVERED for the
  injury-accumulation sub-domain.
- **Subagent-hallucination cascade** — subagent claims a
  finding citing "ch15:42" when the manuscript ends at ch12.
  Caught by the HARD GATE's hallucination-marker check before
  the user sees the briefing.

## See also

- `canon-validation-taxonomy.md` — the 10-domain index this
  audit closes a gap in (PHYSICS primary-domain table)
- `validate-dispatcher.md` — the dispatcher that emits the
  CLASS_B_AUDIT line; documents the Class B Dispatch Protocol
  (two-phase flow)
- `subagent-output-verification.md` — the HARD GATE applied
  to all subagent returns; enforces citation discipline,
  shape conformance, hallucination-marker rejection
- `silent-failure-audit.md` — catalog of drift-failure shapes;
  this audit adds row 28
- `temporal-verify.sh` — the existing PHYSICS Class A audit
  for chronological-event ordering; complementary to this
  audit, not overlapping
