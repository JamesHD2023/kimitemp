#!/usr/bin/env python3
# ============================================================
# Ideorix — Typography Fix (Python stdlib, v2.7.136)
#
# The WRITE counterpart to typography-sweep.sh (which is scan-only by
# design). Converts ASCII typographic artifacts in narrative prose to
# their curly/publishing equivalents, so the pre-export typography gate
# passes WITHOUT the orchestrator hand-writing a one-off converter every
# time (the recurring anti-pattern).
#
# Converts (curly target, the default):
#   '  -> U+2019  (apostrophe / closing single quote — the dominant prose case)
#   "  -> U+201C / U+201D  (directional: opening vs closing by context)
#   -- -> U+2014  (em-dash; exactly two hyphens, never --- thematic breaks)
#   ...-> U+2026  (ellipsis; exactly three dots)
#
# Leaves untouched (never mutates):
#   - YAML frontmatter (the line-1 --- ... --- block)
#   - fenced code blocks (``` ... ```)
#   - markdown thematic-break / scene-break lines (a line of 3+ hyphens)
#
# Writes via a same-dir temp + atomic rename (the v2.7.134 CIFS lesson):
# a failed write never leaves a truncated/0-byte file.
#
# Usage:
#   typography-fix.py <file.md|file.txt> [--check]
#     (default: fix in place; --check: report only, exit 1 if changes needed)
#
# Exit: 0 ok (fixed, or already clean) · 1 (--check) changes needed · 2 usage
# ============================================================

import argparse
import os
import re
import sys
import uuid

THEMATIC = re.compile(r"^\s*-{3,}\s*$")
FM_DELIM = re.compile(r"^---\s*$")


# Leading-apostrophe elisions that are U+2019, not an opening single quote.
ELISIONS = ("tis", "twas", "em", "cause", "round", "til", "till", "bout",
            "nother", "n")
_OPEN_PREV = " \t([{—–-‘“"   # contexts where a quote opens


def _is_word(ch):
    return ch.isalnum()


def fix_quotes(line):
    """Directional straight single/double quotes -> curly, by context."""
    out = []
    n = len(line)
    for i, ch in enumerate(line):
        prev = line[i - 1] if i > 0 else ""
        nxt = line[i + 1] if i + 1 < n else ""
        if ch == '"':
            out.append("“" if (prev == "" or prev in _OPEN_PREV) else "”")
        elif ch == "'":
            if _is_word(prev):
                out.append("’")                       # contraction / possessive / closing
            elif nxt.isdigit():
                out.append("’")                       # decade elision: '90s
            elif nxt.isalpha():
                # leading apostrophe: known elision -> ’, else opening ‘
                tail = ""
                j = i + 1
                while j < n and line[j].isalpha():
                    tail += line[j]
                    j += 1
                out.append("’" if tail.lower() in ELISIONS else "‘")
            else:
                out.append("’")
        else:
            out.append(ch)
    return "".join(out)


def fix_line(line):
    line = fix_quotes(line)
    line = re.sub(r"(?<!-)--(?!-)", "—", line)   # -- -> em-dash (not ---)
    line = re.sub(r"(?<!\.)\.\.\.(?!\.)", "…", line)  # ... -> ellipsis
    return line


def transform(text):
    lines = text.split("\n")
    out = []
    in_fence = False
    in_fm = False
    for i, line in enumerate(lines):
        # YAML frontmatter: only when the file starts with ---.
        if i == 0 and FM_DELIM.match(line):
            in_fm = True
            out.append(line)
            continue
        if in_fm:
            out.append(line)
            if FM_DELIM.match(line):
                in_fm = False
            continue
        if line.startswith("```"):
            in_fence = not in_fence
            out.append(line)
            continue
        if in_fence or THEMATIC.match(line):
            out.append(line)          # never touch code or scene-break lines
            continue
        out.append(fix_line(line))
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="Fix ASCII typography artifacts (curly target).")
    ap.add_argument("file", help="markdown/text file to fix")
    ap.add_argument("--check", action="store_true",
                    help="report only; exit 1 if changes are needed (no write)")
    args = ap.parse_args()

    if not os.path.isfile(args.file):
        sys.stderr.write("ERROR: file not found: %s\n" % args.file)
        return 2
    ext = os.path.splitext(args.file)[1].lower()
    if ext not in (".md", ".txt", ".markdown"):
        sys.stderr.write("ERROR: unsupported extension %s (need .md/.txt)\n" % ext)
        return 2

    with open(args.file, encoding="utf-8", errors="replace") as fh:
        original = fh.read()
    fixed = transform(original)

    if fixed == original:
        sys.stderr.write("typography-fix: %s already clean\n" % os.path.basename(args.file))
        return 0
    if args.check:
        sys.stderr.write("typography-fix: %s needs fixes\n" % os.path.basename(args.file))
        return 1

    # v2.7.140: PID alone can collide under rapid process cycling — add a
    # random component so concurrent fixes never share a temp path.
    tmp = "%s.tmp.%d.%s" % (args.file, os.getpid(), uuid.uuid4().hex[:8])
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(fixed)
    os.replace(tmp, args.file)
    sys.stderr.write("typography-fix: fixed %s\n" % os.path.basename(args.file))
    return 0


if __name__ == "__main__":
    sys.exit(main())
