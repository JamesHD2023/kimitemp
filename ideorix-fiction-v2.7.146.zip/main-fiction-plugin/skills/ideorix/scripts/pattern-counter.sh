#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 3: Pattern Counter
# Counts all frequency-limited and zero-tolerance AI-ism patterns.
# This is the module that catches "the kind of" x9, "the particular" x4, etc.
# ============================================================
# Usage: bash pattern-counter.sh <chapter-file> [manuscript-totals-file]
# If manuscript-totals-file provided, adds to running totals.

set -euo pipefail

CHAPTER="${1:?Usage: pattern-counter.sh <chapter-file> [totals-file]}"
# Optional 2nd argument (totals-file) reserved for future per-pattern aggregation
# across chapters; not consumed by this script today.

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

# Strip italicised + bold spans (markdown) before counting. Cited paper
# / book / film titles are italicised (e.g. *Most Published Research
# Findings Are False*); flagging crutch words inside them counts the
# referenced work, not the author's prose. Quoted dialogue is NOT
# stripped — character verbal tics remain a legitimate concern.
perl -CSDA -pe '
    s/\*\*[^*\n]+\*\*//g;     # **bold**
    s/__[^_\n]+__//g;         # __bold__
    s/\*[^*\n]+\*//g;         # *italic*
    s/_[^_\n]+_//g;           # _italic_
' "$CHAPTER" > "$TMPDIR/stripped.txt"
# v2.7.143: awk tolower() is locale-aware and multibyte-safe; byte-oriented
# tr could mishandle non-ASCII (curly quotes, accented words), under-counting
# patterns in the lowercased scan (same class as the forbidden-words fix).
awk '{print tolower($0)}' < "$TMPDIR/stripped.txt" > "$TMPDIR/lower.txt"
FAIL=0

echo "=== PATTERN COUNTER ==="
echo "Chapter: $CHAPTER"
echo "Words: $(wc -w < "$CHAPTER")"
echo ""

count_pattern() {
    local label="$1"
    local pattern="$2"
    local cap="$3"
    local tolerance="$4"  # "zero" or "limited"
    local count
    count=$(grep -cE "$pattern" "$TMPDIR/lower.txt" 2>/dev/null || true)
    local status="PASS"
    if [ "$tolerance" = "zero" ] && [ "$count" -gt 0 ]; then
        status="FAIL"
        FAIL=1
    elif [ "$tolerance" = "limited" ] && [ "$count" -gt "$cap" ]; then
        status="FAIL (${count}/${cap})"
        FAIL=1
    elif [ "$tolerance" = "limited" ] && [ "$count" -gt 0 ]; then
        status="OK (${count}/${cap})"
    fi
    printf "  %-45s %3d  cap: %-4s  %s\n" "$label" "$count" "$cap" "$status"
    echo "${label}|${count}" >> "$TMPDIR/counts.txt"
}

# === ZERO-TOLERANCE PATTERNS ===
echo "--- Zero-Tolerance Patterns (0 allowed) ---"
count_pattern "a sense of [emotion]"           "a sense of "                              0 "zero"
count_pattern "there was something about"       "there was something about"                0 "zero"
count_pattern "little did [they] know"          "little did [a-z ]+ know|unbeknownst to"   0 "zero"
count_pattern "the air was thick with"          "the air was thick with"                   0 "zero"
count_pattern "couldn't help but"               "couldn't help but|could not help but"     0 "zero"
count_pattern "couldn't quite name"             "couldn't quite name|could not quite name" 0 "zero"
count_pattern "and in that moment"              "and in that moment|in that moment"        0 "zero"
count_pattern "the silence was deafening"       "the silence was deafening"                0 "zero"
count_pattern "eyes that held [abstraction]"    "eyes that held"                           0 "zero"
count_pattern "weight of [X] settled/shoulders" "the weight of [a-z ]+ (settled|shoulders)"     0 "zero"
count_pattern "the shape of [feeling]"          "the shape of "                            0 "zero"
count_pattern "it's not X, it's Y"             "it's not [a-z ]+, it's |it was not [a-z ]+, it was " 0 "zero"
count_pattern "from X to Y to Z (empty sweep)" "from [a-z]+ to [a-z]+ to "                        0 "zero"

echo ""
echo "--- Zero-Tolerance: Robotic Transitions ---"
count_pattern "furthermore"                     "\\bfurthermore\\b"                        0 "zero"
count_pattern "moreover"                        "\\bmoreover\\b"                           0 "zero"
count_pattern "interestingly"                   "\\binterestingly\\b"                      0 "zero"
count_pattern "notably"                         "\\bnotably\\b"                            0 "zero"
count_pattern "significantly"                   "\\bsignificantly\\b"                      0 "zero"
count_pattern "it's worth noting"               "it's worth noting|it is worth noting"     0 "zero"
count_pattern "it was clear that"               "it was clear that"                        0 "zero"
count_pattern "it was evident that"             "it was evident that"                      0 "zero"
count_pattern "needless to say"                 "needless to say"                          0 "zero"

echo ""
echo "--- Zero-Tolerance: Stage-Direction Atmosphere ---"
count_pattern "the particular [X] that/of"      "the particular [a-z ]+ (that|of) "             0 "zero"
count_pattern "that specific [X] where/that"    "that specific [a-z ]+ (where|that) "           0 "zero"

echo ""
echo "--- Zero-Tolerance: Frame Leaks ---"
count_pattern "Book [N] reference"              "book [0-9]|book one|book two|book three"  0 "zero"
count_pattern "the reader"                      "the reader"                               0 "zero"
count_pattern "the previous chapter"            "the previous chapter|previous section"    0 "zero"
count_pattern "in Chapter [N]"                  "in chapter [0-9]|chapter [0-9]+ of"       0 "zero"

echo ""

# === FREQUENCY-LIMITED PATTERNS (per-chapter) ===
echo "--- Frequency-Limited Patterns ---"
count_pattern "the way [pronoun] [verb]"        "the way (she|he|they|it|i|we|you) "       6 "limited"
count_pattern "which was/were"                  "which (was|were) "                        2 "limited"
count_pattern "the kind/sort/type of [X] that"  "(the kind of|the sort of|the type of|one of those) [a-z ]+ that" 3 "limited"
count_pattern "something about [X]"             "something (about|in|behind) "             2 "limited"
count_pattern "found herself/himself [verb]ing" "found (herself|himself|themselves|itself) " 3 "limited"
count_pattern "as though"                       "as though "                               10 "limited"
count_pattern "it was as if"                    "it was as if "                            2 "limited"
count_pattern "a shiver ran down"               "a shiver ran"                             1 "limited"
count_pattern "filed this away / filed that"    "\\bfiled\\b"                              4 "limited"
count_pattern "couldn't quite [verb]"           "couldn't quite |could not quite "         3 "limited"
count_pattern "not for the first time"          "not for the first time"                   2 "limited"
count_pattern "in fact"                         "\\bin fact\\b"                            2 "limited"

echo ""
echo "--- Chapter Opening/Ending Patterns ---"
# v2.7.40 fix: tolerate the case where the first 5 lines are all
# heading/blank (common when chapters open with `# Title` + several
# `## Subheaders`). Pre-v2.7.40 this aborted under `set -euo pipefail`
# because grep -v returned 1 with no surviving lines, killing the
# whole script before the SUMMARY block was emitted.
FIRST_LINE=$( (head -5 "$CHAPTER" | grep -v '^#' | grep -v '^$' | head -1 | tr '[:upper:]' '[:lower:]') || true )
echo "  First prose line: ${FIRST_LINE:0:80}..."

MORNING_OPEN=$(echo "$FIRST_LINE" | grep -c "morning" 2>/dev/null || true)
WEATHER_OPEN=$(echo "$FIRST_LINE" | grep -cE "rain|sun|wind|cloud|fog|storm|snow|cold|warm|light|dark|grey|gray" 2>/dev/null || true)
echo "  Opens with morning: $MORNING_OPEN"
echo "  Opens with weather: $WEATHER_OPEN"

LAST_PARA=$(tac "$CHAPTER" | grep -v '^$' | head -3 | tr '[:upper:]' '[:lower:]')
PHILOSOPHICAL_END=$(echo "$LAST_PARA" | grep -cE "perhaps|sometimes|in the end|after all|what it meant|meaning of" 2>/dev/null || true)
echo "  Philosophical ending: $PHILOSOPHICAL_END"

echo ""
echo "=== SUMMARY ==="
echo "Zero-tolerance violations: counted above"
echo "Frequency-limited: see per-pattern counts"

if [ "$FAIL" -eq 1 ]; then
    echo "STATUS: FAIL"
    exit 1
else
    echo "STATUS: PASS"
    exit 0
fi
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
