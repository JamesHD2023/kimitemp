#!/usr/bin/env python3
# ============================================================
# Ideorix — Screenplay Renderer (Python stdlib, v2.7.131)
#
# Converts a Fountain screenplay ({Title}.fountain) into an
# industry-layout .docx using ONLY the Python 3 standard library
# (zipfile, re, html, os, sys, argparse, datetime). No external
# dependencies — no `docx` npm package, no python-docx, no pandoc.
#
# This is the screenplay counterpart to manuscript-render.py: it
# closes the "Claude hand-writes a Node.js docx generator for the
# screenplay export" gap (npm-install friction, Write-tool
# truncation, path-with-spaces ENOENT, smart-quote breakage).
#
# Layout per references/format-docx.md "Screenplay DOCX Layout":
#   - US Letter; margins L 1.5" / R 1.0" / T 1.0" / B 0.75"
#   - Courier Prime 12pt, plain, black
#   - Scene heading: flush left, UPPERCASE, space above
#   - Action: flush left
#   - Character cue: indent 2.2", UPPERCASE
#   - Parenthetical: indent 1.6", right indent 1.4"
#   - Dialogue: indent 1.0", right indent 1.5"
#   - Transition: right-aligned, UPPERCASE
#   - Title page: separate first section
# Foundation scope (matches manuscript-render.py): no auto page
# numbers, no MORE/CONT'D pagination, no dual-dialogue tables —
# Word paginates; these are future increments. Output is a valid,
# correctly-styled screenplay DOCX.
#
# Usage:
#   python3 screenplay-render.py <fountain-file> [--output <path>]
# ============================================================
"""Render a Fountain screenplay into a screenplay-layout DOCX (stdlib only)."""

import argparse
import html
import os
import re
import sys
import uuid
import zipfile
from datetime import datetime, timezone

CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>"""

# Body-section header: page number, top-right, "N." (period). Title page is a
# separate section with no header reference, so it stays unnumbered; body
# numbering continues from the title page (first script page shows "2.").
HEADER1_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:p><w:pPr><w:jc w:val="right"/></w:pPr><w:fldSimple w:instr=" PAGE "><w:r><w:t>2</w:t></w:r></w:fldSimple><w:r><w:t>.</w:t></w:r></w:p>
</w:hdr>"""

ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
</Relationships>"""

DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>
</Relationships>"""

# Courier Prime 12pt default; one paragraph style per screenplay element.
STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults>
  <w:rPrDefault><w:rPr><w:rFonts w:ascii="Courier Prime" w:hAnsi="Courier Prime" w:cs="Courier Prime"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:rPrDefault>
  <w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:pPrDefault>
</w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>
<w:style w:type="paragraph" w:styleId="SceneHeading">
  <w:name w:val="Scene Heading"/><w:basedOn w:val="Normal"/><w:next w:val="Action"/><w:qFormat/>
  <w:pPr><w:keepNext/><w:spacing w:before="240" w:after="240"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Action">
  <w:name w:val="Action"/><w:basedOn w:val="Normal"/><w:qFormat/>
  <w:pPr><w:spacing w:after="240"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Character">
  <w:name w:val="Character"/><w:basedOn w:val="Normal"/><w:next w:val="Dialogue"/><w:qFormat/>
  <w:pPr><w:keepNext/><w:spacing w:before="240"/><w:ind w:left="3168"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Parenthetical">
  <w:name w:val="Parenthetical"/><w:basedOn w:val="Normal"/><w:next w:val="Dialogue"/><w:qFormat/>
  <w:pPr><w:keepNext/><w:ind w:left="2304" w:right="2016"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Dialogue">
  <w:name w:val="Dialogue"/><w:basedOn w:val="Normal"/><w:qFormat/>
  <w:pPr><w:ind w:left="1440" w:right="2160"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Transition">
  <w:name w:val="Transition"/><w:basedOn w:val="Normal"/><w:next w:val="SceneHeading"/><w:qFormat/>
  <w:pPr><w:spacing w:before="240" w:after="240"/><w:jc w:val="right"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="Centered">
  <w:name w:val="Centered"/><w:basedOn w:val="Normal"/><w:qFormat/>
  <w:pPr><w:spacing w:after="240"/><w:jc w:val="center"/></w:pPr></w:style>
<w:style w:type="paragraph" w:styleId="TitleCenter">
  <w:name w:val="Title Center"/><w:basedOn w:val="Normal"/><w:qFormat/>
  <w:pPr><w:jc w:val="center"/></w:pPr></w:style>
</w:styles>"""

CORE_XML_TMPL = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>{title}</dc:title>
<dc:creator>{author}</dc:creator>
<dcterms:created xsi:type="dcterms:W3CDTF">{ts}</dcterms:created>
<dcterms:modified xsi:type="dcterms:W3CDTF">{ts}</dcterms:modified>
</cp:coreProperties>"""

# Body section margins: L 1.5" R 1.0" T 1.0" B 0.75". Default header = page no.
BODY_SECTPR = '<w:sectPr><w:headerReference w:type="default" r:id="rId2"/><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1080" w:left="2160" w:header="720"/></w:sectPr>'
DOCUMENT_TMPL = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<w:body>
{body}
""" + BODY_SECTPR + """
</w:body>
</w:document>"""

SCENE_RE = re.compile(r"^(int|ext|est|int\.?/ext|i/e)[\.\s]", re.IGNORECASE)
TRANSITION_RE = re.compile(r"^[A-Z0-9 ]+TO:$")


def xml_escape(text):
    return html.escape(text, quote=False)


def para_xml(style, text, sectpr=""):
    """One <w:p> in the given style. sectpr (if set) embeds a section break."""
    run = ""
    if text:
        run = "<w:r><w:t xml:space=\"preserve\">%s</w:t></w:r>" % xml_escape(text)
    ppr = "<w:pStyle w:val=\"%s\"/>%s" % (style, sectpr)
    return "<w:p><w:pPr>%s</w:pPr>%s</w:p>" % (ppr, run)


def parse_title_page(lines):
    """Return (title_fields dict, body_start_index). Fountain title page is
    Key: Value lines at the very top, ending at the first blank line."""
    fields = {}
    i = 0
    if not lines or ":" not in lines[0]:
        return fields, 0
    key = None
    while i < len(lines):
        line = lines[i]
        if line.strip() == "":
            i += 1
            break
        m = re.match(r"^([A-Za-z ][A-Za-z ]*):\s*(.*)$", line)
        if m:
            key = m.group(1).strip().lower()
            fields[key] = m.group(2).strip()
        elif key is not None and line.startswith((" ", "\t")):
            fields[key] = (fields.get(key, "") + " " + line.strip()).strip()
        else:
            break
        i += 1
    # A valid title page needs at least a recognised key.
    if not any(k in fields for k in ("title", "credit", "author", "authors")):
        return {}, 0
    return fields, i


def classify(line, prev_blank, next_line):
    """Return (style, text) for a non-blank body line. Honours Fountain
    forced-element prefixes; otherwise infers from context."""
    raw = line.rstrip("\n")
    stripped = raw.strip()

    # Forced elements.
    if stripped.startswith("!"):
        return "Action", stripped[1:]
    if stripped.startswith("@"):
        return "Character", stripped[1:].upper()
    if stripped.startswith(".") and not stripped.startswith(".."):
        return "SceneHeading", stripped[1:].upper()
    if stripped.startswith(">") and stripped.endswith("<"):
        return "Centered", stripped[1:-1].strip()
    if stripped.startswith(">"):
        return "Transition", stripped[1:].strip().upper()

    # Scene heading (auto).
    if SCENE_RE.match(stripped):
        return "SceneHeading", stripped.upper()
    # Transition (auto): UPPERCASE line ending in TO:.
    if TRANSITION_RE.match(stripped) and stripped == stripped.upper():
        return "Transition", stripped
    # Parenthetical.
    if stripped.startswith("(") and stripped.endswith(")"):
        return "Parenthetical", stripped
    # Character cue (auto): preceded by blank, UPPERCASE with a letter,
    # followed by a non-blank line (the dialogue).
    if (prev_blank and next_line.strip() != "" and re.search(r"[A-Za-z]", stripped)
            and stripped == stripped.upper() and not stripped.endswith(":")):
        return "Character", stripped
    return "Action", stripped


def parse_body(lines):
    """Yield (style, text) for the screenplay body."""
    # Strip boneyard /* */ and [[notes]].
    text = "\n".join(lines)
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    text = re.sub(r"\[\[.*?\]\]", "", text, flags=re.DOTALL)
    body = text.split("\n")

    out = []
    in_dialogue = False
    for idx, line in enumerate(body):
        stripped = line.strip()
        # Drop sections (#) and synopses (=) — structural, not script.
        if stripped.startswith("#") or stripped.startswith("="):
            continue
        if stripped == "":
            in_dialogue = False
            continue
        prev_blank = (idx == 0) or (body[idx - 1].strip() == "")
        next_line = body[idx + 1] if idx + 1 < len(body) else ""
        style, content = classify(line, prev_blank, next_line)
        # Continuation of a dialogue block: a plain line right under a
        # Character/Parenthetical/Dialogue with no blank gap is Dialogue.
        if not prev_blank and in_dialogue and style == "Action":
            style = "Dialogue"
        if style in ("Character", "Parenthetical", "Dialogue"):
            in_dialogue = True
        else:
            in_dialogue = False
        if content == "":
            continue
        out.append((style, content))
    return out


def build_title_section(fields):
    """Title-page paragraphs ending with the title-section sectPr (no page
    number)."""
    paras = []
    # ~3.5" of top space.
    for _ in range(8):
        paras.append(para_xml("TitleCenter", ""))
    title = fields.get("title", "").upper()
    if title:
        paras.append("<w:p><w:pPr><w:pStyle w:val=\"TitleCenter\"/></w:pPr>"
                     "<w:r><w:rPr><w:b/></w:rPr><w:t xml:space=\"preserve\">%s</w:t></w:r></w:p>"
                     % xml_escape(title))
    credit = fields.get("credit", "Written by")
    author = fields.get("author", fields.get("authors", ""))
    paras.append(para_xml("TitleCenter", ""))
    paras.append(para_xml("TitleCenter", credit))
    paras.append(para_xml("TitleCenter", ""))
    if author:
        paras.append(para_xml("TitleCenter", author))
    if fields.get("source"):
        paras.append(para_xml("TitleCenter", ""))
        paras.append(para_xml("TitleCenter", fields["source"]))
    # Title section break (no page numbers; same page geometry).
    title_sectpr = ('<w:sectPr><w:pgSz w:w="12240" w:h="15840"/>'
                    '<w:pgMar w:top="1440" w:right="1440" w:bottom="1080" w:left="2160"/></w:sectPr>')
    paras.append("<w:p><w:pPr><w:pStyle w:val=\"TitleCenter\"/>%s</w:pPr></w:p>" % title_sectpr)
    return paras


def render(fountain_path, output_path):
    with open(fountain_path, encoding="utf-8", errors="replace") as fh:
        raw = fh.read()
    if "\x00" in raw:
        sys.stderr.write("WARN: NULL bytes found and stripped from %s for this "
                         "render ONLY — the file on disk is corrupted (Write-tool "
                         "padding); regenerate it via the bash-direct write "
                         "protocol.\n" % os.path.basename(fountain_path))
        raw = raw.replace("\x00", "")
    lines = raw.split("\n")

    fields, body_start = parse_title_page(lines)
    body_elements = parse_body(lines[body_start:])
    if not body_elements:
        sys.stderr.write("ERROR: no screenplay content parsed from %s\n" % fountain_path)
        return 4

    paras = []
    if fields:
        paras.extend(build_title_section(fields))
    for style, content in body_elements:
        paras.append(para_xml(style, content))

    document = DOCUMENT_TMPL.format(body="\n".join(paras))
    title = fields.get("title", os.path.splitext(os.path.basename(fountain_path))[0])
    author = fields.get("author", fields.get("authors", ""))
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    core = CORE_XML_TMPL.format(title=xml_escape(title), author=xml_escape(author), ts=ts)

    out_dir = os.path.dirname(output_path)
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    # Same-dir temp + atomic replace (v2.7.134): never leave a 0-byte stub at
    # the final path on failure; final write is an atomic same-FS rename.
    try:
        if os.path.exists(output_path) and os.path.getsize(output_path) == 0:
            os.remove(output_path)
    except OSError:
        pass
    # v2.7.140: PID alone can collide under rapid process cycling — add a
    # random component so concurrent renders never share a temp path.
    tmp_output = "%s.tmp.%d.%s.docx" % (output_path, os.getpid(), uuid.uuid4().hex[:8])
    # v2.7.139: the zip-write itself was unguarded — a failure mid-write
    # (disk full, permission denied after mkdir succeeded) left an orphaned
    # temp on disk and, on Windows/CIFS, collided with the next render.
    # Guard the write, clean up the temp on any failure, and verify the
    # temp is non-trivial before the atomic replace.
    try:
        with zipfile.ZipFile(tmp_output, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", CONTENT_TYPES)
            z.writestr("_rels/.rels", ROOT_RELS)
            z.writestr("word/_rels/document.xml.rels", DOC_RELS)
            z.writestr("word/styles.xml", STYLES_XML)
            z.writestr("word/header1.xml", HEADER1_XML)
            z.writestr("word/document.xml", document)
            z.writestr("docProps/core.xml", core)
        if os.path.getsize(tmp_output) == 0:
            raise OSError("zip write produced a 0-byte file")
        os.replace(tmp_output, output_path)
    except (OSError, zipfile.BadZipFile) as e:
        sys.stderr.write("ERROR: screenplay DOCX write failed: %s\n" % e)
        try:
            os.remove(tmp_output)
        except OSError:
            pass
        return 5
    sys.stderr.write("SCREENPLAY RENDER (python stdlib): wrote %s\n" % output_path)
    return 0


def main():
    ap = argparse.ArgumentParser(description="Render a Fountain screenplay to DOCX (stdlib).")
    ap.add_argument("fountain", help="path to the .fountain file")
    ap.add_argument("--output", help="output .docx path")
    args = ap.parse_args()
    if not os.path.isfile(args.fountain):
        sys.stderr.write("ERROR: fountain file not found: %s\n" % args.fountain)
        return 2
    output = args.output
    if not output:
        base = os.path.splitext(os.path.basename(args.fountain))[0]
        output = os.path.join(os.path.dirname(args.fountain) or ".", base + ".docx")
    return render(args.fountain, output)


if __name__ == "__main__":
    sys.exit(main())
