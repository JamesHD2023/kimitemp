#!/bin/bash
# ============================================================
# Ideorix — Shared Markdown-to-DOCX Manuscript Renderer (v2.7.76)
# Converts a project's chapter markdown files into a single .docx
# manuscript via pandoc, with optional reference template for
# styling and optional YAML config for metadata.
#
# Architecture-level fix for the v2.7.x class of ad-hoc per-project
# DOCX generation scripts that re-implemented markdown parsing
# fresh each time. The most-recent symptom was an infinite-loop on
# literal asterisks in source text (model numbers like "SL*18"
# tripping the parser's italic-emphasis search). Pandoc handles
# this and similar inline edge cases robustly; this script wraps
# pandoc so projects share one tested rendering path instead of
# each writing their own.
#
# v2.7.76 foundation scope:
#   - Single-line chapter title format
#   - Body paragraphs + scene breaks
#   - YAML config for project metadata (title, author)
#   - Optional reference template for styling
#   - Integration with docx-integrity-check.sh
#   - Opt-in via project-config.md
#
# NOT yet supported (incremental follow-up):
#   - Two-line chapter titles
#   - ### Section subheadings inside chapters
#   - Front matter / back matter rendering
#   - Footnotes (pandoc supports them natively but no engine
#     orchestration around placement / formatting)
#   - Genre-specific layouts (cookbook recipe blocks, screenplay)
#   - Multi-volume aggregation
#
# See references/markdown-to-docx-render.md for the full spec.
# ============================================================
# Usage: bash markdown-to-docx-render.sh <project-root> [--output <path>]
#
# <project-root>: path to the Ideorix project (e.g.,
#                 ~/Documents/Ideorix-Projects/My-Book/).
#                 The script reads engine-data/chapters/ch*.md and
#                 (if present) engine-data/render-config.yaml +
#                 engine-data/render-template.docx.
#
# Options:
#   --output <path>    Override default output path
#                      (default since v2.7.92:
#                       <project-root>/manuscript/<title>.docx,
#                       where <title> is the project-root basename)
#   --config <path>    Override config path
#                      (default: <project-root>/engine-data/render-config.yaml)
#   --template <path>  Override reference template path
#                      (default: <project-root>/engine-data/render-template.docx
#                       if present; pandoc default styling otherwise)
#
# Exit codes:
#   0  success — DOCX produced and passed integrity check
#   1  invalid arguments / project structure
#   2  no chapter files found
#   3  pandoc not installed (with install hint)
#   4  pandoc invocation failed
#   5  output DOCX failed integrity check

set -uo pipefail

PROJECT=""
OUTPUT_OVERRIDE=""
CONFIG_OVERRIDE=""
TEMPLATE_OVERRIDE=""

while [ $# -gt 0 ]; do
    case "$1" in
        --output)
            OUTPUT_OVERRIDE="${2:-}"
            shift 2
            ;;
        --config)
            CONFIG_OVERRIDE="${2:-}"
            shift 2
            ;;
        --template)
            TEMPLATE_OVERRIDE="${2:-}"
            shift 2
            ;;
        --help|-h)
            sed -n '/^# Usage:/,/^# Exit codes:/p' "$0" | sed 's/^# //; s/^#//'
            exit 0
            ;;
        *)
            if [ -z "$PROJECT" ]; then
                PROJECT="$1"
            fi
            shift
            ;;
    esac
done

if [ -z "$PROJECT" ]; then
    echo "Usage: markdown-to-docx-render.sh <project-root> [--output <path>] [--config <path>] [--template <path>]" >&2
    exit 1
fi

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project root not found: $PROJECT" >&2
    exit 1
fi

CHAPTER_DIR="$PROJECT/engine-data/chapters"
if [ ! -d "$CHAPTER_DIR" ]; then
    echo "ERROR: chapter directory not found: $CHAPTER_DIR" >&2
    exit 2
fi

# Default paths (overridable via flags)
CONFIG="${CONFIG_OVERRIDE:-$PROJECT/engine-data/render-config.yaml}"
TEMPLATE="${TEMPLATE_OVERRIDE:-$PROJECT/engine-data/render-template.docx}"

# Default output is the user-facing deliverables folder, NOT the
# engine-data audit-trail folder. v2.7.92 fix: the previous default
# (engine-data/manuscript.docx) left the project's manuscript/
# subfolder empty after rendering, so users who navigated there
# expecting the finished file found nothing. Aligns with the
# canonical output convention in format-docx.md and the
# launch-readiness-gate "Manuscript Export" check, which already
# looks for *.docx under manuscript/. Project basename is the
# title (set by create-project-tree.sh from the user's input).
PROJECT_TITLE="$(basename "$PROJECT")"
DEFAULT_OUTPUT="$PROJECT/manuscript/${PROJECT_TITLE}.docx"
OUTPUT="${OUTPUT_OVERRIDE:-$DEFAULT_OUTPUT}"
mkdir -p "$(dirname "$OUTPUT")" 2>/dev/null || true

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INTEGRITY_CHECK="$SCRIPT_DIR/docx-integrity-check.sh"

# Collect chapter files in numeric order. We check chapter discovery
# before pandoc availability because "no chapters" is the more
# specific (and more user-actionable) error when both conditions hold.
shopt -s nullglob 2>/dev/null || true
CHAPTERS=()
while IFS= read -r f; do
    CHAPTERS+=("$f")
done < <(find "$CHAPTER_DIR" -maxdepth 1 -type f -name 'ch*.md' | sort)

if [ "${#CHAPTERS[@]}" -eq 0 ]; then
    echo "ERROR: no chapter files (ch*.md) found in $CHAPTER_DIR" >&2
    exit 2
fi

echo "MANUSCRIPT RENDER: found ${#CHAPTERS[@]} chapter file(s) in $CHAPTER_DIR"

# Pandoc check
if ! command -v pandoc >/dev/null 2>&1; then
    echo "ERROR: pandoc not installed" >&2
    case "$(uname -s)" in
        Darwin) echo "  Install: brew install pandoc" >&2 ;;
        Linux)
            if command -v apt >/dev/null 2>&1; then
                echo "  Install: sudo apt install pandoc" >&2
            elif command -v dnf >/dev/null 2>&1; then
                echo "  Install: sudo dnf install pandoc" >&2
            else
                echo "  Install: see https://pandoc.org/installing.html" >&2
            fi
            ;;
        MINGW*|MSYS*|CYGWIN*) echo "  Install: winget install pandoc" >&2 ;;
        *) echo "  Install: see https://pandoc.org/installing.html" >&2 ;;
    esac
    exit 3
fi

# Optional config: extract title + author for pandoc metadata
TITLE=""
AUTHOR=""
if [ -f "$CONFIG" ]; then
    # Minimal YAML parsing — single-line key: value pairs at top level only.
    # Sufficient for the foundation scope (title + author); incremental
    # follow-ups can extend to richer config via python3.
    TITLE=$(grep -E '^title:' "$CONFIG" | head -1 | sed -E 's/^title:[[:space:]]*//; s/^"//; s/"$//' || true)
    AUTHOR=$(grep -E '^author:' "$CONFIG" | head -1 | sed -E 's/^author:[[:space:]]*//; s/^"//; s/"$//' || true)
fi

# Concatenate chapters into a single staging markdown via same-FS temp.
# Same-FS temp follows the v2.7.73 file-write hygiene rule (Linux /tmp
# would EPERM on Cowork-Windows when mv'd to the Windows-mounted output).
# v2.7.140: PID alone can collide under rapid process cycling — add $RANDOM.
STAGED="$PROJECT/engine-data/.manuscript-staged.tmp.$$.$RANDOM.md"
trap 'rm -f "$STAGED" 2>/dev/null || true' EXIT

# v2.7.127 null-byte auto-recovery: a chapter padded with NULL bytes (the
# Write-tool artifact on some hosts) would otherwise abort the export at the
# staged-file NULL check below. We strip NULLs during concat so the render
# self-heals, but report each affected chapter so the writer knows the source
# file on disk is corrupted and should be regenerated (bash-direct write).
NULL_CHAPTERS=""
for f in "${CHAPTERS[@]}"; do
    if [ "$(LC_ALL=C tr -dc '\000' < "$f" | wc -c | tr -d '[:space:]')" -gt 0 ]; then
        NULL_CHAPTERS="$NULL_CHAPTERS $(basename "$f")"
    fi
done
if [ -n "$NULL_CHAPTERS" ]; then
    echo "WARN: NULL bytes found and stripped for this render in:$NULL_CHAPTERS" >&2
    echo "      The render will proceed, but those chapter files are corrupted" >&2
    echo "      on disk (Write-tool padding). Regenerate them via the bash-direct" >&2
    echo "      write protocol (core-pipeline.md File Operation Policy)." >&2
fi

{
    # Pandoc metadata block (rendered into the docx as title page if
    # the reference template supports it; otherwise inlined as a top
    # heading + by-line).
    if [ -n "$TITLE" ] || [ -n "$AUTHOR" ]; then
        echo "---"
        [ -n "$TITLE" ] && echo "title: \"$TITLE\""
        [ -n "$AUTHOR" ] && echo "author: \"$AUTHOR\""
        echo "---"
        echo ""
    fi

    for f in "${CHAPTERS[@]}"; do
        # Strip per-chapter YAML frontmatter (chapter metadata) so only
        # the prose body lands in the manuscript.
        python3 -c '
import sys
path = sys.argv[1]
with open(path, encoding="utf-8") as fh:
    content = fh.read()
content = content.replace("\x00", "")   # v2.7.127: strip NULL-byte padding
if content.startswith("---"):
    end = content.find("---", 3)
    if end != -1:
        content = content[end + 3:].lstrip()
sys.stdout.write(content)
' "$f"
        echo ""
        echo ""
    done
} > "$STAGED"

# Verify staged file is non-empty and clean before invoking pandoc.
# Same integrity invariants we apply to chapter writes.
if [ ! -s "$STAGED" ]; then
    echo "ERROR: staged manuscript is zero bytes ($STAGED) — aborting" >&2
    exit 4
fi
if [ "$(LC_ALL=C tr -dc '\000' < "$STAGED" | wc -c | tr -d '[:space:]')" -gt 0 ]; then
    echo "ERROR: staged manuscript contains NULL bytes ($STAGED) — aborting" >&2
    exit 4
fi

# v2.7.138 scene-break normalisation: replace markdown horizontal-rule lines
# (---, ***, ___, * * *, and the # / # # # SMF variants) with a centered
# "* * *" paragraph. Pandoc's default markdown→docx converts ---/***/___ to
# a VML horizontal rule (<v:rect o:hr="t"/>), which renders as a full-width
# line across the page — wrong for manuscript output (KDP / print / agent
# submission all expect a centered glyph, not a horizontal line). We emit
# raw OpenXML so the paragraph has explicit centered alignment + 12pt
# spacing above/below without depending on the reference template defining
# a SceneBreak style.
python3 - "$STAGED" <<'PY'
import re, sys
path = sys.argv[1]
with open(path, encoding="utf-8") as fh:
    text = fh.read()

# Skip the top YAML metadata block (the bash script may have emitted one
# above the chapter content) so its --- delimiters are not mistaken for
# scene breaks. The block must START at byte 0 with "---\n".
head, rest = "", text
if text.startswith("---\n"):
    end = text.find("\n---\n", 4)
    if end != -1:
        head = text[: end + 5]
        rest = text[end + 5 :]

HR_LINE = re.compile(
    r"^[ \t]*(?:"
    r"\*[ \t]*\*[ \t]*\*[ \t*]*"   # *** / * * * / * * * *
    r"|-{3,}"                       # ---
    r"|_{3,}"                       # ___
    r"|#(?:[ \t]*#){0,3}"           # # / # # / # # #
    r")[ \t]*$"
)

OPENXML_REPL = (
    "```{=openxml}\n"
    '<w:p><w:pPr><w:jc w:val="center"/>'
    '<w:spacing w:before="240" w:after="240"/></w:pPr>'
    "<w:r><w:t>* * *</w:t></w:r></w:p>\n"
    "```"
)

lines = rest.split("\n")
out = []
for i, line in enumerate(lines):
    if not HR_LINE.match(line):
        out.append(line)
        continue
    # Markdown HR rule: must be surrounded by blank lines (or doc edges).
    # If the previous line has content, "---" is actually a Setext H2
    # underline and we leave it alone.
    prev_blank = (i == 0) or (not lines[i - 1].strip())
    next_blank = (i == len(lines) - 1) or (not lines[i + 1].strip())
    if prev_blank and next_blank:
        out.append(OPENXML_REPL)
    else:
        out.append(line)

with open(path, "w", encoding="utf-8") as fh:
    fh.write(head + "\n".join(out))
PY

# Pre-clear a stale 0-byte output from a prior failed run (best-effort) so it
# cannot block the write on a Windows/CIFS mount.
if [ -f "$OUTPUT" ] && [ ! -s "$OUTPUT" ]; then
    rm -f "$OUTPUT" 2>/dev/null || true
fi

# Invoke pandoc. Reference template is optional; pandoc uses sensible defaults.
# v2.7.134: render to a same-dir temp, then move into place — pandoc never
# leaves a 0-byte stub at $OUTPUT on failure, and the final write is a same-FS
# rename (the reliable pattern on Windows/CIFS mounts).
OUT_TMP="$(dirname "$OUTPUT")/.manuscript-render.$$.$RANDOM.docx"
PANDOC_ARGS=(-f markdown -t docx -o "$OUT_TMP")
if [ -f "$TEMPLATE" ]; then
    PANDOC_ARGS+=(--reference-doc="$TEMPLATE")
    echo "MANUSCRIPT RENDER: using reference template $TEMPLATE"
else
    echo "MANUSCRIPT RENDER: no reference template found at $TEMPLATE — using pandoc defaults"
fi

if ! pandoc "${PANDOC_ARGS[@]}" "$STAGED" 2>/dev/null; then
    echo "ERROR: pandoc invocation failed" >&2
    echo "  Re-running with stderr surfaced for diagnosis:" >&2
    pandoc "${PANDOC_ARGS[@]}" "$STAGED" >&2 || true
    rm -f "$OUT_TMP" 2>/dev/null || true
    exit 4
fi
if ! mv -f "$OUT_TMP" "$OUTPUT" 2>/dev/null; then
    echo "ERROR: could not move rendered docx into place at $OUTPUT" >&2
    rm -f "$OUT_TMP" 2>/dev/null || true
    exit 4
fi

echo "MANUSCRIPT RENDER: wrote $OUTPUT"

# Post-render integrity check (v2.7.64 docx-integrity-check.sh catches
# NULL bytes in word/document.xml — same shape we catch for chapter
# markdown writes).
if [ -f "$INTEGRITY_CHECK" ]; then
    if bash "$INTEGRITY_CHECK" "$OUTPUT" >/dev/null 2>&1; then
        echo "MANUSCRIPT RENDER: PASS — integrity check clean"
    else
        echo "ERROR: output DOCX failed integrity check ($OUTPUT)" >&2
        echo "  Run: bash $INTEGRITY_CHECK $OUTPUT" >&2
        echo "  for the full diagnostic." >&2
        exit 5
    fi
else
    echo "MANUSCRIPT RENDER: WARN — docx-integrity-check.sh not found at $INTEGRITY_CHECK"
    echo "  Output produced but not verified."
fi

exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
