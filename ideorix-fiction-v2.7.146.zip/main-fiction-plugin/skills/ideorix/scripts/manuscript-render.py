#!/usr/bin/env python3
# ============================================================
# Ideorix — Manuscript Renderer (Python stdlib, v2.7.93)
#
# Generates a valid .docx manuscript from engine-data/chapters/ch*.md
# using only the Python 3 standard library (zipfile, re, html, sys,
# os, argparse, datetime). No external dependencies — pandoc,
# python-docx, etc. are NOT required.
#
# Shipped as the no-dependency fallback under scripts/manuscript-
# render.sh (the chooser): when pandoc is present the chooser uses
# the higher-quality pandoc renderer; otherwise it falls back to
# this script. Together they give every Ideorix user a working
# DOCX export out of the box on macOS, Windows, and Linux without
# requiring any install step beyond Python 3 (which Python users
# already have).
#
# Output format per references/format-docx.md:
#   - Chapter title → Heading1 (24pt bold centered)
#   - Body paragraphs → BodyText style (0.5" first-line indent,
#     double line-spacing, justified)
#   - First paragraph after a heading or scene-break →
#     FirstParagraph style (no first-line indent — conventional
#     novel typesetting)
#   - Scene breaks (* * * or ***) → SceneBreak style (centered)
#   - Inline **bold** and *italic* recognised (CommonMark-ish
#     word-boundary rule for italics so SL*18 stays literal)
#   - Em-dashes, curly quotes, en-dashes preserved verbatim
#   - YAML frontmatter stripped (per per-chapter convention)
# ============================================================
"""Render an Ideorix project's chapter markdown into a single
DOCX manuscript using Python 3 stdlib only.

Usage:
    python3 manuscript-render.py <project-root> [--output <path>]
                                  [--title <title>] [--author <name>]
"""

import argparse
import html
import os
import re
import sys
import uuid
import zipfile
from datetime import datetime, timezone

# v2.7.141: chapters that needed NULL-byte self-healing this render — the
# per-file warning can scroll away; a final summary next to the success
# line makes the corrupted-source state impossible to miss.
NULL_BYTE_FILES = []


CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>"""

# v2.7.133: centered page number in the footer (novel convention per
# format-docx.md). Numbering runs from page 1.
FOOTER1_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:fldSimple w:instr=" PAGE "><w:r><w:t>1</w:t></w:r></w:fldSimple></w:p>
</w:ftr>"""

ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
</Relationships>"""

DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>
</Relationships>"""

STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults>
  <w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:rPrDefault>
  <w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:pPrDefault>
</w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal">
  <w:name w:val="Normal"/>
  <w:qFormat/>
</w:style>
<w:style w:type="paragraph" w:styleId="BodyText">
  <w:name w:val="Body Text"/>
  <w:basedOn w:val="Normal"/>
  <w:qFormat/>
  <w:pPr>
    <w:spacing w:after="0" w:line="480" w:lineRule="auto"/>
    <w:ind w:firstLine="720"/>
    <w:jc w:val="both"/>
  </w:pPr>
</w:style>
<w:style w:type="paragraph" w:styleId="FirstParagraph">
  <w:name w:val="First Paragraph"/>
  <w:basedOn w:val="BodyText"/>
  <w:qFormat/>
  <w:pPr>
    <w:ind w:firstLine="0"/>
  </w:pPr>
</w:style>
<w:style w:type="paragraph" w:styleId="Heading1">
  <w:name w:val="heading 1"/>
  <w:basedOn w:val="Normal"/>
  <w:next w:val="FirstParagraph"/>
  <w:qFormat/>
  <w:pPr>
    <w:spacing w:before="480" w:after="240" w:line="240" w:lineRule="auto"/>
    <w:jc w:val="center"/>
    <w:keepNext/>
    <w:pageBreakBefore/>
  </w:pPr>
  <w:rPr><w:b/><w:sz w:val="36"/></w:rPr>
</w:style>
<w:style w:type="paragraph" w:styleId="SceneBreak">
  <w:name w:val="Scene Break"/>
  <w:basedOn w:val="Normal"/>
  <w:next w:val="FirstParagraph"/>
  <w:qFormat/>
  <w:pPr>
    <w:spacing w:before="240" w:after="240" w:line="240" w:lineRule="auto"/>
    <w:jc w:val="center"/>
  </w:pPr>
</w:style>
</w:styles>"""

CORE_XML_TMPL = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:title>{title}</dc:title>
<dc:creator>{author}</dc:creator>
<dcterms:created xsi:type="dcterms:W3CDTF">{ts}</dcterms:created>
<dcterms:modified xsi:type="dcterms:W3CDTF">{ts}</dcterms:modified>
</cp:coreProperties>"""

DOCUMENT_TMPL = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<w:body>
{body}
<w:sectPr><w:footerReference w:type="default" r:id="rId2"/><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:footer="720"/></w:sectPr>
</w:body>
</w:document>"""


# Inline markdown patterns.
# Bold first (longer markers), then italic.  Both markers require
# word-boundary context (no alphanumeric immediately outside the
# `*`s) so literal asterisks like "SL*18" stay literal, and a bold
# `**` doesn't accidentally span from one word to another across
# unrelated text.  Internal `*` inside `**...**` voids the bold
# match (so "**Marantz SL*18**" renders as the literal string
# rather than mis-styling the surrounding prose).
INLINE_PATTERN = re.compile(
    r"((?<![A-Za-z0-9])\*\*[^*\n]+?\*\*(?![A-Za-z0-9])"            # **bold**
    r"|(?<![A-Za-z0-9])\*[^\s*][^*\n]*?[^\s*]\*(?![A-Za-z0-9])"    # *italic*
    r"|(?<![A-Za-z0-9])\*[^\s*]\*(?![A-Za-z0-9]))"                  # *x*
)
SCENE_BREAK_PATTERN = re.compile(
    r"^("
    r"[\s\*]*\*[\s\*]*"      # asterisks: ***, * * *, * * * *
    r"|-{3,}\s*"             # markdown HR: --- (also pandoc's HR)
    r"|_{3,}\s*"             # markdown HR: ___
    r"|#(?:\s*#){1,3}\s*"    # standard manuscript format: # or # # #
    r")$"
)
HEADING_PATTERN = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$")


def strip_frontmatter(text):
    """Strip YAML frontmatter (between --- delimiters at file head)."""
    if text.startswith("---\n"):
        end = text.find("\n---\n", 4)
        if end != -1:
            return text[end + 5:]
        end = text.find("\n---", 4)
        if end != -1:
            return text[end + 4:].lstrip("\n")
    return text


def parse_inline(text):
    """Tokenise a single paragraph string into [(style_tuple, text), ...].

    style_tuple uses 'b' for bold and 'i' for italic.  Plain text is
    style ().  Unmatched asterisks stay literal (so 'SL*18' renders
    as 'SL*18' verbatim).
    """
    runs = []
    pos = 0
    for m in INLINE_PATTERN.finditer(text):
        if m.start() > pos:
            runs.append(((), text[pos:m.start()]))
        token = m.group(1)
        if token.startswith("**") and token.endswith("**") and len(token) >= 4:
            runs.append((("b",), token[2:-2]))
        elif token.startswith("*") and token.endswith("*") and len(token) >= 2:
            runs.append((("i",), token[1:-1]))
        else:
            runs.append(((), token))
        pos = m.end()
    if pos < len(text):
        runs.append(((), text[pos:]))
    return runs or [((), "")]


def render_run(styles, text):
    if not text:
        return ""
    rpr = ""
    if styles:
        parts = []
        if "b" in styles:
            parts.append("<w:b/>")
        if "i" in styles:
            parts.append("<w:i/>")
        rpr = "<w:rPr>" + "".join(parts) + "</w:rPr>"
    escaped = html.escape(text, quote=False)
    return (
        "<w:r>"
        + rpr
        + '<w:t xml:space="preserve">'
        + escaped
        + "</w:t></w:r>"
    )


def render_paragraph(style_name, runs):
    body = "".join(render_run(s, t) for s, t in runs) or "<w:r><w:t/></w:r>"
    return (
        "<w:p>"
        + f'<w:pPr><w:pStyle w:val="{style_name}"/></w:pPr>'
        + body
        + "</w:p>"
    )


def chapter_paragraphs(md_path):
    """Yield (style_name, runs) tuples for one chapter file."""
    with open(md_path, encoding="utf-8") as fh:
        raw = fh.read()
    # v2.7.127 null-byte auto-recovery: a chapter padded with NULL bytes (the
    # Write-tool artifact on some hosts) is stripped so the render self-heals;
    # we report it so the writer knows the source file on disk is corrupted.
    if "\x00" in raw:
        sys.stderr.write(
            "WARN: NULL bytes found and stripped for this render in %s — the "
            "source file is corrupted on disk (Write-tool padding); regenerate "
            "it via the bash-direct write protocol.\n" % os.path.basename(md_path)
        )
        NULL_BYTE_FILES.append(os.path.basename(md_path))
        raw = raw.replace("\x00", "")
    text = strip_frontmatter(raw)

    lines = text.split("\n")
    buf = []
    in_section_index = 0  # 0 = first paragraph after heading / scene break

    def flush_buf():
        nonlocal in_section_index
        if not buf:
            return
        joined = " ".join(line.strip() for line in buf if line.strip())
        if not joined:
            buf.clear()
            return
        style = "FirstParagraph" if in_section_index == 0 else "BodyText"
        paragraphs.append((style, parse_inline(joined)))
        in_section_index += 1
        buf.clear()

    paragraphs = []
    in_code = False
    for line in lines:
        stripped = line.strip()

        if stripped.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue

        # Check scene-break BEFORE heading: the SMF hash variant ("#" or
        # "# # #" alone on a line) would otherwise be caught by the
        # broader HEADING_PATTERN (which treats "# foo" as an H1 with
        # text "foo"). Scene-break patterns are narrow and unambiguous,
        # so checking them first is safe.
        if stripped and SCENE_BREAK_PATTERN.match(stripped):
            flush_buf()
            paragraphs.append(("SceneBreak", [((), "* * *")]))
            in_section_index = 0
            continue

        m = HEADING_PATTERN.match(line)
        if m:
            flush_buf()
            heading_text = m.group(2)
            style_name = "Heading1" if len(m.group(1)) == 1 else "FirstParagraph"
            paragraphs.append((style_name, parse_inline(heading_text)))
            in_section_index = 0
            continue

        if not stripped:
            flush_buf()
            continue

        buf.append(line)

    flush_buf()
    return paragraphs


def collect_chapters(chapter_dir):
    if not os.path.isdir(chapter_dir):
        return []
    chapter_re = re.compile(r"^ch\d+.*\.md$", re.IGNORECASE)
    matches = [
        os.path.join(chapter_dir, name)
        for name in os.listdir(chapter_dir)
        if chapter_re.match(name)
    ]
    return sorted(matches)


def main():
    ap = argparse.ArgumentParser(description="Render an Ideorix manuscript to DOCX (Python stdlib).")
    ap.add_argument("project_root", help="Path to the project root (contains engine-data/)")
    ap.add_argument("--output", help="Override output DOCX path")
    ap.add_argument("--title", help="Override manuscript title (defaults to basename of project root)")
    ap.add_argument("--author", default="", help="Author name for DOCX core properties")
    # Accept-and-ignore the flags pandoc renderer takes, for chooser-compat:
    ap.add_argument("--config", help=argparse.SUPPRESS)
    ap.add_argument("--template", help=argparse.SUPPRESS)
    args = ap.parse_args()

    project_root = os.path.abspath(args.project_root)
    if not os.path.isdir(project_root):
        print(f"ERROR: project root not found: {project_root}", file=sys.stderr)
        sys.exit(2)

    chapter_dir = os.path.join(project_root, "engine-data", "chapters")
    chapters = collect_chapters(chapter_dir)
    if not chapters:
        print(f"ERROR: no chapter files (ch*.md) found in {chapter_dir}", file=sys.stderr)
        sys.exit(2)

    title = args.title or os.path.basename(project_root.rstrip(os.sep)) or "Manuscript"
    output = args.output or os.path.join(project_root, "manuscript", f"{title}.docx")
    out_dir = os.path.dirname(output)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    body_parts = []
    for ch in chapters:
        for style_name, runs in chapter_paragraphs(ch):
            body_parts.append(render_paragraph(style_name, runs))

    body_xml = "\n".join(body_parts) if body_parts else "<w:p/>"
    document_xml = DOCUMENT_TMPL.format(body=body_xml)
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    core_xml = CORE_XML_TMPL.format(
        title=html.escape(title, quote=False),
        author=html.escape(args.author, quote=False),
        ts=ts,
    )

    # Write to a same-dir temp then atomically replace the final path
    # (v2.7.134): a failed write never leaves a 0-byte stub at the final
    # path (the stub then blocks retries on a Windows/CIFS mount), and the
    # final write is an atomic same-FS rename. Clear a stale 0-byte stub
    # from a prior failed run first (best-effort).
    try:
        if os.path.exists(output) and os.path.getsize(output) == 0:
            os.remove(output)
    except OSError:
        pass
    # v2.7.140: PID alone can collide under rapid process cycling — add a
    # random component so concurrent renders never share a temp path.
    tmp_output = "%s.tmp.%d.%s.docx" % (output, os.getpid(), uuid.uuid4().hex[:8])
    with zipfile.ZipFile(tmp_output, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CONTENT_TYPES)
        z.writestr("_rels/.rels", ROOT_RELS)
        z.writestr("word/_rels/document.xml.rels", DOC_RELS)
        z.writestr("word/document.xml", document_xml)
        z.writestr("word/styles.xml", STYLES_XML)
        z.writestr("word/footer1.xml", FOOTER1_XML)
        z.writestr("docProps/core.xml", core_xml)
    os.replace(tmp_output, output)

    print(f"MANUSCRIPT RENDER (python stdlib): wrote {output}")
    if NULL_BYTE_FILES:
        print("WARN: %d source file(s) contained NULL bytes and were self-healed "
              "for this render ONLY — the files on disk are still corrupted: %s. "
              "Regenerate them via the bash-direct write protocol."
              % (len(NULL_BYTE_FILES), ", ".join(NULL_BYTE_FILES)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
