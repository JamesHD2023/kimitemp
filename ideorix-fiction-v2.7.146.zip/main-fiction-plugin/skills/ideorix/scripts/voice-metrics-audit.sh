#!/bin/bash
# ============================================================
# Ideorix — Voice Metrics Audit (v2.7.65)
# Per-chapter author-voice measurement. Records:
#   - FP ratio (paragraphs containing first-person pronouns /
#     total paragraphs)
#   - sentence-length median / mean / max
#   - total paragraphs, total sentences, total words
# into engine-data/reports/voice-metrics-ledger.md so the
# voice-trend-audit can spot drift across chapters.
#
# Per-chapter measurement is INFORMATIONAL — it never fails on
# its own. The boiled-frog drift pattern (Vol 2 of the user's
# series shipped with 13 chapters at FP=0.000 and a window-mean
# below 0.020) is only detectable across chapters; that's the
# trend audit's job. This script's only failure modes are setup
# errors (missing chapter file, malformed args).
# ============================================================
# Usage: bash voice-metrics-audit.sh <chapter-file> [<project-root>]
#
# Reads optional targets from <project-root>/engine-data/voice-profile.md:
#   fp_target:        <float, default 0.20>
#   sentence_band_min: <int, default 13>
#   sentence_band_max: <int, default 19>
#
# Exit codes:
#   0  measurement recorded (always, when args + chapter valid)
#   2  invalid arguments / chapter missing

set -euo pipefail

CHAPTER="${1:?Usage: voice-metrics-audit.sh <chapter-file> [<project-root>]}"
PROJECT="${2:-}"

if [ ! -f "$CHAPTER" ]; then
    echo "ERROR: chapter file not found: $CHAPTER" >&2
    exit 2
fi
if [ ! -s "$CHAPTER" ]; then
    echo "ERROR: chapter file is empty: $CHAPTER" >&2
    exit 2
fi

CHAPTER_NAME=$(basename "$CHAPTER" .md)
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# Resolve voice-profile.md targets if available. Fall back to defaults
# matching the design-doc targets for the user's NF memoir series:
# FP ratio 0.20, sentence-length band 13-19.
FP_TARGET="0.20"
BAND_MIN="13"
BAND_MAX="19"
VOICE_PROFILE=""
if [ -n "$PROJECT" ] && [ -f "$PROJECT/engine-data/voice-profile.md" ]; then
    VOICE_PROFILE="$PROJECT/engine-data/voice-profile.md"
    val=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*fp_target:' "$VOICE_PROFILE" 2>/dev/null \
        | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*fp_target:[[:space:]]*//' \
        | awk '{print $1}' || true)
    if [ -n "$val" ]; then FP_TARGET="$val"; fi
    val=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*sentence_band_min:' "$VOICE_PROFILE" 2>/dev/null \
        | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*sentence_band_min:[[:space:]]*//' \
        | awk '{print $1}' || true)
    if [ -n "$val" ]; then BAND_MIN="$val"; fi
    val=$(grep -iE '^[[:space:]]*[-*+]?[[:space:]]*sentence_band_max:' "$VOICE_PROFILE" 2>/dev/null \
        | head -1 | sed -E 's/^[[:space:]]*[-*+]?[[:space:]]*sentence_band_max:[[:space:]]*//' \
        | awk '{print $1}' || true)
    if [ -n "$val" ]; then BAND_MAX="$val"; fi
    # v2.7.144: when a voice-profile.md EXISTS but a key is absent, the
    # default silently stood in — a writer who typo'd fp_target never
    # learned their target wasn't being used. Surface every substitution.
    grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*fp_target:' "$VOICE_PROFILE" 2>/dev/null \
        || echo "NOTE: fp_target not found in voice-profile.md — using default $FP_TARGET"
    grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*sentence_band_min:' "$VOICE_PROFILE" 2>/dev/null \
        || echo "NOTE: sentence_band_min not found in voice-profile.md — using default $BAND_MIN"
    grep -qiE '^[[:space:]]*[-*+]?[[:space:]]*sentence_band_max:' "$VOICE_PROFILE" 2>/dev/null \
        || echo "NOTE: sentence_band_max not found in voice-profile.md — using default $BAND_MAX"
fi

# v2.7.67: locate the paragraph-classifier artifact for this chapter if
# one exists. When present + fresh (artifact mtime newer than the
# chapter file's), voice-metrics-audit computes a semantic_fp_ratio
# alongside the syntactic fp_ratio. Stale artifacts are ignored — they
# would describe a previous version of the chapter.
CLASSIFIER_ARTIFACT=""
CLASSIFIER_STATUS="ABSENT"
if [ -n "$PROJECT" ]; then
    CHAPTER_BASENAME=$(basename "$CHAPTER" .md)
    CHAPTER_NUM_PART=$(echo "$CHAPTER_BASENAME" | sed -E 's/^ch//' | sed -E 's/[^0-9].*$//')
    if [ -n "$CHAPTER_NUM_PART" ]; then
        CHAPTER_NN_FOR_ART=$(printf '%02d' "$CHAPTER_NUM_PART" 2>/dev/null || echo "")
        if [ -n "$CHAPTER_NN_FOR_ART" ]; then
            ART="$PROJECT/engine-data/reports/validate/paragraph-classifier-ch${CHAPTER_NN_FOR_ART}-subagent.md"
            if [ -f "$ART" ]; then
                CH_MTIME=$(stat -c %Y "$CHAPTER" 2>/dev/null || stat -f %m "$CHAPTER" 2>/dev/null || echo 0)
                ART_MTIME=$(stat -c %Y "$ART" 2>/dev/null || stat -f %m "$ART" 2>/dev/null || echo 0)
                if [ "$ART_MTIME" -ge "$CH_MTIME" ]; then
                    CLASSIFIER_ARTIFACT="$ART"
                    CLASSIFIER_STATUS="FRESH"
                else
                    CLASSIFIER_STATUS="STALE"
                fi
            fi
        fi
    fi
fi

# Compute metrics. Python keeps the paragraph + sentence parsing readable
# and avoids the awk gymnastics that bit number-7-bias.sh in v2.7.59.
METRICS=$(python3 - "$CHAPTER" "$CLASSIFIER_ARTIFACT" <<'PY'
import re
import sys
from statistics import median

path = sys.argv[1]
classifier_path = sys.argv[2] if len(sys.argv) > 2 else ""
with open(path, encoding="utf-8", errors="replace") as f:
    text = f.read()

# Strip YAML frontmatter (only when line 1 is exactly `---`).
lines = text.split("\n")
if lines and lines[0].strip() == "---":
    i = 1
    while i < len(lines) and lines[i].strip() != "---":
        i += 1
    if i < len(lines):
        text = "\n".join(lines[i+1:])

# Drop markdown headings (#...) and horizontal-rule lines (---, ***)
# so they don't get counted as paragraphs.
cleaned = []
for ln in text.split("\n"):
    s = ln.strip()
    if s.startswith("#"): continue
    if re.fullmatch(r"[-*_]{3,}", s): continue
    cleaned.append(ln)
text = "\n".join(cleaned)

# Paragraphs split on blank lines.
paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
total_paragraphs = len(paragraphs)

# First-person detection: paragraph is FP if it contains any FP pronoun
# as a standalone word. Matches the diagnostic the user ran against the
# 6-book series. Pronouns are case-insensitive but only count when they
# appear as whole words (the \b regex below).
FP_RE = re.compile(r"\b(I|me|my|mine|myself|we|us|our|ours|ourselves)\b", re.IGNORECASE)
fp_paragraphs = sum(1 for p in paragraphs if FP_RE.search(p))
fp_ratio = (fp_paragraphs / total_paragraphs) if total_paragraphs > 0 else 0.0

# Sentence tokenization: split on .!? followed by whitespace + capital
# letter or end-of-string. Crude but stable across the existing scripts'
# style. Skip empty / single-word artifacts.
all_sentences = []
for p in paragraphs:
    # Normalise whitespace inside paragraph for sentence-splitting.
    flat = re.sub(r"\s+", " ", p)
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'“])", flat)
    for s in parts:
        s = s.strip()
        if not s: continue
        # Count words; skip degenerate fragments (< 2 words).
        words = re.findall(r"[A-Za-z][A-Za-z'’\-]*", s)
        if len(words) >= 2:
            all_sentences.append(len(words))

total_sentences = len(all_sentences)
total_words = sum(all_sentences)
if total_sentences > 0:
    s_median = median(all_sentences)
    s_mean = total_words / total_sentences
    s_max = max(all_sentences)
else:
    s_median = 0
    s_mean = 0.0
    s_max = 0

# Semantic FP ratio (v2.7.67) — only computed when a fresh
# paragraph-classifier artifact is provided. The artifact's per-
# paragraph table is parsed; semantic numerator counts FP-containing
# paragraphs whose class is ANCHOR-NARRATIVE or ANALYTICAL-AUTHOR;
# semantic denominator is the count of such paragraphs.
#
# Returns "N/A" when:
#   - no classifier path supplied
#   - artifact unreadable
#   - row count mismatches chapter paragraph count by > 1 (the
#     classifier's paragraph splits diverged from ours; trust no
#     semantic signal in that case — fall back is clean)
#   - the AUTHOR-VOICE set is empty (would divide by zero)
semantic_fp_ratio = "N/A"
semantic_fp_paras = "N/A"
semantic_author_paras = "N/A"
semantic_status = "absent"
AUTHOR_CLASSES = {"ANCHOR-NARRATIVE", "ANALYTICAL-AUTHOR"}
VALID_CLASSES = AUTHOR_CLASSES | {"EXPOSITORY-THIRDPARTY", "DIALOGUE", "META-STRUCTURAL"}

if classifier_path:
    try:
        with open(classifier_path, encoding="utf-8", errors="replace") as f:
            art = f.read()
    except OSError:
        art = ""
    if art:
        # Parse the per-paragraph table. Format:
        #   | Para # | Lines | Class | Rationale |
        # First two table rows are header + separator; remaining rows
        # are data. We accept any row beginning with `|` whose second
        # cell parses as an integer (the para #) and whose fourth cell
        # is one of the valid classes.
        rows = []
        for line in art.split("\n"):
            line = line.strip()
            if not line.startswith("|"): continue
            cells = [c.strip() for c in line.strip("|").split("|")]
            if len(cells) < 3: continue
            try:
                para_idx = int(cells[0])
            except ValueError:
                continue
            cls = cells[2] if len(cells) >= 3 else ""
            if cls in VALID_CLASSES:
                rows.append((para_idx, cls))
        # Check classification completeness vs our paragraph count.
        if rows and abs(len(rows) - total_paragraphs) <= 1:
            # Index by para # (1-based). Match against our paragraph
            # array (0-based).
            sem_num = 0
            sem_den = 0
            for (idx, cls) in rows:
                if cls not in AUTHOR_CLASSES: continue
                sem_den += 1
                pos = idx - 1
                if 0 <= pos < total_paragraphs:
                    if FP_RE.search(paragraphs[pos]):
                        sem_num += 1
            if sem_den > 0:
                semantic_fp_ratio = f"{sem_num / sem_den:.4f}"
                semantic_fp_paras = str(sem_num)
                semantic_author_paras = str(sem_den)
                semantic_status = "fresh"
            else:
                semantic_status = "empty-author-set"
        elif rows:
            semantic_status = "mismatch"
        else:
            semantic_status = "unparseable"

print(f"{total_paragraphs}|{fp_paragraphs}|{fp_ratio:.4f}|{int(s_median)}|{s_mean:.2f}|{s_max}|{total_sentences}|{total_words}|{semantic_fp_ratio}|{semantic_fp_paras}|{semantic_author_paras}|{semantic_status}")
PY
)

IFS='|' read -r TOTAL_PARAS FP_PARAS FP_RATIO S_MEDIAN S_MEAN S_MAX TOTAL_SENTS TOTAL_WORDS SEM_FP_RATIO SEM_FP_PARAS SEM_AUTHOR_PARAS SEM_STATUS <<<"$METRICS"

# Surface the python-side status when richer than the bash-side mtime
# probe. The python status reports "mismatch" / "empty-author-set" /
# "unparseable" — cases the mtime probe alone can't see.
if [ "$CLASSIFIER_STATUS" = "FRESH" ] && [ "$SEM_STATUS" != "fresh" ]; then
    case "$SEM_STATUS" in
        mismatch)            CLASSIFIER_STATUS="MISMATCH" ;;
        empty-author-set)    CLASSIFIER_STATUS="EMPTY-AUTHOR-SET" ;;
        unparseable)         CLASSIFIER_STATUS="UNPARSEABLE" ;;
    esac
fi

# Per-chapter classification — informational. The trend audit is what
# fails on cross-chapter drift. Bands:
#   - FP ratio < (target * 0.5)  ⇒  WARN — single-chapter outlier
#   - FP ratio < (target * 0.75) ⇒  INFO — under target but plausible
#   - else                       ⇒  PASS
FP_CLASS="PASS"
fp_warn_threshold=$(awk -v t="$FP_TARGET" 'BEGIN{printf "%.4f", t*0.5}')
fp_info_threshold=$(awk -v t="$FP_TARGET" 'BEGIN{printf "%.4f", t*0.75}')
if awk -v r="$FP_RATIO" -v th="$fp_warn_threshold" 'BEGIN{exit !(r < th)}'; then
    FP_CLASS="WARN"
elif awk -v r="$FP_RATIO" -v th="$fp_info_threshold" 'BEGIN{exit !(r < th)}'; then
    FP_CLASS="INFO"
fi

# Sentence-median band classification — informational.
SENT_CLASS="PASS"
if [ "$S_MEDIAN" -lt "$BAND_MIN" ] || [ "$S_MEDIAN" -gt "$BAND_MAX" ]; then
    SENT_CLASS="INFO"
fi

echo "=== VOICE METRICS AUDIT ==="
echo "Chapter: $CHAPTER_NAME"
if [ -n "$VOICE_PROFILE" ]; then
    echo "Voice profile: $VOICE_PROFILE"
else
    echo "Voice profile: (not present — using defaults)"
fi
echo ""
echo "--- Paragraph-level ---"
echo "  Total paragraphs:        $TOTAL_PARAS"
echo "  First-person paragraphs: $FP_PARAS"
echo "  FP ratio (syntactic):    $FP_RATIO  (target: $FP_TARGET)"
echo "  Classification:          $FP_CLASS"
echo ""
echo "--- Semantic FP ratio (v2.7.67 — requires paragraph-classifier) ---"
case "$CLASSIFIER_STATUS" in
    FRESH)
        echo "  Classifier status:       FRESH ($CLASSIFIER_ARTIFACT)"
        echo "  Author-voice paragraphs: $SEM_AUTHOR_PARAS  (ANCHOR-NARRATIVE + ANALYTICAL-AUTHOR)"
        echo "  FP within author-voice:  $SEM_FP_PARAS"
        echo "  Semantic FP ratio:       $SEM_FP_RATIO  (target: $FP_TARGET)"
        ;;
    STALE)
        echo "  Classifier status:       STALE (artifact older than chapter — re-run \`validate-dispatcher classify $CHAPTER_NAME\`)"
        ;;
    MISMATCH)
        echo "  Classifier status:       MISMATCH (artifact paragraph count diverges from chapter — re-run classifier)"
        ;;
    EMPTY-AUTHOR-SET)
        echo "  Classifier status:       EMPTY-AUTHOR-SET (no ANCHOR-NARRATIVE / ANALYTICAL-AUTHOR paragraphs — chapter is fully expository / dialogue / structural)"
        ;;
    UNPARSEABLE)
        echo "  Classifier status:       UNPARSEABLE (artifact present but no valid rows parsed)"
        ;;
    *)
        echo "  Classifier status:       ABSENT (run \`bash scripts/validate-dispatcher.sh \"<project>\" classify <N>\` for higher-fidelity drift signal)"
        ;;
esac
echo ""
echo "--- Sentence-level ---"
echo "  Total sentences:         $TOTAL_SENTS"
echo "  Total words:             $TOTAL_WORDS"
echo "  Sentence median:         $S_MEDIAN  (band: $BAND_MIN-$BAND_MAX)"
echo "  Sentence mean:           $S_MEAN"
echo "  Sentence max:            $S_MAX"
echo "  Classification:          $SENT_CLASS"
echo ""

# Ledger append — voice-trend-audit.sh reads this to compute window-mean
# and slope over the last N chapters. Header is created lazily on first
# write. When PROJECT is not supplied (ad-hoc invocation), skip the
# ledger update; the per-chapter summary still prints to stdout.
if [ -n "$PROJECT" ]; then
    LEDGER="$PROJECT/engine-data/reports/voice-metrics-ledger.md"
    mkdir -p "$(dirname "$LEDGER")"
    if [ ! -f "$LEDGER" ]; then
        cat > "$LEDGER" <<'HDR'
# Voice Metrics Ledger

Per-chapter author-voice measurements. Each row is one
`voice-metrics-audit.sh` run. `voice-trend-audit.sh` reads this
ledger to compute window-mean + slope across chapters; the
trend audit is what fails on drift, this ledger is the data.

Columns:
  - timestamp:       audit run time
  - chapter:         chapter basename (e.g. ch07)
  - total_paras:     total paragraphs (post-frontmatter, post-heading)
  - fp_paras:        paragraphs containing first-person pronouns
  - fp_ratio:        fp_paras / total_paras (syntactic — v2.7.65)
  - sent_median:     median sentence length (words)
  - sent_mean:       mean sentence length (words)
  - sent_max:        max sentence length (words)
  - fp_class:        per-chapter band (PASS / INFO / WARN)
  - words:           total word count (informational; word-count-check
                     is the canonical word-count audit)
  - semantic_fp_ratio: FP-presence within {ANCHOR-NARRATIVE ∪
                     ANALYTICAL-AUTHOR} paragraphs only — populated
                     when a fresh paragraph-classifier artifact exists
                     for the chapter (v2.7.67); "N/A" otherwise
  - classifier_status: ABSENT / FRESH / STALE / MISMATCH /
                     EMPTY-AUTHOR-SET / UNPARSEABLE (v2.7.67)

| Timestamp | Chapter | Total paras | FP paras | FP ratio | Sent median | Sent mean | Sent max | FP class | Words | Semantic FP ratio | Classifier status |
|---|---|---|---|---|---|---|---|---|---|---|---|
HDR
    fi
    printf '| %s | %s | %d | %d | %s | %d | %s | %d | %s | %d | %s | %s |\n' \
        "$TIMESTAMP" "$CHAPTER_NAME" "$TOTAL_PARAS" "$FP_PARAS" "$FP_RATIO" \
        "$S_MEDIAN" "$S_MEAN" "$S_MAX" "$FP_CLASS" "$TOTAL_WORDS" \
        "$SEM_FP_RATIO" "$CLASSIFIER_STATUS" \
        >> "$LEDGER"
    echo "  → Appended to: $LEDGER"
fi

echo ""
echo "=== SUMMARY ==="
echo "Paragraphs: $TOTAL_PARAS | FP ratio: $FP_RATIO ($FP_CLASS) | Sent median: $S_MEDIAN ($SENT_CLASS)"
echo "STATUS: PASS (per-chapter metrics are informational; see voice-trend-audit for drift detection)"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
