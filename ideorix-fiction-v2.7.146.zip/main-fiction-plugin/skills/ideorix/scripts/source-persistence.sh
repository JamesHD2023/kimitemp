#!/bin/bash
# ============================================================
# Ideorix Source Persistence Helper
# Persists a user-uploaded file to the canonical project folder
# (manuscript/ for primary inputs; source-canon/ for
# supplementary canon) and verifies the write per File-Write
# Hygiene. Single source of truth for the persistence operation
# invoked by the Source Persistence binding.
#
# Used by every flow that accepts user uploads beyond the
# primary input: Edit & Revise, Manuscript Clinic, Continue
# Writing, Continue Researching, Heritage Text, Analyze a Book.
# (BYO-canon Step 0 and the importers handle their own
# persistence; this script is for the supplementary-upload
# pattern.)
#
# Usage:
#   source-persistence.sh <staged-content-file> <project-path> <category> <original-filename>
#
# Args:
#   staged-content-file  — Engine-supplied tempfile (e.g. /tmp/{name}) holding
#                          the bytes the engine absorbed via Read tool. The
#                          engine writes Read content here, then calls this
#                          script to persist.
#   project-path         — ~/Documents/Ideorix-Projects/{Title}/ (absolute path)
#   category             — "primary" or "supplementary"
#   original-filename    — The user's original filename (used for the destination
#                          basename; preserves their naming).
#
# Exit:
#   0 = persisted successfully + canon-absorbed.md updated
#   1 = persistence failed (write error, ls verification failed, byte mismatch)
#   2 = invocation error (missing file, bad category, etc.)
# ============================================================
set -euo pipefail

usage() {
    echo "Usage: source-persistence.sh <staged-file> <project-path> <category> <original-filename>"
    echo "  category: primary | supplementary"
    exit 2
}

STAGED="${1:-}"
PROJECT="${2:-}"
CATEGORY="${3:-}"
ORIG_NAME="${4:-}"

if [ -z "$STAGED" ] || [ -z "$PROJECT" ] || [ -z "$CATEGORY" ] || [ -z "$ORIG_NAME" ]; then
    usage
fi

if [ ! -f "$STAGED" ]; then
    echo "ERROR: staged content file not found: $STAGED"
    exit 2
fi

if [ ! -d "$PROJECT" ]; then
    echo "ERROR: project path does not exist (or is not a directory): $PROJECT"
    exit 2
fi

case "$CATEGORY" in
    primary|supplementary) ;;
    *) echo "ERROR: category must be 'primary' or 'supplementary' (got: $CATEGORY)"; exit 2 ;;
esac

# Determine destination based on category.
if [ "$CATEGORY" = "primary" ]; then
    DEST_DIR="$PROJECT/manuscript"
else
    DEST_DIR="$PROJECT/source-canon"
fi

# Ensure dest dir exists.
mkdir -p "$DEST_DIR"
if [ ! -d "$DEST_DIR" ]; then
    echo "FAILED_PERSIST: could not create destination directory: $DEST_DIR"
    exit 1
fi

DEST_FILE="$DEST_DIR/$ORIG_NAME"

# Portable sha256 — macOS has no `sha256sum`; it ships `shasum -a 256`.
_sha256() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$1" | awk '{print $1}'
    else
        shasum -a 256 "$1" | awk '{print $1}'
    fi
}

# Conflict check — if a file already exists at the destination, the engine
# (not this script) handles the merge/rename/skip decision via
# AskUserQuestion. This script just refuses to overwrite silently.
if [ -e "$DEST_FILE" ]; then
    EXISTING_HASH=$(_sha256 "$DEST_FILE")
    NEW_HASH=$(_sha256 "$STAGED")
    if [ "$EXISTING_HASH" = "$NEW_HASH" ]; then
        # Already persisted, identical content. Idempotent — succeed.
        echo "[PASS] source-persistence (idempotent — content already at $DEST_FILE)"
        BYTES=$(wc -c < "$DEST_FILE")
        SHA_FULL=$NEW_HASH
    else
        echo "FAILED_PERSIST: destination exists with different content: $DEST_FILE"
        echo "  existing sha256: $EXISTING_HASH"
        echo "  new sha256:      $NEW_HASH"
        echo "  Engine MUST surface to user via AskUserQuestion (replace / rename / skip)"
        exit 1
    fi
else
    # Atomic write: copy via /tmp staging then mv (replaces inode, bypasses cache).
    # The staged file is already in /tmp by convention, so cp + sync is sufficient.
    if ! cp -f "$STAGED" "$DEST_FILE"; then
        echo "FAILED_PERSIST: cp exited non-zero copying $STAGED -> $DEST_FILE"
        exit 1
    fi
    sync

    # Verify per File-Write Hygiene: ls + byte-count + sha256.
    if [ ! -f "$DEST_FILE" ]; then
        echo "FAILED_PERSIST: write succeeded but file not visible at destination: $DEST_FILE"
        exit 1
    fi

    BYTES_STAGED=$(wc -c < "$STAGED")
    BYTES=$(wc -c < "$DEST_FILE")
    if [ "$BYTES_STAGED" -ne "$BYTES" ]; then
        echo "FAILED_PERSIST: byte count mismatch (staged: $BYTES_STAGED, destination: $BYTES)"
        exit 1
    fi

    SHA_FULL=$(_sha256 "$DEST_FILE")
    SHA_STAGED=$(_sha256 "$STAGED")
    if [ "$SHA_FULL" != "$SHA_STAGED" ]; then
        echo "FAILED_PERSIST: sha256 mismatch (content corrupted in transit)"
        exit 1
    fi

    echo "[PASS] source-persistence — $DEST_FILE ($BYTES bytes)"
fi

# Update canon-absorbed.md (append entry).
ENGINE_DATA="$PROJECT/engine-data"
mkdir -p "$ENGINE_DATA"
MARKER="$ENGINE_DATA/canon-absorbed.md"

TIMESTAMP=$(date -u +%Y-%m-%dT%H-%M)
SHA_SHORT=$(echo "$SHA_FULL" | cut -c1-16)

# First-200-char excerpt (text files only; binary files get a "[binary]" placeholder).
EXCERPT=""
if file "$DEST_FILE" 2>/dev/null | grep -qE 'text|XML|HTML|JSON|empty'; then
    EXCERPT=$(head -c 200 "$DEST_FILE" | tr '\n' ' ' | tr -s ' ' | sed 's/|/\\|/g')
else
    EXCERPT="[binary content — open in original application to view]"
fi

# Initialize marker file if absent.
if [ ! -f "$MARKER" ]; then
    cat > "$MARKER" <<EOF
# Canon Absorbed — $(basename "$PROJECT")

Each session block below records what the engine absorbed
and where it persisted the content. Spot-check the excerpt
column against your original file to confirm the engine
captured what you intended.

EOF
fi

# Append session block. If the same session timestamp already exists, append
# to it; otherwise create a new block. Simplest implementation: always append
# a row — the engine groups by session via the timestamp column.
{
    echo ""
    echo "## Session $TIMESTAMP — entry"
    echo ""
    echo "| File | Category | Persisted to | sha256 (first 16) | First-200-char excerpt |"
    echo "|------|----------|--------------|-------------------|-------------------------|"
    echo "| $ORIG_NAME | $CATEGORY | $(echo "$DEST_FILE" | sed "s|$PROJECT/||") | $SHA_SHORT | $EXCERPT |"
} >> "$MARKER"

echo "  marker updated: $MARKER"
echo "  category: $CATEGORY"
echo "  bytes: $BYTES"
echo "  sha256 (first 16): $SHA_SHORT"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
