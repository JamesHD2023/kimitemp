#!/bin/bash
# ============================================================
# Ideorix Mechanical Audit — Module 6: Entity Canon Verification
# Extracts proper nouns from chapter, checks against entity-canon.md.
# Reports drift (names not in canon) and forbidden AI names.
# ============================================================
# Usage (two forms — v2.7.40 dual signature):
#
#   Legacy form (ideorix-audit.sh caller):
#     bash entity-canon-verify.sh <chapter-file> <entity-canon-file> [forbidden-words-file]
#
#   Dispatcher form (validate-dispatcher.sh CHAPTER_PROJECT class):
#     bash entity-canon-verify.sh <chapter-file> <project-root>
#
# The script detects arg 2 by `[ -d ]` test: a directory is interpreted
# as project root (resolves canon at $project/engine-data/entity-canon.md
# and gracefully skips if the file is absent — matches NF behavior); a
# file is interpreted as the canon file path directly (legacy form).
# Pre-v2.7.40 only the legacy form was supported, which broke the
# v2.7.29 dispatcher's CHAPTER_PROJECT contract for fiction projects.

set -euo pipefail

CHAPTER="${1:?Usage: entity-canon-verify.sh <chapter-file> <entity-canon-file-or-project-root>}"
ARG2="${2:?Usage: entity-canon-verify.sh <chapter-file> <entity-canon-file-or-project-root>}"
FORBIDDEN="${3:-}"

if [ ! -f "$CHAPTER" ]; then echo "ERROR: Chapter file not found: $CHAPTER"; exit 1; fi
if [ ! -s "$CHAPTER" ]; then echo "ERROR: Chapter file is empty: $CHAPTER"; exit 1; fi

# Resolve the canon file: arg-2 is either the canon file directly
# (legacy form) or a project root (dispatcher form).
if [ -d "$ARG2" ]; then
    CANON="$ARG2/engine-data/entity-canon.md"
    # Dispatcher form: graceful skip if no canon present (matches NF
    # contract; lets fiction projects without an entity-canon.md run
    # the dispatcher cleanly rather than producing a hard FAIL).
    if [ ! -f "$CANON" ]; then
        echo "=== ENTITY CANON VERIFICATION (skipped) ==="
        echo "  N/A — no entity-canon.md found at $CANON"
        exit 0
    fi
elif [ -f "$ARG2" ]; then
    CANON="$ARG2"
else
    echo "ERROR: arg 2 is neither a file nor a directory: $ARG2"
    exit 1
fi

TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

FAIL=0
DRIFT_FAIL=0

echo "=== ENTITY CANON VERIFICATION ==="
echo "Chapter: $CHAPTER"
echo "Canon: $CANON"
echo ""

# Extract only canonical names (col 2) and aliases (col 3) from the markdown table.
# Skip header row (contains 'Canonical') and separator rows (contain ---).
awk -F'|' '
    NR==1 || /^\s*\|[-:\s|]+\|\s*$/ { next }
    /\| *Canonical *\|/ { next }
    NF>=3 {
        gsub(/^ +| +$/, "", $2); gsub(/^ +| +$/, "", $3);
        if ($2 != "" && $2 !~ /^Canonical$/i) print tolower($2)
        if ($3 != "") {
            n = split($3, a, /, */)
            for (i=1; i<=n; i++) {
                gsub(/^ +| +$/, "", a[i])
                if (a[i] != "" && a[i] !~ /^Aliases$/i) print tolower(a[i])
            }
        }
    }
' "$CANON" | sort -u > "$TMPDIR/authorised.txt"

# Load real-world entities allowlist (cities, brands, public bodies, document
# field labels, languages, demonyms, calendar / clock terms, currency, well-
# known historical names). The allowlist ships with the plugin and is
# loaded alongside the project's entity-canon.md so that real-world
# capitalised tokens that legitimately appear in chapter prose are not
# flagged as canon drift (Cowork bug report 2026-05-01).
ALLOWLIST="$(dirname "$0")/../references/allowed-real-world-entities.md"
ALLOWLIST_LOADED=0
if [ -f "$ALLOWLIST" ]; then
    awk '
        /^---/ || /^#/ || /^>/ || /^</ { next }
        /^\s*$/ { next }
        {
            n = split($0, words, /[[:space:],.;:()"\[\]]+/)
            for (i = 1; i <= n; i++) {
                w = words[i]
                if (w ~ /^[A-Z][a-zA-Z]+$/) print tolower(w)
            }
        }
    ' "$ALLOWLIST" >> "$TMPDIR/authorised.txt"
    ALLOWLIST_LOADED=1
fi
sort -u -o "$TMPDIR/authorised.txt" "$TMPDIR/authorised.txt"

# Canon state marker. When canon is still being built (e.g. before a
# batch-editor checkpoint), the project can mark it `expanding` so
# per-chapter drift surfaces as WARN rather than FAIL — drift entries
# represent new entities awaiting canon expansion, not violations.
# Forbidden AI-name hits below remain hard-FAIL regardless of state.
# Default (no marker) is `locked` = strict / current behavior.
# Marker format: a line in the first 10 of the canon file matching
# `<!-- canon-state: expanding -->`.
CANON_STATE="locked"
if head -10 "$CANON" | grep -qiE '<!--[[:space:]]*canon-state:[[:space:]]*expanding'; then
    CANON_STATE="expanding"
fi

AUTH_COUNT=$(wc -l < "$TMPDIR/authorised.txt")
if [ "$ALLOWLIST_LOADED" -eq 1 ]; then
    echo "Authorised names/aliases loaded: $AUTH_COUNT (project canon + real-world allowlist)"
else
    echo "Authorised names/aliases loaded: $AUTH_COUNT"
fi
echo "Canon state: $CANON_STATE"

# Strip appendix content from the chapter before extracting proper nouns.
# Reference tables, ingredient lists, and bibliographic entries in
# appendices flood the candidate list with hundreds of false positives
# (chemical additives, brand names, technical lookup keys). Stop at the
# first heading that begins with '# Appendix' (any heading depth, case-
# insensitive). Authors with non-standard appendix labels can rename
# them or split appendix content to a separate file.
APPENDIX_LINE=$(awk 'tolower($0) ~ /^#+[[:space:]]*appendix/ { print NR; exit }' "$CHAPTER")
if [ -n "$APPENDIX_LINE" ]; then
    head -n $((APPENDIX_LINE - 1)) "$CHAPTER" > "$TMPDIR/body.txt"
    echo "Appendix detected at line $APPENDIX_LINE — content below excluded from canon scan"
else
    cp "$CHAPTER" "$TMPDIR/body.txt"
fi

# Extract capitalised proper-noun candidates with multi-pass filtering.
# The prior single-line s/// stripped only single-word sentence starts and
# missed multi-word sentence-start cases, dialogue-opening capitals, and
# line-start capitals. The result was the candidate list filling with
# "Did", "What", "You", "Something", "Maybe", "Right", "Now", "Then" and
# similar (Cowork bug report 2026-05-01). The replacement uses slurp-mode
# perl (-0777) so sentence boundaries that span line breaks are honoured,
# and the candidates are post-filtered through a stoplist of common
# pronouns, question-words, temporal markers, and structural words.
perl -e '
    use strict;
    use warnings;
    my $text = "";
    while (my $line = <STDIN>) {
        next if $line =~ /^#/;                  # skip markdown headings
        $text .= $line;
    }

    # Strip sentence-starting capitalised words (after . ! ? or at document start).
    $text =~ s/(?:^|(?<=[.!?])\s+)([A-Z][a-z]+)/ STRIPPED /g;

    # Strip dialogue-opening capitalised words: "Word
    $text =~ s/"([A-Z][a-z]+)/" STRIPPED /g;

    # Strip paragraph-start capitals (after a blank line).
    $text =~ s/(\n\n+)([A-Z][a-z]+)/$1STRIPPED/g;

    # Extract remaining capitalised tokens (single word or multi-word names)
    my %seen;
    while ($text =~ /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g) {
        my $tok = $1;
        next if length($tok) < 2;
        $seen{$tok}++;
    }

    # Stoplist for sentence-starters that slipped through
    my @stoplist = qw(
        The This That These Those There They Their Them
        He She His Her Hers Him
        It Its
        I We You Your Yours Our Ours
        Now Then When Where Why How What Which Who Whom Whose
        Yes No Maybe Sure Right Help OK Okay Hello Hi Hey
        And But Or So Yet Nor For
        After Before Until While Since Although Though If Unless
        Did Do Does Done Tell Told Said Say Says
        Something Someone Somewhere Anything Anyone Anywhere
        Nothing Nobody Nowhere Everything Everyone Everywhere
        Today Yesterday Tomorrow Tonight
        Chapter Part Book Volume Section Page
        Mr Mrs Miss Ms Dr Sir Madam Lord Lady
    );
    my %stop = map { $_ => 1 } @stoplist;

    for my $name (sort keys %seen) {
        next if $stop{$name};
        print "$name\n";
    }
' < "$TMPDIR/body.txt" > "$TMPDIR/candidates.raw" || {
    # v2.7.139: a perl runtime error (encoding issue, regex exception) used
    # to flow into an empty candidate list, which the drift check below
    # reported as "CLEAN — all proper nouns match canon". An audit that
    # could not run must say so (exit 2 = SKIP in the dispatcher contract),
    # never present itself as a clean pass.
    echo "ERROR: proper-noun extraction failed (perl exited non-zero) — audit cannot verify this chapter"
    echo "STATUS: SKIP"
    exit 2
}
# grep -v exits 1 on empty input (a chapter whose capitalised tokens are all
# stop-listed); that is a legitimate zero-candidate result, not an error —
# without the || true it would abort the script under set -e -o pipefail.
grep -v '^$' "$TMPDIR/candidates.raw" | sort -u > "$TMPDIR/candidates.txt" || true

# Remove common English words that happen to be capitalised (sentence starts)
# Keep only words that appear mid-sentence at least once
CAND_COUNT=$(wc -l < "$TMPDIR/candidates.txt")
echo "Proper-noun candidates found: $CAND_COUNT"

echo ""
echo "--- Canon Compliance ---"
DRIFT_COUNT=0
while IFS= read -r name; do
    lower_name=$(echo "$name" | tr '[:upper:]' '[:lower:]')

    # Common-word fast path (months, days, honorifics, function words).
    case "$lower_name" in
        january|february|march|april|may|june|july|august|september|october|november|december) continue ;;
        monday|tuesday|wednesday|thursday|friday|saturday|sunday) continue ;;
        the|and|but|not|she|her|his|him|they|them|was|were|had|has|have) continue ;;
        mrs|mr|miss|dr|sir|saint|st) continue ;;
    esac

    # Whole-name lookup. Substring-match (grep -qF) so extracted partial
    # names match longer canon entries (e.g. extracted "National Institutes"
    # matches canon "National Institutes of Health" because "of" / "the" /
    # "and" are lowercase function words the proper-noun extractor stops
    # on). False-positive risk (shorter name appearing inside longer canon
    # entry) is acceptable: in practice the shorter name IS the legitimate
    # reference to the longer entity.
    if grep -qF "$lower_name" "$TMPDIR/authorised.txt" 2>/dev/null; then
        continue
    fi

    # Multi-word fallback: a multi-word candidate (e.g. "Cheshire Constabulary")
    # is allowed if EVERY word is in the authorised set. This handles the
    # common case where the allowlist tokenises real-world entries into
    # individual capitalised tokens (cities, brands, public bodies).
    if [[ "$lower_name" == *" "* ]]; then
        all_words_authorised=1
        for word in $lower_name; do
            if ! grep -qFx "$word" "$TMPDIR/authorised.txt" 2>/dev/null; then
                all_words_authorised=0
                break
            fi
        done
        if [ "$all_words_authorised" -eq 1 ]; then
            continue
        fi

        # Street / infrastructure suffix pattern: "Hathersage Road",
        # "Brunswick Street", "Plymouth Grove" — accept any "Word Suffix"
        # form where Suffix is a recognised infrastructure / address term.
        # The leading word may be a real local name not in any allowlist;
        # the suffix tells us this is a street / address reference rather
        # than a character / fictional-place drift.
        last_word="${lower_name##* }"
        case "$last_word" in
            road|street|avenue|lane|drive|crescent|close|square|terrace|hill|mews|gardens|place|way|walk|park|common|green|bridge|station|junction|roundabout|motorway|bypass|highway|grove|court|gate|view|fields|meadow|estate|circus|row|rise|wynd|brae|loan|vennel|pend|wharf|quay|embankment|parade|broadway|boulevard) continue ;;
        esac
    fi

    echo "  DRIFT: \"$name\" — not in entity canon"
    DRIFT_COUNT=$((DRIFT_COUNT + 1))
done < "$TMPDIR/candidates.txt"

if [ "$DRIFT_COUNT" -eq 0 ]; then
    echo "  CLEAN — all proper nouns match canon"
else
    echo "  $DRIFT_COUNT drift item(s) found"
    # Drift contributes to FAIL only when canon is locked. When canon-state
    # is `expanding`, drift surfaces as WARN (see SUMMARY logic below).
    # AI-name / AI-place hits set FAIL directly and remain hard-FAIL
    # regardless of canon state.
    DRIFT_FAIL=1
fi

# Check for forbidden AI names if forbidden-words file provided
if [ -n "$FORBIDDEN" ] && [ -f "$FORBIDDEN" ]; then
    echo ""
    echo "--- Forbidden AI Names ---"
    AI_NAMES="Elara|Luna|Aurora|Willow|Sage|Ivy|Wren|Ember|Rowan|Juniper|Seraphina|Isolde"
    AI_NAMES="$AI_NAMES|Thorne|Ash|Jasper|Hawthorne|Sterling|Orion|Caspian|Silas|Gideon|Alaric"
    AI_NAMES="$AI_NAMES|Kai|Zephyr|Atlas|Beckett|Declan|Lysander|Evander|Callum|Rhys|Soren"

    # v2.7.139: distinguish grep "no matches" (exit 1 → count 0) from grep
    # "could not run" (exit ≥ 2: unreadable file, regex/encoding error). The
    # prior `|| echo 0` collapsed both into a clean zero count, so a chapter
    # the scan couldn't read reported PASS. An audit that cannot run must
    # say so (exit 2 = SKIP in the dispatcher contract).
    set +e
    AI_HITS=$(grep -ocEi "\b($AI_NAMES)\b" "$CHAPTER" 2>/dev/null)
    GREP_RC=$?
    set -e
    if [ "$GREP_RC" -ge 2 ]; then
        echo "  ERROR: forbidden-name scan could not run (grep exit $GREP_RC) on $CHAPTER"
        echo "STATUS: SKIP"
        exit 2
    fi
    [ "$GREP_RC" -eq 1 ] && AI_HITS=0
    echo "  Forbidden AI name matches: $AI_HITS"
    if [ "$AI_HITS" -gt 0 ]; then
        grep -onEi "\b($AI_NAMES)\b" "$CHAPTER" | head -5 | sed 's/^/    /'
        FAIL=1
    else
        echo "  STATUS: PASS"
    fi

    echo ""
    echo "--- Forbidden AI Place Names ---"
    AI_PLACES="Willowbrook|Maplewood|Ravenwood|Thornfield|Briarwood|Shadowvale|Moonhaven"
    AI_PLACES="$AI_PLACES|Starfall|Crystalbrook|Silvermist|Whispering Pines|Enchanted Hollow"

    # Same exit-code discrimination as the name scan above (v2.7.139).
    set +e
    PLACE_HITS=$(grep -ocEi "\b($AI_PLACES)\b" "$CHAPTER" 2>/dev/null)
    GREP_RC=$?
    set -e
    if [ "$GREP_RC" -ge 2 ]; then
        echo "  ERROR: forbidden-place scan could not run (grep exit $GREP_RC) on $CHAPTER"
        echo "STATUS: SKIP"
        exit 2
    fi
    [ "$GREP_RC" -eq 1 ] && PLACE_HITS=0
    echo "  Forbidden AI place name matches: $PLACE_HITS"
    [ "$PLACE_HITS" -gt 0 ] && FAIL=1 || echo "  STATUS: PASS"
fi

echo ""
echo "=== SUMMARY ==="
echo "Canon entries: $AUTH_COUNT | Candidates: $CAND_COUNT | Drift: $DRIFT_COUNT | State: $CANON_STATE"

if [ "$FAIL" -eq 1 ]; then
    # AI name/place hit — hard FAIL regardless of canon state.
    echo "STATUS: FAIL"
    exit 1
fi
if [ "$DRIFT_FAIL" -eq 1 ]; then
    if [ "$CANON_STATE" = "expanding" ]; then
        echo "STATUS: WARN — $DRIFT_COUNT proper noun(s) not yet in canon (canon-state: expanding)"
        echo "Action: drift items above represent new entities awaiting canon expansion. They will need to be added (or fixed if typos) at the canon-lock checkpoint."
        exit 0
    fi
    echo "STATUS: FAIL"
    exit 1
fi
echo "STATUS: PASS"
exit 0
# ============================================================
# DEFENSIVE PAD — do not edit. Protects against plugin install
# hosts that truncate updated files to the previous version's
# byte count when the new file is larger. Truncation cuts pad
# bytes; the executable body above (terminated by `exit N`)
# survives. See CLAUDE.md > Defensive Pad.
# ============================================================
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
# ..............................................................
